# CHANGELOG — Audit-fix pass 4: host-side link timing, new logo, settings redesign

**Unverified on device** (same caveats as passes 1-3: no Kotlin compiler,
Android toolchain or mGBA source in the sandbox). Native logic is covered by
`tools/native-link-test/run_regs.sh`, now 60+ checks including the new timing
behaviour against a stub of mGBA's event queue.

## 14. Host transfers now complete after a realistic delay, not inside the write (`mgba_jni.c`)
This was the "still open — most likely next suspect" from pass 3.
`link_sio_write_register()` used to do the whole transfer inside the ROM's
SIOCNT write: data in SIOMULTI, IRQ raised, Start/Busy already clear. Link code
is written around a ~1 ms transfer, typically `SIOCNT |= START; state =
PENDING;` with the SIO interrupt setting `state = DONE` later. Here the IRQ
fired between those two statements, so the ISR ran first and the ROM then
overwrote DONE with PENDING — waiting forever. Polling code never saw busy set.
Now the network exchange still happens inside the write (emulated time is
frozen while it blocks), but its result is held back: the write returns with
Start/Busy set and an mGBA timing event (`mTimingSchedule`) delivers
SIOMULTI0-3, clears busy, sets/clears the error flag and raises the IRQ after
44 bit-times at the ROM's baud rate (6,410 cycles at 115,200 baud; 12,820 /
19,225 / 76,900 for the slower rates) — in emulated time, identical on every
phone. While busy, a second Start is ignored and software can't clear the bit,
as on hardware. Teardown is handled: link stop clears a stuck busy bit (the
event stays queued and fires harmlessly — it is never scheduled twice), ROM
swap and save-state load drop the bookkeeping because the event queue itself
was discarded.
**If the build log complains** about `mTimingSchedule`, `struct mTimingEvent`
or `gba->timing`, set `LINK_HOST_DEFERRED_COMPLETION` to 0 (top of the link
globals) — that is the only code touching mGBA's timing API, and everything
else keeps working with the old instant behaviour.

## 15. New launcher icon and in-app logo
Was a single flat 108dp vector used as a plain drawable (so launchers boxed it
as a legacy icon). Now a proper adaptive icon — gradient background, a handheld
with screen/d-pad/buttons in the foreground, plus a monochrome layer for
Android 13 themed icons — with PNG fallbacks for API 24-25 (`mipmap-*`). The
same artwork appears as a rounded badge in the Settings header and About
dialog (`ic_logo_badge.xml`). All generated from one geometry definition:
`python3 tools/gen_launcher_icon.py` (preview: `tools/launcher_icon_preview.png`).

## 16. Settings redesign
- Menu is grouped into cards (Display & sound / Controls / Gameplay & data /
  Multiplayer / System) with tinted icon chips, chevrons and a logo header
  showing the version.
- **Misc is now "Gameplay"** and applies changes instantly (no Save/Cancel):
  fast-forward is a 0.5x-16x slider instead of a text box; toggles for the
  performance overlay and auto save & load as before; and two new options:
  - **Haptic feedback** (+ light/medium/strong): a short vibration on the press
    edge of an on-screen button. Uses the Vibrator service directly (new
    `VIBRATE` permission, granted at install) so it works regardless of the
    system touch-feedback switch.
  - **Confirm before Reset / Close** (default ON): asks before the two game-menu
    entries that discard unsaved progress.
- Advanced -> Reset settings covers the new options.
- About shows the logo and the mGBA (MPL 2.0) licence line.

---

# CHANGELOG — Audit-fix pass 3: multiplayer ("works in the app, not in the ROM")

**Unverified on device.** No Kotlin compiler, Android toolchain, mGBA source
or second phone in the sandbox. What IS verified: the new native logic
(`link_mailbox.h`, the SIO register code, the child exchange) runs against
stubs under ASan/UBSan/TSan (`tools/native-link-test/run.sh` and
`run_regs.sh`, 50+ checks), and the transport bug below is reproduced in a
small model (`tools/link-transport-model/model.py`). Whether this makes any
given ROM's link screen work is a question only a real two-phone test can
answer — please capture "Copy link log" on BOTH phones.

## 11. Host mistook keepalives/stale packets for the reply (`LinkMultiplayer.kt`)
`wifiExchange()` and `btExchange()` treated the FIRST packet/frame to arrive
as the reply. The child sends a KEEPALIVE every 2 s, so sooner or later one
arrived first: that round failed, the real reply stayed queued, and the next
round consumed it — every transfer after that was answered with the
PREVIOUS transfer's data. The only guard (reject an exact repeat of the last
seq) can't recognise an older reply. Multi-Player link code is lock-step, so
this alone can make a ROM's handshake fail while the app-level connection
looks fine.
**Fix:** the reply must carry the request's seq (child echoes it; Wi-Fi byte
3, Bluetooth byte 3 — the old unused upper half of the 32-bit word);
everything else is discarded and the wait continues. Wi-Fi resends once after
60 ms (child de-duplicates by seq and re-sends its cached reply — never
re-delivers to the ROM). After 3 consecutive failures the host only waits
40 ms per transfer until one succeeds, so an unresponsive peer can't freeze
host emulation. A child with nothing to say stays silent instead of sending a
made-up word. Host waits raised 30/50 ms -> 150/200 ms (see 12).

## 12. Child answered from the network thread, out of step with its CPU (`mgba_jni.c`, new `link_mailbox.h`)
The child wrote SIOMULTI/IRQ from the network thread and replied instantly
with whatever SIOMLT_SEND held. A host ROM in its connect loop fires
transfers as fast as the network allows, so many landed between two child
frames: the child's ISR saw a sample of them and every reply carried stale
data. Now the network thread posts into a mailbox and BLOCKS; the game thread
takes at most ONE request at the start of a frame, lands it, and releases the
reply (the word the ROM had staged at that moment, as on hardware). The
host's next request can only be delivered a frame later, after the ISR has
staged the next word. `LINK_CHILD_LOCKSTEP` (top of the link globals) turns
this off for an A/B test with one rebuild.
Cost: one transfer per child frame at most (~60/s). A ROM that fires more
than one transfer per frame will run its host side slower than before.

## 13. Child never saw its player ID / link status (`mgba_jni.c`)
Child-side SIOCNT updates (SD, SI, ID=1, busy) were written only into
`memory.io[]`, but mGBA serves SIOCNT reads from `gba->sio.siocnt` (the field
`nativeRunFrame()` already logs). Now written to both. Also: a child ROM's own
SIOCNT writes no longer reset its ID bits to 0 or set its read-only busy
bit; the SD/ID status is applied when the link starts if the ROM was already
in Multi-Player mode (link menu opened before connecting); SIOMULTI is only
written while the ROM is in Multi-Player mode (those addresses are shared
with SIODATA32); the SIO IRQ is only raised if the ROM enabled it (SIOCNT
bit 14), on both roles.

## Still open — most likely next suspect
**Instant completion on the host.** `link_sio_write_register()` performs the
whole transfer synchronously inside the ROM's SIOCNT write and returns with
busy already clear; the IRQ is raised before the ROM's next instruction. On
hardware the transfer takes ~1 ms (about 18,000 cycles), so a ROM that sets a
"transfer in progress" flag AFTER writing Start, expecting the ISR to clear it
later, can be left stuck. The fix is to schedule completion with mGBA's event
timer (`mTimingSchedule`), but that needs the exact timing API of the pinned
mGBA revision, whose source is not in this zip — a wrong guess breaks the
build — so it is NOT attempted blind. A capture from the next test would show
whether it matters: look for a host that keeps starting transfers right after
each completed one without the ROM's usual inter-transfer gap.

---

# CHANGELOG — Audit-fix pass 2

Second batch from the same audit. As before, the Kotlin is unverified on
device (no Kotlin compiler in the sandbox); the native JNI changes are covered
by a new host-side test, `tools/native-jni-test/run.sh` (16 checks under
ASan/UBSan — the same tests against the ORIGINAL code hit a heap-buffer-
overflow, so they do exercise the fix).

## 7. JNI argument validation (`mgba_jni.c`)
- `nativeRunFrame`: skips the frame (logging once) if the Bitmap is smaller
  than the core's 240x160 frame or its stride is too small; it used to write
  straight into the pixel memory assuming the right size.
- `nativeReadAudioSamples`: `maxSamples` (stereo pairs) is clamped to
  `GetArrayLength(jbuf) / 2`; NULL array / non-positive count return 0.
- `nativeReadMemory`: `length` is clamped to the array's size and to 64 KiB
  (it was unbounded, and ran under `g_core_mutex`); NULL array returns 0. The
  return value is now the bytes actually read — the only caller already
  formats exactly that many.
- `nativeLinkStart`: NULL link object and a failed `NewGlobalRef` now return
  false instead of crashing / storing a NULL global; the class local ref is
  released.

## 8. Crash logger installed once per process (`MainActivityDebugLog.kt`)
`installCrashLogger()` ran on every `onCreate()` and each call wrapped the
previous handler, so a crash ran N nested handlers and every handler's lambda
pinned its own destroyed `MainActivity` (via `filesDir`). Now guarded by a
process-wide latch and captures only a `File` from the application context.

## 9. `ndkVersion` moved to its real home (`app/build.gradle.kts`)
It sat inside `defaultConfig { ndk { } }`, which has no such property — it
only compiled through Kotlin's outer-receiver lookup. Same value, now
directly under `android { }`.

## 10. ROM browser / ROM staging
- Zips on disk are now checked for a `.gba` with `java.util.zip.ZipFile`
  (central directory only) instead of streaming the whole archive through a
  `ZipInputStream` (`RomZipUtils.kt`, `RomBrowserActivity.kt`).
- `stageRomFile()` stops at 64 MiB (a GBA cart is <= 32 MiB) so a mis-picked
  huge file or a zip bomb can't fill the cache (`MainActivityRom.kt`).

## Deliberately NOT changed
- **`mCoreConfigDeinit()` on core teardown:** the per-core config object
  looks like it is never freed (a small leak per ROM load), but whether
  `core->deinit()` already releases it depends on the pinned mGBA revision,
  whose source isn't in this zip. A wrong guess is a double free, so it's
  left alone until it can be checked against the real source.
- Link security, ROM-browser UI-thread directory listing, `gradle-wrapper.jar`
  (not in the zip — regenerate with `gradle wrapper`), targetSdk, release
  signing, and all architecture/feature items remain open.

---

# CHANGELOG — Audit-fix pass

From a full static code audit. Six fixes, all in response to bugs found by
reading the code; none of the Kotlin could be compiled here (no Kotlin
compiler / Android toolchain in the sandbox), so treat them as unverified on
device until built. The native save/load rewrite IS covered by a host-side
test (`tools/native-state-test/run.sh`, 16 checks under ASan/UBSan).

## 1. Battery saves were wiped on every ROM load and Reset (internal storage)
**Files:** `MainActivity.kt`, `MainActivitySaveStateCore.kt`, `MainActivityRom.kt`, `MainActivityDebugLog.kt`
**Problem:** pass 24 made `backupIfExists()` a rename (`X.sav` -> `X.sav.bak`).
`loadRomFromUri()` and `resetGame()` still called it right before
`nativeLoadROM()` opened `X.sav`, so the core created a fresh empty file and
the game started with no save; the next launch then overwrote the `.bak` too.
**Fix:** new `SaveEntry.copyInto()` / `backupBatteryIfExists()` — a copy that
leaves the original in place, written via temp + rename, and never replacing
a backup with an empty file. State slots keep the rename.

## 2. Saves collided between ROMs
**File:** `MainActivityRom.kt`
**Problem:** every save was keyed by the sanitized file name only, so a ROM
hack and its base game (or any same-named ROMs) shared one `.sav` and one set
of states; all-non-Latin titles collapsed to `____`.
**Fix:** key is now `<name>_<CRC32 of the ROM>`; Unicode letters/digits are
kept in the name. Existing saves are COPIED (never moved) to the new key for
the first ROM that loads under an old key (`migrateLegacyRomFiles`); old
files are left in place.

## 3. Link BYE was never sent on Disconnect
**File:** `LinkMultiplayer.kt`
**Problem:** `disconnect()` runs on the main thread; network I/O there throws,
and `sendPkt()` swallows every exception, so the peer only noticed after the
8 s liveness timeout.
**Fix:** the BYE is sent from a short-lived worker (joined for <= 500 ms)
when called on the main thread.

## 4. Autosave ran on the UI thread, ignored `saveStateBusy`, and was skipped on Close Game
**Files:** `MainActivity.kt`, `MainActivitySaveStateCore.kt`, `MainActivityDebugLog.kt`
**Fix:** new `persistSession()` does the battery flush + autosave on a worker
the caller waits on for <= 2.5 s; the autosave takes the same `saveStateBusy`
flag as Quick Save/Load and the slot dialog; `closeGame()` now autosaves
(previously the onPause it triggered saw `romLoaded == false`). All save
paths now back up the old slot only AFTER the new state was written.

## 5. ROM-swap races
**Files:** `MainActivityRom.kt`, `MainActivityDebugLog.kt`
**Fix:** `romLoaded` is cleared for the duration of a swap/reset (no autosave
of the wrong ROM, no loop restart mid-swap); the game thread is stopped
before the battery flush; a failed load/reset resumes the old session
instead of leaving a dead screen; the new ROM is staged to
`rom_loading.gba` (not over the file the live core has mapped) and only
renamed to `rom_loaded.gba` after a successful load.

## 6. Native save/load held `g_core_mutex` during zlib and disk I/O
**File:** `mgba_jni.c`
**Fix:** the lock now covers only `mCoreSaveStateNamed()` /
`mCoreLoadStateNamed()`; compression, decompression and file I/O run
unlocked, so a Quick Save can't stall the game/audio thread. Output is
`fsync()`ed before close so the Kotlin rename-into-place is crash-safe. File
format unchanged.

## Not done at the time of this entry (see the pass above it for what was done since)
JNI argument validation (bitmap/array sizes), crash-logger re-install per
Activity, link security (insecure RFCOMM / no shared secret), ROM-browser
UI-thread listing and `ZipInputStream` scans, `gradle-wrapper.jar` missing
from the zip, `ndkVersion` placement, and all architecture/feature items.

---

# CHANGELOG — Fifty-eighth pass

Direct ask: remove the temporary popup/notification shown after Quick
Save, Quick Load, and Screenshot — Toast was the only such mechanism
found anywhere in the project (no Snackbar, PopupWindow, custom overlay,
or coroutine exists in this codebase) — while leaving the actual save/
load/screenshot operations, `saveStateBusy` concurrency, numbered save
slots, and everything else untouched.

## 1. Quick Save, Quick Load, and Screenshot no longer show a Toast

**Category:** UI (removal, direct ask)
**Files modified:** `MainActivitySaveStateCore.kt`, `MainActivityDebugLog.kt`
**Problem:** N/A — not a bug, a direct ask. `quickSaveState()`,
`quickLoadState()`, and `takeScreenshot()`/`saveScreenshotBitmap()` each
called `uiToast()` on every guard clause and on the final result.
**Solution:** All 11 `uiToast()` call sites across these four functions
removed — both guard-clause toasts in each of `quickSaveState()`/
`quickLoadState()`/`takeScreenshot()`, `quickLoadState()`'s own "No
quick save yet", and both result toasts in `saveScreenshotBitmap()`.
Every `if`/`return`/`return@Thread` one of these toasts sat inside is
otherwise unchanged — only the `uiToast(...)` call itself is gone from
each. `resetGame()`'s own toasts (a separate feature, same file) and
every other `uiToast()` call in the project are untouched.
**Reason:** Direct ask.
**Expected improvement:** Tapping — or spamming — Quick Save, Quick
Load, or Screenshot now shows nothing on screen; the underlying save/
load/screenshot still happens exactly as before.
**Side effects:** `quickLoadState()`'s local `ok` is now computed but
never read (its only use was the now-removed result toast) — left in
place rather than also restructuring that line, so this stays a pure
notification removal. Produces a harmless "variable 'ok' is never used"
compiler warning; doesn't fail the build (no `-Werror`/
`allWarningsAsErrors` in this project's Gradle config).
**Verification:** No compiler or device in this sandbox, as always.
Checksum-diffed against the Fifty-seventh pass's own delivered zip: only
these 2 files differ. Full-body diff of all 4 functions reviewed by
hand; grepped for every remaining `uiToast(` in both files post-edit —
the only matches left are this pass's own explanatory comments plus
`resetGame()`'s and other features' pre-existing, untouched calls.
Confirmed `nativeSaveState()`/`nativeLoadState()`/
`captureGameFrameBitmap()`/`bmp.compress()` are all still called on
their original lines. Confirmed by grep that no Snackbar, PopupWindow,
coroutine, or `postDelayed` exists anywhere in the non-link codebase —
Toast, dispatched through the existing shared `uiToast()` helper
(`SharedUi.kt`, untouched, still used by ~15 other files), was the only
mechanism removed here.

---

# CHANGELOG — Fifty-seventh pass

A full-codebase audit was provided directly rather than run live in this
chat (`mgba_audit_report.md`, non-link/multiplayer scope, no code changed
by that report itself), paired with a pre-scoped implementation ask
covering exactly four of its findings — F1, F5, F2, F4, in that order —
with explicit instructions to leave link/multiplayer code untouched, keep
the diff small, and not start on the audit's own larger architectural
proposals (see KNOWN_LIMITATIONS.md for what those were and why they're
still open, not missing).

## 1. Overlapping on-screen controls: topmost-drawn control now wins hit-testing

**Category:** Bug fix (input)
**Files modified:** `MainActivityInput.kt`, `MainActivityControlEditorGeometry.kt`
**Problem:** `drawControls()` paints `buttons` in list order, so the
later-drawn of two overlapping controls is the one visually on top. But
`actionButtonAt()` (gameplay taps) used `firstOrNull{}` and
`hitTestEditable()`'s generic control-selection loop (layout editor) used
a forward `for` loop — both resolving to the *first* list-order match,
i.e. whichever control was added earliest, which is whichever one is
visually *underneath* when two overlap.
**Solution:** Both now search `buttons.asReversed()` instead of `buttons`,
so the first match found is the last-drawn (topmost) control.
`updateGameKeys()` is unchanged — it deliberately ORs every overlapping
match's keyMask together rather than picking one, which was already
correct regardless of draw order. Rendering order, `ButtonDef`, default
layouts, and control geometry are all unchanged.
**Reason:** Direct ask, implementing audit finding F1.
**Expected improvement:** Tapping a control that's visibly on top of
another now actually hits that control, in both gameplay and the layout
editor.
**Side effects:** None for non-overlapping layouts (the default case) —
reversing iteration order only changes the outcome when two controls'
rects actually overlap.
**Verification:** No compiler or device in this sandbox, as always. Both
edits are a single-line iteration-order change each; reviewed by hand
against `drawControls()`'s own paint order, and confirmed by grep that
neither function has another call site that also needed the change.

---

## 2. Removed the sole force-unwrap (`!!`) in the non-link codebase

**Category:** Hardening (defensive)
**Files modified:** `MainActivitySaveStateUi.kt`
**Problem:** The save-state list adapter's `getView()` called
`getItem(position)!!`. Not currently reachable — this adapter's backing
`slots` list is fixed at construction and never mutated, so `position` is
always in range — but a `!!` here means any future change to that
assumption becomes an instant crash instead of a controlled fallback.
**Solution:** `getItem(position) ?: return row` — returns the
already-built/recycled row un-bound in the (currently unreachable) null
case, rather than crashing.
**Reason:** Direct ask, implementing audit finding F5.
**Expected improvement:** No behavior change today; removes a latent
crash risk if this adapter's assumptions ever change.
**Side effects:** None.
**Verification:** No compiler or device in this sandbox, as always. `row`
is already in scope as a `LinearLayout` (a `View`), matching `getView()`'s
declared `View` return type on this early-return path. Confirmed by grep
this was the only `!!` in the file.

---

## 3. Native frame render now defends against a non-RGBA_8888 bitmap

**Category:** Hardening (native)
**Files modified:** `mgba_jni.c`
**Problem:** `nativeRunFrame()` locks the Java-side `Bitmap` passed in
from `MainActivityRender.kt` and writes into it as raw `uint32_t` pixels
unconditionally. That bitmap is always created by this app itself in
`ARGB_8888` config today, so this doesn't currently trigger — but nothing
in the native function itself checked that assumption before writing 4
bytes per pixel into whatever buffer it actually got.
**Solution:** Right after `AndroidBitmap_getInfo()` succeeds — before
`AndroidBitmap_lockPixels()` is ever called — a new check compares
`info.format` against `ANDROID_BITMAP_FORMAT_RGBA_8888`. On a mismatch:
log a warning with the actual format value, release `g_core_mutex`, and
return, all before any lock is taken, so there's nothing to unlock on
that path. The existing successful-path logic is otherwise byte-for-byte
unchanged.
**Reason:** Direct ask, implementing audit finding F2.
**Expected improvement:** A future config change (or any other caller of
this native method) that produces a differently-formatted bitmap now
fails loudly with a log line instead of silently corrupting memory.
**Side effects:** None on the RGBA_8888 path (the only path in use
today).
**Verification:** No compiler, Android NDK, or device in this sandbox, as
always. Built a standalone C harness that stubs every JNI/bitmap/pthread
symbol this function touches and `#include`s the real function body
(extracted verbatim from the edited file, not retyped by hand) — 4
scenarios run (getInfo failure, bad format, lockPixels failure, full
success): `g_core_mutex` locked and unlocked exactly once in every case,
`AndroidBitmap_unlockPixels()` never called without a matching successful
lock, and the full-success path's pixel output confirmed byte-identical
to the original logic.

---

## 4. Game thread shutdown now detects and interrupts a hung thread

**Category:** Hardening (lifecycle)
**Files modified:** `MainActivityRender.kt`
**Problem:** `stopGameLoop()` calls `gameThread?.join(750)` and proceeds
regardless of whether the thread actually stopped — a wedged game thread
(the existing 750ms comment's own "slow/unusual audio HAL" case, or any
other stall) was silently ignored rather than surfaced or signaled.
**Solution:** A local `thread` reference is joined (not `gameThread`
directly, so a concurrent reassignment of the field can't cause the
isAlive check to look at a different Thread than the one just waited
on). If `thread?.isAlive` is still true after the join, a warning is
logged and `thread?.interrupt()` is sent — safe here specifically because
the loop's own `catch (_: InterruptedException) { break }`
(`startGameLoop()`) already treats an interrupt as a clean stop signal,
not an error.
**Reason:** Direct ask, implementing audit finding F4.
**Expected improvement:** A hung game thread now gets a log line and an
actual shutdown signal instead of being silently left running past the
timeout.
**Side effects:** None on the normal-shutdown path (thread already dead
by the time `join(750)` returns, as today).
**Verification:** No compiler or device in this sandbox, as always. One
correction from the ask's own example snippet: `thread?.isAlive == true`
does not smart-cast `thread` to non-null for the `interrupt()` call
afterward — Kotlin doesn't prove non-nullness through a
safe-call-vs-Boolean-literal comparison, a known compiler limitation —
so `thread?.interrupt()` is used instead. Identical behavior in every
reachable case; checked by hand against Kotlin's actual smart-cast rules
since no compiler is available here.

---

# CHANGELOG — Fifty-sixth pass

Two messages: "full code audit just skip link or multiplayer function
see if there anything you can improve", then "Continue" after the
first response ran out of room mid-review. Read the non-link/
multiplayer call graph in full, not just entry points — following the
lesson in KNOWN_LIMITATIONS.md's Forty-eighth-pass note, where that
pass's own audit skimmed GameScreenRecorder.kt's start()/stop()/
teardown and missed two real bugs living one level deeper, in
drainVideoLocked()/drainAudioLocked()/maybeStartMuxerLocked() — before
concluding there was little left to find. There nearly was: this pass
covers mgba_jni.c end to end (link-cable sections skipped per the ask,
confirmed by checking every JNIEXPORT function name against the ask
before skipping it), CMakeLists.txt, EmulatorEngine.kt,
GameScreenRecorder.kt, EglBitmapSurfaceRenderer.kt, the full render/
game-loop/triple-buffer path (MainActivityRender.kt, the buffer fields
in MainActivity.kt), MainActivityInput.kt's multi-touch handling,
MainActivityControlLayout.kt's per-frame draw path,
MainActivityAudio.kt's pacer/filter/decimate functions,
MainActivityMemoryViewer.kt, MusicPlaylistPlayer.kt, RomZipUtils.kt,
RomBrowserActivity.kt, the save-state/screenshot capture functions in
MainActivitySaveStateUi.kt, JSON (de)serialization in
MainActivityLayoutPresets.kt, and MainActivityRom.kt/
MainActivityDebugLog.kt's ROM-load and reset/close paths — lighter,
spot-check coverage on the remaining dialog/settings-construction
files. See this pass's own KNOWN_LIMITATIONS.md entry for exactly
which files that means and why.

Two real, safe findings, both applied below (items 1–2). Then: "is
that all the problem did you see a way to improve this" — read further
into files this pass had only spot-checked rather than re-asserting
the first pass's conclusion, the same "go back and actually read the
deeper functions, not just entry points" move the Forty-eighth pass's
own follow-up needed (see KNOWN_LIMITATIONS.md's note on that one).
It found a real one: item 3, a genuine correctness bug (not a perf/
diagnostic nice-to-have like the first two), in the control-layout
editor. Everything else in scope — resource lifecycle, thread-safety,
JNI mutex discipline, the triple-buffer scheme, the audio-locked frame
pacer, JSON parsing's parse-into-local-then-commit pattern — still
reads as correct. Not padding this with cosmetic nitpicks (unused-
import duplication across every MainActivityXxx.kt file, a few
one-line DRY-able formulas) that would cost real verification risk for
no behavior change; see KNOWN_LIMITATIONS.md for the one build-level
idea considered and deliberately not applied.

Then a fourth message, unrelated to the audit itself: "can you make
the dpad arrow not pointy each edge" — a direct, specific design ask
about ic_dpad_arrow.xml (last touched by name in the Fifty-fifth
pass's own entry below). Item 4.

## 1. formatHexDump() no longer calls String.format() in its hot loop

**Category:** Performance (main-thread hot loop)
**Files modified:** `MainActivityMemoryViewer.kt`
**Problem:** `scheduleMemoryRefresh()`'s self-rescheduling
`Handler.postDelayed()` loop (500ms interval, MainActivity.kt) calls
`refreshMemoryDump()` → `formatHexDump()` on the MAIN thread — the same
thread Choreographer's `doFrame()` needs for every vsync tick while
this overlay is open over a running game (it deliberately doesn't stop
the game loop — see `showMemoryViewer()`'s own doc comment). At
`memoryPageBytes` = 512, one call built 32 rows × (1 address +
16 bytes) = 544 `String.format("%02X ...")`/`("%08X ...")` calls —
each one allocates and drives a Locale-aware `java.util.Formatter`
plus its own format-string parse. Real, avoidable CPU on a thread that
can least afford it, twice a second for as long as the viewer stays
open.
**Solution:** A manual hex-digit lookup (`HEX_DIGITS`, plus
`StringBuilder.appendHex2()`/`appendHex8()`) replaces every
`String.format()` call in the loop. Same StringBuilder, same row/
column layout, same literal spacing — only the two hex-writing
primitives changed.
**Reason:** Full code audit, this pass's own opening message.
**Expected improvement:** No Formatter allocation/parse overhead on
the main thread while the memory viewer is open — fewer/smaller GC
pauses competing with frame rendering during exactly the window this
feature is meant to be used in (watching live RAM while playing).
**Side effects:** None — output is byte-for-byte identical.
**Verification:** No compiler or device in this sandbox, as always.
Structural equivalence checked by hand (identical append sequence and
literal spacing, only the two hex-encoding calls swapped). Numeric
equivalence checked with a standalone Python harness reproducing both
the new bit-shift hex encoding and Java Formatter's own documented
per-type two's-complement-width rule for `%X` (a `byte` argument
formats at 8-bit width, an `int` at 32-bit — the reason the original
code's plain `String.format("%02X", byteVal)` was already safe for
negative `Byte` values without an explicit mask): 200,000 random
byte/address pairs plus every real GBA region's base address this
feature actually reads (`memRegions`, MainActivity.kt) — zero
mismatches.

---

## 2. GameScreenRecorder: silent audio-batch truncation now logged once per recording

**Category:** Hardening (diagnostics)
**Files modified:** `GameScreenRecorder.kt`
**Problem:** `feedAudio()` already has one documented, accepted drop
case — no encoder input buffer available at all this call — logged
nowhere, on purpose (see that function's own doc comment: an
occasional whole-chunk drop under backpressure is inaudible and not
worth a log line). A second, different case sat right next to it with
no log at all: when a buffer IS available but has less room than
`pairs` needs, `maxShorts` silently clamps down and the remainder of
that batch is dropped mid-buffer instead of at a clean chunk boundary
— indistinguishable from the first case by anything in the log, only
by reading the code. This exact function's neighborhood has already
produced two previous, real, silently-manifesting bugs (see
BUGS_FIXED.md, Forty-ninth pass) — reason enough to close off a second
unlogged drop path here even with no report pointing at it yet.
**Solution:** `audioTruncationLogged` (reset alongside
`recordingStartNanos`/`audioPresentationTimeUs` in `start()`) makes
this a one-time-per-recording `Log.w()` instead of either silence or
per-call spam: logged once, the moment truncation first happens, not
repeated for the rest of the session even though the underlying cause
(an encoder's fixed input-buffer size) would otherwise recur on every
later call once it starts.
**Reason:** Full code audit, this pass's own opening message.
**Expected improvement:** If this ever actually triggers on a real
device/encoder, there's now a specific log line (wanted-vs-got short
counts) instead of nothing — the same silence-to-signal win FIX 17
(mgba_jni.c) already banked for link debugging, applied here.
**Side effects:** None expected — purely additive logging, gated to
fire at most once per `start()`/`stop()` cycle. Nothing about what
gets queued, dropped, or played changes.
**Verification:** No compiler in this sandbox. Read-through only;
brace/paren counts balanced after the edit (script-checked, not just
eyeballed); confirmed exactly one `feedAudio()` and one
`audioTruncationLogged` declaration remain in the file post-edit.

---

## 3. Control-layout editor: switching (or clearing) the selected control no longer loses or misapplies an open inline edit

**Category:** Bug fix (correctness)
**Files modified:** `MainActivityControlEditorMode.kt`
**Problem:** `SliderRow` (SharedUi.kt) is built once per toolbar slot
(`editSizeSlider`/`editOpacitySlider`) and reused for every control the
user ever selects — `SliderRow.setValue()`, called from
`syncEditButtonBarToSelection()` whenever the selection changes, only
ever updates the SeekBar/valueText half of the row, never a still-open
tap-to-type `valueEdit` box left over from editing the *previous*
control. Meanwhile `setSelectedScalePercent()`/
`setSelectedAlphaPercent()` — `SliderRow`'s own `onChange` — both read
`editSelectedId` live, at the moment they're called, not a value
captured when the slider was built. Three places changed or cleared
`editSelectedId` *before* anything would flush a pending edit:
`onEditTouch()`'s `ACTION_DOWN` (reassigns immediately on every new
hit-test, before `syncEditButtonBarToSelection()` runs a few lines
down), `exitEditMode()`, and `confirmResetAllLayout()`'s Reset handler
(both null it out before hiding the views whose own GONE-triggered
focus loss would otherwise flush `valueEdit` via `SliderRow`'s
existing focus-change handling). Net effect: finish typing a number
into, say, control A's size box, then tap straight over to control B
without hitting Done first — the number lands on B, not A, once
typing finishes; do the same right before Done/Cancel/Reset and the
number is silently discarded instead of applied to A. Neither has a
prior report — this is genuinely new, not a regression of anything in
BUGS_FIXED.md.
**Solution:** New `flushPendingSliderEdits()` calls
`commitInlineEdit()` on both sliders (a no-op on either when it isn't
actually mid-edit — see `SliderRow.commitInlineEdit()`'s own guard),
inserted at the top of all three call sites, *before* `editSelectedId`
changes — so a genuinely finished edit commits to the control it was
actually typed for, and the sliders then correctly resync to whatever
gets selected (or doesn't) next.
**Reason:** Full code audit, follow-up ("did you see a way to improve
this") on this pass's original opening message.
**Expected improvement:** No more silently-misapplied or silently-
discarded slider edits when a control switch or edit-mode exit happens
to land while a size/opacity box is still open.
**Side effects:** None expected. `onEditTouch()`'s `ACTION_DOWN`
now makes two extra guarded, near-zero-cost calls on every tap in edit
mode (see the guard above) — not a hot path (touch-driven, edit mode
only), and every existing behavior when neither slider is mid-edit is
unchanged, since both calls no-op in that case.
**Verification:** No compiler or device in this sandbox. Traced by
hand: confirmed `SliderRow.setValue()` never touches `valueEdit`
(SharedUi.kt), confirmed `setSelectedScalePercent()`/
`setSelectedAlphaPercent()` read `editSelectedId` live rather than a
captured value (MainActivityControlEditorMode.kt), and confirmed
`editSizeSlider`/`editOpacitySlider` are the *only* two `SliderRow`
instances anywhere in the app (grepped every `sliderRow(`/`SliderRow(`
call site) — so no other call site needed the same fix. Brace/paren
counts balanced after the edit; confirmed exactly one
`flushPendingSliderEdits()` definition and three call sites.

---

## 4. D-pad arrow: all 3 corners rounded off

**Category:** Visual polish (direct report)
**Files modified:** `app/src/main/res/drawable/ic_dpad_arrow.xml`
**Problem:** "make the dpad arrow not pointy each edge" — the filled
triangle (apex (16,9), base corners (5,25)/(27,25), set by the
Fifty-fifth pass's own length/proportion fix) met at 3 sharp corners.
**Solution:** Same 3 target points, each corner now rounded to radius
3 by hand-building the standard filled-path corner-rounding technique
in the raw path data: back off a short distance from each vertex along
both edges meeting there, then join those two points with a quadratic
Bezier (`Q`) using the original vertex as the curve's control point.
Distance backed off differs by corner on purpose (~4.4 units at the
apex's sharper ~69° angle, ~5.7 units at each ~56° base corner) since
a sharper angle needs a longer setback to reach the same rounded
radius — see the file's own updated comment for the full reasoning.
New `pathData`: `M13.53,12.6 Q16,9 18.47,12.6 L23.77,20.3 Q27,25
21.3,25 L10.7,25 Q5,25 8.23,20.3 Z`, replacing the old `M16,9 L27,25
L5,25 Z`.
**Reason:** Direct report, this pass.
**Expected improvement:** Softer, rounded arrowhead instead of sharp
triangular points, on all 4 D-pad arms (one asset, canvas-rotated per
arm — see the file's own top comment).
**Side effects:** None expected. Same silhouette footprint (apex and
base positions unchanged) and fill color; only the corners between
those points changed.
**Verification:** No compiler, device, or icon-preview tool in this
sandbox (last pass's own such tool wasn't checked into the repo, so
there's nothing left to run). XML confirmed well-formed via Python's
`xml.dom.minidom` (this project's own established check for drawable
edits — see FILE_CHANGES.md history). Path geometry double-checked
two ways: by hand (each rounded corner's setback distance recomputed
from `radius ÷ tan(half the interior angle)`, confirmed the resulting
tangent points lie exactly on the original straight edges so the
`Z`-closed final segment introduces no discontinuity) and visually,
by rendering both the old and new path data by hand — Matplotlib in
this sandbox, not the project's own tooling — side by side as a PNG
and inspecting it directly: a clean, evenly-rounded arrowhead, no
gaps, no self-intersection, still clearly reads as a directional
arrow rather than a blob.

---

# CHANGELOG — Fifty-fifth pass

One message, with an in-app screenshot of the Fifty-fourth pass's own
result: "dpad arrow is very long and i don't like rhe recorder button
look weird and i don't think it well say im recoder button because it
look wierd." Both are the same lesson from two angles — this project's
own offline preview tooling (built last pass) renders each icon
standalone or in a rough mockup, which caught the record icon's
first-draft *sparseness* last pass, but proportions and "does this
concept read at all" can still land differently once actually seen at
real size inside the real app, and the screenshot here is what caught
both of these.

## 1. D-pad arrow shortened/widened; record icon replaced with a plain ring+dot

**Category:** Fix (visual, from a direct report with an in-app
screenshot)
**Files modified:** `ic_dpad_arrow.xml`, `ic_record.xml` (content only
— neither file's call sites changed)
**Problem:** `ic_dpad_arrow.xml`'s first version (apex (16,5), base
(7,26)/(25,26): height 21, width 18) read as a long spike rather than a
bold arrowhead once seen at real size. `ic_record.xml`'s first version
(camcorder body + viewfinder wedge + lens dot, this file's own
Fifty-fourth-pass entry) didn't read as "record" at all per the direct
report — an object-silhouette concept that needed to be decoded rather
than recognized on sight, which defeats the point of an icon.
**Solution:**
- D-pad arrow: same single-triangle-rotated-4-ways approach, new
  coordinates — apex (16,9), base (5,25)/(27,25): height 16, width 22,
  now wider than tall instead of the reverse. No change to `drawDpad()`
  itself; this is a content-only edit to the vector resource it already
  loads.
- Record: replaced outright rather than adjusted, since the report was
  about the *concept*, not this concept's proportions. New design is a
  ring (r11.5, strokeWidth 1.8) with a bold filled dot inside (r6.5) —
  the same ring-and-dot pattern real camcorders/dashcams use for their
  own physical record button, not just an icon convention, chosen
  specifically for on-sight recognizability over cleverness. No body
  outline, no wedge, nothing left to misread as something else. Also no
  change to any `.kt` call site — `drawActionButtonIcon()` already just
  loads and tints whatever `ic_record.xml` contains.
**Reason:** Direct report, quoted above, with an in-app screenshot
(not this project's own offline preview) as the evidence for both.
**Side effects:** None expected. Both remain solid/simple enough to
read clearly at small size; the ring+dot's overall silhouette (a
circle, no rectangular body) stays visually distinct from
`ic_screenshot.xml`'s camera silhouette (rectangular body + top bump)
despite both now using a ring+dot *somewhere* in their design — the
gross shape at a glance still differs, which is what matters for
telling the two buttons apart quickly.
**Verification:** No compiler or on-device APK in this sandbox, as
always. Re-rendered both, standalone and inside the actual button-box
treatment, via this project's own offline SVG-arc renderer (built
Fifty-fourth pass) — this time judged the *arrow's proportions*
directly against the reported complaint (materially wider/shorter than
before) and the *record icon's on-sight readability* directly against
"doesn't say record" (a plain, unambiguous ring+dot, nothing to
decode), rather than re-checking the things last pass's tooling had
already covered adequately (family-wide visual weight, which was never
the complaint this time). Both files re-checked well-formed
(`xml.dom.minidom`).

---

# CHANGELOG — Fifty-fourth pass

Two messages, one pass: "improve button make it like the screenshot
button quick save and load they good i don't have any references for
how i want it to look" (Record specifically), then "redesign the dpad
fast forward record button make it like the screenshot quick save and
load button so it fit" (extending the same treatment to the d-pad and
fast-forward, and reconfirming Record). No reference image for any of
it this time — design judgment plus this project's own offline
SVG-arc-aware preview tooling (built this pass — no on-device way to
run the real APK and look at it) instead of tracing one.

## 1. Record, d-pad, and fast-forward converted from text/plain-shape glyphs to real vector icons

**Category:** Fix (visual consistency, no reference image)
**Files modified:** `MainActivity.kt`, `MainActivityControlLayout.kt`;
new `ic_record.xml`, `ic_dpad_arrow.xml`, `ic_fast_forward.xml`
**Problem:** Of this app's utility/directional controls, only Quicksave/
Quickload/Screenshot had been converted to real vector icons + thin
border (`utilityIconBorderStrokeW`) in earlier passes. Three were still
on the older treatment: Record drew a bare `canvas.drawCircle()` in
that button's own configured accent color (strokePaint, same as its
box — the "lone red dot" a default config produces; see
FEATURES_ADDED.md's Forty-eighth-pass entry), the 4 d-pad arms each
drew their direction as a Unicode text character (▲▼◀▶) via
labelPaint, and fast-forward drew "»" as text — all three on the
thicker `outlineStrokeW` border, fast-forward/dpad on inconsistent
corner radii (8f flat / size-relative) too.
**Solution:**
- `ic_record.xml` (new): camcorder body + viewfinder wedge (single
  continuous outline, same construction as `ic_screenshot.xml`) plus a
  filled lens dot as this icon's own accent shape. First draft (body +
  wedge only) read as too sparse once actually rendered next to the
  other three's own internal detail; the lens dot was added after that
  check — both as this icon's accent shape and because it doubles as
  the universal record-button dot.
- `ic_dpad_arrow.xml` (new): one filled triangle, drawn pointing up.
  Reused for all 4 arms via `canvas.rotate()` around each arm's own
  center (0°/90°/180°/270°) instead of 4 near-duplicate files.
- `ic_fast_forward.xml` (new): the standard twin-triangle "»" media
  glyph, solid fill.
- `drawActionButtonIcon()`: `"record"` folded into the same branch
  quicksave/quickload/screenshot already used (own icon via
  `actionIconFor()`, same `utilityIconBorderStrokeW` border, same fixed-
  white tint, same 0.46f bounds fraction) instead of its own
  plain-circle case; that case, and the `s` local it was the only
  reader of, removed.
- `drawDpad()`: same cache-fill-on-first-use pattern inline
  (`iconDpadArrow`, since the d-pad is one `buttons`-list entry drawn
  as 4 hardcoded arms rather than something `actionIconFor()`'s
  `[id]`-keyed lookup applies to), border switched to
  `utilityIconBorderStrokeW`, `canvas.rotate()`/`restore()` wraps the
  icon draw per arm. `dpadArmCorner` (already size-relative) left as-is
  — it already scales more correctly with a resized d-pad than a fixed
  radius would.
- `drawControls()`'s fast-forward block: border → `utilityIconBorderStrokeW`,
  corner radius 8f → 12f (matching every other button), text draw
  replaced with the same cache-fill-on-first-use + tint + bounds
  pattern (`iconFastForward`, same reasoning as `iconDpadArrow` — ff
  isn't a `buttons`-list entry either). The `colorFfActive`/
  `colorAccentLight` border+fill on/off cue is untouched — only the
  glyph changed.
- `MainActivity.kt`: `iconRecord` (added earlier this same pass),
  `iconDpadArrow`, `iconFastForward` cache fields added; doc comments
  on this cache and on `utilityIconBorderStrokeW` updated to describe
  the expanded set of controls using them.
**Reason:** Direct reports, both quoted above.
**Behavior change beyond the visual, worth flagging explicitly:**
Record's dot used to render in that button's own configured accent
color. It now uses the fixed `icon.setTint(Color.WHITE)` treatment
quicksave/quickload/screenshot's icons already use — same as this pass
gives the d-pad arrows and fast-forward glyph. The box itself (border +
press/active fill) for all of these still reads that button's own
configured accent color exactly as before; only the glyph drawn inside
stopped following it. Consistent with the direct report asking these
to match the icon-button family, but noted here since "the dot doesn't
turn red anymore even if Record's color is set to red" is a real,
visible change a config-reliant setup would otherwise surface
unannounced.
**Side effects:** None expected beyond the above. The pre-existing,
unrelated Fast-Forward "Control Opacity does nothing" issue
(KNOWN_LIMITATIONS.md — `ffAlpha` still comes from `buttonBaseAlpha`
directly, never `customLayout["ff"]?.alphaOverride`) is untouched by
this pass; still open.
**Verification:** No compiler or on-device APK in this sandbox, as
always. This pass built an offline check rather than skipping straight
to "should compile": a small Python SVG-arc-aware renderer (reads each
vector's real `pathData`, including elliptical-arc commands — same
syntax Android's VectorDrawable path data uses) to rasterize every new/
changed icon standalone, side-by-side with the existing
quicksave/quickload/screenshot glyphs, and again inside a mockup of the
actual button-box treatment (border + 0.46f-bounds icon, and a full
4-arm rotated d-pad cross) at both a large preview size and a small one
approximating real on-screen scale. Caught the record icon's
first-draft sparseness before it shipped. Brace/paren counts checked on
both edited `.kt` files after every edit (all balanced); every new/
edited XML checked well-formed. No kotlinc available to actually
compile-check.

---

# CHANGELOG — Fifty-third pass

One item — a direct report with a reference PNG (`emulator_icons.zip`,
matching this project's existing icon-pack style) calling out the Quick
Load button's arrow specifically as bad/wrong-shaped, distinct from the
whole-icon brightness/size complaint the Fiftieth–Fifty-second passes
addressed.

## 1. Quick Load arrow rebuilt to match a supplied reference PNG

**Category:** Fix (shape/geometry, from a user-supplied reference image)
**Files modified:** `ic_quick_load.xml`
**Problem:** The arrow half of the Quick Load glyph read as a blunt
comma/hook, not an arrow. Note: the project state this pass started
from already differed from the Fifty-second pass's own logged design —
stroke width was already 1.4 (that pass set 2.75) and the arrow was
already two circular arcs meeting a single tip point (that pass logged
a straight-shaft/corner-bracket head instead). Neither change has an
intervening CHANGELOG entry. This pass documents what it did to the
file as received; it doesn't reconstruct what produced that file.
**Root cause:** The arrow's two arcs (outer/inner edge of the curved
shaft) each connected directly to a single tip point instead of to a
separate, wider arrowhead. With no flare at the head, the silhouette
couldn't read as an arrowhead no matter how the arc radii were tuned.
**Solution:** Rebuilt the arrow path from the supplied reference
(`emulator_icons.zip` → `quick_load.png`). Isolated the arrow as its
own connected component (confirmed it doesn't touch the folder
outline), traced its contour, and independently least-squares-fit a
true circle to the outer shaft edge and a separate true circle to the
inner shaft edge — deliberately not concentric/shared-center, since
the reference ribbon tapers (narrower at the tail, wider near the
head) and a shared center would force a constant width it doesn't
have. Added explicit barb points between each arc's endpoint and the
tip, flared wider than the arc's own continuation — that flare, plus
the small notch it creates against each arc, is what makes the head
read as an arrowhead. Coordinates were mapped from reference-PNG pixel
space into the 32×32 viewport using the folder body's own straight
edges (top/bottom/left/right, each measured as a flat run away from
the rounded corners) as the calibration anchor — not the folder's
overall bbox, which includes the tab. First attempt used the overall
bbox and came out with the arrowhead sitting almost flush against the
folder's body-top edge (flagged directly: "top of the arrow the line
is very closed") — the reference PNG's tab turned out to be shorter
relative to its body than this file's existing tab is relative to
its own body, so calibrating on the overall bbox pulled everything
mapped near the top closer to the body-top edge than it should sit.
Re-anchored on the body edges directly, which is what actually bounds
where the arrow lives regardless of the tab's own proportions. Folder
path and stroke width untouched.
**Reason:** Direct report + reference PNG, then a direct follow-up
report on the first attempt's arrowhead-to-folder clearance.
**Expected improvement:** Quick Load's icon should now show a clearly
arrow-shaped glyph (tapering curved shaft, flared triangular head)
matching the supplied reference, instead of the previous hook/comma
shape.
**Side effects:** None — only `ic_quick_load.xml`'s arrow `<path>`
changed. The folder `<path>` (geometry, stroke width, stroke color) is
byte-for-byte what it was on receipt, and `ic_quick_save.xml`/
`ic_screenshot.xml` weren't touched.
**Verification:** No Android build available in this sandbox, same as
every previous pass. What was checked instead: wrote a small Python
path-data interpreter (the M/L/A/Z subset these icons use, including
real SVG/AVD elliptical-arc endpoint-to-center math) to rasterize
`pathData` directly, and used it to confirm the *previous* file
reproduced the reported bad shape — it matched the supplied screenshot
closely — before changing anything. The two fitted circles were
checked against the actual reference contour points: max residual
~1.6px (outer edge, r≈128px) and ~1.0px (inner edge, r≈152px), i.e.
each edge really is one constant-curvature arc, just two different
circles. The final path was rendered back through the same
interpreter reading straight off the saved XML file (not working
notes), pixel-overlaid against the reference PNG at matching scale —
including a tight crop on specifically the arrowhead-to-folder-top gap
after the first attempt's calibration issue, not just the full-icon
silhouette — and re-checked at a small (~44px) size to confirm it
still reads clearly at real button size. The edited file was
re-parsed with `xml.etree.ElementTree` to confirm it's still
well-formed.

---

# CHANGELOG — Fifty-second pass

One item — a direct report with a screenshot of the actual rendered
buttons, again calling out Quick Load/Quick Save/Screenshot as dark,
thin, and hard to recognize, despite the Fiftieth and Fifty-first
passes both having worked on exactly these three icons' geometry.

## 1. Utility icons still washed out: the real cause was never the path geometry

**Category:** Fix (root cause the previous two passes never found) + redesign (per this pass's explicit new spec)
**Files modified:** `MainActivityControlLayout.kt`, `ic_quick_load.xml`, `ic_quick_save.xml`, `ic_screenshot.xml`
**Problem:** Same complaint as the Fiftieth pass's original report —
dark, thin, small, hard to recognize at actual button size — persisting
through two passes that both worked on the icons' own path geometry
(the floppy redesign, then the arrow kink/fold-over fix).
**Root cause:** `drawActionButtonIcon()` was calling
`icon.setTint(strokePaint.color)` / `icon.alpha = strokePaint.alpha` for
all three icons. `strokePaint` at that point holds the button's own
OUTLINE color — `colorAccentLight` (`#D8D8DE`) at `idleAlpha`
(`buttonBaseAlpha`, default 160/255 ≈ 63%) — the same dim, semi-
transparent treatment used for every button's thin border. That tint is
applied after the drawable is loaded, so it silently overrides whatever
color is baked into the VectorDrawable XML; the icons could have been
pure `#FFFFFF` at full alpha already and it wouldn't have mattered.
Neither previous pass could have found this by improving path
coordinates, since the defect isn't in the paths.
**Solution:** Two independent changes. (1) `drawActionButtonIcon()` now
tints these three icons to `Color.WHITE` / alpha `255` instead of
`strokePaint`'s color/alpha — matching `labelPaint`'s always-fully-
opaque white (the same paint that draws the D-pad's "▲▼◀▶" glyphs and
the "A"/"B" labels), which is the actual brightness reference the
direct report pointed at. The button's own outline/fill, drawn right
above via `strokePaint`/`fillPaint`, is untouched, so idle/pressed flash
behavior is unchanged. (2) All three `ic_*.xml` files redesigned bigger
and bolder per this pass's spec: stroke width 2.0 → 2.75 (within the
requested 2.5–3.0 range), each icon's bounding box enlarged from
roughly 50–69% of the 32-unit viewport to ~75–81% (close to the
requested x=3..29 / y=3..29), and the quickload arrow rebuilt from a
curved-sweep-into-filled-triangle into a straight shaft + right-angle
corner-bracket head (the same construction Feather/Material use for an
"open"/external-link glyph) — reads as an unambiguous arrowhead at a
glance where the curve was reading as a hook.
**Reason:** Direct report + a screenshot of the actual rendered buttons.
**Expected improvement:** All three icons should now render bright
white at full opacity — matching the D-pad arrows/A/B letters in
brightness, regardless of the user's button-opacity setting — on top of
being visibly bigger and bolder than any previous pass's geometry.
**Side effects:** None on unrelated controls — confirmed by diffing the
whole project against the version this pass started from: only
`MainActivityControlLayout.kt` and the three `ic_*.xml` files differ,
and the `.kt` diff is exactly the two tint/alpha lines plus a comment
(same box-drawing code, same touch handling, same everything else in
the file). The `"record"` icon (drawn separately, doesn't go through
`actionIconFor()`) is untouched.
**Verification:** No Android build available in this environment, and
this pass's own instructions say the requester builds the APK
themselves — so this wasn't compiled or run on-device. What was
checked: a standalone Python/Pillow script re-implementing each icon's
exact path geometry (arcs sampled the way a real path stroker traverses
them) rendered all three at large size, near-actual size (~28–30px),
and composited inside a simulated button — the real dim outline box
plus the icon at `Color.WHITE`/alpha 255, at the actual
`half = 0.375 * min(rect)` sizing ratio the code uses — confirming the
new geometry reads clearly at real proportions and that full-opacity
white against the dim outline matches the reference screenshot's ask.
This is a stroke-rendering approximation, not Skia's actual renderer,
so the real check is still the requester's own on-device build.
Brace/paren balance on the modified `.kt` file confirmed equal
before/after.

---

# CHANGELOG — Fifty-first pass

One item — a direct report with a screenshot of the actual rendered
button, catching a defect the Fiftieth pass's own verification missed.

## 1. Quickload arrow: fixed a pinch/kink invisible in the previous pass's own verification render

**Category:** Fix (regression in the immediately preceding pass)
**Files modified:** `MainActivityControlLayout.kt`
**Problem:** The Fiftieth pass's quickload arrow (a curved tail into a
filled triangular head) rendered as a tangled, overlapping mess on an
actual device, not the clean swoosh it tested as.
**Root cause:** Two compounding issues, both invisible in the previous
pass's own check: (1) the tail's curve had a tight bend relative to its
own length, and at real icon size the stroke width is a much larger
fraction of that bend's radius than in a generously-sized test render —
tight enough that the stroke folds over itself at the bend instead of
following it cleanly, a real rendering effect, not the shared-edge
double-composite this file's other icon fixes have been about; (2) the
curve's tangent at its endpoint pointed nearly horizontal while the
arrowhead it fed into pointed 45°, so the two shapes met at a visible
kink even along the stretch where the curve itself stayed clean. The
previous pass's verification script rendered its test icons at a size
and stroke-width ratio far more generous than any real button, so
neither defect showed up there.
**Solution:** Shallower curve (wide bend, large radius throughout, so
the stroke never has to fold to follow it) with its endpoint chosen so
the curve's own natural tangent there already runs close to the
arrowhead's 45° axis, rather than meeting it at an unrelated angle.
**Reason:** Direct report + a screenshot of the actual rendered button.
**Expected improvement:** Quickload's arrow should read as a clean
swoosh into the arrowhead, matching the reference photo, with no
overlap or kink.
**Side effects:** None — only the tail curve's and head's coordinates
changed; the folder outline, the floppy disk, and the screenshot camera
(all unaffected by this defect) are untouched.
**Verification:** Same standalone-script approach as the Fiftieth pass,
but corrected to test render at icon size and stroke-width *proportional*
to 3 real button sizes spanning this app's actual Control Size range
(small/default/large) rather than one generously-sized render — the
error that let the original defect through in the first place. The
original bug reproduced at realistic scale before the fix, and stayed
gone after it, at all 3 sizes checked. Brace/paren balance re-confirmed
on the modified file.

---

# CHANGELOG — Fiftieth pass

One item — a new reference photo superseding the Forty-ninth pass's
own icon work.

## 1. Quicksave/quickload/screenshot icons redrawn again to match a new reference photo

**Category:** Fix (new reference photo supersedes the previous one)
**Files modified:** `SharedUi.kt`, `SettingsIcons.kt`,
`MainActivityControlLayout.kt`
**What changed:** The new photo shows a different icon set than the
Forty-ninth pass's own reference: a classic floppy disk (chamfered
top-right corner, a shutter notch holding a write-protect tab, 3 label
lines) for quicksave, not a folded-corner page; a folder with a curved
"open" arrow for quickload, not a box with a straight escaping arrow;
screenshot's camera keeps its body/bump/lens structure but the bump
moves off-center-left with a small filled indicator inside it, and the
lens gains an inner ring plus a filled aperture dot instead of a single
hollow ring.

`drawFloppyDiskIcon()` (SharedUi.kt) — dormant for quicksave since the
Forty-ninth pass switched that button to the page shape, but still used
by the Settings STORAGE glyph the whole time — is rewritten to the new
detailed floppy disk (one continuous `Path`: 3 rounded corners plus the
chamfer, `arcTo()`+`lineTo()` off one `moveTo()`, closed) and
`"quicksave"` now calls it again instead of growing a second, separate
floppy-disk-drawing implementation. Both call sites share the one
upgraded shape. `"quickload"` and `"screenshot"` are rebuilt in place,
same as always.

Building these needed a fill paint for the first time in this function
(an arrowhead, a tab and label lines, a lens dot). `drawActionButtonIcon()`'s
`fillPaint` is a shared, reused-every-frame field that
`drawOutlineButton()` only ever sets when a button is pressed — the
existing press-tint background fill is its one other user here — so
outside that branch it would have held whatever a *different* button
last left in it earlier the same frame. Fixed by matching `fillPaint`'s
color/alpha to `strokePaint`'s already-correct ones right after that
press-tint fill (so the tint keeps its own dedicated 30%-alpha look),
rather than allocating a fresh `Paint` per icon per frame.
**Reason:** Direct request + new reference photo.
**Expected improvement:** All three icons should read as closer matches
to the new reference photo than the Forty-ninth pass's shapes.
**Side effects:** Settings' STORAGE glyph now renders the more detailed
floppy disk too, since it shares `drawFloppyDiskIcon()` with the
quicksave button — one shape in both places instead of two that could
drift apart. No button's hitbox, drag/resize, or layout behavior
touched.
**Verification:** No compiler, device, or pixel-diff tool in this
sandbox — but instead of eyeballing the coordinate math alone, the three
shapes were reproduced in a small standalone script (same arcs/paths/
proportions, rendered to a PNG) and checked side by side against the
reference photo before being written into the actual source; the
quickload arrowhead's direction was caught and corrected this way
(pointed right-and-slightly-up on the first attempt, not the reference's
45°-up-right). Whole-file brace/paren balance checked on all 3 modified
files after every edit.

---

# CHANGELOG — Forty-ninth pass

Two threads this pass: a correction to the Forty-eighth pass's button
work (direct reports, quoted below), and the two GameScreenRecorder.kt
audit findings from last pass, both now fixed ("fix all").

## 1. Quicksave/quickload icons redrawn to match the reference photo; the name caption is reverted

**Category:** Fix (corrects a misread of the original request)
**Files modified:** `MainActivityControlLayout.kt`
**What changed:** The Forty-eighth pass added a text caption under
these three buttons' icons. Direct follow-up report: "did you see each
button on the photo i sent you the name just for what is it dont add it
just the button on left side the three of them" — the reference
screenshot's text labels were there so *Claude* would identify the
icons correctly, not a request to put text on the in-game button.
`drawActionButtonCaption()` is removed; the `when(id)` dispatch is back
to icon-only for all four buttons, same as it was before Forty-eighth.
Separately: "the overlapping is the button not text... change it now
with the images i sent you" — `drawActionButtonIcon()`'s `"quicksave"`
and `"quickload"` cases are redrawn from scratch to match the reference
image's own icons (a folded-corner page for quicksave, a box with an
outward-breaking arrow for quickload) instead of the previous floppy
disk / arrow-into-tray shapes. `"screenshot"` is unchanged — already a
camera silhouette, already close to the reference.
**Reason:** Two direct reports correcting the previous pass's
interpretation, quoted above.
**Expected improvement:** Icon-only again, matching what was actually
asked for both times; the two redrawn icons should read as closer
matches to the reference photo than the shapes they replace.
**Side effects:** None outside these two `when` branches — the button
`Button` model, hitbox, drag/resize, and every other button's icon are
untouched. `drawFloppyDiskIcon()` (SharedUi.kt) is untouched too; it's
still used by the Settings STORAGE glyph, just no longer by this one.
**Verification:** No compiler, no device, and no pixel-level image
inspection tool available in this sandbox — the two new icons are a
best-effort visual match to the reference photo's icon concepts (a
folded page, a box-with-arrow), not a traced reproduction. Both are
built to avoid the "duplicate light" shared-edge defect class already
fixed twice elsewhere in this file (drawFloppyDiskIcon()'s own FIX, and
"screenshot"'s bump seam) — every new shape either touches its

**Addendum, same pass, before this build was ever confirmed working:**
direct report that the two icons above still showed a visible
overlap — "it not continue stroke it line by line it's bad and on
reference its not line it got like an arc or c." This corrected a
specific piece of the verification note above: "only ever touches at a
single point, not a shared edge" was treated as safe by this file's own
established reasoning, but a shared point between two *independent*
draw calls still visibly double-composites — the report confirms that
on a real screen, not just in theory. Both icons were rebuilt so every
visually-connected piece is one continuous `Path` (a single `moveTo`,
unbroken `lineTo` chain) instead of separate `drawLine()`/`moveTo`
pieces meeting at a point: quicksave's fold-crease detail (the part
that touched the page outline at two points) is removed rather than
patched, since the page's own diagonal-cut corner already reads as
"folded" on its own; quickload's arrowhead is now one unbroken
shaft→tip→wing1→tip→wing2 path, the retrace back through the tip
handled by Android's own MITER-to-BEVEL fallback (`Paint.setStrokeMiter`)
rather than three independent lines meeting at a point. Same caveat as
above: no device to confirm against, so this is the corrected reasoning
applied as carefully as it can be from a read-through — not a
confirmed-fixed result.

neighbor at a single point or not at all, never along a shared run of
pixels. Whole-file brace/paren balance checked before and after (caught
and fixed one unmatched paren in a doc comment on the GameScreenRecorder.kt
side of this same pass — see item 2 — before it got this far).

## 2. GameScreenRecorder.kt: dropped encoder output during muxer startup, and a video/audio timestamp-origin mismatch

**Category:** Bug fix (found by audit, not a direct report — see
BUGS_FIXED.md for the full root-cause writeup)
**Files modified:** `GameScreenRecorder.kt`
**What changed:** `drainVideoLocked()`/`drainAudioLocked()` are now one
shared `drainLocked()` (parameterized by `isVideo`) instead of two
near-duplicates — they differed only in which field to read/write, so
this fix would otherwise have had to be made correctly in two places.
Real encoder output produced before `muxerStarted` is now copied into a
small per-track pending queue (`PendingSample`) instead of discarded;
`maybeStartMuxerLocked()` flushes both queues the instant the muxer
actually starts. Separately, a new `recordingStartNanos` field is set
synchronously at the top of `start()` — before the capture thread even
spawns — and is now the sole origin for video's per-frame presentation
timestamps (`startCaptureLoop()`), replacing a local clock that used to
start only after that thread's own EGL setup finished.
**Reason:** See BUGS_FIXED.md.
**Expected improvement:** No real audio/video output should be
silently lost during a recording's startup window, and the recorded
file's audio/video should no longer drift by however long EGL setup
took to start the video track.
**Side effects:** `pendingVideoSamples`/`pendingAudioSamples` are also
cleared in `teardownLocked()` — this class is one long-lived instance
reused across many start()/stop() cycles, so a queue left over from an
aborted recording (muxer never started) must not bleed into the next
one. No change to the steady-state (post-muxer-start) code path beyond
one existing boolean check being read the same way it always was.
**Verification:** No compiler or device in this sandbox. Traced every
call site of the old `drainVideoLocked()`/`drainAudioLocked()` to
confirm the new shared signature covers both; confirmed
`maybeStartMuxerLocked()` updates the relevant track-index field before
calling itself recursively-in-effect (i.e. before checking the other
track), so the flush sees correct state. Whole-file brace/paren balance
checked before and after — caught a missing closing paren in this
fix's own doc comment on the first pass, fixed before finishing.

---

# CHANGELOG — Forty-eighth pass

Direct report: "the screenshot button and the quick load and save make
it like the one on myboy the first photo with name on it because right
now it's bad with the overlapping line on button" — two reference
screenshots attached: one of My Boy!'s own icon-plus-name action list,
one of this app's current control overlay for comparison.

## 1. Quicksave/quickload/screenshot buttons now show their name, not just an icon

**Category:** Feature (control overlay)
**Files modified:** `MainActivityControlLayout.kt`
**What changed:** These three one-tap action buttons (the fourth,
`record`, is unchanged — it wasn't named in the report) now draw a
small text caption underneath the existing vector icon: new
`drawActionButtonCaption()`, called from `drawOutlineButton()`'s own
`when(id)` dispatch right after `drawActionButtonIcon()`. The caption
text comes from `labelFor()` — already the one source of truth for
these three names (the Add Control list, Remove Control confirmation,
and edit-mode toolbar all already read from it) — so the on-screen name
can't drift out of sync with those. Text size is solved from an actual
`Paint.measureText()` at a candidate size rather than a fixed constant,
since these buttons carry their own Control Size slider and are
corner-drag-resizable like every other control; a size tuned for the
default layout would clip "Screenshot" — the widest of the three — the
moment someone scales the button down.
**Reason:** Requested directly, with My Boy!'s own action-menu
screenshot as the reference: an icon alone asks a finger to remember
which small glyph means which action; icon-plus-name doesn't.
**Expected improvement:** All three buttons now read the way My Boy!'s
own do — recognizable by icon, confirmable by name — without giving up
the icon itself (kept, not replaced, since it's still the faster glance
once learned).
**Side effects:** Purely additive to `drawOutlineButton()`'s render
path — the `Button` model, hitbox, drag/resize, per-button opacity
override, and flash-on-tap feedback are all untouched, since the
caption is drawn straight from the same already-resolved `rect` rather
than stored as new per-button state. `record` keeps its bare dot
exactly as before.
**Verification:** No compiler or device in this sandbox, as every pass.
Read-through only: confirmed `labelFor()` already returns the exact
three strings needed ("Quick Save"/"Quick Load"/"Screenshot") with no
change to that function; confirmed the new function is only ever called
for the three intended ids; whole-file brace/paren balance checked
before and after this pass's edit. I also re-read this same button
family's two earlier stroke-overlap fixes (the floppy-disk notch and
the camera bump seam, both from direct reports of a "duplicate light"
look) to check whether either had regressed — both still trace cleanly
with no shared-edge overlap by my own read of the geometry — so I
can't point at a specific remaining line in the icon itself as the
cause of "the overlapping line." See KNOWN_LIMITATIONS.md.

---

# CHANGELOG — Forty-seventh pass

Five bugs reported directly against the Forty-sixth pass's build, all
fixed this pass — see BUGS_FIXED.md for each one's full root-cause
writeup and FILE_CHANGES.md for the file-by-file detail. No new
features; every item below is a fix to something the Forty-sixth pass
(or earlier) already shipped:

1. **ROM browser** opened a freshly-navigated-into folder scrolled to
   its bottom rather than its top, whenever that folder was shorter than
   whatever was previously on screen.
2. **Screen recorder** video froze at its first frame (audio kept
   recording fine throughout) — the Forty-sixth pass's own build already
   contained one undocumented attempt at this (`lockCanvas()` →
   `lockHardwareCanvas()`) that turned out not to fully fix it; this pass
   replaces both with a real EGL/GLES2 renderer instead.
3. **Quicksave/quickload/screenshot** never visibly reacted to a tap —
   no pressed/highlight feedback at all, unlike every other on-screen
   button.
4. **Custom control layouts** could revert to defaults after leaving the
   app any way other than the in-app menu's own Close (system Back, or
   the OS reclaiming a backgrounded process) — root cause traced to
   `loadCustomLayout()` only ever running once, at a point in `onCreate()`
   that's always Portrait regardless of the player's actual game
   orientation.
5. **Settings screens' icons** — one real leftover emoji character
   (Layouts screen's per-preset edit action), several icons reading as
   too small, and the Input/gamepad glyph's face buttons specifically
   too tiny to read clearly.

# CHANGELOG — Forty-sixth pass

Reported directly: the Forty-fifth pass's file split didn't build — see
BUGS_FIXED.md for the root cause and fix. Six features requested in the
same message, once the build was working again: background music,
screen recording, a rebuilt Layouts screen (named/savable presets), a
Debug settings toggle for two existing tools, a ROM browser scroll fix
(BUGS_FIXED.md), and real icon glyphs for quicksave/quickload/screenshot
(BUGS_FIXED.md).

## 1. Background music (Sound settings)

**Category:** Feature — see FEATURES_ADDED.md for the user-facing summary.
**Files added:** `MusicPlaylistPlayer.kt`, `MainActivityMusic.kt`.
**Files modified:** `MainActivity.kt` (fields, prefs load, lifecycle),
`MainActivityAudio.kt` (nothing — see below), `MainActivitySettingsDialogs.kt`.
**Design:** `MusicPlaylistPlayer` is a small, self-contained playlist
engine (a `Context` and a `List<Uri>` in, nothing else) — sequential or
shuffled playback of a SAF-chosen folder, auto-advance on completion,
bounded skip-on-error (never plays two tracks from the same "everything
in this folder is corrupt" folder past 10 tries). Every `MediaPlayer.
prepare()` call happens on a background thread it spins up itself —
`prepare()` blocks, and this can run from *inside* another track's own
completion callback (auto-advance), which fires on the main thread; a
`setupGeneration` counter discards a background prepare() that's been
superseded by a newer play/skip call before it finishes, so rapid
next-taps can't end up starting stale audio. `MainActivityMusic.kt` is
the glue: `listMusicFiles()` walks a SAF tree (extension **or** reported
mime type — some providers get one wrong), the folder-picker's own
callback (`musicFolderPicker`, a field on `MainActivity.kt` — has to be,
`registerForActivityResult()` needs Activity-construction-time
registration, mirroring `dataFolderPicker`'s own exact pattern), and
`pauseMusicForLifecycle()`/`resumeMusicForLifecycle()` hooked into
`onPause()`/`onResume()` alongside the game loop's own stop/start.
**New prefs:** `PREF_MUSIC_FOLDER_URI`, `PREF_MUSIC_ENABLED`,
`PREF_MUSIC_SHUFFLE`, `PREF_MUSIC_VOLUME`.
**Verification:** brace/paren balance on every touched file; every new
symbol cross-checked declared exactly once and called with the right
name from every call site (see the pass's own full symbol sweep, same
method BUGS_FIXED.md's build-fix verification used); no local compiler
— see KNOWN_LIMITATIONS.md.

## 2. Screen recorder (game screen + audio, no on-screen buttons)

**Category:** Feature — see FEATURES_ADDED.md.
**Files added:** `GameScreenRecorder.kt`, `MainActivityRecorder.kt`.
**Files modified:** `MainActivity.kt` (field, lifecycle),
`MainActivityAudio.kt` (one line in `writePcm()`),
`MainActivityRender.kt` (recording indicator),
`MainActivityControlLayout.kt`/`MainActivity.kt`/
`MainActivityControlEditorGeometry.kt`/`MainActivityInput.kt` (the new
"record" on-screen button — see item 6).
**Design — why no buttons is automatic, not filtered:** the video source
is `captureGameFrameBitmap()` (`MainActivitySaveStateUi.kt`, unmodified
— already exists for screenshots/save-thumbnails, already the
pre-controls game frame) drawn onto a `MediaCodec` Surface-input video
encoder's own input `Surface`, from a dedicated capture thread this
class owns. The on-screen buttons are drawn by a completely different
code path (`drawControls()`, only ever called against the real
`SurfaceView`'s own canvas in `renderFrame()`) that this recorder never
touches — there's no frame where a button *could* appear, rather than
one that gets cropped out after the fact. Audio is fed straight from
`writePcm()` — the literal samples about to reach the `AudioTrack`, into
a standard `MediaCodec` AAC ByteBuffer-input encoder, non-blocking
(drops a chunk rather than ever stalling the game thread waiting for an
encoder buffer). Both muxed into one `.mp4` via `MediaMuxer`, written to
a cache-dir temp file (its String-path constructor is guaranteed
available at any API level this app supports; its FileDescriptor
overload isn't) and copied out to the Storage folder's new `video`
subfolder (or the same automatic-mirror fallback Screenshots/saves
already use) once finished — same "stage locally, copy out" shape
`SaveEntry.stageForWrite()`/`commitWrite()` already established.
720x480/20fps: exactly 3x the GBA's native 240x160 (undistorted, no
letterboxing math), and a modest rate given every captured frame is a
fresh ~1.4MB bitmap on a 2D handheld-console capture, not fast 3D
footage. No `MediaProjection`/screen-capture permission needed at all —
this never touches the device's actual display output, so there's
nothing to request permission for.
**Verification:** same as item 1. The MediaCodec/MediaMuxer sequencing
itself (Surface-input video + ByteBuffer-input audio + a muxer that
needs both tracks' formats before `start()`) follows the standard,
widely-used pattern for exactly this "encode programmatically-drawn
content" case rather than an improvised one — flagged in
KNOWN_LIMITATIONS.md as the one piece of this pass with genuine
runtime-only risk, since there's no device here to actually run it on.

## 3. Layouts screen rebuilt — named, savable/loadable layout presets

**Category:** Feature — see FEATURES_ADDED.md.
**Files added:** `MainActivityLayoutPresets.kt`.
**Files modified:** `MainActivitySettingsDialogs.kt` (`showLayoutsSettings()`
rebuilt; Button size/opacity moved into `showInputSettings()`),
`MainActivityControlEditorMode.kt` (`exitEditMode()`), `MainActivity.kt`
(`editingPresetName` field), `MainActivityMenus.kt` (Layouts row subtitle),
`MainActivityControlEditorGeometry.kt` (stale scope-comment fix, below).
**Design:** a preset is a named JSON snapshot of the *existing*
`customLayout`/`removedButtons`/`addedExtraButtons` — that live state is
completely unchanged, a preset is just a storable copy of it, captured
(`captureCurrentAsPreset()`) or restored (`applyLayoutPreset()`) as a
whole. "+ New layout" and each row's ✎ both funnel into the *same*
existing editor `enterEditMode()`/"Edit Button Layout…" already uses —
`editingPresetName` (null = today's ordinary edit session; `""` = a new
preset pending a name; any other string = updating that preset) is what
tells `exitEditMode()`'s Done handler to also prompt for a name/update
the preset, on top of its existing "save the active layout" behavior,
unchanged. Stored under one new key, `PREF_LAYOUT_PRESETS` (a JSON
array), same "one key, one blob" shape the active layout's own 3
prefixed keys already use.
**Also fixed while researching this:** the control editor's own
top-of-file comment (`MainActivityControlEditorGeometry.kt`) claimed
this app is landscape-locked — true when originally written, no longer
true since `android:screenOrientation` became `"unspecified"` plus a
real Portrait choice in Video settings, some later pass than whichever
wrote that claim. Both it and the (newly-written, this pass)
`LayoutEntry` doc comment it was based on now say so accurately; the
preset code's own cross-orientation handling was already written
correctly regardless (writes straight to the *other* orientation's
stored slot without touching the live one) — only the comment
explaining it as "not reachable today" was wrong.
**Verification:** same as item 1.

## 4. Debug settings — toggle Memory Viewer / Link Debug out of the ▤ menu

**Category:** Feature — see FEATURES_ADDED.md.
**Files modified:** `MainActivityMenus.kt` (`showGameMenu()` rewritten;
new Debug row), `MainActivitySettingsDialogs.kt` (`showDebugSettings()`),
`MainActivity.kt` (two new fields + prefs load), `MainActivityShared.kt`
(two new prefs).
**Design/refactor:** `showGameMenu()` used to be a fixed `items` list, a
*separate* `needsRom` set of hardcoded index positions into that list,
and a `when(which)` dispatch with its *own* hardcoded positions — three
parallel structures kept in sync purely by everyone remembering to
renumber all three together (the old code's own comment about "Memory"
being placed right before "Close" specifically to dodge renumbering
everything after it was already a symptom of this). Conditionally hiding
two entries would have meant every entry *after* whichever one got
hidden shifting position in all three places. Replaced with a
`GameMenuAction(label, needsRom, action)` list built conditionally —
label/needsRom/dispatch bound together per row, so entries can be added,
removed, or hidden in any combination with nothing else to keep in sync.
Both toggles default **true** (today's behavior — both menu entries were
always present before this pass) and persist immediately on tap, same as
every other simple on/off setting in this app.
**New prefs:** `PREF_DEBUG_MEMORY_VIEWER`, `PREF_DEBUG_LINK_LOG`.
**Verification:** same as item 1.

## 5. Fixed and updated

See BUGS_FIXED.md for the pass-45 build failure (root cause, fix,
full symbol-by-symbol verification), the ROM browser scroll/rearrange
fix, and the quicksave/quickload/screenshot icon-button change (a
direct "this looks bad" report, tracked as a fix rather than a
feature, matching how the emoji→text change on the same three buttons
was tracked in the Forty-fourth pass).



Requested directly: split `MainActivity.kt` into separate, organized
files, with the app behaving exactly the same afterward. Pure
architecture pass — no bug fixes, no new features, nothing in
BUGS_FIXED.md/FEATURES_ADDED.md this time.

## 1. MainActivity.kt split into 15 files by responsibility

**Category:** Refactor/architecture (no intended behavior change)
**Files modified:** `MainActivity.kt`; new `MainActivityAudio.kt`,
`MainActivityRom.kt`, `MainActivitySaveStateCore.kt`,
`MainActivitySaveStateUi.kt`, `MainActivityControlLayout.kt`,
`MainActivityRender.kt`, `MainActivityInput.kt`,
`MainActivityControlEditorGeometry.kt`, `MainActivityControlEditorMode.kt`,
`MainActivityMemoryViewer.kt`, `MainActivityMenus.kt`,
`MainActivityVideoSettings.kt`, `MainActivitySettingsDialogs.kt`,
`MainActivityDebugLog.kt`, `MainActivityLink.kt`.
**Problem:** `MainActivity.kt` had grown to ~7,700 lines and ~190
functions covering every concern this app has — audio, the render/game
loop, gameplay touch, the control-layout editor, save-states, ROM
loading, every settings screen, crash/link debug logging, and the link-
multiplayer dialogs — all in one file, making any one piece hard to
find or reason about in isolation.
**Solution:** Every function that wasn't required to stay (see below)
moved verbatim into a new file as an `internal fun MainActivity.<name>()`
extension function, grouped by responsibility (see each new file's own
top-of-file comment, and the file map at the top of `MainActivity.kt`).
This is the exact same mechanism `SharedUi.kt` already established
(Thirty-second pass) for the same reason, just applied to the rest of
the file: an unqualified call site (`someFunction()`) resolves to an
`internal` extension function on the enclosing receiver type the same
way it resolves a real member call, so every existing call site —
inside `MainActivity.kt`, and inside every other new file — keeps
compiling completely unchanged. `MainActivity.kt` itself now holds only
what Kotlin/Android actually requires to stay a physical class member:
every field/property (visibility widened `private`→`internal` so the
new files can read/write them), the `Activity`/`SurfaceHolder.Callback`
lifecycle overrides (`onCreate`, `onDestroy`, `onPause`, `onResume`,
`onWindowFocusChanged`, `surfaceCreated`, `surfaceDestroyed`,
`surfaceChanged` — Kotlin requires an override to be a literal class
member, not an extension function), the `SaveEntry` inner class (an
`inner class` needs to stay physical for its implicit outer-instance
access to keep working), and the small data classes/sealed class/
companion-object constants (left in place — moving the type
declarations themselves, as opposed to the functions that use them,
had no real readability upside worth the relocation risk).
**Reason:** Requested directly. The extension-function approach
specifically (over e.g. real owned-state helper classes holding a
`MainActivity` back-reference) was chosen because it requires
zero rewriting inside any moved function body — every field/function
reference inside a moved function reads exactly as it did before,
Kotlin resolves it exactly as it did before, and the *only* textual
change anywhere is each function's own signature line plus a handful of
visibility keywords — which is what made this safely reviewable at all
without a real compiler in this sandbox (same constraint as every pass;
see Verification below).
**Expected improvement:** Each piece of functionality now lives in a
file sized for what it actually does (the smallest new file is 112
lines, the largest 873) instead of one 7,700-line file holding
everything; a future pass touching, say, save-state logic only has
`MainActivitySaveStateCore.kt`/`MainActivitySaveStateUi.kt` to read, not
the whole app.
**Side effects:** None intended — this pass deliberately touched
nothing about *what* the app does, only *where* the code that does it
lives. Two real textual side effects fell out of the mechanism itself
and are worth naming explicitly: (1) every companion-object constant
(`TAG`, every `PREF_*` key, `ORIENTATION_*`, etc.) and every class field
that any moved function reads is now `internal` instead of `private` —
still invisible outside this app's own module, just no longer scoped to
this one file; (2) `stateSlotRow()` (moved to
`MainActivitySaveStateUi.kt`) used `this@MainActivity` twice, inside
nested `.apply{}` blocks, to reach back past an inner `ImageView`/
`TextView` receiver — valid only because `stateSlotRow()` used to be a
literal member of `class MainActivity`, which is itself a scope named
`MainActivity`. As a top-level extension function its own receiver's
label is the function's own name, not `MainActivity` (see Kotlin's
qualified-`this` rules for extension functions/receivers) — both
rewritten to `this@stateSlotRow`, the only content-level edit inside any
moved function body anywhere in this pass.
**Verification:** No compiler or device in this sandbox, same as every
pass — this one leaned harder on scripted, exhaustive checks specifically
*because* of that, rather than read-through alone, given the size of
what moved:
- Every one of the 190 top-level members (fields, functions, the
  companion object, the small data classes, `SaveEntry`) was segmented
  by exact line range and every function-shaped one mapped to exactly
  one destination (new file or "stays"); a scripted check confirmed
  all 168 that moved plus the 8 lifecycle/callback overrides that
  stayed account for all 176 functions with none missing, none
  duplicated, and none left unmapped.
- Every moved function's body was diffed line-for-line against the
  original: re-indenting the new (top-level) version by one level and
  reverting its signature line reproduces the original file's text
  exactly, everywhere, confirming nothing was altered beyond the
  signature line itself and the whitespace-only dedent.
- Brace balance checked per new file and against the original total
  (854 open/854 close both before and after, split across 16 files
  afterward instead of 1) — every individual file balances on its own,
  meaning no function's braces ended up split across a file boundary.
- Grepped for every symbol that lost `private` (companion-object
  constants inside a *nested* segment weren't touched by the first
  pass of this script, since only each segment's own signature line was
  rewritten — caught by grepping the new `MainActivity.kt` for leftover
  `private` and finding ~40 companion-object constants still
  inaccessible from the new files; fixed, then re-verified the same
  way) and for every `this@`/`return@`/labeled-lambda pattern in every
  moved file (`this@MainActivity` — the two `stateSlotRow()` instances
  above, both real, both fixed; every `return@Thread`/`return@post`/
  `return@setAdapter`/`return@registerForActivityResult`/
  `return@<functionName>` instance checked and confirmed to already be
  either self-contained within the one function that moved as a unit,
  or based on an SDK function/trailing-lambda name rather than
  `MainActivity`'s own class name, neither of which the move affects).
- Confirmed `SaveEntry`'s own three genuinely-private members
  (`doc()`, `stagingFile()`, `usesDataFolder`) are never referenced
  from any new file (only from `SaveEntry`'s own methods, which stayed
  together with it), so they correctly did *not* need widening.
- Diffed the full pre/post file tree: every other existing file
  (`LinkMultiplayer.kt`, `RomBrowserActivity.kt`, `SharedUi.kt`,
  `RomZipUtils.kt`, `EmulatorEngine.kt`, every Gradle/manifest/resource
  file) is byte-for-byte identical to before this pass; the diff is
  exactly the 15 new files plus `MainActivity.kt` itself.
- `build.gradle.kts` has no explicit `sourceSets`/`srcDir`
  configuration, so the default Kotlin source set already picks up
  every `.kt` file under `src/main/kotlin/` automatically — nothing to
  add there for the new files to be compiled.

---

# CHANGELOG — Forty-fourth pass

Nine things this pass, eight from one direct report covering the editor
popup, off-screen dragging, portrait L/R and Select/Start, the three
emoji control buttons, save-slot/screenshot thumbnails capturing the
on-screen buttons, and two new features (Quick Save/Autosave as real
slots, and a My Boy–style Auto Save & Load setting) — plus a ninth,
found and reported mid-pass: customized button layouts not surviving an
abrupt app close.

## 1. Custom button layout lost on an abrupt app close

**Category:** bug fix
**Files modified:** `MainActivity.kt`
**Problem:** reported directly, mid-pass: a layout saved via the
editor's own "Done"/Save action would survive closing the app through
an in-app menu path, but not swiping the app away (or an OEM task
killer) shortly after saving.
**Solution:** `saveCustomLayout()`'s `SharedPreferences.Editor` write
was `.apply()` — queues the disk write on a background thread and
returns immediately. Switched to `.commit()`, which blocks the caller
until the write has actually landed on disk.
**Reason:** `.apply()`'s async write is only guaranteed to be flushed
ahead of a *normal* activity transition; an abrupt process kill can
outrun it outright, and the next cold start then reads whatever was on
disk before that save — indistinguishable from the customization having
reset. `.commit()` closes that window entirely. Called once per
deliberate Save tap, not a hot path, so the small synchronous cost is a
non-issue.
**Expected improvement:** a saved layout now survives being closed any
way at all, not just through the menu.
**Side effects:** none. `exportLayoutBackup()`'s own external-file
mirror, called right after, was already a plain synchronous
`File.writeText()` and needed no equivalent change.

## 2. Editor per-control popup still clipping, after five previous fixes

**Category:** bug fix
**Files modified:** `MainActivity.kt`
**Problem:** reported directly, still reproducible after five previous
passes' worth of fixes to the same report (all of them position-clamp
fixes — see this file's own history above). "The button customization
popup still get cut off if you move around the button."
**Solution:** `editRow2`/`editOpacityRow`'s sliders were a *fixed*
`EDIT_TOOLBAR_SLIDER_WIDTH_DP` (190dp) regardless of actual screen
width. `refreshEditToolbarPosition()` now computes how much width is
actually available (`lastSw` minus margins minus the row label's own
measured width) and shrinks both sliders to fit, down to a
`EDIT_TOOLBAR_SLIDER_MIN_WIDTH_DP` (90dp) floor, before measuring the
bar.
**Reason:** every previous fix clamped where the popup gets
*positioned*; none ever questioned whether its own intrinsic width
could fit the screen at all. On a screen narrower than the ~330dp the
design width adds up to (a portrait phone's own width being the common
case — see item 4 below), no amount of position-clamping can stop the
excess width rendering off one edge or the other, which is exactly what
read as "cut off."
**Expected improvement:** the popup can no longer be wider than the
screen has room for, on any screen size.
**Side effects:** none on any screen wide enough for the 190dp design
width (every existing landscape install) — the new shrink logic is a
no-op there.

## 3. Dragged/resized controls able to render off-screen

**Category:** bug fix
**Files modified:** `MainActivity.kt`
**Problem:** reported directly: "moving button make it that it can't go
over the screen." A large (or resized-up) control dragged near an edge
could still render well past it.
**Solution:** new `clampControlCenterToScreen()` clamps a control's
center against its *actual current size* (base width/height from
`defaultGeometry`, times its current scale), reusing the existing
`clampToScreenAxis()` per axis. Applied both to the plain-drag branch
and, new this pass, to the resize branch — growing a control near an
edge now gently pushes its position back rather than letting it run
past.
**Reason:** the old clamp was `(x - editDragOffX).coerceIn(sw*0.03f,
sw*0.97f)` — a fixed percentage band on the *center point only*, blind
to the control's own size. A large control's center could stay
obediently inside that band while its rendered edges ran well past the
screen.
**Expected improvement:** no control, at any size, can be dragged or
resized fully or partially off-screen.
**Side effects:** none for typically-sized controls dragged well away
from an edge — behavior there is unchanged.

## 4. L/R and Select/Start distorted in portrait

**Category:** bug fix
**Files modified:** `MainActivity.kt`
**Problem:** reported directly: "fix if you go portrait the button ge
weird like r l."
**Solution:** both `lrH` (L/R) and `ssH` (Select/Start) were computed
from raw screen height (`sh * <factor>`) while their matching width came
from raw screen width (`sw * <factor>`). Both now use `minOf(sw, sh)`
instead of `sh` alone — the same pattern `outlineStrokeW` already uses
elsewhere in this file for the same reason.
**Reason:** the intended squat/pill shapes only ever held up because
`sw` happens to exceed `sh` in landscape — the app's normal orientation.
Portrait inverts that relationship, and the same formula inverted the
shape into a tall, narrow sliver along with it.
**Expected improvement:** L/R and Select/Start keep a sane, correctly-
proportioned shape in portrait instead of an inverted one.
**Side effects:** none in landscape — `minOf(sw, sh)` equals `sh` there
already, so this is a byte-for-byte no-op for every existing landscape
install.

## 5. Quick Save/Quick Load/Screenshot buttons using emoji glyphs

**Category:** bug fix (visual consistency)
**Files modified:** `MainActivity.kt`
**Problem:** reported directly: "it use emoji don't use emoji."
**Solution:** the three `addButton()` labels — "💾"/"📂"/"📷" — replaced
with plain text "QS"/"QL"/"SS", matching the existing 2-letter
convention already used for LA/LB/AB/RA/RB in the same row.
**Reason:** direct request. Scoped specifically to these three
on-screen game-control buttons — dialog titles and settings-list icons
elsewhere in the app use emoji too, but weren't part of this report and
are left untouched this pass.
**Expected improvement:** no emoji rendering variance across devices/
fonts for these three controls.
**Side effects:** none — `drawOutlineButton()`'s label sizing was
already tuned for this exact length.

## 6. Save-slot thumbnails and screenshots capturing on-screen buttons

**Category:** bug fix
**Files modified:** `MainActivity.kt`
**Problem:** reported directly: "save slot png should only screenshot
the game screen not the buttons too, and same for screenshot button."
**Solution:** new `cropToGameScreen()` crops a full-surface `PixelCopy`
capture down to `gameScreenRect` — already tracked precisely for
hit-testing/dragging/`updateGameMatrix()`'s own clamp — before scaling.
Used by both `captureStateThumbnail()` and `takeScreenshot()`.
**Reason:** `renderFrame()` draws the game bitmap and then
`drawControls()` onto that same `Canvas` before presenting it, so a
`PixelCopy` of the `SurfaceView` was always the game *and* every
on-screen button composited together — there's no earlier,
controls-free version of that surface left to capture instead.
Cropping the already-composited capture down to the known game-screen
region is a much smaller, safer change than trying to suppress control
drawing for one frame around a capture that happens on a different
thread.
**Expected improvement:** state thumbnails and manual screenshots show
only the game image.
**Side effects:** none — crop bounds are clamped to the actual captured
bitmap regardless of what `gameScreenRect` currently holds.

## 7. Quick Save and Autosave now shown as real slots

**Category:** feature
**Files modified:** `MainActivity.kt`
**Problem:** reported directly: "make a slot for quick save slot and
autosave slot," plus, from the same report, "idk did it really save
because there no quicksave slot so i can't check."
**Solution:** new `SlotKind` (sealed class: `QuickSave`, `Autosave`,
`Numbered(slot)`) generalizes `SlotInfo`, which used to only hold a bare
`slot: Int`. `showSaveStateSlotDialog()` now lists Quick Save and
Autosave first, ahead of the numbered slots, each with its own
thumbnail and timestamp exactly like a numbered slot already had.
`quickStateFile()` gained a thumbnail sibling (`quickThumbFile()`) it
never had before, and `quickSaveState()` now captures one on every
successful one-tap save.
**Reason:** direct request, and the direct mechanism behind the
"can't check" report — Quick Save previously had no thumbnail and never
appeared in any slot picker, by design, so there was no way to see
whether a one-tap save had actually landed.
**Expected improvement:** both slots are now visible, checkable, and
loadable through the same dialog as the numbered slots.
**Side effects:** none for the numbered slots — `loadSlotInfo()`
(extracted from what used to be `showSaveStateSlotDialog()`'s own inline
per-slot logic) reproduces their existing behavior exactly, just
generalized to also serve the two new kinds.

## 8. New "Auto Save & Load" Misc setting

**Category:** feature
**Files modified:** `MainActivity.kt`
**Problem:** reported directly: "add auto save & load toggle like
myboy... auto save game on exit, load it back on start."
**Solution:** new `autoSaveLoadEnabled` preference (off by default).
When on, `onPause()` writes a dedicated `Autosave` state
(`autoStateFile()`) synchronously — unlike every other save-state write
in this file, which run on a background `Thread` — every time the app
backgrounds. `loadRomFromUri()`'s own success callback silently loads it
back the next time that same ROM starts, before `startGameLoop()`.
**Reason:** `onPause()`'s write has to be synchronous because Android
may kill the process shortly after `onPause()`/`onStop()` return, with
no guarantee a fire-and-forget background `Thread` ever finishes; the
background-`Thread` pattern used elsewhere is optimized for keeping
gameplay responsive while the game loop is still running, which by this
point in `onPause()` it no longer is (`stopGameLoop()` already ran).
Load-on-start is silent (no toast when nothing's found) since it runs on
every single ROM load, and most of the time — especially the very first
time a given ROM is opened — there won't be anything to load yet.
**Expected improvement:** matches the requested My Boy–style behavior;
off by default so nothing changes for anyone who doesn't enable it.
**Side effects:** thumbnail capture for the Autosave slot (see item 7)
is fired on its own best-effort background `Thread` from inside
`onPause()` rather than awaited synchronously there, since
`captureStateThumbnail()`'s own `PixelCopy`-plus-latch approach would
deadlock if blocking-awaited directly on the main thread. The state
save itself — the part that actually matters — is unaffected by this;
worst case the Autosave row's thumbnail lags by one save until the next
chance to update it. Also added to the "Reset settings" flow's own
defaults, unlike several older settings which reached that flow only in
a later pass (see this file's own history) — same gap, closed from the
start this time.

# CHANGELOG — Forty-third pass

Six things this pass: two real performance bugs in the per-frame render
path (found via direct code inspection, not a screenshot/report — both
confirmed by reading `drawDpad()`/`shoulderButtonPath()` directly), the
per-item editor's toolbar still going off-screen on drag despite four
previous passes' worth of fix attempts at the same report, Turbo A/B
rendering smaller than A/B, the control layout resetting when this app's
storage is cleared, and a request for an automatic own-folder — saves,
states, screenshots, layout — with no setup step required, "like My Boy."

## 1. `drawDpad()` — 240 RectF allocations/sec eliminated

**Category:** performance fix
**Files modified:** `MainActivity.kt`
**Problem:** allocated a fresh `RectF` for each of the 4 d-pad arms on
every single rendered frame — permanent GC churn on the same thread that
paces audio playback, for as long as a game is running.
**Solution:** the 4 arm rects are now reusable fields, recomputed via
`updateDpadArmRects()` only when the d-pad's own bounding rect has
actually changed (a plain `RectF.equals()` check) instead of every frame.
**Reason:** direct report, exact numbers given (240 allocations/sec at
60fps).
**Expected improvement:** zero steady-state allocation from this
function during normal play; only an editor drag/resize/orientation
change triggers a recompute.
**Side effects:** none — output is numerically identical, verified by
deriving the draw position from the cached rects' own `centerX()`/
`centerY()`/`width()` rather than duplicating the arithmetic.

## 2. `shoulderButtonPath()` — 120 Path allocations/sec eliminated

**Category:** performance fix
**Files modified:** `MainActivity.kt`
**Problem:** allocated a brand-new `Path` (a moveTo, 2 quadTo, a cubicTo,
a lineTo, a close) on every call, twice per frame for L and R.
**Solution:** two reusable `Path` fields (L and R need independent,
simultaneously-live geometry), rewound (`Path.rewind()`, not `.reset()` —
keeps the internal arrays) and rebuilt only when that side's rect has
changed since the last frame.
**Reason:** direct report, exact numbers given (120 allocations/sec at
60fps).
**Expected improvement:** same steady-state-zero-allocation improvement
as #1, same reasoning.
**Side effects:** none — geometry construction is untouched, just
targeted at a reused Path instead of `Path()`.

## 3. Per-item editor toolbar still cut off/disappearing on drag

**Category:** bug fix
**Files modified:** `MainActivity.kt`
**Problem:** same direct report as four previous passes'
`refreshEditToolbarPosition()` fix attempts: "if you move it sometimes it
disappears or get cutoff." The most recent of those attempts had already
named the exact remaining gap in its own comment ("the one remaining
case (topBound+h doesn't fit below lastSh at all)") without actually
closing it — a trailing `.coerceAtLeast(topBound)` ran *after* the
on-screen clamp with no ceiling of its own, so on a short enough
effective screen it could push the toolbar below the visible screen
entirely.
**Solution:** `topBound` is now folded into a single `coerceIn(minTy,
maxTy)` as a *preference*, honored only when doing so can't push the bar
past the bottom of the screen; falls back to the screen's own top margin
otherwise. Provably bounded — see the function's own doc comment for the
full argument.
**Reason:** direct report, worded identically to the reports the four
previous fix attempts were responding to.
**Expected improvement:** the toolbar can no longer render off-screen
regardless of screen size, selected control size, or drag position.
**Side effects:** on the one screen-too-short-for-either-preference edge
case, the bar now prefers overlapping the top bar's own strip (still
fully visible/usable) over running off the bottom (not usable at all).

## 4. Turbo A/B rendered smaller than normal A/B

**Category:** bug fix
**Files modified:** `MainActivity.kt`
**Problem:** `tSz` (Turbo A/B's default size) was `abSz * 0.75f` — a
fixed 75% shrink baked in underneath each button's own independent
Control Size slider, not instead of it. Matching percentages on both
sliders still produced two different sizes.
**Solution:** `tSz = abSz`. Turbo A/B keep their own independent
position/scale entries — still draggable/resizable separately from A/B —
only the default size they scale from now matches.
**Reason:** direct report: "turbo a and b not the same size as normal a
and b."
**Expected improvement:** the same Control Size percentage now produces
the same rendered size on both.
**Side effects:** none — the offset that positions Turbo A/B relative to
A/B is computed from `abSz`, not `tSz`, so it's unaffected; the two
buttons remain comfortably clear of each other at the new size.

## 5. Control layout resetting when this app's storage is cleared

**Category:** bug fix
**Files modified:** `MainActivity.kt`
**Problem:** `loadCustomLayout()`/`saveCustomLayout()` are pure
SharedPreferences, already outside any cache directory — but
SharedPreferences is still only ever as durable as this app's own
private storage, gone the moment that's cleared any other way.
**Solution:** `exportLayoutBackup()` mirrors both orientation profiles to
a JSON file in the new automatic own-folder mirror (#6) every time
`saveCustomLayout()` runs; `importLayoutBackupIfNeeded()` restores from
it on startup, but only when SharedPreferences has no layout data at all
to lose.
**Reason:** direct report: "if i clear cache my button reset."
**Expected improvement:** a layout survives a storage clear as long as
the automatic mirror folder does.
**Side effects:** none for anyone who's configured a Storage folder
already (see #6) — this backup only ever runs in the automatic-mirror
default case.

## 6. Automatic own-folder mirror — saves/states/screenshots/layout

**Category:** feature
**Files modified:** `MainActivity.kt`
**Problem:** this app's existing Storage-folder feature (Settings →
Storage) is opt-in — nothing leaves internal storage without a manual
SAF folder pick first. Requested directly: "make the app make its own
folder like my boy emulator and all the stuff in there like save
screenshot layout."
**Solution:** a new automatic mirror folder —
`Android/data/<pkg>/files/mGBA` (Saves/States/Screenshots/Layout) —
needs no permission and no setup, active whenever no Storage folder is
explicitly chosen. Native save/state I/O is untouched (still reads/writes
`SaveEntry`'s existing internal `legacy` file exactly as before); this
only ever mirrors already-successful writes outward, best-effort, via the
new `SaveEntry.mirrorToAutoFolder()`. Screenshots' existing fallback path
now nests under this same root instead of sitting bare under
`getExternalFilesDir()`. Steps aside entirely once a Storage folder is
configured — one visible "own folder" at a time.
**Reason:** direct report, as above.
**Expected improvement:** saves/states/screenshots/layout are all in one
findable, organized folder from first launch, no setup trip required.
**Side effects:** no migration of anything already saved under plain
internal storage before this pass — deliberately, matching this
project's existing stated policy on the Storage-folder feature just
above (moving/deleting a person's actual save data automatically, with
no real device available anywhere in this project's history to verify
that move against, is a worse risk than asking). Only new
saves/states/screenshots/layout writes go to the new folder from here.

# CHANGELOG — Forty-first pass

Four things reported directly, covering the file manager, the ROM
browser's Landscape→Portrait transition, the per-item editor's Control
Size/Opacity controls, and Max frame skips. Five screenshots attached, all
of the per-item editor bar (the title screen with Game Screen Size open,
then R Shoulder and A Button at a few slightly different toolbar
positions/zoom levels) — matched item 3's report directly. The file
manager and frame skip reports were text-only; both were directly
traceable in code without needing a matching screenshot.

## 1. File manager — .zip files no longer held back from the initial list

**Category:** UX/performance fix
**Files modified:** `RomBrowserActivity.kt`
**Problem:** Even with the Fortieth pass's own zip-scan parallelization,
`.zip` files were still held out of the list entirely until each had been
individually opened and content-checked (`RomZipUtils.zipContainsGba()`)
— a folder with several archives still showed only its bare `.gba`
files/subfolders at first, with the rest populating in afterward as scans
completed one by one. Reported directly: "only one file show at the
start and the other load later unlike my boy file manager it already
show all the file instantly."
**Solution:** `refreshList()` now treats `.zip` files the same as
folders/`.gba` files for the *initial* render — included by name/
extension alone, shown instantly, no scan required, correctly sorted in
place alongside everything else from the start. Content verification
still runs exactly as before, on the same background thread pool, but
now *prunes* an eventually-invalid `.zip` back out of the already-shown
list instead of gating that zip's first appearance on the scan
finishing.
**Reason:** direct report, as above.
**Expected improvement:** the file list should appear complete
immediately, matching the cited reference file manager's own behavior. A
side benefit: since every entry is already in its final sorted position
from the first render, nothing visibly jumps to a new spot once
verification finishes either (the old add-after-verify design appended
newly-verified zips at the end, then re-sorted, which could shuffle the
list the user was already looking at).
**Side effects:** A `.zip` that turns out not to contain a `.gba` may now
be visible for a moment before disappearing, rather than never appearing
at all. Tapping it in that window is already handled safely: MainActivity's
`loadRomFromUri()`/`stageRomFile()` already tolerates "no `.gba` found
inside" gracefully (a toast, not a crash), since the SAF fallback picker
has never gone through `zipContainsGba()` at all — this isn't a new code
path, just a slightly wider window in which an existing, already-graceful
one can be reached. `renderList()`'s own doc comment updated —
`stillScanning` now describes pruning, not gating additions.
**Verification:** No compiler/device available in this sandbox (see
README_SETUP.md). Traced `entries`/`zipCandidates` construction and the
renamed `invalidZips` set to confirm the final `filterNot` only ever
removes, never reorders or duplicates, entries from the already-rendered
list, and that the `generation` staleness guard (untouched) still applies
to it. Balance-checked.

---

## 2. ROM browser — Landscape→Portrait transition, next step tried

**Category:** UX polish (continuation of a Fortieth-pass fix)
**Files modified:** `themes.xml`
**Problem:** Reported directly, still visible after the Fortieth pass's
own `overridePendingTransition(0,0)` fix for this same Landscape
MainActivity → Portrait RomBrowserActivity transition: "it landscape but
it go to portrait instantly which is bad."
**Solution:** Added `android:windowDisablePreview=true` to
`Theme.mGBA.RomBrowser` — the next step that pass's own
KNOWN_LIMITATIONS entry had already flagged to try if a flash was still
visible. It addresses a different mechanism than the earlier fix: the
starting-window snapshot Android can show for a newly-launching Activity
before its first real frame is ready, separate from the enter/exit
transition animation `overridePendingTransition` already suppresses.
**Reason:** direct report, as above.
**Expected improvement:** should remove whatever's left of the visible
mismatch during this transition; combined with the already-black
`windowBackground` on this theme, the worst case left is a plain black
frame rather than a stretched or mismatched-orientation one.
**Side effects:** None expected. `windowDisablePreview` only affects the
one-time starting-window snapshot for this Activity, not its actual
content, layout, or the orientation lock itself — RomBrowserActivity
remains statically Portrait, unchanged, per the Thirty-second pass's own
crash history (see KNOWN_LIMITATIONS.md for why runtime rotation isn't
attempted here again).
**Verification:** No compiler/device. Confirmed `windowDisablePreview`
against long-standing Android theme attributes, no version-gating needed
for minSdk 24. XML re-validated as well-formed. Still can't be fully
confirmed without a real device — the same honest limitation every pass
touching this screen has had to note; see KNOWN_LIMITATIONS.md.

---

## 3. Control Size / Control Opacity — real sliders, type an exact number

**Category:** UX fix + minor architecture improvement
**Files modified:** `MainActivity.kt`, `SharedUi.kt` (new shared widget,
one relocated helper)
**Problem:** Reported directly, even after the Fortieth pass's own
48dp-minimum-touch-target fix for the "-"/"+" chips: "the plus for
opacity and increase button size it very small and bad... maybe a slider
with number or percent and you can type the number."
**Solution:** New reusable `sliderRow()`/`SliderRow` in `SharedUi.kt` — a
`SeekBar` plus a tap-to-type value readout (opens a new
`showTypeValueDialog()`, also in `SharedUi.kt`) — replaces the "-"/"+"
`editChip()` pair for both Control Size (50-800%) and Control Opacity (a
percent, floor matching the existing 60/255 alpha floor via
`alphaToPercent()`/`percentToAlpha()`). Both are drag-anywhere-on-the-
track *and* type-an-exact-number. `roundedDialogBackground()` moved from
`MainActivity.kt` to `SharedUi.kt` alongside them — the new dialog needs
it too, and it's exactly the kind of small/stateless/cosmetic helper that
file exists for (see its own top comment); every existing call site is
unaffected, same unqualified/same-package extension-function pattern the
rest of that file already relies on. The old delta-based
`adjustSelectedScale()`/`adjustSelectedAlpha()` are replaced with
absolute `setSelectedScalePercent()`/`setSelectedAlphaPercent()`, and a
new `syncEditButtonBarToSelection()` consolidates what used to be three
separate partial-refresh spots (`updateEditButtonBarLockIcon()`, plus
inline label/visibility lines in `onEditTouch`'s `ACTION_DOWN`) into one
— now also called after Reset and the lock toggle, which the old
stateless chips never needed since they had no live value that could go
stale.
**Reason:** direct report, as above.
**Expected improvement:** both controls should now be comfortable to
grab anywhere along their width, show their current value at a glance,
and accept an exact typed number for precise adjustment.
**Side effects:** The corner-drag resize gesture on the game canvas
itself (a second, older way to resize a control) now also keeps the
Control Size slider's displayed value live during that drag, so the two
never show inconsistent numbers. A locked control now visibly dims both
sliders (`SliderRow.setEnabled()`) rather than silently no-op-ing on
interaction — a small UX improvement over the old chips, which had no
visual indication of a locked state at all. Two stale doc-comment
references to the deleted `adjustSelectedScale()` were updated to point
at its replacement.
**Verification:** No compiler/device. Traced every constructor/function-
call site for argument name/order correctness. Caught and fixed a real
Kotlin scoping hazard during review: building the `SeekBar` inside an
`.apply {}` block would have let the receiver's own `max` property shadow
this function's `max` parameter for the unqualified reference on the
assignment's right-hand side (an implicit-receiver member resolves before
an enclosing function's same-named parameter) — moved the assignment
outside `apply{}` entirely to remove the ambiguity rather than rely on
being right about which way it resolves. Balance-checked.

---

## 4. Max frame skips — fixed making things slower instead of faster

**Category:** Bug fix (root cause)
**Files modified:** `MainActivity.kt`
**Problem:** Reported directly: "can you check max frame skip at 10 it
very bad its laggy i think it wrong unlike myboy it skip frame so its
fast but it skip frame but in here the max frame skip it becomes
slower." Root cause: the "behind schedule" signal gating
`maybeSkipRenderThisFrame` compared the *previous* iteration's full
wall-clock duration against one frame's budget — but that duration
always includes the blocking `writePcm()` call, the frame pacer by
design (see the AUDIO ARCHITECTURE comment above `initAudioTrack()`),
which alone consumes ~1 frame period of real time on every normal
iteration regardless of whether anything was actually skipped. Total
iteration time therefore sits right on the exact budget threshold
essentially always, so which side of that line it lands on is mostly
scheduling/audio-buffer noise, not a real signal the device is actually
struggling — "behind schedule" could fire close to half the time even on
a healthy device. With no cooldown beyond a single non-skip iteration,
one false trip could then chain up to `maxFrameSkips` visibly-stuck-on-
one-frame iterations in a row — worse, not better, the higher
`maxFrameSkips` was set, exactly the behavior reported.
**Solution:** The skip decision now compares against `lastComputeNs` —
only the CPU-bound portion of the previous iteration (`nativeSetKeys`
through `nativeReadAudioSamples`), timed separately from, and stopping
before, the blocking `writePcm()` call. This isolates "is the device's
own compute too slow for one frame's budget" from "did the pacer's own
intentional wait happen to land a hair over an exact threshold" — the
question this check was always meant to answer.
**Reason:** direct report, as above.
**Expected improvement:** Max frame skips should no longer trigger on
ordinary audio-pacing noise, and should scale sanely with the configured
value (10 no longer worse than a low setting) — it should only engage
when the device's own per-frame compute genuinely exceeds budget.
**Side effects:** The underlying "skip the pixel blit but still fully
emulate the frame" mechanism (`EmulatorEngine.nativeRunFrame(null)` /
`mgba_jni.c`) is unchanged — this pass only fixes *when* that mechanism
engages, not what it does. Re-traced the native side while investigating:
`g_core->runFrame()` (the actual CPU/PPU/APU emulation) always runs
regardless of a null bitmap; only the pixel-copy loop is skipped, so this
feature's real headroom is inherently limited to whatever that copy
costs. Not a new limitation this pass introduces, just one this pass's
own investigation confirmed — noted in KNOWN_LIMITATIONS.md.
**Verification:** No compiler/device. Traced the `lastComputeNs`
assignment through all three code paths (the skip branch, the normal
single-frame branch, and the fast-forward batch branch) to confirm every
one sets it right after its own last `nativeReadAudioSamples` call and
before its own `writePcm()`/decimate-and-write, so whichever branch runs,
the next iteration's decision is always based on real compute time, never
the pacer's wait. Confirmed `t0` (still used for the FPS overlay window
and the no-audio fallback sleep, both unrelated to this fix) is
untouched. Balance-checked.

---

# CHANGELOG — Fortieth pass

Five things reported directly against the Thirty-ninth pass's own
delivery and the ROM browser (Thirty-second pass, untouched since). Five
screenshots attached matched every one of them: the portrait edit view
showing the dark background band behind the D-pad/buttons, the landscape
edit view with the grid visible, both per-item popups (D-Pad, A Button)
showing the tiny Control Size ± chips, and the ROM browser's own
portrait view with a large unused black strip above "Load game."

## 1. Editor alignment grid — cells weren't actually square

**Category:** Bug fix (root cause, not a workaround) + minor extension
**Files modified:** `MainActivity.kt`
**Problem:** `gridDivisions` cells were built as `w/N` columns by `h/N`
rows (`drawGrid()`, `snapScaleToGrid()`) — N of each, independently, over
whatever the screen's actual width and height happened to be. On any
non-square screen (i.e. every real device, in either orientation) that's
a rectangle, not a square, no matter what N is — reads exactly as "not
really box[es]," which is what was reported. Size was also capped at the
32 preset.
**Solution:** New `gridCellPx()` is now the single source of the cell
size: `min(lastSw, lastSh) / gridDivisions`, so cells are always real
squares — N of them across the shorter screen dimension, however many
whole ones fit the longer one. `drawGrid()` and both
`snapPositionToGrid()`/`snapScaleToGrid()` all read from it instead of
each deriving their own (previously non-square) size, so what's drawn
and what dragging/resizing snaps to can never drift apart. `gridOptions`
extended to `4, 8, 16, 32, 64` (was capped at 32); preset labels changed
from `"N×N"` to bare `"N"` since the old label stopped being accurate the
moment N stopped meaning "columns and rows equally" — the dialog's
description text was extended to explain what the number means instead.
**Reason:** Direct report: "grid not really box and add more like 60 not
just 30 grid."
**Expected improvement:** The grid overlay now draws actual squares in
both orientations, snapping matches exactly what's drawn, and a
substantially finer 64-division option is available for precise
alignment (close to the "60" asked for; kept as a power of 2 to match
this dialog's own existing 4/8/16/32 progression rather than introducing
an odd one out).
**Side effects:** A previously-saved `PREF_GRID_SIZE` value (say, 8)
means something visually different now — the same integer now produces
square cells instead of a `w/N`-by-`h/N` rectangle, and landscape vs.
portrait will show a different *number* of columns vs. rows at the same
setting (always exactly N×N before; now N across the short side and
however many fit the long side). This is the fix itself, not a
regression to work around — nothing about a saved layout's own button
positions/sizes changes, only what the (purely visual/optional-snap)
grid looks like.
**Verification:** No compiler/device in this sandbox, as every pass.
Hand-traced `gridCellPx()`/`drawGrid()`/`snapPositionToGrid()`/
`snapScaleToGrid()` for both portrait and landscape aspect ratios,
confirming one shared cell size feeds all four. Grepped every remaining
call site of both snap functions to confirm none still pass the removed
`dimension` argument. Ran a corrected comment/string/template-aware
brace-paren-bracket scanner (own bug found and fixed this pass — it
wasn't restoring string-vs-code mode correctly after a `${...}`
template, which is common enough in this file's own log strings that it
mis-flagged several untouched files too, not just the edited ones; same
class of self-inflicted scanner bug Thirty-ninth pass's own item 5
found) over every `.kt` file in the project: all balanced.

---

## 2. Control Size / Control Opacity ± chips — real touch targets

**Category:** Bug fix (root cause, not a workaround)
**Files modified:** `MainActivity.kt`
**Problem:** `editChip()`'s `setPadding(18, 4, 18, 4)` passed raw pixels,
not dp — every other size in this file goes through `dp()`, this one
didn't. On a real, higher-density phone that's a handful of actual
pixels, not the 18dp/4dp it reads as in the source. Barely visible on
worded chips ("Add Control" etc.), which get most of their size from the
text itself regardless; nearly the *entire* size of a single-glyph
`"-"`/`"+"` chip, which is exactly what was reported.
**Solution:** `setPadding` now goes through `dp()` like everything else
in the file. `editChip()` gained an opt-in `minTouchDp: Int = 0`
parameter — 0 changes nothing for any existing call site — that sets
`minWidth`/`minimumWidth`/`minHeight`/`minimumHeight` to `dp(minTouchDp)`
when positive. The four Control Size/Control Opacity `"-"`/`"+"` call
sites now pass `minTouchDp = 48` (Android's own minimum touch target
guideline), guaranteeing a real tap target regardless of how little a
bare glyph plus padding would otherwise produce.
**Reason:** Direct report: "in control size there's plus and minus but
it really hard to click its very small."
**Expected improvement:** The four stepper buttons are now a guaranteed
48dp square minimum — several times their previous effective size.
**Side effects:** The `dp()` padding fix applies to every `editChip()`
button in the editor UI, not just the four steppers — the top bar (Add
Control / Reset Controls / Grid / Cancel / Done) and Unlocked/Reset in
the per-item bar all get modestly larger too, since 18/4 was always
meant to be dp, not raw pixels. The top bar is already wrapped in a
`HorizontalScrollView` specifically to handle overflow (added when it
grew to five buttons — see Thirty-ninth pass), so this is a safe,
already-anticipated case, not a layout break.
**Verification:** No compiler/device. Confirmed via grep that all 11
`editChip(` call sites resolve correctly against the new 3-parameter
signature — Kotlin's trailing-lambda call syntax works fine with a
defaulted middle parameter, so the 9 call sites that don't pass
`minTouchDp` still compile as `(label) { onClick }` against the default.
Balance-checked.

---

## 3. Removed the semi-transparent control-area background band

**Category:** Bug fix (removal, requested directly)
**Files modified:** `MainActivity.kt`
**Problem:** `drawControls()` filled a full-width rect from
`controlsTop` down to the bottom of the screen with `colorControlsBg`
(`#CC111122` — dark navy at ~80% opacity) every single frame, behind the
D-pad/buttons.
**Solution:** Deleted the fill and its now-unused color constant.
`renderFrame()` already runs `canvas.drawColor(Color.BLACK)` before
`drawControls()`, so the area is now plain black — seamless with the
rest of the screen — instead of a distinct tinted panel. `fillPaint`
itself (the shared `Paint` reused for every button/D-pad/FF fill in this
function) is untouched; only its two `colorControlsBg`-specific lines
are gone.
**Reason:** Direct report: "at the bottom there black transparent and
its bad... i don't really like it."
**Expected improvement:** No more visible tinted band behind the
on-screen controls.
**Side effects:** Worth flagging as a judgment call: the report said the
tint was disliked but didn't specify a replacement, so full removal
(plain black, matching the rest of the screen) was chosen as the most
direct reading rather than, say, a different color or lower opacity —
easy to swap for a specific alternative instead if plain black isn't
actually what was wanted.
**Verification:** No compiler/device. Confirmed `fillPaint`'s other 8
use sites in `drawControls()`/`drawDpad()` are intact and unrelated to
the removed rect. Confirmed `drawColor(Color.BLACK)` unconditionally
precedes `drawControls()` in `renderFrame()`, so no stale-frame/
unfilled-gap risk. Updated one other doc comment (inside
`updateGameMatrix()`) that referenced `colorControlsBg` by name, so
nothing still points at a removed symbol. Balance-checked.

---

## 4. ROM browser — landscape flash before settling into portrait

**Category:** Bug fix
**Files modified:** `MainActivity.kt`, `RomBrowserActivity.kt`
**Problem:** MainActivity runs in landscape during play;
RomBrowserActivity is manifest-locked to portrait. Opening it triggers a
real display reconfiguration, and the default Activity transition
animation (a slide/fade across the switch) gave that reconfiguration a
couple of animated frames to be visible in — reads exactly as "opens in
landscape... then it go to portrait instantly."
**Solution:** `changeRom()` now calls `overridePendingTransition(0, 0)`
immediately after launching `RomBrowserActivity`, collapsing the
enter/exit transition to an instant cut. `RomBrowserActivity` gets a
matching `override fun finish() { super.finish();
overridePendingTransition(0, 0) }` so all of its several `finish()` call
sites (✕ Close, picking a `.gba` file, the SAF-picker callback, backing
out at the root) get the same fix from one place, covering the return
trip too.
**Reason:** Direct report.
**Expected improvement:** The transition into and out of the ROM browser
should now be an instant cut instead of an animated one with a
wrong-orientation frame visible mid-transition.
**Side effects:** `overridePendingTransition` is deprecated as of API 34
(replaced by `overrideActivityTransition`) but remains fully functional
at this app's targetSdk 34 — kept as the plain, long-stable call rather
than a version-gated branch onto the newer, unfamiliar API, since the
two behave identically here and there's no compiler in this sandbox to
verify a new signature against. `@Suppress("DEPRECATION")` added at both
call sites. Deliberately doesn't touch `requestedOrientation` anywhere —
see `RomBrowserActivity`'s own top-of-file comment for the real native
RenderThread SIGABRT that made this screen its own Activity in the first
place; this is a window-transition/animation-only change and doesn't go
near that code path.
**Verification:** No compiler/device, as every pass — this specific
class of fix (a system-compositor-level rotation animation) is
inherently hard to fully verify without a real device; called out again
in KNOWN_LIMITATIONS.md this pass. Confirmed by reading the platform
docs' description of both APIs that neither calls `requestedOrientation`
or touches a live window's surface, so this carries none of the risk the
prior crash involved. Balance-checked both files.

---

## 5. ROM browser — status bar hidden, dead black space at top

**Category:** Bug fix (root cause)
**Files modified:** `themes.xml`, `AndroidManifest.xml`
**Problem:** The whole app uses `Theme.mGBA`, which sets
`android:windowFullscreen=true` at the `<application>` level — correct
for MainActivity's actual gameplay immersion (see `setImmersive()`), but
`RomBrowserActivity` inherited it too despite being a plain file-picking
utility screen. With the status bar hidden, its reserved space just
rendered as dead black area with no clock/notification/signal icons in
it.
**Solution:** New style `Theme.mGBA.RomBrowser` (parent `Theme.mGBA`)
overriding just `android:windowFullscreen` to `false`; applied via
`android:theme` on `RomBrowserActivity`'s own `<activity>` tag. Every
other visual (black window background, black status/nav bar color, no
content overlay) is unchanged.
**Reason:** Direct report: "there's lot of black space... make it that i
can see the notification or mobile data."
**Expected improvement:** The system status bar (clock, notifications,
signal/battery) should now show while browsing for a ROM; MainActivity's
own fullscreen gameplay is unaffected — it still uses `Theme.mGBA`
directly.
**Side effects:** None expected — `RomBrowserActivity.onCreate()` has no
runtime status-bar/immersive code of its own (confirmed below), so the
fullscreen behavior was coming entirely from the inherited theme
attribute; this one override is a complete fix, not a partial one
needing a runtime companion.
**Verification:** No compiler/device. Grepped the whole project
confirming `setImmersive()` and every `SYSTEM_UI_FLAG_*`/
`WindowInsetsController` usage is scoped to `MainActivity.kt` only —
`RomBrowserActivity.kt` has none. Validated both changed XML files parse
as well-formed XML.

---

## 6. ROM browser — zip scan parallelized, real "still scanning" indicator

**Category:** Performance fix + UX clarity fix
**Files modified:** `RomBrowserActivity.kt`
**Problem:** `refreshList()`'s background zip scan checked each `.zip`
candidate for a `.gba` entry one after another on a single `Thread` —
already flagged as a known, deliberate trade-off in
KNOWN_LIMITATIONS.md (Thirtieth pass): "a folder with many... `.zip`
files will take proportionally longer." Reported directly against a
real folder with a dozen archives (screenshot: 11 `.zip` files, one bare
`.gba`) — exactly that cost coming due. The immediate (`.gba`/folder)
results rendered right away, but the rest waited through eleven
sequential scans behind a single, easy-to-miss gray "Checking
archives…" text row.
**Solution:** Two independent fixes. (1) The scan now runs on a small
bounded pool (`ZIP_SCAN_THREADS = 4`) instead of sequentially — every
candidate is submitted up front, then its `Future` is collected, so
wall-clock time for N archives is roughly N/4 scans deep instead of N.
Still coordinated from a background `Thread` (unchanged), so the main
thread is never blocked either way. (2) The old
`messageRow("Checking archives…")` text-only row is replaced by a new
`scanningRow()` — an actual indeterminate `ProgressBar` next to the same
text — so "still actively working" reads unambiguously instead of being
mistakable for a finished/empty state.
**Reason:** Direct report: "it only show one file but still checking
archives to see all file."
**Expected improvement:** A folder with several archives should populate
substantially faster, and the loading state should read clearly as "in
progress."
**Side effects:** `ZIP_SCAN_THREADS` is a fixed constant, not adaptive
to device core count — deliberate, since this work is I/O-bound
(`ContentResolver`/flash reads), not CPU-bound, so core count isn't the
relevant resource; see KNOWN_LIMITATIONS.md. `messageRow()` now only
serves the "No ROMs or folders here" end state; its doc comment was
updated to stop describing the now-separate scanning row.
**Verification:** No compiler/device. Traced the `Future` submission/
collection order to confirm every candidate is submitted before any
`.get()` blocks (genuine parallelism, not accidental serialization), and
that `pool.shutdown()` only runs after every result is collected (no
leaked running tasks). Confirmed the existing `generation` staleness
guard (discarding a scan's result if the user has since navigated away)
is untouched and still applies to the merged final render.
Balance-checked.

---

# CHANGELOG — Thirty-ninth pass

Five related reports, all traced back to the same root cause introduced
when the game screen became resizable (Thirty-seventh pass): "Game
Screen Size" visibly resizing a big black area instead of just the
image, Stretch to Fit stretching what looked like the whole UI, a
leftover top-left speed indicator, and a request for a full grid-based
alignment/snapping system plus a cleanup pass on the editor's own UI
text. Screenshots (edit mode, and the resized game screen mid-session)
were attached and matched this diagnosis directly.

## 1. Game Screen Size resizing a black area instead of just the image

**Category:** Bug fix (root cause, not a workaround)
**Files modified:** `MainActivity.kt`
**Problem:** `updateGameMatrix()` built the editable "gamescreen" box as
`resolvedRect("gamescreen", ..., w = sw, h = sh * gameScreenFraction)` —
full screen width by a height fraction, an area with nothing to do with
the GBA's actual 3:2 image aspect ratio. The non-stretch branch then
aspect-fit the real bitmap *inside* that oversized box, so most of what
the editor let you drag/resize was dead pillarboxed space the small
visible image just happened to sit somewhere inside of. Resizing "Game
Screen Size" really resized that big mostly-empty rectangle — reads
exactly like "resizing enlarges a black area/container instead of the
image," matching both the report and the attached edit-mode screenshots
(a yellow selection box far larger than the actual game picture inside
it).
**Solution:** The box's default geometry is now itself aspect-correct —
built from the live framebuffer's own width:height ratio, clamped to the
available width if the screen is too narrow for it at full reserved
height. Since `scale` (one uniform float, see `LayoutEntry`) multiplies
both dimensions of an already-correct box, the editable box now *is* the
image, with no baked-in margin — there's nothing left for a resize to
enlarge except the picture itself. Added `clampRectToScreen()`, applied
to the resolved box every frame, so no amount of resizing (up to the
existing 8x cap) can push the box past the screen's own edges either —
the other half of "don't enlarge the entire container."
**Reason:** Direct bug report with screenshots.
**Expected improvement:** Dragging/resizing "Game Screen Size" now
visibly, proportionally resizes only the GBA picture. The box can never
exceed the screen's own bounds.
**Side effects:** Any `customLayout["gamescreen"]` entry saved by a
build before this pass had its `scale` computed against the old
(non-aspect-correct) base box; under the new, correct base box the same
stored `scale` number now produces a differently-sized result (in most
realistic cases, closer to correct/smaller, since the old base was
inflated). Position (`xFrac`/`yFrac`) is unaffected in the common case —
the new default box's *center* lands in the same place as the old one
whenever the screen is wide enough that width isn't the clamped
dimension, which is true for essentially every real device this app
targets. Worst case, the game screen's own "Reset" button in the
per-item editor bar fixes it in one tap.
**Verification:** No compiler in this sandbox, as every pass. Traced
`updateGameMatrix()`/`hitTestEditable()`/`onEditTouch()` by hand against
every one of the seven scenarios in the request (portrait, landscape,
grid on/off at each size, snapping, plain resize, Stretch to Fit,
Reset/Cancel/Done) — see KNOWN_LIMITATIONS.md for what's still genuinely
untested (no device or build in this sandbox). Ran a corrected,
comment/string/template-aware brace-paren-bracket scanner (see item 5
below — the previous version of this same scanner had its own bug,
found and fixed this pass) over the whole file: balanced, 0 remaining
depth. Confirmed every other source file (`LinkMultiplayer.kt`,
`EmulatorEngine.kt`, `RomBrowserActivity.kt`, `RomZipUtils.kt`,
`SharedUi.kt`, `mgba_jni.c`, `AndroidManifest.xml`) is byte-identical to
the input zip — nothing multiplayer/emulator-core related was touched.

## 2. Stretch to Fit stretching the whole UI / growing the black area vertically

**Category:** Bug fix
**Files modified:** `MainActivity.kt`
**Problem:** Same root cause as item 1 — Stretch to Fit filled
`gameScreenRect`, which *was* the oversized, non-aspect box. Any resize
applied to that shared box (even from the ordinary, non-stretch editing
flow) affected what Stretch to Fit then filled too, which is what read
as it affecting more than just the game picture.
**Solution:** Stretch to Fit is now a genuinely separate, fixed
computation, independent of any saved `"gamescreen"` `customLayout`
entry: the box is pinned to exactly `(0, 0, sw, sh * gameScreenFraction)`
— full available width, the same reserved height the app has always
used — every time, and the bitmap is scaled non-uniformly to fill that
exactly (unchanged: distorting the 3:2 aspect on purpose is what
"stretch" means). Because the reserved height is untouched by this,
turning Stretch to Fit on can't grow the black area vertically; because
nothing outside `gameScreenRect`/`gameMatrix` is touched, it can't
affect any other part of the UI. `hitTestEditable()` now skips
`"gamescreen"` entirely while Stretch to Fit is on — the box is fixed
and fills the width by definition, so there's nothing left to drag or
resize until it's turned back off (attempting to anyway, e.g. if it was
selected right before the setting was toggled from Settings without
leaving the editor, is a guarded no-op in `onEditTouch()` rather than a
silent edit to a `customLayout` entry that mode never reads).
**Reason:** Direct bug report.
**Expected improvement:** Stretch to Fit now does exactly what its name
says — fills the available width at the standard reserved height — and
nothing else on screen moves or resizes when it's toggled.
**Side effects:** None noted.
**Verification:** Same as item 1 (shared fix, same function).

## 3. Removed the top-left fast-forward speed indicator

**Category:** Bug fix / cleanup (requested removal)
**Files modified:** `MainActivity.kt`
**Problem:** `drawFfOverlay()` drew `"⏩ Nx"` at a fixed top-left canvas
position whenever fast-forward was active — a separate, always-on-top
element from the on-*button* speed text Thirty-seventh pass already
removed (see that pass's FEATURES_ADDED.md entry) for the same
complaint. This one was apparently never noticed until now — it's not
attached to any button, so removing the button-face text didn't affect
it.
**Solution:** Deleted `drawFfOverlay()`, its dedicated `hudPaint`, and
the `if (fastForwardActive) drawFfOverlay(canvas)` call site in
`renderFrame()`. `formatSpeed()` (which it used to build its text) is
still used elsewhere — the Misc settings speed field and the
hold-for-speed-slider readout — and stays.
**Reason:** Requested directly, matching the attached screenshots (all
three show it).
**Expected improvement:** Nothing draws in the top-left corner anymore.
Fast-forward's own on/off state is still visible via the »-button's
existing color/fill change, same as it's been since Thirty-seventh pass.
**Side effects:** None — this was a pure rendering call with no other
state tied to it. The separate, *opt-in* Settings → Misc → "Show
performance overlay (FPS / audio underruns)" readout (top-right, off by
default, added deliberately as a diagnostic tool — see
KNOWN_LIMITATIONS.md's earlier passes) is a different feature entirely
and was left exactly as-is: it isn't top-left, isn't on by default, and
isn't what any of the three attached screenshots show.
**Verification:** Grepped the whole file for both removed identifiers
afterward — zero remaining references.

## 4. Editor alignment grid — Grid Size / Show Grid / Snap to Grid

**Category:** Feature
**Files modified:** `MainActivity.kt`
**What changed:** A new "Grid" entry on the editor's top bar opens a
Grid Settings dialog: **Grid Size** (4×4 / 8×8 / 16×16 / 32×32 preset
radio, matching every other size-like setting already in this app),
**Show Grid** (draws the alignment lines while the editor is open —
`drawGrid()`, called from `drawEditOverlay()` regardless of whether
anything is currently selected), and **Snap to Grid** (drag/resize
round to the nearest grid line/cell — `snapPositionToGrid()` for
position, `snapScaleToGrid()` for size, both called from
`onEditTouch()`'s `ACTION_MOVE` only when the toggle is on). Applies to
every draggable/resizable control, the game screen included (while
Stretch to Fit is off — see item 2). All three settings persist
(`PREF_GRID_SIZE`/`PREF_SHOW_GRID`/`PREF_SNAP_GRID`) independently of
`customLayout`/`removedButtons`/`addedExtraButtons` — toggling them can
never touch, and is never touched by, anything already saved.
**Reason:** Requested directly — coarse-or-precise grid divisions,
snapping on move/resize, visibility toggle, snap toggle, snap
predictable enough that nothing ends up "slightly off-grid."
**Design note (size snapping):** Every entry resizes through one
uniform `scale` float, so buttons and the game screen never distort —
snapping width and height *independently* would either break that or
leave one of the two dimensions off-grid regardless. `snapScaleToGrid()`
snaps the element's **width** to a whole number of grid cells and
derives `scale` from that; height then follows exactly (same scale,
fixed aspect) rather than being separately forced onto its own line.
One predictable rule for every control, not a different one depending
on what's selected.
**Side effects:** None to existing layouts — see persistence note above.
**Verification:** No compiler in this sandbox, as every pass. Traced
`showGridSettingsDialog()` against the existing `showLayoutsSettings()`
it was modeled on (same `dlgRadioGroup()`/`dlgAddOpt()` helpers,
confirmed still present and unchanged in `SharedUi.kt`).

## 5. Customization UI: removed emoji, relabeled per the request, fixed a diagnostic-script bug

**Category:** Cleanup / bug fix (own tooling)
**Files modified:** `MainActivity.kt`
**What changed:** Every emoji/dingbat glyph in the editor's own UI is
gone, replaced with the plain labels requested: top bar now reads Edit
Layout / Add Control / Reset Controls (was "Reset All") / Grid (new) /
Cancel / Done. The per-item bar (shown when a control is selected) is
restructured from one long horizontal strip of `Size±`/`Op±` chips into
three stacked rows so the full requested labels fit: control name + Lock
state (now text, "Locked"/"Unlocked", not a lock emoji) + Reset; then
"Game Screen Size" or "Control Size" (contextual, set in
`onEditTouch()`'s `ACTION_DOWN`) with `-`/`+`; then "Control Opacity"
with `-`/`+` — hidden entirely when the game screen is selected, since
opacity has no effect on the live game image (nothing reads a
`"gamescreen"` `alphaOverride`) and showing a control that visibly does
nothing would be worse than not showing it. The Input-settings button
that opens the editor ("🖊 Edit Button Layout…") and a handful of
directly editor-adjacent toasts/dialogs (reset confirmation,
remove-control menu/toast) were cleaned the same way. Left alone, as
genuinely unrelated: gameplay button glyphs (Quick Save/Load/Screenshot
faces), and Settings-screen titles/rows outside the editor itself
(Memory Viewer, Storage, Advanced, the Link-Connected dialog) — none of
those are part of "Customization UI" and changing them wasn't asked for.
**Also fixed this pass:** the whole-file balance-checker script used to
verify item 1/2 above had its own bug — `${...}` string-template
expressions weren't correctly returning to "real code" parsing after
the `${`, so a closing `}` inside one was miscounted as string content
instead of a real brace. Confirmed by running the broken version against
the *original, unmodified* input file first (same false positive there,
proving it was the checker, not the code) before fixing it and
re-confirming both files balance cleanly. One-off diagnostic only, same
as Thirty-eighth pass's own comment-aware scanner — not added as a
standing part of this project.
**Reason:** Requested directly ("Do not use emojis," specific label
list, working Reset/Cancel/Done).
**Side effects:** None functional — text/visibility only.
**Verification:** Grepped the whole file for every emoji character that
was removed — zero remaining in the editor UI. Diffed the function
signature list against the original file: exactly the five functions
added (`clampRectToScreen`, `snapPositionToGrid`, `snapScaleToGrid`,
`showGridSettingsDialog`, `drawGrid`) and the one removed
(`drawFfOverlay`) — nothing else moved or duplicated.

---



Scope note: one real bug, `MainActivity.kt` only, prompted by an actual
CI build-log attachment (run 1575 — Thirty-seventh pass's zip failed
`compileReleaseKotlin`, so nothing installable came out of it, same as
Thirty-sixth pass's own build-log-prompted fix).

## 1. Fixed a duplicated comment-opener that swallowed the rest of the file

**Category:** Bug fix (build-breaking)
**Files modified:** `MainActivity.kt`
**Problem:** `applyLayoutSettings()`'s doc comment ended up with two
consecutive `/**` openers — the original, plus a new one added on top of
it by mistake during the previous pass's edit, whose `old_str` had
matched starting one line after the existing opener instead of including
it. Kotlin block comments nest, so the one `*/` already present only
closed the inner level; the outer comment stayed open through the rest
of the file.
**Solution:** Removed the duplicate `/**`, leaving the single, correctly
paired opener/closer the comment always should have had.
**Reason:** The user attached the real GitHub Actions build log —
`e: ... Missing '}'`, `e: ... Unclosed comment`, and a cascade of
`Unresolved reference` errors for real functions (`stopLink`,
`drawLinkStatus`, `drawFpsOverlay`, `showLinkRemoteDialog`,
`showLinkLocalDialog`, `showSaveStateSlotDialog`, `applyLayoutSettings`
itself) whose definitions had all been swallowed into the phantom
comment.
**Expected improvement:** `assembleRelease` should compile again — every
error in the log traced back to this one root cause.
**Side effects:** None — removing a stray duplicate comment marker has
no behavioral effect of its own.
**Verification:** No compiler in this sandbox, as every pass — but this
pass's verification method changed as a direct result of this bug: the
usual whole-file `{`/`}` character count (this project's standing
smoke test every pass) cannot detect an unclosed comment at all, since
comment markers don't add or remove brace characters — it reported
721/721 (balanced) both before and after this exact bug was live. Wrote
a proper comment-aware scanner instead (tracks Kotlin's nested `/* */`
depth, skips `//` line comments and string contents) to find precisely
where the phantom comment began, confirmed a clean 0 final depth after
the fix, and confirmed all seven functions the build log reported as
unresolved have exactly one real definition each. See
KNOWN_LIMITATIONS.md for what this means for every earlier pass's own
"balance checked" claims.

---

# CHANGELOG — Thirty-seventh pass

Six things reported together: the hold-for-speed-slider request repeated
(not built two passes ago), the game screen still not actually
resizable, a Z-order bug hiding the editor behind Settings, a request to
remove Fullscreen now that resize is real, 4x fast-forward feel/sound,
and Max frame skips flickering/flashing white. The white-flash one was a
real, confirmed bug — see BUGS_FIXED.md. Everything else here.

## 1. Fast-forward hold-for-speed-slider

**Category:** Feature (previously deferred, now built)
**Files modified:** `MainActivity.kt`
**What changed:** The »/fast-forward button no longer toggles the instant
it's touched. `ACTION_DOWN` now arms a delayed Runnable
(`ffLongPressPending`, same shape as the editor's own
`editLongPressPending`); if `ACTION_UP` lands on the button before the
long-press timeout, that Runnable is cancelled and fast-forward toggles
normally (a real tap). If the timeout fires first, `showFastForwardSpeedSlider()`
opens instead — a slider (0.5–16×, half-speed steps) with a live-updating
readout and a Done button, writing the same `fastForwardSpeed`/
`PREF_FF_SPEED` the Misc settings text field already does. Also removed
the "» 4×" speed-text that used to appear on the button while active —
the existing color/fill change already shows on/off state; the text was
a separate indicator reported as unwanted.
**Reason:** Requested directly (twice — see Thirty-fifth pass's own
deferral note).
**Side effects:** None to the toggle behavior itself for a normal tap —
still instant, just resolved on `ACTION_UP` instead of `ACTION_DOWN` now.
**Verification:** No compiler or device in this sandbox, as every pass.
Read-through only: confirmed the Runnable is cancelled via
`mainHandler.removeCallbacks()` on both the tap-resolves-first path and
the generic `else` branch (`ACTION_CANCEL`/stray events) other touch
state already gets cleared on, not just the happy path.

## 2. Game screen is now actually resizable/draggable

**Category:** Feature (completing something claimed finished before it
was)
**Files modified:** `MainActivity.kt`
**What changed:** The game screen is now a real participant in the same
editor every button already used, through the same generic id-keyed
machinery (`resolvedRect()`, `editRectFor()`, `hitTestEditable()`,
`labelFor()`, `resetSingleButton()`) rather than a parallel system of its
own — see the `gameScreenRect` field comment for the full reasoning.
`updateGameMatrix()` resolves `"gamescreen"`'s rect the same way any
button resolves its own, then fits/positions the GBA image within
*that* rect instead of a fixed top-left region.
`buildControlLayout()` now calls `updateGameMatrix()` internally at its
own end (removing three now-redundant external call-site pairs), so
`gameScreenRect` — and the actual rendered image — stays in sync with
every layout change, live drag/resize included, without threading a
second call through every one of `buildControlLayout`'s own call sites
individually. Long-press-to-remove is explicitly guarded against
`"gamescreen"` (see `showRemoveButtonMenu()`) — there's nothing sensible
"remove the game screen" would mean.
**Reason:** Requested directly; the previous pass had only fixed the
*navigation* into the editor, not made the screen draggable/resizable
once there (flagged as deferred at the time).
**Side effects:** None to button behavior — buttons' own resolution and
editing are completely unchanged, this only adds a new id alongside them
sharing the same machinery.
**Verification:** No compiler or device in this sandbox. Read-through
only: confirmed `editRectFor()`/`hitTestEditable()`/`drawEditOverlay()`
(the last one already generic via `editRectFor()`, needed no changes at
all) all correctly reach `gameScreenRect` for the new id; confirmed
`isButtonVisible("gamescreen")` resolves true by default (not in
`extraControlIds`, so it falls to the "not in `removedButtons`" branch,
and the long-press guard stops it from ever landing there); confirmed
`saveCustomLayout()`/`loadCustomLayout()` needed zero changes since they
already serialize the whole `customLayout` map generically by key.

## 3. Fixed: editor was invisible until Settings was closed first

**Category:** Bug fix
**Files modified:** `MainActivity.kt`
**Problem:** Tapping "Screen size" dismissed the Video popup and called
`enterEditMode()`, but never touched `settingsMenuOverlay` — the
Settings screen *underneath* that popup, a separate full-screen opaque
overlay — which stayed covering the editor that had, in fact, already
started right underneath it.
**Solution:** `settingsMenuOverlay.visibility = View.GONE` added
alongside the existing `dialog?.dismiss()`.
**Reason:** Reported directly ("you have to closed setting first to see
screen size or screen button customization").
**Expected improvement:** The editor (and its existing toolbar — Add
control, per-button Reset, Done/Discard — all of which likely read as
missing entirely while this bug made the whole screen unreachable) should
now actually be visible and usable the first time.
**Verification:** No compiler or device in this sandbox. Confirmed
`settingsMenuOverlay.visibility = View.GONE` is the exact same call its
own "✕ Close" button already uses elsewhere in this file, not a new,
unproven way of hiding it.

## 4. Fullscreen removed

**Category:** UX change (requested removal)
**Files modified:** `MainActivity.kt`
**What changed:** `fullscreenMode`, `CTRL_FRAC_FULL`, `PREF_FULLSCREEN`,
and every branch conditioned on them removed entirely — not hidden,
actually deleted (the controls-background rect now always draws; idle
alpha no longer has a fullscreen-only dim). The "Reset settings" handler
(Misc) also gained `stretchToFit`/`maxFrameSkips`/`linearFilterEnabled`,
which turned out to have been missing from it since they were added two
passes ago — an unrelated gap noticed while removing `fullscreenMode`
from that same list.
**Reason:** Requested directly, now that screen resize (item 2) is a
real substitute for what Fullscreen used to be the only way to get.
**Side effects:** Anyone with Fullscreen previously turned on will see
the game screen back at its plain default size after updating — a one-time
resize via the editor gets back to (or past) what Fullscreen used to give
directly.
**Verification:** No compiler or device in this sandbox. Grepped for
every remaining reference to all three removed symbols after the edit —
none left outside this pass's own explanatory comments.

## 5. Fast-forward at 4x and Max frame skips (My Boy comparison)

**Category:** Investigated / partially fixed
**Files modified:** `MainActivity.kt` (Max frame skips only — see
BUGS_FIXED.md for that one; nothing changed for fast-forward speed/audio
itself this pass)
**What happened:** Max frame skips' flickering was a real, confirmed bug
— fixed, see BUGS_FIXED.md. Fast-forward "4x is slow, sound a bit bad"
is the same territory investigated two passes ago (that pass's items 3–4),
now with a specific number attached rather than resolved further — see
KNOWN_LIMITATIONS.md for why this wasn't guessed at a third time either.

---

# CHANGELOG — Thirty-sixth pass

Scope note: one real bug, `MainActivity.kt` only, prompted by an actual
CI build-log attachment (run 1565 — Thirty-fifth pass's zip failed
`compileReleaseKotlin`, so nothing installable came out of it).

## 1. Fixed a real Kotlin compile error

**Category:** Bug fix (build-breaking)
**Files modified:** `MainActivity.kt`
**Problem:** `linearFilterEnabled` (Thirty-fifth pass's Linear filtering
feature) was read/written in four places but never declared — an
unchecked assumption that it already existed as a field alongside
`stretchToFit`/`maxFrameSkips`, based on seeing its *name* in a grep
result (a pref-load line and a doc comment) rather than an actual
declaration line for it specifically.
**Solution:** Added `@Volatile private var linearFilterEnabled = false`
next to `stretchToFit`/`maxFrameSkips`, matching their declaration style
exactly. No other change needed — every read/write site already had the
right shape for a plain `Boolean` field.
**Reason:** The user attached the actual GitHub Actions build log
showing `compileReleaseKotlin FAILED` with four `Unresolved reference:
linearFilterEnabled` errors, exact file/line/column for each.
**Expected improvement:** `assembleRelease` should compile again — this
was the only reported error in the log, and all four instances shared
the one root cause.
**Side effects:** None — a missing declaration doesn't have partial or
alternate behavior to preserve; adding it just makes the already-written
call sites work as originally intended.
**Verification:** No compiler in this sandbox, as every pass — verified
by reading the exact four file/line/column locations the real compiler
reported and confirming each now resolves to the new declaration, rather
than a fresh guess; whole-file brace/paren balance checked after the
edit (708 open/close braces, 3113 open/close parens).

---

# CHANGELOG — Thirty-fifth pass

Five screenshots this pass, comparing this app's Video settings against a
reference emulator's, plus a fullscreen crash report, a layout-reset
report, and the Turbo A/B size complaint continuing. Large pass — see
FILE_CHANGES.md for the full diff and KNOWN_LIMITATIONS.md for what's
deferred and why.

## 1. Video settings rebuilt to match the reference screenshots

**Category:** Feature + UX rework
**Files modified:** `MainActivity.kt`
**What changed:** `showVideoSettings()` rebuilt as a plain list (title +
optional gray subtitle per row, dividers) instead of one form with
everything crammed in. Two real, previously-unreachable features turned
out to already exist as fields/logic with zero UI wired to them —
**Stretch to fit screen** (`stretchToFit`, already implemented in
`updateGameMatrix()`) and **Linear filtering** (`linearFilterEnabled`,
had a field and a pref but nothing ever read it — the actual `drawBitmap`
call passed a plain `null` Paint, filtering permanently off regardless of
the setting; now uses a real `gamePaint` whose `isFilterBitmap` follows
it) — both just needed a checkbox. **Max frame skips** was the same
halfway state one level deeper: the field/pref/doc-comment describing the
intended behavior already existed, but the referenced
`maybeSkipRenderThisFrame()` didn't — implemented for real this pass (see
item 2). **Screen orientation** moved from an inline 5-option radio group
into its own popup (`showScreenOrientationDialog()`), matching the
reference's own popup styling — applies on tap, no separate Save. **Enable
OpenGL** and **GLSL Shader**, also in the reference, are deliberately
*not* included — this app's renderer has only ever been Canvas/
SurfaceView; there's no OpenGL path to switch to and no shader system,
and a checkbox that doesn't change anything would be worse than no
checkbox. **Fullscreen** (the previous screen's own checkbox) was kept
despite not appearing in the reference list — see item 4, it's not
redundant yet.
**Reason:** Requested directly, reference screenshots provided.
**Side effects:** None for existing saved prefs — `PREF_STRETCH`,
`PREF_MAX_SKIPS`, `PREF_LINEAR_FILTER` were already being read on every
launch, just never written to by anything in the UI; this pass adds the
first UI that can actually write them.
**Verification:** No compiler or device in this sandbox, as every pass.
Read-through only: confirmed all three "phantom" fields
(`stretchToFit`/`maxFrameSkips`/`linearFilterEnabled`) by grepping for
every reference to each, not just the one that prompted the search;
confirmed `gamePaint`'s single shared instance is mutated in place
(`updateLinearFilterPaint()`) rather than allocating a fresh Paint per
frame; whole-file brace/paren balance checked after all edits.

## 2. Max frame skips — implemented for real, wired into the normal-speed loop

**Category:** Feature (completing a half-built one)
**Files modified:** `MainActivity.kt`
**What changed:** The normal (non-fast-forward, `framesToRun == 1`)
branch of the game loop now tracks whether the *previous* iteration took
longer than one frame's budget (~16.67ms) and, if so and skip budget
remains (`consecutiveFrameSkips < maxFrameSkips`), calls
`nativeRunFrame(null)` instead of `nativeRunFrame(backBmp)` for this
frame — skipping the pixel blit only, not emulation or audio, reusing
the exact same null-bitmap fast path fast-forward's own sub-frame loop
already relies on. The buffer-publish step after it is unconditional
either way, so a skipped frame just leaves the previous frame on screen
for one more render cycle rather than corrupting anything.
**Reason:** Requested directly ("add max frame skip features can be set
to 0 to 10").
**Expected improvement:** On a slower device, normal (1x) play can drop
the expensive blit for a few frames to catch back up, rather than only
ever having that option during fast-forward.
**Side effects:** None at the default (0 — behavior identical to every
previous pass, `behindSchedule` is irrelevant when `maxFrameSkips` is 0
since the `&&` short-circuits). `consecutiveFrameSkips`/
`lastFrameLoopStartNs` reset every time the loop (re)starts, alongside
the existing `ffFrameAccumulator` reset, so stale state can't leak into
a fresh game session.
**Verification:** No compiler or device in this sandbox. Read-through
only: confirmed the buffer-publish `synchronized` block already runs
unconditionally regardless of whether a blit happened (checked its
actual code rather than assuming), which is what makes "skip the blit"
safe rather than needing its own separate handling; confirmed the skip
logic is scoped to `framesToRun == 1` only, so it can't interact with
fast-forward's own, differently-motivated skip-blit logic in the batch
branch.

## 3. Turbo A/B size — raised again

**Category:** Fix (second round of the same complaint)
**Files modified:** `MainActivity.kt`
**What changed:** Default size (`tSz`) raised 0.55x → 0.75x of a normal
A/B button; the resize scale cap (shared by every button, both the
toolbar +/- and the pinch gesture) raised 4x → 8x.
**Reason:** Reported as still too limited after an earlier pass had
already raised the cap once (2.5x → 4x) for this same complaint.
**Expected improvement:** Turbo A/B can now reach roughly 6x their old
default size (0.75 × 8) — comfortably past a normal A/B button's size if
wanted, rather than topping out just short of one.
**Side effects:** The higher cap applies to every button, not just Turbo
A/B — anyone resizing anything can now go bigger than before. Still
bounded, not literally unlimited.
**Verification:** No compiler or device in this sandbox. Confirmed both
`coerceIn` call sites (toolbar +/- and the pinch-resize gesture) were
updated together, not just one.

## 4. Fullscreen crash and lost layout edits — not fixed, crash log requested

**Category:** Investigated, not fixed
**Files modified:** none
**What happened:** Read through `applyLayoutSettings()`,
`buildControlLayout()`, and every `fullscreenMode`-conditional branch
looking for a crash-prone path. Didn't find one with high enough
confidence to act on. Separately, confirmed *why* a crash would also
explain "all the buttons I changed are gone": `saveCustomLayout()` is
only ever called from the edit-mode exit handler (`exitEditMode(save =
true)`) — layout edits aren't persisted until that explicit save, so a
crash before reaching it would lose whatever was mid-edit with no
separate bug required to explain that part.
**Why no code change:** No specific line to point at. This app already
has a built-in crash logger (see "Copy crash log" in the quick game
menu) — that's real data instead of another guess, and the efficient way
to actually find this one.

---

# CHANGELOG — Thirty-fourth pass

Four things reported in one message: cutout black area still present after
last pass, Turbo A/B feeling slow with an unwanted toggle, and fast-forward
described as laggy with weird sound. Two of these got real code changes
this pass; two got investigated and explained instead of guessed at a
third/second time — see each item and KNOWN_LIMITATIONS.md.

## 1. Turbo A/B moved off a toggle, sped up, labels fixed

**Category:** UX rework + fix (existing feature, not new)
**Files modified:** `MainActivity.kt`
**What changed:** The "⚡ Turbo A / Turbo B buttons" Settings checkbox
(added both together, all-or-nothing) is gone. `"ta"`/`"tb"` moved into
`extraControlIds`, the same individually opt-in-via-"+ Add control" system
`"abturbo"`/`"ab"`/etc. already used — each can now be added, positioned,
and removed independently. Their on-button label changed from `"T"` (both
buttons showed the identical letter, no way to tell Turbo A from Turbo B
by looking) to `"A"`/`"B"` respectively, matching how `"abturbo"` already
reuses its equivalent normal button's letter with red signaling "turbo."
`turboHalfPeriodMs` halved, 66ms → 30ms (≈7-8/sec → ≈16-17/sec).
**Reason:** Requested directly — toggle removal, label confusion, and
"its slow" were all named explicitly.
**Expected improvement:** Add just the one you want; tell them apart at a
glance; feels like an actual turbo button rather than a slow repeat.
**Side effects:** Anyone who'd previously turned the old checkbox on will
find Turbo A/B gone from their layout after updating (the old pref is
simply no longer read) — needs re-adding via "+ Add control", once, same
as adopting any other newly-available extra. Not a data-loss concern, no
saves/states involved, just a one-time re-add.
**Verification:** No compiler or device in this sandbox, as every pass.
Read-through only: confirmed `addButton()` already checks
`isButtonVisible()` internally for every id (checked its implementation
directly rather than assuming), so dropping the `if (turboButtonsEnabled)`
wrapper and calling it unconditionally is exactly the same pattern
`"abturbo"` already used successfully, not a new one; confirmed
`allControlIds()`'s special-cased `if (turboButtonsEnabled)` branch is
now fully redundant with `ids += extraControlIds` and removed rather than
left dead; confirmed `labelFor()` already had `"ta" -> "Turbo A"`/
`"tb" -> "Turbo B"` mapped (so the "+ Add control" menu needed no changes
of its own to show them correctly); confirmed removing the checkbox left
`showInputSettings()`'s local `prefs` variable unused and removed it too,
rather than leaving dead code; whole-file brace/paren balance checked
after all edits.

## 2. Fast-forward audio: better decimation filter

**Category:** Fix (audio quality during fast-forward)
**Files modified:** `MainActivity.kt`
**What changed:** `decimateForFastForward()` used plain box-filter
averaging (each output sample the equal-weighted mean of `factor` input
samples) — the function's own prior doc comment already called this "a
cheap stand-in for a proper low-pass filter." Replaced with the standard
filter-then-downsample shape: a one-pole low-pass runs once across the
whole accumulated block, then every `factor`th filtered sample is kept,
rather than trying to make the averaging do both jobs.
**Reason:** Reported as "sound is weird" alongside the fast-forward lag
complaint.
**Expected improvement:** Less aliasing (harsh/grainy high-frequency
content folding back down) and less of the muffled quality a box filter's
weak, non-flat passband adds — a cleaner-sounding pitch-up. The pitch-up
itself is unchanged and not a bug: speeding up audio this way inherently
raises its pitch (the "chipmunk" effect), same as it would on a tape
played fast, and this function was never trying to hide that.
**Side effects:** None expected for pacing/timing — `outPairs` (what
actually governs how much audio gets written and how long `writePcm()`
blocks for) is computed exactly the same way as before, `accumPairs /
factor`; only how each output sample's *value* is computed changed. CPU
cost is in the same complexity class as the box average it replaces (one
multiply-add per input sample either way), so this shouldn't make the
reported laggy feeling any worse.
**Verification:** No compiler or device in this sandbox, as every pass.
Read-through only: confirmed the filter runs continuously across
`accumPairs` samples rather than being reset per output (a continuous
IIR state is what makes it an actual low-pass rather than something more
like independent per-block averages again); confirmed the `alpha =
2/(factor+1)` conversion is a standard, well-established period-to-EMA
formula rather than an arbitrary constant; confirmed the caller
(`accumPairs > 0` before calling) already guarantees at least one sample
exists before the function reads `ffAccumBuffer[0]`/`[1]` to seed the
filter state; confirmed the `factor <= 1` early-return path (normal,
non-fast-forward speeds) is completely untouched.

## 3. Camera-cutout black area — not touched again this pass

**Category:** Investigated, not fixed a third time
**Files modified:** none
**What happened:** Still reported after Thirty-third pass's `ALWAYS` mode
upgrade. Read back through how the game screen itself is sized
(`updateGameMatrix()`) rather than guessing at the cutout mode a third
time, and found a real, separate, and quite plausible explanation: the
GBA's native 240×160 (3:2) image is scaled to *fit inside* the available
area preserving aspect ratio (`scale = min(sw/240, gameH/160)`), then
centered — on a modern phone's much wider-than-3:2 landscape screen, the
width term is essentially never the limit, so there's a real, expected,
correctly-computed black margin on the left and right of the game image
(pillarboxing) on every device with this app, cutout or not. If the
phone's cutout happens to sit within that margin — plausible, since
cutouts are usually near an edge and so is the pillarbox — "a lot of
black screen on camera notch area" could describe *that*, not a
cutout-handling gap at all, in which case neither this pass's nor last
pass's cutout-mode changes could ever have looked any different, working
correctly or not.
**Why no code change:** This is a real, different hypothesis from what
the last two passes acted on, not confirmed — and if it's right, there
isn't an obvious fix that doesn't mean stretching or cropping the actual
game image, both worse tradeoffs than the pillarboxing itself. Guessing a
third time on a description this general risked another cycle spent on
the wrong target. See KNOWN_LIMITATIONS.md for what would actually
resolve this.

## 4. Fast-forward "laggy" — investigated, no bug found

**Category:** Investigated, not fixed
**Files modified:** none
**What happened:** Read back through the entire fast-forward path in
`startGameLoop()` (the audio-write-blocking frame pacer, the batched
sub-frame loop, the skip-blit optimization for hidden sub-frames) and
`nativeRunFrame()`'s null-bitmap fast path in `mgba_jni.c` looking for a
concrete inefficiency. Didn't find one — both are already tuned about as
tightly as this design allows (documented across several earlier passes'
own FIX comments already in this code). The audio-blocking pacer's
correctness assumption is that emulating `factor` sub-frames takes *less*
wall-clock time than playing `factor` frames' worth of audio would at 1x
— true with CPU to spare, but if a device's CPU can't emulate faster than
that at the chosen fast-forward multiplier, the same blocking design that
paces normal 1x play smoothly will instead show up as real stutter,
because emulation itself becomes the bottleneck rather than the audio
buffer. Genuinely can't tell from a read-through alone whether that's
what's happening here, or something else — no profiler, no device.
**Why no code change:** No specific bug to point at and fix. See
KNOWN_LIMITATIONS.md for what would help pin this down further.

---

# CHANGELOG — Thirty-third pass

Two unrelated requests this pass: a reported black area around the
camera-cutout notch, and a live memory viewer (full description in
FEATURES_ADDED.md; this entry covers its mechanics too).

## 1. Camera-cutout black area — strengthened, not confirmed fixed

**Category:** Fix attempt (display cutout handling)
**Files modified:** `MainActivity.kt`, `RomBrowserActivity.kt`
**What changed:** MainActivity's existing cutout handling (added an
earlier pass) upgraded from `LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES`
to `LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS` on API 30+ (falling back to the
previous `SHORT_EDGES` on API 28–29, where `ALWAYS` doesn't exist).
`ALWAYS` is a strict superset of `SHORT_EDGES` — content is unconditionally
allowed into the cutout area, with none of `SHORT_EDGES`'s own conditions
— so this can only extend the drawable area further, never shrink it.
Separately, and more confidently: RomBrowserActivity — new this overall
changeset, so it never had *any* cutout handling — got the same
ALWAYS/SHORT_EDGES pair MainActivity now has, rather than being left on
the platform default.
**Reason:** Reported directly: "a lot of black screen on camera notch
area."
**Expected improvement:** Less unused black area around the cutout on
MainActivity; RomBrowserActivity should now handle it at all, where
before this pass it did nothing.
**Side effects:** None expected — `ALWAYS` only ever grants more drawable
area, never less, and the two Activities' handling is now consistent
with each other.
**Verification:** No compiler or device in this sandbox, as every pass —
and this one carries a genuine, stated uncertainty on top of that usual
caveat: `ALWAYS` is a real, correct strengthening of the cutout mode
regardless, confirmed against current Android documentation, but whether
it's the *complete* explanation for "a lot of black screen" (as opposed
to, say, aspect-ratio letterboxing being mistaken for it, or the
RomBrowserActivity gap being the larger part of what was actually seen)
isn't something this read-through can settle without a screenshot or a
device to compare against. See KNOWN_LIMITATIONS.md.

## 2. Live memory viewer

**Category:** Feature (see FEATURES_ADDED.md for the full description)
**Files modified:** `mgba_jni.c`, `EmulatorEngine.kt`, `MainActivity.kt`
**What changed:** New `nativeReadMemory()` (native) /
`EmulatorEngine.nativeReadMemory()` (Kotlin) reads live core memory via
`mCore.busRead8()`; a new overlay displays it as a hex dump, reachable
from the quick game menu's new "Memory" item.
**Reason:** Requested directly.
**Expected improvement:** Can now watch live GBA memory (party/battle
data, or anything else) change turn by turn without leaving the running
game.
**Side effects:** None to existing features — purely additive; the new
`busRead8()` calls happen only while the overlay is open and are held
under the same `g_core_mutex` every other core access already uses, so
they can't race with `nativeRunFrame()` on the game thread.
**Verification:** No compiler or device in this sandbox, as every pass.
Read-through only: confirmed `busRead8`/`busRead16`/`busRead32` are real,
current `mCore` function-pointer members (checked against mGBA's own
`src/core/cheats.c`, which reads memory through the identical
`core->busRead8(core, address)` call for its cheat system) rather than
assumed from memory of the API; confirmed every `g_core` access in the
new function is inside the lock, matching this file's existing
discipline; confirmed the quick game menu's new item was appended at the
end of the list (not inserted in the middle) so no other item's numeric
dispatch `when` case needed renumbering; whole-file brace/paren balance
checked on every touched file after all edits (`MainActivity.kt` 689/689
braces, `mgba_jni.c` 80/80 braces, all parens balanced too).

---

# CHANGELOG — Thirty-second pass

Follow-up on Thirty-first pass's delivery: remove the Root button, and
pushed back on the no-rotation compromise with a concrete counter-example
(My Boy's own file manager: Portrait for ROM selection, a different,
Settings-configurable rotation for gameplay). Full description in
FEATURES_ADDED.md; this entry covers the mechanics.

## 1. ROM browser split into its own Activity, statically locked to Portrait

**Category:** Feature/architecture (ROM browser presentation)
**Files modified:** `AndroidManifest.xml`, `MainActivity.kt`; new
`RomBrowserActivity.kt`, `RomZipUtils.kt`, `SharedUi.kt`.
**What changed:** ROM selection moved from an overlay inside
MainActivity's window to a separate `RomBrowserActivity`, declared
`android:screenOrientation="portrait"` in the manifest. No
`requestedOrientation` call exists anywhere in the new Activity.
MainActivity's role reduced to launching it and handling the result.
**Reason:** Requested directly, with a specific real-world counter-
example (My Boy) that the previous panel-only compromise didn't match.
**Expected improvement:** The actual Portrait-file-manager /
independently-oriented-gameplay behavior asked for, matching the
reference app, without the two previous attempts' runtime-rotation
crash risk — see below.
**Side effects:** `RomBrowserActivity` is a real screen transition now
(new Activity, not an overlay) — a system Activity transition animation
will play opening/closing it, where before this was instant (an overlay
visibility toggle). Minor visual change, not expected to matter, but
different from before. Back button behavior changed: it now navigates up
a folder before exiting, where previously there was no back-stack
participation for this screen at all (it was an overlay, not an
Activity) — see FEATURES_ADDED.md.
**Verification:** No compiler or device in this sandbox, as every pass.
Read-through only: grepped the entire codebase for every symbol that
should have moved (`romTreeUri`, `romTreePicker`, `PREF_ROMS_TREE_URI`,
`romBrowserStack`, `buildRomBrowser`, `zipContainsGba`,
`ensureBroadFileAccess`, etc.) to confirm no stray references were left
calling something that no longer exists in `MainActivity.kt`; separately
checked every import added or left over from earlier passes
(`android.os.Environment`, `android.provider.Settings`,
`java.io.BufferedInputStream`) for real usage beyond the import line
itself, removing three that had none; checked every import in all three
new files the same way, all used; six now-inaccurate comments (see
FILE_CHANGES.md for the full list) caught and rewritten rather than left
to describe code that no longer exists; whole-file brace/paren balance
checked on `MainActivity.kt` (652/652 braces, 2777/2777 parens) and each
new file individually (`RomBrowserActivity.kt`: 70/70, 259/259;
`RomZipUtils.kt`: 6/6, 29/29; `SharedUi.kt`: 2/2, 23/23); manifest XML
parsed successfully; confirmed the new/pristine file lists differ by
exactly the 3 new files, nothing else added or removed.

---

# CHANGELOG — Thirty-first pass

Follow-up feedback on Thirtieth pass's ROM browser delivery: wanted real
free navigation instead of the existing SAF-tree-scoped browsing, a
Portrait-only file manager screen, and mentioned the menus/browser
feeling laggy. Full description of what got built in FEATURES_ADDED.md;
this entry covers the mechanics and the two things that were *not* just
built as literally requested.

## 1. Free-roam file manager, replacing the SAF tree picker

**Category:** Feature (ROM browser navigation model)
**Files modified:** `AndroidManifest.xml`, `MainActivity.kt`
**What changed:** ROM browsing moved from `DocumentFile` over one
SAF-granted folder tree to plain `java.io.File` over all of local shared
storage, gated by a new permission flow (`ensureBroadFileAccess()` —
`MANAGE_EXTERNAL_STORAGE` on API 30+, `READ_EXTERNAL_STORAGE` below
that). See FEATURES_ADDED.md for the full file list.
**Reason:** Requested directly.
**Expected improvement:** Navigate anywhere in local storage without a
separate folder-granting step; likely addresses the reported "laggy
menus/file manager" too, since folder listing is now a direct local read
instead of a Binder call into Android's storage provider — the
pre-existing code already flagged that call as a possible lag source
(see the block comment above `openRomBrowserAtRoot()` before this pass,
and KNOWN_LIMITATIONS.md).
**Side effects:** First launch (or first ROM load after an update) now
prompts for a real permission — a system Settings screen on API 30+, not
just an in-app dialog — where before this feature needed no storage
permission at all. Documented as a deliberate, known trade-off, not an
oversight — see FEATURES_ADDED.md's note.
**Verification:** No compiler or device in this sandbox, as every pass.
Read-through only: confirmed the native ROM-loading call
(`EmulatorEngine.nativeLoadROM(tmp.absolutePath, savePath)`) already only
ever took plain paths, never a `Uri` or SAF-specific type, so
`stageRomFile()`/`zipContainsGba()`/`loadRomFromUri()` needed zero
changes — the new browser just calls the same `loadRomFromUri(Uri.fromFile(file))`
every other entry point already used; confirmed `deriveRomBaseName()`'s
existing `contentResolver.query()` + `try/catch` + `uri.lastPathSegment`
fallback chain handles a `file://` Uri correctly (the query throws or
returns nothing for a scheme with no registered ContentProvider,
falling through to `lastPathSegment`, which returns the decoded file
name); whole-file brace/paren count checked after all edits (726/726
braces, 3083/3083 parens).

## 2. Portrait-styled panel, not an actual forced rotation

**Category:** Feature (ROM browser presentation)
**Files modified:** `MainActivity.kt`
**What changed:** `buildRomBrowser()` now returns a dimmed-backdrop
`FrameLayout` with a centered, width-capped, rounded `panel` inside it,
instead of one edge-to-edge `LinearLayout`. No orientation API call
anywhere in this screen's code.
**Reason:** Requested as "force Portrait for file manager only" — built
as the safer alternative instead (see below), not the literal request.
**Expected improvement:** The portrait-list look, without reintroducing
the native RenderThread SIGABRT a real forced rotation caused on this
exact screen (found and reverted two passes before this one — see
BUGS_FIXED.md/CHANGELOG.md). That reverted attempt's own comment had
already named this panel approach as the safer route to revisit if
portrait selection mattered enough to come back to — it did, so this
pass built it.
**Side effects:** Not a literal device rotation, so anything that
specifically expected the *device* to report itself as portrait (none of
this app's own code does) wouldn't see that. Purely visual/layout.
**Verification:** No compiler or device in this sandbox. Read-through
only: confirmed no `requestedOrientation` call exists anywhere in
`buildRomBrowser()`, `openRomBrowserAtRoot()`, or the row/close/load
handlers — the exact call sites the reverted attempt used — so the
SIGABRT's specific trigger (a real surface reconfiguration in the middle
of other view work) has nothing to fire on here.

---

# CHANGELOG — Thirtieth pass

Feature request: make the ROM browser's `.zip` filtering content-aware
instead of name-only. Full description in FEATURES_ADDED.md; this entry
covers the mechanics.

## 1. ROM browser now verifies a `.zip` actually contains a `.gba` before listing it

**Category:** Feature (ROM browser filtering)
**Files modified:** `MainActivity.kt`
**What changed:** `refreshRomBrowserList()` no longer treats every `.zip`
in a folder as a ROM by name alone. Directories and bare `.gba` files
still render immediately; `.zip` files are now checked in the background
(`zipContainsGba()`, sharing its magic-bytes check with `stageRomFile()`
via new helper `isZipSignature()`) and only added to the list once
verified. A new generation counter (`romBrowserGeneration`) discards a
scan whose folder the user has already navigated away from by the time
it finishes.
**Reason:** Requested directly — see FEATURES_ADDED.md for the full
description and user-facing behavior.
**Expected improvement:** A ROMs folder that also holds a save-data
backup zip, a screenshot batch, or any other unrelated archive no longer
shows those as if they were games in the "Load game" list — only `.zip`
files that actually contain a `.gba` appear.
**Side effects:** None for directories or bare `.gba` files — that path
is byte-for-byte the same filter as before, same sort order. `.zip`
files now take an extra (background, non-blocking) content check before
appearing; a folder with many/large irrelevant `.zip` files will show its
real ROMs slightly later than a folder with few. See
KNOWN_LIMITATIONS.md.
**Verification:** No compiler or device in this sandbox, as every pass.
Read-through only: confirmed `stageRomFile()`'s own behavior and its one
caller (`loadRomFromUri()`) are unchanged — it now calls the extracted
`isZipSignature()` but performs the identical byte comparison; confirmed
`openRomBrowserAtRoot()`/`romBrowserUp()` (the only two callers of
`refreshRomBrowserList()`) needed no changes; whole-file brace count
checked before and after this pass's edits (713 open, 713 close both
times) and again after a follow-up fix to a doc-comment ordering slip
made during the edit itself.

---

# CHANGELOG — Twenty-ninth pass

User requested a code audit, then a deeper one, then asked to fix both
findings. Neither is the multiplayer bug this project has been chasing —
both are independent, real issues the audit surfaced along the way.

---

## 1. `mgba_jni.c` — close a pre-existing locking gap around g_link_obj/g_link_xchg_mid/g_link_is_host (FIX 23)

**Category:** Correctness (data race), low practical severity
**Files modified:** `mgba_jni.c`
**What the audit found:** These three globals are read under `g_core_mutex`
everywhere else (`link_sio_write_register()`, called from `nativeRunFrame()`
while it holds the lock) but were written *outside* the lock in both
`nativeLinkStart()` (before it was ever taken) and `nativeLinkStop()`
(after it was released) — the one gap in an otherwise-consistent
"always under g_core_mutex" rule for this file's globals. Present since
FIX 7/8 introduced these globals; not something any of the recent passes
introduced.
**The fix:** Both functions now write all three only while holding
`g_core_mutex`. `GetObjectClass()`/`GetMethodID()` stay outside it (pure
JNIEnv reflection, touch no shared state); only the resulting method ID
and global ref, plus `is_host`, move inside. One small, deliberate
behavior refinement along the way: previously, on `nativeLinkStart()`'s
`!g_core` failure path, `g_link_xchg_mid` could be left holding a
freshly-resolved, valid method ID while `g_link_obj` was NULL (the old
code cleared `g_link_obj` unconditionally at the very top, before the
`g_core` check existed). Now all three are only ever written together, so
there's no window where they're inconsistent with each other.
**Practical risk:** Low. Pointer- and bool-sized writes are naturally
atomic on ARM, so this was never likely to produce an actual torn read —
but it was genuine unsynchronized concurrent access by the letter of the C
standard, worth closing once found rather than leaving on the books.
**Verification:** No device or compiler in this sandbox, as every pass.
File-wide brace/paren balance checked before and after (comment- and
string-aware, same script every C-file pass has used).

## 2. `MainActivity.kt` — extend the quicksave-race guard to the slot-picker dialog (FIX, audit pass)

**Category:** Correctness (race condition), same class as a bug already
fixed once in this file
**Files modified:** `MainActivity.kt`
**What the audit found:** An earlier pass added `quickStateBusy` (an
`AtomicBoolean` guard) specifically because `quickSaveState()`/
`quickLoadState()` used to spawn unsynchronized background Threads with no
ordering between overlapping calls — a fast double-tap could load stale
data or land saves out of order. `showSaveStateSlotDialog()`'s own
save/load action had the exact same unguarded pattern and was never given
the same guard. Narrower to actually hit (the dialog dismisses itself
after one tap, so it takes two separate menu visits in quick succession
rather than one fast double-tap on an always-visible button) but
identical underlying race.
**The fix:** Renamed `quickStateBusy` → `saveStateBusy` (its scope is no
longer just the "quick" operations) and added the same
`compareAndSet(false, true)` guard, with a `try/finally` that always
clears it, to the slot dialog's save/load `Thread`. One shared flag
across all three call sites (quick save, quick load, slot save/load) was
chosen over a second, separate flag so a quick-save can't race a
slot-load either — the two would need to know about each other to close
that gap otherwise, which is more state for no real benefit.
**Verification:** No device or compiler in this sandbox. Checked the
edited region's brace/try/finally nesting by hand, plus a whole-file
naive brace count (697 open, 697 close) as a smoke test — not fully
reliable for Kotlin string templates in general, but a meaningful signal
given the edit itself didn't touch any string literals.

---

# CHANGELOG — Twenty-seventh pass

User tested against Dragon Ball Z: Supersonic Warriors with a fresh matched
capture, and confirmed directly that the communication error appears
during the quiet stretch after the initial handshake burst — well before
this file's own ~11.5s retry gives up.

---

## 1. `mgba_jni.c` — log raw SIO mode changes independent of the active per-mode driver (FIX 22)

**Category:** Diagnostic, not a fix
**Files modified:** `mgba_jni.c`
**What the new capture shows:** Same shape as the Twenty-sixth pass's own
capture — a burst of real handshake data, then both sides write
`SIOCNT=0x2003` (Start cleared) within 65ms of each other and go silent
until a restart ~11.5s later. FIX 21 didn't change this shape, which rules
out pacing as the cause. New this pass, confirmed by the user: the
communication error is already showing on screen during that quiet
stretch, well before this file's own retry timeout — something is failing
faster and on different grounds than anything this driver currently tracks.
**The theory:** Checked GBATEK's actual documented Multi-Player procedure
(gbatek-sio-multi-player-mode). It documents that a child can signal
"not ready" by temporarily leaving Multi-Player mode entirely — not via any
bit this driver inspects. `link_sio_write_register()` is only ever
registered for `SIO_MULTI` (FIX 7), matching how every real per-mode SIO
driver in mGBA's own source is scoped to one mode — so a ROM taking that
exact documented exit would go completely unlogged by this file until it
switches back, and every "restart" logged since the Sixteenth pass might
be exactly that, not a failed-and-retried negotiation. This driver also
never relays *mode*, only actual Multi-Player transfers, so even where the
theory is right, the other device has no way to see its partner's signal.
**What this pass does:** Not the fix — the safe way to check the theory.
Rather than adding `init`/`load`/`unload` driver callbacks (a real option,
deliberately not taken — their exact signature isn't something this
sandbox can verify, and FIX 7's own comment already records getting bitten
by exactly this category of mistake once, on `GBASIOSetDriver()`'s own
argument count), `nativeRunFrame()` now reads `sio.rcnt`/`sio.siocnt`
straight off the core directly and logs on any change — bypassing the
per-mode driver question entirely, since these are plain fields on a
struct this file already dereferences successfully elsewhere.
**Expected outcome:** If the next matched capture shows an "SIO mode" log
line moving away from Multi-Player's own selection during the quiet
stretch, that confirms the theory and justifies the driver-callback
approach next. If `rcnt`/`siocnt` sit still through the whole stretch, the
theory is wrong and this was a cheap way to rule it out.
**Verification:** No device or compiler in this sandbox, as always. Unlike
FIX 20/21's pacing math, this isn't pure arithmetic that can be tested
standalone — it's a struct field read whose only real verification is
whether it compiles against the pinned mGBA headers, which happens in CI.
File-wide brace/paren balance checked before and after, as every pass.

---

# CHANGELOG — Twenty-sixth pass

User tested FIX 20 on a real device and sent back a fresh matched capture,
then separately reported trying Dragon Ball Z: Supersonic Warriors and
getting an instant "communication error" plus noticeable in-game lag.

---

## 1. `mgba_jni.c` — bound FIX 20's pacing to a short per-attempt window (FIX 21)

**Category:** Refinement of an experimental diagnostic, still not a
confirmed fix
**Files modified:** `mgba_jni.c`
**What the new capture shows:** Real movement for the first time in this
project's history — the child's own SIOMLT_SEND is no longer stuck at only
`0x0000`/`0xFEFE`; it's now writing genuinely varying values, and the
~200ms restart loop documented since the Sixteenth pass is gone, replaced
by full attempts ~15-17s apart. Each attempt still ends in a new stall
(both sides write SIOCNT with Start cleared and sit for several seconds)
before restarting — a different, previously-invisible bottleneck.
**What the user separately reported:** Dragon Ball Z: Supersonic Warriors —
a real-time fighting game, far less tolerant than a slow retry-based
handshake — fails instantly with "communication error" and lags visibly.
No capture from that specific attempt, but consistent with FIX 20's own
documented cost: an unconditional ~16.74ms added to every host-triggered
exchange for the whole session, with no way to turn itself off.
**The fix:** Not a fix — a refinement of FIX 20's experiment. Pacing is now
bounded to a 3-second `LINK_PACE_WINDOW_NS` grace window, armed once at
session start and re-armed on every local RCNT write (i.e. every
negotiation restart, per every capture on file). Outside an armed window —
an established connection, exactly where a real-time game would be during
actual play — `link_pace_exchange()` is a single boolean check, identical
in cost to FIX 20 being off. See `mgba_jni.c`'s FIX 21 comment for the full
reasoning and exactly which capture the 3s figure comes from.
**Reason:** The aliasing/timing theory looks confirmed by the first result
(nothing else in 20 fixes had ever moved the child past two placeholder
values) but applying it as a flat, whole-session cost is too blunt — it
risks trading one game's stuck handshake for another game's broken
real-time play. Bounding it to short per-attempt windows keeps the
demonstrated benefit without the standing tax.
**Verification:** No device in this sandbox, as always. The windowed
pacing logic (arm/expire/re-arm, and that only the exchanges genuinely
inside the window ever sleep) was extracted verbatim and compiled
standalone against a controllable fake clock — 5 scenarios (unarmed,
armed-matches-FIX-20, expiry stops sleeping and clears the flag, a
400-call burst spanning the boundary only paces the ~179 calls actually
inside it, re-arming after expiry starts a fresh window) all passed under
`gcc -Wall -Wextra -std=gnu11` with zero warnings. File-wide brace/paren
balance checked before and after.
**Not answered by this pass:** Whether 3s is the right window, whether the
new SIOCNT=0x2003 stall is the next real bottleneck, and whether Dragon
Ball Z: Supersonic Warriors' failure was really pacing latency or
something else about that ROM — all need a real device and, ideally, a
capture from that specific game.

---

# CHANGELOG — Twenty-fifth pass

User-reported, with a fresh matched host+child capture (`log.text`/
`logt.text`, 07-17) attached: multiplayer still doesn't work, and — new
information, not previously on file — confirmed the same ROM's multiplayer
works outside this app, ruling out "this specific ROM's own link code is
unusual" as an explanation for the first time in this project's history.

---

## 1. `mgba_jni.c` — experimental exchange pacing (FIX 20)

**Category:** Diagnostic experiment, not a confirmed fix
**Files modified:** `mgba_jni.c`
**What the new capture shows:** Identical to FIX 18/19's evidence, unchanged
across ten passes and five unrelated feature passes in between: the child's
own SIOMLT_SEND is still only ever `0x0000`/`0xFEFE`, and its own RCNT/SIOCNT
setup sequence still restarts roughly every 200ms (194-209ms apart across
five resets in this capture), while the host's own outgoing data still
arrives at the child correctly and varying, exactly as it always has.
**What's new:** With the ROM ruled out by the user directly, the bug has to
be in this app's own link implementation. That re-focuses attention on the
theory named since the Seventeenth pass but never acted on: this driver
resolves every transfer as one instantaneous blocking network round-trip,
with nothing pacing completion against real per-transfer cycle cost
(`GBASIOCyclesPerTransfer`, cited since FIX 10) — and `nativeLinkChildExchange()`
runs on a background thread with no correlation to when the child's own CPU
actually gets to execute, so at the observed exchange rate (hundreds/second)
roughly a dozen updates can land, each overwriting the last, for every
single frame's worth of CPU time the child ROM gets to run in.
**The fix:** Not a fix — a bounded, reversible experiment. `link_pace_exchange()`
makes a host-triggered exchange wait until at least one emulated GBA frame
(~16.74ms) has passed since the previous one before starting the network
round-trip, so the child's CPU gets a real chance to observe each exchange
before the next one lands. Toggleable via `LINK_PACE_EXCHANGES` (on by
default); set to 0 for this file's exact prior behavior. See `mgba_jni.c`'s
own FIX 20 comment for the full reasoning, including why a fully correct
fix (real `mTiming` scheduler integration) is not attempted here.
**Reason:** Every prior pass that named the timing-architecture theory
declined to test it, for lack of a way to check it without a device. This
gives the user a cheap, single-toggle way to test it on a real device
without this project taking on a full scheduler-integration rewrite blind.
**Expected outcome:** One of two informative results, either of which moves
this forward. If the ~200ms reset and the 0x0000/0xFEFE ceiling persist
unchanged with pacing on, the aliasing theory is very likely wrong (or not
the whole story), and the next pass should look elsewhere. If either
changes, that's real evidence to justify real scheduler integration next.
**Side effects:** Adds up to ~16.7ms of latency per host-triggered exchange
when the network reply would otherwise have arrived faster than that — on
top of the network round-trip's own latency, not instead of it. No effect
on the child role's own code path. No effect on data correctness — every
byte exchanged is identical to before, only the timing of when the next
exchange is allowed to start changes.
**Verification:** No Android/NDK toolchain or device in this sandbox, as
every pass. The pacing/interval math (GBA frame length → nanoseconds,
sleep-remaining-time logic, reset-on-reconnect) was extracted verbatim and
compiled standalone against a controllable fake clock (not real
`clock_gettime`/`nanosleep`, which need a real device to observe) — five
scenarios (first exchange, back-to-back, late-arriving, half-elapsed,
ten-in-a-row) all passed under `gcc -Wall -Wextra -std=gnu11` with zero
warnings. File-wide brace/paren balance checked comment- and string-aware
before and after. This confirms the arithmetic and control flow are correct
in isolation — it does not confirm the fix changes the reported symptom,
which (as with every pass in this project) needs a real device to know.

---

# CHANGELOG — Twenty-fourth pass

User-reported: the menu-based Save State/Load State flow (as opposed to
the Quick Save/Quick Load buttons fixed last pass) feels slow in two
places — the slot-picker dialog taking a moment to appear, and picking a
slot taking a moment to confirm.

---

## 1. `MainActivity.kt` — slot thumbnails cached in memory

**Category:** Performance
**Files modified:** `MainActivity.kt`
**What was wrong:** `showSaveStateSlotDialog()` re-read and re-decoded
every slot's PNG thumbnail from disk on *every single open*, even when
nothing about that slot had changed since the last time the dialog was
shown. On repeat opens — exactly what fast save/load testing does — this
was pure wasted disk I/O and PNG decode work.
**The fix:** Added `slotInfoCache`, an in-memory `ConcurrentHashMap` keyed
by ROM name + slot number, holding each slot's already-decoded `SlotInfo`.
A slot is only re-read/re-decoded when its `exists`/`lastModified()` no
longer match what's cached — i.e. only when it's actually stale, which in
practice means right after a save to that slot. Keyed by ROM name as well
as slot number since slot *numbers* repeat across ROMs but point at
different underlying files.
**Confidence:** High — this only removes redundant, correctness-neutral
work; the freshness check still falls back to a full re-decode any time
the underlying file has actually changed.

---

## 2. `MainActivity.kt`/`SaveEntry` — backup-before-save now a rename, not a copy

**Category:** Performance
**Files modified:** `MainActivity.kt`
**What was wrong:** `backupIfExists()` (called right before every save,
by both Quick Save and the menu's Save State) read an existing slot's
full bytes and wrote them out again to the `.bak` sibling — immediately
before `nativeSaveState()` was about to overwrite that same original file
anyway. That's up to 2x a save-state's worth of disk I/O for every single
save, all of it before the confirmation toast could fire.
**The fix:** Added `SaveEntry.moveInto()`. When no Storage folder is
configured (the common case), the backup is now a single
`File.renameTo()` — an instant, metadata-only move on the same volume —
instead of a byte-for-byte copy. Falls back to the old copy behavior if
the rename fails, or whenever a Storage folder IS configured (no
equivalent plain rename via `DocumentFile`).
**Confidence:** High for the internal-storage path (the default); the
Storage-folder path is unchanged from before, so no regression risk
there.

---

# CHANGELOG — Twenty-third pass

User-reported (from fast save/load testing): Quick Save/Quick Load
sometimes "saved on a different frame" than expected, and sometimes
appeared not to save at all when tapped quickly.

---

## 1. `MainActivity.kt` — quickSaveState()/quickLoadState() race fixed

**Category:** Bug fix (data race)
**Files modified:** `MainActivity.kt`
**What was wrong:** Every tap of Quick Save or Quick Load spawned a brand
new, totally unsynchronized `Thread`. `g_core_mutex` on the native side
only serializes the moment of the actual file write/read against the
running game thread — it says nothing about which Kotlin thread reaches
that point first. A fast double-tap of Quick Save, or Quick Save followed
immediately by Quick Load, raced: whichever thread happened to win the
mutex first went first, regardless of tap order. A Load that won the race
before a pending Save had written could read the file from before that
save (looks like "loaded the old/first save"); two Saves landing in
either order looks like "saved a different frame" than the one actually
displayed at the moment of the tap.
**The fix:** Added a shared `AtomicBoolean` busy-guard around both
functions. A tap that arrives while a prior quicksave/quickload is still
in flight is now a no-op with its own toast, instead of spawning a second
racing thread. Confirmed: `nativeSaveState()` already opens with
`O_TRUNC` (see `mgba_jni.c`), so an existing slot is always fully
replaced, never appended to or left partially overwritten — the
"different frame" symptom was the race above, not a failure to replace
the slot.
**Confidence:** The race is definite from the code (no lock, no debounce,
two independent Threads touching the same file/native calls). Not
re-confirmed on a real device this pass — no Android toolchain here.

---

# CHANGELOG — Twenty-second pass

Two user-reported issues, both in `MainActivity.kt`: a stray "Load ROM"
button rendering on top of the ROM browser it was supposed to sit behind,
and Save State feeling slow — the confirmation toast wasn't showing up
until well after the state had actually finished saving.

---

## 1. `MainActivity.kt` — floating "Load ROM" button removed

**Category:** Bug fix (visual — matches a screenshot showing the button
floating over the ROM browser's file list)
**Files modified:** `MainActivity.kt`
**What was wrong:** The purple "▶ Load ROM" `Button` sat behind
`romBrowserOverlay`/`settingsMenuOverlay` in add order (added to `root`
first), but a stock Material `Button` carries a small default elevation
even with nothing explicitly setting one. Android draws children with
non-zero elevation above children with zero elevation regardless of add
order once any Z-order is involved, so the button rendered ON TOP of the
overlays that were supposed to cover it — visible as a stray purple pill
hovering over the ROM browser's file list, exactly as reported.
**The fix:** Removed the button outright rather than patching its
elevation. `changeRom()` already auto-opens the ROM browser on first
launch and on Close (`closeGame()`), which covers the button's main
purpose already. Its other purpose — a way back into ROM selection when
the folder picker gets cancelled before any folder's chosen, or a ROM
load fails — is now handled by `onGameTouch()`: tapping the idle
(no-ROM-loaded) surface calls `changeRom()` directly. No button, no
elevation, no Z-order conflict possible.
**Confidence:** The elevation-over-opaque-sibling explanation matches
Android's own documented Z-order behavior and matches the reported
screenshot exactly (button visible mid-screen, over the file list, below
where "Use system file picker instead" sits). Not re-confirmed on a real
device this pass — no Android toolchain here — but removing the view
entirely can't reproduce a Z-order bug that only existed because the view
was there.

---

## 2. `MainActivity.kt` — Save State confirmation no longer waits on the thumbnail

**Category:** Bug fix (perceived performance — reported as "doesn't save
instantly")
**Files modified:** `MainActivity.kt`
**What was wrong:** In `showSaveStateSlotDialog()`'s save path, the
"Saved to Slot N" toast fired AFTER `captureStateThumbnail(slot)`
completed, not right after the actual state write. That thumbnail capture
waits on `PixelCopy.request()` (up to a 500ms `CountDownLatch.await()`),
then scales and PNG-encodes a full-screen bitmap — all of it fully
blocking, even though the save itself was already done and safely on disk
before any of it started. Every Save State via the slot dialog felt
delayed by however long that took. (The one-tap 💾 quicksave button —
`quickSaveState()` — never had this problem; it doesn't capture a
thumbnail at all.)
**The fix:** Reordered so the confirmation toast fires immediately after
`nativeSaveState()`/`nativeLoadState()` returns, and
`captureStateThumbnail()` runs afterward, still on the same background
thread but no longer gating the confirmation. The slot list just won't
show a brand-new thumbnail until it's next opened; the save itself is no
longer perceived as slow.
**Confidence:** The 500ms figure is read directly from
`captureStateThumbnail()`'s own `latch.await(500, TimeUnit.MILLISECONDS)`
call, so the worst case this fix removes from the confirmation's critical
path is exact, not estimated. Not verified against a real device's actual
felt latency this pass — no Android toolchain here — but the reorder
itself can't change save correctness, only when the toast fires relative
to work that was already happening.

---

# CHANGELOG — Twenty-first pass

Bug fix, real-device-reported: the Twentieth pass's Storage folder feature
broke save/load once someone actually tested it on a phone — reported as
"doesn't save and load" after turning that feature on. Root cause and fix
below; no new feature this pass.

---

## 1. `MainActivity.kt` — SAF native-fopen bridge replaced

**Category:** Bug fix (confirmed on real device this pass; Twentieth pass's
version of this was flagged in KNOWN_LIMITATIONS.md as unconfirmed)
**Files modified:** `MainActivity.kt`
**What was wrong:** `SaveEntry.nativePath()` bridged a SAF document to
native code via `/proc/self/fd/<N>` — reopening a `ParcelFileDescriptor`'s
fd as a plain path and handing that straight to `VFileOpen()`, including
for the battery save, which the core mmaps for the entire ROM session.
Nothing guarantees a re-opened SAF fd supports mmap/seek/`O_TRUNC` the way
native code needs — that's provider-specific — and a real-device test this
pass showed it doesn't hold up: saves and states appeared to go somewhere,
but loading them back either failed or didn't reflect what was saved.
**The fix:** Native code no longer touches a SAF document directly. It
always `fopen()`s a plain file under this app's own internal storage —
exactly as before the Storage-folder feature existed — and Kotlin copies
bytes to/from the chosen folder's document on either side of that call,
using `ContentResolver`'s stream APIs (`openInputStream`/`openOutputStream`),
which every `DocumentsProvider` is required to support. See
`SaveEntry.stageForRead()` / `stageForWrite()` / `commitWrite()` for the
one-shot save-state/quicksave/thumbnail case, and `batteryMirrorPath()` /
`syncBatteryMirror()` for the session-long battery save (synced out at
`onPause()`, before swapping to a different ROM, on `closeGame()`, and as a
last-resort in `onDestroy()`).
**Confidence:** Removes a specific, real failure mode confirmed this pass.
Still not run against every possible DocumentsProvider (cloud-storage-backed
folders in particular) — see KNOWN_LIMITATIONS.md — but no longer depends on
provider-specific mmap/seek/truncate behavior at all, only on the stream
APIs every provider must implement.

---

# CHANGELOG — Twentieth pass

New feature, unrelated to the link/multiplayer work above — user-chosen
Storage folder for saves/states/screenshots, so they can live somewhere
visible in a file manager instead of only under this app's own internal
storage (`Android/data/...`).

---

## 1. `MainActivity.kt` — Storage folder (Settings → Storage)

**Category:** Feature
**Files modified:** `MainActivity.kt`
**What it does:** A new Settings row lets the user pick a folder (system
folder-picker/SAF — same mechanism the ROM browser already uses, see
`romTreePicker`, just with write access too). Once set, three subfolders
appear inside it — `save`, `cheat`, `screenshot` — and every battery save,
save-state, state thumbnail, quicksave, and screenshot goes there instead
of internal storage from that point on. `cheat` is provisioned but unused
— there's no cheat feature yet to write into it (see the "Cheats" menu
entry, still "not implemented yet").
**Why SAF, not a plain hardcoded path:** the obvious alternative
(`MANAGE_EXTERNAL_STORAGE`, giving raw `java.io.File` access anywhere)
was already deliberately rejected for the ROM browser for reasons that
apply just as much here — see that feature's own comment. The wrinkle
specific to this feature: `nativeSaveState()`/`nativeLoadState()`/
`nativeLoadROM()`'s save path all need a real fopen()-able path string,
which a SAF document's `content://` URI isn't. Bridged via
`/proc/self/fd/<N>` — open a `ParcelFileDescriptor` for the SAF document,
hand native code that path instead, close the descriptor once native code
has opened its own independent handle. No native code changed at all.
**No migration:** switching folders does not move whatever already exists
under internal storage — only new saves/states/screenshots go to the new
location. Stated plainly in the Settings screen itself before anyone taps
"Choose folder" — see KNOWN_LIMITATIONS.md for why automatic migration
isn't attempted.
**Verification:** No Android toolchain in this sandbox (unchanged
constraint every pass). Brace/paren counts checked directly. The
`/proc/self/fd/` bridge itself is a well-known, long-used technique for
this exact SAF/native-fopen mismatch, but not confirmed against a real
device/provider here — see KNOWN_LIMITATIONS.md.

---

# CHANGELOG — Nineteenth pass

Negative result, not a fix — re-tested Eighteenth pass's SIOCNT-mirroring
change against a real matched capture. No observed change: the child's own
`childData` is still only ever `0x0000`/`0xFEFE`, same as every capture
back to the Sixth pass. Not reverted — it's still correct on its own terms,
just not the fix for this ROM.

Also added: `copyLinkDebugLog()` now appends a `=== copied at
MM-DD HH:MM:SS.mmm ===` line to the exported text, so two phones' captures
can be time-aligned by eye. Prompted by this pass's two logs covering
different real-world spans — turned out to be expected (host logs ~3
lines per SIO exchange, child ~1, so the same 40,000-character cap holds
less real time on the host side), not a bug, but there was no quick way to
confirm that from the logs alone before now.

---

# CHANGELOG — Eighteenth pass

Scope note: `mgba_jni.c` only. First pass with a real matched capture — two
link logs, one per phone, from the same connection attempt (timestamps
overlapping to the second) instead of minutes apart, made possible by
Seventeenth pass's logcat-independent logging.

---

## 1. `mgba_jni.c` — child's own SIOCNT never reflected transfer completion

**Category:** Bug fix
**Files modified:** `mgba_jni.c`
**Problem:** Cross-referencing the new matched capture confirmed the
network layer is not the issue — the host's live, changing outgoing data
correctly reaches the child (visible as `hostData` in its exchange log),
and the child's own data correctly reaches the host (`recv`), both
directions, from a real simultaneous pair for the first time. That leaves
the child ROM's own code as the only place still unaccounted for. Reading
`nativeLinkChildExchange()` end to end turned up a gap it already
self-documented: it writes the SIOMULTI0-3 data registers and raises the
SIO IRQ, but never touched the child device's own SIOCNT. GBATEK documents
Multi-Player SIOCNT bit 7 (Start/Busy) as a hardware-mirrored reflection of
the parent's clock line on every connected unit, not something a child's
CPU sets — polling it to notice "a transfer just landed" is a normal
technique alongside, or instead of, IntrWait on the IRQ this file already
raises. A child ROM using that technique would see a flat, never-changing
value here, regardless of the IRQ or data registers already being correct.
**Solution:** `nativeLinkChildExchange()` now reads the child's current
SIOCNT, refreshes bits 2 (child), 3 (ready), 4-5 (player ID), and clears
bit 7 (busy) after every exchange, preserving every other bit (mode, baud
rate, IRQ-enable) exactly as the ROM last set it.
**Reason:** Closes a gap the code already admitted to itself in a comment,
cross-referenced against GBATEK — not a new guess about either test ROM's
internals.
**Expected improvement:** If either test ROM polls SIOCNT bit 7 to detect
new data (a common pattern alongside or instead of the IRQ), it should now
see it, instead of a flat value indistinguishable from "no cable."
**Side effects:** None on the host path — this only touches the child-role
function. Preserves mode/baud/IRQ-enable bits rather than clobbering them.
**Verification:** No Android toolchain in this sandbox (unchanged
constraint every pass). Brace/paren count checked directly (69/69, 645/645
across the whole file). Not confirmed on a real device — see
KNOWN_LIMITATIONS.md.

---

# CHANGELOG — Seventeenth pass

Scope note: `mgba_jni.c`, `EmulatorEngine.kt`, `MainActivity.kt`,
`LinkMultiplayer.kt`. Prompted by two things in the same message: "still
doesn't work multiplayer" (expected — see KNOWN_LIMITATIONS.md for what
this pass's new evidence actually shows) and "can't get log on this
device, only on other device" — the exact logcat-access split Sixteenth
pass flagged but didn't fix, now confirmed to still be blocking things.

1. **Durable, logcat-independent link debug logging.** `copyLinkDebugLog()`
   used to shell out to `logcat`, which reads back a process's own output
   fine on stock Android but which some OEM builds restrict further — W's
   own two-phone split (real output on one, nothing on the other, same
   build) is direct evidence of that, not of a bug in this app. Every
   `LOGI`/`LOGW`/`LOGE` in `mgba_jni.c` now also writes to a plain private
   file under this app's own `filesDir`, via a new `jni_log_line()` the
   existing `LOGI`/`LOGW`/`LOGE` macros expand to — every call site in the
   file is unchanged, since those are still plain macros. A new
   `nativeSetLinkLogPath()` JNI entry point (called once from
   `MainActivity.onCreate()`) hands the path in. Needs no logcat/READ_LOGS
   access at all, on any device, since it was never reading logcat to
   begin with.
2. **Fresh log per connection attempt, not an ever-growing file.**
   `nativeLinkStart()` re-truncates the log file at the start of every
   session, matching the actual workflow (connect, wait, read the log) —
   a capture reflects one attempt, not whatever a previous one left
   behind. An 8MB backstop cap in the new `link_log_write()` resets to
   empty if a single session ever runs long enough to hit it, which normal
   use shouldn't.
3. **Kotlin-side connection-lifecycle logging (Fifteenth pass's 7 log
   lines in `LinkMultiplayer.kt`) now mirrors into the same file** via a
   new `linkLog()` helper, instead of only going to `Log.i`/`Log.w`. One
   "Copy link log" read now captures the same combined picture the old
   3-tag logcat filter (`mGBA-JNI:* mGBA-Link:* mGBA:*`) used to, without
   depending on logcat access to get it.
4. **No protocol or timing behavior changed.** All four items above are
   logging/infrastructure only. See KNOWN_LIMITATIONS.md for this pass's
   actual investigation (a deeper read of the new host+child evidence, and
   an updated but still-unconfirmed theory) and BUGS_FIXED.md for why this
   isn't labeled a bug fix.

---

# CHANGELOG — Sixteenth pass

Scope note: `mgba_jni.c`, `MainActivity.kt` only. Prompted by the first
genuinely useful evidence this project has had: FIX 13 (Fifteenth pass)
worked, and W sent back four logs — a screenshot of an empty capture on one
phone, and three real logcat files (`wifi_host.text`, `wifi_join.text`,
`bluetoth__1_.text`) with actual multiplayer-attempt content instead of
boot noise.

Reading those three files is what this pass actually is. No new hypothesis
was chased from a cold read this time — everything below follows directly
from what the logs show, and from tracing the two remaining places this
codebase had *no* logging at all (the exchange result on the host side, and
the entire child-side receive path) once it became clear those were the
specific gaps stopping the new evidence from being conclusive.

**Still nothing here fixes the reported bug.** See KNOWN_LIMITATIONS.md.
What this pass adds is the other half of the trace FIX 11/13 started, so
the *next* capture — taken with both phones logging the same session,
which this one wasn't — has a real chance of showing the actual mechanism
rather than another layer of "here's activity, still can't tell what it
means."

---

## 1. Logged the SIO exchange result on the host side, not just the trigger

**Category:** Diagnostic capture
**Files modified:** `app/src/main/cpp/mgba_jni.c`
**Problem:** `link_sio_write_register()` (FIX 11/13) traced every write that
*triggers* an exchange, but never what `link_exchange()` actually returned.
`wifi_host.text` this pass showed 1124 Start-bit writes in 1.67 seconds —
mathematically far too fast to be hitting `WIFI_XCHG_MS=30` on each one
(that alone would take over 30 seconds) — strongly implying most were
completing fast with real replies, not timing out, but nothing in the log
said so directly, and the reply *content* was invisible either way.
**Solution:** Added `LOGI("SIO exchange result: sent=... recv=... timedOut=...")`
right after `link_exchange()` returns, inside the same host-only branch.
**Reason:** Directly motivated by not being able to answer "is the network
side actually working" from `wifi_host.text` alone, despite the timing
strongly suggesting yes.
**Expected improvement:** The next host-side capture will say, per
transfer, exactly what came back and whether it was a timeout.
**Side effects:** Roughly doubles this function's log volume during active
exchanges — expected and accounted for in item 3 below.
**Verification:** Not runnable here. Read-through only; placed inside the
already-host-gated branch, so no new conditions to get wrong.

---

## 2. Added logging to the entire child-side receive path (previously zero)

**Category:** Diagnostic capture
**Files modified:** `app/src/main/cpp/mgba_jni.c`
**Problem:** `nativeLinkChildExchange()` — the only thing that ever updates
a child device's own SIOMULTI0/1 registers — had no logging in either its
early-exit or success path. Every log gathered across sixteen passes,
including this pass's three, is entirely blind to whether this function is
even being called, let alone what it exchanges. `wifi_join.text` and
`bluetoth__1_.text` both show the child ROM repeatedly restarting its own
SIOCNT/RCNT setup roughly every 200ms — consistent with a ROM that keeps
giving up on its own negotiation — but whether that's because this function
never runs, runs but with bad data, or runs fine and the ROM just doesn't
react, was and is unanswerable without this.
**Solution:** Added `LOGW` on the early-exit branch (active/host-role/core
pointer check) and `LOGI` on every successful call, logging both
`hostData` and `childData`.
**Reason:** Same motivation as item 1 — this was the single largest blind
spot left after item 1, and the one most directly relevant to the
"still doesn't work on rom" reports for a device acting as the child.
**Expected improvement:** The next child-side capture will show whether
this function runs at all during a real attempt, how often, and with what
data — directly testable against the host's own `wifi_host.text`-style
trace if both phones capture the same session.
**Side effects:** Adds log volume proportional to how often the child
actually receives host data — unknown until measured, since this pass's
child-role logs show no evidence either way.
**Verification:** Not runnable here. Read-through only.

---

## 3. Bumped the debug-log capture window again, 8000 → 20000 lines

**Category:** Bug fix (diagnostic capture)
**Files modified:** `MainActivity.kt`
**Problem:** Fifteenth pass's 8000-line bump was sized against *boot*
noise, before this pass's evidence showed real exchange activity running
at ~670/second on the host — 2243 lines in 1.67s from the write trace
alone, before items 1-2 above add more on top.
**Solution:** `-t 8000` → `-t 20000`. Comment above `copyLinkDebugLog()`
updated with the real numbers behind the bump this time, instead of a
guess.
**Reason:** Directly sized against this pass's own measured log rate, with
headroom for items 1-2's added volume.
**Expected improvement:** A capture spanning several seconds of real
exchange activity, from either role, shouldn't scroll its own start out
from under itself before W gets to read it.
**Side effects:** Larger worst-case clipboard/dialog payload — same
reasoning as the Fifteenth-pass bump, still well within what a
`ScrollView`/`TextView` and the clipboard handle fine.
**Verification:** Not runnable here. Read-through only.

---

## Not changed this pass

- The actual mechanism behind the child ROM's repeated resets, or whether
  it's the same mechanism on Wi-Fi and Bluetooth — items 1-2 are what
  would show this, not a fix for it yet.
- The empty-log-on-one-phone issue W also reported/screenshotted this
  pass. Very likely a normal Android self-logcat restriction that varies
  by device/OS version (not something this codebase controls), for which
  Shizuku — already working on W's other phone — is the practical
  workaround. Not attempted as a code fix this pass; see
  KNOWN_LIMITATIONS.md for why and what a real fix would involve.
- Everything else FIX 9-15 already covers.



Scope note: `mgba_jni.c`, `LinkMultiplayer.kt`, `MainActivity.kt`. Prompted
by a retest reporting all three still-open symptoms at once: ROM detection
still failing on both transports, Wi-Fi disconnect not reaching the other
phone, and lag on Bluetooth. Two logcat dumps (one per transport) were
attached as evidence for the ROM-detection question specifically.

Reading those two dumps first, before touching any source, is what this
pass actually turned on: neither contained a single line from anywhere near
an actual link attempt — both covered barely 200ms of real time, entirely
boot-time noise. That's items 1-2 below. Item 3 is a design gap every prior
FIX 9-12 comment already described the intent for but never actually
enforced, found by re-reading `mgba_jni.c` end to end rather than from the
logs (which had no signal to read). Item 4 is the clipboard tool itself,
updated to match.

**None of this is confirmed to fix the reported symptoms** — see
KNOWN_LIMITATIONS.md's Fifteenth-pass entry for exactly what would. Items
1-2 are a confirmed, demonstrated bug (the evidence is the two attached
files) whose fix is straightforward; item 3 is a hardening whose actual
impact is unknown. What every item together should reliably produce,
even if the underlying multiplayer bug turns out to be something else
entirely, is a next debug-log capture that finally contains something to
read.

---

## 1. Filtered mGBA's own core logging out of `jni_log()`

**Category:** Bug fix (diagnostic capture) / possible general performance
**Files modified:** `app/src/main/cpp/mgba_jni.c`
**Problem:** `jni_log()` — the callback that forwards mGBA's internal
logger to Android's logcat — forwarded every core log line, at every
level, to `LOGI` under the `mGBA-JNI` tag, with `(void)level` explicitly
discarding the one piece of information that would have let it filter
anything. Confirmed directly from both logcat files attached this pass:
every line in both was genuinely `mGBA-JNI` (the tag filter was never the
issue), but both covered barely 166-241ms of real time — pure boot-time
`"Starting DMA ..."` / `"Read from write-only I/O register: ..."` spam,
nothing from anywhere near an actual multiplayer attempt. Confirmed
against mgba-emu/mgba's real source this pass (not inferred): the latter
message is logged at `mLOG_STUB`, the same level FIX 12 already
identified for the (now-removed) `rawWrite16` no-op warnings. This chatter
is completely unrelated to link/multiplayer — any DMA-heavy ROM produces
dozens of these lines every single frame — so it was never specific to
this investigation, it just happened to be what finally made the capture
tool's output visibly useless enough to trace.
**Solution:** `jni_log()` now drops `mLOG_DEBUG`/`mLOG_STUB`/
`mLOG_GAME_ERROR` before they reach `LOGI`, matching mGBA's own
`src/platform/libretro/libretro.c` under `NDEBUG` (this project's own
`CMakeLists.txt` also builds with `NDEBUG`). `FATAL`/`ERROR`/`WARN`/`INFO`
are unaffected. Belt-and-suspenders on top of the level check: also drops
the two specific message prefixes actually observed flooding both attached
logs, regardless of level, in case either isn't DEBUG/STUB after all.
**Reason:** Directly demonstrated by the two files W attached — see
mgba_jni.c's own FIX 13 comment for the full trail.
**Expected improvement:** The next `Copy link log` capture should cover
much more real time and actually contain FIX 11's SIO trace lines and
LinkMultiplayer.kt's own connection-lifecycle logging, instead of nothing.
Secondary, unconfirmed: `__android_log_print` is a real syscall: cutting
dozens of avoidable calls per frame, on every ROM, may also just be a
general performance improvement — not only for the Bluetooth lag this pass
was asked about.
**Side effects:** None expected — pure log suppression, no behavior
change. If DEBUG/STUB-level core tracing is ever needed again for
unrelated debugging, this is the one place to temporarily loosen.
**Verification:** No compiler in this sandbox, as every pass. The two
attached logs are direct evidence the *problem* is real; the fix itself
(which specific mLogLevel constants exist, and that STUB is used for
exactly this "wrong-direction register access" case) is checked against
mgba-emu/mgba's real source this pass, not assumed.

---

## 2. Bumped the debug-log capture window, updated its guidance

**Category:** Bug fix (diagnostic capture)
**Files modified:** `MainActivity.kt`
**Problem:** `copyLinkDebugLog()`'s `logcat -t 2000` limit, combined with
Item 1's since-fixed noise, meant the window covered a fraction of a
second in practice.
**Solution:** Bumped `2000` to `8000`. Purely a safety margin on top of
Item 1's real fix, not a substitute for it — the comment above the
function, and the empty-state dialog message, were both updated to say so
and to explicitly mention re-testing the disconnect scenario (tap
Disconnect, wait a few seconds, then read the log), since that's now also
something this capture is meant to help diagnose.
**Reason:** Cheap extra headroom now that each line is worth far more
signal than before.
**Expected improvement:** A long test session (multiple connect/play/
disconnect cycles) is less likely to scroll early evidence back out.
**Side effects:** Slightly larger clipboard payload and dialog text in the
worst case; a plain monospace `TextView` inside a `ScrollView` handles a
few thousand lines fine.
**Verification:** Not runnable here (no device). Read-through only.

---

## 3. Host-gated the native SIO exchange trigger

**Category:** Hardening (protocol correctness) — impact unconfirmed
**Files modified:** `app/src/main/cpp/mgba_jni.c`
**Problem:** `link_sio_write_register()`'s exchange branch fired on *any*
SIOCNT write with the Start bit set, regardless of which role's own ROM
made that write. FIX 9's original comment already claimed this branch
"correctly never fires" on a child device, on the theory that a child ROM
never performs that write (GBATEK: Start/Busy is read-only for slaves) —
but nothing in the code actually enforced that; it was resting entirely on
that assumption holding for both test ROMs.
**Solution:** Added `&& g_link_is_host` to the branch condition; simplified
the two `g_link_is_host ? … : …` blocks inside it that the guard now makes
unreachable in the child case. The FIX 11 diagnostic warning is now also
host-gated, deliberately not logging the (now-expected) child case at all,
to avoid reintroducing Item 1's problem if a ROM's child-role code hits
this on every poll iteration.
**Reason:** Re-reading `mgba_jni.c` end to end for anything FIX 9-12 might
have missed, since the attached logs had no signal to point at anything
more specific. If either test ROM's link code shares one code path between
parent/child roles (plausible — Nintendo's SDK is commonly used that way)
and doesn't itself distinguish, this would have let a child device trigger
a second, spurious exchange of its own alongside the correct
network-triggered one — sending an unsolicited packet the host's *next*
real exchange could then consume as that round's reply. Fits the reported
symptom set well: identical ROM-detection failure on both transports (this
file is shared, unlike the already-hardened transport-specific Kotlin) and
worse lag specifically on Bluetooth (`BT_XCHG_MS=50` vs `WIFI_XCHG_MS=30` —
a stolen reply costs more there). Also may bear on the Twelfth-pass
KNOWN_LIMITATIONS entry that flagged suspiciously rapid repeated exchanges
in an earlier capture, never followed up.
**Expected improvement:** Unconfirmed — see KNOWN_LIMITATIONS.md. Cheap and
safe either way: host behavior is completely unchanged, since `is_host` was
already true on every path that used to run.
**Side effects:** None expected for the host role. For the child role. only
removes a call this design was never supposed to make in the first place.
**Verification:** Not runnable here. Design-intent gap identified by
reading, not by a build or device test.

---

## 4. Added specific reason logging to every disconnect/peer-lost path

**Category:** Bug fix (diagnostic capture)
**Files modified:** `LinkMultiplayer.kt`
**Problem:** `disconnect()`'s outgoing BYE send had a bare
`catch (_: Exception) {}` — completely silent whether it succeeded, was
skipped (null socket/peer), or threw. Separately, all 8 call sites of
`handlePeerLost()` logged one identical generic line regardless of which
of the 6 listener locations detected it or why (explicit BYE vs. the 8s
liveness timeout). A captured log couldn't have distinguished "peer's BYE
never arrived", "it arrived but something else consumed it first", and
"neither side has sent one yet, still waiting on the watchdog" — three
very different bugs that all look identical from the report "if I
disconnect, it doesn't disconnect on the other phone."
**Solution:** `disconnect()` now logs the BYE send's outcome specifically
(sent + destination, skipped + which of socket/peer was null, or the
exception). `handlePeerLost()` now takes a `reason: String`; every call
site names itself and, where relevant, the specific trigger (BYE received
vs. timeout duration).
**Reason:** Purely additive — no timing or protocol logic changed, only
what gets logged and how specifically.
**Expected improvement:** The next capture of a disconnect test should say
exactly which side sent a BYE, whether it was received, and if not,
whether the other side eventually gave up via the 8s watchdog instead —
enough to actually localize the reported bug instead of re-guessing at it.
**Side effects:** None expected. Slightly more log volume on disconnect
specifically (a handful of lines, not per-frame) — not a concern after
Item 1.
**Verification:** Not runnable here. Read-through only; every call site
cross-checked to confirm none were missed (`grep -n "handlePeerLost("`).

---

## Not changed this pass

- The actual WiFi disconnect-propagation bug, if it's not just Item 3
  above or a timing/testing artifact — nothing else found it by reading.
- The actual Bluetooth ROM-detection failure and lag, beyond Items 1 and 3
  above — same.
- `BT_XCHG_MS`/`WIFI_XCHG_MS` themselves — no evidence yet that the
  timeout values are wrong rather than the timeouts being hit at all.
- Everything else FIX 9-14 already covers.



Scope note: one-line fix, `MainActivity.kt` only, prompted by a real CI
build log the user attached (the Thirteenth pass's zip failed
`compileReleaseKotlin`).

---

## 1. Fixed a real Kotlin compile error

**Category:** Bug fix (compile error)
**Files modified:** `MainActivity.kt`
**Problem:** `showLinkDebugLogDialog(text: String)`'s parameter name
collided with `TextView`'s own `text` property. Inside `TextView(this)
.apply { text = shown }`, the bare `text` on the left of the assignment
resolved to the outer parameter (immutable) rather than the receiver's
property, so the compiler rejected it as reassigning a `val`. Everywhere
else in the file, the same kind of assignment goes through an explicit
variable (`row.text = ...`), which is never ambiguous — this was the one
bare/unqualified case, and it happened to collide.
**Solution:** Renamed the parameter to `logText`; the function body's one
reference to it (`text.ifBlank { ... }`) updated to match, `text = shown`
inside the `apply` block left as-is since it's now unambiguous.
**Reason:** Real `compileReleaseKotlin` failure from an actual CI run —
see the attached build log's `14_Build APK.txt`.
**Expected improvement:** Build succeeds.
**Side effects:** None — pure rename, no behavior change. The one caller
(`copyLinkDebugLog()`) passes its argument positionally, so it's
unaffected by the parameter's internal name.
**Verification:** No compiler available in this sandbox, as always — but
this fix is about as close to "verified" as this project gets without
one: the failure came from a real Gradle/Kotlin compiler run, the
collision was fully diagnosed against the exact reported line/column, and
grepping confirmed no other function in either of the last two passes'
additions has a parameter name that collides with a property name used
bare inside a nested `apply`/similar block.

---

# CHANGELOG — Earlier passes (summary)

Full entries for these passes were trimmed to keep this file a
reasonable length. None of them touch multiplayer/link code except where
noted — see FILE_CHANGES.md's own history if the exact diff for one of
these ever matters again.

- **Thirteenth** — `MainActivity.kt`: save-state slot picker now shows a
  thumbnail per slot.
- **Twelfth** — `MainActivity.kt`: added the in-app "Copy link log"
  diagnostic (logcat-based at the time; superseded by Seventeenth pass's
  file-based version). Diagnostic only, not a link fix.
- **Eleventh** — `MainActivity.kt`: fixed a Tenth-pass regression where
  every row in the restyled quick game menu silently did nothing when
  tapped (`isClickable`/`isFocusable` on the row view was stealing the
  touch from the `ListView`'s own click dispatch).
- **Tenth** — `MainActivity.kt`: quick game menu restyled and expanded to
  match a reference screenshot (10 items instead of 5); two now-redundant
  Settings rows removed; immersive mode now re-applied on focus regain;
  display-cutout black bar fixed; Screenshot/Reset/Close actions added.
- **Fifth** — First pass to focus on `LinkMultiplayer.kt`/multiplayer
  internals specifically (four earlier undocumented passes had already
  covered audio, rendering, ROM-swap safety, and the control layout
  editor). Fixed missing `@Volatile` on six connection-state fields
  (a real cross-thread visibility bug) and an untracked discovery socket
  that made `disconnect()` a no-op for it.
