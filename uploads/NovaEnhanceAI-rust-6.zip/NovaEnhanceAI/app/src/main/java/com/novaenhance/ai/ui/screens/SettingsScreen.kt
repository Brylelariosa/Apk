package com.novaenhance.ai.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.res.painterResource
import com.novaenhance.ai.R
import android.widget.Toast
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.novaenhance.ai.storage.ThemePreference
import com.novaenhance.ai.ui.components.NovaBottomBar
import com.novaenhance.ai.ui.components.NovaButton
import com.novaenhance.ai.ui.components.NovaButtonStyle
import com.novaenhance.ai.ui.viewmodel.NovaViewModelFactory
import com.novaenhance.ai.ui.viewmodel.SettingsViewModel

@Composable
fun SettingsScreen(onBack: () -> Unit, onOpenCrashLog: () -> Unit) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val viewModel: SettingsViewModel = viewModel(factory = NovaViewModelFactory(context))
    val settings by viewModel.settings.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(painterResource(R.drawable.ic_back_arrow), contentDescription = "Back") } }
            )
        },
        // The diagnostics buttons used to be the very last thing on a scrolling page.
        bottomBar = {
            NovaBottomBar {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    NovaButton(
                        text = "Copy debug info",
                        style = NovaButtonStyle.Outlined,
                        onClick = {
                            clipboardManager.setText(AnnotatedString(viewModel.buildDebugReport()))
                            Toast.makeText(context, "Debug info copied", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.weight(1f)
                    )
                    NovaButton(
                        text = "View crash log",
                        style = NovaButtonStyle.Outlined,
                        onClick = onOpenCrashLog,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Appearance", style = MaterialTheme.typography.titleMedium)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ThemePreference.entries.forEach { theme ->
                        val selected = settings.theme == theme
                        NovaButton(
                            text = theme.name.lowercase().replaceFirstChar { it.uppercase() },
                            style = if (selected) NovaButtonStyle.Tonal else NovaButtonStyle.Outlined,
                            onClick = { viewModel.setTheme(theme) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            SettingRow(
                title = "Train only while charging",
                subtitle = "Delays training until the device is plugged in",
                checked = settings.trainOnlyWhileCharging,
                onCheckedChange = { viewModel.setTrainOnlyWhileCharging(it) }
            )

            SettingRow(
                title = "Thermal protection",
                subtitle = "Automatically pauses training if the device gets too hot",
                checked = settings.thermalProtectionEnabled,
                onCheckedChange = { viewModel.setThermalProtectionEnabled(it) }
            )

            SettingRow(
                title = "Low RAM mode",
                subtitle = "Uses smaller batches and tiles to reduce memory use",
                checked = settings.lowRamModeEnabled,
                onCheckedChange = { viewModel.setLowRamModeEnabled(it) }
            )

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Diagnostics", style = MaterialTheme.typography.titleMedium)
                Text(
                    "Copy debug info copies device info and recent activity to your clipboard, so you can paste it " +
                        "somewhere to explain what's happening if something seems slow or broken.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    "If the app crashed or was killed, View crash log shows why and what it was doing at that " +
                        "moment. You can copy it from there.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun SettingRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    // The whole row toggles, not just the small switch at its edge.
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 56.dp)
            .toggleable(value = checked, onValueChange = onCheckedChange, role = Role.Switch),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = null)
    }
}
