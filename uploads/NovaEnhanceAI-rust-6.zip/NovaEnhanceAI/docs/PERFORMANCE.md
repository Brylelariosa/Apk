# NovaEnhance AI - performance report (build 15)

Target device: Infinix HOT 11 2022 (Unisoc T610: 2 x Cortex-A75 + 6 x Cortex-A55, 4 GB RAM, Android 11, arm64).
6 GB and 8 GB phones go through the same code and simply get larger working sets (section 4.3).

## 0. Read this first - what was measured and what was not

* **Every number below was measured on a PC**, with this repository's own benchmark (`rust/examples/bench.rs`, run through
  `tools/bench.sh`): an x86-64 cloud VM with 2 shared vCPUs. The raw output of each run is in `docs/benchmarks/` and each table
  names its file. That VM is noisy (repeated runs differ by several percent, sometimes 20 %), so best-of and median are both
  shown, and ratios are only taken **inside one run** (the VM instance was not the same for all runs, so absolute times in
  different files are not comparable).
* **Nothing was measured on the phone.** There was no ARM device, so the following are **unverified**: the speed-up on ARM,
  which convolution kernel your phone picks, thermal behaviour, battery use, and the real memory use of the RAM tiers.
  Section 7 explains how to measure each - including a way that needs no PC.
* **Nothing is estimated and presented as a measurement.** Where a figure is derived (for example the share of useful rows in
  a chunk) it is arithmetic, and it says so.
* **The output did not change.** In every case compared, the original build and this build produce byte-identical pixels
  (same checksum; `docs/benchmarks/host-run-6-output-identical-to-original.txt` compares four profiles against the original's
  saved output with both kernels: maximum difference 0). So no quality was traded for speed, and there is no quality number to report.
* Kotlin and the new screen layout were **not built with Gradle here** (no Android SDK in the sandbox). They were checked with
  the real Kotlin compiler against hand-written stubs - see section 6. The first CI run is the real check, as for builds 13 and 14.

## 1. Results at a glance (PC, original build -> this build)

| Case | Original | This build | Faster | Output | File |
|---|---|---|---|---|---|
| 0.8 MP photo, default profile (CNN + classic), best of 5 | 4.16 s | 1.54 s | **2.7x** | identical | run-1 |
| 0.8 MP, every technique on, best of 3 | 5.10 s | 2.12 s | **2.4x** | identical | run-1 |
| 0.8 MP, classic stages only (no CNN) | 0.477 s | 0.469 s | no change | identical | run-1 |
| 0.8 MP, no CNN | 0.158 s | 0.162 s | no change | identical | run-1 |
| CNN inference alone, 0.8 MP, best of 5 | 4.20 s | 1.48 s | **2.8x** | identical | run-3 |
| 12 MP, CNN profile, same band settings as before | 87.3 s | 34.1 s | **2.6x** | identical | run-2 |
| 12 MP, CNN profile, 4 GB band settings (new) | 87.3 s | 27.0 s | **3.2x** | identical | run-4 |
| 12 MP, CNN profile, 8 GB band settings (new) | 87.3 s | 26.3 s | **3.3x** | identical | run-4 |
| 12 MP, classic stages, 4 GB / 8 GB band settings | 14.4 s | 9.2 s / 7.8 s | **1.6x / 1.8x** | identical | run-2, run-4 |
| 48 MP (8000 px wide, 600-row slice), classic, 4 GB / 8 GB | 20.3 s | 6.0 s / 3.8 s | **3.4x / 5.3x** | identical | run-2, run-4 |
| 48 MP slice, CNN profile | 48.3 s | 17.9 s | **2.7x** | identical | run-2 |
| Training step, batch 4, median of 20 | 223 ms | 117 ms | **1.9x** | same loss | run-3 |
| Training step, batch 8, median of 10 | 430 ms | 221 ms | **1.9x** | same loss | run-3 |
| 120 s sustained, 0.8 MP CNN profile | 24 photos, median 4.97 s | 58 photos, median 2.04 s | **2.4x** | - | run-3 |

Reading the table:

* The CNN speed-up (about 2.7x) comes from the convolution kernel. The classic stages (no CNN) are untouched by it, which is
  why the "classic" and "no CNN" rows do not move.
* The large-photo gains on classic stages come from **not re-processing context rows** (section 4.2), not from faster arithmetic.
* "Same band settings as before" = 256-row bands and an 800 000-pixel cap, what every phone used in build 14. The 4 GB / 8 GB rows
  use the band size the new Kotlin code would choose on such a phone.
* The 48 MP rows process a 600-row slice of an 8000 x 6000 frame (a full 48 MP photo takes ten times as long on this PC).

Memory on the PC (`peak_extra_heap_mb` = most heap live at once above where the case started, counted by the benchmark's own
allocator; native working set only, not the bitmaps):

| Case | Original | This build |
|---|---|---|
| 0.8 MP default | 12.8 MB | 13.0 MB |
| 12 MP default, same band settings | 33.9 MB | 34.0 MB |
| 12 MP default, 4 GB / 8 GB band settings | - | 63.4 MB / 92.8 MB |
| 12 MP classic, same band settings | 43.4 MB | 49.4 MB |
| 12 MP classic, 4 GB / 8 GB band settings | - | 80.8 MB / 134.4 MB |
| 48 MP slice classic, same band settings (and 4 GB) | 56.3 MB | 98.2 MB |
| 48 MP slice classic, 8 GB band settings | - | 190.1 MB |

**This is the price of the large-photo gains: a bigger working set.** It is bounded (section 4.3) but it is real, and it is the
thing to watch on a 4 GB phone. Other measurements: allocation counts are essentially unchanged for the CNN profile (5 135 -> 5 165 over
5 photos of 0.8 MP), the average number of busy cores is the same (1.9 of 2), and 10 photos in a row grow the
process by about 0.1 MB (original 0.2 MB) - no leak, no drift (`-1.5 %` original, `+2.5 %` new, inside the noise).

## 2. What carries over to the phone

| Change | Should carry over? | What could differ on the phone |
|---|---|---|
| Fewer wasted context rows (section 4.2) | **Yes** - it is arithmetic about how many rows are processed twice, independent of the CPU. | How much of the total time those stages take; a bigger chunk has a bigger working set and may cache worse on an A55. |
| RAM-tier band sizes (4.3) | The reduction of wasted work, yes. | Real memory pressure, and how much "free RAM" a 4 GB phone really has while other apps run. |
| Blocked convolution kernel (4.1) | **Unknown.** It is 2.6x - 3.4x faster on x86-64. ARM code generation is different. | Possibly slower or equal. That is why the phone **times both kernels itself** and uses the new one only if it is clearly (5 %) faster; otherwise the build behaves exactly like build 14. |
| Thermal easing (4.4) | Unknown - needs a hot phone. | Whether the phone reports a thermal headroom at all (many budget phones do not). |
| Training yields to Enhance (4.5) | Yes, it is a thread cap. | Not measured. |

## 3. Phase 1 audit - findings in priority order

Status key: **shipped**, **kept** (examined, left as it is, with evidence), **not done** (with the reason).

### F1 - The CNN convolution kernel (shipped)
* **Where:** `rust/src/nn/kernels.rs` (`conv_row`, `conv_row_gated`), used by `nn/infer.rs::run_strip` and by
  `nn/train.rs` (`forward_band`, `output_band`, `backward_band`). Layers 2 and 3 (48 -> 48 channels) are about 94 % of the
  network's multiply-accumulates.
* **Today:** a register-blocked 3 x 3 convolution that relies on the compiler to vectorise small local arrays. Weights are read
  with a stride of `cout` for every (tap, input channel).
* **Problem:** auto-vectorisation is fragile. The same source, compiled inside a different crate, measured 4.1 GMAC/s against 7.1-7.4
  for a verbatim copy (`host-run-5`, section C) - so the speed depends on compiler decisions that cannot be read off the source.
  On the PC the reference kernel ran at 5.1-5.4 GMAC/s.
* **Change:** weights re-ordered once into one contiguous stream per output-channel block (`ConvWeights`), a second kernel
  (`conv_row_blocked`, `conv_row_gated_blocked`) doing **the same arithmetic in the same order**, and `kernels::active_kernel()`, which
  times both on the device the first time the network runs and keeps the faster one. Unsafe code: none.
* **Impact (PC):** kernel 2.9-3.1x (`host-run-1`: 5.1-5.4 vs 15.4-15.8 GMAC/s); CNN inference 2.8x; whole 0.8 MP photo 2.7x;
  training 1.9x. **Phone: unverified**, protected by the race.
* **Risk:** the first call costs a few milliseconds on the PC (tens on a phone, an estimate); a noisy moment during the race
  can pick the slower kernel, which only costs speed because the two are bit-identical; the extra packed copy of the weights adds a few allocations
  (+30 over 5 photos in run-1).
* **Tests:** `blocked_kernel_is_bit_identical_to_the_reference`, `gated_blocked_kernel_matches_the_reference`,
  `fast_inference_is_bit_identical_to_the_reference_forward_pass` (whole-image reference forward pass, both kernels, 1 and 3 threads,
  sizes 1 x 1 ... 301 x 9), `both_kernels_give_bit_identical_loss_and_gradient`, `the_engine_picks_a_kernel_and_sticks_with_it`.

### F2 - Context rows processed over and over on wide photos (shipped)
* **Where:** `rust/src/enhance/session.rs::process_rows` (chunk height), `app/.../ai/engine/BandProcessor.kt` (band height).
* **Today:** every native chunk is processed together with `halo` real rows above and below (so results do not depend on how the
  photo is cut up) and those rows are then thrown away. The chunk height was `cap / width` rows with a floor of `2 x halo + 16`,
  so a chunk kept only `16` own rows when the floor applied.
* **Problem:** an 8000-px-wide photo with every classic stage on (halo 57) processed 130 rows to produce 16 - **8x the useful work**.
  A 4000-px photo (12 MP) kept 86 of 200 rows (43 %). Kotlin's fixed 256-row bands also ended in a short tail chunk.
* **Change:** the floor is now `max(16, 2 x halo)` own rows (`chunk_core_rows`), so waste is at most 100 %; Kotlin rounds each band
  to a whole number of chunks (`ComputeBudget.bandRowsFor`, between one chunk and 512 rows, so progress, cancellation and
  heat pacing keep their granularity).
* **Impact (PC):** 48 MP slice, classic: 20.3 s -> 6.0 s with unchanged band settings, output identical. At 12 MP the floor alone
  changes nothing (14.4 s vs 14.7 s with unchanged band settings, `host-run-2`); the gain there comes from F3.
* **Risk:** for very wide photos the minimum chunk is larger than the nominal pixel cap (8000 px x 228 rows = 1.8 M pixels), so the working set
  grows (56 -> 98 MB peak extra heap on the PC for that case).
* **Tests:** `chunks_always_get_room_for_their_context`; the existing `banded_processing_matches_whole_image_processing`
  (no seams); Kotlin `ComputeBudgetTest` (`chunk rows match the native side`, `a chunk always has room for its context`,
  `a band is a whole number of chunks and keeps its granularity`).

### F3 - One fixed working-set cap for every phone (shipped)
* **Where:** `NativeEnhancer.DEFAULT_MAX_BAND_PIXELS = 800 000`, passed by `EnhancementEngine` to `NativeEnhancer.open` on every device.
* **Problem:** a larger chunk wastes less on context rows (F2); an 8 GB phone had the same cap as a 2 GB phone.
* **Change:** `ComputeBudget.maxBandPixels(MemoryStats.ramInfo())`: a tier from total RAM, never more than 5 % of the RAM free at
  that moment (56 bytes per pixel), never below 400 000, and 800 000 (the old value) when the phone is flagged low-RAM or the RAM
  cannot be read. One function, used by every path that enhances a photo (Enhance, batch, training's validation passes).
* **Impact (PC):** 12 MP classic 14.4 s -> 9.2 s (4 GB settings) / 7.8 s (8 GB settings); 12 MP CNN 34.1 s -> 27.0 s / 26.3 s.
* **Risk:** more memory on bigger tiers (section 1). On a phone that is already short of RAM the affordability cap can go
  **below** the old 800 000.
* **Tests:** Kotlin `ComputeBudgetTest` (tiers, free-RAM cap, low-RAM device, floor, rounding).

### F4 - Thermal protection only reacted at MODERATE (shipped, unverified)
* **Where:** `app/.../utils/ThermalGovernor.kt`, `DeviceCapabilities.kt`, `ComputeBudget.threadsForHeadroom`.
* **Today:** NONE / LIGHT = every core, no pacing; MODERATE = 2 threads plus a cool-down; SEVERE / CRITICAL pause.
* **Change:** while the status is NONE / LIGHT and the phone reports `PowerManager.getThermalHeadroom` (Android 11+), threads
  are handed back gradually: all of them up to headroom 0.70, then linearly down to a quarter of the ceiling at 1.0 (8 threads: 5 at
  0.85, 2 at 1.0). **The MODERATE / SEVERE / CRITICAL rules and every cool-down length are unchanged.** NaN (Android 10, or a
  phone that does not report it) = exactly the old behaviour.
* **Impact:** none measurable on a PC. The expectation is a steadier load that reaches MODERATE less often; **unverified**.
* **Risk:** a phone that reports a wrong or constant high headroom would run on fewer threads than before. Settings -> Copy debug
  info now prints the reported value; section 10 says how to switch the easing off.
* **Tests:** Kotlin `ComputeBudgetTest` (no information changes nothing, cool phones keep every thread, monotonic hand-back, small ceilings).

### F5 - Training competed with the photo the user was waiting for (shipped)
* **Where:** `ModelTrainer.kt` batch loop, `EnhancementEngine.kt`, `BatchEnhancer.kt`, `EnhanceViewModel.kt`, new `utils/InteractiveWork.kt`.
* **Problem:** training asked for `cores - 2` threads and nothing reduced that while an Enhance was running.
* **Change:** Enhance and batch passes are counted by `InteractiveWork` (running **or queued** on the existing engine gate); while that count
  is above zero the training loop's concurrency is capped at 2 threads (`yieldToInteractive`). It never turns a PROCEED into a PAUSE.
  Training's own validation / rescoring passes do not count as interactive.
* **Risk:** training is slower while the user enhances - by design. A leaked count could keep training on 2 threads until the process ends.
* **Tests:** `InteractiveWorkTest` (overlap, no negative count, 8 threads x 2 000 enter/exit pairs balance out);
  the `ThermalGovernor` decision itself needs Android classes and is compile-checked only.
* **Already in place, unchanged:** the training activation workspace is reused between steps (`nn/train.rs`, `WORKSPACE`, freed by
  `release_workspace()`), so "reusable training buffers" needed no change.

### F6 - Worker scheduler `par.rs::run_jobs` (kept)
* **Today:** dynamic scheduling over fresh scoped threads per parallel call; fast cores claim more jobs.
* **Evidence:** one 0.8 MP photo starts 88 threads (CNN profile) or 464 (classic) at 2 threads (strace, `host-run-5` A); starting a
  thread costs 25-35 us (`host-run-3`). That is about 0.2 % of the CNN run and about 3 % of the classic run **on the PC**.
  A persistent pool would need `'static` plumbing or unsafe code to share borrowed buffers.
* **Decision:** not justified by the numbers, so not replaced - as the brief asks. Revisit only if a phone run shows the spawn cost is much larger.

### F7 - Scratch buffers in the classic stages (kept)
* **Evidence:** system CPU time (where page faults of freshly allocated buffers show up) was 2.6 % (no CNN), 3.2 % (classic) and
  0.4 % (CNN profile) of total CPU time (`host-run-5` B). Reuse could win at most that, and not all of it.
* **Decision:** not changed; adds lifetime and cancellation risk for no measurable benefit.

### F8 - Core-count lookup `par::max_threads()` (kept)
* **Evidence:** `available_parallelism()` costs 7 us and is called once per JNI call (`bridge.rs`) - never in a loop (`host-run-5` D). Caching it would also stop the app
  noticing cores going offline. Not changed.

### F9 - NEON intrinsics / hand-written assembly (not done)
* Could not be compiled or run here (no aarch64 toolchain run, no device), and the brief itself warns against assuming it beats the
  compiler's vectoriser. A look at AArch64 code for the two layouts through a different LLVM was inconclusive (neither clearly better), which
  is the reason for the on-device race instead of a guess; that experiment is not reproducible from this repository and is **not** evidence for any speed-up.
  The race is also the safe place to add a third (intrinsics) candidate later.

### F10 - Winograd F(2x2, 3x3) (prototyped on the PC, not shipped)
* On one 48 -> 48 layer over a 130 x 64 tile: original 21.7-23.4 ms, shipped blocked kernel 12.2-12.8 ms, Winograd 8.1-9.6 ms
  (about 1.3-1.5x faster than the shipped kernel), `host-run-5` C, source in `docs/benchmarks/prototypes/`.
* **Not shipped:** it changes the order of the arithmetic (largest difference from the original 1.3e-6), so it is **not bit-identical**:
  every other change here keeps the output byte-for-byte, and this one would not - it also changes training gradients. It would need a quality
  review on real photos and a trained model, and the PC gain may not carry over to in-order A55 cores. If the phone shows the CNN stage
  still dominates, this is the next experiment, as a third candidate in the same race.

### Not examined separately
* `conv_weight_grad` (the weight-gradient part of a training step) was not changed or profiled on its own. Training is 1.9x faster
  while the convolutions are about 2.7x faster, so some part of a step does not benefit; how large it is has not been measured.

## 4. How the shipped changes work

### 4.1 Which kernel? A race on the phone
`kernels::active_kernel()` runs once per process, the first time the network (or `backendName`, used by the debug report) is
needed. It times both kernels on a 64-pixel row of the 48 -> 48 layer - 8 rounds alternating who goes first, best round counts -
and chooses the blocked kernel only if its best time is below 95 % of the reference's. A tie or any doubt keeps the reference kernel,
so a phone where the new code does not help behaves like build 14. `NOVA_KERNEL=reference|blocked` in the environment forces one
(for the benchmark; an app process has no such variable). Settings -> Copy debug info shows the result as `Native kernels: ...`.

### 4.2 Why wide photos were slow: the arithmetic
A chunk of `core` own rows costs `core + 2 x halo` rows of work. Useful share = `core / (core + 2 x halo)` - derived, not measured:

| 12 MP (4000 px wide, halo 57) | pixel cap | own rows per chunk | useful share |
|---|---|---|---|
| build 14, every phone | 800 000 | 86 (plus a tail chunk per band) | 43 % |
| low-RAM tier (new) | 800 000 | 114 (band = 2 chunks) | 50 % |
| 4 GB tier | 1 500 000 | 261 | 70 % |
| 6 GB tier | 2 500 000 | 511 | 82 % |
| 8 GB tier | 4 000 000 | 512 (band limit) | 82 % |

| 48 MP (8000 px wide, halo 57) | pixel cap | own rows per chunk | useful share |
|---|---|---|---|
| build 14, every phone | 800 000 | 16 | 12 % |
| low-RAM and 4 GB tier | 800 000 / 1 500 000 | 114 | 50 % |
| 6 GB tier | 2 500 000 | 198 | 63 % |
| 8 GB tier | 4 000 000 | 386 | 77 % |

The measured times follow the arithmetic: 12 MP classic 14.4 / 9.2 / 7.8 s is 1 : 0.64 : 0.54 against 1 : 0.61 : 0.52 predicted from the
useful share; 48 MP slice 20.3 / 6.0 / 3.8 s is 1 : 0.30 : 0.19 against 1 : 0.24 : 0.16. Results are identical because a chunk
always reads its true neighbouring rows - the cut position never changes a pixel (`banded_processing_matches_whole_image_processing`).

### 4.3 RAM tiers and the affordability cap
Android reports less than the label (a "4 GB" phone shows about 3.7 GB), so the boundaries sit below the round numbers:

| Total RAM reported | Pixel cap per chunk | Typical phone |
|---|---|---|
| under 3 072 MB, or flagged low-RAM | 800 000 (as before) | 2-3 GB |
| 3 072 - 5 119 MB | 1 500 000 | "4 GB" - the Infinix HOT 11 2022 |
| 5 120 - 7 167 MB | 2 500 000 | "6 GB" |
| 7 168 MB and up | 4 000 000 | "8 GB" and more |

Then limited to 5 % of the RAM free right now at 56 bytes per pixel (the cost measured on the heaviest stage mix at 8000 px wide, rounded up),
rounded down to 50 000 and never below 400 000. Example: 1 500 MB free -> about 1.4 M pixels. `ThermalGovernor` still pauses work when
free RAM falls below `PAUSE_RAM_THRESHOLD_MB`, checked between bands.

### 4.4 Thermal easing
`threadsForHeadroom(ceiling, headroom)`: headroom <= 0.70 or unknown -> the ceiling; at 1.0 and above -> a quarter of the ceiling
(at least 1); linear in between, rounded up. Applied only while Android's own status is below MODERATE (NONE, LIGHT or unknown); BandPacer (Enhance) and the training loop both
get it through `ThermalGovernor.evaluate`. The 10-second forecast is requested at most once per snapshot (per band or per training step).

### 4.5 Training steps aside
`ThermalGovernor.evaluate(concurrencyCeiling, yieldToInteractive = true)` (training only) returns at most 2 threads while
`InteractiveWork.isActive`. Nothing waits: it is a counter read.

## 5. Benchmark detail

Files in `docs/benchmarks/` (all PC, original = the unmodified build 14.1 tree, built with the same compiler and flags):

| File | Content |
|---|---|
| `host-run-1-small-photos.txt` | kernel race, 0.8 MP default / no CNN / classic / everything on, 10 photos in a row. **Partial:** the run stopped during the 12 MP case; 12 MP and 48 MP were re-run in run-2. |
| `host-run-2-12mp-and-48mp-slice.txt` | 12 MP default and classic, 48 MP slice classic and default, same band settings for both trees |
| `host-run-3-cnn-training-spawn-sustained.txt` | CNN inference, training batch 4 and 8, thread-spawn cost, 120 s sustained |
| `host-run-4-band-sizing-by-ram-tier.txt` | this build with the band settings Kotlin picks on a 4 GB and an 8 GB phone |
| `host-run-5-scheduler-scratch-and-kernel-prototypes.txt` | evidence for F6 - F10 (thread counts, system time, kernel prototypes, core-count lookup) |
| `host-run-6-output-identical-to-original.txt` | pixel comparison with the original's output, 4 profiles x 2 kernels |
| `prototypes/` | source of the Winograd / kernel prototype and of the core-count micro-benchmark (text files, not part of the build) |

What each run reports: wall time per photo (best, median), throughput, average busy cores, allocation count, peak extra heap, peak RSS,
output checksum. **Not measured:** temperature and battery (no sensor or thermal API on the PC); the 120 s run only shows that the PC does not slow
down over two minutes (original -0.4 %, new +0.3 %), which says nothing about a phone's heat.

## 6. Regression checks that were run

* **Rust:** `cargo test --lib` - **64 tests pass** (the 58 existing ones, none removed, plus 6 new: bit-identical kernels, bit-identical inference against a
  whole-image reference, identical loss and gradient from both kernels, kernel choice stability, chunk floor); also `cargo build --release`.
  Rust 1.97 here; your CI uses the newest stable - the new code has no `unsafe`, so the lint that stopped run 1987 cannot apply to it.
* **Model compatibility:** parameter layout and `.novamodel` format untouched; `PackedWeights` only repacks the same numbers. Same
  loss and gradient in the tests, same output pixels in run-6.
* **Quality / dimensions / band boundaries:** run-6 (max difference 0, PSNR infinite, four profiles, both kernels); `banded_processing_matches_whole_image_processing`
  and `strips_give_the_same_result_as_one_pass`.
* **JNI safety:** no JNI signature changed; `python3 tools/jni_crosscheck.py` -> 19 Kotlin externals match 19 Rust exports.
* **Cancellation and concurrency:** the band loop, `isStale` check and engine gate are unchanged; `InteractiveWorkTest` covers the counter under contention.
* **Kotlin:** the engine, budget, thermal and diagnostics files were compiled with the real Kotlin compiler (2.0.21, also in
  `-language-version 1.9` mode to match the project's 1.9.24) against stubs of the Android classes: no errors. The new Enhance-screen files
  were type-checked the same way against hand-written Compose stubs (a weaker check). 16 JUnit tests pass (12 budget tests, 4 interactive-work tests).
  Resource references: none missing, all 26 XML files parse.
* **Not run:** Gradle, the Android targets, an emulator or device, the user-interface flows, low-memory behaviour on a real phone, thermal behaviour.

## 7. How to measure on the phone

### 7.1 Without a PC
1. Install the APK built from this source. 2. Settings -> **Copy debug info** and paste it somewhere. Read:
   * `Native kernels:` ends in `/blocked` or `/reference` - the one your phone measured as faster. `/reference` means the new kernel did not win on your CPU and the CNN
     part runs as in build 14.
   * `Enhance band budget:` - pixels per chunk right now: 1 500 000 on a 4 GB phone that has at least about 1.6 GB free, less when less is free.
   * `Thermal headroom (10 s forecast):` - a number, or "not reported by this phone" (then nothing changed for you).
   * Under *Recent activity*, after enhancing a large photo: `Processed WxH in N band(s) ... in X ms` and the `band cap ... bands of ... rows` line.
3. Enhance the same large photo with build 14 and with this build and compare the `X ms` lines.

### 7.2 With a PC and a USB-connected phone (USB debugging on)
```
rustup target add aarch64-linux-android && cargo install cargo-ndk     # once; Android NDK 25.2.9519653, ANDROID_NDK_HOME set
tools/bench.sh --target android --full --baseline /path/to/older/NovaEnhanceAI    # old and new, side by side, on the phone
tools/bench.sh --target android --full --long 600                                 # adds a 10-minute run; read drift_percent
```
The first block is `kernel race`: `reference_gmac_s`, `blocked_gmac_s`, `choice`. Then wall time, `avg_cores_busy`, `peak_rss_mb`,
`peak_extra_heap_mb`, allocation counts. For heat, watch `adb shell dumpsys thermalservice` before and after the long run. The Android path of `tools/bench.sh`
has **not been run** (no device, no NDK here), so a first failure there is a script problem, not a result. On a PC: `tools/bench.sh --full`
(add `--only "12 MP"` for one case; `--baseline DIR` to compare with an older tree). Results go to `bench-results-<time>.txt`.

## 8. Files modified and added

**Rust:** `rust/src/nn/kernels.rs` (blocked kernel, `ConvWeights`, `Kernel`, race), `nn/weights.rs`, `nn/infer.rs`, `nn/train.rs`, `nn/mod.rs` (`backend_name`),
`enhance/session.rs` (`chunk_core_rows`), `rust/examples/bench.rs` (benchmark tool).
**Kotlin (performance):** `utils/Constants.kt`, `ComputeBudget.kt`, `MemoryStats.kt`, `DeviceCapabilities.kt`, `ThermalGovernor.kt`, `DiagnosticsReport.kt`, new `InteractiveWork.kt`;
`ai/engine/EnhancementEngine.kt`, `BandProcessor.kt`, `BatchEnhancer.kt`; `training/trainer/ModelTrainer.kt`; `ui/viewmodel/EnhanceViewModel.kt`.
**Kotlin (Enhance screen, no scrolling):** `ui/screens/EnhanceScreen.kt`, `ui/components/LabeledSlider.kt`, `NovaButtons.kt`, new `EnhancementControls.kt`
(replaces `AdvancedEnhancementControls.kt`).
**Tests:** `ComputeBudgetTest.kt` (extended), new `InteractiveWorkTest.kt`; Rust tests inside the modules above.
**Tools and docs:** new `tools/bench.sh`, `docs/PERFORMANCE.md`, `docs/benchmarks/*`; `CHANGES.md`, `README.md`.
**Deliberately unchanged:** `rust/src/par.rs`, `bridge.rs` and every JNI signature, the network layout and checkpoint format, `UpscaleStage`, Gradle files, the GitHub workflow.

## 9. Build and test

```
cd rust && cargo test --lib                  # 64 tests (CI runs this)
cd rust && cargo build --release --example bench && ./target/release/examples/bench kernel
python3 tools/jni_crosscheck.py              # JNI names and types
./gradlew testDebugUnitTest                  # Kotlin unit tests (budget, interactive work, ...)
./gradlew assembleDebug                      # as before; Rust is built per ABI by Gradle / cargo-ndk
```

## 10. Known limitations, risks, and how to switch things back

* Everything phone-specific is unverified (section 0). The safe fallbacks: kernel race (ties and doubt keep the old kernel); unknown thermal
  headroom (old behaviour); unreadable RAM (old 800 000 cap).
* **More memory on bigger tiers** and for very wide photos (section 1). The pixel cap is a soft cap for wide photos: the minimum chunk is
  `4 x halo` rows (228 rows with every classic stage on).
* **Switch-offs:** band sizes - set `BAND_PIXELS_4GB`, `_6GB`, `_8GB` in `Constants.kt` to `800_000`; thermal easing - set `THERMAL_HEADROOM_MIN_FRACTION`
  to `1.0f`; training yield - set `THREADS_WHILE_INTERACTIVE_WORK_RUNS` to `8`; kernel - `NOVA_KERNEL=reference` (benchmark / adb only).
* A phone's headroom report could be misleading (see F4); check the value in the debug info before blaming the easing.
* Winograd, NEON intrinsics, scratch reuse and a persistent thread pool are documented above as not done, with the evidence.
