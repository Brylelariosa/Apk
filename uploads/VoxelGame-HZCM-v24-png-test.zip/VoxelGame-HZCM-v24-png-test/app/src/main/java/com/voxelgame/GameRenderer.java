package com.voxelgame;

import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.opengl.GLSurfaceView;
import android.util.Log;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;
import java.io.IOException;
import java.io.InputStream;

public class GameRenderer implements GLSurfaceView.Renderer {

    private static final String TAG = "VoxelAtlas";

    // ══════════════════════════════════════════════════════════════════════════
    // PNG TEXTURE TEST MODE
    //
    // Set to false to completely bypass the PNG loading pipeline and use ONLY
    // the procedural textures generated in TextureAtlas.h (generateAtlasData).
    //
    // HOW TO USE:
    //   1. Set USE_PNG_TEXTURES = false, rebuild, run.
    //   2. If terrain appears → the bug is inside the PNG texture system.
    //      Re-enable one file group at a time to locate the broken tile.
    //   3. If terrain is still missing → the bug is in chunk/mesh/render, not textures.
    //
    // When false:
    //   • No PNG files are opened or decoded.
    //   • No nativeSetAtlasTile() calls are made.
    //   • The GL_TEXTURE_2D_ARRAY atlas built by initAtlas() in Renderer.cpp
    //     is used exactly as-is (procedural 16×16 pixel-art tiles).
    //   • All 20 layers are valid; terrain will render with solid pixel-art colours.
    // ══════════════════════════════════════════════════════════════════════════
    private static final boolean USE_PNG_TEXTURES = false;

    static {
        System.loadLibrary("voxelgame");
    }

    // ── Atlas tile names ───────────────────────────────────────────────────────
    // Index matches ATLAS_TILE[48] LUT in the vertex shader.
    // Files go in:  app/src/main/assets/textures/<name>
    // null entries are intentionally skipped (debug tile 0 = magenta sentinel).
    private static final String[] TILE_NAMES = {
        null,             //  0  debug      (never override — keep magenta sentinel)
        "grass_top.png",  //  1  grass top
        "grass_side.png", //  2  grass side
        "dirt.png",       //  3  dirt
        "stone.png",      //  4  stone
        "sand.png",       //  5  sand
        "snow_top.png",   //  6  snow top
        "snow_side.png",  //  7  snow side
        "wood_side.png",  //  8  wood bark (side)
        "wood_top.png",   //  9  wood rings (top/bottom)
        "leaves.png",     // 10  leaves
        "water.png",      // 11  water
        "gravel.png",     // 12  gravel
        "red_sand.png",   // 13  red sand / terracotta
        "clay.png",       // 14  clay
        "ice.png",        // 15  ice
        "cactus_side.png",// 16  cactus side
        "cactus_top.png", // 17  cactus top
        "basalt.png",     // 18  basalt
        "cobble.png",     // 19  cobble
    };

    private final AssetManager assetManager;

    public GameRenderer(AssetManager assetManager) {
        this.assetManager = assetManager;
    }

    // ── GLSurfaceView.Renderer ─────────────────────────────────────────────────
    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        nativeInit();  // creates GL context, builds procedural atlas (always runs)

        if (USE_PNG_TEXTURES) {
            Log.i(TAG, "=== PNG texture mode ENABLED — loading atlas PNGs ===");
            loadAtlasTiles();
        } else {
            Log.i(TAG, "=== PNG texture mode DISABLED — using procedural atlas only ===");
            Log.i(TAG, "PNG count: 0 (skipped by USE_PNG_TEXTURES=false)");
            Log.i(TAG, "Texture layer count: " + TILE_NAMES.length
                    + " (all procedural, built in TextureAtlas.h)");
            Log.i(TAG, "If terrain renders correctly here, the bug is in the PNG pipeline.");
        }
    }

    @Override
    public void onSurfaceChanged(GL10 gl, int width, int height) {
        nativeResize(width, height);
    }

    @Override
    public void onDrawFrame(GL10 gl) {
        nativeRender();
    }

    // ── PNG → atlas upload ─────────────────────────────────────────────────────
    // Only called when USE_PNG_TEXTURES = true.
    //
    // For each tile slot that has a filename, try to load the PNG from assets.
    // Decode → force to ARGB_8888 software bitmap → scale to 16x16 if needed
    // → convert ARGB int pixels to RGBA byte array → upload via nativeSetAtlasTile.
    //
    // If ANY step fails, the procedural tile stays in place (no rendering is stopped).
    // A magenta fallback is written for tiles that decode corrupt/zero data.
    //
    // MUST be called on the GL thread (inside onSurfaceCreated), after nativeInit().
    private void loadAtlasTiles() {
        // Force software ARGB_8888 decoding.
        // Without inPreferredConfig, BitmapFactory may return HARDWARE bitmaps on
        // Android 8.1+ — getPixels() throws IllegalStateException on those.
        // inScaled=false: assets are density-independent, never auto-scale.
        // inPremultiplied=false: we pack raw channels ourselves for OpenGL.
        final BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inPreferredConfig = Bitmap.Config.ARGB_8888;
        opts.inScaled          = false;
        opts.inPremultiplied   = false;

        int loaded  = 0;
        int skipped = 0;

        // Magenta fallback (255,0,255,255) — used when a PNG decodes all-zero.
        // This is immediately visible in-game, making bad tiles easy to spot.
        byte[] magentaFallback = buildMagentaTile();

        for (int i = 0; i < TILE_NAMES.length; i++) {
            if (TILE_NAMES[i] == null) continue;  // tile 0 (debug) intentionally skipped

            String path = "textures/" + TILE_NAMES[i];
            InputStream is     = null;
            Bitmap      bmp    = null;
            Bitmap      scaled = null;
            try {
                is  = assetManager.open(path);
                bmp = BitmapFactory.decodeStream(is, null, opts);

                if (bmp == null) {
                    Log.w(TAG, "loadAtlasTiles: BitmapFactory returned null for: " + path
                            + " — using magenta fallback for tile " + i);
                    nativeSetAtlasTile(i, magentaFallback);
                    skipped++;
                    continue;
                }

                // On some devices, driver ignores inPreferredConfig and still returns HARDWARE.
                if (bmp.getConfig() == Bitmap.Config.HARDWARE) {
                    Log.w(TAG, "loadAtlasTiles: HARDWARE bitmap for " + path
                            + " despite ARGB_8888 request — copying to software");
                    Bitmap soft = bmp.copy(Bitmap.Config.ARGB_8888, false);
                    bmp.recycle();
                    bmp = soft;
                    if (bmp == null) {
                        Log.e(TAG, "loadAtlasTiles: software copy failed for " + path
                                + " — using magenta fallback");
                        nativeSetAtlasTile(i, magentaFallback);
                        skipped++;
                        continue;
                    }
                }

                Log.d(TAG, "loadAtlasTiles: decoded " + path
                        + " [" + bmp.getWidth() + "x" + bmp.getHeight()
                        + " " + bmp.getConfig() + "]");

                // Scale to 16x16 if source is different (e.g. 32x32 HD packs).
                if (bmp.getWidth() != 16 || bmp.getHeight() != 16) {
                    Log.i(TAG, "loadAtlasTiles: scaling " + bmp.getWidth()
                            + "x" + bmp.getHeight() + " → 16x16 for tile " + i);
                    scaled = Bitmap.createScaledBitmap(bmp, 16, 16, /*filter=*/false);
                    bmp.recycle();
                    bmp    = scaled;
                    scaled = null;
                    if (bmp == null || bmp.getWidth() != 16 || bmp.getHeight() != 16) {
                        Log.e(TAG, "loadAtlasTiles: scaling failed for tile " + i
                                + " — using magenta fallback");
                        nativeSetAtlasTile(i, magentaFallback);
                        skipped++;
                        continue;
                    }
                    // Post-scale HARDWARE check (some Android versions).
                    if (bmp.getConfig() == Bitmap.Config.HARDWARE) {
                        Bitmap soft2 = bmp.copy(Bitmap.Config.ARGB_8888, false);
                        bmp.recycle();
                        bmp = soft2;
                        if (bmp == null) {
                            Log.e(TAG, "loadAtlasTiles: post-scale HARDWARE copy failed tile "
                                    + i + " — using magenta fallback");
                            nativeSetAtlasTile(i, magentaFallback);
                            skipped++;
                            continue;
                        }
                    }
                }

                // Read 256 pixels as Android ARGB ints (0xAARRGGBB).
                int[] argb = new int[256];
                try {
                    bmp.getPixels(argb, 0, 16, 0, 0, 16, 16);
                } catch (IllegalStateException e) {
                    Log.e(TAG, "loadAtlasTiles: getPixels() IllegalStateException for " + path
                            + " config=" + bmp.getConfig()
                            + " — HARDWARE bitmap slipped through guard. Using magenta.", e);
                    nativeSetAtlasTile(i, magentaFallback);
                    skipped++;
                    continue;
                }
                bmp.recycle();
                bmp = null;

                // Convert Android ARGB → packed RGBA bytes for glTexSubImage3D.
                byte[] rgba = new byte[256 * 4];
                for (int p = 0; p < 256; p++) {
                    int px = argb[p];
                    rgba[p * 4    ] = (byte)((px >> 16) & 0xFF); // R
                    rgba[p * 4 + 1] = (byte)((px >>  8) & 0xFF); // G
                    rgba[p * 4 + 2] = (byte)((px      ) & 0xFF); // B
                    rgba[p * 4 + 3] = (byte)((px >> 24) & 0xFF); // A
                }

                // Detect all-zero RGB (corrupt PNG or fully transparent).
                // Upload magenta fallback so the bad tile is visible in-game.
                boolean allZero = true;
                for (int b = 0; b < rgba.length; b += 4) {
                    if (rgba[b] != 0 || rgba[b+1] != 0 || rgba[b+2] != 0) {
                        allZero = false;
                        break;
                    }
                }
                if (allZero) {
                    Log.w(TAG, "loadAtlasTiles: all RGB pixels are zero for tile " + i
                            + " (" + path + ") — PNG corrupt or fully transparent."
                            + " Uploading magenta fallback so it is visible in-game.");
                    nativeSetAtlasTile(i, magentaFallback);
                    skipped++;
                    continue;
                }

                nativeSetAtlasTile(i, rgba);
                loaded++;
                Log.i(TAG, "loadAtlasTiles: tile " + i + " OK <-- " + path);

            } catch (IOException e) {
                // File not found — procedural tile stays, terrain keeps rendering.
                Log.d(TAG, "loadAtlasTiles: " + path + " not found — keeping procedural tile");
                skipped++;
            } catch (OutOfMemoryError e) {
                Log.e(TAG, "loadAtlasTiles: OOM for tile " + i + " (" + path + ")"
                        + " — using magenta fallback", e);
                nativeSetAtlasTile(i, magentaFallback);
                skipped++;
            } finally {
                if (scaled != null) { scaled.recycle(); }
                if (bmp    != null) { bmp.recycle(); }
                if (is     != null) { try { is.close(); } catch (IOException ignored) {} }
            }
        }

        int total = TILE_NAMES.length - 1; // exclude tile 0 (debug, intentionally null)
        Log.i(TAG, "=== Atlas loaded ===");
        Log.i(TAG, "PNG count: " + loaded + " loaded, " + skipped + " skipped out of " + total);
        Log.i(TAG, "Texture layer count: " + TILE_NAMES.length
                + " (loaded=" + loaded + " procedural/fallback=" + (total - loaded) + ")");
    }

    // ── Magenta fallback tile ─────────────────────────────────────────────────
    // Used when a PNG fails to decode. Immediately visible in-game: makes broken
    // tiles easy to spot without stopping terrain from rendering.
    private static byte[] buildMagentaTile() {
        byte[] tile = new byte[256 * 4];
        for (int i = 0; i < 256; i++) {
            // Checkerboard: alternating bright magenta and dark magenta
            boolean checker = ((i % 16) + (i / 16)) % 2 == 0;
            tile[i * 4    ] = (byte)(checker ? 255 : 200); // R
            tile[i * 4 + 1] = (byte) 0;                    // G
            tile[i * 4 + 2] = (byte)(checker ? 255 : 200); // B
            tile[i * 4 + 3] = (byte) 255;                  // A
        }
        return tile;
    }

    // ── JNI declarations ──────────────────────────────────────────────────────
    public native void nativeInit();
    public native void nativeResize(int width, int height);
    public native void nativeRender();

    // Upload one 16×16 RGBA tile into the live GL_TEXTURE_2D_ARRAY atlas.
    // Must be called from the GL thread (inside onSurfaceCreated).
    public native void nativeSetAtlasTile(int tileIdx, byte[] rgbaBytes);
}
