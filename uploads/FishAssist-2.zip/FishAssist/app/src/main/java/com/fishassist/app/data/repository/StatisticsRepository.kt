package com.fishassist.app.data.repository

import com.fishassist.app.data.local.StatisticsDao
import com.fishassist.app.data.model.Statistics
import kotlinx.coroutines.flow.Flow

class StatisticsRepository constructor(private val dao: StatisticsDao) {

    val statistics: Flow<Statistics?> = dao.observe()

    suspend fun recordCatch(reactionMs: Long, detectionFps: Float) {
        val s = dao.get() ?: Statistics()
        dao.upsert(s.copy(
            totalFishCaught    = s.totalFishCaught + 1,
            totalReactionTimeMs = s.totalReactionTimeMs + reactionMs,
            reactionSamples    = s.reactionSamples + 1,
            detectionFpsSum    = s.detectionFpsSum + detectionFps,
            fpsSamples         = s.fpsSamples + 1
        ))
    }

    suspend fun recordMiss() {
        val s = dao.get() ?: Statistics()
        dao.upsert(s.copy(totalMissed = s.totalMissed + 1))
    }

    suspend fun addSessionTime(ms: Long) {
        val s = dao.get() ?: Statistics()
        dao.upsert(s.copy(totalSessionMs = s.totalSessionMs + ms))
    }

    suspend fun reset() = dao.reset()
}
