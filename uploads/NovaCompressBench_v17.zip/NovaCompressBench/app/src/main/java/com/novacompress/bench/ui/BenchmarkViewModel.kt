package com.novacompress.bench.ui

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.novacompress.bench.benchmark.BenchmarkRunner
import com.novacompress.bench.benchmark.BenchmarkSource
import com.novacompress.bench.core.BenchmarkMetrics
import com.novacompress.bench.core.CompressionAlgorithm
import com.novacompress.bench.data.repository.BenchmarkRepository
import com.novacompress.bench.di.AppContainer
import com.novacompress.bench.novacompress.NovaCompressAlgorithm
import com.novacompress.bench.novacompress.format.NovaResearchReport
import com.novacompress.bench.service.KeepAliveService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class BenchmarkUiState(
    /** Every source queued up for the next run - one real picked file, one
     *  built-in sample, or (this is the point of allowing a list rather than
     *  a single nullable source) several built-in samples selected together
     *  so one tap benchmarks all of them in a single batch. */
    val sources: List<BenchmarkSource> = emptyList(),
    val selectedAlgorithmIds: Set<String> = emptySet(),
    val isRunning: Boolean = false,
    val progressCompleted: Int = 0,
    val progressTotal: Int = 0,
    val progressCurrentName: String? = null,
    /** Every algorithm x source combination from the most recent run,
     *  flattened into one list - each row already carries its own
     *  [BenchmarkMetrics.sourceFileName], so a batch of several sources
     *  doesn't need a different shape here, just more rows. */
    val results: List<BenchmarkMetrics> = emptyList(),
    /** One [NovaResearchReport] per source that included NovaCompress in the
     *  run (only ever >1 entry when several sources were benchmarked
     *  together). */
    val researchReports: List<NovaResearchReport> = emptyList(),
    val errorMessage: String? = null,
)

class BenchmarkViewModel(
    val algorithms: List<CompressionAlgorithm>,
    private val runner: BenchmarkRunner,
    private val repository: BenchmarkRepository,
    private val applicationContext: Context,
) : ViewModel() {
    private val _uiState = MutableStateFlow(
        BenchmarkUiState(selectedAlgorithmIds = algorithms.map { it.id }.toSet())
    )
    val uiState: StateFlow<BenchmarkUiState> = _uiState.asStateFlow()

    val historyFileNames = repository.observeDistinctFileNames()
    fun historyForFile(fileName: String) = repository.observeForFile(fileName)

    /** Adds one source (e.g. a file just picked from the system file picker)
     *  to the current selection, alongside whatever is already queued.
     *
     *  Deliberately does *not* clear [BenchmarkUiState.results]/[BenchmarkUiState.researchReports]
     *  - see BENCHMARKS.md Entry 14. [NovaResearchReport] in particular is never persisted
     *  anywhere (unlike [BenchmarkMetrics], which [runBenchmark] saves via [repository]), so
     *  clearing it here as a side effect of just queuing the *next* source to test - before the
     *  person has necessarily copied out the current results - destroyed data with no way back
     *  short of re-running the whole (often slow) benchmark. Each [BenchmarkMetrics] row already
     *  carries its own `sourceFileName`, so leaving prior results on screen while new sources are
     *  queued can't produce a mislabeled result - only a stale-until-replaced one, which the next
     *  completed [runBenchmark] run naturally replaces anyway. */
    fun addSource(source: BenchmarkSource) {
        _uiState.value = _uiState.value.copy(
            sources = _uiState.value.sources + source,
            errorMessage = null,
        )
    }

    /** Adds or removes a single built-in sample from the selection, matched
     *  by reference/structural equality against whatever instance the
     *  caller passes in - the Home screen holds a `remember`-stable list of
     *  sample instances so this comparison is reliable (two *separately
     *  generated* samples aren't guaranteed `equal` since their [ByteArray]
     *  payloads compare by reference, not content).
     *
     *  See [addSource]'s KDoc for why this doesn't clear results/researchReports either. */
    fun toggleSample(sample: BenchmarkSource) {
        val current = _uiState.value.sources
        val updated = if (current.contains(sample)) current - sample else current + sample
        _uiState.value = _uiState.value.copy(sources = updated, errorMessage = null)
    }

    /** See [addSource]'s KDoc for why this doesn't clear results/researchReports either. */
    fun removeSource(source: BenchmarkSource) {
        _uiState.value = _uiState.value.copy(
            sources = _uiState.value.sources - source,
            errorMessage = null,
        )
    }

    /** Clears the queued sources for the *next* run. Still deliberately leaves the current
     *  results/researchReports alone - see [addSource]'s KDoc. If the person wants those gone
     *  too (starting completely fresh), that's a separate, explicit action to add if it turns
     *  out to be wanted - "clear my queued sources" and "discard my last results" aren't the
     *  same intent, and this method's name only ever promised the first one. */
    fun clearSources() {
        _uiState.value = _uiState.value.copy(
            sources = emptyList(),
            errorMessage = null,
        )
    }

    fun toggleAlgorithm(id: String) {
        val current = _uiState.value.selectedAlgorithmIds
        _uiState.value = _uiState.value.copy(
            selectedAlgorithmIds = if (id in current) current - id else current + id,
        )
    }

    /** Runs every selected algorithm against every selected source - one
     *  built-in sample and one real picked file behave identically here
     *  (both are just a [BenchmarkSource]), so "compress multiple built-in
     *  samples in one go" falls out of this loop for free rather than
     *  needing separate handling.
     *
     *  Drives [BenchmarkRunner.runOne] directly (rather than
     *  [BenchmarkRunner.runAll]) so that when [NovaCompressAlgorithm] is
     *  among the selected algorithms, its Stage 1-10 research report can be
     *  captured as a side effect of the *one* real compress pass already
     *  being timed and verified - via `runOne`'s `compressAction` override -
     *  instead of running NovaCompress a second time afterward just to get
     *  the report. NovaCompress is comfortably the slowest algorithm in the
     *  suite, so that used to double the cost of every benchmark run that
     *  included it.
     *
     *  Runs inside [KeepAliveService]'s foreground-priority window for the
     *  whole call - see that service's KDoc for why: a run over several
     *  sources/algorithms can take minutes, and without it, backgrounding
     *  partway through risked the process being killed and every bit of
     *  progress lost, with no way back short of starting over. See
     *  BENCHMARKS.md Entry 16. */
    fun runBenchmark(onComplete: () -> Unit) {
        val state = _uiState.value
        val sources = state.sources
        if (sources.isEmpty()) return
        val selected = algorithms.filter { it.id in state.selectedAlgorithmIds }
        if (selected.isEmpty()) return

        val totalSteps = sources.size * selected.size
        _uiState.value = state.copy(
            isRunning = true, errorMessage = null,
            progressCompleted = 0, progressTotal = totalSteps, progressCurrentName = null,
        )
        KeepAliveService.start(applicationContext)
        viewModelScope.launch(Dispatchers.Default) {
            try {
                val allResults = ArrayList<BenchmarkMetrics>(totalSteps)
                val reports = ArrayList<NovaResearchReport>()
                var stepsDoneBeforeThisSource = 0
                for (source in sources) {
                    for ((index, algorithm) in selected.withIndex()) {
                        val label = if (sources.size > 1) "${source.displayName}: ${algorithm.displayName}" else algorithm.displayName
                        val stepNumber = stepsDoneBeforeThisSource + index
                        _uiState.value = _uiState.value.copy(
                            progressCompleted = stepNumber,
                            progressTotal = totalSteps,
                            progressCurrentName = label,
                        )
                        // NotificationManagerCompat calls are thread-safe and don't require the
                        // main thread the way Compose Navigation's navigate() does (see onComplete
                        // below) - safe to call directly from this Dispatchers.Default coroutine.
                        KeepAliveService.updateProgress(applicationContext, "${stepNumber + 1}/$totalSteps: $label")

                        allResults += if (algorithm is NovaCompressAlgorithm) {
                            val nova: NovaCompressAlgorithm = algorithm
                            var report: NovaResearchReport? = null
                            val metrics = runner.runOne(source, algorithm) { input, output ->
                                report = nova.compressWithReport(input, output)
                            }
                            // Only recorded on a successful pass: if compression failed, runOne
                            // already turned that into a FAIL row above - there's nothing valid
                            // to show on the Research screen for this source either.
                            report?.let { reports += it.copy(sourceName = source.displayName) }
                            metrics
                        } else {
                            runner.runOne(source, algorithm)
                        }
                    }
                    stepsDoneBeforeThisSource += selected.size
                }

                repository.save(allResults)
                // onComplete() navigates (NavController.navigate -> LifecycleRegistry.setCurrentState),
                // which asserts main thread - this whole block was running on Dispatchers.Default.
                withContext(Dispatchers.Main) {
                    _uiState.value = _uiState.value.copy(isRunning = false, results = allResults, researchReports = reports)
                    KeepAliveService.stop(applicationContext)
                    onComplete()
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    _uiState.value = _uiState.value.copy(isRunning = false, errorMessage = e.message ?: "Benchmark failed")
                    KeepAliveService.stop(applicationContext)
                }
            }
        }
    }

    companion object {
        fun factory(container: AppContainer): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return BenchmarkViewModel(
                        container.algorithms,
                        container.benchmarkRunner,
                        container.benchmarkRepository,
                        container.applicationContext,
                    ) as T
                }
            }
    }
}
