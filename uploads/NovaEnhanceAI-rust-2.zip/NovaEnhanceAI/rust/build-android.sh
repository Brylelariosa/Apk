#!/usr/bin/env bash
# Builds the Rust core for ONE Android ABI and copies the .so to where Gradle packages it.
#
#   build-android.sh <abi> <rust-triple> <clang-prefix> <ndk-dir> <out-dir> <min-api>
#
# e.g. build-android.sh arm64-v8a aarch64-linux-android aarch64-linux-android /path/to/ndk app/build/rustJniLibs 29
#
# Called by the `buildRust*` tasks in app/build.gradle.kts. It needs `cargo` (GitHub's ubuntu runners ship it) and
# adds the Android target with rustup when the target is missing.
set -euo pipefail

ABI="$1"
TRIPLE="$2"
CLANG_PREFIX="$3"
NDK_DIR="$4"
OUT_DIR="$5"
MIN_API="${6:-29}"

CRATE_DIR="$(cd "$(dirname "$0")" && pwd)"
export PATH="$HOME/.cargo/bin:$PATH"

if ! command -v cargo >/dev/null 2>&1; then
  echo "[rust] ERROR: 'cargo' was not found on the PATH." >&2
  echo "[rust] GitHub's ubuntu-latest runners include Rust. On any other runner install it first, e.g." >&2
  echo "[rust]   curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y --profile minimal" >&2
  exit 1
fi

echo "[rust] $(cargo --version) / $(rustc --version)"

if command -v rustup >/dev/null 2>&1; then
  rustup target add "$TRIPLE" || echo "[rust] could not add target $TRIPLE - trying to build anyway"
fi

case "$(uname -s)" in
  Linux)  HOST_TAG="linux-x86_64" ;;
  Darwin) HOST_TAG="darwin-x86_64" ;;
  *)      HOST_TAG="windows-x86_64" ;;
esac

TOOLCHAIN_BIN="$NDK_DIR/toolchains/llvm/prebuilt/$HOST_TAG/bin"
LINKER="$TOOLCHAIN_BIN/${CLANG_PREFIX}${MIN_API}-clang"
if [ ! -x "$LINKER" ]; then
  echo "[rust] ERROR: NDK linker not found: $LINKER" >&2
  exit 1
fi

TRIPLE_UPPER="$(echo "$TRIPLE" | tr 'a-z-' 'A-Z_')"
export "CARGO_TARGET_${TRIPLE_UPPER}_LINKER=$LINKER"
# 16 KB page alignment: required by Android 15+ devices and harmless everywhere else.
export "CARGO_TARGET_${TRIPLE_UPPER}_RUSTFLAGS=-C link-arg=-Wl,-z,max-page-size=16384"
unset RUSTFLAGS || true

TARGET_DIR="${CARGO_TARGET_DIR:-$CRATE_DIR/target}"
cargo build --release --manifest-path "$CRATE_DIR/Cargo.toml" --target "$TRIPLE" --target-dir "$TARGET_DIR"

mkdir -p "$OUT_DIR/$ABI"
cp "$TARGET_DIR/$TRIPLE/release/libnovaenhance_native.so" "$OUT_DIR/$ABI/libnovaenhance_native.so"
echo "[rust] built $OUT_DIR/$ABI/libnovaenhance_native.so ($(wc -c < "$OUT_DIR/$ABI/libnovaenhance_native.so") bytes)"
