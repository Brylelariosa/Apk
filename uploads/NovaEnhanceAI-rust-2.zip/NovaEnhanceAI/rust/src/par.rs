//! Small, safe, dependency-free parallelism built on `std::thread::scope`.
//!
//! Work is handed out ONE JOB AT A TIME from a shared queue ("dynamic scheduling") rather than pre-split into equal
//! shares. That matters on big.LITTLE phones (2 fast + 6 slow cores): a static split finishes when the slowest core
//! finishes, whereas here the fast cores simply claim more jobs and every core stays busy until the last job is
//! taken. Jobs may borrow from the caller's stack (scoped threads), so there is no `'static` plumbing and no unsafe
//! code: row chunks are handed out as disjoint `&mut` slices.

use std::sync::Mutex;

/// Hard cap on worker threads (mirrors `ComputeBudget.MAX_NATIVE_THREADS` on the Kotlin side).
pub const MAX_THREADS: usize = 8;

/// Threads the machine offers, capped at [`MAX_THREADS`].
pub fn max_threads() -> usize {
    let n = std::thread::available_parallelism().map(|v| v.get()).unwrap_or(1);
    n.max(1).min(MAX_THREADS)
}

/// Turns a caller's request (`<= 0` means "all") into a concrete thread count.
pub fn resolve_threads(requested: i32) -> usize {
    let max = max_threads();
    if requested <= 0 {
        max
    } else {
        (requested as usize).min(max)
    }
}

/// Rows handed to one job: enough pixels (~8K) that a job is worth scheduling.
pub fn rows_per_job(width: usize) -> usize {
    (8192 / width.max(1)).max(2)
}

/// Runs `work(&mut state, job)` for every job on up to `threads` threads. Every worker owns a private state created
/// by `make_state`; the final states of all workers are returned (use them for per-thread accumulators such as
/// gradient sums or partial histograms). With one thread (or one job) everything runs inline.
pub fn run_jobs<J, S, M, W>(jobs: Vec<J>, threads: usize, make_state: M, work: W) -> Vec<S>
where
    J: Send,
    S: Send,
    M: Fn() -> S + Sync,
    W: Fn(&mut S, J) + Sync,
{
    let n = jobs.len();
    let threads = threads.max(1).min(n.max(1));
    if threads <= 1 {
        let mut state = make_state();
        for job in jobs {
            work(&mut state, job);
        }
        return vec![state];
    }
    let queue = Mutex::new(jobs.into_iter());
    let mut results: Vec<S> = Vec::with_capacity(threads);
    std::thread::scope(|scope| {
        let mut handles = Vec::with_capacity(threads);
        for _ in 0..threads {
            handles.push(scope.spawn(|| {
                let mut state = make_state();
                loop {
                    let next = {
                        let mut guard = queue.lock().unwrap();
                        guard.next()
                    };
                    match next {
                        Some(job) => work(&mut state, job),
                        None => break,
                    }
                }
                state
            }));
        }
        for handle in handles {
            results.push(handle.join().unwrap());
        }
    });
    results
}

/// Splits `data` into chunks of `chunk_len` elements and calls `f(chunk_index, chunk)` for each, in parallel.
pub fn par_chunks_mut<T, F>(data: &mut [T], chunk_len: usize, threads: usize, f: F)
where
    T: Send,
    F: Fn(usize, &mut [T]) + Sync,
{
    if data.is_empty() || chunk_len == 0 {
        return;
    }
    let jobs: Vec<(usize, &mut [T])> = data.chunks_mut(chunk_len).enumerate().collect();
    run_jobs(jobs, threads, || (), |_, (index, chunk)| f(index, chunk));
}

/// Row-oriented variant: `data` holds rows of `row_len` elements; `f(first_row, rows)` receives up to
/// `rows_per_chunk` consecutive rows (a whole number of rows, the last chunk may be shorter).
pub fn par_row_chunks_mut<T, F>(data: &mut [T], row_len: usize, rows_per_chunk: usize, threads: usize, f: F)
where
    T: Send,
    F: Fn(usize, &mut [T]) + Sync,
{
    if row_len == 0 || rows_per_chunk == 0 {
        return;
    }
    par_chunks_mut(data, row_len * rows_per_chunk, threads, |index, chunk| f(index * rows_per_chunk, chunk));
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn chunks_cover_everything_once() {
        let mut data = vec![0u32; 1000];
        par_chunks_mut(&mut data, 7, 4, |i, chunk| {
            for v in chunk.iter_mut() {
                *v += (i + 1) as u32;
            }
        });
        for (k, v) in data.iter().enumerate() {
            assert_eq!(*v, (k / 7 + 1) as u32);
        }
    }

    #[test]
    fn run_jobs_sums_all_jobs() {
        let jobs: Vec<u64> = (1..=100).collect();
        let states = run_jobs(jobs, 4, || 0u64, |s, j| *s += j);
        let total: u64 = states.iter().sum();
        assert_eq!(total, 5050);
    }

    #[test]
    fn row_chunks_report_first_row() {
        let mut data = vec![0usize; 10 * 3];
        par_row_chunks_mut(&mut data, 3, 4, 3, |first_row, rows| {
            let n = rows.len() / 3;
            for r in 0..n {
                for c in 0..3 {
                    rows[r * 3 + c] = first_row + r;
                }
            }
        });
        for r in 0..10 {
            for c in 0..3 {
                assert_eq!(data[r * 3 + c], r);
            }
        }
    }
}
