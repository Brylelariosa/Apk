//! Thin FFI to the Android NDK: logcat and `jnigraphics` (direct access to bitmap pixel memory).
//!
//! The Android-only parts are compiled for `target_os = "android"`; on any other target (host unit tests) they
//! degrade to stderr logging and "bitmaps are unavailable" errors, so the rest of the crate builds and tests on a
//! desktop machine.

use std::os::raw::{c_int, c_void};

pub const LOG_TAG: &str = "NovaEnhanceNative";

pub fn log_error(msg: &str) {
    write_log(6, msg);
}

pub fn log_info(msg: &str) {
    write_log(4, msg);
}

#[cfg(target_os = "android")]
mod android_ffi {
    use std::os::raw::{c_char, c_int, c_void};

    #[repr(C)]
    #[derive(Default, Clone, Copy)]
    pub struct AndroidBitmapInfo {
        pub width: u32,
        pub height: u32,
        pub stride: u32,
        pub format: i32,
        pub flags: u32,
    }

    #[link(name = "log")]
    extern "C" {
        pub fn __android_log_write(prio: c_int, tag: *const c_char, text: *const c_char) -> c_int;
    }

    #[link(name = "jnigraphics")]
    extern "C" {
        pub fn AndroidBitmap_getInfo(env: *mut c_void, bitmap: *mut c_void, info: *mut AndroidBitmapInfo) -> c_int;
        pub fn AndroidBitmap_lockPixels(env: *mut c_void, bitmap: *mut c_void, addr: *mut *mut c_void) -> c_int;
        pub fn AndroidBitmap_unlockPixels(env: *mut c_void, bitmap: *mut c_void) -> c_int;
    }
}

#[cfg(target_os = "android")]
fn write_log(prio: c_int, msg: &str) {
    let tag = std::ffi::CString::new(LOG_TAG).unwrap_or_default();
    let clean: String = msg.chars().filter(|c| *c != '\0').collect();
    if let Ok(text) = std::ffi::CString::new(clean) {
        unsafe {
            android_ffi::__android_log_write(prio, tag.as_ptr(), text.as_ptr());
        }
    }
}

#[cfg(not(target_os = "android"))]
fn write_log(prio: c_int, msg: &str) {
    eprintln!("[{}:{}] {}", LOG_TAG, prio, msg);
}

/// `ANDROID_BITMAP_FORMAT_RGBA_8888`: what an ARGB_8888 `Bitmap` looks like in memory (bytes R, G, B, A).
pub const BITMAP_FORMAT_RGBA_8888: i32 = 1;

/// A locked ARGB_8888 bitmap: raw pixel memory (bytes R, G, B, A per pixel, rows `stride` bytes apart), unlocked on
/// drop. Rows are handed out through raw pointers so the same bitmap may serve as source and destination (the
/// in-place enhancement mode) without ever creating overlapping Rust references.
pub struct LockedBitmap {
    env: *mut c_void,
    bitmap: *mut c_void,
    ptr: *mut u8,
    pub width: usize,
    pub height: usize,
    pub stride: usize,
}

// The pointer is plain pixel memory pinned by the lock. Callers uphold the aliasing rules: concurrent readers, or
// writers to disjoint rows.
unsafe impl Send for LockedBitmap {}
unsafe impl Sync for LockedBitmap {}

impl LockedBitmap {
    /// Locks `bitmap`. `env` is the raw `JNIEnv*`, `bitmap` the raw `jobject`.
    #[cfg(target_os = "android")]
    pub unsafe fn lock(env: *mut c_void, bitmap: *mut c_void) -> Result<LockedBitmap, String> {
        let mut info = android_ffi::AndroidBitmapInfo::default();
        if android_ffi::AndroidBitmap_getInfo(env, bitmap, &mut info) < 0 {
            return Err("could not read the bitmap info".to_string());
        }
        if info.format != BITMAP_FORMAT_RGBA_8888 {
            return Err("only ARGB_8888 / RGBA_8888 bitmaps are supported".to_string());
        }
        let mut addr: *mut c_void = std::ptr::null_mut();
        if android_ffi::AndroidBitmap_lockPixels(env, bitmap, &mut addr) < 0 || addr.is_null() {
            return Err("could not lock the bitmap pixels (recycled or hardware bitmap?)".to_string());
        }
        Ok(LockedBitmap {
            env,
            bitmap,
            ptr: addr as *mut u8,
            width: info.width as usize,
            height: info.height as usize,
            stride: info.stride as usize,
        })
    }

    #[cfg(not(target_os = "android"))]
    pub unsafe fn lock(_env: *mut c_void, _bitmap: *mut c_void) -> Result<LockedBitmap, String> {
        Err("bitmaps are only available on Android".to_string())
    }

    #[cfg(target_os = "android")]
    fn unlock(&self) {
        unsafe {
            android_ffi::AndroidBitmap_unlockPixels(self.env, self.bitmap);
        }
    }

    #[cfg(not(target_os = "android"))]
    fn unlock(&self) {}

    /// The whole pixel buffer (`stride * height` bytes) as a read-only slice.
    ///
    /// # Safety
    /// No `&mut` view of the same memory may be alive while the returned slice is used.
    pub unsafe fn bytes(&self) -> &[u8] {
        std::slice::from_raw_parts(self.ptr as *const u8, self.stride * self.height)
    }

    /// The whole pixel buffer as a mutable slice.
    ///
    /// # Safety
    /// No other view of the same memory may be alive while the returned slice is used.
    #[allow(clippy::mut_from_ref)]
    pub unsafe fn bytes_mut(&self) -> &mut [u8] {
        std::slice::from_raw_parts_mut(self.ptr, self.stride * self.height)
    }

    /// Row `y` (width * 4 bytes) as a read-only slice.
    ///
    /// # Safety
    /// Same rule as [`LockedBitmap::bytes`].
    pub unsafe fn row(&self, y: usize) -> &[u8] {
        std::slice::from_raw_parts(self.ptr.add(y * self.stride) as *const u8, self.width * 4)
    }

    /// Row `y` as a mutable slice.
    ///
    /// # Safety
    /// Same rule as [`LockedBitmap::bytes_mut`].
    #[allow(clippy::mut_from_ref)]
    pub unsafe fn row_mut(&self, y: usize) -> &mut [u8] {
        std::slice::from_raw_parts_mut(self.ptr.add(y * self.stride), self.width * 4)
    }

    /// Address of the pixel memory (used to detect "source and destination are the same bitmap").
    pub fn address(&self) -> usize {
        self.ptr as usize
    }
}

impl Drop for LockedBitmap {
    fn drop(&mut self) {
        self.unlock();
    }
}
