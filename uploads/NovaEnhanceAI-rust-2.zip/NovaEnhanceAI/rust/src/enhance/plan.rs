//! The PLAN turns the user's options plus the scene analysis into everything the band processor needs that is global
//! to the photo: white-balance gains, the tone curve (levels / exposure / contrast), the CLAHE tile curves, and the
//! low-resolution maps that drive the local techniques (shadows / highlights, clarity, low-light, dehaze).
//!
//! The maps live at thumbnail resolution (<= 320 px) and are sampled with bilinear interpolation at full resolution,
//! so a "large radius" local adjustment costs a few bytes of memory instead of a full-size blurred copy, needs no
//! context rows, and is exactly identical whatever band split is used.
//!
//! "Auto" mode: every technique the user left at 0 is switched on to the amount the analysis suggests; anything the
//! user set explicitly always wins.

use super::analysis::{percentile_bin, Analysis};
use super::options::Options;
use crate::img::blur::{gaussian_plane, guided_filter, min_filter};
use crate::img::{clampf, luma};

pub const TONE_LUT_SIZE: usize = 1024;

/// Resolved strength of every technique (0 = off).
#[derive(Clone, Debug, Default)]
pub struct Amounts {
    pub white_balance: f32,
    pub auto_levels: f32,
    pub exposure: f32,
    pub contrast: f32,
    pub shadows: f32,
    pub highlights: f32,
    pub clahe: f32,
    pub low_light: f32,
    pub dehaze: f32,
    pub vibrance: f32,
    pub clarity: f32,
    pub detail: f32,
    pub denoise: f32,
    pub despike: f32,
    pub deband: f32,
    pub deblur: f32,
    pub vignette: f32,
}

impl Amounts {
    fn from_options(o: &Options) -> Amounts {
        Amounts {
            white_balance: o.white_balance,
            auto_levels: o.auto_levels,
            exposure: o.exposure,
            contrast: o.contrast,
            shadows: o.shadows,
            highlights: o.highlights,
            clahe: o.clahe,
            low_light: o.low_light,
            dehaze: o.dehaze,
            vibrance: o.vibrance,
            clarity: o.clarity,
            detail: o.detail,
            denoise: o.denoise,
            despike: o.despike,
            deband: o.deband,
            deblur: o.deblur,
            vignette: o.vignette,
        }
    }

    /// Takes the auto value for every field the user left at 0.
    fn fill_unset(&mut self, auto: &Amounts) {
        fn fill(dst: &mut f32, auto: f32) {
            if *dst == 0.0 {
                *dst = auto;
            }
        }
        fill(&mut self.white_balance, auto.white_balance);
        fill(&mut self.auto_levels, auto.auto_levels);
        fill(&mut self.exposure, auto.exposure);
        fill(&mut self.contrast, auto.contrast);
        fill(&mut self.shadows, auto.shadows);
        fill(&mut self.highlights, auto.highlights);
        fill(&mut self.clahe, auto.clahe);
        fill(&mut self.low_light, auto.low_light);
        fill(&mut self.dehaze, auto.dehaze);
        fill(&mut self.vibrance, auto.vibrance);
        fill(&mut self.clarity, auto.clarity);
        fill(&mut self.detail, auto.detail);
        fill(&mut self.denoise, auto.denoise);
        fill(&mut self.despike, auto.despike);
        fill(&mut self.deband, auto.deband);
        fill(&mut self.deblur, auto.deblur);
        fill(&mut self.vignette, auto.vignette);
    }
}

/// What the analysis says about the picture.
#[derive(Clone, Debug)]
pub struct SceneStats {
    pub mean_luma: f32, // 0..1
    pub std_luma: f32,  // 0..1
    pub p_lo: f32,      // 0..1, 0.4th percentile of luma
    pub p_hi: f32,      // 0..1, 99.6th percentile
    pub dark_frac: f32,
    pub bright_frac: f32,
    /// Fraction of empty histogram bins inside the 5..95 percentile range (large = posterised / banded).
    pub banding: f32,
    /// max/min of the mean R, G, B (1.0 = neutral).
    pub cast_ratio: f32,
    pub wb_gains_full: [f32; 3],
    pub sat_mean: f32,
    /// Mean dark channel, 0..1 (large = hazy).
    pub haze: f32,
}

fn thumb_luma(an: &Analysis) -> Vec<f32> {
    let n = an.tw * an.th;
    let mut y = vec![0.0f32; n];
    for i in 0..n {
        y[i] = luma(an.thumb[i * 3], an.thumb[i * 3 + 1], an.thumb[i * 3 + 2]);
    }
    y
}

fn dark_channel(an: &Analysis, radius: usize) -> Vec<f32> {
    let n = an.tw * an.th;
    let mut dark = vec![0.0f32; n];
    for i in 0..n {
        dark[i] = an.thumb[i * 3].min(an.thumb[i * 3 + 1]).min(an.thumb[i * 3 + 2]);
    }
    min_filter(&dark, an.tw, an.th, radius)
}

fn scene_stats(an: &Analysis) -> SceneStats {
    let total: f64 = an.luma_hist.iter().map(|v| *v as f64).sum::<f64>().max(1.0);
    let mut mean = 0.0f64;
    for i in 0..256 {
        mean += (i as f64 / 255.0) * an.luma_hist[i] as f64;
    }
    mean /= total;
    let mut var = 0.0f64;
    for i in 0..256 {
        let d = i as f64 / 255.0 - mean;
        var += d * d * an.luma_hist[i] as f64;
    }
    var /= total;

    let p_lo = percentile_bin(&an.luma_hist, 0.004) as f32 / 255.0;
    let p_hi = percentile_bin(&an.luma_hist, 0.996) as f32 / 255.0;
    let dark: f64 = an.luma_hist[..40].iter().map(|v| *v as f64).sum();
    let bright: f64 = an.luma_hist[236..].iter().map(|v| *v as f64).sum();

    // Banding / posterisation: gaps in the histogram of a large picture.
    let mut banding = 0.0f32;
    if an.pixels >= 200_000 {
        let lo5 = percentile_bin(&an.luma_hist, 0.05);
        let hi95 = percentile_bin(&an.luma_hist, 0.95);
        if hi95 >= lo5 + 40 {
            let mut empty = 0usize;
            for i in lo5..=hi95 {
                if an.luma_hist[i] == 0 {
                    empty += 1;
                }
            }
            banding = empty as f32 / (hi95 - lo5 + 1) as f32;
        }
    }

    // Grey-world white balance on the thumbnail, ignoring near-black and near-white pixels.
    let n = an.tw * an.th;
    let (mut sr, mut sg, mut sb, mut cnt) = (0.0f64, 0.0f64, 0.0f64, 0.0f64);
    let (mut sat_sum, mut sat_cnt) = (0.0f64, 0.0f64);
    for i in 0..n {
        let (r, g, b) = (an.thumb[i * 3], an.thumb[i * 3 + 1], an.thumb[i * 3 + 2]);
        let y = luma(r, g, b);
        let mx = r.max(g).max(b);
        let mn = r.min(g).min(b);
        if mx > 10.0 {
            sat_sum += ((mx - mn) / mx) as f64;
            sat_cnt += 1.0;
        }
        if y > 20.0 && mx < 245.0 {
            sr += r as f64;
            sg += g as f64;
            sb += b as f64;
            cnt += 1.0;
        }
    }
    let (mut gains, mut cast_ratio) = ([1.0f32, 1.0, 1.0], 1.0f32);
    if cnt >= 100.0 {
        let (mr, mg, mb) = ((sr / cnt) as f32, (sg / cnt) as f32, (sb / cnt) as f32);
        if mr > 1.0 && mg > 1.0 && mb > 1.0 {
            let gray = (mr + mg + mb) / 3.0;
            let mut g3 = [
                clampf(gray / mr, 0.7, 1.43),
                clampf(gray / mg, 0.7, 1.43),
                clampf(gray / mb, 0.7, 1.43),
            ];
            let k = 0.299 * g3[0] + 0.587 * g3[1] + 0.114 * g3[2];
            for c in 0..3 {
                g3[c] /= k;
            }
            gains = g3;
            cast_ratio = mr.max(mg).max(mb) / mr.min(mg).min(mb);
        }
    }

    let dc = dark_channel(an, 2);
    let haze = if dc.is_empty() { 0.0 } else { dc.iter().sum::<f32>() / dc.len() as f32 / 255.0 };

    SceneStats {
        mean_luma: mean as f32,
        std_luma: var.sqrt() as f32,
        p_lo,
        p_hi,
        dark_frac: (dark / total) as f32,
        bright_frac: (bright / total) as f32,
        banding,
        cast_ratio,
        wb_gains_full: gains,
        sat_mean: if sat_cnt > 0.0 { (sat_sum / sat_cnt) as f32 } else { 0.0 },
        haze,
    }
}

/// What "Auto Enhance" switches on. Heuristics tuned to be conservative: a good photo gets only a light touch.
fn auto_amounts(st: &SceneStats, an: &Analysis) -> Amounts {
    let mut a = Amounts::default();
    if an.noise_sigma > 1.5 {
        a.denoise = clampf((an.noise_sigma - 1.5) / 8.0, 0.25, 1.0);
    }
    if an.spike_rate > 2e-5 {
        a.despike = clampf(an.spike_rate * 2e4, 0.3, 1.0);
    }
    if an.grad_p95 > 0.0 && an.grad_p95 < 16.0 {
        a.deblur = clampf((16.0 - an.grad_p95) / 16.0, 0.25, 0.7);
    }
    if st.cast_ratio > 1.10 {
        a.white_balance = clampf((st.cast_ratio - 1.06) / 0.25, 0.0, 0.85);
    }
    let span = st.p_hi - st.p_lo;
    if span < 0.85 {
        a.auto_levels = clampf((0.92 - span) / 0.5, 0.2, 0.9);
    }
    let m = st.mean_luma;
    if m < 0.30 {
        a.low_light = clampf((0.34 - m) / 0.20, 0.25, 1.0);
    } else if (m - 0.45).abs() > 0.08 {
        a.exposure = clampf((0.45 - m) * 2.0, -0.6, 0.6);
    }
    if st.dark_frac > 0.25 && m >= 0.30 {
        a.shadows = 0.4;
    }
    if st.bright_frac > 0.04 {
        a.highlights = 0.4;
    }
    if st.haze > 0.28 {
        a.dehaze = clampf((st.haze - 0.2) / 0.4, 0.2, 0.8);
    }
    if st.std_luma < 0.20 {
        a.clahe = 0.35;
    }
    if st.std_luma < 0.17 {
        a.contrast = clampf((0.20 - st.std_luma) * 4.0, 0.0, 0.5);
    }
    a.vibrance = if st.sat_mean < 0.30 { 0.3 } else { 0.15 };
    a.clarity = 0.15;
    if an.noise_sigma < 2.0 {
        a.detail = 0.2;
    }
    if st.banding > 0.12 {
        a.deband = 0.5;
    }
    a
}

/// Everything global that the band processor needs.
pub struct Plan {
    pub img_w: usize,
    pub img_h: usize,
    pub block: usize,
    pub tw: usize,
    pub th: usize,

    pub amounts: Amounts,
    /// Saturation boost (factor 1 + value), from the colour-restoration slider.
    pub saturation: f32,
    pub noise_sigma: f32,

    pub wb_gains: [f32; 3],
    pub wb_active: bool,
    /// `TONE_LUT_SIZE` entries mapping 0..255 -> 0..255 (levels, exposure, contrast); empty = identity.
    pub tone_lut: Vec<f32>,
    /// Edge-aware blurred luminance at thumbnail resolution (shadows / highlights, clarity, low-light); may be empty.
    pub base_map: Vec<f32>,
    /// `tiles_x * tiles_y * 256` CLAHE curves (luma level -> equalised level); empty when CLAHE is off.
    pub clahe_lut: Vec<f32>,
    pub tiles_x: usize,
    pub tiles_y: usize,
    /// Atmospheric light and per-pixel transmission (thumbnail resolution); empty when dehaze is off.
    pub haze_a: [f32; 3],
    pub haze_t: Vec<f32>,
    /// Add a hair of dither when writing 8-bit (hides banding the tone curves would otherwise introduce).
    pub dither: bool,
    pub summary: String,
}

fn build_tone_lut(a: &Amounts, p_lo: f32, p_hi: f32) -> Vec<f32> {
    if !(a.auto_levels > 0.0 || a.exposure != 0.0 || a.contrast != 0.0) {
        return Vec::new();
    }
    let lo = (p_lo * a.auto_levels).min(0.35);
    let hi = 1.0 - ((1.0 - p_hi) * a.auto_levels).min(0.35);
    let span = (hi - lo).max(0.25);
    let gamma = 2.0f32.powf(-a.exposure * 0.9); // exposure > 0 -> gamma < 1 -> brighter
    let k = clampf(a.contrast, -0.9, 0.9);
    let two_pi = 2.0 * std::f32::consts::PI;
    let mut lut = vec![0.0f32; TONE_LUT_SIZE];
    for i in 0..TONE_LUT_SIZE {
        let x = i as f32 / (TONE_LUT_SIZE - 1) as f32;
        let x1 = clampf((x - lo) / span, 0.0, 1.0);
        let x2 = x1.powf(gamma);
        // Symmetric, monotone S-curve: f(0) = 0, f(1) = 1, slope 1 + k at the middle and 1 - k at the ends.
        let x3 = x2 - k * (two_pi * x2).sin() / two_pi;
        lut[i] = clampf(x3, 0.0, 1.0) * 255.0;
    }
    lut
}

/// Per-tile equalisation curves with a clip limit (CLAHE).
fn build_clahe(an: &Analysis) -> Vec<f32> {
    let tiles = an.tiles_x * an.tiles_y;
    let mut lut = vec![0.0f32; tiles * 256];
    for t in 0..tiles {
        let hist = &an.tile_hist[t * 256..(t + 1) * 256];
        let total: f32 = hist.iter().map(|v| *v as f32).sum();
        let out = &mut lut[t * 256..(t + 1) * 256];
        if total < 1.0 {
            for i in 0..256 {
                out[i] = i as f32;
            }
            continue;
        }
        let limit = (3.0 * total / 256.0).max(1.0);
        let mut h = [0.0f32; 256];
        let mut excess = 0.0f32;
        for i in 0..256 {
            let v = hist[i] as f32;
            if v > limit {
                excess += v - limit;
                h[i] = limit;
            } else {
                h[i] = v;
            }
        }
        let add = excess / 256.0;
        let mut acc = 0.0f32;
        for i in 0..256 {
            acc += h[i] + add;
            out[i] = acc / total * 255.0;
        }
    }
    lut
}

/// Dark-channel-prior dehazing: atmospheric light and a refined transmission map at thumbnail resolution.
fn build_dehaze(an: &Analysis, tl: &[f32], amount: f32, threads: usize) -> ([f32; 3], Vec<f32>) {
    let n = an.tw * an.th;
    let dc = dark_channel(an, 2);

    // Atmospheric light: the brightest pixel among the 0.5% with the highest dark channel.
    let mut order: Vec<usize> = (0..n).collect();
    order.sort_by(|a, b| dc[*b].partial_cmp(&dc[*a]).unwrap_or(std::cmp::Ordering::Equal));
    let top = (n / 200).max(1).min(n);
    let mut best = order[0];
    let mut best_sum = -1.0f32;
    for &i in order[..top].iter() {
        let s = an.thumb[i * 3] + an.thumb[i * 3 + 1] + an.thumb[i * 3 + 2];
        if s > best_sum {
            best_sum = s;
            best = i;
        }
    }
    let a = [
        clampf(an.thumb[best * 3], 120.0, 250.0),
        clampf(an.thumb[best * 3 + 1], 120.0, 250.0),
        clampf(an.thumb[best * 3 + 2], 120.0, 250.0),
    ];

    // Transmission estimate: t = 1 - omega * dark_channel(I / A).
    let mut ratio = vec![0.0f32; n];
    for i in 0..n {
        let r = an.thumb[i * 3] / a[0];
        let g = an.thumb[i * 3 + 1] / a[1];
        let b = an.thumb[i * 3 + 2] / a[2];
        ratio[i] = r.min(g).min(b);
    }
    let mdc = min_filter(&ratio, an.tw, an.th, 2);
    let mut t0 = vec![0.0f32; n];
    for i in 0..n {
        t0[i] = clampf(1.0 - 0.95 * mdc[i], 0.1, 1.0);
    }

    // Refine with a guided filter (the luminance is the guide), so transmission follows real edges.
    let guide: Vec<f32> = tl.iter().map(|v| v / 255.0).collect();
    let max_dim = an.tw.max(an.th);
    let radius = ((max_dim as f32 * 0.03) as usize).max(3);
    let mut t = guided_filter(&guide, &t0, an.tw, an.th, radius, 1e-3, threads);

    for v in t.iter_mut() {
        let blended = 1.0 - amount * (1.0 - clampf(*v, 0.0, 1.0));
        *v = blended.max(0.3);
    }
    (a, t)
}

impl Plan {
    pub fn build(opts: &Options, an: &Analysis, threads: usize) -> Plan {
        let st = scene_stats(an);
        let tl = thumb_luma(an);

        let mut amounts = Amounts::from_options(opts);
        if opts.auto {
            let auto = auto_amounts(&st, an);
            amounts.fill_unset(&auto);
        }

        // White balance: blend the full gains toward neutral by the amount, keep luminance.
        let mut wb_gains = [1.0f32, 1.0, 1.0];
        let wb_active = amounts.white_balance > 0.0 && st.cast_ratio > 1.005;
        if wb_active {
            for c in 0..3 {
                wb_gains[c] = st.wb_gains_full[c].powf(amounts.white_balance);
            }
            let k = 0.299 * wb_gains[0] + 0.587 * wb_gains[1] + 0.114 * wb_gains[2];
            for c in 0..3 {
                wb_gains[c] /= k;
            }
        }

        let tone_lut = build_tone_lut(&amounts, st.p_lo, st.p_hi);

        let needs_base = amounts.shadows > 0.0 || amounts.highlights > 0.0 || amounts.clarity > 0.0 || amounts.low_light > 0.0;
        let mut base_map = Vec::new();
        if needs_base {
            let max_dim = an.tw.max(an.th);
            let r = ((max_dim as f32 * 0.025) as usize).max(2);
            let gf = guided_filter(&tl, &tl, an.tw, an.th, r, 18.0 * 18.0, threads);
            let mut smooth = vec![0.0f32; an.tw * an.th];
            gaussian_plane(&gf, &mut smooth, an.tw, an.th, 1.5, threads);
            base_map = smooth;
        }

        let clahe_lut = if amounts.clahe > 0.0 { build_clahe(an) } else { Vec::new() };

        let mut haze_a = [255.0f32; 3];
        let mut haze_t = Vec::new();
        if amounts.dehaze > 0.0 {
            let (a, t) = build_dehaze(an, &tl, amounts.dehaze, threads);
            haze_a = a;
            haze_t = t;
        }

        let dither = !tone_lut.is_empty()
            || wb_active
            || amounts.clahe > 0.0
            || amounts.low_light > 0.0
            || amounts.dehaze > 0.0
            || amounts.deband > 0.0
            || amounts.shadows > 0.0
            || amounts.highlights > 0.0;

        let summary = format!(
            "{}x{} noise={:.1} gradP95={:.0} spikes={:.5} mean={:.2} std={:.2} cast={:.2} haze={:.2} sat={:.2} | auto={} wb={:.2} levels={:.2} exp={:.2} contrast={:.2} shadows={:.2} highlights={:.2} clahe={:.2} lowlight={:.2} dehaze={:.2} vibrance={:.2} clarity={:.2} detail={:.2} denoise={:.2} despike={:.2} deband={:.2} deblur={:.2}",
            an.w,
            an.h,
            an.noise_sigma,
            an.grad_p95,
            an.spike_rate,
            st.mean_luma,
            st.std_luma,
            st.cast_ratio,
            st.haze,
            st.sat_mean,
            opts.auto,
            amounts.white_balance,
            amounts.auto_levels,
            amounts.exposure,
            amounts.contrast,
            amounts.shadows,
            amounts.highlights,
            amounts.clahe,
            amounts.low_light,
            amounts.dehaze,
            amounts.vibrance,
            amounts.clarity,
            amounts.detail,
            amounts.denoise,
            amounts.despike,
            amounts.deband,
            amounts.deblur,
        );

        Plan {
            img_w: an.w,
            img_h: an.h,
            block: an.block,
            tw: an.tw,
            th: an.th,
            amounts,
            saturation: opts.color_restoration,
            noise_sigma: an.noise_sigma,
            wb_gains,
            wb_active,
            tone_lut,
            base_map,
            clahe_lut,
            tiles_x: an.tiles_x,
            tiles_y: an.tiles_y,
            haze_a,
            haze_t,
            dither,
            summary,
        }
    }

    /// Bilinearly samples a thumbnail-resolution `map` along image row `y_abs` into `out` (one value per column).
    pub fn sample_map_row(&self, map: &[f32], y_abs: usize, out: &mut [f32]) {
        sample_map_row(map, self.tw, self.th, self.block, y_abs, out);
    }
}

/// Bilinear sample of a `tw x th` map whose pixels each cover `block x block` source pixels, along image row `y_abs`.
pub fn sample_map_row(map: &[f32], tw: usize, th: usize, block: usize, y_abs: usize, out: &mut [f32]) {
    let b = block as f32;
    let fy = clampf((y_abs as f32 + 0.5) / b - 0.5, 0.0, (th - 1) as f32);
    let y0 = fy.floor() as usize;
    let y1 = (y0 + 1).min(th - 1);
    let wy = fy - y0 as f32;
    let r0 = &map[y0 * tw..(y0 + 1) * tw];
    let r1 = &map[y1 * tw..(y1 + 1) * tw];
    for x in 0..out.len() {
        let fx = clampf((x as f32 + 0.5) / b - 0.5, 0.0, (tw - 1) as f32);
        let x0 = fx.floor() as usize;
        let x1 = (x0 + 1).min(tw - 1);
        let wx = fx - x0 as f32;
        let top = r0[x0] + (r0[x1] - r0[x0]) * wx;
        let bottom = r1[x0] + (r1[x1] - r1[x0]) * wx;
        out[x] = top + (bottom - top) * wy;
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::enhance::analysis::{analyze, VecImage};
    use crate::enhance::options::{Options, AUTO, OPTIONS_LEN};

    fn flat_image(w: usize, h: usize, rgb: [u8; 3]) -> VecImage {
        let mut px = vec![255u8; w * h * 4];
        for i in 0..w * h {
            px[i * 4] = rgb[0];
            px[i * 4 + 1] = rgb[1];
            px[i * 4 + 2] = rgb[2];
        }
        VecImage { w, h, px }
    }

    #[test]
    fn tone_lut_is_identity_without_techniques_and_monotone_with_them() {
        let a = Amounts::default();
        assert!(build_tone_lut(&a, 0.0, 1.0).is_empty());
        let a = Amounts { contrast: 0.5, exposure: 0.4, auto_levels: 0.6, ..Amounts::default() };
        let lut = build_tone_lut(&a, 0.05, 0.9);
        assert_eq!(lut.len(), TONE_LUT_SIZE);
        for i in 1..lut.len() {
            assert!(lut[i] + 1e-3 >= lut[i - 1], "not monotone at {}", i);
        }
        assert!(lut[0] >= 0.0 && lut[lut.len() - 1] <= 255.0);
    }

    #[test]
    fn auto_mode_corrects_a_colour_cast_and_dark_exposure() {
        let img = flat_image(400, 300, [30, 20, 60]);
        let an = analyze(&img, 2);
        let mut a = vec![0.0f32; OPTIONS_LEN];
        a[AUTO] = 1.0;
        let plan = Plan::build(&Options::from_slice(&a), &an, 2);
        assert!(plan.amounts.low_light > 0.0, "dark picture should switch low-light on");
        assert!(plan.wb_active, "blue-ish cast should switch white balance on");
        assert!(plan.wb_gains[0] > plan.wb_gains[2], "red should be boosted relative to blue");
    }

    #[test]
    fn user_values_win_over_auto() {
        let img = flat_image(400, 300, [30, 20, 60]);
        let an = analyze(&img, 2);
        let mut a = vec![0.0f32; OPTIONS_LEN];
        a[AUTO] = 1.0;
        a[crate::enhance::options::LOW_LIGHT] = 0.123;
        let plan = Plan::build(&Options::from_slice(&a), &an, 2);
        assert!((plan.amounts.low_light - 0.123).abs() < 1e-6);
    }

    #[test]
    fn map_sampling_reproduces_a_constant() {
        let map = vec![42.0f32; 5 * 4];
        let mut out = vec![0.0f32; 37];
        sample_map_row(&map, 5, 4, 8, 13, &mut out);
        for v in out {
            assert!((v - 42.0).abs() < 1e-4);
        }
    }
}
