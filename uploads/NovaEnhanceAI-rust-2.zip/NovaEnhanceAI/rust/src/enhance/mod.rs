//! The photo-enhancement pipeline.
//!
//! ```text
//!  open:    analyze (one streaming read-only pass: thumbnail, histograms, noise/blur estimates)
//!             -> plan (auto-enhance decisions, tone curve, CLAHE curves, low-resolution maps)
//!  band k:  load rows (+ context) -> CNN -> hot pixels -> artifact removal -> denoise -> deband -> deblur
//!             -> tone/colour pass -> detail -> sharpen -> write rows
//! ```
//!
//! Every stage works on a bounded band of the photo, so peak native memory does not grow with the photo's size.

pub mod analysis;
pub mod deblur;
pub mod denoise;
pub mod options;
pub mod plan;
pub mod session;
pub mod tone;
