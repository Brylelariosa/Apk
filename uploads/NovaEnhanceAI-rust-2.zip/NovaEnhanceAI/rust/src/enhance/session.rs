//! An enhancement SESSION: the analysed, planned state of one photo, and the band processor that turns source rows
//! into enhanced rows.
//!
//! Memory: a band is loaded as floats (12 bytes per pixel), processed through the stages and written straight back
//! as bytes. The band's size is capped by `max_band_pixels` (rows are split internally if the caller asks for more),
//! so the working set is a few band-sized buffers regardless of the photo's resolution, and the Java heap is not
//! involved at all.
//!
//! In-place mode: the destination may be the SOURCE bitmap, which saves a whole photo-sized bitmap in batch jobs.
//! The rows above a band must then still be seen in their ORIGINAL form (they are context for the band's filters),
//! so the session keeps a small copy ("carry", at most `context_rows` rows) of the original rows it is about to
//! overwrite. Bands must then arrive strictly top to bottom.

use std::sync::Mutex;

use super::analysis::{analyze, PixelSource};
use super::options::Options;
use super::plan::Plan;
use super::{deblur, denoise, tone};
use crate::filters::restore::{restore_artifacts, RESTORE_RADIUS};
use crate::filters::sharpen::smart_sharpen;
use crate::img::{clampf, to_byte};
use crate::nn::weights::PackedWeights;
use crate::nn::{infer, RECEPTIVE_FIELD_RADIUS, TOTAL_PARAMS};
use crate::par::{par_row_chunks_mut, rows_per_job, run_jobs};

/// Default cap on pixels (band + context rows) processed at once: ~10 MB per float buffer.
pub const DEFAULT_MAX_BAND_PIXELS: usize = 800_000;

/// A bitmap-like thing rows can be read from and written to. Writes take `&self` because the real implementation
/// writes through raw pixel memory (rows are disjoint between callers).
pub trait RowIo: PixelSource {
    fn write_row(&self, y: usize, data: &[u8]);
}

struct Carry {
    /// First row of the original rows kept in `data`.
    start_row: usize,
    /// Next row the in-place mode expects to be asked for.
    next_row: usize,
    /// Original RGBA rows `[start_row, next_row)`.
    data: Vec<u8>,
}

pub struct Session {
    w: usize,
    h: usize,
    opts: Options,
    plan: Plan,
    weights: Option<PackedWeights>,
    halo: usize,
    max_band_pixels: usize,
    carry: Mutex<Carry>,
}

/// Real context rows a band needs above and below it: the sum of the reaches of every active neighbourhood stage.
fn compute_halo(opts: &Options, plan: &Plan, has_cnn: bool) -> usize {
    let a = &plan.amounts;
    let mut halo = 0usize;
    if has_cnn {
        halo += RECEPTIVE_FIELD_RADIUS;
    }
    if a.despike > 0.0 {
        halo += denoise::DESPIKE_REACH;
    }
    if opts.noise_reduction > 0.0 {
        halo += RESTORE_RADIUS;
    }
    if a.denoise > 0.0 {
        halo += denoise::denoise_reach(a.denoise);
    }
    if a.deband > 0.0 {
        halo += denoise::deband_reach(a.deband);
    }
    if a.deblur > 0.0 {
        halo += deblur::deblur_reach(a.deblur);
    }
    if a.detail > 0.0 {
        halo += deblur::DETAIL_REACH;
    }
    if opts.upscale_factor == 1 && opts.sharpen.enabled() {
        halo += opts.sharpen.reach_rows();
    }
    halo
}

/// Position-hash triangular-ish noise in (-0.5, 0.5) for each channel: dither that does not need any state.
fn dither_noise(x: usize, y: usize) -> (f32, f32, f32) {
    let mut h = (x as u32).wrapping_mul(0x9E37_79B1) ^ (y as u32).wrapping_mul(0x85EB_CA77);
    h ^= h >> 15;
    h = h.wrapping_mul(0x2C1B_3C6D);
    h ^= h >> 12;
    h = h.wrapping_mul(0x297A_2D39);
    h ^= h >> 15;
    let n = |bits: u32| ((bits & 0x3FF) as f32) / 1023.0 - 0.5;
    (n(h), n(h >> 10), n(h >> 20))
}

impl Session {
    /// Analyses `src` (read-only) and builds the plan. `params` are the CNN weights (`TOTAL_PARAMS` floats) or
    /// `None` to skip the CNN stage.
    pub fn open(
        src: &dyn PixelSource,
        options: &[f32],
        params: Option<&[f32]>,
        max_band_pixels: usize,
        threads: usize,
    ) -> Session {
        let opts = Options::from_slice(options);
        let weights = match params {
            Some(p) if p.len() >= TOTAL_PARAMS && opts.strength > 0.0 => Some(PackedWeights::pack(p, false)),
            _ => None,
        };
        let an = analyze(src, threads);
        let plan = Plan::build(&opts, &an, threads);
        let halo = compute_halo(&opts, &plan, weights.is_some());
        Session {
            w: an.w,
            h: an.h,
            opts,
            plan,
            weights,
            halo,
            max_band_pixels: max_band_pixels.max(50_000),
            carry: Mutex::new(Carry { start_row: 0, next_row: 0, data: Vec::new() }),
        }
    }

    pub fn width(&self) -> usize {
        self.w
    }

    pub fn height(&self) -> usize {
        self.h
    }

    /// Rows of real context a band reads above and below its own rows.
    pub fn context_rows(&self) -> usize {
        self.halo
    }

    /// Changes the cap on pixels processed at once (band + context rows).
    pub fn set_max_band_pixels(&mut self, max_band_pixels: usize) {
        self.max_band_pixels = max_band_pixels.max(50_000);
    }

    /// One line describing what the analysis found and which techniques are on.
    pub fn summary(&self) -> &str {
        &self.plan.summary
    }

    /// Enhances source rows `[y0, y1)` into `dst`. With `in_place` the destination IS the source bitmap and bands
    /// must be requested top to bottom without gaps.
    pub fn process_rows(
        &self,
        src: &dyn RowIo,
        dst: &dyn RowIo,
        y0: usize,
        y1: usize,
        in_place: bool,
        threads: usize,
    ) -> Result<(), String> {
        if src.width() != self.w || src.height() != self.h || dst.width() != self.w || dst.height() != self.h {
            return Err("the bitmaps do not have the size the session was opened with".to_string());
        }
        if y0 > y1 || y1 > self.h {
            return Err(format!("row range {}..{} is outside 0..{}", y0, y1, self.h));
        }
        let max_rows = (self.max_band_pixels / self.w.max(1)).max(2 * self.halo + 16);
        let core = (max_rows - 2 * self.halo).max(8);
        let mut c0 = y0;
        while c0 < y1 {
            let c1 = (c0 + core).min(y1);
            self.process_chunk(src, dst, c0, c1, in_place, threads)?;
            c0 = c1;
        }
        Ok(())
    }

    fn process_chunk(
        &self,
        src: &dyn RowIo,
        dst: &dyn RowIo,
        c0: usize,
        c1: usize,
        in_place: bool,
        threads: usize,
    ) -> Result<(), String> {
        let (w, h) = (self.w, self.h);
        let r0 = c0.saturating_sub(self.halo);
        let r1 = (c1 + self.halo).min(h);
        let bh = r1 - r0;
        let rpj = rows_per_job(w);

        let mut guard = if in_place { Some(self.carry.lock().unwrap_or_else(|e| e.into_inner())) } else { None };
        if let Some(g) = guard.as_ref() {
            if c0 != g.next_row {
                return Err(format!(
                    "in-place bands must be processed top to bottom without gaps (expected row {}, got {})",
                    g.next_row, c0
                ));
            }
        }

        // 1) Load rows [r0, r1) as floats. In in-place mode the rows above c0 are already overwritten in the
        //    bitmap; their originals come from the carry.
        let mut band = vec![0.0f32; w * bh * 3];
        {
            let carry_ref: Option<(&[u8], usize)> = guard.as_ref().map(|g| (g.data.as_slice(), g.start_row));
            par_row_chunks_mut(&mut band, w * 3, rpj, threads, |first_row, chunk| {
                let rows_n = chunk.len() / (w * 3);
                for ry in 0..rows_n {
                    let y = r0 + first_row + ry;
                    let row: &[u8] = match carry_ref {
                        Some((data, start)) if y < c0 => &data[(y - start) * w * 4..(y - start + 1) * w * 4],
                        _ => src.row(y),
                    };
                    let out = &mut chunk[ry * w * 3..(ry + 1) * w * 3];
                    for x in 0..w {
                        out[x * 3] = row[x * 4] as f32;
                        out[x * 3 + 1] = row[x * 4 + 1] as f32;
                        out[x * 3 + 2] = row[x * 4 + 2] as f32;
                    }
                }
            });
        }

        // 2) In-place: remember the original rows the NEXT band will need as context, before they are overwritten.
        let new_start = c1.saturating_sub(self.halo);
        let mut new_carry: Vec<u8> = Vec::new();
        if let Some(g) = guard.as_ref() {
            new_carry.reserve((c1 - new_start) * w * 4);
            for y in new_start..c1 {
                if y < c0 {
                    let off = (y - g.start_row) * w * 4;
                    new_carry.extend_from_slice(&g.data[off..off + w * 4]);
                } else {
                    new_carry.extend_from_slice(src.row(y));
                }
            }
        }

        // 3) The stages.
        self.run_stages(&mut band, bh, r0, threads);

        // 4) Write rows [c0, c1) back as bytes. Alpha comes from the source row (still original here).
        {
            let band_ref = &band;
            let dither = self.plan.dither;
            let mut jobs: Vec<(usize, usize)> = Vec::new();
            let mut ya = c0;
            while ya < c1 {
                jobs.push((ya, (ya + rpj).min(c1)));
                ya += rpj;
            }
            run_jobs(
                jobs,
                threads,
                || vec![0u8; w * 4],
                |tmp: &mut Vec<u8>, (ra, rb): (usize, usize)| {
                    for y in ra..rb {
                        let srow = src.row(y);
                        let brow = &band_ref[(y - r0) * w * 3..(y - r0 + 1) * w * 3];
                        for x in 0..w {
                            let alpha = srow[x * 4 + 3];
                            let a = alpha as f32;
                            let (nr, ng, nb) = if dither { dither_noise(x, y) } else { (0.0, 0.0, 0.0) };
                            tmp[x * 4] = to_byte(clampf(brow[x * 3] + nr, 0.0, a));
                            tmp[x * 4 + 1] = to_byte(clampf(brow[x * 3 + 1] + ng, 0.0, a));
                            tmp[x * 4 + 2] = to_byte(clampf(brow[x * 3 + 2] + nb, 0.0, a));
                            tmp[x * 4 + 3] = alpha;
                        }
                        dst.write_row(y, tmp);
                    }
                },
            );
        }

        if let Some(g) = guard.as_mut() {
            g.data = new_carry;
            g.start_row = new_start;
            g.next_row = c1;
        }
        Ok(())
    }

    fn run_stages(&self, band: &mut Vec<f32>, bh: usize, r0: usize, threads: usize) {
        let w = self.w;
        let a = &self.plan.amounts;

        // 1. The CNN, blended with the original by `strength`.
        if let Some(pw) = self.weights.as_ref() {
            let mut nn_out = vec![0.0f32; w * bh * 3];
            infer::infer_rgb(band, w, bh, pw, &mut nn_out, threads);
            let s = self.opts.strength;
            if s >= 0.999 {
                std::mem::swap(band, &mut nn_out);
            } else {
                for i in 0..band.len() {
                    band[i] += s * (nn_out[i] - band[i]);
                }
            }
        }

        // 2. Hot pixels / salt-and-pepper, then compression artifacts, then noise, then banding.
        if a.despike > 0.0 {
            denoise::despike(band, w, bh, a.despike, threads);
        }
        if self.opts.noise_reduction > 0.0 {
            restore_artifacts(band, w, bh, self.opts.noise_reduction, threads);
        }
        if a.denoise > 0.0 {
            denoise::denoise(band, w, bh, a.denoise, self.plan.noise_sigma, threads);
        }
        if a.deband > 0.0 {
            denoise::deband(band, w, bh, a.deband, threads);
        }

        // 3. Real deconvolution of optical / motion softness.
        if a.deblur > 0.0 {
            deblur::deblur(band, w, bh, a.deblur, threads);
        }

        // 4. Global + low-resolution-map driven tone and colour.
        tone::tone_pass(band, w, bh, r0, &self.plan, threads);

        // 5. Fine detail, then the final sharpen (when the photo is not about to be upscaled, which sharpens itself).
        if a.detail > 0.0 {
            deblur::detail(band, w, bh, a.detail, self.plan.noise_sigma, threads);
        }
        if self.opts.upscale_factor == 1 && self.opts.sharpen.enabled() {
            smart_sharpen(band, w, bh, 3, &self.opts.sharpen, threads);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::enhance::options::*;
    use crate::nn::initialize_params;
    use crate::rng::Rng;
    use std::cell::UnsafeCell;

    struct TestImage {
        w: usize,
        h: usize,
        px: UnsafeCell<Vec<u8>>,
    }

    unsafe impl Sync for TestImage {}

    impl TestImage {
        fn new(w: usize, h: usize, px: Vec<u8>) -> TestImage {
            TestImage { w, h, px: UnsafeCell::new(px) }
        }
        fn blank(w: usize, h: usize) -> TestImage {
            TestImage::new(w, h, vec![0u8; w * h * 4])
        }
        fn bytes(&self) -> Vec<u8> {
            unsafe { (*self.px.get()).clone() }
        }
    }

    impl PixelSource for TestImage {
        fn width(&self) -> usize {
            self.w
        }
        fn height(&self) -> usize {
            self.h
        }
        fn row(&self, y: usize) -> &[u8] {
            unsafe { &(*self.px.get())[y * self.w * 4..(y + 1) * self.w * 4] }
        }
    }

    impl RowIo for TestImage {
        fn write_row(&self, y: usize, data: &[u8]) {
            unsafe {
                (*self.px.get())[y * self.w * 4..(y + 1) * self.w * 4].copy_from_slice(data);
            }
        }
    }

    fn photo(w: usize, h: usize) -> Vec<u8> {
        let mut rng = Rng::new(77);
        let mut px = vec![255u8; w * h * 4];
        for y in 0..h {
            for x in 0..w {
                let sky = (y as f32 / h as f32) * 60.0;
                let edge = if (x / 20 + y / 25) % 2 == 0 { 40.0 } else { 0.0 };
                for c in 0..3 {
                    let v = 60.0 + sky + edge + c as f32 * 12.0 + rng.normal() * 3.0;
                    px[(y * w + x) * 4 + c] = v.max(0.0).min(255.0) as u8;
                }
            }
        }
        px
    }

    fn rich_options() -> Vec<f32> {
        let mut a = vec![0.0f32; OPTIONS_LEN];
        a[STRENGTH] = 0.8;
        a[NOISE_REDUCTION] = 0.3;
        a[COLOR_RESTORATION] = 0.2;
        a[AUTO] = 1.0;
        a[DENOISE] = 0.5;
        a[DETAIL] = 0.4;
        a[CLAHE] = 0.3;
        a[SHARP_AMOUNT] = 1.0;
        a[SHARP_SIGMA] = 1.0;
        a[SHARP_OVERSHOOT] = 0.08;
        a[SHARP_CLAMP_RADIUS] = 1.0;
        a[SHARP_GATE_LOW] = 2.0;
        a[SHARP_GATE_HIGH] = 12.0;
        a[UPSCALE_FACTOR] = 1.0;
        a
    }

    fn max_diff(a: &[u8], b: &[u8]) -> i32 {
        let mut m = 0i32;
        for i in 0..a.len() {
            m = m.max((a[i] as i32 - b[i] as i32).abs());
        }
        m
    }

    #[test]
    fn banded_processing_matches_whole_image_processing() {
        let (w, h) = (96usize, 140usize);
        let src = TestImage::new(w, h, photo(w, h));
        let mut params = vec![0.0f32; TOTAL_PARAMS];
        initialize_params(&mut params, 3);

        let mut session = Session::open(&src, &rich_options(), Some(params.as_slice()), 10_000_000, 2);
        let whole = TestImage::blank(w, h);
        session.process_rows(&src, &whole, 0, h, false, 2).unwrap();

        // Same session, but the photo is requested in small bands (each reads its own context rows).
        session.set_max_band_pixels(50_000);
        let banded = TestImage::blank(w, h);
        let mut y = 0;
        while y < h {
            let y_end = (y + 23).min(h);
            session.process_rows(&src, &banded, y, y_end, false, 2).unwrap();
            y = y_end;
        }
        assert!(max_diff(&whole.bytes(), &banded.bytes()) <= 1, "band seams detected");
    }

    #[test]
    fn in_place_processing_matches_out_of_place() {
        let (w, h) = (80usize, 120usize);
        let original = photo(w, h);
        let src = TestImage::new(w, h, original.clone());
        let session = Session::open(&src, &rich_options(), None, 50_000, 2);
        let out = TestImage::blank(w, h);
        session.process_rows(&src, &out, 0, h, false, 2).unwrap();

        let in_place = TestImage::new(w, h, original);
        let session2 = Session::open(&in_place, &rich_options(), None, 50_000, 2);
        let mut y = 0;
        while y < h {
            let y_end = (y + 17).min(h);
            session2.process_rows(&in_place, &in_place, y, y_end, true, 2).unwrap();
            y = y_end;
        }
        assert!(max_diff(&out.bytes(), &in_place.bytes()) <= 1, "in-place result differs");
    }

    #[test]
    fn in_place_rejects_gaps() {
        let (w, h) = (40usize, 60usize);
        let img = TestImage::new(w, h, photo(w, h));
        let session = Session::open(&img, &rich_options(), None, 50_000, 1);
        assert!(session.process_rows(&img, &img, 10, 20, true, 1).is_err());
    }

    #[test]
    fn everything_off_is_a_bit_exact_copy() {
        let (w, h) = (50usize, 40usize);
        let px = photo(w, h);
        let src = TestImage::new(w, h, px.clone());
        let session = Session::open(&src, &vec![0.0f32; OPTIONS_LEN], None, 50_000, 2);
        let out = TestImage::blank(w, h);
        session.process_rows(&src, &out, 0, h, false, 2).unwrap();
        assert_eq!(out.bytes(), px);
    }
}
