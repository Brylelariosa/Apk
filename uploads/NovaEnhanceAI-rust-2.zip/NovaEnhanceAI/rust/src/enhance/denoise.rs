//! Noise and artifact techniques that look at neighbouring pixels. All work on an interleaved RGB float band
//! (0..255) in place, treat the band edge as replicated, and report their reach in rows (`reach_rows`) so the band
//! processor can carry enough real context rows for seam-free results.
//!
//! * [`despike`]  hot-pixel / salt-and-pepper removal: an isolated pixel that sticks out of all 8 neighbours is
//!   replaced by their median. Real detail (edges, lines, texture) never qualifies.
//! * [`denoise`]  fast non-local means on luma (3x3 patches, searched in a small window, weights from a lookup
//!   table) plus edge-aware chroma smoothing (guided filter steered by the cleaned luma).
//! * [`deband`]   removes the 1-level staircases of posterised gradients: a separable mean that only averages
//!   neighbours within a small threshold of the centre, so real edges are never blurred.

use crate::img::blur::guided_filter;
use crate::img::{cidx, clampf, luma_plane, ycc_to_rgb, CB_SCALE, CR_SCALE};
use crate::par::{par_row_chunks_mut, rows_per_job};

// ---------------------------------------------------------------------------------------------- despike

pub const DESPIKE_REACH: usize = 1;

fn median8(v: &mut [f32; 8]) -> f32 {
    // insertion sort of 8 values
    for i in 1..8 {
        let key = v[i];
        let mut j = i;
        while j > 0 && v[j - 1] > key {
            v[j] = v[j - 1];
            j -= 1;
        }
        v[j] = key;
    }
    0.5 * (v[3] + v[4])
}

/// Replaces isolated outlier pixels (per channel) by the median of their 8 neighbours.
pub fn despike(band: &mut [f32], w: usize, h: usize, amount: f32, threads: usize) {
    if w < 3 || h < 3 || !(amount > 0.0) {
        return;
    }
    let thr = 45.0 - 30.0 * clampf(amount, 0.0, 1.0); // levels: 45 (gentle) .. 15 (aggressive)
    let src: Vec<f32> = band[..w * h * 3].to_vec();
    let rpj = rows_per_job(w);
    let src_ref = &src;
    par_row_chunks_mut(&mut band[..w * h * 3], w * 3, rpj, threads, |first_row, chunk| {
        let rows_n = chunk.len() / (w * 3);
        for ry in 0..rows_n {
            let y = first_row + ry;
            let yu = cidx(y as isize - 1, h);
            let yd = cidx(y as isize + 1, h);
            for x in 0..w {
                let xl = cidx(x as isize - 1, w);
                let xr = cidx(x as isize + 1, w);
                for c in 0..3 {
                    let centre = src_ref[(y * w + x) * 3 + c];
                    let mut nb = [
                        src_ref[(yu * w + xl) * 3 + c],
                        src_ref[(yu * w + x) * 3 + c],
                        src_ref[(yu * w + xr) * 3 + c],
                        src_ref[(y * w + xl) * 3 + c],
                        src_ref[(y * w + xr) * 3 + c],
                        src_ref[(yd * w + xl) * 3 + c],
                        src_ref[(yd * w + x) * 3 + c],
                        src_ref[(yd * w + xr) * 3 + c],
                    ];
                    let mut mx = nb[0];
                    let mut mn = nb[0];
                    for k in 1..8 {
                        if nb[k] > mx {
                            mx = nb[k];
                        }
                        if nb[k] < mn {
                            mn = nb[k];
                        }
                    }
                    if centre > mx + thr || centre < mn - thr {
                        chunk[(ry * w + x) * 3 + c] = median8(&mut nb);
                    }
                }
            }
        }
    });
}

// ---------------------------------------------------------------------------------------------- denoise

const NLM_LUT: usize = 256;
const NLM_LUT_SCALE: f32 = 32.0; // table covers exponents 0..8
const CHROMA_RADIUS: usize = 4;

fn search_radius(amount: f32) -> usize {
    if amount > 0.66 {
        3
    } else {
        2
    }
}

pub fn denoise_reach(amount: f32) -> usize {
    // NLM: search radius + patch radius (1); chroma guided filter: 2 * radius.
    search_radius(amount) + 1 + 2 * CHROMA_RADIUS
}

/// Non-local means on a luma plane. `sigma` is the noise level in levels, `h_param` the filtering strength.
fn nlm_luma(y: &[f32], out: &mut [f32], w: usize, h: usize, sigma: f32, h_param: f32, search_r: usize, threads: usize) {
    let mut lut = [0.0f32; NLM_LUT];
    for i in 0..NLM_LUT {
        lut[i] = (-(i as f32 + 0.5) / NLM_LUT_SCALE).exp();
    }
    let inv_h2 = 1.0 / (h_param * h_param).max(1e-6);
    let two_sigma2 = 2.0 * sigma * sigma;
    let sr = search_r as isize;
    let lut_ref = &lut;

    par_row_chunks_mut(&mut out[..w * h], w, 16, threads, |first_row, chunk| {
        let rows_n = chunk.len() / w;
        // The centre pixel counts with weight 1.
        let mut num = vec![0.0f32; rows_n * w];
        let mut den = vec![1.0f32; rows_n * w];
        for i in 0..rows_n * w {
            num[i] = y[first_row * w + i];
        }
        let mut h3 = vec![0.0f32; (rows_n + 2) * w];
        let mut sqe = vec![0.0f32; w + 2];

        for dy in -sr..=sr {
            for dx in -sr..=sr {
                if dx == 0 && dy == 0 {
                    continue;
                }
                // Horizontal 3-sums of squared differences for the rows first_row-1 ..= first_row+rows_n.
                for k in 0..rows_n + 2 {
                    let p = first_row as isize - 1 + k as isize;
                    let ya = cidx(p, h);
                    let yb = cidx(p + dy, h);
                    let ra = &y[ya * w..(ya + 1) * w];
                    let rb = &y[yb * w..(yb + 1) * w];
                    for i in 0..w + 2 {
                        let col = i as isize - 1;
                        let d = ra[cidx(col, w)] - rb[cidx(col + dx, w)];
                        sqe[i] = d * d;
                    }
                    let h3row = &mut h3[k * w..(k + 1) * w];
                    for x in 0..w {
                        h3row[x] = sqe[x] + sqe[x + 1] + sqe[x + 2];
                    }
                }
                for r in 0..rows_n {
                    let yn = cidx(first_row as isize + r as isize + dy, h);
                    let neighbour_row = &y[yn * w..(yn + 1) * w];
                    for x in 0..w {
                        let d9 = h3[r * w + x] + h3[(r + 1) * w + x] + h3[(r + 2) * w + x];
                        let t = ((d9 / 9.0 - two_sigma2).max(0.0)) * inv_h2;
                        let idx = (t * NLM_LUT_SCALE) as usize;
                        if idx < NLM_LUT {
                            let wgt = lut_ref[idx];
                            let nv = neighbour_row[cidx(x as isize + dx, w)];
                            num[r * w + x] += wgt * nv;
                            den[r * w + x] += wgt;
                        }
                    }
                }
            }
        }
        for i in 0..rows_n * w {
            chunk[i] = num[i] / den[i];
        }
    });
}

/// Luma non-local-means + guided chroma smoothing. `amount` 0..1 sets both the search window and the strength;
/// `noise_sigma` is the analysed noise level (levels); a floor keeps the effect visible on clean pictures.
pub fn denoise(band: &mut [f32], w: usize, h: usize, amount: f32, noise_sigma: f32, threads: usize) {
    if w < 4 || h < 4 || !(amount > 0.0) {
        return;
    }
    let amount = clampf(amount, 0.0, 1.0);
    let n = w * h;
    let sigma = noise_sigma.max(2.0);
    let h_param = sigma * (0.6 + 0.8 * amount);

    let y = luma_plane(band, w, h, 3);
    let mut cb = vec![0.0f32; n];
    let mut cr = vec![0.0f32; n];
    for i in 0..n {
        cb[i] = (band[i * 3 + 2] - y[i]) * CB_SCALE;
        cr[i] = (band[i * 3] - y[i]) * CR_SCALE;
    }

    let mut y_dn = vec![0.0f32; n];
    nlm_luma(&y, &mut y_dn, w, h, sigma, h_param, search_radius(amount), threads);

    let eps = {
        let e = 5.0 + 12.0 * amount;
        e * e
    };
    let cb_dn = guided_filter(&y_dn, &cb, w, h, CHROMA_RADIUS, eps, threads);
    let cr_dn = guided_filter(&y_dn, &cr, w, h, CHROMA_RADIUS, eps, threads);

    let rpj = rows_per_job(w);
    let (y_ref, cb_ref, cr_ref) = (&y_dn, &cb_dn, &cr_dn);
    par_row_chunks_mut(&mut band[..n * 3], w * 3, rpj, threads, |first_row, chunk| {
        let rows_n = chunk.len() / (w * 3);
        for ry in 0..rows_n {
            for x in 0..w {
                let i = (first_row + ry) * w + x;
                let (r, g, b) = ycc_to_rgb(y_ref[i], cb_ref[i], cr_ref[i]);
                let o = (ry * w + x) * 3;
                chunk[o] = r;
                chunk[o + 1] = g;
                chunk[o + 2] = b;
            }
        }
    });
}

// ---------------------------------------------------------------------------------------------- deband

pub fn deband_reach(amount: f32) -> usize {
    3 + (5.0 * clampf(amount, 0.0, 1.0)) as usize
}

/// Removes banding: each channel becomes the mean of the neighbours that differ from it by no more than a small
/// threshold (separable: rows, then columns). Gradients get smoothed across their 1-level steps; real edges and
/// texture above the threshold are left untouched.
pub fn deband(band: &mut [f32], w: usize, h: usize, amount: f32, threads: usize) {
    if w < 3 || h < 3 || !(amount > 0.0) {
        return;
    }
    let amount = clampf(amount, 0.0, 1.0);
    let r = deband_reach(amount);
    let thr = 1.0 + 2.0 * amount; // levels
    let inv = 1.0 / (2 * r + 1) as f32;
    let rpj = rows_per_job(w);
    let n3 = w * h * 3;

    // Horizontal pass: band -> tmp.
    let mut tmp = vec![0.0f32; n3];
    {
        let src: &[f32] = &*band;
        par_row_chunks_mut(&mut tmp, w * 3, rpj, threads, |first_row, chunk| {
            let rows_n = chunk.len() / (w * 3);
            for ry in 0..rows_n {
                let y = first_row + ry;
                let row = &src[y * w * 3..(y + 1) * w * 3];
                let out = &mut chunk[ry * w * 3..(ry + 1) * w * 3];
                for x in 0..w {
                    for c in 0..3 {
                        let centre = row[x * 3 + c];
                        let mut sum = 0.0f32;
                        for k in 1..=r {
                            let l = row[cidx(x as isize - k as isize, w) * 3 + c];
                            let rr = row[cidx(x as isize + k as isize, w) * 3 + c];
                            sum += clampf(l - centre, -thr, thr) + clampf(rr - centre, -thr, thr);
                        }
                        out[x * 3 + c] = centre + sum * inv;
                    }
                }
            }
        });
    }

    // Vertical pass: tmp -> band.
    let tmp_ref = &tmp;
    par_row_chunks_mut(&mut band[..n3], w * 3, rpj, threads, |first_row, chunk| {
        let rows_n = chunk.len() / (w * 3);
        let mut acc = vec![0.0f32; w * 3];
        for ry in 0..rows_n {
            let y = first_row + ry;
            let centre = &tmp_ref[y * w * 3..(y + 1) * w * 3];
            for v in acc.iter_mut() {
                *v = 0.0;
            }
            for k in 1..=r {
                let yu = cidx(y as isize - k as isize, h);
                let yd = cidx(y as isize + k as isize, h);
                let ru = &tmp_ref[yu * w * 3..(yu + 1) * w * 3];
                let rd = &tmp_ref[yd * w * 3..(yd + 1) * w * 3];
                for i in 0..w * 3 {
                    acc[i] += clampf(ru[i] - centre[i], -thr, thr) + clampf(rd[i] - centre[i], -thr, thr);
                }
            }
            let out = &mut chunk[ry * w * 3..(ry + 1) * w * 3];
            for i in 0..w * 3 {
                out[i] = centre[i] + acc[i] * inv;
            }
        }
    });
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::rng::Rng;

    #[test]
    fn despike_removes_a_hot_pixel_and_keeps_an_edge() {
        let (w, h) = (20usize, 12usize);
        let mut band = vec![0.0f32; w * h * 3];
        for y in 0..h {
            for x in 0..w {
                let v = if x < 10 { 60.0 } else { 180.0 };
                for c in 0..3 {
                    band[(y * w + x) * 3 + c] = v;
                }
            }
        }
        band[(5 * w + 4) * 3] = 255.0; // hot red pixel in the dark flat area
        let before_edge = band[(5 * w + 10) * 3];
        despike(&mut band, w, h, 0.8, 2);
        assert!((band[(5 * w + 4) * 3] - 60.0).abs() < 1e-3, "hot pixel replaced");
        assert!((band[(5 * w + 10) * 3] - before_edge).abs() < 1e-3, "edge untouched");
    }

    #[test]
    fn nlm_reduces_noise_on_a_flat_region() {
        let (w, h) = (48usize, 40usize);
        let mut rng = Rng::new(5);
        let mut band = vec![0.0f32; w * h * 3];
        for i in 0..w * h {
            let n = rng.normal() * 8.0;
            band[i * 3] = 128.0 + n;
            band[i * 3 + 1] = 128.0 + n;
            band[i * 3 + 2] = 128.0 + n;
        }
        let noisy = band.clone();
        denoise(&mut band, w, h, 0.8, 8.0, 3);
        let var = |b: &[f32]| {
            let mut s = 0.0f64;
            for y in 8..h - 8 {
                for x in 8..w - 8 {
                    let d = (b[(y * w + x) * 3] - 128.0) as f64;
                    s += d * d;
                }
            }
            s
        };
        assert!(var(&band) < var(&noisy) * 0.5, "noise power should drop by half or more");
    }

    #[test]
    fn deband_smooths_a_staircase_but_not_a_real_edge() {
        let (w, h) = (80usize, 12usize);
        let mut band = vec![0.0f32; w * h * 3];
        for y in 0..h {
            for x in 0..w {
                let stair = 100.0 + (x / 8) as f32; // 1-level steps every 8 px
                let v = if x < 60 { stair } else { stair + 100.0 }; // plus a real edge at x = 60
                for c in 0..3 {
                    band[(y * w + x) * 3 + c] = v;
                }
            }
        }
        let before = band.clone();
        deband(&mut band, w, h, 1.0, 2);
        // the staircase step at x = 24 gets blended
        let jump_before = (before[(6 * w + 24) * 3] - before[(6 * w + 23) * 3]).abs();
        let jump_after = (band[(6 * w + 24) * 3] - band[(6 * w + 23) * 3]).abs();
        assert!(jump_after < jump_before * 0.8, "{} -> {}", jump_before, jump_after);
        // the real edge keeps its height
        assert!(band[(6 * w + 62) * 3] - band[(6 * w + 57) * 3] > 90.0);
    }
}
