//! Detail techniques on the luma channel (the delta is added to R, G and B alike, so colours never shift).
//!
//! * [`deblur`]  Richardson-Lucy deconvolution with a Gaussian point-spread function: undoes real optical / motion /
//!   focus softness instead of merely adding contrast. Damped (ratio limited to 0.5..2 per iteration), blended and
//!   de-ringed (the result may not leave the local range of the input), so noise and halos stay under control.
//! * [`detail`]  multi-scale detail boost: guided-filter base/detail split, noise-aware soft threshold on the detail
//!   layer, then a gain. Brings out texture without touching edges.

use crate::img::blur::{gaussian_plane, gaussian_radius, guided_filter};
use crate::img::{cidx, clampf, luma_plane};
use crate::par::{par_row_chunks_mut, rows_per_job};

fn deblur_sigma(amount: f32) -> f32 {
    0.7 + 0.6 * clampf(amount, 0.0, 1.0)
}

fn deblur_iterations(amount: f32) -> usize {
    2 + (2.0 * clampf(amount, 0.0, 1.0)).round() as usize
}

/// Rows of context `deblur` needs: every iteration blurs twice (reach = kernel radius each), plus the 3x3 de-ringing.
pub fn deblur_reach(amount: f32) -> usize {
    let r = gaussian_radius(deblur_sigma(amount));
    deblur_iterations(amount) * 2 * r + 1
}

/// Richardson-Lucy deconvolution on luma. `amount` 0..1 sets the PSF width, the iteration count and the blend.
pub fn deblur(band: &mut [f32], w: usize, h: usize, amount: f32, threads: usize) {
    if w < 4 || h < 4 || !(amount > 0.0) {
        return;
    }
    let amount = clampf(amount, 0.0, 1.0);
    let n = w * h;
    let sigma = deblur_sigma(amount);
    let iters = deblur_iterations(amount);
    let blend = 0.4 + 0.6 * amount;

    let obs = luma_plane(band, w, h, 3);
    let mut est = obs.clone();
    let mut blurred = vec![0.0f32; n];
    let mut ratio = vec![0.0f32; n];
    let mut corr = vec![0.0f32; n];
    for _ in 0..iters {
        gaussian_plane(&est, &mut blurred, w, h, sigma, threads);
        for i in 0..n {
            ratio[i] = clampf(obs[i] / blurred[i].max(1.0), 0.5, 2.0);
        }
        // The PSF is symmetric, so the correction uses the same kernel.
        gaussian_plane(&ratio, &mut corr, w, h, sigma, threads);
        for i in 0..n {
            est[i] = clampf(est[i] * corr[i], 0.0, 260.0);
        }
    }

    let rpj = rows_per_job(w);
    let (obs_ref, est_ref) = (&obs, &est);
    par_row_chunks_mut(&mut band[..n * 3], w * 3, rpj, threads, |first_row, chunk| {
        let rows_n = chunk.len() / (w * 3);
        for ry in 0..rows_n {
            let y = first_row + ry;
            for x in 0..w {
                let i = y * w + x;
                // De-ringing: stay inside the local range of the observed luma (plus a little headroom).
                let mut mn = obs_ref[i];
                let mut mx = obs_ref[i];
                for dy in -1isize..=1 {
                    let yy = cidx(y as isize + dy, h);
                    for dx in -1isize..=1 {
                        let v = obs_ref[yy * w + cidx(x as isize + dx, w)];
                        if v < mn {
                            mn = v;
                        }
                        if v > mx {
                            mx = v;
                        }
                    }
                }
                let range = mx - mn;
                let restored = clampf(est_ref[i], mn - 0.1 * range, mx + 0.1 * range);
                let delta = clampf((restored - obs_ref[i]) * blend, -40.0, 40.0);
                let o = (ry * w + x) * 3;
                chunk[o] = clampf(chunk[o] + delta, 0.0, 255.0);
                chunk[o + 1] = clampf(chunk[o + 1] + delta, 0.0, 255.0);
                chunk[o + 2] = clampf(chunk[o + 2] + delta, 0.0, 255.0);
            }
        }
    });
}

const DETAIL_RADIUS: usize = 3;
const DETAIL_EPS: f32 = 400.0; // (20 levels)^2: structure stronger than this counts as an edge and stays in the base

/// Rows of context `detail` needs (the guided filter's two cascaded box filters).
pub const DETAIL_REACH: usize = 2 * DETAIL_RADIUS;

/// Boosts fine texture: `y' = y + gain * softThreshold(y - guidedFilter(y))`.
pub fn detail(band: &mut [f32], w: usize, h: usize, amount: f32, noise_sigma: f32, threads: usize) {
    if w < 4 || h < 4 || !(amount > 0.0) {
        return;
    }
    let amount = clampf(amount, 0.0, 1.0);
    let n = w * h;
    let y = luma_plane(band, w, h, 3);
    let base = guided_filter(&y, &y, w, h, DETAIL_RADIUS, DETAIL_EPS, threads);
    let tau = (1.2 * noise_sigma).max(1.0);
    let gain = 1.6 * amount;

    let rpj = rows_per_job(w);
    let (y_ref, base_ref) = (&y, &base);
    par_row_chunks_mut(&mut band[..n * 3], w * 3, rpj, threads, |first_row, chunk| {
        let rows_n = chunk.len() / (w * 3);
        for ry in 0..rows_n {
            for x in 0..w {
                let i = (first_row + ry) * w + x;
                let d = y_ref[i] - base_ref[i];
                let mag = (d.abs() - tau).max(0.0);
                let boosted = if d >= 0.0 { mag } else { -mag };
                let delta = clampf(gain * boosted, -40.0, 40.0);
                let o = (ry * w + x) * 3;
                chunk[o] = clampf(chunk[o] + delta, 0.0, 255.0);
                chunk[o + 1] = clampf(chunk[o + 1] + delta, 0.0, 255.0);
                chunk[o + 2] = clampf(chunk[o + 2] + delta, 0.0, 255.0);
            }
        }
    });
}

#[cfg(test)]
mod tests {
    use super::*;

    fn blurred_step(w: usize, h: usize) -> Vec<f32> {
        let mut band = vec![0.0f32; w * h * 3];
        for y in 0..h {
            for x in 0..w {
                let t = ((x as f32 - (w / 2) as f32) / 2.5).tanh() * 0.5 + 0.5;
                let v = 50.0 + 150.0 * t;
                for c in 0..3 {
                    band[(y * w + x) * 3 + c] = v;
                }
            }
        }
        band
    }

    #[test]
    fn deblur_steepens_a_soft_edge_without_overshoot() {
        let (w, h) = (60usize, 20usize);
        let mut band = blurred_step(w, h);
        let before = band.clone();
        deblur(&mut band, w, h, 0.8, 2);
        let slope = |b: &[f32]| b[(10 * w + w / 2 + 1) * 3] - b[(10 * w + w / 2 - 2) * 3];
        assert!(slope(&band) > slope(&before), "edge should get steeper");
        for &v in &band {
            assert!(v >= 0.0 && v <= 255.0);
        }
        // far from the edge nothing changes
        assert!((band[(10 * w + 2) * 3] - before[(10 * w + 2) * 3]).abs() < 0.5);
    }

    #[test]
    fn detail_boost_leaves_flat_areas_alone() {
        let (w, h) = (40usize, 30usize);
        let mut band = vec![120.0f32; w * h * 3];
        detail(&mut band, w, h, 1.0, 2.0, 2);
        for v in band {
            assert!((v - 120.0).abs() < 1e-3);
        }
    }

    #[test]
    fn detail_boost_increases_texture_contrast() {
        let (w, h) = (40usize, 30usize);
        let mut band = vec![0.0f32; w * h * 3];
        for y in 0..h {
            for x in 0..w {
                let v = 120.0 + if (x + y) % 2 == 0 { 6.0 } else { -6.0 };
                for c in 0..3 {
                    band[(y * w + x) * 3 + c] = v;
                }
            }
        }
        let before = band.clone();
        detail(&mut band, w, h, 1.0, 1.0, 2);
        let spread = |b: &[f32]| (b[(15 * w + 20) * 3] - b[(15 * w + 21) * 3]).abs();
        assert!(spread(&band) > spread(&before));
    }
}
