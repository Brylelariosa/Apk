//! The few JNI calls this library needs, called through the JNI function table by its (spec-fixed) index.
//!
//! No `jni` crate: the table layout is part of the JNI specification (`jni.h`), so a raw `[*const c_void; N]` plus
//! the handful of signatures below is all it takes, and the crate keeps zero dependencies. Every index used here is
//! named after the JNI function it belongs to.

use std::ffi::CString;
use std::os::raw::{c_char, c_void};

pub type JInt = i32;
pub type JSize = i32;
pub type JFloat = f32;
pub type JLong = i64;
pub type JBoolean = u8;
pub type JObject = *mut c_void;

pub const JNI_FALSE: JBoolean = 0;
pub const JNI_TRUE: JBoolean = 1;

/// `struct JNINativeInterface_`: 4 reserved slots followed by the function pointers, in `jni.h` order.
#[repr(C)]
pub struct JniTable {
    fns: [*const c_void; 240],
}

/// A `JNIEnv*` as the JVM hands it to a native method (a pointer to a pointer to the table).
pub type RawEnv = *mut *const JniTable;

// Indices into the function table (JNI specification order).
const FIND_CLASS: usize = 6;
const THROW_NEW: usize = 14;
const EXCEPTION_CLEAR: usize = 17;
const IS_SAME_OBJECT: usize = 24;
const NEW_STRING_UTF: usize = 167;
const GET_ARRAY_LENGTH: usize = 171;
const NEW_INT_ARRAY: usize = 179;
const NEW_FLOAT_ARRAY: usize = 181;
const GET_INT_ARRAY_REGION: usize = 203;
const GET_FLOAT_ARRAY_REGION: usize = 205;
const SET_INT_ARRAY_REGION: usize = 211;
const SET_FLOAT_ARRAY_REGION: usize = 213;
const EXCEPTION_CHECK: usize = 228;

type FnFindClass = unsafe extern "system" fn(RawEnv, *const c_char) -> JObject;
type FnThrowNew = unsafe extern "system" fn(RawEnv, JObject, *const c_char) -> JInt;
type FnExceptionClear = unsafe extern "system" fn(RawEnv);
type FnIsSameObject = unsafe extern "system" fn(RawEnv, JObject, JObject) -> JBoolean;
type FnNewStringUtf = unsafe extern "system" fn(RawEnv, *const c_char) -> JObject;
type FnGetArrayLength = unsafe extern "system" fn(RawEnv, JObject) -> JSize;
type FnNewArray = unsafe extern "system" fn(RawEnv, JSize) -> JObject;
type FnGetIntRegion = unsafe extern "system" fn(RawEnv, JObject, JSize, JSize, *mut i32);
type FnSetIntRegion = unsafe extern "system" fn(RawEnv, JObject, JSize, JSize, *const i32);
type FnGetFloatRegion = unsafe extern "system" fn(RawEnv, JObject, JSize, JSize, *mut f32);
type FnSetFloatRegion = unsafe extern "system" fn(RawEnv, JObject, JSize, JSize, *const f32);
type FnExceptionCheck = unsafe extern "system" fn(RawEnv) -> JBoolean;

/// A copyable handle on the `JNIEnv*` of the current native call. Only valid on the thread that received it.
#[derive(Clone, Copy)]
pub struct Env(pub RawEnv);

impl Env {
    #[inline]
    unsafe fn slot(&self, index: usize) -> *const c_void {
        let table: *const JniTable = *self.0;
        (*table).fns[index]
    }

    /// The raw `JNIEnv*` as the NDK's jnigraphics functions want it.
    pub fn as_void(&self) -> *mut c_void {
        self.0 as *mut c_void
    }

    /// `env->GetArrayLength(array)`.
    pub unsafe fn array_len(&self, array: JObject) -> usize {
        let f: FnGetArrayLength = std::mem::transmute(self.slot(GET_ARRAY_LENGTH));
        let n = f(self.0, array);
        if n < 0 {
            0
        } else {
            n as usize
        }
    }

    /// Copies a Java `int[]` into a Vec.
    pub unsafe fn read_ints(&self, array: JObject) -> Vec<i32> {
        let n = self.array_len(array);
        let mut out = vec![0i32; n];
        if n > 0 {
            let f: FnGetIntRegion = std::mem::transmute(self.slot(GET_INT_ARRAY_REGION));
            f(self.0, array, 0, n as JSize, out.as_mut_ptr());
        }
        out
    }

    /// Copies a Java `float[]` into a Vec.
    pub unsafe fn read_floats(&self, array: JObject) -> Vec<f32> {
        let n = self.array_len(array);
        let mut out = vec![0f32; n];
        if n > 0 {
            let f: FnGetFloatRegion = std::mem::transmute(self.slot(GET_FLOAT_ARRAY_REGION));
            f(self.0, array, 0, n as JSize, out.as_mut_ptr());
        }
        out
    }

    /// Overwrites the first `data.len()` elements of a Java `int[]`.
    pub unsafe fn write_ints(&self, array: JObject, data: &[i32]) {
        if data.is_empty() {
            return;
        }
        let f: FnSetIntRegion = std::mem::transmute(self.slot(SET_INT_ARRAY_REGION));
        f(self.0, array, 0, data.len() as JSize, data.as_ptr());
    }

    /// Overwrites the first `data.len()` elements of a Java `float[]`.
    pub unsafe fn write_floats(&self, array: JObject, data: &[f32]) {
        if data.is_empty() {
            return;
        }
        let f: FnSetFloatRegion = std::mem::transmute(self.slot(SET_FLOAT_ARRAY_REGION));
        f(self.0, array, 0, data.len() as JSize, data.as_ptr());
    }

    /// A new Java `int[]` holding `data` (null if the JVM is out of memory).
    pub unsafe fn new_int_array(&self, data: &[i32]) -> JObject {
        let f: FnNewArray = std::mem::transmute(self.slot(NEW_INT_ARRAY));
        let array = f(self.0, data.len() as JSize);
        if !array.is_null() {
            self.write_ints(array, data);
        }
        array
    }

    /// A new Java `float[]` holding `data` (null if the JVM is out of memory).
    pub unsafe fn new_float_array(&self, data: &[f32]) -> JObject {
        let f: FnNewArray = std::mem::transmute(self.slot(NEW_FLOAT_ARRAY));
        let array = f(self.0, data.len() as JSize);
        if !array.is_null() {
            self.write_floats(array, data);
        }
        array
    }

    /// A new Java `String` (ASCII/UTF-8 text without NULs).
    pub unsafe fn new_string(&self, text: &str) -> JObject {
        let clean: String = text.chars().filter(|c| *c != '\0').collect();
        let c = match CString::new(clean) {
            Ok(c) => c,
            Err(_) => return std::ptr::null_mut(),
        };
        let f: FnNewStringUtf = std::mem::transmute(self.slot(NEW_STRING_UTF));
        f(self.0, c.as_ptr())
    }

    /// Throws `java/lang/<class>` with `message`; the native method must return right after.
    pub unsafe fn throw(&self, class_name: &str, message: &str) {
        let class_c = match CString::new(class_name) {
            Ok(c) => c,
            Err(_) => return,
        };
        let clean: String = message.chars().filter(|c| *c != '\0').collect();
        let msg_c = match CString::new(clean) {
            Ok(c) => c,
            Err(_) => return,
        };
        let find: FnFindClass = std::mem::transmute(self.slot(FIND_CLASS));
        let class = find(self.0, class_c.as_ptr());
        if class.is_null() {
            // FindClass itself failed (NoClassDefFoundError pending); drop that and give up quietly.
            let clear: FnExceptionClear = std::mem::transmute(self.slot(EXCEPTION_CLEAR));
            clear(self.0);
            return;
        }
        let throw_new: FnThrowNew = std::mem::transmute(self.slot(THROW_NEW));
        throw_new(self.0, class, msg_c.as_ptr());
    }

    /// `env->IsSameObject(a, b)`.
    pub unsafe fn is_same_object(&self, a: JObject, b: JObject) -> bool {
        let f: FnIsSameObject = std::mem::transmute(self.slot(IS_SAME_OBJECT));
        f(self.0, a, b) != JNI_FALSE
    }

    /// `env->ExceptionCheck()`.
    pub unsafe fn exception_pending(&self) -> bool {
        let f: FnExceptionCheck = std::mem::transmute(self.slot(EXCEPTION_CHECK));
        f(self.0) != JNI_FALSE
    }
}

/// Errors a native method reports to Java.
pub enum NativeError {
    /// Bad arguments from the caller -> `IllegalArgumentException`.
    Arg(String),
    /// The call was valid but could not be carried out -> `IllegalStateException`.
    State(String),
}

impl NativeError {
    pub fn arg<S: Into<String>>(msg: S) -> NativeError {
        NativeError::Arg(msg.into())
    }

    pub fn state<S: Into<String>>(msg: S) -> NativeError {
        NativeError::State(msg.into())
    }
}

fn panic_message(payload: &(dyn std::any::Any + Send)) -> String {
    if let Some(s) = payload.downcast_ref::<&str>() {
        (*s).to_string()
    } else if let Some(s) = payload.downcast_ref::<String>() {
        s.clone()
    } else {
        "unknown panic".to_string()
    }
}

/// Runs a native method body: `Ok` returns its value; `Err` and panics become Java exceptions and the `default`
/// value is returned (the JVM ignores it because an exception is pending).
pub fn guard<R, F>(env: Env, default: R, body: F) -> R
where
    F: FnOnce() -> Result<R, NativeError>,
{
    match std::panic::catch_unwind(std::panic::AssertUnwindSafe(body)) {
        Ok(Ok(value)) => value,
        Ok(Err(NativeError::Arg(msg))) => {
            crate::sys::log_error(&format!("IllegalArgument: {}", msg));
            unsafe { env.throw("java/lang/IllegalArgumentException", &msg) };
            default
        }
        Ok(Err(NativeError::State(msg))) => {
            crate::sys::log_error(&format!("IllegalState: {}", msg));
            unsafe { env.throw("java/lang/IllegalStateException", &msg) };
            default
        }
        Err(payload) => {
            let msg = format!("native panic: {}", panic_message(payload.as_ref()));
            crate::sys::log_error(&msg);
            unsafe { env.throw("java/lang/RuntimeException", &msg) };
            default
        }
    }
}
