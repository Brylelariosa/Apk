//! NovaEnhance AI - native core, written in Rust.
//!
//! * [`nn`]       the small residual CNN: streaming inference, training (forward/backward/Adam, L2-SP).
//! * [`filters`]  classical image filters: artifact removal, edge-aware sharpening, Lanczos upscaling, degradations.
//! * [`enhance`]  the streaming enhancement pipeline: scene analysis -> plan -> band-by-band processing.
//! * [`bridge`]   the JNI entry points the Kotlin side calls.
//!
//! Memory model: nothing in here ever holds more than one *band* of a photo in floating point. Pixels are read
//! straight out of the Android bitmap, processed in a bounded working buffer and written straight back, so peak
//! native memory is set by a budget (see `enhance::session`), not by the photo's resolution, and the Java heap is
//! never touched on the hot path.
#![allow(clippy::too_many_arguments)]
#![allow(clippy::needless_range_loop)]

pub mod bridge;
pub mod enhance;
pub mod filters;
pub mod img;
pub mod jni;
pub mod nn;
pub mod par;
pub mod rng;
pub mod sys;
