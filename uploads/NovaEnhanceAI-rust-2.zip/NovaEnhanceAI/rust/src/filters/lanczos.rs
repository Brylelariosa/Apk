//! Lanczos-3 upscaling by an integer factor, computed ONLY for output rows `[y0, y1)`, followed by the smart
//! sharpen. Source and destination are the raw RGBA_8888 memory of two bitmaps, so a photo is enlarged band by band
//! with memory bounded by the band (about 20 bytes per output pixel of band + context rows) - the full-size
//! enlarged picture only ever exists as the destination bitmap itself.
//!
//! The pixels written are identical to what one call over the whole image produces, whatever band split the caller
//! uses: the sharpening context rows are recomputed internally (up to `reach_rows()` rows above and below the
//! band), so there are no band seams.

use crate::filters::sharpen::{smart_sharpen, SharpenParams};
use crate::img::{cidx, clampf, to_byte};
use crate::par::{par_row_chunks_mut, rows_per_job};

const LANCZOS_A: usize = 3;
const TAPS: usize = 2 * LANCZOS_A; // 6 taps per output sample

fn lanczos3(x: f64) -> f64 {
    let ax = x.abs();
    if ax < 1e-9 {
        return 1.0;
    }
    if ax >= LANCZOS_A as f64 {
        return 0.0;
    }
    let px = std::f64::consts::PI * x;
    LANCZOS_A as f64 * px.sin() * (px / LANCZOS_A as f64).sin() / (px * px)
}

/// Taps for output samples `[first, first + count)` of one axis: source indices (clamped) and normalised weights.
struct AxisTable {
    idx: Vec<usize>,
    w: Vec<f32>,
}

fn make_axis_table(first: usize, count: usize, src_n: usize, factor: usize) -> AxisTable {
    let mut t = AxisTable { idx: vec![0usize; count * TAPS], w: vec![0.0f32; count * TAPS] };
    for i in 0..count {
        let out = first + i;
        // Half-pixel-centre mapping, the convention every mainstream resampler uses.
        let s = (out as f64 + 0.5) / factor as f64 - 0.5;
        let base = s.floor() as isize;
        let mut raw = [0.0f64; TAPS];
        let mut sum = 0.0f64;
        for k in 0..TAPS {
            let pos = base - (LANCZOS_A as isize - 1) + k as isize;
            raw[k] = lanczos3(s - pos as f64);
            sum += raw[k];
        }
        for k in 0..TAPS {
            let pos = base - (LANCZOS_A as isize - 1) + k as isize;
            t.w[i * TAPS + k] = (raw[k] / sum) as f32;
            t.idx[i * TAPS + k] = cidx(pos, src_n);
        }
    }
    t
}

/// Lanczos-3 upscale by `factor` (1..8) of rows `[y0, y1)` of the `(src_w * factor) x (src_h * factor)` result,
/// then smart sharpening.
///
/// `src` / `dst` are whole-bitmap RGBA_8888 byte buffers (R, G, B, A) with the given row strides in bytes. `dst` must
/// be the FULL output size; only rows `[y0, y1)` are written.
pub fn upscale_rows(
    src: &[u8],
    src_stride: usize,
    src_w: usize,
    src_h: usize,
    dst: &mut [u8],
    dst_stride: usize,
    factor: usize,
    y0: usize,
    y1: usize,
    sharpen: &SharpenParams,
    threads: usize,
) {
    if src_w == 0 || src_h == 0 || factor < 1 {
        return;
    }
    let dst_w = src_w * factor;
    let dst_h = src_h * factor;
    let y1 = y1.min(dst_h);
    if y0 >= y1 {
        return;
    }

    let sharpen = sharpen.sanitized();
    let do_sharpen = sharpen.enabled();
    // Output rows recomputed above/below the band purely as sharpening context (only where the image has them).
    let reach = if do_sharpen { sharpen.reach_rows().max(1) } else { 0 };
    let ys = y0.saturating_sub(reach);
    let ye = (y1 + reach).min(dst_h);
    let band_rows = ye - ys;

    let xt = make_axis_table(0, dst_w, src_w, factor);
    let yt = make_axis_table(ys, band_rows, src_h, factor);

    // Source rows the vertical taps of this band touch (after edge clamping).
    let mut r0 = src_h - 1;
    let mut r1 = 0usize;
    for &idx in yt.idx.iter() {
        if idx < r0 {
            r0 = idx;
        }
        if idx > r1 {
            r1 = idx;
        }
    }
    let src_rows = r1 - r0 + 1;
    let row_floats = dst_w * 4;
    let rpj = rows_per_job(dst_w);

    // 1) Horizontal pass: each needed source row, resampled to the output width (float RGBA).
    let mut hbuf = vec![0.0f32; src_rows * row_floats];
    {
        let xt_ref = &xt;
        par_row_chunks_mut(&mut hbuf, row_floats, rpj, threads, |first_row, chunk| {
            let rows_n = chunk.len() / row_floats;
            for ry in 0..rows_n {
                let sy = r0 + first_row + ry;
                let srow = &src[sy * src_stride..sy * src_stride + src_w * 4];
                let out = &mut chunk[ry * row_floats..(ry + 1) * row_floats];
                for x in 0..dst_w {
                    let ix = &xt_ref.idx[x * TAPS..(x + 1) * TAPS];
                    let wx = &xt_ref.w[x * TAPS..(x + 1) * TAPS];
                    let (mut c0, mut c1, mut c2, mut c3) = (0.0f32, 0.0f32, 0.0f32, 0.0f32);
                    for k in 0..TAPS {
                        let q = ix[k] * 4;
                        let wk = wx[k];
                        c0 += wk * srow[q] as f32;
                        c1 += wk * srow[q + 1] as f32;
                        c2 += wk * srow[q + 2] as f32;
                        c3 += wk * srow[q + 3] as f32;
                    }
                    out[x * 4] = c0;
                    out[x * 4 + 1] = c1;
                    out[x * 4 + 2] = c2;
                    out[x * 4 + 3] = c3;
                }
            }
        });
    }

    // 2) Vertical pass: the six taps of every output row, then ANTI-RINGING: the result is clamped to the range of
    //    the 2x2 source pixels that surround the sample. Lanczos overshoots next to a hard edge; that overshoot is
    //    exactly what reads as a halo once the picture is enlarged, and no value of the 2x2 neighbourhood is ever
    //    beyond the flat colours the edge joins, so the clamp removes the ringing and nothing else.
    let mut band = vec![0.0f32; band_rows * row_floats];
    {
        let xt_ref = &xt;
        let yt_ref = &yt;
        let hbuf_ref = &hbuf;
        par_row_chunks_mut(&mut band, row_floats, rpj, threads, |first_row, chunk| {
            let rows_n = chunk.len() / row_floats;
            for ry in 0..rows_n {
                let r = first_row + ry;
                let iy = &yt_ref.idx[r * TAPS..(r + 1) * TAPS];
                let wy = &yt_ref.w[r * TAPS..(r + 1) * TAPS];
                let h0 = &hbuf_ref[(iy[0] - r0) * row_floats..(iy[0] - r0 + 1) * row_floats];
                let h1 = &hbuf_ref[(iy[1] - r0) * row_floats..(iy[1] - r0 + 1) * row_floats];
                let h2 = &hbuf_ref[(iy[2] - r0) * row_floats..(iy[2] - r0 + 1) * row_floats];
                let h3 = &hbuf_ref[(iy[3] - r0) * row_floats..(iy[3] - r0 + 1) * row_floats];
                let h4 = &hbuf_ref[(iy[4] - r0) * row_floats..(iy[4] - r0 + 1) * row_floats];
                let h5 = &hbuf_ref[(iy[5] - r0) * row_floats..(iy[5] - r0 + 1) * row_floats];
                let (w0, w1, w2, w3, w4, w5) = (wy[0], wy[1], wy[2], wy[3], wy[4], wy[5]);
                // The two source rows that bracket this output row (the inner taps).
                let in_a = iy[LANCZOS_A - 1] * src_stride;
                let in_b = iy[LANCZOS_A] * src_stride;
                let out = &mut chunk[ry * row_floats..(ry + 1) * row_floats];
                for x in 0..dst_w {
                    let xa = xt_ref.idx[x * TAPS + LANCZOS_A - 1] * 4;
                    let xb = xt_ref.idx[x * TAPS + LANCZOS_A] * 4;
                    for c in 0..4 {
                        let i = x * 4 + c;
                        let v = w0 * h0[i] + w1 * h1[i] + w2 * h2[i] + w3 * h3[i] + w4 * h4[i] + w5 * h5[i];
                        if c < 3 {
                            let p0 = src[in_a + xa + c];
                            let p1 = src[in_a + xb + c];
                            let p2 = src[in_b + xa + c];
                            let p3 = src[in_b + xb + c];
                            let lo = p0.min(p1).min(p2).min(p3) as f32;
                            let hi = p0.max(p1).max(p2).max(p3) as f32;
                            out[i] = clampf(v, lo, hi);
                        } else {
                            // alpha is not range-limited here; it is clamped to 0..255 when written
                            out[i] = clampf(v, 0.0, 255.0);
                        }
                    }
                }
            }
        });
    }
    drop(hbuf); // release before the sharpening scratch is allocated

    // 3) Sharpening on the float band (context rows included, so the rows we keep are exact).
    if do_sharpen {
        smart_sharpen(&mut band, dst_w, band_rows, 4, &sharpen, threads);
    }

    // 4) Write the band's own rows. Colour is capped at alpha (premultiplied RGBA); for opaque images a no-op.
    let band_ref = &band;
    let first_out_row = y0 - ys;
    par_row_chunks_mut(&mut dst[y0 * dst_stride..y1 * dst_stride], dst_stride, rpj, threads, |first_row, chunk| {
        let rows_n = chunk.len() / dst_stride;
        for ry in 0..rows_n {
            let inp = &band_ref[(first_out_row + first_row + ry) * row_floats..(first_out_row + first_row + ry + 1) * row_floats];
            let out = &mut chunk[ry * dst_stride..ry * dst_stride + dst_w * 4];
            for x in 0..dst_w {
                let alpha = clampf(inp[x * 4 + 3], 0.0, 255.0);
                out[x * 4] = to_byte(clampf(inp[x * 4], 0.0, alpha));
                out[x * 4 + 1] = to_byte(clampf(inp[x * 4 + 1], 0.0, alpha));
                out[x * 4 + 2] = to_byte(clampf(inp[x * 4 + 2], 0.0, alpha));
                out[x * 4 + 3] = to_byte(alpha);
            }
        }
    });
}

#[cfg(test)]
mod tests {
    use super::*;

    fn gradient_image(w: usize, h: usize) -> Vec<u8> {
        let mut px = vec![0u8; w * h * 4];
        for y in 0..h {
            for x in 0..w {
                let o = (y * w + x) * 4;
                px[o] = (x * 255 / w.max(1)) as u8;
                px[o + 1] = (y * 255 / h.max(1)) as u8;
                px[o + 2] = ((x + y) * 255 / (w + h)) as u8;
                px[o + 3] = 255;
            }
        }
        px
    }

    #[test]
    fn upscaling_a_constant_image_keeps_the_colour() {
        let (w, h, f) = (6usize, 5usize, 2usize);
        let mut src = vec![0u8; w * h * 4];
        for i in 0..w * h {
            src[i * 4] = 90;
            src[i * 4 + 1] = 140;
            src[i * 4 + 2] = 30;
            src[i * 4 + 3] = 255;
        }
        let mut dst = vec![0u8; w * f * h * f * 4];
        upscale_rows(&src, w * 4, w, h, &mut dst, w * f * 4, f, 0, h * f, &SharpenParams::default(), 2);
        for i in 0..w * f * h * f {
            assert_eq!(dst[i * 4], 90);
            assert_eq!(dst[i * 4 + 1], 140);
            assert_eq!(dst[i * 4 + 2], 30);
            assert_eq!(dst[i * 4 + 3], 255);
        }
    }

    #[test]
    fn any_band_split_gives_identical_pixels() {
        let (w, h, f) = (12usize, 10usize, 3usize);
        let src = gradient_image(w, h);
        let p = SharpenParams { amount: 0.8, sigma: 1.5, push: 0.5, push_radius: 2, ..SharpenParams::default() };
        let (dw, dh) = (w * f, h * f);
        let mut whole = vec![0u8; dw * dh * 4];
        upscale_rows(&src, w * 4, w, h, &mut whole, dw * 4, f, 0, dh, &p, 2);
        let mut banded = vec![0u8; dw * dh * 4];
        let mut y = 0;
        while y < dh {
            let y_end = (y + 7).min(dh);
            upscale_rows(&src, w * 4, w, h, &mut banded, dw * 4, f, y, y_end, &p, 2);
            y = y_end;
        }
        assert_eq!(whole, banded);
    }
}
