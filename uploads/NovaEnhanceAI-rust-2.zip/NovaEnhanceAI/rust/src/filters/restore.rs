//! Compression-artifact / chroma-noise removal on an interleaved float RGB image (0..255).
//!
//! A joint bilateral filter in YCbCr: a 17x17 neighbourhood (applied as two separable passes) where each tap's weight
//! is `spatial * range(luma) * range(Cb) * range(Cr)`, every term a tabulated Gaussian. Two weight sets: the one that
//! averages LUMA (tight luma range, loose chroma guard) and the one that averages CHROMA (loose luma range, because
//! shading varies inside a flat-coloured area; tight chroma range, so a real colour boundary is never averaged
//! across). That removes JPEG ringing, mosquito noise and colour blotches while leaving real edges alone.
//!
//! Taps are summed in the same order for every pixel, so a band with [`RESTORE_RADIUS`] rows of real context
//! reproduces a whole-image pass exactly (two passes: the reach is the radius, the second pass reads the first's
//! output only along the other axis).

use crate::img::{cidx, ycc_to_rgb, CB_SCALE, CR_SCALE};
use crate::par::{par_row_chunks_mut, rows_per_job};

pub const RESTORE_RADIUS: usize = 8;
const R: usize = RESTORE_RADIUS;
const TAPS: usize = 2 * R + 1;
const LUMA_LUT: usize = 256;
const CHROMA_LUT: usize = 320;

struct Tables {
    spatial: [f32; TAPS],
    luma_out_luma: [f32; LUMA_LUT],
    luma_out_chroma: [f32; CHROMA_LUT],
    chroma_out_luma: [f32; LUMA_LUT],
    chroma_out_chroma: [f32; CHROMA_LUT],
}

fn fill_gaussian(table: &mut [f32], sigma: f32) {
    let two_sigma_sq = 2.0f64 * sigma as f64 * sigma as f64;
    for i in 0..table.len() {
        table[i] = (-((i * i) as f64) / two_sigma_sq).exp() as f32;
    }
}

fn make_tables(strength: f32) -> Tables {
    let mut t = Tables {
        spatial: [0.0; TAPS],
        luma_out_luma: [0.0; LUMA_LUT],
        luma_out_chroma: [0.0; CHROMA_LUT],
        chroma_out_luma: [0.0; LUMA_LUT],
        chroma_out_chroma: [0.0; CHROMA_LUT],
    };
    let spatial_two_sigma_sq = 2.0f64 * (R as f64 / 2.0) * (R as f64 / 2.0); // sigma = radius / 2
    for k in 0..TAPS {
        let d = k as f64 - R as f64;
        t.spatial[k] = (-(d * d) / spatial_two_sigma_sq).exp() as f32;
    }
    // Tuned on JPEG-damaged line art and photos.
    fill_gaussian(&mut t.luma_out_luma, 3.0 + 9.0 * strength);
    fill_gaussian(&mut t.luma_out_chroma, 40.0);
    fill_gaussian(&mut t.chroma_out_luma, 14.0 + 12.0 * strength);
    fill_gaussian(&mut t.chroma_out_chroma, 5.0 + 12.0 * strength);
    t
}

#[inline(always)]
fn lut_index(diff: f32, last: usize) -> usize {
    let i = (diff.abs() + 0.5) as usize;
    if i < last {
        i
    } else {
        last
    }
}

/// Weighted sums of one filtered pixel; feed it the taps in order, then read the result.
struct Acc {
    luma_sum: f32,
    luma_weight: f32,
    cb_sum: f32,
    cr_sum: f32,
    chroma_weight: f32,
}

impl Acc {
    fn new() -> Acc {
        Acc { luma_sum: 0.0, luma_weight: 0.0, cb_sum: 0.0, cr_sum: 0.0, chroma_weight: 0.0 }
    }

    /// Adds tap `k` whose `[Y, Cb, Cr]` are `q[0..3]`, relative to the centre pixel `(cy, ccb, ccr)`.
    #[inline(always)]
    fn add(&mut self, t: &Tables, k: usize, cy: f32, ccb: f32, ccr: f32, q: &[f32]) {
        let (vy, vcb, vcr) = (q[0], q[1], q[2]);
        let iy = lut_index(vy - cy, LUMA_LUT - 1);
        let icb = lut_index(vcb - ccb, CHROMA_LUT - 1);
        let icr = lut_index(vcr - ccr, CHROMA_LUT - 1);
        let spatial = t.spatial[k];
        let wl = spatial * t.luma_out_luma[iy] * t.luma_out_chroma[icb] * t.luma_out_chroma[icr];
        let wc = spatial * t.chroma_out_luma[iy] * t.chroma_out_chroma[icb] * t.chroma_out_chroma[icr];
        self.luma_sum += wl * vy;
        self.luma_weight += wl;
        self.cb_sum += wc * vcb;
        self.cr_sum += wc * vcr;
        self.chroma_weight += wc;
    }

    fn result(&self) -> [f32; 3] {
        [self.luma_sum / self.luma_weight, self.cb_sum / self.chroma_weight, self.cr_sum / self.chroma_weight]
    }
}

/// Removes compression artifacts and chroma noise from `band` (`w * h * 3` floats, 0..255) in place.
/// `strength` 0 does nothing; 1 is the strongest setting.
pub fn restore_artifacts(band: &mut [f32], w: usize, h: usize, strength: f32, threads: usize) {
    if w == 0 || h == 0 || !(strength > 0.0) {
        return;
    }
    let n = w * h;
    let tables = make_tables(strength.min(1.0));
    let rpj = rows_per_job(w);
    let row_floats = w * 4;

    // 1) RGB -> [Y, Cb, Cr, unused].
    let mut ycc = vec![0.0f32; n * 4];
    {
        let src: &[f32] = &*band;
        par_row_chunks_mut(&mut ycc, row_floats, rpj, threads, |first_row, chunk| {
            let rows_n = chunk.len() / row_floats;
            for ry in 0..rows_n {
                for x in 0..w {
                    let p = ((first_row + ry) * w + x) * 3;
                    let (r, g, b) = (src[p], src[p + 1], src[p + 2]);
                    let y = 0.299 * r + 0.587 * g + 0.114 * b;
                    let o = (ry * w + x) * 4;
                    chunk[o] = y;
                    chunk[o + 1] = (b - y) * CB_SCALE;
                    chunk[o + 2] = (r - y) * CR_SCALE;
                    chunk[o + 3] = 0.0;
                }
            }
        });
    }

    // 2) Horizontal pass: each row is copied into a padded buffer with replicated ends, so the tap loop needs no
    //    clamping.
    let mut tmp = vec![0.0f32; n * 4];
    {
        let ycc_ref = &ycc;
        let tables_ref = &tables;
        par_row_chunks_mut(&mut tmp, row_floats, rpj, threads, |first_row, chunk| {
            let rows_n = chunk.len() / row_floats;
            let mut pad = vec![0.0f32; (w + 2 * R) * 4];
            for ry in 0..rows_n {
                let y = first_row + ry;
                let row = &ycc_ref[y * row_floats..(y + 1) * row_floats];
                for i in 0..w + 2 * R {
                    let sx = cidx(i as isize - R as isize, w);
                    pad[i * 4..i * 4 + 4].copy_from_slice(&row[sx * 4..sx * 4 + 4]);
                }
                for x in 0..w {
                    let c = (x + R) * 4;
                    let (cy, ccb, ccr) = (pad[c], pad[c + 1], pad[c + 2]);
                    let mut acc = Acc::new();
                    for k in 0..TAPS {
                        let q = (x + k) * 4;
                        acc.add(tables_ref, k, cy, ccb, ccr, &pad[q..q + 3]);
                    }
                    let res = acc.result();
                    let o = (ry * w + x) * 4;
                    chunk[o] = res[0];
                    chunk[o + 1] = res[1];
                    chunk[o + 2] = res[2];
                    chunk[o + 3] = 0.0;
                }
            }
        });
    }
    drop(ycc);

    // 3) Vertical pass over the horizontally filtered rows (replicated at the top/bottom), straight back to RGB.
    {
        let tmp_ref = &tmp;
        let tables_ref = &tables;
        par_row_chunks_mut(&mut band[..n * 3], w * 3, rpj, threads, |first_row, chunk| {
            let rows_n = chunk.len() / (w * 3);
            for ry in 0..rows_n {
                let y = first_row + ry;
                let mut rows: [&[f32]; TAPS] = [&tmp_ref[0..0]; TAPS];
                for k in 0..TAPS {
                    let yy = cidx(y as isize + k as isize - R as isize, h);
                    rows[k] = &tmp_ref[yy * row_floats..(yy + 1) * row_floats];
                }
                let centre = rows[R];
                for x in 0..w {
                    let c = x * 4;
                    let (cy, ccb, ccr) = (centre[c], centre[c + 1], centre[c + 2]);
                    let mut acc = Acc::new();
                    for k in 0..TAPS {
                        acc.add(tables_ref, k, cy, ccb, ccr, &rows[k][c..c + 3]);
                    }
                    let res = acc.result();
                    let (r, g, b) = ycc_to_rgb(res[0], res[1], res[2]);
                    let o = (ry * w + x) * 3;
                    chunk[o] = r;
                    chunk[o + 1] = g;
                    chunk[o + 2] = b;
                }
            }
        });
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn flat_image_is_unchanged() {
        let (w, h) = (24usize, 18usize);
        let mut img = vec![0.0f32; w * h * 3];
        for i in 0..w * h {
            img[i * 3] = 120.0;
            img[i * 3 + 1] = 80.0;
            img[i * 3 + 2] = 200.0;
        }
        let before = img.clone();
        restore_artifacts(&mut img, w, h, 0.5, 2);
        for i in 0..img.len() {
            assert!((img[i] - before[i]).abs() < 0.05, "i {}: {} vs {}", i, img[i], before[i]);
        }
    }

    #[test]
    fn small_noise_is_reduced_but_a_hard_edge_survives() {
        let (w, h) = (40usize, 24usize);
        let mut img = vec![0.0f32; w * h * 3];
        for y in 0..h {
            for x in 0..w {
                let base = if x < 20 { 50.0 } else { 200.0 };
                let noise = (((x * 5 + y * 3) % 7) as f32 - 3.0) * 1.5;
                for c in 0..3 {
                    img[(y * w + x) * 3 + c] = base + noise;
                }
            }
        }
        let before = img.clone();
        restore_artifacts(&mut img, w, h, 0.8, 2);
        let mut var_before = 0.0f32;
        let mut var_after = 0.0f32;
        for y in 4..h - 4 {
            for x in 4..14 {
                let d0 = before[(y * w + x) * 3] - 50.0;
                let d1 = img[(y * w + x) * 3] - 50.0;
                var_before += d0 * d0;
                var_after += d1 * d1;
            }
        }
        assert!(var_after < var_before * 0.5, "noise should drop: {} -> {}", var_before, var_after);
        assert!(img[(12 * w + 30) * 3] - img[(12 * w + 10) * 3] > 120.0);
    }
}
