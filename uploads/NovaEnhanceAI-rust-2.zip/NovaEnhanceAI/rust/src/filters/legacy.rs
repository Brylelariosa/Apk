//! Filters over Android `Bitmap.getPixels()` arrays (`0xAARRGGBB` ints). They serve the training-data degradation
//! generator, the validator and the quick similarity metric - small images where a copy through the JVM is fine. The
//! photo-enhancement hot path never uses them (it works on bitmap memory directly).

use crate::img::blur::{gaussian_radius, make_gaussian};
use crate::img::cidx;
use crate::par::{max_threads, par_row_chunks_mut, rows_per_job};
use crate::rng::Rng;

#[inline(always)]
fn channel(p: i32, shift: u32) -> i32 {
    (p >> shift) & 0xFF
}

#[inline(always)]
fn clamp8(v: i32) -> i32 {
    if v < 0 {
        0
    } else if v > 255 {
        255
    } else {
        v
    }
}

#[inline(always)]
fn pack_argb(a: i32, r: i32, g: i32, b: i32) -> i32 {
    (((clamp8(a) as u32) << 24) | ((clamp8(r) as u32) << 16) | ((clamp8(g) as u32) << 8) | (clamp8(b) as u32)) as i32
}

fn thread_budget(w: usize, h: usize) -> usize {
    // Small images skip the pool: waking threads costs more than the work.
    if w * h < 96 * 96 {
        1
    } else {
        max_threads()
    }
}

fn convolve_pass(src: &[i32], w: usize, h: usize, kernel: &[f32], radius: usize, horizontal: bool) -> Vec<i32> {
    let mut dst = vec![0i32; w * h];
    let taps = 2 * radius + 1;
    par_row_chunks_mut(&mut dst, w, rows_per_job(w), thread_budget(w, h), |first_row, chunk| {
        let rows = chunk.len() / w;
        for ry in 0..rows {
            let y = first_row + ry;
            for x in 0..w {
                let (mut a, mut r, mut g, mut b) = (0.0f32, 0.0f32, 0.0f32, 0.0f32);
                for k in 0..taps {
                    let off = k as isize - radius as isize;
                    let px = if horizontal {
                        src[y * w + cidx(x as isize + off, w)]
                    } else {
                        src[cidx(y as isize + off, h) * w + x]
                    };
                    let wk = kernel[k];
                    a += wk * channel(px, 24) as f32;
                    r += wk * channel(px, 16) as f32;
                    g += wk * channel(px, 8) as f32;
                    b += wk * channel(px, 0) as f32;
                }
                chunk[ry * w + x] = pack_argb(a as i32, r as i32, g as i32, b as i32);
            }
        }
    });
    dst
}

/// Separable Gaussian blur (all four channels, alpha included). `sigma <= 0` returns the input.
pub fn gaussian_blur_argb(pixels: &[i32], w: usize, h: usize, sigma: f32) -> Vec<i32> {
    if sigma <= 0.0 || pixels.is_empty() {
        return pixels.to_vec();
    }
    let radius = gaussian_radius(sigma);
    let kernel = make_gaussian(sigma, radius);
    let horizontal = convolve_pass(pixels, w, h, &kernel, radius, true);
    convolve_pass(&horizontal, w, h, &kernel, radius, false)
}

/// Bilinear resize (centre-aligned sampling).
pub fn resize_bilinear_argb(pixels: &[i32], src_w: usize, src_h: usize, dst_w: usize, dst_h: usize) -> Vec<i32> {
    let mut out = vec![0i32; dst_w * dst_h];
    if pixels.is_empty() || src_w == 0 || src_h == 0 || dst_w == 0 || dst_h == 0 {
        return out;
    }
    let x_ratio = src_w as f32 / dst_w as f32;
    let y_ratio = src_h as f32 / dst_h as f32;
    for dy in 0..dst_h {
        let sy = (dy as f32 + 0.5) * y_ratio - 0.5;
        let y0 = cidx(sy.floor() as isize, src_h);
        let y1 = cidx(y0 as isize + 1, src_h);
        let fy = sy - sy.floor();
        for dx in 0..dst_w {
            let sx = (dx as f32 + 0.5) * x_ratio - 0.5;
            let x0 = cidx(sx.floor() as isize, src_w);
            let x1 = cidx(x0 as isize + 1, src_w);
            let fx = sx - sx.floor();
            let p00 = pixels[y0 * src_w + x0];
            let p10 = pixels[y0 * src_w + x1];
            let p01 = pixels[y1 * src_w + x0];
            let p11 = pixels[y1 * src_w + x1];
            let lerp_channel = |shift: u32| -> i32 {
                let top = channel(p00, shift) as f32 * (1.0 - fx) + channel(p10, shift) as f32 * fx;
                let bottom = channel(p01, shift) as f32 * (1.0 - fx) + channel(p11, shift) as f32 * fx;
                (top * (1.0 - fy) + bottom * fy) as i32
            };
            out[dy * dst_w + dx] = pack_argb(lerp_channel(24), lerp_channel(16), lerp_channel(8), lerp_channel(0));
        }
    }
    out
}

/// 1.0 for identical luma, 0.0 for maximally different (mean absolute luma difference, normalised).
pub fn quick_similarity_score(a: &[i32], b: &[i32], w: usize, h: usize) -> f32 {
    if a.is_empty() || b.is_empty() || a.len() != b.len() {
        return 0.0;
    }
    let n = (w * h).min(a.len());
    if n == 0 {
        return 0.0;
    }
    let mut sum_abs_diff = 0.0f64;
    for i in 0..n {
        let luma_a = (channel(a[i], 16) * 299 + channel(a[i], 8) * 587 + channel(a[i], 0) * 114) / 1000;
        let luma_b = (channel(b[i], 16) * 299 + channel(b[i], 8) * 587 + channel(b[i], 0) * 114) / 1000;
        sum_abs_diff += (luma_a - luma_b).abs() as f64;
    }
    let mean_abs_diff = sum_abs_diff / n as f64;
    (1.0 - mean_abs_diff / 255.0) as f32
}

/// Adds zero-mean Gaussian noise; `amount` 1.0 means sigma = 40 levels.
pub fn add_gaussian_noise(pixels: &[i32], amount: f32, seed: u32) -> Vec<i32> {
    let mut out = vec![0i32; pixels.len()];
    let mut rng = Rng::new(seed as u64);
    let sigma = amount.max(0.0) * 40.0;
    for i in 0..pixels.len() {
        let p = pixels[i];
        let r = channel(p, 16) + (rng.normal() * sigma) as i32;
        let g = channel(p, 8) + (rng.normal() * sigma) as i32;
        let b = channel(p, 0) + (rng.normal() * sigma) as i32;
        out[i] = pack_argb(channel(p, 24), r, g, b);
    }
    out
}

/// Blocky, low-detail 8x8 look of an over-compressed JPEG (block averages, quantised, blended with the original
/// by quality).
pub fn simulate_jpeg_artifacts(pixels: &[i32], w: usize, h: usize, quality_percent: i32) -> Vec<i32> {
    let mut out = pixels.to_vec();
    let quality = quality_percent.max(1).min(100);
    let step = ((100 - quality) / 4).max(1);
    let blend = quality as f32 / 100.0;
    let mut by = 0usize;
    while by < h {
        let mut bx = 0usize;
        while bx < w {
            let block_h = 8usize.min(h - by);
            let block_w = 8usize.min(w - bx);
            let (mut sum_r, mut sum_g, mut sum_b) = (0i64, 0i64, 0i64);
            let count = (block_w * block_h) as i64;
            for y in 0..block_h {
                for x in 0..block_w {
                    let p = pixels[(by + y) * w + (bx + x)];
                    sum_r += channel(p, 16) as i64;
                    sum_g += channel(p, 8) as i64;
                    sum_b += channel(p, 0) as i64;
                }
            }
            let quantize = |v: i32| (v / step) * step;
            let avg_r = quantize((sum_r / count) as i32);
            let avg_g = quantize((sum_g / count) as i32);
            let avg_b = quantize((sum_b / count) as i32);
            for y in 0..block_h {
                for x in 0..block_w {
                    let idx = (by + y) * w + (bx + x);
                    let orig = pixels[idx];
                    let r = (avg_r as f32 * (1.0 - blend) + channel(orig, 16) as f32 * blend) as i32;
                    let g = (avg_g as f32 * (1.0 - blend) + channel(orig, 8) as f32 * blend) as i32;
                    let b = (avg_b as f32 * (1.0 - blend) + channel(orig, 0) as f32 * blend) as i32;
                    out[idx] = pack_argb(channel(orig, 24), r, g, b);
                }
            }
            bx += 8;
        }
        by += 8;
    }
    out
}

/// Linear motion blur along `angle_degrees` over `length_px` pixels (alpha kept from the centre pixel).
pub fn motion_blur(pixels: &[i32], w: usize, h: usize, angle_degrees: f32, length_px: i32) -> Vec<i32> {
    if length_px <= 1 {
        return pixels.to_vec();
    }
    let mut out = vec![0i32; pixels.len()];
    let rad = angle_degrees * std::f32::consts::PI / 180.0;
    let dx = rad.cos();
    let dy = rad.sin();
    let half = length_px / 2;
    for y in 0..h {
        for x in 0..w {
            let (mut r, mut g, mut b) = (0.0f32, 0.0f32, 0.0f32);
            let mut count = 0i32;
            for t in -half..=half {
                let sx = cidx((x as f32 + dx * t as f32) as isize, w);
                let sy = cidx((y as f32 + dy * t as f32) as isize, h);
                let p = pixels[sy * w + sx];
                r += channel(p, 16) as f32;
                g += channel(p, 8) as f32;
                b += channel(p, 0) as f32;
                count += 1;
            }
            let center_alpha = channel(pixels[y * w + x], 24);
            let c = count as f32;
            out[y * w + x] = pack_argb(center_alpha, (r / c) as i32, (g / c) as i32, (b / c) as i32);
        }
    }
    out
}

/// Desaturates toward luma and warms the result, like an aged print.
pub fn color_fade(pixels: &[i32], fade_amount: f32) -> Vec<i32> {
    let f = fade_amount.max(0.0).min(1.0);
    let mut out = vec![0i32; pixels.len()];
    for i in 0..pixels.len() {
        let p = pixels[i];
        let (r, g, b) = (channel(p, 16), channel(p, 8), channel(p, 0));
        let luma = (r * 299 + g * 587 + b * 114) / 1000;
        let fr = (r as f32 * (1.0 - f) + luma as f32 * f) as i32;
        let fg = (g as f32 * (1.0 - f) + luma as f32 * f) as i32;
        let fb = (b as f32 * (1.0 - f) + luma as f32 * f) as i32;
        let fr = clamp8((fr as f32 + 15.0 * f) as i32);
        let fg = clamp8((fg as f32 + 8.0 * f) as i32);
        let fb = clamp8((fb as f32 - 15.0 * f) as i32);
        out[i] = pack_argb(channel(p, 24), fr, fg, fb);
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    fn argb(a: i32, r: i32, g: i32, b: i32) -> i32 {
        pack_argb(a, r, g, b)
    }

    #[test]
    fn blur_of_constant_image_is_constant() {
        let px = vec![argb(255, 100, 150, 200); 30 * 20];
        let out = gaussian_blur_argb(&px, 30, 20, 1.5);
        for p in out {
            assert!((channel(p, 16) - 100).abs() <= 1 && (channel(p, 8) - 150).abs() <= 1 && (channel(p, 0) - 200).abs() <= 1);
        }
    }

    #[test]
    fn identical_images_score_one() {
        let a: Vec<i32> = (0..100).map(|i| argb(255, i, i * 2 % 255, 7)).collect();
        assert!((quick_similarity_score(&a, &a, 10, 10) - 1.0).abs() < 1e-6);
    }

    #[test]
    fn resize_to_same_size_is_identity() {
        let a: Vec<i32> = (0..64).map(|i| argb(255, i * 3, i * 2, i)).collect();
        let b = resize_bilinear_argb(&a, 8, 8, 8, 8);
        assert_eq!(a, b);
    }

    #[test]
    fn jpeg_simulation_at_quality_100_changes_nothing() {
        let a: Vec<i32> = (0..256).map(|i| argb(255, i % 256, (i * 5) % 256, (i * 11) % 256)).collect();
        assert_eq!(simulate_jpeg_artifacts(&a, 16, 16, 100), a);
    }
}
