//! Classical image filters.
//!
//! * [`legacy`]   ARGB `int[]` filters used by the dataset degradation generator and the validator.
//! * [`restore`]  compression-artifact / chroma-noise removal (joint bilateral).
//! * [`sharpen`]  edge-aware sharpening: edge push + clamped unsharp mask.
//! * [`lanczos`]  band-wise Lanczos-3 upscaling straight between two bitmaps.

pub mod lanczos;
pub mod legacy;
pub mod restore;
pub mod sharpen;
