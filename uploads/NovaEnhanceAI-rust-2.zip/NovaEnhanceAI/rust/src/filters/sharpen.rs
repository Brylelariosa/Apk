//! Edge-aware ("smart") sharpening on interleaved float images (3 or 4 floats per pixel, values 0..255; the fourth
//! float, alpha, is never touched).
//!
//! A classic unsharp mask adds `amount * (pixel - blur)` everywhere, which amplifies compression noise in flat areas
//! and leaves halos on strong edges. This version:
//!
//! * takes the detail from LUMA only (no colour fringes),
//! * multiplies it by a smooth gate driven by the local gradient (flat/noisy areas are left alone, real edges get
//!   the full amount), and
//! * clamps the sharpened luma to the local min..max of the unsharpened luma plus a small overshoot, which removes
//!   halos.
//!
//! The optional first stage, the EDGE PUSH, snaps blurred step edges to the flat colours on either side - the
//! halo-free way to make soft line art crisp.
//!
//! Every output pixel reads the input within a fixed number of rows ([`SharpenParams::reach_rows`]) and does
//! fixed-order float math, so a band that carries that many real context rows reproduces a whole-image pass.

use crate::img::blur::{gaussian_plane, gaussian_radius};
use crate::img::{cidx, clampf, luma_plane};
use crate::par::{par_row_chunks_mut, rows_per_job};

const MAX_PUSH_RADIUS: i32 = 4;
const PUSH_STEEPNESS: f32 = 8.0;
const PUSH_MIN_SPAN: f32 = 8.0;
const PUSH_GATE_LOW: f32 = 4.0;
const PUSH_GATE_HIGH: f32 = 20.0;
const PUSH_DIRECTION_SLOPE: f32 = 0.414_213_56; // tan(22.5 degrees)

#[derive(Clone, Copy, Debug)]
pub struct SharpenParams {
    /// Unsharp detail gain; 0 disables the unsharp stage.
    pub amount: f32,
    /// Gaussian sigma, in pixels of THIS image, of the blur the detail is measured against.
    pub sigma: f32,
    /// The result may exceed the local min/max by this fraction of the local range.
    pub overshoot: f32,
    /// Radius of the local min/max window (1..4).
    pub clamp_radius: i32,
    /// Gradient (levels per pixel) at or below which detail is not boosted.
    pub gate_low: f32,
    /// Gradient at or above which detail gets the full amount.
    pub gate_high: f32,
    /// Edge push strength, 0 (off) .. 1.
    pub push: f32,
    /// Distance in pixels at which the two sides of an edge are sampled (1..4).
    pub push_radius: i32,
}

impl Default for SharpenParams {
    fn default() -> SharpenParams {
        SharpenParams {
            amount: 0.0,
            sigma: 1.0,
            overshoot: 0.08,
            clamp_radius: 1,
            gate_low: 2.0,
            gate_high: 12.0,
            push: 0.0,
            push_radius: 1,
        }
    }
}

fn push_sigma(radius: i32) -> f32 {
    0.6 + 0.2 * radius as f32
}

impl SharpenParams {
    /// Clamps every field into its valid range (NaN becomes "off").
    pub fn sanitized(self) -> SharpenParams {
        let mut p = self;
        p.amount = if p.amount > 0.0 { p.amount } else { 0.0 };
        p.sigma = clampf(p.sigma, 0.3, 8.0);
        p.overshoot = clampf(p.overshoot, 0.0, 1.0);
        p.clamp_radius = p.clamp_radius.max(1).min(4);
        p.push = if p.push > 0.0 { clampf(p.push, 0.0, 1.0) } else { 0.0 };
        p.push_radius = p.push_radius.max(1).min(MAX_PUSH_RADIUS);
        p
    }

    /// True if the parameters would change any pixel at all.
    pub fn enabled(&self) -> bool {
        self.amount > 0.0 || self.push > 0.0
    }

    /// Real context rows needed above and below a band: the push's reach plus the unsharp stage's reach (the second
    /// reads the first's output).
    pub fn reach_rows(&self) -> usize {
        let p = self.sanitized();
        let push = if p.push > 0.0 { gaussian_radius(push_sigma(p.push_radius)) + p.push_radius as usize } else { 0 };
        let unsharp = if p.amount > 0.0 {
            gaussian_radius(p.sigma).max(p.clamp_radius as usize).max(1)
        } else {
            0
        };
        push + unsharp
    }
}

/// For a luma plane (0..255) writes into `delta`, per pixel, the luma change the smart sharpen wants to apply:
///
/// ```text
/// detail = Y - gaussian(Y, sigma)
/// gate   = smoothstep(gateLow, gateHigh, |sobel(Y)| / 8)
/// sharp  = Y + amount * gate * detail
/// result = clamp(sharp, min - overshoot * range, max + overshoot * range)      (min/max over the (2r+1)^2 window)
/// delta  = result - Y
/// ```
fn luma_detail_delta(y: &[f32], w: usize, h: usize, p: &SharpenParams, delta: &mut [f32], threads: usize) {
    let rpj = rows_per_job(w);
    gaussian_plane(y, delta, w, h, p.sigma, threads);

    let r = p.clamp_radius as usize; // 1..4
    let gated = p.gate_high > p.gate_low;
    let gate_low = p.gate_low;
    let gate_inv = if gated { 1.0 / (p.gate_high - p.gate_low) } else { 0.0 };
    let amount = p.amount;
    let overshoot = p.overshoot;

    par_row_chunks_mut(&mut delta[..w * h], w, rpj, threads, |first_row, chunk| {
        let rows_n = chunk.len() / w;
        for ry in 0..rows_n {
            let yy = first_row + ry;
            let mut rows: [&[f32]; 9] = [&y[0..0]; 9];
            for k in 0..(2 * r + 1) {
                let idx = cidx(yy as isize + k as isize - r as isize, h);
                rows[k] = &y[idx * w..(idx + 1) * w];
            }
            let ru = rows[r - 1];
            let rc = rows[r];
            let rd = rows[r + 1];
            let out = &mut chunk[ry * w..(ry + 1) * w];
            for x in 0..w {
                let yc = rc[x];
                let mut mn = yc;
                let mut mx = yc;
                for k in 0..(2 * r + 1) {
                    let rr = rows[k];
                    for dx in -(r as isize)..=(r as isize) {
                        let v = rr[cidx(x as isize + dx, w)];
                        if v < mn {
                            mn = v;
                        }
                        if v > mx {
                            mx = v;
                        }
                    }
                }
                let xl = cidx(x as isize - 1, w);
                let xr = cidx(x as isize + 1, w);
                let gx = (ru[xr] + 2.0 * rc[xr] + rd[xr]) - (ru[xl] + 2.0 * rc[xl] + rd[xl]);
                let gy = (rd[xl] + 2.0 * rd[x] + rd[xr]) - (ru[xl] + 2.0 * ru[x] + ru[xr]);
                let grad = (gx * gx + gy * gy).sqrt() * 0.125;

                let mut gate = 1.0f32;
                if gated {
                    let t = clampf((grad - gate_low) * gate_inv, 0.0, 1.0);
                    gate = t * t * (3.0 - 2.0 * t);
                }
                let blur = out[x];
                let mut sharp = yc + amount * gate * (yc - blur);
                let range = mx - mn;
                sharp = clampf(sharp, mn - overshoot * range, mx + overshoot * range);
                out[x] = sharp - yc;
            }
        }
    });
}

/// Edge push on an interleaved float image (`w * h * stride`). `out` (same layout) receives the result; `inp` is
/// not modified; they must be different buffers.
///
/// ```text
/// Ys         = gaussian(luma(in), pushSigma)           steady luma for finding the edge direction
/// direction  = Sobel gradient of Ys, quantised to 8 directions pointing UPHILL
/// front/back = mean colour and mean Ys of the 3 pixels `pushRadius` away on the uphill / downhill side
/// t          = (Ys - Lback) / (Lfront - Lback), clamped to 0..1
/// t'         = clamp(0.5 + (t - 0.5) * steepness, 0, 1)
/// target     = lerp(Cback, Cfront, t')
/// out        = in + push * gate(|gradient|) * (target - in)
/// ```
fn edge_push(inp: &[f32], out: &mut [f32], w: usize, h: usize, stride: usize, p: &SharpenParams, threads: usize) {
    let rpj = rows_per_job(w);
    let y_plane = luma_plane(inp, w, h, stride);
    let mut ys = vec![0.0f32; w * h];
    gaussian_plane(&y_plane, &mut ys, w, h, push_sigma(p.push_radius), threads);
    drop(y_plane);

    let r = p.push_radius as isize;
    let gate_low = PUSH_GATE_LOW / r as f32;
    let gate_inv = r as f32 / (PUSH_GATE_HIGH - PUSH_GATE_LOW);
    let strength = p.push;
    let third = 1.0f32 / 3.0;
    let ys = &ys;

    par_row_chunks_mut(&mut out[..w * h * stride], w * stride, rpj, threads, |first_row, chunk| {
        let rows_n = chunk.len() / (w * stride);
        for ry in 0..rows_n {
            let y = first_row + ry;
            let ru = &ys[cidx(y as isize - 1, h) * w..cidx(y as isize - 1, h) * w + w];
            let rc = &ys[y * w..y * w + w];
            let rd = &ys[cidx(y as isize + 1, h) * w..cidx(y as isize + 1, h) * w + w];
            for x in 0..w {
                let s = (y * w + x) * stride;
                let d = (ry * w + x) * stride;
                for c in 0..stride {
                    chunk[d + c] = inp[s + c];
                }

                let xl = cidx(x as isize - 1, w);
                let xr = cidx(x as isize + 1, w);
                let gx = (ru[xr] + 2.0 * rc[xr] + rd[xr]) - (ru[xl] + 2.0 * rc[xl] + rd[xl]);
                let gy = (rd[xl] + 2.0 * rd[x] + rd[xr]) - (ru[xl] + 2.0 * ru[x] + ru[xr]);
                let grad = (gx * gx + gy * gy).sqrt() * 0.125;
                if !(grad > gate_low) {
                    continue; // gate closed: flat area or noise
                }
                let gt = clampf((grad - gate_low) * gate_inv, 0.0, 1.0);
                let weight = strength * (gt * gt * (3.0 - 2.0 * gt));

                let ax = gx.abs();
                let ay = gy.abs();
                let dx: isize = if ax > PUSH_DIRECTION_SLOPE * ay {
                    if gx > 0.0 {
                        1
                    } else {
                        -1
                    }
                } else {
                    0
                };
                let dy: isize = if ay > PUSH_DIRECTION_SLOPE * ax {
                    if gy > 0.0 {
                        1
                    } else {
                        -1
                    }
                } else {
                    0
                };

                let mut ox = [0isize; 3];
                let mut oy = [0isize; 3];
                if dx == 0 || dy == 0 {
                    for i in 0..3 {
                        ox[i] = dx * r + dy * (i as isize - 1);
                        oy[i] = dy * r + dx * (i as isize - 1);
                    }
                } else {
                    ox[0] = dx * r;
                    oy[0] = dy * r;
                    ox[1] = dx * r;
                    oy[1] = 0;
                    ox[2] = 0;
                    oy[2] = dy * r;
                }

                let (mut f_r, mut f_g, mut f_b, mut f_l) = (0.0f32, 0.0f32, 0.0f32, 0.0f32);
                let (mut b_r, mut b_g, mut b_b, mut b_l) = (0.0f32, 0.0f32, 0.0f32, 0.0f32);
                for i in 0..3 {
                    let fi = cidx(y as isize + oy[i], h) * w + cidx(x as isize + ox[i], w);
                    let bi = cidx(y as isize - oy[i], h) * w + cidx(x as isize - ox[i], w);
                    f_r += inp[fi * stride];
                    f_g += inp[fi * stride + 1];
                    f_b += inp[fi * stride + 2];
                    f_l += ys[fi];
                    b_r += inp[bi * stride];
                    b_g += inp[bi * stride + 1];
                    b_b += inp[bi * stride + 2];
                    b_l += ys[bi];
                }
                f_r *= third;
                f_g *= third;
                f_b *= third;
                f_l *= third;
                b_r *= third;
                b_g *= third;
                b_b *= third;
                b_l *= third;

                let span = f_l - b_l;
                if !(span > PUSH_MIN_SPAN) {
                    continue; // the two sides are too alike to be an edge
                }
                let pos = clampf((rc[x] - b_l) / span, 0.0, 1.0);
                let t = clampf(0.5 + (pos - 0.5) * PUSH_STEEPNESS, 0.0, 1.0);
                let s0 = inp[s];
                let s1 = inp[s + 1];
                let s2 = inp[s + 2];
                chunk[d] = s0 + weight * ((b_r + t * (f_r - b_r)) - s0);
                chunk[d + 1] = s1 + weight * ((b_g + t * (f_g - b_g)) - s1);
                chunk[d + 2] = s2 + weight * ((b_b + t * (f_b - b_b)) - s2);
            }
        }
    });
}

/// Smart sharpening in place on an interleaved float image (`stride` floats per pixel, RGB first, 0..255).
/// Results are clamped to 0..255.
pub fn smart_sharpen(band: &mut [f32], w: usize, h: usize, stride: usize, params: &SharpenParams, threads: usize) {
    let p = params.sanitized();
    if !p.enabled() || w == 0 || h == 0 {
        return;
    }
    if p.push > 0.0 {
        let mut pushed = vec![0.0f32; w * h * stride];
        edge_push(band, &mut pushed, w, h, stride, &p, threads);
        band[..w * h * stride].copy_from_slice(&pushed);
    }
    if p.amount > 0.0 {
        let y = luma_plane(band, w, h, stride);
        let mut delta = vec![0.0f32; w * h];
        luma_detail_delta(&y, w, h, &p, &mut delta, threads);
        drop(y);
        let rpj = rows_per_job(w);
        let delta = &delta;
        par_row_chunks_mut(&mut band[..w * h * stride], w * stride, rpj, threads, |first_row, chunk| {
            let rows_n = chunk.len() / (w * stride);
            for ry in 0..rows_n {
                for x in 0..w {
                    let d = delta[(first_row + ry) * w + x];
                    let o = (ry * w + x) * stride;
                    for c in 0..3 {
                        chunk[o + c] = clampf(chunk[o + c] + d, 0.0, 255.0);
                    }
                }
            }
        });
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn step_edge(w: usize, h: usize, blur: bool) -> Vec<f32> {
        let mut img = vec![0.0f32; w * h * 3];
        for y in 0..h {
            for x in 0..w {
                let v = if blur {
                    let t = ((x as f32 - (w / 2) as f32) / 3.0).max(-1.0).min(1.0) * 0.5 + 0.5;
                    40.0 + 170.0 * t
                } else if x < w / 2 {
                    40.0
                } else {
                    210.0
                };
                for c in 0..3 {
                    img[(y * w + x) * 3 + c] = v;
                }
            }
        }
        img
    }

    #[test]
    fn sharpen_never_leaves_the_local_range_by_much_and_keeps_flat_areas() {
        let (w, h) = (48usize, 20usize);
        let mut img = step_edge(w, h, true);
        let before = img.clone();
        let p = SharpenParams { amount: 1.5, sigma: 1.2, ..SharpenParams::default() };
        smart_sharpen(&mut img, w, h, 3, &p, 2);
        for i in 0..img.len() {
            assert!(img[i] >= 0.0 && img[i] <= 255.0);
        }
        // far from the edge nothing changes
        assert!((img[(10 * w + 2) * 3] - before[(10 * w + 2) * 3]).abs() < 1e-3);
        assert!((img[(10 * w + 45) * 3] - before[(10 * w + 45) * 3]).abs() < 1e-3);
    }

    #[test]
    fn edge_push_steepens_a_blurred_edge() {
        let (w, h) = (48usize, 20usize);
        let mut img = step_edge(w, h, true);
        let before = img.clone();
        let p = SharpenParams { push: 1.0, push_radius: 2, ..SharpenParams::default() };
        smart_sharpen(&mut img, w, h, 3, &p, 2);
        // a pixel on the dark side of the ramp gets darker (moves toward the dark plateau)
        let x = w / 2 - 2;
        assert!(img[(10 * w + x) * 3] <= before[(10 * w + x) * 3] + 1e-3);
    }

    #[test]
    fn band_with_context_matches_whole_image() {
        let (w, h) = (40usize, 60usize);
        let img = step_edge(w, h, true);
        let p = SharpenParams { amount: 1.2, sigma: 1.0, push: 0.6, push_radius: 1, ..SharpenParams::default() };
        let mut whole = img.clone();
        smart_sharpen(&mut whole, w, h, 3, &p, 2);

        let reach = p.reach_rows();
        let (y0, y1) = (20usize, 40usize);
        let r0 = y0 - reach;
        let r1 = y1 + reach;
        let mut band = img[r0 * w * 3..r1 * w * 3].to_vec();
        smart_sharpen(&mut band, w, r1 - r0, 3, &p, 2);
        for y in y0..y1 {
            for x in 0..w * 3 {
                let a = whole[y * w * 3 + x];
                let b = band[(y - r0) * w * 3 + x];
                assert!((a - b).abs() < 1e-3, "row {} col {}: {} vs {}", y, x, a, b);
            }
        }
    }
}
