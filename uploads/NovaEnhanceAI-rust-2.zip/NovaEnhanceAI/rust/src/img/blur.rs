//! Blur primitives on single float planes (edge-replicating borders, row-parallel).
//!
//! `src` and `dst` must be different buffers. All of them are "output row = f(a few input rows)", so band
//! processing with enough halo rows gives exactly the same result as whole-image processing.

use super::cidx;
use crate::par::{par_row_chunks_mut, rows_per_job};

pub fn gaussian_radius(sigma: f32) -> usize {
    let r = (sigma * 3.0).ceil();
    if r < 1.0 {
        1
    } else {
        r as usize
    }
}

/// Normalised 1-D Gaussian kernel with `2 * radius + 1` taps.
pub fn make_gaussian(sigma: f32, radius: usize) -> Vec<f32> {
    let mut k = vec![0.0f32; 2 * radius + 1];
    let two_sigma_sq = 2.0 * sigma * sigma;
    let mut sum = 0.0f32;
    for i in 0..k.len() {
        let d = i as f32 - radius as f32;
        let v = (-(d * d) / two_sigma_sq).exp();
        k[i] = v;
        sum += v;
    }
    for v in k.iter_mut() {
        *v /= sum;
    }
    k
}

/// Separable Gaussian blur of a `w * h` plane. `sigma <= 0` copies the input.
pub fn gaussian_plane(src: &[f32], dst: &mut [f32], w: usize, h: usize, sigma: f32, threads: usize) {
    if sigma <= 0.0 {
        dst[..w * h].copy_from_slice(&src[..w * h]);
        return;
    }
    let r = gaussian_radius(sigma);
    let g = make_gaussian(sigma, r);
    let mut tmp = vec![0.0f32; w * h];
    let rpj = rows_per_job(w);

    par_row_chunks_mut(&mut tmp, w, rpj, threads, |first_row, chunk| {
        let rows = chunk.len() / w;
        let mut pad = vec![0.0f32; w + 2 * r];
        for ry in 0..rows {
            let y = first_row + ry;
            let row = &src[y * w..(y + 1) * w];
            for i in 0..w + 2 * r {
                pad[i] = row[cidx(i as isize - r as isize, w)];
            }
            let out = &mut chunk[ry * w..(ry + 1) * w];
            for v in out.iter_mut() {
                *v = 0.0;
            }
            // Tap-major so the inner loop is a contiguous multiply-add the compiler vectorises.
            for k in 0..(2 * r + 1) {
                let wk = g[k];
                let seg = &pad[k..k + w];
                for x in 0..w {
                    out[x] += wk * seg[x];
                }
            }
        }
    });

    par_row_chunks_mut(&mut dst[..w * h], w, rpj, threads, |first_row, chunk| {
        let rows = chunk.len() / w;
        for ry in 0..rows {
            let y = first_row + ry;
            let out = &mut chunk[ry * w..(ry + 1) * w];
            for v in out.iter_mut() {
                *v = 0.0;
            }
            for k in 0..(2 * r + 1) {
                let yy = cidx(y as isize + k as isize - r as isize, h);
                let wk = g[k];
                let srow = &tmp[yy * w..(yy + 1) * w];
                for x in 0..w {
                    out[x] += wk * srow[x];
                }
            }
        }
    });
}

fn box_row(src_row: &[f32], dst_row: &mut [f32], r: usize) {
    let w = src_row.len();
    let inv = 1.0f64 / (2 * r + 1) as f64;
    let mut sum = 0.0f64;
    for k in -(r as isize)..=(r as isize) {
        sum += src_row[cidx(k, w)] as f64;
    }
    dst_row[0] = (sum * inv) as f32;
    for x in 1..w {
        sum += src_row[cidx(x as isize + r as isize, w)] as f64 - src_row[cidx(x as isize - r as isize - 1, w)] as f64;
        dst_row[x] = (sum * inv) as f32;
    }
}

/// Mean over a `(2r+1)^2` window, O(1) per pixel regardless of `r` (running sums in f64 so long rows do not drift).
pub fn box_blur_plane(src: &[f32], dst: &mut [f32], w: usize, h: usize, r: usize, threads: usize) {
    if r == 0 {
        dst[..w * h].copy_from_slice(&src[..w * h]);
        return;
    }
    let mut tmp = vec![0.0f32; w * h];
    let rpj = rows_per_job(w);
    par_row_chunks_mut(&mut tmp, w, rpj, threads, |first_row, chunk| {
        let rows = chunk.len() / w;
        for ry in 0..rows {
            let y = first_row + ry;
            box_row(&src[y * w..(y + 1) * w], &mut chunk[ry * w..(ry + 1) * w], r);
        }
    });

    let inv = 1.0f64 / (2 * r + 1) as f64;
    par_row_chunks_mut(&mut dst[..w * h], w, rpj, threads, |first_row, chunk| {
        let rows = chunk.len() / w;
        let mut acc = vec![0.0f64; w];
        for k in -(r as isize)..=(r as isize) {
            let yy = cidx(first_row as isize + k, h);
            let row = &tmp[yy * w..(yy + 1) * w];
            for x in 0..w {
                acc[x] += row[x] as f64;
            }
        }
        for ry in 0..rows {
            let y = first_row + ry;
            if ry > 0 {
                let add = cidx(y as isize + r as isize, h);
                let sub = cidx(y as isize - r as isize - 1, h);
                let ra = &tmp[add * w..(add + 1) * w];
                let rs = &tmp[sub * w..(sub + 1) * w];
                for x in 0..w {
                    acc[x] += ra[x] as f64 - rs[x] as f64;
                }
            }
            let out = &mut chunk[ry * w..(ry + 1) * w];
            for x in 0..w {
                out[x] = (acc[x] * inv) as f32;
            }
        }
    });
}

/// Guided filter (He et al.): edge-preserving smoothing of `src` steered by `guide`. `eps` is the variance (in
/// squared plane units) below which structure is flattened. Reach: 2 * `r` rows. O(1) per pixel.
pub fn guided_filter(guide: &[f32], src: &[f32], w: usize, h: usize, r: usize, eps: f32, threads: usize) -> Vec<f32> {
    let n = w * h;
    let mut mean_i = vec![0.0f32; n];
    let mut mean_p = vec![0.0f32; n];
    let mut corr_ip = vec![0.0f32; n];
    let mut corr_ii = vec![0.0f32; n];
    let mut prod = vec![0.0f32; n];

    box_blur_plane(guide, &mut mean_i, w, h, r, threads);
    box_blur_plane(src, &mut mean_p, w, h, r, threads);
    for i in 0..n {
        prod[i] = guide[i] * src[i];
    }
    box_blur_plane(&prod, &mut corr_ip, w, h, r, threads);
    for i in 0..n {
        prod[i] = guide[i] * guide[i];
    }
    box_blur_plane(&prod, &mut corr_ii, w, h, r, threads);

    // a -> corr_ip, b -> corr_ii
    for i in 0..n {
        let var_i = corr_ii[i] - mean_i[i] * mean_i[i];
        let cov_ip = corr_ip[i] - mean_i[i] * mean_p[i];
        let a = cov_ip / (var_i.max(0.0) + eps);
        let b = mean_p[i] - a * mean_i[i];
        corr_ip[i] = a;
        corr_ii[i] = b;
    }
    box_blur_plane(&corr_ip, &mut mean_i, w, h, r, threads); // mean of a
    box_blur_plane(&corr_ii, &mut mean_p, w, h, r, threads); // mean of b
    for i in 0..n {
        prod[i] = mean_i[i] * guide[i] + mean_p[i];
    }
    prod
}

/// Minimum over a `(2r+1)^2` window (separable). Meant for small planes (low-resolution maps), single-threaded.
pub fn min_filter(src: &[f32], w: usize, h: usize, r: usize) -> Vec<f32> {
    let mut tmp = vec![0.0f32; w * h];
    for y in 0..h {
        for x in 0..w {
            let mut m = f32::MAX;
            for k in -(r as isize)..=(r as isize) {
                let v = src[y * w + cidx(x as isize + k, w)];
                if v < m {
                    m = v;
                }
            }
            tmp[y * w + x] = m;
        }
    }
    let mut out = vec![0.0f32; w * h];
    for y in 0..h {
        for x in 0..w {
            let mut m = f32::MAX;
            for k in -(r as isize)..=(r as isize) {
                let v = tmp[cidx(y as isize + k, h) * w + x];
                if v < m {
                    m = v;
                }
            }
            out[y * w + x] = m;
        }
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn gaussian_keeps_constant_images_constant() {
        let (w, h) = (20usize, 13usize);
        let src = vec![77.0f32; w * h];
        let mut dst = vec![0.0f32; w * h];
        gaussian_plane(&src, &mut dst, w, h, 2.0, 3);
        for v in dst {
            assert!((v - 77.0).abs() < 1e-3);
        }
    }

    #[test]
    fn box_blur_matches_naive_mean() {
        let (w, h, r) = (17usize, 11usize, 2usize);
        let src: Vec<f32> = (0..w * h).map(|i| ((i * 37) % 255) as f32).collect();
        let mut dst = vec![0.0f32; w * h];
        box_blur_plane(&src, &mut dst, w, h, r, 3);
        for y in 0..h {
            for x in 0..w {
                let mut s = 0.0f64;
                for dy in -(r as isize)..=(r as isize) {
                    for dx in -(r as isize)..=(r as isize) {
                        s += src[cidx(y as isize + dy, h) * w + cidx(x as isize + dx, w)] as f64;
                    }
                }
                let expect = s / ((2 * r + 1) * (2 * r + 1)) as f64;
                assert!((dst[y * w + x] as f64 - expect).abs() < 1e-3, "({}, {})", x, y);
            }
        }
    }

    #[test]
    fn guided_filter_flattens_noise_but_keeps_a_step_edge() {
        let (w, h) = (40usize, 30usize);
        let mut src = vec![0.0f32; w * h];
        for y in 0..h {
            for x in 0..w {
                let base = if x < 20 { 40.0 } else { 200.0 };
                let noise = (((x * 7 + y * 13) % 5) as f32 - 2.0) * 2.0;
                src[y * w + x] = base + noise;
            }
        }
        let out = guided_filter(&src, &src, w, h, 3, 100.0, 2);
        // Interior of each flat side is smoother than the input; the edge survives.
        let left = out[15 * w + 10];
        let right = out[15 * w + 30];
        assert!((left - 40.0).abs() < 3.0);
        assert!((right - 200.0).abs() < 3.0);
        assert!(out[15 * w + 30] - out[15 * w + 10] > 150.0);
    }
}
