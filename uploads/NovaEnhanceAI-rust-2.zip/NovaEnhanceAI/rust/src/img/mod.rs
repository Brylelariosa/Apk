//! Small shared helpers for the image code. Working convention everywhere in the pipeline: interleaved RGB floats in
//! the 0..255 range ("levels"), so every threshold in the filters is in levels and matches what the filters were
//! tuned with.

pub mod blur;

#[inline(always)]
pub fn clampf(v: f32, lo: f32, hi: f32) -> f32 {
    if v < lo {
        lo
    } else if v > hi {
        hi
    } else {
        v
    }
}

/// Clamps a possibly-negative signed index into `[0, n - 1]` (edge replication).
#[inline(always)]
pub fn cidx(i: isize, n: usize) -> usize {
    if i < 0 {
        0
    } else if i as usize >= n {
        n - 1
    } else {
        i as usize
    }
}

#[inline(always)]
pub fn lerp(a: f32, b: f32, t: f32) -> f32 {
    a + (b - a) * t
}

/// Rec.601 luma of 0..255 values.
#[inline(always)]
pub fn luma(r: f32, g: f32, b: f32) -> f32 {
    0.299 * r + 0.587 * g + 0.114 * b
}

#[inline(always)]
pub fn smoothstep(e0: f32, e1: f32, x: f32) -> f32 {
    let t = clampf((x - e0) / (e1 - e0), 0.0, 1.0);
    t * t * (3.0 - 2.0 * t)
}

/// Rounds a 0..255 float to a byte (round half up, clamped).
#[inline(always)]
pub fn to_byte(v: f32) -> u8 {
    let i = (v + 0.5) as i32;
    if i < 0 {
        0
    } else if i > 255 {
        255
    } else {
        i as u8
    }
}

/// BT.601 full-range chroma scales (the offset is dropped): Cb = (B - Y) * 0.564, Cr = (R - Y) * 0.713.
pub const CB_SCALE: f32 = 0.564;
pub const CR_SCALE: f32 = 0.713;
pub const INV_CB: f32 = 1.0 / 0.564;
pub const INV_CR: f32 = 1.0 / 0.713;
pub const INV_GREEN: f32 = 1.0 / 0.587;

/// Rebuilds RGB from luma and the two scaled chroma differences.
#[inline(always)]
pub fn ycc_to_rgb(y: f32, cb: f32, cr: f32) -> (f32, f32, f32) {
    let r = y + cr * INV_CR;
    let b = y + cb * INV_CB;
    let g = (y - 0.299 * r - 0.114 * b) * INV_GREEN;
    (r, g, b)
}

/// Extracts the luma plane of an interleaved image (`stride` = 3 or 4 floats per pixel).
pub fn luma_plane(img: &[f32], w: usize, h: usize, stride: usize) -> Vec<f32> {
    let mut y = vec![0.0f32; w * h];
    for i in 0..w * h {
        let p = i * stride;
        y[i] = luma(img[p], img[p + 1], img[p + 2]);
    }
    y
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn ycc_roundtrip() {
        for &(r, g, b) in &[(10.0f32, 200.0f32, 50.0f32), (255.0, 0.0, 128.0), (0.0, 0.0, 0.0)] {
            let y = luma(r, g, b);
            let cb = (b - y) * CB_SCALE;
            let cr = (r - y) * CR_SCALE;
            let (r2, g2, b2) = ycc_to_rgb(y, cb, cr);
            assert!((r - r2).abs() < 0.01 && (g - g2).abs() < 0.01 && (b - b2).abs() < 0.01);
        }
    }

    #[test]
    fn cidx_clamps_both_ends() {
        assert_eq!(cidx(-5, 10), 0);
        assert_eq!(cidx(3, 10), 3);
        assert_eq!(cidx(12, 10), 9);
    }
}
