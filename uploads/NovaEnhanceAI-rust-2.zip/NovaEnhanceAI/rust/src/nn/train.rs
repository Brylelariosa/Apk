//! Forward + backward over a batch of 64x64 tiles. Produces the batch-AVERAGED L1-loss gradient in the flat
//! parameter layout and the batch-average loss. No optimizer step, no L2-SP, no clipping - those live in `nn::train_step`.
//!
//! Parallelism is layer-synchronous over (sample x 4-row band) jobs on scoped threads with dynamic scheduling, so it
//! scales with cores even for a batch of 1 and balances across big.LITTLE cores. Every job writes only its own
//! rows of the destination plane (handed out as disjoint `&mut` chunks - no unsafe code), and weight gradients are
//! summed in per-worker accumulators. With one thread the result is fully deterministic; with more, only float
//! summation order varies.
//!
//! Memory: ~4.3 MB of activations and gradients per sample; batches larger than [`MAX_SAMPLES_IN_FLIGHT`] run in
//! waves, so peak native memory stays at ~17 MB however large the batch is.

use super::kernels::{conv_row, conv_row_gated, conv_weight_grad};
use super::weights::{GradAcc, PackedWeights};
use super::{C1, CIN, COUT, INPUT_FLOATS, OUTPUT_FLOATS, PADDED_IMAGE_CHANNELS, TILE_SIZE, TOTAL_PARAMS};
use crate::par::run_jobs;
use std::sync::Mutex;

const SIZE: usize = TILE_SIZE; // 64
const PADDED: usize = SIZE + 2; // 66: one zero pixel on each side
const IMG_CH: usize = PADDED_IMAGE_CHANNELS; // 4
const HIDDEN: usize = C1; // 48 (C1 == C2)

// A job is (sample, BAND_ROWS consecutive rows): small enough that fast cores never wait long for slow ones at the
// end of a phase, big enough that scheduling overhead stays in the noise.
const BAND_ROWS: usize = 4;
const BANDS: usize = SIZE / BAND_ROWS;

/// Samples processed layer-synchronously at once.
pub const MAX_SAMPLES_IN_FLIGHT: usize = 4;

fn plane_floats(channels: usize) -> usize {
    PADDED * PADDED * channels
}

/// Per-sample activations and gradients. Borders are zero from construction on and never written.
struct SampleBuf {
    x: Vec<f32>,
    a1: Vec<f32>,
    a2: Vec<f32>,
    a3: Vec<f32>,
    g0: Vec<f32>,
    g1: Vec<f32>,
    d4: Vec<f32>,
}

impl SampleBuf {
    fn new() -> SampleBuf {
        SampleBuf {
            x: vec![0.0; plane_floats(IMG_CH)],
            a1: vec![0.0; plane_floats(HIDDEN)],
            a2: vec![0.0; plane_floats(HIDDEN)],
            a3: vec![0.0; plane_floats(HIDDEN)],
            g0: vec![0.0; plane_floats(HIDDEN)],
            g1: vec![0.0; plane_floats(HIDDEN)],
            d4: vec![0.0; plane_floats(IMG_CH)],
        }
    }
}

struct Workspace {
    samples: Vec<SampleBuf>,
}

static WORKSPACE: Mutex<Option<Workspace>> = Mutex::new(None);

/// Frees the activation/gradient workspace a training session keeps between steps. The next step re-creates it.
pub fn release_workspace() {
    let mut guard = WORKSPACE.lock().unwrap_or_else(|e| e.into_inner());
    *guard = None;
}

// ------------------------------------------------------------------------------------------------ forward

struct FwdJob<'a> {
    inp: &'a [f32],
    chunk: &'a mut [f32],
    y0: usize,
}

/// out = relu(bias + conv3x3(in)) for the band's rows. `chunk` holds the band's padded output rows.
fn forward_band(inp: &[f32], cin: usize, w: &[f32], b: &[f32], chunk: &mut [f32], y0: usize) {
    let pr_in = PADDED * cin;
    let pr_out = PADDED * HIDDEN;
    for yy in 0..BAND_ROWS {
        let y = y0 + yy;
        let r0 = &inp[y * pr_in..(y + 1) * pr_in];
        let r1 = &inp[(y + 1) * pr_in..(y + 2) * pr_in];
        let r2 = &inp[(y + 2) * pr_in..(y + 3) * pr_in];
        let o = yy * pr_out + HIDDEN;
        conv_row([r0, r1, r2], cin, w, Some(b), HIDDEN, SIZE, true, &mut chunk[o..o + SIZE * HIDDEN]);
    }
}

/// layer 0: x -> a1, layer 1: a1 -> a2, layer 2: a2 -> a3.
fn forward_phase(samples: &mut [SampleBuf], count: usize, layer: usize, pw: &PackedWeights, threads: usize) {
    let (cin, w, b): (usize, &[f32], &[f32]) = match layer {
        0 => (IMG_CH, pw.w1.as_slice(), pw.b1.as_slice()),
        1 => (HIDDEN, pw.w2.as_slice(), pw.b2.as_slice()),
        _ => (HIDDEN, pw.w3.as_slice(), pw.b3.as_slice()),
    };
    let mut jobs = Vec::new();
    for sb in samples.iter_mut().take(count) {
        let SampleBuf { x, a1, a2, a3, .. } = sb;
        let (inp, out): (&[f32], &mut Vec<f32>) = match layer {
            0 => (&x[..], a1),
            1 => (&a1[..], a2),
            _ => (&a2[..], a3),
        };
        let pr = PADDED * HIDDEN;
        let interior = &mut out[pr..pr + SIZE * pr];
        for (band, chunk) in interior.chunks_mut(BAND_ROWS * pr).enumerate() {
            jobs.push(FwdJob { inp, chunk, y0: band * BAND_ROWS });
        }
    }
    run_jobs(jobs, threads, || (), |_, job: FwdJob<'_>| {
        forward_band(job.inp, cin, w, b, job.chunk, job.y0);
    });
}

// ------------------------------------------------------------------------------------------------ output + loss

struct OutJob<'a> {
    a3: &'a [f32],
    d4: &'a mut [f32],
    input: &'a [f32],
    target: &'a [f32],
    y0: usize,
}

/// Layer 4 + global residual + clip + L1 loss + output gradient, for the band's rows.
/// Returns the sum of |out - target| over the band (all 3 channels).
fn output_band(job: OutJob<'_>, pw: &PackedWeights, grad_scale: f32) -> f64 {
    let OutJob { a3, d4, input, target, y0 } = job;
    let pr_in = PADDED * HIDDEN;
    let pr_d4 = PADDED * IMG_CH;
    let mut c4 = [0.0f32; SIZE * IMG_CH];
    let mut loss = 0.0f64;
    for yy in 0..BAND_ROWS {
        let y = y0 + yy;
        let r0 = &a3[y * pr_in..(y + 1) * pr_in];
        let r1 = &a3[(y + 1) * pr_in..(y + 2) * pr_in];
        let r2 = &a3[(y + 2) * pr_in..(y + 3) * pr_in];
        conv_row([r0, r1, r2], HIDDEN, &pw.w4, Some(pw.b4.as_slice()), IMG_CH, SIZE, false, &mut c4);

        let in_row = &input[y * SIZE * CIN..(y + 1) * SIZE * CIN];
        let tg_row = &target[y * SIZE * COUT..(y + 1) * SIZE * COUT];
        let d4_off = yy * pr_d4 + IMG_CH;
        for x in 0..SIZE {
            for c in 0..COUT {
                let residual = in_row[x * CIN + c] + c4[x * IMG_CH + c];
                let clipped = residual.max(0.0).min(1.0);
                let diff = clipped - tg_row[x * COUT + c];
                loss += diff.abs() as f64;
                let sign = if diff > 0.0 {
                    1.0f32
                } else if diff < 0.0 {
                    -1.0f32
                } else {
                    0.0f32
                };
                // The clip has zero gradient outside [0,1].
                d4[d4_off + x * IMG_CH + c] = if residual >= 0.0 && residual <= 1.0 { sign * grad_scale } else { 0.0 };
            }
        }
    }
    loss
}

fn output_phase(
    samples: &mut [SampleBuf],
    count: usize,
    inputs: &[f32],
    targets: &[f32],
    pw: &PackedWeights,
    grad_scale: f32,
    threads: usize,
) -> Vec<f64> {
    let mut jobs = Vec::new();
    for (s, sb) in samples.iter_mut().take(count).enumerate() {
        let SampleBuf { a3, d4, .. } = sb;
        let input = &inputs[s * INPUT_FLOATS..(s + 1) * INPUT_FLOATS];
        let target = &targets[s * OUTPUT_FLOATS..(s + 1) * OUTPUT_FLOATS];
        let pr = PADDED * IMG_CH;
        let interior = &mut d4[pr..pr + SIZE * pr];
        for (band, chunk) in interior.chunks_mut(BAND_ROWS * pr).enumerate() {
            jobs.push(OutJob { a3: &a3[..], d4: chunk, input, target, y0: band * BAND_ROWS });
        }
    }
    run_jobs(jobs, threads, || 0.0f64, |loss: &mut f64, job: OutJob<'_>| {
        *loss += output_band(job, pw, grad_scale);
    })
}

// ------------------------------------------------------------------------------------------------ backward

struct BwdJob<'a> {
    /// The layer's input plane (also the ReLU gate of the previous layer).
    a: &'a [f32],
    /// Gradient at the layer's output (pre-activation).
    gout: &'a [f32],
    /// Where to write the gradient at the previous layer's pre-activation (None for the first layer).
    gprev: Option<&'a mut [f32]>,
    y0: usize,
}

/// One backward layer for the band's rows:
///   dW/dB += weight-gradient(layer input, gradOut)
///   gradPrev = (prevActivation > 0) ? conv3x3(gradOut, flippedWeights) : 0      (skipped when `gprev` is None)
fn backward_band(job: BwdJob<'_>, cin: usize, cout: usize, flipped: Option<&[f32]>, dw: &mut [f32], db: &mut [f32]) {
    let BwdJob { a, gout, gprev, y0 } = job;
    conv_weight_grad(a, cin, gout, cout, SIZE, y0, y0 + BAND_ROWS, dw, db);
    if let (Some(chunk), Some(wt)) = (gprev, flipped) {
        let pr_g = PADDED * cout; // gradient plane row length
        let pr_a = PADDED * cin; // previous-layer plane row length
        for yy in 0..BAND_ROWS {
            let y = y0 + yy;
            let r0 = &gout[y * pr_g..(y + 1) * pr_g];
            let r1 = &gout[(y + 1) * pr_g..(y + 2) * pr_g];
            let r2 = &gout[(y + 2) * pr_g..(y + 3) * pr_g];
            let gate_start = ((y + 1) * PADDED + 1) * cin;
            let gate = &a[gate_start..gate_start + SIZE * cin];
            let o = yy * pr_a + cin;
            conv_row_gated([r0, r1, r2], cout, wt, cin, SIZE, gate, &mut chunk[o..o + SIZE * cin]);
        }
    }
}

/// Layer 4: (a3, d4) -> g0. Layer 3: (a2, g0) -> g1. Layer 2: (a1, g1) -> g0. Layer 1: (x, g0) -> nothing.
fn backward_phase(samples: &mut [SampleBuf], count: usize, layer: usize, pw: &PackedWeights, threads: usize) -> Vec<GradAcc> {
    let (cin, cout): (usize, usize) = match layer {
        4 => (HIDDEN, IMG_CH),
        3 => (HIDDEN, HIDDEN),
        2 => (HIDDEN, HIDDEN),
        _ => (IMG_CH, HIDDEN),
    };
    let flipped: Option<&[f32]> = match layer {
        4 => Some(pw.w4t.as_slice()),
        3 => Some(pw.w3t.as_slice()),
        2 => Some(pw.w2t.as_slice()),
        _ => None,
    };
    let mut jobs = Vec::new();
    for sb in samples.iter_mut().take(count) {
        let SampleBuf { x, a1, a2, a3, g0, g1, d4 } = sb;
        let (a, gout, gprev): (&[f32], &[f32], Option<&mut Vec<f32>>) = match layer {
            4 => (&a3[..], &d4[..], Some(g0)),
            3 => (&a2[..], &g0[..], Some(g1)),
            2 => (&a1[..], &g1[..], Some(g0)),
            _ => (&x[..], &g0[..], None),
        };
        match gprev {
            Some(g) => {
                let pr = PADDED * cin;
                let interior = &mut g[pr..pr + SIZE * pr];
                for (band, chunk) in interior.chunks_mut(BAND_ROWS * pr).enumerate() {
                    jobs.push(BwdJob { a, gout, gprev: Some(chunk), y0: band * BAND_ROWS });
                }
            }
            None => {
                for band in 0..BANDS {
                    jobs.push(BwdJob { a, gout, gprev: None, y0: band * BAND_ROWS });
                }
            }
        }
    }
    run_jobs(jobs, threads, GradAcc::new, |acc: &mut GradAcc, job: BwdJob<'_>| {
        let (dw, db): (&mut Vec<f32>, &mut Vec<f32>) = match layer {
            4 => (&mut acc.w4, &mut acc.b4),
            3 => (&mut acc.w3, &mut acc.b3),
            2 => (&mut acc.w2, &mut acc.b2),
            _ => (&mut acc.w1, &mut acc.b1),
        };
        backward_band(job, cin, cout, flipped, dw.as_mut_slice(), db.as_mut_slice());
    })
}

// ------------------------------------------------------------------------------------------------ driver

/// Returns `(average L1 loss, flat gradient)` for the batch. The gradient is the batch-AVERAGED L1-loss gradient in
/// the flat parameter layout (`TOTAL_PARAMS` floats).
pub fn compute_loss_and_gradient(
    input_batch: &[f32],
    target_batch: &[f32],
    batch_size: usize,
    params: &[f32],
    threads: usize,
) -> (f32, Vec<f32>) {
    if batch_size == 0 {
        return (0.0, vec![0.0; TOTAL_PARAMS]);
    }
    assert!(
        input_batch.len() >= batch_size * INPUT_FLOATS && target_batch.len() >= batch_size * OUTPUT_FLOATS,
        "training batch buffers are too small"
    );
    let pw = PackedWeights::pack(params, true);

    let mut guard = WORKSPACE.lock().unwrap_or_else(|e| e.into_inner());
    let ws = guard.get_or_insert_with(|| Workspace { samples: Vec::new() });
    let wave = batch_size.min(MAX_SAMPLES_IN_FLIGHT);
    while ws.samples.len() < wave {
        ws.samples.push(SampleBuf::new());
    }

    // dL/d(out) per value = sign(diff) / (values per sample * batch): folds both the L1 mean and the batch mean.
    let grad_scale = 1.0f32 / (OUTPUT_FLOATS as f32 * batch_size as f32);
    let mut total = GradAcc::new();
    let mut loss_sum = 0.0f64;

    let mut base = 0usize;
    while base < batch_size {
        let count = wave.min(batch_size - base);

        // Stage the input tiles as padded 4-channel planes (interior only; border and 4th channel stay 0).
        for s in 0..count {
            let src = &input_batch[(base + s) * INPUT_FLOATS..(base + s + 1) * INPUT_FLOATS];
            let plane = &mut ws.samples[s].x;
            for y in 0..SIZE {
                for x in 0..SIZE {
                    let dst = ((y + 1) * PADDED + (x + 1)) * IMG_CH;
                    let sp = (y * SIZE + x) * CIN;
                    plane[dst] = src[sp];
                    plane[dst + 1] = src[sp + 1];
                    plane[dst + 2] = src[sp + 2];
                }
            }
        }

        for layer in 0..3 {
            forward_phase(&mut ws.samples, count, layer, &pw, threads);
        }
        let losses = output_phase(
            &mut ws.samples,
            count,
            &input_batch[base * INPUT_FLOATS..],
            &target_batch[base * OUTPUT_FLOATS..],
            &pw,
            grad_scale,
            threads,
        );
        loss_sum += losses.iter().sum::<f64>();

        for layer in [4usize, 3, 2, 1] {
            let accs = backward_phase(&mut ws.samples, count, layer, &pw, threads);
            for acc in accs.iter() {
                total.add(acc);
            }
        }
        base += count;
    }

    let loss = (loss_sum / (OUTPUT_FLOATS as f64 * batch_size as f64)) as f32;
    (loss, total.to_flat())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::nn::initialize_params;
    use crate::rng::Rng;

    #[test]
    fn gradient_is_independent_of_thread_count() {
        let mut params = vec![0.0f32; TOTAL_PARAMS];
        initialize_params(&mut params, 4);
        // Make the tail layer non-trivial so the gradient is not almost zero.
        for i in 0..crate::nn::W4_SIZE {
            params[crate::nn::W4_OFFSET + i] *= 50.0;
        }
        let mut rng = Rng::new(21);
        let batch = 5usize;
        let input: Vec<f32> = (0..batch * INPUT_FLOATS).map(|_| rng.next_f32()).collect();
        let target: Vec<f32> = (0..batch * OUTPUT_FLOATS).map(|_| rng.next_f32()).collect();
        let (l1, g1) = compute_loss_and_gradient(&input, &target, batch, &params, 1);
        let (l4, g4) = compute_loss_and_gradient(&input, &target, batch, &params, 4);
        release_workspace();
        assert!((l1 - l4).abs() < 1e-4, "loss {} vs {}", l1, l4);
        for i in 0..TOTAL_PARAMS {
            assert!((g1[i] - g4[i]).abs() < 1e-4 + 1e-3 * g1[i].abs(), "grad {}: {} vs {}", i, g1[i], g4[i]);
        }
    }
}
