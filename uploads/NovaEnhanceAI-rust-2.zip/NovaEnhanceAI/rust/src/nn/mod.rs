//! The from-scratch residual CNN (no TensorFlow, no bundled model file): a model IS a flat `[f32; TOTAL_PARAMS]`.
//!
//! ```text
//! input (3 ch, [0,1])
//!   -> Conv 3x3, 3->48, ReLU
//!   -> Conv 3x3, 48->48, ReLU
//!   -> Conv 3x3, 48->48, ReLU
//!   -> Conv 3x3, 48->3            (near-zero init: a fresh model is an approximate identity)
//!   -> output = clip(input + conv4_out, 0, 1)     (global residual)
//! ```
//!
//! The flat parameter layout is the checkpoint format (unchanged from the C++ implementation, so every existing
//! `.novamodel` keeps loading): for each layer the weights `[ki][kj][cin][cout]` (cout contiguous), then the bias.

pub mod infer;
pub mod kernels;
pub mod train;
pub mod weights;

use crate::rng::Rng;

pub const TILE_SIZE: usize = 64;
pub const KERNEL: usize = 3;
pub const CIN: usize = 3;
pub const C1: usize = 48;
pub const C2: usize = 48;
pub const COUT: usize = 3;

pub const W1_SIZE: usize = KERNEL * KERNEL * CIN * C1; // 1296
pub const B1_SIZE: usize = C1; // 48
pub const W2_SIZE: usize = KERNEL * KERNEL * C1 * C1; // 20736
pub const B2_SIZE: usize = C1; // 48
pub const W3_SIZE: usize = KERNEL * KERNEL * C1 * C2; // 20736
pub const B3_SIZE: usize = C2; // 48
pub const W4_SIZE: usize = KERNEL * KERNEL * C2 * COUT; // 1296
pub const B4_SIZE: usize = COUT; // 3

pub const W1_OFFSET: usize = 0;
pub const B1_OFFSET: usize = W1_OFFSET + W1_SIZE;
pub const W2_OFFSET: usize = B1_OFFSET + B1_SIZE;
pub const B2_OFFSET: usize = W2_OFFSET + W2_SIZE;
pub const W3_OFFSET: usize = B2_OFFSET + B2_SIZE;
pub const B3_OFFSET: usize = W3_OFFSET + W3_SIZE;
pub const W4_OFFSET: usize = B3_OFFSET + B3_SIZE;
pub const B4_OFFSET: usize = W4_OFFSET + W4_SIZE;
pub const TOTAL_PARAMS: usize = B4_OFFSET + B4_SIZE; // 44211

pub const TILE_PIXELS: usize = TILE_SIZE * TILE_SIZE;
pub const INPUT_FLOATS: usize = TILE_PIXELS * CIN;
pub const OUTPUT_FLOATS: usize = TILE_PIXELS * COUT;

/// The image tensors have 3 channels, the kernels want multiples of 4: one always-zero channel is added.
pub const PADDED_IMAGE_CHANNELS: usize = 4;

/// Four stacked 3x3 convolutions: every output pixel depends on input pixels at most this far away.
pub const RECEPTIVE_FIELD_RADIUS: usize = 4;

/// Global L2-norm ceiling for the gradient vector before each Adam update (see `clip_gradient_norm`).
pub const MAX_GRADIENT_NORM: f32 = 1.0;

/// He-initialises conv1-3, near-zeros conv4 (so the network starts as an approximate identity) and zeros all biases.
pub fn initialize_params(params: &mut [f32], seed: u32) {
    assert!(params.len() >= TOTAL_PARAMS, "params must hold TOTAL_PARAMS floats");
    let mut rng = Rng::new(seed as u64);

    let mut he_init = |w: &mut [f32], fan_in: usize| {
        let stddev = (2.0f32 / fan_in as f32).sqrt();
        for v in w.iter_mut() {
            *v = rng.normal() * stddev;
        }
    };

    he_init(&mut params[W1_OFFSET..W1_OFFSET + W1_SIZE], KERNEL * KERNEL * CIN);
    he_init(&mut params[W2_OFFSET..W2_OFFSET + W2_SIZE], KERNEL * KERNEL * C1);
    he_init(&mut params[W3_OFFSET..W3_OFFSET + W3_SIZE], KERNEL * KERNEL * C1);

    for v in params[B1_OFFSET..B1_OFFSET + B1_SIZE].iter_mut() {
        *v = 0.0;
    }
    for v in params[B2_OFFSET..B2_OFFSET + B2_SIZE].iter_mut() {
        *v = 0.0;
    }
    for v in params[B3_OFFSET..B3_OFFSET + B3_SIZE].iter_mut() {
        *v = 0.0;
    }

    // Near-zero tail conv: at t=0 the network is ~identity (output ~= input) rather than noise, so a fresh install
    // "enhances" photos as a safe no-op until trained.
    let mut tail_rng = Rng::new((seed as u64) ^ 0xA5A5_5A5A_1234_5678);
    for v in params[W4_OFFSET..W4_OFFSET + W4_SIZE].iter_mut() {
        *v = tail_rng.normal() * 1e-3;
    }
    for v in params[B4_OFFSET..B4_OFFSET + B4_SIZE].iter_mut() {
        *v = 0.0;
    }
}

fn adam_update(
    params: &mut [f32],
    grads: &[f32],
    momentum: &mut [f32],
    velocity: &mut [f32],
    step: i32,
    learning_rate: f32,
) {
    let beta1 = 0.9f32;
    let beta2 = 0.999f32;
    let eps = 1e-8f32;
    let t = step.max(1) as f32;
    let bias_correction1 = 1.0 - beta1.powf(t);
    let bias_correction2 = 1.0 - beta2.powf(t);
    for i in 0..params.len() {
        momentum[i] = beta1 * momentum[i] + (1.0 - beta1) * grads[i];
        velocity[i] = beta2 * velocity[i] + (1.0 - beta2) * grads[i] * grads[i];
        let m_hat = momentum[i] / bias_correction1;
        let v_hat = velocity[i] / bias_correction2;
        params[i] -= learning_rate * m_hat / (v_hat.sqrt() + eps);
    }
}

/// Rescales `grad` in place if its L2 norm exceeds `max_norm`. A large learning rate could otherwise push every
/// output pixel to exactly 0 or 1 within a few steps; the clip's backward pass is exactly zero at saturation, so a
/// fully saturated output permanently zeroes the gradient with no way to recover. Clipping keeps any single update
/// small enough to make that dead end very unlikely.
fn clip_gradient_norm(grad: &mut [f32], max_norm: f32) {
    let mut sum_sq = 0.0f64;
    for g in grad.iter() {
        sum_sq += (*g as f64) * (*g as f64);
    }
    let norm = sum_sq.sqrt();
    if norm > max_norm as f64 {
        let scale = (max_norm as f64 / norm) as f32;
        for g in grad.iter_mut() {
            *g *= scale;
        }
    }
}

/// Forward + backward + one Adam step over a batch of 64x64 tiles, in place on `params`/`momentum`/`velocity`.
/// Returns the average L1 loss over the batch (pre-update). `anchor` may be `None` (and `l2sp_lambda` 0) to disable
/// the anti-forgetting penalty. `threads <= 0` means all.
pub fn train_step(
    input_batch: &[f32],
    target_batch: &[f32],
    batch_size: usize,
    params: &mut [f32],
    momentum: &mut [f32],
    velocity: &mut [f32],
    anchor: Option<&[f32]>,
    adam_step: i32,
    learning_rate: f32,
    l2sp_lambda: f32,
    threads: usize,
) -> f32 {
    let (loss, mut gradient) = train::compute_loss_and_gradient(input_batch, target_batch, batch_size, params, threads);

    if let Some(anchor_params) = anchor {
        if l2sp_lambda > 0.0 {
            for i in 0..TOTAL_PARAMS {
                gradient[i] += 2.0 * l2sp_lambda * (params[i] - anchor_params[i]);
            }
        }
    }

    clip_gradient_norm(&mut gradient, MAX_GRADIENT_NORM);
    adam_update(
        &mut params[..TOTAL_PARAMS],
        &gradient,
        &mut momentum[..TOTAL_PARAMS],
        &mut velocity[..TOTAL_PARAMS],
        adam_step,
        learning_rate,
    );
    loss
}

/// Runs the network over one `TILE_SIZE` x `TILE_SIZE` tile of floats in [0,1] (HWC, 3 channels).
pub fn infer_unit_tile(input: &[f32], params: &[f32]) -> Vec<f32> {
    let mut scaled: Vec<f32> = input.iter().map(|v| v * 255.0).collect();
    let weights = weights::PackedWeights::pack(params, false);
    let mut out = vec![0.0f32; scaled.len()];
    infer::infer_rgb(&scaled, TILE_SIZE, TILE_SIZE, &weights, &mut out, 1);
    scaled.clear();
    for v in out.iter_mut() {
        *v /= 255.0;
    }
    out
}

/// Which convolution kernels this build runs (for logs).
pub fn backend_name() -> &'static str {
    if cfg!(target_arch = "aarch64") {
        "rust-aarch64-neon"
    } else if cfg!(all(target_arch = "arm", target_feature = "neon")) {
        "rust-armv7-neon"
    } else if cfg!(target_arch = "arm") {
        "rust-armv7"
    } else {
        "rust-portable"
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn layout_matches_the_documented_size() {
        assert_eq!(TOTAL_PARAMS, 44211);
    }

    #[test]
    fn fresh_model_is_near_identity() {
        let mut params = vec![0.0f32; TOTAL_PARAMS];
        initialize_params(&mut params, 42);
        let mut rng = Rng::new(3);
        let input: Vec<f32> = (0..INPUT_FLOATS).map(|_| rng.next_f32()).collect();
        let out = infer_unit_tile(&input, &params);
        let mut max_diff = 0.0f32;
        for i in 0..input.len() {
            max_diff = max_diff.max((out[i] - input[i]).abs());
        }
        assert!(max_diff < 0.1, "fresh model should be close to identity, max diff {}", max_diff);
    }

    #[test]
    fn training_reduces_loss_on_a_denoising_task() {
        let mut rng = Rng::new(11);
        let mut params = vec![0.0f32; TOTAL_PARAMS];
        initialize_params(&mut params, 1);
        let mut momentum = vec![0.0f32; TOTAL_PARAMS];
        let mut velocity = vec![0.0f32; TOTAL_PARAMS];
        let target: Vec<f32> = (0..OUTPUT_FLOATS).map(|i| ((i / 3) % 64) as f32 / 63.0).collect();
        let input: Vec<f32> = target.iter().map(|v| (v + 0.1 * rng.normal()).max(0.0).min(1.0)).collect();
        let first = train_step(&input, &target, 1, &mut params, &mut momentum, &mut velocity, None, 1, 1e-3, 0.0, 2);
        let mut last = first;
        for step in 2..40 {
            last = train_step(&input, &target, 1, &mut params, &mut momentum, &mut velocity, None, step, 1e-3, 0.0, 2);
        }
        assert!(last < first, "loss should fall: {} -> {}", first, last);
    }
}
