//! Register-blocked 3x3 'same' convolution kernels (stride 1, zero padding), portable Rust.
//!
//! Data layout shared by every kernel here and by the code that calls them:
//!
//! * Activations are NHWC, one image at a time: pixel (y,x) channel c lives at `((y * W) + x) * C + c`.
//! * "Padded planes" carry a ONE-PIXEL ZERO BORDER: (H+2) x (W+2) x C, with the real image in the interior. Every
//!   kernel reads its 3x3 neighbourhood straight out of such a plane, so there is no edge special-casing in the hot
//!   loops. Callers must never write into the border.
//! * Weights are `[ki][kj][cin][cout]` with cout contiguous - exactly the flat parameter layout.
//! * Channel counts must be multiples of 4 (the 3-channel image tensors are padded to 4 channels).
//!
//! The inner loops are written as small fixed-size blocks (4 pixels x 12 or 4 output channels) held in local
//! arrays, which LLVM keeps in vector registers and vectorises (NEON on ARM) - no intrinsics needed. On AArch64 the
//! multiply-add is a fused `fmla`; elsewhere it is a plain multiply and add (a software fma would be far slower).

#[cfg(target_arch = "aarch64")]
#[inline(always)]
fn fma(a: f32, b: f32, c: f32) -> f32 {
    a.mul_add(b, c)
}

#[cfg(not(target_arch = "aarch64"))]
#[inline(always)]
fn fma(a: f32, b: f32, c: f32) -> f32 {
    a * b + c
}

/// Accumulates the 3x3 x `cin` reduction for PX adjacent output pixels and CB output channels starting at `c0`.
#[inline(always)]
fn conv_block<const PX: usize, const CB: usize>(
    rows: &[&[f32]; 3],
    cin: usize,
    weights: &[f32],
    cout: usize,
    x: usize,
    c0: usize,
    acc: &mut [[f32; CB]; PX],
) {
    for ki in 0..3 {
        let row = rows[ki];
        for kj in 0..3 {
            let tap = ki * 3 + kj;
            let wbase = tap * cin * cout + c0;
            let ibase = (x + kj) * cin;
            for ci in 0..cin {
                let woff = wbase + ci * cout;
                let wrow = &weights[woff..woff + CB];
                for p in 0..PX {
                    let v = row[ibase + p * cin + ci];
                    for b in 0..CB {
                        acc[p][b] = fma(v, wrow[b], acc[p][b]);
                    }
                }
            }
        }
    }
}

#[inline(always)]
fn row_pixels<const PX: usize, const CB: usize>(
    rows: &[&[f32]; 3],
    cin: usize,
    weights: &[f32],
    bias: Option<&[f32]>,
    cout: usize,
    relu: bool,
    out: &mut [f32],
    x: usize,
) {
    let mut c0 = 0usize;
    while c0 < cout {
        let mut acc = [[0.0f32; CB]; PX];
        if let Some(b) = bias {
            for p in 0..PX {
                for k in 0..CB {
                    acc[p][k] = b[c0 + k];
                }
            }
        }
        conv_block::<PX, CB>(rows, cin, weights, cout, x, c0, &mut acc);
        for p in 0..PX {
            let o = (x + p) * cout + c0;
            for k in 0..CB {
                let v = acc[p][k];
                out[o + k] = if relu && v < 0.0 { 0.0 } else { v };
            }
        }
        c0 += CB;
    }
}

fn conv_row_cb<const CB: usize>(
    rows: &[&[f32]; 3],
    cin: usize,
    weights: &[f32],
    bias: Option<&[f32]>,
    cout: usize,
    width: usize,
    relu: bool,
    out: &mut [f32],
) {
    let mut x = 0usize;
    while x + 4 <= width {
        row_pixels::<4, CB>(rows, cin, weights, bias, cout, relu, out, x);
        x += 4;
    }
    while x < width {
        row_pixels::<1, CB>(rows, cin, weights, bias, cout, relu, out, x);
        x += 1;
    }
}

/// One output row of `out = epi(bias + conv3x3(in, weights))`.
///
/// * `rows[0..2]`  padded input rows y-1, y, y+1. Each starts at PADDED pixel 0 (the left zero column) and is at
///   least `(width + 2) * cin` floats long.
/// * `weights`     `[3][3][cin][cout]`
/// * `bias`        `cout` floats, or `None` for zero
/// * `out`         starts at OUTPUT pixel 0 of the row; pixel stride is `cout`
/// * `relu`        apply ReLU to the result
pub fn conv_row(
    rows: [&[f32]; 3],
    cin: usize,
    weights: &[f32],
    bias: Option<&[f32]>,
    cout: usize,
    width: usize,
    relu: bool,
    out: &mut [f32],
) {
    assert!(cout % 4 == 0 && cin % 4 == 0, "channel counts must be multiples of 4");
    if cout % 12 == 0 {
        conv_row_cb::<12>(&rows, cin, weights, bias, cout, width, relu, out);
    } else {
        conv_row_cb::<4>(&rows, cin, weights, bias, cout, width, relu, out);
    }
}

/// Backward-data building block: `out = (gate > 0) ? conv3x3(in, weights) : 0`. With spatially flipped,
/// channel-transposed weights and the forward ReLU activation as `gate`, it computes dL/d(pre-activation) of the
/// previous layer in one pass. `gate` has `out`'s layout (pixel stride `cout`) and starts at output pixel 0.
pub fn conv_row_gated(
    rows: [&[f32]; 3],
    cin: usize,
    weights: &[f32],
    cout: usize,
    width: usize,
    gate: &[f32],
    out: &mut [f32],
) {
    conv_row(rows, cin, weights, None, cout, width, false, out);
    let n = width * cout;
    for i in 0..n {
        if !(gate[i] > 0.0) {
            out[i] = 0.0;
        }
    }
}

fn weight_grad_cb<const CIB: usize, const COB: usize>(
    in_pad: &[f32],
    cin: usize,
    dout_pad: &[f32],
    cout: usize,
    width: usize,
    y0: usize,
    y1: usize,
    dw: &mut [f32],
) {
    let pw = width + 2;
    for tap in 0..9 {
        let ki = tap / 3;
        let kj = tap % 3;
        let mut ci0 = 0usize;
        while ci0 < cin {
            let mut co0 = 0usize;
            while co0 < cout {
                let mut acc = [[0.0f32; COB]; CIB];
                for y in y0..y1 {
                    let in_row = &in_pad[((y + ki) * pw + kj) * cin..];
                    let d_row = &dout_pad[((y + 1) * pw + 1) * cout..];
                    for x in 0..width {
                        let ip = &in_row[x * cin + ci0..x * cin + ci0 + CIB];
                        let dp = &d_row[x * cout + co0..x * cout + co0 + COB];
                        for a in 0..CIB {
                            let v = ip[a];
                            for b in 0..COB {
                                acc[a][b] = fma(v, dp[b], acc[a][b]);
                            }
                        }
                    }
                }
                for a in 0..CIB {
                    let base = (tap * cin + ci0 + a) * cout + co0;
                    for b in 0..COB {
                        dw[base + b] += acc[a][b];
                    }
                }
                co0 += COB;
            }
            ci0 += CIB;
        }
    }
}

/// Accumulates the weight gradient of one conv layer for output rows `[y0, y1)`:
///
/// ```text
/// dW[ki][kj][ci][co] += sum_{y,x} in_pad[y+ki][x+kj][ci] * dout[y][x][co]
/// dB[co]             += sum_{y,x} dout[y][x][co]
/// ```
///
/// `in_pad` / `dout_pad` are padded planes of the layer input (`cin` channels) and of the gradient at the layer
/// output (`cout` channels), both (height+2) x (width+2). `dw` must hold `9*cin*cout` floats and `db` `cout` floats;
/// both are ACCUMULATED into, so each worker owns a private pair and the caller sums them afterwards.
pub fn conv_weight_grad(
    in_pad: &[f32],
    cin: usize,
    dout_pad: &[f32],
    cout: usize,
    width: usize,
    y0: usize,
    y1: usize,
    dw: &mut [f32],
    db: &mut [f32],
) {
    assert!(cout % 4 == 0 && cin % 4 == 0, "channel counts must be multiples of 4");
    let pw = width + 2;
    for y in y0..y1 {
        let d_row = &dout_pad[((y + 1) * pw + 1) * cout..];
        for x in 0..width {
            let dp = &d_row[x * cout..x * cout + cout];
            for co in 0..cout {
                db[co] += dp[co];
            }
        }
    }
    if cout % 12 == 0 {
        weight_grad_cb::<4, 12>(in_pad, cin, dout_pad, cout, width, y0, y1, dw);
    } else {
        weight_grad_cb::<4, 4>(in_pad, cin, dout_pad, cout, width, y0, y1, dw);
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::rng::Rng;

    /// Naive reference: padded planes in, same-size output (no padding in the output).
    fn naive_conv(inp: &[f32], cin: usize, w: &[f32], bias: &[f32], cout: usize, width: usize, height: usize) -> Vec<f32> {
        let pw = width + 2;
        let mut out = vec![0.0f32; width * height * cout];
        for y in 0..height {
            for x in 0..width {
                for co in 0..cout {
                    let mut s = bias[co] as f64;
                    for ki in 0..3 {
                        for kj in 0..3 {
                            for ci in 0..cin {
                                let v = inp[((y + ki) * pw + (x + kj)) * cin + ci] as f64;
                                s += v * w[((ki * 3 + kj) * cin + ci) * cout + co] as f64;
                            }
                        }
                    }
                    out[(y * width + x) * cout + co] = s as f32;
                }
            }
        }
        out
    }

    fn random_plane(rng: &mut Rng, width: usize, height: usize, ch: usize) -> Vec<f32> {
        let pw = width + 2;
        let mut p = vec![0.0f32; (height + 2) * pw * ch];
        for y in 0..height {
            for x in 0..width {
                for c in 0..ch {
                    p[((y + 1) * pw + (x + 1)) * ch + c] = rng.normal();
                }
            }
        }
        p
    }

    #[test]
    fn conv_row_matches_naive_reference() {
        let mut rng = Rng::new(5);
        for &(cin, cout) in &[(4usize, 48usize), (48, 48), (48, 4)] {
            let (width, height) = (11usize, 5usize);
            let plane = random_plane(&mut rng, width, height, cin);
            let w: Vec<f32> = (0..9 * cin * cout).map(|_| rng.normal() * 0.1).collect();
            let bias: Vec<f32> = (0..cout).map(|_| rng.normal() * 0.1).collect();
            let expect = naive_conv(&plane, cin, &w, &bias, cout, width, height);
            let pw = width + 2;
            for y in 0..height {
                let r = |k: usize| &plane[(y + k) * pw * cin..(y + k + 1) * pw * cin];
                let mut out = vec![0.0f32; width * cout];
                conv_row([r(0), r(1), r(2)], cin, &w, Some(bias.as_slice()), cout, width, false, &mut out);
                for i in 0..width * cout {
                    let e = expect[y * width * cout + i];
                    assert!((out[i] - e).abs() < 1e-3, "cin {} cout {} y {} i {}: {} vs {}", cin, cout, y, i, out[i], e);
                }
            }
        }
    }

    #[test]
    fn weight_grad_matches_naive_reference() {
        let mut rng = Rng::new(9);
        let (cin, cout, width, height) = (8usize, 12usize, 9usize, 6usize);
        let inp = random_plane(&mut rng, width, height, cin);
        let dout = random_plane(&mut rng, width, height, cout);
        let mut dw = vec![0.0f32; 9 * cin * cout];
        let mut db = vec![0.0f32; cout];
        conv_weight_grad(&inp, cin, &dout, cout, width, 0, height, &mut dw, &mut db);
        let pw = width + 2;
        for ki in 0..3 {
            for kj in 0..3 {
                for ci in 0..cin {
                    for co in 0..cout {
                        let mut s = 0.0f64;
                        for y in 0..height {
                            for x in 0..width {
                                s += inp[((y + ki) * pw + (x + kj)) * cin + ci] as f64
                                    * dout[((y + 1) * pw + (x + 1)) * cout + co] as f64;
                            }
                        }
                        let got = dw[((ki * 3 + kj) * cin + ci) * cout + co];
                        assert!((got as f64 - s).abs() < 1e-3, "dw mismatch {} vs {}", got, s);
                    }
                }
            }
        }
        for co in 0..cout {
            let mut s = 0.0f64;
            for y in 0..height {
                for x in 0..width {
                    s += dout[((y + 1) * pw + (x + 1)) * cout + co] as f64;
                }
            }
            assert!((db[co] as f64 - s).abs() < 1e-3);
        }
    }
}
