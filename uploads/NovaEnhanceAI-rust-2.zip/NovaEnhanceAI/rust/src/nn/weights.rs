//! Kernel-friendly copies of the flat parameter vector (a cheap per-call repack of ~44K floats), and the
//! per-worker gradient accumulator in the same padded layout.
//!
//! ```text
//!   w1  [9][4][48]   input channel 3 carries zero weights
//!   w2  [9][48][48]
//!   w3  [9][48][48]
//!   w4  [9][48][4]   output channel 3 carries zero weights and zero bias
//! ```
//!
//! For training, backward-data weights are built too. The gradient with respect to a layer's input is itself a 3x3
//! convolution of the output gradient with the kernel rotated 180 degrees and its channel axes swapped:
//! `wt[tap'][co][ci] = w[8 - tap'][ci][co]`, which lets the SAME forward kernel compute backward-data.

use super::*;

const TAPS: usize = KERNEL * KERNEL; // 9

/// src `[9][src_cin][src_cout]` -> dst `[9][dst_cin][dst_cout]`, zero-filling the padding.
fn repack_padded(src: &[f32], src_cin: usize, src_cout: usize, dst_cin: usize, dst_cout: usize) -> Vec<f32> {
    let mut dst = vec![0.0f32; TAPS * dst_cin * dst_cout];
    for tap in 0..TAPS {
        for ci in 0..src_cin {
            for co in 0..src_cout {
                dst[(tap * dst_cin + ci) * dst_cout + co] = src[(tap * src_cin + ci) * src_cout + co];
            }
        }
    }
    dst
}

/// `wt[tap][co][ci] = w[8 - tap][ci][co]`.
fn transpose_flip(w: &[f32], cin: usize, cout: usize) -> Vec<f32> {
    let mut wt = vec![0.0f32; TAPS * cout * cin];
    for tap in 0..TAPS {
        let flipped = TAPS - 1 - tap;
        for ci in 0..cin {
            for co in 0..cout {
                wt[(tap * cout + co) * cin + ci] = w[(flipped * cin + ci) * cout + co];
            }
        }
    }
    wt
}

fn pad_bias(src: &[f32], padded: usize) -> Vec<f32> {
    let mut dst = vec![0.0f32; padded];
    dst[..src.len()].copy_from_slice(src);
    dst
}

pub struct PackedWeights {
    pub w1: Vec<f32>,
    pub b1: Vec<f32>,
    pub w2: Vec<f32>,
    pub b2: Vec<f32>,
    pub w3: Vec<f32>,
    pub b3: Vec<f32>,
    pub w4: Vec<f32>,
    pub b4: Vec<f32>,
    /// Backward-data weights; empty unless packed with `with_backward`.
    pub w2t: Vec<f32>,
    pub w3t: Vec<f32>,
    pub w4t: Vec<f32>,
}

impl PackedWeights {
    pub fn pack(params: &[f32], with_backward: bool) -> PackedWeights {
        let w1 = repack_padded(&params[W1_OFFSET..W1_OFFSET + W1_SIZE], CIN, C1, PADDED_IMAGE_CHANNELS, C1);
        let b1 = pad_bias(&params[B1_OFFSET..B1_OFFSET + B1_SIZE], C1);
        let w2 = params[W2_OFFSET..W2_OFFSET + W2_SIZE].to_vec();
        let b2 = pad_bias(&params[B2_OFFSET..B2_OFFSET + B2_SIZE], C1);
        let w3 = params[W3_OFFSET..W3_OFFSET + W3_SIZE].to_vec();
        let b3 = pad_bias(&params[B3_OFFSET..B3_OFFSET + B3_SIZE], C2);
        let w4 = repack_padded(&params[W4_OFFSET..W4_OFFSET + W4_SIZE], C2, COUT, C2, PADDED_IMAGE_CHANNELS);
        let b4 = pad_bias(&params[B4_OFFSET..B4_OFFSET + B4_SIZE], PADDED_IMAGE_CHANNELS);

        let (w2t, w3t, w4t) = if with_backward {
            (
                transpose_flip(&w2, C1, C1),
                transpose_flip(&w3, C1, C2),
                transpose_flip(&w4, C2, PADDED_IMAGE_CHANNELS),
            )
        } else {
            (Vec::new(), Vec::new(), Vec::new())
        };

        PackedWeights { w1, b1, w2, b2, w3, b3, w4, b4, w2t, w3t, w4t }
    }
}

/// Per-worker gradient accumulator in the padded kernel layout.
pub struct GradAcc {
    pub w1: Vec<f32>,
    pub b1: Vec<f32>,
    pub w2: Vec<f32>,
    pub b2: Vec<f32>,
    pub w3: Vec<f32>,
    pub b3: Vec<f32>,
    pub w4: Vec<f32>,
    pub b4: Vec<f32>,
}

impl GradAcc {
    pub fn new() -> GradAcc {
        GradAcc {
            w1: vec![0.0; TAPS * PADDED_IMAGE_CHANNELS * C1],
            b1: vec![0.0; C1],
            w2: vec![0.0; TAPS * C1 * C1],
            b2: vec![0.0; C1],
            w3: vec![0.0; TAPS * C1 * C2],
            b3: vec![0.0; C2],
            w4: vec![0.0; TAPS * C2 * PADDED_IMAGE_CHANNELS],
            b4: vec![0.0; PADDED_IMAGE_CHANNELS],
        }
    }

    pub fn add(&mut self, other: &GradAcc) {
        fn accumulate(dst: &mut [f32], src: &[f32]) {
            for i in 0..dst.len() {
                dst[i] += src[i];
            }
        }
        accumulate(&mut self.w1, &other.w1);
        accumulate(&mut self.b1, &other.b1);
        accumulate(&mut self.w2, &other.w2);
        accumulate(&mut self.b2, &other.b2);
        accumulate(&mut self.w3, &other.w3);
        accumulate(&mut self.b3, &other.b3);
        accumulate(&mut self.w4, &other.w4);
        accumulate(&mut self.b4, &other.b4);
    }

    /// The gradient in the flat parameter layout (dropping the padded channels).
    pub fn to_flat(&self) -> Vec<f32> {
        let mut flat = vec![0.0f32; TOTAL_PARAMS];
        for tap in 0..TAPS {
            for ci in 0..CIN {
                for co in 0..C1 {
                    flat[W1_OFFSET + (tap * CIN + ci) * C1 + co] = self.w1[(tap * PADDED_IMAGE_CHANNELS + ci) * C1 + co];
                }
            }
        }
        flat[B1_OFFSET..B1_OFFSET + B1_SIZE].copy_from_slice(&self.b1[..B1_SIZE]);
        flat[W2_OFFSET..W2_OFFSET + W2_SIZE].copy_from_slice(&self.w2);
        flat[B2_OFFSET..B2_OFFSET + B2_SIZE].copy_from_slice(&self.b2[..B2_SIZE]);
        flat[W3_OFFSET..W3_OFFSET + W3_SIZE].copy_from_slice(&self.w3);
        flat[B3_OFFSET..B3_OFFSET + B3_SIZE].copy_from_slice(&self.b3[..B3_SIZE]);
        for tap in 0..TAPS {
            for ci in 0..C2 {
                for co in 0..COUT {
                    flat[W4_OFFSET + (tap * C2 + ci) * COUT + co] = self.w4[(tap * C2 + ci) * PADDED_IMAGE_CHANNELS + co];
                }
            }
        }
        flat[B4_OFFSET..B4_OFFSET + B4_SIZE].copy_from_slice(&self.b4[..B4_SIZE]);
        flat
    }
}

impl Default for GradAcc {
    fn default() -> Self {
        GradAcc::new()
    }
}
