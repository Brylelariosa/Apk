//! Fused, streaming, multi-threaded forward pass over an image of ANY size.
//!
//! The result equals running the network as ONE fully-convolutional pass over the image: zero padding applies only
//! at the image's true border, never at internal boundaries - so there are no tile seams. Rows are streamed through
//! all four layers once: every layer keeps just its 3 newest rows in a ring buffer, so the whole pipeline's working
//! set is ~150 KB per worker and the activations never leave the core's cache.
//!
//! ```text
//! step t:  load input row t -> L1 row t-1 -> L2 row t-2 -> L3 row t-3 -> L4/output row t-4
//! ```
//!
//! Work is split into vertical column strips (with a 4 px halo of real context on interior sides) that run in
//! parallel; each strip returns its own output block which is copied into place afterwards, so no two threads ever
//! write the same memory.

use super::kernels::conv_row;
use super::weights::PackedWeights;
use super::{C1, PADDED_IMAGE_CHANNELS, RECEPTIVE_FIELD_RADIUS};
use crate::par::run_jobs;

const HALO: usize = RECEPTIVE_FIELD_RADIUS;
const MIN_STRIP: usize = 32;
const MAX_STRIP: usize = 128;
const IMG_CH: usize = PADDED_IMAGE_CHANNELS; // 4
const HIDDEN: usize = C1; // 48

fn choose_strip_width(width: usize, threads: usize) -> usize {
    // ~2 strips per thread so dynamic scheduling can even out fast and slow cores.
    let t = threads.max(1);
    let s = (width + 2 * t - 1) / (2 * t);
    let s = s.max(MIN_STRIP).min(MAX_STRIP);
    (s + 3) & !3
}

/// The three padded rows (r-1, r, r+1) of a 3-slot ring; rows outside the image are the shared zero row.
fn ring_rows<'a>(ring: &'a [f32], zero: &'a [f32], stride: usize, r: usize, height: usize) -> [&'a [f32]; 3] {
    let up = if r > 0 {
        let s = ((r - 1) % 3) * stride;
        &ring[s..s + stride]
    } else {
        zero
    };
    let mid = {
        let s = (r % 3) * stride;
        &ring[s..s + stride]
    };
    let down = if r + 1 < height {
        let s = ((r + 1) % 3) * stride;
        &ring[s..s + stride]
    } else {
        zero
    };
    [up, mid, down]
}

/// Streams ONE vertical strip (image columns `[x0, x1)`) top-to-bottom through all four layers and returns its
/// output block (`img_h * (x1 - x0) * 3` floats, values 0..255).
fn run_strip(src: &[f32], img_w: usize, img_h: usize, x0: usize, x1: usize, pw: &PackedWeights) -> Vec<f32> {
    // Context columns exist only where the image does: at a true image border the zero padding inside the kernels
    // is the correct behaviour.
    let xs = x0.saturating_sub(HALO);
    let xe = (x1 + HALO).min(img_w);
    let sw = xe - xs; // strip width including halo
    let wp = sw + 2; // ring rows are padded by one zero pixel on each side

    let in_stride = wp * IMG_CH;
    let hid_stride = wp * HIDDEN;
    let mut in_ring = vec![0.0f32; 3 * in_stride];
    let mut a1 = vec![0.0f32; 3 * hid_stride];
    let mut a2 = vec![0.0f32; 3 * hid_stride];
    let mut a3 = vec![0.0f32; 3 * hid_stride];
    let zero_img = vec![0.0f32; in_stride];
    let zero_hid = vec![0.0f32; hid_stride];
    let mut c4 = vec![0.0f32; sw * IMG_CH];

    let out_w = x1 - x0;
    let mut out = vec![0.0f32; img_h * out_w * 3];
    let inv255 = 1.0f32 / 255.0;
    let keep0 = x0 - xs; // first kept column, local to the strip

    for t in 0..img_h + 4 {
        if t < img_h {
            let slot = (t % 3) * in_stride + IMG_CH;
            let dst_row = &mut in_ring[slot..slot + sw * IMG_CH];
            let src_row = &src[(t * img_w + xs) * 3..(t * img_w + xs + sw) * 3];
            for i in 0..sw {
                dst_row[i * 4] = src_row[i * 3] * inv255;
                dst_row[i * 4 + 1] = src_row[i * 3 + 1] * inv255;
                dst_row[i * 4 + 2] = src_row[i * 3 + 2] * inv255;
                dst_row[i * 4 + 3] = 0.0;
            }
        }

        if t >= 1 {
            let r = t - 1; // layer 1
            if r < img_h {
                let rows = ring_rows(&in_ring, &zero_img, in_stride, r, img_h);
                let o = (r % 3) * hid_stride + HIDDEN;
                conv_row(rows, IMG_CH, &pw.w1, Some(pw.b1.as_slice()), HIDDEN, sw, true, &mut a1[o..o + sw * HIDDEN]);
            }
        }
        if t >= 2 {
            let r = t - 2; // layer 2
            if r < img_h {
                let rows = ring_rows(&a1, &zero_hid, hid_stride, r, img_h);
                let o = (r % 3) * hid_stride + HIDDEN;
                conv_row(rows, HIDDEN, &pw.w2, Some(pw.b2.as_slice()), HIDDEN, sw, true, &mut a2[o..o + sw * HIDDEN]);
            }
        }
        if t >= 3 {
            let r = t - 3; // layer 3
            if r < img_h {
                let rows = ring_rows(&a2, &zero_hid, hid_stride, r, img_h);
                let o = (r % 3) * hid_stride + HIDDEN;
                conv_row(rows, HIDDEN, &pw.w3, Some(pw.b3.as_slice()), HIDDEN, sw, true, &mut a3[o..o + sw * HIDDEN]);
            }
        }
        if t >= 4 {
            let r = t - 4; // layer 4 + global residual + output
            if r < img_h {
                let rows = ring_rows(&a3, &zero_hid, hid_stride, r, img_h);
                conv_row(rows, HIDDEN, &pw.w4, Some(pw.b4.as_slice()), IMG_CH, sw, false, &mut c4);
                for lx in keep0..keep0 + out_w {
                    let px = (r * img_w + xs + lx) * 3;
                    let o = (r * out_w + (lx - keep0)) * 3;
                    for c in 0..3 {
                        let v = src[px + c] * inv255 + c4[lx * 4 + c];
                        out[o + c] = v.max(0.0).min(1.0) * 255.0;
                    }
                }
            }
        }
    }
    out
}

struct StripResult {
    x0: usize,
    x1: usize,
    data: Vec<f32>,
}

/// Runs the network over an RGB float image (`w * h * 3`, interleaved, values 0..255) and writes the result (same
/// layout and range) into `dst`. `src` and `dst` must be different buffers.
pub fn infer_rgb(src: &[f32], w: usize, h: usize, weights: &PackedWeights, dst: &mut [f32], threads: usize) {
    if w == 0 || h == 0 {
        return;
    }
    assert!(src.len() >= w * h * 3 && dst.len() >= w * h * 3, "infer_rgb: buffers too small");
    let strip = choose_strip_width(w, threads);
    let mut jobs: Vec<(usize, usize)> = Vec::new();
    let mut x0 = 0usize;
    while x0 < w {
        jobs.push((x0, (x0 + strip).min(w)));
        x0 += strip;
    }

    let states: Vec<Vec<StripResult>> = run_jobs(
        jobs,
        threads,
        Vec::new,
        |results: &mut Vec<StripResult>, (a, b): (usize, usize)| {
            let data = run_strip(src, w, h, a, b, weights);
            results.push(StripResult { x0: a, x1: b, data });
        },
    );

    for worker in states {
        for r in worker {
            let sw = r.x1 - r.x0;
            for y in 0..h {
                let from = &r.data[y * sw * 3..(y + 1) * sw * 3];
                let to = (y * w + r.x0) * 3;
                dst[to..to + sw * 3].copy_from_slice(from);
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::nn::{initialize_params, TOTAL_PARAMS};
    use crate::rng::Rng;

    #[test]
    fn strips_give_the_same_result_as_one_pass() {
        let mut params = vec![0.0f32; TOTAL_PARAMS];
        initialize_params(&mut params, 17);
        // Make the tail layer non-trivial so differences cannot hide.
        for i in 0..crate::nn::W4_SIZE {
            params[crate::nn::W4_OFFSET + i] *= 200.0;
        }
        let weights = PackedWeights::pack(&params, false);
        let mut rng = Rng::new(99);
        let (w, h) = (150usize, 23usize);
        let src: Vec<f32> = (0..w * h * 3).map(|_| rng.next_f32() * 255.0).collect();
        let mut one = vec![0.0f32; w * h * 3];
        let mut many = vec![0.0f32; w * h * 3];
        infer_rgb(&src, w, h, &weights, &mut one, 1);
        infer_rgb(&src, w, h, &weights, &mut many, 4);
        for i in 0..one.len() {
            assert!((one[i] - many[i]).abs() < 1e-2, "i {}: {} vs {}", i, one[i], many[i]);
        }
    }
}
