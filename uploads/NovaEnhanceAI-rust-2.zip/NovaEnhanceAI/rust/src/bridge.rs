//! JNI entry points. Three Kotlin singletons call in here:
//!
//! * `NativeImageProcessor`  ARGB `int[]` filters, the Lanczos upscaler (bitmap to bitmap).
//! * `NativeNeuralEngine`    CNN initialisation, inference and training.
//! * `NativeEnhancer`        the enhancement session: open (analysis + plan), process bands, close.
//!
//! Every function runs its body through [`guard`]: a bad argument becomes an `IllegalArgumentException`, a failed
//! operation an `IllegalStateException`, and even a Rust panic becomes a `RuntimeException` instead of killing the
//! app. Names follow the JNI convention `Java_<package>_<Class>_<method>` (the package has no underscores, so no
//! escaping is needed).
#![allow(non_snake_case)]

use std::collections::HashMap;
use std::os::raw::c_void;
use std::sync::atomic::{AtomicI64, Ordering};
use std::sync::{Arc, Mutex, Once};

use crate::enhance::analysis::PixelSource;
use crate::enhance::session::{RowIo, Session};
use crate::filters::sharpen::SharpenParams;
use crate::filters::{lanczos, legacy};
use crate::img::to_byte;
use crate::jni::{guard, Env, JBoolean, JFloat, JInt, JLong, JObject, NativeError, RawEnv, JNI_TRUE};
use crate::nn;
use crate::par::resolve_threads;
use crate::sys::{log_error, LockedBitmap};

// ------------------------------------------------------------------------------------------------ plumbing

impl PixelSource for LockedBitmap {
    fn width(&self) -> usize {
        self.width
    }
    fn height(&self) -> usize {
        self.height
    }
    fn row(&self, y: usize) -> &[u8] {
        unsafe { LockedBitmap::row(self, y) }
    }
}

impl RowIo for LockedBitmap {
    fn write_row(&self, y: usize, data: &[u8]) {
        unsafe {
            LockedBitmap::row_mut(self, y).copy_from_slice(data);
        }
    }
}

static HOOK: Once = Once::new();

fn install_panic_hook() {
    HOOK.call_once(|| {
        std::panic::set_hook(Box::new(|info| {
            log_error(&format!("panic: {}", info));
        }));
    });
}

/// Called by the JVM when the library is loaded.
#[no_mangle]
pub extern "system" fn JNI_OnLoad(_vm: *mut c_void, _reserved: *mut c_void) -> JInt {
    install_panic_hook();
    0x0001_0006 // JNI_VERSION_1_6
}

static SESSIONS: Mutex<Option<HashMap<i64, Arc<Session>>>> = Mutex::new(None);
static NEXT_SESSION: AtomicI64 = AtomicI64::new(1);

fn register_session(session: Session) -> i64 {
    let id = NEXT_SESSION.fetch_add(1, Ordering::Relaxed);
    let mut sessions = SESSIONS.lock().unwrap_or_else(|e| e.into_inner());
    sessions.get_or_insert_with(HashMap::new).insert(id, Arc::new(session));
    id
}

fn lookup_session(id: i64) -> Option<Arc<Session>> {
    let sessions = SESSIONS.lock().unwrap_or_else(|e| e.into_inner());
    sessions.as_ref().and_then(|m| m.get(&id).cloned())
}

fn unregister_session(id: i64) {
    let mut sessions = SESSIONS.lock().unwrap_or_else(|e| e.into_inner());
    if let Some(map) = sessions.as_mut() {
        map.remove(&id);
    }
}

unsafe fn read_pixels(env: Env, array: JObject, width: JInt, height: JInt, what: &str) -> Result<Vec<i32>, NativeError> {
    if array.is_null() {
        return Err(NativeError::arg(format!("{}: pixel array is null", what)));
    }
    if width <= 0 || height <= 0 {
        return Err(NativeError::arg(format!("{}: width and height must be positive", what)));
    }
    let n = env.array_len(array);
    let expect = (width as usize) * (height as usize);
    if n != expect {
        return Err(NativeError::arg(format!(
            "{}: pixel array holds {} ints but {}x{} needs {}",
            what, n, width, height, expect
        )));
    }
    Ok(env.read_ints(array))
}

unsafe fn read_float_array(env: Env, array: JObject, what: &str) -> Result<Vec<f32>, NativeError> {
    if array.is_null() {
        return Err(NativeError::arg(format!("{}: array is null", what)));
    }
    Ok(env.read_floats(array))
}

fn sharpen_params(amount: f32, sigma: f32, overshoot: f32, clamp_radius: i32, gate_low: f32, gate_high: f32, push: f32, push_radius: i32) -> SharpenParams {
    SharpenParams { amount, sigma, overshoot, clamp_radius, gate_low, gate_high, push, push_radius }.sanitized()
}

// ------------------------------------------------------------------------------------------------ NativeImageProcessor

#[no_mangle]
pub unsafe extern "system" fn Java_com_novaenhance_ai_ai_engine_NativeImageProcessor_nativeGaussianBlur(
    env: RawEnv,
    _this: JObject,
    pixels: JObject,
    width: JInt,
    height: JInt,
    sigma: JFloat,
) -> JObject {
    let e = Env(env);
    guard(e, std::ptr::null_mut(), || -> Result<JObject, NativeError> {
        let px = read_pixels(e, pixels, width, height, "gaussianBlur")?;
        let out = legacy::gaussian_blur_argb(&px, width as usize, height as usize, sigma);
        Ok(e.new_int_array(&out))
    })
}

#[no_mangle]
pub unsafe extern "system" fn Java_com_novaenhance_ai_ai_engine_NativeImageProcessor_nativeResizeBilinear(
    env: RawEnv,
    _this: JObject,
    pixels: JObject,
    src_width: JInt,
    src_height: JInt,
    dst_width: JInt,
    dst_height: JInt,
) -> JObject {
    let e = Env(env);
    guard(e, std::ptr::null_mut(), || -> Result<JObject, NativeError> {
        let px = read_pixels(e, pixels, src_width, src_height, "resizeBilinear")?;
        if dst_width <= 0 || dst_height <= 0 {
            return Err(NativeError::arg("resizeBilinear: destination size must be positive"));
        }
        let out = legacy::resize_bilinear_argb(&px, src_width as usize, src_height as usize, dst_width as usize, dst_height as usize);
        Ok(e.new_int_array(&out))
    })
}

#[no_mangle]
pub unsafe extern "system" fn Java_com_novaenhance_ai_ai_engine_NativeImageProcessor_nativeQuickSimilarityScore(
    env: RawEnv,
    _this: JObject,
    a: JObject,
    b: JObject,
    width: JInt,
    height: JInt,
) -> JFloat {
    let e = Env(env);
    guard(e, 0.0f32, || -> Result<JFloat, NativeError> {
        let pa = read_pixels(e, a, width, height, "similarity(a)")?;
        let pb = read_pixels(e, b, width, height, "similarity(b)")?;
        Ok(legacy::quick_similarity_score(&pa, &pb, width as usize, height as usize))
    })
}

#[no_mangle]
pub unsafe extern "system" fn Java_com_novaenhance_ai_ai_engine_NativeImageProcessor_nativeAddGaussianNoise(
    env: RawEnv,
    _this: JObject,
    pixels: JObject,
    width: JInt,
    height: JInt,
    amount: JFloat,
    seed: JInt,
) -> JObject {
    let e = Env(env);
    guard(e, std::ptr::null_mut(), || -> Result<JObject, NativeError> {
        let px = read_pixels(e, pixels, width, height, "addGaussianNoise")?;
        let out = legacy::add_gaussian_noise(&px, amount, seed as u32);
        Ok(e.new_int_array(&out))
    })
}

#[no_mangle]
pub unsafe extern "system" fn Java_com_novaenhance_ai_ai_engine_NativeImageProcessor_nativeSimulateJpegArtifacts(
    env: RawEnv,
    _this: JObject,
    pixels: JObject,
    width: JInt,
    height: JInt,
    quality_percent: JInt,
) -> JObject {
    let e = Env(env);
    guard(e, std::ptr::null_mut(), || -> Result<JObject, NativeError> {
        let px = read_pixels(e, pixels, width, height, "simulateJpegArtifacts")?;
        let out = legacy::simulate_jpeg_artifacts(&px, width as usize, height as usize, quality_percent);
        Ok(e.new_int_array(&out))
    })
}

#[no_mangle]
pub unsafe extern "system" fn Java_com_novaenhance_ai_ai_engine_NativeImageProcessor_nativeMotionBlur(
    env: RawEnv,
    _this: JObject,
    pixels: JObject,
    width: JInt,
    height: JInt,
    angle_degrees: JFloat,
    length_px: JInt,
) -> JObject {
    let e = Env(env);
    guard(e, std::ptr::null_mut(), || -> Result<JObject, NativeError> {
        let px = read_pixels(e, pixels, width, height, "motionBlur")?;
        let out = legacy::motion_blur(&px, width as usize, height as usize, angle_degrees, length_px);
        Ok(e.new_int_array(&out))
    })
}

#[no_mangle]
pub unsafe extern "system" fn Java_com_novaenhance_ai_ai_engine_NativeImageProcessor_nativeColorFade(
    env: RawEnv,
    _this: JObject,
    pixels: JObject,
    width: JInt,
    height: JInt,
    fade_amount: JFloat,
) -> JObject {
    let e = Env(env);
    guard(e, std::ptr::null_mut(), || -> Result<JObject, NativeError> {
        let px = read_pixels(e, pixels, width, height, "colorFade")?;
        let out = legacy::color_fade(&px, fade_amount);
        Ok(e.new_int_array(&out))
    })
}

#[no_mangle]
pub unsafe extern "system" fn Java_com_novaenhance_ai_ai_engine_NativeImageProcessor_nativeUpscaleBand(
    env: RawEnv,
    _this: JObject,
    src: JObject,
    dst: JObject,
    factor: JInt,
    y0: JInt,
    y1: JInt,
    amount: JFloat,
    sigma: JFloat,
    overshoot: JFloat,
    clamp_radius: JInt,
    gate_low: JFloat,
    gate_high: JFloat,
    push: JFloat,
    push_radius: JInt,
    threads: JInt,
) -> JBoolean {
    let e = Env(env);
    guard(e, 0u8, || -> Result<JBoolean, NativeError> {
        if factor < 1 || factor > 8 {
            return Err(NativeError::arg("upscaleBand: factor must be 1..8"));
        }
        let src_lock = LockedBitmap::lock(e.as_void(), src).map_err(NativeError::state)?;
        let dst_lock = LockedBitmap::lock(e.as_void(), dst).map_err(NativeError::state)?;
        let f = factor as usize;
        if src_lock.address() == dst_lock.address() {
            return Err(NativeError::arg("upscaleBand: source and destination must be different bitmaps"));
        }
        if dst_lock.width != src_lock.width * f || dst_lock.height != src_lock.height * f {
            return Err(NativeError::arg("upscaleBand: destination must be exactly factor times the source size"));
        }
        if y0 < 0 || y1 < y0 || y1 as usize > dst_lock.height {
            return Err(NativeError::arg("upscaleBand: row range is outside the destination"));
        }
        let sharpen = sharpen_params(amount, sigma, overshoot, clamp_radius, gate_low, gate_high, push, push_radius);
        lanczos::upscale_rows(
            src_lock.bytes(),
            src_lock.stride,
            src_lock.width,
            src_lock.height,
            dst_lock.bytes_mut(),
            dst_lock.stride,
            f,
            y0 as usize,
            y1 as usize,
            &sharpen,
            resolve_threads(threads),
        );
        Ok(JNI_TRUE)
    })
}

// ------------------------------------------------------------------------------------------------ NativeNeuralEngine

#[no_mangle]
pub unsafe extern "system" fn Java_com_novaenhance_ai_ai_engine_NativeNeuralEngine_nativeInitializeParams(
    env: RawEnv,
    _this: JObject,
    params: JObject,
    seed: JLong,
) {
    let e = Env(env);
    guard(e, (), || -> Result<(), NativeError> {
        let mut p = read_float_array(e, params, "initializeParams")?;
        if p.len() < nn::TOTAL_PARAMS {
            return Err(NativeError::arg(format!("initializeParams: expected {} floats, got {}", nn::TOTAL_PARAMS, p.len())));
        }
        nn::initialize_params(&mut p, seed as u32);
        e.write_floats(params, &p);
        Ok(())
    })
}

#[no_mangle]
pub unsafe extern "system" fn Java_com_novaenhance_ai_ai_engine_NativeNeuralEngine_nativeInfer(
    env: RawEnv,
    _this: JObject,
    input: JObject,
    params: JObject,
) -> JObject {
    let e = Env(env);
    guard(e, std::ptr::null_mut(), || -> Result<JObject, NativeError> {
        let inp = read_float_array(e, input, "infer(input)")?;
        let p = read_float_array(e, params, "infer(params)")?;
        if inp.len() != nn::INPUT_FLOATS {
            return Err(NativeError::arg(format!("infer: input must hold {} floats, got {}", nn::INPUT_FLOATS, inp.len())));
        }
        if p.len() < nn::TOTAL_PARAMS {
            return Err(NativeError::arg(format!("infer: params must hold {} floats, got {}", nn::TOTAL_PARAMS, p.len())));
        }
        let out = nn::infer_unit_tile(&inp, &p);
        Ok(e.new_float_array(&out))
    })
}

#[no_mangle]
pub unsafe extern "system" fn Java_com_novaenhance_ai_ai_engine_NativeNeuralEngine_nativeTrainStep(
    env: RawEnv,
    _this: JObject,
    input_batch: JObject,
    target_batch: JObject,
    batch_size: JInt,
    params: JObject,
    momentum: JObject,
    velocity: JObject,
    anchor_params: JObject,
    adam_step: JInt,
    learning_rate: JFloat,
    l2sp_lambda: JFloat,
    threads: JInt,
) -> JFloat {
    let e = Env(env);
    guard(e, 0.0f32, || -> Result<JFloat, NativeError> {
        if batch_size <= 0 {
            return Err(NativeError::arg("trainStep: batchSize must be positive"));
        }
        let b = batch_size as usize;
        let input = read_float_array(e, input_batch, "trainStep(input)")?;
        let target = read_float_array(e, target_batch, "trainStep(target)")?;
        let mut p = read_float_array(e, params, "trainStep(params)")?;
        let mut m = read_float_array(e, momentum, "trainStep(momentum)")?;
        let mut v = read_float_array(e, velocity, "trainStep(velocity)")?;
        let anchor = if anchor_params.is_null() { None } else { Some(e.read_floats(anchor_params)) };
        if input.len() < b * nn::INPUT_FLOATS || target.len() < b * nn::OUTPUT_FLOATS {
            return Err(NativeError::arg("trainStep: batch arrays are smaller than batchSize tiles"));
        }
        if p.len() < nn::TOTAL_PARAMS || m.len() < nn::TOTAL_PARAMS || v.len() < nn::TOTAL_PARAMS {
            return Err(NativeError::arg("trainStep: params/momentum/velocity must each hold TOTAL_PARAMS floats"));
        }
        if let Some(a) = anchor.as_ref() {
            if a.len() < nn::TOTAL_PARAMS {
                return Err(NativeError::arg("trainStep: anchor params must hold TOTAL_PARAMS floats"));
            }
        }
        let loss = nn::train_step(
            &input,
            &target,
            b,
            &mut p,
            &mut m,
            &mut v,
            anchor.as_deref(),
            adam_step,
            learning_rate,
            l2sp_lambda,
            resolve_threads(threads),
        );
        e.write_floats(params, &p);
        e.write_floats(momentum, &m);
        e.write_floats(velocity, &v);
        Ok(loss)
    })
}

#[no_mangle]
pub unsafe extern "system" fn Java_com_novaenhance_ai_ai_engine_NativeNeuralEngine_nativeInferRegion(
    env: RawEnv,
    _this: JObject,
    pixels: JObject,
    width: JInt,
    height: JInt,
    params: JObject,
    threads: JInt,
    out: JObject,
) {
    let e = Env(env);
    guard(e, (), || -> Result<(), NativeError> {
        let px = read_pixels(e, pixels, width, height, "inferRegion")?;
        let p = read_float_array(e, params, "inferRegion(params)")?;
        if p.len() < nn::TOTAL_PARAMS {
            return Err(NativeError::arg("inferRegion: params must hold TOTAL_PARAMS floats"));
        }
        if out.is_null() || e.array_len(out) != px.len() {
            return Err(NativeError::arg("inferRegion: out must be an int[] of width*height"));
        }
        let n = px.len();
        let mut rgb = vec![0.0f32; n * 3];
        for i in 0..n {
            let c = px[i] as u32;
            rgb[i * 3] = ((c >> 16) & 0xFF) as f32;
            rgb[i * 3 + 1] = ((c >> 8) & 0xFF) as f32;
            rgb[i * 3 + 2] = (c & 0xFF) as f32;
        }
        let weights = nn::weights::PackedWeights::pack(&p, false);
        let mut res = vec![0.0f32; n * 3];
        nn::infer::infer_rgb(&rgb, width as usize, height as usize, &weights, &mut res, resolve_threads(threads));
        let mut ints = vec![0i32; n];
        for i in 0..n {
            let alpha = (px[i] as u32) & 0xFF00_0000;
            let r = to_byte(res[i * 3]) as u32;
            let g = to_byte(res[i * 3 + 1]) as u32;
            let b = to_byte(res[i * 3 + 2]) as u32;
            ints[i] = (alpha | (r << 16) | (g << 8) | b) as i32;
        }
        e.write_ints(out, &ints);
        Ok(())
    })
}

#[no_mangle]
pub unsafe extern "system" fn Java_com_novaenhance_ai_ai_engine_NativeNeuralEngine_nativeReleaseTrainingWorkspace(
    env: RawEnv,
    _this: JObject,
) {
    let e = Env(env);
    guard(e, (), || -> Result<(), NativeError> {
        nn::train::release_workspace();
        Ok(())
    })
}

#[no_mangle]
pub unsafe extern "system" fn Java_com_novaenhance_ai_ai_engine_NativeNeuralEngine_nativeBackendName(
    env: RawEnv,
    _this: JObject,
) -> JObject {
    let e = Env(env);
    guard(e, std::ptr::null_mut(), || -> Result<JObject, NativeError> { Ok(e.new_string(nn::backend_name())) })
}

// ------------------------------------------------------------------------------------------------ NativeEnhancer

/// `nativeOpen(source: Bitmap, options: FloatArray, params: FloatArray?, threads: Int, maxBandPixels: Int): Long`
#[no_mangle]
pub unsafe extern "system" fn Java_com_novaenhance_ai_ai_engine_NativeEnhancer_nativeOpen(
    env: RawEnv,
    _this: JObject,
    source: JObject,
    options: JObject,
    params: JObject,
    threads: JInt,
    max_band_pixels: JInt,
) -> JLong {
    let e = Env(env);
    guard(e, 0i64, || -> Result<JLong, NativeError> {
        install_panic_hook();
        let opts = read_float_array(e, options, "open(options)")?;
        let weights: Option<Vec<f32>> = if params.is_null() { None } else { Some(e.read_floats(params)) };
        let lock = LockedBitmap::lock(e.as_void(), source).map_err(NativeError::state)?;
        let cap = if max_band_pixels > 0 { max_band_pixels as usize } else { crate::enhance::session::DEFAULT_MAX_BAND_PIXELS };
        let session = Session::open(&lock, &opts, weights.as_deref(), cap, resolve_threads(threads));
        drop(lock);
        Ok(register_session(session))
    })
}

/// `nativeProcessBand(handle: Long, src: Bitmap, dst: Bitmap, y0: Int, y1: Int, threads: Int)`.
/// `dst` may be the same bitmap as `src` (in-place mode: bands strictly top to bottom).
#[no_mangle]
pub unsafe extern "system" fn Java_com_novaenhance_ai_ai_engine_NativeEnhancer_nativeProcessBand(
    env: RawEnv,
    _this: JObject,
    handle: JLong,
    src: JObject,
    dst: JObject,
    y0: JInt,
    y1: JInt,
    threads: JInt,
) {
    let e = Env(env);
    guard(e, (), || -> Result<(), NativeError> {
        let session = lookup_session(handle).ok_or_else(|| NativeError::state("the enhancement session is already closed"))?;
        if y0 < 0 || y1 < y0 {
            return Err(NativeError::arg("processBand: invalid row range"));
        }
        let t = resolve_threads(threads);
        let same = e.is_same_object(src, dst);
        let src_lock = LockedBitmap::lock(e.as_void(), src).map_err(NativeError::state)?;
        if same {
            session
                .process_rows(&src_lock, &src_lock, y0 as usize, y1 as usize, true, t)
                .map_err(NativeError::arg)?;
        } else {
            let dst_lock = LockedBitmap::lock(e.as_void(), dst).map_err(NativeError::state)?;
            session
                .process_rows(&src_lock, &dst_lock, y0 as usize, y1 as usize, false, t)
                .map_err(NativeError::arg)?;
        }
        Ok(())
    })
}

#[no_mangle]
pub unsafe extern "system" fn Java_com_novaenhance_ai_ai_engine_NativeEnhancer_nativeContextRows(
    env: RawEnv,
    _this: JObject,
    handle: JLong,
) -> JInt {
    let e = Env(env);
    guard(e, 0i32, || -> Result<JInt, NativeError> {
        let session = lookup_session(handle).ok_or_else(|| NativeError::state("the enhancement session is already closed"))?;
        Ok(session.context_rows() as JInt)
    })
}

#[no_mangle]
pub unsafe extern "system" fn Java_com_novaenhance_ai_ai_engine_NativeEnhancer_nativeSummary(
    env: RawEnv,
    _this: JObject,
    handle: JLong,
) -> JObject {
    let e = Env(env);
    guard(e, std::ptr::null_mut(), || -> Result<JObject, NativeError> {
        let session = lookup_session(handle).ok_or_else(|| NativeError::state("the enhancement session is already closed"))?;
        Ok(e.new_string(session.summary()))
    })
}

#[no_mangle]
pub unsafe extern "system" fn Java_com_novaenhance_ai_ai_engine_NativeEnhancer_nativeClose(
    env: RawEnv,
    _this: JObject,
    handle: JLong,
) {
    let e = Env(env);
    guard(e, (), || -> Result<(), NativeError> {
        unregister_session(handle);
        Ok(())
    })
}
