"""Cross-checks every Kotlin `private external fun nativeX(...)` against the Rust JNI export
`Java_com_novaenhance_ai_ai_engine_<Class>_nativeX(env, this, ...)` in rust/src/bridge.rs:
same name, same parameter count, same primitive parameter types, same return type.
(Rust spells every reference type - arrays, Bitmap, String - as JObject, so those are checked by position only.)
Run from the repo root:  python3 tools/jni_crosscheck.py"""
import re, sys, glob

KT_TO_RUST = {'Int': 'JInt', 'Float': 'JFloat', 'Boolean': 'JBoolean', 'Long': 'JLong',
              'IntArray': 'JObject', 'FloatArray': 'JObject', 'ByteArray': 'JObject',
              'Bitmap': 'JObject', 'String': 'JObject', 'Unit': None}

rust = open('rust/src/bridge.rs').read()
rust_funcs = {}
for m in re.finditer(r'pub\s+unsafe\s+extern\s+"system"\s+fn\s+Java_com_novaenhance_ai_ai_engine_(\w+?)_(native\w+)\s*\((.*?)\)\s*(?:->\s*(\w+))?\s*\{', rust, re.S):
    cls, name, params, ret = m.groups()
    plist = [p.strip() for p in params.split(',') if p.strip()]
    assert plist[0].startswith('env') and plist[1].startswith('_this'), (name, plist)
    types = [p.split(':')[1].strip() for p in plist[2:]]
    rust_funcs[(cls, name)] = (types, ret)

bad = 0
checked = 0
seen = set()
for kt in glob.glob('app/src/main/java/com/novaenhance/ai/ai/engine/*.kt'):
    src = open(kt).read()
    cls_m = re.search(r'\bobject\s+(\w+)', src) or re.search(r'\bclass\s+(\w+)', src)
    for m in re.finditer(r'private\s+external\s+fun\s+(native\w+)\s*\(([^)]*)\)\s*(?::\s*(\w+)\??)?', src):
        name, params, ret = m.groups()
        ret = ret or 'Unit'
        cls = cls_m.group(1)
        plist = [p.strip() for p in params.replace('\n', ' ').split(',') if p.strip()]
        types = [KT_TO_RUST[p.split(':')[1].strip().rstrip('?')] for p in plist]
        kret = KT_TO_RUST[ret]
        key = (cls, name)
        seen.add(key)
        checked += 1
        if key not in rust_funcs:
            print('MISSING in Rust:', key)
            bad += 1
            continue
        rtypes, rret = rust_funcs[key]
        if rtypes != types or rret != kret:
            print('MISMATCH', key, '\n  kotlin:', types, '->', kret, '\n  rust  :', rtypes, '->', rret)
            bad += 1

unused = sorted(set(rust_funcs) - seen)
for key in unused:
    print('NOTE: Rust export without a Kotlin declaration:', key)
print(f'{checked} Kotlin external functions checked against {len(rust_funcs)} Rust JNI exports: '
      f'{"ALL MATCH" if bad == 0 else str(bad) + " PROBLEMS"}')
sys.exit(1 if bad else 0)
