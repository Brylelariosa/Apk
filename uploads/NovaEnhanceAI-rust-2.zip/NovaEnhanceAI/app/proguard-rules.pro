# NovaEnhance AI - release shrinking rules.
# Goal: keep the release APK small (minifyEnabled + shrinkResources are on)
# while protecting the handful of classes that are accessed reflectively,
# via JNI, or via Room's generated code.

# --- Room ---
# Entities/DAOs are referenced by generated code (*_Impl classes); keep
# field/annotation info so the generated implementations resolve correctly.
-keep class com.novaenhance.ai.database.entities.** { *; }
-keepclassmembers class com.novaenhance.ai.database.entities.** { *; }
-dontwarn androidx.room.**

# --- JNI (the Rust core: image filters, neural network, enhancement session) ---
# The Rust library exports these methods by exact name (Java_<package>_<Class>_<method>); R8 must not
# rename, inline, or remove them.
-keep class com.novaenhance.ai.ai.engine.NativeImageProcessor {
    native <methods>;
}
-keep class com.novaenhance.ai.ai.engine.NativeNeuralEngine {
    native <methods>;
}
-keep class com.novaenhance.ai.ai.engine.NativeEnhancer {
    native <methods>;
}

# --- Kotlin coroutines / metadata ---
-keepattributes Signature, InnerClasses, EnclosingMethod
-keepattributes *Annotation*
-dontwarn kotlinx.coroutines.**

# --- Compose (defensive; AGP's default compose rules already cover most of this) ---
-dontwarn androidx.compose.**

# --- Readable crash log ---
# The in-app Crash Log (Settings -> View Crash Log) shows Java stack traces on the phone itself, where there
# is no mapping file to de-obfuscate them with. Keeping class/method names and line numbers makes them
# readable; shrinking and optimization (the part that keeps the APK small) are unaffected.
-keepattributes SourceFile,LineNumberTable
-dontobfuscate
