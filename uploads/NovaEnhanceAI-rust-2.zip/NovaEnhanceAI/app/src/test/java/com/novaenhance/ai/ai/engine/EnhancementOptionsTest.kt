package com.novaenhance.ai.ai.engine

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class EnhancementOptionsTest {

    @Test
    fun `defaults keep every advanced technique off`() {
        assertFalse(EnhancementOptions().usesAdvancedTechniques)
    }

    @Test
    fun `switching any technique on is reported`() {
        assertTrue(EnhancementOptions(autoEnhance = true).usesAdvancedTechniques)
        assertTrue(EnhancementOptions(dehaze = 0.5f).usesAdvancedTechniques)
        assertTrue(EnhancementOptions(exposure = -0.2f).usesAdvancedTechniques)
        assertTrue(EnhancementOptions(vignette = 0.3f).usesAdvancedTechniques)
        assertTrue(EnhancementOptions(deblur = 0.1f).usesAdvancedTechniques)
    }

    @Test
    fun `signed controls accept negative values and unsigned ones reject them`() {
        EnhancementOptions(exposure = -1f, contrast = -1f, vignette = -1f)
        try {
            EnhancementOptions(clahe = -0.1f)
            fail("an unsigned technique must reject negative values")
        } catch (expected: IllegalArgumentException) {
            // ok
        }
    }

    @Test
    fun `out of range values are rejected`() {
        try {
            EnhancementOptions(exposure = 1.5f)
            fail("exposure above 1 must be rejected")
        } catch (expected: IllegalArgumentException) {
            // ok
        }
    }
}
