package com.novaenhance.ai.ai.engine

import android.graphics.Bitmap
import com.novaenhance.ai.utils.ComputeBudget
import com.novaenhance.ai.utils.NovaLog
import com.novaenhance.ai.utils.ThermalGovernor
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.math.max

/**
 * The single entry point the UI and validator both call to actually enhance an image. Design split, spelled out
 * because it's easy to lose track of which layer does what:
 *
 *  - The Rust enhancement SESSION ([NativeEnhancer]) does all per-pixel work in one pipeline, band by band, directly
 *    on bitmap memory: the *learned* CNN pass (denoise + sharpen + detail-restore + artifact-removal in one shot,
 *    the part that gets better as the user trains it), then the classical techniques - hot-pixel removal,
 *    compression-artifact removal, non-local-means denoise, deband, deblur, white balance, dehaze, low-light,
 *    shadows/highlights, CLAHE, levels/exposure/contrast, clarity, detail, vibrance/saturation, sharpen. A scene
 *    analysis ("Auto enhance") can decide which of them a photo needs.
 *  - [UpscaleStage]: Lanczos-3 resampling + edge-aware sharpening for the 2x/4x options (the learned model does not
 *    upscale - it is a fixed-size restoration model, not a super-resolution one). The sharpening happens ONCE, at
 *    the final resolution, on the resampled pixels.
 *  - [BandProcessor]: the band loop - keeps peak memory bounded regardless of source resolution, and (given
 *    [thermalGovernor]) paces itself under thermal pressure, so a manual "Enhance" tap on a large photo backs off the
 *    same way training's validation passes do.
 *
 * Memory: the source bitmap, the output bitmap and a native working set capped at a few MB per band. Nothing is
 * allocated on the Java heap per band. With `inPlace = true` even the second full-size bitmap is saved.
 */
class EnhancementEngine(
    private val modelEngine: NovaModelEngine,
    private val thermalGovernor: ThermalGovernor? = null
) {
    companion object {
        // Shared across every EnhancementEngine instance (a new one is created per enhancement request - see
        // EnhanceViewModel.runEnhancement), so it actually bounds concurrent expensive processing globally instead
        // of per-request. Without this, two overlapping requests (an old one not yet stopped, plus a new one) would
        // each get their own independent thread budget, so native work could run for both at once even with the
        // generation/isStale checks in place (those stop a stale request from *publishing*, and bound how long it
        // keeps working before noticing it's stale, but never stopped it from running *concurrently* with a newer
        // one in the meantime).
        //
        // A coroutine Mutex (not a thread lock) so acquiring it suspends the calling coroutine without blocking a
        // thread - enhance() only ever runs on Dispatchers.Default, never the main thread.
        private val nativeProcessingGate = Mutex()

        // How the 0..1 Sharpness slider maps to the two sharpening stages (see SharpenSpec). Tuned with
        // tools/quality_eval (numbers in README -> "Cleaner results (build 11)"):
        //  - EDGE PUSH, the halo-free stage that makes soft line art crisp. It fades in linearly and is at full
        //    strength from slider ~0.63 up, so the default (0.3) is a moderate push: clearly crisper line art while
        //    photos stay about where they were.
        private const val PUSH_GAIN = 1.6f
        //  - UNSHARP stage at 1x: quadratic, so it is a hint at the default and only gets strong when asked for.
        private const val UNSHARP_GAIN_1X = 1.5f
        //  - UNSHARP stage once upscaled: linear, because edges are spread over several pixels and need more help.
        private const val UNSHARP_GAIN_UPSCALED = 1.5f

        /** Edge-push strength for a Sharpness slider position: 0 = off, [PUSH_GAIN] x slider up to 1 = full. */
        internal fun pushStrengthFor(sharpness: Float): Float = (sharpness * PUSH_GAIN).coerceIn(0f, 1f)

        /** Sharpening for the 1x path, applied band-wise at the end of the native pipeline. */
        internal fun sharpenSpecFor1x(sharpness: Float): SharpenSpec =
            if (sharpness <= 0f) SharpenSpec.NONE
            else SharpenSpec(
                amount = UNSHARP_GAIN_1X * sharpness * sharpness,
                sigma = 1.0f,
                overshoot = 0f, // no halos at all: the push does the crisping, the unsharp stage only adds micro-contrast
                clampRadius = 1,
                push = pushStrengthFor(sharpness),
                pushRadius = 1
            )

        /** Sharpening for the upscaled path, applied at the OUTPUT resolution (so sigma and radius scale with it). */
        internal fun sharpenSpecForUpscale(sharpness: Float, factor: Int): SharpenSpec =
            if (sharpness <= 0f) SharpenSpec.NONE
            else SharpenSpec(
                amount = sharpness * UNSHARP_GAIN_UPSCALED,
                sigma = 0.5f * factor,
                overshoot = 0f,
                clampRadius = max(1, factor / 2),
                push = pushStrengthFor(sharpness),
                pushRadius = max(1, factor / 2) // ~half the upscale factor: measured best at 2x (1) and 4x (2)
            )
    }

    private val bandProcessor = BandProcessor(thermalGovernor = thermalGovernor)
    private val upscaleStage = UpscaleStage(thermalGovernor)

    data class EnhanceProgress(val fraction: Float, val stage: Stage) {
        enum class Stage { AI_TILES, UPSCALING, FINISHING }
    }

    /**
     * Enhances [source] and returns the result.
     *
     * @param isStale checked before starting, between bands, and between the enhancement pass and the upscale pass,
     *   so a request superseded by a newer slider change stops within at most one band's worth of native work
     *   instead of running the full image to completion. This exists BECAUSE coroutine cancellation alone can't do
     *   it: a native JNI call already in flight keeps running to completion regardless of job.cancel(). Default
     *   `{ false }` keeps the unconditional-completion behaviour for other callers (e.g. ModelValidator's
     *   before/after comparison passes, which have their own TrainingControlFlow-based cancellation).
     * @param inPlace enhance [source] itself instead of allocating a second full-size bitmap (saves one photo-sized
     *   bitmap in batch jobs). Only honoured when [source] is mutable. When the 1x result is returned it IS
     *   [source] - the caller must not recycle it twice. With an upscale the in-place 1x result is only an
     *   intermediate and the returned bitmap is the new, larger one; either way [source]'s original pixels are gone
     *   afterwards, so never pass a bitmap that is still needed (e.g. the before/after viewer's original).
     */
    suspend fun enhance(
        source: Bitmap,
        options: EnhancementOptions,
        onProgress: ((EnhanceProgress) -> Unit)? = null,
        isStale: () -> Boolean = { false },
        inPlace: Boolean = false
    ): Bitmap {
        if (isStale()) throw CancellationException("Enhancement superseded before starting")

        // Everything below is exactly the "expensive processing" that must not overlap with another request's.
        // Held for the whole call, not re-acquired per stage. withLock (rather than manual lock()/unlock())
        // guarantees the gate is released on every exit path.
        return nativeProcessingGate.withLock {
            // Re-checked now that this request actually holds the gate: it may have been superseded by a newer one
            // while waiting its turn.
            if (isStale()) throw CancellationException("Enhancement superseded while waiting for the native-processing gate")

            val threadCeiling = ComputeBudget.enhancementThreads(Runtime.getRuntime().availableProcessors())
            val startMs = System.currentTimeMillis()

            // What the photo can actually afford (see UpscalePlan) - decided BEFORE the pass because it also decides
            // where the sharpening happens: at 1x inside the session, or after the upscale.
            val factor = UpscalePlan.effectiveFactor(source.width, source.height, options.upscaleFactor)
            if (factor != options.upscaleFactor) {
                NovaLog.i(
                    "EnhancementEngine",
                    "upscale x${options.upscaleFactor} limited to x$factor for a ${source.width}x${source.height} source " +
                        "(output cap ${UpscalePlan.MAX_OUTPUT_PIXELS / 1_000_000} MP)"
                )
            }
            val sharpenAt1x = if (factor == 1) sharpenSpecFor1x(options.sharpness) else SharpenSpec.NONE

            // The weights are snapshotted ONCE per photo (~173 KB) instead of holding the engine lock for every band.
            val modelParams: FloatArray? = if (options.strength > 0f) modelEngine.snapshotParams() else null
            val inPlaceNow = inPlace && source.isMutable
            if (inPlace && !inPlaceNow) {
                NovaLog.i("EnhancementEngine", "in-place enhancement requested but the bitmap is immutable - using a second bitmap")
            }

            NovaLog.breadcrumb(
                "EnhancementEngine",
                "enhance ${source.width}x${source.height} factor=$factor inPlace=$inPlaceNow threads<=$threadCeiling " +
                    "auto=${options.autoEnhance} cnn=${modelParams != null}"
            )
            val session = NativeEnhancer.open(
                source,
                NativeEnhancer.encodeOptions(options, sharpenAt1x, factor),
                modelParams,
                threadCeiling,
                NativeEnhancer.DEFAULT_MAX_BAND_PIXELS
            )
            val aiEnhanced: Bitmap = try {
                NovaLog.i(
                    "EnhancementEngine",
                    "analysis: ${NativeEnhancer.summary(session)} | context rows ${NativeEnhancer.contextRows(session)}"
                )
                val destination = if (inPlaceNow) source else Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
                try {
                    bandProcessor.process(
                        session,
                        source,
                        destination,
                        threadCeiling,
                        onProgress = { p ->
                            onProgress?.invoke(EnhanceProgress(p.rowsDone.toFloat() / p.rowsTotal, EnhanceProgress.Stage.AI_TILES))
                        },
                        isStale = isStale
                    )
                } catch (t: Throwable) {
                    // Covers the isStale() abort as much as any other failure: a separate output is a full-resolution
                    // bitmap nothing else references yet - free its native memory now instead of waiting for GC.
                    if (destination !== source) destination.recycle()
                    throw t
                }
                destination
            } finally {
                NativeEnhancer.close(session)
            }
            NovaLog.i(
                "EnhancementEngine",
                "enhance pass ${source.width}x${source.height} done in ${System.currentTimeMillis() - startMs}ms " +
                    "(kernels=${NativeNeuralEngine.backendName}, up to $threadCeiling threads)"
            )

            if (factor == 1) {
                onProgress?.invoke(EnhanceProgress(1f, EnhanceProgress.Stage.FINISHING))
                return@withLock aiEnhanced
            }
            if (isStale()) {
                if (aiEnhanced !== source) aiEnhanced.recycle() // not returning it, and nothing else references it yet
                throw CancellationException("Enhancement superseded before upscaling")
            }

            onProgress?.invoke(EnhanceProgress(0f, EnhanceProgress.Stage.UPSCALING))
            val upscaled = try {
                upscaleStage.upscale(
                    aiEnhanced,
                    factor = factor,
                    sharpen = sharpenSpecForUpscale(options.sharpness, factor),
                    threadCeiling = threadCeiling,
                    onProgress = { fraction -> onProgress?.invoke(EnhanceProgress(fraction, EnhanceProgress.Stage.UPSCALING)) },
                    isStale = isStale
                )
            } finally {
                // The 1x result is only an input to the upscale: free it whether that succeeded, was superseded or
                // failed - unless it IS the caller's source bitmap (in-place mode), which the caller owns.
                if (aiEnhanced !== source) aiEnhanced.recycle()
            }

            onProgress?.invoke(EnhanceProgress(1f, EnhanceProgress.Stage.FINISHING))
            upscaled
        }
    }
}
