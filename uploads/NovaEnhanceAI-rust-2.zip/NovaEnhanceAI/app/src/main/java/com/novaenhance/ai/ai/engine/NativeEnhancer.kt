package com.novaenhance.ai.ai.engine

import android.graphics.Bitmap

/**
 * JNI bridge to the Rust enhancement SESSION (`/rust/src/enhance`).
 *
 * A session is the analysed, planned state of ONE photo. [open] reads the source bitmap once (a streaming,
 * read-only pass that builds a thumbnail, histograms and noise/blur estimates - a few MB at most) and returns a
 * handle; [processBand] then turns source rows into enhanced rows, reading the bitmap's pixel memory directly and
 * writing the result straight into the destination bitmap. No pixel ever crosses into the Java heap, and native
 * working memory is capped by a band budget instead of growing with the photo - which is what makes the pipeline
 * RAM-friendly on a 4 GB phone. [close] frees the session; always call it (use try/finally).
 *
 * In-place mode: pass the SAME bitmap as [src] and [dst] (it must be a mutable ARGB_8888 bitmap) and the photo is
 * enhanced without allocating a second full-size bitmap. Bands must then be processed strictly top to bottom
 * without gaps (the native side keeps a few rows of the originals as context for the rows it is about to overwrite).
 */
object NativeEnhancer {

    init {
        System.loadLibrary("novaenhance_native")
    }

    /** Default cap on pixels (band + context rows) the native pipeline processes at once: ~10 MB per float buffer. */
    const val DEFAULT_MAX_BAND_PIXELS = 800_000

    // --- Layout of the options array; mirrors rust/src/enhance/options.rs index for index. ---
    private const val OPTIONS_LEN = 32
    private const val I_STRENGTH = 0
    private const val I_SHARPNESS = 1
    private const val I_NOISE_REDUCTION = 2
    private const val I_COLOR_RESTORATION = 3
    private const val I_AUTO = 4
    private const val I_WHITE_BALANCE = 5
    private const val I_AUTO_LEVELS = 6
    private const val I_EXPOSURE = 7
    private const val I_CONTRAST = 8
    private const val I_SHADOWS = 9
    private const val I_HIGHLIGHTS = 10
    private const val I_CLAHE = 11
    private const val I_LOW_LIGHT = 12
    private const val I_DEHAZE = 13
    private const val I_VIBRANCE = 14
    private const val I_CLARITY = 15
    private const val I_DETAIL = 16
    private const val I_DENOISE = 17
    private const val I_DESPIKE = 18
    private const val I_DEBAND = 19
    private const val I_DEBLUR = 20
    private const val I_VIGNETTE = 21
    private const val I_UPSCALE_FACTOR = 22
    private const val I_SHARP_AMOUNT = 24
    private const val I_SHARP_SIGMA = 25
    private const val I_SHARP_OVERSHOOT = 26
    private const val I_SHARP_CLAMP_RADIUS = 27
    private const val I_SHARP_GATE_LOW = 28
    private const val I_SHARP_GATE_HIGH = 29
    private const val I_SHARP_PUSH = 30
    private const val I_SHARP_PUSH_RADIUS = 31

    /**
     * Packs [options] into the native options array. [sharpen] is the sharpening to apply at 1x inside the session
     * ([SharpenSpec.NONE] when the photo is about to be upscaled, which sharpens at the final resolution itself);
     * [upscaleFactor] is the factor that will actually be applied afterwards.
     */
    fun encodeOptions(options: EnhancementOptions, sharpen: SharpenSpec, upscaleFactor: Int): FloatArray {
        val a = FloatArray(OPTIONS_LEN)
        a[I_STRENGTH] = options.strength
        a[I_SHARPNESS] = options.sharpness
        a[I_NOISE_REDUCTION] = options.noiseReduction
        a[I_COLOR_RESTORATION] = options.colorRestoration
        a[I_AUTO] = if (options.autoEnhance) 1f else 0f
        a[I_WHITE_BALANCE] = options.whiteBalance
        a[I_AUTO_LEVELS] = options.autoLevels
        a[I_EXPOSURE] = options.exposure
        a[I_CONTRAST] = options.contrast
        a[I_SHADOWS] = options.shadows
        a[I_HIGHLIGHTS] = options.highlights
        a[I_CLAHE] = options.clahe
        a[I_LOW_LIGHT] = options.lowLight
        a[I_DEHAZE] = options.dehaze
        a[I_VIBRANCE] = options.vibrance
        a[I_CLARITY] = options.clarity
        a[I_DETAIL] = options.detail
        a[I_DENOISE] = options.denoise
        a[I_DESPIKE] = options.despike
        a[I_DEBAND] = options.deband
        a[I_DEBLUR] = options.deblur
        a[I_VIGNETTE] = options.vignette
        a[I_UPSCALE_FACTOR] = upscaleFactor.toFloat()
        a[I_SHARP_AMOUNT] = sharpen.amount
        a[I_SHARP_SIGMA] = sharpen.sigma
        a[I_SHARP_OVERSHOOT] = sharpen.overshoot
        a[I_SHARP_CLAMP_RADIUS] = sharpen.clampRadius.toFloat()
        a[I_SHARP_GATE_LOW] = sharpen.gateLow
        a[I_SHARP_GATE_HIGH] = sharpen.gateHigh
        a[I_SHARP_PUSH] = sharpen.push
        a[I_SHARP_PUSH_RADIUS] = sharpen.pushRadius.toFloat()
        return a
    }

    /**
     * Analyses [source] and builds the enhancement plan. [params] are the CNN weights
     * ([NativeNeuralEngine.TOTAL_PARAMS] floats, copied natively) or null to skip the CNN stage. [threads] <= 0
     * means "all"; [maxBandPixels] caps the native working set (see [DEFAULT_MAX_BAND_PIXELS]). Returns a handle
     * that MUST be passed to [close].
     */
    fun open(
        source: Bitmap,
        options: FloatArray,
        params: FloatArray?,
        threads: Int = 0,
        maxBandPixels: Int = DEFAULT_MAX_BAND_PIXELS
    ): Long {
        require(options.size >= OPTIONS_LEN) { "options array must hold $OPTIONS_LEN floats" }
        require(params == null || params.size >= NativeNeuralEngine.TOTAL_PARAMS) { "params must hold TOTAL_PARAMS floats" }
        return nativeOpen(source, options, params, threads, maxBandPixels)
    }

    /**
     * Enhances source rows [y0] until [y1] into [dst]. [dst] may be [src] itself (in place; bands then strictly
     * top to bottom). Both must be ARGB_8888, same size, neither recycled nor a hardware bitmap.
     */
    fun processBand(handle: Long, src: Bitmap, dst: Bitmap, y0: Int, y1: Int, threads: Int = 0) {
        require(src.width == dst.width && src.height == dst.height) { "processBand: bitmaps differ in size" }
        require(y0 in 0..y1 && y1 <= src.height) { "processBand: rows $y0..$y1 are outside 0..${src.height}" }
        nativeProcessBand(handle, src, dst, y0, y1, threads)
    }

    /** Real context rows the session reads above and below each band (for logs). */
    fun contextRows(handle: Long): Int = nativeContextRows(handle)

    /** One line describing what the analysis found and which techniques are active. */
    fun summary(handle: Long): String = nativeSummary(handle)

    /** Frees the session. Safe to call more than once. */
    fun close(handle: Long) {
        if (handle != 0L) nativeClose(handle)
    }

    // --- JNI declarations, implemented in rust/src/bridge.rs ---
    private external fun nativeOpen(
        source: Bitmap, options: FloatArray, params: FloatArray?, threads: Int, maxBandPixels: Int
    ): Long
    private external fun nativeProcessBand(handle: Long, src: Bitmap, dst: Bitmap, y0: Int, y1: Int, threads: Int)
    private external fun nativeContextRows(handle: Long): Int
    private external fun nativeSummary(handle: Long): String
    private external fun nativeClose(handle: Long)
}
