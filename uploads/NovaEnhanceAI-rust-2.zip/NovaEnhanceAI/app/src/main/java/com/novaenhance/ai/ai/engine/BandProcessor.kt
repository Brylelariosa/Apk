package com.novaenhance.ai.ai.engine

import android.graphics.Bitmap
import com.novaenhance.ai.utils.Constants
import com.novaenhance.ai.utils.MemoryStats
import com.novaenhance.ai.utils.NovaLog
import com.novaenhance.ai.utils.ThermalGovernor
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.min

private const val TAG = "BandProcessor"

/**
 * Drives a native enhancement session ([NativeEnhancer]) over a whole photo in full-width horizontal BANDS, so
 * peak memory stays bounded whatever the photo's resolution - while leaving no seams: the native side reads every
 * band's true neighbouring rows as context (wherever the image has them) and writes only the band's own rows.
 *
 * Unlike the Java-array pipeline this replaced, no pixel passes through the Java heap: the native code reads the
 * source bitmap's memory and writes the destination bitmap's memory directly, so a band costs no allocation here
 * at all and the garbage collector has nothing to do.
 *
 * The native session does its own parallelism (a band fans out over worker threads), so bands run strictly one
 * after another. Between bands this class consults [thermalGovernor] - so a manual "Enhance" on a hot phone backs
 * off exactly like training's own validation passes do - and checks `isStale`, so a request superseded by a newer
 * slider change stops within one band's work instead of finishing the whole image.
 */
class BandProcessor(
    private val thermalGovernor: ThermalGovernor? = null,
    private val bandRows: Int = Constants.BAND_ROWS_PX
) {

    init {
        require(bandRows > 0) { "bandRows must be positive, got $bandRows" }
    }

    data class BandProgress(val rowsDone: Int, val rowsTotal: Int)

    /**
     * Enhances every row of [source] into [destination] using the open session [session].
     *
     * [destination] may be [source] itself (in-place enhancement: it must be mutable, and no second full-size
     * bitmap is needed). Otherwise it must be an ARGB_8888 bitmap of the same size. On any failure the caller
     * owns cleaning up [destination].
     *
     * @param threadCeiling most native worker threads a band may use; [thermalGovernor] can only narrow this.
     */
    suspend fun process(
        session: Long,
        source: Bitmap,
        destination: Bitmap,
        threadCeiling: Int,
        onProgress: ((BandProgress) -> Unit)? = null,
        isStale: () -> Boolean = { false }
    ) {
        val startMs = System.currentTimeMillis()
        val width = source.width
        val height = source.height
        require(destination.width == width && destination.height == height) {
            "destination ${destination.width}x${destination.height} does not match the ${width}x$height source"
        }
        val inPlace = destination === source
        NovaLog.breadcrumb(
            TAG,
            "process ${width}x$height ${if (inPlace) "in place" else "into a separate bitmap"}, " +
                "bands of $bandRows rows | ${MemoryStats.summary()}"
        )

        val pacer = BandPacer(thermalGovernor)
        var bands = 0
        var y0 = 0
        while (y0 < height) {
            if (isStale()) throw CancellationException("Enhancement superseded - aborting before the next band")

            val threads = pacer.threadsForNextBand(threadCeiling)
            val y1 = min(height, y0 + bandRows)
            NovaLog.breadcrumb(TAG, "band ${bands + 1} rows $y0-$y1 threads=$threads | ${MemoryStats.summary()}")

            val from = y0
            withContext(Dispatchers.Default) {
                NativeEnhancer.processBand(session, source, destination, from, y1, threads)
            }

            bands++
            y0 = y1
            onProgress?.invoke(BandProgress(y0, height))
        }

        val pacingNote = if (pacer.pacedBands > 0) ", eased off for ${pacer.pacedBands} band(s) on thermal state" else ""
        NovaLog.i(
            TAG,
            "Processed ${width}x$height in $bands band(s) of up to $bandRows rows " +
                "(up to $threadCeiling threads$pacingNote) in ${System.currentTimeMillis() - startMs}ms"
        )
    }
}
