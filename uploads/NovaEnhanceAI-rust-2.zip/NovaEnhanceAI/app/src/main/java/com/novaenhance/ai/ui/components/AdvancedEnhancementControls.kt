package com.novaenhance.ai.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.novaenhance.ai.ai.engine.EnhancementOptions

/**
 * The photo-enhancement techniques of the Rust pipeline: an "Auto enhance" switch (the scene analysis decides what a
 * photo needs) and a collapsible list of sliders, one per technique. Every slider defaults to 0 = off; a slider the
 * user moves always wins over what Auto would have chosen.
 */
@Composable
fun AdvancedEnhancementControls(
    options: EnhancementOptions,
    enabled: Boolean,
    onOptionsChange: (EnhancementOptions) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Auto enhance", style = MaterialTheme.typography.bodyMedium)
                Text(
                    "Analyses each photo (colour cast, exposure, haze, noise, blur ...) and applies only what it needs. " +
                        "Sliders you move yourself always win.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Switch(
                checked = options.autoEnhance,
                onCheckedChange = { onOptionsChange(options.copy(autoEnhance = it)) },
                enabled = enabled
            )
        }

        val suffix = if (options.usesAdvancedTechniques) " (on)" else ""
        OutlinedButton(onClick = { expanded = !expanded }, modifier = Modifier.fillMaxWidth()) {
            Text(if (expanded) "Hide advanced techniques" else "Advanced techniques$suffix")
        }

        if (expanded) {
            SectionLabel("Tone and colour")
            TechniqueSlider("White balance", options.whiteBalance, enabled = enabled) { onOptionsChange(options.copy(whiteBalance = it)) }
            TechniqueSlider("Auto levels", options.autoLevels, enabled = enabled) { onOptionsChange(options.copy(autoLevels = it)) }
            TechniqueSlider("Exposure", options.exposure, signed = true, enabled = enabled) { onOptionsChange(options.copy(exposure = it)) }
            TechniqueSlider("Contrast", options.contrast, signed = true, enabled = enabled) { onOptionsChange(options.copy(contrast = it)) }
            TechniqueSlider("Shadows (lift)", options.shadows, enabled = enabled) { onOptionsChange(options.copy(shadows = it)) }
            TechniqueSlider("Highlights (recover)", options.highlights, enabled = enabled) { onOptionsChange(options.copy(highlights = it)) }
            TechniqueSlider("Local contrast (CLAHE)", options.clahe, enabled = enabled) { onOptionsChange(options.copy(clahe = it)) }
            TechniqueSlider("Low-light boost", options.lowLight, enabled = enabled) { onOptionsChange(options.copy(lowLight = it)) }
            TechniqueSlider("Dehaze", options.dehaze, enabled = enabled) { onOptionsChange(options.copy(dehaze = it)) }
            TechniqueSlider("Vibrance", options.vibrance, enabled = enabled) { onOptionsChange(options.copy(vibrance = it)) }
            TechniqueSlider("Vignette fix", options.vignette, signed = true, enabled = enabled) { onOptionsChange(options.copy(vignette = it)) }

            SectionLabel("Detail and sharpness")
            TechniqueSlider("Clarity", options.clarity, enabled = enabled) { onOptionsChange(options.copy(clarity = it)) }
            TechniqueSlider("Fine detail", options.detail, enabled = enabled) { onOptionsChange(options.copy(detail = it)) }
            TechniqueSlider("Deblur (deconvolution)", options.deblur, enabled = enabled) { onOptionsChange(options.copy(deblur = it)) }

            SectionLabel("Cleaning")
            TechniqueSlider("Denoise (non-local means)", options.denoise, enabled = enabled) { onOptionsChange(options.copy(denoise = it)) }
            TechniqueSlider("Hot pixels / speckle", options.despike, enabled = enabled) { onOptionsChange(options.copy(despike = it)) }
            TechniqueSlider("Remove banding", options.deband, enabled = enabled) { onOptionsChange(options.copy(deband = it)) }

            OutlinedButton(
                onClick = {
                    onOptionsChange(
                        options.copy(
                            autoEnhance = false,
                            whiteBalance = 0f,
                            autoLevels = 0f,
                            exposure = 0f,
                            contrast = 0f,
                            shadows = 0f,
                            highlights = 0f,
                            clahe = 0f,
                            lowLight = 0f,
                            dehaze = 0f,
                            vibrance = 0f,
                            clarity = 0f,
                            detail = 0f,
                            vignette = 0f,
                            denoise = 0f,
                            despike = 0f,
                            deband = 0f,
                            deblur = 0f
                        )
                    )
                },
                enabled = enabled && options.usesAdvancedTechniques,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Reset advanced techniques")
            }
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.primary
    )
}

@Composable
private fun TechniqueSlider(
    label: String,
    value: Float,
    enabled: Boolean,
    signed: Boolean = false,
    onValueChange: (Float) -> Unit
) {
    LabeledSlider(
        label = label,
        value = value,
        valueRange = if (signed) -1f..1f else 0f..1f,
        enabled = enabled,
        onValueChange = onValueChange
    )
}
