package com.novaenhance.ai.ai.engine

import android.graphics.Bitmap

/**
 * Thin JNI bridge over the Rust image-filter code (`/rust/src/filters`).
 *
 * Two groups of calls live here:
 *
 *  - ARGB `IntArray` filters ([gaussianBlur], [resizeBilinear], [quickSimilarityScore] and the synthetic
 *    degradations used to build training pairs). They work on plain pixel arrays in Android's ARGB_8888 int layout
 *    (as produced by [Bitmap.getPixels]) and are meant for small images - tiles, validation crops.
 *  - [upscaleBand], which works on the raw memory of two bitmaps (no array copy at all).
 *
 * The photo-enhancement hot path (CNN, artifact removal, denoise, tone, sharpen ...) does NOT go through here any
 * more: it is a single native session that reads and writes bitmap memory directly, see [NativeEnhancer].
 */
object NativeImageProcessor {

    init {
        System.loadLibrary("novaenhance_native")
    }

    fun gaussianBlur(pixels: IntArray, width: Int, height: Int, sigma: Float): IntArray {
        validateTileArgs(pixels, width, height, "gaussianBlur")
        return nativeGaussianBlur(pixels, width, height, sigma)
    }

    fun resizeBilinear(
        pixels: IntArray,
        srcWidth: Int,
        srcHeight: Int,
        dstWidth: Int,
        dstHeight: Int
    ): IntArray = nativeResizeBilinear(pixels, srcWidth, srcHeight, dstWidth, dstHeight)

    /**
     * Lanczos-3 upscales [src] by the integer [factor] into [dst] (ringing clamped to the range of the 2x2 source
     * pixels around each sample) - rows [y0] until [y1] only - and applies the [spec] sharpening: the halo-free
     * edge push first, then the edge-aware unsharp stage. [dst] must be an ARGB_8888 bitmap of exactly `factor x` [src]'s size; it is
     * written in place, so a whole image is produced by calling this for consecutive row ranges (see
     * [UpscaleStage]). Every call recomputes the few extra rows the sharpening needs, so the result is identical
     * to one whole-image call whatever the band split - no seams. Neither bitmap may be recycled or a hardware
     * bitmap.
     */
    fun upscaleBand(src: Bitmap, dst: Bitmap, factor: Int, y0: Int, y1: Int, spec: SharpenSpec, threads: Int = 0) {
        require(factor in 1..MAX_UPSCALE_FACTOR) { "upscaleBand: factor must be in 1..$MAX_UPSCALE_FACTOR (got $factor)" }
        require(
            dst.width.toLong() == src.width.toLong() * factor && dst.height.toLong() == src.height.toLong() * factor
        ) { "upscaleBand: ${dst.width}x${dst.height} is not ${factor}x ${src.width}x${src.height}" }
        require(y0 in 0..y1 && y1 <= dst.height) { "upscaleBand: rows $y0..$y1 are outside the ${dst.height}-row destination" }
        check(
            nativeUpscaleBand(
                src, dst, factor, y0, y1, spec.amount, spec.sigma, spec.overshoot, spec.clampRadius,
                spec.gateLow, spec.gateHigh, spec.push, spec.pushRadius, threads
            )
        ) { "native upscaleBand failed (see logcat tag NovaEnhanceNative) - is a bitmap recycled?" }
    }

    /** Fast proxy similarity in [0,1]; used by the validator, not a full SSIM. */
    fun quickSimilarityScore(a: IntArray, b: IntArray, width: Int, height: Int): Float =
        nativeQuickSimilarityScore(a, b, width, height)

    fun addGaussianNoise(pixels: IntArray, width: Int, height: Int, amount: Float, seed: Int): IntArray =
        nativeAddGaussianNoise(pixels, width, height, amount, seed)

    fun simulateJpegArtifacts(pixels: IntArray, width: Int, height: Int, qualityPercent: Int): IntArray =
        nativeSimulateJpegArtifacts(pixels, width, height, qualityPercent)

    fun motionBlur(pixels: IntArray, width: Int, height: Int, angleDegrees: Float, lengthPx: Int): IntArray =
        nativeMotionBlur(pixels, width, height, angleDegrees, lengthPx)

    fun colorFade(pixels: IntArray, width: Int, height: Int, fadeAmount: Float): IntArray =
        nativeColorFade(pixels, width, height, fadeAmount)

    // A reasonable ceiling on any one dimension passed into a native image call. It exists purely to reject an
    // obviously-wrong value before it reaches JNI, rather than let width*height silently overflow or allocate
    // something huge. (The 13 MP main camera of the HOT 11 is 4208 px wide; a 4x upscale of a smaller photo is
    // wider still.)
    private const val MAX_IMAGE_DIMENSION = 16384

    /** Mirrors the Rust bridge's limit. */
    private const val MAX_UPSCALE_FACTOR = 8

    /**
     * Explicit validation before any array-based JNI call: width/height/array-length agreement is a call-site
     * invariant nothing in the type system enforces. The Rust bridge repeats the check at the JNI boundary (and
     * answers a mismatch with an IllegalArgumentException instead of undefined behaviour), but failing fast here
     * with a clear Kotlin stack trace pointing at the actual misuse is more useful.
     */
    private fun validateTileArgs(pixels: IntArray, width: Int, height: Int, fnName: String) {
        require(width > 0 && height > 0) { "$fnName: width and height must be positive (got ${width}x$height)" }
        require(width <= MAX_IMAGE_DIMENSION && height <= MAX_IMAGE_DIMENSION) {
            "$fnName: ${width}x$height exceeds the $MAX_IMAGE_DIMENSION px per-dimension ceiling for a native image call"
        }
        val expected = width.toLong() * height.toLong()
        require(pixels.size.toLong() == expected) {
            "$fnName: pixels.size (${pixels.size}) does not match width*height ($expected for ${width}x$height)"
        }
    }

    // --- JNI declarations, implemented in rust/src/bridge.rs ---
    private external fun nativeGaussianBlur(pixels: IntArray, width: Int, height: Int, sigma: Float): IntArray
    private external fun nativeResizeBilinear(
        pixels: IntArray, srcWidth: Int, srcHeight: Int, dstWidth: Int, dstHeight: Int
    ): IntArray
    private external fun nativeQuickSimilarityScore(a: IntArray, b: IntArray, width: Int, height: Int): Float
    private external fun nativeAddGaussianNoise(
        pixels: IntArray, width: Int, height: Int, amount: Float, seed: Int
    ): IntArray
    private external fun nativeSimulateJpegArtifacts(
        pixels: IntArray, width: Int, height: Int, qualityPercent: Int
    ): IntArray
    private external fun nativeMotionBlur(
        pixels: IntArray, width: Int, height: Int, angleDegrees: Float, lengthPx: Int
    ): IntArray
    private external fun nativeColorFade(pixels: IntArray, width: Int, height: Int, fadeAmount: Float): IntArray
    private external fun nativeUpscaleBand(
        src: Bitmap, dst: Bitmap, factor: Int, y0: Int, y1: Int, amount: Float, sigma: Float, overshoot: Float,
        clampRadius: Int, gateLow: Float, gateHigh: Float, push: Float, pushRadius: Int, threads: Int
    ): Boolean
}
