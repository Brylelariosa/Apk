/*
 * mgba_jni.c — JNI bridge between mGBA core and Android/Kotlin.
 *
 * Fixes applied in this revision
 * ───────────────────────────────
 * FIX 1  pthread_mutex_t g_core_mutex protects g_core / g_fb.
 * FIX 2  core->loadConfig(core, &core->config) instead of mCoreLoadConfig.
 * FIX 3  nativeRunFrame pixel copy respects info.stride.
 * FIX 4  nativeReadAudioSamples — new function to drain mGBA blip buffers
 *         for Android AudioTrack. Uses blip_read_samples with stereo=1 to
 *         produce interleaved L/R PCM in one pass each channel.
 * FIX 5  nativeRunFrame(bitmap=NULL) skips the pixel-copy blit entirely.
 *         Used for fast-forward sub-frames that get overwritten before
 *         they're ever displayed — emulation and audio still run in full,
 *         only the wasted 240x160 copy is skipped.
 * FIX 6  Link SIO exchange now reads the outgoing byte from SIOMLT_SEND
 *         (0x400012A) instead of the receive-only SIOMULTI0 (0x4000120).
 *         Previously the link connected fine at the socket level but no
 *         real game data ever crossed it, since we were echoing back
 *         stale received bytes instead of what the ROM wrote to send.
 * FIX 7  SUPERSEDES FIX 6's approach. Polling SIOCNT after runFrame() and
 *         poking SIOMULTI0-3 with rawWrite16 never actually worked, because
 *         mGBA's own SIO controller (src/gba/sio.c) intercepts every SIOCNT
 *         write the instant the game makes it: if no GBASIODriver is
 *         registered for the active mode, it resolves the Start bit itself
 *         via a built-in "dummy driver" fallback, synchronously, before
 *         our post-runFrame check ever runs. So the raw pokes were mostly
 *         racing (and losing to) the core's own default behavior.
 *         The real fix is a proper GBASIODriver, registered with
 *         GBASIOSetDriver() in nativeLinkStart/Stop, whose writeRegister
 *         callback intercepts the Start-bit write synchronously and does
 *         the JNI exchange right there.
 *         See link_sio_write_register() near the bottom of this file.
 * FIX 8  Corrections after the first real CI build against the actual
 *         mGBA 0.10.3 headers (this project's pinned tag) turned up two
 *         places where mgba.io's current docs/master branch don't match
 *         0.10.3's actual API:
 *           - GBASIOSetDriver() takes 3 args here (sio, driver, mode), not
 *             2 — this build's compile error was "too few arguments to
 *             function call, expected 3, have 2".
 *           - struct GBASIODriver has no processEvents member on this
 *             revision — "no member named 'processEvents'".
 *         Also, GBASIOMultiplayerFinishTransfer() — the internal call the
 *         core's own drivers use to finish a transfer — triggered an
 *         implicit-declaration warning even with sio.h included, meaning
 *         it isn't exposed on this revision either; link_sio_write_register
 *         now writes SIOMULTI0-3 directly instead of risking an unresolved
 *         symbol at link time. Net effect: transfers complete correctly,
 *         but this build doesn't automatically raise the SIO IRQ the way
 *         hardware would — only relevant for a game that waits on that
 *         interrupt instead of polling SIOCNT's Start bit.
 *         Also fixed: struct LinkSIODriver / g_link_driver / g_link_gba were
 *         declared below nativeLoadROM and nativeRunFrame despite being used
 *         inside them — moved up next to the other link-cable globals.
 * FEATURE 9  Battery/cart save persistence + save states.
 *         nativeLoadROM now takes a second path and hands the core a real,
 *         app-managed VFile via core->loadSave() so SRAM/Flash/EEPROM
 *         writes survive app restarts (see the comment at that call site).
 *         nativeSaveState/nativeLoadState wrap mCoreSaveStateNamed()/
 *         mCoreLoadStateNamed() for full-snapshot save-state slots, keyed
 *         by whatever path the Kotlin layer passes in.
 * FIX 9  Root-caused why multiplayer still never got a ROM past its own
 *         "waiting for link" screen even once the two phones' network
 *         handshake succeeded. Two separate, GBATEK-confirmed bugs:
 *           (a) Nothing ever set SIOCNT's parent/child (bit 2) or
 *               all-ready (bit 3) status bits, both of which GBATEK
 *               documents games as checking *before* ever attempting a
 *               transfer — so a ROM that checks first could spin forever
 *               regardless of the network state. Fixed in
 *               link_sio_write_register() by reflecting both on every
 *               SIOCNT write, not just Start-bit ones.
 *           (b) GBATEK: the Start/Busy bit is "Read Only for Slaves" — a
 *               child unit never triggers its own transfer, only the
 *               parent does. Since the exchange branch below is keyed off
 *               *this device's own* Start-bit write, it correctly never
 *               fired on a child device — meaning a child's wifiExchange()/
 *               btExchange() (the only thing that ever answered the
 *               parent's request) was simply never called. The parent's
 *               every request timed out, deterministically, every time.
 *               Fixed with a new passive-responder entry point,
 *               nativeLinkChildExchange(), called from a background Kotlin
 *               thread the instant a request arrives over the network
 *               instead of waiting on a local SIOCNT write that was never
 *               coming. See its own comment below for the full picture,
 *               and LinkMultiplayer.kt for the Kotlin-side listener threads
 *               that call it.
 *         Also added: ID bits (4-5) and the Error bit (6) are now set
 *         correctly on the parent's side after each transfer (previously
 *         left at whatever the ROM had last written, which is undefined
 *         behavior per GBATEK for bit 4-5 before the first transfer).
 * FIX 10 Root-caused why SIOCNT/data-register correctness (FIX 9) still
 *         wasn't enough to get either test game (Yu-Gi-Oh! World
 *         Championship 2006, The Legend of Zelda: Four Swords) off their
 *         own link-wait screens: FIX 8 already flagged, but left
 *         unaddressed, that nothing here ever raises the SIO IRQ. Real GBA
 *         multiplayer code overwhelmingly uses the BIOS IntrWait/
 *         VBlankIntrWait pattern (enable INT_SERIAL in IE, then sleep for
 *         that interrupt) rather than busy-polling SIOCNT bit 7 in a spin
 *         loop — busy-polling burns battery on real hardware and every
 *         GBA-dev tutorial (Tonc, gbadev) teaches IntrWait for exactly this
 *         reason — so a transfer that completes correctly but never
 *         interrupts leaves that (very common) style of ROM asleep
 *         forever, waiting for a wake-up that's never coming, even though
 *         the bytes themselves crossed the network correctly. This also
 *         explains the fast-forward symptom reported after FIX 9: an
 *         interrupt-driven ROM sitting in that sleep state isn't hitting
 *         the Start-bit write per frame at all (it wrote it once, then went
 *         to sleep waiting on the IRQ), so there's nothing left to make
 *         link_exchange()'s blocking network round-trip pace the frame
 *         rate — fast-forward looks and feels completely normal precisely
 *         *because* the link exchange has stalled, not because it's
 *         keeping up.
 *
 *         Confirmed against mGBA's actual src/gba/sio.c (read directly from
 *         the mgba-emu/mgba source this pass, not inferred): the real
 *         GBASIOWriteSIOCNT() calls exactly
 *         `GBARaiseIRQ(sio->p, GBA_IRQ_SIO, 0)` — same pattern already used
 *         for every other GBA interrupt source (timers, DMA, keypad) — but
 *         only from its own dummy-driver fallback, and only for Normal
 *         mode; SIO_MULTI's dummy-driver case does no IRQ work at all.
 *         That means for Multi-Player mode specifically, raising this
 *         interrupt has only ever been a registered driver's own job —
 *         exactly the role link_sio_write_register()/
 *         nativeLinkChildExchange() play here — it was just never done.
 *         Fixed by calling GBARaiseIRQ(g_link_gba, GBA_IRQ_SIO, 0) at the
 *         same point each function already finishes a transfer (after the
 *         four SIOMULTI0-3 writes), on both the host and child paths, once
 *         per device since each phone is a fully separate process with its
 *         own core. Deliberately unconditional on the timedOut branch too:
 *         real Multi-Player transfers are clocked by the parent's fixed
 *         baud rate (see GBASIOCyclesPerTransfer in the real sio.c) and
 *         complete — and interrupt — on that schedule regardless of
 *         whether a given child answered in time, which is exactly why
 *         FIX 9 already gives a timed-out round real 0xFFFF data and the
 *         Error bit instead of silently withholding the round entirely.
 *         `<mgba/internal/gba/gba.h>` is already included above (needed
 *         for `struct GBA` itself), and GBARaiseIRQ/GBA_IRQ_SIO live in
 *         that same header, so no new include was needed.
 *         Caveat: read directly from real mGBA source this pass (a real
 *         improvement over guessing from memory, which is how FIX 7/8's
 *         signature mismatches happened), but not from a byte-identical
 *         checkout of the exact pinned 0.10.3 tag, and still never
 *         compiled in this sandbox — this foundational an interrupt API
 *         (shared by every hardware peripheral, not link-specific) is a
 *         poor candidate for a breaking signature change, but if the CI
 *         build disagrees, this is the first place to check.
 */

#include <jni.h>
#include <android/bitmap.h>
#include <android/log.h>
#include <pthread.h>

#include <fcntl.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include <mgba/core/core.h>
#include <mgba/core/config.h>
#include <mgba/core/log.h>
#include <mgba/core/serialize.h>     /* mCoreSaveStateNamed/mCoreLoadStateNamed,
                                       * SAVESTATE_* flags — save states. */
#include <mgba/core/blip_buf.h>      /* blip_t, blip_samples_avail, blip_read_samples
                                       * — this is mGBA's public wrapper header that
                                       * re-exports src/third-party/blip_buf/blip_buf.h.
                                       * The bare "mgba-util/blip_buf.h" path used
                                       * previously does not exist in the mGBA tree. */
#include <mgba-util/vfs.h>           /* VFileOpen/struct VFile — battery save +
                                       * save-state I/O both go through explicit
                                       * VFiles rather than mCore's slot/directory
                                       * API, since this app never sets up
                                       * core->dirs (no mDirectorySetAttachBase
                                       * call anywhere) — see nativeLoadROM,
                                       * nativeSaveState, nativeLoadState. */

#ifndef mColor
typedef uint32_t mColor;
#endif
#include <mgba/gba/core.h>
#include <mgba/gba/interface.h>       /* struct GBASIODriver */
#include <mgba/internal/gba/gba.h>    /* struct GBA — needed to reach gba->sio via core->board */
#include <mgba/internal/gba/sio.h>    /* GBASIOSetDriver, enum GBASIOMode (SIO_MULTI) */

#define LOG_TAG        "mGBA-JNI"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

/* GBA ARM7TDMI clock — used as the blip_buf input clock rate.
 * mGBA advances blip buffers at the CPU clock, so this must match. */
#define GBA_AUDIO_CLOCK 16777216

/* ── Globals — all access must hold g_core_mutex ────────────────────────── */

static pthread_mutex_t g_core_mutex = PTHREAD_MUTEX_INITIALIZER;
static struct mCore   *g_core   = NULL;
static mColor         *g_fb     = NULL;
static int             g_width  = 240;
static int             g_height = 160;

/* ── Link cable state — also protected by g_core_mutex ──────────────────── */

static jobject   g_link_obj      = NULL;
static jmethodID g_link_xchg_mid = NULL;
static bool      g_link_active   = false;
static bool      g_link_is_host  = false;

/* FIX 8 (build-log driven): these were previously declared far below, in the
 * "GBA LINK CABLE MULTIPLAYER" section — but nativeLoadROM and nativeRunFrame
 * both reference them earlier in the file than that, which doesn't compile
 * in C (confirmed by the actual build log: "use of undeclared identifier
 * 'g_link_gba'" / "'g_link_driver'" at the point of use). Declared here
 * instead, alongside the other link-cable globals, so every use site is
 * after the declaration regardless of where in the file it appears. */
struct LinkSIODriver {
    struct GBASIODriver d;
    JNIEnv  *env;       /* only valid while nativeRunFrame is on the stack */
    uint16_t localSend; /* last value the ROM wrote to SIOMLT_SEND (0x12A) */
};
static struct LinkSIODriver g_link_driver;
static struct GBA          *g_link_gba = NULL;

/* ── Logger ─────────────────────────────────────────────────────────────── */

static void jni_log(struct mLogger *logger, int category,
                    enum mLogLevel level, const char *fmt, va_list args)
{
    (void)logger; (void)category; (void)level;
    char buf[512];
    vsnprintf(buf, sizeof(buf), fmt, args);
    LOGI("%s", buf);
}
static struct mLogger g_logger = { .log = jni_log };

/* ── Internal cleanup — CALLER MUST HOLD g_core_mutex ───────────────────── */

static void destroy_core(void)
{
    if (g_core) {
        g_core->deinit(g_core);
        g_core = NULL;
    }
    free(g_fb);
    g_fb = NULL;
}

/* ── nativeLoadROM ──────────────────────────────────────────────────────── */

JNIEXPORT jboolean JNICALL
Java_com_mgba_android_EmulatorEngine_nativeLoadROM(
        JNIEnv *env, jobject thiz, jstring jpath, jstring jSavePath)
{
    /* FIX (residual risk from prior pass): the old core used to be destroyed
     * unconditionally here, before the new ROM was even opened. If any step
     * below failed (bad/corrupt file, core init failure, OOM), the in-progress
     * session was already gone with nothing to fall back to.
     *
     * Now the new core is built entirely in local variables — g_core/g_fb are
     * never touched — and the old core is only torn down once every step has
     * succeeded. On any failure path the caller's existing session (if any)
     * is left running exactly as it was. */

    mLogSetDefaultLogger(&g_logger);

    const char *path = (*env)->GetStringUTFChars(env, jpath, NULL);
    if (!path) return JNI_FALSE;
    LOGI("Loading ROM: %s", path);

    struct mCore *core = GBACoreCreate();
    if (!core) {
        LOGE("GBACoreCreate failed");
        (*env)->ReleaseStringUTFChars(env, jpath, path);
        return JNI_FALSE;
    }

    if (!core->init(core)) {
        LOGE("core->init failed");
        core->deinit(core);
        (*env)->ReleaseStringUTFChars(env, jpath, path);
        return JNI_FALSE;
    }

    mCoreInitConfig(core, "mgba-android");

    struct mCoreOptions opts;
    memset(&opts, 0, sizeof(opts));
    opts.skipBios     = true;
    opts.useBios      = false;
    opts.sampleRate   = 44100;
    opts.audioBuffers = 1024;
    opts.volume       = 256;
    mCoreConfigLoadDefaults(&core->config, &opts);
    /* AUDIO FIX (root cause, not a symptom patch): this MUST be the single-
     * argument mCoreLoadConfig(core), not core->loadConfig(core, &core->config)
     * directly.
     *
     * mCoreLoadConfig() internally calls mCoreLoadForeignConfig(), which does
     * two things before it ever reaches the vtable loadConfig:
     *   1. mCoreConfigMap(config, &core->opts)  -- maps the "volume" key we
     *      just set above (opts.volume = 256) into core->opts.volume.
     *   2. core->setAudioBufferSize(core, core->opts.audioBuffers).
     * Only THEN does it call core->loadConfig(core, config), which for the
     * GBA core runs:  gba->audio.masterVolume = core->opts.volume;
     *
     * Calling core->loadConfig() directly (as this file previously did)
     * skips step 1 entirely, so core->opts.volume is left at its
     * zero-initialized default and every ROM's audio mixer comes up
     * permanently muted at masterVolume=0 -- silent regardless of anything
     * downstream (AudioTrack, blip_buf, etc. all work correctly; they're
     * just relaying real zeroes). This was the actual cause of "no sound";
     * the AudioTrack/AudioFocus work in the Kotlin layer was correct but
     * couldn't fix a mixer that was muted at the native layer. */
    mCoreLoadConfig(core);

    const unsigned w = 240, h = 160;

    mColor *fb = (mColor *)calloc((size_t)w * (size_t)h, sizeof(mColor));
    if (!fb) {
        LOGE("framebuffer alloc failed (%ux%u)", w, h);
        core->deinit(core);
        (*env)->ReleaseStringUTFChars(env, jpath, path);
        return JNI_FALSE;
    }
    core->setVideoBuffer(core, fb, (size_t)w);

    if (!mCoreLoadFile(core, path)) {
        LOGE("mCoreLoadFile failed: %s", path);
        free(fb);
        core->deinit(core);
        (*env)->ReleaseStringUTFChars(env, jpath, path);
        return JNI_FALSE;
    }
    (*env)->ReleaseStringUTFChars(env, jpath, path);

    /* FEATURE: battery/cart save (SRAM/Flash/EEPROM) persistence.
     * core->loadSave() hands the core a VFile it owns for the rest of this
     * core's lifetime — mGBA's savedata backend mmaps it, and every in-game
     * write (a menu's "Save the game?" prompt, an action game's checkpoint,
     * etc.) lands directly in the mapped pages, which the kernel writes back
     * to [savePath] on its own — the same durability model any mmap-backed
     * store relies on (mGBA's own VFS layer calls msync when explicitly
     * syncing mapped data). The core closes this VFile itself as part of
     * core->deinit() (see destroy_core()), so it is NOT closed here.
     *
     * O_CREAT | O_RDWR, no O_TRUNC: a fresh save is created empty and the
     * savedata backend grows it to the detected size (SRAM/Flash/EEPROM) on
     * first write; an existing file's contents are preserved untouched, so
     * re-loading the same ROM later (see MainActivity.deriveRomBaseName)
     * resumes the same in-game save.
     *
     * Order matters: this MUST run after mCoreLoadFile (the save type is
     * detected from the ROM header while loading) and before core->reset()
     * below — the same order every mGBA frontend uses (see e.g.
     * src/platform/sdl/main.c: mCoreLoadFile → mCoreAutoloadSave → … →
     * reset happens once the emulation thread actually starts). Reset only
     * reinitialises CPU/PPU/etc. state; it does not touch already-loaded
     * save data, exactly like a real GBA's power button doesn't erase the
     * cartridge's battery save. */
    if (jSavePath) {
        const char *savePath = (*env)->GetStringUTFChars(env, jSavePath, NULL);
        if (savePath) {
            struct VFile *saveVf = VFileOpen(savePath, O_CREAT | O_RDWR);
            if (saveVf) {
                if (!core->loadSave(core, saveVf)) {
                    LOGW("core->loadSave failed for %s (ROM may have no battery save)", savePath);
                }
            } else {
                LOGW("VFileOpen failed for save path: %s", savePath);
            }
            (*env)->ReleaseStringUTFChars(env, jSavePath, savePath);
        }
    } else {
        LOGW("nativeLoadROM: no save path given — battery save will not persist");
    }

    core->reset(core);

    /* ── FIX: Explicitly set blip buffer sample rates after reset ────────
     * mCoreConfigLoadDefaults+loadConfig should configure this, but on some
     * mGBA build variants loadConfig doesn't call blip_set_rates until a
     * subsequent reset — which is circular.  Calling it here unconditionally
     * after the reset guarantees both blip buffers are live before any frame
     * is rendered.  If rates were already set correctly this is a safe no-op. */
    {
        blip_t *left  = core->getAudioChannel(core, 0);
        blip_t *right = core->getAudioChannel(core, 1);
        if (left && right) {
            blip_set_rates(left,  GBA_AUDIO_CLOCK, (double)opts.sampleRate);
            blip_set_rates(right, GBA_AUDIO_CLOCK, (double)opts.sampleRate);
            LOGI("blip_set_rates: clock=%d  sampleRate=%d",
                 GBA_AUDIO_CLOCK, (int)opts.sampleRate);
        } else {
            LOGW("getAudioChannel returned NULL — audio will be silent");
        }
    }

    /* Swap in the fully-loaded new core and only now tear down whatever was
     * running before. destroy_core() operates on the (still-old) globals, so
     * we snapshot them, install the new core, then deinit the snapshot —
     * all under one lock, so nativeRunFrame/nativeReadAudioSamples/etc. never
     * observe a half-swapped state. */
    pthread_mutex_lock(&g_core_mutex);
    struct mCore *old_core = g_core;
    mColor       *old_fb   = g_fb;
    /* SAFETY: g_link_gba points into the OLD core's GBA struct, which
     * old_core->deinit() below is about to free. If a link session was left
     * running across a ROM swap, drop it now rather than leave a dangling
     * pointer for link_sio_write_register to dereference on the next
     * transfer — the Kotlin side will see the link drop and can restart it
     * against the new ROM if the user still wants it. */
    if (g_link_active) {
        g_link_active = false;
        g_link_gba    = NULL;
        LOGW("ROM swapped while a link session was active — link stopped");
    }
    g_core   = core;
    g_fb     = fb;
    g_width  = (int)w;
    g_height = (int)h;
    pthread_mutex_unlock(&g_core_mutex);

    if (old_core) {
        old_core->deinit(old_core);
    }
    free(old_fb);

    LOGI("ROM loaded OK — core=%p  %dx%d", (void*)core, (int)w, (int)h);
    return JNI_TRUE;
}

/* Forward declaration */
static uint32_t link_exchange(JNIEnv *env, uint32_t local_data);

/* ── nativeRunFrame ─────────────────────────────────────────────────────── */

JNIEXPORT void JNICALL
Java_com_mgba_android_EmulatorEngine_nativeRunFrame(
        JNIEnv *env, jobject thiz, jobject bitmap)
{
    pthread_mutex_lock(&g_core_mutex);
    if (!g_core || !g_fb) {
        pthread_mutex_unlock(&g_core_mutex);
        return;
    }

    /* FIX 7: give the SIO driver callback a valid JNIEnv* for the duration of
     * this call only — it fires synchronously, on this same thread, from
     * inside runFrame() the instant the game writes the Start bit, so it can
     * safely borrow this call's env rather than needing one of its own. */
    g_link_driver.env = g_link_active ? env : NULL;
    g_core->runFrame(g_core);
    g_link_driver.env = NULL;

    AndroidBitmapInfo info;
    void *pixels = NULL;
    if (bitmap == NULL) {
        /* PERF: fast-forward sub-frames that will never reach the screen
         * (see the Kotlin call site in MainActivity.startGameLoop — only the
         * LAST sub-frame of a fast-forward batch is displayed) pass NULL
         * here to skip the pixel copy below entirely. Emulation and audio
         * still run in full above; only the wasted blit is skipped. */
        pthread_mutex_unlock(&g_core_mutex);
        return;
    }
    if (AndroidBitmap_getInfo(env, bitmap, &info) < 0) {
        pthread_mutex_unlock(&g_core_mutex);
        return;
    }
    if (AndroidBitmap_lockPixels(env, bitmap, &pixels) < 0) {
        pthread_mutex_unlock(&g_core_mutex);
        return;
    }

    for (int row = 0; row < g_height; row++) {
        const mColor *srcRow = g_fb + (size_t)row * (size_t)g_width;
        uint32_t     *dstRow = (uint32_t *)((uint8_t *)pixels
                                            + (size_t)row * info.stride);
        for (int col = 0; col < g_width; col++) {
            dstRow[col] = (srcRow[col] & 0x00FFFFFFu) | 0xFF000000u;
        }
    }

    AndroidBitmap_unlockPixels(env, bitmap);
    pthread_mutex_unlock(&g_core_mutex);
}

/* ── nativeReadAudioSamples ─────────────────────────────────────────────── */
/*
 * FIX 4 — drain mGBA blip buffers into a Java short[] for AudioTrack.
 *
 * blip_read_samples(buf, arr, count, stereo=1) writes to every OTHER element
 * when stereo=1, so we can interleave L and R in one pass each:
 *   L → arr[0], arr[2], arr[4]…
 *   R → arr[1], arr[3], arr[5]…
 *
 * Returns the number of stereo sample PAIRS written (array elements used = n*2).
 * Returns 0 when no samples are available or the core is not initialised.
 *
 * Called from the game thread immediately after nativeRunFrame(), so the mutex
 * is always available (no nested locking).
 */
JNIEXPORT jint JNICALL
Java_com_mgba_android_EmulatorEngine_nativeReadAudioSamples(
        JNIEnv *env, jobject thiz, jshortArray jbuf, jint maxSamples)
{
    pthread_mutex_lock(&g_core_mutex);
    if (!g_core) { pthread_mutex_unlock(&g_core_mutex); return 0; }

    blip_t *left  = g_core->getAudioChannel(g_core, 0);
    blip_t *right = g_core->getAudioChannel(g_core, 1);
    if (!left || !right) { pthread_mutex_unlock(&g_core_mutex); return 0; }

    int availL = blip_samples_avail(left);
    int availR = blip_samples_avail(right);
    /* AUDIO FIX: previously only availL was checked and re-used for both
     * blip_read_samples() calls, on the assumption the two channels are
     * always in lockstep (true for mGBA's GBA core in normal operation, but
     * not something the JNI layer should silently assume — reading more
     * samples than a channel actually has buffered is undefined behavior in
     * blip_buf, not a safely-clamped no-op). Take the minimum of both. */
    int avail = (availL < availR) ? availL : availR;
    int count = (avail < (int)maxSamples) ? avail : (int)maxSamples;
    if (count <= 0) { pthread_mutex_unlock(&g_core_mutex); return 0; }

    jshort *arr = (*env)->GetShortArrayElements(env, jbuf, NULL);
    if (!arr) { pthread_mutex_unlock(&g_core_mutex); return 0; }

    /* stereo=1: write to every other element, perfect for L/R interleaving */
    blip_read_samples(left,  arr,     count, 1);   /* → [0],[2],[4]…  */
    blip_read_samples(right, arr + 1, count, 1);   /* → [1],[3],[5]…  */

    (*env)->ReleaseShortArrayElements(env, jbuf, arr, 0);
    pthread_mutex_unlock(&g_core_mutex);
    return (jint)count;
}

/* ── nativeSetKeys ──────────────────────────────────────────────────────── */

JNIEXPORT void JNICALL
Java_com_mgba_android_EmulatorEngine_nativeSetKeys(
        JNIEnv *env, jobject thiz, jint keys)
{
    pthread_mutex_lock(&g_core_mutex);
    if (g_core) g_core->setKeys(g_core, (uint32_t)keys);
    pthread_mutex_unlock(&g_core_mutex);
}

/* ── nativeGetWidth / nativeGetHeight ───────────────────────────────────── */

JNIEXPORT jint JNICALL
Java_com_mgba_android_EmulatorEngine_nativeGetWidth(JNIEnv *env, jobject thiz)
{
    pthread_mutex_lock(&g_core_mutex);
    jint w = (jint)g_width;
    pthread_mutex_unlock(&g_core_mutex);
    return w;
}

JNIEXPORT jint JNICALL
Java_com_mgba_android_EmulatorEngine_nativeGetHeight(JNIEnv *env, jobject thiz)
{
    pthread_mutex_lock(&g_core_mutex);
    jint h = (jint)g_height;
    pthread_mutex_unlock(&g_core_mutex);
    return h;
}

/* ── nativeDestroy ──────────────────────────────────────────────────────── */

JNIEXPORT void JNICALL
Java_com_mgba_android_EmulatorEngine_nativeDestroy(JNIEnv *env, jobject thiz)
{
    pthread_mutex_lock(&g_core_mutex);
    destroy_core();
    pthread_mutex_unlock(&g_core_mutex);
    LOGI("mGBA core destroyed");
}

/* ═══════════════════════════════════════════════════════════════════════════
 * SAVE STATES
 * ═══════════════════════════════════════════════════════════════════════════
 * Full emulator snapshots (CPU/PPU/audio/in-flight save data/RTC — enough to
 * resume mid-frame exactly where you left off), independent of the battery
 * save handled in nativeLoadROM above. Written via mCoreSaveStateNamed()/
 * mCoreLoadStateNamed() against a plain VFile at whatever path the Kotlin
 * layer passes in.
 *
 * These *Named variants (not mCoreSaveState()/mCoreLoadState()'s slot-number
 * API) are used deliberately: the slot API resolves numbered slots through
 * core->dirs.state, a VDir this app never sets up (mCoreInitConfig() above
 * only loads config values — see nativeLoadROM — it doesn't attach
 * directories the way a desktop frontend's mDirectorySetAttachBase() call
 * would). The Named variants take an explicit VFile instead and need no
 * such setup; MainActivity.kt manages "slots" itself as plain files.
 *
 * Flags: SAVESTATE_SAVEDATA | SAVESTATE_RTC | SAVESTATE_METADATA.
 * SAVESTATE_SCREENSHOT is deliberately excluded — this build has USE_PNG and
 * USE_ZLIB both OFF (see CMakeLists.txt), and PNG-embedded screenshot
 * support in src/core/serialize.c is gated behind USE_PNG. SAVESTATE_CHEATS
 * is excluded because this app never attaches a cheat device. */

JNIEXPORT jboolean JNICALL
Java_com_mgba_android_EmulatorEngine_nativeSaveState(
        JNIEnv *env, jobject thiz, jstring jpath)
{
    pthread_mutex_lock(&g_core_mutex);
    if (!g_core) {
        pthread_mutex_unlock(&g_core_mutex);
        LOGW("nativeSaveState: no ROM loaded");
        return JNI_FALSE;
    }

    const char *path = (*env)->GetStringUTFChars(env, jpath, NULL);
    if (!path) {
        pthread_mutex_unlock(&g_core_mutex);
        return JNI_FALSE;
    }

    /* O_TRUNC: a save-state slot is always a single complete snapshot that
     * fully replaces whatever was there before — never appended to or
     * merged (matches src/feature/gui/gui-runner.c's own slot-write
     * pattern: O_CREAT | O_TRUNC | O_RDWR). */
    struct VFile *vf = VFileOpen(path, O_CREAT | O_TRUNC | O_RDWR);
    (*env)->ReleaseStringUTFChars(env, jpath, path);
    if (!vf) {
        pthread_mutex_unlock(&g_core_mutex);
        LOGE("nativeSaveState: VFileOpen failed");
        return JNI_FALSE;
    }

    bool ok = mCoreSaveStateNamed(g_core, vf,
        SAVESTATE_SAVEDATA | SAVESTATE_RTC | SAVESTATE_METADATA);
    vf->close(vf);
    pthread_mutex_unlock(&g_core_mutex);
    LOGI("nativeSaveState: %s", ok ? "OK" : "FAILED");
    return ok ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL
Java_com_mgba_android_EmulatorEngine_nativeLoadState(
        JNIEnv *env, jobject thiz, jstring jpath)
{
    pthread_mutex_lock(&g_core_mutex);
    if (!g_core) {
        pthread_mutex_unlock(&g_core_mutex);
        LOGW("nativeLoadState: no ROM loaded");
        return JNI_FALSE;
    }

    const char *path = (*env)->GetStringUTFChars(env, jpath, NULL);
    if (!path) {
        pthread_mutex_unlock(&g_core_mutex);
        return JNI_FALSE;
    }

    struct VFile *vf = VFileOpen(path, O_RDONLY);
    (*env)->ReleaseStringUTFChars(env, jpath, path);
    if (!vf) {
        pthread_mutex_unlock(&g_core_mutex);
        LOGW("nativeLoadState: slot file missing or unreadable");
        return JNI_FALSE;
    }

    bool ok = mCoreLoadStateNamed(g_core, vf,
        SAVESTATE_SAVEDATA | SAVESTATE_RTC | SAVESTATE_METADATA);
    vf->close(vf);
    pthread_mutex_unlock(&g_core_mutex);
    LOGI("nativeLoadState: %s", ok ? "OK" : "FAILED");
    return ok ? JNI_TRUE : JNI_FALSE;
}

/* ═══════════════════════════════════════════════════════════════════════════
 * GBA LINK CABLE MULTIPLAYER
 * ═══════════════════════════════════════════════════════════════════════════ */

static uint32_t link_exchange(JNIEnv *env, uint32_t local_data)
{
    if (!env || !g_link_obj || !g_link_xchg_mid) return 0xFFFFFFFFu;
    jint r = (*env)->CallIntMethod(env, g_link_obj,
                                    g_link_xchg_mid, (jint)local_data);
    if ((*env)->ExceptionOccurred(env)) {
        (*env)->ExceptionClear(env);
        return 0xFFFFFFFFu;
    }
    return (uint32_t)r;
}

/* ── FIX 7: real GBASIODriver, registered with the core's SIO subsystem ──
 *
 * This is what src/gba/sio.c actually dispatches to when the game writes
 * SIOCNT or SIOMLT_SEND — as opposed to the old approach of reading those
 * registers back out after the fact, which the core's own dummy-driver
 * fallback had usually already resolved by the time we looked.
 *
 * struct GBASIODriver only specifies the callback layout; every real driver
 * in mGBA (see src/gba/hardware.c's Game Boy Player driver for the pattern
 * this mirrors) wraps it in its own struct with whatever extra state it
 * needs, and casts back to that wrapper inside its callbacks.
 * (struct LinkSIODriver / g_link_driver / g_link_gba are declared up near
 * the other link-cable globals — see FIX 8.)
 *
 * address here is the register OFFSET from the 0x4000000 IO base (mGBA's
 * own dispatcher indexes memory.io[] with it), so SIOCNT is 0x128 and
 * SIOMLT_SEND is 0x12A — not the full 0x04000128 / 0x400012A addresses. */
static uint16_t link_sio_write_register(struct GBASIODriver *driver,
                                         uint32_t address, uint16_t value)
{
    struct LinkSIODriver *ld = (struct LinkSIODriver *)driver;

    if (address == 0x12Au) {                 /* SIOMLT_SEND: just latch it */
        ld->localSend = value;
        return value;
    }

    if (address != 0x128u) return value;

    /* FIX 9 (GBATEK-verified: gbatek "SIO Multi-Player Mode" register table).
     * Reflect link status on *every* SIOCNT write, not only ones with the
     * Start bit set:
     *   Bit 2 (SI-Terminal): 0=Parent, 1=Child            — read-only status
     *   Bit 3 (SD-Terminal): 0=Bad connection, 1=All Ready — read-only status
     * Both are hardware-read-only — real GBAs don't let the CPU set them,
     * they always reflect true link state — and GBATEK's own Multi-Player
     * initialization sequence has every ROM read both BEFORE ever attempting
     * a transfer ("Read SIOCNT Bit 3 to verify that all GBAs are in
     * Multi-Player mode" / "...Bit 2 to detect whether this is the Parent").
     * Nothing previously set either bit, so a ROM doing that check first —
     * before ever writing the Start bit — would see bit 3 permanently 0,
     * indistinguishable from "no cable plugged in", and could sit on a
     * "waiting for link" screen forever even after the phones' own network
     * handshake had already succeeded. Applying this on every write (not
     * just Start-bit ones) means it's already correct by the time the ROM's
     * *first* SIOCNT write (the one that merely selects multiplayer mode,
     * Start bit still 0) happens, with no dependency on transfer timing. */
    if (g_link_active) {
        value |= 0x0008u;                                                      /* bit3: ready */
        value = (uint16_t)((value & ~0x0004u) | (g_link_is_host ? 0u : 0x0004u)); /* bit2 */
    }

    if ((value & 0x0080u) && ld->env
        && g_link_obj && g_link_xchg_mid && g_core) {  /* Start/Busy bit */
        uint32_t remote_data = link_exchange(ld->env, (uint32_t)ld->localSend);
        bool     timedOut    = (remote_data == 0xFFFFFFFFu);
        uint16_t remote16    = (uint16_t)(remote_data & 0xFFFFu);
        uint16_t hostData, childData;
        if (g_link_is_host) {
            hostData = ld->localSend; childData = remote16;
        } else {
            hostData = remote16;      childData = ld->localSend;
        }
        /* FIX 8 (build-log driven): GBASIOMultiplayerFinishTransfer() was the
         * "correct" internal call for this — same one the core's own drivers
         * use — but the previous build log showed it as an implicit
         * (undeclared) function even with sio.h included, meaning it isn't
         * actually exposed on the mGBA revision this project pins (0.10.3);
         * that header apparently gained it later. Rather than risk an
         * unresolved symbol at link time, write the four multiplayer data
         * registers directly through the same mCore vtable calls already
         * proven to work elsewhere in this file. This used to also skip the
         * SIO IRQ that the internal call would have raised automatically —
         * see FIX 10 below, which now raises it explicitly instead. */
        g_core->rawWrite16(g_core, 0x04000120u, 0, hostData);
        g_core->rawWrite16(g_core, 0x04000122u, 0, childData);
        g_core->rawWrite16(g_core, 0x04000124u, 0, 0xFFFFu);
        g_core->rawWrite16(g_core, 0x04000126u, 0, 0xFFFFu);
        /* FIX 10: the transfer is done — raise the interrupt an
         * interrupt-driven ROM (IntrWait/VBlankIntrWait on INT_SERIAL,
         * the standard GBA-dev pattern) is asleep waiting for. A
         * poll-driven ROM just ignores this (IF gets a bit set that
         * nothing ever checks) — safe either way. See FIX 10 above for
         * why this is unconditional on timedOut. */
        GBARaiseIRQ(g_link_gba, GBA_IRQ_SIO, 0);
        value &= ~0x0080u;   /* Start/Busy bit: transfer already complete */
        /* FIX 9: per GBATEK, ID bits (4-5) are undefined until the first
         * transfer completes (00=parent, 01=1st child) — games use this,
         * alongside bit 2 above, to tell their own role apart. Bit 6 (Error)
         * flags a round where the peer didn't answer in time, instead of
         * silently handing the ROM a stale 0xFFFF indistinguishable from
         * real "not connected" data — GBATEK explicitly expects parent-side
         * error checking here ("parent unit might... perform error
         * checking"), so this gives it something real to check. */
        value = (uint16_t)((value & ~0x0030u) | (g_link_is_host ? 0u : 0x0010u));
        value = timedOut ? (uint16_t)(value | 0x0040u) : (uint16_t)(value & ~0x0040u);
    }
    return value;
}

/* FIX 9 — passive-child responder entry point.
 *
 * GBATEK is explicit that the Start/Busy bit is "Read Only for Slaves" — on
 * real hardware a child unit never triggers a transfer itself, it only ever
 * reacts to the parent's clock. link_sio_write_register()'s exchange branch
 * above is keyed off *this device's own* SIOCNT Start-bit write, so on a
 * child device that branch — correctly, matching real hardware — never
 * fires at all. That meant a child's local jniExchangeData()/wifiExchange()/
 * btExchange() call (the only thing that ever answered the parent's request
 * packet) never happened, so the parent's every attempt timed out waiting
 * for a reply nothing was ever going to send: multiplayer could never
 * progress past a "waiting for players" screen, regardless of whether the
 * two phones' own network connection was fine.
 *
 * Called from a background Kotlin thread (LinkMultiplayer's dedicated Wi-Fi
 * child-listener thread, or its Bluetooth reader thread acting in child
 * mode) the instant a request arrives from the parent over the network —
 * never from anything the local ROM does. It writes this device's own
 * SIOMULTI0/1 exactly as the parent side does above, so this device's ROM
 * sees a completed transfer next time it reads those registers, and returns
 * this device's latched SIOMLT_SEND value so the Kotlin caller can send it
 * back to the parent as that round's reply.
 *
 * Deliberately does NOT touch SIOCNT itself (unlike the parent-side branch
 * above): doing so correctly would mean preserving the mode/baud bits the
 * ROM already wrote, which needs reading the register back first, and
 * there's no confirmed-working raw-read counterpart to rawWrite16 in this
 * file yet to verify that against a real build. Bits 2/3 are still handled
 * correctly for a child (see the write-register comment above — those
 * apply on the child's own initial mode-setup write, which it does still
 * make); only the post-transfer ID/Error bits (4-6) are not mirrored on the
 * child's own SIOCNT. See KNOWN_LIMITATIONS.md.
 */
JNIEXPORT jint JNICALL
Java_com_mgba_android_EmulatorEngine_nativeLinkChildExchange(
        JNIEnv *env, jobject thiz, jint hostData)
{
    (void)env; (void)thiz;
    pthread_mutex_lock(&g_core_mutex);
    if (!g_link_active || g_link_is_host || !g_link_gba || !g_core) {
        pthread_mutex_unlock(&g_core_mutex);
        return (jint)0xFFFF;
    }
    uint16_t childData = g_link_driver.localSend;
    g_core->rawWrite16(g_core, 0x04000120u, 0, (uint16_t)hostData);
    g_core->rawWrite16(g_core, 0x04000122u, 0, childData);
    g_core->rawWrite16(g_core, 0x04000124u, 0, 0xFFFFu);
    g_core->rawWrite16(g_core, 0x04000126u, 0, 0xFFFFu);
    /* FIX 10: same reasoning as the host side above — this device is a
     * separate process with its own core, so it needs its own IRQ raised
     * on its own GBA struct for an interrupt-driven child ROM to ever wake
     * up and notice the transfer that just landed in its SIOMULTI regs. */
    GBARaiseIRQ(g_link_gba, GBA_IRQ_SIO, 0);
    pthread_mutex_unlock(&g_core_mutex);
    return (jint)childData;
}

JNIEXPORT jboolean JNICALL
Java_com_mgba_android_EmulatorEngine_nativeLinkStart(
        JNIEnv *env, jobject thiz, jobject link_obj, jboolean is_host)
{
    (void)thiz;
    if (g_link_obj) { (*env)->DeleteGlobalRef(env, g_link_obj); g_link_obj = NULL; }

    jclass cls = (*env)->GetObjectClass(env, link_obj);
    g_link_xchg_mid = (*env)->GetMethodID(env, cls, "jniExchangeData", "(I)I");
    if (!g_link_xchg_mid) {
        LOGE("LinkMultiplayer.jniExchangeData(I)I not found");
        return JNI_FALSE;
    }
    g_link_obj     = (*env)->NewGlobalRef(env, link_obj);
    g_link_is_host = (bool)is_host;

    pthread_mutex_lock(&g_core_mutex);
    if (!g_core) {
        pthread_mutex_unlock(&g_core_mutex);
        LOGE("nativeLinkStart called with no ROM loaded");
        (*env)->DeleteGlobalRef(env, g_link_obj);
        g_link_obj = NULL;
        return JNI_FALSE;
    }

    /* FIX 7/8: register a real driver with the core's SIO subsystem instead
     * of relying on post-frame register polling. GBASIOSetDriver() on this
     * mGBA revision takes a mode argument (confirmed by the build log: the
     * 2-argument call I wrote from mgba's current docs failed to compile —
     * "too few arguments to function call, expected 3, have 2" — this
     * revision's signature apparently predates that simplification), and
     * struct GBASIODriver has no processEvents member on this revision
     * either (also confirmed by the build log). */
    g_link_gba = (struct GBA *)g_core->board;
    g_link_driver.d.init          = 0;
    g_link_driver.d.deinit        = 0;
    g_link_driver.d.load          = 0;
    g_link_driver.d.unload        = 0;
    g_link_driver.d.writeRegister = link_sio_write_register;
    g_link_driver.env             = NULL;
    g_link_driver.localSend       = 0xFFFFu;
    GBASIOSetDriver(&g_link_gba->sio, &g_link_driver.d, SIO_MULTI);

    g_link_active = true;
    pthread_mutex_unlock(&g_core_mutex);

    LOGI("Link multiplayer started (host=%d)", (int)is_host);
    return JNI_TRUE;
}

JNIEXPORT void JNICALL
Java_com_mgba_android_EmulatorEngine_nativeLinkStop(JNIEnv *env, jobject thiz)
{
    (void)thiz;
    pthread_mutex_lock(&g_core_mutex);
    g_link_active = false;
    if (g_link_gba) {
        GBASIOSetDriver(&g_link_gba->sio, NULL, SIO_MULTI);   /* core reverts to its own dummy driver */
        g_link_gba = NULL;
    }
    pthread_mutex_unlock(&g_core_mutex);

    if (g_link_obj) {
        (*env)->DeleteGlobalRef(env, g_link_obj);
        g_link_obj = NULL;
    }
    g_link_xchg_mid = NULL;
    LOGI("Link multiplayer stopped");
}
