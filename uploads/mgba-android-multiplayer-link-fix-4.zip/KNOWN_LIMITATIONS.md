# KNOWN_LIMITATIONS — Seventh pass

## Environment constraints on this pass itself

Identical constraints to every pass before it: no Android SDK/NDK, no
Kotlin/C compiler, no network access to fetch either, so `GBARaiseIRQ`
was never actually called against a real build. What's different this
pass: instead of reasoning from memory about mGBA's internal API (the
approach that produced the FIX 7/8 signature mismatches, later corrected
by real build-log output), this pass fetched and read mGBA's actual
`src/gba/sio.c` from its real source repository and confirmed the exact
call — `GBARaiseIRQ(sio->p, GBA_IRQ_SIO, 0)` — used for exactly this
purpose elsewhere in the same file (Normal-mode SIO, in the core's own
dummy-driver fallback). That's real evidence the call and constant name
are right, not a guess, but it's still not a build log against this
project's exact pinned tag (0.10.3) — see "Found but not fixed" below.

## Found but deliberately not fixed this pass

- **Still no way to confirm this against real hardware or even a CI
  build from inside this sandbox.** The recommendation from every
  previous pass stands: run the real build (GitHub Actions or a local
  Android Studio checkout) before assuming this is done. If
  `GBARaiseIRQ`'s signature has changed since whatever revision the
  fetched `sio.c` reflects, the compiler will say so immediately and
  loudly (wrong argument count/type) — that's a much cheaper failure
  mode than the silent "compiles fine, still doesn't work in-game"
  failure this pass was diagnosing.
- **The child's own SIOCNT still doesn't get ID/Error bits set** — unchanged
  from the sixth pass (see that section below); this pass's fix only
  touches the interrupt controller (IF/IE), not SIOCNT itself, so it
  doesn't need the risky raw-read that finding was blocked on, but it
  also doesn't resolve it.
- **If a game turns out to need the IRQ raised on a more precise cycle
  count than "immediately"** (real Multi-Player transfers take a
  baud-rate-dependent number of cycles — see `GBASIOCyclesPerTransfer` in
  the real `sio.c`, which this project's network-bound transfer already
  can't match exactly since it's paced by a Wi-Fi/Bluetooth round-trip,
  not a shift-register clock) — this could in principle matter for a game
  doing very fine-grained timing assumptions around the interrupt, but no
  such requirement is documented in GBATEK for the interrupt itself (only
  for the data-ready timing), so this wasn't treated as a blocking
  concern.

# KNOWN_LIMITATIONS — Sixth pass

## Environment constraints on this pass itself

Same sandbox constraints as every previous pass: no Android SDK/NDK, no
Kotlin/C compiler, no network access to fetch either — so nothing here was
actually built, and nothing was tested against a real ROM on real
hardware. Verification this pass leaned unusually hard on an external
source, though: the core diagnosis (a child GBA never triggers its own SIO
transfer; SIOCNT bits 2/3/4-5/6 have documented, specific meanings) was
cross-checked against GBATEK — the community-maintained GBA hardware
reference — rather than inferred purely from reading this codebase. That
makes the *protocol* reasoning solid, but it's still no substitute for
actually running two phones against a real link-cable game. Recommend
testing with a game known to have a straightforward multiplayer mode (a
simple homebrew link test, if one is available, is easier to reason about
than a full commercial title's menu logic) before assuming this is
completely done.

## Found but deliberately not fixed this pass

- **The child side's own SIOCNT doesn't get the ID/Error bits (4-6) set
  after a transfer** — only the parent's does. Setting them correctly on
  the child would require reading the register's current value first (to
  preserve whatever mode/baud bits its own ROM wrote) before OR-ing in the
  status bits, and this codebase has no confirmed-working raw-register-read
  call yet (only `rawWrite16`, used elsewhere and presumably CI-validated
  given it's unchanged from earlier passes). Guessing at a `rawRead16`
  signature and being wrong would fail the whole build rather than degrade
  gracefully, so this was left alone. The child's bit 2/3 (parent/child,
  ready) status is still correct — that part happens on the child's own
  initial mode-setup write, which it does still make; it's only the
  post-transfer ID/Error bits that aren't mirrored on that side. If a game
  turns out to specifically check its OWN Error bit or re-derive its role
  from its OWN ID bits (as opposed to bit 2, which is now correct) rather
  than just checking bit 2 once up front, this is where to look first.

- **The fifth pass's Wi-Fi out-of-order-packet guard and SIO-exchange-
  holds-the-core-mutex items are unchanged** — see the fifth-pass section
  below, still accurate.

- Everything else in the fifth-pass list below is unchanged and still
  applies (no build/device testing capability in this sandbox, no
  armeabi-v7a/x86 support, no pinned Gradle wrapper checksum, no automated
  tests).

# KNOWN_LIMITATIONS — Fifth pass

## Environment constraints on this pass itself

- **No build was run.** This sandbox has a JDK but no Android SDK, no NDK,
  no Kotlin compiler, and no network access to fetch any of them — so
  `./gradlew assembleDebug` was never actually invoked here. Every change
  was verified by careful manual reading, full brace/paren-balance
  checking across both edited Kotlin files, and cross-referencing every
  new identifier against its declaration and every use site. That is real
  verification, but it is not the same thing as a green CI build, and it
  cannot catch every class of compiler-level error (e.g. a subtle type
  mismatch). Recommend running the normal GitHub Actions workflow on this
  ZIP before relying on it.
- **No device/emulator testing.** Nothing here was exercised on real or
  virtual hardware. This particularly matters for the multiplayer fixes —
  they were reasoned through against the JVM memory model and the existing
  code's own logic, not observed fixing an actual repro.
- **No network access for supply-chain verification.** See the Gradle
  wrapper checksum item below.

## Found but deliberately not fixed this pass

- **Wi-Fi link protocol: only exact-duplicate packets are discarded, not
  full out-of-order sequences.** `wifiExchange()` now discards a packet
  whose `seq` byte exactly repeats the last one accepted, which covers the
  simplest and most common stale-packet case. It does not implement full
  modular sequence-number correlation (comparing a received packet's `seq`
  against what was actually expected for the current round, with wraparound
  handling). Doing that properly requires deciding how the protocol should
  behave after any packet loss causes the two sides' sequence counters to
  drift — a real design question, not just a bug fix, and not something to
  guess at without a way to test against real network conditions.

- **An SIO exchange holds the native core mutex for its full network
  round-trip.** `link_sio_write_register()` runs synchronously inside
  `runFrame()` (already inside `g_core_mutex`) and calls back into Kotlin's
  `jniExchangeData()`, which does a blocking socket operation (up to 30 ms
  for Wi-Fi, 50 ms for Bluetooth) before returning. In the current
  architecture this is safe (verified: everything in the hot path runs
  sequentially on the same game thread, so there's no self-deadlock, and a
  cross-thread caller like `nativeSaveState`/`nativeDestroy` just waits a
  bounded amount of time for the mutex) but it does mean a game that
  performs SIO transfers very frequently could see its effective frame rate
  capped by the network round-trip time during active multiplayer. Fixing
  this properly would mean redesigning the SIO/network interaction to be
  asynchronous — a substantial change that needs real hardware and
  real-game testing to get right, not something to attempt blind in one
  pass.

- **`WifiManager.getConnectionInfo()`/`.dhcpInfo` remain deprecated but
  in use**, already wrapped in `@Suppress("DEPRECATION")` from an earlier
  pass. A modern replacement exists (`ConnectivityManager` +
  `LinkProperties`, both available since well below this project's
  minSdk 24) but this exact code path has already been root-caused and
  fixed multiple times across prior passes (per `README_SETUP.md`), and a
  rewrite can't be validated against real Wi-Fi hardware in this
  environment. Left as-is rather than risk regressing a working,
  hard-won fix.

- **Gradle wrapper has no pinned `distributionSha256Sum`.** Adding one is
  good supply-chain practice, but doing it correctly requires the real
  published checksum for `gradle-8.6-bin.zip` from Gradle's own
  release-checksums page — this sandbox has no network access to fetch it,
  and a guessed/incorrect value would hard-fail every build. Recommend
  pulling the real value from `https://gradle.org/release-checksums/` and
  adding it directly.

- **No armeabi-v7a/x86/x86_64 ABI support** (arm64-v8a only). Reasonable
  given `minSdk 24` — 32-bit-ARM-only devices are effectively extinct at
  that API level — but noted here for completeness since it wasn't changed
  or re-evaluated this pass.

- **No automated tests exist for the multiplayer fixes made this pass** (or
  for the codebase generally). The fixes were verified by reasoning through
  the JVM memory model and the existing control flow, not by a test that
  could catch a future regression. Adding instrumented/unit test coverage
  for `LinkMultiplayer.kt` would be a reasonable next investment, especially
  given how much of this pass's value was in exactly this file.

## Not revisited this pass (out of scope, not found broken)

`MainActivity.kt`'s touch-handling, control-layout editor, and rendering
code were read but intentionally not modified — nothing broken was found,
and this code implements the exact visual "outline skin" the brief asked
to preserve unchanged. Audio/render pipeline internals were the subject of
two previous dedicated passes and were only re-read here to confirm this
pass's changes don't interact with them, not re-audited from scratch.
