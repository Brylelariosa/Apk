# FILE_CHANGES — Seventh pass

## Modified

### `app/src/main/cpp/mgba_jni.c`
**Why:** User re-tested the sixth pass's fix against Yu-Gi-Oh! World
Championship 2006 and The Legend of Zelda: Four Swords — still not
working, plus a new diagnostic detail: fast-forward stays available
during an active "Connected" session, which real hardware/mGBA proper
doesn't allow.
**What changed:** Two calls to `GBARaiseIRQ(g_link_gba, GBA_IRQ_SIO, 0)`
added — one in `link_sio_write_register()`'s Start-bit/exchange branch
(host path), one in `nativeLinkChildExchange()` (child path) — each right
after that side finishes writing SIOMULTI0-3 for the round. Also updated
the now-stale FIX 8 comment that had said raising this IRQ was an
unaddressed gap, since FIX 10 (this pass) addresses it.
**Expected benefit:** Any GBA multiplayer ROM using the standard
interrupt-driven wait (BIOS `IntrWait`/`VBlankIntrWait` on the serial
interrupt, rather than busy-polling SIOCNT) should now actually wake up
and see the transfer the sixth pass's fixes correctly deliver, instead of
sleeping forever waiting for an interrupt that was never coming. Also
explains (without requiring any change to) the fast-forward observation:
a stalled, interrupt-sleeping ROM isn't re-hitting the Start bit every
frame, so fast-forward had nothing left to throttle it against.
**Verification:** Confirmed the exact call/constant name
(`GBARaiseIRQ`/`GBA_IRQ_SIO`) by reading mGBA's real `src/gba/sio.c` this
pass, not from memory — see the `FIX 10` comment block at the top of the
file for the citation, and `KNOWN_LIMITATIONS.md` for what that
verification does and doesn't cover (real source, but not a build log
against this project's exact pinned tag).

## Not modified

`LinkMultiplayer.kt`, `MainActivity.kt`, `EmulatorEngine.kt`, and every
build/config file were not touched this pass — this pass was scoped
tightly to the one root cause found, per the reported symptom.

---

# FILE_CHANGES — Sixth pass

## Modified

### `app/src/main/cpp/mgba_jni.c`
**Why:** User report: "Connected" shows in the app but the ROM's own link
menu never progresses, and a peer disconnecting isn't noticed. The fifth
pass's `FILE_CHANGES.md` explicitly says this file was "read in full... no
changes made or needed" — this pass found that assessment was looking for
memory-safety/mutex issues (which is genuinely fine) rather than SIO
protocol correctness against GBATEK, which is where the actual bug was.
**What changed:** `link_sio_write_register()` now reflects SIOCNT's
parent/child (bit 2) and all-ready (bit 3) status on every write, and sets
the ID (bits 4-5) and Error (bit 6) bits correctly after a transfer — all
four were previously never touched. Added `nativeLinkChildExchange()`, a
new JNI entry point a child device's Kotlin-side listener threads call the
instant a request arrives over the network, since a real GBA child never
triggers its own transfer (see `BUGS_FIXED.md` for the full explanation).
**Expected benefit:** This is the fix that should actually let two phones
get a ROM past its own "waiting for link" screen, rather than just the
app-level socket handshake succeeding.

### `app/src/main/kotlin/com/mgba/android/EmulatorEngine.kt`
**Why:** Kotlin-side declaration for the new native entry point above.
**What changed:** Added `external fun nativeLinkChildExchange(hostData: Int): Int`.
**Expected benefit:** N/A (declaration only).

### `app/src/main/kotlin/com/mgba/android/LinkMultiplayer.kt`
**Why:** Same report as above, plus: "if I disconnect on other phone the
other phone doesn't detect that and say still connected."
**What changed:** New `startWifiChildResponder()` thread (Wi-Fi child role)
and a new child-mode branch inside the existing `startBtReader()`
(Bluetooth child role), both calling `nativeLinkChildExchange()`; a BYE
packet sent best-effort at the top of `disconnect()`; a liveness watchdog
(`lastPeerActivityMs` / `PEER_TIMEOUT_MS`) checked inside `startKeepalive()`
which now also runs for Bluetooth (previously Wi-Fi only) and sends BT
keepalive traffic too; new `onPeerLost` callback; `wifiExchange()`/
`btExchange()` now recognize an explicit BYE instead of treating it as
generically-bad data. See `BUGS_FIXED.md` for the full list.
**Expected benefit:** Multiplayer should actually reach the ROM; a peer
disconnecting (intentionally or otherwise) should now be reflected in the
UI within a couple of seconds instead of never.

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** Needs to react when `LinkMultiplayer` detects the peer is gone —
previously there was no such signal to react to.
**What changed:** One line wiring `link.onPeerLost` to the same UI update
`stopLink()` already does (reset the link button, toast), right after
`link` is constructed.
**Expected benefit:** "Connected" no longer lies indefinitely after the
other phone actually leaves.

## Added

- Sixth-pass sections prepended to `BUGS_FIXED.md`, `KNOWN_LIMITATIONS.md`,
  and this file, following the project's existing per-pass convention.

## Deleted

None.

## Reviewed and deliberately left unchanged

- **Everything the fifth pass already reviewed** (`CMakeLists.txt`,
  `proguard-rules.pro`, Gradle files, the manifest) — not re-audited from
  scratch this pass; nothing in this pass's changes touches any of them.

# FILE_CHANGES — Fifth pass

## Modified

### `app/src/main/kotlin/com/mgba/android/LinkMultiplayer.kt`
**Why:** Dedicated review of the multiplayer/link-cable subsystem, which
hadn't had one yet across the previous four passes.
**What changed:** `@Volatile` added to six connection-state fields; a
`discSocket` field that existed but was never assigned is now actually
used; a `connectGeneration` token and `btPendingSocket` tracking added
across all four connect paths and `disconnect()`; the Wi-Fi `DATA` packet's
`seq` byte is now validated on receive instead of only being populated on
send. See `CHANGELOG.md` items 1–4 for full detail.
**Expected benefit:** More reliable multiplayer connection setup, teardown,
and reconnect handling; a documented-but-previously-nonfunctional packet
check now actually works.

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** General review pass plus fixing the cross-cutting issue where a
native-side ROM swap could silently leave the Kotlin-side link state
inconsistent.
**What changed:** ROM load/change now disconnects an active link session
first; the ROM-load completion callback now checks `isFinishing`/
`isDestroyed`; added `backupIfExists()` and wired it into both the battery
-save and save-state-slot write paths; added an opt-in performance overlay
(state fields, game-loop counter, draw function, and a Misc-settings
checkbox). See `CHANGELOG.md` items 5–8.
**Expected benefit:** Consistent link/ROM state, one fewer lifecycle edge
case, a data-safety net, and an optional diagnostic overlay — all without
any visible change to the existing UI unless the new overlay is explicitly
turned on.

### `app/src/main/AndroidManifest.xml`
**Why:** Two declared permissions were confirmed (via grep across the
whole `kotlin/` tree) to be unused.
**What changed:** Removed `READ_EXTERNAL_STORAGE` and `BLUETOOTH_SCAN`,
each with a comment explaining why.
**Expected benefit:** Smaller permission footprint; no functional change,
since neither was ever checked or relied upon.

### `gradle.properties`
**Why:** `android.enableJetifier` was verified to be dead weight given the
current dependency list.
**What changed:** `android.enableJetifier=true` → `false`, with a comment
explaining the reasoning and when to revert it.
**Expected benefit:** Marginally faster builds.

### `README_SETUP.md`
**Why:** The project's own convention (see its "Fixes applied vs the
original" / "Second/Third/Fourth pass" sections) is to document each
review pass in place.
**What changed:** Appended a "Fifth pass" section following the same
format, plus a note (not a retroactive edit) flagging that the original
table's pthread-linking entry no longer matches the current
`CMakeLists.txt`.
**Expected benefit:** Keeps the project's own change history complete and
consistent for whoever reads it next (including a future review pass).

## Added

- `CHANGELOG.md`, `REVIEW_REPORT.md`, `FILE_CHANGES.md` (this file),
  `FEATURES_ADDED.md`, `BUGS_FIXED.md`, `KNOWN_LIMITATIONS.md` — the
  documentation deliverables for this pass.

## Deleted

None.

## Reviewed and deliberately left unchanged

- **`app/src/main/kotlin/com/mgba/android/EmulatorEngine.kt`** — read in
  full; a clean, minimal JNI facade with no issues found.
- **`app/src/main/cpp/mgba_jni.c`** — read in full (all 731 lines). Every
  entry point already correctly guards `g_core`/`g_fb` behind
  `g_core_mutex` with proper NULL-after-destroy checking, including the
  ROM-swap path. No changes made or needed.
- **`app/src/main/cpp/CMakeLists.txt`** — read in full; the pthread-linking
  decision (intentionally *not* linking `-lpthread`) is correct and already
  well-commented for NDK r18+. No changes made.
- **`app/proguard-rules.pro`** — already correctly protects
  `jniExchangeData` (the one method a native `GetMethodID` lookup depends
  on by exact name) from R8 renaming. No changes needed.
- **`app/build.gradle.kts`, `settings.gradle.kts`,
  `gradle/wrapper/gradle-wrapper.properties`** — reviewed; no functional
  issues found. See `KNOWN_LIMITATIONS.md` for one supply-chain
  recommendation (a pinned wrapper checksum) that wasn't made because this
  sandbox has no network access to fetch the real value.
