package com.novacompress.ai.di

import android.content.Context
import com.novacompress.ai.core.evolution.EvolutionEngine
import com.novacompress.ai.core.service.CompressionService
import com.novacompress.ai.core.service.DecompressionService
import com.novacompress.ai.data.database.NovaDatabase
import com.novacompress.ai.data.repository.CompressionRepository
import com.novacompress.ai.data.repository.EvolutionStatsRepository
import com.novacompress.ai.data.repository.RoomGenomeRepository

/**
 * Minimal hand-rolled dependency container for Phase 1/2. The spec allows
 * Hilt "only when necessary" - this handful of singletons wired up in one
 * place doesn't yet justify the extra KSP/annotation-processor surface
 * area, so this stays plain until a later phase's dependency graph
 * actually needs it (e.g. WorkManager worker injection).
 */
class ServiceLocator(context: Context) {
    private val database: NovaDatabase = NovaDatabase.getInstance(context)
    private val genomeRepository = RoomGenomeRepository(database.genomeDao(), database.benchmarkRecordDao())
    private val evolutionEngine = EvolutionEngine(genomeRepository)

    val repository: CompressionRepository = CompressionRepository(database.compressionRecordDao())
    val evolutionStatsRepository = EvolutionStatsRepository(database.genomeDao(), database.benchmarkRecordDao())
    val compressionService: CompressionService = CompressionService(evolutionEngine = evolutionEngine)
    val decompressionService: DecompressionService = DecompressionService()
}
