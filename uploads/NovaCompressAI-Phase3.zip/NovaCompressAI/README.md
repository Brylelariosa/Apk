# NovaCompress AI — Phase 1 + 2 + 3

This covers **Phases 1-3** of NovaCompress AI: the core compression engine,
a genuinely working genome Evolution Engine + Benchmark Laboratory, three
more compression plugins (including a properly-built Burrows-Wheeler
Transform), and a Research Lab UI with a live Genome Explorer and an
Archive Inspector. It is not the whole spec — see
[PROGRESS.md](PROGRESS.md) for what's here vs. what's next.

## What actually works right now

- **Eight real, lossless compression plugins**: Delta Encoding, Run-Length
  Encoding (PackBits-style), canonical Huffman coding, LZ77 (LZSS-style
  with hash-chain matching), Move-To-Front, Burrows-Wheeler Transform
  (suffix array via prefix-doubling, no sentinel byte needed - cross
  validated byte-for-byte against a brute-force reference implementation),
  Arithmetic Coding (Witten-Neal-Cleary, stress-tested across 300 random
  configurations), and Predictive Coding (second-order linear predictor).
  Every plugin was first prototyped and round-trip-tested in Python before
  being ported to Kotlin, to catch algorithmic bugs before they became
  Kotlin bugs.
- **Seven genome presets**: Balanced, Maximum Compression, Fast, Battery
  Saver, Block Sorting (bzip2-style BWT+MTF+RLE+Huffman), Research Mode
  (BWT+MTF+Arithmetic), and Signal Optimized (Predictive+RLE+Huffman).
- **A real pipeline engine** that chains plugins in sequence and reverses
  them correctly for decompression - and correctly rejects invalid
  pipelines (empty, over the stage limit, unknown plugin, or duplicate
  plugins), per the spec's pipeline validation rules.
- **A real, chunked, streaming `.nova` archive format** — magic header,
  self-describing metadata, per-chunk SHA-256, and a whole-file SHA-256
  footer. Reading is fully verified: any corrupted byte, truncated file, or
  hash mismatch is caught and reported, never silently ignored.
- **A real Verification Engine**: every chunk is compressed, decompressed,
  and compared byte-for-byte (plus an independent SHA-256 check) *before*
  its compressed bytes are ever written to the archive.
- **A real Benchmark Laboratory**: every candidate genome is actually
  compressed, decompressed, timed with `System.nanoTime()`, and verified
  against the real file — never an estimate.
- **A real Evolution Engine**: mutation (insert/delete/swap/replace) and
  crossover (single-point recombination), both guaranteed to produce
  structurally valid, duplicate-free pipelines. Every compression job
  benchmarks the best known genomes plus fresh mutated/crossed candidates,
  records *every* result as permanent knowledge, and picks the genuinely
  measured winner - not a guess.
- **A growing Knowledge Database**: genomes carry generation, species,
  lifecycle status, and parent lineage; every benchmark experiment is
  permanently recorded, win or lose.
- **Archive Inspector**: reads a `.nova` file's metadata (original name,
  size, pipeline, chunk count) without decompressing or verifying a single
  chunk - fast, read-only inspection of a possibly-large archive.
- **A working Compose UI**, five screens: Dashboard (stats + recent
  activity + live genome/benchmark counts), Compress (file picker →
  analysis → evolved & verified compression → result with a real
  explanation), Decompress (file picker → Inspect or Decompress, both
  fully wired), Research Lab (species breakdown chart + Genome Explorer),
  and Settings.
- **67 JUnit test methods**, including a from-scratch brute-force BWT
  reference implementation used only for cross-validation in tests, and a
  150-configuration arithmetic-coding stress test.

## What's deliberately not here yet

Thermal/battery-aware background research scheduling (WorkManager),
checkpointing/resume for interrupted jobs, Hilt, the full Plugin SDK,
multi-file archives, "Bit Packing" as its own plugin, the "share to
compress" / "open .nova" external intents, and the spec's more elaborate
visualizations (AI Brain Visualization, Mutation Timeline, zoomable
interactive charts). These are staged into later phases — see
PROGRESS.md.

## About the Gradle Wrapper

The build environment for this project is GitHub Actions, per the project's
own build instructions. The sandbox this project was generated in has **no
network access and no local Gradle/Android SDK/Kotlin compiler** — so a
`gradle-wrapper.jar` binary (normally produced by running `gradle wrapper`
against a real Gradle install) could not be generated or verified here.

Rather than commit a guessed-at binary that might be silently wrong, the
CI workflow (`.github/workflows/android-ci.yml`) installs a real Gradle
distribution first and runs `gradle wrapper --gradle-version 8.6` as its
first step, regenerating `gradlew`, `gradlew.bat`, and `gradle-wrapper.jar`
before anything else runs. This is a standard, well-known pattern and means
CI never depends on a wrapper jar that was never actually executed.

If you clone this locally and want to run `./gradlew` directly, you'll need
to run `gradle wrapper --gradle-version 8.6` yourself once (with any Gradle
8.x install), or just use your own `gradle` command directly.

## Verified version matrix

Every version below was cross-checked (not assumed) against current
compatibility tables before being pinned:

| Component | Version |
|---|---|
| Gradle | 8.6 (per the project's own pinned target) |
| Android Gradle Plugin | 8.4.0 |
| Kotlin | 1.9.24 |
| Compose Compiler extension | 1.5.14 |
| KSP | 1.9.24-1.0.20 |
| compileSdk / targetSdk | 34 |
| minSdk | 26 (Android 8.0) |

Note: as of mid-2026 the ecosystem has moved on to Gradle 9.x / AGP 9.x
(which changes Kotlin integration significantly). This project deliberately
stays on the version matrix the project's own build spec pinned (Gradle
8.6, NDK 25.x, CMake 3.22.1) rather than jumping to the newer major
versions; upgrading is a reasonable future task if you'd rather ride the
current tooling.

## Building

Push to GitHub and let `.github/workflows/android-ci.yml` build it, or
locally:

```bash
gradle wrapper --gradle-version 8.6   # one-time, if gradlew isn't already valid
./gradlew testDebugUnitTest           # run the 67 unit tests
./gradlew assembleDebug               # produce app/build/outputs/apk/debug/app-debug.apk
```

## Project layout

```
app/src/main/java/com/novacompress/ai/
  core/
    analyzer/     FileAnalyzer, FeatureVector
    plugins/      8 CompressionPlugin implementations + PluginRegistry
    pipeline/     PipelineDescriptor, CompressionPipeline
    genome/       CompressionGenome, GenomeStatus, GenomePresets, GenomeSelector
    verification/ VerificationEngine
    archive/      NovaArchiveWriter/Reader/Inspector, ArchiveMetadata, format constants
    benchmark/    BenchmarkLaboratory, BenchmarkResult, FitnessCalculator
    evolution/    EvolutionEngine, MutationEngine, CrossoverEngine, GenomeRepository (interface)
    service/      CompressionService, DecompressionService (orchestration)
    common/       Constants, EngineResult, BinaryIO, ByteCursor
  data/           Room database (compression history + genomes + benchmarks), DAOs, repositories
  di/             ServiceLocator + ViewModel factory (no Hilt yet, see below)
  ui/             Compose screens + ViewModels (dashboard/compress/decompress/research/settings)
app/src/test/java/com/novacompress/ai/   67 JUnit tests mirroring the above
```

## Notable engineering decisions

- **BWT without a sentinel byte.** Since every byte value 0-255 is already
  valid input, there's no spare value to use as a rotation-boundary marker
  (the textbook BWT construction usually assumes one). Built via a suffix
  array of the cyclic rotations instead (prefix-doubling over rank arrays,
  comparing `(rank[i], rank[(i+k) mod n])` each round) - and specifically
  cross-validated byte-for-byte against a brute-force "generate every
  rotation, sort them" reference implementation before trusting the fast
  version, since getting this wrong silently (producing *a* valid
  permutation that isn't the *intended* one) is exactly the kind of bug
  that would only show up as slightly worse compression, not a crash.
- **Arithmetic coding uses `Long` throughout**, not `Int`: the interval
  arithmetic's intermediate products (`range * cumulativeFrequency`) reach
  roughly 2^50 for realistic chunk sizes, which silently overflows a 32-bit
  `Int` without throwing.
- **No Hilt yet.** A handful of hand-wired singletons doesn't justify the
  KSP/annotation-processor surface area yet; `ServiceLocator` is a plain
  Kotlin class. Hilt is a sensible addition once WorkManager workers need
  injection (Phase 4).
- **No JSON library for archive metadata.** `org.json` (Android's built-in
  JSON classes) throws `RuntimeException: not mocked` in plain JVM unit
  tests unless a second, real implementation is added as a test dependency
  — a well-known Android testing gotcha. Archive metadata instead uses
  simple length-prefixed fields, which are just as self-describing and
  behave identically in tests and production.
- **`GenomeRepository` is an interface** specifically so `EvolutionEngine`'s
  mutation/crossover/selection logic can be unit tested against an
  in-memory fake instead of requiring Room's real SQLite backing, which
  doesn't work in plain JVM unit tests without adding Robolectric.
- **The Research Lab's chart is proportional Compose boxes, not a Canvas
  draw or a charting library.** Simple, dependency-free, and correct;
  upgrading to a real interactive chart is a reasonable Phase 7 task once
  there's enough benchmark history to make zoom/pan worth having.
- **R8/minification is off for release builds** for now. Enabling it
  safely needs keep rules for Room and the plugin registry; that's staged
  for when release signing is actually set up.
- **Files are saved to app-scoped external storage**
  (`getExternalFilesDir()`), not a user-chosen SAF destination, so no
  storage permissions are needed yet.
