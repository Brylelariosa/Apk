package com.torrix.app.engine

/**
 * The only native entry point. Every request is `method` + JSON arguments and
 * every answer is a JSON envelope, see rust-engine/src/lib.rs (`call`).
 */
object NativeBridge {
    init {
        System.loadLibrary("torrix_engine")
    }

    @JvmStatic
    external fun nativeCall(method: String, argsJson: String): String?
}
