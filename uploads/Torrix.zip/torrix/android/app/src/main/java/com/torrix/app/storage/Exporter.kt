package com.torrix.app.storage

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.SystemClock
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream

/**
 * Copies a finished download from app storage to its final home, streaming in
 * 256 KiB blocks (nothing is ever held in memory), and never needs a storage
 * permission:
 *  - Downloads/Torrix through MediaStore (works on Android 11+ without permissions)
 *  - any folder the user picked with the Storage Access Framework
 */
class Exporter(private val ctx: Context) {

    data class FileSpec(val rel: String, val length: Long)

    data class ExportResult(val location: String, val uri: String?, val mime: String?, val bytes: Long)

    private interface Sink {
        val label: String
        suspend fun write(parts: List<String>, mime: String, src: File, onBytes: (Long) -> Unit): Uri
    }

    suspend fun export(
        root: File,
        files: List<FileSpec>,
        mode: SaveMode,
        treeUri: String?,
        onProgress: (copied: Long, total: Long) -> Unit,
    ): ExportResult = withContext(Dispatchers.IO) {
        val rootCanon = root.canonicalFile
        val usable = files.mapNotNull { spec ->
            if (!isSafeRelative(spec.rel)) return@mapNotNull null
            val src = File(rootCanon, spec.rel).canonicalFile
            // Names come from torrent metadata: never trust them to stay inside the folder.
            if (!src.path.startsWith(rootCanon.path + File.separator) || !src.isFile) {
                return@mapNotNull null
            }
            spec to src
        }
        if (usable.isEmpty()) throw IOException("The downloaded files could not be found.")
        val total = usable.sumOf { it.second.length() }

        val sink: Sink = when (mode) {
            SaveMode.PUBLIC_DOWNLOADS -> MediaStoreSink()
            SaveMode.CUSTOM_FOLDER -> {
                val uri = treeUri ?: throw IOException("No save folder has been chosen.")
                TreeSink(Uri.parse(uri))
            }
            SaveMode.APP_ONLY -> throw IOException("Saving to another location is switched off.")
        }

        var copied = 0L
        var lastReport = 0L
        var lastUri: Uri? = null
        var lastMime: String? = null
        for ((spec, src) in usable) {
            val parts = spec.rel.split('/').map { cleanComponent(it) }
            val mime = mimeOf(parts.last())
            val base = copied
            lastUri = sink.write(parts, mime, src) { n ->
                copied = base + n
                val now = SystemClock.elapsedRealtime()
                if (now - lastReport >= 250L) {
                    lastReport = now
                    onProgress(copied, total)
                }
            }
            copied = base + src.length()
            lastMime = mime
        }
        onProgress(total, total)
        val single = usable.size == 1
        ExportResult(
            location = sink.label,
            uri = if (single) lastUri?.toString() else null,
            mime = if (single) lastMime else null,
            bytes = total,
        )
    }

    private suspend fun copy(input: InputStream, output: OutputStream, onBytes: (Long) -> Unit) {
        val job = currentCoroutineContext()[Job]
        val buf = ByteArray(256 * 1024)
        var done = 0L
        while (true) {
            val n = input.read(buf)
            if (n < 0) break
            output.write(buf, 0, n)
            done += n
            onBytes(done)
            job?.ensureActive()
        }
        output.flush()
    }

    private inner class MediaStoreSink : Sink {
        override val label = "Downloads/Torrix"

        override suspend fun write(
            parts: List<String>,
            mime: String,
            src: File,
            onBytes: (Long) -> Unit,
        ): Uri {
            val name = parts.last()
            val dirs = parts.dropLast(1)
            val subdir = if (dirs.isEmpty()) "" else dirs.joinToString("/") + "/"
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/Torrix/$subdir")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val resolver = ctx.contentResolver
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IOException("Could not create \"$name\" in Downloads.")
            try {
                val out = resolver.openOutputStream(uri, "w")
                    ?: throw IOException("Could not write \"$name\".")
                out.use { o -> src.inputStream().use { i -> copy(i, o, onBytes) } }
                val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                resolver.update(uri, done, null, null)
                return uri
            } catch (t: Throwable) {
                runCatching { resolver.delete(uri, null, null) }
                throw t
            }
        }
    }

    private inner class TreeSink(treeUri: Uri) : Sink {
        private val root: DocumentFile = DocumentFile.fromTreeUri(ctx, treeUri)
            ?: throw IOException("The chosen folder is not available any more.")
        private val dirs = HashMap<String, DocumentFile>()

        override val label: String = root.name ?: "the chosen folder"

        init {
            if (!root.exists() || !root.canWrite()) {
                throw IOException("Torrix can no longer write to the chosen folder. Pick it again in Settings.")
            }
        }

        private fun dir(path: String): DocumentFile {
            if (path.isEmpty()) return root
            dirs[path]?.let { return it }
            val parent = dir(path.substringBeforeLast('/', ""))
            val name = path.substringAfterLast('/')
            val found = parent.findFile(name)
            val d = if (found != null && found.isDirectory) {
                found
            } else {
                parent.createDirectory(name) ?: throw IOException("Could not create the folder \"$name\".")
            }
            dirs[path] = d
            return d
        }

        override suspend fun write(
            parts: List<String>,
            mime: String,
            src: File,
            onBytes: (Long) -> Unit,
        ): Uri {
            val parent = dir(parts.dropLast(1).joinToString("/"))
            val name = parts.last()
            val doc = parent.createFile(mime, name)
                ?: throw IOException("Could not create \"$name\" in the chosen folder.")
            try {
                val out = ctx.contentResolver.openOutputStream(doc.uri, "w")
                    ?: throw IOException("Could not write \"$name\".")
                out.use { o -> src.inputStream().use { i -> copy(i, o, onBytes) } }
                return doc.uri
            } catch (t: Throwable) {
                runCatching { doc.delete() }
                throw t
            }
        }
    }

    companion object {
        /** Same rules as rust-engine/src/storage.rs `is_safe_relative_path`. */
        fun isSafeRelative(p: String): Boolean {
            if (p.isEmpty() || p.length > 4096 || p.startsWith("/") ||
                p.contains('\u0000') || p.contains('\\')
            ) return false
            return p.split('/').all { it.isNotEmpty() && it != "." && it != ".." }
        }

        fun cleanComponent(raw: String): String {
            val s = buildString {
                for (c in raw) append(if (c.isISOControl() || c in "<>:\"|?*\\/") '_' else c)
            }.trim()
            return if (s.isEmpty() || s == "." || s == "..") "_" else s.take(200)
        }

        fun mimeOf(name: String): String {
            val ext = name.substringAfterLast('.', "").lowercase()
            return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
                ?: "application/octet-stream"
        }
    }
}
