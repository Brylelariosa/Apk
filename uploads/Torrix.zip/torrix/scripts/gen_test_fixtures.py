"""Generates the .torrent fixtures embedded in rust-engine/src/torrent.rs (module `fixtures`).

They are built here with Python's hashlib so the Rust parser is checked against an independent
implementation. Run: python3 scripts/gen_test_fixtures.py
"""
import hashlib

def benc(v):
    if isinstance(v, int):
        return b"i%de" % v
    if isinstance(v, bytes):
        return b"%d:" % len(v) + v
    if isinstance(v, str):
        return benc(v.encode())
    if isinstance(v, list):
        return b"l" + b"".join(benc(x) for x in v) + b"e"
    if isinstance(v, dict):
        out = b"d"
        for k in sorted(k.encode() if isinstance(k, str) else k for k in v):
            key = k.decode()
            out += benc(k) + benc(v[key])
        return out + b"e"
    raise TypeError(type(v))

def pieces_of(data, plen):
    return b"".join(hashlib.sha1(data[i:i+plen]).digest() for i in range(0, len(data), plen))

def rust_bytes(b):
    out = []
    for c in b:
        if 0x20 <= c < 0x7f and chr(c) not in '"\\':
            out.append(chr(c))
        else:
            out.append("\\x%02x" % c)
    return 'b"' + "".join(out) + '"'

# 1) single-file torrent, 40 bytes of content, 16-byte pieces (16,16,8)
content = b"0123456789abcdefghijklmnopqrstuvwxyzABCD"
assert len(content) == 40
info1 = {"length": 40, "name": "hello.txt", "piece length": 16, "pieces": pieces_of(content, 16)}
t1 = {"announce": "udp://tracker.example.org:6969/announce",
      "announce-list": [["udp://tracker.example.org:6969/announce"], ["https://t2.example.net/announce", "ftp://ignored.example/x"]],
      "comment": "Torrix test fixture",
      "info": info1}
b1 = benc(t1)
h1 = hashlib.sha1(benc(info1)).hexdigest()

# 2) multi-file torrent, content = "aaaaa" + "bbbbbbb" (12 bytes), 4-byte pieces
c2 = b"aaaaa" + b"bbbbbbb"
info2 = {"files": [{"length": 5, "path": ["cd1", "a.flac"]}, {"length": 7, "path": ["b.txt"]}],
         "name": "album", "piece length": 4, "pieces": pieces_of(c2, 4), "private": 1}
t2 = {"announce": "http://tracker.example.com/announce", "info": info2}
b2 = benc(t2)
h2 = hashlib.sha1(benc(info2)).hexdigest()

print("    pub const SINGLE_CONTENT: &[u8] = %s;" % rust_bytes(content))
print("    pub const SINGLE_TORRENT: &[u8] = %s;" % rust_bytes(b1))
print('    pub const SINGLE_INFO_HASH: &str = "%s";' % h1)
print("    pub const MULTI_CONTENT: &[u8] = %s;" % rust_bytes(c2))
print("    pub const MULTI_TORRENT: &[u8] = %s;" % rust_bytes(b2))
print('    pub const MULTI_INFO_HASH: &str = "%s";' % h2)
