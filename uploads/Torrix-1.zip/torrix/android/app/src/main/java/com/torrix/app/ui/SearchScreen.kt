package com.torrix.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.torrix.app.engine.Fmt
import com.torrix.app.engine.SearchResultItem

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(vm: MainViewModel, modifier: Modifier = Modifier) {
    val ui by vm.search.collectAsStateWithLifecycle()
    val selected by vm.selectedResult.collectAsStateWithLifecycle()
    var query by rememberSaveable { mutableStateOf(ui.query) }
    val focus = LocalFocusManager.current

    fun go() {
        focus.clearFocus()
        vm.runSearch(query)
    }

    Column(modifier.fillMaxSize()) {
        Column(
            Modifier.padding(start = 16.dp, top = 16.dp, end = 16.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            Text("Search", style = MaterialTheme.typography.titleLarge)
            Text(
                "Looks in sources that publish legal torrents: Linux distributions, the Internet Archive, and an indexer you add yourself.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("What are you looking for?") },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { go() }),
                trailingIcon = {
                    IconButton(onClick = { go() }) {
                        Icon(Icons.Filled.Search, contentDescription = "Search")
                    }
                },
            )
        }

        val error = ui.error
        when {
            ui.loading -> Row(
                Modifier.fillMaxWidth().padding(24.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                Text("Searching", style = MaterialTheme.typography.bodyMedium)
            }
            error != null -> EmptyState("Could not search", error, Modifier.padding(horizontal = 4.dp))
            !ui.searched -> EmptyState(
                "Find something to download",
                "Try a distribution name such as \"debian\", or a title from the public-domain collections.",
                Modifier.padding(horizontal = 4.dp),
            )
            else -> {
                val failed = ui.providers.filter { !it.ok }
                LazyColumn(
                    contentPadding = PaddingValues(start = 16.dp, top = 12.dp, end = 16.dp, bottom = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    if (failed.isNotEmpty()) {
                        item(key = "providers") {
                            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    for (p in failed) {
                                        Text(
                                            "${p.name} is unavailable: ${p.error ?: "no answer"}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                                        )
                                    }
                                }
                            }
                        }
                    }
                    if (ui.results.isEmpty()) {
                        item(key = "none") {
                            EmptyState("No results", "Nothing matched. Try fewer or different words.")
                        }
                    }
                    // Index keys: indexers can return the same hash more than once.
                    itemsIndexed(ui.results, key = { index, _ -> index }) { _, r ->
                        ResultRow(r, onClick = { vm.selectedResult.value = r })
                    }
                }
            }
        }
    }

    selected?.let { r -> ResultSheet(vm, r) }
}

@Composable
private fun ResultRow(r: SearchResultItem, onClick: () -> Unit) {
    val shape = MaterialTheme.shapes.medium
    Card(
        modifier = Modifier.fillMaxWidth().clip(shape).clickable(onClick = onClick),
        shape = shape,
        colors = flatCardColors(),
        border = flatBorder(),
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(r.title, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(
                resultMeta(r),
                style = MaterialTheme.typography.bodySmall.merge(NumberStyle),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

private fun resultMeta(r: SearchResultItem): String {
    val parts = ArrayList<String>()
    parts.add(r.provider)
    r.category?.let { parts.add(it) }
    r.sizeBytes?.let { parts.add(Fmt.bytes(it)) }
    r.seeders?.let { parts.add("$it seeders") }
    return parts.joinToString(" · ")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ResultSheet(vm: MainViewModel, r: SearchResultItem) {
    val clipboard = LocalClipboardManager.current
    ModalBottomSheet(
        onDismissRequest = { vm.selectedResult.value = null },
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
    ) {
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 16.dp).navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text(r.title, style = MaterialTheme.typography.titleLarge, maxLines = 4, overflow = TextOverflow.Ellipsis)
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                DetailLine("Source", r.provider)
                r.category?.let { DetailLine("Category", it) }
                r.sizeBytes?.let { DetailLine("Size", Fmt.bytes(it)) }
                if (r.seeders != null) DetailLine("Seeders", "${r.seeders}" + (r.leechers?.let { ", $it leechers" } ?: ""))
                r.published?.let { DetailLine("Published", it) }
                r.infoHash?.let { DetailLine("Info hash", it) }
            }
            Button(
                onClick = { vm.downloadResult(r) },
                enabled = r.source != null,
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Download") }
            if (r.magnet != null) {
                OutlinedButton(
                    onClick = {
                        clipboard.setText(AnnotatedString(r.magnet))
                        vm.say("Magnet link copied")
                    },
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Icon(TorrixIcons.Copy, contentDescription = null, modifier = Modifier.size(18.dp))
                    Text("  Copy magnet link")
                }
            }
            if (r.torrentUrl != null) {
                OutlinedButton(
                    onClick = {
                        clipboard.setText(AnnotatedString(r.torrentUrl))
                        vm.say(".torrent address copied")
                    },
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Icon(TorrixIcons.Copy, contentDescription = null, modifier = Modifier.size(18.dp))
                    Text("  Copy .torrent address")
                }
            }
            Text(
                "Only download content you have the right to download.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun DetailLine(label: String, value: String) {
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(end = 2.dp),
        )
        Text(value, style = MaterialTheme.typography.bodySmall.merge(NumberStyle), maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}
