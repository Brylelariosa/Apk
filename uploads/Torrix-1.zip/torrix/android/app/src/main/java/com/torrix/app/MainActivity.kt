package com.torrix.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import com.torrix.app.ui.MainViewModel
import com.torrix.app.ui.TorrixRoot

class MainActivity : ComponentActivity() {

    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)

        setContent {
            val folderPicker = rememberLauncherForActivityResult(
                ActivityResultContracts.OpenDocumentTree(),
            ) { uri: Uri? -> if (uri != null) vm.onTreePicked(uri) }

            val torrentPicker = rememberLauncherForActivityResult(
                ActivityResultContracts.OpenDocument(),
            ) { uri: Uri? -> if (uri != null) vm.beginAddFile(uri) }

            TorrixRoot(
                vm = vm,
                onPickFolder = { folderPicker.launch(null) },
                onPickTorrent = { torrentPicker.launch(arrayOf("*/*")) },
                onBatterySettings = { openBatterySettings() },
            )
        }

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
                .launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        // A cold start from a magnet link or a .torrent file. After a rotation or
        // process restore the intent is delivered again, so only handle fresh launches.
        if (savedInstanceState == null) handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onStart() {
        super.onStart()
        (application as TorrixApp).engine.setUiVisible(true)
    }

    override fun onStop() {
        (application as TorrixApp).engine.setUiVisible(false)
        super.onStop()
    }

    private fun handleIntent(intent: Intent?) {
        if (intent == null || intent.action != Intent.ACTION_VIEW) return
        val data = intent.data ?: return
        if (data.scheme.equals("magnet", ignoreCase = true)) {
            vm.beginAdd(data.toString())
        } else {
            vm.beginAddFile(data)
        }
    }

    private fun openBatterySettings() {
        try {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        } catch (_: Exception) {
            vm.say("Open Android Settings, then Apps, then Torrix, then Battery.")
        }
    }
}
