package com.torrix.app

import android.app.Application
import com.torrix.app.engine.EngineController
import com.torrix.app.service.Notifier

class TorrixApp : Application() {
    lateinit var engine: EngineController
        private set

    override fun onCreate() {
        super.onCreate()
        Notifier.createChannels(this)
        engine = EngineController(this)
        engine.start()
    }
}
