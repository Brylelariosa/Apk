package com.torrix.app.engine

import android.app.Application
import android.os.StatFs
import com.torrix.app.service.DownloadService
import com.torrix.app.service.NetworkMonitor
import com.torrix.app.service.Notifier
import com.torrix.app.storage.CompletedItem
import com.torrix.app.storage.CompletedStore
import com.torrix.app.storage.Exporter
import com.torrix.app.storage.HandledStore
import com.torrix.app.storage.SaveMode
import com.torrix.app.storage.SettingsStore
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Owns the native engine for the whole process: starts it, polls its
 * snapshot, applies settings and network changes, and saves finished
 * downloads to their final location. The UI and the foreground service both
 * read from here.
 */
class EngineController(private val app: Application) {

    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    val settings = SettingsStore(app)
    val completed = CompletedStore(File(app.filesDir, "completed.json"))
    val network = NetworkMonitor(app)

    private val handled = HandledStore(app)
    private val exporter = Exporter(app)
    private val started = AtomicBoolean(false)

    private val _snapshot = MutableStateFlow(Snapshot.EMPTY)
    val snapshot: StateFlow<Snapshot> = _snapshot.asStateFlow()

    private val _status = MutableStateFlow<EngineStatus>(EngineStatus.Starting)
    val status: StateFlow<EngineStatus> = _status.asStateFlow()

    private val _exports = MutableStateFlow<Map<String, ExportState>>(emptyMap())
    val exports: StateFlow<Map<String, ExportState>> = _exports.asStateFlow()

    private val _restartRequired = MutableStateFlow(false)
    val restartRequired: StateFlow<Boolean> = _restartRequired.asStateFlow()

    @Volatile
    private var uiVisible = false

    /**
     * Torrent data lives here while it downloads: private internal storage, no permission
     * needed, and direct disk access (the "Android/data" folder on shared storage goes through
     * Android 11's slower FUSE layer).
     */
    val stagingDir: File by lazy { File(app.filesDir, "torrents").apply { mkdirs() } }

    // ---------------------------------------------------------------- startup

    fun start() {
        if (!started.compareAndSet(false, true)) return
        scope.launch(Dispatchers.IO) { boot() }
    }

    private suspend fun boot() {
        try {
            val cfg = settings.state.value
            val net = network.state.value
            val netAllowed = net.connected && (net.unmetered || cfg.allowMobileData)
            val engineDir = File(app.filesDir, "engine").apply { mkdirs() }
            val args = JSONObject()
                .put("engine_dir", engineDir.absolutePath)
                .put("staging_dir", stagingDir.absolutePath)
                .put("cache_dir", app.cacheDir.absolutePath)
                .put("settings", cfg.toEngineJson())
                .put("net_allowed", netAllowed)
            rpc("init", args)
            _status.value = EngineStatus.Ready
            scope.launch { pollLoop() }
            scope.launch { watchSettings() }
            scope.launch { watchNetwork() }
        } catch (t: Throwable) {
            _status.value = EngineStatus.Failed(t.message ?: t.javaClass.simpleName)
        }
    }

    /** JSON-in / JSON-out call into the native engine. Throws [EngineException] on failure. */
    suspend fun rpc(method: String, args: JSONObject = JSONObject()): JSONObject =
        withContext(Dispatchers.IO) {
            val raw = NativeBridge.nativeCall(method, args.toString())
                ?: throw EngineException("The torrent engine did not answer.")
            val envelope = JSONObject(raw)
            if (!envelope.optBoolean("ok", false)) {
                throw EngineException(envelope.optString("error", "Unknown engine error."))
            }
            envelope.optJSONObject("data") ?: JSONObject()
        }

    // ---------------------------------------------------------------- loops

    private suspend fun pollLoop() {
        while (currentCoroutineContext().isActive) {
            try {
                val raw = withContext(Dispatchers.IO) { NativeBridge.nativeCall("snapshot", "{}") }
                if (raw != null) {
                    val envelope = JSONObject(raw)
                    if (envelope.optBoolean("ok", false)) {
                        val snap = parseSnapshot(envelope.getJSONObject("data"))
                        _snapshot.value = snap
                        onSnapshot(snap)
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                // A bad poll is simply skipped; the next one will succeed.
            }
            delay(if (uiVisible) 1_000L else 3_000L)
        }
    }

    private suspend fun watchSettings() {
        settings.state.collectLatest { s ->
            delay(400) // debounce typing in text fields
            try {
                val r = rpc("set_settings", JSONObject().put("settings", s.toEngineJson()))
                if (r.optBoolean("restart_required")) _restartRequired.value = true
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
            }
        }
    }

    private suspend fun watchNetwork() {
        var first = true
        combine(network.state, settings.state) { n, s ->
            n.connected && (n.unmetered || s.allowMobileData)
        }.distinctUntilChanged().collectLatest { allowed ->
            // Wi-Fi <-> mobile switches flap briefly; wait before reacting (except at start).
            if (!first) delay(1_200)
            first = false
            try {
                rpc("set_net_allowed", JSONObject().put("allowed", allowed))
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
            }
        }
    }

    // ---------------------------------------------------------- visibility

    fun setUiVisible(visible: Boolean) {
        uiVisible = visible
        scope.launch {
            // Poll less often in the background: less CPU, less battery.
            try {
                rpc("set_poll_ms", JSONObject().put("ms", if (visible) 1_000 else 3_000))
            } catch (_: Exception) {
            }
        }
        if (visible && needsService(_snapshot.value)) DownloadService.start(app)
    }

    fun onTorrentAdded() = DownloadService.start(app)

    /** True while the foreground service has a reason to exist. */
    fun needsService(s: Snapshot): Boolean {
        val seed = settings.state.value.seedAfterComplete
        return s.torrents.any { t ->
            (!t.finished && !t.hold && t.state != "error") || (seed && t.state == "seeding")
        } || _exports.value.values.any { it.running }
    }

    private fun onSnapshot(s: Snapshot) {
        if (uiVisible && needsService(s)) DownloadService.start(app)
        for (t in s.torrents) {
            if (t.finished && !handled.contains(t.hash)) {
                handled.add(t.hash)
                scope.launch(Dispatchers.IO) { handleFinished(t) }
            }
        }
    }

    // ----------------------------------------------------- finished downloads

    private suspend fun handleFinished(t: TorrentItem) {
        val cfg = settings.state.value
        if (cfg.saveMode == SaveMode.APP_ONLY) {
            Notifier.finished(app, "Download complete", t.name, t.hash.hashCode())
            return
        }
        runExport(t, cfg.saveMode, cfg.customTreeUri)
    }

    /** Copy a finished torrent to its final location, then free the app-storage copy. */
    private suspend fun runExport(t: TorrentItem, mode: SaveMode, treeUri: String?) {
        setExport(t.hash, ExportState(true, 0L, t.totalBytes, null))
        try {
            val d = rpc("details", JSONObject().put("hash", t.hash))
            val root = File(d.optString("output_folder", t.outputFolder))
            val arr = d.optJSONArray("files") ?: JSONArray()
            val specs = ArrayList<Exporter.FileSpec>()
            for (i in 0 until arr.length()) {
                val f = arr.optJSONObject(i) ?: continue
                if (f.optBoolean("included", true)) {
                    specs.add(Exporter.FileSpec(f.optString("path"), f.optLong("length")))
                }
            }
            val result = exporter.export(root, specs, mode, treeUri) { copied, total ->
                setExport(t.hash, ExportState(true, copied, total, null))
            }
            completed.add(
                CompletedItem(
                    hash = t.hash,
                    name = t.name,
                    sizeBytes = result.bytes,
                    completedMs = t.completedMs ?: System.currentTimeMillis(),
                    location = result.location,
                    uri = result.uri,
                    mime = result.mime,
                )
            )
            setExport(t.hash, null)
            if (!settings.state.value.seedAfterComplete) {
                // The files now live in their final place; free the working copy.
                try {
                    rpc("remove", JSONObject().put("hash", t.hash).put("delete_files", true))
                } catch (_: Exception) {
                }
            }
            Notifier.finished(app, "Download complete", "${t.name} was saved to ${result.location}", t.hash.hashCode())
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            setExport(t.hash, ExportState(false, 0L, t.totalBytes, e.message ?: "Could not save the files."))
        }
    }

    private fun setExport(hash: String, state: ExportState?) {
        _exports.update { m -> if (state == null) m - hash else m + (hash to state) }
    }

    /** Save a finished torrent to the chosen location (or Downloads) on demand. */
    fun saveFinished(hash: String, forcePublicDownloads: Boolean) {
        val t = _snapshot.value.torrents.firstOrNull { it.hash == hash && it.finished } ?: return
        if (_exports.value[hash]?.running == true) return
        val cfg = settings.state.value
        val mode = if (forcePublicDownloads || cfg.saveMode == SaveMode.APP_ONLY) {
            SaveMode.PUBLIC_DOWNLOADS
        } else {
            cfg.saveMode
        }
        scope.launch(Dispatchers.IO) { runExport(t, mode, cfg.customTreeUri) }
    }

    // ---------------------------------------------------------------- actions

    suspend fun pause(hash: String) {
        rpc("pause", JSONObject().put("hash", hash))
    }

    suspend fun resume(hash: String) {
        rpc("resume", JSONObject().put("hash", hash))
        DownloadService.start(app)
    }

    suspend fun pauseAll() {
        rpc("pause_all")
    }

    suspend fun resumeAll() {
        rpc("resume_all")
        DownloadService.start(app)
    }

    suspend fun remove(hash: String, deleteFiles: Boolean) {
        rpc("remove", JSONObject().put("hash", hash).put("delete_files", deleteFiles))
    }

    suspend fun search(query: String): SearchOutcome =
        parseSearch(rpc("search", JSONObject().put("query", query)))

    suspend fun diagnostics(): List<String> {
        val arr = rpc("logs").optJSONArray("lines") ?: JSONArray()
        return List(arr.length()) { arr.optString(it) }
    }

    fun freeStagingBytes(): Long = try {
        StatFs(stagingDir.path).availableBytes
    } catch (_: Exception) {
        Long.MAX_VALUE
    }
}
