# JNI: the native library looks this class and its native method up by name.
-keep class com.torrix.app.engine.NativeBridge { *; }
-keepclasseswithmembernames class * { native <methods>; }

# Strip verbose logging calls from release builds.
-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
}

-dontwarn org.jetbrains.annotations.**
