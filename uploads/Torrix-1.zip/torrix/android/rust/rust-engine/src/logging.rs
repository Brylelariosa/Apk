//! Tiny in-memory log. Android users usually cannot read logcat, so the last
//! few hundred warnings/errors are kept here and shown in Settings ->
//! Diagnostics. Nothing sensitive is ever logged (no magnet links, keys or
//! file names): callers pass short generic messages only.

use std::collections::VecDeque;
use std::sync::Mutex;

const MAX_LINES: usize = 300;

static LINES: Mutex<VecDeque<String>> = Mutex::new(VecDeque::new());

pub fn push(line: String) {
    if let Ok(mut g) = LINES.lock() {
        if g.len() >= MAX_LINES {
            g.pop_front();
        }
        g.push_back(line);
    }
}

pub fn lines() -> Vec<String> {
    LINES
        .lock()
        .map(|g| g.iter().cloned().collect())
        .unwrap_or_default()
}

pub fn info(msg: impl AsRef<str>) {
    push(format!("{} I {}", crate::now_ms(), msg.as_ref()));
}

pub fn warn(msg: impl AsRef<str>) {
    push(format!("{} W {}", crate::now_ms(), msg.as_ref()));
}

pub fn error(msg: impl AsRef<str>) {
    push(format!("{} E {}", crate::now_ms(), msg.as_ref()));
}

struct RingLogger;

impl log::Log for RingLogger {
    fn enabled(&self, metadata: &log::Metadata) -> bool {
        metadata.level() <= log::Level::Warn
    }

    fn log(&self, record: &log::Record) {
        if self.enabled(record.metadata()) {
            push(format!(
                "{} {} {}: {}",
                crate::now_ms(),
                record.level(),
                record.target(),
                record.args()
            ));
        }
    }

    fn flush(&self) {}
}

static LOGGER: RingLogger = RingLogger;

/// Route `log` records (and librqbit's tracing events, through tracing's `log`
/// feature) into the ring buffer, and keep panic messages.
pub fn init() {
    let _ = log::set_logger(&LOGGER);
    log::set_max_level(log::LevelFilter::Warn);
    std::panic::set_hook(Box::new(|info| {
        push(format!("{} PANIC {}", crate::now_ms(), info));
    }));
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn ring_buffer_is_bounded() {
        for i in 0..(MAX_LINES + 50) {
            push(format!("line {i}"));
        }
        let l = lines();
        assert!(l.len() <= MAX_LINES);
        assert!(l.last().unwrap().contains("line"));
    }
}
