# VideoFrameExtractor — Devlog

Track what we build, fix, and improve. Newest entries first.

---

## v1.1 — Save Location, Time Range, Frame Preview
**Built:** Three major feature additions

### Save Location
- New **OUTPUT LOCATION** card with "Choose Folder" button using `ActivityResultContracts.OpenDocumentTree`
- Persists folder permission with `takePersistableUriPermission` so chosen folder survives across sessions
- When a custom folder is picked, extraction writes via `DocumentFile` + SAF `ContentResolver` streams
- Session subfolder (`videoname_TIMESTAMP/`) is still created inside the chosen directory
- "Reset" button clears custom folder and reverts to default app storage
- Default behaviour (app external storage) unchanged when no folder is chosen
- Added `androidx.documentfile:documentfile:1.0.1` dependency

### Time Range
- New **TIME RANGE** section inside the settings card
- **Start** and **End** time fields accept `m:ss.mmm`, `h:mm:ss.mmm`, `ss.mmm` formats with millisecond precision (e.g. `3:00.000`)
- Auto-filled on video load: Start → `0:00.000`, End → video duration
- Extraction clamps both values to `[0, videoDuration]`; validates that start < end
- `updateEstimate()` now uses range duration instead of full video duration
- Range info line shows `Range: 0:30.000 → 1:45.000 (1:15)` live as you type
- `parseTimeMs()` helper parses all supported formats robustly
- `formatTimeMs()` helper produces `m:ss.mmm` / `h:mm:ss.mmm` display strings

### Frame Preview
- **Preview** button next to Start time field
- Loads frame at the current Start time using `OPTION_CLOSEST_SYNC` on IO dispatcher
- Shows frame in a new **FRAME PREVIEW** card (hidden until first preview)
- Card label updates to `Frame at 0:30.000` to confirm which timestamp is shown
- Preview button disabled during active extraction to avoid retriever contention
- `previewJob` is cancellable so rapid taps don't pile up stale requests

### Bug / UX fixes
- `setUiExtracting()` now also disables Preview and Choose Folder buttons during extraction
- `doExtract` now accepts explicit `startMs`/`endMs` params; `startExtraction()` validates and passes them
- Frame counter `totalFrames` is now derived from range duration, not full video duration

---

## v1.0 — Initial Release
**Built:** Core frame extraction app

### What's in v1.0
- **Video picker** via `ActivityResultContracts.GetContent` (no permission needed on modern Android)
- **Auto-detects** video resolution, duration, and native FPS (API 28+ via `METADATA_KEY_VIDEO_FRAME_COUNT`)
- **FPS input** pre-filled with native fps; any custom value supported (0.1–240)
- **Live estimate** updates as you type (e.g. "1800 frames")
- **Frame extraction** using `MediaMetadataRetriever.getFrameAtTime()` with `OPTION_CLOSEST` for accuracy
- **PNG output** saved to `getExternalFilesDir("frames")` — no permissions needed
- **Output folder** timestamped per session: `videoname_20250615_143022/`
- **Frame files** named `frame_000001.png`, `frame_000002.png`, etc.
- **Progress bar** + live frame counter + ETA estimate during extraction
- **Cancel button** stops extraction mid-way, keeping frames extracted so far
- **Copy Path** button copies output folder path to clipboard
- Dark green (#1B4332 / #52B788) UI theme

### Output path
```
/sdcard/Android/data/com.bryle.videoframes/files/frames/videoname_TIMESTAMP/
```
Accessible via any file manager app under `Android/data/`.

### Known limitations
- `OPTION_CLOSEST` is accurate but slow on high-fps videos (decodes every frame sequentially)
- Output goes to app-specific storage, not directly to Gallery/Photos
- No batch processing (one video at a time)
- ETA is a rough estimate based on frames-per-second rate so far
- SAF-backed output (custom folder) is slower than direct File I/O due to per-file IPC overhead

---

## Ideas / Future Work

### Performance
- [ ] Add "Fast mode" toggle → uses `OPTION_CLOSEST_SYNC` (keyframes only, much faster)
- [ ] API 28+: use `getFramesAtIndex()` in batches for native-fps extraction (more efficient)
- [ ] Per-frame decode timing displayed in UI
- [ ] Batch-copy to SAF folder post-extraction (extract locally for speed, then move)

### Output options
- [ ] Save to `Pictures/` via MediaStore (appears in Gallery) — needs MediaStore insert on Q+
- [ ] Configurable output format: PNG / JPEG (with JPEG quality slider)
- [ ] Custom output folder name override
- [ ] Resize output frames (e.g. 50% scale to reduce file size)

### UI / UX
- [ ] Preview End frame (second preview button)
- [ ] Scrub slider tied to preview — drag to seek and preview any timestamp
- [ ] Recent jobs history (list of past extractions with frame counts)
- [ ] Share button to export a single extracted frame

### Extraction
- [ ] Batch mode: queue multiple videos
- [ ] Extract every Nth frame mode (e.g. every 5th frame)
- [ ] Frame deduplication: skip near-identical frames (hash diff)
