# DuelForge

A Yu-Gi-Oh-style Trading Card Game engine for Android, built with Kotlin and Jetpack
Compose. Play a full duel (Draw/Standby/Main 1/Battle/Main 2/End phases, Normal/Flip/
Fusion/Special Summons, a real chain/priority system, Spell/Trap activation, Counter
Traps, etc.) against a simple AI opponent, using a 49-card original sample deck (96
cards total with duplicates) plus 2 Extra Deck Fusion Monsters.

## How to play

- The field uses the full screen width: opponent's Spell/Trap + monster rows, a
  segmented phase tracker, your monster + Spell/Trap rows, then your hand pinned at
  the bottom (always visible, never needs scrolling to reach). Each player's LP is
  shown next to their deck; tap the 📜 button to view the full battle log, and 🔧 for
  the debug/testing screen.
- **Tap a card** (in your hand, on your field, or in your Spell/Trap zone) to slide up
  a panel showing its name/stats/description and available actions: Normal Summon,
  Set, Flip Summon, switch Attack/Defense Position, or Activate an effect. Tap away
  (deselect) and the panel collapses again, giving the field the full screen back.
- A Field Spell, if active, shows as a small "🌍 [name]" badge next to its controller's
  LP rather than a full zone slot - tap it for a full preview.
- **Tributes**: if a monster needs tributes, after choosing Normal Summon/Set you'll
  be asked to tap that many of your own field monsters, then press Confirm.
- **Attacking**: during your Battle Phase, tap one of your face-up Attack Position
  monsters to select it as an attacker, then tap an opponent's monster to attack it
  (or press "Attack Directly" if they have no monsters).
- **Responding**: when the opponent does something you can respond to (with a
  face-up Quick Effect, a Quick-Play Spell in hand, or a Trap on your field), a
  dialog pops up listing your options, plus "Pass".
- The phase tracker shows all six phases (Draw/Standby/Main 1/Battle/Main 2/End) as a
  row of chips with the current one highlighted, GBA-duel-game style, with the
  relevant action button(s) just below it. Press **Next Phase** to advance; pressing
  it during your End Phase ends your turn and the AI plays its entire turn
  automatically (pausing for any response prompts of yours along the way). During
  Main Phase 1 you instead get three shortcuts: **⚔ Battle** (go fight), **→ Main 2**
  (skip straight to Main Phase 2), and **⏭ End** (skip straight to End Phase) - handy
  when you don't need that phase this turn.
- Tap **🔍 View Card** (shown for any selected face-up card) for a large full-art
  preview - the same preview also pops up briefly whenever you Summon, Flip Summon,
  or activate something. Cards appearing on or leaving the field animate in/out
  instead of popping instantly.
- Declaring an attack flashes a brief "⚔ ATTACK!" overlay before damage resolves.
- A coin-toss effect (e.g. Abare Ushioni) asks you to **call Heads or Tails** first,
  then plays a brief flip animation landing on the real result before applying it.

## What's implemented

- Full turn structure: Draw -> Standby -> Main 1 -> Battle -> Main 2 -> End, with the
  turn player skipping their first Draw Phase. Standby Phase and End Phase each open a
  priority window, so "during your Standby Phase" / "during the End Phase" Trigger
  effects can fire (e.g. peeking at a Set card every Standby Phase, reviving a monster
  destroyed earlier that same turn during the End Phase).
- Normal Summon and Set (face-down Defense), with tribute requirements based on Level
  (1-4: none, 5-6: one, 7+: two).
- Flip Summon (manually flipping a Set monster face-up) and flipping via battle, both
  triggering FLIP effects.
- Battle Position changes (once per turn, not the turn a monster was Summoned/Set or
  attacked).
- Battle: ATK-vs-ATK, ATK-vs-DEF, and direct attacks, including piercing-style "you
  take the difference" damage when your attacker's ATK is less than a Defense
  Position target's DEF.
- A real chain/priority system: Quick-Play Spells, Quick Effects, Traps (including
  Counter Traps that negate-and-destroy), and Trigger effects can all be chained,
  resolving LIFO.
- Fusion Summon via "Fusion Catalyst", which finds a valid Fusion Monster + material
  combination on your field and Special Summons it.
- A Field Spell (Battlefield Overgrowth) that buffs all EARTH monsters' ATK.
- A simple AI opponent that plays its whole turn: summons/sets the best available
  monster (tributing when it's a net upgrade), activates useful Spells/Effects,
  attacks only into favorable trades, and responds to your actions with its own
  Quick Effects/Traps when it has them.

## v1 simplifications (by design)

These keep the engine manageable while still feeling like "real" Yu-Gi-Oh. Worth
knowing if a duel plays out unexpectedly:

- **No Synchro/Xyz/Pendulum/Link monsters.** The Extra Deck + Fusion Summon pathway
  is built to be extended to these later if you want.
- **Fusion Summon auto-picks materials** - the first valid combination found on your
  field is used automatically; there's no "choose your fusion materials" screen.
- **Trigger and FLIP effects auto-activate** (no "would you like to activate?"
  prompt) - they just happen and then the opponent gets a chance to respond.
- **Chains resolve fully once both sides pass once** - real Yu-Gi-Oh re-opens
  priority after every single chain link resolves; here, once nobody adds a new
  link, the whole stack resolves top-to-bottom in one go. Multi-link chains and
  Counter Traps still work correctly, but some very specific real-game edge cases
  (e.g. responding mid-resolution to something a lower chain link does) aren't
  modeled.
- **No hand-size limit** at the End Phase.
- **A monster Set face-down can't be Flip Summoned the same turn it was Set.**
- **The AI doesn't use Quick-Play Spells during its Battle Phase**, and doesn't Flip
  Summon its own Set monsters - both remain possible for the human player.
- **A handful of effects are intentionally simplified** for cards whose real text needs
  game mechanics this engine doesn't model (Union monster equip/protection, deck-reorder
  UI, GY-card browsing). Each is called out in a code comment right above its
  `EffectRegistry` entry, and summarized in `devlog.md`.

## Adding cards / art

See `app/src/main/assets/cards/README.md` for full instructions. Short version:
drop `<card_id>.png` into `app/src/main/assets/cards/` for artwork (placeholders are
used otherwise), and add new card data to `app/src/main/assets/cards.json` - effect
cards also need an entry in `app/src/main/java/com/hzcm/duelforge/data/EffectRegistry.kt`.

## Building via GitHub Actions

This project is set up for the same GitHub Actions pipeline as your other Android
projects:

1. Zip this whole `DuelForge/` folder (keep `gradlew` executable inside the zip).
2. Push the zip into your repo's `uploads/` folder.
3. The workflow extracts it, locates `settings.gradle.kts`, fetches the Gradle 8.6
   wrapper jar, and builds a debug APK with AGP 8.2.2 / Kotlin 1.9.22 / JDK 17.
4. Download the APK from the workflow run's artifacts.

## Project structure

```
app/src/main/java/com/hzcm/duelforge/
  model/    - Card, CardInstance, GameState, Enums, CardEffect (pure data types)
  data/     - CardDatabase (loads cards.json), EffectRegistry (effect implementations)
  engine/   - GameEngine (core), ChainManager, SummonManager, BattleManager, AIController
  ui/       - GameViewModel, GameScreen, CardView, ImageLoader
  MainActivity.kt
app/src/main/assets/
  cards.json      - all card data
  cards/          - card artwork (add your own PNGs here)
```

See `devlog.md` for a running development log of architecture decisions and
known issues.
