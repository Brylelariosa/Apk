# DuelForge - Development Log

A Yu-Gi-Oh-style TCG engine for Android (Kotlin + Jetpack Compose), built for the
GitHub Actions APK pipeline workflow. vs AI opponent, full rules including chains
and priority (with documented v1 simplifications).

---

## Session 1 - Initial build

### Project setup
- `settings.gradle.kts`, root `build.gradle.kts` (AGP 8.2.2, Kotlin 1.9.22)
- `gradle.properties`, `gradle/wrapper/gradle-wrapper.properties` (Gradle 8.6, matches CI)
- `gradlew` (Unix wrapper script, made executable, fixed a CLASSPATH typo)
- `app/build.gradle.kts` - compileSdk/targetSdk 34, minSdk 24, Compose enabled,
  compose-bom 2024.02.01, compose compiler ext 1.5.8, JVM target 17
- `AndroidManifest.xml` - uses `@android:drawable/sym_def_app_icon` (no custom icon
  needed), MainActivity locked to landscape
- `strings.xml`, `themes.xml` - basic dark theme

### Model layer (`model/`)
- `Enums.kt` - PlayerId (+ `.opponent()`), CardType, MonsterCategory, SpellType,
  TrapType, Attribute, Race, Phase, Location, BattlePosition, EffectTiming
  (NORMAL/IGNITION/TRIGGER/QUICK/CONTINUOUS/FLIP), sealed `FusionMaterial`
  (Specific/AnyOfRace/AnyMonster)
- `Card.kt` - static card definition (immutable), `tributesRequired` computed from level
  (1-4: 0, 5-6: 1, 7+: 2)
- `CardInstance.kt` - mutable per-duel copy of a card: location, zone index, battle
  position, face-up state, per-turn flags, stat modifiers, `isNegated` flag (for Counter
  Traps), `effectiveAtk`/`effectiveDef`
- `GameState.kt` - `PlayerField` (zones, hand/deck/GY/banished/extra deck, LP, normal
  summon tracking), `ChainLink`, sealed `GameEvent` (what just happened, drives
  Trigger/Quick conditions), `GameState`, `PriorityPrompt`
- `Effects.kt` - `CardEffect` data class + typealiases for condition/cost/target/resolve
  lambdas

### Engine layer (`engine/`)
- **GameEngine.kt** - core class: owns `GameState` + `CardDatabase`, zone management
  (draw/destroy/banish/GY/extra-deck moves), turn/phase state machine (`advancePhase`),
  win condition checks, and `computeAtk`/`computeDef` (stat queries that fold in
  continuous field-wide effects).
- **ChainManager.kt** - the heart of "full rules": `openPriorityWindow` (checks the
  acting player's own Trigger effects first, then the responder's Quick/Trap/Trigger
  options - recursing if they chain something), `submitPriorityChoice` (UI resume
  point for human responses), `pushChainLink` (pays costs, moves/flips cards, handles
  Field Spell placement), `resolveChain` (LIFO resolution, respects `isNegated`),
  `getActivatableEffects`, `resolveTargets`, plus `canActivateEffect`/`activateEffect`
  (the player-initiated entry point for Normal Spells / Ignition / proactive Quick).
- **SummonManager.kt** - Normal Summon / Set (with tribute validation), Flip Summon +
  `triggerFlipEffects`, battle position changes, generic `specialSummon`, and the
  Fusion Summon pathway (`findFusionCombo` greedily matches `FusionMaterial`
  requirements, `performFusionSummon` sends materials to GY and special-summons the
  Fusion Monster).
- **BattleManager.kt** - `canDeclareAttack`/`declareAttack` (CPS, opens a priority
  window before damage), `resolveBattleDamage` implementing ATK-vs-ATK, ATK-vs-DEF, and
  direct attack rules, including flipping face-down defenders (and firing their FLIP
  effects) before computing damage.
- **AIController.kt** - `aiRunTurn` drives the AI's entire turn via nested CPS
  callbacks (so a human priority prompt mid-AI-turn pauses cleanly); `aiMainPhaseStep`
  picks summons (greedy ATK-vs-tribute-cost heuristic) and activations; `aiBattleStep`
  attacks only into "safe" trades; `aiChooseResponse`/`aiChooseTargets` for chain
  decisions.

### Data layer (`data/`)
- **cards.json** - 17 main-deck cards + 2 Extra Deck Fusion Monsters, all original
  names/stats. Deck = ~33 cards via per-card `count`. Fusion materials encoded as
  strings (`SPECIFIC:id`, `RACE:NAME:count`, `ANY:count`).
- **CardDatabase.kt** - loads/parses cards.json, builds main + extra decks.
- **EffectRegistry.kt** - implements all 10 effect cards (see card list below).

### Key architecture decisions
- Long sequences (AI turns, chain resolution, battles) use continuation-passing style
  (`onDone: () -> Unit`) so a human priority prompt can pause mid-sequence and resume via
  `submitPriorityChoice()`.
- `advancePhase()` only triggers `aiRunTurn()` from its `Phase.END -> endTurn()` branch
  (the one place control can switch to the AI) - this avoids infinite recursion since
  `aiRunTurn` itself calls `advancePhase()` repeatedly for the AI's own phases.
- Continuous field-wide effects (Battlefield Overgrowth: all EARTH +200 ATK) are
  hand-coded in `GameEngine.computeAtk()` rather than via a generic registry - documented
  v1 simplification.
- "Destroyed by battle" Trigger effects (Glacier Hound) auto-resolve directly inside
  `destroyCard()` rather than joining the chain, since the card has already left the
  field by the time it would be considered.
- Avoided `return@CardEffect` inside lambda arguments to `CardEffect(...)` (ambiguous
  whether constructors get implicit labels without a compiler to verify) - used
  `.let { }` blocks instead throughout EffectRegistry.

### Card list (17 main deck + 2 Extra Deck)
| Card | Type | Stats | Effect |
|---|---|---|---|
| Squire of the Vale | Normal Monster | 800/500 LIGHT Warrior Lv2 | - |
| Wildclaw Tiger | Normal Monster | 1700/1000 EARTH Beast Lv4 | - |
| Ironclad Defender | Effect Monster | 1200/2000 EARTH Machine Lv4 | FLIP: gain 1000 LP |
| Stormcaller Falcon | Effect Monster | 1600/1200 WIND Winged Beast Lv4 | On Normal Summon: draw 1 |
| Crimson War Wyrm | Effect Monster | 2300/1700 FIRE Dragon Lv6 (1 tribute) | Ignition, once/turn: halve an opponent monster's ATK until EOT |
| Tidal Leviathan | Normal Monster | 2400/1000 WATER Aqua Lv6 (1 tribute) | - |
| Obsidian Golem Titan | Normal Monster | 2900/2800 EARTH Rock Lv8 (2 tributes) | - |
| Sentinel of the Sealed Gate | Effect Monster | 2500/2100 DARK Fiend Lv7 (2 tributes) | Quick, once/turn: discard 1 to negate+destroy a Trap activation |
| Spark Imp | Effect Monster | 300/200 FIRE Fiend Lv1 | (see "Not yet implemented" below) |
| Glacier Hound | Effect Monster | 1000/800 WATER Beast Lv3 | If destroyed by battle: draw 1 |
| Tactical Reinforcement | Normal Spell | - | Draw 2, discard 1 |
| Fusion Catalyst | Normal Spell | - | Fusion Summon from Extra Deck |
| Battlefield Overgrowth | Field Spell | - | All EARTH monsters +200 ATK |
| Rapid Strike | Quick-Play Spell | - | Target your monster that attacked: it can attack again |
| Shield Wall | Continuous Trap | - | Once/turn: switch the attacked monster to Defense |
| Reversal Ambush | Normal Trap | - | Destroy the attacking monster |
| Negation Barrier | Counter Trap | - | Negate + destroy a Spell/Monster Effect activation |
| Twin-Fang Chimera | Fusion Monster (Extra Deck) | 2600/2100 DARK Beast Lv6 | 2x BEAST material |
| Inferno Dragon Overlord | Fusion Monster (Extra Deck) | 3000/2500 FIRE Dragon Lv8 | Crimson War Wyrm + 1 monster |

### Known v1 simplifications (to document in final README)
- No Synchro/Xyz/Pendulum/Link (architecture supports adding via Extra Deck + special
  summon pathway later).
- Fusion Summon auto-picks the first valid material combination (no manual material
  selection UI).
- Trigger and FLIP effects auto-activate without an "activate?" prompt.
- Chain resolves fully top-to-bottom once both sides pass once (no re-opening priority
  after each individual link resolves).
- No hand-size limit at End Phase.
- AI doesn't use Quick-Play Spells during the Battle Phase (Rapid Strike is
  human-only in practice).
- Set monsters can't be Flip Summoned the same turn they're Set.

### Spark Imp - added
- `spark_imp_ignition`: payCost sends Spark Imp itself to the GY (self-tribute as cost,
  paid even if later negated by a Counter Trap - matches real rules), resolve deals 500
  damage to the opponent and checks win conditions.

### UI layer (`ui/`) - completed
- **ImageLoader.kt** - loads `assets/cards/<imageId>.{png,jpg,jpeg,webp}` with an
  in-memory cache; returns null (triggering the placeholder) if nothing found.
- **CardView.kt** - renders a card: empty-zone outline, card back (face-down, unless
  `revealFaceDown` for the human's own set cards), artwork + ATK/DEF/position overlay,
  or a generated placeholder (colored by card type/category) with name, attribute/race,
  Lv/ATK/DEF.
- **GameViewModel.kt** - wraps `GameEngine`, exposes `refresh` (bumped after every
  engine mutation to drive recomposition), `selectedCard`/`tributeSelection`/
  `attackerSelection` selection state, and action methods (`onHandCardTapped`,
  `onOwnMonsterTapped`, `onOwnSpellTrapTapped`, `onOpponentMonsterTapped`,
  `beginSummon`/`confirmTributeSummon`, `setTrap`, `activateEffect`, `flipSummon`,
  `changeBattlePosition`, `declareDirectAttack`, `advancePhase`, `submitPriorityChoice`,
  `restart`).
- **GameScreen.kt** - full landscape layout: opponent field (field zone, 5 monster
  zones, 5 spell/trap zones, LP/counts), turn/phase bar with Next Phase/End Turn
  button, scrollable battle log + context-sensitive action panel side by side, player
  field (mirrored, with own face-down cards revealed to the player), scrollable hand.
  Plus a priority-response `AlertDialog` and a game-over overlay with "New Duel".
- **MainActivity.kt** - hosts `GameScreen()` inside a `MaterialTheme`/`Surface`.

### Added during review
- **Set Spell/Trap action** (`SummonManager.canSetSpellOrTrap`/`setSpellOrTrap`) - this
  was missing entirely from the original plan; without it Trap cards could never reach
  the Spell/Trap Zone. Restricted to Trap cards only (Quick-Play Spells are activated
  directly from hand instead - a Set Quick-Play Spell would have no activation path
  given the priority-window design, so Setting one is disallowed to avoid a dead card).
- **Rapid Strike's `canActivate`** now requires `state.phase == Phase.BATTLE`, so the
  AI doesn't waste it responding outside the Battle Phase (the granted extra attack
  would just get reset away before ever being used).
- Traced through a "Negation Barrier negates a Trigger effect, which destroys the
  Trigger's source, which opens a nested priority window" scenario by hand (no compiler
  available) - confirmed `resolveChain()`'s recursive-via-nested-`destroyCard` pattern
  correctly drains `state.chain` and calls `onDone()` exactly once, GIVEN that no
  Quick/Trap effect in this card pool reacts to `GameEvent.Destroyed` for the human
  player (documented as a structural limitation: such a reaction would surface a
  priority prompt out of order relative to `resolveChain`'s loop).

### Known gaps not fixed this session (acceptable for v1)
- AI never Flip Summons its own face-down monsters (only the human can).
- AI may occasionally hold onto Rapid Strike longer than ideal but won't waste it
  outside Battle Phase anymore.

### Final file list
```
DuelForge/
  README.md, devlog.md
  settings.gradle.kts, build.gradle.kts, gradle.properties
  gradlew, gradle/wrapper/gradle-wrapper.properties
  app/build.gradle.kts
  app/src/main/AndroidManifest.xml
  app/src/main/res/values/{strings,themes}.xml
  app/src/main/assets/cards.json
  app/src/main/assets/cards/README.md
  app/src/main/java/com/hzcm/duelforge/
    MainActivity.kt
    model/{Enums,Card,CardInstance,GameState,Effects}.kt
    data/{CardDatabase,EffectRegistry}.kt
    engine/{GameEngine,ChainManager,SummonManager,BattleManager,AIController}.kt
    ui/{ImageLoader,CardView,GameViewModel,GameScreen}.kt
```

### Status: feature-complete for v1, ready to zip and push to the build pipeline.


---

## Session 3 — Debug Duel (cont.) + Field Polish

### Debug Duel Screen (completed from Session 2)
- **DebugDuelScreen.kt** — Full testing area reachable via 🔧 button in the PhaseBar. Both player fields displayed side-by-side with live `computeAtk()` values shown on each monster zone. Three tabs:
  - **⚙ Setup**: pick player + zone, select any card from the full pool, tap to place. Supports Hand / Monster Zone / S/T Zone / Field Zone / GY. Face/position toggles for monsters. LP ±1000 buttons + quick reset. Phase selector and turn-player toggle.
  - **⛓ Chain Lab**: lists all non-CONTINUOUS effects on field/hand for either player; "Push →" force-pushes any effect to chain bypassing `canActivate`. Event injection (NormalSummon, AttackDeclared). Priority window opener for both sides. [Resolve] and [Clear] chain buttons.
  - **🎯 Scenarios**: one-tap preset tests: Trigger-on-summon, Counter Trap negation, 3-link chain, Battlefield Overgrowth continuous buff.

### Generic Continuous Effect System
- **StatBonus typealias** added to `Effects.kt` (`(engine, source, target) -> Int`).
- `CardEffect` gains `atkBonus`/`defBonus` optional fields (CONTINUOUS timing only).
- `GameEngine.computeAtk/Def` now iterates all face-up field cards and sums their `atkBonus`/`defBonus` lambdas. **No more hard-coded card-ID checks in the engine** — to add a new stat buff, supply an `atkBonus` lambda in EffectRegistry only.
- `battlefield_overgrowth` now has two entries: its normal ACTIVATE effect + a CONTINUOUS entry using the new `earthAtkBuff(200)` shared factory.

### Shared Effect Factories (EffectRegistry)
- `gainLPOnFlip(amount)`, `drawOnNormalSummon(count)`, `drawIfDestroyedByBattle(count)`, `inflictDamageOnSelfTribute(damage)`, `earthAtkBuff(amount)` — private factories that multiple cards can reference. Fix the factory → every card using it is fixed automatically.

### Card visuals
- **Card back**: real artwork (`assets/card_back.webp`) loaded via `ImageLoader.loadCardBack()` and rendered in `CardBack()`. Falls back to the blue placeholder if the file is missing.
- **Defense Position rotation**: monsters in Defense Position are rendered 90° sideways (graphicsLayer rotationZ = 90f) with a blue border tint and "DEF" badge, matching real YGO visual convention. Applies to both face-up and face-down defense cards.

### Field layout
- **PlayerPanel** rows swapped: monster zones are now on top (closest to the center/PhaseBar) and Spell/Trap zones are below — matching the real YGO mat layout where both players' monster zones face each other across the center line.

### Battle Phase
- **Single-tap** to enter Battle Phase: `advancePhase()` now transitions MAIN1 → BATTLE_START → BATTLE in one call. No more tapping "Next Phase" twice.
- **Battle Phase banner**: a red translucent overlay ("⚔ BATTLE PHASE — Tap your monsters to attack!") appears when Battle Phase begins, telling the player what to do.

### Discard selection
- `GameState.pendingDiscard: DiscardRequest?` added. When non-null, chain resolution is paused.
- `GameEngine.pendingDiscardResume` stores the continuation callback.
- `GameEngine.requestDiscard(player, count, reason, onDone)` extension: AI auto-picks last N cards; human player gets a card-picker dialog.
- `resolveChain()` returns early when `pendingDiscard` is set; `GameViewModel.confirmDiscard()` sends chosen cards to GY and resumes resolution.
- **DiscardDialog** composable in GameScreen shows the player's hand as tappable CardViews; Confirm button only enables when the right number of cards are selected.
- `tactical_reinforcement` updated to use `requestDiscard` instead of randomly discarding `hand.last()`.

---

## Session 4 — Card Preview, Attack Animation, Phase Shortcuts, Field Bug Fixes, 12 New Cards

### Bug fixes (reported by play-testing)
- **Defense-position overlap fixed**: `CardView` now gives a Defense Position monster a
  square `CardHeight × CardHeight` slot (instead of the normal `CardWidth × CardHeight`)
  before rotating it 90°, so the rotated card's wider bounding box fits entirely inside
  its own zone instead of bleeding into the neighboring zone.
- **Card back now used for ALL face-down cards**, not just monsters: Set Spells and Set
  Traps in the Spell/Trap Zone previously fell through to the generic placeholder; they
  now render with `CardBack()` exactly like a face-down monster, with a blue-tinted
  border (vs grey for an opponent's hidden Set card) so the owner can tell it's theirs.
- **Setting a Spell card was impossible**: `canSetSpellOrTrap`/`setSpellOrTrap` only
  ever allowed Trap cards (Session 1 limitation). Normal and Quick-Play Spells can now
  be Set face-down too (Field/Continuous/Equip Spells still activate directly from hand,
  since Setting one has no benefit). `HandCardActions` now shows "Set face-down" for
  Spell and Trap cards.
- **Deck pile visual added**: both players' decks now render as a small card-back stack
  with a count badge (`DeckPile` composable) next to their LP line, instead of just text
  — addresses "I don't see deck to draw from." Drawing itself was already automatic
  (real rules: draw happens automatically every Draw Phase) - clarified in-code that this
  is intentional, not a bug.

### Card preview overlay
- Tapping **"🔍 View Card"** (shown for any face-up selected card) or summoning/Flip
  Summoning/activating a card now shows a full-art `CardPreviewOverlay`: a centered
  large rendition of the card, full-screen-darkened background, tap-anywhere to dismiss.
- Auto-triggered previews (after Normal/Special/Flip Summon or activating an effect)
  auto-dismiss after ~2.2s via `previewAutoShow`; manually-opened previews
  (`showFieldPreview`) stay open until tapped. Face-down cards are never previewed
  (nothing to show) - the View Card button only appears when `card.faceUp`.

### Attack animation
- Declaring an attack (`onOpponentMonsterTapped`/`declareDirectAttack`) now flashes a
  brief red "⚔ ATTACK!" full-screen overlay (`AttackFlashOverlay`, fade in 80ms / hold
  170ms / fade out 450ms) before/while damage resolves, addressing "add attack
  animation." Added `androidx.compose.animation:animation` as an explicit Gradle
  dependency for `AnimatedVisibility`.

### Phase bar — Main Phase 1 shortcuts
- Main Phase 1 now shows three buttons instead of one: **⚔ Battle** (go to Battle
  Phase), **→ MP2** (skip straight to Main Phase 2), **⏭ End** (skip straight to End
  Phase) - addresses "make phase better like you can choose main phase to end or main
  phase 2." All other phases keep the single contextual button ("Next Phase"/"End
  Turn"). Skip buttons stop early (without losing the skip) if a chain/priority prompt
  appears along the way, so e.g. an opponent Trap mid-skip is never silently bypassed.

### Engine: Standby Phase and End Phase priority windows
- `advancePhase()` now opens a priority window when entering **Standby Phase** (before
  Main Phase 1) and **End Phase**, enabling "during your Standby Phase" / "during the
  End Phase" Trigger effects for the first time (previously these phases were pure
  pass-through with no chance for any card to react). `advancePhase()` is now fully
  continuation-passing (`onDone: () -> Unit`) since these windows can pause on a human
  response; `aiRunTurn()` was rewritten to thread callbacks through every phase step
  accordingly (previously assumed `advancePhase()` always completed synchronously).
- `openPriorityWindow`'s own-side auto-trigger scan and `getActivatableEffects` (the
  responder side) now also scan the player's **hand** and **Graveyard** for Trigger/Quick
  monster effects, not just face-up field monsters - needed for "Special Summon this
  card from your hand when X happens" and GY-based Quick effects (see new cards below).
  Verified this doesn't change behavior for any existing card (all existing Trigger
  conditions key off `lastEvent` referential checks or a self-resetting flag that's
  already false by the time these scans run).
- Added `lastBattleWinner`/`lastBattleLoser` (renamed/extended from a one-sided
  `lastBattleAttackerWon`/`lastBattleVictim` draft) to `GameEngine`, set by
  `BattleManager` for **either** side of a battle (attacker or defender, whichever one's
  stat was higher) and cleared at the start of each new attack declaration - powers
  Absorbing Kid from the Sky's "when this card destroys a monster by battle" effect.
- Added `CardInstance.turnDestroyedOnField` (stamped by `destroyCard()`) and
  `ignoreSetTurnRestriction` (lets a Set Trap be activated the same turn it was Set, for
  Absolute King Back Jack) plus `PlayerField.cannotSetCardsThisTurn` (for Absorbing
  Jar), all cleared at the proper turn boundary in `endTurn()`/`startGame()`.

### 12 new cards added
| Card | Type | Stats | Effect |
|---|---|---|---|
| Absolute King - Megaplunder | Normal Monster | 2000/1500 EARTH Dinosaur Lv6 | - |
| Absolute King Back Jack | Effect Monster | 0/0 DARK Fiend Lv1 | Quick (GY, opponent's turn): banish from GY, excavate top Deck card - Set it if Normal Trap (activatable this turn), else GY. Trigger: if destroyed→GY, peek top 3 of Deck. |
| Absolute Crusader | Effect Monster | 1800/1200 EARTH Warrior Lv4 | Trigger: if a Lv5+ monster is Special Summoned (either side), tribute self to destroy it |
| Abaki | Effect Monster | 1700/1100 FIRE Fiend Lv4 | Trigger: destroyed by battle → both players take 500 damage |
| A Man with Wdjat | Effect Monster | 1600/1600 DARK Spellcaster Lv4 | Trigger: on Normal Summon and each of your Standby Phases, peek at 1 opponent Set card (logged, not moved) |
| A/D Changer | Effect Monster | 100/100 LIGHT Warrior Lv1 | Quick (GY): banish self from GY, flip any 1 monster's battle position |
| A-Team: Trap Disposal Unit | Effect Monster | 300/400 FIRE Machine Lv2 | Quick: tribute self to negate + destroy an opponent's activated Trap |
| A-Assault Core | Effect Monster | 1900/200 LIGHT Machine Lv4 | Ignition, once/turn: target 1 LIGHT Machine you control, +500 ATK until EOT (simplified from its original Union equip ability - see note below) |
| Abominable Unchained Soul | Effect Monster | 3000/1500 DARK Fiend Lv8 | Trigger (hand): if a card you control is destroyed, Special Summon this from hand. Trigger (on Summon): discard 1 to destroy 1 card on the field. Trigger (GY, End Phase): if destroyed this turn, Special Summon it again. |
| Abare Ushioni | Effect Monster | 1200/1200 EARTH Beast-Warrior Lv4 | Ignition, once/turn: coin toss - win inflicts 1000 to opponent, lose deals 1000 to self |
| Absorbing Jar | Effect Monster (FLIP) | 600/500 EARTH Rock Lv3 | FLIP: destroy all Set Spell/Traps, each player draws 1 per their own card destroyed this way, no one can Set this turn |
| Absorbing Kid from the Sky | Effect Monster | 1300/1000 LIGHT Fairy Lv4 | Trigger: destroys a monster by battle → gain LP = its Level × 300 |

Counts: 2 copies each except Abominable Unchained Soul (1 copy, Lv8 boss). Main deck
total grows from 44 to 67 cards. Artwork dropped into `assets/cards/` matching each
card's id (`absolute_king_megaplunder.jpg`, `absolute_king_back_jack.jpg`,
`absolute_crusader.jpg`, `abaki.jpg`, `a_man_with_wdjat.jpg`, `ad_changer.jpg`,
`a_team_trap_disposal.jpg`, `a_assault_core.jpg`, `abominable_unchained_soul.jpg`,
`abare_ushioni.jpg`, `absorbing_jar.jpg`, `absorbing_kid_from_sky.jpg`). Added
`DINOSAUR` to the `Race` enum for Megaplunder.

### v1 simplifications introduced this session (documented in code comments too)
- **A-Assault Core**: its real card is a Union monster (equip to a LIGHT Machine for a
  shared-stats + "unaffected by opponent's monster effects, redirect destruction to this
  card instead" protection package, unequip to Special Summon itself back). The engine
  has no equip-tracking or effect-immunity subsystem, so this was simplified to a
  straightforward Ignition ATK buff that captures the "support unit empowers a Machine
  ally" flavor without the full equip mechanic.
- **Absolute King Back Jack / A/D Changer** GY effects are reachable only via the
  reactive priority-response prompt (like a Trap), not a tappable Graveyard browser -
  there's no GY-card-picker UI yet.
- **A Man with Wdjat**'s "look at a Set card" is logged as a reveal only; the card is
  conceptually picked up and returned to the exact same hidden position, so no actual
  board state changes (matches the real card text, which is non-destructive anyway).
- **Abominable Unchained Soul**'s End Phase revival drops the "place it on the bottom of
  the Deck when it leaves the field again" clause - would need a redirect hook on every
  removal pathway (destroy/tribute/banish) for one card's niche downside clause.

---

## Session 5 — Coin Toss "Call It," Card-Appear/Preview Animation, Pinned Hand, Menu Scroll Fix, 15 More Cards

### Bug fixes
- **Testing Area button was unreachable**: `MainMenuScreen` centered its content in a
  plain `Box` with no scroll, so on a short screen the third menu button could render
  partly or fully below the visible/tappable area. Wrapped the menu in
  `verticalScroll` so all three buttons are always reachable.
- **Hand required scrolling to reach**: the whole left column (opponent field, phase
  bar, your field, your hand) was one big `verticalScroll` `Column`, so a tall field
  pushed the hand below the fold. Split it: opponent panel + phase bar + your field
  now scroll together in their own `Column`, while `PlayerHandRow` is pinned right
  below that, outside the scroll - the hand is always visible without scrolling no
  matter how much field state stacks up above it.

### Coin toss now asks you to call it
- Abare Ushioni's coin toss previously just auto-rolled a result with no input from the
  player. It now properly asks **"Call it! Heads or Tails?"** via a new
  `CoinCallDialog`, exactly like the genre's real coin-call mechanic - resolution only
  happens after you pick a side.
- Added a proper engine-level request/resume mechanism for this
  (`GameState.pendingCoinCall` / `GameEngine.pendingCoinCallResume` /
  `GameEngine.requestCoinCall` / `GameViewModel.callCoinToss`), modeled directly on the
  existing discard-request pattern (`pendingDiscard`/`requestDiscard`/`confirmDiscard`).
  `resolveChain()` now also pauses on `pendingCoinCall`, not just `pendingDiscard`.
- After the player calls a side, a `CoinFlipOverlay` plays a brief flicker-between-faces
  animation (suggesting a spinning coin) before settling on the true result, then shows
  "Called Heads/Tails - right!/wrong!". The animation is cosmetic only - same pattern as
  the existing attack flash: the actual LP change already happened in engine state by
  the time the animation plays.
- This is a reusable mechanism now, not Abare-Ushioni-specific - any future "call a coin
  toss" card just calls `engine.requestCoinCall(...)` from its `resolve` lambda.

### Card-appear and preview animations ("just appears instantly" fixed)
- Added `AnimatedCardSlot` (`CardView.kt`) - a drop-in wrapper around `CardView` using
  Compose's `AnimatedContent`, keyed by `CardInstance.instanceId`. Every monster zone,
  Spell/Trap zone, and Field Zone (both players) now fades + scales a card in when it
  appears and fades + scales it out when it leaves, instead of popping in/out instantly.
  Hand cards intentionally keep plain `CardView` - they reorder too often in their
  `LazyRow` for an appear/disappear fade to read as meaningful there.
- The full-art card preview overlay (shown on summon/activate, or via "🔍 View Card")
  now fades + scales in/out via `AnimatedVisibility` instead of popping instantly.
  Fixed a related bug along the way: reading the live (already-nulled) preview state
  from inside the exit transition would have faded out an *empty* box instead of the
  card - now caches the last non-null card so the correct artwork fades out.

### 15 new cards added
| Card | Type | Stats | Effect |
|---|---|---|---|
| Adamancipator Crystal - Dragite | Effect Monster | 0/2200 WATER Rock Lv4 | Trigger: Special Summoned → draw 1 |
| Adamancipator Analyzer | Effect Monster | 1500/700 EARTH Rock Lv4 | Trigger (hand): you control none, opponent controls 1+ → Special Summon self. Ignition: excavate top 5, Special Summon 1 Lv4-or-lower Rock found, rest to bottom of Deck |
| Achichi @Ignister | Effect Monster | 800/800 FIRE Cyberse Lv2 | Trigger: Normal/Special Summoned → add 1 Lv4-or-lower Cyberse from Deck to hand |
| Abyssrhine, the Atlantean Spirit | Effect Monster | 1600/1600 WATER Aqua Lv3 | Quick (GY, opponent's turn): banish self + discard 1 → draw 1 |
| Abyss Soldier | Effect Monster | 1800/1300 WATER Aqua Lv4 | Ignition: discard 1 WATER monster → bounce any 1 field card to hand |
| Acorno | Effect Monster | 200/400 EARTH Plant Lv1 | Ignition (hand): discard 1 card → Special Summon self from hand |
| Abyss Flower | Normal Monster | 750/400 EARTH Plant Lv2 | - |
| Abyssal Kingshark | Effect Monster | 1700/600 WATER Fish Lv4 | Once/turn: survives non-battle destruction |
| Abyss Shark | Effect Monster | 1200/700 WATER Fish Lv5 | Trigger (hand): all your monsters WATER → Special Summon self, search a Lv3-5 Fish, restricts your Special Summons to WATER the rest of the turn |
| Achacha Chanbara | Effect Monster | 1400/400 FIRE Warrior Lv3 | Trigger (hand): a Spell/Trap/Monster effect is activated (either turn) → Special Summon self, inflict 400 damage |
| Absorouter Dragon | Effect Monster | 1200/2800 DARK Dragon Lv7 | Trigger (hand): you control another DARK Dragon → Special Summon self. Trigger (GY): destroyed → draw 1 |
| Acid Crawler | Normal Monster | 900/700 EARTH Insect Lv3 | - |
| Ad Libitum of Despia | Effect Monster | 1500/2000 DARK Fairy Lv8 | Ignition: all monsters on the field gain ATK = Level x 100 until end of turn |
| Abyss Warrior | Effect Monster | 1800/1300 WATER Aqua Lv4 | Ignition: discard 1 WATER monster → return 1 GY monster (either side) to top of Deck |
| Achacha Archer | Effect Monster | 1200/600 FIRE Warrior Lv3 | Trigger: Normal/Flip Summoned → inflict 500 damage |

Counts: 2 copies each except Ad Libitum of Despia (1 copy, Lv8 boss). Main deck total
grows from 67 to 96 cards. Added `FISH` and `CYBERSE` to the `Race` enum.

### New reusable engine mechanics added to support these
- `GameEngine.returnToHand(card)` / `returnToDeck(card, toTop)` / `addFromDeckToHand(player, predicate)`
  - generic helpers for "bounce to hand," "return to top/bottom of Deck," and
    "search the Deck for X, add to hand" effects (several of this batch's cards need
    one of these; previously only Graveyard/banish had dedicated helpers).
- `PlayerField.specialSummonRestriction: Attribute?` - "you can only Special Summon
  [Attribute] monsters for the rest of this turn" (Abyss Shark), enforced inside
  `specialSummon()`. Cleared every turn boundary alongside `cannotSetCardsThisTurn`.
- `canActivateEffect` now also allows **Ignition**-timing Monster effects to activate
  from **hand** (previously Ignition effects required already being face-up on the
  field). Needed for Acorno's "discard 1; Special Summon this card from your hand"
  - a real and fairly common card pattern (hand-activated abilities), not a one-off
    hack. Existing Ignition monster effects are unaffected: each one's own
    `canActivate` already explicitly checks `Location.MONSTER_ZONE`, so this is purely
    additive/opt-in per effect.
- The Trigger-effect hand/Graveyard scanning added last session is what several of
  this batch's "Special Summon this card from your hand when X happens" effects
  (Adamancipator Analyzer, Abyss Shark, Achacha Chanbara, Absorouter Dragon) ride on -
  no further engine changes needed there.

### v1 simplifications introduced this session
- **Adamancipator Crystal - Dragite / Analyzer**: no Synchro Summon mechanic exists in
  this engine, so all Synchro-specific clauses (treating the Crystal as a Tuner target,
  etc.) are dropped; only the excavate/Special-Summon-condition portions are kept.
- **Achichi @Ignister**: drops its "banish from GY to destroy your own battling Cyberse
  monster at the start of the Damage Step" clause - this engine has no separate Damage
  Step sub-phase to hook into.
- **Abyssrhine, the Atlantean Spirit**: drops its archetype-specific (Mermail/Atlantean)
  tribute-search effect entirely - no such cards exist in this pool yet.
- **Acorno**: the real card discards a specific named card ("Pinecono"); genericized to
  discarding any 1 card, since no such card exists in this pool.
- **Abyssal Kingshark**: drops the "does not target it" qualifier - protects against any
  non-battle (effect) destruction once per turn, hardcoded directly in `destroyCard()`
  rather than as a new generic subsystem, since it's the only card that needs it so far.
- **Abyss Shark**: drops all Xyz/"Number"-monster-specific clauses (no Xyz mechanic
  exists here either).
- **Achacha Chanbara**: drops the "will inflict damage when it resolves" qualifier -
  fires on any Spell/Trap/Monster effect activation, not just damage-dealing ones.
- **Absorouter Dragon**: the real card searches a "Rokket" monster on GY-send; replaced
  with a plain draw 1, since no Rokket cards exist in this pool.
- **Ad Libitum of Despia**: duration shortened to "until the end of this turn" instead
  of "until the end of the opponent's turn" - the latter would need a different reset
  hook than the per-turn one `atkModifier` already uses everywhere else (A-Assault Core,
  Crimson War Wyrm, etc.), and would behave inconsistently for buffs applied to the
  opponent's own monsters specifically. Also drops its archetype-specific (Despia)
  Fusion-material-reuse second effect.
- **Abyss Warrior**: auto-picks "top of the Deck" instead of offering a top/bottom
  choice (no UI for that kind of choice yet).

---

## Session 6 — Full Field UI Overhaul (GBA-style layout)

The whole `GameScreen` layout was rebuilt from scratch in response to feedback that the
UI looked cramped and didn't read like a real duel screen (referencing *Yu-Gi-Oh!
Ultimate Masters: World Championship Tournament 2006*'s GBA UI as the target feel).
Cross-checked phase names/structure against the current official Yu-Gi-Oh! TCG rulebook
("Game mechanics" overview) to make sure terminology (Draw/Standby/Main 1/Battle/Main
2/End Phase) stayed accurate through the redesign.

### What changed
- **Bigger cards**: `CardWidth`/`CardHeight` went from 48×66dp to 58×80dp (~30% more
  area), with the placeholder text and DEF badge font sizes bumped up to match. The
  full-art preview overlay also grew, from 170×245dp to 190×270dp.
- **Removed the permanent side column.** The old layout split the screen into a field
  column (1.7 weight) and a log+action column (1 weight) side by side - on a phone-width
  screen that squeezed the 5-zone rows into less space than they needed, which is what
  was clipping content in the Spell/Trap row. The field now uses the **full screen
  width**, single column.
- **Field Zone moved out of the row into a compact HUD badge.** It's a rarely-used zone
  (only one Field Spell exists in this pool) and a full card-sized slot for it was
  crowding out the 5 primary zones. It's now a small "🌍 [card name]" chip next to each
  player's LP, tap it for a full preview. It was never tappable for any other purpose
  before (Field Spells activate from hand, not from the zone), so nothing was lost.
- **New GBA-style phase tracker.** Replaced the plain text phase line with a segmented
  strip - six chips (Draw / Standby / Main 1 / Battle / Main 2 / End), the current one
  highlighted gold, the rest dimmed - sitting above the turn's action button(s). Visually
  tracks where you are in the turn at a glance instead of just reading it off as text.
- **Log moved off-screen into a 📜 button.** It used to be a permanently-docked panel
  eating a third of the screen at all times; now it's a dialog opened on demand, freeing
  that space for the field.
- **Action panel is now a contextual bottom sheet, not a permanent column.** Tapping a
  card animates a panel in (expand + fade) right below your own field, showing its name/
  stats/description and action buttons; it animates back out when you deselect. When
  nothing's selected, that space collapses to zero, so the field + hand get the full
  screen. This is the closest analogue to the GBA games' pop-up command menu the engine
  supports without building true floating per-card menus.
- The hand stays pinned at the bottom (from last session) and is unaffected by the
  action sheet's height - the sheet lives inside the *scrollable* upper area, while the
  hand sits outside it, so the hand never moves or gets pushed off-screen no matter how
  many action buttons a card has.

### Note on the referenced game
Didn't use any assets from *Ultimate Masters* itself (or the Joey Wheeler coin image
sent earlier) - those are Konami-licensed. The rebuild takes the *layout idea* (segmented
phase tracker, full-width field, contextual command menu) and reimplements it with this
project's own palette/components.
