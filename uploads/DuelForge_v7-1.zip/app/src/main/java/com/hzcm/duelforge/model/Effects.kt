package com.hzcm.duelforge.model

import com.hzcm.duelforge.engine.GameEngine

typealias EffectCondition = (engine: GameEngine, source: CardInstance) -> Boolean
typealias EffectCost      = (engine: GameEngine, source: CardInstance) -> Boolean
typealias TargetSelector  = (engine: GameEngine, source: CardInstance) -> List<CardInstance>
typealias EffectResolve   = (engine: GameEngine, source: CardInstance, targets: List<CardInstance>) -> Unit
typealias StatBonus = (engine: GameEngine, source: CardInstance, target: CardInstance) -> Int

data class CardEffect(
    val id: String,
    val timing: EffectTiming,
    val description: String,
    val oncePerTurn: Boolean = false,
    val canActivate: EffectCondition,
    val targetSelector: TargetSelector? = null,
    val payCost: EffectCost? = null,
    val resolve: EffectResolve,
    val atkBonus: StatBonus? = null,
    val defBonus: StatBonus? = null,
    /** CONTINUOUS: return true if [source] being face-up on the field blocks [attacker] from attacking. */
    val blocksAttack: ((engine: GameEngine, source: CardInstance, attacker: CardInstance) -> Boolean)? = null,
    /** CONTINUOUS: return true if [source] itself cannot be destroyed by battle. */
    val indestructibleByBattle: ((engine: GameEngine, source: CardInstance) -> Boolean)? = null,
)
