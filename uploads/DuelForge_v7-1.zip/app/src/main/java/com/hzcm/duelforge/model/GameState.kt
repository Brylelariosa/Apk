package com.hzcm.duelforge.model

/** Everything that belongs to one player's side of the field. */
class PlayerField {
    val hand: MutableList<CardInstance> = mutableListOf()
    val deck: MutableList<CardInstance> = mutableListOf()
    val graveyard: MutableList<CardInstance> = mutableListOf()
    val banished: MutableList<CardInstance> = mutableListOf()
    val extraDeck: MutableList<CardInstance> = mutableListOf()

    val monsterZones: Array<CardInstance?> = arrayOfNulls(5)
    val spellTrapZones: Array<CardInstance?> = arrayOfNulls(5)
    var fieldZone: CardInstance? = null

    var lifePoints: Int = 8000
    var normalSummonsUsed: Int = 0
    var normalSummonsAllowed: Int = 1

    /** True for the rest of the current turn if something (e.g. Absorbing Jar's FLIP
     *  effect) has forbidden this player from Setting any cards. Cleared every turn
     *  boundary by [com.hzcm.duelforge.engine.GameEngine.endTurn]. */
    var cannotSetCardsThisTurn: Boolean = false

    /** When non-null, this player can only Special Summon monsters of this Attribute for
     *  the rest of the current turn (e.g. Abyss Shark's "cannot Special Summon monsters,
     *  except WATER monsters"). Cleared every turn boundary. */
    var specialSummonRestriction: Attribute? = null

    /** When true, this player cannot Special Summon any monsters this turn (e.g. after Scapegoat). */
    var specialSummonBlocked: Boolean = false

    fun monsters(): List<CardInstance> = monsterZones.filterNotNull()
    fun spellsAndTraps(): List<CardInstance> = spellTrapZones.filterNotNull()
    fun allFieldCards(): List<CardInstance> =
        monsters() + spellsAndTraps() + listOfNotNull(fieldZone)

    fun firstEmptyMonsterZone(): Int? = monsterZones.indices.firstOrNull { monsterZones[it] == null }
    fun firstEmptySpellTrapZone(): Int? = spellTrapZones.indices.firstOrNull { spellTrapZones[it] == null }
}

/** One link in the chain - a single effect activation waiting to resolve, LIFO order. */
data class ChainLink(
    val source: CardInstance,
    val effect: CardEffect,
    val controller: PlayerId,
    val targets: List<CardInstance> = emptyList()
)

/**
 * A description of "what just happened" used by Trigger / Quick effects to decide whether
 * they can respond. The engine updates [GameState.lastEvent] before opening a priority window.
 */
sealed class GameEvent {
    object None : GameEvent()
    data class NormalSummon(val card: CardInstance) : GameEvent()
    data class SpecialSummon(val card: CardInstance) : GameEvent()
    data class FlipSummon(val card: CardInstance) : GameEvent()
    data class SpellActivated(val card: CardInstance) : GameEvent()
    data class TrapActivated(val card: CardInstance) : GameEvent()
    data class MonsterEffectActivated(val card: CardInstance) : GameEvent()
    data class AttackDeclared(val attacker: CardInstance, val target: CardInstance?) : GameEvent()
    data class Destroyed(val card: CardInstance) : GameEvent()
    data class PhaseChanged(val phase: Phase) : GameEvent()
}

/**
 * Sent to the UI when an effect needs the human player to call a coin toss before it's
 * flipped (e.g. Abare Ushioni). Stored in [GameState.pendingCoinCall]; cleared after
 * [GameViewModel.callCoinToss].
 */
enum class CoinSide { HEADS, TAILS }

val CoinSide.displayName: String get() = if (this == CoinSide.HEADS) "Heads" else "Tails"

data class CoinCallRequest(
    val player: PlayerId,
    val reason: String
)

/** The outcome of a resolved coin toss, kept around just long enough for the UI to
 *  play a flip animation landing on [landed] before clearing it. */
data class CoinFlipReveal(
    val called: CoinSide,
    val landed: CoinSide,
    val won: Boolean
)

/**
 * Sent to the UI when an effect needs the human player to pick card(s) to discard.
 * Stored in [GameState.pendingDiscard]; cleared after [GameViewModel.confirmDiscard].
 */
data class DiscardRequest(
    val player: PlayerId,
    val count: Int,
    val reason: String
)

/** Top-level mutable state for an entire duel. */
class GameState {
    val fields: Map<PlayerId, PlayerField> = mapOf(
        PlayerId.PLAYER to PlayerField(),
        PlayerId.AI to PlayerField()
    )

    var turnPlayer: PlayerId = PlayerId.PLAYER
    var turnCount: Int = 1
    var phase: Phase = Phase.DRAW

    /** The active chain stack. Index 0 = first link activated (resolves last). */
    val chain: MutableList<ChainLink> = mutableListOf()

    var lastEvent: GameEvent = GameEvent.None

    val log: MutableList<String> = mutableListOf()
    var winner: PlayerId? = null
    var gameOver: Boolean = false

    /** When non-null the UI must show a priority prompt for the human player. */
    var pendingHumanPriority: PriorityPrompt? = null

    /**
     * When non-null, an effect is waiting for the human player to choose [DiscardRequest.count]
     * card(s) to discard. The UI shows a hand-picker; [GameViewModel.confirmDiscard] resumes
     * chain resolution after the player commits.
     */
    var pendingDiscard: DiscardRequest? = null

    /**
     * When non-null, an effect is waiting for the human player to call Heads or Tails
     * before a coin toss resolves. The UI shows a call-it prompt;
     * [GameViewModel.callCoinToss] resumes chain resolution after the player picks a side.
     */
    var pendingCoinCall: CoinCallRequest? = null

    /** Set the instant a coin toss resolves, so the UI can play a brief flip animation
     *  landing on the true result; consumed (set back to null) by [GameViewModel] right
     *  after it captures it for the animation overlay. */
    var lastCoinFlip: CoinFlipReveal? = null

    /** Set by Waboku: the player protected from battle damage and battle destruction this turn. */
    var wabokuProtectedPlayer: PlayerId? = null

    /** True once the player has manually drawn during their Draw Phase this turn. */
    var drawDone: Boolean = false

    /** When true, all Special Summons for the field owner are blocked this turn (e.g. after Scapegoat). */
    // Per-player SS block tracked in PlayerField.specialSummonBlocked

    fun field(p: PlayerId): PlayerField = fields.getValue(p)

    fun addLog(message: String) {
        log.add(message)
        if (log.size > 200) log.removeAt(0)
    }
}

/**
 * Data the UI needs to ask the human player "you may respond with X, Y, or pass".
 * [optionEffects] are aligned with [optionLabels] by index.
 */
data class PriorityPrompt(
    val optionLabels: List<String>,
    val optionSources: List<CardInstance>,
    val optionEffects: List<CardEffect>,
    val reason: String
)
