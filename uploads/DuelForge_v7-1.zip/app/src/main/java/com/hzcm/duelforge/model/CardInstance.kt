package com.hzcm.duelforge.model

/**
 * A specific physical copy of a [Card] as it exists during a duel. Two copies of the
 * same Card in a deck get two different CardInstances with different [instanceId]s.
 */
class CardInstance(
    val instanceId: String,
    val card: Card,
    var owner: PlayerId,
    var controller: PlayerId
) {
    var location: Location = Location.DECK
    var zoneIndex: Int? = null

    // Battle state (monsters only)
    var battlePosition: BattlePosition = BattlePosition.ATTACK
    var faceUp: Boolean = true
    var hasAttackedThisTurn: Boolean = false
    var positionChangedThisTurn: Boolean = false
    var turnEnteredField: Int = -1

    /** The turnCount during which this card was last destroyed via [com.hzcm.duelforge.engine.GameEngine.destroyCard]
     *  (-1 if never, or not since being reshuffled/redrawn). Used by "if this card was
     *  destroyed this turn..." effects like Abominable Unchained Soul's End Phase revival. */
    var turnDestroyedOnField: Int = -1

    /** When true, a Trap Set this turn ignores the normal "can't activate the turn it was
     *  Set" restriction (e.g. Absolute King Back Jack's excavation effect explicitly lets
     *  the Set card "be activated during this turn"). Cleared every turn boundary. */
    var ignoreSetTurnRestriction: Boolean = false

    // Temporary stat modifiers, cleared at End Phase by the engine for "until end of turn" effects
    var atkModifier: Int = 0
    var defModifier: Int = 0

    // Once-per-turn effect usage tracking, keyed by effect id
    val effectUsedThisTurn: MutableSet<String> = mutableSetOf()

    // Counters used by some effects (e.g. extra attacks granted this turn)
    var extraAttacksAllowed: Int = 0

    /** General-purpose persistent counter used by Swords of Revealing Light (turn expiry)
     *  and similar cards. NOT cleared each turn - managed by the specific effect. */
    var effectCounter: Int = 0

    /** Set by Counter Trap effects (e.g. Negation Barrier) on the chain link's source
     *  before it resolves, to negate (and usually destroy) the activation. */
    var isNegated: Boolean = false

    val effectiveAtk: Int get() = ((card.atk ?: 0) + atkModifier).coerceAtLeast(0)
    val effectiveDef: Int get() = ((card.def ?: 0) + defModifier).coerceAtLeast(0)

    /** A trap can't be activated the turn it was Set - unless [ignoreSetTurnRestriction] grants an exception. */
    fun canActivateAsTrap(currentTurn: Int): Boolean =
        card.cardType == CardType.TRAP && location == Location.SPELL_TRAP_ZONE &&
            (ignoreSetTurnRestriction || turnEnteredField < currentTurn)

    fun resetForNewTurn() {
        hasAttackedThisTurn = false
        positionChangedThisTurn = false
        atkModifier = 0
        defModifier = 0
        extraAttacksAllowed = 0
        isNegated = false
        ignoreSetTurnRestriction = false
        effectUsedThisTurn.clear()
    }

    /** Human-readable label for logs / UI. */
    override fun toString(): String = card.name
}
