package com.hzcm.duelforge.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.hzcm.duelforge.data.EffectRegistry
import com.hzcm.duelforge.engine.*
import com.hzcm.duelforge.model.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// GBA-inspired palette: deep navy field mat, gold accents for the active phase/selection.
private val BgColor     = Color(0xFF0A1424)
private val MatColor    = Color(0xFF112338)
private val PanelColor  = Color(0xFF152C46)
private val AccentGold  = Color(0xFFE8B339)
private val DimChip     = Color(0xFF1C3550)

@Composable
fun GameScreen(
    viewModel: GameViewModel = viewModel(),
    onOpenDebug: () -> Unit = {}
) {
    val engine = viewModel.engine
    @Suppress("UNUSED_EXPRESSION")
    viewModel.refresh
    val state = engine.state

    var showLog by remember { mutableStateOf(false) }

    val hasSelection = viewModel.selectedCard != null ||
        viewModel.tributeSelection != null ||
        viewModel.attackerSelection != null

    Box(modifier = Modifier.fillMaxSize().background(BgColor)) {
        // ── Fixed-height field layout (no scroll) ─────────────────────
        Column(modifier = Modifier.fillMaxSize().padding(horizontal = 4.dp, vertical = 2.dp)) {
            OpponentHud(engine, viewModel, onLogClick = { showLog = true }, onOpenDebug = onOpenDebug)
            Spacer(modifier = Modifier.height(2.dp))
            OpponentFieldRows(engine, viewModel)
            Spacer(modifier = Modifier.height(2.dp))
            PhaseTrackerBar(viewModel)
            Spacer(modifier = Modifier.height(2.dp))
            PlayerFieldRows(engine, viewModel)
            Spacer(modifier = Modifier.height(2.dp))
            PlayerHud(engine, viewModel)
            Spacer(modifier = Modifier.height(3.dp))
            PlayerHandRow(engine, viewModel)
        }

        // ── ActionSheet overlays at bottom when card selected ─────────
        AnimatedVisibility(
            visible = hasSelection,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = expandVertically(tween(180)) + fadeIn(tween(180)),
            exit = shrinkVertically(tween(140)) + fadeOut(tween(120))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(BgColor.copy(alpha = 0.95f))
                    .padding(4.dp)
            ) {
                ActionSheet(viewModel)
            }
        }

        // ── Overlays (drawn on top of everything) ──────────────────────
        if (showLog) LogDialog(state) { showLog = false }
        state.pendingHumanPriority?.let { prompt -> PriorityDialog(prompt, viewModel) }
        state.pendingDiscard?.let { req -> DiscardDialog(req, viewModel) }
        state.pendingCoinCall?.let { req -> CoinCallDialog(req, viewModel) }
        if (state.gameOver) GameOverOverlay(state, viewModel)

        // Phase popup (centered card-style)
        viewModel.phasePopupText?.let { text -> PhasePopupOverlay(text) }

        // Attack indicator (who attacks whom)
        viewModel.attackIndicator?.let { text -> AttackIndicatorOverlay(text) }

        // Card break/destroy animation
        viewModel.destroyAnimCard?.let { card -> CardBreakOverlay(card) }

        viewModel.coinFlipReveal?.let { reveal ->
            CoinFlipOverlay(reveal, onDone = { viewModel.dismissCoinFlipReveal() })
        }

        val previewCard = viewModel.previewCard
        var cachedPreviewCard by remember { mutableStateOf(previewCard) }
        if (previewCard != null) cachedPreviewCard = previewCard
        AnimatedVisibility(
            visible = previewCard != null,
            enter = fadeIn(tween(180)) + scaleIn(initialScale = 0.85f, animationSpec = tween(180)),
            exit = fadeOut(tween(150)) + scaleOut(targetScale = 0.9f, animationSpec = tween(150))
        ) {
            cachedPreviewCard?.let { card ->
                CardPreviewOverlay(
                    card = card,
                    autoDismiss = viewModel.previewAutoShow,
                    onDismiss = { viewModel.dismissPreview() }
                )
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// HUD bars - LP, deck/GY/banished counts, Field Spell badge, log/debug buttons
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun OpponentHud(
    engine: GameEngine,
    vm: GameViewModel,
    onLogClick: () -> Unit,
    onOpenDebug: () -> Unit
) {
    val field = engine.state.field(PlayerId.AI)
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            DeckPile(deckSize = field.deck.size)
            Spacer(modifier = Modifier.width(4.dp))
            Column {
                Text("OPPONENT", color = Color(0xFF7E96B5), fontSize = 7.sp, fontWeight = FontWeight.Bold)
                Text("LP ${field.lifePoints}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
            Spacer(modifier = Modifier.width(4.dp))
            FieldSpellBadge(field.fieldZone, vm)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "GY:${field.graveyard.size} ✦${field.banished.size}",
                color = Color(0xFF7E96B5), fontSize = 7.sp
            )
            Spacer(modifier = Modifier.width(4.dp))
            HudIconButton("📜", onLogClick)
            Spacer(modifier = Modifier.width(2.dp))
            HudIconButton("⚙", onOpenDebug)
        }
    }
}

@Composable
private fun PlayerHud(engine: GameEngine, vm: GameViewModel) {
    val field = engine.state.field(PlayerId.PLAYER)
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            DeckPile(deckSize = field.deck.size)
            Spacer(modifier = Modifier.width(4.dp))
            Column {
                Text("YOU", color = Color(0xFF7E96B5), fontSize = 7.sp, fontWeight = FontWeight.Bold)
                Text("LP ${field.lifePoints}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
            Spacer(modifier = Modifier.width(4.dp))
            FieldSpellBadge(field.fieldZone, vm)
        }
        Text(
            "GY:${field.graveyard.size} ✦${field.banished.size}",
            color = Color(0xFF7E96B5), fontSize = 7.sp
        )
    }
}

@Composable
private fun HudIconButton(icon: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(26.dp)
            .background(PanelColor, RoundedCornerShape(6.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(icon, fontSize = 12.sp)
    }
}

@Composable
private fun FieldSpellBadge(fieldZone: CardInstance?, vm: GameViewModel) {
    if (fieldZone == null) return
    Box(
        modifier = Modifier
            .background(Color(0xFF2E6B3E), RoundedCornerShape(5.dp))
            .clickable { if (fieldZone.faceUp) vm.showFieldPreview(fieldZone) }
            .padding(horizontal = 6.dp, vertical = 3.dp)
    ) {
        Text(
            "🌍 ${fieldZone.card.name}",
            color = Color.White,
            fontSize = 8.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.widthIn(max = 110.dp)
        )
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Field rows - 5 monster zones + 5 Spell/Trap zones, full width, no Field Zone
// slot here (it's shown as a compact badge in the HUD row instead, since it's
// rarely used and a full card-sized slot for it crowds out the primary zones).
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun OpponentFieldRows(engine: GameEngine, vm: GameViewModel) {
    val field = engine.state.field(PlayerId.AI)
    Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
            for (i in 0..4) {
                AnimatedCardSlot(instance = field.spellTrapZones[i])
            }
        }
        Spacer(modifier = Modifier.height(3.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
            for (i in 0..4) {
                val cardInst = field.monsterZones[i]
                AnimatedCardSlot(
                    instance = cardInst,
                    selected = vm.attackerSelection != null && cardInst != null,
                    onClick = cardInst?.let { c -> { vm.onOpponentMonsterTapped(c) } }
                )
            }
        }
    }
}

@Composable
private fun PlayerFieldRows(engine: GameEngine, vm: GameViewModel) {
    val field = engine.state.field(PlayerId.PLAYER)
    Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
            for (i in 0..4) {
                val cardInst = field.monsterZones[i]
                AnimatedCardSlot(
                    instance = cardInst,
                    revealFaceDown = true,
                    selected = isSelected(cardInst, vm),
                    onClick = cardInst?.let { c -> { vm.onOwnMonsterTapped(c) } }
                )
            }
        }
        Spacer(modifier = Modifier.height(3.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
            for (i in 0..4) {
                val cardInst = field.spellTrapZones[i]
                AnimatedCardSlot(
                    instance = cardInst,
                    revealFaceDown = true,
                    selected = isSelected(cardInst, vm),
                    onClick = cardInst?.let { c -> { vm.onOwnSpellTrapTapped(c) } }
                )
            }
        }
    }
}

@Composable
private fun PlayerHandRow(engine: GameEngine, vm: GameViewModel) {
    val field = engine.state.field(PlayerId.PLAYER)
    LazyRow(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
        items(field.hand) { cardInst ->
            CardView(
                instance = cardInst,
                revealFaceDown = true,
                selected = isSelected(cardInst, vm),
                onClick = { vm.onHandCardTapped(cardInst) }
            )
        }
    }
}

@Composable
private fun DeckPile(deckSize: Int) {
    if (deckSize == 0) return
    Box(modifier = Modifier.size(26.dp, 36.dp), contentAlignment = Alignment.BottomEnd) {
        CardBack(modifier = Modifier.fillMaxSize())
        Box(
            modifier = Modifier
                .size(15.dp)
                .background(Color(0xCC000000), RoundedCornerShape(3.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(deckSize.toString(), color = Color.White, fontSize = 7.sp, fontWeight = FontWeight.Bold)
        }
    }
}

private fun isSelected(card: CardInstance?, vm: GameViewModel): Boolean {
    if (card == null) return false
    if (vm.selectedCard === card) return true
    if (vm.attackerSelection === card) return true
    if (vm.tributeSelection?.chosen?.contains(card) == true) return true
    if (vm.discardChosen.contains(card)) return true
    return false
}

// ─────────────────────────────────────────────────────────────────────────────
// Phase tracker bar - GBA-style segmented phase strip + turn/phase controls
// ─────────────────────────────────────────────────────────────────────────────

private val PHASE_ORDER = listOf(
    Phase.DRAW to "Draw",
    Phase.STANDBY to "Standby",
    Phase.MAIN1 to "Main 1",
    Phase.BATTLE to "Battle",
    Phase.MAIN2 to "Main 2",
    Phase.END to "End"
)

@Composable
private fun PhaseTrackerBar(vm: GameViewModel) {
    val state = vm.engine.state
    val displayPhase = if (state.phase == Phase.BATTLE_START) Phase.BATTLE else state.phase

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(MatColor, RoundedCornerShape(6.dp))
            .border(1.dp, Color(0xFF24405E), RoundedCornerShape(6.dp))
            .padding(horizontal = 4.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        // Phase chips
        Row(modifier = Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            PHASE_ORDER.forEach { (phase, label) ->
                val isCurrent = phase == displayPhase
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .background(if (isCurrent) AccentGold else DimChip, RoundedCornerShape(3.dp))
                        .padding(vertical = 3.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        label,
                        fontSize = 7.sp,
                        fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                        color = if (isCurrent) Color(0xFF1A1300) else Color(0xFF6E84A0),
                        maxLines = 1
                    )
                }
            }
        }

        // Action buttons
        val canAdvance = state.turnPlayer == PlayerId.PLAYER && !state.gameOver &&
            state.chain.isEmpty() && state.pendingHumanPriority == null

        when {
            state.phase == Phase.DRAW && state.turnPlayer == PlayerId.PLAYER && canAdvance -> {
                if (!vm.playerHasDrawnThisTurn) {
                    PhaseBtn(if (state.turnCount == 1) "No Draw" else "Draw ✦") { vm.drawCard() }
                } else {
                    PhaseBtn("Proceed ▶") { vm.advancePhase() }
                }
            }
            state.phase == Phase.MAIN1 && canAdvance -> {
                PhaseBtn("⚔") { vm.goToBattlePhase() }
                PhaseBtn("M2") { vm.skipToMainPhase2() }
                PhaseBtn("End") { vm.endTurnNow() }
            }
            state.phase == Phase.BATTLE && canAdvance -> {
                PhaseBtn("Main 2 ▶") { vm.advancePhase() }
            }
            state.phase == Phase.MAIN2 && canAdvance -> {
                PhaseBtn("End Turn") { vm.endTurnNow() }
            }
            else -> {
                Button(
                    onClick = { vm.advancePhase() },
                    enabled = canAdvance,
                    modifier = Modifier.height(28.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                ) {
                    Text(
                        when {
                            state.turnPlayer == PlayerId.AI -> "…"
                            state.phase == Phase.END -> "End Turn"
                            else -> "Next ▶"
                        },
                        fontSize = 9.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun PhaseBtn(label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = modifier.height(32.dp),
        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)
    ) { Text(label, fontSize = 9.sp) }
}

// ─────────────────────────────────────────────────────────────────────────────
// Log dialog - duel history, opened via the 📜 button instead of a permanent panel
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun LogDialog(state: GameState, onDismiss: () -> Unit) {
    val listState = rememberLazyListState()
    LaunchedEffect(Unit) {
        if (state.log.isNotEmpty()) listState.scrollToItem(state.log.size - 1)
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Duel Log") },
        text = {
            LazyColumn(state = listState, modifier = Modifier.heightIn(max = 420.dp)) {
                items(state.log) { line ->
                    Text(line, color = Color(0xFFCCCCCC), fontSize = 11.sp, lineHeight = 14.sp)
                }
            }
        },
        confirmButton = { Button(onClick = onDismiss) { Text("Close") } }
    )
}

// ─────────────────────────────────────────────────────────────────────────────
// Action sheet - replaces the old permanent side panel. Only rendered (via
// AnimatedVisibility, in GameScreen) when something is actually selected, so
// the field gets full space the rest of the time.
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun ActionSheet(vm: GameViewModel) {
    val engine = vm.engine
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(PanelColor, RoundedCornerShape(8.dp))
            .border(1.dp, AccentGold.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
            .padding(10.dp)
    ) {
        val tribute  = vm.tributeSelection
        val attacker = vm.attackerSelection
        val card     = vm.selectedCard

        when {
            tribute  != null -> TributePanel(vm, tribute)
            attacker != null -> AttackerPanel(vm, engine, attacker)
            card     != null -> CardActionPanel(vm, engine, card)
        }
    }
}

@Composable
private fun TributePanel(vm: GameViewModel, tribute: TributeSelection) {
    val action = if (tribute.asSet) "Set" else "Normal Summon"
    Text(
        "$action ${tribute.card.card.name}: choose ${tribute.required} tribute(s) " +
        "(${tribute.chosen.size}/${tribute.required})",
        color = Color.White, fontSize = 12.sp
    )
    Spacer(modifier = Modifier.height(6.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(
            onClick = { vm.confirmTributeSummon() },
            enabled = tribute.chosen.size == tribute.required
        ) { Text("Confirm") }
        Button(onClick = { vm.cancelTributeSummon() }) { Text("Cancel") }
    }
}

@Composable
private fun AttackerPanel(vm: GameViewModel, engine: GameEngine, attacker: CardInstance) {
    Text("${attacker.card.name} attacking", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    Spacer(modifier = Modifier.height(6.dp))
    if (engine.canDeclareAttack(attacker, null)) {
        Text("No opponent monsters — attack directly?", color = Color.LightGray, fontSize = 11.sp)
        Spacer(modifier = Modifier.height(6.dp))
        Button(onClick = { vm.declareDirectAttack() }) { Text("⚔ Attack Directly") }
    } else {
        Text("Tap one of your opponent's monsters to attack it.", color = Color.LightGray, fontSize = 11.sp)
    }
}

@Composable
private fun CardActionPanel(vm: GameViewModel, engine: GameEngine, card: CardInstance) {
    Row(verticalAlignment = Alignment.Top) {
        Column(modifier = Modifier.weight(1f)) {
            Text(card.card.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            if (card.card.isMonster) {
                Text(
                    "Lv${card.card.level ?: 0}  ${card.card.attribute?.name ?: ""} " +
                    "${card.card.race?.name?.replace('_', ' ') ?: ""}  " +
                    "ATK ${card.card.atk ?: 0} / DEF ${card.card.def ?: 0}",
                    color = AccentGold, fontSize = 10.sp, fontWeight = FontWeight.Bold
                )
            }
        }
        if (card.faceUp) {
            Button(
                onClick = { vm.showFieldPreview(card) },
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                modifier = Modifier.height(30.dp)
            ) { Text("🔍 View", fontSize = 10.sp) }
        }
    }

    Spacer(modifier = Modifier.height(4.dp))
    Text(
        card.card.description,
        color = Color(0xFFCBD5E1), fontSize = 11.sp, lineHeight = 14.sp,
        maxLines = 4, overflow = TextOverflow.Ellipsis
    )
    Spacer(modifier = Modifier.height(8.dp))

    when (card.location) {
        Location.HAND             -> HandCardActions(vm, engine, card)
        Location.MONSTER_ZONE     -> FieldMonsterActions(vm, engine, card)
        Location.SPELL_TRAP_ZONE  -> SpellTrapZoneActions(vm, engine, card)
        else -> Text("No actions available.", color = Color.Gray, fontSize = 10.sp)
    }
}

@Composable
private fun HandCardActions(vm: GameViewModel, engine: GameEngine, card: CardInstance) {
    FlowButtons {
        if (card.card.isMonster) {
            if (engine.canNormalSummon(card)) {
                val tribNote = if (card.card.tributesRequired > 0) " (${card.card.tributesRequired} trib)" else ""
                ActionButton("Normal Summon$tribNote") { vm.beginSummon(false) }
                if (engine.canSetMonster(card)) {
                    ActionButton("Set (face-down)$tribNote") { vm.beginSummon(true) }
                }
            }
        }
        if ((card.card.isSpell || card.card.isTrap) && engine.canSetSpellOrTrap(card)) {
            ActionButton("Set face-down") { vm.setTrap() }
        }
        for (effect in EffectRegistry.effectsFor(card.card.id)) {
            if (engine.canActivateEffect(card, effect)) {
                ActionButton("Activate: ${effect.description}") { vm.activateEffect(effect) }
            }
        }
    }
}

@Composable
private fun FieldMonsterActions(vm: GameViewModel, engine: GameEngine, card: CardInstance) {
    FlowButtons {
        if (engine.canFlipSummon(card)) {
            ActionButton("Flip Summon") { vm.flipSummon() }
        }
        val opposite = if (card.battlePosition == BattlePosition.ATTACK) BattlePosition.DEFENSE else BattlePosition.ATTACK
        if (engine.canChangeBattlePosition(card, opposite)) {
            val label = if (opposite == BattlePosition.ATTACK) "→ Attack Pos" else "→ Defense Pos"
            ActionButton(label) { vm.changeBattlePosition(opposite) }
        }
        for (effect in EffectRegistry.effectsFor(card.card.id)) {
            if (engine.canActivateEffect(card, effect)) {
                ActionButton("Activate: ${effect.description}") { vm.activateEffect(effect) }
            }
        }
    }
}

@Composable
private fun SpellTrapZoneActions(vm: GameViewModel, engine: GameEngine, card: CardInstance) {
    FlowButtons {
        for (effect in EffectRegistry.effectsFor(card.card.id)) {
            if (engine.canActivateEffect(card, effect)) {
                ActionButton("Activate: ${effect.description}") { vm.activateEffect(effect) }
            }
        }
    }
    if (!card.faceUp) {
        val hint = when {
            card.card.isTrap  -> "Set Trap — activates during opponent's turn."
            card.card.isSpell -> "Set Spell — tap Activate on your turn."
            else -> ""
        }
        if (hint.isNotEmpty()) {
            Spacer(modifier = Modifier.height(4.dp))
            Text(hint, color = Color(0xFF8899AA), fontSize = 10.sp)
        }
    }
}

@Composable
private fun FlowButtons(content: @Composable () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) { content() }
}

@Composable
private fun ActionButton(label: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp)
    ) {
        Text(label, fontSize = 11.sp)
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Priority dialog
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun PriorityDialog(prompt: PriorityPrompt, vm: GameViewModel) {
    AlertDialog(
        onDismissRequest = {},
        title = { Text("Respond?") },
        text = {
            Column {
                Text(prompt.reason, fontSize = 11.sp)
                Spacer(modifier = Modifier.height(8.dp))
                prompt.optionLabels.forEachIndexed { index, label ->
                    Button(
                        onClick = { vm.submitPriorityChoice(index) },
                        modifier = Modifier.padding(vertical = 2.dp).fillMaxWidth()
                    ) { Text(label, fontSize = 10.sp) }
                }
            }
        },
        confirmButton = {
            Button(onClick = { vm.submitPriorityChoice(null) }) { Text("Pass") }
        }
    )
}

// ─────────────────────────────────────────────────────────────────────────────
// Discard dialog
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun DiscardDialog(req: DiscardRequest, vm: GameViewModel) {
    val hand = vm.engine.state.field(req.player).hand
    AlertDialog(
        onDismissRequest = {},
        title = { Text("Discard ${req.count} card${if (req.count > 1) "s" else ""}") },
        text = {
            Column {
                Text(req.reason, fontSize = 10.sp, color = Color.LightGray)
                Spacer(modifier = Modifier.height(8.dp))
                Text("Tap to select (${vm.discardChosen.size}/${req.count}):", fontSize = 9.sp, color = Color.Gray)
                Spacer(modifier = Modifier.height(4.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    items(hand) { card ->
                        CardView(
                            instance = card,
                            revealFaceDown = true,
                            selected = vm.discardChosen.contains(card),
                            onClick = { vm.onDiscardCardToggled(card) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { vm.confirmDiscard() },
                enabled = vm.discardChosen.size == req.count
            ) { Text("Discard") }
        }
    )
}

// ─────────────────────────────────────────────────────────────────────────────
// Coin call dialog — "Call it: Heads or Tails?" (Abare Ushioni and similar effects)
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun CoinCallDialog(req: CoinCallRequest, vm: GameViewModel) {
    AlertDialog(
        onDismissRequest = {},
        title = { Text("Call it!") },
        text = {
            Column {
                Text(req.reason, fontSize = 11.sp, color = Color.LightGray)
                Spacer(modifier = Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { vm.callCoinToss(CoinSide.HEADS) },
                        modifier = Modifier.weight(1f)
                    ) { Text("Heads") }
                    Button(
                        onClick = { vm.callCoinToss(CoinSide.TAILS) },
                        modifier = Modifier.weight(1f)
                    ) { Text("Tails") }
                }
            }
        },
        confirmButton = {}
    )
}

// ─────────────────────────────────────────────────────────────────────────────
// Coin flip reveal overlay — animated flip landing on the already-resolved result
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun CoinFlipOverlay(reveal: CoinFlipReveal, onDone: () -> Unit) {
    var displayedSide by remember(reveal) { mutableStateOf(reveal.called) }
    var settled by remember(reveal) { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (settled) 1.18f else 1f,
        animationSpec = tween(220),
        label = "coinScale"
    )

    LaunchedEffect(reveal) {
        repeat(12) {
            displayedSide = if (displayedSide == CoinSide.HEADS) CoinSide.TAILS else CoinSide.HEADS
            delay(70L)
        }
        displayedSide = reveal.landed
        settled = true
        delay(1500L)
        onDone()
    }

    Box(
        modifier = Modifier.fillMaxSize().background(Color(0xCC000000)),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier
                    .size(100.dp)
                    .scale(scale)
                    .background(
                        Brush.radialGradient(listOf(Color(0xFFFFE9A8), Color(0xFFC9971F))),
                        CircleShape
                    )
                    .border(4.dp, Color(0xFF8A6418), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    if (displayedSide == CoinSide.HEADS) "H" else "T",
                    fontSize = 40.sp,
                    fontWeight = FontWeight.Black,
                    color = Color(0xFF4A3300)
                )
            }
            Spacer(modifier = Modifier.height(14.dp))
            Text(
                if (!settled) "Flipping..." else "${reveal.landed.displayName}!",
                color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp
            )
            if (settled) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    "Called ${reveal.called.displayName} — " + if (reveal.won) "right!" else "wrong!",
                    color = if (reveal.won) Color(0xFF66E28A) else Color(0xFFFF6B6B),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Phase popup overlay — card-style banner shown briefly when phase changes
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun PhasePopupOverlay(text: String) {
    val isEnemy = text.startsWith("ENEMY")
    val isPlayer = text.startsWith("YOUR")
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Box(
            modifier = Modifier
                .background(
                    if (isEnemy) Color(0xCC4A0A0A) else Color(0xCC0A2A4A),
                    RoundedCornerShape(12.dp)
                )
                .border(2.dp, if (isEnemy) Color(0xFFAA3333) else AccentGold, RoundedCornerShape(12.dp))
                .padding(horizontal = 28.dp, vertical = 14.dp)
        ) {
            Text(
                text,
                color = if (isEnemy) Color(0xFFFF8888) else AccentGold,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Attack indicator overlay — shows who attacked whom (replaces animation)
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun AttackIndicatorOverlay(text: String) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Box(
            modifier = Modifier
                .background(Color(0xCC000000), RoundedCornerShape(8.dp))
                .border(1.dp, Color(0xFF884422), RoundedCornerShape(8.dp))
                .padding(horizontal = 18.dp, vertical = 10.dp)
        ) {
            Text("⚔  $text", color = Color(0xFFFFAA44), fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Card break overlay — shatter animation when a card is destroyed
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun CardBreakOverlay(card: CardInstance) {
    val scale = remember { androidx.compose.animation.core.Animatable(1f) }
    val alpha = remember { androidx.compose.animation.core.Animatable(1f) }
    val rotation = remember { androidx.compose.animation.core.Animatable(0f) }

    LaunchedEffect(card) {
        // Flash red then shatter
        launch { scale.animateTo(1.15f, tween(150)) }
        delay(150L)
        launch { rotation.animateTo(15f, tween(300)) }
        launch { scale.animateTo(0f, tween(500)) }
        launch { alpha.animateTo(0f, tween(600)) }
    }

    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .graphicsLayer {
                    scaleX = scale.value
                    scaleY = scale.value
                    this.alpha = alpha.value
                    rotationZ = rotation.value
                }
        ) {
            Box(
                modifier = Modifier
                    .size(CardWidth * 1.6f, CardHeight * 1.6f)
                    .background(Color(0xFFCC2222), RoundedCornerShape(8.dp))
                    .border(3.dp, Color(0xFFFF4444), RoundedCornerShape(8.dp))
                    .padding(4.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("💥", fontSize = 28.sp)
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                card.card.name,
                color = Color(0xFFFF6666),
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp
            )
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Card preview overlay
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun CardPreviewOverlay(
    card: CardInstance,
    autoDismiss: Boolean,
    onDismiss: () -> Unit
) {
    if (autoDismiss) {
        LaunchedEffect(card) {
            delay(2200L)
            onDismiss()
        }
    }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xCC000000))
            .clickable { onDismiss() },
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(modifier = Modifier.size(190.dp, 270.dp)) {
                val context = LocalContext.current
                val bitmap  = remember(card.card.imageId) {
                    ImageLoader.loadCardImage(context, card.card.imageId)
                }
                if (bitmap != null) {
                    Image(
                        bitmap = bitmap.asImageBitmap(),
                        contentDescription = card.card.name,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Fit
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(cardTypeColor(card.card), RoundedCornerShape(10.dp))
                            .padding(12.dp)
                    ) {
                        Column {
                            Text(card.card.name, color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(card.card.description, color = Color.DarkGray, fontSize = 11.sp, lineHeight = 13.sp)
                            if (card.card.isMonster) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    "ATK ${card.card.atk ?: 0} / DEF ${card.card.def ?: 0}",
                                    color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp
                                )
                            }
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                if (autoDismiss) "Tap to dismiss (auto-closes shortly)" else "Tap to dismiss",
                color = Color(0xFFBBBBBB), fontSize = 10.sp
            )
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Game over overlay
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun GameOverOverlay(state: GameState, vm: GameViewModel) {
    Box(
        modifier = Modifier.fillMaxSize().background(Color(0xCC000000)),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            val winnerText = when (state.winner) {
                PlayerId.PLAYER -> "You Win! 🎉"
                PlayerId.AI     -> "Opponent Wins!"
                null            -> "Duel Over"
            }
            Text(winnerText, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 28.sp)
            Spacer(modifier = Modifier.height(16.dp))
            Button(onClick = { vm.restart() }) { Text("New Duel") }
        }
    }
}
