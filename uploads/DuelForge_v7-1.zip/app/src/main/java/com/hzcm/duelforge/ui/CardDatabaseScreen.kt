package com.hzcm.duelforge.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hzcm.duelforge.data.CardDatabase
import com.hzcm.duelforge.data.EffectRegistry
import com.hzcm.duelforge.model.*

private val DbBg      = Color(0xFF0A1628)
private val DbPanel   = Color(0xFF12213A)
private val DbAccent  = Color(0xFFD4A017)
private val DbTextDim = Color(0xFFB0BEC5)

/**
 * Read-only browser over every card defined in cards.json + EffectRegistry. Pure UI - it
 * doesn't touch a [com.hzcm.duelforge.engine.GameEngine] or mutate anything, so it's safe
 * to open from the main menu independent of any duel in progress.
 */
@Composable
fun CardDatabaseScreen(onExit: () -> Unit) {
    val context = LocalContext.current
    val cardDb = remember { CardDatabase.getInstance(context) }
    val allCards = remember(cardDb) { cardDb.allCards().sortedBy { it.name } }

    var query by remember { mutableStateOf("") }
    var typeFilter by remember { mutableStateOf<CardType?>(null) }
    var selected by remember { mutableStateOf<Card?>(null) }

    val filtered = allCards.filter { card ->
        (typeFilter == null || card.cardType == typeFilter) &&
            (query.isBlank() || card.name.contains(query, ignoreCase = true))
    }

    Box(modifier = Modifier.fillMaxSize().background(DbBg)) {
        Column(modifier = Modifier.fillMaxSize().padding(8.dp)) {
            // ── Header: title, count, search, exit ──────────────────────────
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Text("📖 Card Database", color = DbAccent, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(Modifier.width(10.dp))
                Text("${filtered.size}/${allCards.size} cards", color = DbTextDim, fontSize = 9.sp)
                Spacer(Modifier.weight(1f))
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text("Search…", fontSize = 10.sp) },
                    singleLine = true,
                    modifier = Modifier.width(150.dp).height(48.dp),
                    textStyle = TextStyle(fontSize = 11.sp, color = Color.White)
                )
                Spacer(Modifier.width(8.dp))
                SmallTextButton("← Exit", Color(0xFF8B3A3A), onExit)
            }
            Spacer(Modifier.height(6.dp))

            // ── Type filter chips ────────────────────────────────────────────
            Row(verticalAlignment = Alignment.CenterVertically) {
                FilterChip("All", typeFilter == null) { typeFilter = null }
                Spacer(Modifier.width(4.dp))
                FilterChip("Monster", typeFilter == CardType.MONSTER) { typeFilter = CardType.MONSTER }
                Spacer(Modifier.width(4.dp))
                FilterChip("Spell", typeFilter == CardType.SPELL) { typeFilter = CardType.SPELL }
                Spacer(Modifier.width(4.dp))
                FilterChip("Trap", typeFilter == CardType.TRAP) { typeFilter = CardType.TRAP }
            }
            Spacer(Modifier.height(6.dp))

            // ── Grid ──────────────────────────────────────────────────────────
            if (filtered.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No cards match \"$query\".", color = DbTextDim, fontSize = 11.sp)
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 84.dp),
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(filtered, key = { it.id }) { card ->
                        CardGridItem(card) { selected = card }
                    }
                }
            }
        }

        selected?.let { card -> CardDetailOverlay(card, cardDb) { selected = null } }
    }
}

@Composable
private fun SmallTextButton(label: String, color: Color, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .background(color, RoundedCornerShape(4.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Text(label, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun FilterChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .background(if (selected) DbAccent else DbPanel, RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(label, color = if (selected) Color.Black else DbTextDim, fontSize = 9.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun CardGridItem(card: Card, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .clickable(onClick = onClick)
            .background(DbPanel, RoundedCornerShape(6.dp))
            .padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        DbThumbnail(card, modifier = Modifier.size(76.dp, 104.dp))
        Spacer(Modifier.height(3.dp))
        Text(
            card.name, color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold,
            maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
            lineHeight = 9.sp
        )
        if (card.isMonster) {
            Text("${card.atk ?: 0}/${card.def ?: 0}", color = Color(0xFFFFDD88), fontSize = 7.sp)
        } else {
            Text(if (card.isSpell) "SPELL" else "TRAP", color = Color(0xFF99AABB), fontSize = 7.sp)
        }
    }
}

@Composable
private fun DbThumbnail(card: Card, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val bitmap = remember(card.imageId) { ImageLoader.loadCardImage(context, card.imageId) }
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(5.dp))
            .border(1.dp, Color(0xFF444444), RoundedCornerShape(5.dp))
            .background(dbTypeColor(card))
    ) {
        if (bitmap != null) {
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = card.name,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        } else {
            Column(modifier = Modifier.fillMaxSize().padding(4.dp), verticalArrangement = Arrangement.SpaceBetween) {
                Text(
                    card.name, color = Color.Black, fontSize = 7.sp, fontWeight = FontWeight.Bold,
                    lineHeight = 8.sp, maxLines = 3, overflow = TextOverflow.Ellipsis
                )
                if (card.isMonster) {
                    Text("Lv${card.level ?: 0}", color = Color(0xFF222222), fontSize = 6.sp)
                }
            }
        }
    }
}

private fun dbTypeColor(card: Card): Color = when (card.cardType) {
    CardType.MONSTER -> when (card.monsterCategory) {
        MonsterCategory.NORMAL -> Color(0xFFE8C77A)
        MonsterCategory.EFFECT -> Color(0xFFE8915A)
        MonsterCategory.FUSION -> Color(0xFFC79BE8)
        null                   -> Color(0xFFE8C77A)
    }
    CardType.SPELL -> Color(0xFF7FBF7F)
    CardType.TRAP  -> Color(0xFFE07FA8)
}

// ──────────────────────────────────────────────────────────────────────────────
// Detail overlay - tap a card to see full art, full text, and registered effects.
// Dismiss by tapping the "✕" or anywhere on the dark backdrop outside the panel.
// ──────────────────────────────────────────────────────────────────────────────

@Composable
private fun CardDetailOverlay(card: Card, cardDb: CardDatabase, onDismiss: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xCC000000))
            .clickable(onClick = onDismiss),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .padding(20.dp)
                .background(DbPanel, RoundedCornerShape(10.dp))
                // Swallow taps here so clicking the panel itself doesn't trigger the
                // backdrop's onDismiss above (Compose hit-testing would otherwise let the
                // tap fall through to the parent's clickable).
                .clickable(enabled = false) {}
                .padding(16.dp)
        ) {
            Column {
                Row(modifier = Modifier.fillMaxWidth()) {
                    Spacer(Modifier.weight(1f))
                    SmallTextButton(label = "✕", color = Color(0xFF8B3A3A), onClick = onDismiss)
                }
                Spacer(Modifier.height(4.dp))
                Row {
                    DbThumbnail(card, modifier = Modifier.size(110.dp, 152.dp))
                    Spacer(Modifier.width(16.dp))
                    Column(
                        modifier = Modifier
                            .widthIn(max = 260.dp)
                            .heightIn(max = 260.dp)
                            .verticalScroll(rememberScrollState())
                    ) {
                        Text(card.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Spacer(Modifier.height(4.dp))
                        Text(detailTypeLine(card), color = DbAccent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        if (card.isMonster) {
                            Spacer(Modifier.height(2.dp))
                            Text(
                                "ATK ${card.atk ?: 0}  /  DEF ${card.def ?: 0}",
                                color = Color(0xFFFFDD88), fontSize = 11.sp, fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(card.description, color = Color(0xFFCCCCCC), fontSize = 10.sp, lineHeight = 13.sp)

                        val effects = EffectRegistry.effectsFor(card.id)
                        if (effects.isNotEmpty()) {
                            Spacer(Modifier.height(8.dp))
                            Text("Registered effects:", color = DbTextDim, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            effects.forEach { eff ->
                                Text(
                                    "• [${eff.timing.name}] ${eff.description}",
                                    color = Color(0xFF99AABB), fontSize = 9.sp, lineHeight = 11.sp
                                )
                            }
                        }

                        Spacer(Modifier.height(8.dp))
                        val count = cardDb.countOf(card.id)
                        Text(
                            "${if (card.isExtraDeck) "Extra Deck" else "Main Deck"} • x$count copy",
                            color = Color(0xFF667788), fontSize = 8.sp
                        )
                    }
                }
            }
        }
    }
}

private fun detailTypeLine(card: Card): String = when (card.cardType) {
    CardType.MONSTER -> {
        val cat = card.monsterCategory?.name ?: "NORMAL"
        "Lv${card.level ?: 0}  ${card.attribute?.name ?: ""}  ${card.race?.name?.replace('_', ' ') ?: ""}  [$cat]"
    }
    CardType.SPELL -> "SPELL  •  ${card.spellType?.name?.replace('_', ' ') ?: "NORMAL"}"
    CardType.TRAP  -> "TRAP  •  ${card.trapType?.name?.replace('_', ' ') ?: "NORMAL"}"
}
