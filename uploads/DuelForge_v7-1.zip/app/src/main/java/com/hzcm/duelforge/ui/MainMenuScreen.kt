package com.hzcm.duelforge.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val MenuBg     = Color(0xFF0A1628)
private val AccentGold = Color(0xFFD4A017)
private val AccentBlue = Color(0xFF3A7BD5)
private val CardDark   = Color(0xFF12213A)
private val TextGray   = Color(0xFFB0BEC5)

@Composable
fun MainMenuScreen(
    onStartDuel: () -> Unit,
    onCardDatabase: () -> Unit,
    onTestingArea: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF0A1628), Color(0xFF091020))
                )
            )
            .verticalScroll(rememberScrollState()),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(0.dp)
        ) {

            // ── Logo / Title ──────────────────────────────────────────
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "⚔",
                    fontSize = 48.sp,
                    color = AccentGold
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = "DUEL FORGE",
                    fontSize = 32.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = AccentGold,
                    letterSpacing = 4.sp
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "Card Duel Engine",
                    fontSize = 13.sp,
                    color = TextGray,
                    fontStyle = FontStyle.Italic,
                    letterSpacing = 2.sp
                )
            }

            Spacer(Modifier.height(40.dp))

            // ── Menu Card ────────────────────────────────────────────
            Box(
                modifier = Modifier
                    .width(280.dp)
                    .background(CardDark, RoundedCornerShape(16.dp))
                    .padding(24.dp)
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {

                    MenuButton(
                        label = "⚔  Start Duel",
                        description = "Face the AI in a full duel",
                        primary = true,
                        onClick = onStartDuel
                    )

                    Divider(
                        color = Color(0xFF1E3050),
                        thickness = 1.dp,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )

                    MenuButton(
                        label = "📖  Card Database",
                        description = "Browse all available cards",
                        primary = false,
                        onClick = onCardDatabase
                    )

                    MenuButton(
                        label = "🔧  Testing Area",
                        description = "Debug tools and effect tester",
                        primary = false,
                        onClick = onTestingArea
                    )
                }
            }

            Spacer(Modifier.height(32.dp))

            // ── Footer ───────────────────────────────────────────────
            Text(
                text = "v2.3 • HZCM",
                fontSize = 10.sp,
                color = Color(0xFF3A5070),
                letterSpacing = 1.sp
            )
        }
    }
}

@Composable
private fun MenuButton(
    label: String,
    description: String,
    primary: Boolean,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .height(64.dp),
        shape = RoundedCornerShape(10.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (primary) AccentBlue else Color(0xFF1A2D4A)
        ),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = label,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = if (primary) Color.White else AccentGold
            )
            Text(
                text = description,
                fontSize = 10.sp,
                color = if (primary) Color(0xFFBBCCDD) else TextGray,
                textAlign = TextAlign.Center
            )
        }
    }
}
