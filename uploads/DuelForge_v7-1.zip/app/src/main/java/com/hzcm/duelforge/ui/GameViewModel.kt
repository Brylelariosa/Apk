package com.hzcm.duelforge.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.hzcm.duelforge.engine.*
import com.hzcm.duelforge.model.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

data class TributeSelection(
    val card: CardInstance,
    val asSet: Boolean,
    val required: Int,
    val chosen: List<CardInstance> = emptyList()
)

class GameViewModel(application: Application) : AndroidViewModel(application) {
    val engine: GameEngine = GameEngine(application.applicationContext)

    var refresh by mutableIntStateOf(0)
        private set

    var selectedCard by mutableStateOf<CardInstance?>(null)
        private set

    var tributeSelection by mutableStateOf<TributeSelection?>(null)
        private set

    var attackerSelection by mutableStateOf<CardInstance?>(null)

    var discardChosen by mutableStateOf<List<CardInstance>>(emptyList())
        private set

    var previewCard by mutableStateOf<CardInstance?>(null)
        private set

    var previewAutoShow by mutableStateOf(false)
        private set

    var attackFlash by mutableStateOf(false)

    var coinFlipReveal by mutableStateOf<CoinFlipReveal?>(null)
        private set

    // ── New state ──────────────────────────────────────────────────────

    /** True once the player has manually drawn this turn. Reset each new player turn. */
    var playerHasDrawnThisTurn by mutableStateOf(false)
        private set

    /** Card currently playing its break/destroy animation. Auto-cleared after delay. */
    var destroyAnimCard by mutableStateOf<CardInstance?>(null)
        private set

    /** Brief text overlay showing who attacked whom. */
    var attackIndicator by mutableStateOf<String?>(null)
        private set

    /** Phase name popup (centered card-like overlay). */
    var phasePopupText by mutableStateOf<String?>(null)
        private set

    // ──────────────────────────────────────────────────────────────────

    fun dismissCoinFlipReveal() { coinFlipReveal = null }

    init {
        // Hook into engine callbacks
        engine.onCardDestroyedCallback = { card ->
            destroyAnimCard = card
            viewModelScope.launch {
                delay(900L)
                destroyAnimCard = null
            }
        }
        engine.onPhaseChangedCallback = { phase, turnPlayer ->
            val who = if (turnPlayer == PlayerId.PLAYER) "YOUR" else "ENEMY"
            phasePopupText = when (phase) {
                Phase.DRAW       -> "$who DRAW PHASE"
                Phase.STANDBY    -> "$who STANDBY PHASE"
                Phase.MAIN1      -> "$who MAIN PHASE 1"
                Phase.BATTLE_START, Phase.BATTLE -> "$who BATTLE PHASE"
                Phase.MAIN2      -> "$who MAIN PHASE 2"
                Phase.END        -> "$who END PHASE"
            }
            viewModelScope.launch {
                delay(1200L)
                phasePopupText = null
            }
        }
        engine.onAttackDeclaredCallback = { attacker, target ->
            val targetName = target?.card?.name ?: "directly"
            attackIndicator = "${attacker.card.name}  →  $targetName"
            viewModelScope.launch {
                delay(1600L)
                attackIndicator = null
            }
        }

        engine.startGame()
        // Turn 1 player has no draw
        playerHasDrawnThisTurn = true
        refresh++
    }

    private fun bump() { refresh++ }

    // ------------------------------------------------------------------
    // Preview overlay
    // ------------------------------------------------------------------

    fun showSummonPreview(card: CardInstance) {
        previewCard = card
        previewAutoShow = true
    }

    fun showFieldPreview(card: CardInstance) {
        previewCard = card
        previewAutoShow = false
    }

    fun dismissPreview() {
        previewCard = null
        previewAutoShow = false
    }

    // ------------------------------------------------------------------
    // Selection
    // ------------------------------------------------------------------

    fun clearSelection() {
        selectedCard = null
        tributeSelection = null
        attackerSelection = null
    }

    fun onHandCardTapped(card: CardInstance) {
        if (tributeSelection != null) return
        attackerSelection = null
        selectedCard = if (selectedCard === card) null else card
    }

    fun onOwnMonsterTapped(card: CardInstance) {
        if (tributeSelection != null) {
            toggleTribute(card); return
        }
        if (engine.state.phase == Phase.BATTLE) {
            selectedCard = null
            attackerSelection = if (attackerSelection === card) null else card
            return
        }
        attackerSelection = null
        selectedCard = if (selectedCard === card) null else card
    }

    fun onOwnSpellTrapTapped(card: CardInstance) {
        if (tributeSelection != null) return
        attackerSelection = null
        selectedCard = if (selectedCard === card) null else card
    }

    fun onOpponentMonsterTapped(card: CardInstance) {
        val attacker = attackerSelection ?: return
        if (!engine.canDeclareAttack(attacker, card)) return
        attackerSelection = null
        engine.declareAttack(attacker, card) { bump() }
        bump()
    }

    // ------------------------------------------------------------------
    // Summon / Set / Flip / Position
    // ------------------------------------------------------------------

    fun beginSummon(asSet: Boolean) {
        val card = selectedCard ?: return
        val required = card.card.tributesRequired
        if (required > 0) {
            tributeSelection = TributeSelection(card, asSet, required); return
        }
        val summoned = card
        if (asSet) {
            engine.setMonster(card, emptyList()) { bump() }
        } else {
            engine.normalSummon(card, emptyList()) {
                showSummonPreview(summoned); bump()
            }
        }
        selectedCard = null; bump()
    }

    private fun toggleTribute(card: CardInstance) {
        val sel = tributeSelection ?: return
        if (card.location != Location.MONSTER_ZONE || card.controller != PlayerId.PLAYER) return
        val chosen = sel.chosen.toMutableList()
        if (chosen.contains(card)) chosen.remove(card)
        else if (chosen.size < sel.required) chosen.add(card)
        tributeSelection = sel.copy(chosen = chosen)
    }

    fun confirmTributeSummon() {
        val sel = tributeSelection ?: return
        if (sel.chosen.size != sel.required) return
        val summoned = sel.card
        if (sel.asSet) {
            engine.setMonster(sel.card, sel.chosen) { bump() }
        } else {
            engine.normalSummon(sel.card, sel.chosen) {
                showSummonPreview(summoned); bump()
            }
        }
        tributeSelection = null; selectedCard = null; bump()
    }

    fun cancelTributeSummon() { tributeSelection = null }

    fun setTrap() {
        val card = selectedCard ?: return
        engine.setSpellOrTrap(card) { bump() }
        selectedCard = null; bump()
    }

    fun activateEffect(effect: CardEffect) {
        val card = selectedCard ?: return
        val activated = card
        engine.activateEffect(card, effect) {
            if (activated.card.isSpell || activated.card.isMonster) showSummonPreview(activated)
            bump()
        }
        selectedCard = null; bump()
    }

    fun flipSummon() {
        val card = selectedCard ?: return
        val flipped = card
        engine.flipSummon(card) { showSummonPreview(flipped); bump() }
        selectedCard = null; bump()
    }

    fun changeBattlePosition(newPosition: BattlePosition) {
        val card = selectedCard ?: return
        engine.changeBattlePosition(card, newPosition) { bump() }
        selectedCard = null; bump()
    }

    // ------------------------------------------------------------------
    // Draw (manual)
    // ------------------------------------------------------------------

    /** Player manually draws their card during Draw Phase. */
    fun drawCard() {
        val state = engine.state
        if (state.phase != Phase.DRAW || state.turnPlayer != PlayerId.PLAYER) return
        if (playerHasDrawnThisTurn) return
        // Turn 1: no draw
        if (state.turnCount == 1) {
            playerHasDrawnThisTurn = true
            bump(); return
        }
        engine.drawCards(PlayerId.PLAYER, 1)
        state.drawDone = true
        playerHasDrawnThisTurn = true
        bump()
    }

    // ------------------------------------------------------------------
    // Battle
    // ------------------------------------------------------------------

    fun declareDirectAttack() {
        val attacker = attackerSelection ?: return
        if (!engine.canDeclareAttack(attacker, null)) return
        attackerSelection = null
        engine.declareAttack(attacker, null) { bump() }
        bump()
    }

    // ------------------------------------------------------------------
    // Phase / priority
    // ------------------------------------------------------------------

    fun advancePhase() {
        clearSelection()
        engine.advancePhase {
            if (engine.state.phase == Phase.BATTLE_START) {
                engine.advancePhase { bump() }
                bump()
            } else {
                // If we just arrived at a new player DRAW phase, reset drawn flag
                if (engine.state.phase == Phase.DRAW && engine.state.turnPlayer == PlayerId.PLAYER) {
                    playerHasDrawnThisTurn = false
                }
                bump()
            }
        }
        bump()
    }

    fun goToBattlePhase() {
        clearSelection()
        engine.advancePhase {
            if (engine.state.phase == Phase.BATTLE_START) {
                engine.advancePhase { bump() }
                bump()
            } else { bump() }
        }
        bump()
    }

    fun skipToMainPhase2() {
        clearSelection()
        skipPhasesUntil(Phase.MAIN2, 0)
    }

    /** Directly end turn from any player phase — no need to click twice. */
    fun endTurnNow() {
        clearSelection()
        advanceToEndOfPlayerTurn(0)
    }

    private fun advanceToEndOfPlayerTurn(guard: Int) {
        if (engine.state.gameOver || guard > 14) { bump(); return }
        if (engine.state.chain.isNotEmpty() || engine.state.pendingHumanPriority != null) { bump(); return }
        engine.advancePhase {
            when {
                engine.state.gameOver -> bump()
                // AI's turn just started (during aiRunTurn) — we're done
                engine.state.turnPlayer == PlayerId.AI -> bump()
                // Back to human DRAW phase after AI turn completed
                engine.state.phase == Phase.DRAW && engine.state.turnPlayer == PlayerId.PLAYER -> {
                    playerHasDrawnThisTurn = false
                    bump()
                }
                // Still in human's turn, keep advancing
                else -> advanceToEndOfPlayerTurn(guard + 1)
            }
        }
        bump()
    }

    private fun skipPhasesUntil(target: Phase, guard: Int) {
        if (engine.state.phase == target || engine.state.gameOver || guard >= 10 ||
            engine.state.chain.isNotEmpty() || engine.state.pendingHumanPriority != null
        ) {
            bump(); return
        }
        engine.advancePhase {
            skipPhasesUntil(target, guard + 1)
        }
        bump()
    }

    fun submitPriorityChoice(index: Int?) {
        engine.submitPriorityChoice(index)
        bump()
    }

    fun onDiscardCardToggled(card: CardInstance) {
        val req = engine.state.pendingDiscard ?: return
        val chosen = discardChosen.toMutableList()
        if (chosen.contains(card)) chosen.remove(card)
        else if (chosen.size < req.count) chosen.add(card)
        discardChosen = chosen
    }

    fun confirmDiscard() {
        val callback = engine.pendingDiscardResume ?: return
        val chosen = discardChosen.toList()
        engine.state.pendingDiscard = null
        engine.pendingDiscardResume = null
        discardChosen = emptyList()
        chosen.forEach { engine.sendToGraveyard(it) }
        callback(chosen)
        if (engine.state.chain.isNotEmpty()) engine.resolveChain()
        bump()
    }

    fun callCoinToss(side: CoinSide) {
        val callback = engine.pendingCoinCallResume ?: return
        engine.state.pendingCoinCall = null
        engine.pendingCoinCallResume = null
        callback(side)
        if (engine.state.chain.isNotEmpty()) engine.resolveChain()
        coinFlipReveal = engine.state.lastCoinFlip
        engine.state.lastCoinFlip = null
        bump()
    }

    fun restart() {
        clearSelection()
        discardChosen = emptyList()
        dismissPreview()
        attackFlash = false
        coinFlipReveal = null
        destroyAnimCard = null
        attackIndicator = null
        phasePopupText = null
        engine.startGame()
        // Turn 1: no draw
        playerHasDrawnThisTurn = true
        bump()
    }
}
