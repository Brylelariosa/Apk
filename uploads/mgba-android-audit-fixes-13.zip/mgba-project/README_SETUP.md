# mGBA Android

Built and distributed via GitHub Actions.  
Push this ZIP to your `uploads/` folder in the repo — the workflow handles everything else.

---

## How to build

### Via GitHub Actions (normal workflow)

```
uploads/
└── mgba-android.zip   ← push this file; workflow triggers automatically
```

The workflow:
1. Extracts the ZIP, finds `settings.gradle.kts`
2. Downloads `gradle-wrapper.jar` for Gradle 8.6
3. Installs NDK 25.2.9519653 + CMake 3.22.1
4. Runs `./gradlew assembleDebug`

CMake auto-fetches the mGBA 0.10.3 source from GitHub on the first build
(via `FetchContent_Declare`).  The downloaded source lands in `app/.cxx/`
which the workflow caches, so subsequent builds skip the download entirely.

The APK is uploaded as a workflow artifact (retained 30 days).

### Locally (Android Studio)

1. Clone mGBA alongside the project:
   ```bash
   git clone --depth 1 --branch 0.10.3 https://github.com/mgba-emu/mgba.git mgba-core
   ```
   CMakeLists.txt checks for this folder first and skips the FetchContent download.

2. Open the project in Android Studio (Hedgehog+) and hit Run.

---

## Fixes applied vs the original

| File | Change |
|------|--------|
| `MainActivity.kt` | `catch (e: Throwable)` — was `Exception`, which silently missed `UnsatisfiedLinkError` |
| `MainActivity.kt` | Game loop body wrapped in try/catch; surface-recreate restarts the loop |
| `AndroidManifest.xml` | `android:extractNativeLibs="true"` — required alongside `useLegacyPackaging=true` |
| `mgba_jni.c` | `pthread_mutex_t` guards `g_core`/`g_fb` — eliminates race with `nativeDestroy` |
| `mgba_jni.c` | `core->loadConfig(core)` replaces `mCoreLoadConfig(core)` — opts actually applied now |
| `mgba_jni.c` | Stride-correct pixel copy in `nativeRunFrame` — no more row-shift on padded bitmaps |
| `CMakeLists.txt` | FetchContent fallback auto-downloads mGBA 0.10.3 when no local clone is present |
| `CMakeLists.txt` | `--strip-debug` replaces `--strip-all`; `pthread` added to link targets |
| `app/build.gradle.kts` | Removed `-DM_CORE_GB=ON` (was a no-op; FORCE in CMakeLists always won) |
| `gradle-wrapper.properties` | Gradle 8.6 to match the workflow's hard-coded `GRADLE_VERSION="8.6"` |

### Second pass (this audit)

| File | Change |
|------|--------|
| `AndroidManifest.xml` | `android:extractNativeLibs="true"` is now *actually* declared — the row above claimed this but the attribute was never present in the file; AGP's implicit default happened to match, but the doc/code mismatch was real |
| `MainActivity.kt` | Added `onPause()`/`onResume()` — previously absent entirely, so the emulation thread and `AudioTrack` kept running/playing after the app was backgrounded (battery drain, audio leaking behind other apps) until the `Surface` happened to be destroyed, which isn't prompt or guaranteed |
| `MainActivity.kt` | Added a persistent "📂 Change ROM" button — previously `loadRomBtn` was hidden forever after the first successful load with no other UI path to load a different game; switching titles required force-killing the app |
| `MainActivity.kt` / `LinkMultiplayer.kt` | `BLUETOOTH_CONNECT` is a runtime-dangerous permission on API 31+. It was declared in the manifest but never requested, so tapping "Host — Bluetooth", "Join — Bluetooth", or opening the paired-devices list crashed with an uncaught `SecurityException` on every Android 12+ device. Added `ensureBluetoothPermission()` + a permission launcher that requests it on demand and resumes the action once granted |

**Residual risk from the prior pass — now fixed:** `nativeLoadROM()` used to destroy the previous native core unconditionally *before* attempting to load the new file, so a "Change ROM" attempt on an invalid/corrupt file lost the in-progress session with no fallback. `mgba_jni.c` now builds the new core entirely in local variables (create → init → config → load file → reset → audio setup) and only swaps it into the live globals — destroying the old core — after every step succeeds. Any failure now leaves the current session running untouched.

### Fourth pass — render/audio decoupling (crackle, stutter, and speed wobble)

**Root cause.** Rendering (`lockCanvas`/`drawBitmap`/`unlockCanvasAndPost`) ran on
the *same* thread as `writePcm()`, right after it, every frame. Since the
third pass made the blocking `AudioTrack.write()` call *the frame pacer*
itself, any slow render — a GC pause, a busy compositor, a software-canvas
`SurfaceView` on a budget device — delayed the next audio write too. That's
a buffer underrun heard as a click/pop, and the resulting irregular frame
delivery reads as choppiness or a "speed wobble" even though no individual
sample was actually mispitched. This was identified and explicitly deferred
in the third pass rather than fixed.

**Fix.** `MainActivity.kt` now uses three `Bitmap` buffers instead of one,
ping-ponged so the game thread never writes into a buffer the renderer might
be reading. The renderer moved onto its own `Choreographer.postFrameCallback`
loop — paced by the display's vsync, completely independent of the
audio-locked game thread — so a slow frame draw can no longer stall audio.
`startGameLoop()`/`stopGameLoop()` now start/stop that render loop alongside
the game thread; `stopRenderLoop()` is safe to call from a background thread
(the ROM-reload path does) since it only touches a `@Volatile` flag directly
and defers the actual `Choreographer` call to the main thread.

### Third pass — feature build-out (My Boy!/Pizza Boy/RetroArch-parity roadmap)

**#1 Audio — root-caused and rebuilt, not patched.** The old pipeline paced the
game loop with a fixed `Thread.sleep(1/60s)`, which doesn't match the GBA's real
59.7275 Hz refresh rate, and wrote PCM with `WRITE_NON_BLOCKING` while discarding
the return value — so the ~0.46% surplus this mismatch produced was silently
dropped by AudioTrack every few seconds (a periodic stutter, not the "no sound
at all" the brief assumed — this codebase's audio was never fully silent, just
subtly wrong). Rebuilt as an **audio-locked** loop: PCM is now written with a
genuine blocking `AudioTrack.write()`, and that blocking call *is* the frame
pacer for normal-speed play — no `Thread.sleep()` at all, so no drift can
accumulate. A short fallback sleep (using the *correct* GBA frame period, not
1/60s) only covers frames that produce zero audio. Also added: low-latency
performance mode (API 26+) with a graceful single retry if a device's audio HAL
rejects it, dead-object detection + automatic `AudioTrack` recreation, a
symmetric-channel defensive fix in `mgba_jni.c`'s blip-buffer drain, and a
`flush()` on pause so resuming after a long background period doesn't play a
blip of stale audio. Fast-forward still drops audio outright rather than
pitch-shifting it — a deliberate scope decision (see the in-code comment for
why), not an oversight.

**#2 Control layout editor — new subsystem.** Every on-screen button (D-pad ×4,
A, B, Start, Select, L, R, Fast-Forward) is now individually draggable and
resizable via a corner handle, with a per-button opacity override and lock,
live-previewed over the actual running game and persisted to SharedPreferences
as JSON. Reached from ⚙ Settings → "Edit Button Layout…". Positions are stored
as *fractions* of screen size (not raw pixels) and keyed per orientation, so
the storage format is ready for a future portrait mode even though the
activity is currently locked to landscape. Explicitly out of scope for this
pass (documented in-code rather than silently omitted): per-button rotation/
mirroring, snap-to-guides/alignment grid, and named/duplicatable layout
profiles or true per-game layouts (the latter needs a ROM-identity concept —
hash or path — this codebase doesn't have yet).

### Fifth pass — multiplayer thread-safety, ROM-swap/link-state consistency, unused permissions

This pass focused on `LinkMultiplayer.kt`'s connection-handling internals
(the previous four passes had already covered audio, rendering, ROM-swap
safety, and the control layout editor in depth) plus a couple of
cross-cutting consistency and permission-hygiene issues. `mgba_jni.c` was
read in full against every one of the concerns below and found to already
correctly guard `g_core`/`g_fb` behind a mutex on every entry point
(`nativeRunFrame`, `nativeReadAudioSamples`, `nativeSetKeys`,
`nativeSaveState`/`nativeLoadState`, `nativeDestroy`) — no native changes
were needed this pass.

| File | Change |
|------|--------|
| `LinkMultiplayer.kt` | `dataSocket`/`peerAddr`/`peerDataPort`/`btSocket`/`btIn`/`btOut` are now `@Volatile` |
| `LinkMultiplayer.kt` | `discSocket` now actually tracks the live discovery/broadcast socket and is force-closed on `disconnect()` |
| `LinkMultiplayer.kt` | WIFI `DATA` packets now validate the `seq` byte on receive; an exact-duplicate/stale packet is discarded |
| `LinkMultiplayer.kt` | Added `connectGeneration` token + `btPendingSocket` tracking across all four connect paths (`startWifiHost`, `connectWifi`, `startBluetoothHost`, `connectBluetooth`) and `disconnect()` |
| `MainActivity.kt` | Loading/changing a ROM while linked now calls `stopLink()` first, keeping native SIO state and the Kotlin/UI "Connected" state in agreement |
| `MainActivity.kt` | ROM-load completion callback now checks `isFinishing`/`isDestroyed` before re-initializing audio and starting a new game thread |
| `MainActivity.kt` | Added `backupIfExists()` — a single rolling `.bak` copy made before the battery save is re-mapped or a save-state slot is overwritten |
| `MainActivity.kt` | Added an optional performance overlay (core FPS + `AudioTrack` underrun count), off by default, toggled from ⚙ Settings → Misc |
| `AndroidManifest.xml` | Removed `READ_EXTERNAL_STORAGE` — unused; ROM loading is 100% SAF (`OpenDocument`) |
| `AndroidManifest.xml` | Removed `BLUETOOTH_SCAN` — unused; the app only calls `getBondedDevices()`/RFCOMM connect (needs `BLUETOOTH_CONNECT`), never `startDiscovery()` |
| `gradle.properties` | `android.enableJetifier=false` — no support-lib-namespaced dependency remains to jetify (only `androidx.core`/`androidx.appcompat`, both AndroidX-native) |

**The multiplayer fixes, in plain terms.** All four connection-state fields
above were plain `var`s written on a setup thread (host discovery thread,
client connect thread) and read from `jniExchangeData()` on the native
game-loop thread — a different thread that's frequently already running by
the time a connection completes. Without `@Volatile`, the JMM doesn't
guarantee that thread ever sees the write; worst case, an established link
reads as permanently disconnected. Separately, `showLinkDialog()` never
blocked starting a second connection attempt while a first was still
mid-handshake (it only guards on `isConnected`, not "is connecting"), so a
user backing out and retrying could leave an abandoned attempt's eventual
completion clobbering a newer connection's sockets or firing a callback for
an operation already abandoned — `connectGeneration` closes that gap.
`btPendingSocket` specifically lets `disconnect()` actually cancel a
Bluetooth `connect()` call in progress (which can otherwise block for 10+
seconds) instead of only being able to cancel it after the fact.

**The ROM-swap/link fix, in plain terms.** `mgba_jni.c`'s ROM-swap path
already correctly protects *itself* from a dangling pointer when a new ROM
is loaded mid-link-session (see the second-pass note above) by dropping
`g_link_active`/`g_link_gba` — but it has no way to tell the Kotlin side
this happened, so `link.isConnected` and the "🔗 ✓" button kept claiming
"Connected" after a swap even though the native SIO driver behind it was
gone. `changeRomBtn`/`loadRomBtn` now call `stopLink()` first so both sides
agree.

**Housekeeping note, not a code change:** the very first table above
("Fixes applied vs the original") says pthread was *added* to
`CMakeLists.txt`'s link targets. The current file intentionally omits
`-lpthread` (NDK r18+ folded it into `libc`; explicitly linking it can fail
— see the comment in `CMakeLists.txt`), so that historical row no longer
matches the file as it stands. Left as-is rather than edited, since it was
presumably accurate for whatever pass wrote it; noted here so the
discrepancy doesn't cause confusion later.

See `KNOWN_LIMITATIONS.md` for what was found but deliberately *not*
changed this pass (full out-of-order protection for the Wi-Fi link
protocol, the SIO-exchange/core-mutex interaction, and a couple of
supply-chain follow-ups this sandbox couldn't safely make).

### Sixth pass — SIO protocol correctness (child never answers; status bits never set)

Not summarized here in full — this pass's own `BUGS_FIXED.md`,
`FILE_CHANGES.md`, and `KNOWN_LIMITATIONS.md` sections (each headed "Sixth
pass") are the complete record; this entry is just so the index above
doesn't silently skip a pass. Headline result: a child device never
actually answered the host's link requests (GBATEK: the Start/Busy bit is
read-only for slaves, so a child's own `wifiExchange()`/`btExchange()` was
never being called), and nothing ever set SIOCNT's parent/child or
all-ready status bits, both of which real ROMs check before ever
attempting a transfer. Both fixed. Reported as still not fully working
before this next pass could confirm why — see below.

### Seventh pass — the SIO IRQ was never raised

User report after the sixth pass: still not progressing (tested against
Yu-Gi-Oh! World Championship 2006 and The Legend of Zelda: Four Swords),
plus a sharp diagnostic observation — fast-forward stayed available even
while "Connected" was showing, unlike real hardware/mGBA proper, where an
active link exchange's network round-trip should throttle it.

| File | Change |
|------|--------|
| `mgba_jni.c` | `link_sio_write_register()` (host/parent path) now calls `GBARaiseIRQ(g_link_gba, GBA_IRQ_SIO, 0)` right after finishing a transfer |
| `mgba_jni.c` | `nativeLinkChildExchange()` (child path) now does the same, on its own device's core |

**In plain terms.** FIX 8, back in an earlier pass, already left a note
that this build "doesn't automatically raise the SIO IRQ the way hardware
would... only relevant for a game that waits on that interrupt instead of
polling SIOCNT's Start bit" — flagged as a known gap, not acted on. Games
that wait on the interrupt are not a rare edge case: the standard
GBA-dev idiom taught by every tutorial (Tonc, gbadev) for *any* interrupt
wait, serial included, is BIOS `IntrWait`/`VBlankIntrWait` — enable the bit
in IE, then sleep — specifically because busy-polling wastes battery on
real hardware. A ROM built that way had no bug in the data it received
(the sixth pass's fixes were real and correct); it just never woke back up
to look at it. This also fully explains the fast-forward observation:
an interrupt-driven ROM that already made its one Start-bit write and is
now asleep waiting isn't hitting that write again every frame, so there's
no per-frame blocking network round-trip left to throttle anything —
fast-forward looking normal was itself a symptom, not a separate bug.

This pass confirmed the exact call — `GBARaiseIRQ(gba, GBA_IRQ_SIO, 0)` —
by reading mGBA's actual `src/gba/sio.c` directly rather than guessing from
memory (which is what produced the FIX 7/8 signature mismatches two passes
ago). See the `FIX 10` comment block at the top of `mgba_jni.c` for the
full citation and reasoning, including why it's believed safe for
poll-style ROMs too (they simply never enabled the IE bit that would make
this observable). As with every pass, this could not be compiled or run
against real devices in this environment — see `KNOWN_LIMITATIONS.md`.


### Eighth pass — no fix; added logging, because guessing had stopped working

User re-tested the seventh pass's IRQ fix against both games over both
Wi-Fi and Bluetooth: no change at all. Not "still broken in a new way" —
the exact same symptom (Connected shows, ROM doesn't react, fast-forward
unthrottled) as before that fix. That pattern — a real fix, zero observable
difference — is itself a clue: it's consistent with
`link_sio_write_register()` never being invoked in the first place for
either game, since `GBASIOSetDriver()` only registers this driver for
`SIO_MULTI` mode, and the core swaps its active SIO driver every time the
ROM's own mode bits change. If either ROM's handshake is spending its time
in a different mode, or never gets far enough to reach Multi-Player mode,
nothing from the sixth or seventh pass could ever have been observable —
which fits the data better than "the fix has a subtle bug in it."

Rather than add a fourth speculative protocol theory with no way to check
it from this sandbox, this pass added permanent trace logging instead (see
`mgba_jni.c`'s `FIX 11` comment and `FILE_CHANGES.md`) and is explicitly
waiting on real logcat output before the next pass touches the protocol
logic again. Whether any `"SIO write addr=..."` lines show up under tag
`mGBA-JNI` during a real attempt settles, in one test, a question that
static code reading cannot.

### Ninth pass — found a real, separate bug: Wi-Fi host disconnected on its own

User report this pass distinguished the two transports for the first time:
Wi-Fi connects, then disconnects on its own after a few seconds; Bluetooth
stays connected, but the ROM still doesn't react — the same "Connected but
nothing happens in-game" symptom the eighth pass's logging is waiting on
real logcat to explain.

The Bluetooth half is unchanged and still needs that logcat (see the
eighth pass above — nothing new to add there without it, and this pass
deliberately did not add a fourth protocol theory). But the Wi-Fi half
turned out to be a real, independent, fully-diagnosable-by-reading bug,
found by asking a different question: not "is the SIO protocol correct"
(already checked twice), but "why would Wi-Fi specifically, and not
Bluetooth, drop a connection that both sides agree succeeded?"

| File | Change |
|------|--------|
| `LinkMultiplayer.kt` | New `wifiSocketLock`; `wifiExchange()` now holds it for its send+receive |
| `LinkMultiplayer.kt` | New `drainHostWifiKeepalives()`, called from `startKeepalive()`'s Wi-Fi branch, host role only |

**In plain terms.** The FIX 9 liveness watchdog (sixth pass) only ever
learns the peer is alive when something actually calls
`dataSocket.receive()`. The child role always has that covered —
`startWifiChildResponder()` reads continuously the instant it connects.
The host role didn't: its only other call to `receive()` was buried inside
`wifiExchange()`, which doesn't run until *this device's own ROM* starts
making real SIO transfers. Two ROMs' link-cable menus can easily take
longer than the watchdog's 8-second timeout to navigate to after the
app-level "Connected" already shows — so the host's own keepalive-liveness
check would fire first, on a peer that was never actually gone, and tear
the whole thing down (sending the other phone a BYE in the process, so
both sides drop together — matching what was reported). Bluetooth was
never exposed to this: its reader thread (`startBtReader()`) already runs
for both roles.

Fixed by giving the host role the same kind of always-listening coverage
the child already had, without letting it race a real in-flight SIO
exchange for the same socket — see `wifiSocketLock` and both functions'
own comments in `LinkMultiplayer.kt` for exactly how.

As with every pass, this environment has no Kotlin compiler and no device
to test against (see `KNOWN_LIMITATIONS.md`) — verified by careful reading,
brace/paren balance checking, and tracing every new identifier to its
declaration and use sites, same standard as every prior pass, not by an
actual build or a real link session.

### Audit-fix pass 15 — Zelda: Four Swords still not linking: the link-up search

| File | Change |
|------|--------|
| `cpp/link_timing.h` | the search: a table of 16 transfer lengths, the state machine that counts the game's probe rounds and whether the other phone answered; the header comment has the evidence from both captures |
| `cpp/mgba_jni.c` | the host applies the search's length as its transfer time, feeds each completed transfer to the search, logs `Link sweep:` lines; `Link timing:` and the STAT line gain `sweep=` |
| `link/LinkTiming.kt`, `MainActivitySettingsDialogs.kt` (+ comments in three files) | the setting's text says what Auto does now; no logic changed |

**In plain terms.** Pass 14 made Four Swords' transfers shorter and the game still did not link: the 2 Nov logs show it keeps
sending the same 7-transfer rounds (it just repeats them more often) and the other phone still answers only every second
one. Nobody can tell from two captures which transfer length the game wants, so with **Auto** (the default) the host phone now
**tries 16 different lengths** while the game is on its link screen — about a minute for all of them — keeps the one where the other
phone starts answering every round, and logs what happened at each. Install this build on **both** phones, keep Link timing on
Auto, sit on Four Swords' multiplayer screen for at least 90 s, and send both link logs (▤ menu -> "Link log…") whether or not it
linked. The game runs at roughly half speed over Wi-Fi while it searches. **Not tested on the real game or a phone** — see
`KNOWN_LIMITATIONS.md` and CHANGELOG.md item 39.

Checks: `tools/native-link-test/run_regs.sh` (`test_sio_regs` 206, `test_log` 10, `test_link_timing` 79),
`tools/native-link-test/run_sim.sh` (two simulated phones: 46 + 33), `tools/link-timing-test/run.sh` (38), and the earlier suites
unchanged (`save-logic-test` 442, `frame-pacer-test` 160, `native-state-test` 65, `native-jni-test` 16, `native-link-test/run.sh`
mailbox 24 under ASan/UBSan and the ThreadSanitizer run). Not built with Gradle/NDK.

### Audit-fix pass 14 — Zelda: A Link to the Past & Four Swords and the link timing

| File | Change |
|------|--------|
| `cpp/link_timing.h` (new) | the two caps on a host transfer's length in the game (Smooth 4.5 ms as before, Compatible 1.5 ms) and which game / setting gets which |
| `cpp/mgba_jni.c` | the cap is chosen per link session (`nativeLinkSetTimingMode()`, resolved in `nativeLinkStart()` from the ROM header) and logged |
| `link/LinkTiming.kt` (new), `EmulatorEngine.kt`, `MainActivity*.kt` | Settings → Debug → **Link timing** (Auto / Smooth / Compatible), saved in the preferences and passed to the engine before the link starts |

> **Superseded by pass 15 (above): the 2 Nov logs disproved this explanation, and the 1.5 ms transfers did not make the game link.**

**In plain terms.** Zelda: Four Swords restarts its link-up round every 2 frames and needs 13 cable transfers in each
round. "Smooth link" made each transfer last as long as a Wi-Fi round trip (up to 4.5 ms), so only 7 fit and the
game's link-up could never finish (that is what the 31 Oct 2026 logs show). With **Auto** (the default) that game gets
1.5 ms transfers and every other game keeps what it had. The price is speed while linked over Wi-Fi (about 37 % in the
simulation, to be measured on phones). Only the host's setting matters; it applies from the next connection. The first
lines of the link log now say which timing was used. **Not tested on the real game or a phone** — see
`KNOWN_LIMITATIONS.md` and CHANGELOG.md item 38.

Checks: `tools/native-link-test/run_regs.sh` (`test_sio_regs` 160, `test_log` 10, `test_link_timing` 30),
`tools/native-link-test/run_sim.sh` (two simulated phones: 46 + 18), `tools/link-timing-test/run.sh` (38), and the
earlier suites unchanged (`save-logic-test` 442, `frame-pacer-test` 160, `native-state-test` 65, `native-jni-test` 16,
`native-link-test/run.sh` mailbox 24 under ASan/UBSan and under TSan). The Kotlin suites need a `kotlinc`
(`KOTLINC=/path/to/kotlinc ./run.sh`). Not built with Gradle/NDK.

### Audit-fix pass 13 — closing the app while a game is still loading

| File | Change |
|------|--------|
| `saves/SaveStateGate.kt` | the save/load/ROM-change guard can be closed for good and waited on (`close()`, `awaitIdle()`) |
| `MainActivity.kt` | `onDestroy()` closes it, and waits for a load that is already in its final step, before the emulated console is freed |
| `MainActivityRom.kt`, `MainActivityDebugLog.kt` | a ROM load / Reset that finds the guard closed stops quietly instead of building a console |

**In plain terms.** Loading a ROM or pressing Reset finishes on a background thread. If the screen was closed
while that thread was still busy (unzipping, a slow Storage folder), the screen's clean-up freed the emulated
console and the late thread then built a new one that nothing would free. The clean-up now shuts the door first
and waits briefly for a load that is already inside; a late one simply stops. Nothing changes while the app is
running normally. (This is unrelated to the failed two-phone test whose logs came with the report — see
CHANGELOG.md, pass 13, for what those logs show.)

Checks: `tools/save-logic-test/run.sh` (442), `tools/frame-pacer-test/run.sh` (160),
`tools/native-state-test/run.sh` (65, ASan/UBSan), `tools/native-link-test/run.sh`, `run_regs.sh` and
`run_sim.sh`, `tools/native-jni-test/run.sh`. The two Kotlin ones need a `kotlinc`
(`KOTLINC=/path/to/kotlinc ./run.sh`). Not built with Gradle/NDK and not run on a device — see
`KNOWN_LIMITATIONS.md`.

### Audit-fix pass 12 — switching games during a save, a real 0.5x, safer state loading

| File | Change |
|------|--------|
| `saves/SaveStateGate.kt` (new) | the "a save/load is running" guard, now also taken by the code that replaces the game |
| `MainActivityRom.kt`, `MainActivityDebugLog.kt` | loading a ROM / Reset waits for a running save/load before replacing the console |
| `pacing/SpeedPlanner.kt`, `pacing/SlowMotionAudio.kt` (new), `MainActivityRender.kt`, `MainActivityAudio.kt` | 0.5x really is half speed: one frame per step with its sound stretched to twice the length |
| `mgba_jni.c` | a compressed save state's header is checked against the file before anything is allocated |
| `tools/native-link-test/test_mailbox.c`, `run.sh` | the test's own data races fixed; TSan reports are shown in full |

**In plain terms.** (1) If you switched games while a save was still being written, the save could land in
the other game's slot; the switch now waits for the save (and refuses, with a message, if it never
finishes). (2) The Fast-forward speed "0.5x" used to play at normal speed whenever sound worked; it is now
half speed, with the sound slowed down to match (lower in pitch). (3) A damaged save-state file can no
longer make the app reserve far more memory than the file justifies.

Checks: `tools/save-logic-test/run.sh` (359), `tools/frame-pacer-test/run.sh` (160),
`tools/native-state-test/run.sh` (65, ASan/UBSan), `tools/native-link-test/run.sh` (mailbox under
ASan/UBSan and TSan). The two Kotlin ones need a `kotlinc` (`KOTLINC=/path/to/kotlinc ./run.sh`). Not built
with Gradle/NDK and not run on a device — see `KNOWN_LIMITATIONS.md`.

### Audit-fix pass 11 — loading a save state and resetting the link driver are one step

| File | Change |
|------|--------|
| `mgba_jni.c` | `nativeLoadState()` resets the link driver's transfer/tick bookkeeping inside the same lock as the load itself, instead of releasing the lock and taking it again |
| `tools/native-state-test/harness.c` | a stand-in game thread shows no frame can run between the two (the new check fails on the old code) |

**In plain terms.** Loading a save state replaces the emulated console's internal timer queue, which
leaves the multiplayer code's own bookkeeping out of date until it is reset. That reset used to
happen a moment *after* the load, with the game thread free to run a frame in between. It now
happens in the same locked step. It only matters while a link session is running, and the gap was a
few instructions wide — a tidy-up, not something you were likely to see.

Checks: `tools/native-state-test/run.sh` (27 checks under ASan/UBSan; the new ones fail on the old
code). Not built with the NDK and not run on a device — see `KNOWN_LIMITATIONS.md`.

### Audit-fix pass 10 — the game loop stays paced when audio playback fails

| File | Change |
|------|--------|
| `pacing/FallbackFramePacer.kt` (new package) | The wall-clock pacer as plain Kotlin: on every iteration the audio write did not pace, it holds the loop to the real GBA frame rate at the selected fast-forward speed |
| `MainActivityAudio.kt` | `writePcm()` returns whether every sample was accepted by the AudioTrack |
| `MainActivityRender.kt` | the game loop paces itself with the pacer whenever `writePcm()` did not; no sleep while stopping |
| `MainActivityShared.kt` | `FALLBACK_MAX_LAG_NS` |

**In plain terms.** The game loop is normally held to the right speed by the audio device (it
waits while it writes the sound). If the sound could not be played — no audio track, an error,
a paused track — nothing held it back and the emulator ran as fast as the phone could manage.
It now notices when the sound write did not do the pacing and slows itself with the phone's
clock instead, at the real Game Boy Advance speed (or the chosen fast-forward speed), and goes
back to the audio device as soon as sound works again.

Checks: `tools/frame-pacer-test/run.sh` (50 assertions on the real `pacing/*.kt`, JVM only,
needs a `kotlinc`), plus the real game-loop functions compiled against stand-ins for Android
and run against a simulated audio device (not part of the repo). Not run on a device and not
built with Gradle — see `KNOWN_LIMITATIONS.md`.

### Audit-fix pass 9 — the in-game save follows the game's name; closing a game no longer waits on storage

| File | Change |
|------|--------|
| `saves/*.kt` (new package) | The decisions as plain Kotlin: `SaveKeys` (game `<name>` vs build `<name>_<crc>`), `BatteryAdoption` + `BatterySaveResolver` (which in-game save a ROM opens, older per-ROM saves carried over), `SessionPersister` (end-of-session work off the UI thread) |
| `MainActivityBatterySaves.kt`, `LoaderThreadDialog.kt` (new) | The Android side: files (app folder + Storage folder), preferences, the "Which in-game save?" dialog |
| `MainActivityRom.kt` | In-game save is `<name>.sav` — a patched ROM renamed to the original's name continues the original's game; save states stay per build; autosave only loaded while it still matches the save |
| `MainActivitySaveStateCore.kt`, `MainActivityDebugLog.kt` | `closeGame()` no longer waits for the storage flush; Reset syncs the Storage folder before staging it |
| `MainActivityRender.kt` | `stopGameLoop()` wakes the blocked audio writer first; a stopped loop thread can never restart |

**In plain terms.** The in-game (battery) save used to be filed per ROM *file*
(name + CRC32), so a patched ROM renamed to the original's name got a new, empty
save. It is now filed by the *name*. The first time a name is opened, the old
per-ROM saves are looked at: one played-into save is carried over silently, two
different ones are put to the player ("Which in-game save?"), and nothing is ever
deleted or overwritten without a copy being kept next to it. Save states,
quicksave and autosave stay per ROM file because they are a snapshot of one
build's memory.

Closing a game used to wait on the UI thread for the copies to the Storage
folder and the autosave write (up to 2.5 s) and for the game thread to leave its
blocking audio write. The copies now run on one background thread and the audio
writer is woken first.

Checks: `tools/save-logic-test/run.sh` (319 assertions on the real `saves/*.kt`,
JVM only, needs a `kotlinc`) and a type-check of every Kotlin file against the
real android-34 `android.jar`. Not run on a device and not built with Gradle —
see `KNOWN_LIMITATIONS.md`.
