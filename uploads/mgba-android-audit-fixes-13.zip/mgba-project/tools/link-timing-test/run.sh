#!/usr/bin/env bash
# Host-side test of the Kotlin side of "Link timing" (app/src/main/kotlin/com/mgba/android/link/LinkTiming.kt) and of its
# agreement with the native side (app/src/main/cpp/link_timing.h): the codes that cross JNI and the preferences, and a
# source check of the wiring that cannot be compiled without the Android SDK. Compiles the REAL source next to
# LinkTimingTest.kt. Needs a Kotlin compiler (kotlinc) and a JDK; no Android SDK, no Gradle.
#
#   KOTLINC=/path/to/kotlinc ./run.sh      (defaults to `kotlinc` on PATH)
set -euo pipefail
cd "$(dirname "$0")"
KOTLINC="${KOTLINC:-kotlinc}"
MAIN=../../app/src/main
OUT="$(mktemp -d)"
trap 'rm -rf "$OUT"' EXIT
"$KOTLINC" -language-version 1.9 -api-version 1.9 -jvm-target 17 -nowarn \
    "$MAIN"/kotlin/com/mgba/android/link/*.kt LinkTimingTest.kt -d "$OUT/classes"
CP="$OUT/classes:$(dirname "$(dirname "$(readlink -f "$(command -v "$KOTLINC")")")")/lib/kotlin-stdlib.jar"
java -Dfile.encoding=UTF-8 -Dstdout.encoding=UTF-8 -cp "$CP" com.mgba.android.link.LinkTimingTestKt "$MAIN"
