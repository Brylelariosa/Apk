package com.mgba.android.link

import java.io.File
import kotlin.system.exitProcess

// Host-side tests for app/src/main/kotlin/com/mgba/android/link/LinkTiming.kt and for its agreement with the native side.
// run.sh compiles the REAL source next to this file, so a test cannot drift from the shipping code. No Android, no JUnit.
//
// Three kinds of check:
//   1. the enum itself (codes, defaults, how an unknown code is handled, labels);
//   2. the CONTRACT with app/src/main/cpp/link_timing.h — the codes cross JNI as plain ints and are stored in the
//      preferences, so a renumbering on either side would silently change what a saved setting means;
//   3. the WIRING, as source text (the files involved need the Android SDK to compile, which this test does not have):
//      the preference is loaded and saved, the native mode is set before the link starts and in its own try block, and
//      the JNI declaration matches the C export.

private var checks = 0
private val failures = ArrayList<String>()

private fun check(cond: Boolean, what: String) {
    checks++
    if (!cond) { failures += what; println("  FAIL: $what") }
}

private fun <T> checkEq(actual: T, expected: T, what: String) =
    check(actual == expected, "$what — expected <$expected> but was <$actual>")

private fun section(name: String) = println("• $name")

fun main(args: Array<String>) {
    require(args.size == 1) { "usage: LinkTimingTestKt <path to app/src/main>" }
    val main = File(args[0])
    fun text(rel: String): String {
        val f = File(main, rel)
        require(f.isFile) { "missing source file: $f" }
        return f.readText(Charsets.UTF_8)
    }

    section("the modes")
    checkEq(LinkTiming.values().map { it.name }, listOf("AUTO", "SMOOTH", "COMPAT"), "the modes, in menu order")
    checkEq(LinkTiming.AUTO.code, 0, "AUTO code")
    checkEq(LinkTiming.SMOOTH.code, 1, "SMOOTH code")
    checkEq(LinkTiming.COMPAT.code, 2, "COMPAT code")
    checkEq(LinkTiming.DEFAULT, LinkTiming.AUTO, "the default is Auto")
    checkEq(LinkTiming.DEFAULT.code, 0, "the default's code is 0, which is also the native default and what an absent preference reads as")
    check(LinkTiming.values().map { it.code }.toSet().size == LinkTiming.values().size, "codes are unique")
    check(LinkTiming.values().map { it.label }.toSet().size == LinkTiming.values().size, "labels are unique")
    check(LinkTiming.values().all { it.label.isNotBlank() && it.label.length <= 24 }, "labels are non-blank and short enough for the row's value column")
    check(LinkTiming.values().all { it.summary.isNotBlank() }, "every mode has a summary for the picker")
    check(LinkTiming.AUTO.label.contains("recommended", ignoreCase = true), "the recommended mode says so")

    section("fromCode")
    for (m in LinkTiming.values()) checkEq(LinkTiming.fromCode(m.code), m, "fromCode(${m.code}) round-trips to ${m.name}")
    for (bad in intArrayOf(-1, 3, 4, 99, 255, Int.MIN_VALUE, Int.MAX_VALUE))
        checkEq(LinkTiming.fromCode(bad), LinkTiming.DEFAULT, "an unknown code ($bad) — a corrupt preference or a newer build's value — is the default, never an error")

    section("contract with link_timing.h (the numbers that cross JNI and the preferences)")
    val header = text("cpp/link_timing.h")
    val nativeCodes = Regex("""LINK_TIMING_([A-Z]+)\s*=\s*(\d+)""").findAll(header).associate { it.groupValues[1] to it.groupValues[2].toInt() }
    checkEq(nativeCodes.keys, LinkTiming.values().map { it.name }.toSet(), "the native enum and the Kotlin enum have the same modes")
    for (m in LinkTiming.values()) checkEq(nativeCodes[m.name], m.code, "native LINK_TIMING_${m.name} equals Kotlin ${m.name}.code")
    val caps = Regex("""#define\s+(LINK_STRETCH_MAX_US|LINK_STRETCH_COMPAT_MAX_US)\s+(\d+)u""").findAll(header).associate { it.groupValues[1] to it.groupValues[2].toInt() }
    check(caps["LINK_STRETCH_MAX_US"] == 4500 && caps["LINK_STRETCH_COMPAT_MAX_US"] == 1500, "the caps this test and the summaries assume (4.5 ms / 1.5 ms) are the header's: $caps")
    val jni = text("cpp/mgba_jni.c")
    check(!Regex("""#define\s+LINK_STRETCH_MAX_US\b""").containsMatchIn(jni), "mgba_jni.c does not define the cap again (link_timing.h is the single source)")
    check(jni.contains("#include \"link_timing.h\""), "mgba_jni.c includes link_timing.h")

    section("wiring (source text)")
    val shared = text("kotlin/com/mgba/android/MainActivityShared.kt")
    check(Regex("""internal const val PREF_LINK_TIMING = "link_timing"""").findAll(shared).count() == 1, "PREF_LINK_TIMING is defined once")
    val activity = text("kotlin/com/mgba/android/MainActivity.kt")
    check(activity.contains("LinkTiming.fromCode(p.getInt(PREF_LINK_TIMING, LinkTiming.DEFAULT.code))"), "onCreate loads the preference through fromCode(), with the default's code as fallback")
    check(Regex("""@Volatile internal var linkTiming: LinkTiming = LinkTiming\.DEFAULT""").containsMatchIn(activity), "the setting is a @Volatile field that starts at the default")
    val dialogs = text("kotlin/com/mgba/android/MainActivitySettingsDialogs.kt")
    check(dialogs.contains("putInt(PREF_LINK_TIMING, linkTiming.code)"), "the Debug dialog stores the code")
    check(dialogs.contains("LinkTiming.values()") && dialogs.contains("videoChoiceRow("), "the Debug dialog offers every mode through the choice row")
    val link = text("kotlin/com/mgba/android/MainActivityLink.kt")
    val setAt = link.indexOf("EmulatorEngine.nativeLinkSetTimingMode(linkTiming.code)")
    val startAt = link.indexOf("EmulatorEngine.nativeLinkStart(")
    check(setAt in 0 until startAt, "onLinkConnected sets the native mode BEFORE nativeLinkStart (the native side reads it there)")
    val tryAt = link.lastIndexOf("try {", setAt)
    val catchAt = link.indexOf("catch (t: Throwable)", setAt)
    check(tryAt >= 0 && catchAt > setAt && catchAt < startAt && link.substring(tryAt, setAt).none { it == '}' },
        "...inside its own try/catch, so a failure costs the setting and never the link")
    val engine = text("kotlin/com/mgba/android/EmulatorEngine.kt")
    check(Regex("""external fun nativeLinkSetTimingMode\(mode: Int\)""").containsMatchIn(engine), "EmulatorEngine declares nativeLinkSetTimingMode(mode: Int)")
    check(Regex("""Java_com_mgba_android_EmulatorEngine_nativeLinkSetTimingMode\(JNIEnv \*env, jobject thiz, jint mode\)""").containsMatchIn(jni),
        "the C export matches it (Kotlin Int = jint, no return value)")
    val proguard = File(main, "../../proguard-rules.pro").readText(Charsets.UTF_8)
    check(proguard.contains("-keep class com.mgba.android.EmulatorEngine") && proguard.contains("native <methods>;"), "R8 keeps EmulatorEngine's native methods, the new one included")

    println()
    if (failures.isEmpty()) println("ALL $checks CHECKS PASSED")
    else {
        println("${failures.size} of $checks CHECKS FAILED")
        exitProcess(1)
    }
}
