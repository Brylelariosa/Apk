# link-timing-test

JVM test of the Kotlin side of **Settings → Debug → Link timing** (pass 14) and of its agreement with the native side.
It needs a Kotlin compiler (`kotlinc`) and a JDK — no Android SDK, no Gradle:

    KOTLINC=/path/to/kotlinc ./run.sh        # `kotlinc` on PATH by default

`run.sh` compiles the real `app/src/main/kotlin/com/mgba/android/link/LinkTiming.kt` next to `LinkTimingTest.kt` and runs
it (38 checks).

| what | how |
|---|---|
| the modes | `AUTO` / `SMOOTH` / `COMPAT` have the codes 0 / 1 / 2 (they are stored in the preferences and passed over JNI — never renumber), Auto is the default, `fromCode()` maps an unknown code to Auto, labels are unique and short, every mode has a summary |
| agreement with the native side | `app/src/main/cpp/link_timing.h` is parsed as text: its `LINK_TIMING_*` values equal the enum's codes (both directions), and its two caps are the 4500 / 1500 us the summaries and docs assume |
| the wiring (source checks — the Android parts cannot be compiled here) | `mgba_jni.c` includes the header and has no second definition of the cap; `nativeLinkSetTimingMode` has the same name and signature in `mgba_jni.c` and `EmulatorEngine.kt`; the proguard rules keep it; `onLinkConnected()` calls it **before** `nativeLinkStart()` and inside its own `try`; the setting is loaded from and saved to `PREF_LINK_TIMING` |

What it cannot check: that the Debug dialog looks right or that Android accepts the code (a differential compile and a
stub compile covered the Kotlin; a Gradle build is still needed). The policy itself — which game gets which cap — is
tested natively by `tools/native-link-test/test_link_timing.c` and `test_sio_regs.c`.

**Pass 15:** the Kotlin side changed only in text (the mode summaries, the Link timing row's description and comments) because
Auto now runs a search for Zelda: Four Swords instead of using the fixed 1.5 ms profile; the modes, codes, defaults and wiring
this test checks are unchanged, and so is its count (38). The search itself is native: `tools/native-link-test/test_link_timing.c`
and `test_sio_regs.c`.
