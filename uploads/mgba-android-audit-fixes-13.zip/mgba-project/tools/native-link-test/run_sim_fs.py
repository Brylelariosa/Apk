"""Two-phone simulation of the Zelda: A Link to the Past & Four Swords link-up, and of the host's link-up SEARCH
(link_timing.h), through the real link code.

What it checks, and what it cannot. sim_dev.c's "Four Swords" section models what the two captures (31 Oct and
2 Nov 2026) show: the master repeats 7-transfer rounds whatever the transfer length, its probe period follows the
length (2 frames at 4.5 ms, 1 frame at 1.5 ms), and the slave recognises only every second probe. It has ONE
synthetic knob, a window of transfer lengths in which the master sends full 13-word rounds. With no window nothing
can ever link (F1, F2, F4); with a window the search has something to find (F3, F5-F7). The real cartridge may behave
differently at lengths the captures do not cover — which is why the app searches on the phones. This file proves the
mechanics: that the pass-14 profile reproduces the captured failure, that the search steps through its lengths, locks
when the slave answers every round and stays locked, never deadlocks or harms a game that cannot link, and that the
child follows a host whose transfer length changes under it.

Timing argument of sim_dev: 0 = Auto, 1 = Smooth (force the long transfers), 2 = Compatible. In the Four Swords
model the simulated cartridge carries that game's header title, so Auto runs the search."""
from sim_lib import run, check, finish

AUTO, SMOOTH, COMPAT = 0, 1, 2
WIN_24   = (2350, 2450)   # full rounds only at transfer lengths of 2.35-2.45 ms: the search table's 2.4 ms step (the 4th) is inside
WIN_FAST = (0, 1200)      # full rounds at cable-like lengths: the table's first step, exact timing (0.38 ms), is inside

def ratio(a, b):
    return int(a) / max(1, int(b))

def captured_cadence(H, C, words_x10, period, label):
    check(H['detected'] == '0' and H['ok_rounds'] == '0' and C['synced'] == '0', f"{label}: the link never completes")
    check(int(H['words_x10']) == words_x10, f"every round is {int(H['words_x10']) / 10:.1f} transfers — the captures' 7, whatever the length")
    check(int(H['period']) == period, f"the probe period has become {H['period']} frame(s)")
    check(0.35 <= ratio(C['probes_recognized'], C['probes']) <= 0.65,
          f"the slave recognises about every second probe ({C['probes_recognized']} of {C['probes']}) — the pattern in the captures' child logs")
    check(C['valid_blocks'] == '0' and int(C['bad_blocks']) > 20, f"no block ever validates ({C['bad_blocks']} windows mixed two rounds)")

print("== F1. OLD timing (Smooth forced = 4.5 ms transfers), Wi-Fi-like 3 ms one-way (the capture: ~5.8 ms round trips)")
H, C = run("fs smooth", 12, 3, 1, smooth=1, fs=1, timing=SMOOTH)
if H:
    check(H['cap_us'] == '4500' and H['sweep'] == '0', f"the host's transfers are capped at {H['cap_us']} us and there is no search (a fixed choice)")
    captured_cadence(H, C, 70, 2, "31 Oct capture")
    check(55 <= int(H['speed_avg']) <= 100, f"...while the game ran at {H['speed_avg']}% speed (the capture: ~77%): fast, but not linked")

print("== F2. PASS-14 timing (Compatible forced = 1.5 ms transfers), same link")
H, C = run("fs compat", 12, 3, 1, smooth=1, fs=1, timing=COMPAT)
if H:
    check(H['cap_us'] == '1500' and H['sweep'] == '0', f"the host's transfers are capped at {H['cap_us']} us and there is no search")
    captured_cadence(H, C, 70, 1, "2 Nov capture")
    check(25 <= int(H['speed_avg']) <= 70, f"...at {H['speed_avg']}% speed (the capture: 46%): seven round trips per frame, and still no link")

print("== F3. AUTO, a master with a window at 2.4 ms: the search runs through exact timing, 2.5 ms and 4.9 ms and locks on the 4th length")
H, C = run("fs search", 30, 3, 1, smooth=1, fs=1, timing=AUTO, win=WIN_24, show_sweep=True)
if H:
    check(H['sweep'] == '1', "Auto + the Four Swords header on a smooth host: the search is on")
    check(H['detected'] == '1' and C['synced'] == '1', "both sides link up")
    check(H['sweep_locks'] == '1' and H['lock_cap_us'] == '2400' and H['sweep_steps'] == '3',
          f"the search locked once, at 2400 us, after three finished steps (locks={H['sweep_locks']}, cap={H['lock_cap_us']}, steps={H['sweep_steps']})")
    check(float(H['lock_at']) < 22.0, f"...{H['lock_at']} s into the session (three steps of 600 transfers on a Wi-Fi-like link)")
    check(H['sweep_locked'] == '1' and H['sweep_index'] == '3' and H['sweep_unlocks'] == '0' and H['sweep_steps'] == '3' and H['cap_us'] == '2400',
          f"and it stays locked for the rest of the session: step index {H['sweep_index']}, {H['sweep_unlocks']} unlocks, cap {H['cap_us']} us")
    check(int(H['ok_rounds']) >= 40 and int(C['probes_recognized']) >= 40, f"the master's rounds validate ({H['ok_rounds']} of {H['full_rounds']} full rounds) and the slave recognises probes ({C['probes_recognized']} of {C['probes']})")
    check(int(H['speed_avg']) >= 20, f"the price: the game ran at {H['speed_avg']}% speed over the search and the Wi-Fi-like link")

print("== F4. AUTO, a master with NO window (the null hypothesis): the search cycles and finds nothing, and does no harm")
H, C = run("fs null", 32, 3, 1, smooth=1, fs=1, timing=AUTO, show_sweep=True)
if H:
    check(H['sweep'] == '1' and H['sweep_locks'] == '0' and H['sweep_locked'] == '0', "the search ran the whole time and never locked")
    check(int(H['sweep_steps']) >= 5, f"it kept cycling through its lengths ({H['sweep_steps']} steps finished, now at index {H['sweep_index']})")
    check(H['detected'] == '0' and C['synced'] == '0' and H['ok_rounds'] == '0', "no link (nothing in this model can link)")
    check(int(H['words_x10']) == 70 and 0.35 <= ratio(C['probes_recognized'], C['probes']) <= 0.65,
          f"the captures' pattern at every length: {int(H['words_x10']) / 10:.1f}-transfer rounds, every second probe recognised ({C['probes_recognized']} of {C['probes']})")
    check(int(H['xchg_fail']) <= 3 and int(H['frames']) >= 400, f"the host kept running and exchanging: {H['frames']} frames, {H['xchg_fail']} failed exchanges")

print("== F5. AUTO, a master with full rounds at cable-like lengths: exact timing (the first step) links, and the search never moves on")
H, C = run("fs fast", 14, 3, 1, smooth=1, fs=1, timing=AUTO, win=WIN_FAST, show_sweep=True)
if H:
    check(H['detected'] == '1' and C['synced'] == '1', "both sides link up")
    check(H['sweep_locks'] == '1' and H['lock_cap_us'] == '0' and H['sweep_steps'] == '0' and H['sweep_index'] == '0' and H['sweep_locked'] == '1',
          f"locked in the first step at exact timing, no step finished ({H['sweep_steps']}), still locked at the end")
    check(float(H['lock_at']) < 5.0, f"...within {H['lock_at']} s")
    check(int(H['full_rounds']) >= 40 and int(H['ok_rounds']) >= int(H['full_rounds']) - 3, f"full rounds validate ({H['ok_rounds']} of {H['full_rounds']})")

print("== F6. same on a local link (0.15 ms one-way, both players on one phone)")
H, C = run("fs fast local", 8, 0.15, 1, smooth=1, fs=1, timing=AUTO, win=WIN_FAST)
if H:
    check(H['detected'] == '1' and C['synced'] == '1' and H['sweep_locked'] == '1' and H['sweep_steps'] == '0', "links up in the first step and stays locked")
    check(int(H['speed_avg']) >= 60 and int(C['speed_avg']) >= 60, f"and the game keeps most of its speed: host {H['speed_avg']}%, child {C['speed_avg']}%")

print("== F7. same over a Bluetooth-like 15 ms one-way delay: links up, but a round trip per transfer makes it slow")
H, C = run("fs fast bt", 14, 15, 1, smooth=1, fs=1, timing=AUTO, win=WIN_FAST)
if H:
    check(H['detected'] == '1' and C['synced'] == '1' and H['sweep_locked'] == '1', "still links up and locks (the search counts rounds, whatever the round trip)")
    print(f"      (host speed {H['speed_avg']}% — a transfer costs a full ~31 ms round trip; Wi-Fi is the way to play this)")

finish()
