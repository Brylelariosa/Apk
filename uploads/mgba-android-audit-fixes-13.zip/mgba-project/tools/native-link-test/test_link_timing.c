/* Host-side test of app/src/main/cpp/link_timing.h — which cap on the host's emulated transfer time a link
 * session gets (per game, from the ROM header, and from the "Link timing" setting), and the Four Swords link-up
 * search (the table of lengths and the state machine that watches the probe rounds). Pure C: the header is
 * included as it ships. The register-level behaviour (the cap really bounds the transfer in emulated cycles,
 * nativeLinkStart() applies it, the hooks feed the search) is test_sio_regs.c's "LINK TIMING" and "LINK-UP SEARCH"
 * sections; the two-process behaviour is run_sim.sh.
 *
 * The numbers marked CAPTURE come from the two-phone logs of The Legend of Zelda: A Link to the Past & Four Swords
 * (host Infinix X675, child Itel A6610L): 31 Oct 2026 with the old 4.5 ms cap, 2 Nov 2026 with the pass-14 1.5 ms cap.
 * What they show: the master's round is 7 transfers (probe 0xFEFE first) at BOTH lengths, the probe repeats every
 * 2 frames at 4.5 ms and every frame at 1.5 ms, and the slave answers every second round. */
#include <limits.h>
#include <stdio.h>
#include <string.h>
#include "../../app/src/main/cpp/link_timing.h"
#include "capture_replay.h"

static int fails = 0;
#define CHECK(c, msg) do { if (c) printf("PASS  %s\n", msg); else { printf("FAIL  %s\n", msg); fails++; } } while (0)

#define FRAME_TICKS         44u      /* a frame is 280,896 cycles = 43.82 link ticks of 6,410 cycles */
#define FS_ROUND_TRANSFERS  7u       /* CAPTURE: the master's round at both lengths: probe, counter, 0xFFFF, 0, 0, 0, 0 */

/* A cartridge image with a header: [title] at 0xA0, zero elsewhere. */
static void make_rom(uint8_t *rom, size_t size, const char *title)
{
    memset(rom, 0, size);
    if (title) memcpy(rom + LINK_ROM_TITLE_OFFSET, title, strlen(title));
}

/* A scripted master for the search tests: [tick] advances 6 link ticks per transfer (a 2.29 ms spacing) and
 * 2 more at the end of a round, so a 7-transfer round is 44 ticks from probe to probe — one frame, as in the capture. */
typedef struct { LinkSweep s; uint16_t tick; unsigned ev, steps, locks, unlocks; } Drv;
static void drv_init(Drv *d, uint16_t t0) { memset(d, 0, sizeof *d); link_sweep_init(&d->s); d->tick = t0; }
static void drv_note(Drv *d, unsigned e)
{
    d->ev |= e;
    if (e & LINK_SWEEP_EV_STEP)   d->steps++;
    if (e & LINK_SWEEP_EV_LOCK)   d->locks++;
    if (e & LINK_SWEEP_EV_UNLOCK) d->unlocks++;
}
static void feed(Drv *d, uint16_t sent, uint16_t recv)
{
    drv_note(d, link_sweep_on_transfer(&d->s, sent, recv, d->tick));
    d->tick = (uint16_t)(d->tick + 6u);
}
/* One round of [n] transfers: the probe, then the counter word and zeros; when [ans] the slave's reply 0x0042 comes with the counter. */
static void round_(Drv *d, unsigned n, bool ans)
{
    feed(d, 0xFEFE, 0);
    for (unsigned k = 1; k < n; k++) feed(d, k == 1 ? 0xFFD0u : 0u, (ans && k == 1) ? 0x0042u : 0u);
    d->tick = (uint16_t)(d->tick + 2u);
}

int main(void)
{
    static uint8_t rom[0x200];

    printf("== constants: the numbers the Kotlin side and the preferences depend on\n");
    CHECK(LINK_TIMING_AUTO == 0 && LINK_TIMING_SMOOTH == 1 && LINK_TIMING_COMPAT == 2,
          "LINK_TIMING_AUTO/SMOOTH/COMPAT are 0/1/2 (stored in preferences, passed over JNI — never renumber)");
    CHECK(LINK_STRETCH_MAX_US == 4500u, "the Smooth cap is still 4500 us (what every game but Four Swords keeps)");
    CHECK(LINK_STRETCH_COMPAT_MAX_US < LINK_STRETCH_MAX_US, "the Compatible cap is shorter than the Smooth cap");
    CHECK(LINK_ROM_TITLE_OFFSET == 0xA0u && LINK_ROM_TITLE_LEN == 12u, "the ROM header title is 12 bytes at 0xA0");

    printf("== the search table (link_sweep_step_cap_us)\n");
    {
        int distinct = 1, wraps = 1, bounded = 1, has0 = 0, has1500 = 0;
        for (uint32_t a = 0; a < LINK_SWEEP_STEPS; a++) {
            const uint32_t ca = link_sweep_step_cap_us(a);
            if (ca > 10000u) bounded = 0;
            if (ca == 0u) has0 = 1;
            if (ca == LINK_STRETCH_COMPAT_MAX_US) has1500 = 1;
            if (link_sweep_step_cap_us(a + LINK_SWEEP_STEPS) != ca || link_sweep_step_cap_us(a + 5u * LINK_SWEEP_STEPS) != ca) wraps = 0;
            for (uint32_t b = a + 1u; b < LINK_SWEEP_STEPS; b++) if (link_sweep_step_cap_us(b) == ca) distinct = 0;
        }
        CHECK(LINK_SWEEP_STEPS == 16u, "16 lengths");
        CHECK(distinct, "no length twice (a repeated step would waste ~3 s of a search that has nothing to spare)");
        CHECK(wraps, "the index wraps: after the last length the search starts over");
        CHECK(bounded, "no length above 10 ms (a transfer that long would stall the host for 10 ms each)");
        CHECK(link_sweep_step_cap_us(0) == 0u, "the first step is exact cable timing (what the master sees on hardware)");
        CHECK(has0 && has1500, "the table holds exact timing and the pass-14 length (1.5 ms), so a search also answers 'was pass 14 right at all'");
        /* The working model (see the header): the master adapts its probe period to its transfer length, and 12 or more
         * transfers between two probes are what the slave's receive code needs. The lengths where 12 fit, if the
         * period is 2, 4 or 8 frames, are the windows below. The table must put at least one step in each. */
        int w2 = 0, w4 = 0, w8 = 0;
        for (uint32_t a = 0; a < LINK_SWEEP_STEPS; a++) {
            const uint32_t ca = link_sweep_step_cap_us(a);
            if (ca >= 2310u && ca <= 2710u) w2 = 1;
            if (ca >= 4700u && ca <= 5500u) w4 = 1;
            if (ca >= 9500u && ca <= 11000u) w8 = 1;
        }
        CHECK(w2 && w4 && w8, "the table has a step in each window of the working model (2, 4 and 8 frames per probe)");
    }
    CHECK(LINK_SWEEP_DWELL >= 8u * FS_ROUND_TRANSFERS * LINK_SWEEP_LOCK_ROUNDS,
          "a step lasts long enough for a slave that answers every round to be seen at least 8 times over the lock threshold");
    CHECK(LINK_SWEEP_LOCK_ROUNDS >= 3u, "locking needs at least 3 answered rounds in a row: the capture's slave answers every SECOND round, so 2 in a row would be luck");
    CHECK(LINK_SWEEP_UNLOCK_ROUNDS >= 2u, "a lock survives one missed round");

    printf("== link_timing_known_game(): recognised by the ROM header title\n");
    make_rom(rom, sizeof rom, "GBAZELDA");
    CHECK(link_timing_known_game(rom, sizeof rom) != NULL, "\"GBAZELDA\" at 0xA0 is Four Swords");
    CHECK(link_timing_known_game(rom, 0xACu) != NULL, "...with exactly the 12 title bytes present (0xAC bytes) it is still read");
    CHECK(link_timing_known_game(rom, 0xABu) == NULL, "...one byte fewer and the header is not fully there: not recognised");
    CHECK(link_timing_known_game(rom, 0) == NULL && link_timing_known_game(NULL, sizeof rom) == NULL && link_timing_known_game(NULL, 0) == NULL,
          "an empty or missing image is not a known game");
    make_rom(rom, sizeof rom, "GBAZELDA");
    memcpy(rom + 0xA8, "2\0\0\0", 4);
    CHECK(link_timing_known_game(rom, sizeof rom) != NULL, "text after the title (a revision or regional variant) still matches: only the leading characters are compared");
    {
        const char *others[] = { "GBAZELD", "ZELDA", "gbazelda", "GBAZELDX", "POKEMON EMER", "GBAZ", "", "MARIOKART", "ZELDA MC" };
        int any = 0;
        for (size_t i = 0; i < sizeof others / sizeof others[0]; i++) {
            make_rom(rom, sizeof rom, others[i]);
            if (link_timing_known_game(rom, sizeof rom)) { any = 1; printf("      unexpectedly matched \"%s\"\n", others[i]); }
        }
        CHECK(!any, "near-misses and other games are not recognised (no case folding, no 4-letter prefix: a wrong match slows a game's link)");
    }
    make_rom(rom, sizeof rom, NULL);
    memcpy(rom + 0x10, "GBAZELDA", 8);          /* right text, wrong place */
    CHECK(link_timing_known_game(rom, sizeof rom) == NULL, "the title is only looked for at 0xA0");

    printf("== link_timing_resolve(): setting x game -> cap\n");
    {
        static uint8_t fs[0x100], other[0x100];
        make_rom(fs, sizeof fs, "GBAZELDA"); make_rom(other, sizeof other, "POKEMON EMER");
        LinkTiming t;
        t = link_timing_resolve(LINK_TIMING_AUTO, fs, sizeof fs);
        CHECK(t.cap_us == LINK_STRETCH_COMPAT_MAX_US && t.game && t.mode == LINK_TIMING_AUTO, "Auto + Four Swords -> Compatible cap, game named");
        t = link_timing_resolve(LINK_TIMING_AUTO, other, sizeof other);
        CHECK(t.cap_us == LINK_STRETCH_MAX_US && t.game == NULL && t.mode == LINK_TIMING_AUTO, "Auto + another game -> Smooth cap (as before this change)");
        t = link_timing_resolve(LINK_TIMING_AUTO, NULL, 0);
        CHECK(t.cap_us == LINK_STRETCH_MAX_US && t.game == NULL, "Auto + no ROM image -> Smooth cap");
        t = link_timing_resolve(LINK_TIMING_SMOOTH, fs, sizeof fs);
        CHECK(t.cap_us == LINK_STRETCH_MAX_US && t.game != NULL && t.mode == LINK_TIMING_SMOOTH, "Smooth + Four Swords -> Smooth cap (forced); the game is still recognised for the log");
        t = link_timing_resolve(LINK_TIMING_SMOOTH, other, sizeof other);
        CHECK(t.cap_us == LINK_STRETCH_MAX_US, "Smooth + another game -> Smooth cap");
        t = link_timing_resolve(LINK_TIMING_COMPAT, other, sizeof other);
        CHECK(t.cap_us == LINK_STRETCH_COMPAT_MAX_US && t.game == NULL && t.mode == LINK_TIMING_COMPAT, "Compatible + another game -> Compatible cap (forced)");
        t = link_timing_resolve(LINK_TIMING_COMPAT, NULL, 0);
        CHECK(t.cap_us == LINK_STRETCH_COMPAT_MAX_US, "Compatible needs no ROM image at all");
        const int bad[] = { -1, 3, 4, 77, 255, INT_MIN, INT_MAX };
        int ok = 1;
        for (size_t i = 0; i < sizeof bad / sizeof bad[0]; i++) {
            LinkTiming a = link_timing_resolve(bad[i], fs, sizeof fs), b = link_timing_resolve(bad[i], other, sizeof other);
            if (a.mode != LINK_TIMING_AUTO || a.cap_us != LINK_STRETCH_COMPAT_MAX_US || b.mode != LINK_TIMING_AUTO || b.cap_us != LINK_STRETCH_MAX_US) ok = 0;
        }
        CHECK(ok, "an unknown mode value (corrupt preference, newer build) acts as Auto");
        CHECK(link_timing_resolve(LINK_TIMING_AUTO, fs, sizeof fs).sweep, "Auto + Four Swords: the link-up search runs");
        CHECK(!link_timing_resolve(LINK_TIMING_AUTO, other, sizeof other).sweep && !link_timing_resolve(LINK_TIMING_AUTO, NULL, 0).sweep,
              "Auto + another game (or no image): no search");
        CHECK(!link_timing_resolve(LINK_TIMING_SMOOTH, fs, sizeof fs).sweep && !link_timing_resolve(LINK_TIMING_COMPAT, fs, sizeof fs).sweep,
              "an explicit Smooth or Compatible choice is a fixed length even for Four Swords: no search");
        CHECK(link_timing_resolve(77, fs, sizeof fs).sweep && link_timing_resolve(INT_MIN, fs, sizeof fs).sweep, "an unknown mode acts as Auto here too");
    }

    printf("== link_timing_mode_name() / link_timing_rom_title(): the log lines\n");
    CHECK(!strcmp(link_timing_mode_name(LINK_TIMING_AUTO), "auto") && !strcmp(link_timing_mode_name(LINK_TIMING_SMOOTH), "smooth") &&
          !strcmp(link_timing_mode_name(LINK_TIMING_COMPAT), "compat") && !strcmp(link_timing_mode_name(42), "auto"), "mode names (unknown -> auto)");
    {
        char t[LINK_ROM_TITLE_LEN + 1u];
        make_rom(rom, sizeof rom, "GBAZELDA");
        link_timing_rom_title(rom, sizeof rom, t);
        CHECK(!strcmp(t, "GBAZELDA"), "the title is copied up to its NUL padding");
        make_rom(rom, sizeof rom, "ABCDEFGHIJKL");   /* all 12 bytes used, no NUL inside the title field... */
        memcpy(rom + 0xAC, "BPEE", 4);               /* ...and the 4-byte game code right behind it, as in a real header */
        memset(t, 'x', sizeof t);
        link_timing_rom_title(rom, sizeof rom, t);
        CHECK(!strcmp(t, "ABCDEFGHIJKL") && strlen(t) == 12, "a full 12-byte title is terminated inside the 13-byte buffer (ASan would catch an overrun)");
        make_rom(rom, sizeof rom, NULL);
        rom[0xA0] = 'A'; rom[0xA1] = 0x01; rom[0xA2] = 0xFF; rom[0xA3] = 'B';
        link_timing_rom_title(rom, sizeof rom, t);
        CHECK(!strcmp(t, "A..B"), "control and non-ASCII bytes become '.' (a log line must stay printable)");
        memset(t, 'x', sizeof t);
        link_timing_rom_title(rom, 0xABu, t);
        CHECK(t[0] == '\0', "a truncated image gives an empty title");
        memset(t, 'x', sizeof t);
        link_timing_rom_title(NULL, 0, t);
        CHECK(t[0] == '\0', "no image gives an empty title");
    }

    printf("== the search state machine (link_sweep_on_transfer / link_sweep_on_port_reset)\n");
    {
        Drv d;

        drv_init(&d, 100);
        CHECK(d.s.index == 0 && link_sweep_cap_us(&d.s) == link_sweep_step_cap_us(0) && !d.s.locked && !d.s.seen_probe && d.s.cur.transfers == 0,
              "a new search starts at the first length, not locked, nothing seen");

        for (int i = 0; i < 3000; i++) feed(&d, (uint16_t)(0x1000 + i), 0);
        CHECK(d.ev == 0 && d.s.index == 0 && d.s.cur.transfers == 0 && !d.s.seen_probe,
              "3,000 transfers before the game's first probe: no step used up, no event (the dwell is counted from the first probe)");

        drv_init(&d, 100);
        feed(&d, 0xFEFE, 0); feed(&d, 0xFEFE, 0); feed(&d, 0xFFFF, 0); feed(&d, 0, 0); feed(&d, 0xFEFE, 0);
        CHECK(d.s.cur.rounds == 1 && d.s.round_open, "a 0xFEFE straight after a 0xFEFE is the round's counter word, not a probe (counter counts down through 0xFEFE); the next one after other words is");
        drv_init(&d, 100);
        feed(&d, 0, 0); feed(&d, 0xFEFE, 0); feed(&d, 0xFEFE, 0xFFFF);
        CHECK(d.s.seen_probe && d.s.cur.transfers == 2 && d.s.round_words == 2, "the session's first probe counts as a transfer and opens a round; words before it are not in the round");

        /* round statistics: 10 rounds of 7 words, every second one answered; the 11th probe closes the 10th round */
        drv_init(&d, 65400);                                   /* 65,400 + 10 x 44 ticks passes 65,536: the stamp wraps inside the run */
        for (int r = 0; r < 10; r++) round_(&d, FS_ROUND_TRANSFERS, r & 1);
        feed(&d, 0xFEFE, 0);
        const LinkSweepStep *c = &d.s.cur;
        CHECK(c->rounds == 10 && c->words == 70 && c->answered == 5 && c->best_run == 1 && !d.s.locked && d.ev == 0,
              "10 rounds of 7 words, every second one answered: counted exactly, no lock, no event");
        CHECK(c->periods == 10 && c->period_ticks == 10u * FRAME_TICKS && c->transfers == 71,
              "the probe-to-probe period is measured in link ticks (44 here), across the 16-bit stamp wrap (the tick started at 65,400 and wrapped in the 3rd round)");

        /* what counts as an answer */
        {
            const uint16_t replies[] = { 0x0000, 0xFFFF, 0x0001, 0x8000, 0xFFFE, 0x0020 };
            const int want[]         = {      0,      0,      1,      1,      1,      1 };
            int ok = 1;
            for (size_t i = 0; i < sizeof replies / sizeof replies[0]; i++) {
                drv_init(&d, 0);
                feed(&d, 0xFEFE, 0); feed(&d, 0xFFD0, replies[i]); feed(&d, 0xFEFE, 0);
                if ((d.s.cur.answered == 1u) != (want[i] != 0)) { ok = 0; printf("      reply %04X: answered=%u\n", replies[i], d.s.cur.answered); }
            }
            CHECK(ok, "an answer is any reply other than 0x0000 / 0xFFFF (nothing there / the idle line)");
        }

        /* lock: 3 completed answered rounds in a row */
        drv_init(&d, 0);
        round_(&d, 7, 1); round_(&d, 7, 1); round_(&d, 7, 1);
        CHECK(d.locks == 0 && d.s.cur.rounds == 2 && !d.s.locked, "two completed answered rounds (the third is still open): not locked");
        feed(&d, 0xFEFE, 0);
        CHECK(d.locks == 1 && (d.ev & LINK_SWEEP_EV_LOCK) && d.s.locked && d.s.run == 3, "the probe that completes the third answered round locks (event raised once)");
        for (int r = 0; r < 200; r++) round_(&d, 7, 1);
        CHECK(d.locks == 1 && d.steps == 0 && d.s.locked && d.s.index == 0 && d.s.cur.transfers > 2u * LINK_SWEEP_DWELL,
              "locked: 1,400+ more transfers (more than two dwell times) never advance the step, and the event is not raised again");
        /* a run broken by a silent round starts over */
        drv_init(&d, 0);
        round_(&d, 7, 1); round_(&d, 7, 1); round_(&d, 7, 0); round_(&d, 7, 1); round_(&d, 7, 1); feed(&d, 0xFEFE, 0);
        CHECK(d.locks == 0 && !d.s.locked && d.s.run == 2 && d.s.cur.best_run == 2, "answered, answered, silent, answered, answered: no lock (best run 2)");

        /* unlock: 2 silent rounds in a row end a lock (one is forgiven) */
        drv_init(&d, 0);
        for (int r = 0; r < 5; r++) round_(&d, 7, 1);
        round_(&d, 7, 0); round_(&d, 7, 1);
        CHECK(d.s.locked && d.unlocks == 0, "locked; one silent round in between: still locked");
        round_(&d, 7, 0); round_(&d, 7, 0); feed(&d, 0xFEFE, 0);
        CHECK(!d.s.locked && d.unlocks == 1 && d.s.silent_run == 2, "two silent rounds in a row: the lock ends");
        CHECK(d.steps == 0 && d.s.index == 0 && d.s.cur.best_run == 5,
              "...a lock lost early leaves the step running at the same length (its dwell is not used up yet), its numbers kept");
        for (int r = 0; r < 200 && !d.steps; r++) round_(&d, 7, 0);
        CHECK(d.steps == 1 && d.s.index == 1 && d.s.done_index == 0 && d.s.done.answered == 6u && d.s.done.best_run == 5u,
              "...and it ends when the dwell is used up, reporting what the step saw (6 answered rounds, best run 5)");
        /* a lock lost late: the locked step has used up its dwell long ago, so it ends with the unlock */
        drv_init(&d, 0);
        for (int r = 0; r < 200; r++) round_(&d, 7, 1);
        round_(&d, 7, 0); round_(&d, 7, 0);
        CHECK(d.s.locked && d.steps == 0, "(setup) a long lock, two silent rounds sent but the second is not complete yet");
        feed(&d, 0xFEFE, 0);
        CHECK(d.unlocks == 1 && d.steps == 1 && (d.ev & LINK_SWEEP_EV_UNLOCK) && d.s.index == 1 && link_sweep_cap_us(&d.s) == link_sweep_step_cap_us(1),
              "a lock lost after its dwell was used up: the search moves on to the next length at once (unlock and step in the same transfer)");
        CHECK(d.s.done_index == 0 && d.s.done.cap_us == link_sweep_step_cap_us(0) && d.s.done.answered >= 195u,
              "...and the step that was locked is the one reported");

        /* a step ends after DWELL transfers, counted from the first probe; its numbers are kept; the next one starts clean */
        drv_init(&d, 0);
        for (int i = 0; i < 100; i++) feed(&d, 0x2000, 0);                                  /* before the first probe */
        unsigned n_in_step = 0, ev_step_at = 0;
        for (int r = 0; r < 200 && !d.steps; r++) {
            for (unsigned k = 0; k < FS_ROUND_TRANSFERS && !d.steps; k++) {
                unsigned before = d.steps;
                feed(&d, k == 0 ? 0xFEFEu : (k == 1 ? 0xFFD0u : 0u), 0);
                n_in_step++;
                if (d.steps != before) ev_step_at = n_in_step;
            }
            d.tick += 2;
        }
        CHECK(ev_step_at == LINK_SWEEP_DWELL && d.s.index == 1, "the step ends exactly at the DWELL-th transfer after the first probe");
        CHECK(d.s.done.cap_us == link_sweep_step_cap_us(0) && d.s.done.transfers == LINK_SWEEP_DWELL && d.s.done.rounds >= 80u && d.s.done.words == d.s.done.rounds * 7u && d.s.done.answered == 0,
              "its numbers are kept in done: length, transfers, rounds (the one in progress is dropped), words, answers");
        CHECK(d.s.cur.cap_us == link_sweep_step_cap_us(1) && d.s.cur.transfers == 0 && d.s.cur.rounds == 0 && !d.s.round_open && d.s.run == 0 && d.s.silent_run == 0,
              "the next step starts clean, with no half round carried over");

        /* run does not carry over a step boundary: two answered rounds before, one after must not lock */
        drv_init(&d, 0);
        d.s.cur.transfers = LINK_SWEEP_DWELL - 3u * 7u;
        d.s.seen_probe = true;
        round_(&d, 7, 1); round_(&d, 7, 1); round_(&d, 7, 1); round_(&d, 7, 1); round_(&d, 7, 1); feed(&d, 0xFEFE, 0);
        CHECK(d.steps >= 1 && d.locks == 0 && !d.s.locked, "a run of answered rounds interrupted by the end of a step does not lock in the next one (a round that straddles two lengths says nothing about either)");

        /* the whole table is walked in order, and wraps */
        drv_init(&d, 0);
        int in_order = 1;
        for (uint32_t step = 0; step < 2u * LINK_SWEEP_STEPS + 3u; step++) {
            const unsigned before = d.steps;
            int guard = 0;
            while (d.steps == before && guard++ < 5000) { round_(&d, 7, 0); }
            if (d.s.index != (step + 1u) % LINK_SWEEP_STEPS || d.s.done_index != step % LINK_SWEEP_STEPS || d.s.done.cap_us != link_sweep_step_cap_us(step)) in_order = 0;
        }
        CHECK(in_order && d.s.index == 3u, "35 silent steps: visited in table order, done_index/cap follow, wraps after the 16th");

        /* the game resets its port (RCNT write) */
        drv_init(&d, 0);
        for (int r = 0; r < 6; r++) round_(&d, 7, 1);
        CHECK(d.s.locked, "(setup) locked");
        unsigned ev = link_sweep_on_port_reset(&d.s);
        CHECK(ev == (LINK_SWEEP_EV_UNLOCK | LINK_SWEEP_EV_STEP) && !d.s.locked && d.s.index == 1 && d.s.done_index == 0 && d.s.done.answered >= 4u,
              "a port reset while locked: lock ends, the step is reported, the next length starts");
        round_(&d, 7, 0); round_(&d, 7, 0);
        const uint32_t idx = d.s.index, tr = d.s.cur.transfers, rds = d.s.cur.rounds;
        ev = link_sweep_on_port_reset(&d.s);
        CHECK(ev == 0u && d.s.index == idx && d.s.cur.transfers == tr && d.s.cur.rounds == rds, "a port reset while searching: no event, no step skipped, the statistics stay");
        CHECK(!d.s.round_open && d.s.run == 0 && d.s.silent_run == 0 && !d.s.have_prev && !d.s.round_answered && d.s.round_words == 0,
              "...only the round in progress is dropped (it would otherwise be measured across the restart)");
        feed(&d, 0xFEFE, 0);
        CHECK(d.s.round_open && d.s.round_words == 1, "...and the first transfer after a reset starts a round again");
        /* a reset right after a probe: the first FEFE afterwards is a probe even though the last word before the reset was FEFE */
        drv_init(&d, 0);
        feed(&d, 0xFEFE, 0); link_sweep_on_port_reset(&d.s); feed(&d, 0xFEFE, 0);
        CHECK(d.s.round_open && d.s.round_words == 1, "the probe-after-probe exclusion does not span a port reset");

        /* an unused search re-inited is a clean one */
        link_sweep_init(&d.s);
        CHECK(d.s.index == 0 && d.s.cur.transfers == 0 && !d.s.seen_probe && !d.s.locked && !d.s.have_prev && d.s.done.transfers == 0 && d.s.done_index == 0,
              "link_sweep_init() clears everything (a new link session starts at the first length with no memory of the last)");
    }

    printf("== the search over what the game really did (capture_replay.h: 700 transfers of each real capture)\n");
    {
        struct Rp { unsigned steps, locks, unlocks; LinkSweepStep done; LinkSweep s; } rp[2];
        const uint16_t (*caps[2])[3] = { k_cap_oct31, k_cap_nov2 };
        for (int c = 0; c < 2; c++) {
            memset(&rp[c], 0, sizeof rp[c]);
            link_sweep_init(&rp[c].s);
            for (unsigned i = 0; i < CAP_REPLAY_N; i++) {
                const unsigned e = link_sweep_on_transfer(&rp[c].s, caps[c][i][0], caps[c][i][1], caps[c][i][2]);
                if (e & LINK_SWEEP_EV_STEP)   { rp[c].steps++; rp[c].done = rp[c].s.done; }
                if (e & LINK_SWEEP_EV_LOCK)   rp[c].locks++;
                if (e & LINK_SWEEP_EV_UNLOCK) rp[c].unlocks++;
            }
        }
        for (int c = 0; c < 2; c++) {
            const LinkSweepStep *d = &rp[c].done;
            const char *nm = c == 0 ? "31 Oct capture (4.5 ms)" : "2 Nov capture (1.5 ms)";
            char msg[200];
            printf("      %s: step of %u transfers, %u rounds, %u answered (longest run %u), %u words, probe every %u.%u ticks\n", nm, d->transfers, d->rounds,
                   d->answered, d->best_run, d->words, d->periods ? d->period_ticks * 10u / d->periods / 10u : 0u, d->periods ? d->period_ticks * 10u / d->periods % 10u : 0u);
            snprintf(msg, sizeof msg, "%s: the search never locks (the slave never answers more than two rounds in a row) and never unlocks", nm);
            CHECK(rp[c].locks == 0 && rp[c].unlocks == 0 && !rp[c].s.locked && d->best_run <= 2u, msg);
            snprintf(msg, sizeof msg, "%s: one step finishes, after exactly %u transfers", nm, (unsigned)LINK_SWEEP_DWELL);
            CHECK(rp[c].steps == 1 && d->transfers == LINK_SWEEP_DWELL, msg);
            snprintf(msg, sizeof msg, "%s: every round the search sees is exactly 7 transfers (%u rounds, %u words)", nm, d->rounds, d->words);
            CHECK(d->rounds >= 80u && d->rounds <= 86u && d->words == d->rounds * FS_ROUND_TRANSFERS, msg);
            snprintf(msg, sizeof msg, "%s: the slave answered every second round (%u of %u)", nm, d->answered, d->rounds);
            CHECK(d->answered * 2u + 2u >= d->rounds && d->answered * 2u <= d->rounds + 2u, msg);
        }
        CHECK(rp[0].done.periods && rp[0].done.period_ticks / rp[0].done.periods >= 87u && rp[0].done.period_ticks / rp[0].done.periods <= 88u,
              "31 Oct capture: the probe repeats every 87-88 ticks (2 frames)");
        CHECK(rp[1].done.periods && rp[1].done.period_ticks / rp[1].done.periods >= 43u && rp[1].done.period_ticks / rp[1].done.periods <= 44u,
              "2 Nov capture: the probe repeats every 43-44 ticks (1 frame): the period follows the transfer length");
    }

    printf("\n%s (%d failure(s))\n", fails ? "FAILED" : "ALL PASSED", fails);
    return fails ? 1 : 0;
}
