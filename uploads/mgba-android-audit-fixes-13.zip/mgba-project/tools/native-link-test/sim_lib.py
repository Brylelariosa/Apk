"""Shared harness of the two-phone link simulation: starts a host and a child `sim_dev` process joined by UDP on
loopback, parses their RESULT lines, and counts checks. Used by run_sim.py (the 16-word packet ROM model) and
run_sim_fs.py (the Four Swords link-up model and the host's link-up search)."""
import subprocess, sys, time, os, signal

port = [47100]
fails = 0
def check(cond, msg):
    global fails
    print(("PASS  " if cond else "FAIL  ") + msg)
    if not cond: fails += 1

def kv(line):
    return dict(p.split('=', 1) for p in line.split()[1:])

def run(name, seconds, oneway_ms, sync, child_enter_s=0.0, fastpath=1, loss=0.0, pause_child=None, smooth=0, fs=0, timing=0, win=(1, 0), show_sweep=False):
    port[0] += 2
    a, b = port[0], port[0] + 1
    args = lambda role, me, peer, enter: ['./sim_dev', role, str(me), str(peer), str(seconds), str(oneway_ms), str(sync), str(enter), str(fastpath), '0', str(loss), str(smooth), str(fs), str(timing), str(win[0]), str(win[1])]
    c = subprocess.Popen(args('child', a, b, child_enter_s), stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    h = subprocess.Popen(args('host', b, a, 0), stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if pause_child:
        time.sleep(pause_child[0]); os.kill(c.pid, signal.SIGSTOP)
        time.sleep(pause_child[1]); os.kill(c.pid, signal.SIGCONT)
    try:
        ho, he = h.communicate(timeout=seconds + 40)
        co, ce = c.communicate(timeout=40)
    except subprocess.TimeoutExpired:
        h.kill(); c.kill()
        check(False, f"{name}: DEADLOCK — a process did not finish")
        return None, None
    if h.returncode or c.returncode:
        print(he[-1500:]); print(ce[-1500:])
        check(False, f"{name}: a process crashed / sanitizer error (host rc={h.returncode}, child rc={c.returncode})")
        return None, None
    hr = [l for l in ho.splitlines() if l.startswith('RESULT')][0]
    cr = [l for l in co.splitlines() if l.startswith('RESULT')][0]
    print(f"   host : {hr}\n   child: {cr}")
    if show_sweep:     # the host's search log lines, as the phone's log file would carry them (stderr: "[host  12.345] I Link sweep: ...")
        lines = [l.split('] ', 1)[-1] for l in he.splitlines() if 'Link sweep:' in l]
        shown = lines if len(lines) <= 14 else lines[:7] + [f"... ({len(lines) - 14} more lines) ..."] + lines[-7:]
        for l in shown: print(f"      {l}")
    return kv(hr), kv(cr)



def finish():
    """Prints the summary and exits non-zero if any check failed."""
    print(f"\n{'FAILED' if fails else 'ALL PASSED'} ({fails} failure(s))")
    sys.exit(1 if fails else 0)
