#!/usr/bin/env bash
# Host-side test of the link code in mgba_jni.c: link_sio_write_register(), the clock-tie tick,
# the child's tick-driven delivery / hold, link_child_apply(), the lock-step
# nativeLinkChildExchange(), nativeLinkStart/Stop — extracted verbatim from the real source and
# run against stubbed JNI/mGBA types (link_test_stubs.h); plus link_timing.h's own test. Needs gcc only.
set -euo pipefail
cd "$(dirname "$0")"
python3 extract.py
gcc -std=gnu11 -Wall -Wextra -Wno-unused-function -Wno-unused-parameter -g -fsanitize=address,undefined \
    -fno-omit-frame-pointer test_sio_regs.c -o test_sio_regs -lpthread
./test_sio_regs
# the real log-file code (rotation / single writer / append mode)
gcc -std=gnu11 -Wall -Wextra -Wno-unused-function -Wno-unused-parameter -g -fsanitize=address,undefined \
    -fno-omit-frame-pointer test_log.c -o test_log -lpthread
./test_log
# the per-game link timing policy (link_timing.h): pure C, the header exactly as it ships
gcc -std=gnu11 -Wall -Wextra -g -fsanitize=address,undefined -fno-omit-frame-pointer test_link_timing.c -o test_link_timing
./test_link_timing
rm -f test_sio_regs test_log test_link_timing extracted_r*.c extracted_rlog.c
