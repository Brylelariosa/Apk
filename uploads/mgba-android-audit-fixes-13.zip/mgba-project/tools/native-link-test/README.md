# native-link-test

Host-side tests for the multiplayer code in `app/src/main/cpp/` — they need only `gcc` and `python3`.
`extract.py` cuts the **real** functions out of `mgba_jni.c` (so a test can't drift from the shipping code)
and the tests compile them against the tiny JNI/mGBA stand-ins in `link_test_stubs.h`.

| script | what it runs | time |
|---|---|---|
| `run.sh` | `test_mailbox.c` — the child's lock-step mailbox, under ASan+UBSan and ThreadSanitizer (a TSan report is shown in full and fails the script) | ~10 s |
| `run_regs.sh` | `test_sio_regs.c` — SIO register semantics, the clock-tie tick, the child's tick-driven delivery / hold / governor, `nativeLinkStart/Stop`, the per-session transfer-time cap; `test_log.c` — the real log-file code (format, rotation, concurrent writers); `test_link_timing.c` — the per-game link timing policy in `link_timing.h` | ~15 s |
| `run_sim.sh [all\|legacy\|fs]` | `sim_dev.c` ×2 — **two simulated phones** (separate processes running the real link code) joined by UDP with an artificial delay: old behaviour (reproduces the captured failure), new behaviour over Wi-Fi / poor Wi-Fi / Bluetooth-like delay, packet loss, a not-ready child, a frozen child (`run_sim.py`, scenarios 1-14, ~3 min); the Four Swords link-up model and the host's link-up search (`run_sim_fs.py`, F1-F7, ~2 min) | ~5 min |

The simulation's ROM is a **model** built from the two real captures (a host that probes with a 16-word packet,
a child whose ROM resets its link hardware if a packet isn't complete within 6 of its own frames). It checks
that the code does what the clock-tie fix claims and cannot deadlock; it cannot say what a particular real ROM does.

## Pass 8 additions (smooth link)
- `link_test_stubs.h` models the split-phase methods (`jniExchangeBegin` / `jniExchangeEnd` /
  `jniLastRttUs`) with hooks (`g_begin_hook`, `g_end_hook`, `g_rtt_hook`); `g_smooth_methods_present = 0`
  reproduces a Kotlin side that lacks them.
- `test_sio_regs.c` — 33 new assertions: the Start write returns at once with Start/Busy set, the answer
  is collected only when the transfer completes, the adaptive transfer time follows the measured round
  trip (grows when a collect had to wait, shortens slowly when it did not, capped, unmoved by a timeout),
  answers given locally (peer absent / not in multi mode), teardown with a request in flight, the
  blocking fallback when the completion event is still queued, and the `nativeLinkStart` variants.
- `sim_dev.c` takes an 11th argument (`smooth`, 0/1) and models Begin/End with a delay line so the
  one-way delay is not paid inside the send; `run_sim.py` scenarios 8-14 compare it with the blocking
  exchange at 2 ms, 0.15 ms (local link), 3 ms and 15 ms one-way, under loss, with a late child and with a
  frozen child. Scenario 6's "0 resets at 1% loss" was statistical — one reset in a single run is noise (pass 15: allowed 1, measured on the unchanged pass-13 code too).
- Run each scenario on its own if your sandbox kills long background jobs (each is 10-40 s).

## Pass 12 (ThreadSanitizer)
- `test_mailbox.c`: the fake game thread and the main thread shared `FakeChild.run` / `isr_count` as plain ints —
  a data race in the test itself (not in `link_mailbox.h`, whose fields are all accessed under its mutex). Both are
  C11 `atomic_int` now; the fake thread's other writes happen before the `atomic_fetch_add` that publishes them.
- `run.sh` used to pipe the TSan run through `tail -4`, which hid every report behind a passing-looking summary; it now
  prints the whole report and exits non-zero when TSan fails.

## Pass 14 (Zelda: A Link to the Past & Four Swords — per-game link timing; its premise was disproved in pass 15)
- `link_timing.h` (pure C, in `app/src/main/cpp/`) holds the two caps on the host's emulated transfer time (Smooth 4500 us,
  Compatible 1500 us), the Auto / Smooth / Compatible modes and the rule that recognises the game (the ROM header title
  `GBAZELDA` at 0xA0). Pass 14 assumed a fixed 2-frame probe period and a 13-transfer round and chose 1.5 ms for it; the
  2 Nov 2026 capture with that very build showed the period adapting and the round still 7 transfers, so 1.5 ms did not
  help — see pass 15 below. The mechanics it added are still used: the per-session cap, the title match, the log helpers.
- `link_test_stubs.h`: `struct GBA` has `memory.rom` / `memory.romSize` now, because `nativeLinkStart()` reads the header title.
- `test_sio_regs.c` (138 -> 160 checks in pass 14): the cap a session gets for every setting and ROM; no inheritance between
  sessions; the cap bounds the stretch but not the round-trip measurement; a 1.5 ms transfer is 25,165 cycles with its IRQ
  at that moment. `SMOOTH_ON()` resets the round-trip estimate, so the smooth tests no longer depend on the order they run in.
- `run_sim.py` was split: `sim_lib.py` has the process launcher and the check helpers (`run`, `check`, `finish`);
  `run_sim.py` (scenarios 1-14, unchanged in what it checks) and `run_sim_fs.py` import it.
  `run_sim.sh` sets `PYTHONDONTWRITEBYTECODE=1` so that importing `sim_lib` leaves no `__pycache__` in the tree.
- The extraction markers in `mgba_jni.c` that `extract.py` cuts at must stay intact; `nativeLinkSetTimingMode()` sits
  right before `nativeLinkStart()`, inside the third region.

## Pass 15 (Four Swords: the link-up search)
- **What the two captures showed** (see CHANGELOG.md, pass 15): rounds of exactly 7 transfers at 4.5 ms *and* at 1.5 ms, the
  slave answering every second round, and a probe period that follows the transfer length (2 frames, 1 frame). Nothing in
  them says which transfer length, if any, makes the master send the 12+ transfers per probe the slave's receive code needs.
- `link_timing.h` gained the **search** (host, Auto + a known game): a table of 16 lengths (first: exact cable timing),
  600 transfers each, a state machine that counts probe rounds and whether the slave answered, locks on 3 answered rounds in
  a row and unlocks on 2 silent ones or when the game resets its link port. `mgba_jni.c` applies the length as the
  host's stretch (`g_link_stretch_fixed`), feeds every completed host transfer to the state machine and logs one
  `Link sweep:` line per finished step.
- `test_link_timing.c` (30 -> 79 checks): the table (16 distinct lengths, wraps, holds exact timing and 1.5 ms, covers the working
  model's windows), `resolve().sweep` truth table, the state machine (dwell counted from the first probe, round accounting,
  what counts as an answer, lock / unlock / step / port reset, the 16-bit stamp wrap), and **replays of 700 real transfers
  of each capture** (`capture_replay.h`, generated from the logs' `X` lines): the search never locks on what the game really
  did, and sees 7-transfer rounds with a probe every 87.6 / 43.8 ticks, as the logs say.
- `test_sio_regs.c` (160 -> 206 checks): which sessions run the search (host + smooth + Auto + the Four Swords title only),
  that the first length is the stretch from the first transfer, that `nativeLinkStop` ends it and a new session starts
  afresh, that the real transfer path feeds the search (steps after 600 transfers, locks after 3 answered rounds, stays put
  while locked, unlocks after 2 silent rounds, an RCNT write ends a lock), and that timed-out transfers are not counted.
- `sim_dev.c`'s Four Swords model was rewritten from the captures: 7-transfer rounds, a probe period that follows the
  transfer length, a slave that recognises only a probe that follows a complete block, replies that are zeros when the
  slave is not answering. It has **one synthetic knob** (arguments 14 and 15: a window of transfer lengths, in microseconds,
  in which the master sends full 13-word rounds). With no window nothing can ever link — the captures' pattern at every
  length — and the search must cycle without harm. **A model, not the cartridge:** whether the real cartridge has such a
  window, and where, is what the search on the phones is for.
- `run_sim_fs.py` F1-F7: F1 (Smooth forced, 4.5 ms) and F2 (Compatible forced, 1.5 ms) reproduce the two captures — 7-transfer
  rounds, period 2 / 1 frames, every second probe recognised, no link, 68 % / 34 % speed (captures: 77 % / 46 %). F3: a window
  at 2.4 ms — the search runs three steps (exact timing, 2.5 ms, 4.9 ms), locks on the fourth, the link completes and the
  search never moves again. F4: no window — it cycles through its lengths for 30 s, never locks, nothing breaks. F5-F7: a
  window at cable-like lengths — it links in the first step, on a local link (93 % speed), over Wi-Fi-like and Bluetooth-like delays.
  `sim_lib.run(..., show_sweep=True)` prints the host's `Link sweep:` log lines, i.e. what the phone's log would show.

