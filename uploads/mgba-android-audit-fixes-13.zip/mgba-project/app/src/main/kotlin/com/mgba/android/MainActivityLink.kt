package com.mgba.android

// Split out of MainActivity.kt (pass 46 — "refactor main activity into
// separate classes so organized") as internal extension functions on
// MainActivity, exactly the pattern already established in SharedUi.kt's
// own top-of-file comment (Thirty-second pass) for the same reason: every
// existing unqualified call site inside MainActivity.kt (and inside every
// other split-out file) keeps compiling completely unchanged, since Kotlin
// resolves an unqualified call to an internal extension function on the
// enclosing receiver type the same way it resolves a member call — no
// behavior change, purely a file-organization move. See MainActivity.kt's
// own top-of-file comment for the full file map.

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.text.InputType
import android.text.TextUtils
import android.text.format.DateFormat
import android.util.Log
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.Closeable
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.io.PrintWriter
import java.io.StringWriter
import java.util.concurrent.atomic.AtomicInteger
import java.util.zip.ZipInputStream
import kotlin.math.abs
import kotlin.math.roundToInt


/** Runs [action] immediately if Bluetooth permission is already granted
 *  (or not needed on this API level), otherwise requests it first. */
internal fun MainActivity.ensureBluetoothPermission(action: () -> Unit) {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) { action(); return }
    val granted = ContextCompat.checkSelfPermission(
        this, Manifest.permission.BLUETOOTH_CONNECT
    ) == PackageManager.PERMISSION_GRANTED
    if (granted) { action() }
    else { pendingBtAction = action; btPermissionLauncher.launch(Manifest.permission.BLUETOOTH_CONNECT) }
}


// ── Link cable UI ──────────────────────────────────────────────────────
// Two Settings rows:
//   "Link remote" — a link to ANOTHER phone, over Wi-Fi or Bluetooth (Host / Join each). Bluetooth used to be
//                   "Link local"; it moved here, since it is a link between two phones too.
//   "Link local"  — a link between two games on THIS phone, like My Boy!'s local link: the second game opens in
//                   its own window next to this one (PlayerTwoActivity) and the two link over loopback.
// Status is toasts only, plus the existing ⬤ LINK canvas overlay (drawLinkStatus, below) for "still connected".

/** Extra on the intent that opens the second window: join the host that is already listening here. */
internal const val EXTRA_LOCAL_LINK_JOIN = "com.mgba.android.LOCAL_LINK_JOIN"

internal fun MainActivity.showLinkRemoteDialog() {
    if (link.isConnected) { showLinkDisconnectDialog(); return }
    // The link is wired into the running game the moment the other phone joins, so there has to be one —
    // without it the two phones would connect and then have nothing to link.
    if (!romLoaded) { uiToast("Load a game first, then start a link"); return }
    AlertDialog.Builder(this).setTitle("Link remote — another phone")
        .setItems(arrayOf("Host — Wi-Fi", "Join — Wi-Fi", "Host — Bluetooth", "Join — Bluetooth")) { _, i ->
            when (i) {
                0 -> hostWifiLink()
                1 -> joinWifiLink()
                2 -> hostBluetoothLink()
                3 -> joinBluetoothLink()
            }
        }.show()
}

private fun MainActivity.hostWifiLink() {
    link.startWifiHost(
        onReady     = { ip -> showHostWaitDialog("Hosting — Wi-Fi", wifiHostMessage(ip)) },
        onConnected = { dismissHostWaitDialog(); onLinkConnected(true, "Wi-Fi") },
        onError     = { dismissHostWaitDialog(); uiToast("Host error: $it") })
}

private fun MainActivity.joinWifiLink() {
    uiToast("Scanning…")
    link.discoverWifiHosts(
        onFound = { hosts ->
            if (hosts.isEmpty()) showIpDialog()
            else AlertDialog.Builder(this)
                .setTitle("Select host")
                .setItems(hosts.toTypedArray()) { _, j -> joinWifi(hosts[j]) }
                .setNegativeButton("Enter IP") { _, _ -> showIpDialog() }.show()
        },
        onError = { showIpDialog() })
}

// FIX: BLUETOOTH_CONNECT is a runtime-dangerous permission on API 31+. It was declared in the manifest but
// never requested, so tapping either of the two Bluetooth options crashed the app on Android 12+ with an
// uncaught SecurityException from listenUsingInsecureRfcommWithServiceRecord() /
// createInsecureRfcommSocketToServiceRecord() / getBondedDevices().
private fun MainActivity.hostBluetoothLink() = ensureBluetoothPermission {
    showHostWaitDialog(
        "Hosting — Bluetooth",
        "Waiting for a paired phone to join…\n\nOn the other phone choose Link remote → Join — Bluetooth " +
            "and pick this phone from the list. The two phones must already be paired in " +
            "Android's Bluetooth settings.\n\nBluetooth has a longer delay than Wi-Fi, so the game " +
            "will run slower while it is waiting on the cable. Use Wi-Fi if you can."
    )
    link.startBluetoothHost(
        onConnected = { dismissHostWaitDialog(); onLinkConnected(true, "Bluetooth") },
        onError     = { dismissHostWaitDialog(); uiToast("BT error: $it") })
}

private fun MainActivity.joinBluetoothLink() = ensureBluetoothPermission {
    val devs = link.getBondedDevices()
    if (devs.isEmpty()) { uiToast("No paired devices"); return@ensureBluetoothPermission }
    AlertDialog.Builder(this).setTitle("Choose device")
        .setItems(devs.map { it.name ?: it.address }.toTypedArray()) { _, j ->
            uiToast("Connecting…")
            link.connectBluetooth(devs[j],
                onConnected = { onLinkConnected(false, "Bluetooth") },
                onError     = { uiToast("BT error: $it") })
        }.show()
}


// ── Link local ─────────────────────────────────────────────────────────
// See PlayerTwoActivity's class comment for how the second game window works and what it keeps separate.

/** A second window can only sit NEXT to this one when this app is in split-screen (multi-window) mode. */
private fun MainActivity.canShowSecondWindow(): Boolean =
    Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && isInMultiWindowMode

internal fun MainActivity.showLinkLocalDialog() {
    if (link.isConnected) { showLinkDisconnectDialog(); return }
    if (isPlayerTwo) {
        // The second window: it joins the first one's host. (The first window starts that and opens this one.)
        if (!romLoaded) {
            pendingLocalLinkJoin = true
            uiToast("Choose a game in this window — it links to the other game by itself once it has loaded")
            return
        }
        joinLocalHost()
        return
    }
    if (!romLoaded) { uiToast("Load a game first, then start a link"); return }   // see showLinkRemoteDialog()
    if (!canShowSecondWindow()) { showSplitScreenHelpDialog(); return }
    AlertDialog.Builder(this).setTitle("Link local — two games on this phone")
        .setMessage(
            "Opens a second game window next to this one and links the two games, like a link cable " +
                "between two Game Boys.\n\nThis window is the host. In the new window choose the other " +
                "game — it connects by itself once it has loaded.\n\nThe second window keeps its own saves."
        )
        .setPositiveButton("Start") { _, _ -> startLocalLink() }
        .setNegativeButton("Cancel", null)
        .show()
}

private fun MainActivity.showSplitScreenHelpDialog() {
    AlertDialog.Builder(this).setTitle("Split the screen first")
        .setMessage(
            "Link local runs the second game in its own window next to this one, so this app has to be in " +
                "split-screen mode first.\n\n" +
                "1. Open Recents (the ▢ button, or swipe up and hold).\n" +
                "2. Tap this app's icon above its preview and choose Split screen (on some phones: long-press " +
                "the title, or the ⋮ menu).\n" +
                "3. Pick any app for the other half, then open ▤ → Link local again.\n\n" +
                "If your phone has no split-screen mode, use Link remote with two phones instead."
        )
        .setPositiveButton("OK", null)
        .show()
}

/** First window: listen on loopback, then open the second window beside this one. */
private fun MainActivity.startLocalLink() {
    link.startWifiHost(
        onReady     = {
            showHostWaitDialog(
                "Link local — waiting",
                "Waiting for the second game…\n\nIn the other window choose a game. It connects by itself " +
                    "as soon as it has loaded."
            )
        },
        onConnected = { dismissHostWaitDialog(); onLinkConnected(true, "Local") },
        onError     = { dismissHostWaitDialog(); uiToast("Local link error: $it") },
        local       = true)
    try {
        startActivity(
            Intent(this, PlayerTwoActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT)
                .putExtra(EXTRA_LOCAL_LINK_JOIN, true)
        )
    } catch (t: Throwable) {
        Log.e(TAG, "couldn't open the second game window", t)
        link.cancelAttempt()
        dismissHostWaitDialog()
        uiToast("Couldn't open the second game window: ${t.message ?: t.javaClass.simpleName}")
    }
}

/** Second window: connect to the first window's loopback host. Runs once its game is loaded (see
 *  loadRomFromUri()) or from this window's own "Link local" row. */
internal fun MainActivity.joinLocalHost() {
    if (link.isConnected) return
    uiToast("Linking to the first game…")
    link.connectWifi("127.0.0.1",
        onConnected = { onLinkConnected(false, "Local") },
        onError     = { uiToast("Local link error: $it") })
}


internal fun MainActivity.showLinkDisconnectDialog() {
    AlertDialog.Builder(this).setTitle("Link Connected ✓")
        .setItems(arrayOf("Disconnect")) { _, _ -> stopLink() }.show()
}


internal fun MainActivity.showIpDialog() {
    val et = EditText(this).apply { hint = "192.168.x.x" }
    AlertDialog.Builder(this).setTitle("Host IP").setView(et)
        .setPositiveButton("Connect") { _, _ -> joinWifi(et.text.toString().trim()) }.show()
}


internal fun MainActivity.joinWifi(ip: String) {
    if (ip.isBlank()) return
    uiToast("Connecting…")
    link.connectWifi(ip,
        onConnected = { onLinkConnected(false, "Wi-Fi") },
        onError     = { uiToast("Connect error: $it") })
}


/** Runs on the main thread when a link transport comes up (either role, either transport). */
internal fun MainActivity.onLinkConnected(isHost: Boolean, via: String) {
    // HOST FIX: this callback is posted from the connect thread, so by the time it runs the transport can
    // already be gone — Cancel pressed, or the other phone dropped in between. Wiring the emulator to a
    // transport that no longer exists leaves it waiting on answers that can never come.
    if (!link.isConnected) return
    // Per-game transfer timing (link_timing.h): the native side reads the mode inside nativeLinkStart(), together with
    // the ROM header. Its own try: if this call ever failed (an old native library), the link must still start —
    // with the previous or default mode — rather than the whole connection failing over a tuning knob.
    try {
        EmulatorEngine.nativeLinkSetTimingMode(linkTiming.code)
    } catch (t: Throwable) {
        Log.w(TAG, "nativeLinkSetTimingMode threw", t)
    }
    val ok = try {
        EmulatorEngine.nativeLinkStart(link, isHost, linkClockSync, linkSmooth)
    } catch (t: Throwable) {
        // Nothing here may take the app down: a failure just means no link.
        Log.e(TAG, "nativeLinkStart threw", t)
        false
    }
    if (!ok) {
        // The emulator couldn't take the link (no game running, or the native hookup failed). A "connected"
        // transport with nothing wired into the game can never work — close it, which also tells the other
        // phone, instead of leaving a LINK badge that does nothing.
        link.disconnect()
        uiToast("Couldn't start the link — load a game and try again")
        return
    }
    uiToast("Link via $via")
}


// ── Host wait dialog ───────────────────────────────────────────────────
// Shown while a Host attempt is open. A toast used to be the only sign that hosting had started: it
// vanished after a couple of seconds, hid the IP the other player may need, and gave no way to stop
// hosting short of waiting out the 15-second window. File-level (not a MainActivity field) because the
// ready / connected / error callbacks arrive separately and each has to be able to close it.
private var hostWaitDialog: AlertDialog? = null

private fun wifiHostMessage(ip: String): String =
    if (ip == "0.0.0.0") {
        "Waiting for the other player…\n\nOn their phone choose Link remote → Join — Wi-Fi."
    } else {
        "Waiting for the other player…\n\nOn their phone choose Link remote → Join — Wi-Fi. " +
            "If it doesn't find this phone, they can enter this IP:\n\n$ip"
    }

internal fun MainActivity.showHostWaitDialog(title: String, message: String) {
    dismissHostWaitDialog()
    if (isFinishing) return
    val dlg = AlertDialog.Builder(this)
        .setTitle(title)
        .setMessage(message)
        // Back / tapping outside / the Cancel button all end up here: stop hosting right away.
        .setOnCancelListener { link.cancelAttempt(); hostWaitDialog = null }
        .setNegativeButton("Cancel") { d, _ -> d.cancel() }
        .create()
    dlg.window?.setBackgroundDrawable(roundedDialogBackground())
    hostWaitDialog = dlg
    dlg.show()
}

internal fun dismissHostWaitDialog() {
    try { hostWaitDialog?.dismiss() } catch (_: Exception) {}
    hostWaitDialog = null
}


internal fun MainActivity.stopLink() {
    EmulatorEngine.nativeLinkStop(); link.disconnect()
    uiToast("Disconnected")
}

