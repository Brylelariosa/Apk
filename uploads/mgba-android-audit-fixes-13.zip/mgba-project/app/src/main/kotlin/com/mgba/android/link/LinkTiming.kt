package com.mgba.android.link

/**
 * How long the HOST's emulated link transfers last — Settings → Debug → "Link timing".
 *
 * Smooth link hides the Wi-Fi round trip by letting every cable transfer last about as long as the round trip
 * (~4.5 ms of game time). Zelda: Four Swords' link-up never completes with that, and the two-phone logs of 31 Oct and
 * 2 Nov 2026 did not show a length that fixes it (1.5 ms, tried in pass 14, did not). So [AUTO] recognises that game
 * from the ROM header and has the host SEARCH for a length: it steps through a table of transfer lengths, watching
 * whether the other phone answers every round, and keeps the length that works — see `app/src/main/cpp/link_timing.h`
 * for the search, the evidence and the cost (speed over Wi-Fi while it searches). [AUTO] gives every other game the
 * long transfers as before; the other two modes force one fixed profile for every game (no search), as a safety net
 * and for experiments.
 *
 * Only the HOST's choice matters (the child follows the host's spacing), and it is read once per link session, in
 * `onLinkConnected()`, so a change applies from the next connection.
 *
 * The codes are the native `LINK_TIMING_*` constants in `link_timing.h`: they cross JNI as plain ints
 * (`EmulatorEngine.nativeLinkSetTimingMode`) and are what the preference stores, so they never change meaning.
 * `tools/link-timing-test` checks them against the header. Pure — no Android types.
 */
internal enum class LinkTiming(val code: Int, val label: String, val summary: String) {
    AUTO(0, "Auto (recommended)",
        "Zelda: Four Swords: the host tries different transfer lengths until the other phone answers (slower while it searches). Every other game: the fast long transfers."),
    SMOOTH(1, "Smooth",
        "Always the long transfers, no search: fastest over Wi-Fi. Zelda: Four Swords did not link up with them in testing."),
    COMPAT(2, "Compatible",
        "Always 1.5 ms transfers, no search: the game runs slower over Wi-Fi. Zelda: Four Swords did not link up with them in testing either; for experiments.");

    companion object {
        val DEFAULT: LinkTiming = AUTO

        /** The mode a stored or received [code] stands for; an unknown one (a corrupt preference, a value from a
         *  newer build) is [DEFAULT] — it must never stop a link from starting. */
        fun fromCode(code: Int): LinkTiming = values().firstOrNull { it.code == code } ?: DEFAULT
    }
}
