package com.mgba.android.saves

import java.util.concurrent.atomic.AtomicBoolean

/**
 * The one-at-a-time guard around everything that reads or replaces the native core's state: Quick Save / Quick Load,
 * the slot dialog's save / load / delete, the autosave — and a ROM load or Reset, which replace the core itself.
 *
 * Why the core swap has to take it too. `g_core_mutex` on the native side only makes each native call atomic; it does
 * not decide WHICH core a save/load thread reaches. An operation is tied to a ROM when it is requested (the slot file's
 * name is resolved from the game that was running at that moment) but only touches the core some time later, after the
 * file was staged — possibly through a slow Storage-folder provider. A core swap landing in between made it snapshot
 * the NEW game into the OLD game's slot, load the old game's slot into the new core (an accepted load also puts the
 * state's copy of the in-game save over the live one), or file a thumbnail under the wrong game. While a swap holds
 * this guard no operation can be in flight, and none can start before the replacement is complete.
 *
 * Why it can be [close]d. The same reasoning covers the activity's teardown, from the other side: `onDestroy()` frees
 * the native core, and a ROM load or Reset still running on its background thread (staging a big zip, waiting for an
 * answer to a dialog that is gone) used to reach `nativeLoadROM()` afterwards and build a brand-new core that nothing
 * would ever free — or, if a new activity instance was already loading its own game, replace that one's core. The
 * check "is the activity finishing" that those threads made came after the native call, in the UI post, which is too
 * late, and one made before it would not close the gap either: teardown can begin right after the check. The check has
 * to sit INSIDE the guard, and teardown has to wait for the guard. So teardown calls [close] — from then on no one can
 * take the guard, a swap waiting for it gives up at once — and then [awaitIdle], which waits for the one holder that
 * may already be inside (a swap in the middle of `nativeLoadROM()`) before the core is destroyed.
 *
 * A flag, not a lock: not reentrant, no owner check. The holder is a short-lived worker thread, and a second tap while
 * one operation runs is meant to be a silent no-op ([tryAcquire] returns false). Every acquirer must [release] in a
 * `finally`, or no save, load or ROM change can ever run again.
 *
 * Pure (no Android types), so `tools/save-logic-test` runs the real class on a JVM.
 */
internal class SaveStateGate {
    private val busy = AtomicBoolean(false)
    private val closed = AtomicBoolean(false)

    /** Whether some operation holds the guard right now. For diagnostics and tests; never a substitute for acquiring. */
    val isBusy: Boolean get() = busy.get()

    /** True once [close] has been called — the activity is being torn down. Never goes back to false. */
    val isClosed: Boolean get() = closed.get()

    /**
     * Takes the guard if it is free and not [close]d, without waiting. For a button tap: it arrives while an operation
     * runs → no-op.
     *
     * [closed] is read again AFTER the guard is taken. That is what makes [close] followed by [awaitIdle] airtight
     * (a Dekker pair — every access is a sequentially consistent atomic): either [awaitIdle] sees this thread holding
     * the guard and waits for it, or this thread sees the guard closed and gives it straight back. It is impossible
     * for [awaitIdle] to see the guard free and this thread to see it open.
     */
    fun tryAcquire(): Boolean {
        if (closed.get()) return false
        if (!busy.compareAndSet(false, true)) return false
        if (closed.get()) {
            busy.set(false)
            return false
        }
        return true
    }

    /**
     * Takes the guard, waiting up to [timeoutMs] for the current holder to finish. For callers that must not be
     * silently skipped by a stray tap having got there first: the autosave, and the core swap. Returns false if it
     * could not get it in time, if the guard was [close]d (a closed guard never opens again, so the wait is not run
     * out — check [isClosed] to tell this from a timeout), or if the waiting thread was interrupted (the interrupt flag
     * is kept).
     */
    fun acquire(timeoutMs: Long): Boolean {
        val timeoutNs = timeoutMs.coerceIn(0L, MAX_WAIT_MS) * 1_000_000L
        val startNs = System.nanoTime()
        while (!tryAcquire()) {
            if (closed.get()) return false
            if (System.nanoTime() - startNs >= timeoutNs) return false
            try {
                Thread.sleep(POLL_MS)
            } catch (_: InterruptedException) {
                Thread.currentThread().interrupt()
                return false
            }
        }
        return true
    }

    /** Gives the guard back. Only the thread that acquired it calls this, from a `finally`. */
    fun release() {
        busy.set(false)
    }

    /**
     * Teardown: from now on [tryAcquire] and [acquire] always return false, so no save, load, ROM load or Reset can
     * start. An operation that already holds the guard is not interrupted — [awaitIdle] waits for it. Idempotent.
     */
    fun close() {
        closed.set(true)
    }

    /**
     * Waits until no operation holds the guard, at most [timeoutMs]. Called after [close], this is the barrier that
     * makes it safe to free the native core: it returns true only when nothing is inside any more and — the guard
     * being closed — nothing can get in. False if a holder is still inside when the time is up (the caller then goes
     * on regardless; there is no way to stop a thread that is in a native call) or the waiting thread was interrupted
     * (the interrupt flag is kept). Without a prior [close] it only reports a moment in time.
     */
    fun awaitIdle(timeoutMs: Long): Boolean {
        val timeoutNs = timeoutMs.coerceIn(0L, MAX_WAIT_MS) * 1_000_000L
        val startNs = System.nanoTime()
        while (busy.get()) {
            if (System.nanoTime() - startNs >= timeoutNs) return false
            try {
                Thread.sleep(POLL_MS)
            } catch (_: InterruptedException) {
                Thread.currentThread().interrupt()
                return false
            }
        }
        return true
    }

    private companion object {
        const val POLL_MS = 10L
        /** A day: far beyond any real wait, and keeps `timeoutMs * 1_000_000` from overflowing a Long. */
        const val MAX_WAIT_MS = 24L * 60L * 60L * 1000L
    }
}
