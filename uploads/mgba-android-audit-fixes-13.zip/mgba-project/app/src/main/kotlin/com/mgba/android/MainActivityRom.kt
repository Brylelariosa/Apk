package com.mgba.android

// Split out of MainActivity.kt (pass 46 — "refactor main activity into
// separate classes so organized") as internal extension functions on
// MainActivity, exactly the pattern already established in SharedUi.kt's
// own top-of-file comment (Thirty-second pass) for the same reason: every
// existing unqualified call site inside MainActivity.kt (and inside every
// other split-out file) keeps compiling completely unchanged, since Kotlin
// resolves an unqualified call to an internal extension function on the
// enclosing receiver type the same way it resolves a member call — no
// behavior change, purely a file-organization move. See MainActivity.kt's
// own top-of-file comment for the full file map.

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.text.InputType
import android.text.TextUtils
import android.text.format.DateFormat
import android.util.Log
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.Closeable
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.io.PrintWriter
import java.io.StringWriter
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference
import java.util.zip.ZipInputStream
import kotlin.math.abs
import kotlin.math.roundToInt
import com.mgba.android.saves.NamedFile
import com.mgba.android.saves.RomIdentity
import com.mgba.android.saves.SaveKeys
import com.mgba.android.saves.StateSibling
import com.mgba.android.saves.StateSiblings


// isZipSignature()/zipContainsGba() moved to RomZipUtils.kt this pass
// (Thirty-second) when the ROM browser became its own Activity —
// RomBrowserActivity needs zipContainsGba() too, and this way there's
// still only one copy of the byte comparison between it and
// stageRomFile() below, same as when both lived in this class.

/** Copies [uri] into [tmp]. If the source is a zip archive — detected by
 *  its real magic bytes (see RomZipUtils.isZipSignature()), not by file
 *  extension, so a misnamed archive still works and a .zip that somehow
 *  isn't a real zip is correctly rejected instead of handed to the core
 *  as garbage — the first .gba entry found inside is extracted instead
 *  of the raw archive bytes. This is what lets both the file browser
 *  and the classic system picker load a ROM straight out of a .zip with
 *  no separate extraction step. Returns false if nothing worth loading
 *  ended up in [tmp] (unreadable source, or a zip with no .gba entry). */
internal fun MainActivity.stageRomFile(uri: Uri, tmp: File): Boolean {
    val raw = contentResolver.openInputStream(uri) ?: return false
    raw.use { stream ->
        val input = stream.buffered()
        if (!RomZipUtils.isZipSignature(input)) {
            val ok = tmp.outputStream().use { o -> copyCapped(input, o, MAX_ROM_BYTES) }
            if (!ok) tmp.delete()
            return ok
        }
        ZipInputStream(input).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                if (!entry.isDirectory && entry.name.endsWith(".gba", ignoreCase = true)) {
                    val ok = tmp.outputStream().use { o -> copyCapped(zip, o, MAX_ROM_BYTES) }
                    if (!ok) tmp.delete()
                    return ok
                }
                entry = zip.nextEntry
            }
        }
        return false
    }
}

/** AUDIT FIX: ceiling on how many bytes stageRomFile() will write. A GBA
 *  cartridge tops out at 32 MiB; 64 MiB leaves room for odd dumps while
 *  keeping a wrong pick — a huge file renamed .gba, or a zip bomb whose one
 *  .gba entry inflates to gigabytes — from filling the app's cache. */
private const val MAX_ROM_BYTES = 64L * 1024 * 1024

/** Copies [input] to [output], stopping with false (and logging) as soon as
 *  more than [limit] bytes would be written. */
private fun copyCapped(input: java.io.InputStream, output: java.io.OutputStream, limit: Long): Boolean {
    val buf = ByteArray(64 * 1024)
    var total = 0L
    while (true) {
        val n = input.read(buf)
        if (n < 0) return true
        total += n
        if (total > limit) {
            Log.w(TAG, "stageRomFile: source exceeds $limit bytes — refusing to stage it as a ROM")
            return false
        }
        output.write(buf, 0, n)
    }
}


/** Stages [uri] (transparently unzipping it first if needed — see
 *  stageRomFile()), swaps it into the running core, and updates the UI
 *  on success or failure. Shared by every ROM entry point — the classic
 *  system picker above and the in-app file browser's file rows below
 *  both just call this now, instead of each duplicating the load. */
internal fun MainActivity.loadRomFromUri(uri: Uri) {
    // AUDIT FIX (ROM-swap races): capture whether a session exists and mark
    // it gone for the duration of the swap, synchronously, before the loader
    // thread even starts. romLoaded used to stay true all the way through, so
    // an onPause() landing between the native core swap and the UI-thread
    // post below would autosave the NEW ROM's state under the OLD ROM's name
    // (currentRomBaseName isn't updated until that post), and an onResume()
    // in the same window could restart the old core's loop mid-swap. With it
    // false, both skip — there is no consistent session to save or resume
    // until the post below (or resumeSessionAfterFailedSwap()) says so.
    val hadSession = romLoaded
    if (hadSession) romLoaded = false
    Thread {
        // Set once nativeLoadROM() has actually replaced the old core; before
        // that point any failure leaves the previous session intact and
        // resumable (see resumeSessionAfterFailedSwap()).
        var swapped = false
        try {
            // FIX: nativeLoadROM() silently drops any active link session
            // as part of swapping the native core (see the "ROM swapped
            // while a link session was active" comment in mgba_jni.c) —
            // that side is careful to avoid leaving a dangling pointer,
            // but it has no way to tell the Kotlin side this happened.
            // Without this, link.isConnected and the ⬤ LINK overlay would
            // keep claiming "Connected" after a ROM swap even though the
            // native SIO driver backing the exchange no longer exists —
            // a silently broken multiplayer session with no indication
            // in the UI of why. Disconnect first so both sides agree.
            if (link.isConnected) stopLink()
            // FIX (Twenty-first pass): if a Storage folder is configured
            // and a ROM is already running, its battery save has only
            // ever been mirrored to internal storage (see
            // SaveEntry.batteryMirrorPath()) — the real document in the
            // chosen folder hasn't seen anything played since the last
            // sync point. Flush it out now, before that mirror file gets
            // reused for the ROM we're about to swap in, or whatever was
            // played this session never reaches the chosen folder at all.
            // mirrorToAutoFolder() alongside it: same flush moment, just
            // for the automatic own-folder mirror instead of a chosen
            // SAF folder — see the FEATURE block above dataFolderTree().
            // AUDIT FIX: the game thread is stopped FIRST and the flush
            // happens after. It used to be the other way round, so SRAM
            // writes the still-running game made between the flush and the
            // stop never reached the Storage-folder mirror.
            //
            // FIX: stop any in-progress game loop *before* touching the
            // native core, and reset transient input/FF state. Previously
            // there was no way to load a second ROM at all (loadRomBtn was
            // permanently hidden after the first successful load), so this
            // path was never exercised. nativeLoadROM() now builds the new
            // core fully before swapping it in, so a failed load here
            // leaves the previous session running rather than destroying
            // it (see mgba_jni.c).
            stopGameLoop()
            if (hadSession) flushBatteryMirrors(currentBatteryKey)
            // AUDIT FIX: stage into its OWN file, not rom_loaded.gba. The
            // running core memory-maps its ROM file for its whole lifetime
            // (mGBA's GBALoadROM maps the VFile), and stageRomFile()
            // truncates and rewrites whatever file it is given — doing that
            // to rom_loaded.gba rewrote the live core's ROM out from under
            // it, and left a corrupt copy behind for resetGame() whenever
            // staging or loading then failed. The staged file is only
            // renamed over rom_loaded.gba once the new core has loaded it.
            val tmp = cacheDir.resolve("rom_loading$instanceFileTag.gba")
            if (!stageRomFile(uri, tmp)) {
                tmp.delete()
                uiToast("Couldn't read that file (or found no .gba inside the zip)")
                resumeSessionAfterFailedSwap(hadSession)
                return@Thread
            }
            // ROM SAVE: identify the ROM by its picked display name —
            // not the fixed "rom_loaded.gba" cache path above, which
            // every ROM shares — so its saves persist under names stable
            // across app restarts and re-picking the same file later.
            // The IN-GAME save is filed by that NAME alone, so a patched
            // copy renamed to the original's name continues the original's
            // game; save states are filed by name + CRC32 of the ROM, one
            // set per build. See romIdentity()/resolveBatterySave().
            val identity = romIdentity(uri, tmp)
            val ownKey = identity.buildKey
            // A flush still running from the session that just ended (closeGame() no longer waits for it — see
            // SessionPersister) must be finished before anything below touches the same save files.
            awaitSessionFlush()
            migrateLegacyRomFiles(legacyRomBaseName(uri), ownKey)
            // The key the states are filed under is the build's own — unless an alias (or a first-load offer) sends
            // them to another version's. Nothing is copied or moved either way. The second game window of Link local
            // keeps strictly to its own key. May show a dialog and wait for the answer: this is the loader thread,
            // never the UI thread.
            val stateKey = if (isPlayerTwo) ownKey else resolveStateKey(identity)
            // The in-game save: the name-keyed one — an older per-ROM save of this game is carried over into it the
            // first time (and the player asked only if two different real saves exist).
            val battery = resolveBatterySave(identity)
            val saveEntry = batterySaveEntry(battery.key)
            backupBatteryIfExists(saveEntry)   // AUDIT FIX: copy, not rename — see SaveEntry.copyInto()
            // FIX (Twenty-first pass): was saveEntry.nativePath(forWrite
            // = true).path — a /proc/self/fd bridge straight onto the SAF
            // document, mmap'd by the core for the whole session. See the
            // block comment above dataFolderTree() for why that doesn't
            // hold up on a real device. batteryMirrorPath() below is
            // always a plain local path; when a Storage folder is
            // configured it stages the existing save in from there first.
            val savePath = saveEntry.batteryMirrorPath()
            // AUDIT FIX (ROM switch vs. save/load): a Quick Save / Quick Load / slot save or load that was already in
            // flight when this load started is tied to the OLD game (its slot file was named from it) but reaches the
            // native core only when its own staging is done — so replacing the core under it filed the NEW game's
            // state in the OLD game's slot (or loaded one game's slot into the other's core). Wait for it (taps made
            // since romLoaded went false were already refused), and hold the guard across the swap itself so nothing
            // starts in the middle of it. Not obtained in time (a hung storage provider): don't swap — the running
            // game is untouched, put it back, like any other failure before the core is replaced.
            //
            // AUDIT FIX (teardown vs. ROM load): this is also where a load that outlived its activity stops. onDestroy()
            // closes the guard before it frees the native core, and a closed guard is never handed out — so a thread
            // that was still staging or waiting on a dialog when the activity went away cannot get to nativeLoadROM()
            // and build a core nobody would free. The check has to be this one, inside the guard: the isFinishing /
            // isDestroyed test in the UI post below runs after the native call, and one made just before it would
            // leave the same gap (teardown can begin right after it).
            if (!acquireSaveStateBusy(SAVE_STATE_SWAP_WAIT_MS)) {
                tmp.delete()
                if (saveStateBusy.isClosed) {
                    // Nobody left to tell and no session to put back.
                    Log.i(TAG, "ROM load abandoned: the activity was torn down before the core could be replaced")
                    return@Thread
                }
                Log.w(TAG, "ROM load refused: a save/load was still running after ${SAVE_STATE_SWAP_WAIT_MS} ms")
                uiToast("A save is still in progress — try again in a moment")
                resumeSessionAfterFailedSwap(hadSession)
                return@Thread
            }
            val ok = try {
                coreGeneration.incrementAndGet()   // a background autosave queued for the OLD core must not run on the new one
                EmulatorEngine.nativeLoadROM(tmp.absolutePath, savePath)
            } finally {
                saveStateBusy.release()
            }
            if (ok) {
                swapped = true
                // This build's session is now the latest one on the shared in-game save — see
                // BatteryResolution.autosaveMatchesSave. (A session on the build's own fallback file is not.)
                if (!battery.usesBuildFile) recordBatterySession(identity)
                // The new core now has tmp mapped; renaming keeps that
                // mapping valid (same inode) while making this the ROM copy
                // resetGame() reloads from. The old core, already torn down
                // inside nativeLoadROM(), held the previous inode.
                val canonical = cacheDir.resolve("rom_loaded$instanceFileTag.gba")
                canonical.delete()
                if (!tmp.renameTo(canonical)) {
                    Log.w(TAG, "Couldn't publish ${tmp.name} as ${canonical.name} — Reset Game may not find the ROM")
                }
            } else {
                tmp.delete()
            }
            Handler(Looper.getMainLooper()).post romLoadDone@ {
                // FIX: onDestroy() may have already run and freed the
                // native core by the time this posts, if the load was
                // slow (large ROM, a slow SAF/cloud-backed URI) and the
                // user backed out of the app in the meantime. Without
                // this check, the block below would re-init AudioTrack
                // and start a brand new game thread + Choreographer
                // registration after teardown — resources nothing would
                // ever clean up, since onDestroy() has already run and
                // won't run again for this instance.
                if (isFinishing || isDestroyed) return@romLoadDone
                // BUG FIX: this whole block runs on the MAIN thread,
                // asynchronously, well after loadRomFromUri's own
                // try/catch — wrapping the background Thread body above
                // — has already finished and returned. That catch does
                // NOT protect anything in here despite the misleading
                // nesting; Handler.post() only schedules this lambda,
                // it doesn't run it, so by the time this body actually
                // executes the outer try is long gone. Any exception
                // here (Bitmap.createBitmap, AudioTrack init, the
                // thread/Choreographer setup in startGameLoop()) was
                // previously a genuine uncaught exception on the main
                // thread — a hard app crash, with the ROM having *just*
                // finished loading successfully.
                try {
                    if (ok) {
                        val w = EmulatorEngine.nativeGetWidth().coerceAtLeast(1)
                        val h = EmulatorEngine.nativeGetHeight().coerceAtLeast(1)
                        frameBuffers = Array(3) {
                            Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                        }
                        writeIdx = 0
                        readyIdx = -1
                        displayIdx = -1
                        // AUDIT FIX: the name is set BEFORE romLoaded flips
                        // true, so no reader can ever see "a ROM is loaded"
                        // paired with the previous ROM's save key.
                        currentRomBaseName = stateKey
                        currentRomOwnKey = ownKey
                        currentBatteryKey = battery.key
                        currentBatteryShared = !battery.usesBuildFile
                        romLoaded = true
                        // FIX (this pass): see applyScreenOrientationPref()'s
                        // own doc comment. This activity was Portrait the
                        // whole time RomBrowserActivity was open (idle —
                        // see that function) — now that a ROM is actually
                        // loaded, switch to the user's chosen gameplay
                        // orientation, before startGameLoop() below starts
                        // rendering.
                        applyScreenOrientationPref()
                        clearPointerState()
                        currentKeys.set(0)
                        fastForwardActive = false
                        // FEATURE (direct report — Misc setting "Auto
                        // Save & Load": "...points load it back on
                        // start"): the other half of onPause()'s own
                        // autosave write — see that function's doc
                        // comment for why *that* half is synchronous.
                        // This half is synchronous for a related but
                        // different reason: it has to finish before
                        // startGameLoop() below starts rendering, or
                        // the very first frame(s) shown would briefly
                        // be the ROM's own boot state before snapping
                        // to the restored one. currentRomBaseName is
                        // already set above, so autoStateEntry() below
                        // resolves to *this* ROM's own autosave, not
                        // whichever ROM was playing last. Silent when
                        // there's nothing to load (no toast, no
                        // "nothing found" message) — this runs on
                        // literally every ROM load, and most of the
                        // time, especially the very first time this ROM
                        // is ever opened, there won't be one yet.
                        //
                        // A save state carries the in-game save too, and loading it puts ITS copy back over the live
                        // one. When the in-game save has moved on since this autosave was made — another version of
                        // the ROM played on it, or a save was carried over from one — that would silently rewind
                        // the player's progress, so the autosave is left alone this time (the next one replaces it).
                        if (autoSaveLoadEnabled) {
                            val autoEntry = autoStateEntry()
                            if (autoEntry.exists()) {
                                if (!battery.autosaveMatchesSave) {
                                    uiToast("Autosave not loaded — the in-game save has changed since it was made")
                                } else {
                                    val autoLocalPath = autoEntry.stageForRead()
                                    if (autoLocalPath != null && EmulatorEngine.nativeLoadState(autoLocalPath)) {
                                        uiToast("Autosave loaded")
                                    }
                                }
                            }
                        }
                        // A freshly built core has no cheats: put this game's list back (it is
                        // applied by the core itself from the first frame on).
                        applyCheatsToCore()
                        initAudioTrack()
                        startGameLoop()
                        // FEATURE (Link local): the second window links to the first one by itself as soon as
                        // its game is running — see PlayerTwoActivity / joinLocalHost().
                        if (pendingLocalLinkJoin) {
                            pendingLocalLinkJoin = false
                            joinLocalHost()
                        }
                    } else {
                        uiToast("Unsupported ROM format")
                        if (hadSession) {
                            // AUDIT FIX: nativeLoadROM() builds the new core
                            // off to the side and leaves the old one
                            // untouched on failure, but this used to leave
                            // the loop stopped and romLoaded false anyway —
                            // a dead screen on top of a perfectly good
                            // session. Put the old one back.
                            romLoaded = true
                            startGameLoop()
                        } else {
                            romLoaded = false
                        }
                    }
                } catch (e: Throwable) {
                    // Leave the app in a state the user can recover from
                    // instead of a crash: no half-started game, surface
                    // wiped, and romLoaded left false so a tap on the
                    // idle screen (see onGameTouch()) reopens the ROM
                    // browser instead of leaving a dead screen behind.
                    Log.e(TAG, "ROM load post-processing failed", e)
                    uiToast("Load error: ${e.message ?: e.javaClass.simpleName}")
                    romLoaded = false
                    clearSurfaceToBlack()
                }
            }
        } catch (e: Throwable) {
            Log.e(TAG, "ROM load failed", e)
            uiToast("Load error: ${e.message ?: e.javaClass.simpleName}")
            // Only safe to resume if the old core is still the live one.
            if (!swapped) resumeSessionAfterFailedSwap(hadSession)
        }
    }.apply { name = "mGBA-load" }.start()
}

/**
 * AUDIT FIX: a ROM swap (or Reset) that fails BEFORE the native core is
 * replaced — unreadable file, no .gba in the zip, a thrown exception —
 * leaves the previous core alive and untouched, so the previous session
 * should simply carry on. It used to be left with its loop stopped and
 * romLoaded false, i.e. a dead screen. No-op when there was no session to
 * go back to. Posts to the UI thread because it restarts the game loop.
 */
internal fun MainActivity.resumeSessionAfterFailedSwap(hadSession: Boolean) {
    if (!hadSession) return
    Handler(Looper.getMainLooper()).post {
        if (isFinishing || isDestroyed) return@post
        romLoaded = true
        startGameLoop()
    }
}


/** Entry point for loading/swapping the ROM — called from onCreate() on
 *  first launch, from closeGame() when backing out of a game, and from
 *  onGameTouch() when the idle (no-ROM-loaded) surface is tapped.
 *  Launches RomBrowserActivity (a separate Activity as of Thirty-second
 *  pass, not an overlay in this one — see its own top-of-file comment)
 *  and waits for a result; romBrowserLauncher above hands whatever it
 *  returns to loadRomFromUri(). Broad file access, the folder browsing
 *  itself, and the classic single-document SAF picker fallback are all
 *  that Activity's own concern now, not this one's. */
internal fun MainActivity.changeRom() {
    romBrowserLauncher.launch(Intent(this, RomBrowserActivity::class.java))
    // FIX (Fortieth pass — reported directly: opens in landscape,
    // "then it go to portrait instantly"). This app is normally in
    // landscape during play; RomBrowserActivity is manifest-locked to
    // portrait (see its own top-of-file comment for why that's a
    // static declaration and NOT a runtime requestedOrientation call —
    // this fix doesn't touch that at all, for the same reason).
    // Actually rotating the physical display for the new Activity is a
    // real reconfiguration, and the default slide/fade activity
    // transition gives it a couple of animated frames to be visible
    // mid-rotation, which is what reads as "opens landscape, then
    // snaps to portrait". overridePendingTransition(0, 0) collapses
    // that transition to nothing, so the swap is an instant cut
    // instead of an animated one with a wrong-orientation frame in the
    // middle. Deprecated as of API 34 (replaced by
    // overrideActivityTransition) but still fully functional at this
    // app's targetSdk 34 — kept as the plain call rather than a
    // version-gated branch since the two behave identically here and
    // there's nothing to verify a newer, unfamiliar signature against
    // in this sandbox (no compiler/device, as every pass). See
    // RomBrowserActivity's own finish() override for the matching
    // fix on the way back.
    @Suppress("DEPRECATION")
    overridePendingTransition(0, 0)
}


// ── Save / state file naming ─────────────────────────────────────────
// SAF (Storage Access Framework) URIs don't carry a real filesystem
// path, and the only identifier for "which ROM is this" that's stable
// across app restarts and re-picking the same file is the picked
// document's display name — queried via ContentResolver, since
// uri.lastPathSegment is often an opaque provider-specific ID rather
// than the actual filename on many document providers (Downloads,
// Google Drive, etc).

/** The ROM's display name minus its extension, exactly as the provider
 *  reported it (or the URI's last path segment as a fallback) — not yet
 *  sanitized. Shared by romReadableName() and legacyRomBaseName(). */
private fun MainActivity.romRawBaseName(uri: Uri): String {
    var display: String? = null
    try {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { c ->
                val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && c.moveToFirst()) display = c.getString(idx)
            }
    } catch (_: Exception) {
        // Provider didn't support the query — fall through to the
        // URI-based fallback below.
    }
    return (display ?: uri.lastPathSegment ?: "rom").substringBeforeLast('.')
}

/** CRC32 of the staged ROM file as 8 lowercase hex digits, or null if it
 *  can't be read. java.util.zip.CRC32 is intrinsified on arm64, so even a
 *  32 MB ROM takes a few tens of milliseconds. */
private fun romCrc32Hex(file: File): String? = try {
    val crc = java.util.zip.CRC32()
    val buf = ByteArray(64 * 1024)
    file.inputStream().use { input ->
        while (true) {
            val n = input.read(buf)
            if (n < 0) break
            crc.update(buf, 0, n)
        }
    }
    "%08x".format(crc.value)
} catch (e: Exception) {
    Log.w(TAG, "romCrc32Hex(${file.name}) failed — falling back to a name-only save key", e)
    null
}

/**
 * Which ROM this is: its readable game name (the picked file's display name, made filesystem-safe) and the CRC32 of
 * the staged ROM bytes. See [SaveKeys] for what gets filed under which half:
 *
 *  - the IN-GAME (battery) save is keyed by the NAME alone — `<name>.sav`. A patched ROM renamed to the original's
 *    name, or any other ROM carrying that name, opens the same in-game save, the way it does in every other
 *    emulator. resolveBatterySave() picks it and carries older per-ROM saves over.
 *  - save STATES, quicksave, autosave and their thumbnails are keyed by name AND CRC — `<name>_<crc32>.<ext>` — so
 *    two different builds never share a snapshot of one build's memory (AUDIT FIX, save collisions). resolveStateKey()
 *    can point a build at another version's states when the player asks for that.
 *
 * [stagedRom] is the local copy stageRomFile() already produced (already unzipped if the source was a .zip), so the
 * hash is of the actual ROM bytes, not of the archive around them. A CRC that cannot be computed leaves
 * [RomIdentity.crc] null and the build key falls back to the bare name, as it always did.
 *
 * Existing installs: files saved under the old name-only key are copied across by migrateLegacyRomFiles(), called
 * right after this; per-ROM in-game saves from the CRC era are carried over by the BatterySaveResolver.
 */
internal fun MainActivity.romIdentity(uri: Uri, stagedRom: File): RomIdentity =
    RomIdentity(romReadableName(uri), romCrc32Hex(stagedRom))

/** The readable half of every save key — see [SaveKeys.readableName]. The second game window of Link local
 *  (PlayerTwoActivity) gets a "p2-" prefix, which is what keeps its saves apart from the first window's even for the
 *  very same ROM file — a trade between two copies of a game needs two saves. */
internal fun MainActivity.romReadableName(uri: Uri): String =
    SaveKeys.readableName(romRawBaseName(uri), isPlayerTwo)

/** The key saves were filed under BEFORE the CRC suffix was added — the
 *  old sanitizer, verbatim. Only used to find files to migrate. */
internal fun MainActivity.legacyRomBaseName(uri: Uri): String =
    SaveKeys.legacyName(romRawBaseName(uri))

/**
 * One-time carry-over of saves filed under the old name-only key
 * ([legacyBase]) to the new CRC-suffixed one ([newBase]): every
 * `<legacyBase>.*` file in the local saves/ and states/ folders, and — best
 * effort — in the chosen Storage folder's "save" subfolder.
 *
 * COPIES, never moves. Which ROM a legacy file "really" belongs to can't be
 * known (that is the collision this change ends), and a file that merely
 * shares a name — a corrupt download, an unsupported ROM that then fails to
 * load — must not be able to take saves away from the real one. The old
 * files are left in place, so the worst case is some duplicated bytes, never
 * a lost save; once you've confirmed everything carried over they are safe
 * to delete by hand.
 *
 * Only copies when the destination doesn't exist yet, so it can never
 * overwrite saves made under the new key, and each copy goes through a temp
 * file + rename so a crash can't leave a truncated file that then blocks the
 * real migration. The exact "<legacyBase>." prefix (sanitized names contain
 * no dots) means one ROM's migration can't pick up another ROM's files.
 *
 * Call from a background thread: it does file and SAF I/O.
 */
internal fun MainActivity.migrateLegacyRomFiles(legacyBase: String, newBase: String) {
    if (legacyBase == newBase) return
    // First ROM to load under a given legacy key claims it; every later ROM
    // that used to share that key starts clean instead of also inheriting a
    // copy of the shared save (which is exactly the collision being fixed).
    val claimKey = "legacy_saves_claimed_$legacyBase"
    val claims = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    if (claims.contains(claimKey)) return
    val legacyPrefix = "$legacyBase."
    val newPrefix = "$newBase."
    for (dir in listOf(savesDir(), statesDir())) {
        dir.listFiles { f -> f.isFile && f.name.startsWith(legacyPrefix) && !f.name.contains(".tmp-") }
            ?.forEach { old ->
                val dest = File(dir, newPrefix + old.name.substring(legacyPrefix.length))
                if (dest.exists()) return@forEach
                val tmp = File(dir, "${dest.name}.tmp-mig")
                try {
                    old.copyTo(tmp, overwrite = true)
                    if (tmp.renameTo(dest)) Log.i(TAG, "Carried over ${old.name} -> ${dest.name}")
                    else Log.w(TAG, "Couldn't carry over ${old.name} -> ${dest.name}")
                } catch (e: Exception) {
                    Log.w(TAG, "Couldn't carry over ${old.name} -> ${dest.name}", e)
                } finally {
                    tmp.delete()   // no-op once the rename succeeded
                }
            }
    }
    val folder = dataSubfolder("save")
    try {
        if (folder != null) for (doc in folder.listFiles()) {
            val n = doc.name ?: continue
            if (!n.startsWith(legacyPrefix)) continue
            val newName = newPrefix + n.substring(legacyPrefix.length)
            if (folder.findFile(newName) != null) continue
            val dst = folder.createFile("application/octet-stream", newName) ?: continue
            contentResolver.openInputStream(doc.uri)?.use { input ->
                contentResolver.openOutputStream(dst.uri, "wt")?.use { out -> input.copyTo(out) }
            }
        }
    } catch (e: Exception) {
        Log.w(TAG, "Storage-folder carry-over skipped", e)
    }
    claims.edit().putString(claimKey, newBase).apply()
}



// ── SAVE STATE LINKS: use another version of this ROM's save states ────────────────────────────────────────────
//
// The in-game (battery) save no longer needs any of this: it is keyed by the game's NAME, so every ROM carrying a
// name opens the same one (see resolveBatterySave() / BatterySaveResolver). What is left per ROM BUILD is the
// snapshots — numbered state slots, quicksave, autosave and their thumbnails — filed under "<name>_<crc32>".
// Those are a copy of one build's memory, so another build's can glitch or crash if the patch changed game code;
// keeping them apart is the safe default and this block lets the player opt in to sharing.
//
// BACKGROUND: the first version of this feature (it was the only way to share ANY save between two versions)
// keyed everything off an alias, offered it only for a ROM that had no real in-game save yet, and treated "Keep
// separate" / "Not now" as dead ends — which is why a renamed patch that had been launched even once never got the
// original's progress. Aliases that were stored back then keep working: "save_alias_<ownKey>" = <otherKey> now
// redirects the STATE files only, and is dropped when the other version has no states left.
//
// Two entries in SharedPreferences(PREFS), unchanged from that first version:
//   "save_alias_<ownKey>"          = <otherKey>   the FINAL key — one hop, never a chain
//   "save_alias_declined_<ownKey>" = true         "Keep separate": never ask again
// loadRomFromUri() resolves the state key once (resolveStateKey()) and hands it to everything that files states —
// state slots, quicksave, autosave, thumbnails — all of which read currentRomBaseName. No file is ever moved,
// copied, deleted or overwritten: an alias only changes which existing files are opened, and removing it
// (Settings -> Storage -> Unlink) puts the ROM's own back.

private enum class SaveLinkChoice { USE_SAME, KEEP_SEPARATE, NOT_NOW }

private fun saveAliasPrefKey(ownKey: String) = "save_alias_$ownKey"
private fun saveAliasDeclinedPrefKey(ownKey: String) = "save_alias_declined_$ownKey"

/** Set once a build is seen to have save states of its own — the link offer is moot from then on, and the scan that
 *  found them (a listing of the saves folders and of the Storage folder, document by document) never has to run for
 *  this build again. */
private fun ownStatesSeenPrefKey(ownKey: String) = "save_states_seen_$ownKey"

/** State keys that were scanned this process and had nothing to offer — a ROM that has no states yet would
 *  otherwise rescan the saves folders (and the Storage folder, document by document) on every single load. */
private val stateLinkChecked: MutableSet<String> = java.util.Collections.synchronizedSet(HashSet<String>())

/** Every file whose name starts with [prefix], in the local saves/ and states/ folders and — names first, size and
 *  date only for the matches — the Storage folder's "save" subfolder. */
private fun MainActivity.listSaveFilesStartingWith(prefix: String): List<NamedFile> {
    val out = ArrayList<NamedFile>()
    for (dir in listOf(savesDir(), statesDir())) {
        dir.listFiles { f -> f.isFile && f.name.startsWith(prefix) }
            ?.forEach { out.add(NamedFile(it.name, it.length(), it.lastModified())) }
    }
    try {
        dataSubfolder("save")?.listFiles()?.forEach { doc ->
            val name = doc.name ?: return@forEach
            if (name.startsWith(prefix) && doc.isFile) out.add(NamedFile(name, doc.length(), doc.lastModified()))
        }
    } catch (e: Exception) {
        Log.w(TAG, "Storage-folder scan skipped", e)
    }
    return out
}

/** Does [key] have at least one non-empty save state (numbered slot, quicksave or autosave)? */
private fun MainActivity.stateFilesExist(key: String): Boolean =
    StateSiblings.hasStates(key, listSaveFilesStartingWith("$key."))

/** One hop only: if [key] is itself linked to a third version whose states still exist, point at THAT. */
private fun MainActivity.finalAliasKey(prefs: android.content.SharedPreferences, key: String): String {
    val next = prefs.getString(saveAliasPrefKey(key), null)
    return if (next != null && next != key && stateFilesExist(next)) next else key
}

/**
 * The key this ROM's save STATES go under: its own build key unless an alias says otherwise. Called by
 * loadRomFromUri() on its LOADER THREAD, right after migrateLegacyRomFiles(), and may block on a dialog — never call
 * it on the main thread.
 *
 *  1. An alias exists and the other version still has states -> use it. Otherwise it is stale: dropped.
 *  2. Not declined, this ROM has no states of its own, and another version of the same game does (findSibling) ->
 *     ask: "Use same states" -> store the alias, use that key;  "Keep separate" -> store "declined", own key;
 *     "Not now" / Back / tap outside -> own key for THIS load only, nothing stored (asked again next load).
 *  3. Otherwise the own key.
 *
 * The question is only about states: the in-game save is shared by name regardless of the answer.
 */
internal fun MainActivity.resolveStateKey(identity: RomIdentity): String {
    val ownKey = identity.buildKey
    return try {
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val aliasPref = saveAliasPrefKey(ownKey)
        val declinedPref = saveAliasDeclinedPrefKey(ownKey)

        val alias = prefs.getString(aliasPref, null)
        if (alias != null) {
            if (alias != ownKey && stateFilesExist(alias)) return alias
            prefs.edit().remove(aliasPref).apply()   // stale: the states it pointed at are gone
        }
        if (prefs.getBoolean(declinedPref, false)) return ownKey
        val crc = identity.crc ?: return ownKey      // a name-only key has no "different crc" to compare — nothing to offer
        val ownStatesSeen = ownStatesSeenPrefKey(ownKey)
        if (ownKey in stateLinkChecked || prefs.getBoolean(ownStatesSeen, false)) return ownKey

        // Nothing to offer from here on is remembered for the rest of the process, so a ROM without states does not
        // rescan the folders on every load. (An answer of "Not now" is deliberately NOT remembered.) A build that
        // has states of its own is remembered for good: loading it never costs a folder scan again.
        if (stateFilesExist(ownKey)) {
            stateLinkChecked.add(ownKey)
            prefs.edit().putBoolean(ownStatesSeen, true).apply()
            return ownKey
        }
        val sibling = StateSiblings.find(identity.readable, crc, listSaveFilesStartingWith("${identity.readable}_"))
        if (sibling == null) { stateLinkChecked.add(ownKey); return ownKey }

        when (askUseSameStates(sibling)) {
            SaveLinkChoice.USE_SAME -> {
                val target = finalAliasKey(prefs, sibling.key)
                if (target == ownKey) return ownKey
                prefs.edit().putString(aliasPref, target).remove(declinedPref).apply()
                target
            }
            SaveLinkChoice.KEEP_SEPARATE -> {
                prefs.edit().putBoolean(declinedPref, true).apply()
                ownKey
            }
            SaveLinkChoice.NOT_NOW -> ownKey
        }
    } catch (e: Exception) {
        Log.w(TAG, "save-state link lookup failed — using this ROM's own states", e)
        ownKey
    }
}

/** The "Same game, different version?" question about save STATES — see [awaitDialog] for how the loader thread
 *  waits for it and every way out of the dialog releases it. */
private fun MainActivity.askUseSameStates(sibling: StateSibling): SaveLinkChoice =
    awaitDialog(SaveLinkChoice.NOT_NOW) { answer ->
        val ctx = this
        val date = DateFormat.getMediumDateFormat(ctx).format(java.util.Date(sibling.modified))
        val body = ctx.dialogContentLayout().apply {
            addView(TextView(ctx).apply {
                text = "Found save states from another version of this ROM (${sibling.crc}, last used $date). " +
                    "Use the same save states? Your in-game save is already shared between versions. " +
                    "Save states from another version can glitch if the patch changed game code. " +
                    "Your own files for this version are kept untouched."
                textSize = 14f
                setTextColor(Color.WHITE)
            })
        }
        AlertDialog.Builder(ctx)
            .setTitle("Same game, different version?")
            .setView(ScrollView(ctx).apply { addView(body) })
            .setPositiveButton("Use same states") { _, _ -> answer(SaveLinkChoice.USE_SAME) }
            .setNegativeButton("Keep separate") { _, _ -> answer(SaveLinkChoice.KEEP_SEPARATE) }
            .setNeutralButton("Not now") { _, _ -> answer(SaveLinkChoice.NOT_NOW) }
            .setOnCancelListener { answer(SaveLinkChoice.NOT_NOW) }   // Back / tap outside
            .create()
            .also { it.window?.setBackgroundDrawable(roundedDialogBackground()) }
    }

/** What Settings -> Storage shows in its "Save states for this ROM" row. */
internal class SaveLinkStatus(val linkedCrc: String?, val unlinkedPending: Boolean)

/** null when no game is loaded. [linkedCrc] != null: this ROM is using another version's states right now.
 *  [unlinkedPending]: it still is, but the link has been removed — applies the next time the ROM is loaded. */
internal fun MainActivity.currentSaveLinkStatus(): SaveLinkStatus? {
    if (!romLoaded || currentRomOwnKey.isEmpty()) return null
    val usingOtherKey = currentRomBaseName != currentRomOwnKey
    if (!usingOtherKey) return SaveLinkStatus(null, false)
    val alias = getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(saveAliasPrefKey(currentRomOwnKey), null)
    val crc = currentRomBaseName.substringAfterLast('_')
    return if (alias != null) SaveLinkStatus(crc, false) else SaveLinkStatus(crc, true)
}

/** Settings -> Storage -> Unlink: removes the alias and records "declined" so the first-load question does not
 *  come back. Files are untouched; the game keeps using the linked states until it is loaded again. */
internal fun MainActivity.unlinkSavesForCurrentRom() {
    val own = currentRomOwnKey
    if (own.isEmpty()) return
    getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
        .remove(saveAliasPrefKey(own))
        .putBoolean(saveAliasDeclinedPrefKey(own), true)
        .apply()
}
