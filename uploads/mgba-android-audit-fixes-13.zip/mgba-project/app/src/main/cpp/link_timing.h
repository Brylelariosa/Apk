/*
 * link_timing.h — how long the HOST's emulated link transfers last, chosen per game, and the Four Swords link-up
 * search.
 *
 * Why this exists (two-phone captures of 31 Oct and 2 Nov 2026: The Legend of Zelda: A Link to the Past & Four Swords)
 * ---------------------------------------------------------------------------------------------------------
 * Smooth link (see SMOOTH LINK in mgba_jni.c) hides the Wi-Fi round trip by letting every cable transfer last
 * about as long as the round trip — up to 4.5 ms of EMULATED time (LINK_STRETCH_MAX_US) instead of the 0.38 ms a
 * 115,200-baud cable needs. A game that only needs a packet to arrive within some number of frames never notices
 * (the cap was sized for a 16-word packet in ~6 frames: 16 x (4.5 + 0.8) ms = 85 ms = 5 frames).
 *
 * Four Swords' link-up does not complete with it, and the logs say what it does instead (the host logged every
 * transfer: 6,791 of them on 31 Oct, 9,999 on 2 Nov):
 *   - The master repeats a round of exactly 7 transfers that starts with the probe 0xFEFE: 2,392 of the 2,403 rounds
 *     in the two logs (the other 11 are 3, 4 or 8 long), at both transfer lengths. The words are [probe, counter,
 *     0xFFFF, 0, 0, 0, 0] (31 Oct: [probe, 0xFFFF, 0, 0, counter, 0, 0]). The slave's ROM answers only in every SECOND
 *     round — 485 of 973 on 31 Oct, 715 of 1,428 on 2 Nov, never more than two in a row — with four words [counter,
 *     checksum, 0x0020, 0xFFFF]. The link never completes. (On 2 Nov the first attempt ran 23 s, until the game reset
 *     its serial port, the second 29 s; the log does not say why the first ended.)
 *   - How often the probe repeats follows the transfer length: with 4.5 ms transfers every 87-88 link ticks, i.e. 2
 *     frames (the transfers are 12 ticks = 4.6 ms apart); with 1.5 ms transfers every 43-44 ticks, i.e. 1 frame (6
 *     ticks = 2.3 ms apart; the host then ran at 46 % speed).
 *   - The public Spuds0588/mgba-splitscreen project decoded the cartridge's receive code: the slave takes a probe as a
 *     probe only if it already holds a complete block (more than 11 words received since the last one); an earlier
 *     one is stored as data. Seven transfers per probe give exactly "every second probe". Its notes also show a master
 *     that sends 13 transfers per probe where transfers are fast (~0.6 ms apart).
 * So the working theory is: the game needs 12 or more transfers between two probes, and the master's round length
 * depends on how long its transfers last. Pass 14 assumed a fixed 2-frame period and chose 1.5 ms for it; the second
 * capture showed the period adapting and the round still 7 transfers, so that choice did not help. Which transfer
 * length (if any) makes the master send 12+ transfers per round is NOT known from two data points — and nothing
 * here can run the cartridge. So the host searches for it on the phones (below) instead of guessing a third time.
 *
 * The search (Auto + a known game, host only)
 * -------------------------------------------
 * The host cycles through a table of transfer lengths, LINK_SWEEP_STEPS of them, LINK_SWEEP_DWELL transfers each.
 * It watches the probe rounds (a round starts at a 0xFEFE probe) and whether the slave answered in them. When the
 * slave answers LINK_SWEEP_LOCK_ROUNDS rounds in a row — which, with the receive rule above, only happens when it
 * recognises every probe — the length is kept ("locked"; the step does not end while locked). A lock ends when
 * the slave then misses LINK_SWEEP_UNLOCK_ROUNDS rounds in a row, or when the game resets its link port (RCNT write:
 * it started over). The search then carries on: with the next length at once after a port reset or a lock that has
 * outlasted the step's dwell, otherwise when the dwell is used up. Every finished step is logged as one line (rounds, answered,
 * transfers per round, probe period), so even a search that finds nothing returns what the game does at each length.
 * The search ends nowhere by itself: it keeps cycling until the link is up or the link stops.
 *
 * Which games: Auto recognises the cartridges listed in link_timing_known_game() by the title in the ROM header
 * (0xA0, 12 bytes). Settings -> Debug -> "Link timing" can force a fixed profile for every game: "Smooth" (the long
 * transfers, as before pass 14) or "Compatible" (the pass-14 profile: 1.5 ms; it did not make Four Swords link; kept
 * as a fixed-length option for experiments). Only the HOST's choice matters — the child follows
 * the host's spacing — and it is read once per link session, at nativeLinkStart().
 *
 * Pure C, no mGBA/JNI types, so it is unit-tested on the host (tools/native-link-test/test_link_timing.c).
 */
#ifndef LINK_TIMING_H
#define LINK_TIMING_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>

/* Cap on the emulated duration of one host transfer, microseconds. */
#define LINK_STRETCH_MAX_US         4500u   /* Smooth: about what a Wi-Fi round trip needs (and 9,600 baud at the slowest) */
#define LINK_STRETCH_COMPAT_MAX_US  1500u   /* Compatible: the pass-14 profile for Four Swords (see above: it did not link) */

/* The user's choice (Settings -> Debug -> "Link timing"). Stored in the preferences and passed over JNI as a
 * plain int by LinkTiming.code (LinkTiming.kt) — the numbers are part of that contract, never renumber. */
enum {
    LINK_TIMING_AUTO   = 0,   /* decide per game from its ROM header */
    LINK_TIMING_SMOOTH = 1,   /* always LINK_STRETCH_MAX_US */
    LINK_TIMING_COMPAT = 2    /* always LINK_STRETCH_COMPAT_MAX_US */
};

/* ROM header: the 12-byte game title starts here (the 4-byte game code follows it). */
#define LINK_ROM_TITLE_OFFSET   0xA0u
#define LINK_ROM_TITLE_LEN      12u

typedef struct {
    int         mode;     /* the mode that was applied (an unknown value has become LINK_TIMING_AUTO) */
    uint32_t    cap_us;   /* the emulated-transfer-time cap for this session (the first step's, when searching) */
    const char *game;     /* the known game recognised in the ROM header, or NULL */
    bool        sweep;    /* run the link-up search (Auto and a known game) */
} LinkTiming;

/* The name of the known game whose link code needs the Compatible profile, or NULL.
 * [rom] = the cartridge image (only the first LINK_ROM_TITLE_OFFSET + LINK_ROM_TITLE_LEN bytes are read),
 * [rom_size] = how many bytes of it are valid. A title is matched on its leading characters. */
static inline const char *link_timing_known_game(const uint8_t *rom, size_t rom_size)
{
    static const struct { const char *title; const char *name; } k_games[] = {
        /* The Legend of Zelda: A Link to the Past & Four Swords — "GBAZELDA" at 0xA0 in a real USA dump (the
         * Spuds0588/mgba-splitscreen project identifies the cartridge the same way). */
        { "GBAZELDA", "Zelda: A Link to the Past & Four Swords" },
    };
    if (!rom || rom_size < LINK_ROM_TITLE_OFFSET + LINK_ROM_TITLE_LEN) return NULL;
    for (size_t i = 0; i < sizeof k_games / sizeof k_games[0]; i++) {
        if (memcmp(rom + LINK_ROM_TITLE_OFFSET, k_games[i].title, strlen(k_games[i].title)) == 0)
            return k_games[i].name;
    }
    return NULL;
}

/* Decides which cap applies to a link session. Unknown modes act as Auto. */
static inline LinkTiming link_timing_resolve(int mode, const uint8_t *rom, size_t rom_size)
{
    LinkTiming t;
    t.mode = (mode == LINK_TIMING_SMOOTH || mode == LINK_TIMING_COMPAT) ? mode : LINK_TIMING_AUTO;
    t.game = link_timing_known_game(rom, rom_size);
    if (t.mode == LINK_TIMING_SMOOTH)      t.cap_us = LINK_STRETCH_MAX_US;
    else if (t.mode == LINK_TIMING_COMPAT) t.cap_us = LINK_STRETCH_COMPAT_MAX_US;
    else                                   t.cap_us = t.game ? LINK_STRETCH_COMPAT_MAX_US : LINK_STRETCH_MAX_US;
    t.sweep = (t.mode == LINK_TIMING_AUTO) && t.game != NULL;
    return t;
}

static inline const char *link_timing_mode_name(int mode)
{
    return mode == LINK_TIMING_SMOOTH ? "smooth" : mode == LINK_TIMING_COMPAT ? "compat" : "auto";
}

/* Copies the ROM's header title into [out] as printable text (anything else becomes '.'), NUL-terminated;
 * "" if the image is too short. For the log: a capture that says which title Auto saw settles any question
 * about why a profile was or was not picked. */
static inline void link_timing_rom_title(const uint8_t *rom, size_t rom_size, char out[LINK_ROM_TITLE_LEN + 1u])
{
    out[0] = '\0';
    if (!rom || rom_size < LINK_ROM_TITLE_OFFSET + LINK_ROM_TITLE_LEN) return;
    size_t n = 0;
    for (size_t i = 0; i < LINK_ROM_TITLE_LEN; i++) {
        const uint8_t c = rom[LINK_ROM_TITLE_OFFSET + i];
        if (c == 0) break;                                   /* NUL padding ends the title */
        out[n++] = (c >= 0x20 && c < 0x7F) ? (char)c : '.';
    }
    out[n] = '\0';
}

/* ── The Four Swords link-up search (see the header comment) ─────────────────────────────────────────────────── */

#define LINK_SWEEP_PROBE_WORD      0xFEFEu   /* what the master repeats while it looks for its partner */
#define LINK_SWEEP_STEPS           16u       /* lengths in the table below */
#define LINK_SWEEP_DWELL           600u      /* host transfers per step: ~40-85 rounds, ~3 s on Wi-Fi */
#define LINK_SWEEP_LOCK_ROUNDS     3u        /* answered rounds in a row that count as "recognises every probe" */
#define LINK_SWEEP_UNLOCK_ROUNDS   2u        /* unanswered rounds in a row that end a lock */

/* Flags returned by link_sweep_on_transfer() / link_sweep_on_port_reset(). */
#define LINK_SWEEP_EV_STEP         1u        /* a step finished: link_sweep_done() has its numbers, the length changed */
#define LINK_SWEEP_EV_LOCK         2u        /* the slave answers every round: the current length is kept */
#define LINK_SWEEP_EV_UNLOCK       4u        /* the lock ended */

/* The transfer length of step [i], microseconds (wraps around). The order is the order of the search. Chosen from the
 * two captures: 0 is exact cable timing (what the master sees on hardware, and on an emulator with lock-step cores);
 * at 4.5 ms a seven-transfer round just fitted two frames with ~1.8 link ticks (0.7 ms) to spare, so 4.7-5.5 ms is where
 * the master must stretch its probe period again; 2.4-2.65 ms is the same one period earlier (at 1.5 ms it just fitted
 * one frame), 10 ms the same one period later; the others fill the gaps; 1500 is the pass-14 length, for reference. */
static inline uint32_t link_sweep_step_cap_us(uint32_t i)
{
    static const uint32_t k_caps_us[LINK_SWEEP_STEPS] = {
        0u, 2500u, 4900u, 2400u, 2650u, 5200u, 1000u, 4700u,
        5500u, 3000u, 1800u, 600u, 3600u, 4100u, 10000u, 1500u
    };
    return k_caps_us[i % LINK_SWEEP_STEPS];
}

/* What one step saw. */
typedef struct {
    uint32_t cap_us;         /* the transfer length of the step */
    uint32_t transfers;      /* transfers in the step (counted from the game's first probe) */
    uint32_t rounds;         /* probe rounds that ended inside the step (a round ends at the next probe) */
    uint32_t answered;       /* ...of which the slave answered (a reply other than 0x0000 / 0xFFFF) */
    uint32_t best_run;       /* longest run of consecutive answered rounds */
    uint32_t words;          /* transfers inside those rounds */
    uint32_t period_ticks;   /* sum of the link ticks from one probe to the next */
    uint32_t periods;        /* ...and how many of them */
} LinkSweepStep;

typedef struct {
    uint32_t      index;          /* the step in progress */
    uint32_t      done_index;     /* the step that finished last */
    bool          locked;
    bool          seen_probe;     /* the game has started probing: only then do steps count down */
    uint32_t      run;            /* answered rounds in a row, now */
    uint32_t      silent_run;     /* unanswered rounds in a row, now */
    bool          round_open;
    bool          round_answered;
    uint32_t      round_words;
    uint16_t      round_stamp;    /* link tick of the round's probe */
    bool          have_prev;
    uint16_t      prev_sent;
    LinkSweepStep cur;            /* the step in progress */
    LinkSweepStep done;           /* the step that finished last (valid after LINK_SWEEP_EV_STEP) */
} LinkSweep;

static inline void link_sweep_begin_step(LinkSweep *s)
{
    memset(&s->cur, 0, sizeof s->cur);
    s->cur.cap_us = link_sweep_step_cap_us(s->index);
    s->run = s->silent_run = 0;      /* a round that straddles two lengths says nothing about either */
    s->round_open = false;
    s->round_answered = false;
    s->round_words = 0;
}

static inline void link_sweep_finish_step(LinkSweep *s)
{
    s->done       = s->cur;
    s->done_index = s->index;
    s->index      = (s->index + 1u) % LINK_SWEEP_STEPS;
    link_sweep_begin_step(s);
}

static inline void link_sweep_init(LinkSweep *s)
{
    memset(s, 0, sizeof *s);
    link_sweep_begin_step(s);
}

/* The transfer length to use right now. */
static inline uint32_t link_sweep_cap_us(const LinkSweep *s)
{
    return s->cur.cap_us;
}

/* The finished step's numbers, after LINK_SWEEP_EV_STEP. */
static inline const LinkSweepStep *link_sweep_done(const LinkSweep *s)
{
    return &s->done;
}

/* Feeds one finished host transfer: [sent] = the host's word, [recv] = the child's reply (0xFFFF if it did not
 * answer), [stamp] = the host's link tick when the transfer started. Returns LINK_SWEEP_EV_* flags. */
static inline unsigned link_sweep_on_transfer(LinkSweep *s, uint16_t sent, uint16_t recv, uint16_t stamp)
{
    unsigned ev = 0u;
    /* A round starts at a probe. A probe straight after a probe is the round's own counter word (it counts down
     * through 0xFEFE once every 254 rounds), not a new round. */
    const bool probe = sent == LINK_SWEEP_PROBE_WORD && !(s->have_prev && s->prev_sent == LINK_SWEEP_PROBE_WORD);
    s->have_prev = true;
    s->prev_sent = sent;
    /* The dwell is counted from the game's first probe, not from the start of the link: whatever the game does
     * before it starts looking for a partner (menus, the multiboot-style wait) must not use up a step's time. */
    if (probe) s->seen_probe = true;
    if (s->seen_probe) s->cur.transfers++;

    if (probe) {
        if (s->round_open) {                                   /* the previous round ends here */
            s->cur.rounds++;
            s->cur.words        += s->round_words;
            s->cur.period_ticks += (uint16_t)(stamp - s->round_stamp);
            s->cur.periods++;
            if (s->round_answered) {
                s->cur.answered++;
                s->silent_run = 0;
                if (++s->run > s->cur.best_run) s->cur.best_run = s->run;
                if (!s->locked && s->run >= LINK_SWEEP_LOCK_ROUNDS) { s->locked = true; ev |= LINK_SWEEP_EV_LOCK; }
            } else {
                s->run = 0;
                if (++s->silent_run >= LINK_SWEEP_UNLOCK_ROUNDS && s->locked) { s->locked = false; ev |= LINK_SWEEP_EV_UNLOCK; }
            }
        }
        s->round_open     = true;
        s->round_answered = false;
        s->round_words    = 0;
        s->round_stamp    = stamp;
    }
    if (s->round_open) {
        s->round_words++;
        if (recv != 0x0000u && recv != 0xFFFFu) s->round_answered = true;
    }

    if (s->seen_probe && !s->locked && s->cur.transfers >= LINK_SWEEP_DWELL) {
        link_sweep_finish_step(s);
        ev |= LINK_SWEEP_EV_STEP;
    }
    return ev;
}

/* The game reset its link port (RCNT write): it is starting over. A lock that did not survive that moves on to
 * the next length; a reset while still searching only discards the round in progress. */
static inline unsigned link_sweep_on_port_reset(LinkSweep *s)
{
    unsigned ev = 0u;
    if (s->locked) {
        s->locked = false;
        link_sweep_finish_step(s);
        ev = LINK_SWEEP_EV_UNLOCK | LINK_SWEEP_EV_STEP;
    } else {
        s->run = s->silent_run = 0;
        s->round_open = false;
        s->round_answered = false;
        s->round_words = 0;
        s->have_prev = false;
    }
    return ev;
}

#endif /* LINK_TIMING_H */
