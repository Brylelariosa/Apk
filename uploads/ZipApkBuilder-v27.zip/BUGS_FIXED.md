# Bugs Fixed — v27

## 1. Owner chip visibility ignored its own condition
**Where:** `restoreSavedBuildState()`

**Root cause:** a semicolon-separated single-line `if` —
```kotlin
if (savedOwner.isNotEmpty()) tvOwnerInfo.text = "..."; tvOwnerInfo.visibility = VISIBLE
```
Kotlin (like Java/C) only scopes the *first* statement after an unbraced `if`
to that condition. The semicolon ends the `if`, so `tvOwnerInfo.visibility =
VISIBLE` ran on every call to this function regardless of `savedOwner`.

**Fix:** wrapped both statements in braces so both are conditional, matching
the evident original intent.

**Effect if unfixed:** in the edge case where a saved build exists but
`savedOwner` is empty (e.g. data from a much older version, before that field
existed), the owner chip would be shown visible with stale or blank text
instead of staying hidden.

## 2. New-repo creation polled ~18s longer than necessary
**Where:** `promptCreateRepo()`

**Root cause:**
```kotlin
repeat(10) {
    Thread.sleep(2_000)
    ...
    if (chk == 200) { ready = true; return@repeat }
}
```
`return@repeat` returns from the *current lambda invocation* of `repeat`'s
block — it's the equivalent of `continue`, not `break`. There is no way to
exit a Kotlin `repeat { }` early with a labeled return; it always runs the
full count.

**Fix:** replaced with `for (attempt in 1..10) { ...; if (chk == 200) { ready
= true; break } }`, which can actually stop as soon as the repo is reachable.

**Effect if unfixed:** every new-repo creation waited out all 10 iterations
(20s) even when the repo became reachable on, say, the 2nd check (4s) —
wasting up to ~16-18 extra seconds every time, on top of whatever the actual
wait should have been.

## 3. File editor line-number gutter recomputed on every keystroke
**Where:** `showFileEditorDialog()`'s `TextWatcher`

**Root cause:** `afterTextChanged` unconditionally did
`(s.toString()).lines().size` (a full copy + split of the entire document) and
rebuilt the whole gutter string, on every single character typed or deleted —
work proportional to file size, repeated on every keystroke regardless of
whether the edit could possibly have changed the line count.

**Fix:** capture whether the replaced region (in `beforeTextChanged`) or the
newly-inserted region (in `onTextChanged`) contains a newline; only recompute
the gutter when at least one of those is true. Ordinary character typing
never touches a newline, so it now skips the expensive path entirely.

**Effect if unfixed:** visible typing lag in the in-app file editor for any
file of meaningful size — including, notably, this app's own ~4,700-line
`MainActivity.kt` if someone ever opened it through the file browser.

## 4. Reported download path could not match the actual saved file
**Where:** `saveZipToDownloadsInternal()` (Android 10+ / MediaStore branch)

**Root cause:** the returned path was built by string-joining the public
Downloads directory with the *requested* filename. MediaStore, however,
silently renames on a collision (`artifact.zip` → `artifact.zip (1)`) rather
than overwriting or failing — so re-downloading the same artifact name twice
could report a path pointing at a file that isn't the one actually written.

**Fix:** after the write completes, query the item's actual
`MediaStore.Downloads.DISPLAY_NAME` back from the `ContentResolver` and use
that in the returned path (and therefore in the log line and Download History
entry too).

## 5. One failed item aborted an entire batch delete
**Where:** `deleteItemsRecursive()`

**Root cause:** the loop over selected items and the whole operation shared
one `try`/`catch`; a folder that failed to list (or any other error partway
through) threw out of the loop entirely, silently skipping every remaining
selected item with no indication of which ones were or weren't deleted.

**Fix:** each item is now attempted in its own `try`/`catch`; failures are
counted and logged per-item, and a summary ("Deleted 4 item(s), 1 failed.")
is reported once all items have been attempted.

## 6. Artifact ZIP leaked into the app cache on every download
**Where:** `downloadArtifact()`

**Root cause:** the temp file created at `cacheDir/artifact_<timestamp>.zip`
was copied to Downloads via `saveZipToDownloads()` but never deleted
afterward — unlike the equivalent temp file in `downloadLatestRunLogs()`,
which already correctly deletes its own copy. Since each file's name includes
a timestamp, they never overwrote each other; they just accumulated.

**Fix:** the cache copy is deleted immediately after the log/history entry is
recorded. A one-time startup sweep (`cleanupStaleCacheFiles()`) also catches
any files left behind by sessions from before this fix existed, or by a
session killed mid-flow before reaching the delete call.

## 7. Four inconsistent implementations of the same byte-formatting logic
**Where:** class-level `fmtBytes()` plus three local duplicates inside
`downloadLatestRunLogs()`, `downloadArtifact()`, and `showUploadProgressDialog()`

**Root cause:** the three local copies were simpler than the class-level one
— integer-only KB (no decimal), and no GB tier at all, so a hypothetical
artifact over 1GB would display as e.g. "1500.0 MB" from the local copies but
correctly as "1.46 GB" from the class-level one. Not incorrect, just
inconsistent, and four copies of the same logic is its own maintenance risk.

**Fix:** removed all three local copies; every call site now resolves to the
single class-level `fmtBytes()`.
