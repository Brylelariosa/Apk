# File Changes — v27

## Modified

### `app/src/main/java/com/zipapkbuilder/MainActivity.kt`
4,492 → 4,739 lines (+461 / −214 across the file). Every behavioral change in
this update lives here. In one file, roughly in the order it was touched:
- Swapped the unused `kotlin.concurrent.thread` import for
  `java.util.concurrent.{Executors, ExecutorService}`.
- Added a shared `bgExecutor` (bounded 4-thread pool) field and an
  `onDestroy()` override that shuts it down and stops the status-dot
  animations.
- Replaced all 25 `thread { ... }` call sites with `bgExecutor.execute { ... }`
  (mechanical, verified no call site relied on the `Thread` return value or
  `.join()`). As part of this, all 9 `return@thread` labels were updated to
  `return@execute` — the implicit label always matches the enclosing
  function's name, so this follows directly from the rename.
- Fixed the `restoreSavedBuildState()` brace bug, the `promptCreateRepo()`
  `repeat`/`return@repeat` bug, the file editor's per-keystroke gutter
  rebuild, `deleteItemsRecursive()`'s abort-on-first-failure behavior, and the
  MediaStore path-reporting inaccuracy in `saveZipToDownloadsInternal()`.
- Removed the three duplicate local `fmtBytes()` definitions.
- Refactored `downloadArtifact()` to call `buildDownloadProgressDialog()`
  instead of hand-building its own copy of the dialog; renamed its local view
  references (`progressDialog` → `dlUi.dialog`, `progressBarDl` →
  `dlUi.progressBar`, etc.) to match the shared `DownloadDialogHolder`.
- Added `logApkInfoFromZip()`, `cleanupStaleCacheFiles()`,
  `hasEnoughStorage()`, `validateProjectZip()`, `friendlyError()`, and
  `fmtDuration()` as new helper functions.
- Added the Build History feature: `addBuildToHistory()` /
  `loadBuildHistory()` (mirroring the existing Download History pair), wired
  into `runFlow()`'s success and failure paths, plus the
  `refreshBuildHistory()` UI population function inside `showSettingsDialog()`.
- Wired `validateProjectZip()` and a large-ZIP memory warning into `runFlow()`
  right after the ZIP is read into memory.
- Wired `hasEnoughStorage()` into both `downloadArtifact()` and
  `downloadLatestRunLogs()` before their download loops start.
- Wired `logApkInfoFromZip()` + cache cleanup into `downloadArtifact()`'s
  success path.
- Added the `scrollPending` flag and `LOG_CHAR_CAP` constant, and rewrote
  `appendLog()` to use both.
- Removed two fully dead fields, `btnDownloadLogs` and `btnSavedRepos` (and
  their now-orphaned explanatory comments).

### `app/src/main/AndroidManifest.xml`
Added `android:largeHeap="true"` to the `<application>` tag. See
`PERFORMANCE_REPORT.md` #5 for why.

### `app/build.gradle`
`versionCode 1` → `27`, `versionName "1.0"` → `"27"`. This had never been
bumped since the first release; it now actually reflects the app's real
version history going forward.

### `app/src/main/res/layout/dialog_settings.xml`
422 → 487 lines. Added the **Build History** section (header row with a Clear
button, a stats summary `TextView`, and an entries container) directly below
the existing Download History section, following its exact structural
pattern. New IDs: `sBtnClearBuildHistory`, `tvBuildStats`,
`layoutBuildHistory`.

## Added
- `CHANGELOG.md`
- `FEATURES_ADDED.md`
- `PERFORMANCE_REPORT.md`
- `BUGS_FIXED.md`
- `FILE_CHANGES.md` (this file)

## Deleted
None.

## Reviewed, Not Changed
- The embedded `WORKFLOW_YAML` and `KEYSTORE_WORKFLOW_YAML` strings (the
  GitHub Actions workflows this app generates and pushes) — already
  well-optimized; see `PERFORMANCE_REPORT.md`.
- `settings.gradle`, `gradle.properties`, `gradle-wrapper.properties` — no
  issues found.
