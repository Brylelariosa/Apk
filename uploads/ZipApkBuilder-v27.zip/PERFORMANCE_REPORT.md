# Performance Report — v27

A note on methodology first: this was a source-level review, not a profiled
one — there's no way to actually run the app or a Gradle build in the
environment this update was written in. Every item below is reasoned from
what the code does (allocation patterns, thread/loop behavior, I/O calls), not
from measured before/after numbers. Treat the "expected impact" notes as
reasoning, not benchmarks.

## Bottlenecks Found

### 1. Unbounded ad hoc thread creation
25 separate call sites did `thread { ... }`, each spinning up a brand-new OS
thread (with its own ~512KB–1MB default stack) for what's usually a short
network call. No ceiling existed on how many could be alive at once.

**Expected impact:** fewer thread creations/teardowns per session and a lower
worst-case memory footprint from live thread stacks — most noticeable on a
low-RAM device under normal use (a handful of actions in a session), and it
also removes a real (if unlikely) failure mode where rapid tapping could have
spawned many concurrent threads with no bound.

### 2. Redundant scroll-to-bottom during log streaming
`appendLog()` queued a `fullScroll()` pass for every single line appended.
A verbose Gradle build streams hundreds of lines; that's hundreds of queued
scroll passes, most of them made obsolete by the next line arriving
microseconds later.

**Expected impact:** far fewer scroll passes during a build's log streaming —
this is the single most repeated code path in the whole app during active use,
so it's the one most worth trimming.

### 3. Line-number gutter recomputed on every keystroke
The file editor's line-number column re-split the *entire document* and
rebuilt the whole `"1\n2\n3\n…\nN"` gutter string on every character typed,
regardless of whether that character could have changed the line count.

**Expected impact:** this is the fix most likely to be *felt* directly — typing
in a file of any real size (a few hundred lines or more) should no longer lag,
since the expensive path now only runs on edits that actually touch a newline
(pressing Enter, deleting a line, pasting multi-line text), not on ordinary
typing.

### 4. Wasted polling after success
`promptCreateRepo()`'s `repeat(10) { return@repeat }` loop could not exit
early on success — `return@repeat` only skips to the next iteration. Once the
repo became reachable, the loop kept sleeping 2s and re-checking for every
remaining iteration anyway.

**Expected impact:** up to ~18 fewer seconds of pure waiting on the "create new
repo" path (the exact amount depends on which iteration first succeeded).

### 5. Memory pressure on large project uploads
The Git Data API upload path can hold several full copies of a project ZIP in
memory at once during encoding (raw bytes → Base64 string → JSON-wrapped
payload → UTF-8 byte array). For a ZIP approaching the app's own 99MB cap,
that's a meaningful multiple of 99MB resident at once, without the app
requesting a larger heap.

**Expected impact:** `android:largeHeap="true"` raises the ceiling the OS gives
the app before it would OOM-kill on this path — a standard mitigation for an
app that legitimately needs to hold a large buffer temporarily, rather than a
rewrite of the (working, tested) upload logic itself.

### 6. Duplicated dialog construction
`downloadArtifact()` hand-built its own ~115-line copy of the download-progress
dialog that `buildDownloadProgressDialog()` already provides — extra bytecode,
and two copies that could silently drift apart over time.

**Expected impact:** smaller method, one less thing to keep in sync, no
behavior change (verified the resulting dialog wiring — pause/resume/cancel —
is identical to what the hand-built version did).

## Memory Improvements
- `android:largeHeap="true"` (see #5 above).
- Console log (`tvLog`) now capped at ~200k characters, trimmed from the
  oldest end, so a long or looping build — or just a long-lived session across
  several builds — can't grow its backing buffer without bound.
- The artifact ZIP cached during download is now deleted immediately after
  being copied to Downloads, instead of accumulating in `cacheDir` forever.
- A one-time stale-cache sweep on cold start catches any leftover temp files
  from a session that was killed before its own cleanup ran.
- Bounding background threads to 4 also bounds worst-case memory spent on
  live thread stacks.

## Build Speed
This refers to two different things worth separating:
- **This app's own APK build speed** wasn't a target here — this is a hand-
  maintained app, not a generated one, and its own build wasn't observed to
  be slow.
- **The GitHub Actions builds this app triggers for other projects**: the
  embedded workflow was reviewed for caching/speed opportunities and is
  already in good shape — `gradle/actions/setup-gradle` for dependency
  caching, a dedicated NDK/CMake cache, a hash-keyed incremental cache for
  C++/CMake build outputs, and `--configuration-cache --build-cache --parallel`
  on the actual Gradle invocation. Nothing was changed here; adding another
  cache layer on top would be redundant rather than additive, and the CI
  workflow is the highest-blast-radius part of the whole system to get wrong.
- Fixed the ~18s of wasted polling in new-repo creation (see #4).

## Battery
Nothing here draws obvious continuous battery beyond what the app already
did (network polling during a build, which is inherent to the design). The
executor change indirectly helps a little: fewer live threads means less
scheduler overhead, and the app is no longer capable of accumulating an
unbounded number of concurrently-running background threads if someone taps
around quickly.

## What Was Reviewed but Left Alone
- The `HttpURLConnection` + `.disconnect()` pattern used throughout: this is
  a deliberate, consistent choice (guarantees resource cleanup) rather than an
  oversight, and changing it to optimize for connection-pool reuse would be a
  behavior change to network code with no way to verify it here — not worth
  the risk for a marginal gain.
- The embedded GitHub Actions workflow YAML (see above) — already
  well-optimized.
- The overall single-file, single-Activity architecture — the brief was
  explicit about not rewriting working systems, and a structural refactor
  (e.g. splitting the ~4,700-line file into multiple classes) is a much
  higher-risk change for a codebase that can't be compiled in this
  environment to verify. Everything in this update is a targeted, in-place
  change instead.
