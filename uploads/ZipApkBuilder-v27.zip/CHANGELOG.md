# Changelog — v27

A performance, reliability, quality-of-life, and feature update. No architectural
rewrites — every change is a targeted fix or addition on top of the existing
single-Activity design.

## Fixed
- **Owner chip showed even when it shouldn't.** Missing braces on an `if` meant
  `tvOwnerInfo.visibility = VISIBLE` ran unconditionally instead of only when
  `savedOwner` was actually set. See `BUGS_FIXED.md`.
- **New-repo creation waited up to ~18s longer than necessary.** A
  `repeat(10) { return@repeat }` loop can't actually break early —
  `return@repeat` just skips to the next iteration — so after the repo became
  reachable, the code kept sleeping and polling anyway. Now breaks immediately.
- **File editor lagged while typing in any reasonably large file.** The
  line-number gutter recomputed the entire line count on every keystroke.
  Now it only recomputes when the edit actually spans a newline.
- **Downloaded-file path could be wrong.** On a filename collision, Android's
  MediaStore silently renames the file (`name (1).zip`); the app used to
  report the originally-requested name regardless. It now queries the name
  MediaStore actually used.
- **One failed item could silently cancel an entire batch delete.** Deleting
  multiple files/folders at once now continues through all selected items
  even if one fails, and reports a clear summary at the end.
- **A temp file leaked into the cache on every artifact download.** The
  downloaded artifact ZIP was copied to Downloads but never removed from
  `cacheDir` afterward — every download left a permanent copy behind.
- **Duplicate/inconsistent byte-formatting.** Four separate implementations
  of "format bytes as KB/MB/GB" existed with different rounding and no GB
  tier on three of them. Unified into one.

## Performance
- Replaced 25 ad hoc `thread { }` spawns with a single shared, bounded
  (4-thread) background executor — less thread-creation overhead and memory
  per action, with enough concurrency that a long build never blocks
  unrelated actions like Browse Artifacts.
- `appendLog()` no longer queues a separate scroll pass for every streamed
  build-log line — bursts now coalesce into a single pending scroll.
- The console log now has a length cap (~200k characters) so a very long or
  looping build, or a long multi-build session, can't grow it unbounded.
- Added `android:largeHeap="true"` — uploading a project ZIP can briefly hold
  several full in-memory copies (raw bytes, Base64 string, JSON payload, UTF-8
  bytes); for a large ZIP this can approach the default per-app heap ceiling
  on a low-RAM device.
- `downloadArtifact()` no longer hand-builds its own ~115-line copy of the
  download-progress dialog; it reuses the same builder `downloadLatestRunLogs()`
  already relies on.
- Reviewed the embedded GitHub Actions workflow for build-speed opportunities.
  It already uses `setup-gradle` dependency caching, dedicated NDK/CMake
  caching, hash-keyed incremental C++ build caching, and
  `--configuration-cache --build-cache --parallel` — left untouched rather
  than adding redundant caching on top of what's already there.

## Reliability & Quality of Life
- **Pre-upload ZIP validation**: peeks the ZIP's entry list (already in memory,
  no extra I/O) for `settings.gradle(.kts)` and `gradlew` before uploading, and
  warns if either is missing — catching the most common "wrong ZIP" mistake
  before spending an upload and a full CI run on it.
- **Storage space check** before artifact/log downloads start, so a large file
  fails fast with a clear message instead of partway through.
- **Friendlier network error messages** (no internet, timeout, TLS/date issue,
  unreachable host) for the main build flow.
- **Automatic cleanup of leftover temp files** from a previous session that was
  killed before its own cleanup ran — swept once on cold start.
- **`onDestroy()` added** — shuts the background executor down and stops the
  status-dot animations, where previously nothing was cleaned up at all.
- Large ZIP (>40MB) uploads now log an upfront note that the upload will hold
  the file fully in memory and may take a while.
- `versionCode`/`versionName` now actually track the app's real version history
  (was frozen at `1` / `"1.0"` since the very first release, through 26 prior
  versions).

## New Features
- **Build History** (Settings → Build History): the last 30 builds triggered
  from this device, with outcome, repo/branch, duration, and time — recorded
  locally, no network call needed to view it.
- **Build Statistics**: a one-line summary (success rate, average successful
  build duration) computed from that same local history.
- **Build Duration Timer**: every build now measures and logs its own
  end-to-end elapsed time.
- **APK Info Viewer**: after a successful artifact download, the app peeks
  inside the ZIP for the `.apk` and logs its package name, version, min/target
  SDK, and size — a quick sanity check without installing it first.

## Code Quality
- Removed 2 fields (`btnDownloadLogs`, `btnSavedRepos`) that were declared,
  always null, and never read anywhere.
- Removed 3 duplicate local `fmtBytes()` copies (kept the one class-level
  version; all call sites are unaffected).
- Removed ~115 lines of duplicated dialog-construction code from
  `downloadArtifact()`.
- Removed the now-unused `kotlin.concurrent.thread` import.
- Verified there are no unused imports anywhere in the file (checked
  systematically, not spot-checked).

See `BUGS_FIXED.md`, `PERFORMANCE_REPORT.md`, `FEATURES_ADDED.md`, and
`FILE_CHANGES.md` for full detail on each item above.
