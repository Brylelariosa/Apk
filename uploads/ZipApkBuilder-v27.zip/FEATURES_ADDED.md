# Features Added — v27

## Build History
**Where:** Settings (⚙) → scroll down to **Build History**, below Download History.

**What it does:** Every time you run 🚀 Upload & Build, the outcome (success /
failed / cancelled), the repo and branch, and how long it took are recorded
locally on-device. The section shows your last 30 builds, newest first, with
an icon (✓ / ✗ / ⊘) so you can scan outcomes at a glance. Tap **Clear** to wipe
the history.

**Why it's separate from "Build Log":** the existing Build Log button already
lets you browse any past GitHub Actions run in detail, but that requires a
couple of live API calls just to open. Build History is instant and free —
it's a local log of what *this device* has triggered, not a window into
GitHub's data.

## Build Statistics
**Where:** Same Settings section, shown as a single line above the list
(e.g. *"14 build(s) · 86% success · avg 3m 42s"*).

**What it does:** Success rate is computed over all recorded builds; average
duration is computed only from successful ones, so a quick network failure
doesn't drag the "typical build time" number down misleadingly.

## Build Duration Timer
**Where:** Automatic — shown in the console log at the end of every build
(*"⏱ Build finished in 3m 58s"*) and stored with each Build History entry.

**What it does:** Times the full flow — verifying the token, checking/creating
the repo, uploading the ZIP, waiting for the run, and downloading the
artifact — end to end, as experienced from the phone, not just GitHub's own
run duration.

## APK Info Viewer
**Where:** Automatic — appears in the console log right after a successful
📲 Download & Install APK.

**What it does:** Peeks inside the downloaded artifact ZIP for the `.apk` file
and reports:
- Package name
- Version name and version code
- Minimum and target SDK
- APK size

This is a quick way to confirm what actually got built (right package name,
expected version bump, sane SDK range) without needing to install the APK
first. If the artifact doesn't contain an `.apk` (e.g. a logs-only artifact),
nothing is shown — this never blocks or slows down the download itself.

## Pre-Upload ZIP Validation
**Where:** Automatic — runs right after you pick a ZIP and tap 🚀 Upload & Build,
before the upload starts.

**What it does:** Scans the ZIP's entry names (already-loaded bytes, no extra
reads) for `settings.gradle`/`settings.gradle.kts` and `gradlew`. If either is
missing, a warning appears in the log *before* the upload happens — the same
files the workflow's own "Find project directory" and "Make gradlew
executable" steps require. This catches the single most common mistake
(wrong ZIP, or a folder zipped one level off) before spending an upload and a
full CI run finding out.

## Storage Space Check
**Where:** Automatic — runs right before any artifact or build-log download
starts.

**What it does:** Checks that the destination has enough free space for the
incoming file (with a 10MB safety margin). If not, the download fails
immediately with a clear message instead of partway through with a confusing
I/O error.

## Automatic Stale-Cache Cleanup
**Where:** Automatic — runs once, quietly, on app startup.

**What it does:** If a previous session was killed (force-close, low-memory
kill, crash) before it could clean up its own temp files, this sweeps any
leftover artifact/log/APK-info temp files older than a couple of minutes out
of the app's cache. You'll see a short log line only if it actually found
something to clean up.
