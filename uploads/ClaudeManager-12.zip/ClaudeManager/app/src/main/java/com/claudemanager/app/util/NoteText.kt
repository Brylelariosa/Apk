package com.claudemanager.app.util

/**
 * The rules for a project's note, in one place so the dialog, the ViewModel and the tests agree.
 *
 * A note used to stop at 140 characters; it now takes a full message (a pasted error, a status
 * update). The card shows the first lines and expands on tap, and the note dialog scrolls.
 *
 * Pure Kotlin on purpose: nothing here depends on Android.
 */
object NoteText {

    /** The longest note: about 300 words. */
    const val MAX_LENGTH = 2000

    /** [raw] cut to [MAX_LENGTH]. The cut never leaves half an emoji (a lone surrogate) at the end. */
    fun clamp(raw: String): String {
        if (raw.length <= MAX_LENGTH) return raw
        val cut = if (Character.isHighSurrogate(raw[MAX_LENGTH - 1])) MAX_LENGTH - 1 else MAX_LENGTH
        return raw.substring(0, cut)
    }

    /** What gets saved: the surrounding blanks removed, then [clamp]ed. */
    fun clean(raw: String): String = clamp(raw.trim())
}
