package com.claudemanager.app.util

import android.content.Context
import android.text.format.DateFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.abs

object TimeUtil {

    private const val DAY_MS = 24L * 60L * 60L * 1000L

    /**
     * "3d 4h", "2h 17m", "42m", "9m 05s", "45s".
     * Minutes are floored, so a fresh 2h 30m timer reads 2h 29m a second later. From one day up
     * the minutes are left out: a reset on Sunday does not need them.
     */
    fun formatRemaining(ms: Long): String {
        val totalSec = ms.coerceAtLeast(0L) / 1000L
        val d = totalSec / 86_400L
        val h = (totalSec % 86_400L) / 3600L
        val m = (totalSec % 3600L) / 60L
        val s = totalSec % 60L
        return when {
            d > 0L -> "${d}d ${h}h"
            h > 0L -> "${h}h ${m}m"
            m >= 10L -> "${m}m"
            m > 0L -> "${m}m ${s.toString().padStart(2, '0')}s"
            else -> "${s}s"
        }
    }

    /** "5h", "2h 30m", "45m". */
    fun formatDuration(ms: Long): String {
        val totalMin = ms.coerceAtLeast(0L) / 60_000L
        val h = totalMin / 60L
        val m = totalMin % 60L
        return when {
            h > 0L && m > 0L -> "${h}h ${m}m"
            h > 0L -> "${h}h"
            else -> "${m}m"
        }
    }

    /** Clock time in the phone's 12h/24h style. */
    fun formatTime(context: Context, ms: Long): String =
        DateFormat.getTimeFormat(context).format(Date(ms))

    private fun sameDay(a: Long, b: Long): Boolean {
        val ca = Calendar.getInstance().apply { timeInMillis = a }
        val cb = Calendar.getInstance().apply { timeInMillis = b }
        return ca.get(Calendar.YEAR) == cb.get(Calendar.YEAR) &&
            ca.get(Calendar.DAY_OF_YEAR) == cb.get(Calendar.DAY_OF_YEAR)
    }

    /**
     * Clock time, prefixed with the weekday when it is not today ("Wed 5:00 PM"). A week or more
     * away (or back) the date comes too ("Wed, Oct 28 5:00 PM"), so a weekday is never ambiguous.
     */
    fun formatClock(context: Context, ms: Long, now: Long): String {
        val time = formatTime(context, ms)
        if (sameDay(ms, now)) return time
        val pattern = if (abs(daysBetween(now, ms)) >= 7L) "EEE, MMM d" else "EEE"
        val day = SimpleDateFormat(pattern, Locale.getDefault()).format(Date(ms))
        return "$day $time"
    }

    /**
     * The next moment the wall clock reads [hour]:[minute], strictly after [now].
     * Like setting an alarm: 9:00 picked at 10:00 means 9:00 tomorrow.
     */
    fun nextOccurrence(hour: Int, minute: Int, now: Long): Long {
        val c = Calendar.getInstance().apply {
            timeInMillis = now
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        if (c.timeInMillis <= now) c.add(Calendar.DAY_OF_YEAR, 1)
        return c.timeInMillis
    }

    /** The start (midnight) of the day [ms] falls on. */
    fun startOfDay(ms: Long): Long {
        val c = Calendar.getInstance().apply {
            timeInMillis = ms
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        return c.timeInMillis
    }

    /** [ms] moved [days] calendar days on (back when negative), keeping the clock time. */
    fun addDays(ms: Long, days: Int): Long {
        val c = Calendar.getInstance().apply {
            timeInMillis = ms
            add(Calendar.DAY_OF_YEAR, days)
        }
        return c.timeInMillis
    }

    /** The moment on the day that starts at [dayStart] when the wall clock reads [hour]:[minute]. */
    fun atTime(dayStart: Long, hour: Int, minute: Int): Long {
        val c = Calendar.getInstance().apply {
            timeInMillis = dayStart
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        return c.timeInMillis
    }

    /**
     * Calendar days from the day of [from] to the day of [to]: 0 for the same day, 1 for the next
     * day, negative when [to] is earlier. Rounded, so a daylight-saving hour never skews it.
     */
    fun daysBetween(from: Long, to: Long): Long =
        Math.round((startOfDay(to) - startOfDay(from)).toDouble() / DAY_MS)

    /** "Wed". */
    fun weekdayShort(ms: Long): String =
        SimpleDateFormat("EEE", Locale.getDefault()).format(Date(ms))

    /** "Wed, Oct 28": the weekday and the date. */
    fun formatDate(ms: Long): String =
        SimpleDateFormat("EEE, MMM d", Locale.getDefault()).format(Date(ms))

    /** "Today", "Tomorrow", then the plain date ("Oct 28"), counted from [now]. */
    fun relativeDay(ms: Long, now: Long): String = when (daysBetween(now, ms)) {
        0L -> "Today"
        1L -> "Tomorrow"
        else -> SimpleDateFormat("MMM d", Locale.getDefault()).format(Date(ms))
    }

    fun dayKey(ms: Long): Int {
        val c = Calendar.getInstance().apply { timeInMillis = ms }
        return c.get(Calendar.YEAR) * 1000 + c.get(Calendar.DAY_OF_YEAR)
    }

    fun dayLabel(ms: Long, now: Long): String {
        if (sameDay(ms, now)) return "Today"
        if (sameDay(ms, now - 24L * 60L * 60L * 1000L)) return "Yesterday"
        return SimpleDateFormat("EEE, MMM d", Locale.getDefault()).format(Date(ms))
    }
}
