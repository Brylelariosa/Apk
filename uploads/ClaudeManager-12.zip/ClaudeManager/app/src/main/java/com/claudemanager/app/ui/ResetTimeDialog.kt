package com.claudemanager.app.ui

import android.app.TimePickerDialog
import android.text.format.DateFormat
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.claudemanager.app.data.Project
import com.claudemanager.app.util.ResetDay
import com.claudemanager.app.util.TimeUtil
import java.util.Calendar

/**
 * Set the reset as a day and a clock time: "Wednesday 5:00 PM", "Sunday 5:00 PM", or just a time.
 *
 * The day row offers today and the seven days after it. Until a day is tapped it follows the time
 * like an alarm (9:00 picked at 10:00 means 9:00 tomorrow); tapping a day pins it (see ResetDay).
 * The time opens the system time picker, so it follows the phone's 12h/24h setting. The status is
 * not touched. Used by "Set reset time" and by the RUNNING -> WAITING change (see ResetPrompt).
 */
@Composable
fun ResetTimeDialog(project: Project, now: Long, onSet: (Long) -> Unit, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val cs = MaterialTheme.colorScheme

    // Fixed while the dialog is open, so the day row and the starting point stay put.
    val openedAt = remember(project.id) { System.currentTimeMillis() }
    val days = remember(openedAt) { ResetDay.choices(openedAt) }
    // Start from the current reset, or from "now + the default window" when there is none.
    val initial = remember(project.id) {
        val end = project.timerEndTimestamp
        val millis = if (end != null && end > openedAt) end else openedAt + project.defaultDurationMillis
        Calendar.getInstance().apply { timeInMillis = millis }
    }

    var pinnedDay by remember(project.id) {
        mutableStateOf(ResetDay.pinnedDayFor(project.timerEndTimestamp, openedAt))
    }
    var hour by remember(project.id) { mutableStateOf(initial.get(Calendar.HOUR_OF_DAY)) }
    var minute by remember(project.id) { mutableStateOf(initial.get(Calendar.MINUTE)) }

    val resetAt = ResetDay.resolve(pinnedDay, hour, minute, now)
    val shownDay = TimeUtil.startOfDay(resetAt)
    val ahead = resetAt > now

    // The system time picker sits on top of this dialog, so it must not outlive it.
    val picker = remember { mutableStateOf<TimePickerDialog?>(null) }
    DisposableEffect(Unit) {
        onDispose { picker.value?.dismiss() }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = cs.surface,
        title = { Text("Reset day & time") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Day",
                    style = MaterialTheme.typography.labelLarge,
                    color = cs.onSurfaceVariant
                )
                for (rowOfDays in days.chunked(4)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        for (d in rowOfDays) {
                            DayChip(
                                weekday = d.weekday,
                                caption = d.caption,
                                selected = d.start == shownDay,
                                modifier = Modifier.weight(1f)
                            ) { pinnedDay = d.start }
                        }
                    }
                }

                Text(
                    text = "Time",
                    style = MaterialTheme.typography.labelLarge,
                    color = cs.onSurfaceVariant
                )
                OutlinedButton(
                    onClick = {
                        val dialog = TimePickerDialog(
                            context,
                            { _, h, m ->
                                hour = h
                                minute = m
                            },
                            hour,
                            minute,
                            DateFormat.is24HourFormat(context)
                        )
                        dialog.setTitle("Reset time")
                        picker.value = dialog
                        dialog.show()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 56.dp),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(start = 16.dp, end = 8.dp, top = 8.dp, bottom = 8.dp)
                ) {
                    Text(
                        text = TimeUtil.formatTime(context, resetAt),
                        modifier = Modifier.weight(1f),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Icon(Icons.Filled.ArrowDropDown, contentDescription = null)
                }

                Text(
                    text = if (ahead) {
                        "Resets ${TimeUtil.formatDate(resetAt)} at ${TimeUtil.formatTime(context, resetAt)} " +
                            "(in ${TimeUtil.formatRemaining(resetAt - now)})"
                    } else {
                        "That time has already passed. Pick a later time or another day."
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (ahead) cs.onSurfaceVariant else cs.error
                )
            }
        },
        confirmButton = {
            Button(onClick = { onSet(resetAt) }, enabled = ahead) { Text("Set") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
