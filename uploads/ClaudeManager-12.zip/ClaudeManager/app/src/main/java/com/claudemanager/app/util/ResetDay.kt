package com.claudemanager.app.util

import java.util.Calendar

/** One day the reset picker offers: its start, the weekday on top, and "Today" / "Tomorrow" / the date. */
data class ResetDayChoice(val start: Long, val weekday: String, val caption: String)

/**
 * Which day a reset falls on. The picker asks for a day and a clock time, so a reset can be
 * "Wednesday 5:00 PM" or "Sunday 5:00 PM" as well as "in five hours".
 *
 *  - The picker offers today and the seven days after it (eight days), so every weekday is there,
 *    and so is the same weekday one week on.
 *  - A day the user has not tapped is automatic: the next time the clock reads the chosen time,
 *    like an alarm (9:00 picked at 10:00 means 9:00 tomorrow). Tapping a day pins it: that day
 *    exactly, whatever the time.
 *
 * Pure Kotlin on purpose: the clock is passed in, so the result depends on nothing else.
 */
object ResetDay {

    /** Today and the seven days after it. */
    const val DAYS_OFFERED = 8

    /** The start of today and of each following day, [count] days in all. */
    fun offered(now: Long, count: Int = DAYS_OFFERED): List<Long> =
        List(count) { i -> TimeUtil.startOfDay(TimeUtil.addDays(now, i)) }

    /** [offered] with the labels the picker shows. */
    fun choices(now: Long, count: Int = DAYS_OFFERED): List<ResetDayChoice> =
        offered(now, count).map { start ->
            ResetDayChoice(
                start = start,
                weekday = TimeUtil.weekdayShort(start),
                caption = TimeUtil.relativeDay(start, now)
            )
        }

    /**
     * The reset moment for a day and a clock time. [pinnedDay] is the start of the tapped day, or
     * null for automatic (the next [hour]:[minute] after [now]). A pinned day is taken literally,
     * so the result can be in the past (today, with a time that has gone by): the caller checks.
     */
    fun resolve(pinnedDay: Long?, hour: Int, minute: Int, now: Long): Long =
        if (pinnedDay == null) {
            TimeUtil.nextOccurrence(hour, minute, now)
        } else {
            TimeUtil.atTime(pinnedDay, hour, minute)
        }

    /**
     * What the picker starts on for a reset that is already set at [end]: null (automatic) when
     * automatic lands on the same day anyway, otherwise the day of [end], pinned. A reset that is
     * not set, or already over, starts automatic.
     */
    fun pinnedDayFor(end: Long?, now: Long): Long? {
        if (end == null || end <= now) return null
        val clock = Calendar.getInstance().apply { timeInMillis = end }
        val auto = TimeUtil.nextOccurrence(
            clock.get(Calendar.HOUR_OF_DAY),
            clock.get(Calendar.MINUTE),
            now
        )
        val day = TimeUtil.startOfDay(end)
        return if (TimeUtil.startOfDay(auto) == day) null else day
    }
}
