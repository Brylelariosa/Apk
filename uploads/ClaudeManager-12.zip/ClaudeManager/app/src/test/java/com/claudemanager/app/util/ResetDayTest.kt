package com.claudemanager.app.util

import java.util.Calendar
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * "Reset on Wednesday or Sunday 5:00 PM". The dates sit in mid-July 2026, away from every
 * daylight-saving change, so the tests give the same answer in any time zone:
 * Wed 15 Jul, Thu 16, Fri 17, Sat 18, Sun 19, Mon 20, Tue 21, Wed 22.
 */
class ResetDayTest {

    private fun time(dayOfMonth: Int, hour: Int, minute: Int): Long =
        Calendar.getInstance().apply {
            clear()
            set(2026, Calendar.JULY, dayOfMonth, hour, minute, 0)
        }.timeInMillis

    private fun midnight(dayOfMonth: Int): Long = time(dayOfMonth, 0, 0)

    /** Wednesday morning. */
    private val now = time(15, 10, 30)

    // ---- the days on offer ----

    @Test
    fun theDayRowIsTodayAndTheSevenDaysAfter() {
        val days = ResetDay.offered(now)
        assertEquals(ResetDay.DAYS_OFFERED, days.size)
        assertEquals((15..22).map { midnight(it) }, days)
    }

    @Test
    fun theFirstTwoDaysAreCalledTodayAndTomorrow() {
        val choices = ResetDay.choices(now)
        assertEquals(ResetDay.DAYS_OFFERED, choices.size)
        assertEquals("Today", choices[0].caption)
        assertEquals("Tomorrow", choices[1].caption)
        assertEquals(midnight(15), choices[0].start)
        assertEquals(midnight(22), choices.last().start)
        assertTrue(choices.all { it.weekday.isNotBlank() && it.caption.isNotBlank() })
    }

    // ---- automatic day: like an alarm ----

    @Test
    fun automaticTakesTodayWhenTheTimeIsStillAhead() {
        assertEquals(time(15, 17, 0), ResetDay.resolve(null, 17, 0, now))
    }

    @Test
    fun automaticTakesTomorrowWhenTheTimeHasPassed() {
        assertEquals(time(16, 9, 0), ResetDay.resolve(null, 9, 0, now))
    }

    @Test
    fun automaticNeverGivesTheCurrentMinute() {
        // 10:30 asked at 10:30:00 sharp is not "after now", so it is tomorrow's.
        assertEquals(time(16, 10, 30), ResetDay.resolve(null, 10, 30, now))
    }

    // ---- a tapped day: Wednesday or Sunday 5:00 PM ----

    @Test
    fun aTappedDayGivesThatDayAtThatTime() {
        assertEquals(time(19, 17, 0), ResetDay.resolve(midnight(19), 17, 0, now)) // Sunday 5:00 PM
        assertEquals(time(22, 17, 0), ResetDay.resolve(midnight(22), 17, 0, now)) // next Wednesday 5:00 PM
    }

    @Test
    fun aTappedDayKeepsTheMinutes() {
        assertEquals(time(19, 17, 45), ResetDay.resolve(midnight(19), 17, 45, now))
    }

    @Test
    fun aTappedDayIsTakenLiterallyEvenWhenItIsAlreadyPast() {
        // Today at 9:00 is behind us. The dialog sees that and refuses it; resolve does not roll it on.
        val resolved = ResetDay.resolve(midnight(15), 9, 0, now)
        assertEquals(time(15, 9, 0), resolved)
        assertTrue(resolved < now)
    }

    // ---- where the picker starts for a reset that is already set ----

    @Test
    fun noResetStartsAutomatic() {
        assertNull(ResetDay.pinnedDayFor(null, now))
    }

    @Test
    fun aResetThatIsOverStartsAutomatic() {
        assertNull(ResetDay.pinnedDayFor(now - 1L, now))
        assertNull(ResetDay.pinnedDayFor(now, now))
    }

    @Test
    fun aResetLaterTodayStartsAutomatic() {
        assertNull(ResetDay.pinnedDayFor(time(15, 17, 0), now))
    }

    @Test
    fun aResetTomorrowWithinTheNextDayStartsAutomatic() {
        // 9:00 tomorrow is 22.5 hours away: automatic lands on it.
        assertNull(ResetDay.pinnedDayFor(time(16, 9, 0), now))
    }

    @Test
    fun aResetTomorrowMoreThanADayAwayIsPinned() {
        // Wed 16:00 -> Thu 17:00 is 25 hours; automatic would pick Wed 17:00, one day too early.
        val later = time(15, 16, 0)
        assertEquals(midnight(16), ResetDay.pinnedDayFor(time(16, 17, 0), later))
    }

    @Test
    fun aResetSeveralDaysAwayIsPinnedToItsDay() {
        assertEquals(midnight(19), ResetDay.pinnedDayFor(time(19, 17, 0), now))
        assertEquals(midnight(22), ResetDay.pinnedDayFor(time(22, 17, 0), now))
    }

    @Test
    fun pinningTheDayOfASetResetGivesTheSameResetBack() {
        val end = time(19, 17, 0)
        val pinned = ResetDay.pinnedDayFor(end, now)
        assertEquals(end, ResetDay.resolve(pinned, 17, 0, now))
    }
}
