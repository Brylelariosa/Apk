package com.claudemanager.app.util

import java.util.Calendar
import org.junit.Assert.assertEquals
import org.junit.Test

/**
 * The pure parts of TimeUtil (nothing here needs a Context). Dates sit in mid-July, away from every
 * daylight-saving change, so the tests give the same answer in any time zone.
 */
class TimeUtilTest {

    private val minute = 60_000L
    private val hour = 60 * minute
    private val day = 24 * hour

    private fun time(month: Int, dayOfMonth: Int, hour: Int, minute: Int, second: Int = 0): Long =
        Calendar.getInstance().apply {
            clear()
            set(2026, month - 1, dayOfMonth, hour, minute, second)
        }.timeInMillis

    // ---- formatRemaining ----

    @Test
    fun remainingUnderAMinuteIsInSeconds() {
        assertEquals("45s", TimeUtil.formatRemaining(45_000L))
        assertEquals("0s", TimeUtil.formatRemaining(-5_000L))
    }

    @Test
    fun remainingUnderTenMinutesKeepsTheSeconds() {
        assertEquals("9m 05s", TimeUtil.formatRemaining(9 * minute + 5_000L))
    }

    @Test
    fun remainingUnderAnHourIsInMinutes() {
        assertEquals("42m", TimeUtil.formatRemaining(42 * minute + 30_000L))
    }

    @Test
    fun remainingUnderADayIsHoursAndMinutes() {
        assertEquals("2h 17m", TimeUtil.formatRemaining(2 * hour + 17 * minute + 59_000L))
        assertEquals("23h 59m", TimeUtil.formatRemaining(day - 1_000L))
    }

    @Test
    fun remainingFromADayUpIsDaysAndHours() {
        assertEquals("1d 0h", TimeUtil.formatRemaining(day))
        assertEquals("3d 4h", TimeUtil.formatRemaining(3 * day + 4 * hour + 59 * minute))
        assertEquals("6d 23h", TimeUtil.formatRemaining(7 * day - 1_000L))
    }

    // ---- day arithmetic ----

    @Test
    fun startOfDayIsMidnight() {
        assertEquals(time(7, 15, 0, 0), TimeUtil.startOfDay(time(7, 15, 17, 45, 30)))
        assertEquals(time(7, 15, 0, 0), TimeUtil.startOfDay(time(7, 15, 0, 0)))
    }

    @Test
    fun addDaysKeepsTheClockTimeAndCrossesMonths() {
        assertEquals(time(7, 18, 10, 30), TimeUtil.addDays(time(7, 15, 10, 30), 3))
        assertEquals(time(8, 2, 10, 30), TimeUtil.addDays(time(7, 30, 10, 30), 3))
        assertEquals(time(7, 14, 10, 30), TimeUtil.addDays(time(7, 15, 10, 30), -1))
    }

    @Test
    fun atTimeSetsTheClockOnThatDayAndDropsTheSeconds() {
        assertEquals(time(7, 19, 17, 0), TimeUtil.atTime(time(7, 19, 0, 0), 17, 0))
        assertEquals(time(7, 19, 17, 45), TimeUtil.atTime(time(7, 19, 0, 0), 17, 45))
    }

    @Test
    fun daysBetweenCountsCalendarDays() {
        val now = time(7, 15, 23, 59)
        assertEquals(0L, TimeUtil.daysBetween(now, time(7, 15, 0, 0)))
        assertEquals(1L, TimeUtil.daysBetween(now, time(7, 16, 0, 1)))
        assertEquals(4L, TimeUtil.daysBetween(now, time(7, 19, 17, 0)))
        assertEquals(17L, TimeUtil.daysBetween(now, time(8, 1, 3, 0)))
        assertEquals(-1L, TimeUtil.daysBetween(now, time(7, 14, 23, 59)))
    }

    @Test
    fun relativeDayNamesTodayAndTomorrow() {
        val now = time(7, 15, 10, 30)
        assertEquals("Today", TimeUtil.relativeDay(time(7, 15, 0, 0), now))
        assertEquals("Tomorrow", TimeUtil.relativeDay(time(7, 16, 0, 0), now))
    }
}
