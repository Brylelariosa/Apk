package com.claudemanager.app.util

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class NoteTextTest {

    private val max = NoteText.MAX_LENGTH
    private val emoji = "\uD83D\uDE00" // one emoji, two UTF-16 chars

    @Test
    fun aLongMessageFitsWhereTheOldBoxStoppedAt140() {
        assertTrue(max > 140)
        val message = "Build failed: could not resolve androidx.room:room-compiler:2.6.1. ".repeat(10)
        assertEquals(message, NoteText.clamp(message))
    }

    @Test
    fun aNoteOfExactlyTheLimitIsKept() {
        val note = "a".repeat(max)
        assertEquals(note, NoteText.clamp(note))
    }

    @Test
    fun aLongerNoteIsCutAtTheLimit() {
        val clamped = NoteText.clamp("a".repeat(max + 500))
        assertEquals(max, clamped.length)
    }

    @Test
    fun theCutNeverLeavesHalfAnEmoji() {
        // The emoji would start on the last allowed character and end after it.
        val raw = "a".repeat(max - 1) + emoji + "tail"
        assertEquals("a".repeat(max - 1), NoteText.clamp(raw))
    }

    @Test
    fun anEmojiThatEndsExactlyOnTheLimitIsKept() {
        val raw = "a".repeat(max - 2) + emoji + "tail"
        assertEquals("a".repeat(max - 2) + emoji, NoteText.clamp(raw))
    }

    @Test
    fun cleanTrimsTheBlanksAroundTheNote() {
        assertEquals("hello", NoteText.clean("  \n hello \t "))
        assertEquals("", NoteText.clean("   "))
    }

    @Test
    fun cleanTrimsFirstSoBlanksDoNotUseUpTheLimit() {
        val note = "a".repeat(max)
        assertEquals(note, NoteText.clean("   $note   "))
    }
}
