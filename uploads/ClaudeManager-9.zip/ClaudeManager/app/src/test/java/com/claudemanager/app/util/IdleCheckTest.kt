package com.claudemanager.app.util

import com.claudemanager.app.data.Account
import com.claudemanager.app.data.ActivityStatus
import com.claudemanager.app.data.Project
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class IdleCheckTest {

    private val hour = 60L * 60L * 1000L
    private val now = 100L * hour
    private val account = Account(id = 1L, email = "me@example.com")

    private fun project(
        status: ActivityStatus,
        accountId: Long? = account.id,
        createdAt: Long = 0L,
        lastStartedAt: Long? = null,
        lastActivityChangeAt: Long? = null,
        timerEndTimestamp: Long? = null
    ) = Project(
        name = "Demo",
        accountId = accountId,
        defaultDurationMillis = 5L * hour,
        timerEndTimestamp = timerEndTimestamp,
        activityStatus = status,
        createdAt = createdAt,
        lastStartedAt = lastStartedAt,
        lastActivityChangeAt = lastActivityChangeAt
    )

    private fun report(vararg projects: Project): IdleReport =
        IdleCheck.report(account, projects.toList(), now)

    @Test
    fun runningKeepsTheAccountInUseHoweverLongItHasBeenRunning() {
        val r = report(project(ActivityStatus.RUNNING, lastActivityChangeAt = now - 30 * hour))
        assertFalse(r.isIdle)
        assertTrue(r.isOpenEnded)
        assertNull(r.idleAt)
    }

    @Test
    fun everyWorkingStatusKeepsTheAccountInUse() {
        val working = listOf(
            ActivityStatus.RUNNING,
            ActivityStatus.BUILDING,
            ActivityStatus.TESTING,
            ActivityStatus.CUSTOM
        )
        for (status in working) {
            val r = report(project(status, lastActivityChangeAt = now - 12 * hour))
            assertFalse(status.name, r.isIdle)
        }
    }

    @Test
    fun workingReasonRemembersWhenTheStatusWasSet() {
        val setAt = now - 3 * hour
        val r = report(project(ActivityStatus.BUILDING, lastActivityChangeAt = setAt))
        val reason = r.reasons.single() as IdleReason.Working
        assertEquals(setAt, reason.since)
    }

    @Test
    fun statusSinceIsTheLastChangeThenTheStartThenTheCreation() {
        val p = project(
            ActivityStatus.RUNNING,
            createdAt = 1 * hour,
            lastStartedAt = 5 * hour,
            lastActivityChangeAt = 7 * hour
        )
        assertEquals(7 * hour, IdleCheck.statusSince(p))
        assertEquals(5 * hour, IdleCheck.statusSince(p.copy(lastActivityChangeAt = null)))
        assertEquals(
            1 * hour,
            IdleCheck.statusSince(p.copy(lastActivityChangeAt = null, lastStartedAt = null))
        )
    }

    @Test
    fun waitingWithAResetTimeIsInUseUntilThatTime() {
        val resetAt = now + 2 * hour
        val r = report(project(ActivityStatus.WAITING, timerEndTimestamp = resetAt))
        assertFalse(r.isIdle)
        assertFalse(r.isOpenEnded)
        assertEquals(1, r.reasons.size)
        assertTrue(r.reasons.single() is IdleReason.ResetPending)
        assertEquals(resetAt, r.idleAt)
    }

    @Test
    fun waitingWithoutAResetTimeStaysInUse() {
        val r = report(project(ActivityStatus.WAITING, lastActivityChangeAt = now - 8 * hour))
        assertFalse(r.isIdle)
        assertTrue(r.isOpenEnded)
        assertNull(r.idleAt)
        assertTrue(r.reasons.single() is IdleReason.Working)
    }

    @Test
    fun waitingIsOverOnceItsResetTimeHasPassed() {
        val r = report(project(ActivityStatus.WAITING, timerEndTimestamp = now - 1L))
        assertTrue(r.isIdle)
        assertNull(r.idleAt)
    }

    @Test
    fun readyFinishedAndErrorNeverBlockOnTheirOwn() {
        val quiet = listOf(ActivityStatus.READY, ActivityStatus.FINISHED, ActivityStatus.ERROR)
        for (status in quiet) {
            val r = report(project(status, lastActivityChangeAt = now))
            assertTrue(status.name, r.isIdle)
        }
    }

    @Test
    fun aPendingResetStillKeepsTheAccountInUse() {
        val resetAt = now + 3 * hour
        val r = report(project(ActivityStatus.FINISHED, timerEndTimestamp = resetAt))
        assertFalse(r.isIdle)
        assertEquals(1, r.reasons.size)
        assertEquals(resetAt, r.idleAt)
    }

    @Test
    fun theDeleteHoldKeepsTheAccountInUseUntilItEnds() {
        val held = account.copy(holdUntil = now + 3 * hour)
        val r = IdleCheck.report(held, emptyList(), now)
        assertFalse(r.isIdle)
        assertEquals(now + 3 * hour, r.idleAt)

        val over = account.copy(holdUntil = now - 1L)
        assertTrue(IdleCheck.report(over, emptyList(), now).isIdle)
    }

    @Test
    fun idleAtIsTheLatestEndAmongTheTimedReasons() {
        val soon = now + 1 * hour
        val later = now + 3 * hour
        val r = report(
            project(ActivityStatus.WAITING, timerEndTimestamp = soon),
            project(ActivityStatus.FINISHED, timerEndTimestamp = later)
        )
        assertEquals(2, r.reasons.size)
        assertEquals(later, r.idleAt)
    }

    @Test
    fun aReasonWithoutAnEndTimeMeansThereIsNoIdleTime() {
        val r = report(
            project(ActivityStatus.RUNNING, lastActivityChangeAt = now - 1 * hour),
            project(ActivityStatus.FINISHED, timerEndTimestamp = now + 3 * hour)
        )
        assertEquals(2, r.reasons.size)
        assertTrue(r.isOpenEnded)
        assertNull(r.idleAt)
    }

    @Test
    fun projectsOfOtherAccountsAreIgnored() {
        val r = report(project(ActivityStatus.RUNNING, accountId = 2L, lastActivityChangeAt = now))
        assertTrue(r.isIdle)
    }

    // ---- Several accounts at once ----

    private val other = Account(id = 2L, email = "other@example.com")
    private val third = Account(id = 3L, email = "third@example.com", holdUntil = now + hour)

    private val mixed = listOf(
        project(ActivityStatus.RUNNING, accountId = account.id, lastActivityChangeAt = now),
        project(ActivityStatus.FINISHED, accountId = other.id, timerEndTimestamp = now - 1L),
        project(ActivityStatus.RUNNING, accountId = null, lastActivityChangeAt = now)
    )

    @Test
    fun reportsGiveEveryAccountTheSameResultAsASingleReport() {
        val everyone = listOf(account, other, third)
        val all = IdleCheck.reports(everyone, mixed, now)
        assertEquals(setOf(1L, 2L, 3L), all.keys)
        for (a in everyone) {
            val single = IdleCheck.report(a, mixed, now)
            assertEquals("account ${a.id}", single.isIdle, all.getValue(a.id).isIdle)
            assertEquals("account ${a.id}", single.reasons, all.getValue(a.id).reasons)
        }
    }

    @Test
    fun idleAccountsKeepsOnlyTheIdleOnesInTheirOrder() {
        // account: running, other: reset over, third: held after a delete.
        assertEquals(listOf(other), IdleCheck.idleAccounts(listOf(account, other, third), mixed, now))
        assertEquals(
            listOf(other),
            IdleCheck.idleAccounts(listOf(third, other, account), mixed, now)
        )
        // Once the hold is over, the third account is idle too, and the order stays as given.
        assertEquals(
            listOf(third, other),
            IdleCheck.idleAccounts(listOf(third, other, account), mixed, now + 2 * hour)
        )
    }

    @Test
    fun noAccountsMeansNoReportsAndNoIdleAccounts() {
        assertTrue(IdleCheck.reports(emptyList(), mixed, now).isEmpty())
        assertTrue(IdleCheck.idleAccounts(emptyList(), mixed, now).isEmpty())
    }
}
