package com.voxelgame;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private GameSurfaceView surfaceView;

    // ── Render-distance HUD button ────────────────────────────────────────────
    private Button  rdButton;
    private Handler rdHandler;
    private Runnable rdPoll;

    // ── Debug overlay panel ───────────────────────────────────────────────────
    // The panel is a floating, semi-transparent monospace text view that polls
    // the native stats cache every 250 ms via nativeGetDebugStats().
    //
    // Layout z-order (FrameLayout, top = last added):
    //   GL surface → joystick → RD button → DBG button → debug panel
    //
    // The DBG button responds to:
    //   tap        → toggle debug panel (show / hide)
    //   long press → copy current stats to clipboard  (handy for bug reports)
    //                + toggle advanced mode (extra sections)
    private ScrollView  debugPanelScroll;
    private TextView    debugText;
    private Button      dbgButton;
    private Handler     debugHandler;
    private Runnable    debugPoll;
    private boolean     debugAdvanced = false;   // mirrors C++ advancedDebugVisible
    private boolean     debugVisible  = false;   // local mirror for Java layout

    // Update interval for the debug text overlay (ms)
    private static final int DEBUG_POLL_MS = 250;

    // ─────────────────────────────────────────────────────────────────────────
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN           |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION      |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY     |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN    |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        );

        FrameLayout root = new FrameLayout(this);

        // ── GL surface ────────────────────────────────────────────────────────
        surfaceView = new GameSurfaceView(this);
        root.addView(surfaceView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        // ── Joystick overlay ──────────────────────────────────────────────────
        JoystickOverlay joystick = new JoystickOverlay(this);
        root.addView(joystick, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
        surfaceView.setJoystickOverlay(joystick);

        // ── Render-distance button (top-right) ────────────────────────────────
        rdButton = makeRdButton();
        FrameLayout.LayoutParams rdParams = new FrameLayout.LayoutParams(
                dpToPx(88), dpToPx(36));
        rdParams.gravity     = Gravity.TOP | Gravity.END;
        rdParams.topMargin   = dpToPx(12);
        rdParams.rightMargin = dpToPx(12);
        root.addView(rdButton, rdParams);

        // ── DBG button (top-right, to the left of the RD button) ─────────────
        // rightMargin = rdRightMargin(12) + rdWidth(88) + gap(6) = 106 dp
        dbgButton = makeDbgButton();
        FrameLayout.LayoutParams dbgParams = new FrameLayout.LayoutParams(
                dpToPx(52), dpToPx(36));
        dbgParams.gravity     = Gravity.TOP | Gravity.END;
        dbgParams.topMargin   = dpToPx(12);
        dbgParams.rightMargin = dpToPx(106);   // sits left of RD button
        root.addView(dbgButton, dbgParams);

        // ── Debug stats panel (top-left, initially hidden) ────────────────────
        // Added LAST so it renders above all other views in the FrameLayout.
        debugPanelScroll = makeDebugPanel();
        FrameLayout.LayoutParams panelParams = new FrameLayout.LayoutParams(
                dpToPx(272), dpToPx(400));
        panelParams.gravity     = Gravity.TOP | Gravity.START;
        panelParams.topMargin   = dpToPx(12);
        panelParams.leftMargin  = dpToPx(12);
        debugPanelScroll.setVisibility(View.GONE);
        root.addView(debugPanelScroll, panelParams);

        setContentView(root);

        // ── Pollers ───────────────────────────────────────────────────────────
        rdHandler = new Handler(Looper.getMainLooper());
        rdPoll = () -> {
            refreshRdLabel();
            rdHandler.postDelayed(rdPoll, 1000);
        };

        debugHandler = new Handler(Looper.getMainLooper());
        debugPoll = () -> {
            if (debugVisible) {
                refreshDebugPanel();
            }
            debugHandler.postDelayed(debugPoll, DEBUG_POLL_MS);
        };
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────
    @Override protected void onResume() {
        super.onResume();
        surfaceView.onResume();
        rdHandler.postDelayed(rdPoll, 1000);
        debugHandler.postDelayed(debugPoll, DEBUG_POLL_MS);
    }

    @Override protected void onPause() {
        super.onPause();
        surfaceView.onPause();
        rdHandler.removeCallbacks(rdPoll);
        debugHandler.removeCallbacks(debugPoll);
    }

    // ═════════════════════════════════════════════════════════════════════════
    // RD button
    // ═════════════════════════════════════════════════════════════════════════
    private Button makeRdButton() {
        Button btn = new Button(this);
        btn.setText("RD: 7");
        btn.setTextColor(Color.WHITE);
        btn.setTextSize(12f);
        btn.setTypeface(Typeface.MONOSPACE);
        btn.setBackgroundColor(0xCC000000);
        btn.setPadding(dpToPx(8), dpToPx(4), dpToPx(8), dpToPx(4));
        btn.setOnClickListener(v -> showRdDialog());
        return btn;
    }

    private void refreshRdLabel() {
        try {
            int cur = surfaceView.nativeGetRenderDistance();
            rdButton.setText("RD: " + cur);
        } catch (Exception ignored) {}
    }

    // ── Render-distance settings dialog ──────────────────────────────────────
    private void showRdDialog() {
        final int MIN = 2, MAX = 200;
        int current;
        try { current = surfaceView.nativeGetRenderDistance(); }
        catch (Exception e) { current = 7; }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dpToPx(24), dpToPx(16), dpToPx(24), dpToPx(8));

        TextView title = new TextView(this);
        title.setText("Render Distance");
        title.setTextSize(16f);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        TextView valueLabel = new TextView(this);
        valueLabel.setTextSize(28f);
        valueLabel.setGravity(Gravity.CENTER);
        valueLabel.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        valueLabel.setText(String.valueOf(current));
        root.addView(valueLabel);

        TextView rangeHint = new TextView(this);
        rangeHint.setText("Range: " + MIN + " – " + MAX + " chunks");
        rangeHint.setTextSize(11f);
        rangeHint.setGravity(Gravity.CENTER);
        rangeHint.setTextColor(Color.GRAY);
        root.addView(rangeHint);

        SeekBar seekBar = new SeekBar(this);
        seekBar.setMax(MAX - MIN);
        seekBar.setProgress(current - MIN);
        LinearLayout.LayoutParams seekParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        seekParams.topMargin = dpToPx(12);
        root.addView(seekBar, seekParams);

        TextView perfHint = new TextView(this);
        perfHint.setTextSize(11f);
        perfHint.setGravity(Gravity.CENTER);
        perfHint.setTextColor(0xFF888888);
        perfHint.setPadding(0, dpToPx(4), 0, 0);
        updatePerfHint(perfHint, current);
        root.addView(perfHint);

        LinearLayout inputRow = new LinearLayout(this);
        inputRow.setOrientation(LinearLayout.HORIZONTAL);
        inputRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        rowParams.topMargin = dpToPx(12);
        inputRow.setLayoutParams(rowParams);

        TextView inputLabel = new TextView(this);
        inputLabel.setText("Type exact value: ");
        inputLabel.setTextSize(13f);

        EditText editText = new EditText(this);
        editText.setInputType(InputType.TYPE_CLASS_NUMBER);
        editText.setHint("2–200");
        editText.setText(String.valueOf(current));
        editText.setSelectAllOnFocus(true);
        LinearLayout.LayoutParams etParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        editText.setLayoutParams(etParams);

        inputRow.addView(inputLabel);
        inputRow.addView(editText);
        root.addView(inputRow);

        final int[] pending = {current};
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int progress, boolean fromUser) {
                int v = progress + MIN;
                pending[0] = v;
                valueLabel.setText(String.valueOf(v));
                editText.setText(String.valueOf(v));
                updatePerfHint(perfHint, v);
            }
            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) {}
        });

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(root);
        builder.setPositiveButton("Apply", (dialog, which) -> {
            String typed = editText.getText().toString().trim();
            int finalVal = pending[0];
            try {
                int parsed = Integer.parseInt(typed);
                finalVal = Math.max(MIN, Math.min(MAX, parsed));
            } catch (NumberFormatException ignored) {}

            surfaceView.nativeSetRenderDistance(finalVal);
            rdButton.setText("RD: " + finalVal);
        });
        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    private void updatePerfHint(TextView tv, int dist) {
        String hint;
        if      (dist <= 4)  hint = "⚡ Very fast — minimum detail";
        else if (dist <= 8)  hint = "✓ Balanced — recommended for most devices";
        else if (dist <= 16) hint = "◎ High quality — needs a fast device";
        else if (dist <= 32) hint = "⚠ Demanding — may cause thermal throttling";
        else                 hint = "🔥 Extreme — stress-test only";
        tv.setText(hint);
    }

    // ═════════════════════════════════════════════════════════════════════════
    // DBG button + debug panel
    // ═════════════════════════════════════════════════════════════════════════

    /**
     * Creates the small "DBG" toggle button anchored at top-right (left of RD button).
     *
     * Tap       → toggle debug panel visibility
     * Long press → copy current stats to clipboard AND toggle advanced mode
     */
    private Button makeDbgButton() {
        Button btn = new Button(this);
        btn.setText("DBG");
        btn.setTextColor(Color.WHITE);
        btn.setTextSize(11f);
        btn.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        // Semi-transparent dark background, rounded feel via padding
        btn.setBackgroundColor(0xBB0D1B2A);
        btn.setPadding(dpToPx(6), dpToPx(4), dpToPx(6), dpToPx(4));

        // Tap — toggle panel
        btn.setOnClickListener(v -> toggleDebugPanel());

        // Long press — copy to clipboard + flip advanced mode
        btn.setOnLongClickListener(v -> {
            copyStatsToClipboard();
            // Also flip advanced mode so long-press reveals more detail
            debugAdvanced = !debugAdvanced;
            try { surfaceView.nativeToggleAdvancedDebug(); }
            catch (Exception ignored) {}
            Toast.makeText(this,
                    debugAdvanced ? "Advanced stats ON — copied to clipboard"
                                  : "Advanced stats OFF — copied to clipboard",
                    Toast.LENGTH_SHORT).show();
            return true;  // consume event
        });
        return btn;
    }

    /** Toggle debug panel visibility, syncing both Java and C++ state. */
    private void toggleDebugPanel() {
        debugVisible = !debugVisible;
        try { surfaceView.nativeToggleDebug(); }
        catch (Exception ignored) {}

        if (debugVisible) {
            debugPanelScroll.setVisibility(View.VISIBLE);
            dbgButton.setBackgroundColor(0xDD1565C0);   // blue tint = active
            dbgButton.setText("DBG ●");
            refreshDebugPanel();   // immediate first refresh, don't wait for poll
        } else {
            debugPanelScroll.setVisibility(View.GONE);
            dbgButton.setBackgroundColor(0xBB0D1B2A);  // back to dark
            dbgButton.setText("DBG");
            debugAdvanced = false;   // reset advanced on close
        }
    }

    /**
     * Creates the semi-transparent debug stats panel.
     * Returns a ScrollView containing a monospace TextView.
     */
    private ScrollView makeDebugPanel() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(0xCC0D1B2A);   // dark navy, 80% opaque

        debugText = new TextView(this);
        debugText.setTypeface(Typeface.MONOSPACE);
        debugText.setTextColor(0xFFE0E0E0);
        debugText.setTextSize(10.5f);
        debugText.setLineSpacing(2f, 1f);
        debugText.setPadding(dpToPx(10), dpToPx(10), dpToPx(10), dpToPx(10));
        debugText.setText("Waiting for stats…");

        scroll.addView(debugText);
        return scroll;
    }

    /**
     * Polls nativeGetDebugStats() and updates the overlay text.
     * Called every 250 ms from debugPoll Runnable.
     * Does nothing if the panel is hidden (avoids pointless JNI calls).
     */
    private void refreshDebugPanel() {
        if (!debugVisible) return;
        try {
            String stats = surfaceView.nativeGetDebugStats();
            if (stats == null || stats.isEmpty()) return;

            // In basic mode show only RENDERING + STREAMING sections.
            // In advanced mode show everything.
            if (!debugAdvanced) {
                stats = extractBasicStats(stats);
            }

            debugText.setText(stats);
        } catch (Exception ignored) {}
    }

    /**
     * Trims the full stats string to just the first two sections
     * (RENDERING + STREAMING) for the default non-advanced view.
     * Sections are separated by blank lines in the JNI-formatted string.
     */
    private static String extractBasicStats(String full) {
        // Each section is separated by "\n\n" in the formatted output.
        // Keep up to the 3rd blank-line boundary (= 2 sections + gap).
        int count = 0;
        int pos   = 0;
        while (pos < full.length()) {
            int idx = full.indexOf("\n\n", pos);
            if (idx < 0) break;
            count++;
            if (count == 2) {
                // Return everything up to end of 2nd section
                return full.substring(0, idx).trim()
                        + "\n\n[ long-press DBG for full stats ]";
            }
            pos = idx + 2;
        }
        return full;   // fallback — return everything
    }

    /** Copies the current stats snapshot to the Android clipboard. */
    private void copyStatsToClipboard() {
        try {
            String stats = surfaceView.nativeGetDebugStats();
            if (stats == null || stats.isEmpty()) return;
            ClipboardManager cm = (ClipboardManager)
                    getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) {
                cm.setPrimaryClip(ClipData.newPlainText("VoxelGame Debug Stats", stats));
            }
        } catch (Exception ignored) {}
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    private int dpToPx(int dp) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }
}
