package dev.hexmaniac.core.table.format

/**
 * Parses HexManiac table formats such as `[name""11 hp. type.types]data.pokemon.names`.
 *
 * A format is a list of fields in square brackets followed by the number of rows. Each field is a name plus a type:
 * `.` one byte, `:` two bytes, `::` four bytes, `""N` text of N bytes, `<...>` a pointer, `|b[]source` a set of bits.
 * A suffix after an integer type refines it: `|h` hexadecimal, `|z` signed, `|t|a:|b.` packed bit slices,
 * `|s=other(0=x|1=y)` a type chosen by another field, a number or a list/table name for named values.
 *
 * [bitCount] says how many options a bit field's source (a list or table name) has, which decides how many
 * bytes the field takes; it returns null when the source is unknown, and 8 bits are assumed then.
 */
class FormatParser(private val bitCount: (String) -> Int?) {

    /** Parses a whole table definition. Throws [FormatException] when the text is not understood. */
    fun parse(format: String): TableFormat {
        val text = format.trim()
        val open = text.indexOf('[')
        val close = text.lastIndexOf(']')
        if (open == -1 || open > close) throw FormatException("Table content must be wrapped in [ ].")
        val segments = parseSegments(text.substring(open + 1, close))
        if (segments.isEmpty()) throw FormatException("Table content must not be empty.")
        val schema = Schema.layout(segments)
        if (schema.rowSize == 0) throw FormatException("Table rows must not be empty.")
        return TableFormat(schema, parseLength(text.substring(close + 1)))
    }

    /** Parses the text after the closing bracket: a number, a table name with margins, `!FF`, `/field` and so on. */
    fun parseLength(text: String): LengthSpec {
        val t = text.trim()
        if (t.isEmpty()) return LengthSpec.Auto
        if (t.all { it in '0'..'9' }) return LengthSpec.Fixed(maxOf(1, t.toIntOrNull() ?: Int.MAX_VALUE))
        if (t.startsWith("!")) return parseEndCode(t)
        if (t.startsWith("/")) {
            val field = t.substring(1)
            return if (field.isNotEmpty() && field.all(::isFieldNameChar)) LengthSpec.FromField(field) else LengthSpec.Unsupported(t)
        }
        if (t.all { isTableNameChar(it) || it == '-' || it == '+' }) return parseNamedLength(t)
        return LengthSpec.Unsupported(t)
    }

    private fun parseEndCode(t: String): LengthSpec {
        val digits = t.substring(1)
        if (digits.isEmpty() || digits.length % 2 != 0 || !digits.all { it in '0'..'9' || it in 'a'..'f' || it in 'A'..'F' }) {
            return LengthSpec.Unsupported(t)
        }
        val code = ByteArray(digits.length / 2) { digits.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
        return LengthSpec.EndCode(code)
    }

    /** `name`, `name+3` (three extra rows), `name-1` (the first row of name has no counterpart), `name+1+5`. */
    private fun parseNamedLength(t: String): LengthSpec {
        val separators = ArrayList<Int>()
        for (i in t.indices) if (t[i] == '+' || t[i] == '-') separators.add(i)
        if (separators.isEmpty()) return LengthSpec.FromName(t, 0, 0)
        separators.add(t.length)
        val margins = IntArray(separators.size - 1) { parseSigned(t.substring(separators[it], separators[it + 1])) }
        if (margins.size > 2) return LengthSpec.Unsupported(t)
        val name = t.substring(0, separators[0])
        if (name.isEmpty()) return LengthSpec.Unsupported(t)
        if (margins.size == 2) return LengthSpec.FromName(name, margins[0], margins[1])
        val margin = margins[0]
        return when {
            margin > 0 -> LengthSpec.FromName(name, 0, margin)
            margin < 0 -> LengthSpec.FromName(name, margin, 0)
            else -> LengthSpec.FromName(name, 0, 0)
        }
    }

    private fun parseSigned(text: String): Int {
        if (text.isEmpty()) return 0
        val negative = text[0] == '-'
        val digits = if (text[0] == '-' || text[0] == '+') text.substring(1) else text
        if (digits.isEmpty() || !digits.all { it in '0'..'9' }) return 0
        val value = digits.toIntOrNull() ?: return 0
        return if (negative) -value else value
    }

    internal fun parseSegments(text: String): List<Segment> {
        val list = ArrayList<Segment>()
        var rest = text.trim()
        while (rest.isNotEmpty()) {
            if (rest[0] == '[') {
                rest = parseRepeatedGroup(rest, list)
                continue
            }
            if (rest[0] == ' ') {
                rest = rest.substring(1)
                continue
            }

            var nameEnd = 0
            while (nameEnd < rest.length && isFieldNameChar(rest[nameEnd])) nameEnd++
            val name = rest.substring(0, nameEnd)
            rest = rest.substring(nameEnd)
            val token = extractToken(rest)
            if (name.isEmpty() && token.type != TokenType.SPLITTER) throw FormatException("Expected a field name before: $rest")
            if (token.type == TokenType.TEXT && token.length < 1) throw FormatException("Text must be at least 1 byte long: $name")
            if (token.type == TokenType.TEXT && token.length > MAX_TEXT) throw FormatException("Text must not be longer than $MAX_TEXT bytes: $name")

            if (token.type == TokenType.INTEGER && rest.length > token.formatLength && rest[token.formatLength] != ' ') {
                rest = rest.substring(token.formatLength)
                val end = tokenEnd(rest)
                val suffix = rest.substring(0, end)
                rest = rest.substring(end).trim()
                addSuffixed(list, name, token.length, suffix)
            } else if (token.type == TokenType.POINTER && token.formatLength > 2) {
                val spec = PointerSpec(rest.substring(1, token.formatLength - 1), this)
                list.add(Segment(POINTER_SIZE, listOf(Field(name, FieldKind.POINTER, POINTER_SIZE, pointer = spec))))
                rest = rest.substring(token.formatLength).trim()
            } else if (token.type == TokenType.BIT_ARRAY) {
                val source = rest.substring(BIT_ARRAY_TOKEN.length, token.formatLength)
                rest = rest.substring(token.formatLength).trim()
                list.add(Segment(token.length, listOf(Field(name, FieldKind.BITS, token.length, bitSource = source))))
            } else if (token.type == TokenType.SPLITTER) {
                rest = rest.substring(token.formatLength).trim()
            } else {
                rest = rest.substring(token.formatLength).trim()
                addPlain(list, name, token)
            }
        }
        return list
    }

    /** `[fields]N`: adds the inner fields N times. Returns the text after the group. */
    private fun parseRepeatedGroup(text: String, into: MutableList<Segment>): String {
        val close = matchingBracket(text)
        if (close == -1) throw FormatException("Found unmatched open bracket ([).")
        val inner = parseSegments(text.substring(1, close))
        val rest = text.substring(close + 1)
        val end = tokenEnd(rest)
        val count = rest.substring(0, end).toIntOrNull() ?: throw FormatException("Could not parse '$rest' as a number.")
        if (count < 0 || count > MAX_REPEAT) throw FormatException("Cannot repeat a group $count times.")
        for (k in 1..count) {
            for (segment in inner) into.add(if (count == 1) segment else segment.repeated(k))
        }
        return rest.substring(end)
    }

    private fun addPlain(list: MutableList<Segment>, name: String, token: Token) {
        when (token.type) {
            TokenType.TEXT -> list.add(Segment(token.length, listOf(Field(name, FieldKind.TEXT, token.length))))
            TokenType.POINTER ->
                list.add(Segment(POINTER_SIZE, listOf(Field(name, FieldKind.POINTER, POINTER_SIZE, pointer = PointerSpec("", this)))))
            TokenType.INTEGER ->
                if (token.length > 0) list.add(Segment(token.length, listOf(Field(name, FieldKind.NUMBER, token.length))))
            else -> list.add(Segment(1, listOf(Field(name, FieldKind.NUMBER, 1))))
        }
    }

    /** Handles what follows an integer type without a space: `|h`, `|z`, `|t...`, `|s=...`, an enum name or a count. */
    private fun addSuffixed(list: MutableList<Segment>, name: String, size: Int, suffix: String) {
        when {
            suffix.startsWith("|h") -> list.add(single(Field(name, FieldKind.HEX, size)))
            suffix.startsWith("|z") -> list.add(single(Field(name, FieldKind.SIGNED, size)))
            suffix.startsWith("|t") -> list.add(tuple(name, size, suffix.substring(2)))
            // Computed values, comments, buttons and pictures take no space in the row.
            suffix.startsWith("|comment=") || suffix.startsWith("|=") ||
                suffix.startsWith("|python=") || suffix.startsWith("|render=") -> Unit
            suffix.startsWith("|c") -> list.add(Segment(COLOR_SIZE, listOf(Field(name, FieldKind.COLOR, COLOR_SIZE))))
            suffix.startsWith("|s=") -> list.add(record(name, size, suffix))
            else -> list.add(single(enumField(name, size, suffix)))
        }
    }

    private fun single(field: Field) = Segment(field.size, listOf(field))

    private fun enumField(name: String, size: Int, enumText: String): Field {
        val parts = enumText.split('+')
        if (parts.size == 2) {
            val offset = parts[1].toIntOrNull()
            if (offset != null) return Field(name, FieldKind.NUMBER, size, enumName = parts[0], enumOffset = offset)
        }
        return Field(name, FieldKind.NUMBER, size, enumName = enumText)
    }

    /** `name:|t|a:|b.|c::e`: bit slices of one integer, low bits first; `.` is one bit, `:` two, then an enum name. */
    private fun tuple(name: String, size: Int, contract: String): Segment {
        val fields = ArrayList<Field>()
        var bitOffset = 0
        for (part in contract.split('|')) {
            if (part.isEmpty()) continue
            val elementName = part.takeWhile { it != '.' && it != ':' }
            val enumName = part.split('.', ':').filter { it.isNotEmpty() }.drop(1).joinToString(".")
            val format = part.substring(elementName.length, part.length - enumName.length)
            var width = 0
            for (c in format) width += if (c == '.') 1 else if (c == ':') 2 else 0
            if (width == 0) throw FormatException("$elementName: tuple element needs a length.")
            if (elementName.isNotEmpty()) {
                val kind = if (width == 1 && enumName.isEmpty()) FieldKind.FLAG else FieldKind.NUMBER
                fields.add(
                    Field(
                        elementName, kind, size, shift = bitOffset, width = width, group = name,
                        enumName = enumName.ifEmpty { null },
                    ),
                )
            }
            bitOffset += width
        }
        if (bitOffset > size * 8) throw FormatException("$name: tuple is too long for its field.")
        return Segment(size, fields)
    }

    /** `|s=field(0=enum|1=<>|...)` */
    private fun record(name: String, size: Int, contract: String): Segment {
        if (contract.count { it == '(' } != 1 || contract.count { it == ')' } != 1) {
            throw FormatException("Record format is s=name(number=enum|...).")
        }
        val body = contract.substring(3)
        val matchField = body.substringBefore('(')
        if (matchField.isEmpty()) throw FormatException("Record format is s=name(number=enum|...).")
        val cases = LinkedHashMap<Int, String>()
        for (pair in body.substring(matchField.length + 1).replace(")", "").split('|')) {
            val keyAndValue = pair.split('=')
            if (keyAndValue.size != 2) continue
            val key = keyAndValue[0].toIntOrNull() ?: continue
            cases[key] = keyAndValue[1]
        }
        return single(Field(name, FieldKind.RECORD, size, record = RecordSpec(matchField, cases)))
    }

    private enum class TokenType { UNKNOWN, INTEGER, TEXT, POINTER, BIT_ARRAY, SPLITTER }

    private class Token(val type: TokenType, val formatLength: Int, val length: Int)

    /** Identifies the type token at the start of [s]: how many characters it takes and how many bytes it stands for. */
    private fun extractToken(s: String): Token {
        if (s.startsWith("\"\"")) {
            var end = 2
            while (end < s.length && s[end] in '0'..'9') end++
            val length = s.substring(2, end).toIntOrNull() ?: return UNKNOWN_TOKEN
            return Token(TokenType.TEXT, end, length)
        }
        if (s.startsWith("|=") || s.startsWith("|render=") || s.startsWith("|comment=") || s.startsWith("|python=")) {
            return Token(TokenType.INTEGER, 0, 0)
        }
        if (s.startsWith("::")) return Token(TokenType.INTEGER, 2, 4)
        if (s.startsWith(":.") || s.startsWith(".:")) return Token(TokenType.INTEGER, 2, 3)
        if (s.startsWith(":")) return Token(TokenType.INTEGER, 1, 2)
        if (s.startsWith(".")) return Token(TokenType.INTEGER, 1, 1)
        if (s.startsWith("<")) {
            var open = 1
            var end = 1
            while (open > 0 && end < s.length) {
                if (s[end] == '<') open++ else if (s[end] == '>') open--
                end++
            }
            return if (open > 0) UNKNOWN_TOKEN else Token(TokenType.POINTER, end, POINTER_SIZE)
        }
        if (s.startsWith(BIT_ARRAY_TOKEN)) {
            var end = BIT_ARRAY_TOKEN.length
            while (end < s.length && isTableNameChar(s[end])) end++
            val bits = bitCount(s.substring(BIT_ARRAY_TOKEN.length, end)) ?: DEFAULT_BITS
            return Token(TokenType.BIT_ARRAY, end, maxOf(1, (bits + 7) / 8))
        }
        if (s.startsWith("| ")) return Token(TokenType.SPLITTER, 1, 0)
        return UNKNOWN_TOKEN
    }

    private fun matchingBracket(s: String): Int {
        var depth = 0
        for (i in s.indices) {
            if (s[i] == '[') {
                depth++
            } else if (s[i] == ']') {
                depth--
                if (depth == 0) return i
            }
        }
        return -1
    }

    private fun tokenEnd(s: String): Int {
        val space = s.indexOf(' ')
        return if (space == -1) s.length else space
    }

    private companion object {
        const val POINTER_SIZE = 4
        const val COLOR_SIZE = 2
        const val MAX_TEXT = 1000
        const val MAX_REPEAT = 4096
        const val DEFAULT_BITS = 8
        const val BIT_ARRAY_TOKEN = "|b[]"
        val UNKNOWN_TOKEN = Token(TokenType.UNKNOWN, 0, 0)

        fun isFieldNameChar(c: Char) = c.isLetterOrDigit() || c == '_'
        fun isTableNameChar(c: Char) = c.isLetterOrDigit() || c == '_' || c == '.'
    }
}
