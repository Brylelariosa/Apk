package dev.hexmaniac.core.table.format

/** The layout of one table row. */
class Schema(val fields: List<Field>, val rowSize: Int) {
    private val byName: Map<String, Int> = HashMap<String, Int>().also { map ->
        fields.forEachIndexed { index, field -> if (field.group == null) map.putIfAbsent(field.name, index) }
    }

    /** The whole (non-tuple) field called [name], or null. */
    fun field(name: String): Field? = byName[name]?.let { fields[it] }

    /**
     * The field a record field at [index] looks at: the closest field before it that is called [name],
     * or the first one with that name when none comes earlier.
     */
    fun siblingFor(index: Int, name: String): Field? {
        for (i in index - 1 downTo 0) {
            val field = fields[i]
            if (field.group == null && field.name == name) return field
        }
        return field(name)
    }

    companion object {
        /** Places [segments] one after the other; every field of a segment starts at the segment's offset. */
        internal fun layout(segments: List<Segment>): Schema {
            val placed = ArrayList<Field>()
            var offset = 0
            for (segment in segments) {
                for (field in segment.fields) placed.add(field.placedAt(offset))
                offset += segment.size
            }
            return Schema(placed, offset)
        }
    }
}

/** The bytes one parsed piece of a format occupies and the fields that are shown for them. */
internal class Segment(val size: Int, val fields: List<Field>) {
    fun repeated(index: Int) = Segment(size, fields.map { it.repeated(index) })
}

/** How many rows a table has. */
sealed class LengthSpec {
    /** Not stated: rows are counted while the data keeps matching the format. */
    object Auto : LengthSpec()

    class Fixed(val count: Int) : LengthSpec()

    /**
     * The row count of the table, list or constant called [name], plus [begin] and [end] extra rows
     * (a negative [begin] means the first rows of the named table have no counterpart here).
     */
    class FromName(val name: String, val begin: Int, val end: Int) : LengthSpec()

    /** Rows continue until a row starts with [code]. */
    class EndCode(val code: ByteArray) : LengthSpec()

    /** Nested tables only: the count is the value of [field] in the row that holds the pointer. */
    class FromField(val field: String) : LengthSpec()

    /** A form this app cannot evaluate. */
    class Unsupported(val text: String) : LengthSpec()
}

/** A parsed table definition: the row layout and the way its length is determined. */
class TableFormat(val schema: Schema, val length: LengthSpec)

class FormatException(message: String) : Exception(message)
