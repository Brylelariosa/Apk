package dev.hexmaniac.core.rom

/** Pointers found by [PointerSearch]: where each one is stored and where it leads, both as file offsets. */
class PointerHits internal constructor(
    /** File offsets of the pointers, lowest first. */
    val sources: IntArray,
    /** The file offset each pointer leads to, in the order of [sources]. */
    val targets: IntArray,
) {
    val size: Int get() = sources.size
}

/**
 * Finds pointers by looking at the bytes. HexManiac discovers pointers in data without a table definition the same
 * way: a 4-byte aligned word whose top byte is 08 or 09 and whose address lies inside the image. Pointers that are not
 * word aligned (script commands, mostly) are not found, and neither are pointers kept in another form.
 */
object PointerSearch {
    private const val BASE = 0x08000000L

    /** Every pointer that leads to a file offset from [start] up to, but not including, [end]. */
    fun leadingTo(rom: RomData, start: Int, end: Int): PointerHits {
        val bytes = rom.bytes
        val low = BASE + start.coerceAtLeast(0)
        val high = BASE + end.coerceAtLeast(0)
        var sources = IntArray(INITIAL_CAPACITY)
        var targets = IntArray(INITIAL_CAPACITY)
        var count = 0
        var i = 0
        val last = bytes.size - 4
        while (i <= last) {
            val top = bytes[i + 3].toInt()
            if (top == 0x08 || top == 0x09) {
                val word = ((bytes[i].toInt() and 0xFF) or ((bytes[i + 1].toInt() and 0xFF) shl 8) or
                    ((bytes[i + 2].toInt() and 0xFF) shl 16) or (top shl 24)).toLong()
                if (word >= low && word < high) {
                    if (count == sources.size) {
                        sources = sources.copyOf(count * 2)
                        targets = targets.copyOf(count * 2)
                    }
                    sources[count] = i
                    targets[count] = (word - BASE).toInt()
                    count++
                }
            }
            i += 4
        }
        return PointerHits(sources.copyOf(count), targets.copyOf(count))
    }

    private const val INITIAL_CAPACITY = 16
}
