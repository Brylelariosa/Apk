package dev.hexmaniac.core.graphics

/** GBA colours: 15 bits in two bytes (little endian), 5 bits per channel, red in the lowest bits. */
internal object Palettes {
    /** The colour [value] as 0xAARRGGBB with full opacity. */
    fun argb(value: Int): Int {
        val red = scale(value and 31)
        val green = scale((value shr 5) and 31)
        val blue = scale((value shr 10) and 31)
        return (0xFF shl 24) or (red shl 16) or (green shl 8) or blue
    }

    /** [count] colours that start at [offset]; colours beyond the end of [data] are black. */
    fun read(data: ByteArray, offset: Int, count: Int): IntArray = IntArray(count) { i ->
        val at = offset.toLong() + 2L * i
        if (at < 0 || at + 2 > data.size) {
            BLACK
        } else {
            argb((data[at.toInt()].toInt() and 0xFF) or ((data[at.toInt() + 1].toInt() and 0xFF) shl 8))
        }
    }

    /** [count] shades of grey from black to white, for pictures that have no palette. */
    fun grey(count: Int): IntArray = IntArray(count) { i ->
        val level = if (count <= 1) 0 else i * 255 / (count - 1)
        (0xFF shl 24) or (level shl 16) or (level shl 8) or level
    }

    const val BLACK = 0xFF shl 24

    private fun scale(channel: Int) = channel * 255 / 31
}
