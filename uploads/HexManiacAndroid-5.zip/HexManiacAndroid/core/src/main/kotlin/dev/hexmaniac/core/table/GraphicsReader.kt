package dev.hexmaniac.core.table

import dev.hexmaniac.core.graphics.GraphicSpec
import dev.hexmaniac.core.graphics.Lz77
import dev.hexmaniac.core.graphics.Palettes
import dev.hexmaniac.core.graphics.Picture
import dev.hexmaniac.core.graphics.Tiles
import dev.hexmaniac.core.rom.RomData
import dev.hexmaniac.core.table.format.Field
import dev.hexmaniac.core.table.format.FieldKind
import dev.hexmaniac.core.table.format.PointerKind

/** What a pointer to a sprite, tileset or palette looks like: a picture to show with a few words about it. */
class Graphic(
    val picture: Picture,
    /** Name of the palette that paints a sprite ("normal", "shiny"), or null when there is none to name. */
    val palette: String?,
    /** How many palettes the sprite can be painted with; 0 when it cannot be painted with a palette of the game. */
    val choices: Int,
    /** Which of them [picture] is painted with. */
    val choice: Int,
)

/**
 * Draws the pictures that table rows point to. Sprites are painted with a palette that the game keeps in one of the
 * places HexManiac looks in: the palette named by the sprite's format, the row with the same number of the table that
 * format names, or (when it names nothing) the palettes that sit in the same row of this or a related table.
 */
internal class GraphicsReader(private val rom: RomData, private val catalog: TableCatalog) {

    /** Data to read from: [bytes] from [start] on. Compressed data is a copy that starts at 0. */
    private class Source(val bytes: ByteArray, val start: Int)

    private class PaletteRef(val name: String, val spec: GraphicSpec.Palette, val offset: Int)

    fun graphic(table: TableLocation, row: Int, index: Int, choice: Int): Graphic? {
        if (row < 0 || row >= table.rowCount || index < 0 || index >= table.schema.fields.size) return null
        val field = catalog.concreteField(table, row, index)
        if (field.kind != FieldKind.POINTER) return null
        val pointer = field.pointer ?: return null
        if (pointer.kind != PointerKind.SPECIAL) return null
        val spec = GraphicSpec.parse(pointer.inner) ?: return null
        val target = rom.pointerTarget(table.rowStart(row) + field.offset)
        if (target < 0) return null
        return when (spec) {
            is GraphicSpec.Sprite -> sprite(table, row, spec, target, choice)
            is GraphicSpec.Tileset -> tileset(table, row, spec, target, choice)
            is GraphicSpec.Palette -> palette(spec, target)
        }
    }

    // ---- drawing ----

    private fun source(compressed: Boolean, target: Int): Source? {
        if (!compressed) return Source(rom.bytes, target)
        val bytes = Lz77.decompress(rom.bytes, target) ?: return null
        return Source(bytes, 0)
    }

    private fun sprite(table: TableLocation, row: Int, spec: GraphicSpec.Sprite, target: Int, choice: Int): Graphic? {
        val source = source(spec.compressed, target) ?: return null
        val indexes = Tiles.indexes(source.bytes, source.start, spec.bits, spec.tilesWide, spec.tilesHigh)
        return painted(indexes, spec.tilesWide * 8, spec.tilesHigh * 8, spec.bits, spec.paletteHint, table, row, choice)
    }

    /** Tiles are laid out 16 to a row, as many as the data holds (or the format says), but never more than [MAX_TILES]. */
    private fun tileset(table: TableLocation, row: Int, spec: GraphicSpec.Tileset, target: Int, choice: Int): Graphic? {
        val source = source(spec.compressed, target) ?: return null
        val held = if (spec.compressed) source.bytes.size / Tiles.bytesPerTile(spec.bits) else Int.MAX_VALUE
        val tiles = minOf(if (spec.tiles > 0) spec.tiles else held, MAX_TILES)
        if (tiles < 1) return null
        val wide = minOf(TILES_PER_ROW, tiles)
        val high = (tiles + wide - 1) / wide
        val indexes = Tiles.indexes(source.bytes, source.start, spec.bits, wide, high)
        return painted(indexes, wide * 8, high * 8, spec.bits, spec.paletteHint, table, row, choice)
    }

    private fun painted(
        indexes: IntArray,
        width: Int,
        height: Int,
        bits: Int,
        hint: String?,
        table: TableLocation,
        row: Int,
        choice: Int,
    ): Graphic {
        val grey = Palettes.grey(1 shl bits)
        val palettes = if (bits >= 4) palettesFor(table, row, hint) else emptyList()
        if (palettes.isEmpty()) return Graphic(Picture.painted(indexes, width, height, grey), null, 0, 0)
        val chosen = ((choice % palettes.size) + palettes.size) % palettes.size
        val ref = palettes[chosen]
        val colors = colorsOf(ref) ?: grey
        return Graphic(Picture.painted(indexes, width, height, colors), ref.name, palettes.size, chosen)
    }

    /** All the pages of a palette as a grid of colours, 16 to a row. */
    private fun palette(spec: GraphicSpec.Palette, target: Int): Graphic? {
        val source = source(spec.compressed, target) ?: return null
        val perPage = 1 shl spec.bits
        val limit = 256 / perPage
        val pages = if (spec.compressed) (source.bytes.size / (perPage * 2)).coerceIn(1, limit) else spec.pages.coerceIn(1, limit)
        val colors = Palettes.read(source.bytes, source.start, perPage * pages)
        return Graphic(Picture.swatches(colors, SWATCHES_PER_ROW), null, 0, 0)
    }

    /** The first page of the palette. */
    private fun colorsOf(ref: PaletteRef): IntArray? {
        val source = source(ref.spec.compressed, ref.offset) ?: return null
        return Palettes.read(source.bytes, source.start, 1 shl ref.spec.bits)
    }

    // ---- finding the palette ----

    private fun palettesFor(table: TableLocation, row: Int, hint: String?): List<PaletteRef> {
        val found = LinkedHashMap<Int, PaletteRef>()
        val candidates = ArrayList<PaletteRef>()
        if (!hint.isNullOrEmpty()) {
            candidates.addAll(hinted(row, hint))
        } else {
            for (related in catalog.related(table)) {
                if (row < related.rowCount) candidates.addAll(palettesIn(related, row, own = false))
            }
            candidates.addAll(palettesIn(table, row, own = true))
        }
        for (ref in candidates) found.putIfAbsent(ref.offset, ref)
        return found.values.toList()
    }

    /** The palettes a format's hint leads to; [row] is the row of the sprite in its own table. */
    private fun hinted(row: Int, hint: String): List<PaletteRef> {
        val name = hint.substringBefore(':')
        val key = if (hint.contains(':')) hint.substringAfter(':') else ""

        val single = catalog.standalone(name)
        if (single != null) {
            val spec = GraphicSpec.parse(single.second) as? GraphicSpec.Palette
            if (spec != null && single.first >= 0 && single.first < rom.size) return listOf(PaletteRef(shortName(name), spec, single.first))
        }

        val hintedTable = catalog.location(name) ?: return emptyList()
        val result = ArrayList<PaletteRef>()
        result.addAll(chosenByNumber(hintedTable, row))
        if (key.contains('=')) result.addAll(chosenByKey(hintedTable, key))
        if (row >= 0 && row < hintedTable.rowCount) result.addAll(palettesIn(hintedTable, row, own = false))
        return result
    }

    /** A table with one number per row that picks a row of a table of palettes, as the icons of the Pokemon do. */
    private fun chosenByNumber(hinted: TableLocation, row: Int): List<PaletteRef> {
        val fields = hinted.schema.fields
        if (fields.size != 1 || row < 0 || row >= hinted.rowCount) return emptyList()
        val field = fields[0]
        val enumName = field.enumName ?: return emptyList()
        if (field.kind != FieldKind.NUMBER || enumName.toIntOrNull() != null) return emptyList()
        val palettes = catalog.location(enumName) ?: return emptyList()
        val number = Values.fieldValue(rom, hinted.rowStart(row), field)
        if (number < 0 || number >= palettes.rowCount) return emptyList()
        return palettesIn(palettes, number.toInt(), own = false).take(1)
    }

    /** A hint such as `id=1100`: the row of the table whose value of the field `id` is 1100. */
    private fun chosenByKey(hinted: TableLocation, key: String): List<PaletteRef> {
        val field = hinted.schema.field(key.substringBefore('=')) ?: return emptyList()
        val wanted = keyValue(field, key.substringAfter('=')) ?: return emptyList()
        for (row in 0 until hinted.rowCount) {
            if (Values.fieldValue(rom, hinted.rowStart(row), field) == wanted) return palettesIn(hinted, row, own = false).take(1)
        }
        return emptyList()
    }

    /** The stored value a hint means: hexadecimal for hexadecimal fields, the position of a name, or a decimal number. */
    private fun keyValue(field: Field, text: String): Long? {
        if (text.isEmpty()) return null
        val enumName = field.enumName
        return when {
            field.kind == FieldKind.HEX -> text.toLongOrNull(16)
            enumName != null && enumName.toIntOrNull() == null -> {
                val position = catalog.options(enumName).indexOf(text)
                if (position < 0) null else position.toLong() + field.enumOffset
            }
            else -> text.toLongOrNull()
        }
    }

    /** The palettes that the pointers of row [row] of [table] lead to. */
    private fun palettesIn(table: TableLocation, row: Int, own: Boolean): List<PaletteRef> {
        val result = ArrayList<PaletteRef>()
        for (index in table.schema.fields.indices) {
            val field = catalog.concreteField(table, row, index)
            if (field.kind != FieldKind.POINTER) continue
            val pointer = field.pointer ?: continue
            if (pointer.kind != PointerKind.SPECIAL) continue
            val spec = GraphicSpec.parse(pointer.inner) as? GraphicSpec.Palette ?: continue
            val target = rom.pointerTarget(table.rowStart(row) + field.offset)
            if (target < 0) continue
            result.add(PaletteRef(if (own) field.name else shortName(table.name), spec, target))
        }
        return result
    }

    /** "normal" for "graphics.pokemon.palettes.normal". */
    private fun shortName(name: String): String = name.substringAfterLast('.')

    private companion object {
        const val TILES_PER_ROW = 16
        const val MAX_TILES = 1024
        const val SWATCHES_PER_ROW = 16
    }
}
