package dev.hexmaniac.core.table

/**
 * The matching rule of the search boxes on the table screens: every word the person typed must occur somewhere in
 * the text, in any order and ignoring case. An empty query matches everything.
 */
class TextFilter(query: String) {
    private val words: List<String> = query.lowercase().split(' ', '\t', '\n').filter { it.isNotEmpty() }

    /** True when there is nothing to filter by. */
    val isEmpty: Boolean get() = words.isEmpty()

    fun matches(text: String): Boolean {
        if (words.isEmpty()) return true
        val lower = text.lowercase()
        for (word in words) if (!lower.contains(word)) return false
        return true
    }

    /** The positions of the [items] whose text matches, in order. */
    fun <T> select(items: List<T>, text: (T) -> String): IntArray {
        val kept = ArrayList<Int>()
        for (i in items.indices) if (matches(text(items[i]))) kept.add(i)
        return kept.toIntArray()
    }
}
