package dev.hexmaniac.core.table

import dev.hexmaniac.core.table.format.Schema
import dev.hexmaniac.core.table.format.TableFormat

/** One step into a nested table: the pointer field [fieldIndex] of row [row]. */
data class PathStep(val row: Int, val fieldIndex: Int)

/**
 * Names a table independently of where it currently is in the ROM: a table of the reference data, optionally followed
 * by steps into the tables its rows point to. Screens keep paths and look the table up again after every edit.
 */
data class TablePath(val root: String, val steps: List<PathStep> = emptyList()) {
    val depth: Int get() = steps.size

    fun child(row: Int, fieldIndex: Int) = TablePath(root, steps + PathStep(row, fieldIndex))

    /** The path one level up; the root path has no parent. */
    fun parent(): TablePath? = if (steps.isEmpty()) null else TablePath(root, steps.dropLast(1))
}

/** A table found in the ROM: where it starts, what its rows look like and how many there are. */
class TableLocation internal constructor(
    val path: TablePath,
    /** File offset of the first row. */
    val start: Int,
    val format: TableFormat,
    val rowCount: Int,
    /** Bytes after the last row that mark the end of the table (an end code), 0 for most tables. */
    val trailingBytes: Int,
    /** Names of the rows: row r is called `labels[r - labelBegin]` when that index exists. */
    internal val labels: List<String?>,
    internal val labelBegin: Int,
) {
    val schema: Schema get() = format.schema
    val rowSize: Int get() = schema.rowSize

    /** Name of the root table, e.g. "data.pokemon.stats". */
    val name: String get() = path.root

    val byteLength: Int get() = rowCount * rowSize + trailingBytes
    val end: Int get() = start + byteLength

    fun rowStart(row: Int): Int = start + row * rowSize
}

/** A table for the table list. */
class TableEntry(
    val name: String,
    val rowCount: Int,
    val rowSize: Int,
    val start: Int,
)

/** Tables shown under one heading of the table list. */
class TableSection(val title: String, val tables: List<TableEntry>)
