package dev.hexmaniac.core.graphics

/** A picture of [width] by [height] pixels: one 0xAARRGGBB value per pixel, row after row. */
class Picture(val width: Int, val height: Int, val pixels: IntArray) {
    init {
        require(width > 0 && height > 0) { "A picture needs a size" }
        require(pixels.size == width * height) { "Expected ${width * height} pixels, got ${pixels.size}" }
    }

    companion object {
        /** The picture whose pixels are the [palette] colours chosen by [indexes]; indexes outside the palette are black. */
        internal fun painted(indexes: IntArray, width: Int, height: Int, palette: IntArray): Picture {
            val pixels = IntArray(indexes.size) { i ->
                val index = indexes[i]
                if (index >= 0 && index < palette.size) palette[index] else Palettes.BLACK
            }
            return Picture(width, height, pixels)
        }

        /** A palette as a grid of [columns] colours per row; the last row is filled up with black. */
        internal fun swatches(colors: IntArray, columns: Int): Picture {
            val rows = (colors.size + columns - 1) / columns
            val pixels = IntArray(columns * rows) { i -> if (i < colors.size) colors[i] else Palettes.BLACK }
            return Picture(columns, rows, pixels)
        }
    }
}
