package dev.hexmaniac.core.rom

/**
 * Room for new data. Free space in a GBA ROM is a run of 0xFF bytes (what an erased cartridge reads as). It is almost
 * always the end of the image, after the last of the game's data; HexManiac looks for it the same way and grows the
 * image when it is full.
 */
object FreeSpace {
    /** Bytes kept untouched between existing data and whatever is placed next to it. */
    const val GAP = 0x40

    /** The most a cartridge can hold: the ROM window of the address space, 0x08000000 to 0x09FFFFFF. */
    const val MAX_ROM_SIZE = 0x2000000

    /** The earliest offset new data may go to (the header and the start-up code come before it). */
    private const val SEARCH_START = 0x200

    /** A grown image is rounded up to a multiple of this. */
    private const val GROWTH_STEP = 0x1000

    private const val FREE = 0xFF.toByte()

    /** A place for new data: [offset] is where it starts and [romSize] the size the image must have to hold it. */
    class Spot(val offset: Int, val romSize: Int)

    /** The offset just past the last byte of [rom] that is not 0xFF: where the free space at the end begins. */
    fun tailStart(rom: RomData): Int {
        val bytes = rom.bytes
        var end = bytes.size
        while (end > 0 && bytes[end - 1] == FREE) end--
        return end
    }

    /**
     * Where [length] bytes can go, or null when there is no room and the image cannot grow. The end of the image comes
     * first; when it is too small the image grows, up to [MAX_ROM_SIZE]; only a ROM that cannot grow any more has its
     * free runs further in searched. Nothing is changed: a [Spot] with a larger [Spot.romSize] than the image has
     * means the caller grows it (filling the new bytes with 0xFF) before writing.
     */
    fun find(rom: RomData, length: Int, gap: Int = GAP): Spot? {
        require(length > 0) { "Nothing to place" }
        val size = rom.size
        val start = alignUp(maxOf(tailStart(rom), SEARCH_START) + gap)
        if (start.toLong() + length <= size) return Spot(start, size)
        if (start.toLong() + length <= MAX_ROM_SIZE) {
            val grown = roundUp(start + length, GROWTH_STEP).coerceAtMost(MAX_ROM_SIZE)
            return Spot(start, maxOf(grown, size))
        }
        return findInside(rom, length, gap)
    }

    /** The first run of free bytes with [gap] bytes to spare on both sides of [length] bytes. */
    private fun findInside(rom: RomData, length: Int, gap: Int): Spot? {
        val bytes = rom.bytes
        var at = SEARCH_START
        while (at < bytes.size) {
            if (bytes[at] != FREE) {
                at++
                continue
            }
            var end = at
            while (end < bytes.size && bytes[end] == FREE) end++
            val start = alignUp(at + gap)
            if (start.toLong() + length + gap <= end) return Spot(start, bytes.size)
            at = end
        }
        return null
    }

    private fun alignUp(value: Int): Int = (value + 3) and 3.inv()

    private fun roundUp(value: Int, step: Int): Int = ((value.toLong() + step - 1) / step * step).coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
}
