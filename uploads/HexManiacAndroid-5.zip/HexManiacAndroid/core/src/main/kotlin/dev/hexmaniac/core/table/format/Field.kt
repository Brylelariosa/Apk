package dev.hexmaniac.core.table.format

/** How the bytes of one field are read, shown and edited. */
enum class FieldKind {
    /** Unsigned integer; with [Field.enumName] set its values are shown as option names. */
    NUMBER,

    /** Two's complement integer. */
    SIGNED,

    /** Unsigned integer shown in hexadecimal. */
    HEX,

    /** One bit of a packed integer, shown as on or off. */
    FLAG,

    /** Fixed width text in the Pokemon character set, ended by 0xFF. */
    TEXT,

    /** Four byte pointer; see [Field.pointer] for what it points at. */
    POINTER,

    /** A set of flags, one bit per option of a list or table. */
    BITS,

    /** Integer whose meaning depends on the value of a sibling field; see [Field.record]. */
    RECORD,

    /** 15 bit GBA colour. */
    COLOR,
}

/** What a pointer field points at, taken from the text between its angle brackets. */
enum class PointerKind { PLAIN, TEXT, TABLE, SPECIAL }

/**
 * The inner format of a pointer field ("" for a plain pointer, `""` for text, `[...]n` for a table, a backtick
 * format such as `lzs4` for sprites, palettes and scripts). The nested table is parsed on first use.
 */
class PointerSpec internal constructor(val inner: String, private val parser: FormatParser) {
    val kind: PointerKind = when {
        inner.isEmpty() -> PointerKind.PLAIN
        inner == "\"\"" -> PointerKind.TEXT
        inner.startsWith("[") -> PointerKind.TABLE
        inner.startsWith("`") -> PointerKind.SPECIAL
        else -> PointerKind.PLAIN
    }

    /** Short name of special data such as "lzs4" or "xse"; null for the other kinds. */
    val special: String? =
        if (kind == PointerKind.SPECIAL) inner.substring(1).takeWhile { it.isLetterOrDigit() } else null

    /** The table the pointer leads to, or null when this is not a table pointer or its format cannot be parsed. */
    val table: TableFormat? by lazy {
        if (kind != PointerKind.TABLE) null else try {
            parser.parse(inner)
        } catch (e: FormatException) {
            null
        }
    }
}

/** A field whose type is chosen by the value of [matchField]: value -> enum name, or `<...>` for a pointer. */
class RecordSpec(val matchField: String, val cases: Map<Int, String>)

/**
 * One value inside a table row.
 *
 * [offset] and [size] locate the integer holding the value; a field that is only a slice of a packed integer
 * (a tuple element) has [shift] and [width] set, other fields cover all of their bytes.
 */
data class Field(
    val name: String,
    val kind: FieldKind,
    val size: Int,
    val offset: Int = 0,
    val shift: Int = 0,
    val width: Int = size * 8,
    /** For tuple elements, the name of the packed field that holds them. */
    val group: String? = null,
    /** Name of the list or table that names this field's values. */
    val enumName: String? = null,
    /** Added to the option index to get the stored value. */
    val enumOffset: Int = 0,
    val pointer: PointerSpec? = null,
    val record: RecordSpec? = null,
    /** For [FieldKind.BITS], the list or table naming each bit. */
    val bitSource: String? = null,
) {
    /** Name shown to the user: "group.name" for tuple elements. */
    val label: String get() = if (group == null) name else "$group.$name"

    /** True when this field is only some bits of a larger integer. */
    val isSlice: Boolean get() = width < size * 8

    internal fun placedAt(rowOffset: Int): Field = copy(offset = rowOffset)

    internal fun repeated(index: Int): Field {
        val suffix = " #$index"
        return copy(
            name = if (group == null) name + suffix else name,
            group = group?.plus(suffix),
            record = record?.let { RecordSpec(it.matchField + suffix, it.cases) },
        )
    }
}
