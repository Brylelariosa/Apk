package dev.hexmaniac.core.table.data

/** A table the metadata places at a fixed address. */
class NamedAnchor(val name: String, val address: Int, val format: String)

/** A named list of values such as move effects or egg groups; places without a name are null. */
class NamedList(val name: String, val items: List<String?>)

/** Tables shown under one heading; entries are table names. */
class TableGroup(val name: String, val tables: List<String>)

/** The parts of a `default*.toml` file this app uses. */
class GameMetadata(
    val anchors: List<NamedAnchor> = emptyList(),
    val lists: List<NamedList> = emptyList(),
    val groups: List<TableGroup> = emptyList(),
) {
    /** This metadata with [other] applied on top: items of [other] replace items of the same name. */
    fun merge(other: GameMetadata): GameMetadata = GameMetadata(
        replaceByName(anchors, other.anchors) { it.name },
        replaceByName(lists, other.lists) { it.name },
        replaceByName(groups, other.groups) { it.name },
    )

    private fun <T> replaceByName(base: List<T>, extra: List<T>, name: (T) -> String): List<T> {
        if (extra.isEmpty()) return base
        val merged = LinkedHashMap<String, T>()
        for (item in base) merged[name(item)] = item
        for (item in extra) merged[name(item)] = item
        return merged.values.toList()
    }
}

/**
 * Reads the small subset of TOML that HexManiac's metadata files use: `[[Section]]` headers, `key = '''text'''`,
 * `key = number` and `key = [ '''a''', '''b''' ]` (possibly over several lines), with `#` comments.
 * Sections other than NamedAnchors, List and TableGroup are skipped.
 */
object MetadataParser {
    fun parse(text: String): GameMetadata {
        val anchors = ArrayList<NamedAnchor>()
        val lists = ArrayList<NamedList>()
        val groups = ArrayList<TableGroup>()
        val section = Section()

        fun flush() {
            when (section.kind) {
                "NamedAnchors" -> {
                    val name = section.text["Name"]
                    val address = section.text["Address"]?.let { parseHex(it) }
                    val format = section.text["Format"]
                    if (name != null && address != null && format != null) anchors.add(NamedAnchor(name, address, format))
                }
                "List" -> section.text["Name"]?.let { lists.add(NamedList(it, section.indexedItems())) }
                "TableGroup" -> section.text["Name"]?.let { groups.add(TableGroup(it, section.allItems())) }
            }
            section.reset()
        }

        for (rawLine in text.lineSequence()) {
            val line = rawLine.trimStart(BOM).trim()
            if (section.inArray) {
                section.continueArray(line)
                continue
            }
            if (line.isEmpty() || line.startsWith("#")) continue
            if (line.startsWith("[[")) {
                flush()
                section.kind = line.removePrefix("[[").substringBefore("]]").trim()
                continue
            }
            val equals = line.indexOf('=')
            if (equals < 0) continue
            section.assign(line.substring(0, equals).trim(), line.substring(equals + 1).trim())
        }
        flush()
        return GameMetadata(anchors, lists, groups)
    }

    /** The key/value pairs collected for the section being read. */
    private class Section {
        var kind: String = ""
        val text = HashMap<String, String>()
        private val single = HashMap<Int, String>()
        private val arrays = ArrayList<Pair<Int, List<String>>>()
        private var arrayStart = 0
        private var arrayItems: ArrayList<String>? = null

        val inArray: Boolean get() = arrayItems != null

        fun reset() {
            text.clear()
            single.clear()
            arrays.clear()
            arrayItems = null
        }

        fun assign(key: String, value: String) {
            val index = parseNumber(key)
            when {
                value.startsWith("[") -> {
                    arrayStart = index ?: 0
                    arrayItems = ArrayList()
                    continueArray(value.substring(1))
                }
                value.startsWith("'''") -> {
                    val end = value.indexOf("'''", 3)
                    val content = if (end < 0) value.substring(3) else value.substring(3, end)
                    if (index != null) single[index] = content else text[key] = content
                }
                else -> text[key] = value.substringBefore('#').trim()
            }
        }

        /** Reads array items from [line]; the array ends at the first `]` outside quotes. */
        fun continueArray(line: String) {
            val items = arrayItems ?: return
            var i = 0
            while (i < line.length) {
                if (line.startsWith("'''", i)) {
                    val end = line.indexOf("'''", i + 3)
                    if (end < 0) return
                    items.add(line.substring(i + 3, end))
                    i = end + 3
                } else if (line[i] == ']') {
                    arrays.add(arrayStart to items)
                    arrayItems = null
                    return
                } else if (line[i] == '#') {
                    return
                } else {
                    i++
                }
            }
        }

        /** Items by position: single entries sit at their key, arrays start at theirs. Blank entries are null. */
        fun indexedItems(): List<String?> {
            val placed = HashMap<Int, String>(single)
            for ((start, items) in arrays) items.forEachIndexed { i, item -> placed[start + i] = item }
            val size = (placed.keys.maxOrNull() ?: -1) + 1
            return List(size) { placed[it]?.takeIf { s -> s.isNotBlank() } }
        }

        /** All array items in file order, without positions. */
        fun allItems(): List<String> = arrays.sortedBy { it.first }.flatMap { it.second }

        private fun parseNumber(key: String): Int? =
            if (key.startsWith("0x") || key.startsWith("0X")) parseHex(key) else key.toIntOrNull()
    }
}
