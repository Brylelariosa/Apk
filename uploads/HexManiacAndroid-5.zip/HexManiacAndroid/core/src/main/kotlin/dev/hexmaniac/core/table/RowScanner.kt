package dev.hexmaniac.core.table

import dev.hexmaniac.core.rom.RomData
import dev.hexmaniac.core.table.format.Field
import dev.hexmaniac.core.table.format.FieldKind
import dev.hexmaniac.core.table.format.PointerKind
import dev.hexmaniac.core.table.format.Schema
import dev.hexmaniac.core.text.PcsTable

/** Answers questions about named lists and tables that checking row data needs. */
internal interface OptionSource {
    /** How many values the list or table [name] has (a plain number counts as that many); null when unknown. */
    fun optionCount(name: String): Int?

    /** True when [name] is a fixed list of the reference data rather than a table in the ROM. */
    fun isList(name: String): Boolean
}

/**
 * Decides how many rows a table of unstated length has, by checking row after row whether the bytes still look like
 * the format says (text that ends properly, pointers that lead into the ROM, names that exist).
 */
internal class RowScanner(
    private val rom: RomData,
    private val pcs: PcsTable,
    private val options: OptionSource,
) {
    /** Counts the rows that start at [start] and fit before [boundary]; at least 1. */
    fun countAuto(start: Int, schema: Schema, boundary: Int): Int {
        val rowSize = schema.rowSize
        var count = 0
        var allowJunk = false
        while (count < MAX_AUTO_ROWS &&
            start.toLong() + (count + 1).toLong() * rowSize <= boundary &&
            rowMatches(start + count * rowSize, schema, count, allowJunk, boundary)
        ) {
            count++
            if (count == JUNK_LIMIT) allowJunk = true
        }
        return maxOf(1, count)
    }

    /** Counts the rows before the first row that starts with [code]; -1 when no end code is found. */
    fun countUntil(start: Int, schema: Schema, code: ByteArray): Int {
        var count = 0
        var at = start
        while (count <= MAX_STREAM_ROWS) {
            if (at < 0 || at + code.size > rom.size) return -1
            var same = true
            for (i in code.indices) if (rom[at + i] != (code[i].toInt() and 0xFF)) same = false
            if (same) return count
            count++
            at += schema.rowSize
        }
        return -1
    }

    /** True when the row at [rowStart] looks like [schema] describes it. [rowIndex] is the row's position in its table. */
    fun rowMatches(rowStart: Int, schema: Schema, rowIndex: Int, allowJunk: Boolean, boundary: Int): Boolean {
        if (rowStart < 0 || rowStart.toLong() + schema.rowSize > minOf(rom.size, boundary)) return false
        val single = schema.fields.size == 1
        for (field in schema.fields) {
            if (field.group != null) continue
            if (!fieldMatches(rowStart + field.offset, field, rowIndex, single, allowJunk)) return false
        }
        return true
    }

    private fun fieldMatches(start: Int, field: Field, rowIndex: Int, single: Boolean, allowJunk: Boolean): Boolean =
        when (field.kind) {
            FieldKind.TEXT -> textMatches(start, field.size, single, allowJunk)
            FieldKind.NUMBER -> numberMatches(start, field, rowIndex, allowJunk)
            FieldKind.SIGNED, FieldKind.COLOR -> allowJunk || field.size < 4 || !looksLikePointerByte(rom[start + 3])
            FieldKind.POINTER -> pointerMatches(start, field)
            FieldKind.BITS -> bitsMatch(start, field)
            FieldKind.HEX, FieldKind.FLAG, FieldKind.RECORD -> true
        }

    private fun looksLikePointerByte(byte: Int) = byte == 0x08 || byte == 0x09

    private fun textMatches(start: Int, size: Int, single: Boolean, allowJunk: Boolean): Boolean {
        if (size > 1) {
            val length = pcs.readStringLength(rom.bytes, start, true, size)
            if (length < 1 || length > size) return false
            var allEnd = true
            for (i in 0 until size) if (rom[start + i] != 0xFF) allEnd = false
            if (allEnd) return false
        }

        var blank = true
        for (i in 0 until size) if (rom[start + i] != 0x00 && rom[start + i] != 0xFF) blank = false
        // Two zero bytes after the text on a word boundary mean the width is probably wrong, unless padding to the next word follows.
        if (!blank && single && start % 4 == 0 && rom[start + size - 1] == 0 && rom[start + size] == 0) {
            val nextWord = (start + size + 3) / 4 * 4
            for (i in start + size until nextWord) if (rom[i] != 0) return false
            if (rom[nextWord] == 0) return false
        }

        val last = rom[start + size - 1]
        val reasonableEnd = last == 0x00 || last == 0xFF
        return allowJunk || reasonableEnd || !single
    }

    private fun numberMatches(start: Int, field: Field, rowIndex: Int, allowJunk: Boolean): Boolean {
        val name = field.enumName
        if (name == null) return allowJunk || field.size < 4 || !looksLikePointerByte(rom[start + 3])
        if (rowIndex == 0) return true
        val count = options.optionCount(name) ?: return true
        if (count == 0 || options.isList(name)) return true
        val value = Values.readUnsigned(rom, start, field.size)
        if (field.size == 2 && value.toShort().toInt() == -2) return true
        return value - field.enumOffset < count
    }

    private fun pointerMatches(start: Int, field: Field): Boolean {
        val word = rom.readWord(start)
        if (word == 0) return true
        val destination = (word.toLong() and 0xFFFFFFFFL) - Values.POINTER_BASE
        if (destination < 0 || destination > rom.size) return false
        if (destination == 0L) return true
        if (field.pointer?.kind == PointerKind.TEXT) return pcs.readStringLength(rom.bytes, destination.toInt(), true) >= 1
        return true
    }

    private fun bitsMatch(start: Int, field: Field): Boolean {
        val bits = (field.bitSource?.let { options.optionCount(it) } ?: 8) % 8
        if (bits == 0) return true
        return (rom[start + field.size - 1] shr bits) == 0
    }

    companion object {
        const val MAX_AUTO_ROWS = 1500
        const val JUNK_LIMIT = 80
        const val MAX_STREAM_ROWS = 100_000
    }
}
