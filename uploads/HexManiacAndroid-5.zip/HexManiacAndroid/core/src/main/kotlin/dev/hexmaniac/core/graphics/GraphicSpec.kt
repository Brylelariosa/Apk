package dev.hexmaniac.core.graphics

/**
 * What a special pointer of the table definitions (the part in backticks, such as `lzs4x8x8|graphics.items.palettes`)
 * says about the picture data it leads to. Formats that this app does not draw (tile maps, scripts, ...) are not
 * understood and parse to null.
 */
sealed class GraphicSpec {
    /** True for data in the GBA's LZ77 compression, false for data that is stored as it is. */
    abstract val compressed: Boolean

    /** A picture of [tilesWide] by [tilesHigh] tiles. [paletteHint] names where its palette is, or is null. */
    class Sprite(
        override val compressed: Boolean,
        val bits: Int,
        val tilesWide: Int,
        val tilesHigh: Int,
        val paletteHint: String?,
    ) : GraphicSpec()

    /**
     * Colours: 16 (4 bits) or 256 (8 bits) per page. A palette of several pages fills the slots from [firstPage] on;
     * [pages] is 0 for compressed data, which takes as many pages as its size says.
     */
    class Palette(
        override val compressed: Boolean,
        val bits: Int,
        val firstPage: Int,
        val pages: Int,
    ) : GraphicSpec()

    /** Tiles without a size: [tiles] of them, or all that the data holds when [tiles] is 0. */
    class Tileset(
        override val compressed: Boolean,
        val bits: Int,
        val tiles: Int,
        val paletteHint: String?,
    ) : GraphicSpec()

    companion object {
        private const val MAX_TILES = 4096
        private const val PAGE_DIGITS = "0123456789ABCDEF"

        /** Reads the text between the angle brackets of a pointer field (with or without its backticks). */
        fun parse(inner: String): GraphicSpec? {
            val text = inner.trim().removePrefix("`").removeSuffix("`")
            if (text.length < 3) return null
            val compressed = when (text.substring(0, 2)) {
                "lz" -> true
                "uc" -> false
                else -> return null
            }
            val body = text.substring(3)
            val hint = if (body.contains('|')) body.substringAfter('|').substringBefore('|').ifEmpty { null } else null
            val shape = body.substringBefore('|')
            return when (text[2]) {
                's' -> sprite(compressed, shape, hint)
                'p' -> palette(compressed, shape)
                't' -> tileset(compressed, shape, hint)
                else -> null
            }
        }

        private fun sprite(compressed: Boolean, shape: String, hint: String?): GraphicSpec? {
            val parts = shape.removeSuffix("!").split('x')
            if (parts.size != 3) return null
            val bits = parts[0].toIntOrNull() ?: return null
            val wide = parts[1].toIntOrNull() ?: return null
            val high = parts[2].toIntOrNull() ?: return null
            if (!validBits(bits) || wide < 1 || high < 1 || wide > 100 || high > 1024) return null
            if (wide * high > MAX_TILES) return null
            return Sprite(compressed, bits, wide, high, hint)
        }

        private fun palette(compressed: Boolean, shape: String): GraphicSpec? {
            val bits = shape.substringBefore(':').removeSuffix("!").toIntOrNull() ?: return null
            if (bits != 4 && bits != 8) return null
            var first = 0
            var pages = 1
            if (shape.contains(':')) {
                val ids = shape.substringAfter(':').uppercase()
                val low = if (ids.isEmpty()) -1 else PAGE_DIGITS.indexOf(ids.first())
                val high = if (ids.isEmpty()) -1 else PAGE_DIGITS.indexOf(ids.last())
                if (low >= 0 && high >= low) {
                    first = low
                    pages = high - low + 1
                }
            }
            return Palette(compressed, bits, first, if (compressed) 0 else pages)
        }

        private fun tileset(compressed: Boolean, shape: String, hint: String?): GraphicSpec? {
            val parts = shape.removeSuffix("!").split('x')
            val bits = parts[0].toIntOrNull() ?: return null
            if (!validBits(bits) || parts.size > 2) return null
            val tiles = if (parts.size == 2) parts[1].toIntOrNull() ?: return null else 0
            if (tiles < 0 || tiles > MAX_TILES) return null
            if (!compressed && tiles == 0) return null
            return Tileset(compressed, bits, tiles, hint)
        }

        private fun validBits(bits: Int) = bits == 1 || bits == 2 || bits == 4 || bits == 8
    }
}
