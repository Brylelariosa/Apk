package dev.hexmaniac.core.graphics

/**
 * The compression of the GBA BIOS (type 0x10, called LZ77) that the games use for sprites, palettes and tilesets.
 * A stream is a header (0x10 and the size of the result in three bytes) and then groups of one flag byte and up to
 * eight items. The flags are read from the highest bit down: a clear bit is one literal byte, a set bit is a pair of
 * bytes that copies 3 to 18 bytes from 1 to 4096 bytes back in the result.
 */
internal object Lz77 {
    /** The biggest result that is accepted. Graphics fit video memory (96 KB), so a larger size is a sign of bad data. */
    const val MAX_SIZE = 0x40000

    private const val MAGIC = 0x10

    /**
     * The decompressed bytes of the stream that starts at [start], or null when there is no valid stream there:
     * no header, a size of zero or above [MAX_SIZE], a reference to bytes before the start, or a stream that ends early.
     * Flag bits that are left over after the last item are ignored, as the BIOS does.
     */
    fun decompress(data: ByteArray, start: Int): ByteArray? {
        if (start < 0 || start > data.size - 4) return null
        if (data[start].toInt() and 0xFF != MAGIC) return null
        val size = (data[start + 1].toInt() and 0xFF) or
            ((data[start + 2].toInt() and 0xFF) shl 8) or
            ((data[start + 3].toInt() and 0xFF) shl 16)
        if (size < 1 || size > MAX_SIZE) return null

        val result = ByteArray(size)
        var read = start + 4
        var written = 0
        while (written < size) {
            if (read >= data.size) return null
            var flags = data[read++].toInt() and 0xFF
            var item = 0
            while (item < 8 && written < size) {
                if (flags and 0x80 == 0) {
                    if (read >= data.size) return null
                    result[written++] = data[read++]
                } else {
                    if (read + 2 > data.size) return null
                    val first = data[read].toInt() and 0xFF
                    val second = data[read + 1].toInt() and 0xFF
                    read += 2
                    val length = (first shr 4) + 3
                    val distance = (((first and 0x0F) shl 8) or second) + 1
                    if (distance > written) return null
                    var copied = 0
                    while (copied < length && written < size) {
                        result[written] = result[written - distance]
                        written++
                        copied++
                    }
                }
                flags = flags shl 1
                item++
            }
        }
        return result
    }
}
