package dev.hexmaniac.core.table.data

/**
 * Where one game keeps the pointer to a table: the word at [pointerAddress] holds an address, and the table starts
 * [offset] bytes before it. [format] is the table definition (see FormatParser).
 */
class TableDefinition(val name: String, val pointerAddress: Int, val offset: Int, val format: String)

/** The tables of every game, read from `tableReference.txt`. */
class TableReference private constructor(private val byGame: Map<String, List<TableDefinition>>) {
    /** Tables of [game] ("BPRE0"), in file order; empty for games the file does not cover. */
    fun tablesFor(game: String): List<TableDefinition> = byGame[game] ?: emptyList()

    companion object {
        /** The game of each address column, in file order (matches the header comment of the file). */
        private val COLUMNS = listOf("AXVE0", "AXPE0", "AXVE1", "AXPE1", "BPRE0", "BPGE0", "BPRE1", "BPGE1", "BPEE0")

        /**
         * Lines look like `name, addr, addr, ..., format` with one address per game (empty when the game does not have
         * the table). The name may end in `+HEX` or `-HEX`, the distance from the table to where its pointer leads.
         * Lines starting with `//` are comments.
         */
        fun parse(text: String): TableReference {
            val tables = HashMap<String, MutableList<TableDefinition>>()
            for (game in COLUMNS) tables[game] = ArrayList()
            for (line in text.lineSequence()) {
                val row = line.trimStart(BOM).trim()
                if (row.isEmpty() || row.startsWith("//")) continue
                val segments = row.substringBefore("//").split(',')
                if (segments.size != COLUMNS.size + 2) continue
                var name = segments[0].trim()
                var offset = 0
                val plus = name.indexOf('+')
                val minus = name.indexOf('-')
                if (plus >= 0) {
                    offset = parseHex(name.substring(plus + 1)) ?: 0
                    name = name.substring(0, plus)
                } else if (minus >= 0) {
                    offset = -(parseHex(name.substring(minus + 1)) ?: 0)
                    name = name.substring(0, minus)
                }
                val format = segments.last().trim()
                for ((column, game) in COLUMNS.withIndex()) {
                    val address = parseHex(segments[column + 1].trim()) ?: continue
                    tables.getValue(game).add(TableDefinition(name, address, offset, format))
                }
            }
            return TableReference(tables)
        }
    }
}

/**
 * A number stored in the game's code that data tables refer to by name, such as the number of items.
 * The value is `(stored - [addOffset]) / [multiplier]`; it is only trusted when every one of [addresses] says the same.
 */
class ConstantDefinition(
    val name: String,
    val size: Int,
    val addOffset: Int,
    val multiplier: Int,
    val addresses: List<Int>,
)

/** The constants of every game, read from `constantReference.txt`. */
class ConstantReference private constructor(private val byGame: Map<String, List<ConstantDefinition>>) {
    fun constantsFor(game: String): List<ConstantDefinition> = byGame[game] ?: emptyList()

    companion object {
        /**
         * Lines look like `BPRE0.some.name-1 03DB5E,044120  # note`, or `BPRE0:name` for a two byte value and
         * `BPRE0::name` for four bytes. A name may end in `-N` or `+N` (an added offset) or `*N` (a multiplier).
         */
        fun parse(text: String): ConstantReference {
            val byGame = HashMap<String, MutableList<ConstantDefinition>>()
            for (line in text.lineSequence()) {
                val clean = line.trimStart(BOM).trim()
                if (clean.length < 6 || !clean[0].isLetter()) continue
                val definition = parseLine(clean.substring(5)) ?: continue
                byGame.getOrPut(clean.substring(0, 5).uppercase()) { ArrayList() }.add(definition)
            }
            return ConstantReference(byGame)
        }

        private fun parseLine(line: String): ConstantDefinition? {
            val size: Int
            val body: String
            when {
                line.startsWith("::") -> { size = 4; body = line.substring(2) }
                line.startsWith(":") -> { size = 2; body = line.substring(1) }
                line.startsWith(".") -> { size = 1; body = line.substring(1) }
                else -> return null
            }
            val parts = body.substringBefore('#').split(' ').filter { it.isNotEmpty() }
            if (parts.size < 2) return null
            var name = parts[0]
            var addOffset = 0
            var multiplier = 1
            val minus = name.indexOf('-')
            val plus = name.indexOf('+')
            val star = name.indexOf('*')
            if (minus >= 0) {
                addOffset = -(name.substring(minus + 1).toIntOrNull() ?: return null)
                name = name.substring(0, minus)
            } else if (plus >= 0) {
                addOffset = name.substring(plus + 1).toIntOrNull() ?: return null
                name = name.substring(0, plus)
            } else if (star >= 0) {
                multiplier = name.substring(star + 1).toIntOrNull() ?: return null
                name = name.substring(0, star)
            }
            if (multiplier == 0) return null
            val addresses = parts[1].split(',').map { parseHex(it) ?: return null }
            return ConstantDefinition(name, size, addOffset, multiplier, addresses)
        }
    }
}

internal val BOM: Char = Char(0xFEFF)

internal fun parseHex(text: String): Int? {
    val t = text.trim().removePrefix("0x").removePrefix("0X")
    if (t.isEmpty() || t.length > 8 || !t.all { it in '0'..'9' || it in 'a'..'f' || it in 'A'..'F' }) return null
    val value = t.toLong(16)
    return if (value <= Int.MAX_VALUE) value.toInt() else null
}
