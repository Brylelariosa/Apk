package dev.hexmaniac.core.table

import dev.hexmaniac.core.rom.RomData
import dev.hexmaniac.core.table.format.Field

/** Reading and writing the integers inside rows. */
internal object Values {
    const val POINTER_BASE = 0x08000000L

    /** Unsigned little endian integer of [size] (1 to 4) bytes. */
    fun readUnsigned(rom: RomData, offset: Int, size: Int): Long {
        var value = 0L
        for (i in 0 until size) value = value or (rom[offset + i].toLong() shl (8 * i))
        return value
    }

    fun toSigned(value: Long, size: Int): Long {
        val shift = 64 - 8 * size
        return (value shl shift) shr shift
    }

    fun toBytes(value: Long, size: Int): ByteArray = ByteArray(size) { (value ushr (8 * it)).toByte() }

    /** The unsigned value of [field] in the row at [rowStart]; for a slice of a packed integer, just the bits of the slice. */
    fun fieldValue(rom: RomData, rowStart: Int, field: Field): Long {
        val whole = readUnsigned(rom, rowStart + field.offset, field.size)
        if (!field.isSlice) return whole
        return (whole ushr field.shift) and ((1L shl field.width) - 1)
    }
}
