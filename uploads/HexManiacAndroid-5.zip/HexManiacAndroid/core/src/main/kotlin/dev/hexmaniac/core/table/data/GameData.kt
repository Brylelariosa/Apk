package dev.hexmaniac.core.table.data

import dev.hexmaniac.core.io.ResourceSource

/** Everything the bundled reference files say about one game release. */
class GameData(
    /** Game code with version, e.g. "BPRE0". */
    val game: String,
    val tables: List<TableDefinition>,
    val constants: List<ConstantDefinition>,
    val metadata: GameMetadata,
) {
    /** True for a game the reference files do not cover (the shared metadata does not count). */
    val isEmpty: Boolean get() = tables.isEmpty()
}

/**
 * Loads and caches the bundled reference data. Parsing the big files takes a moment, so keep one library for the
 * life of the app and ask it for [GameData] whenever a ROM is opened.
 */
class ReferenceLibrary(private val resources: ResourceSource) {
    private val tableReference: TableReference by lazy {
        TableReference.parse(resources.readText(TABLE_FILE).orEmpty())
    }
    private val constantReference: ConstantReference by lazy {
        ConstantReference.parse(resources.readText(CONSTANT_FILE).orEmpty())
    }
    private val metadataFiles = HashMap<String, GameMetadata>()
    private val loaded = HashMap<String, GameData>()

    /** True when the reference files describe tables for [game] ("BPRE0"). */
    @Synchronized
    fun supports(game: String): Boolean = tableReference.tablesFor(game).isNotEmpty()

    @Synchronized
    fun load(game: String): GameData = loaded.getOrPut(game) {
        val lowerFull = game.lowercase()
        val lowerCode = lowerFull.take(4)
        var metadata = GameMetadata()
        for (file in metadataNamesFor(lowerCode, lowerFull)) {
            metadata = metadata.merge(metadataFiles.getOrPut(file) { MetadataParser.parse(resources.readText(file).orEmpty()) })
        }
        GameData(game, tableReference.tablesFor(game), constantReference.constantsFor(game), metadata)
    }

    /** `default.toml`, then the `default.*.toml` files whose name mentions the game, in alphabetical order. */
    private fun metadataNamesFor(code: String, full: String): List<String> {
        val specific = resources.list()
            .filter { it.startsWith("default.") && it.endsWith(".toml") && it != DEFAULT_FILE }
            .filter { val name = it.lowercase(); name.contains(".$code.") || name.contains(".$full.") }
            .sorted()
        return listOf(DEFAULT_FILE) + specific
    }

    private companion object {
        const val TABLE_FILE = "tableReference.txt"
        const val CONSTANT_FILE = "constantReference.txt"
        const val DEFAULT_FILE = "default.toml"
    }
}
