package dev.hexmaniac.core.graphics

/**
 * The tile graphics of the GBA: pictures made of 8 by 8 pixel tiles that are stored one after the other, row by row,
 * with 1, 2, 4 or 8 bits for every pixel. The value of a pixel is an index into a palette.
 */
internal object Tiles {
    /** The bytes one tile takes with [bits] bits per pixel. */
    fun bytesPerTile(bits: Int): Int = bits * 8

    /**
     * The palette indexes of a picture of [tilesWide] by [tilesHigh] tiles whose data starts at [offset], as
     * `tilesWide * 8` columns by `tilesHigh * 8` rows, row after row. Bytes beyond the end of [data] read as 0.
     *
     * 4 bit pixels keep the left pixel in the low half of the byte, as the hardware does. The 2 and 1 bit layouts
     * are those of HexManiac, which keeps them for the few places that use them.
     */
    fun indexes(data: ByteArray, offset: Int, bits: Int, tilesWide: Int, tilesHigh: Int): IntArray {
        require(bits == 1 || bits == 2 || bits == 4 || bits == 8) { "Unsupported bits per pixel: $bits" }
        require(tilesWide > 0 && tilesHigh > 0) { "A picture needs at least one tile" }
        val width = tilesWide * 8
        val result = IntArray(width * tilesHigh * 8)
        val tileBytes = bytesPerTile(bits)
        for (tileY in 0 until tilesHigh) {
            for (tileX in 0 until tilesWide) {
                val tileStart = offset.toLong() + (tileY * tilesWide + tileX).toLong() * tileBytes
                val left = tileX * 8
                val top = tileY * 8
                for (i in 0 until tileBytes) {
                    val raw = byteAt(data, tileStart + i)
                    when (bits) {
                        4 -> {
                            val at = (top + i / 4) * width + left + (i % 4) * 2
                            result[at] = raw and 0xF
                            result[at + 1] = raw shr 4
                        }
                        8 -> result[(top + i / 8) * width + left + i % 8] = raw
                        2 -> {
                            val at = (top + i / 2) * width + left + (1 - i % 2) * 4
                            result[at] = (raw shr 6) and 3
                            result[at + 1] = (raw shr 4) and 3
                            result[at + 2] = (raw shr 2) and 3
                            result[at + 3] = raw and 3
                        }
                        else -> {
                            val at = (top + i) * width + left
                            for (bit in 0 until 8) result[at + bit] = (raw shr bit) and 1
                        }
                    }
                }
            }
        }
        return result
    }

    private fun byteAt(data: ByteArray, at: Long): Int = if (at >= 0 && at < data.size) data[at.toInt()].toInt() and 0xFF else 0
}
