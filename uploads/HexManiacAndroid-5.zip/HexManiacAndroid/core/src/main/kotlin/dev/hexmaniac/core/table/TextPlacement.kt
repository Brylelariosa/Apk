package dev.hexmaniac.core.table

import dev.hexmaniac.core.rom.FreeSpace
import dev.hexmaniac.core.rom.HexText
import dev.hexmaniac.core.rom.PointerSearch
import dev.hexmaniac.core.rom.RomData

/**
 * Decides where text goes when it is edited, the way HexManiac does. Text that fits stays where it is and the bytes it
 * no longer needs become free space. Text that grows first takes the free bytes behind it, if nothing else needs them,
 * and otherwise moves to free space (growing the ROM when it is full) with every pointer to it following; the old copy
 * is erased. The result is a plan: nothing here changes the ROM.
 */
internal class TextPlacement(private val rom: RomData) {

    /** Text that already is in the ROM, as far as an edit has to know about it. */
    class Existing(
        /** File offset of the first byte. */
        val target: Int,
        /** Bytes the text takes now, its end mark included. */
        val length: Int,
        /** Bytes the text may take without moving: its own plus the free bytes behind it, and never what others use. */
        val room: Int,
        /** File offsets of the pointers that lead to [target]. The pointer being edited is always one of them. */
        val sources: IntArray,
        /** Offset of the first byte inside the text that some other pointer leads to, or [Int.MAX_VALUE]. */
        val innerLimit: Int,
    )

    /** Looks at the text of [length] bytes at [target], which the pointer at [pointerAt] (or -1) leads to. */
    fun measure(target: Int, length: Int, pointerAt: Int): Existing {
        val end = target + length
        var limit = end + freeBehind(end, length)
        var inner = Int.MAX_VALUE
        val sources = ArrayList<Int>()
        val hits = PointerSearch.leadingTo(rom, target, limit)
        for (i in 0 until hits.size) {
            val source = hits.sources[i]
            val destination = hits.targets[i]
            if (source >= target && source < end) continue
            when {
                destination == target -> sources.add(source)
                destination < end -> inner = minOf(inner, destination)
                else -> limit = minOf(limit, destination)
            }
        }
        if (pointerAt >= 0 && pointerAt !in sources) sources.add(pointerAt)
        return Existing(target, length, minOf(limit, inner) - target, sources.toIntArray(), inner)
    }

    /** The plan that makes the text at [existing] read [encoded] (which ends with its end mark). */
    fun replace(label: String, existing: Existing, encoded: ByteArray): EditResult {
        val target = existing.target
        val clearEnd = minOf(target + existing.length, existing.innerLimit)
        if (encoded.size <= existing.room) {
            val writes = ArrayList<ByteWrite>()
            writes.add(ByteWrite(target, encoded))
            val end = target + encoded.size
            if (clearEnd > end) writes.add(ByteWrite(end, erased(clearEnd - end)))
            val others = existing.sources.size - 1
            val notice = if (others > 0) "$others other ${if (others == 1) "place uses" else "places use"} this text and changed too." else null
            return EditResult.Ready(EditPlan(label, writes), notice)
        }

        val spot = FreeSpace.find(rom, encoded.size) ?: return noRoom(encoded.size)
        val writes = ArrayList<ByteWrite>()
        growth(spot)?.let { writes.add(it) }
        writes.add(ByteWrite(target, erased(clearEnd - target)))
        writes.add(ByteWrite(spot.offset, encoded))
        val pointer = Values.toBytes(Values.POINTER_BASE + spot.offset, 4)
        for (source in existing.sources) writes.add(ByteWrite(source, pointer))
        val count = existing.sources.size
        val notice = "Moved to free space at ${HexText.hex(spot.offset, 6)}. $count ${if (count == 1) "pointer" else "pointers"} updated." + grown(spot)
        return EditResult.Ready(EditPlan(label, writes, spot.romSize), notice)
    }

    /**
     * The plan that puts new text [encoded] into free space and points the pointer at [pointerAt] to it. Whatever the
     * pointer led to before is left alone, so other places that use it keep it.
     */
    fun create(label: String, encoded: ByteArray, pointerAt: Int): EditResult = place(label, encoded, pointerAt, "Text placed in free space")

    /** The plan that gives the pointer at [pointerAt] a copy of [text] of its own (bytes with their end mark). */
    fun separate(label: String, text: ByteArray, pointerAt: Int): EditResult = place(label, text, pointerAt, "Text copied to free space")

    private fun place(label: String, encoded: ByteArray, pointerAt: Int, what: String): EditResult {
        val spot = FreeSpace.find(rom, encoded.size) ?: return noRoom(encoded.size)
        val writes = ArrayList<ByteWrite>()
        growth(spot)?.let { writes.add(it) }
        writes.add(ByteWrite(spot.offset, encoded))
        writes.add(ByteWrite(pointerAt, Values.toBytes(Values.POINTER_BASE + spot.offset, 4)))
        val notice = "$what at ${HexText.hex(spot.offset, 6)}." + grown(spot)
        return EditResult.Ready(EditPlan(label, writes, spot.romSize), notice)
    }

    // ---- helpers ----

    /** How many free (0xFF) bytes follow [end], counting only as far as a text of [length] bytes can be extended. */
    private fun freeBehind(end: Int, length: Int): Int {
        var free = 0
        while (end + free < rom.size && length + free < MAX_TEXT_BYTES && rom[end + free] == 0xFF) free++
        return free
    }

    private fun erased(count: Int) = ByteArray(count) { 0xFF.toByte() }

    /** Fills the bytes a grown ROM gains with 0xFF, the way unused ROM space is kept; null when the ROM does not grow. */
    private fun growth(spot: FreeSpace.Spot): ByteWrite? =
        if (spot.romSize > rom.size) ByteWrite(rom.size, erased(spot.romSize - rom.size)) else null

    private fun grown(spot: FreeSpace.Spot): String =
        if (spot.romSize > rom.size) " The ROM grew by ${spot.romSize - rom.size} bytes." else ""

    private fun noRoom(bytes: Int) = EditResult.Rejected("The ROM has no free space for $bytes bytes.")

    private companion object {
        const val MAX_TEXT_BYTES = 4096
    }
}
