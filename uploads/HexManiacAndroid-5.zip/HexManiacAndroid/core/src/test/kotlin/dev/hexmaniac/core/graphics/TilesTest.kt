package dev.hexmaniac.core.graphics

import org.junit.Assert.assertEquals
import org.junit.Test

class TilesTest {
    private fun bytes(vararg values: Int) = ByteArray(values.size) { values[it].toByte() }

    /** The pixel at ([x], [y]) of a result that is [width] pixels wide. */
    private fun IntArray.at(width: Int, x: Int, y: Int) = this[y * width + x]

    @Test
    fun fourBitPixelsKeepTheLeftPixelInTheLowHalf() {
        val data = ByteArray(32)
        data[0] = 0x21
        data[1] = 0x43
        data[4] = 0x65 // the second row of the tile
        data[31] = 0xFE.toByte()
        val pixels = Tiles.indexes(data, 0, 4, 1, 1)
        assertEquals(64, pixels.size)
        assertEquals(1, pixels.at(8, 0, 0))
        assertEquals(2, pixels.at(8, 1, 0))
        assertEquals(3, pixels.at(8, 2, 0))
        assertEquals(4, pixels.at(8, 3, 0))
        assertEquals(5, pixels.at(8, 0, 1))
        assertEquals(6, pixels.at(8, 1, 1))
        assertEquals(14, pixels.at(8, 6, 7))
        assertEquals(15, pixels.at(8, 7, 7))
    }

    @Test
    fun tilesFollowEachOtherRowByRow() {
        val data = ByteArray(4 * 32)
        for (tile in 0 until 4) data[tile * 32] = (tile + 1).toByte() // the left pixel of each tile's first row
        val pixels = Tiles.indexes(data, 0, 4, 2, 2)
        assertEquals(16, pixels.size / 16)
        assertEquals(1, pixels.at(16, 0, 0))
        assertEquals(2, pixels.at(16, 8, 0))
        assertEquals(3, pixels.at(16, 0, 8))
        assertEquals(4, pixels.at(16, 8, 8))
    }

    @Test
    fun eightBitPixelsAreTheBytes() {
        val data = ByteArray(64)
        data[0] = 0x80.toByte()
        data[9] = 77
        data[63] = 255.toByte()
        val pixels = Tiles.indexes(data, 0, 8, 1, 1)
        assertEquals(0x80, pixels.at(8, 0, 0))
        assertEquals(77, pixels.at(8, 1, 1))
        assertEquals(255, pixels.at(8, 7, 7))
    }

    @Test
    fun oneBitPixelsStartAtTheLowBit() {
        val data = ByteArray(8)
        data[0] = 0b0000_0101
        data[7] = 0b1000_0000.toByte()
        val pixels = Tiles.indexes(data, 0, 1, 1, 1)
        assertEquals(1, pixels.at(8, 0, 0))
        assertEquals(0, pixels.at(8, 1, 0))
        assertEquals(1, pixels.at(8, 2, 0))
        assertEquals(1, pixels.at(8, 7, 7))
        assertEquals(0, pixels.at(8, 6, 7))
    }

    @Test
    fun twoBitPixelsUseTheLayoutOfHexManiac() {
        val data = ByteArray(16)
        data[0] = 0b11_10_01_00.toByte() // the right half of the first row, highest bits first
        data[1] = 0b00_01_10_11 // the left half
        val pixels = Tiles.indexes(data, 0, 2, 1, 1)
        assertEquals(3, pixels.at(8, 4, 0))
        assertEquals(2, pixels.at(8, 5, 0))
        assertEquals(1, pixels.at(8, 6, 0))
        assertEquals(0, pixels.at(8, 7, 0))
        assertEquals(0, pixels.at(8, 0, 0))
        assertEquals(1, pixels.at(8, 1, 0))
        assertEquals(2, pixels.at(8, 2, 0))
        assertEquals(3, pixels.at(8, 3, 0))
    }

    @Test
    fun theDataMayStartAnywhere() {
        val data = bytes(9, 9, 9, 0x21)
        assertEquals(1, Tiles.indexes(data, 3, 4, 1, 1).at(8, 0, 0))
    }

    @Test
    fun missingDataReadsAsZero() {
        val data = bytes(0x21, 0x43)
        val pixels = Tiles.indexes(data, 0, 4, 2, 1)
        assertEquals(1, pixels.at(16, 0, 0))
        assertEquals(4, pixels.at(16, 3, 0))
        assertEquals(0, pixels.at(16, 4, 0))
        assertEquals(0, pixels.at(16, 8, 0))
        assertEquals(0, Tiles.indexes(data, 100, 4, 1, 1).sum())
        assertEquals(0, Tiles.indexes(data, -100, 4, 1, 1).sum())
    }

    @Test
    fun theTileSizeFollowsTheBitsPerPixel() {
        assertEquals(8, Tiles.bytesPerTile(1))
        assertEquals(16, Tiles.bytesPerTile(2))
        assertEquals(32, Tiles.bytesPerTile(4))
        assertEquals(64, Tiles.bytesPerTile(8))
    }

    @Test(expected = IllegalArgumentException::class)
    fun otherBitDepthsAreRefused() {
        Tiles.indexes(ByteArray(64), 0, 3, 1, 1)
    }

    @Test(expected = IllegalArgumentException::class)
    fun aPictureNeedsATile() {
        Tiles.indexes(ByteArray(64), 0, 4, 0, 1)
    }
}
