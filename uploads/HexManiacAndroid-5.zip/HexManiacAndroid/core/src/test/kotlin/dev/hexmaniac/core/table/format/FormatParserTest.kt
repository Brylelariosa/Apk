package dev.hexmaniac.core.table.format

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class FormatParserTest {
    private val parser = FormatParser { name ->
        when (name) {
            "tms" -> 58
            "nine" -> 9
            else -> null
        }
    }

    private fun schema(format: String) = parser.parse(format).schema

    private fun fields(format: String) = schema(format).fields

    private fun rejects(format: String) {
        try {
            parser.parse(format)
            fail("expected a FormatException for $format")
        } catch (expected: FormatException) {
            // fine
        }
    }

    // ---- sizes ----

    @Test
    fun integersHaveTheSizeOfTheirMarker() {
        val s = schema("[a. b: c:: d.: e:.]")
        assertEquals(listOf(1, 2, 4, 3, 3), s.fields.map { it.size })
        assertEquals(listOf(0, 1, 3, 7, 10), s.fields.map { it.offset })
        assertEquals(13, s.rowSize)
    }

    @Test
    fun textTakesItsStatedLength() {
        val s = schema("[name\"\"11 level.]")
        assertEquals(FieldKind.TEXT, s.fields[0].kind)
        assertEquals(11, s.fields[0].size)
        assertEquals(12, s.rowSize)
    }

    @Test
    fun pointersTakeFourBytesAndRememberWhereTheyLead() {
        val f = fields("[desc<\"\"> table<[x. y.]4> plain<> special<`lzs4`> bare<>]")
        assertEquals(listOf(PointerKind.TEXT, PointerKind.TABLE, PointerKind.PLAIN, PointerKind.SPECIAL, PointerKind.PLAIN), f.map { it.pointer!!.kind })
        assertEquals("lzs4", f[3].pointer!!.special)
        val nested = f[1].pointer!!.table!!
        assertEquals(2, nested.schema.rowSize)
        assertEquals(4, (nested.length as LengthSpec.Fixed).count)
        assertEquals(20, schema("[a<\"\"> b<[x.]2> c<> d<`asc`4> e<>]").rowSize)
    }

    @Test
    fun nestedPointerFormatsMayContainPointers() {
        val f = fields("[list<[basic. rate:: more<[a. b.]3>]2>]")
        val inner = f[0].pointer!!.table!!
        assertEquals(1 + 4 + 4, inner.schema.rowSize)
        assertEquals(3, (inner.schema.fields[2].pointer!!.table!!.length as LengthSpec.Fixed).count)
    }

    // ---- named values ----

    @Test
    fun namesAfterAnIntegerMarkerNameTheValues() {
        val f = fields("[type.types move:data.pokemon.moves.names level.numbers+1 count.20 plain.]")
        assertEquals("types", f[0].enumName)
        assertEquals("data.pokemon.moves.names", f[1].enumName)
        assertEquals(2, f[1].size)
        assertEquals("numbers", f[2].enumName)
        assertEquals(1, f[2].enumOffset)
        assertEquals("20", f[3].enumName)
        assertNull(f[4].enumName)
    }

    @Test
    fun hexAndSignedSuffixes() {
        val f = fields("[a.|h b:|z c::|h]")
        assertEquals(listOf(FieldKind.HEX, FieldKind.SIGNED, FieldKind.HEX), f.map { it.kind })
    }

    @Test
    fun coloursAreTwoBytes() {
        val s = schema("[a. x:|c y:|c]")
        assertEquals(listOf(FieldKind.NUMBER, FieldKind.COLOR, FieldKind.COLOR), s.fields.map { it.kind })
        assertEquals(5, s.rowSize)
    }

    @Test
    fun computedValuesAndCommentsTakeNoSpace() {
        val s = schema("[a. sum|=a+b b. note|comment=hello c.]")
        assertEquals(listOf("a", "b", "c"), s.fields.map { it.name })
        assertEquals(3, s.rowSize)
    }

    // ---- packed values ----

    @Test
    fun tuplesSplitAnIntegerIntoSlices() {
        val f = fields("[flags:|t|a.|b:|c.names|d.]")
        assertEquals(listOf("a", "b", "c", "d"), f.map { it.name })
        assertEquals(listOf(0, 1, 3, 4), f.map { it.shift })
        assertEquals(listOf(1, 2, 1, 1), f.map { it.width })
        assertEquals(listOf(FieldKind.FLAG, FieldKind.NUMBER, FieldKind.NUMBER, FieldKind.FLAG), f.map { it.kind })
        assertEquals("names", f[2].enumName)
        assertEquals("flags.b", f[1].label)
        assertTrue(f.all { it.size == 2 && it.offset == 0 && it.group == "flags" })
    }

    @Test
    fun unnamedTupleElementsAreSkippedPadding() {
        val f = fields("[x.|t|a.|.:|b.]")
        assertEquals(listOf("a", "b"), f.map { it.name })
        assertEquals(listOf(0, 4), f.map { it.shift })
    }

    @Test
    fun sliceFieldsKnowTheyAreSlices() {
        val f = fields("[x:|t|a:|b::::::]")
        assertTrue(f[0].isSlice)
        assertTrue(f[1].isSlice)
    }

    @Test
    fun tuplesLongerThanTheirIntegerAreRejected() {
        rejects("[x.|t|a::::|b:]")
    }

    @Test
    fun tupleElementsNeedALength() {
        rejects("[x.|t|a|b.]")
    }

    // ---- records and bit arrays ----

    @Test
    fun recordsPickTheirTypeFromAnotherField() {
        val f = fields("[kind. value.|s=kind(0=types|1=<>|2=<\"\">)]")
        val record = f[1].record!!
        assertEquals(FieldKind.RECORD, f[1].kind)
        assertEquals("kind", record.matchField)
        assertEquals(mapOf(0 to "types", 1 to "<>", 2 to "<\"\">"), record.cases)
    }

    @Test
    fun recordsNeedAMatchField() {
        rejects("[a. b.|s=(0=x)]")
        rejects("[a. b.|s=a0=x]")
    }

    @Test
    fun bitArraysTakeOneBitPerOption() {
        assertEquals(8, schema("[flags|b[]tms]").rowSize)
        assertEquals(2, schema("[flags|b[]nine]").rowSize)
        assertEquals(1, schema("[flags|b[]unknown]").rowSize)
        val f = fields("[flags|b[]tms x.]")
        assertEquals(FieldKind.BITS, f[0].kind)
        assertEquals("tms", f[0].bitSource)
        assertEquals(8, f[1].offset)
    }

    // ---- repetition ----

    @Test
    fun groupsCanBeRepeated() {
        val s = schema("[a. [b. c:]2 d.]")
        assertEquals(listOf("a", "b #1", "c #1", "b #2", "c #2", "d"), s.fields.map { it.name })
        assertEquals(listOf(0, 1, 2, 4, 5, 7), s.fields.map { it.offset })
        assertEquals(8, s.rowSize)
    }

    @Test
    fun repeatedGroupsKeepTheirRecordsPointingAtTheirOwnCopy() {
        val f = fields("[[kind. value.|s=kind(0=x)]2]")
        assertEquals("kind #1", f[1].record!!.matchField)
        assertEquals("kind #2", f[3].record!!.matchField)
    }

    @Test
    fun nestedRepetitionMultiplies() {
        val s = schema("[name\"\"8 [[word:|h]6]3 pokemon<>]")
        assertEquals(18, s.fields.count { it.kind == FieldKind.HEX })
        assertEquals(8 + 18 * 2 + 4, s.rowSize)
    }

    @Test
    fun repeatCountsAreChecked() {
        rejects("[[a.]x]")
        rejects("[[a.]99999]")
        rejects("[[a.]2")
    }

    // ---- lengths ----

    @Test
    fun lengthsAfterTheBracket() {
        assertTrue(parser.parse("[a.]").length is LengthSpec.Auto)
        assertEquals(12, (parser.parse("[a.]12").length as LengthSpec.Fixed).count)
        assertEquals(1, (parser.parse("[a.]0").length as LengthSpec.Fixed).count)
    }

    @Test
    fun lengthsCanFollowANamedTable() {
        fun named(text: String) = parser.parseLength(text) as LengthSpec.FromName
        named("data.pokemon.names").let { assertEquals("data.pokemon.names", it.name); assertEquals(0, it.begin); assertEquals(0, it.end) }
        named("names-1").let { assertEquals(-1, it.begin); assertEquals(0, it.end) }
        named("names+2").let { assertEquals(0, it.begin); assertEquals(2, it.end) }
        named("data.items.stats-13-173").let { assertEquals("data.items.stats", it.name); assertEquals(-13, it.begin); assertEquals(-173, it.end) }
    }

    @Test
    fun endCodesAreHex() {
        val spec = parser.parseLength("!FFFF") as LengthSpec.EndCode
        assertEquals(listOf(0xFF, 0xFF), spec.code.map { it.toInt() and 0xFF })
        assertEquals(listOf(0x00), (parser.parseLength("!00") as LengthSpec.EndCode).code.map { it.toInt() })
        assertTrue(parser.parseLength("!F") is LengthSpec.Unsupported)
        assertTrue(parser.parseLength("!") is LengthSpec.Unsupported)
        assertTrue(parser.parseLength("!XY") is LengthSpec.Unsupported)
    }

    @Test
    fun nestedTablesCanTakeTheirCountFromAField() {
        assertEquals("count", (parser.parseLength("/count") as LengthSpec.FromField).field)
        assertTrue(parser.parseLength("/") is LengthSpec.Unsupported)
    }

    @Test
    fun formsTheAppCannotEvaluateAreMarked() {
        assertTrue(parser.parseLength("?tilemap") is LengthSpec.Unsupported)
        assertTrue(parser.parseLength("names-1-2-3") is LengthSpec.Unsupported)
    }

    // ---- errors ----

    @Test
    fun brokenFormatsAreRejected() {
        rejects("a. b.")
        rejects("[a. b.")
        rejects("]a.[")
        rejects("[]")
        rejects("[name\"\"0]")
        rejects("[name\"\"2000]")
        rejects("[. b.]")
        rejects("[a. ??]")
    }

    @Test
    fun everyFieldOfAFormatHasAUniqueSlotInTheRow() {
        val s = schema("[a. b: c<\"\"> d\"\"4 e|b[]nine f::]")
        var end = 0
        for (field in s.fields) {
            assertEquals(end, field.offset)
            end += field.size
        }
        assertEquals(end, s.rowSize)
        assertNotNull(s.field("c"))
        assertNull(s.field("zzz"))
    }
}
