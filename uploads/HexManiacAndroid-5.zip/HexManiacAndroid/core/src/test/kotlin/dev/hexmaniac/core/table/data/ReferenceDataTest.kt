package dev.hexmaniac.core.table.data

import dev.hexmaniac.core.io.ClasspathResources
import dev.hexmaniac.core.table.format.FormatException
import dev.hexmaniac.core.table.format.FormatParser
import dev.hexmaniac.core.table.format.LengthSpec
import dev.hexmaniac.core.table.format.PointerKind
import dev.hexmaniac.core.table.format.TableFormat
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** The reference files that ship with the app, checked as a whole for every game they cover. */
class ReferenceDataTest {
    private val library = ReferenceLibrary(ClasspathResources())
    private val games = listOf("AXVE0", "AXPE0", "AXVE1", "AXPE1", "BPRE0", "BPGE0", "BPRE1", "BPGE1", "BPEE0")

    private fun isTable(format: String) = format.trimStart('^').startsWith("[")

    @Test
    fun everyEnglishGameHasData() {
        for (game in games) {
            assertTrue(game, library.supports(game))
            val data = library.load(game)
            assertFalse(game, data.isEmpty)
            assertTrue("$game tables", data.tables.size > 100)
            assertTrue("$game constants", data.constants.isNotEmpty())
            assertTrue("$game lists", data.metadata.lists.size > 20)
            assertTrue("$game groups", data.metadata.groups.isNotEmpty())
        }
    }

    @Test
    fun gamesWithoutDataAreNotSupported() {
        assertFalse(library.supports("BPRF0"))
        assertFalse(library.supports("BPRI0"))
        assertFalse(library.supports("XXXX0"))
        assertTrue(library.load("XXXX0").isEmpty)
    }

    @Test
    fun everyTableFormatParses() {
        val problems = ArrayList<String>()
        for (game in games) {
            val data = library.load(game)
            val parser = FormatParser { 8 }
            for (table in data.tables) {
                if (!isTable(table.format)) continue
                try {
                    nestedProblems(game, table.name, parser.parse(table.format), problems)
                } catch (e: FormatException) {
                    problems.add("$game ${table.name}: ${e.message}")
                }
            }
        }
        assertEquals(emptyList<String>(), problems.distinct())
    }

    private fun nestedProblems(game: String, name: String, format: TableFormat, into: MutableList<String>) {
        for (field in format.schema.fields) {
            val pointer = field.pointer ?: continue
            if (pointer.kind != PointerKind.TABLE) continue
            val nested = pointer.table
            if (nested == null) into.add("$game $name.${field.name}: nested format ${pointer.inner} does not parse") else nestedProblems(game, name, nested, into)
        }
    }

    @Test
    fun everyNameAFormatUsesIsKnown() {
        val unknown = java.util.TreeSet<String>()
        for (game in games) {
            val data = library.load(game)
            val known = HashSet<String>()
            data.tables.mapTo(known) { it.name }
            data.metadata.anchors.mapTo(known) { it.name }
            data.metadata.lists.mapTo(known) { it.name }
            data.constants.mapTo(known) { it.name }
            val parser = FormatParser { 8 }
            for (table in data.tables) {
                if (!isTable(table.format)) continue
                val names = HashSet<String>()
                referencedNames(parser.parse(table.format), names)
                for (name in names) if (name !in known) unknown.add("$game ${table.name} -> $name")
            }
        }
        assertEquals(KNOWN_GAPS, unknown.toList())
    }

    /** The reference data names something that does not exist; harmless, the value is then shown as a number. */
    private val KNOWN_GAPS = listOf("BPEE0 data.battlefrontier.battletent.fallarbor.trainers -> battlefrontier.pokemon")

    private fun referencedNames(format: TableFormat, into: MutableSet<String>) {
        (format.length as? LengthSpec.FromName)?.let { into.add(it.name) }
        for (field in format.schema.fields) {
            field.enumName?.let { if (it.toIntOrNull() == null) into.add(it) }
            field.bitSource?.let { into.add(it) }
            field.record?.cases?.values?.forEach { if (!it.startsWith("<") && it.toIntOrNull() == null) into.add(it) }
            field.pointer?.table?.let { referencedNames(it, into) }
        }
    }

    @Test
    fun listsAndGroupsAreRead() {
        val data = library.load("BPRE0")
        assertNotNull(data.metadata.groups.firstOrNull { it.name == "Pokemon" })
        assertTrue(data.metadata.lists.any { it.name == "genderratiovalues" })
    }

    @Test
    fun fireRedAndLeafGreenShareMostTables() {
        val fire = library.load("BPRE0").tables.map { it.name }.toSet()
        val leaf = library.load("BPGE0").tables.map { it.name }.toSet()
        assertTrue(fire.intersect(leaf).size > 100)
    }

    @Test
    fun tablePointersAreKnownForEveryGame() {
        for (game in games) {
            val data = library.load(game)
            assertTrue("$game stats", data.tables.any { it.name == "data.pokemon.stats" })
            assertTrue("$game names", data.tables.any { it.name == "data.pokemon.names" })
        }
    }
}
