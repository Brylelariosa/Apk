package dev.hexmaniac.core.graphics

import java.io.ByteArrayOutputStream

/** A plain greedy compressor for the tests: it writes the streams that [Lz77] reads. */
internal object TestLz77 {
    fun compress(data: ByteArray): ByteArray {
        val items = ArrayList<ByteArray>()
        val references = ArrayList<Boolean>()
        var i = 0
        while (i < data.size) {
            var bestLength = 0
            var bestDistance = 0
            for (distance in 1..minOf(4096, i)) {
                var length = 0
                while (length < 18 && i + length < data.size && data[i + length - distance] == data[i + length]) length++
                if (length > bestLength) {
                    bestLength = length
                    bestDistance = distance
                }
            }
            if (bestLength >= 3) {
                val back = bestDistance - 1
                items.add(byteArrayOf((((bestLength - 3) shl 4) or (back shr 8)).toByte(), back.toByte()))
                references.add(true)
                i += bestLength
            } else {
                items.add(byteArrayOf(data[i]))
                references.add(false)
                i++
            }
        }

        val out = ByteArrayOutputStream()
        out.write(0x10)
        out.write(data.size and 0xFF)
        out.write((data.size shr 8) and 0xFF)
        out.write((data.size shr 16) and 0xFF)
        var group = 0
        while (group < items.size) {
            var flags = 0
            for (k in 0 until 8) if (group + k < items.size && references[group + k]) flags = flags or (0x80 shr k)
            out.write(flags)
            for (k in 0 until 8) if (group + k < items.size) out.write(items[group + k])
            group += 8
        }
        return out.toByteArray()
    }
}
