package dev.hexmaniac.core.graphics

import java.util.Random
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class Lz77Test {
    private fun bytes(vararg values: Int) = ByteArray(values.size) { values[it].toByte() }

    @Test
    fun literalsAreCopiedAsTheyAre() {
        val stream = bytes(0x10, 0x05, 0x00, 0x00, 0x00, 1, 2, 3, 4, 5)
        assertArrayEquals(bytes(1, 2, 3, 4, 5), Lz77.decompress(stream, 0))
    }

    @Test
    fun aReferenceCopiesEarlierBytes() {
        // A, B, then 6 bytes copied from 2 back
        val stream = bytes(0x10, 0x08, 0x00, 0x00, 0x20, 0x41, 0x42, 0x30, 0x01)
        assertArrayEquals("ABABABAB".toByteArray(), Lz77.decompress(stream, 0))
    }

    @Test
    fun aReferenceMayOverlapItsOwnOutput() {
        // A, then 7 bytes copied from 1 back
        val stream = bytes(0x10, 0x08, 0x00, 0x00, 0x40, 0x41, 0x40, 0x00)
        assertArrayEquals("AAAAAAAA".toByteArray(), Lz77.decompress(stream, 0))
    }

    @Test
    fun theLongestReferenceReachesFarBack() {
        val data = ByteArray(0x1100) { (it * 7 + (it shr 8)).toByte() }
        for (i in 0x1000 until 0x1012) data[i] = data[i - 0x1000]
        assertArrayEquals(data, Lz77.decompress(TestLz77.compress(data), 0))
    }

    @Test
    fun aRunThatIsLongerThanTheResultIsCut() {
        val stream = bytes(0x10, 0x05, 0x00, 0x00, 0x20, 0x41, 0x42, 0x30, 0x01)
        assertArrayEquals("ABABA".toByteArray(), Lz77.decompress(stream, 0))
    }

    @Test
    fun flagBitsAfterTheLastItemAreIgnored() {
        val stream = bytes(0x10, 0x01, 0x00, 0x00, 0x7F, 0x55)
        assertArrayEquals(bytes(0x55), Lz77.decompress(stream, 0))
    }

    @Test
    fun theStreamMayStartAnywhere() {
        val packed = TestLz77.compress("HELLO HELLO HELLO".toByteArray())
        val rom = ByteArray(7) + packed + ByteArray(5)
        assertArrayEquals("HELLO HELLO HELLO".toByteArray(), Lz77.decompress(rom, 7))
    }

    @Test
    fun compressedRandomAndRepetitiveDataComesBackUnchanged() {
        val random = Random(42)
        for (size in intArrayOf(1, 2, 7, 8, 9, 63, 64, 65, 1000, 4097, 9000)) {
            val noise = ByteArray(size).also { random.nextBytes(it) }
            assertArrayEquals("noise $size", noise, Lz77.decompress(TestLz77.compress(noise), 0))

            val pattern = ByteArray(size) { ((it / 3) % 5).toByte() }
            assertArrayEquals("pattern $size", pattern, Lz77.decompress(TestLz77.compress(pattern), 0))
        }
    }

    @Test
    fun aStreamThatIsNotCompressedDataIsRefused() {
        assertNull(Lz77.decompress(bytes(0x11, 0x01, 0x00, 0x00, 0x00, 0x55), 0))
        assertNull(Lz77.decompress(bytes(0x00, 0x01, 0x00, 0x00, 0x00, 0x55), 0))
        assertNull(Lz77.decompress(ByteArray(8) { 0xFF.toByte() }, 0))
    }

    @Test
    fun aSizeOfZeroOrAnAbsurdSizeIsRefused() {
        assertNull(Lz77.decompress(bytes(0x10, 0x00, 0x00, 0x00, 0x00), 0))
        assertNull(Lz77.decompress(bytes(0x10, 0xFF, 0xFF, 0xFF, 0x00, 1, 2, 3), 0))
        assertNull(Lz77.decompress(bytes(0x10, 0x01, 0x00, 0x04, 0x00, 1), 0)) // 0x040001 is just over the limit
        assertNotNull(Lz77.decompress(TestLz77.compress(ByteArray(Lz77.MAX_SIZE)), 0))
    }

    @Test
    fun aReferenceToBytesBeforeTheStartIsRefused() {
        assertNull(Lz77.decompress(bytes(0x10, 0x08, 0x00, 0x00, 0x80, 0x30, 0x01), 0))
        assertNull(Lz77.decompress(bytes(0x10, 0x08, 0x00, 0x00, 0x40, 0x41, 0x30, 0x05), 0))
    }

    @Test
    fun aStreamThatEndsTooEarlyIsRefused() {
        assertNull(Lz77.decompress(bytes(0x10, 0x05, 0x00, 0x00, 0x00, 1, 2, 3), 0))
        assertNull(Lz77.decompress(bytes(0x10, 0x05, 0x00, 0x00), 0))
        assertNull(Lz77.decompress(bytes(0x10, 0x08, 0x00, 0x00, 0x20, 0x41, 0x42, 0x30), 0))
        assertNull(Lz77.decompress(bytes(0x10, 0x08, 0x00, 0x00, 0x20, 0x41), 0))
    }

    @Test
    fun aStartOutsideTheDataIsRefused() {
        val data = TestLz77.compress("ABCDABCD".toByteArray())
        assertNull(Lz77.decompress(data, -1))
        assertNull(Lz77.decompress(data, data.size))
        assertNull(Lz77.decompress(data, data.size - 3))
        assertNull(Lz77.decompress(ByteArray(0), 0))
    }
}
