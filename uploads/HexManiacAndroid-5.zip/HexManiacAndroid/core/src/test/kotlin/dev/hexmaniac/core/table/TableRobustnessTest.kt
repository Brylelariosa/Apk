package dev.hexmaniac.core.table

import dev.hexmaniac.core.io.ClasspathResources
import dev.hexmaniac.core.rom.RomData
import dev.hexmaniac.core.table.data.GameData
import dev.hexmaniac.core.table.data.ReferenceLibrary
import dev.hexmaniac.core.text.PcsTable
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Random

/**
 * Real ROMs are full of surprises. These tests point every table of every game at random bytes and make sure the
 * engine copes: no exceptions, no endless loops, nothing absurdly slow.
 */
class TableRobustnessTest {
    private val library = ReferenceLibrary(ClasspathResources())
    private val games = listOf("AXVE0", "AXPE0", "AXVE1", "AXPE1", "BPRE0", "BPGE0", "BPRE1", "BPGE1", "BPEE0")

    /** Random data in which every table pointer of the game is valid and every constant is some number. */
    private fun junkRom(data: GameData, seed: Long, fill: Int): RomData {
        val random = Random(seed)
        val size = 0x800000
        val bytes = ByteArray(size)
        if (fill < 0) random.nextBytes(bytes) else java.util.Arrays.fill(bytes, fill.toByte())
        for (table in data.tables) {
            val start = 0x200000 + random.nextInt(0x500000) / 4 * 4
            val word = 0x08000000L + start + table.offset
            for (i in 0 until 4) bytes[table.pointerAddress + i] = (word ushr (8 * i)).toByte()
        }
        return RomData(bytes)
    }

    private class Visit(val tables: Set<String>) {
        var rows = 0
        var fields = 0
        var edits = 0
    }

    private fun walk(tables: TableSet, table: TableLocation, depth: Int, visit: Visit) {
        for (row in 0 until minOf(table.rowCount, ROWS_PER_TABLE)) {
            tables.rowLabel(table, row)
            tables.preview(table, row)
            visit.rows++
            for (view in tables.fields(table, row)) {
                visit.fields++
                tables.editorFor(table, row, view.index)
                tables.editorFor(table, row, view.index, asAddress = true)
                tables.setNumber(table, row, view.index, 0)
                tables.setText(table, row, view.index, "A")
                tables.setAddress(table, row, view.index, "")
                tables.setBits(table, row, view.index, setOf(0, 1, 99))
                tables.setColor(table, row, view.index, "#102030")
                visit.edits += 5
                val opens = view.opens
                if (opens != null && depth < MAX_DEPTH) {
                    val child = tables.locate(opens) ?: error("a nested table that was offered cannot be found: $opens")
                    walk(tables, child, depth + 1, visit)
                }
            }
        }
    }

    private fun exercise(game: String, seed: Long, fill: Int) {
        val data = library.load(game)
        val tables = TableSet(junkRom(data, seed, fill), PcsTable.DEFAULT, game, data)
        val visit = Visit(emptySet())
        val sections = tables.sections()
        for (entry in sections.flatMap { it.tables }) {
            val table = tables.locate(TablePath(entry.name)) ?: error("${entry.name} is listed but cannot be found")
            assertTrue("${entry.name} has rows", table.rowCount >= 1)
            assertTrue("${entry.name} fits", table.end <= 0x800000)
            walk(tables, table, 0, visit)
        }
        assertTrue("$game: some tables are found", sections.sumOf { it.tables.size } > 50)
        assertTrue(visit.rows > 100)
    }

    @Test(timeout = 240_000)
    fun randomBytesNeverBreakTheEngine() {
        for (game in games) exercise(game, 17L, -1)
    }

    @Test(timeout = 240_000)
    fun erasedRomsNeverBreakTheEngine() {
        for (game in games) exercise(game, 5L, 0xFF)
    }

    @Test(timeout = 240_000)
    fun zeroedRomsNeverBreakTheEngine() {
        for (game in games) exercise(game, 9L, 0x00)
    }

    @Test(timeout = 60_000)
    fun theFirstListingIsQuick() {
        val data = library.load("BPRE0")
        val tables = TableSet(junkRom(data, 3L, -1), PcsTable.DEFAULT, "BPRE0", data)
        val started = System.nanoTime()
        tables.sections()
        val millis = (System.nanoTime() - started) / 1_000_000
        println("sections() on a junk FireRed ROM: $millis ms")
        assertTrue("took $millis ms", millis < 20_000)
    }

    private companion object {
        const val ROWS_PER_TABLE = 12
        const val MAX_DEPTH = 3
    }
}
