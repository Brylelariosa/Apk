package dev.hexmaniac.core.rom

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Test

class PointerSearchTest {
    private fun rom(size: Int, vararg pointers: Pair<Int, Long>): RomData {
        val bytes = ByteArray(size)
        for ((at, word) in pointers) for (i in 0 until 4) bytes[at + i] = (word ushr (8 * i)).toByte()
        return RomData(bytes)
    }

    @Test
    fun findsEveryWordAlignedPointerThatLeadsIntoTheRange() {
        val rom = rom(0x100, 0x00 to 0x08000040L, 0x10 to 0x08000044L, 0x20 to 0x08000048L, 0x30 to 0x08000040L)
        val hits = PointerSearch.leadingTo(rom, 0x40, 0x48)
        assertArrayEquals(intArrayOf(0x00, 0x10, 0x30), hits.sources)
        assertArrayEquals(intArrayOf(0x40, 0x44, 0x40), hits.targets)
        assertEquals(3, hits.size)
    }

    @Test
    fun theEndOfTheRangeIsNotIncluded() {
        val rom = rom(0x100, 0x00 to 0x08000047L, 0x04 to 0x08000048L)
        assertArrayEquals(intArrayOf(0x00), PointerSearch.leadingTo(rom, 0x40, 0x48).sources)
    }

    @Test
    fun wordsThatAreNotAlignedOrNotPointersAreIgnored() {
        val rom = rom(
            0x100,
            0x01 to 0x08000040L, // not on a word boundary
            0x08 to 0x0A000040L, // another memory region
            0x0C to 0x07000040L,
            0x10 to 0x00000040L,
        )
        assertEquals(0, PointerSearch.leadingTo(rom, 0x40, 0x41).size)
    }

    @Test
    fun theUpperHalfOfTheRomWindowCountsToo() {
        val rom = rom(0x20, 0x04 to 0x09000010L)
        val hits = PointerSearch.leadingTo(rom, 0x1000010, 0x1000011)
        assertArrayEquals(intArrayOf(0x04), hits.sources)
        assertArrayEquals(intArrayOf(0x1000010), hits.targets)
    }

    @Test
    fun theLastWordOfTheImageIsLookedAt() {
        val rom = rom(8, 0x04 to 0x08000000L)
        assertArrayEquals(intArrayOf(0x04), PointerSearch.leadingTo(rom, 0, 1).sources)
    }

    @Test
    fun manyHitsAreAllReturned() {
        val pointers = (0 until 100).map { it * 4 to 0x08000010L }.toTypedArray()
        val rom = rom(0x400, *pointers)
        assertEquals(100, PointerSearch.leadingTo(rom, 0x10, 0x11).size)
    }

    @Test
    fun anEmptyOrBackwardsRangeFindsNothing() {
        val rom = rom(0x20, 0x00 to 0x08000010L)
        assertEquals(0, PointerSearch.leadingTo(rom, 0x10, 0x10).size)
        assertEquals(0, PointerSearch.leadingTo(rom, 0x20, 0x10).size)
    }
}
