package dev.hexmaniac.core.table

import dev.hexmaniac.core.rom.RomData
import dev.hexmaniac.core.table.data.GameData
import dev.hexmaniac.core.text.PcsTable

/**
 * Builds a ROM image that looks like a small FireRed 1.0 (BPRE0) to the table engine: the header names the game,
 * and the pointers the reference data expects lead to tables that the tests lay out.
 */
class FakeRom(private val data: GameData, size: Int = 0x500000) {
    val bytes = ByteArray(size) { 0xFF.toByte() }
    private val pcs = PcsTable.DEFAULT

    init {
        for (i in 0xA0 until 0xC0) bytes[i] = 0
        ascii(0xA0, "POKEMON FIRE")
        ascii(0xAC, "BPRE")
        ascii(0xB0, "01")
    }

    private fun ascii(at: Int, text: String) {
        for (i in text.indices) bytes[at + i] = text[i].code.toByte()
    }

    fun u8(at: Int, value: Int) {
        bytes[at] = value.toByte()
    }

    fun u16(at: Int, value: Int) {
        for (i in 0 until 2) bytes[at + i] = (value ushr (8 * i)).toByte()
    }

    fun u32(at: Int, value: Long) {
        for (i in 0 until 4) bytes[at + i] = (value ushr (8 * i)).toByte()
    }

    fun pointer(at: Int, target: Int) = u32(at, 0x08000000L + target)

    /** Makes the game's pointer to [table] lead to [start]. */
    fun place(table: String, start: Int) {
        val definition = data.tables.last { it.name == table }
        pointer(definition.pointerAddress, start + definition.offset)
    }

    /** Stores [value] wherever the game keeps the constant called [name]. */
    fun constant(name: String, value: Int) {
        for (c in data.constants.filter { it.name == name }) {
            for (address in c.addresses) {
                if (address + c.size > bytes.size) continue
                val raw = value * c.multiplier + c.addOffset
                for (i in 0 until c.size) bytes[address + i] = (raw ushr (8 * i)).toByte()
            }
        }
    }

    /** Text of exactly [size] bytes: the encoded text with its end mark, then zeros. */
    fun fixedText(at: Int, text: String, size: Int) {
        val encoded = pcs.encode(text).bytes
        for (i in 0 until size) bytes[at + i] = 0
        System.arraycopy(encoded, 0, bytes, at, minOf(encoded.size, size))
    }

    /** Text with its end mark and nothing else; returns the number of bytes used. */
    fun text(at: Int, text: String): Int {
        val encoded = pcs.encode(text).bytes
        System.arraycopy(encoded, 0, bytes, at, encoded.size)
        return encoded.size
    }

    fun toRom() = RomData(bytes.copyOf())
}
