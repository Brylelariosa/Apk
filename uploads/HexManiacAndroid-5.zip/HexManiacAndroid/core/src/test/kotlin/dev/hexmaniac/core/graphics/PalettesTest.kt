package dev.hexmaniac.core.graphics

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PalettesTest {
    @Test
    fun theChannelsAreRedInTheLowBitsThenGreenThenBlue() {
        assertEquals(0xFF000000.toInt(), Palettes.argb(0))
        assertEquals(0xFFFFFFFF.toInt(), Palettes.argb(0x7FFF))
        assertEquals(0xFFFF0000.toInt(), Palettes.argb(0x001F))
        assertEquals(0xFF00FF00.toInt(), Palettes.argb(0x03E0))
        assertEquals(0xFF0000FF.toInt(), Palettes.argb(0x7C00))
    }

    @Test
    fun fiveBitsAreSpreadOverTheWholeRange() {
        assertEquals(0xFF838383.toInt(), Palettes.argb(16 or (16 shl 5) or (16 shl 10)))
        assertEquals(0xFF080808.toInt(), Palettes.argb(1 or (1 shl 5) or (1 shl 10)))
    }

    @Test
    fun theTopBitIsIgnored() {
        assertEquals(Palettes.argb(0x7FFF), Palettes.argb(0xFFFF))
    }

    @Test
    fun coloursAreReadFromBytes() {
        val data = byteArrayOf(0, 0, 0x1F, 0x00, 0xE0.toByte(), 0x03)
        val colors = Palettes.read(data, 0, 3)
        assertEquals(0xFF000000.toInt(), colors[0])
        assertEquals(0xFFFF0000.toInt(), colors[1])
        assertEquals(0xFF00FF00.toInt(), colors[2])
        assertEquals(0xFF00FF00.toInt(), Palettes.read(data, 4, 1)[0])
    }

    @Test
    fun coloursBeyondTheDataAreBlack() {
        val data = byteArrayOf(0x1F, 0x00, 0x1F)
        val colors = Palettes.read(data, 0, 3)
        assertEquals(0xFFFF0000.toInt(), colors[0])
        assertEquals(Palettes.BLACK, colors[1])
        assertEquals(Palettes.BLACK, colors[2])
        assertEquals(Palettes.BLACK, Palettes.read(data, -4, 1)[0])
        assertEquals(Palettes.BLACK, Palettes.read(data, 99, 1)[0])
    }

    @Test
    fun theGreyRampGoesFromBlackToWhite() {
        val ramp = Palettes.grey(16)
        assertEquals(16, ramp.size)
        assertEquals(0xFF000000.toInt(), ramp.first())
        assertEquals(0xFFFFFFFF.toInt(), ramp.last())
        for (i in 1 until ramp.size) assertTrue(ramp[i] and 0xFF > ramp[i - 1] and 0xFF)
        assertEquals(Palettes.BLACK, Palettes.grey(1)[0])
    }
}
