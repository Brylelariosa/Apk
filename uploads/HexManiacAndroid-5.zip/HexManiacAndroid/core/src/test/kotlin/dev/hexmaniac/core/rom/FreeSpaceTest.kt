package dev.hexmaniac.core.rom

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class FreeSpaceTest {
    private fun rom(size: Int, vararg used: Int): RomData {
        val bytes = ByteArray(size) { 0xFF.toByte() }
        for (at in used) bytes[at] = 0x11
        return RomData(bytes)
    }

    @Test
    fun theFreeSpaceAtTheEndStartsAfterTheLastByteThatIsNotFree() {
        assertEquals(0, FreeSpace.tailStart(rom(0x100)))
        assertEquals(0x301, FreeSpace.tailStart(rom(0x1000, 0x10, 0x300)))
        assertEquals(0x1000, FreeSpace.tailStart(rom(0x1000, 0xFFF)))
    }

    @Test
    fun newDataGoesAfterTheLastDataWithAGapAndOnAWordBoundary() {
        val spot = FreeSpace.find(rom(0x4000, 0x2FF), 0x10)!!
        assertEquals(0x340, spot.offset)
        assertEquals(0x4000, spot.romSize)

        val shifted = FreeSpace.find(rom(0x4000, 0x300), 0x10)!!
        assertEquals(0x344, shifted.offset)
    }

    @Test
    fun theGapCanBeChosen() {
        val spot = FreeSpace.find(rom(0x4000, 0x2FF), 0x10, gap = 0x10)!!
        assertEquals(0x310, spot.offset)
    }

    @Test
    fun dataNeverGoesIntoTheHeaderOfAnAlmostEmptyRom() {
        assertEquals(0x240, FreeSpace.find(rom(0x4000), 8)!!.offset)
    }

    @Test
    fun theRomGrowsWhenTheEndIsTooSmall() {
        val full = rom(0x1000, 0xFFF)
        val spot = FreeSpace.find(full, 0x20)!!
        assertEquals(0x1040, spot.offset)
        assertEquals(0x2000, spot.romSize)

        val nearlyFull = rom(0x1000, 0xFF0)
        val second = FreeSpace.find(nearlyFull, 0x100)!!
        assertEquals(0x1034, second.offset)
        assertEquals(0x2000, second.romSize)
    }

    @Test
    fun theRomGrowsByWholeSteps() {
        val spot = FreeSpace.find(rom(0x1000, 0xFFF), 0x1000)!!
        assertEquals(0x1040, spot.offset)
        assertEquals(0x3000, spot.romSize)
    }

    @Test
    fun aRomThatCannotGrowAnyMoreLooksForFreeRunsInsideIt() {
        val size = FreeSpace.MAX_ROM_SIZE
        val bytes = ByteArray(size) // all zeros: nothing is free
        for (i in 0x10000 until 0x10400) bytes[i] = 0xFF.toByte()
        for (i in 0x20000 until 0x20100) bytes[i] = 0xFF.toByte()
        val spot = FreeSpace.find(RomData(bytes), 0x100)!!
        // the short run at 0x20000 is skipped: it has no room for the data and its gaps
        assertEquals(0x10040, spot.offset)
        assertEquals(size, spot.romSize)

        assertNull(FreeSpace.find(RomData(bytes), 0x400))
    }

    @Test
    fun theFreeSpaceInsideIsNeverSearchedBeforeTheEndOfTheImageIsFull() {
        val bytes = ByteArray(0x100000)
        for (i in 0x10000 until 0x20000) bytes[i] = 0xFF.toByte() // a big run in the middle ...
        bytes[0xFFFFF] = 0x22 // ... but the end of the image is in use
        val spot = FreeSpace.find(RomData(bytes), 0x100)!!
        // growing is preferred to using a run that may belong to some other data
        assertEquals(0x100040, spot.offset)
        assertNotNull(spot)
    }

    @Test(expected = IllegalArgumentException::class)
    fun nothingCanBePlacedWithoutALength() {
        FreeSpace.find(rom(0x1000), 0)
    }
}
