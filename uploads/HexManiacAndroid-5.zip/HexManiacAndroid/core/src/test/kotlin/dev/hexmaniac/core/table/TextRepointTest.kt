package dev.hexmaniac.core.table

import dev.hexmaniac.core.io.ClasspathResources
import dev.hexmaniac.core.rom.FreeSpace
import dev.hexmaniac.core.rom.PointerSearch
import dev.hexmaniac.core.rom.RomDocument
import dev.hexmaniac.core.table.data.GameData
import dev.hexmaniac.core.table.data.ReferenceLibrary
import dev.hexmaniac.core.text.PcsTable
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Editing text that a pointer leads to: it stays where it is when it fits, and moves to free space, with every pointer
 * following, when it does not. The ROM has two ability descriptions packed one behind the other and some data right
 * behind them, so neither can grow in place at first.
 */
class TextRepointTest {
    private val abilityNames = 0x100500
    private val descriptions = 0x100580
    private val textA = 0x101100
    private val textB = 0x10110B // "No ability" takes 11 bytes
    private val marker = 0x10111A // "May scare foes" takes 15 bytes; something else starts right behind it

    private lateinit var data: GameData
    private lateinit var original: ByteArray
    private lateinit var document: RomDocument
    private lateinit var tables: TableSet

    private val pcs = PcsTable.DEFAULT

    private fun open(size: Int = 0x500000, tweak: (FakeRom) -> Unit = {}) {
        data = library.load("BPRE0")
        val fake = FakeRom(data, size)
        fake.place("data.abilities.names", abilityNames)
        fake.fixedText(abilityNames, "-------", 13)
        fake.fixedText(abilityNames + 13, "STENCH", 13)
        fake.place("data.abilities.descriptions", descriptions)
        fake.pointer(descriptions, textA)
        fake.pointer(descriptions + 4, textB)
        assertEquals(11, fake.text(textA, "No ability"))
        assertEquals(15, fake.text(textB, "May scare foes"))
        fake.u32(marker, 0x78563412)
        tweak(fake)
        original = fake.bytes.copyOf()
        document = RomDocument("test.gba", fake.bytes)
        tables = TableSet(document.rom, pcs, "BPRE0", data)
    }

    private fun texts(): TableLocation = tables.locate(TablePath("data.abilities.descriptions")) ?: error("no table")

    private fun view(row: Int) = tables.field(texts(), row, 0)

    private fun ready(result: EditResult): EditResult.Ready = result as? EditResult.Ready ?: error("rejected: ${(result as EditResult.Rejected).message}")

    private fun apply(result: EditResult): String? {
        val ready = ready(result)
        ready.plan.applyTo(document)
        tables.invalidate()
        return ready.notice
    }

    private fun edit(row: Int, text: String): String? = apply(tables.setText(texts(), row, 0, text))

    private fun bytes(offset: Int, length: Int): List<Int> = document.rom.copyRange(offset, length).map { it.toInt() and 0xFF }

    private fun assertFree(offset: Int, length: Int) = assertEquals(List(length) { 0xFF }, bytes(offset, length))

    // ---- text that fits ----

    @Test
    fun textThatFitsStaysWhereItIsAndFreesWhatItNoLongerNeeds() {
        open()
        assertNull(edit(1, "Scares"))
        assertEquals("Scares", view(1).text)
        assertEquals(textB, view(1).target)
        assertFree(textB + 7, 8)
        assertEquals(0x78563412, document.rom.readWord(marker))
    }

    @Test
    fun textGrowsBackIntoTheBytesItGaveUp() {
        open()
        edit(1, "Scares")
        val editor = tables.editorFor(texts(), 1, 0) as FieldEditor.PointedText
        assertEquals(15, editor.capacity)
        edit(1, "May scare foes")
        assertEquals("May scare foes", view(1).text)
        assertEquals(textB, view(1).target)
        assertEquals(2, document.undoSteps())
    }

    @Test
    fun textDoesNotGrowIntoFreeBytesThatAnotherPointerLeadsTo() {
        open()
        edit(1, "Scares")
        assertEquals(15, (tables.editorFor(texts(), 1, 0) as FieldEditor.PointedText).capacity)
        // Something now points into the free bytes behind "Scares": they are not available any more from there on.
        document.write(0x2000, Values.toBytes(Values.POINTER_BASE + textB + 9, 4))
        tables.invalidate()
        assertEquals(9, (tables.editorFor(texts(), 1, 0) as FieldEditor.PointedText).capacity)
        val longer = ready(tables.setText(texts(), 1, 0, "May scare foes"))
        assertTrue(longer.notice!!.startsWith("Moved to free space"))
    }

    @Test
    fun capacityOfTextWithNothingFreeBehindItIsItsOwnLength() {
        open()
        assertEquals(11, (tables.editorFor(texts(), 0, 0) as FieldEditor.PointedText).capacity)
        assertEquals(15, (tables.editorFor(texts(), 1, 0) as FieldEditor.PointedText).capacity)
    }

    // ---- text that does not fit ----

    @Test
    fun longerTextMovesToFreeSpaceAndItsPointerFollows() {
        open()
        val text = "A much longer description than before"
        val encoded = pcs.encode(text).bytes
        val expected = FreeSpace.find(document.rom, encoded.size)!!.offset

        val notice = edit(1, text)

        assertEquals(text, view(1).text)
        assertEquals(expected, view(1).target)
        assertTrue(expected > marker)
        assertEquals("No ability", view(0).text)
        assertFree(textB, 15)
        assertEquals(0x78563412, document.rom.readWord(marker))
        assertTrue(notice!!.contains("Moved to free space at ${"%06X".format(expected)}"))
        assertTrue(notice.contains("1 pointer updated"))
    }

    @Test
    fun movingTextIsOneUndoStep() {
        open()
        edit(1, "A much longer description than before")
        assertEquals(1, document.undoSteps())
        document.undo()
        assertArrayEquals(original, document.rom.bytes)
        assertTrue(document.redo())
        tables.invalidate()
        assertEquals("A much longer description than before", view(1).text)
    }

    @Test
    fun everyPointerToMovedTextFollows() {
        open {
            it.pointer(0x2000, textB)
            it.pointer(0x3004, textB)
        }
        val notice = edit(1, "A much longer description than before")
        val moved = view(1).target
        assertTrue(moved > marker)
        assertEquals(moved, document.rom.pointerTarget(0x2000))
        assertEquals(moved, document.rom.pointerTarget(0x3004))
        assertEquals(3, PointerSearch.leadingTo(document.rom, moved, moved + 1).size)
        assertTrue(notice!!.contains("3 pointers updated"))
        assertEquals(0, PointerSearch.leadingTo(document.rom, textB, textB + 1).size)
    }

    @Test
    fun textThatSeveralPointersShareChangesForAllOfThemInPlace() {
        open { it.pointer(0x2000, textB) }
        val notice = edit(1, "Scares")
        assertEquals("1 other place uses this text and changed too.", notice)
        assertEquals(textB, document.rom.pointerTarget(0x2000))
    }

    @Test
    fun aPointerIntoTheMiddleOfMovedTextKeepsItsTail() {
        open { it.pointer(0x2000, textB + 4) }
        val tail = bytes(textB + 4, 11)
        edit(1, "A much longer description than before")
        assertTrue(view(1).target > marker)
        assertFree(textB, 4)
        assertEquals(tail, bytes(textB + 4, 11))
        assertEquals(textB + 4, document.rom.pointerTarget(0x2000))
    }

    @Test
    fun theRomGrowsWhenItIsFull() {
        open(size = 0x102000) { it.bytes[0x101FFF] = 0x00 }
        val oldSize = document.rom.size
        val notice = edit(1, "A much longer description than before")
        assertEquals(oldSize + 0x1000, document.rom.size)
        val moved = view(1).target
        assertTrue(moved >= oldSize)
        assertEquals("A much longer description than before", view(1).text)
        assertTrue(notice!!.contains("The ROM grew by 4096 bytes."))
        // everything the text did not use stays free
        val end = moved + pcs.encode("A much longer description than before").bytes.size
        assertFree(end, document.rom.size - end)
        assertFree(oldSize, moved - oldSize)
        document.undo()
        assertEquals(oldSize, document.rom.size)
        assertArrayEquals(original, document.rom.bytes)
    }

    @Test
    fun textThatCannotBePlacedAnywhereIsRejected() {
        open(size = FreeSpace.MAX_ROM_SIZE) {
            // no run of free bytes long enough for text and its gaps is left anywhere
            var i = 0x200 + 0x3B
            while (i < it.bytes.size) {
                if (it.bytes[i] == 0xFF.toByte()) it.bytes[i] = 0x01
                i += 0x40
            }
        }
        val result = tables.setText(texts(), 1, 0, "A much longer description than before")
        assertTrue((result as EditResult.Rejected).message.contains("no free space"))
        assertArrayEquals(original, document.rom.bytes)
    }

    @Test
    fun textLongerThanOneTextCanBeIsRejected() {
        open()
        val result = tables.setText(texts(), 1, 0, "A".repeat(5000))
        assertTrue((result as EditResult.Rejected).message.contains("4096"))
    }

    // ---- empty pointers ----

    @Test
    fun anEmptyPointerTakesNewTextInFreeSpace() {
        open { it.u32(descriptions + 4, 0) }
        val editor = tables.editorFor(texts(), 1, 0) as FieldEditor.PointedText
        assertEquals("", editor.current)
        assertEquals(0, editor.capacity)

        val encoded = pcs.encode("Brand new").bytes
        val expected = FreeSpace.find(document.rom, encoded.size)!!.offset
        val notice = edit(1, "Brand new")
        assertEquals("Brand new", view(1).text)
        assertEquals(expected, view(1).target)
        assertTrue(notice!!.contains("Text placed in free space"))
        assertEquals("No ability", view(0).text)
        document.undo()
        assertArrayEquals(original, document.rom.bytes)
    }

    @Test
    fun anEmptyPointerCanStillBeEditedAsAnAddress() {
        open { it.u32(descriptions + 4, 0) }
        assertTrue(tables.editorFor(texts(), 1, 0, asAddress = true) is FieldEditor.Address)
    }

    @Test
    fun aPointerThatLeadsToNoTextIsEditedAsAnAddress() {
        open {
            it.pointer(descriptions + 4, 0x120000)
            for (i in 0 until 8) it.u8(0x120000 + i, 0x0A) // bytes the character set has no character for
        }
        assertTrue(tables.editorFor(texts(), 1, 0) is FieldEditor.Address)
        val result = tables.setText(texts(), 1, 0, "Anything")
        assertTrue((result as EditResult.Rejected).message.contains("not text"))
    }

    @Test
    fun aPointerOutsideTheRomIsRejectedWithAHint() {
        open { it.u32(descriptions + 4, 0x08FFFFFF) }
        val result = tables.setText(texts(), 1, 0, "Anything")
        assertTrue((result as EditResult.Rejected).message.contains("Set its address"))
    }

    // ---- text that other pointers use ----

    @Test
    fun anEditorSaysHowManyOtherPointersUseTheText() {
        open { it.pointer(0x2000, textB) }
        assertEquals(1, (tables.editorFor(texts(), 1, 0) as FieldEditor.PointedText).sharedBy)
        assertEquals(0, (tables.editorFor(texts(), 0, 0) as FieldEditor.PointedText).sharedBy)
    }

    @Test
    fun aSeparateCopyCanBeChangedWithoutChangingTheOthers() {
        open { it.pointer(0x2000, textB) }
        val notice = apply(tables.copyText(texts(), 1, 0))
        assertTrue(notice!!.startsWith("Text copied to free space at"))
        assertTrue(view(1).target > marker)
        assertEquals("May scare foes", view(1).text)
        assertEquals(textB, document.rom.pointerTarget(0x2000))
        assertEquals(0, (tables.editorFor(texts(), 1, 0) as FieldEditor.PointedText).sharedBy)

        edit(1, "Different")
        assertEquals("Different", view(1).text)
        // the other pointer still reads the original text, which has not been touched
        assertEquals(textB, document.rom.pointerTarget(0x2000))
        assertEquals(pcs.encode("May scare foes").bytes.toList(), document.rom.copyRange(textB, 15).toList())
    }

    @Test
    fun anEmptyTextThatOthersShareIsNotChangedWhenOneOfThemGetsText() {
        val empty = 0x101200
        open {
            it.u8(empty, 0xFF)
            it.u8(empty + 1, 0x12) // data right behind the empty text
            it.pointer(descriptions + 4, empty)
            it.pointer(0x2000, empty)
            it.pointer(0x3000, empty)
        }
        val editor = tables.editorFor(texts(), 1, 0) as FieldEditor.PointedText
        assertEquals("", editor.current)
        assertEquals(0, editor.sharedBy)

        val notice = edit(1, "Mine now")
        assertTrue(notice!!.startsWith("Text placed in free space"))
        assertEquals("Mine now", view(1).text)
        assertTrue(view(1).target > marker)
        assertEquals(empty, document.rom.pointerTarget(0x2000))
        assertEquals(empty, document.rom.pointerTarget(0x3000))
        assertEquals(0xFF, document.rom[empty])
    }

    @Test
    fun onlyTextPointersCanBeCopied() {
        open()
        val names = tables.locate(TablePath("data.abilities.names"))!!
        assertTrue((tables.copyText(names, 0, 0) as EditResult.Rejected).message.contains("not text"))
    }

    @Test
    fun theNoticeOfAnInPlaceEditIsEmptyWhenNothingElseUsesTheText() {
        open()
        val result = ready(tables.setText(texts(), 0, 0, "Nope"))
        assertNull(result.notice)
        assertNotNull(result.plan)
    }

    /** How many undo steps the document has; it is left as it was. */
    private fun RomDocument.undoSteps(): Int {
        var steps = 0
        while (canUndo) {
            undo()
            steps++
        }
        repeat(steps) { redo() }
        return steps
    }

    private companion object {
        val library = ReferenceLibrary(ClasspathResources())
    }
}
