package dev.hexmaniac.core.table

import dev.hexmaniac.core.graphics.TestLz77
import dev.hexmaniac.core.io.ClasspathResources
import dev.hexmaniac.core.rom.RomDocument
import dev.hexmaniac.core.table.data.GameData
import dev.hexmaniac.core.table.data.ReferenceLibrary
import dev.hexmaniac.core.text.PcsTable
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

/** Pictures behind pointers, on a small ROM that is laid out like FireRed 1.0 where the tests need it to be. */
class GraphicsTest {
    private lateinit var data: GameData
    private lateinit var fake: FakeRom
    private lateinit var tables: TableSet

    private val red = 0xFFFF0000.toInt()
    private val green = 0xFF00FF00.toInt()
    private val blue = 0xFF0000FF.toInt()
    private val white = 0xFFFFFFFF.toInt()
    private val black = 0xFF000000.toInt()

    // GBA colours
    private val gbaWhite = 0x7FFF
    private val gbaRed = 0x001F
    private val gbaGreen = 0x03E0
    private val gbaBlue = 0x7C00

    @Before
    fun setUp() {
        data = ReferenceLibrary(ClasspathResources()).load("BPRE0")
        fake = FakeRom(data)
        fake.place("data.pokemon.names", NAMES)
        listOf("?", "BULBASAUR", "IVYSAUR", "VENUSAUR").forEachIndexed { i, n -> fake.fixedText(NAMES + i * 11, n, 11) }
    }

    private fun open() {
        tables = TableSet(RomDocument("test.gba", fake.bytes).rom, PcsTable.DEFAULT, "BPRE0", data)
    }

    private fun table(name: String): TableLocation = tables.locate(TablePath(name)) ?: error("no table $name")

    // ---- building data ----

    /** Picture data of 4 bit pixels, [width] by [height] pixels, with the tiles in the order the GBA stores them. */
    private fun tiles4(width: Int, height: Int, pixel: (Int, Int) -> Int): ByteArray {
        val tilesWide = width / 8
        val out = ByteArray(width * height / 2)
        for (y in 0 until height) {
            for (x in 0 until width) {
                val at = ((y / 8) * tilesWide + x / 8) * 32 + (y % 8) * 4 + (x % 8) / 2
                val value = pixel(x, y) and 0xF
                out[at] = (out[at].toInt() or (if (x % 2 == 0) value else value shl 4)).toByte()
            }
        }
        return out
    }

    private fun colors(vararg values: Int): ByteArray {
        val out = ByteArray(32)
        values.forEachIndexed { i, v ->
            out[i * 2] = v.toByte()
            out[i * 2 + 1] = (v shr 8).toByte()
        }
        return out
    }

    private fun put(at: Int, bytes: ByteArray) = System.arraycopy(bytes, 0, fake.bytes, at, bytes.size)

    private fun putPacked(at: Int, bytes: ByteArray) = put(at, TestLz77.compress(bytes))

    /** A 64 by 64 sprite with a dot of colour 1 in the top left corner and a dot of colour 2 in the bottom right one. */
    private fun dots(width: Int = 64, height: Int = 64) = tiles4(width, height) { x, y ->
        when {
            x == 0 && y == 0 -> 1
            x == width - 1 && y == height - 1 -> 2
            else -> 0
        }
    }

    // ---- sprites of the Pokemon: the palettes sit in tables of the same length ----

    private fun pokemonSprites() {
        fake.place("graphics.pokemon.sprites.front", FRONT)
        fake.place("graphics.pokemon.palettes.normal", NORMAL)
        fake.place("graphics.pokemon.palettes.shiny", SHINY)
        // row 1: the sprite and both palettes
        putPacked(BLOBS, dots())
        fake.pointer(FRONT + 8, BLOBS)
        putPacked(BLOBS + 0x1000, colors(gbaWhite, gbaRed, gbaGreen))
        fake.pointer(NORMAL + 8, BLOBS + 0x1000)
        putPacked(BLOBS + 0x2000, colors(gbaWhite, gbaBlue, gbaGreen))
        fake.pointer(SHINY + 8, BLOBS + 0x2000)
    }

    @Test
    fun aSpriteIsPaintedWithThePaletteOfTheSameRowOfARelatedTable() {
        pokemonSprites()
        open()
        val graphic = tables.graphic(table("graphics.pokemon.sprites.front"), 1, 0)!!
        assertEquals(64, graphic.picture.width)
        assertEquals(64, graphic.picture.height)
        assertEquals(red, graphic.picture.pixels[0])
        assertEquals(white, graphic.picture.pixels[1])
        assertEquals(white, graphic.picture.pixels[64])
        assertEquals(green, graphic.picture.pixels[64 * 64 - 1])
        assertEquals("normal", graphic.palette)
        assertEquals(2, graphic.choices)
        assertEquals(0, graphic.choice)
    }

    @Test
    fun theOtherPaletteCanBeChosen() {
        pokemonSprites()
        open()
        val front = table("graphics.pokemon.sprites.front")
        val shiny = tables.graphic(front, 1, 0, 1)!!
        assertEquals(blue, shiny.picture.pixels[0])
        assertEquals(green, shiny.picture.pixels[64 * 64 - 1])
        assertEquals("shiny", shiny.palette)
        assertEquals(1, shiny.choice)
    }

    @Test
    fun theChoiceWrapsAround() {
        pokemonSprites()
        open()
        val front = table("graphics.pokemon.sprites.front")
        assertEquals(0, tables.graphic(front, 1, 0, 2)!!.choice)
        assertEquals(1, tables.graphic(front, 1, 0, 3)!!.choice)
        assertEquals(1, tables.graphic(front, 1, 0, -1)!!.choice)
        assertEquals(0, tables.graphic(front, 1, 0, -2)!!.choice)
    }

    @Test
    fun aPaletteShowsItsColours() {
        pokemonSprites()
        open()
        val graphic = tables.graphic(table("graphics.pokemon.palettes.normal"), 1, 0)!!
        assertEquals(16, graphic.picture.width)
        assertEquals(1, graphic.picture.height)
        assertEquals(white, graphic.picture.pixels[0])
        assertEquals(red, graphic.picture.pixels[1])
        assertEquals(green, graphic.picture.pixels[2])
        assertEquals(black, graphic.picture.pixels[3])
        assertNull(graphic.palette)
        assertEquals(0, graphic.choices)
    }

    @Test
    fun aSpriteWithoutAPaletteIsDrawnInGrey() {
        pokemonSprites()
        putPacked(BLOBS + 0x3000, dots())
        fake.pointer(FRONT + 16, BLOBS + 0x3000)
        open()
        val graphic = tables.graphic(table("graphics.pokemon.sprites.front"), 2, 0)!!
        assertEquals(0, graphic.choices)
        assertNull(graphic.palette)
        assertEquals(0xFF111111.toInt(), graphic.picture.pixels[0])
        assertEquals(0xFF222222.toInt(), graphic.picture.pixels[64 * 64 - 1])
        assertEquals(black, graphic.picture.pixels[1])
    }

    @Test
    fun aPointerThatDoesNotLeadToPictureDataHasNoPicture() {
        pokemonSprites()
        fake.pointer(FRONT + 24, BLOBS + 0x4000) // only unused bytes there
        open()
        val front = table("graphics.pokemon.sprites.front")
        assertNull(tables.graphic(front, 3, 0))
        assertNull(tables.graphic(front, 0, 0)) // no pointer at all
    }

    @Test
    fun onlyPicturePointersHavePictures() {
        pokemonSprites()
        open()
        val front = table("graphics.pokemon.sprites.front")
        val fields = tables.fields(front, 1)
        assertTrue(fields[0].picture)
        assertFalse(fields[1].picture)
        assertFalse(fields[2].picture)
        assertNull(tables.graphic(front, 1, 1))
        assertFalse(tables.fields(front, 0)[0].picture) // a pointer that leads nowhere
        assertTrue(tables.fields(table("graphics.pokemon.palettes.normal"), 1)[0].picture)
    }

    @Test
    fun rowsAndFieldsThatDoNotExistHaveNoPicture() {
        pokemonSprites()
        open()
        val front = table("graphics.pokemon.sprites.front")
        assertNull(tables.graphic(front, -1, 0))
        assertNull(tables.graphic(front, 999, 0))
        assertNull(tables.graphic(front, 1, 99))
        assertNull(tables.graphic(front, 1, -1))
    }

    @Test
    fun picturesFollowTheRomAfterItChanges() {
        pokemonSprites()
        open()
        val front = table("graphics.pokemon.sprites.front")
        assertEquals(red, tables.graphic(front, 1, 0)!!.picture.pixels[0])
        putPacked(BLOBS + 0x1000, colors(gbaWhite, gbaBlue, gbaGreen))
        open()
        assertEquals(blue, tables.graphic(table("graphics.pokemon.sprites.front"), 1, 0)!!.picture.pixels[0])
    }

    // ---- sprites that name their palette table ----

    @Test
    fun aHintToATablePicksThePaletteOfTheSameRow() {
        fake.place("graphics.trainers.sprites.front", TRAINERS)
        fake.place("graphics.trainers.palettes.front", TRAINER_PALETTES)
        for (row in 4..6) {
            putPacked(BLOBS + row * 0x400, dots())
            fake.pointer(TRAINERS + row * 8, BLOBS + row * 0x400)
            putPacked(BLOBS + 0x4000 + row * 0x40, colors(gbaWhite, intArrayOf(gbaRed, gbaGreen, gbaBlue)[row - 4], gbaWhite))
            fake.pointer(TRAINER_PALETTES + row * 8, BLOBS + 0x4000 + row * 0x40)
        }
        open()
        val sprites = table("graphics.trainers.sprites.front")
        assertEquals(148, sprites.rowCount)
        assertEquals(red, tables.graphic(sprites, 4, 0)!!.picture.pixels[0])
        assertEquals(green, tables.graphic(sprites, 5, 0)!!.picture.pixels[0])
        val last = tables.graphic(sprites, 6, 0)!!
        assertEquals(blue, last.picture.pixels[0])
        assertEquals("front", last.palette)
        assertEquals(1, last.choices)
    }

    // ---- icons: a table of numbers picks a row of a table of palettes ----

    @Test
    fun aHintToATableOfNumbersPicksTheNumberedPalette() {
        fake.place("graphics.pokemon.icons.sprites", ICONS)
        fake.place("graphics.pokemon.icons.index", ICON_INDEX)
        fake.place("graphics.pokemon.icons.palettes", ICON_PALETTES)
        put(BLOBS, dots(32, 64))
        fake.pointer(ICONS + 4 * 2, BLOBS)
        fake.u8(ICON_INDEX + 2, 1)
        for (row in 0 until 3) {
            put(BLOBS + 0x1000 + row * 0x40, colors(gbaWhite, intArrayOf(gbaRed, gbaGreen, gbaBlue)[row], gbaWhite))
            fake.pointer(ICON_PALETTES + row * 8, BLOBS + 0x1000 + row * 0x40)
            fake.u32(ICON_PALETTES + row * 8 + 4, row.toLong())
        }
        open()
        val icons = table("graphics.pokemon.icons.sprites")
        val graphic = tables.graphic(icons, 2, 0)!!
        assertEquals(32, graphic.picture.width)
        assertEquals(64, graphic.picture.height)
        assertEquals(green, graphic.picture.pixels[0])
        assertEquals("palettes", graphic.palette)
        assertEquals(1, graphic.choices)

        fake.u8(ICON_INDEX + 2, 2)
        open()
        assertEquals(blue, tables.graphic(table("graphics.pokemon.icons.sprites"), 2, 0)!!.picture.pixels[0])
    }

    // ---- sprites with their palette in their own row ----

    @Test
    fun aSpriteTakesThePaletteOfItsOwnRow() {
        fake.place("data.items.stats", ITEMS)
        fake.constant("data.items.count", 3)
        fake.place("graphics.items.sprites", ITEM_SPRITES)
        putPacked(BLOBS, dots(24, 24))
        putPacked(BLOBS + 0x1000, colors(gbaWhite, gbaGreen, gbaBlue))
        fake.pointer(ITEM_SPRITES + 8, BLOBS)
        fake.pointer(ITEM_SPRITES + 12, BLOBS + 0x1000)
        open()
        val sprites = table("graphics.items.sprites")
        assertEquals(4, sprites.rowCount)
        val graphic = tables.graphic(sprites, 1, 0)!!
        assertEquals(24, graphic.picture.width)
        assertEquals(green, graphic.picture.pixels[0])
        assertEquals(blue, graphic.picture.pixels[24 * 24 - 1])
        assertEquals("palette", graphic.palette)
        // the palette field of the same row is a picture too
        assertTrue(tables.fields(sprites, 1)[1].picture)
        assertEquals(green, tables.graphic(sprites, 1, 1)!!.picture.pixels[1])
    }

    // ---- sprites that name a key of a palette table ----

    @Test
    fun aHintWithAKeyPicksThePaletteOfTheRowWithThatKey() {
        fake.place("graphics.trainers.emotes.sprites", EMOTES)
        fake.place("graphics.overworld.palettes", OVERWORLD_PALETTES)
        val ids = intArrayOf(0x1000, 0x1100, 0x1200)
        val shades = intArrayOf(gbaRed, gbaGreen, gbaBlue)
        for (row in 0 until 3) {
            put(BLOBS + 0x1000 + row * 0x40, colors(gbaWhite, shades[row], gbaWhite))
            fake.pointer(OVERWORLD_PALETTES + row * 8, BLOBS + 0x1000 + row * 0x40)
            fake.u16(OVERWORLD_PALETTES + row * 8 + 4, ids[row])
            fake.u16(OVERWORLD_PALETTES + row * 8 + 6, 0)
        }
        for (i in 0 until 8) fake.u8(OVERWORLD_PALETTES + 3 * 8 + i, 0) // the end of the table
        put(BLOBS, dots(16, 16))
        fake.pointer(EMOTES, BLOBS)
        fake.u32(EMOTES + 4, 4)
        open()
        val graphic = tables.graphic(table("graphics.trainers.emotes.sprites"), 0, 0)!!
        assertEquals(16, graphic.picture.width)
        assertEquals(green, graphic.picture.pixels[0]) // id 1100 is the second palette
        assertEquals("palettes", graphic.palette)
    }

    // ---- tilesets ----

    @Test
    fun aTilesetIsLaidOutSixteenTilesToARow() {
        fake.place("graphics.items.mail", MAIL)
        val tileData = ByteArray(20 * 32)
        for (tile in 0 until 20) tileData[tile * 32] = (tile % 3 + 1).toByte() // the left pixel of each tile
        putPacked(BLOBS, tileData)
        put(BLOBS + 0x1000, colors(gbaWhite, gbaRed, gbaGreen, gbaBlue))
        fake.pointer(MAIL, BLOBS + 0x1000) // pal
        fake.pointer(MAIL + 4, BLOBS) // tileset
        open()
        val mail = table("graphics.items.mail")
        val graphic = tables.graphic(mail, 0, 1)!!
        assertEquals(128, graphic.picture.width)
        assertEquals(16, graphic.picture.height) // 20 tiles are two rows of tiles
        assertEquals(red, graphic.picture.pixels[0]) // tile 0
        assertEquals(green, graphic.picture.pixels[8]) // tile 1
        assertEquals(blue, graphic.picture.pixels[16]) // tile 2
        assertEquals(green, graphic.picture.pixels[8 * 128]) // tile 16 starts the second row of tiles
        assertEquals(blue, graphic.picture.pixels[8 * 128 + 8]) // tile 17
        assertEquals(white, graphic.picture.pixels[8 * 128 + 4 * 8]) // there is no tile 20: its pixels have the first colour
        assertNotNull(graphic.palette)
    }

    companion object {
        const val NAMES = 0x100000
        const val FRONT = 0x110000
        const val NORMAL = 0x111000
        const val SHINY = 0x112000
        const val TRAINERS = 0x113000
        const val TRAINER_PALETTES = 0x114000
        const val ICONS = 0x115000
        const val ICON_INDEX = 0x116000
        const val ICON_PALETTES = 0x117000
        const val ITEMS = 0x118000
        const val ITEM_SPRITES = 0x119000
        const val EMOTES = 0x11A000
        const val OVERWORLD_PALETTES = 0x11B000
        const val MAIL = 0x11C000
        const val BLOBS = 0x130000
    }
}
