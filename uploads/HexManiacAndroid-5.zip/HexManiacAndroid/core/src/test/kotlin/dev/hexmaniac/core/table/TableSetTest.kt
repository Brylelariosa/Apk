package dev.hexmaniac.core.table

import dev.hexmaniac.core.io.ClasspathResources
import dev.hexmaniac.core.rom.RomDocument
import dev.hexmaniac.core.table.data.GameData
import dev.hexmaniac.core.table.data.ReferenceLibrary
import dev.hexmaniac.core.table.format.FieldKind
import dev.hexmaniac.core.text.PcsTable
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

/** The table engine on a small ROM that is laid out like FireRed 1.0 where the tests need it to be. */
class TableSetTest {
    private lateinit var data: GameData
    private lateinit var document: RomDocument
    private lateinit var tables: TableSet

    private val names = 0x100000
    private val moves = 0x100100
    private val types = 0x100200
    private val items = 0x100300
    private val abilities = 0x100500
    private val abilityTexts = 0x100580
    private val stats = 0x100600
    private val moveStats = 0x100700
    private val moveTexts = 0x100800
    private val tmMoves = 0x100A00
    private val tmFlags = 0x100B00
    private val levelUp = 0x100C00

    @Before
    fun setUp() {
        data = ReferenceLibrary(ClasspathResources()).load("BPRE0")
        val fake = FakeRom(data)

        fake.place("data.pokemon.names", names)
        listOf("?", "BULBASAUR", "IVYSAUR", "VENUSAUR", "CHARMANDER").forEachIndexed { i, n -> fake.fixedText(names + i * 11, n, 11) }

        fake.place("data.pokemon.moves.names", moves)
        listOf("-", "POUND", "KARATE CHOP", "DOUBLESLAP").forEachIndexed { i, n -> fake.fixedText(moves + i * 13, n, 13) }

        fake.place("data.pokemon.type.names", types)
        fake.constant("data.pokemon.type.length", 3)
        listOf("NORMAL", "FIGHT", "FLYING").forEachIndexed { i, n -> fake.fixedText(types + i * 7, n, 7) }

        fake.place("data.items.stats", items)
        fake.constant("data.items.count", 3)
        fake.fixedText(items, "?", 13)
        fake.fixedText(items + 44, "MASTER BALL", 13)
        fake.fixedText(items + 88, "ULTRA BALL", 13)
        fake.u16(items + 44 + 16, 0)
        fake.u16(items + 88 + 16, 1200)
        fake.u8(items + 44 + 26, 2)
        fake.u8(items + 44 + 27, 1)
        fake.u8(items + 88 + 26, 3)
        fake.u8(items + 88 + 27, 9)
        fake.pointer(items + 44 + 20, 0x101000)
        fake.pointer(items + 88 + 20, 0x101040)
        fake.u32(items + 20, 0)
        fake.text(0x101000, "The best BALL")
        fake.text(0x101040, "A better BALL")
        for (row in 0 until 3) {
            fake.u32(items + row * 44 + 28, 0)
            fake.u32(items + row * 44 + 32, 0)
            fake.u32(items + row * 44 + 36, 0)
            fake.u32(items + row * 44 + 40, 0)
        }

        fake.place("data.abilities.names", abilities)
        fake.fixedText(abilities, "-------", 13)
        fake.fixedText(abilities + 13, "STENCH", 13)
        fake.place("data.abilities.descriptions", abilityTexts)
        fake.pointer(abilityTexts, 0x101100)
        fake.pointer(abilityTexts + 4, 0x101120)
        fake.text(0x101100, "No ability")
        fake.text(0x101120, "May scare foes")

        fake.place("data.pokemon.stats", stats)
        for (row in 0 until 5) {
            val at = stats + row * 28
            for (i in 0 until 28) fake.u8(at + i, 0)
            fake.u8(at, 40 + row)
            fake.u8(at + 1, 50 + row)
            fake.u8(at + 6, row % 3)
            fake.u8(at + 7, (row + 1) % 3)
            fake.u16(at + 10, 0x0001 or (0x2 shl 4))
        }

        fake.place("data.pokemon.moves.stats.battle", moveStats)
        for (row in 0 until 4) {
            val at = moveStats + row * 12
            for (i in 0 until 12) fake.u8(at + i, 0)
            fake.u8(at + 1, 35 + row * 5)
            fake.u8(at + 4, 35)
        }

        fake.place("data.pokemon.moves.descriptions", moveTexts)
        for (row in 0 until 3) {
            fake.pointer(moveTexts + row * 4, 0x101200 + row * 0x40)
            fake.text(0x101200 + row * 0x40, "Description $row".uppercase())
        }

        fake.place("data.pokemon.moves.tms", tmMoves)
        for (i in 0 until 58) fake.u16(tmMoves + i * 2, 1 + i % 3)
        fake.place("data.pokemon.moves.tmcompatibility", tmFlags)
        for (i in 0 until 5 * 8) fake.u8(tmFlags + i, 0)
        fake.u8(tmFlags + 8, 0x05)

        fake.place("data.pokemon.moves.levelup", levelUp)
        for (row in 0 until 5) {
            val list = 0x101400 + row * 0x20
            fake.pointer(levelUp + row * 4, list)
            fake.u16(list, 1 or (1 shl 9))
            fake.u16(list + 2, 2 or (7 shl 9))
            fake.u16(list + 4, 0xFFFF)
        }

        document = RomDocument("test.gba", fake.bytes)
        tables = TableSet(document.rom, PcsTable.DEFAULT, "BPRE0", data)
    }

    private fun table(name: String): TableLocation = tables.locate(TablePath(name)) ?: error("no table $name")

    private fun apply(result: EditResult) {
        when (result) {
            is EditResult.Ready -> result.plan.applyTo(document)
            is EditResult.Rejected -> error("rejected: ${result.message}")
        }
        tables.invalidate()
    }

    private fun rejection(result: EditResult): String = (result as EditResult.Rejected).message

    private fun index(table: TableLocation, label: String): Int = table.schema.fields.indexOfFirst { it.label == label }

    // ---- finding tables and their lengths ----

    @Test
    fun tablesAreFoundThroughTheGamePointers() {
        val pokemon = table("data.pokemon.names")
        assertEquals(names, pokemon.start)
        assertEquals(11, pokemon.rowSize)
    }

    @Test
    fun textTablesWithoutLengthStopWhereTheTextStops() {
        assertEquals(5, table("data.pokemon.names").rowCount)
        assertEquals(4, table("data.pokemon.moves.names").rowCount)
        assertEquals(2, table("data.abilities.names").rowCount)
    }

    @Test
    fun lengthsCanComeFromConstantsAndOtherTables() {
        assertEquals(3, table("data.pokemon.type.names").rowCount)
        assertEquals(3, table("data.items.stats").rowCount)
        assertEquals(5, table("data.pokemon.stats").rowCount)
        assertEquals(2, table("data.abilities.descriptions").rowCount)
        assertEquals(4, table("data.pokemon.moves.stats.battle").rowCount)
    }

    @Test
    fun aMarginInTheLengthDropsRowsOfTheNamedTable() {
        assertEquals(3, table("data.pokemon.moves.descriptions").rowCount)
    }

    @Test
    fun rowSizesFollowTheFormat() {
        assertEquals(28, table("data.pokemon.stats").rowSize)
        assertEquals(44, table("data.items.stats").rowSize)
        assertEquals(12, table("data.pokemon.moves.stats.battle").rowSize)
        assertEquals(8, table("data.pokemon.moves.tmcompatibility").rowSize)
    }

    @Test
    fun tablesWhoseDataIsMissingAreLeftOut() {
        assertNull(tables.locate(TablePath("data.trainers.stats")))
        assertNull(tables.locate(TablePath("no.such.table")))
    }

    // ---- names ----

    @Test
    fun rowsAreNamedAfterTheTableTheirLengthFollows() {
        val stats = table("data.pokemon.stats")
        assertEquals("BULBASAUR", tables.rowLabel(stats, 1))
        assertEquals("CHARMANDER", tables.rowLabel(stats, 4))
    }

    @Test
    fun aLengthMarginShiftsTheNames() {
        val texts = table("data.pokemon.moves.descriptions")
        assertEquals("POUND", tables.rowLabel(texts, 0))
        assertEquals("DOUBLESLAP", tables.rowLabel(texts, 2))
    }

    @Test
    fun textTablesNameTheirOwnRows() {
        assertEquals("KARATE CHOP", tables.rowLabel(table("data.pokemon.moves.names"), 2))
    }

    // ---- reading ----

    @Test
    fun numbersWithNamesShowTheName() {
        val stats = table("data.pokemon.stats")
        val view = tables.field(stats, 1, index(stats, "type1"))
        assertEquals("FIGHT", view.text)
        assertEquals("1", view.note)
        assertEquals(FieldKind.NUMBER, view.kind)
    }

    @Test
    fun plainNumbersShowAsDecimal() {
        val stats = table("data.pokemon.stats")
        assertEquals("41", tables.field(stats, 1, index(stats, "hp")).text)
        assertEquals("51", tables.field(stats, 1, index(stats, "attack")).text)
    }

    @Test
    fun packedFieldsAreSplitIntoTheirParts() {
        val stats = table("data.pokemon.stats")
        assertEquals("1", tables.field(stats, 0, index(stats, "evs.hp")).text)
        assertEquals("0", tables.field(stats, 0, index(stats, "evs.atk")).text)
        assertEquals("2", tables.field(stats, 0, index(stats, "evs.def")).text)
    }

    @Test
    fun pointerFieldsShowTheTextTheyLeadTo() {
        val texts = table("data.abilities.descriptions")
        val view = tables.field(texts, 1, 0)
        assertEquals("May scare foes", view.text)
        assertEquals(0x101120, view.target)
    }

    @Test
    fun fixedTextShowsWithoutQuotes() {
        val pokemon = table("data.pokemon.names")
        assertEquals("IVYSAUR", tables.field(pokemon, 2, 0).text)
    }

    @Test
    fun aFieldsTypeCanDependOnAnotherField() {
        val items = table("data.items.stats")
        val type = index(items, "type")
        val master = tables.field(items, 1, type)
        val ultra = tables.field(items, 2, type)
        assertEquals(FieldKind.NUMBER, master.kind)
        assertEquals(FieldKind.NUMBER, ultra.kind)
    }

    @Test
    fun flagsListTheBitsThatAreSet() {
        val tm = table("data.pokemon.moves.tmcompatibility")
        val view = tables.field(tm, 1, 0)
        assertEquals(FieldKind.BITS, view.kind)
        assertTrue(view.text != "none")
        assertEquals("none", tables.field(tm, 0, 0).text)
    }

    @Test
    fun rowPreviewsLeaveOutTheNameAndUnusedValues() {
        val items = table("data.items.stats")
        val preview = tables.preview(items, 2)
        assertFalse(preview.contains("ULTRA BALL"))
        assertTrue(preview.contains("price 1200"))
    }

    // ---- nested tables ----

    @Test
    fun pointersToTablesLeadToNestedTables() {
        val levels = table("data.pokemon.moves.levelup")
        val view = tables.field(levels, 1, 0)
        assertNotNull(view.opens)
        val child = tables.locate(view.opens!!)!!
        assertEquals(2, child.rowCount)
        assertEquals(2, child.trailingBytes)
        assertEquals(0x101420, child.start)
    }

    @Test
    fun nestedRowsSplitPackedValues() {
        val levels = table("data.pokemon.moves.levelup")
        val child = tables.locate(tables.field(levels, 1, 0).opens!!)!!
        assertEquals("POUND", tables.field(child, 0, index(child, "pair.move")).text)
        assertEquals("1", tables.field(child, 0, index(child, "pair.level")).text)
        assertEquals("KARATE CHOP", tables.field(child, 1, index(child, "pair.move")).text)
        assertEquals("7", tables.field(child, 1, index(child, "pair.level")).text)
    }

    @Test
    fun nestedTablesCanBeEdited() {
        val levels = table("data.pokemon.moves.levelup")
        val childPath = tables.field(levels, 1, 0).opens!!
        var child = tables.locate(childPath)!!
        apply(tables.setNumber(child, 1, index(child, "pair.level"), 20))
        child = tables.locate(childPath)!!
        assertEquals("20", tables.field(child, 1, index(child, "pair.level")).text)
        assertEquals("KARATE CHOP", tables.field(child, 1, index(child, "pair.move")).text)
    }

    // ---- editing ----

    @Test
    fun editingANumberChangesOnlyItsBytes() {
        val stats = table("data.pokemon.stats")
        val before = document.rom.copyRange(stats.rowStart(2), 28)
        apply(tables.setNumber(stats, 2, index(stats, "attack"), 99))
        val after = document.rom.copyRange(stats.rowStart(2), 28)
        for (i in 0 until 28) if (i != 1) assertEquals(before[i], after[i])
        assertEquals(99, after[1].toInt())
    }

    @Test
    fun numbersOutsideTheFieldRangeAreRejected() {
        val stats = table("data.pokemon.stats")
        assertTrue(rejection(tables.setNumber(stats, 0, index(stats, "hp"), 256)).contains("0 to 255"))
        assertTrue(rejection(tables.setNumber(stats, 0, index(stats, "hp"), -1)).contains("0 to 255"))
    }

    @Test
    fun editingAPartOfAPackedFieldKeepsTheOtherParts() {
        val stats = table("data.pokemon.stats")
        apply(tables.setNumber(stats, 0, index(stats, "evs.atk"), 3))
        val after = tables.locate(TablePath("data.pokemon.stats"))!!
        assertEquals("1", tables.field(after, 0, index(after, "evs.hp")).text)
        assertEquals("3", tables.field(after, 0, index(after, "evs.atk")).text)
        assertEquals("2", tables.field(after, 0, index(after, "evs.def")).text)
    }

    @Test
    fun aPartOfAPackedFieldRejectsValuesThatDoNotFit() {
        val stats = table("data.pokemon.stats")
        assertTrue(rejection(tables.setNumber(stats, 0, index(stats, "evs.hp"), 4)).contains("0 to 3"))
    }

    @Test
    fun namedValuesOfferTheirNamesAsChoices() {
        val stats = table("data.pokemon.stats")
        val editor = tables.editorFor(stats, 1, index(stats, "type1")) as FieldEditor.Choice
        assertEquals(listOf("NORMAL", "FIGHT", "FLYING"), editor.entries.map { it.name })
        assertEquals(1L, editor.current)
        apply(tables.setNumber(stats, 1, index(stats, "type1"), editor.entries[2].value))
        assertEquals("FLYING", tables.field(table("data.pokemon.stats"), 1, index(stats, "type1")).text)
    }

    @Test
    fun fixedTextIsPaddedWithZeros() {
        val pokemon = table("data.pokemon.names")
        apply(tables.setText(pokemon, 1, 0, "BULBA"))
        val bytes = document.rom.copyRange(pokemon.rowStart(1), 11)
        assertEquals(0xFF, bytes[5].toInt() and 0xFF)
        for (i in 6 until 11) assertEquals(0, bytes[i].toInt())
        assertEquals("BULBA", tables.field(table("data.pokemon.names"), 1, 0).text)
    }

    @Test
    fun fixedTextThatIsTooLongIsRejected() {
        val pokemon = table("data.pokemon.names")
        assertTrue(rejection(tables.setText(pokemon, 1, 0, "ABCDEFGHIJK")).contains("11"))
        assertTrue(tables.setText(pokemon, 1, 0, "ABCDEFGHIJ") is EditResult.Ready)
    }

    @Test
    fun textWithUnknownCharactersIsRejected() {
        val pokemon = table("data.pokemon.names")
        assertTrue(tables.setText(pokemon, 1, 0, "é中") is EditResult.Rejected)
    }

    @Test
    fun pointedTextThatFitsIsReplacedInPlace() {
        val texts = table("data.abilities.descriptions")
        apply(tables.setText(texts, 1, 0, "Scares"))
        assertEquals("Scares", tables.field(table("data.abilities.descriptions"), 1, 0).text)
        assertEquals(0x101120, tables.field(table("data.abilities.descriptions"), 1, 0).target)
    }

    @Test
    fun pointedTextThatIsLongerThanItsSpaceGrowsIntoTheFreeBytesBehindIt() {
        val texts = table("data.abilities.descriptions")
        apply(tables.setText(texts, 1, 0, "May scare foes and friends too"))
        val view = tables.field(table("data.abilities.descriptions"), 1, 0)
        assertEquals("May scare foes and friends too", view.text)
        assertEquals(0x101120, view.target)
    }

    @Test
    fun pointedTextThatDoesNotFitAnywhereNearMovesToFreeSpace() {
        val texts = table("data.abilities.descriptions")
        // "No ability" has only 32 bytes of free space behind it
        val result = tables.setText(texts, 0, 0, "A".repeat(40))
        assertTrue((result as EditResult.Ready).notice!!.startsWith("Moved to free space"))
        apply(result)
        val view = tables.field(table("data.abilities.descriptions"), 0, 0)
        assertEquals("A".repeat(40), view.text)
        assertTrue(view.target > 0x101120)
    }

    @Test
    fun pointersCanBeRetargetedAndCleared() {
        val texts = table("data.abilities.descriptions")
        apply(tables.setAddress(texts, 0, 0, "101120"))
        assertEquals("May scare foes", tables.field(table("data.abilities.descriptions"), 0, 0).text)
        apply(tables.setAddress(table("data.abilities.descriptions"), 0, 0, ""))
        assertEquals("null", tables.field(table("data.abilities.descriptions"), 0, 0).text)
        assertTrue(rejection(tables.setAddress(table("data.abilities.descriptions"), 0, 0, "7FFFFFF")).contains("past the end"))
    }

    @Test
    fun flagsAreEditedBitByBit() {
        val tm = table("data.pokemon.moves.tmcompatibility")
        val editor = tables.editorFor(tm, 1, 0) as FieldEditor.Bits
        assertEquals(58, editor.names.size)
        assertEquals(setOf(0, 2), editor.selected)
        apply(tables.setBits(tm, 1, 0, setOf(1, 57)))
        val after = tables.editorFor(table("data.pokemon.moves.tmcompatibility"), 1, 0) as FieldEditor.Bits
        assertEquals(setOf(1, 57), after.selected)
        assertEquals(8, document.rom.copyRange(tm.rowStart(1), 8).size)
    }

    @Test
    fun editsCanBeUndone() {
        val stats = table("data.pokemon.stats")
        apply(tables.setNumber(stats, 0, index(stats, "hp"), 1))
        assertEquals("Edit data.pokemon.stats[0].hp", document.undoLabel)
        document.undo()
        tables.invalidate()
        assertEquals("40", tables.field(table("data.pokemon.stats"), 0, index(stats, "hp")).text)
    }

    @Test
    fun editsMadeElsewhereAreSeenAfterInvalidate() {
        val pokemon = table("data.pokemon.names")
        document.write(pokemon.rowStart(5), ByteArray(0), "nothing")
        // A sixth name appears in the ROM: the table grows once the catalog is rebuilt.
        val encoded = PcsTable.DEFAULT.encode("SQUIRTLE").bytes
        val row = ByteArray(11)
        System.arraycopy(encoded, 0, row, 0, encoded.size)
        document.write(pokemon.rowStart(5), row, "add a name")
        assertEquals(5, table("data.pokemon.names").rowCount)
        tables.invalidate()
        assertEquals(6, table("data.pokemon.names").rowCount)
        assertEquals(6, table("data.pokemon.stats").rowCount.coerceAtMost(6))
    }

    // ---- where values live ----

    @Test
    fun fieldsKnowWhereTheirBytesAre() {
        val stats = table("data.pokemon.stats")
        val hp = tables.field(stats, 2, index(stats, "hp"))
        assertEquals(stats.rowStart(2), hp.offset)
        assertEquals(1, hp.size)
        assertEquals("hp", hp.name)
        assertEquals(null, hp.group)
        val atk = tables.field(stats, 2, index(stats, "evs.atk"))
        assertEquals(stats.rowStart(2) + 10, atk.offset)
        assertEquals(2, atk.size)
        assertEquals("evs", atk.group)
        assertEquals("atk", atk.name)
        assertEquals("evs.atk", atk.label)
    }

    @Test
    fun editableTextKeepsLineBreaksButListsShowOneLine() {
        val texts = table("data.abilities.descriptions")
        document.write(0x101120, PcsTable.DEFAULT.encode("May\nscare").bytes, "two lines")
        tables.invalidate()
        val editor = tables.editorFor(table("data.abilities.descriptions"), 1, 0) as FieldEditor.PointedText
        assertEquals("May\nscare", editor.current)
        assertEquals("May scare", tables.field(table("data.abilities.descriptions"), 1, 0).text)
        assertNotNull(texts)
    }

    // ---- listing ----

    @Test
    fun tablesAreListedUnderTheHeadingsOfTheReferenceData() {
        val sections = tables.sections()
        val pokemon = sections.first { it.title == "Pokemon" }
        assertTrue(pokemon.tables.any { it.name == "data.pokemon.names" && it.rowCount == 5 })
        assertTrue(pokemon.tables.any { it.name == "data.pokemon.stats" && it.rowSize == 28 })
        assertEquals(TableSet.OTHER_TABLES, sections.last().title)
        val listed = sections.flatMap { it.tables }.map { it.name }
        assertEquals(listed.size, listed.toSet().size)
        assertFalse(listed.contains("data.trainers.stats"))
    }
}
