package dev.hexmaniac.core.table

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TextFilterTest {
    @Test
    fun anEmptyQueryMatchesEverything() {
        assertTrue(TextFilter("").isEmpty)
        assertTrue(TextFilter("   ").isEmpty)
        assertTrue(TextFilter("").matches("anything"))
        assertTrue(TextFilter(" ").matches(""))
    }

    @Test
    fun caseDoesNotMatter() {
        assertTrue(TextFilter("bulba").matches("BULBASAUR"))
        assertTrue(TextFilter("BULBA").matches("bulbasaur"))
    }

    @Test
    fun everyWordMustOccurInAnyOrder() {
        val filter = TextFilter("ball  master")
        assertTrue(filter.matches("MASTER BALL"))
        assertTrue(filter.matches("ball of the master"))
        assertFalse(filter.matches("ULTRA BALL"))
        assertFalse(TextFilter("x").isEmpty)
    }

    @Test
    fun selectsThePositionsThatMatch() {
        val items = listOf("data.pokemon.names", "data.items.stats", "data.pokemon.stats")
        assertArrayEquals(intArrayOf(0, 2), TextFilter("pokemon").select(items) { it })
        assertArrayEquals(intArrayOf(2), TextFilter("pokemon stats").select(items) { it })
        assertArrayEquals(intArrayOf(0, 1, 2), TextFilter("").select(items) { it })
        assertArrayEquals(intArrayOf(), TextFilter("zzz").select(items) { it })
    }
}
