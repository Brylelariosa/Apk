package dev.hexmaniac.core.graphics

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Test

class PictureTest {
    @Test
    fun indexesAreReplacedByTheirColours() {
        val picture = Picture.painted(intArrayOf(0, 1, 2, 1), 2, 2, intArrayOf(10, 20, 30))
        assertEquals(2, picture.width)
        assertEquals(2, picture.height)
        assertArrayEquals(intArrayOf(10, 20, 30, 20), picture.pixels)
    }

    @Test
    fun indexesOutsideThePaletteAreBlack() {
        val picture = Picture.painted(intArrayOf(0, 5, -1, 2), 4, 1, intArrayOf(10, 20))
        assertArrayEquals(intArrayOf(10, Palettes.BLACK, Palettes.BLACK, Palettes.BLACK), picture.pixels)
    }

    @Test
    fun aPaletteBecomesAGridOfSwatches() {
        val picture = Picture.swatches(IntArray(32) { it }, 16)
        assertEquals(16, picture.width)
        assertEquals(2, picture.height)
        assertEquals(17, picture.pixels[17])
    }

    @Test
    fun theLastRowOfSwatchesIsFilledWithBlack() {
        val picture = Picture.swatches(intArrayOf(1, 2, 3), 2)
        assertEquals(2, picture.width)
        assertEquals(2, picture.height)
        assertArrayEquals(intArrayOf(1, 2, 3, Palettes.BLACK), picture.pixels)
    }

    @Test(expected = IllegalArgumentException::class)
    fun thePixelCountMustMatchTheSize() {
        Picture(2, 2, IntArray(3))
    }

    @Test(expected = IllegalArgumentException::class)
    fun aPictureHasASize() {
        Picture(0, 2, IntArray(0))
    }
}
