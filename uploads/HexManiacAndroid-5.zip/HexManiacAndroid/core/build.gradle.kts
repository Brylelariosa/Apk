import org.gradle.language.jvm.tasks.ProcessResources
import org.jetbrains.kotlin.gradle.dsl.JvmTarget

// Pure-JVM engine: ROM model, text codec, patching and (later) the table-format DSL and graphics.
// No Android dependencies, so it is unit-testable on any JVM.
plugins {
    id("org.jetbrains.kotlin.jvm")
}

java {
    sourceCompatibility = JavaVersion.VERSION_17
    targetCompatibility = JavaVersion.VERSION_17
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
        // Smaller bytecode: skip the generated null-check calls on parameters and call results.
        freeCompilerArgs.addAll("-Xno-param-assertions", "-Xno-call-assertions", "-Xno-receiver-assertions")
    }
}

dependencies {
    testImplementation("junit:junit:4.13.2")
}

tasks.test {
    useJUnit()
}

// Data files that end up inside the engine jar (and so inside the APK): exactly the ones named in hma/index.txt.
// The source folder holds more reference data than the app reads today (other languages, scripts, ...); list a
// file in the index when the feature that uses it lands, so the APK carries no dead weight.
val shippedData: List<String> = file("src/main/resources/hma/index.txt").readLines()
    .map { it.trim() }
    .filter { it.isNotEmpty() }
    .map { "hma/$it" } + "hma/index.txt"

tasks.named<ProcessResources>("processResources") {
    include(shippedData)
}
