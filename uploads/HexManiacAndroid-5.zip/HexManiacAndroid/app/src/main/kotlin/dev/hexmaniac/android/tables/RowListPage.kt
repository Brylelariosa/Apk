package dev.hexmaniac.android.tables

import android.app.Activity
import android.util.SparseArray
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import dev.hexmaniac.android.R
import dev.hexmaniac.android.ui.MenuAction
import dev.hexmaniac.android.ui.SearchList
import dev.hexmaniac.android.ui.TwoLineRow
import dev.hexmaniac.android.ui.chooseAction
import dev.hexmaniac.core.rom.HexText
import dev.hexmaniac.core.table.TableLocation
import dev.hexmaniac.core.table.TablePath
import dev.hexmaniac.core.table.TextFilter

/** The rows of one table, each with its name from the game's lists and a short summary of its values. */
class RowListPage(
    private val activity: Activity,
    private val browser: TableBrowser,
    private val navigator: TableNavigator,
    private val path: TablePath,
    private val heading: String,
) : Page {

    /** What a row is listed as: a main line and, when there is more to tell, a second line. */
    private class RowText(val title: String, val subtitle: String?) {
        val searchable: String get() = title + " " + subtitle.orEmpty()
    }

    private val search = SearchList(
        activity,
        activity.getString(R.string.rows_search_hint),
        activity.getString(R.string.rows_none),
    ) { queryChanged(it) }
    private val adapter = Adapter()
    private var table: TableLocation? = browser.tables.locate(path)

    /** Rows listed so far; text is worked out when a row is first shown or searched, then kept until the ROM changes. */
    private val texts = SparseArray<RowText>()

    /** The rows that match the search, in order; null while every row is listed. */
    private var matches: IntArray? = null

    init {
        search.listView.adapter = adapter
        search.listView.setOnItemClickListener { _, _, position, _ -> navigator.openRow(path, rowAt(position)) }
        search.listView.setOnItemLongClickListener { _, _, position, _ ->
            offerActions(rowAt(position))
            true
        }
    }

    override val view: View get() = search

    override val title: String get() = heading

    override val subtitle: String?
        get() = table?.let {
            activity.getString(R.string.rows_page_subtitle, activity.rowCountText(it.rowCount), it.rowSize, HexText.hex(it.start, 6))
        }

    override val hexLocation: HexLocation? get() = table?.let { HexLocation(it.start, it.rowSize) }

    override fun refresh(): Boolean {
        table = browser.tables.locate(path) ?: return false
        texts.clear()
        findMatches(search.query)
        adapter.notifyDataSetChanged()
        return true
    }

    private fun queryChanged(query: String) {
        findMatches(query)
        adapter.notifyDataSetChanged()
        search.listView.setSelection(0)
    }

    private fun rowAt(position: Int): Int = matches?.get(position) ?: position

    private fun findMatches(query: String) {
        val current = table
        val filter = TextFilter(query)
        search.emptyMessage = activity.getString(if (filter.isEmpty) R.string.rows_none else R.string.search_no_matches)
        if (current == null || filter.isEmpty) {
            matches = null
            return
        }
        // Big tables are searched by number and name only: summarising every row of them would take too long.
        val summarised = current.rowCount <= SUMMARY_SEARCH_LIMIT
        val kept = ArrayList<Int>()
        for (row in 0 until current.rowCount) {
            val words = if (summarised) textOf(current, row).searchable else browser.tables.rowLabel(current, row).orEmpty()
            if (filter.matches("$row $words")) kept.add(row)
        }
        matches = kept.toIntArray()
    }

    private fun textOf(current: TableLocation, row: Int): RowText {
        texts.get(row)?.let { return it }
        val label = browser.tables.rowLabel(current, row)
        val summary = browser.tables.preview(current, row)
        val text = when {
            label != null -> RowText(label, summary.ifEmpty { null })
            summary.isNotEmpty() -> RowText(summary, null)
            else -> RowText(activity.getString(R.string.row_default_title, row), null)
        }
        texts.put(row, text)
        return text
    }

    private fun offerActions(row: Int) {
        val current = table ?: return
        activity.chooseAction(
            textOf(current, row).title,
            listOf(
                MenuAction(activity.getString(R.string.open_row)) { navigator.openRow(path, row) },
                MenuAction(activity.getString(R.string.show_row_in_hex)) { navigator.showInHex(current.rowStart(row), current.rowSize) },
            ),
        )
    }

    private inner class Adapter : BaseAdapter() {
        override fun getCount(): Int = matches?.size ?: table?.rowCount ?: 0

        override fun getItem(position: Int): Any? = null

        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val row = (convertView as? TwoLineRow) ?: TwoLineRow(activity)
            val current = table
            if (current == null) {
                row.bind(null, "", null)
                return row
            }
            val index = rowAt(position)
            val text = textOf(current, index)
            row.bind(index.toString(), text.title, text.subtitle)
            return row
        }
    }

    private companion object {
        /** Tables with more rows than this are searched by row number and name only. */
        const val SUMMARY_SEARCH_LIMIT = 2000
    }
}
