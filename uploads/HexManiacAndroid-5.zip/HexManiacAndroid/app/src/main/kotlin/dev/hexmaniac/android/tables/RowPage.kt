package dev.hexmaniac.android.tables

import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ListView
import dev.hexmaniac.android.R
import dev.hexmaniac.android.ui.ActionRow
import dev.hexmaniac.android.ui.HeadedAdapter
import dev.hexmaniac.android.ui.MATCH
import dev.hexmaniac.android.ui.MenuAction
import dev.hexmaniac.android.ui.WRAP
import dev.hexmaniac.android.ui.chooseAction
import dev.hexmaniac.core.table.FieldView
import dev.hexmaniac.core.table.Graphic
import dev.hexmaniac.core.table.TableLocation
import dev.hexmaniac.core.table.TablePath
import dev.hexmaniac.core.table.format.FieldKind

/**
 * One row of a table with all its values. A tap edits a value (or opens the table it leads to), a long-press offers
 * the less common actions, and the bar below steps to the neighbouring rows.
 */
class RowPage(
    private val activity: Activity,
    private val browser: TableBrowser,
    private val navigator: TableNavigator,
    private val editors: FieldEditors,
    private val path: TablePath,
    private var row: Int,
) : Page {

    /** A line of the page: the heading of a packed value, or one value. */
    private sealed class Item {
        class Group(val name: String) : Item()

        class Value(val field: FieldView) : Item()
    }

    private val root = LinearLayout(activity)
    private val list = ListView(activity)
    private val adapter = Adapter()
    private val actions = ActionRow(activity)
    private var previousAction = 0
    private var nextAction = 0

    private var table: TableLocation? = browser.tables.locate(path)
    private var items: List<Item> = emptyList()
    private var fields: List<FieldView> = emptyList()

    /** The pictures of the values that lead to one, by the index of the value in the row. */
    private var graphics: Map<Int, Graphic> = emptyMap()

    /** Which palette each sprite of the row is painted with, by the index of the value; a tap on the sprite counts up. */
    private val palettes = HashMap<Int, Int>()

    override var title: String = ""
        private set
    override var subtitle: String? = null
        private set

    init {
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(activity.getColor(R.color.bg))

        list.divider = null
        list.dividerHeight = 0
        list.selector = ColorDrawable(Color.TRANSPARENT)
        list.adapter = adapter
        list.setOnItemClickListener { _, _, position, _ -> fieldAt(position)?.let { activate(it) } }
        list.setOnItemLongClickListener { _, _, position, _ ->
            val field = fieldAt(position)
            if (field != null) offerActions(field)
            field != null
        }
        root.addView(list, LinearLayout.LayoutParams(MATCH, 0, 1f))

        previousAction = actions.add(R.string.bar_previous) { moveTo(row - 1) }
        nextAction = actions.add(R.string.bar_next) { moveTo(row + 1) }
        actions.add(R.string.bar_in_hex) { showInHex() }
        root.addView(actions, LinearLayout.LayoutParams(MATCH, WRAP))

        reload()
    }

    override val view: View get() = root

    override val hexLocation: HexLocation? get() = table?.let { HexLocation(it.rowStart(row), it.rowSize) }

    override fun refresh(): Boolean {
        val located = browser.tables.locate(path) ?: return false
        if (row >= located.rowCount) return false
        table = located
        reload()
        return true
    }

    /** Reads the values of the current row again and brings the header, the list and the buttons up to date. */
    private fun reload() {
        val current = table ?: return
        val label = browser.tables.rowLabel(current, row)
        title = label ?: activity.getString(R.string.row_default_title, row)
        subtitle = activity.getString(R.string.row_page_subtitle, row, current.rowCount, path.display())
        fields = browser.tables.fields(current, row)
        items = itemsOf(fields)
        graphics = drawn(current)
        adapter.notifyDataSetChanged()
        actions.setActionEnabled(previousAction, row > 0)
        actions.setActionEnabled(nextAction, row + 1 < current.rowCount)
    }

    /** The values in table order; the parts of a packed value come under a heading of their own. */
    private fun itemsOf(fields: List<FieldView>): List<Item> {
        val result = ArrayList<Item>()
        var group: String? = null
        for (field in fields) {
            if (field.group != group) {
                group = field.group
                if (group != null) result.add(Item.Group(group))
            }
            result.add(Item.Value(field))
        }
        return result
    }

    /** Draws the values of the row that lead to a sprite or a palette. */
    private fun drawn(current: TableLocation): Map<Int, Graphic> {
        val result = HashMap<Int, Graphic>()
        for (field in fields) {
            if (!field.picture) continue
            val graphic = browser.tables.graphic(current, row, field.index, palettes[field.index] ?: 0) ?: continue
            result[field.index] = graphic
        }
        return result
    }

    /** Paints the sprite of the value at [index] with the next of its palettes. */
    private fun nextPalette(index: Int) {
        val current = table ?: return
        palettes[index] = (graphics[index]?.choice ?: 0) + 1
        graphics = drawn(current)
        adapter.notifyDataSetChanged()
    }

    private fun fieldAt(position: Int): FieldView? = (items.getOrNull(position) as? Item.Value)?.field

    private fun moveTo(newRow: Int) {
        val current = table ?: return
        if (newRow < 0 || newRow >= current.rowCount) return
        row = newRow
        palettes.clear()
        reload()
        list.setSelection(0)
        navigator.headerChanged()
    }

    private fun showInHex() {
        val current = table ?: return
        navigator.showInHex(current.rowStart(row), current.rowSize)
    }

    private fun activate(field: FieldView) {
        val current = table ?: return
        editors.edit(current, row, field)
    }

    private fun offerActions(field: FieldView) {
        val current = table ?: return
        val choices = ArrayList<MenuAction>()
        if (field.kind == FieldKind.POINTER) {
            choices.add(MenuAction(activity.getString(R.string.edit_as_address)) { editors.edit(current, row, field, asAddress = true) })
        }
        if (field.target >= 0) {
            choices.add(MenuAction(activity.getString(R.string.show_target_in_hex)) { navigator.showInHex(field.target, 1) })
        }
        choices.add(MenuAction(activity.getString(R.string.show_value_in_hex)) { navigator.showInHex(field.offset, field.size) })
        activity.chooseAction(field.label, choices)
    }

    private inner class Adapter : HeadedAdapter(activity) {
        override fun getCount(): Int = items.size

        override fun isHeading(position: Int): Boolean = items[position] is Item.Group

        override fun headingText(position: Int): String = (items[position] as Item.Group).name

        override fun rowView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val line = (convertView as? FieldRow) ?: FieldRow(activity)
            val field = (items[position] as Item.Value).field
            line.bind(field, indented = field.group != null, graphic = graphics[field.index], onPicture = { nextPalette(field.index) })
            return line
        }
    }
}
