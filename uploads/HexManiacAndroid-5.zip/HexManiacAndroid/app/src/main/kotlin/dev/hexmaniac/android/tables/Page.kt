package dev.hexmaniac.android.tables

import android.view.View
import dev.hexmaniac.core.table.TablePath

/** A stretch of the ROM a page can show in the hex view. */
class HexLocation(val offset: Int, val length: Int)

/**
 * One screen of the table browser. The screens are stacked: the activity shows the top one, the back button removes
 * it and the one below comes back as it was left.
 */
interface Page {
    val view: View

    /** Action bar title and subtitle; read again whenever the ROM changes. */
    val title: String
    val subtitle: String?

    /** What "show in hex" leads to from this page, or null when there is nothing to show. */
    val hexLocation: HexLocation? get() = null

    /**
     * The ROM may have changed: bring what is shown up to date and keep the position in the list.
     * Returns false when what the page shows is gone (its table can no longer be found).
     */
    fun refresh(): Boolean

    /** The page was just put on top of the stack, or is on top again. */
    fun onShown() {}
}

/** What pages ask of the screen that hosts them. */
interface TableNavigator {
    /** Opens the rows of the table [path]; [heading] is its title. */
    fun openTable(path: TablePath, heading: String)

    /** Opens row [row] of the table [path]. */
    fun openRow(path: TablePath, row: Int)

    /** Leaves the table browser and selects the bytes [offset] until [offset] + [length] in the hex view. */
    fun showInHex(offset: Int, length: Int)

    /** The title, subtitle or hex location of the top page changed without the ROM changing (for example a new row). */
    fun headerChanged()
}

/** The name of a table for people: the reference name, followed by the rows that lead into a nested table. */
fun TablePath.display(): String = root + steps.joinToString("") { "[${it.row}]" }
