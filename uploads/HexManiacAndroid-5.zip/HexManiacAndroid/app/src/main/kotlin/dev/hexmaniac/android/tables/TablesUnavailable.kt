package dev.hexmaniac.android.tables

import android.app.Activity
import android.app.AlertDialog
import dev.hexmaniac.android.R
import dev.hexmaniac.android.session.RomSession
import dev.hexmaniac.core.rom.RomInfo

/** Explains that the ROM of [session] is a game the table definitions do not cover; [then] runs once it is closed. */
fun Activity.showTablesUnavailable(session: RomSession, then: () -> Unit = {}) {
    val game = RomInfo.gameLabel(session.document) ?: getString(R.string.tables_unavailable_unknown)
    AlertDialog.Builder(this)
        .setTitle(R.string.tables_unavailable_title)
        .setMessage(getString(R.string.tables_unavailable_message, game))
        .setPositiveButton(android.R.string.ok, null)
        .setOnDismissListener { then() }
        .show()
}
