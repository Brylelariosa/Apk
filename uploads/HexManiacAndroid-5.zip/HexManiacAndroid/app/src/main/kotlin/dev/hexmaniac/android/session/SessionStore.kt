package dev.hexmaniac.android.session

/**
 * The ROM that is open. Every screen of the app runs in this one process, so screens that open on top of the hex
 * view (the table browser) find the ROM here instead of receiving it through an intent.
 */
object SessionStore {
    @Volatile
    var current: RomSession? = null
}
