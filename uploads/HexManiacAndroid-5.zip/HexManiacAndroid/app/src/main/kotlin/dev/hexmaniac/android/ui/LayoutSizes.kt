package dev.hexmaniac.android.ui

import android.view.ViewGroup

/** Short names for the two layout sizes that are not a number of pixels. */
const val MATCH: Int = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP: Int = ViewGroup.LayoutParams.WRAP_CONTENT
