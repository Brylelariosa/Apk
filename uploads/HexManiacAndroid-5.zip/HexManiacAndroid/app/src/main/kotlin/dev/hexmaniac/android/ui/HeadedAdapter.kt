package dev.hexmaniac.android.ui

import android.content.Context
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter

/**
 * The adapter of a list that has small headings between its tappable rows. Headings cannot be selected, so a tap or
 * a long-press on one does nothing; subclasses only say which positions are headings and how the other rows look.
 */
abstract class HeadedAdapter(private val context: Context) : BaseAdapter() {
    protected abstract fun isHeading(position: Int): Boolean

    protected abstract fun headingText(position: Int): String

    /** The view of a row that is not a heading; [convertView] is a view this method returned before, or null. */
    protected abstract fun rowView(position: Int, convertView: View?, parent: ViewGroup?): View

    override fun getItem(position: Int): Any? = null

    override fun getItemId(position: Int): Long = position.toLong()

    override fun getViewTypeCount(): Int = 2

    override fun getItemViewType(position: Int): Int = if (isHeading(position)) TYPE_HEADING else TYPE_ROW

    override fun areAllItemsEnabled(): Boolean = false

    override fun isEnabled(position: Int): Boolean = !isHeading(position)

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        if (!isHeading(position)) return rowView(position, convertView, parent)
        val view = (convertView as? HeaderRow) ?: HeaderRow(context)
        view.text = headingText(position)
        return view
    }

    private companion object {
        const val TYPE_HEADING = 0
        const val TYPE_ROW = 1
    }
}
