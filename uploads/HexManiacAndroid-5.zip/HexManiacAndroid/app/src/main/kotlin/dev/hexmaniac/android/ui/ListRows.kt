package dev.hexmaniac.android.ui

import android.content.Context
import android.graphics.Typeface
import android.text.TextUtils
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import dev.hexmaniac.android.R

/** A small heading above a group of rows. */
class HeaderRow(context: Context) : TextView(context) {
    init {
        textSize = 11.5f
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        setTextColor(context.getColor(R.color.accent))
        isAllCaps = true
        letterSpacing = 0.08f
        setPadding(context.dp(16), context.dp(22), context.dp(16), context.dp(6))
    }
}

/**
 * A list row of up to two lines of text, with an optional short number or code in front. The whole row is the touch
 * target; the ripple shows which row was touched.
 */
class TwoLineRow(context: Context) : LinearLayout(context) {
    private val lead = TextView(context)
    private val title = TextView(context)
    private val subtitle = TextView(context)

    init {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        minimumHeight = context.dp(56)
        setPadding(context.dp(16), context.dp(9), context.dp(16), context.dp(9))
        setBackgroundResource(R.drawable.bg_action)

        lead.typeface = Typeface.MONOSPACE
        lead.textSize = 12.5f
        lead.gravity = Gravity.END
        lead.minWidth = context.dp(36)
        lead.setTextColor(context.getColor(R.color.text_dim))
        val leadParams = LayoutParams(WRAP, WRAP)
        leadParams.rightMargin = context.dp(14)
        addView(lead, leadParams)

        title.textSize = 15f
        title.setTextColor(context.getColor(R.color.text_primary))
        title.maxLines = 1
        title.ellipsize = TextUtils.TruncateAt.END
        subtitle.textSize = 12.5f
        subtitle.setTextColor(context.getColor(R.color.text_secondary))
        subtitle.maxLines = 1
        subtitle.ellipsize = TextUtils.TruncateAt.END

        val texts = LinearLayout(context)
        texts.orientation = VERTICAL
        texts.addView(title, LayoutParams(MATCH, WRAP))
        texts.addView(subtitle, LayoutParams(MATCH, WRAP))
        addView(texts, LayoutParams(0, WRAP, 1f))
    }

    fun bind(leadText: CharSequence?, titleText: CharSequence, subtitleText: CharSequence?) {
        lead.visibility = if (leadText == null) GONE else VISIBLE
        lead.text = leadText
        title.text = titleText
        subtitle.visibility = if (subtitleText.isNullOrEmpty()) GONE else VISIBLE
        subtitle.text = subtitleText
    }
}
