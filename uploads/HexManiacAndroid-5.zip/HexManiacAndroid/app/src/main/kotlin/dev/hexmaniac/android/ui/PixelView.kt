package dev.hexmaniac.android.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.view.View
import dev.hexmaniac.core.graphics.Picture

/**
 * Shows a [Picture] with hard pixel edges. Every pixel of the picture is drawn as a square of a whole number of screen
 * pixels, as large as fits in a box of 96 dp (a sprite of 64 by 64 pixels comes out at 4 screen pixels per pixel on a
 * phone with 2.75 pixels to the dp). A picture that is larger than the box, such as a tileset, is drawn at one screen
 * pixel per pixel instead of being shrunk.
 */
class PixelView(context: Context) : View(context) {
    private val paint = Paint()
    private val source = Rect()
    private val target = Rect()
    private val limit = context.dp(96)
    private var bitmap: Bitmap? = null
    private var shown: Picture? = null

    init {
        paint.isFilterBitmap = false
    }

    /** Shows [picture]; null shows nothing. Showing the picture that is shown already does no work. */
    fun show(picture: Picture?) {
        if (picture === shown) return
        shown = picture
        bitmap = picture?.let { Bitmap.createBitmap(it.pixels, it.width, it.height, Bitmap.Config.ARGB_8888) }
        requestLayout()
        invalidate()
    }

    private fun factor(map: Bitmap): Int = maxOf(1, minOf(limit / map.width, limit / map.height))

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val map = bitmap
        if (map == null) {
            setMeasuredDimension(0, 0)
        } else {
            val size = factor(map)
            setMeasuredDimension(map.width * size, map.height * size)
        }
    }

    override fun onDraw(canvas: Canvas) {
        val map = bitmap ?: return
        source.set(0, 0, map.width, map.height)
        target.set(0, 0, width, height)
        canvas.drawBitmap(map, source, target, paint)
    }
}
