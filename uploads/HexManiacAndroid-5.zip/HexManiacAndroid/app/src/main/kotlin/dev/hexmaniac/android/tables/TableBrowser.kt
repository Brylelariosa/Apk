package dev.hexmaniac.android.tables

import dev.hexmaniac.android.session.RomSession
import dev.hexmaniac.core.table.EditResult
import dev.hexmaniac.core.table.TableSet

/**
 * What the table screens share: the table engine for the open ROM, and the one way edits reach the document
 * (so every edit is an undo step and every screen hears about it).
 */
class TableBrowser private constructor(val session: RomSession, val tables: TableSet) {

    /** Forgets everything the engine read from the ROM; call after the ROM changed. */
    fun invalidate() = tables.invalidate()

    /** Performs the change as one undo step; returns why it cannot be done, or null when it was done. */
    fun apply(result: EditResult): String? = when (result) {
        is EditResult.Ready -> {
            result.plan.applyTo(session.document)
            null
        }
        is EditResult.Rejected -> result.message
    }

    companion object {
        /** True when the reference data has table definitions for the game of the ROM in [session]. */
        fun isSupported(session: RomSession): Boolean = supportedGame(session) != null

        /**
         * Opens the table engine on the ROM of [session]; null when the reference data has no tables for its game.
         * The first call reads the table definitions, so call it off the UI thread.
         */
        fun open(session: RomSession): TableBrowser? {
            val game = supportedGame(session) ?: return null
            val tables = TableSet(session.document.rom, ReferenceData.pcs, game, ReferenceData.library.load(game))
            return TableBrowser(session, tables)
        }

        /** The game code of the ROM when there are tables for it. */
        private fun supportedGame(session: RomSession): String? {
            val game = session.document.header.game?.full ?: return null
            return if (ReferenceData.library.supports(game)) game else null
        }
    }
}
