package dev.hexmaniac.android.tables

import android.content.Context
import dev.hexmaniac.android.R

/** "1 row" or "12 rows". */
fun Context.rowCountText(count: Int): String = resources.getQuantityString(R.plurals.row_count, count, count)

/** "1 table" or "12 tables". */
fun Context.tableCountText(count: Int): String = resources.getQuantityString(R.plurals.table_count, count, count)
