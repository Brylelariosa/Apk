package dev.hexmaniac.android.ui

import android.content.Context
import android.view.View
import android.view.inputmethod.InputMethodManager

/** Hides the soft keyboard and takes the keyboard focus away from this view. */
fun View.hideKeyboard() {
    val manager = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
    manager.hideSoftInputFromWindow(windowToken, 0)
    clearFocus()
}
