package dev.hexmaniac.android.tables

import android.app.Activity
import dev.hexmaniac.android.R
import dev.hexmaniac.android.ui.MenuAction
import dev.hexmaniac.android.ui.PickerItem
import dev.hexmaniac.android.ui.chooseAction
import dev.hexmaniac.android.ui.pickMany
import dev.hexmaniac.android.ui.pickOne
import dev.hexmaniac.android.ui.promptParagraph
import dev.hexmaniac.android.ui.promptText
import dev.hexmaniac.android.ui.showMessage
import dev.hexmaniac.android.ui.toast
import dev.hexmaniac.android.ui.toastLong
import dev.hexmaniac.core.rom.HexText
import dev.hexmaniac.core.table.EditResult
import dev.hexmaniac.core.table.FieldEditor
import dev.hexmaniac.core.table.FieldView
import dev.hexmaniac.core.table.TableLocation

/**
 * Lets the user change one value of a table row. The table engine says what kind of editor the value needs; this
 * class shows the matching dialog and gives the answer back to the engine, which works out the bytes. Accepted changes
 * become one undo step; refused ones are explained in a message and change nothing.
 */
class FieldEditors(
    private val activity: Activity,
    private val browser: TableBrowser,
    private val navigator: TableNavigator,
) {
    private val tables get() = browser.tables

    /** Which value is being edited: the table, the row and the field. */
    private class Target(val table: TableLocation, val row: Int, val field: FieldView)

    /**
     * Does what a tap on [field] of row [row] should do: edit it, or open the table it leads to. With [asAddress] a
     * pointer is edited as a plain address, whatever it points to.
     */
    fun edit(table: TableLocation, row: Int, field: FieldView, asAddress: Boolean = false) {
        val target = Target(table, row, field)
        val title = activity.getString(R.string.edit_value_title, field.name)
        when (val editor = tables.editorFor(table, row, field.index, asAddress)) {
            is FieldEditor.Number -> askNumber(title, target, editor)
            is FieldEditor.Choice -> askChoice(title, target, editor)
            is FieldEditor.Flag -> change(tables.setNumber(table, row, field.index, if (editor.on) 0L else 1L))
            is FieldEditor.Text -> askText(title, target, editor)
            is FieldEditor.PointedText -> askPointedText(title, target, editor)
            is FieldEditor.Address -> askAddress(title, target, editor)
            is FieldEditor.Bits -> askBits(title, target, editor)
            is FieldEditor.Color -> askColor(title, target, editor)
            is FieldEditor.OpenTable -> navigator.openTable(editor.path, nestedHeading(target))
        }
    }

    private fun askNumber(title: String, target: Target, editor: FieldEditor.Number) {
        val digits = editor.max.toString(16).length
        val initial = if (editor.hex) editor.current.toString(16).uppercase().padStart(digits, '0') else editor.current.toString()
        val message = if (editor.hex) {
            activity.getString(R.string.edit_hex_message, editor.max.toString(16).uppercase())
        } else {
            activity.getString(R.string.edit_number_message, editor.min, editor.max)
        }
        activity.promptText(title, message, initial, activity.getString(R.string.edit_hint_number), uppercase = editor.hex) { text ->
            val value = editor.parse(text)
            if (value == null) {
                activity.toast(R.string.toast_enter_number)
            } else {
                change(tables.setNumber(target.table, target.row, target.field.index, value))
            }
        }
    }

    private fun askChoice(title: String, target: Target, editor: FieldEditor.Choice) {
        val items = editor.entries.map { PickerItem(it.name, it.value.toString()) }
        val selected = editor.entries.indexOfFirst { it.value == editor.current }
        // A value the list does not name can still be typed in.
        val typeNumber = { askNumber(title, target, FieldEditor.Number(editor.current, editor.min, editor.max, false)) }
        activity.pickOne(title, items, selected, activity.getString(R.string.edit_as_number), typeNumber) { index ->
            change(tables.setNumber(target.table, target.row, target.field.index, editor.entries[index].value))
        }
    }

    private fun askText(title: String, target: Target, editor: FieldEditor.Text) {
        val message = activity.getString(R.string.edit_text_fixed_message, editor.maxBytes)
        activity.promptText(title, message, editor.current, activity.getString(R.string.edit_hint_text)) { text ->
            change(tables.setText(target.table, target.row, target.field.index, text))
        }
    }

    private fun askPointedText(title: String, target: Target, editor: FieldEditor.PointedText) {
        val intro = if (editor.capacity > 0) {
            activity.getString(R.string.edit_text_pointed_message, editor.capacity)
        } else {
            activity.getString(R.string.edit_text_new_message)
        }
        val message = if (editor.sharedBy > 0) {
            intro + "\n" + activity.resources.getQuantityString(R.plurals.text_shared_note, editor.sharedBy, editor.sharedBy)
        } else {
            intro
        }
        val editAddress = { edit(target.table, target.row, target.field, asAddress = true) }
        // Text that other pointers use can also be given a copy of its own, which changes nothing for the others.
        val more = {
            if (editor.sharedBy > 0) {
                activity.chooseAction(
                    title,
                    listOf(
                        MenuAction(activity.getString(R.string.edit_as_address)) { editAddress() },
                        MenuAction(activity.getString(R.string.edit_own_copy)) {
                            change(tables.copyText(target.table, target.row, target.field.index))
                        },
                    ),
                )
            } else {
                editAddress()
            }
        }
        val neutral = activity.getString(if (editor.sharedBy > 0) R.string.edit_more else R.string.edit_as_address)
        activity.promptParagraph(title, message, editor.current, neutral, more) { text ->
            change(tables.setText(target.table, target.row, target.field.index, text))
        }
    }

    private fun askAddress(title: String, target: Target, editor: FieldEditor.Address) {
        val initial = if (editor.current >= 0) HexText.hex(editor.current, 6) else ""
        val message = activity.getString(R.string.edit_address_message)
        activity.promptText(title, message, initial, activity.getString(R.string.goto_hint), uppercase = true) { text ->
            change(tables.setAddress(target.table, target.row, target.field.index, text))
        }
    }

    private fun askBits(title: String, target: Target, editor: FieldEditor.Bits) {
        val items = editor.names.mapIndexed { bit, name -> PickerItem(name, bit.toString()) }
        activity.pickMany(title, items, editor.selected) { chosen ->
            change(tables.setBits(target.table, target.row, target.field.index, chosen))
        }
    }

    private fun askColor(title: String, target: Target, editor: FieldEditor.Color) {
        val message = activity.getString(R.string.edit_color_message)
        activity.promptText(title, message, editor.current, activity.getString(R.string.edit_hint_color), uppercase = true) { text ->
            change(tables.setColor(target.table, target.row, target.field.index, text))
        }
    }

    /** "moves of Bulbasaur": what a nested table is called, as seen from the row it belongs to. */
    private fun nestedHeading(target: Target): String {
        val owner = tables.rowLabel(target.table, target.row) ?: activity.getString(R.string.row_default_title, target.row)
        return activity.getString(R.string.nested_page_title, target.field.name, owner)
    }

    /** Performs an accepted change as one undo step, saying what happened when there is something to say; explains a refused one. */
    private fun change(result: EditResult) {
        val problem = try {
            browser.apply(result)
        } catch (e: RuntimeException) {
            e.message ?: e.javaClass.simpleName
        }
        if (problem != null) {
            activity.showMessage(activity.getString(R.string.edit_rejected_title), problem)
            return
        }
        if (result is EditResult.Ready) result.notice?.let { activity.toastLong(it) }
    }
}
