package dev.hexmaniac.android.tables

import android.content.Context
import android.view.View
import android.widget.FrameLayout
import dev.hexmaniac.android.ui.MATCH
import dev.hexmaniac.android.ui.hideKeyboard

/**
 * Keeps the pages of the table browser on top of each other. Only the top page is visible; the pages below keep
 * their state (search text, scroll position) and are brought up to date when they come back.
 */
class PageStack(context: Context, private val onTopChanged: (Page) -> Unit) {
    val container = FrameLayout(context)
    private val pages = ArrayList<Page>()

    /** Pages whose content was read before the latest change of the ROM. */
    private val stale = ArrayList<Page>()

    val top: Page? get() = pages.lastOrNull()

    fun push(page: Page) {
        top?.view?.let {
            // A keyboard left open by the search box of the page below would cover the new page.
            it.findFocus()?.hideKeyboard()
            it.visibility = View.GONE
        }
        pages.add(page)
        container.addView(page.view, FrameLayout.LayoutParams(MATCH, MATCH))
        page.onShown()
        onTopChanged(page)
    }

    /** Removes the top page. Returns false, and keeps it, when it is the only page. */
    fun pop(): Boolean {
        if (pages.size <= 1) return false
        removeTop()
        showTop()
        return true
    }

    /** The ROM changed: the top page is refreshed now, the others when they come back to the top. */
    fun romChanged() {
        stale.clear()
        stale.addAll(pages)
        showTop()
    }

    private fun removeTop() {
        val page = pages.removeAt(pages.size - 1)
        stale.remove(page)
        container.removeView(page.view)
    }

    /** Makes the top page current, refreshing it first when it is out of date; pages that lost their data go. */
    private fun showTop() {
        while (true) {
            val page = pages.lastOrNull() ?: return
            page.view.visibility = View.VISIBLE
            if (!stale.remove(page) || page.refresh() || pages.size <= 1) {
                page.onShown()
                onTopChanged(page)
                return
            }
            removeTop()
        }
    }
}
