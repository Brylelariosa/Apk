package dev.hexmaniac.android.ui

import android.app.Activity
import android.app.AlertDialog
import android.content.DialogInterface
import android.graphics.Typeface
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.Toast

fun Activity.toast(message: String) {
    Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}

fun Activity.toast(messageRes: Int, vararg args: Any) {
    toast(getString(messageRes, *args))
}

/** Like [toast], but stays long enough to read a sentence or two. */
fun Activity.toastLong(message: String) {
    Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}

fun Activity.showMessage(title: String, message: String) {
    AlertDialog.Builder(this)
        .setTitle(title)
        .setMessage(message)
        .setPositiveButton(android.R.string.ok, null)
        .show()
}

fun Activity.confirm(title: String, message: String, positive: String, onYes: () -> Unit) {
    AlertDialog.Builder(this)
        .setTitle(title)
        .setMessage(message)
        .setPositiveButton(positive) { _, _ -> onYes() }
        .setNegativeButton(android.R.string.cancel, null)
        .show()
}

/** A list of choices; calls [onPick] with the index of the one the user taps. */
fun Activity.choose(title: String, items: Array<String>, onPick: (Int) -> Unit) {
    AlertDialog.Builder(this)
        .setTitle(title)
        .setItems(items) { _, which -> onPick(which) }
        .show()
}

/** One entry of a menu of actions: what it says and what it does. */
class MenuAction(val label: String, val run: () -> Unit)

/** Shows [actions] as a list under [title] and runs the one the user taps. */
fun Activity.chooseAction(title: String, actions: List<MenuAction>) {
    choose(title, Array(actions.size) { actions[it].label }) { actions[it].run() }
}

/**
 * Asks for one line of monospace text and calls [onOk] with it. The keyboard opens at once and its Done key
 * confirms. [uppercase] makes the keyboard type capitals, which suits hex input.
 */
fun Activity.promptText(
    title: String,
    message: String?,
    initial: String,
    hint: String,
    uppercase: Boolean = false,
    onOk: (String) -> Unit,
) {
    val input = EditText(this)
    input.setText(initial)
    input.hint = hint
    input.typeface = Typeface.MONOSPACE
    var type = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
    if (uppercase) type = type or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
    input.inputType = type
    input.imeOptions = EditorInfo.IME_ACTION_DONE
    input.setSelectAllOnFocus(true)

    val box = FrameLayout(this)
    box.setPadding(dp(24), dp(8), dp(24), 0)
    box.addView(input, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

    val builder = AlertDialog.Builder(this).setTitle(title).setView(box)
    if (message != null) builder.setMessage(message)
    builder.setPositiveButton(android.R.string.ok) { _, _ -> onOk(input.text.toString()) }
    builder.setNegativeButton(android.R.string.cancel, null)
    val dialog = builder.create()
    input.setOnEditorActionListener { _, actionId, _ ->
        if (actionId == EditorInfo.IME_ACTION_DONE) {
            dialog.getButton(DialogInterface.BUTTON_POSITIVE).performClick()
            true
        } else {
            false
        }
    }
    dialog.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
    dialog.show()
}

/**
 * Asks for text of several lines (the Enter key starts a new line) and calls [onOk] with it. An optional third
 * button, labelled [neutralLabel], runs [onNeutral] instead.
 */
fun Activity.promptParagraph(
    title: String,
    message: String?,
    initial: String,
    neutralLabel: String? = null,
    onNeutral: () -> Unit = {},
    onOk: (String) -> Unit,
) {
    val input = EditText(this)
    input.setText(initial)
    input.setSelection(initial.length)
    input.typeface = Typeface.MONOSPACE
    input.textSize = 14f
    input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
    input.setHorizontallyScrolling(false)
    input.minLines = 3
    input.maxLines = 8
    input.gravity = Gravity.TOP or Gravity.START

    val box = FrameLayout(this)
    box.setPadding(dp(24), dp(8), dp(24), 0)
    box.addView(input, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

    val builder = AlertDialog.Builder(this).setTitle(title).setView(box)
    if (message != null) builder.setMessage(message)
    builder.setPositiveButton(android.R.string.ok) { _, _ -> onOk(input.text.toString()) }
    builder.setNegativeButton(android.R.string.cancel, null)
    if (neutralLabel != null) builder.setNeutralButton(neutralLabel) { _, _ -> onNeutral() }
    val dialog = builder.create()
    dialog.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
    dialog.show()
}
