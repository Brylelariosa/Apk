package dev.hexmaniac.android.ui

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import dev.hexmaniac.android.R

/** The rounded box above a list; [onQuery] hears every change of the text. */
class SearchBar(context: Context, hint: String, onQuery: (String) -> Unit) : LinearLayout(context) {
    private val input = EditText(context)

    init {
        orientation = VERTICAL
        setBackgroundColor(context.getColor(R.color.surface))

        input.hint = hint
        input.textSize = 15f
        input.setTextColor(context.getColor(R.color.text_primary))
        input.setHintTextColor(context.getColor(R.color.text_dim))
        input.setBackgroundResource(R.drawable.bg_search)
        input.setCompoundDrawablesRelativeWithIntrinsicBounds(R.drawable.ic_search, 0, 0, 0)
        input.compoundDrawablePadding = context.dp(10)
        input.setPadding(context.dp(14), 0, context.dp(14), 0)
        input.minHeight = context.dp(44)
        input.gravity = Gravity.CENTER_VERTICAL
        input.isSingleLine = true
        input.imeOptions = EditorInfo.IME_ACTION_SEARCH
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        input.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}

            override fun afterTextChanged(s: Editable?) {
                onQuery(s?.toString().orEmpty())
            }
        })
        input.setOnEditorActionListener { _, _, _ ->
            input.hideKeyboard()
            true
        }

        val params = LayoutParams(MATCH, WRAP)
        params.setMargins(context.dp(12), context.dp(10), context.dp(12), context.dp(10))
        addView(input, params)
        addDivider()
    }

    val text: String get() = input.text.toString()

    fun clear() {
        input.setText("")
    }
}

/**
 * A search box over a list, with a line of text for when nothing is left to show. Pages build their adapter and
 * hand it to [listView]; the touch handling is theirs too.
 */
class SearchList(context: Context, hint: String, emptyMessage: String, onQuery: (String) -> Unit) : LinearLayout(context) {
    val listView = ListView(context)
    private val bar = SearchBar(context, hint, onQuery)
    private val empty = TextView(context)

    init {
        orientation = VERTICAL
        // The page takes the keyboard focus, so the search box does not pop the keyboard up by itself.
        isFocusableInTouchMode = true
        descendantFocusability = FOCUS_BEFORE_DESCENDANTS
        addView(bar, LayoutParams(MATCH, WRAP))

        listView.divider = null
        listView.dividerHeight = 0
        listView.selector = ColorDrawable(Color.TRANSPARENT)
        listView.isFastScrollEnabled = true
        listView.setBackgroundColor(context.getColor(R.color.bg))

        empty.text = emptyMessage
        empty.textSize = 14f
        empty.gravity = Gravity.CENTER
        empty.setTextColor(context.getColor(R.color.text_dim))
        empty.setPadding(context.dp(32), context.dp(48), context.dp(32), 0)

        val body = FrameLayout(context)
        body.addView(listView, FrameLayout.LayoutParams(MATCH, MATCH))
        body.addView(empty, FrameLayout.LayoutParams(MATCH, MATCH))
        listView.emptyView = empty
        addView(body, LayoutParams(MATCH, 0, 1f))
    }

    val query: String get() = bar.text

    /** The line shown while the list has no rows; it can differ between "nothing exists" and "nothing matches". */
    var emptyMessage: CharSequence
        get() = empty.text
        set(value) {
            empty.text = value
        }
}
