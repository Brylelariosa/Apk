package dev.hexmaniac.android.session

import android.app.Activity
import android.net.Uri
import dev.hexmaniac.android.R
import dev.hexmaniac.android.io.RomFiles
import dev.hexmaniac.android.ui.BusyRunner
import dev.hexmaniac.android.ui.toast

/** Writes the ROM of a session to a file behind a busy dialog; every screen that offers "Save" uses one. */
class RomSaver(private val activity: Activity, private val busy: BusyRunner) {

    /**
     * Saves to [uri]. With [makeCurrent] the session now belongs to that file ("save as"). [then] runs once the
     * file is written.
     */
    fun saveTo(session: RomSession, uri: Uri, makeCurrent: Boolean, then: () -> Unit = {}) {
        val resolver = activity.contentResolver
        val bytes = session.document.rom.bytes
        busy.run(activity.getString(R.string.busy_saving), {
            RomFiles.write(resolver, uri, bytes)
            if (makeCurrent) RomFiles.displayName(resolver, uri) else null
        }) { newName ->
            if (makeCurrent) {
                session.uri = uri
                if (newName != null) session.name = newName
            }
            session.document.markSaved()
            activity.toast(R.string.toast_saved)
            then()
        }
    }

    /** Saves to the file the ROM was opened from. */
    fun save(session: RomSession, then: () -> Unit = {}) = saveTo(session, session.uri, makeCurrent = false, then = then)
}
