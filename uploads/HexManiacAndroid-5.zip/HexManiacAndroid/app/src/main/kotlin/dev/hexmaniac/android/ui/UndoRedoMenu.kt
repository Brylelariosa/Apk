package dev.hexmaniac.android.ui

import android.app.Activity
import android.view.Menu
import dev.hexmaniac.android.R
import dev.hexmaniac.core.rom.RomDocument

/**
 * Brings the Undo and Redo entries of [menu] in line with [document]: each is enabled when there is a step to take,
 * and names that step ("Undo: Edit data.pokemon.stats[1].hp"). Without a document both are disabled.
 */
fun Activity.updateUndoRedo(menu: Menu, document: RomDocument?) {
    val undo = menu.findItem(R.id.action_undo)
    undo?.isEnabled = document?.canUndo == true
    undo?.title = stepTitle(document?.undoLabel, R.string.action_undo, R.string.action_undo_with_label)

    val redo = menu.findItem(R.id.action_redo)
    redo?.isEnabled = document?.canRedo == true
    redo?.title = stepTitle(document?.redoLabel, R.string.action_redo, R.string.action_redo_with_label)
}

private fun Activity.stepTitle(label: String?, plain: Int, withLabel: Int): String =
    if (label != null) getString(withLabel, label) else getString(plain)
