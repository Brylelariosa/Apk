package dev.hexmaniac.android.tables

import android.app.Activity
import android.view.View
import android.view.ViewGroup
import dev.hexmaniac.android.R
import dev.hexmaniac.android.ui.HeadedAdapter
import dev.hexmaniac.android.ui.MenuAction
import dev.hexmaniac.android.ui.SearchList
import dev.hexmaniac.android.ui.TwoLineRow
import dev.hexmaniac.android.ui.chooseAction
import dev.hexmaniac.core.table.TableEntry
import dev.hexmaniac.core.table.TablePath
import dev.hexmaniac.core.table.TableSection
import dev.hexmaniac.core.table.TextFilter

/** The first page of the table browser: every table found in the ROM, under the headings of the reference data. */
class TableListPage(
    private val activity: Activity,
    private val browser: TableBrowser,
    private val navigator: TableNavigator,
    initial: List<TableSection>,
) : Page {

    private sealed class Item {
        class Heading(val title: String) : Item()

        class Table(val entry: TableEntry) : Item()
    }

    private val search = SearchList(
        activity,
        activity.getString(R.string.tables_search_hint),
        activity.getString(R.string.tables_none_found),
    ) { queryChanged(it) }
    private val adapter = Adapter()
    private var sections = initial
    private var items: List<Item> = emptyList()

    init {
        search.listView.adapter = adapter
        search.listView.setOnItemClickListener { _, _, position, _ -> tableAt(position)?.let { open(it) } }
        search.listView.setOnItemLongClickListener { _, _, position, _ ->
            val entry = tableAt(position)
            if (entry != null) offerActions(entry)
            entry != null
        }
        showMatches("")
    }

    override val view: View get() = search

    override val title: String get() = activity.getString(R.string.tables_title)

    override val subtitle: String get() = activity.tableCountText(sections.sumOf { it.tables.size })

    override fun refresh(): Boolean {
        sections = browser.tables.sections()
        showMatches(search.query)
        return true
    }

    private fun queryChanged(query: String) {
        showMatches(query)
        search.listView.setSelection(0)
    }

    /** Lists the tables whose name, or the heading they are under, contains every word of [query]. */
    private fun showMatches(query: String) {
        val filter = TextFilter(query)
        val matching = ArrayList<Item>()
        for (section in sections) {
            val tables = section.tables.filter { filter.matches(section.title + " " + it.name) }
            if (tables.isEmpty()) continue
            matching.add(Item.Heading(section.title))
            for (entry in tables) matching.add(Item.Table(entry))
        }
        items = matching
        search.emptyMessage = activity.getString(if (filter.isEmpty) R.string.tables_none_found else R.string.search_no_matches)
        adapter.notifyDataSetChanged()
    }

    private fun tableAt(position: Int): TableEntry? = (items.getOrNull(position) as? Item.Table)?.entry

    private fun open(entry: TableEntry) = navigator.openTable(TablePath(entry.name), entry.name)

    private fun offerActions(entry: TableEntry) {
        activity.chooseAction(
            entry.name,
            listOf(
                MenuAction(activity.getString(R.string.open_table)) { open(entry) },
                MenuAction(activity.getString(R.string.show_table_in_hex)) { navigator.showInHex(entry.start, entry.rowSize) },
            ),
        )
    }

    private inner class Adapter : HeadedAdapter(activity) {
        override fun getCount(): Int = items.size

        override fun isHeading(position: Int): Boolean = items[position] is Item.Heading

        override fun headingText(position: Int): String = (items[position] as Item.Heading).title

        override fun rowView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val row = (convertView as? TwoLineRow) ?: TwoLineRow(activity)
            val entry = (items[position] as Item.Table).entry
            val summary = activity.getString(R.string.table_entry_summary, activity.rowCountText(entry.rowCount), entry.rowSize)
            row.bind(null, entry.name, summary)
            return row
        }
    }
}
