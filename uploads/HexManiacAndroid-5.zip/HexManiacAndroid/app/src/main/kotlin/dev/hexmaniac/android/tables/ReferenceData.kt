package dev.hexmaniac.android.tables

import dev.hexmaniac.core.io.ClasspathResources
import dev.hexmaniac.core.table.data.ReferenceLibrary
import dev.hexmaniac.core.text.PcsTable

/**
 * The bundled reference data (character set, table definitions, constants, lists). Reading it takes a moment, so it
 * is read once, on first use, and kept for the life of the process.
 */
object ReferenceData {
    val library: ReferenceLibrary by lazy { ReferenceLibrary(ClasspathResources()) }

    val pcs: PcsTable by lazy {
        try {
            PcsTable.load(ClasspathResources())
        } catch (e: Throwable) {
            PcsTable.DEFAULT
        }
    }

    /**
     * Reads the files now. Call it off the UI thread while a ROM opens, so that using the tables does not wait.
     * It only saves time: when something goes wrong here, whoever needs the data asks again and reports the problem.
     */
    fun warmUp() {
        try {
            library.supports("")
            pcs.hashCode()
        } catch (e: Exception) {
            // see above
        }
    }
}
