package dev.hexmaniac.android.ui

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.Typeface
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.BaseAdapter
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import dev.hexmaniac.android.R
import dev.hexmaniac.core.table.TextFilter

/** One entry of a picker: its name, and a small note beside it (such as the number behind a name). */
class PickerItem(val text: String, val note: String? = null)

/**
 * Asks for one of [items] from a searchable list; [selected] (or -1) marks the current one. An [extraLabel] adds a
 * third button that calls [onExtra] instead of picking.
 */
fun Activity.pickOne(
    title: String,
    items: List<PickerItem>,
    selected: Int,
    extraLabel: String? = null,
    onExtra: () -> Unit = {},
    onPick: (Int) -> Unit,
) {
    var dialog: AlertDialog? = null
    val list = PickerList(this, items, multi = false, current = selected, checked = HashSet())
    list.onTap = { index ->
        dialog?.dismiss()
        onPick(index)
    }
    val builder = AlertDialog.Builder(this).setTitle(title).setView(list.view)
    builder.setNegativeButton(android.R.string.cancel, null)
    if (extraLabel != null) builder.setNeutralButton(extraLabel) { _, _ -> onExtra() }
    val created = builder.create()
    dialog = created
    created.window?.setSoftInputMode(
        WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN or WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE,
    )
    created.show()
    list.scrollToCurrent()
}

/** Asks which of [items] are ticked; [onDone] gets the positions that are ticked when the user taps OK. */
fun Activity.pickMany(title: String, items: List<PickerItem>, selected: Set<Int>, onDone: (Set<Int>) -> Unit) {
    val checked = HashSet(selected)
    val list = PickerList(this, items, multi = true, current = -1, checked = checked)
    val builder = AlertDialog.Builder(this).setTitle(title).setView(list.view)
    builder.setPositiveButton(android.R.string.ok) { _, _ -> onDone(HashSet(checked)) }
    builder.setNegativeButton(android.R.string.cancel, null)
    builder.setNeutralButton(R.string.picker_all, null)
    val created = builder.create()
    created.window?.setSoftInputMode(
        WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN or WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE,
    )
    created.show()
    // The third button changes the ticks without closing the dialog, so its click is taken over here.
    val toggle = created.getButton(AlertDialog.BUTTON_NEUTRAL)
    list.onChecksChanged = { toggle.setText(if (list.allVisibleChecked()) R.string.picker_none else R.string.picker_all) }
    toggle.setOnClickListener { list.toggleVisible() }
    list.onChecksChanged()
}

/** The search box and the list of a picker. */
private class PickerList(
    private val context: Context,
    private val items: List<PickerItem>,
    private val multi: Boolean,
    private val current: Int,
    private val checked: MutableSet<Int>,
) {
    /** Single choice: the position of the tapped entry. */
    var onTap: (Int) -> Unit = {}

    /** Several choices: the ticks, or the entries that are listed, changed. */
    var onChecksChanged: () -> Unit = {}

    /** Positions in [items] of the entries that match the search, in order. */
    private var shown = IntArray(items.size) { it }
    private val listView = ListView(context)
    private val adapter = Adapter()

    val view: LinearLayout = LinearLayout(context)

    init {
        view.orientation = LinearLayout.VERTICAL
        view.setBackgroundColor(context.getColor(R.color.surface))
        view.addView(SearchBar(context, context.getString(R.string.picker_search_hint)) { applyFilter(it) }, LinearLayout.LayoutParams(MATCH, WRAP))

        listView.divider = null
        listView.dividerHeight = 0
        listView.isFastScrollEnabled = true
        listView.adapter = adapter
        listView.onItemClickListener = AdapterView.OnItemClickListener { _, _, position, _ ->
            val index = shown.getOrNull(position)
            if (index != null) tapped(index)
        }
        val height = minOf(context.dp(420), (context.resources.displayMetrics.heightPixels * 0.5f).toInt())
        view.addView(listView, LinearLayout.LayoutParams(MATCH, height))
    }

    private fun tapped(index: Int) {
        if (!multi) {
            onTap(index)
            return
        }
        if (!checked.add(index)) checked.remove(index)
        adapter.notifyDataSetChanged()
        onChecksChanged()
    }

    private fun applyFilter(query: String) {
        shown = TextFilter(query).select(items) { it.text + " " + it.note.orEmpty() }
        adapter.notifyDataSetChanged()
        onChecksChanged()
    }

    fun allVisibleChecked(): Boolean = shown.isNotEmpty() && shown.all { it in checked }

    /** Ticks everything that is listed, or unticks it when it is all ticked already. */
    fun toggleVisible() {
        if (allVisibleChecked()) shown.forEach { checked.remove(it) } else shown.forEach { checked.add(it) }
        adapter.notifyDataSetChanged()
        onChecksChanged()
    }

    /** Shows the current choice a little below the top edge of the list. */
    fun scrollToCurrent() {
        val position = shown.indexOf(current)
        if (position >= 0) listView.post { listView.setSelectionFromTop(position, context.dp(96)) }
    }

    private inner class Adapter : BaseAdapter() {
        override fun getCount(): Int = shown.size

        override fun getItem(position: Int): Any? = null

        override fun getItemId(position: Int): Long = shown[position].toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val row = (convertView as? PickerRow) ?: PickerRow(context)
            val index = shown[position]
            row.bind(items[index], multi, index in checked, !multi && index == current)
            return row
        }
    }
}

private class PickerRow(context: Context) : LinearLayout(context) {
    private val box = CheckBox(context)
    private val name = TextView(context)
    private val note = TextView(context)
    private val primary = context.getColor(R.color.text_primary)
    private val accent = context.getColor(R.color.accent)

    init {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        minimumHeight = context.dp(48)
        setPadding(context.dp(16), context.dp(4), context.dp(16), context.dp(4))
        setBackgroundResource(R.drawable.bg_action)

        box.isClickable = false
        box.isFocusable = false
        addView(box, LayoutParams(WRAP, WRAP))

        name.textSize = 15f
        name.maxLines = 2
        name.ellipsize = TextUtils.TruncateAt.END
        addView(name, LayoutParams(0, WRAP, 1f))

        note.textSize = 12.5f
        note.typeface = Typeface.MONOSPACE
        note.setTextColor(context.getColor(R.color.text_dim))
        val noteParams = LayoutParams(WRAP, WRAP)
        noteParams.leftMargin = context.dp(12)
        addView(note, noteParams)
    }

    fun bind(item: PickerItem, showBox: Boolean, checked: Boolean, highlighted: Boolean) {
        box.visibility = if (showBox) VISIBLE else GONE
        box.isChecked = checked
        name.text = item.text
        name.setTextColor(if (highlighted) accent else primary)
        name.typeface = if (highlighted) Typeface.create("sans-serif-medium", Typeface.NORMAL) else Typeface.DEFAULT
        note.visibility = if (item.note.isNullOrEmpty()) GONE else VISIBLE
        note.text = item.note
    }
}
