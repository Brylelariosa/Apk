package com.novaenhance.ai.utils

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Locale

/** The Dashboard's score text: small real gains must not read as "0%" any more. */
class ImprovementScoreFormatTest {

    private fun show(score: Float) = formatImprovementScore(score, Locale.US)

    @Test
    fun `a score of exactly zero is 0 percent`() {
        assertEquals("0%", show(0f))
        assertEquals("0%", show(-0f))
    }

    @Test
    fun `a never-promoted or broken value is 0 percent, not an error`() {
        assertEquals("0%", show(-3f))
        assertEquals("0%", show(Float.NaN))
    }

    @Test
    fun `the value that showed as 0 percent on the phone now shows its decimals`() {
        // Model v10 on the Infinix HOT 11 stored 0.149, which toInt() printed as "0%".
        assertEquals("0.15%", show(0.149f))
    }

    @Test
    fun `no positive score is ever shown as 0 percent`() {
        val samples = listOf(1e-9f, 0.001f, 0.0049f, 0.0099f, 0.01f, 0.149f, 0.5f, 0.999f, 1f, 1.2f, 9.99f, 10f, 10.4f, 99.9f, 100f)
        for (score in samples) {
            assertNotEquals("score $score", "0%", show(score))
        }
    }

    @Test
    fun `a positive score too small to print says so`() {
        assertEquals("<0.01%", show(0.004f))
        assertEquals("<0.01%", show(1e-9f))
        assertEquals("0.01%", show(0.01f))
    }

    @Test
    fun `below one percent gets two decimals`() {
        assertEquals("0.50%", show(0.5f))
        assertEquals("0.07%", show(0.07f))
        assertEquals("0.99%", show(0.99f))
    }

    @Test
    fun `from one to ten percent gets one decimal`() {
        assertEquals("1.0%", show(1f))
        assertEquals("3.5%", show(3.54f))
        assertEquals("9.9%", show(9.94f))
    }

    @Test
    fun `ten percent and up is a whole number`() {
        assertEquals("10%", show(10f))
        assertEquals("45%", show(45.4f))
        assertEquals("46%", show(45.6f))
        assertEquals("100%", show(100f))
    }

    @Test
    fun `a value above the scale is held at 100 percent`() {
        assertEquals("100%", show(250f))
    }

    @Test
    fun `the decimal mark follows the phone's language`() {
        assertEquals("0,15%", formatImprovementScore(0.149f, Locale.GERMANY))
        assertEquals("3,5%", formatImprovementScore(3.54f, Locale.GERMANY))
        assertEquals("45%", formatImprovementScore(45.4f, Locale.GERMANY))
    }

    @Test
    fun `a bigger score never prints as a smaller number`() {
        // Compare the numbers behind the text over the whole range, skipping the "<0.01%" case which has no number.
        var previous = -1.0
        var score = 0.01f
        while (score <= 100f) {
            val text = show(score)
            val number = text.removeSuffix("%").toDouble()
            assertTrue("score $score -> $text should not go backwards after $previous", number >= previous)
            previous = number
            score *= 1.07f
        }
    }
}
