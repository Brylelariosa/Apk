package com.novaenhance.ai.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.ui.Alignment
import androidx.compose.ui.res.painterResource
import com.novaenhance.ai.R
import com.novaenhance.ai.database.entities.DatasetPairEntity
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.novaenhance.ai.training.dataset.DEFAULT_SYNTHETIC_VARIANTS
import com.novaenhance.ai.ui.components.NovaBottomBar
import com.novaenhance.ai.ui.components.NovaButton
import com.novaenhance.ai.ui.components.NovaButtonStyle
import com.novaenhance.ai.ui.components.PairPreviewDialog
import com.novaenhance.ai.ui.components.RunProgressPanel
import com.novaenhance.ai.ui.components.ThumbnailImage
import com.novaenhance.ai.ui.viewmodel.DatasetViewModel
import com.novaenhance.ai.ui.viewmodel.NovaViewModelFactory
import android.net.Uri

@Composable
fun DatasetManagerScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val viewModel: DatasetViewModel = viewModel(factory = NovaViewModelFactory(context))
    val state by viewModel.uiState.collectAsState()

    // While photos are being generated the other ways of adding to the dataset wait: they would compete for the same
    // memory and CPU, and the run owns the screen's progress display.
    val generating = state.generation != null

    // "Delete all" needs something to delete and a quiet dataset: not while pairs are being added (Auto-Generate, import,
    // a single add or remove in flight) and not while a training run is reading them.
    val canDeleteAll = state.pairs.isNotEmpty() && !generating && !state.isBusy && !state.isTrainingActive

    var pendingLowUri by remember { mutableStateOf<Uri?>(null) }
    var previewedPair by remember { mutableStateOf<DatasetPairEntity?>(null) }
    var showDeleteAllDialog by remember { mutableStateOf(false) }

    val pickLowLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        pendingLowUri = uri
    }
    val pickHighLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        val low = pendingLowUri
        if (low != null && uri != null) {
            viewModel.addManualPair(low, uri)
            pendingLowUri = null
        }
    }
    // Auto-Generate takes SEVERAL photos at once: the system photo picker lets the user tick as many as they like (it
    // falls back to the document picker, which also allows multiple selection, where the photo picker isn't available).
    // One photo works exactly as before - it is just a one-photo selection.
    val pickSyntheticSourcesLauncher = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia()) { uris ->
        if (uris.isNotEmpty()) viewModel.addSyntheticPairsFromPhotos(uris)
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { viewModel.importDataset(it) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Dataset Manager") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(painterResource(R.drawable.ic_back_arrow), contentDescription = "Back") } }
            )
        },
        // Adding pairs is what this screen is for, so those buttons (and the progress of a generation run) stay
        // pinned at the bottom instead of being pushed down by the header or lost below a long list.
        bottomBar = {
            NovaBottomBar {
                state.generation?.let { progress ->
                    RunProgressPanel(
                        title = if (progress.stopping) {
                            "Stopping after this photo…"
                        } else {
                            "Generating pairs - photo ${progress.currentPhoto} of ${progress.total}…"
                        },
                        // One photo has no "how far": its bar just runs.
                        fraction = if (progress.total > 1) progress.fraction else null,
                        detail = "${progress.pairsCreated} pairs added so far",
                        // Stopping a one-photo run would still finish that photo, so there is nothing to offer.
                        onCancel = if (progress.total > 1) viewModel::cancelGeneration else null,
                        cancelEnabled = !progress.stopping
                    )
                }
                if (pendingLowUri != null) {
                    Text(
                        "Now pick the matching high-quality image...",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        NovaButton(
                            text = "Select High-Quality Match",
                            enabled = !generating,
                            onClick = { pickHighLauncher.launch("image/*") },
                            modifier = Modifier.weight(1f)
                        )
                        NovaButton(
                            text = "Cancel",
                            style = NovaButtonStyle.Outlined,
                            onClick = { pendingLowUri = null }
                        )
                    }
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        NovaButton(
                            text = "Add Pair",
                            enabled = !generating,
                            onClick = { pickLowLauncher.launch("image/*") },
                            modifier = Modifier.weight(1f)
                        )
                        NovaButton(
                            text = "Auto-Generate",
                            style = NovaButtonStyle.Outlined,
                            enabled = !generating,
                            onClick = {
                                pickSyntheticSourcesLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
        ) {
            item {
                Column(
                    modifier = Modifier.padding(bottom = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "${state.pairs.size} pairs - ${formatBytes(state.totalSizeBytes)}",
                            style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier.weight(1f)
                        )
                        // The bulk counterpart of the bin icon on each pair. A quiet red text button rather than a big
                        // one: it is easy to reach but hard to hit by accident, and a confirmation follows anyway.
                        TextButton(
                            onClick = { showDeleteAllDialog = true },
                            enabled = canDeleteAll,
                            colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error),
                            modifier = Modifier.heightIn(min = 48.dp)
                        ) {
                            Text("Delete all")
                        }
                    }
                    if (state.isTrainingActive && state.pairs.isNotEmpty()) {
                        Text(
                            "Training is running - Delete all is available again when it has finished",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Text(
                        "Auto-Generate: pick one or more sharp photos - $DEFAULT_SYNTHETIC_VARIANTS degraded copies are made of each",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        NovaButton(
                            text = "Import Dataset",
                            style = NovaButtonStyle.Outlined,
                            enabled = !generating,
                            onClick = { importLauncher.launch("application/zip") },
                            modifier = Modifier.weight(1f)
                        )
                        NovaButton(
                            text = "Export Dataset",
                            style = NovaButtonStyle.Outlined,
                            onClick = {
                                viewModel.exportDataset { file ->
                                    val uri = androidx.core.content.FileProvider.getUriForFile(
                                        context, "${context.packageName}.fileprovider", file
                                    )
                                    val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                                        type = "application/zip"
                                        putExtra(android.content.Intent.EXTRA_STREAM, uri)
                                        addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }
                                    context.startActivity(android.content.Intent.createChooser(intent, "Share dataset"))
                                }
                            },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    state.message?.let {
                        Text(
                            it.text,
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (it.isError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            items(state.pairs, key = { it.id }) { pair ->
                Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Low-quality -> high-quality, side by side, so an
                            // auto-generated pair's degradation is something you
                            // can actually SEE, not just trust from a percentage.
                            // Tappable: opens a full-screen drag-to-compare view,
                            // since a 72dp thumbnail is too small to judge subtle
                            // degradation (blur/noise/mild JPEG blocking) by eye.
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.clickable { previewedPair = pair }
                            ) {
                                ThumbnailImage(path = pair.lowQualityPath)
                                Text("→", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                ThumbnailImage(path = pair.highQualityPath)
                            }
                            IconButton(onClick = { viewModel.removePair(pair) }) {
                                Icon(painterResource(R.drawable.ic_delete), contentDescription = "Remove pair")
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (pair.isSynthetic) "Auto-generated pair" else "Manual pair",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Text(
                            text = when {
                                !pair.isValid -> "Invalid: ${pair.invalidReason}"
                                pair.isDuplicate -> "Duplicate"
                                pair.analyzedAt == null -> "Analyzing..."
                                else -> "Quality ${(pair.qualityScore * 100).toInt()}% - Difficulty ${(pair.difficultyScore * 100).toInt()}%"
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            "Tap images to compare full-screen",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        }
    }

    previewedPair?.let { pair ->
        PairPreviewDialog(
            lowQualityPath = pair.lowQualityPath,
            highQualityPath = pair.highQualityPath,
            subtitle = if (pair.isSynthetic) "Auto-generated pair" else "Manual pair",
            onDismiss = { previewedPair = null }
        )
    }

    if (showDeleteAllDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteAllDialog = false },
            title = { Text(if (state.pairs.size == 1) "Delete the pair?" else "Delete all ${state.pairs.size} pairs?") },
            text = {
                Text(
                    "Every training image pair (${formatBytes(state.totalSizeBytes)}) is removed from this phone. " +
                        "Your AI's learned knowledge is kept either way. This can't be undone."
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteAllPairs()
                        showDeleteAllDialog = false
                    }
                ) { Text("Delete all", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { showDeleteAllDialog = false }) { Text("Keep") } }
        )
    }
}

private fun formatBytes(bytes: Long): String = when {
    bytes >= 1_000_000 -> "%.1f MB".format(bytes / 1_000_000.0)
    bytes >= 1_000 -> "%.1f KB".format(bytes / 1_000.0)
    else -> "$bytes B"
}
