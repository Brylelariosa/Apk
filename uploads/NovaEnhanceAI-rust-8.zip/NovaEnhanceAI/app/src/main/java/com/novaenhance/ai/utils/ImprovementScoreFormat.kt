package com.novaenhance.ai.utils

import java.util.Locale
import kotlin.math.roundToInt

/**
 * How the Dashboard writes the "Improvement score".
 *
 * The score ([com.novaenhance.ai.database.entities.ModelEntity.improvementScore]) is a rolling figure on a 0-100
 * scale that moves by only a fraction of a point per promoted training session: ModelTrainer keeps 70 % of the old
 * value and adds 30 % of the session's average validation gain (four 0-1 quality proxies, times 100). A real but small
 * result such as 0.149 was cut to "0%" by `toInt()`, so the card looked stuck at zero after every session.
 *
 * Small values now keep their decimals, and "0%" is shown only for a score that is really zero:
 *
 * - below 0.01 -> "<0.01%" (positive, but too small to print)
 * - below 1    -> two decimals ("0.15%")
 * - below 10   -> one decimal ("3.5%")
 * - 10 and up  -> a whole number ("45%")
 *
 * Pure function (no Android types), so it is unit-tested on the JVM - see ImprovementScoreFormatTest.
 */
fun formatImprovementScore(score: Float, locale: Locale = Locale.getDefault()): String {
    if (score.isNaN() || score <= 0f) return "0%"
    val shown = score.coerceAtMost(100f)
    return when {
        shown < 0.01f -> "<0.01%"
        shown < 1f -> String.format(locale, "%.2f%%", shown)
        shown < 10f -> String.format(locale, "%.1f%%", shown)
        else -> "${shown.roundToInt()}%"
    }
}
