# Changelog

## 1.6
### Added
- **Floating lyrics: a place and a look for every app.** Drag the floating lyrics while Instagram is open and Melodiq
  remembers the spot *for Instagram*; open YouTube, drag it somewhere else, and that is remembered for YouTube. The
  next time you open either app the window is already where you put it. Apps you never touched use the default
  style (Settings → Floating lyrics). Settings → *Floating lyrics per app* lists the apps that have a style; tap
  one to change its position, size, lines, font, colours, background, width, animation (the same options as the
  default style) or to switch the floating lyrics **off in that app only**. *Add an app* makes a style for an app
  without dragging; *Use the default style* and *Remove this app* undo it. The master switch *A style for each
  app* turns the whole thing off (then dragging moves the one default position again).
  It needs Android's **Usage access** permission (Melodiq only learns the *name of the app in front*, nothing
  from inside it). Android has no pop-up for it, so the section has an *Allow usage access* button that explains
  it and opens the page. Without it every app simply uses the default style, as before.
- **Notification: shuffle and repeat buttons.** Two new buttons whose icons show the state (on = bright with a dot,
  off = dim; repeat shows a *1* for repeat-one). They follow previous / next in the expanded notification and sit
  on either side of previous / next in the expanded media card of Android 13+. They stay in step with the Now
  Playing screen and the headset, whoever changed shuffle or repeat.

### Changed
- The options that shape the floating window (text, window, animation) moved out of `SettingsScreen` into
  `FloatingStyleControls`, so the default style and every app's style offer exactly the same choices. `SubHeading`
  and `percent` moved to `SettingsControls`, `FloatingPreview` to the same new file.
- `FloatingLyricsOverlay` no longer reads the settings directly: it works from one `resolved` style (the default or
  the one of the app on screen). Dragging saves into the app's profile (or the default when styles are not per app).
- `AndroidManifest.xml`: `PACKAGE_USAGE_STATS` and a `<queries>` entry for launcher apps (Android 11+ hides other
  apps otherwise; the *Add an app* list needs them).

### Notes
- Android draws the **previous / play / next** buttons of the media card itself (on Android 13+ from the playback
  state, with its own icons), so an app cannot restyle those three. What an app *can* do is add buttons with its
  own icons, which is what shuffle and repeat are.

## 1.5
### Added
- **Playlists.** A new *Playlists* tab. Make any number of playlists (Japan, Love songs, …), name them, rename or
  delete them. Add songs from the **⋮** menu of any song (Home, Library, Search, inside a playlist), from the new
  *playlist* button on Now Playing, or in bulk with *Add songs* inside a playlist (tick many, add once). Each
  playlist has *Play*, *Shuffle* and *Remove from this playlist*. Names are trimmed and must be unique. Playlists
  use the table that already existed, so nothing is migrated and nothing is lost.
- **Now Playing animation instead of the cover.** Most songs have no cover art, so the middle of Now Playing is now
  an animation that moves while music plays: *Ring* (bars around a pulsing core), *Bars* or *Waves*, coloured
  from the album when it has art. It settles down when the music pauses. Settings → Now Playing look → *Picture*:
  *Animation* (default), *Album cover*, or *Auto* (cover when the song has one). It is a pretend spectrum, not tied
  to the audio, so it needs no permission.
- **Sync timing, redone.** A *Sync* button above the lyrics opens a panel *over the lyrics*, so you watch the lines
  move while you adjust: a slider (±10 s), −1 s / +1 s buttons, and −0.1 s / +0.1 s buttons you can **hold** to
  repeat. Applied at once, nothing to confirm; *Reset* puts it back. The old +/- row in the options dialog is gone
  (the options dialog just links to the panel). The limit is now ±30 s (the buttons go past the slider).
- **Song title in lyrics mode.** The lyrics used to replace the title; a small title + artist header (with the
  favourite and playlist buttons) now stays above them.
- **Notification.** Melodiq's own status-bar icon, and *previous / play / next* now stay in place — they no longer
  lose a button on the last song (which made play jump across and left an empty slot on Android 13+).
- The lyrics list in *Choose lyrics* marks the version that is **In use**, and reopening it is instant for a search
  that was already made (the *Search* button always asks again).

### Fixed
- **Lyrics did not follow the song.** The active line was scrolled to the *bottom* edge of the list instead of the
  middle, so it slid out of sight and the list looked stuck. (`viewportSize` includes the content padding; the middle
  is `(viewportStartOffset + viewportEndOffset) / 2`.) Also: after you scroll the list yourself it now glides back to
  the current line a few seconds after you let go (before, it waited for the next line change), and before the
  first line (new song, replay) it returns to the top.
- **The keyboard covered the lyrics in the editor.** *Edit lyrics* is now a full screen that is pushed up by the
  keyboard (`imePadding`), so the text field shrinks and the last lines can always be scrolled into view. The other
  dialogs also shrink above the keyboard now.
- **Lyrics needed the internet again and again.** Found lyrics were forgotten after 30 days and the cache version
  bump re-fetched everything. Found lyrics are now kept for good: once a song's lyrics have loaded, that song never
  needs the internet again (only *Try again* asks the service anew). "Not found" is still retried after a day. The
  lyrics of songs seen recently are also kept in memory, so coming back to a song shows them without the spinner.

### Changed
- `PlayerManager` also sets the media item's display title; `MusicService` wraps the player in `SkippablePlayer`.
- Refactor: one shared dialog shell (`MelodiqDialog`), one set of text-field colours, one song menu flow
  (`SongMenuHost`), and `OptionRow` is shared by the lyrics options and the song menu.
- The floating lyrics were **not touched** (their files are byte-for-byte the same as in 1.4).
- Removed the unused `purgeOldCache` (it would have contradicted "kept for good"). `DatabaseModule` now carries a
  warning: a schema change wipes playlists, favourites and saved lyrics, so write a migration first.

## 1.4
### Added
- **Floating lyrics.** The current lyric line (plus the lines around it) in a small window on top of other
  apps, with a live preview in Settings. Everything about it is adjustable: how many lines (1–5), text size,
  font, weight, alignment, colour, brightness of the other lines, text shadow, background colour / opacity /
  corner radius, window opacity, width, line-change animation (none / fade / slide / pop) and its length,
  song title, playback buttons, "only while playing", "hide while Melodiq is open", and a lock that lets
  touches pass through. Drag it anywhere; the position is remembered. Needs Android's *Display over other
  apps* permission, which the app explains and asks for only when you switch the feature on.
- **Choose another version of the lyrics.** Lists every version found online (best match first, with length,
  line count and a preview) so you can pick the complete one.
- **Edit, paste or import lyrics.** Type or paste lyrics (with `[mm:ss.xx]` timestamps they stay synced), or
  import an `.lrc` / `.txt` file. The choice is kept for that song until you go back to automatic lyrics.
- **Sync timing.** Shift a song's lyrics earlier or later in 0.1 s steps; remembered per song.
- **Settings screen** (gear icon on Home and Now Playing) for the Now Playing look, the in-app lyrics style and
  the floating lyrics. Every change applies immediately.
- Tap a lyric line to jump to it; "Full text" view; optional keep-screen-on while lyrics are open.

### Fixed
- **Shuffle skipped songs and could repeat them.** ExoPlayer's own shuffle put the song you tapped at a random
  place in its order, so with *repeat off* only the songs after that place were ever played. Shuffle now builds
  a proper deck: every song of the queue exactly once, the playing song first, nothing repeats until the whole
  deck is played. Switching shuffle on half-way keeps what was already played behind you and shuffles only the
  rest. With *repeat all*, each new pass is a fresh random order. The *Shuffle* button starts at a random song.
- **Lyrics that stop halfway.** Lookups used to accept the first match, even when it was a cut-short upload.
  They now compare all trusted matches and take the fullest one; if the synced version ends early but the
  plain-text version continues, the missing lines are appended (without highlight). Lyrics that still look
  incomplete show a notice with a shortcut to the version list. Lyrics cached by older versions are fetched again.

### Changed
- **Animation.** The background used to sweep a gradient back and forth (the moving, rotating bands) and the
  cover spun like a record. Now: a calm *Aurora* of soft glows drifting slowly (or *Pulse*, *Still*, *Plain*), and a
  cover that eases to full size while playing, sinks slightly when paused, and *breathes* (or floats / spins /
  stays still — your choice) with an optional halo. All motion freezes while the music is paused, runs at 30 fps and
  is read only by the draw phase, so nothing recomposes per frame. Browsing screens now use a still gradient.
- Lyrics scroll smoothly to the middle of the screen, scale/fade by distance, and stop fighting you while you scroll.
- Lyrics are now owned by `LyricsManager` (one shared copy) instead of the Now Playing screen, so the floating
  window and the screen always agree. The old "Search manually" dialog is replaced by the version list.
- Dependencies: `lifecycle-runtime-ktx` and `savedstate-ktx` are now declared explicitly (already part of the app;
  the floating window needs their view-tree helpers).

## 1.3
### Fixed
- **Crash when tapping a song to play.** As soon as lyrics were found for the song, the app died with
  `PatternSyntaxException: Syntax error in regexp pattern near index 8  \{[^}]*}`. Android's regex engine
  (ICU) rejects an unescaped `}`, which a desktop JVM accepts. The pattern in `LyricsCleanup` now escapes it
  (`\{[^\}]*\}`), and the two neighbouring patterns escape their `]` the same way. Every other regex in the
  project was checked against a real ICU engine and compiles.
- **Lyrics can no longer crash the app.** The lyrics loader only caught `Exception`, so an `Error` (such as a
  class failing to initialise) escaped and killed the whole app. It now catches everything except
  cancellation, saves an error log, and shows a new *Couldn't load lyrics* state with a *Try again* button
  while the music keeps playing. (Before, any unexpected failure was shown as "Can't reach the lyrics
  service", which was misleading.)

### Changed
- The "message + Try again" layout used by the *offline* and *couldn't load* lyrics states is now one shared
  composable instead of two copies.

## 1.1
### Fixed
- **Lyrics never loaded for songs without an artist tag.** MediaStore reports a missing artist as the text
  `<unknown>`; that was sent to the lyrics service as if it were a real artist. Missing tags are now
  recognised, and lyrics are searched by title + length instead (see HOW_IT_WORKS.md §3).
- Lyrics failures caused by being offline were cached as "not found" for a day. Network errors are no
  longer cached and show a *Try again* button.
- **Player stopped responding after leaving Now Playing.** Every screen created its own PlayerViewModel and
  clearing any one of them disconnected the shared player. There is now one PlayerViewModel for the app and the
  controller is never released by a screen.
- Tapping a song before the player service had connected did nothing; the request is now queued.
- Sleep timer restarted the music if it was already paused, and stopped counting when the app was closed.
- Favouriting a song in a list changed the song shown in the mini player.
- Without audio permission the app showed an empty library; it now shows an *Allow access* screen
  (and re-checks when you return from Settings).
- The gradient background recomposed the whole app 60×/second; the song position recomposed every list 5×/second.
  Both are now draw-phase / isolated.

### Changed
- All emoji and text-glyph icons replaced with vector drawables; real buttons everywhere
  (Play all, Shuffle, Scan library, Lyrics, Sleep timer, Try again, Search manually, Allow access).
- Songs without artwork show a music-note cover instead of an empty box.
- Now Playing: lyrics/sleep timer are labelled buttons; the cover stops turning where it is when paused.
- Song rows show an animated equalizer on the current song.
- Scans SD cards too (Android 10+).

### Removed
- `material-icons-extended` dependency (large; every icon is now our own vector) — faster CI builds.
- Unused permissions `SYSTEM_ALERT_WINDOW` and `RECEIVE_BOOT_COMPLETED`.
