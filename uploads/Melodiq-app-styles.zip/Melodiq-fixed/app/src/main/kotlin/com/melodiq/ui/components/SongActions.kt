package com.melodiq.ui.components

import android.widget.Toast
import androidx.annotation.DrawableRes
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.melodiq.R
import com.melodiq.data.model.Song
import com.melodiq.ui.theme.TextPrimary
import com.melodiq.ui.theme.TextSecondary
import com.melodiq.ui.viewmodel.PlaylistsViewModel

/** One row of the "⋮" menu of a song. */
data class SongAction(
    @DrawableRes val icon: Int,
    val title: String,
    val subtitle: String,
    val onClick: () -> Unit
)

/** A small dialog listing what can be done with one song. */
@Composable
fun SongActionsDialog(song: Song, actions: List<SongAction>, onDismiss: () -> Unit) {
    MelodiqDialog(onDismiss = onDismiss) {
        Column(Modifier.padding(horizontal = 24.dp, vertical = 8.dp)) {
            Text(
                text     = song.title,
                style    = MaterialTheme.typography.titleMedium,
                color    = TextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (song.hasArtist) {
                Text(
                    text     = song.artist,
                    style    = MaterialTheme.typography.bodySmall,
                    color    = TextSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        for (action in actions) {
            OptionRow(
                icon     = action.icon,
                title    = action.title,
                subtitle = action.subtitle,
                onClick  = action.onClick
            )
        }
    }
}

private enum class MenuStep { Menu, PickPlaylist, NewPlaylist }

/**
 * The whole "⋮ on a song" flow in one place: the menu, then the playlist to add it to, then (when the
 * user wants a new one) its name. Pass the song the menu was opened for; null keeps everything closed.
 *
 * @param extraActions more rows for the menu (the playlist screen adds "Remove from this playlist");
 *                     the menu closes after one of them is used.
 * @param startAtPlaylistPicker skip the menu and open the list of playlists straight away.
 */
@Composable
fun SongMenuHost(
    song: Song?,
    playlistsVm: PlaylistsViewModel,
    onDismiss: () -> Unit,
    extraActions: List<SongAction> = emptyList(),
    startAtPlaylistPicker: Boolean = false
) {
    if (song == null) return

    val context = LocalContext.current
    var step by remember(song.id) {
        mutableStateOf(if (startAtPlaylistPicker) MenuStep.PickPlaylist else MenuStep.Menu)
    }
    val toast: (String) -> Unit = { message ->
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }

    when (step) {
        MenuStep.Menu -> {
            val actions = buildList {
                add(
                    SongAction(
                        icon     = R.drawable.ic_playlist_add,
                        title    = "Add to playlist",
                        subtitle = "Put this song in one of your playlists",
                        onClick  = { step = MenuStep.PickPlaylist }
                    )
                )
                for (extra in extraActions) {
                    add(extra.copy(onClick = {
                        extra.onClick()
                        onDismiss()
                    }))
                }
            }
            SongActionsDialog(song = song, actions = actions, onDismiss = onDismiss)
        }

        MenuStep.PickPlaylist -> {
            val state by playlistsVm.uiState.collectAsStateWithLifecycle()
            AddToPlaylistDialog(
                song          = song,
                state         = state,
                onPick        = { item ->
                    if (item.contains(song.id)) {
                        toast("Already in " + item.name)
                    } else {
                        playlistsVm.addSong(item.id, song.id)
                        toast("Added to " + item.name)
                    }
                    onDismiss()
                },
                onNewPlaylist = { step = MenuStep.NewPlaylist },
                onDismiss     = onDismiss
            )
        }

        MenuStep.NewPlaylist -> PlaylistNameDialog(
            title        = "New playlist",
            confirmLabel = "Create",
            initialName  = "",
            validate     = { name -> playlistsVm.nameError(name) },
            onConfirm    = { name ->
                playlistsVm.create(name, listOf(song.id)) { created -> toast("Added to " + created) }
                onDismiss()
            },
            onDismiss    = { step = MenuStep.PickPlaylist }
        )
    }
}
