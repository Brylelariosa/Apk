package com.melodiq.player

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.CommandButton
import androidx.media3.session.MediaSession
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionResult
import com.google.common.collect.ImmutableList
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import com.melodiq.R

/**
 * The extra buttons of the playback notification: *shuffle* and *repeat*.
 *
 * Android draws previous / play-pause / next itself (their look cannot be changed by an app on
 * Android 13+). Buttons an app adds are drawn with the app's own icons, so these two are Melodiq's.
 * On Android 13+ they sit on either side of previous / next in the expanded media card; on older
 * versions they follow next in the expanded notification.
 *
 * The icons show the state (a notification icon is painted one colour, so "on" is full brightness with
 * a dot underneath and "off" is dimmed). [attach] keeps them in step with the player, whoever changed
 * shuffle or repeat: the notification, the Now Playing screen or the headset.
 */
@OptIn(UnstableApi::class)
class NotificationButtons(private val player: Player) : MediaSession.Callback {

    private val shuffleCommand = SessionCommand(ACTION_SHUFFLE, Bundle.EMPTY)
    private val repeatCommand = SessionCommand(ACTION_REPEAT, Bundle.EMPTY)

    private val mainHandler = Handler(Looper.getMainLooper())
    private var session: MediaSession? = null
    private val sendLayout = Runnable {
        try {
            session?.setCustomLayout(layout())
        } catch (e: Exception) {
            // the service was shut down in the meantime
        }
    }

    /** The buttons as they should look right now. */
    fun layout(): ImmutableList<CommandButton> {
        val shuffleOn = player.shuffleModeEnabled
        val shuffle = CommandButton.Builder()
            .setDisplayName(if (shuffleOn) "Shuffle on" else "Shuffle off")
            .setIconResId(if (shuffleOn) R.drawable.ic_notif_shuffle_on else R.drawable.ic_notif_shuffle_off)
            .setSessionCommand(shuffleCommand)
            .build()

        val repeatMode = player.repeatMode
        val repeat = CommandButton.Builder()
            .setDisplayName(
                when (repeatMode) {
                    Player.REPEAT_MODE_ALL -> "Repeat all"
                    Player.REPEAT_MODE_ONE -> "Repeat one"
                    else                   -> "Repeat off"
                }
            )
            .setIconResId(
                when (repeatMode) {
                    Player.REPEAT_MODE_ALL -> R.drawable.ic_notif_repeat_all
                    Player.REPEAT_MODE_ONE -> R.drawable.ic_notif_repeat_one
                    else                   -> R.drawable.ic_notif_repeat_off
                }
            )
            .setSessionCommand(repeatCommand)
            .build()

        return ImmutableList.of(shuffle, repeat)
    }

    /** Shows the buttons on [session] and redraws them whenever shuffle or repeat changes. */
    fun attach(session: MediaSession) {
        this.session = session
        session.setCustomLayout(layout())
        player.addListener(object : Player.Listener {
            override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
                session.setCustomLayout(layout())
            }

            override fun onRepeatModeChanged(repeatMode: Int) {
                session.setCustomLayout(layout())
            }
        })
    }

    override fun onConnect(
        session: MediaSession,
        controller: MediaSession.ControllerInfo
    ): MediaSession.ConnectionResult {
        // A controller (the notification, the lock screen, a headset) may only press commands it was told about.
        val base = super.onConnect(session, controller)
        val commands = base.availableSessionCommands.buildUpon()
            .add(shuffleCommand)
            .add(repeatCommand)
            .build()
        // Send the buttons again a moment after the controller is connected (the media notification is
        // one), so they are there from the start and not only after the first shuffle or repeat change.
        mainHandler.removeCallbacks(sendLayout)
        mainHandler.postDelayed(sendLayout, SEND_LAYOUT_DELAY_MS)
        return MediaSession.ConnectionResult.accept(commands, base.availablePlayerCommands)
    }

    override fun onCustomCommand(
        session: MediaSession,
        controller: MediaSession.ControllerInfo,
        customCommand: SessionCommand,
        args: Bundle
    ): ListenableFuture<SessionResult> {
        when (customCommand.customAction) {
            ACTION_SHUFFLE -> player.shuffleModeEnabled = !player.shuffleModeEnabled
            ACTION_REPEAT  -> player.repeatMode = nextRepeatMode(player.repeatMode)
        }
        return Futures.immediateFuture(SessionResult(SessionResult.RESULT_SUCCESS))
    }

    /** Off → all → one → off, the same order as the repeat button on Now Playing. */
    private fun nextRepeatMode(current: Int): Int = when (current) {
        Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
        Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
        else                   -> Player.REPEAT_MODE_OFF
    }

    private companion object {
        const val ACTION_SHUFFLE = "com.melodiq.action.SHUFFLE"
        const val ACTION_REPEAT = "com.melodiq.action.REPEAT"
        const val SEND_LAYOUT_DELAY_MS = 300L
    }
}
