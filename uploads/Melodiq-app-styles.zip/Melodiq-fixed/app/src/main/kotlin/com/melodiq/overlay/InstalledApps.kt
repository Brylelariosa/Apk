package com.melodiq.overlay

import android.content.Context
import android.content.Intent

/** An app the user can open from the launcher. */
data class InstalledApp(val packageName: String, val label: String)

/** Looks up apps for the per-app floating lyrics: names for the list, and the apps to choose from. */
object InstalledApps {

    /** The app's name, or the package name when Android does not let Melodiq see that app. */
    fun label(context: Context, packageName: String): String = try {
        val pm = context.packageManager
        pm.getApplicationLabel(pm.getApplicationInfo(packageName, 0)).toString().ifBlank { packageName }
    } catch (e: Exception) {
        packageName
    }

    /** Every app with a launcher icon, sorted by name. (The manifest's <queries> makes them visible.) */
    fun launchable(context: Context): List<InstalledApp> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val found = try {
            pm.queryIntentActivities(intent, 0)
        } catch (e: Exception) {
            emptyList()
        }
        return found
            .map { InstalledApp(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
    }
}
