package com.melodiq.ui.components

import android.view.WindowManager
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import com.melodiq.ui.theme.Divider
import com.melodiq.ui.theme.PrimaryPurple
import com.melodiq.ui.theme.SurfaceCard
import com.melodiq.ui.theme.TextPrimary
import com.melodiq.ui.theme.TextSecondary

/**
 * The one dialog shell of the app: a rounded dark card. [tall] makes it a large sheet (lists, pickers);
 * otherwise it is a small card sized by its content. The window shrinks above the keyboard, so a text
 * field or a button inside is never hidden behind it.
 */
@Composable
fun MelodiqDialog(
    onDismiss: () -> Unit,
    tall: Boolean = false,
    content: @Composable ColumnScope.() -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties       = DialogProperties(usePlatformDefaultWidth = !tall)
    ) {
        ResizeForKeyboard()
        Surface(
            modifier = if (tall) Modifier.fillMaxWidth(0.94f).fillMaxHeight(0.9f) else Modifier,
            shape    = RoundedCornerShape(24.dp),
            color    = SurfaceCard
        ) {
            Column(
                modifier = if (tall) {
                    Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
                } else {
                    Modifier.padding(vertical = 16.dp)
                },
                content = content
            )
        }
    }
}

/** Asks Android to shrink the dialog window when the keyboard opens (the default may only slide it). */
@Composable
private fun ResizeForKeyboard() {
    val window = (LocalView.current.parent as? DialogWindowProvider)?.window
    SideEffect {
        window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
    }
}

/** Text-field colours shared by every dialog. */
@Composable
fun melodiqFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor   = PrimaryPurple,
    unfocusedBorderColor = Divider,
    cursorColor          = PrimaryPurple,
    focusedTextColor     = TextPrimary,
    unfocusedTextColor   = TextPrimary,
    focusedLabelColor    = PrimaryPurple,
    unfocusedLabelColor  = TextSecondary
)
