package com.melodiq.player

import android.app.PendingIntent
import android.content.Intent
import android.content.res.Configuration
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.melodiq.MainActivity
import com.melodiq.R
import com.melodiq.crash.AppLog
import com.melodiq.overlay.FloatingLyricsOverlay
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@OptIn(UnstableApi::class)
@AndroidEntryPoint
class MusicService : MediaSessionService() {

    @Inject lateinit var floatingLyrics: FloatingLyricsOverlay

    private lateinit var player: ExoPlayer
    private lateinit var mediaSession: MediaSession

    override fun onCreate() {
        super.onCreate()
        AppLog.i(TAG, "onCreate")

        // The playback notification: Melodiq's own status-bar icon instead of the library's generic one.
        setMediaNotificationProvider(
            DefaultMediaNotificationProvider(this).apply { setSmallIcon(R.drawable.ic_stat_melodiq) }
        )

        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .build()

        player = ExoPlayer.Builder(this)
            .setAudioAttributes(audioAttributes, /* handleAudioFocus= */ true)
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()
            .also {
                it.shuffleModeEnabled = false
                it.addListener(PlaybackLogger())
                // plays every song once per pass, never repeats one inside a pass (see the class docs)
                it.addListener(ShuffleCoordinator(it))
            }

        val sessionActivityIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        // SkippablePlayer keeps "previous" and "next" in the notification at all times (see its docs).
        // NotificationButtons adds shuffle and repeat next to them (see its docs).
        val extraButtons = NotificationButtons(player)
        mediaSession = MediaSession.Builder(this, SkippablePlayer(player))
            .setSessionActivity(sessionActivityIntent)
            .setCallback(extraButtons)
            .build()
        extraButtons.attach(mediaSession)

        // The floating lyrics window lives in this service: it is a foreground service while music
        // plays, so the window is not killed when the app is closed.
        try {
            floatingLyrics.start()
        } catch (e: Throwable) {
            AppLog.w(TAG, "floating lyrics could not start", e)
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        try {
            floatingLyrics.refreshLayout()
        } catch (e: Throwable) {
            AppLog.w(TAG, "floating lyrics could not re-layout", e)
        }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession = mediaSession

    override fun onTaskRemoved(rootIntent: Intent?) {
        AppLog.i(TAG, "onTaskRemoved (playWhenReady=${player.playWhenReady}, items=${player.mediaItemCount})")
        if (!player.playWhenReady || player.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        AppLog.i(TAG, "onDestroy")
        try {
            floatingLyrics.stop()
        } catch (e: Throwable) {
            AppLog.w(TAG, "floating lyrics could not stop", e)
        }
        mediaSession.release()
        player.release()
        super.onDestroy()
    }

    private companion object {
        const val TAG = "MusicService"
    }
}
