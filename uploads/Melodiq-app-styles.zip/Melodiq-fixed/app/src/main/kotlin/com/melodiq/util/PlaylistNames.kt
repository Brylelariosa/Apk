package com.melodiq.util

/** The rules for playlist names: the repository cleans a name, the dialogs check it. */
object PlaylistNames {
    const val MAX_LENGTH = 40

    private val WHITESPACE = Regex("\\s+")

    /** Trims, turns any run of spaces or line breaks into one space and caps the length. */
    fun normalize(raw: String): String =
        raw.trim().replace(WHITESPACE, " ").take(MAX_LENGTH).trim()

    /**
     * The message to show under the name field, or null when [raw] can be used.
     * [otherNames] are the names of the user's other playlists (not the one being renamed).
     */
    fun error(raw: String, otherNames: List<String>): String? {
        val name = normalize(raw)
        return when {
            name.isEmpty() -> "Give the playlist a name"
            otherNames.any { it.equals(name, ignoreCase = true) } -> "You already have a playlist with this name"
            else -> null
        }
    }
}
