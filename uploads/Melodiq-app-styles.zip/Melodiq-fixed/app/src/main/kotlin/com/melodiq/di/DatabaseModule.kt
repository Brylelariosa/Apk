package com.melodiq.di

import android.content.Context
import androidx.room.Room
import com.melodiq.data.db.AppDatabase
import com.melodiq.data.db.dao.*
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): AppDatabase =
        Room.databaseBuilder(context, AppDatabase::class.java, "melodiq.db")
            // WARNING: changing a table (and so the schema version) wipes EVERYTHING in this database —
            // playlists, favourites, the saved lyrics. Write a Migration first if a table ever has to change.
            .fallbackToDestructiveMigration()
            .build()

    @Provides fun provideSongDao(db: AppDatabase): SongDao = db.songDao()
    @Provides fun provideLyricsDao(db: AppDatabase): LyricsDao = db.lyricsDao()
    @Provides fun providePlaylistDao(db: AppDatabase): PlaylistDao = db.playlistDao()
    @Provides fun provideRecentlyPlayedDao(db: AppDatabase): RecentlyPlayedDao = db.recentlyPlayedDao()
    @Provides fun provideFavoriteDao(db: AppDatabase): FavoriteDao = db.favoriteDao()
}
