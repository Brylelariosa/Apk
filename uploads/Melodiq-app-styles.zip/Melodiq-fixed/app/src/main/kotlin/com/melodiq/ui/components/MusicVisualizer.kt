package com.melodiq.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.unit.dp
import com.melodiq.R
import com.melodiq.data.model.VisualizerStyle
import com.melodiq.ui.theme.AccentPink
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.sin

// 30 frames a second is plenty for this and halves the GPU work on budget phones.
private const val FRAME_STEP_SECONDS = 1f / 30f
private const val TWO_PI = 6.2831855f
private const val HALF_PI = 1.5707964f
private const val PI_F = 3.1415927f

/** How lively the picture still is while the music is paused (0 = flat, 1 = full). */
private const val IDLE_ENERGY = 0.12f

private const val RING_BARS = 64
private const val RING_RIPPLES = 3
private const val BAR_COUNT = 27

/**
 * The picture in the middle of Now Playing: an animation that moves while music plays, for songs
 * that have no cover art (or for people who simply prefer it).
 *
 * It is not tied to the audio signal — it is a pretend spectrum built from a few sine waves per bar
 * plus a steady "beat" that makes the whole picture pump — so it needs no permission and costs very
 * little. When the music is paused the picture settles down (it does not just freeze mid-jump).
 *
 * One float clock drives everything; only the draw phase reads it, so nothing is recomposed while
 * the animation runs, and the clock stops when [isPlaying] and [keepMoving] are both false.
 *
 * @param color the album colour (a default purple when the song has no art).
 * @param speed 0.25..2, the "Animation speed" setting.
 * @param keepMoving keep the clock running while paused (the "animate only while playing" setting is off).
 */
@Composable
fun MusicVisualizer(
    isPlaying: Boolean,
    style: VisualizerStyle,
    color: Color,
    speed: Float,
    modifier: Modifier = Modifier,
    keepMoving: Boolean = false
) {
    val clock = remember { mutableFloatStateOf(0f) }
    val running = isPlaying || keepMoving
    LaunchedEffect(running, speed) {
        if (!running) return@LaunchedEffect
        var last = withFrameNanos { it }
        while (true) {
            val now = withFrameNanos { it }
            val delta = (now - last) / 1_000_000_000f
            if (delta >= FRAME_STEP_SECONDS) {
                clock.floatValue += delta * speed
                last = now
            }
        }
    }

    val energy = animateFloatAsState(
        targetValue   = if (isPlaying) 1f else IDLE_ENERGY,
        animationSpec = tween(700),
        label         = "visualizer_energy"
    )

    // reused every frame instead of allocating new paths 30 times a second
    val fillPath = remember { Path() }
    val linePath = remember { Path() }

    val primary   = lerp(color, Color.White, 0.18f)
    val secondary = lerp(AccentPink, color, 0.20f)

    BoxWithConstraints(modifier = modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val t = clock.floatValue
            val e = energy.value
            when (style) {
                VisualizerStyle.RING  -> drawRing(t, e, primary, secondary)
                VisualizerStyle.BARS  -> drawBars(t, e, primary, secondary)
                VisualizerStyle.WAVES -> drawWaves(t, e, primary, secondary, fillPath, linePath)
            }
        }
        if (style == VisualizerStyle.RING) {
            val shortSide = minOf(maxWidth, maxHeight)
            VectorIcon(
                id       = R.drawable.ic_music_note,
                tint     = Color.White.copy(alpha = 0.92f),
                size     = shortSide * 0.16f,
                modifier = Modifier.graphicsLayer {
                    val pump = 1f + 0.12f * kick(clock.floatValue) * energy.value
                    scaleX = pump
                    scaleY = pump
                }
            )
        }
    }
}

// ── The pretend music ─────────────────────────────────────────────────────────

/**
 * One band of the pretend spectrum, 0..1. Every band moves with three sine waves at its own,
 * unrelated speeds, so neighbours do not move together and the pattern never visibly repeats.
 */
private fun level(band: Int, t: Float): Float {
    val a = sin(t * (2.1f + 0.13f * band) + band * 1.7f)
    val b = sin(t * (3.3f + 0.07f * band) + band * 0.9f + 1.3f)
    val c = sin(t * (5.1f - 0.05f * band) + band * 2.3f + 0.4f)
    val v = 0.5f + 0.5f * (0.5f * a + 0.3f * b + 0.2f * c)
    return v * v * 0.55f + v * 0.45f          // a little punchier: peaks stand out from the average
}

/** The steady beat: 1 right on it, fading quickly to 0 (about 114 beats a minute at normal speed). */
private fun kick(t: Float): Float = exp(-((t * 1.9f) % 1f) * 6f)

// ── RING: bars around a pulsing core ──────────────────────────────────────────

private fun DrawScope.drawRing(t: Float, energy: Float, primary: Color, secondary: Color) {
    val mid   = Offset(size.width / 2f, size.height / 2f)
    val reach = min(size.width, size.height) / 2f
    val pump  = kick(t) * energy

    val core      = reach * 0.34f
    val gap       = reach * 0.045f
    val maxLength = reach * 0.40f
    val minLength = reach * 0.025f

    // a wide soft glow behind everything
    drawCircle(
        brush  = Brush.radialGradient(
            colors = listOf(primary.copy(alpha = 0.26f * energy), Color.Transparent),
            center = mid,
            radius = reach
        ),
        radius = reach,
        center = mid
    )

    // rings that leave the core and fade away
    for (i in 0 until RING_RIPPLES) {
        val progress = (t * 0.33f + i.toFloat() / RING_RIPPLES) % 1f
        val fade = 1f - progress
        drawCircle(
            color  = secondary.copy(alpha = (0.34f * fade * fade * energy).coerceIn(0f, 1f)),
            radius = core + (reach - core) * progress,
            center = mid,
            style  = Stroke(width = reach * 0.012f)
        )
    }

    // the bars, mirrored left and right so the picture is symmetrical
    val half      = RING_BARS / 2
    val inner     = core + gap + core * 0.10f * pump
    val thickness = TWO_PI * inner / RING_BARS * 0.56f
    for (i in 0 until RING_BARS) {
        val band   = if (i <= half) i else RING_BARS - i
        val shaped = level(band, t) * (1f - 0.35f * band / half)        // the low side is a bit stronger
        val length = minLength + (maxLength - minLength) * shaped * energy * (1f + 0.22f * pump)
        val angle  = i.toFloat() / RING_BARS * TWO_PI - HALF_PI
        val dx = cos(angle)
        val dy = sin(angle)
        drawLine(
            color       = lerp(primary, secondary, band.toFloat() / half),
            start       = Offset(mid.x + dx * inner, mid.y + dy * inner),
            end         = Offset(mid.x + dx * (inner + length), mid.y + dy * (inner + length)),
            strokeWidth = thickness,
            cap         = StrokeCap.Round
        )
    }

    // the core: a glowing disc that swells on the beat
    val orb = core * (0.94f + 0.08f * pump)
    drawCircle(
        brush  = Brush.radialGradient(
            colors = listOf(lerp(primary, Color.White, 0.30f), primary, secondary.copy(alpha = 0.85f)),
            center = mid,
            radius = orb
        ),
        radius = orb,
        center = mid
    )
    drawCircle(
        color  = Color.White.copy(alpha = 0.22f),
        radius = orb,
        center = mid,
        style  = Stroke(width = reach * 0.010f)
    )
}

// ── BARS: a row of equalizer bars ─────────────────────────────────────────────

private fun DrawScope.drawBars(t: Float, energy: Float, primary: Color, secondary: Color) {
    val usable    = size.width * 0.86f
    val left      = (size.width - usable) / 2f
    val slot      = usable / BAR_COUNT
    val thickness = slot * 0.58f
    val midY      = size.height / 2f
    val maxHeight = size.height * 0.62f
    val middle    = (BAR_COUNT - 1) / 2f
    val pump      = kick(t) * energy

    for (i in 0 until BAR_COUNT) {
        val distance = abs(i - middle) / middle                     // 0 in the middle, 1 at the ends
        val envelope = 1f - 0.55f * distance                        // the middle bars reach highest
        val height   = thickness + (maxHeight - thickness) * level(i, t) * envelope * energy * (1f + 0.15f * pump)
        val x   = left + slot * (i + 0.5f)
        val tint = lerp(primary, secondary, i.toFloat() / (BAR_COUNT - 1))
        val top    = Offset(x, midY - height / 2f)
        val bottom = Offset(x, midY + height / 2f)

        // a wide faint line under the bar gives it a soft glow
        drawLine(color = tint.copy(alpha = 0.22f), start = top, end = bottom, strokeWidth = thickness * 2.1f, cap = StrokeCap.Round)
        drawLine(color = tint, start = top, end = bottom, strokeWidth = thickness, cap = StrokeCap.Round)
    }
}

// ── WAVES: flowing layers ─────────────────────────────────────────────────────

private fun DrawScope.drawWaves(
    t: Float,
    energy: Float,
    primary: Color,
    secondary: Color,
    fillPath: Path,
    linePath: Path
) {
    val width  = size.width
    val height = size.height
    val midY   = height / 2f
    val step   = (width / 48f).coerceAtLeast(4f)
    val pump   = kick(t) * energy

    for (layer in 0 until 3) {
        val amplitude = height * (0.20f - 0.045f * layer) * (0.10f + 0.90f * energy) * (1f + 0.20f * pump)
        val crests    = 1.5f + 0.7f * layer
        val drift     = (if (layer % 2 == 0) 1f else -1f) * (1.1f + 0.5f * layer)
        val baseline  = midY + height * 0.03f * (layer - 1)

        fillPath.reset()
        linePath.reset()
        var x = 0f
        var first = true
        while (x <= width + step) {
            val u     = (x / width).coerceIn(0f, 1f)
            val taper = 0.25f + 0.75f * sin(PI_F * u)               // calm at both ends, full in the middle
            val wave  = 0.62f * sin(u * crests * TWO_PI + t * drift) +
                0.38f * sin(u * crests * 1.9f * TWO_PI - t * drift * 1.3f + layer)
            val y = baseline + amplitude * taper * wave
            if (first) {
                linePath.moveTo(x, y)
                fillPath.moveTo(x, y)
                first = false
            } else {
                linePath.lineTo(x, y)
                fillPath.lineTo(x, y)
            }
            x += step
        }
        fillPath.lineTo(width + step, height)
        fillPath.lineTo(0f, height)
        fillPath.close()

        val tint = lerp(primary, secondary, layer / 2f)
        drawPath(
            path  = fillPath,
            brush = Brush.verticalGradient(
                colors = listOf(tint.copy(alpha = 0.30f - 0.07f * layer), Color.Transparent),
                startY = baseline - amplitude,
                endY   = height
            )
        )
        drawPath(
            path  = linePath,
            color = tint.copy(alpha = 0.95f - 0.20f * layer),
            style = Stroke(width = 3.dp.toPx() - layer, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
    }
}
