package com.melodiq.ui.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import com.melodiq.data.model.AppLyricsProfile
import com.melodiq.data.model.AppProfiles
import com.melodiq.data.model.FloatingLyricsSettings
import com.melodiq.data.model.sanitized
import com.melodiq.data.repository.AppProfileRepository
import com.melodiq.data.repository.SettingsRepository
import com.melodiq.overlay.InstalledApp
import com.melodiq.overlay.InstalledApps
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import javax.inject.Inject

/** The floating-lyrics style of each app: what the "per app" section of Settings shows and changes. */
@HiltViewModel
class AppProfilesViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val repository: AppProfileRepository,
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    val profiles: StateFlow<AppProfiles> = repository.state

    /** What an app without its own style gets: the Floating lyrics settings. */
    private fun defaultStyle(): FloatingLyricsSettings = settingsRepository.settings.value.floating

    fun setEnabled(on: Boolean) = repository.setEnabled(on)

    /** Gives [app] a style of its own, starting from the default one. Does nothing if it has one already. */
    fun addApp(app: InstalledApp) {
        if (profiles.value.find(app.packageName) != null) return
        repository.upsert(AppLyricsProfile(app.packageName, app.label, visible = true, style = defaultStyle()))
    }

    fun setVisible(packageName: String, visible: Boolean) =
        repository.updateApp(packageName) { it.copy(visible = visible) }

    fun updateStyle(packageName: String, transform: (FloatingLyricsSettings) -> FloatingLyricsSettings) =
        repository.updateApp(packageName) { it.copy(style = transform(it.style).sanitized()) }

    /** Back to the default look; the spot the user chose for this app is kept. */
    fun useDefaultStyle(packageName: String) = repository.updateApp(packageName) { app ->
        app.copy(style = defaultStyle().copy(posX = app.style.posX, posY = app.style.posY))
    }

    fun remove(packageName: String) = repository.remove(packageName)

    fun removeAll() = repository.update { it.copy(apps = emptyList()) }

    /** The apps to choose from. Reads every app's name, so it runs off the main thread. */
    suspend fun launchableApps(): List<InstalledApp> =
        withContext(Dispatchers.Default) { InstalledApps.launchable(context) }
}
