package com.melodiq.ui.screen

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.melodiq.R
import com.melodiq.ui.components.ArtworkImage
import com.melodiq.ui.components.ConfirmDialog
import com.melodiq.ui.components.EmptyState
import com.melodiq.ui.components.IconActionButton
import com.melodiq.ui.components.MelodiqButton
import com.melodiq.ui.components.PlaylistActionsDialog
import com.melodiq.ui.components.PlaylistNameDialog
import com.melodiq.ui.theme.TextPrimary
import com.melodiq.ui.theme.TextSecondary
import com.melodiq.ui.viewmodel.PlaylistItem
import com.melodiq.ui.viewmodel.PlaylistsViewModel

/** All the user's playlists: open one, make a new one, rename or delete. */
@Composable
fun PlaylistsScreen(
    playlistsVm: PlaylistsViewModel,
    onOpenPlaylist: (Long) -> Unit
) {
    val state by playlistsVm.uiState.collectAsStateWithLifecycle()

    var creating by remember { mutableStateOf(false) }
    var menuFor  by remember { mutableStateOf<PlaylistItem?>(null) }
    var renaming by remember { mutableStateOf<PlaylistItem?>(null) }
    var deleting by remember { mutableStateOf<PlaylistItem?>(null) }

    Column(Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 20.dp, end = 8.dp, top = 8.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text     = "Playlists",
                style    = MaterialTheme.typography.titleLarge,
                color    = TextPrimary,
                modifier = Modifier.weight(1f)
            )
            IconActionButton(
                icon               = R.drawable.ic_add,
                contentDescription = "New playlist",
                onClick            = { creating = true },
                tint               = Color.White
            )
        }

        when {
            // nothing for the first instant, so the empty message does not flash before the list arrives
            !state.loaded -> Box(Modifier.fillMaxSize())

            state.items.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                EmptyState(
                    icon    = R.drawable.ic_playlist,
                    title   = "No playlists yet",
                    message = "Make one for your Japan songs, love songs and more — and give it any name."
                ) {
                    MelodiqButton(
                        text    = "New playlist",
                        onClick = { creating = true },
                        icon    = R.drawable.ic_add
                    )
                }
            }

            else -> LazyColumn(
                modifier       = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 16.dp)
            ) {
                items(state.items, key = { it.id }) { item ->
                    PlaylistRow(
                        item    = item,
                        onClick = { onOpenPlaylist(item.id) },
                        onMore  = { menuFor = item }
                    )
                }
            }
        }
    }

    if (creating) {
        PlaylistNameDialog(
            title        = "New playlist",
            confirmLabel = "Create",
            initialName  = "",
            validate     = { name -> playlistsVm.nameError(name) },
            onConfirm    = { name ->
                playlistsVm.create(name)
                creating = false
            },
            onDismiss    = { creating = false }
        )
    }

    val actionsFor = menuFor
    if (actionsFor != null) {
        PlaylistActionsDialog(
            item      = actionsFor,
            onRename  = {
                menuFor = null
                renaming = actionsFor
            },
            onDelete  = {
                menuFor = null
                deleting = actionsFor
            },
            onDismiss = { menuFor = null }
        )
    }

    val renameTarget = renaming
    if (renameTarget != null) {
        PlaylistNameDialog(
            title        = "Rename playlist",
            confirmLabel = "Save",
            initialName  = renameTarget.name,
            validate     = { name -> playlistsVm.nameError(name, ignoreId = renameTarget.id) },
            onConfirm    = { name ->
                playlistsVm.rename(renameTarget.id, name)
                renaming = null
            },
            onDismiss    = { renaming = null }
        )
    }

    val deleteTarget = deleting
    if (deleteTarget != null) {
        ConfirmDialog(
            title        = "Delete playlist?",
            message      = "\"" + deleteTarget.name + "\" will be deleted. Your songs stay on the phone.",
            confirmLabel = "Delete",
            confirmIcon  = R.drawable.ic_delete,
            onConfirm    = {
                playlistsVm.delete(deleteTarget.id)
                deleting = null
            },
            onDismiss    = { deleting = null }
        )
    }
}

@Composable
private fun PlaylistRow(item: PlaylistItem, onClick: () -> Unit, onMore: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(start = 16.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ArtworkImage(
            uri      = item.songs.firstOrNull()?.artworkUri,
            shape    = RoundedCornerShape(12.dp),
            modifier = Modifier.size(56.dp)
        )
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text     = item.name,
                style    = MaterialTheme.typography.titleMedium,
                color    = TextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text  = item.countLabel,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
        }
        IconActionButton(
            icon               = R.drawable.ic_more_vert,
            contentDescription = "Options for " + item.name,
            onClick            = onMore,
            tint               = TextSecondary
        )
    }
}
