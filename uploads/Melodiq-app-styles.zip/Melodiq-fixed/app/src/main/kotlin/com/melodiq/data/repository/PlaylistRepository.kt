package com.melodiq.data.repository

import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.melodiq.data.db.dao.PlaylistDao
import com.melodiq.data.db.entity.PlaylistEntity
import com.melodiq.data.model.Playlist
import com.melodiq.util.PlaylistNames
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * The user's named playlists (Japan, Love songs, …). A playlist is a name plus the ids of its songs
 * in the order they were added; the songs themselves stay in the library.
 *
 * The stored table is unchanged since the first version of the app, so no database migration is
 * involved (see DatabaseModule: a schema change would wipe playlists and favourites).
 */
@Singleton
class PlaylistRepository @Inject constructor(
    private val playlistDao: PlaylistDao,
    private val gson: Gson
) {
    // Every change reads the stored song list, edits it and writes it back. Two quick taps
    // ("add" twice) must not overwrite each other, so the changes run one after the other.
    private val writeLock = Mutex()

    /** Newest playlist first. */
    val allPlaylists: Flow<List<Playlist>> = playlistDao.observeAll().map { entities ->
        entities.map { it.toPlaylist() }
    }

    /** Creates a playlist (optionally with songs already in it) and returns its id. */
    suspend fun createPlaylist(name: String, songIds: List<Long> = emptyList()): Long =
        withContext(Dispatchers.IO) {
            writeLock.withLock {
                playlistDao.insert(
                    PlaylistEntity(
                        name        = PlaylistNames.normalize(name),
                        songIdsJson = gson.toJson(songIds.distinct())
                    )
                )
            }
        }

    suspend fun renamePlaylist(playlistId: Long, name: String) {
        withContext(Dispatchers.IO) {
            writeLock.withLock {
                val entity = playlistDao.getById(playlistId)
                if (entity != null) {
                    playlistDao.update(entity.copy(name = PlaylistNames.normalize(name)))
                }
            }
        }
    }

    suspend fun addSongToPlaylist(playlistId: Long, songId: Long) =
        addSongs(playlistId, listOf(songId))

    /** Adds the songs that are not in the playlist yet, at the end, in the given order. */
    suspend fun addSongs(playlistId: Long, songIds: Collection<Long>) =
        editSongIds(playlistId) { current ->
            current + songIds.filter { it !in current }.distinct()
        }

    suspend fun removeSongFromPlaylist(playlistId: Long, songId: Long) =
        editSongIds(playlistId) { current -> current.filter { it != songId } }

    suspend fun deletePlaylist(playlistId: Long) {
        withContext(Dispatchers.IO) {
            writeLock.withLock { playlistDao.deleteById(playlistId) }
        }
    }

    private suspend fun editSongIds(playlistId: Long, change: (List<Long>) -> List<Long>) {
        withContext(Dispatchers.IO) {
            writeLock.withLock {
                val entity = playlistDao.getById(playlistId)
                if (entity != null) {
                    val before = entity.parseSongIds()
                    val after  = change(before)
                    if (after != before) {
                        playlistDao.update(entity.copy(songIdsJson = gson.toJson(after)))
                    }
                }
            }
        }
    }

    private fun PlaylistEntity.toPlaylist() = Playlist(
        id        = id,
        name      = name,
        songIds   = parseSongIds(),
        createdAt = createdAt
    )

    private fun PlaylistEntity.parseSongIds(): List<Long> = try {
        val type = object : TypeToken<List<Long>>() {}.type
        gson.fromJson<List<Long>>(songIdsJson, type) ?: emptyList()
    } catch (e: Exception) {
        emptyList()
    }
}
