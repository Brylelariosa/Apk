package com.melodiq.ui.screen

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.melodiq.R
import com.melodiq.overlay.UsageAccessPermission
import com.melodiq.ui.components.AppPickerDialog
import com.melodiq.ui.components.AppProfileEditor
import com.melodiq.ui.components.AppProfileRow
import com.melodiq.ui.components.ButtonStyle
import com.melodiq.ui.components.MelodiqButton
import com.melodiq.ui.components.OnResumeEffect
import com.melodiq.ui.components.ResetRow
import com.melodiq.ui.components.SettingsSection
import com.melodiq.ui.components.SwitchRow
import com.melodiq.ui.components.UsageAccessDialog
import com.melodiq.ui.theme.TextSecondary
import com.melodiq.ui.viewmodel.AppProfilesViewModel

/**
 * Settings → "Floating lyrics per app": every app can have its own place and look for the floating
 * lyrics. The list shows the apps that have a style; the style of an app is made by dragging the window
 * while that app is open, or here with "Add an app". Apps without one use the default style above.
 */
@Composable
fun AppProfilesSection(viewModel: AppProfilesViewModel = hiltViewModel()) {
    val profiles by viewModel.profiles.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var usageAllowed by remember { mutableStateOf(UsageAccessPermission.isGranted(context)) }
    var showUsageDialog by remember { mutableStateOf(false) }
    var picking by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<String?>(null) }

    // Back from the system "Usage access" page: pick up the new permission.
    OnResumeEffect { usageAllowed = UsageAccessPermission.isGranted(context) }

    if (showUsageDialog) {
        UsageAccessDialog(
            onDismiss = { showUsageDialog = false },
            onOpenSettings = {
                showUsageDialog = false
                UsageAccessPermission.openSettings(context)
            }
        )
    }

    if (picking) {
        AppPickerDialog(
            alreadyAdded = remember(profiles.apps) { profiles.apps.map { it.packageName }.toSet() },
            loadApps     = { viewModel.launchableApps() },
            onPick       = { app ->
                viewModel.addApp(app)
                picking = false
                editing = app.packageName
            },
            onDismiss    = { picking = false }
        )
    }

    val editingProfile = profiles.find(editing)
    if (editingProfile != null) {
        val packageName = editingProfile.packageName
        AppProfileEditor(
            profile         = editingProfile,
            onVisibleChange = { visible -> viewModel.setVisible(packageName, visible) },
            onStyleChange   = { transform -> viewModel.updateStyle(packageName, transform) },
            onUseDefault    = { viewModel.useDefaultStyle(packageName) },
            onRemove        = {
                editing = null
                viewModel.remove(packageName)
            },
            onClose         = { editing = null }
        )
    }

    SettingsSection("Floating lyrics per app") {
        SwitchRow(
            title    = "A style for each app",
            subtitle = "Drag the lyrics while an app is open and Melodiq remembers the spot for that app. " +
                "Apps without a style of their own use the default style above.",
            checked  = profiles.enabled,
            onChange = { on -> viewModel.setEnabled(on) }
        )

        if (profiles.enabled) {
            if (!usageAllowed) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Text(
                        text  = "Melodiq needs \"Usage access\" to see which app is on screen. " +
                            "Until then every app uses the default style.",
                        color = TextSecondary,
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(Modifier.height(8.dp))
                    MelodiqButton(text = "Allow usage access", onClick = { showUsageDialog = true })
                }
            }

            val sorted = remember(profiles.apps) { profiles.apps.sortedBy { it.label.lowercase() } }
            if (sorted.isEmpty()) {
                Text(
                    text     = "No app has its own style yet. Open an app and drag the floating lyrics " +
                        "where you want them, or add an app below.",
                    color    = TextSecondary,
                    style    = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
            } else {
                for (app in sorted) {
                    key(app.packageName) {
                        AppProfileRow(app = app, onClick = { editing = app.packageName })
                    }
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.Start
            ) {
                MelodiqButton(
                    text    = "Add an app",
                    onClick = { picking = true },
                    icon    = R.drawable.ic_add,
                    style   = ButtonStyle.Tonal
                )
            }
            if (sorted.isNotEmpty()) {
                ResetRow(text = "Remove all app styles", onReset = { viewModel.removeAll() })
            }
        }
    }
}
