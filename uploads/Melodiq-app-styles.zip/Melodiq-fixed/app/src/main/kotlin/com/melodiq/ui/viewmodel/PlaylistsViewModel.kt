package com.melodiq.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.melodiq.crash.CrashReporter
import com.melodiq.data.model.Playlist
import com.melodiq.data.model.Song
import com.melodiq.data.repository.MusicRepository
import com.melodiq.data.repository.PlaylistRepository
import com.melodiq.util.PlaylistNames
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

/** A playlist together with the songs of it that still exist in the library. */
data class PlaylistItem(val playlist: Playlist, val songs: List<Song>) {
    val id: Long get() = playlist.id
    val name: String get() = playlist.name

    /** "1 song", "12 songs". */
    val countLabel: String get() = if (songs.size == 1) "1 song" else songs.size.toString() + " songs"

    fun contains(songId: Long): Boolean = playlist.songIds.contains(songId)
}

/** [loaded] is false until the database has answered once, so screens do not flash "no playlists". */
data class PlaylistsUiState(
    val loaded: Boolean = false,
    val items: List<PlaylistItem> = emptyList()
)

/**
 * One instance for the whole app (created in AppRoot, like the player and library view models):
 * every screen that lists, opens or fills a playlist talks to the same one.
 */
@HiltViewModel
class PlaylistsViewModel @Inject constructor(
    private val playlistRepository: PlaylistRepository,
    musicRepository: MusicRepository
) : ViewModel() {

    val uiState: StateFlow<PlaylistsUiState> = combine(
        playlistRepository.allPlaylists,
        musicRepository.allSongs
    ) { playlists, songs ->
        val byId = songs.associateBy { it.id }
        PlaylistsUiState(
            loaded = true,
            items  = playlists.map { playlist ->
                PlaylistItem(playlist, playlist.songIds.distinct().mapNotNull { byId[it] })
            }
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), PlaylistsUiState())

    /** The message to show under the name field, or null when [name] can be used. [ignoreId] = the playlist being renamed. */
    fun nameError(name: String, ignoreId: Long? = null): String? =
        PlaylistNames.error(name, uiState.value.items.filter { it.id != ignoreId }.map { it.name })

    /** Creates a playlist, optionally with songs in it; [onCreated] gets the final name. */
    fun create(name: String, songIds: List<Long> = emptyList(), onCreated: (String) -> Unit = {}) {
        val clean = PlaylistNames.normalize(name)
        if (clean.isEmpty()) return
        launchSafely {
            playlistRepository.createPlaylist(clean, songIds)
            onCreated(clean)
        }
    }

    fun rename(playlistId: Long, name: String) {
        launchSafely { playlistRepository.renamePlaylist(playlistId, name) }
    }

    fun delete(playlistId: Long) {
        launchSafely { playlistRepository.deletePlaylist(playlistId) }
    }

    fun addSong(playlistId: Long, songId: Long) = addSongs(playlistId, listOf(songId))

    fun addSongs(playlistId: Long, songIds: Collection<Long>) {
        launchSafely { playlistRepository.addSongs(playlistId, songIds) }
    }

    fun removeSong(playlistId: Long, songId: Long) {
        launchSafely { playlistRepository.removeSongFromPlaylist(playlistId, songId) }
    }

    /** A failed database write must never take the app down. */
    private fun launchSafely(block: suspend () -> Unit) {
        viewModelScope.launch {
            try {
                block()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                CrashReporter.recordNonFatal("Playlist change failed", e)
            }
        }
    }
}
