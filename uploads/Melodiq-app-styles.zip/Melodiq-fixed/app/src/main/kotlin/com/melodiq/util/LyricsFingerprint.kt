package com.melodiq.util

/**
 * A short, timing-independent signature of a lyrics text. Two copies of the same upload give the same
 * signature whether they are shown synced or plain, so the "Choose lyrics" list can tell which of
 * its versions is the one that is already in use.
 */
object LyricsFingerprint {
    private const val SAMPLE_LENGTH = 160

    // [01:23.45] and tags like [ar:Artist]; the brackets are escaped because Android's regex engine needs that
    private val BRACKETS = Regex("""\[[^\]]*\]""")

    /** Null when there is no text to compare. */
    fun of(synced: String?, plain: String?): String? {
        val text = synced?.takeIf { it.isNotBlank() } ?: plain?.takeIf { it.isNotBlank() } ?: return null
        val builder = StringBuilder(SAMPLE_LENGTH)
        for (ch in BRACKETS.replace(text, "")) {
            if (ch.isLetterOrDigit()) {
                builder.append(ch.lowercaseChar())
                if (builder.length >= SAMPLE_LENGTH) break
            }
        }
        return builder.toString().takeIf { it.isNotEmpty() }
    }
}
