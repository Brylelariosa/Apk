package com.melodiq.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.melodiq.R
import com.melodiq.data.model.LyricsTiming
import com.melodiq.ui.theme.AccentViolet
import com.melodiq.ui.theme.PrimaryPurple
import com.melodiq.ui.theme.TextMuted
import com.melodiq.ui.theme.TextPrimary
import com.melodiq.ui.theme.TextSecondary
import com.melodiq.ui.theme.White20
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.roundToInt

/** The slider covers this far either way; the ±1 s buttons can go further (up to [LyricsTiming.MAX_OFFSET_MS]). */
private const val SLIDER_RANGE_SECONDS = 10f

/** Holding a ±0.1 s button: wait this long, then repeat this often. */
private const val HOLD_DELAY_MS = 350L
private const val HOLD_REPEAT_MS = 70L

/** "In sync", "+1.5 s", "-0.3 s". */
internal fun formatSyncOffset(offsetMs: Long): String =
    if (offsetMs == 0L) "In sync" else String.format(Locale.US, "%+.1f s", offsetMs / 1000f)

/**
 * Moves the lyrics earlier or later in time — for lyrics that run ahead of the singer or behind it.
 *
 * It sits right above the lyrics, so the lines shift on screen while you adjust: drag the slider for
 * big moves, tap ±1 s for steps, hold ±0.1 s for fine tuning. Every change is applied at once; there
 * is nothing to confirm.
 *
 * Positive = the lyrics come later, negative = earlier.
 */
@Composable
fun LyricsSyncPanel(
    offsetMs: Long,
    onOffsetChange: (Long) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    // The panel keeps its own value while it is open, so a slow save never makes the control jump back.
    var draft by remember { mutableLongStateOf(offsetMs) }
    val saved by rememberUpdatedState(offsetMs)
    val report by rememberUpdatedState(onOffsetChange)

    // Every change is passed on at once, so the lyrics behind the panel shift while you adjust.
    LaunchedEffect(draft) {
        if (draft != saved) report(draft)
    }

    fun nudge(deltaMs: Long) {
        draft = (draft + deltaMs).coerceIn(-LyricsTiming.MAX_OFFSET_MS, LyricsTiming.MAX_OFFSET_MS)
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(Color.White.copy(alpha = 0.08f))
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text     = "Sync timing",
                style    = MaterialTheme.typography.labelLarge,
                color    = TextPrimary,
                modifier = Modifier.weight(1f)
            )
            Text(
                text  = formatSyncOffset(draft),
                style = MaterialTheme.typography.titleSmall,
                color = if (draft == 0L) TextSecondary else AccentViolet
            )
            if (draft != 0L) {
                TextButton(onClick = { draft = 0L }) {
                    Text("Reset", color = AccentViolet)
                }
            }
            IconActionButton(
                icon               = R.drawable.ic_close,
                contentDescription = "Close sync timing",
                onClick            = onClose,
                tint               = TextSecondary,
                buttonSize         = 36.dp,
                iconSize           = 20.dp
            )
        }

        Box(contentAlignment = Alignment.Center) {
            // a small mark for "0" behind the slider
            Box(
                Modifier
                    .width(2.dp)
                    .height(16.dp)
                    .background(TextMuted)
            )
            Slider(
                value         = (draft / 1000f).coerceIn(-SLIDER_RANGE_SECONDS, SLIDER_RANGE_SECONDS),
                onValueChange = { seconds -> draft = snapToStep(seconds) },
                valueRange    = -SLIDER_RANGE_SECONDS..SLIDER_RANGE_SECONDS,
                colors        = SliderDefaults.colors(
                    thumbColor         = PrimaryPurple,
                    activeTrackColor   = White20,
                    inactiveTrackColor = White20
                )
            )
        }
        Row(
            modifier              = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Earlier", style = MaterialTheme.typography.labelSmall, color = TextMuted)
            Text("Later", style = MaterialTheme.typography.labelSmall, color = TextMuted)
        }

        Row(
            modifier              = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp, bottom = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            StepChip(
                text        = "−1 s",
                description = "Show the lyrics 1 second earlier",
                repeat      = false,
                modifier    = Modifier.weight(1f)
            ) { nudge(-1_000L) }
            StepChip(
                text        = "−0.1 s",
                description = "Show the lyrics 0.1 second earlier. Hold to repeat",
                repeat      = true,
                modifier    = Modifier.weight(1f)
            ) { nudge(-LyricsTiming.STEP_MS) }
            StepChip(
                text        = "+0.1 s",
                description = "Show the lyrics 0.1 second later. Hold to repeat",
                repeat      = true,
                modifier    = Modifier.weight(1f)
            ) { nudge(LyricsTiming.STEP_MS) }
            StepChip(
                text        = "+1 s",
                description = "Show the lyrics 1 second later",
                repeat      = false,
                modifier    = Modifier.weight(1f)
            ) { nudge(1_000L) }
        }
    }
}

/** The slider moves smoothly; the value it stands for always lands on a tenth of a second. */
private fun snapToStep(seconds: Float): Long =
    (seconds * 10f).roundToInt() * LyricsTiming.STEP_MS

/**
 * A pill that steps on the moment it is pressed. With [repeat] it keeps stepping while it is held
 * (after a short wait), so a long move is one press instead of thirty taps.
 */
@Composable
private fun StepChip(
    text: String,
    description: String,
    repeat: Boolean,
    modifier: Modifier = Modifier,
    onStep: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val step by rememberUpdatedState(onStep)
    var pressed by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .height(40.dp)
            .clip(RoundedCornerShape(50))
            .background(if (pressed) PrimaryPurple.copy(alpha = 0.55f) else Color.White.copy(alpha = 0.10f))
            .semantics {
                contentDescription = description
                role = Role.Button
                onClick {
                    step()
                    true
                }
            }
            .pointerInput(repeat) {
                detectTapGestures(
                    onPress = {
                        pressed = true
                        step()
                        val repeater = if (repeat) {
                            scope.launch {
                                delay(HOLD_DELAY_MS)
                                while (true) {
                                    step()
                                    delay(HOLD_REPEAT_MS)
                                }
                            }
                        } else {
                            null
                        }
                        try {
                            tryAwaitRelease()
                        } finally {
                            repeater?.cancel()
                            pressed = false
                        }
                    }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text  = text,
            style = MaterialTheme.typography.labelLarge,
            color = TextPrimary
        )
    }
}
