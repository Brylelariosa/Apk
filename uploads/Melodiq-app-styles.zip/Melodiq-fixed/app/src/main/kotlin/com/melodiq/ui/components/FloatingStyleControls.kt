package com.melodiq.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.melodiq.data.model.FloatingLyricsSettings
import com.melodiq.data.model.LineAnimation
import com.melodiq.data.model.LyricLine
import com.melodiq.data.model.LyricsAlign
import com.melodiq.data.model.LyricsFont
import com.melodiq.data.model.LyricsWeight
import kotlinx.coroutines.delay

/*
 * The options that decide how the floating lyrics look. They are used twice: for the default style in
 * Settings and for the style of one app (AppProfilesSection), so both always offer the same choices.
 */

/**
 * Text, window and animation options of the floating lyrics. [update] changes the style being edited,
 * whichever one it is; the "when to show" switches are not here because they are the same for every app.
 */
@Composable
fun FloatingStyleControls(
    floating: FloatingLyricsSettings,
    update: ((FloatingLyricsSettings) -> FloatingLyricsSettings) -> Unit
) {
    SubHeading("Text")
    SliderRow(
        title      = "Lines shown",
        value      = floating.lines.toFloat(),
        range      = 1f..5f,
        steps      = 3,
        valueLabel = { it.toInt().toString() },
        onCommit   = { v -> update { it.copy(lines = v.toInt()) } }
    )
    SliderRow(
        title      = "Text size",
        value      = floating.textSizeSp,
        range      = 10f..40f,
        valueLabel = { it.toInt().toString() + " sp" },
        onCommit   = { v -> update { it.copy(textSizeSp = v) } }
    )
    ChoiceRow(
        title    = "Font",
        options  = LyricsFont.values().toList(),
        selected = floating.font,
        label    = { it.label },
        onSelect = { choice -> update { it.copy(font = choice) } }
    )
    ChoiceRow(
        title    = "Weight",
        options  = LyricsWeight.values().toList(),
        selected = floating.weight,
        label    = { it.label },
        onSelect = { choice -> update { it.copy(weight = choice) } }
    )
    ChoiceRow(
        title    = "Alignment",
        options  = LyricsAlign.values().toList(),
        selected = floating.alignment,
        label    = { it.label },
        onSelect = { choice -> update { it.copy(alignment = choice) } }
    )
    ColorRow(
        title    = "Text colour",
        selected = floating.textColor,
        onSelect = { argb -> update { it.copy(textColor = argb) } }
    )
    SliderRow(
        title      = "Other lines brightness",
        value      = floating.inactiveAlpha,
        range      = 0.1f..1f,
        valueLabel = { percent(it) },
        onCommit   = { v -> update { it.copy(inactiveAlpha = v) } }
    )
    SwitchRow(
        title    = "Text shadow",
        subtitle = "Keeps the words readable on any background.",
        checked  = floating.textShadow,
        onChange = { on -> update { it.copy(textShadow = on) } }
    )

    SubHeading("Window")
    ColorRow(
        title    = "Background colour",
        selected = floating.backgroundColor,
        onSelect = { argb -> update { it.copy(backgroundColor = argb) } }
    )
    SliderRow(
        title      = "Background opacity",
        value      = floating.backgroundAlpha,
        range      = 0f..1f,
        valueLabel = { percent(it) },
        onCommit   = { v -> update { it.copy(backgroundAlpha = v) } }
    )
    SliderRow(
        title      = "Corner radius",
        value      = floating.cornerRadiusDp.toFloat(),
        range      = 0f..40f,
        valueLabel = { it.toInt().toString() + " dp" },
        onCommit   = { v -> update { it.copy(cornerRadiusDp = v.toInt()) } }
    )
    SliderRow(
        title      = "Width",
        value      = floating.widthFraction,
        range      = 0.4f..1f,
        valueLabel = { percent(it) },
        onCommit   = { v -> update { it.copy(widthFraction = v) } }
    )
    SliderRow(
        title      = "Window opacity",
        value      = floating.windowAlpha,
        range      = 0.2f..1f,
        valueLabel = { percent(it) },
        onCommit   = { v -> update { it.copy(windowAlpha = v) } }
    )
    SwitchRow(
        title    = "Show song title",
        checked  = floating.showTitle,
        onChange = { on -> update { it.copy(showTitle = on) } }
    )
    SwitchRow(
        title    = "Show playback buttons",
        checked  = floating.showControls,
        onChange = { on -> update { it.copy(showControls = on) } }
    )
    SwitchRow(
        title    = "Lock position",
        subtitle = "Touches pass through the window to the app below. Unlock it here to move it again.",
        checked  = floating.locked,
        onChange = { on -> update { it.copy(locked = on) } }
    )
    SliderRow(
        title      = "Horizontal position",
        value      = floating.posX,
        range      = 0f..1f,
        valueLabel = { percent(it) },
        onCommit   = { v -> update { it.copy(posX = v) } }
    )
    SliderRow(
        title      = "Vertical position",
        value      = floating.posY,
        range      = 0f..1f,
        valueLabel = { percent(it) },
        onCommit   = { v -> update { it.copy(posY = v) } }
    )
    ResetRow(
        text    = "Reset position",
        onReset = { update { it.copy(posX = 0.5f, posY = 0.14f) } }
    )

    SubHeading("Animation")
    ChoiceRow(
        title    = "When the line changes",
        options  = LineAnimation.values().toList(),
        selected = floating.animation,
        label    = { it.label },
        onSelect = { choice -> update { it.copy(animation = choice) } }
    )
    SliderRow(
        title      = "Animation length",
        value      = floating.animationMs.toFloat(),
        range      = 100f..800f,
        valueLabel = { it.toInt().toString() + " ms" },
        onCommit   = { v -> update { it.copy(animationMs = v.toInt()) } }
    )
}

/** The real floating window, drawn with the settings as they are right now, advancing by itself. */
@Composable
fun FloatingPreview(floating: FloatingLyricsSettings) {
    val sample = remember {
        listOf(
            "Walking down the quiet street",
            "Streetlights painting gold on glass",
            "Every little thing I need",
            "Is right here while the moments pass",
            "So play the song again",
            "And let the night go slow"
        ).mapIndexed { index, text -> LyricLine(timeMs = index * 4_000L, text = text) }
    }
    var index by remember { mutableIntStateOf(1) }
    LaunchedEffect(sample.size) {
        while (true) {
            delay(2_800L)
            index = (index + 1) % sample.size
        }
    }
    val window = remember(index, floating.lines) { buildLyricWindow(sample, index, floating.lines) }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF3A2A6B), Color(0xFF1B6B7A))))
            .padding(vertical = 24.dp),
        contentAlignment = Alignment.Center
    ) {
        FloatingLyricsCard(
            window    = window,
            settings  = floating,
            modifier  = Modifier.fillMaxWidth(floating.widthFraction),
            title     = if (floating.showTitle) "Song title \u2014 Artist" else null,
            isPlaying = true
        )
    }
}
