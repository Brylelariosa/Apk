package com.melodiq.ui.components

import androidx.annotation.DrawableRes
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.melodiq.R
import com.melodiq.data.model.Song
import com.melodiq.ui.theme.AccentViolet
import com.melodiq.ui.theme.Divider
import com.melodiq.ui.theme.PrimaryPurple
import com.melodiq.ui.theme.TextMuted
import com.melodiq.ui.theme.TextPrimary
import com.melodiq.ui.theme.TextSecondary
import com.melodiq.ui.viewmodel.PlaylistItem
import com.melodiq.ui.viewmodel.PlaylistsUiState
import com.melodiq.util.PlaylistNames

// ── Name ──────────────────────────────────────────────────────────────────────

/**
 * Asks for a playlist name — used to create one and to rename one. [validate] returns the message to
 * show under the field (or null when the name can be used); it is shown once the user has typed.
 */
@Composable
fun PlaylistNameDialog(
    title: String,
    confirmLabel: String,
    initialName: String,
    validate: (String) -> String?,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf(initialName) }
    var edited by remember { mutableStateOf(false) }
    val problem = validate(name)
    val focusRequester = remember { FocusRequester() }

    LaunchedEffect(Unit) {
        try { focusRequester.requestFocus() } catch (_: Exception) { }
    }

    MelodiqDialog(onDismiss = onDismiss) {
        Text(
            text     = title,
            style    = MaterialTheme.typography.titleLarge,
            color    = TextPrimary,
            modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
        )
        OutlinedTextField(
            value           = name,
            onValueChange   = { typed ->
                name = typed.take(PlaylistNames.MAX_LENGTH)
                edited = true
            },
            label           = { Text("Playlist name") },
            placeholder     = { Text("e.g. Japan, Love songs", color = TextMuted) },
            singleLine      = true,
            isError         = edited && problem != null,
            supportingText  = if (edited && problem != null) ({ Text(problem) }) else null,
            keyboardOptions = KeyboardOptions(
                capitalization = KeyboardCapitalization.Sentences,
                imeAction      = ImeAction.Done
            ),
            keyboardActions = KeyboardActions(onDone = { if (problem == null) onConfirm(name) }),
            colors          = melodiqFieldColors(),
            modifier        = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp)
                .focusRequester(focusRequester)
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 16.dp, top = 12.dp),
            horizontalArrangement = Arrangement.End,
            verticalAlignment     = Alignment.CenterVertically
        ) {
            TextButton(onClick = onDismiss) { Text("Cancel", color = TextSecondary) }
            Spacer(Modifier.width(8.dp))
            MelodiqButton(
                text    = confirmLabel,
                onClick = { onConfirm(name) },
                icon    = R.drawable.ic_check,
                enabled = problem == null
            )
        }
    }
}

// ── Confirm ───────────────────────────────────────────────────────────────────

/** "Are you sure?" for something that cannot be undone. */
@Composable
fun ConfirmDialog(
    title: String,
    message: String,
    confirmLabel: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
    @DrawableRes confirmIcon: Int? = null
) {
    MelodiqDialog(onDismiss = onDismiss) {
        Text(
            text     = title,
            style    = MaterialTheme.typography.titleLarge,
            color    = TextPrimary,
            modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
        )
        Text(
            text     = message,
            style    = MaterialTheme.typography.bodyMedium,
            color    = TextSecondary,
            modifier = Modifier.padding(horizontal = 24.dp, vertical = 4.dp)
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 16.dp, top = 16.dp),
            horizontalArrangement = Arrangement.End,
            verticalAlignment     = Alignment.CenterVertically
        ) {
            TextButton(onClick = onDismiss) { Text("Cancel", color = TextSecondary) }
            Spacer(Modifier.width(8.dp))
            MelodiqButton(
                text    = confirmLabel,
                onClick = onConfirm,
                icon    = confirmIcon,
                accent  = MaterialTheme.colorScheme.error
            )
        }
    }
}

// ── One playlist ──────────────────────────────────────────────────────────────

/** What can be done with a playlist from the list: rename or delete. */
@Composable
fun PlaylistActionsDialog(
    item: PlaylistItem,
    onRename: () -> Unit,
    onDelete: () -> Unit,
    onDismiss: () -> Unit
) {
    MelodiqDialog(onDismiss = onDismiss) {
        Column(Modifier.padding(horizontal = 24.dp, vertical = 8.dp)) {
            Text(
                text     = item.name,
                style    = MaterialTheme.typography.titleMedium,
                color    = TextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text  = item.countLabel,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
        }
        OptionRow(
            icon     = R.drawable.ic_edit,
            title    = "Rename",
            subtitle = "Give this playlist another name",
            onClick  = onRename
        )
        OptionRow(
            icon     = R.drawable.ic_delete,
            title    = "Delete",
            subtitle = "Your songs stay on the phone",
            onClick  = onDelete
        )
    }
}

// ── Add a song to a playlist ──────────────────────────────────────────────────

/** Pick the playlist [song] goes into, or start a new one. */
@Composable
fun AddToPlaylistDialog(
    song: Song,
    state: PlaylistsUiState,
    onPick: (PlaylistItem) -> Unit,
    onNewPlaylist: () -> Unit,
    onDismiss: () -> Unit
) {
    MelodiqDialog(onDismiss = onDismiss) {
        Column(Modifier.padding(horizontal = 24.dp, vertical = 8.dp)) {
            Text(
                text  = "Add to playlist",
                style = MaterialTheme.typography.titleLarge,
                color = TextPrimary
            )
            Text(
                text     = song.title,
                style    = MaterialTheme.typography.bodySmall,
                color    = TextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        OptionRow(
            icon     = R.drawable.ic_add,
            title    = "New playlist",
            subtitle = "Create one and put this song in it",
            onClick  = onNewPlaylist
        )
        if (state.items.isNotEmpty()) {
            HorizontalDivider(
                modifier  = Modifier.padding(vertical = 4.dp),
                thickness = 0.5.dp,
                color     = Divider
            )
            LazyColumn(modifier = Modifier.heightIn(max = 300.dp)) {
                items(state.items, key = { it.id }) { item ->
                    PlaylistPickRow(
                        item      = item,
                        alreadyIn = item.contains(song.id),
                        onClick   = { onPick(item) }
                    )
                }
            }
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.End
        ) {
            TextButton(onClick = onDismiss) { Text("Close", color = TextSecondary) }
        }
    }
}

@Composable
private fun PlaylistPickRow(item: PlaylistItem, alreadyIn: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 24.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ArtworkImage(
            uri      = item.songs.firstOrNull()?.artworkUri,
            shape    = RoundedCornerShape(8.dp),
            modifier = Modifier.size(40.dp)
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text     = item.name,
                style    = MaterialTheme.typography.bodyLarge,
                color    = TextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text  = if (alreadyIn) "Already in this playlist" else item.countLabel,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
        }
        if (alreadyIn) {
            VectorIcon(id = R.drawable.ic_check, tint = AccentViolet, size = 22.dp)
        }
    }
}

// ── Add many songs to one playlist ────────────────────────────────────────────

/**
 * Tick any number of songs, then add them all at once. [songs] are the ones that are not in the
 * playlist yet.
 */
@Composable
fun SongPickerDialog(
    playlistName: String,
    songs: List<Song>,
    onAdd: (Set<Long>) -> Unit,
    onDismiss: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf(emptySet<Long>()) }
    val visible = remember(songs, query) {
        val wanted = query.trim()
        if (wanted.isEmpty()) {
            songs
        } else {
            songs.filter {
                it.title.contains(wanted, ignoreCase = true) || it.artist.contains(wanted, ignoreCase = true)
            }
        }
    }

    MelodiqDialog(onDismiss = onDismiss, tall = true) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(
                Modifier
                    .weight(1f)
                    .padding(start = 8.dp)
            ) {
                Text("Add songs", style = MaterialTheme.typography.titleLarge, color = TextPrimary)
                Text(
                    text     = "to " + playlistName,
                    style    = MaterialTheme.typography.bodySmall,
                    color    = TextSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            IconActionButton(
                icon               = R.drawable.ic_close,
                contentDescription = "Close",
                onClick            = onDismiss,
                tint               = TextSecondary,
                buttonSize         = 44.dp,
                iconSize           = 22.dp
            )
        }

        OutlinedTextField(
            value         = query,
            onValueChange = { query = it },
            placeholder   = { Text("Search your songs", color = TextMuted) },
            leadingIcon   = { VectorIcon(id = R.drawable.ic_search, tint = TextSecondary, size = 22.dp) },
            singleLine    = true,
            shape         = RoundedCornerShape(16.dp),
            colors        = melodiqFieldColors(),
            modifier      = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))

        Box(
            Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            if (visible.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        text  = if (songs.isEmpty()) "Every song is already in this playlist." else "No songs match.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                }
            } else {
                LazyColumn(Modifier.fillMaxSize()) {
                    items(visible, key = { it.id }) { song ->
                        PickSongRow(
                            song     = song,
                            checked  = song.id in selected,
                            onToggle = {
                                selected = if (song.id in selected) selected - song.id else selected + song.id
                            }
                        )
                    }
                }
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp),
            verticalAlignment     = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.End
        ) {
            TextButton(onClick = onDismiss) { Text("Cancel", color = TextSecondary) }
            Spacer(Modifier.width(8.dp))
            MelodiqButton(
                text    = if (selected.isEmpty()) "Add" else "Add (" + selected.size + ")",
                onClick = { onAdd(selected) },
                icon    = R.drawable.ic_check,
                enabled = selected.isNotEmpty()
            )
        }
    }
}

@Composable
private fun PickSongRow(song: Song, checked: Boolean, onToggle: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onToggle)
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ArtworkImage(
            uri      = song.artworkUri,
            shape    = RoundedCornerShape(8.dp),
            modifier = Modifier.size(40.dp)
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text     = song.title,
                style    = MaterialTheme.typography.bodyMedium,
                color    = TextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text     = song.artist,
                style    = MaterialTheme.typography.bodySmall,
                color    = TextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Checkbox(
            checked         = checked,
            onCheckedChange = null,
            colors          = CheckboxDefaults.colors(
                checkedColor   = PrimaryPurple,
                uncheckedColor = TextSecondary,
                checkmarkColor = Color.White
            )
        )
    }
}
