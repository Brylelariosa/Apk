package com.melodiq.ui.screen

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.melodiq.R
import com.melodiq.data.model.BackgroundStyle
import com.melodiq.data.model.CoverMotion
import com.melodiq.data.model.CoverStyle
import com.melodiq.data.model.FloatingLyricsSettings
import com.melodiq.data.model.LookSettings
import com.melodiq.data.model.LyricsAlign
import com.melodiq.data.model.LyricsFont
import com.melodiq.data.model.LyricsStyleSettings
import com.melodiq.data.model.LyricsWeight
import com.melodiq.data.model.NowPlayingVisual
import com.melodiq.data.model.VisualizerStyle
import com.melodiq.overlay.OverlayPermission
import com.melodiq.ui.components.ChoiceRow
import com.melodiq.ui.components.ColorRow
import com.melodiq.ui.components.FloatingPreview
import com.melodiq.ui.components.FloatingStyleControls
import com.melodiq.ui.components.IconActionButton
import com.melodiq.ui.components.MelodiqButton
import com.melodiq.ui.components.OnResumeEffect
import com.melodiq.ui.components.OverlayPermissionDialog
import com.melodiq.ui.components.ResetRow
import com.melodiq.ui.components.SettingsSection
import com.melodiq.ui.components.SliderRow
import com.melodiq.ui.components.SubHeading
import com.melodiq.ui.components.SwitchRow
import com.melodiq.ui.components.percent
import com.melodiq.ui.theme.TextPrimary
import com.melodiq.ui.theme.TextSecondary
import com.melodiq.ui.viewmodel.SettingsViewModel
import java.util.Locale

/** How Now Playing, the lyrics and the floating lyrics look and behave. Every change applies immediately. */
@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    viewModel: SettingsViewModel = hiltViewModel()
) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var overlayAllowed by remember { mutableStateOf(OverlayPermission.isGranted(context)) }
    var showPermissionDialog by remember { mutableStateOf(false) }
    var waitingForPermission by remember { mutableStateOf(false) }

    // Back from the system "Display over other apps" screen: pick up the new permission and, if
    // that is why the user went there, finish switching the floating lyrics on.
    OnResumeEffect {
        overlayAllowed = OverlayPermission.isGranted(context)
        if (waitingForPermission && overlayAllowed) {
            waitingForPermission = false
            viewModel.updateFloating { it.copy(enabled = true) }
        }
    }

    if (showPermissionDialog) {
        OverlayPermissionDialog(
            onDismiss = { showPermissionDialog = false },
            onOpenSettings = {
                showPermissionDialog = false
                waitingForPermission = true
                OverlayPermission.openSettings(context)
            }
        )
    }

    Column(
        Modifier
            .fillMaxSize()
            .systemBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconActionButton(
                icon               = R.drawable.ic_arrow_back,
                contentDescription = "Back",
                onClick            = onBack,
                tint               = Color.White,
                buttonSize         = 48.dp,
                iconSize           = 24.dp
            )
            Text(
                text     = "Settings",
                style    = MaterialTheme.typography.titleLarge,
                color    = TextPrimary,
                modifier = Modifier.padding(start = 8.dp)
            )
        }

        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(bottom = 32.dp)
        ) {
            LookSection(
                look     = settings.look,
                update   = { transform -> viewModel.updateLook(transform) },
                onReset  = { viewModel.resetLook() }
            )
            LyricsSection(
                style    = settings.lyrics,
                update   = { transform -> viewModel.updateLyrics(transform) },
                onReset  = { viewModel.resetLyrics() }
            )
            FloatingSection(
                floating         = settings.floating,
                overlayAllowed   = overlayAllowed,
                onAskPermission  = { showPermissionDialog = true },
                update           = { transform -> viewModel.updateFloating(transform) },
                onReset          = { viewModel.resetFloating() }
            )
            AppProfilesSection()
        }
    }
}

// ── Now Playing look ──────────────────────────────────────────────────────────

@Composable
private fun LookSection(
    look: LookSettings,
    update: ((LookSettings) -> LookSettings) -> Unit,
    onReset: () -> Unit
) {
    SettingsSection("Now Playing look") {
        ChoiceRow(
            title    = "Picture",
            options  = NowPlayingVisual.values().toList(),
            selected = look.visual,
            label    = { it.label },
            onSelect = { choice -> update { it.copy(visual = choice) } }
        )
        ChoiceRow(
            title    = "Animation style",
            options  = VisualizerStyle.values().toList(),
            selected = look.visualizerStyle,
            label    = { it.label },
            onSelect = { choice -> update { it.copy(visualizerStyle = choice) } }
        )
        ChoiceRow(
            title    = "Background",
            options  = BackgroundStyle.values().toList(),
            selected = look.backgroundStyle,
            label    = { it.label },
            onSelect = { choice -> update { it.copy(backgroundStyle = choice) } }
        )
        SliderRow(
            title      = "Glow strength",
            value      = look.backgroundIntensity,
            range      = 0f..1f,
            valueLabel = { percent(it) },
            onCommit   = { v -> update { it.copy(backgroundIntensity = v) } }
        )
        SliderRow(
            title      = "Animation speed",
            value      = look.animationSpeed,
            range      = 0.25f..2f,
            valueLabel = { String.format(Locale.US, "%.2fx", it) },
            onCommit   = { v -> update { it.copy(animationSpeed = v) } }
        )
        SwitchRow(
            title    = "Animate only while playing",
            subtitle = "Everything holds still when the music is paused, which saves battery.",
            checked  = look.animateOnlyWhilePlaying,
            onChange = { on -> update { it.copy(animateOnlyWhilePlaying = on) } }
        )
        ChoiceRow(
            title    = "Cover shape",
            options  = CoverStyle.values().toList(),
            selected = look.coverStyle,
            label    = { it.label },
            onSelect = { choice -> update { it.copy(coverStyle = choice) } }
        )
        ChoiceRow(
            title    = "Cover motion",
            options  = CoverMotion.values().toList(),
            selected = look.coverMotion,
            label    = { it.label },
            onSelect = { choice -> update { it.copy(coverMotion = choice) } }
        )
        SwitchRow(
            title    = "Cover glow",
            checked  = look.coverGlow,
            onChange = { on -> update { it.copy(coverGlow = on) } }
        )
        SliderRow(
            title      = "Cover size",
            value      = look.coverSizeDp.toFloat(),
            range      = 160f..360f,
            valueLabel = { it.toInt().toString() + " dp" },
            onCommit   = { v -> update { it.copy(coverSizeDp = v.toInt()) } }
        )
        ResetRow(text = "Reset look", onReset = onReset)
    }
}

// ── Lyrics in the app ─────────────────────────────────────────────────────────

@Composable
private fun LyricsSection(
    style: LyricsStyleSettings,
    update: ((LyricsStyleSettings) -> LyricsStyleSettings) -> Unit,
    onReset: () -> Unit
) {
    SettingsSection("Lyrics") {
        SliderRow(
            title      = "Text size",
            value      = style.textSizeSp,
            range      = 14f..40f,
            valueLabel = { it.toInt().toString() + " sp" },
            onCommit   = { v -> update { it.copy(textSizeSp = v) } }
        )
        ChoiceRow(
            title    = "Alignment",
            options  = LyricsAlign.values().toList(),
            selected = style.alignment,
            label    = { it.label },
            onSelect = { choice -> update { it.copy(alignment = choice) } }
        )
        ChoiceRow(
            title    = "Font",
            options  = LyricsFont.values().toList(),
            selected = style.font,
            label    = { it.label },
            onSelect = { choice -> update { it.copy(font = choice) } }
        )
        ChoiceRow(
            title    = "Weight",
            options  = LyricsWeight.values().toList(),
            selected = style.weight,
            label    = { it.label },
            onSelect = { choice -> update { it.copy(weight = choice) } }
        )
        SliderRow(
            title      = "Current line size",
            value      = style.activeScale,
            range      = 1f..1.3f,
            valueLabel = { percent(it) },
            onCommit   = { v -> update { it.copy(activeScale = v) } }
        )
        SliderRow(
            title      = "Other lines brightness",
            value      = style.inactiveAlpha,
            range      = 0.1f..1f,
            valueLabel = { percent(it) },
            onCommit   = { v -> update { it.copy(inactiveAlpha = v) } }
        )
        SwitchRow(
            title    = "Fade distant lines",
            checked  = style.fadeDistant,
            onChange = { on -> update { it.copy(fadeDistant = on) } }
        )
        ColorRow(
            title           = "Current line colour",
            selected        = style.highlightColor,
            allowAlbumColor = true,
            onSelect        = { argb -> update { it.copy(highlightColor = argb) } }
        )
        SwitchRow(
            title    = "Glow behind the current line",
            checked  = style.glow,
            onChange = { on -> update { it.copy(glow = on) } }
        )
        SwitchRow(
            title    = "Smooth scrolling",
            subtitle = "Off makes the lyrics jump to each line instead of gliding.",
            checked  = style.smoothScroll,
            onChange = { on -> update { it.copy(smoothScroll = on) } }
        )
        SwitchRow(
            title    = "Tap a line to jump to it",
            checked  = style.tapToSeek,
            onChange = { on -> update { it.copy(tapToSeek = on) } }
        )
        SwitchRow(
            title    = "Keep the screen on",
            subtitle = "While the lyrics are showing.",
            checked  = style.keepScreenOn,
            onChange = { on -> update { it.copy(keepScreenOn = on) } }
        )
        ResetRow(text = "Reset lyrics style", onReset = onReset)
    }
}

// ── Floating lyrics ───────────────────────────────────────────────────────────

@Composable
private fun FloatingSection(
    floating: FloatingLyricsSettings,
    overlayAllowed: Boolean,
    onAskPermission: () -> Unit,
    update: ((FloatingLyricsSettings) -> FloatingLyricsSettings) -> Unit,
    onReset: () -> Unit
) {
    SettingsSection("Floating lyrics") {
        SwitchRow(
            title    = "Show floating lyrics",
            subtitle = "The current line in a small window on top of other apps. Drag it to move it.",
            checked  = floating.enabled,
            onChange = { on ->
                if (on && !overlayAllowed) onAskPermission() else update { it.copy(enabled = on) }
            }
        )
        if (!overlayAllowed) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Text(
                    text  = "Android needs your permission to show a window above other apps.",
                    color = TextSecondary,
                    style = MaterialTheme.typography.bodySmall
                )
                Spacer(Modifier.height(8.dp))
                MelodiqButton(text = "Allow display over other apps", onClick = onAskPermission)
            }
        }

        FloatingPreview(floating)

        SubHeading("When to show")
        SwitchRow(
            title    = "Only while music plays",
            checked  = floating.showOnlyWhilePlaying,
            onChange = { on -> update { it.copy(showOnlyWhilePlaying = on) } }
        )
        SwitchRow(
            title    = "Hide while Melodiq is open",
            subtitle = "The lyrics are already on the Now Playing screen.",
            checked  = floating.hideInApp,
            onChange = { on -> update { it.copy(hideInApp = on) } }
        )
        SwitchRow(
            title    = "Hide when there are no synced lyrics",
            checked  = floating.hideWhenNoLyrics,
            onChange = { on -> update { it.copy(hideWhenNoLyrics = on) } }
        )

        FloatingStyleControls(floating = floating, update = update)

        ResetRow(text = "Reset floating lyrics", onReset = onReset)
    }
}
