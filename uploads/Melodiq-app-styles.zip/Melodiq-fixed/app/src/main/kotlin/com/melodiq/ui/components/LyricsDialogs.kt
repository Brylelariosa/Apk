package com.melodiq.ui.components

import androidx.activity.compose.BackHandler
import androidx.annotation.DrawableRes
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.melodiq.R
import com.melodiq.data.model.LyricsCandidate
import com.melodiq.ui.theme.AccentViolet
import com.melodiq.ui.theme.PrimaryPurple
import com.melodiq.ui.theme.SurfaceDark
import com.melodiq.ui.theme.TextMuted
import com.melodiq.ui.theme.TextPrimary
import com.melodiq.ui.theme.TextSecondary
import com.melodiq.ui.viewmodel.VersionsUiState
import java.util.Locale

private val InUseGreen = Color(0xFF2E9E6B)

// ── Options ───────────────────────────────────────────────────────────────────

/** Everything the user can do about the lyrics of the current song. */
@Composable
fun LyricsOptionsDialog(
    offsetMs: Long,
    isCustom: Boolean,
    canSync: Boolean,
    onDismiss: () -> Unit,
    onChooseVersion: () -> Unit,
    onEdit: () -> Unit,
    onImport: () -> Unit,
    onReset: () -> Unit,
    onOpenSync: () -> Unit
) {
    MelodiqDialog(onDismiss = onDismiss) {
        Text(
            text     = "Lyrics",
            style    = MaterialTheme.typography.titleLarge,
            color    = TextPrimary,
            modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
        )
        OptionRow(
            icon     = R.drawable.ic_list,
            title    = "Choose another version",
            subtitle = "See every version found online and pick the full one",
            onClick  = onChooseVersion
        )
        OptionRow(
            icon     = R.drawable.ic_edit,
            title    = "Edit or paste lyrics",
            subtitle = "Type, paste or fix the lyrics yourself",
            onClick  = onEdit
        )
        OptionRow(
            icon     = R.drawable.ic_upload,
            title    = "Import an .lrc or .txt file",
            subtitle = "Use a lyrics file from your phone",
            onClick  = onImport
        )
        if (isCustom) {
            OptionRow(
                icon     = R.drawable.ic_refresh,
                title    = "Back to automatic lyrics",
                subtitle = "Forget your choice for this song",
                onClick  = onReset
            )
        }
        // Timing only exists for synced lyrics. The controls themselves open above the lyrics, so
        // the lines can be watched moving while they are adjusted.
        if (canSync) {
            OptionRow(
                icon     = R.drawable.ic_tune,
                title    = "Sync timing",
                subtitle = if (offsetMs == 0L) {
                    "Lyrics early or late? Adjust them while they play"
                } else {
                    "Shifted " + formatSyncOffset(offsetMs) + " — tap to adjust"
                },
                onClick  = onOpenSync
            )
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.End
        ) {
            TextButton(onClick = onDismiss) { Text("Close", color = TextSecondary) }
        }
    }
}

/** One tappable row of an options dialog: an icon, a title and what it does. Shared with the song menu. */
@Composable
internal fun OptionRow(
    @DrawableRes icon: Int,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 24.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        VectorIcon(id = icon, tint = AccentViolet, size = 24.dp)
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = TextPrimary, style = MaterialTheme.typography.bodyLarge)
            Text(subtitle, color = TextSecondary, style = MaterialTheme.typography.bodySmall)
        }
    }
}

// ── Editor ────────────────────────────────────────────────────────────────────

/**
 * Free-form lyrics editor. Text with [mm:ss.xx] timestamps becomes synced lyrics, anything else is
 * shown as plain lyrics. Saving empty text goes back to the automatic lyrics.
 *
 * It is a full screen laid over Now Playing rather than a dialog: the keyboard pushes the whole
 * screen up ([imePadding]), so the text field simply gets shorter and the last lines of a long
 * lyrics can always be scrolled into view — inside a dialog the keyboard covered them.
 */
@Composable
fun LyricsEditorScreen(
    initialText: String,
    onDismiss: () -> Unit,
    onSave: (String) -> Unit
) {
    // Deliberately not rememberSaveable: lyrics can be long and would overflow the saved-state bundle.
    var text by remember { mutableStateOf(initialText) }
    val clipboard = LocalClipboardManager.current

    // Back closes the editor, not the Now Playing screen underneath it.
    BackHandler(onBack = onDismiss)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SurfaceDark)
            // swallow touches, so nothing of the screen underneath can be tapped through the editor
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication        = null,
                onClick           = {}
            )
            .systemBarsPadding()
            .imePadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 4.dp, end = 12.dp, top = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconActionButton(
                icon               = R.drawable.ic_close,
                contentDescription = "Cancel",
                onClick            = onDismiss,
                tint               = TextSecondary
            )
            Text(
                text     = "Edit lyrics",
                style    = MaterialTheme.typography.titleLarge,
                color    = TextPrimary,
                modifier = Modifier
                    .weight(1f)
                    .padding(start = 4.dp)
            )
            MelodiqButton(
                text    = "Save",
                onClick = { onSave(text) },
                icon    = R.drawable.ic_check
            )
        }
        Text(
            text     = "Paste or type the lyrics. Lines that start with a time like [01:23.45] stay synced; " +
                "plain text is shown as normal lyrics.",
            style    = MaterialTheme.typography.bodySmall,
            color    = TextSecondary,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)
        )
        OutlinedTextField(
            value         = text,
            onValueChange = { text = it },
            placeholder   = { Text("Lyrics…", color = TextMuted) },
            colors        = melodiqFieldColors(),
            modifier      = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(horizontal = 12.dp, vertical = 8.dp)
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = {
                val pasted = clipboard.getText()?.text
                if (!pasted.isNullOrEmpty()) text = pasted
            }) { Text("Paste", color = AccentViolet) }
            TextButton(onClick = { text = "" }) { Text("Clear", color = TextSecondary) }
        }
    }
}

// ── Version picker ────────────────────────────────────────────────────────────

/**
 * Lists every version of the song found online. Different uploads of the same song often differ:
 * one is complete, another stops after the second verse. The user picks the right one.
 *
 * [onSearch] gets `refresh = false` for the search made when the dialog opens (a repeat of an earlier
 * search is then answered at once) and `true` when the user taps Search again.
 */
@Composable
fun LyricsVersionsDialog(
    initialTitle: String,
    initialArtist: String,
    state: VersionsUiState,
    onSearch: (title: String, artist: String, refresh: Boolean) -> Unit,
    onPick: (LyricsCandidate) -> Unit,
    onDismiss: () -> Unit
) {
    var title  by rememberSaveable { mutableStateOf(initialTitle) }
    var artist by rememberSaveable { mutableStateOf(initialArtist) }
    val canSearch = title.isNotBlank()

    // search right away with what we already know about the song
    LaunchedEffect(Unit) { onSearch(initialTitle, initialArtist, false) }

    MelodiqDialog(onDismiss = onDismiss, tall = true) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text     = "Choose lyrics",
                style    = MaterialTheme.typography.titleLarge,
                color    = TextPrimary,
                modifier = Modifier
                    .weight(1f)
                    .padding(start = 8.dp)
            )
            IconActionButton(
                icon               = R.drawable.ic_close,
                contentDescription = "Close",
                onClick            = onDismiss,
                tint               = TextSecondary,
                buttonSize         = 44.dp,
                iconSize           = 22.dp
            )
        }

        OutlinedTextField(
            value           = title,
            onValueChange   = { title = it },
            label           = { Text("Song title") },
            singleLine      = true,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
            colors          = melodiqFieldColors(),
            modifier        = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value           = artist,
                onValueChange   = { artist = it },
                label           = { Text("Artist (optional)") },
                singleLine      = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { if (canSearch) onSearch(title, artist, true) }),
                colors          = melodiqFieldColors(),
                modifier        = Modifier.weight(1f)
            )
            Spacer(Modifier.width(8.dp))
            MelodiqButton(
                text    = "Search",
                onClick = { onSearch(title, artist, true) },
                icon    = R.drawable.ic_search,
                enabled = canSearch
            )
        }
        Spacer(Modifier.height(12.dp))

        Box(
            Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            VersionsContent(state = state, onPick = onPick, onRetry = { onSearch(title, artist, true) })
        }
    }
}

@Composable
private fun VersionsContent(
    state: VersionsUiState,
    onPick: (LyricsCandidate) -> Unit,
    onRetry: () -> Unit
) {
    when (state) {
        is VersionsUiState.Idle -> Unit
        is VersionsUiState.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = PrimaryPurple, modifier = Modifier.size(32.dp))
        }
        is VersionsUiState.Empty -> CenteredNote(
            text = "No lyrics found for these words. Check the spelling or try the title only."
        )
        is VersionsUiState.Offline -> Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text  = "Can't reach the lyrics service. Check your connection.",
                color = TextSecondary,
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(Modifier.height(12.dp))
            MelodiqButton(text = "Try again", onClick = onRetry, icon = R.drawable.ic_refresh)
        }
        is VersionsUiState.Results -> LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(state.items, key = { it.id }) { candidate ->
                CandidateCard(candidate = candidate, onClick = { onPick(candidate) })
            }
        }
    }
}

@Composable
private fun CenteredNote(text: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(
            text  = text,
            color = TextSecondary,
            style = MaterialTheme.typography.bodyMedium
        )
    }
}

@Composable
private fun CandidateCard(candidate: LyricsCandidate, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color.White.copy(alpha = 0.06f))
            .clickable(onClick = onClick)
            .padding(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text     = headlineOf(candidate),
                color    = TextPrimary,
                style    = MaterialTheme.typography.bodyMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            if (candidate.isCurrent) VersionBadge(text = "In use", color = InUseGreen)
            if (candidate.isBestMatch) VersionBadge(text = "Best match", color = PrimaryPurple)
        }
        Text(
            text     = detailsOf(candidate),
            color    = TextSecondary,
            style    = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(top = 2.dp)
        )
        if (candidate.preview.isNotBlank()) {
            Text(
                text     = candidate.preview,
                color    = TextMuted,
                style    = MaterialTheme.typography.bodySmall,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
}

@Composable
private fun VersionBadge(text: String, color: Color) {
    Text(
        text     = text,
        color    = Color.White,
        style    = MaterialTheme.typography.labelSmall,
        modifier = Modifier
            .padding(start = 8.dp)
            .clip(RoundedCornerShape(50))
            .background(color.copy(alpha = 0.7f))
            .padding(horizontal = 8.dp, vertical = 2.dp)
    )
}

private fun headlineOf(c: LyricsCandidate): String {
    val title = c.title.ifBlank { "Untitled" }
    return if (c.artist.isBlank()) title else title + " — " + c.artist
}

private fun detailsOf(c: LyricsCandidate): String {
    val parts = ArrayList<String>()
    if (c.album.isNotBlank()) parts.add(c.album)
    val duration = c.durationSec
    if (duration != null && duration > 0) {
        val diff = c.durationDiffSec
        val length = String.format(Locale.US, "%d:%02d", duration / 60, duration % 60)
        parts.add(if (diff != null && diff > 0) length + " (" + diff + " s off)" else length)
    }
    parts.add(
        if (c.syncedLines > 0) "Synced, " + c.syncedLines + " lines"
        else "Plain, " + c.plainLines + " lines"
    )
    return parts.joinToString("  ·  ")
}
