package com.melodiq.player

import androidx.media3.common.ForwardingPlayer
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi

/**
 * The player the media session (and so the notification, lock screen and headset buttons) talks to.
 *
 * ExoPlayer withdraws "next" when there is no next song (the last song with repeat off). The
 * notification then lost a button exactly when a queue ended — the play button jumped across and on
 * Android 13+ an empty slot appeared. Here "previous" and "next" stay available all the time, so the
 * three buttons never move. Pressing "next" on the last song simply does nothing.
 */
@OptIn(UnstableApi::class)
class SkippablePlayer(player: Player) : ForwardingPlayer(player) {

    override fun getAvailableCommands(): Player.Commands =
        super.getAvailableCommands().buildUpon()
            .addAll(Player.COMMAND_SEEK_TO_NEXT, Player.COMMAND_SEEK_TO_PREVIOUS)
            .build()

    override fun isCommandAvailable(command: Int): Boolean =
        command == Player.COMMAND_SEEK_TO_NEXT ||
            command == Player.COMMAND_SEEK_TO_PREVIOUS ||
            super.isCommandAvailable(command)
}
