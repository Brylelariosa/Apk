package com.melodiq.overlay

import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.PowerManager
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Tells which app is on screen, so the floating lyrics can use that app's own style.
 *
 * Android has no callback for "another app came to the front", so while somebody is listening
 * ([observe]) this reads the system's short log of app switches about every second. It only looks at
 * the package name of the app that was last brought to the front. Nobody listens when the floating
 * lyrics are off, when nothing is playing or when per-app styles are off, so then it costs nothing.
 * It needs the "Usage access" permission ([UsageAccessPermission]); without it the answer is null.
 */
@Singleton
class ForegroundAppTracker @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val usageStats = context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager
    private val power = context.getSystemService(Context.POWER_SERVICE) as? PowerManager

    // Where the last look at the log ended and what it showed. Kept between listeners, so a listener
    // that starts again does not have to read the whole log from the beginning.
    private var cursorMs = 0L
    private var current: String? = null

    /** The package of the app on screen (null when unknown), whenever it changes. Polls while collected. */
    fun observe(): Flow<String?> = flow {
        while (true) {
            when {
                !UsageAccessPermission.isGranted(context) -> {
                    emit(null)
                    delay(RECHECK_PERMISSION_MS)
                }
                power?.isInteractive == false -> delay(SCREEN_OFF_POLL_MS)
                else -> {
                    emit(scan())
                    delay(POLL_MS)
                }
            }
        }
    }.distinctUntilChanged().flowOn(Dispatchers.Default)

    /** Reads the app switches since the last look and returns the app that is in front now. */
    @Synchronized
    private fun scan(): String? {
        val manager = usageStats ?: return null
        val now = System.currentTimeMillis()
        val begin = if (cursorMs > 0L) cursorMs else now - FIRST_LOOKBACK_MS
        val events: UsageEvents? = try {
            manager.queryEvents(begin, now)
        } catch (e: Exception) {
            null                    // e.g. the permission was just taken away
        }
        if (events == null) return current

        val event = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            // Only "came to the front" counts. The app that last came to the front IS the app on screen:
            // there is always one (the home screen at least), and ignoring "left the front" avoids a
            // moment of "nothing on screen" in the middle of every switch between two apps.
            if (event.eventType == EVENT_FOREGROUND) current = event.packageName
        }
        // Look again a little before "now": an event written late is then still seen. Reading an
        // event twice does no harm, the last one always wins.
        cursorMs = now - OVERLAP_MS
        return current
    }

    private companion object {
        /** An activity came to the front (ACTIVITY_RESUMED on Android 10+, MOVE_TO_FOREGROUND before). */
        const val EVENT_FOREGROUND = 1
        const val POLL_MS = 700L
        const val SCREEN_OFF_POLL_MS = 3_000L
        const val RECHECK_PERMISSION_MS = 3_000L
        const val OVERLAP_MS = 3_000L
        /** The first look has to find the app that has been in front for a while already. */
        const val FIRST_LOOKBACK_MS = 6L * 60L * 60L * 1_000L
    }
}
