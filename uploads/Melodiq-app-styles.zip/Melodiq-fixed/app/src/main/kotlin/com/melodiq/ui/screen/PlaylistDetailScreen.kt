package com.melodiq.ui.screen

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.melodiq.R
import com.melodiq.data.model.Song
import com.melodiq.ui.components.ButtonStyle
import com.melodiq.ui.components.ConfirmDialog
import com.melodiq.ui.components.EmptyState
import com.melodiq.ui.components.IconActionButton
import com.melodiq.ui.components.MelodiqButton
import com.melodiq.ui.components.PlaylistNameDialog
import com.melodiq.ui.components.SongAction
import com.melodiq.ui.components.SongItem
import com.melodiq.ui.components.SongMenuHost
import com.melodiq.ui.components.SongPickerDialog
import com.melodiq.ui.theme.Divider
import com.melodiq.ui.theme.TextMuted
import com.melodiq.ui.theme.TextPrimary
import com.melodiq.ui.theme.TextSecondary
import com.melodiq.ui.viewmodel.LibraryViewModel
import com.melodiq.ui.viewmodel.PlayerViewModel
import com.melodiq.ui.viewmodel.PlaylistItem
import com.melodiq.ui.viewmodel.PlaylistsViewModel

/** One playlist: play it, shuffle it, add songs, take songs out, rename or delete it. */
@Composable
fun PlaylistDetailScreen(
    playlistId: Long,
    onBack: () -> Unit,
    onNavigateToNowPlaying: () -> Unit,
    playlistsVm: PlaylistsViewModel,
    libraryVm: LibraryViewModel,
    playerVm: PlayerViewModel
) {
    val state by playlistsVm.uiState.collectAsStateWithLifecycle()
    val item = state.items.firstOrNull { it.id == playlistId }
    val gone = state.loaded && item == null

    // The playlist was deleted (from this screen): leave. `gone` turns true only once, so this pops once.
    LaunchedEffect(gone) {
        if (gone) onBack()
    }

    if (item != null) {
        PlaylistDetailContent(
            entry                  = item,
            onBack                 = onBack,
            onNavigateToNowPlaying = onNavigateToNowPlaying,
            playlistsVm            = playlistsVm,
            libraryVm              = libraryVm,
            playerVm               = playerVm
        )
    }
}

@Composable
private fun PlaylistDetailContent(
    entry: PlaylistItem,
    onBack: () -> Unit,
    onNavigateToNowPlaying: () -> Unit,
    playlistsVm: PlaylistsViewModel,
    libraryVm: LibraryViewModel,
    playerVm: PlayerViewModel
) {
    val library by libraryVm.uiState.collectAsStateWithLifecycle()
    val player  by playerVm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val currentId = player.currentSong?.id

    var menuSong by remember { mutableStateOf<Song?>(null) }
    var renaming by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf(false) }
    var picking  by remember { mutableStateOf(false) }

    val hasSongs = entry.songs.isNotEmpty()

    Column(Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 4.dp, end = 4.dp, top = 8.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconActionButton(
                icon               = R.drawable.ic_arrow_back,
                contentDescription = "Back",
                onClick            = onBack,
                tint               = TextPrimary
            )
            Column(
                Modifier
                    .weight(1f)
                    .padding(horizontal = 4.dp)
            ) {
                Text(
                    text     = entry.name,
                    style    = MaterialTheme.typography.titleLarge,
                    color    = TextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text  = entry.countLabel,
                    style = MaterialTheme.typography.labelMedium,
                    color = TextMuted
                )
            }
            IconActionButton(
                icon               = R.drawable.ic_edit,
                contentDescription = "Rename playlist",
                onClick            = { renaming = true },
                tint               = TextSecondary
            )
            IconActionButton(
                icon               = R.drawable.ic_delete,
                contentDescription = "Delete playlist",
                onClick            = { deleting = true },
                tint               = TextSecondary
            )
        }

        LazyColumn(
            modifier       = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 16.dp)
        ) {
            item {
                Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                    Row(
                        modifier              = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        MelodiqButton(
                            text     = "Play",
                            onClick  = {
                                playerVm.playSongs(entry.songs, 0)
                                onNavigateToNowPlaying()
                            },
                            modifier = Modifier.weight(1f),
                            icon     = R.drawable.ic_play,
                            enabled  = hasSongs
                        )
                        MelodiqButton(
                            text     = "Shuffle",
                            onClick  = {
                                playerVm.shuffleAndPlay(entry.songs)
                                onNavigateToNowPlaying()
                            },
                            modifier = Modifier.weight(1f),
                            icon     = R.drawable.ic_shuffle,
                            style    = ButtonStyle.Outlined,
                            enabled  = hasSongs
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    MelodiqButton(
                        text     = "Add songs",
                        onClick  = { picking = true },
                        modifier = Modifier.fillMaxWidth(),
                        icon     = R.drawable.ic_add,
                        style    = ButtonStyle.Tonal
                    )
                }
            }

            if (!hasSongs) {
                item {
                    EmptyState(
                        icon     = R.drawable.ic_playlist,
                        title    = "This playlist is empty",
                        message  = "Tap Add songs, or use the ⋮ menu of any song and choose Add to playlist.",
                        modifier = Modifier.padding(top = 32.dp)
                    )
                }
            }

            itemsIndexed(entry.songs, key = { _, song -> song.id }) { index, song ->
                SongItem(
                    song            = song,
                    isCurrent       = currentId == song.id,
                    isPlaying       = player.isPlaying,
                    onClick         = {
                        playerVm.playSongs(entry.songs, index)
                        onNavigateToNowPlaying()
                    },
                    onFavoriteClick = { playerVm.toggleFavorite(song) },
                    onMoreClick     = { menuSong = song }
                )
                if (index < entry.songs.lastIndex) {
                    HorizontalDivider(
                        modifier  = Modifier.padding(start = 80.dp, end = 16.dp),
                        thickness = 0.5.dp,
                        color     = Divider
                    )
                }
            }
        }
    }

    SongMenuHost(
        song         = menuSong,
        playlistsVm  = playlistsVm,
        onDismiss    = { menuSong = null },
        extraActions = listOf(
            SongAction(
                icon     = R.drawable.ic_remove,
                title    = "Remove from this playlist",
                subtitle = "The song stays on your phone",
                onClick  = { menuSong?.let { playlistsVm.removeSong(entry.id, it.id) } }
            )
        )
    )

    if (picking) {
        val inPlaylist = remember(entry.playlist.songIds) { entry.playlist.songIds.toSet() }
        val candidates = remember(library.allSongs, inPlaylist) {
            library.allSongs.filter { it.id !in inPlaylist }
        }
        SongPickerDialog(
            playlistName = entry.name,
            songs        = candidates,
            onAdd        = { ticked ->
                // added in the order the songs appear in the list, not in the order they were ticked
                val ids = candidates.filter { it.id in ticked }.map { it.id }
                playlistsVm.addSongs(entry.id, ids)
                picking = false
                val message = if (ids.size == 1) "Added 1 song" else "Added " + ids.size + " songs"
                Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
            },
            onDismiss    = { picking = false }
        )
    }

    if (renaming) {
        PlaylistNameDialog(
            title        = "Rename playlist",
            confirmLabel = "Save",
            initialName  = entry.name,
            validate     = { name -> playlistsVm.nameError(name, ignoreId = entry.id) },
            onConfirm    = { name ->
                playlistsVm.rename(entry.id, name)
                renaming = false
            },
            onDismiss    = { renaming = false }
        )
    }

    if (deleting) {
        ConfirmDialog(
            title        = "Delete playlist?",
            message      = "\"" + entry.name + "\" will be deleted. Your songs stay on the phone.",
            confirmLabel = "Delete",
            confirmIcon  = R.drawable.ic_delete,
            // the screen closes by itself once the playlist is gone
            onConfirm    = {
                playlistsVm.delete(entry.id)
                deleting = false
            },
            onDismiss    = { deleting = false }
        )
    }
}
