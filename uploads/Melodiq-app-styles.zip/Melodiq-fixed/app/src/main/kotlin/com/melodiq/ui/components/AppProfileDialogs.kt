package com.melodiq.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.melodiq.R
import com.melodiq.data.model.AppLyricsProfile
import com.melodiq.data.model.FloatingLyricsSettings
import com.melodiq.overlay.InstalledApp
import com.melodiq.ui.theme.AccentViolet
import com.melodiq.ui.theme.PrimaryPurple
import com.melodiq.ui.theme.SurfaceCard
import com.melodiq.ui.theme.SurfaceDark
import com.melodiq.ui.theme.TextMuted
import com.melodiq.ui.theme.TextPrimary
import com.melodiq.ui.theme.TextSecondary

/*
 * The pieces of the "Floating lyrics per app" section of Settings: a row for each app that has its own
 * style, the app picker, the editor of one app's style, and the explanation of "Usage access".
 */

// ── One app in the list ──────────────────────────────────────────────────────

@Composable
fun AppProfileRow(app: AppLyricsProfile, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AppIcon(packageName = app.packageName, size = 40.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text     = app.label,
                color    = TextPrimary,
                style    = MaterialTheme.typography.bodyLarge,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text  = describe(app),
                color = TextSecondary,
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

/** A short line about the style of an app: where the window sits, how many lines, how big the text is. */
private fun describe(app: AppLyricsProfile): String {
    if (!app.visible) return "Hidden in this app"
    val s = app.style
    val lines = if (s.lines == 1) "1 line" else s.lines.toString() + " lines"
    return positionName(s.posX, s.posY) + " \u00B7 " + lines + " \u00B7 " + s.textSizeSp.toInt() + " sp"
}

private fun positionName(x: Float, y: Float): String {
    val vertical = when {
        y < 0.34f -> "Top"
        y < 0.67f -> "Middle"
        else      -> "Bottom"
    }
    val horizontal = when {
        x < 0.34f -> "left"
        x < 0.67f -> "centre"
        else      -> "right"
    }
    return if (vertical == "Middle" && horizontal == "centre") "Centre of the screen" else "$vertical $horizontal"
}

// ── Usage access ─────────────────────────────────────────────────────────────

/** Explains why Melodiq needs "Usage access" before sending the user to the system screen. */
@Composable
fun UsageAccessDialog(
    onDismiss: () -> Unit,
    onOpenSettings: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor   = SurfaceCard,
        icon  = { VectorIcon(id = R.drawable.ic_floating, tint = PrimaryPurple, size = 28.dp) },
        title = { Text("Allow usage access") },
        text  = {
            Text(
                "To give every app its own floating lyrics, Melodiq has to know which app is on screen. " +
                    "It only sees the name of the app in front, never what is inside it. " +
                    "On the next screen, choose Melodiq and switch on \"Allow usage access\", then come back."
            )
        },
        confirmButton = {
            TextButton(onClick = onOpenSettings) { Text("Open settings", color = AccentViolet) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Not now", color = TextSecondary) }
        }
    )
}

// ── Choosing an app ──────────────────────────────────────────────────────────

/** A searchable list of the apps on the phone. [alreadyAdded] are marked, tapping any of them calls [onPick]. */
@Composable
fun AppPickerDialog(
    alreadyAdded: Set<String>,
    loadApps: suspend () -> List<InstalledApp>,
    onPick: (InstalledApp) -> Unit,
    onDismiss: () -> Unit
) {
    val apps by produceState<List<InstalledApp>?>(initialValue = null) { value = loadApps() }
    var query by remember { mutableStateOf("") }

    MelodiqDialog(onDismiss = onDismiss, tall = true) {
        Text(
            text     = "Choose an app",
            color    = TextPrimary,
            style    = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp)
        )
        OutlinedTextField(
            value         = query,
            onValueChange = { query = it },
            singleLine    = true,
            placeholder   = { Text("Search apps", color = TextMuted) },
            colors        = melodiqFieldColors(),
            modifier      = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))

        val all = apps
        if (all == null) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = PrimaryPurple)
            }
        } else {
            val shown = remember(all, query) {
                val needle = query.trim()
                all.filter { it.label.contains(needle, ignoreCase = true) }
            }
            if (shown.isEmpty()) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No app found", color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    items(shown, key = { it.packageName }) { app ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onPick(app) }
                                .padding(horizontal = 8.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AppIcon(packageName = app.packageName, size = 40.dp)
                            Spacer(Modifier.width(14.dp))
                            Text(
                                text     = app.label,
                                color    = TextPrimary,
                                style    = MaterialTheme.typography.bodyLarge,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                            if (app.packageName in alreadyAdded) {
                                Text(
                                    text  = "Has a style",
                                    color = TextMuted,
                                    style = MaterialTheme.typography.labelMedium
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// ── The style of one app ─────────────────────────────────────────────────────

/**
 * Full-screen editor of one app's floating-lyrics style. It offers the same options as the default
 * style ([FloatingStyleControls]) plus the position, and whether the window shows in this app at all.
 * Every change is saved at once.
 */
@Composable
fun AppProfileEditor(
    profile: AppLyricsProfile,
    onVisibleChange: (Boolean) -> Unit,
    onStyleChange: ((FloatingLyricsSettings) -> FloatingLyricsSettings) -> Unit,
    onUseDefault: () -> Unit,
    onRemove: () -> Unit,
    onClose: () -> Unit
) {
    val style = profile.style

    Dialog(
        onDismissRequest = onClose,
        properties       = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = SurfaceDark) {
            Column(Modifier.fillMaxSize()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconActionButton(
                        icon               = R.drawable.ic_arrow_back,
                        contentDescription = "Back",
                        onClick            = onClose,
                        tint               = Color.White,
                        buttonSize         = 48.dp,
                        iconSize           = 24.dp
                    )
                    AppIcon(packageName = profile.packageName, size = 32.dp)
                    Text(
                        text     = profile.label,
                        style    = MaterialTheme.typography.titleLarge,
                        color    = TextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier
                            .padding(start = 12.dp)
                            .weight(1f)
                    )
                }

                Column(
                    Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                        .padding(bottom = 32.dp)
                ) {
                    FloatingPreview(style)

                    SettingsSection("In this app") {
                        SwitchRow(
                            title    = "Show floating lyrics here",
                            subtitle = "Off keeps the window away while this app is open.",
                            checked  = profile.visible,
                            onChange = onVisibleChange
                        )
                        Text(
                            text     = "Tip: drag the window while you are in this app and Melodiq remembers " +
                                "the spot. The position sliders are under Style \u2192 Window.",
                            color    = TextSecondary,
                            style    = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                        )
                    }

                    SettingsSection("Style") {
                        FloatingStyleControls(floating = style, update = onStyleChange)
                    }

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        MelodiqButton(
                            text     = "Use the default style",
                            onClick  = onUseDefault,
                            style    = ButtonStyle.Outlined,
                            modifier = Modifier.fillMaxWidth()
                        )
                        MelodiqButton(
                            text     = "Remove this app",
                            onClick  = onRemove,
                            style    = ButtonStyle.Outlined,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }
    }
}
