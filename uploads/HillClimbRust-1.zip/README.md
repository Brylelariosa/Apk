# Hill Climb Racing Rust

Independent Rust reimplementation of Hill Climb Racing, built to compare performance with the original on the same phone. It installs next to the original (`com.fingersoft.hillclimb`) as **Hill Climb Racing Rust** (`dev.hcrrust.hillclimb`).

**Status: Task 2.1 smoke test. There is no game yet.** The code has never been built or run; PROJECT_STATE.md lists exactly what is and is not verified.

## What the smoke test does
- NativeActivity app (no Java), OpenGL ES 2.0 through EGL, sensor-landscape, arm64-v8a, Android 11+.
- Tap to cycle the overlay: **Stats** (FPS avg / min / 1% low, frame-time percentiles, jitter, CPU work per frame, process CPU, RSS, startup time, frame-interval graph), **GPU/EGL info** (vendor, renderer, limits, extension list), **Off**.

## Layout
| Path | Purpose |
|---|---|
| `crates/hcr-bench` | frame statistics and /proc metrics (pure Rust, unit-tested) |
| `crates/hcr-gfx` | draw list, built-in 5x7 font, GLES2 bindings and uploader (GL part Android-only) |
| `crates/hcr-overlay` | overlay pages (pure Rust, unit-tested) |
| `crates/hcr-platform` | logcat logging, panic hook, EGL (Android-only) |
| `crates/hcr-app` | NativeActivity entry point (`libhcr_app.so`) |
| `android/` | manifest and resources (name, icon, theme) |
| `scripts/build_apk.sh` | aapt2, zipalign and apksigner packaging without Gradle |
| `.github/workflows/build.yml` | CI: host tests, cargo-ndk build, package, sign, upload |
| `docs/` | APK analysis and asset manifest (metadata only) |

## Build (GitHub Actions)
Run the **Build APK** workflow (or push to `main`). The signed APK is the `HillClimbRacingRust-apk` artifact. It needs no Gradle and no secrets.

## Signing
Without secrets the APK is signed with the public DEV key in `signing/` (fine for sideloading; anyone can sign with it). For a private key, add repository secrets `HCR_KEYSTORE_B64` (base64 of a keystore), `HCR_KEYSTORE_PASSWORD`, `HCR_KEY_ALIAS`, `HCR_KEY_PASSWORD`. Changing the key requires uninstalling the previous build first.

## Notes
- No Fingersoft assets are in this repository or APK.
- Frame time is measured between consecutive buffer swaps (what the display sees). "CPU work per frame" is the time before the swap call.
- 1% low = 1 / (mean interval of the slowest 1% of frames). Percentiles use nearest-rank.
