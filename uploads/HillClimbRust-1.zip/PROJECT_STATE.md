# PROJECT_STATE — Hill Climb Racing Rust

Last updated: 2026-11-11
Current stage: **2 — toolchain and smoke test. The Task 2.1 code is written but has NOT been built or run.** Stage 1 (APK analysis) is complete. No game logic exists.

## Goal
Independent Rust reimplementation of Hill Climb Racing, installed next to the untouched original, to measure whether Rust performs better on the same phone with identical visuals and gameplay. No speed claim without measured results.

## Stage tracker
| # | Stage | Status |
|---|-------|--------|
| 1 | Analyze uploaded APK | Done (static analysis only, see docs/ANALYSIS.md) |
| 2 | Understand architecture and functionality | Partial: static structure mapped; runtime behaviour not yet observed |
| 3 | Extract and catalog resources | Done as metadata only (docs/asset_manifest.csv); no asset content copied into the project |
| 4 | Document original graphics and gameplay | Not started (needs on-device observation of the original) |
| 5 | Rust architecture | In progress: 5-crate workspace skeleton written for Task 2.1 |
| 6 | Reimplement game systems | Not started |
| 7 | Recreate visuals | Not started |
| 8 | Performance optimization | Not started |
| 9 | Build separate APK | In progress: packaging script and workflow written, never run |
| 10 | Test and compare | Not started |

## Task 2.1 smoke test: what exists and what is verified
Purpose: prove the toolchain, the side-by-side install and the measurement plumbing before any game code.

| Item | State |
|---|---|
| Workspace: `hcr-bench`, `hcr-gfx`, `hcr-overlay`, `hcr-platform`, `hcr-app` | Written, not built |
| Host unit tests (frame statistics, procfs parsers, font atlas, draw list, text wrap, overlay) | Written, not run (no Rust toolchain where it was authored; the workflow runs them first) |
| Android build (cargo-ndk, arm64-v8a, API 30) | Not attempted |
| APK packaging (aapt2, zipalign, apksigner; no Gradle) | Script written, not run |
| Overlay, EGL/GLES2 context, input, lifecycle on the phone | Not run |
| Local static checks (XML well-formed, YAML/TOML parse, shell syntax, Rust bracket balance) | Passed. They cannot catch compile or API errors |

Known risk: `android-activity` 0.6 calls (`poll_events`, `input_events_iter`, `native_window`) were written from memory of the API and may need small fixes on the first CI run.

## Decisions
| Topic | Status |
|---|---|
| Asset policy | User replied "c and how or a". C (bundle) needs written permission from the rights holder, which is not confirmed. **Working default: A** (read assets at runtime from the installed original; nothing copied into repo or APK). Asset code is not part of Task 2.1 and will sit behind one provider interface, so A to C is a switch |
| Renderer | OpenGL ES 2.0 through EGL with raw bindings (same API as the original; its shaders usable as-is). Implemented in Task 2.1; not confirmed by the user |
| Package ID, name, icon | `dev.hcrrust.hillclimb`, "Hill Climb Racing Rust", independently drawn vector icon. Written; not confirmed by the user |
| Packaging | No Gradle: aapt2 + zipalign + apksigner in `scripts/build_apk.sh`. Signed with a bundled public DEV key unless repo secrets provide one |
| Physics | Proposed: Box2D port, calibrated against the original by observation. Not started |

## Key findings from the APK analysis (details in docs/ANALYSIS.md)
1. Original: Cocos2d-x 2.x C++ (`libgame.so`, arm64) on a Java GLSurfaceView shell; GLES 2.0; OpenSL ES audio; Box2D-style physics (R.U.B.E. JSON vehicle models).
2. 2,399 asset files in standard formats; one unidentified 26 KB high-entropy file (`garage/aaa.dat`), not decoded.
3. Only 7 vehicle models are data-defined. Classic terrain, most vehicle tuning, game rules, camera and UI layout are in stripped native code.
4. Scale: 42 stage folders, 30+ vehicle types, 150 audio files, 68 shaders, 18 languages. A benchmarkable vertical slice comes first.

## Risks
- Exact physics and terrain parity cannot be guaranteed (stripped native code); plan is black-box calibration, not decompilation.
- Out of scope (SDK/server-bound): ads, IAP, Play Games/cloud saves, Firebase, LiveOps, promos, Helpshift, consent.
- No PC: measuring the original needs an on-device shell (wireless debugging) or screen-recording analysis. Not yet verified on the phone.
- The original declares `com.android.graphics.driver.prefer_angle=true`; whether its GL path differs from this app's plain EGL on the phone must be checked.

## Environment
- Device: Infinix Hot 11 2022, Android 11, 4 GB RAM, 1080x2400, no root/Shizuku (GPU model not yet recorded; the smoke test displays it).
- Build: GitHub Actions only (ZIP upload workflow). Target arm64-v8a, Android 11+ (minSdk 30), signed release APK.

## Rules carried from the brief
Preserve the original exactly (no redesign, no placeholders). Reuse only authorized assets. Do not wrap the original code. Do not lower quality to gain FPS. Separate package and data directory; original stays untouched. Never mark a feature complete until it is implemented and tested.
