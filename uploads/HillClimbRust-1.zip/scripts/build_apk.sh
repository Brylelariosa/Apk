#!/usr/bin/env bash
# Packages the native library into a signed, aligned release APK without Gradle:
#   aapt2 (manifest + resources) -> add lib/arm64-v8a/*.so -> zipalign -> apksigner.
#
# Environment (all optional except an Android SDK):
#   ANDROID_HOME / ANDROID_SDK_ROOT   Android SDK location
#   VERSION_CODE                      default 1
#   VERSION_NAME                      default: version from the root Cargo.toml
#   KEYSTORE, KEYSTORE_PASSWORD, KEY_ALIAS, KEY_PASSWORD
#                                     default: signing/hcr-rust-dev.jks (public DEV key)
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
[ -d "$SDK" ] || { echo "error: ANDROID_HOME / ANDROID_SDK_ROOT is not set" >&2; exit 1; }

BT="$(ls -d "$SDK"/build-tools/[0-9]* | sort -V | tail -n 1)"
PLATFORM="$(ls -d "$SDK"/platforms/android-[0-9]* | sort -V | tail -n 1)"
ANDROID_JAR="$PLATFORM/android.jar"
SO="$ROOT/build/jniLibs/arm64-v8a/libhcr_app.so"

VERSION_NAME="${VERSION_NAME:-$(sed -n 's/^version = "\(.*\)"/\1/p' "$ROOT/Cargo.toml" | head -n 1)}"
VERSION_CODE="${VERSION_CODE:-1}"
KEYSTORE="${KEYSTORE:-$ROOT/signing/hcr-rust-dev.jks}"
KEYSTORE_PASSWORD="${KEYSTORE_PASSWORD:-hcrrust-dev}"
KEY_ALIAS="${KEY_ALIAS:-hcr}"
KEY_PASSWORD="${KEY_PASSWORD:-$KEYSTORE_PASSWORD}"

[ -f "$SO" ] || { echo "error: $SO not found (run the cargo-ndk build first)" >&2; exit 1; }
[ -f "$KEYSTORE" ] || { echo "error: keystore $KEYSTORE not found" >&2; exit 1; }
[ -f "$ANDROID_JAR" ] || { echo "error: $ANDROID_JAR not found" >&2; exit 1; }

echo "build-tools : $BT"
echo "platform    : $PLATFORM"
echo "version     : $VERSION_NAME ($VERSION_CODE)"
echo "keystore    : $KEYSTORE"

OUT="$ROOT/dist"
WORK="$ROOT/build/apk"
rm -rf "$OUT" "$WORK"
mkdir -p "$OUT" "$WORK/lib/arm64-v8a"
cp "$SO" "$WORK/lib/arm64-v8a/"

# 1. Compile resources and link them with the manifest.
"$BT/aapt2" compile --dir "$ROOT/android/res" -o "$WORK/res.zip"
"$BT/aapt2" link \
  -o "$WORK/base.apk" \
  -I "$ANDROID_JAR" \
  --manifest "$ROOT/android/AndroidManifest.xml" \
  --min-sdk-version 30 \
  --target-sdk-version 34 \
  --version-code "$VERSION_CODE" \
  --version-name "$VERSION_NAME" \
  "$WORK/res.zip"

# 2. Add the native library stored (uncompressed), then page-align it.
( cd "$WORK" && zip -q -0 -r -D base.apk lib )
"$BT/zipalign" -p -f 4 "$WORK/base.apk" "$WORK/aligned.apk"
"$BT/zipalign" -c -p 4 "$WORK/aligned.apk"

# 3. Sign (v2/v3 only: minSdk is 30) and verify.
APK="$OUT/HillClimbRacingRust-$VERSION_NAME-$VERSION_CODE.apk"
"$BT/apksigner" sign \
  --ks "$KEYSTORE" \
  --ks-pass "pass:$KEYSTORE_PASSWORD" \
  --ks-key-alias "$KEY_ALIAS" \
  --key-pass "pass:$KEY_PASSWORD" \
  --out "$APK" \
  "$WORK/aligned.apk"
"$BT/apksigner" verify --verbose --print-certs "$APK"

echo "---- badging (identity check) ----"
"$BT/aapt2" dump badging "$APK" | grep -E "^(package|sdkVersion|targetSdkVersion|application-label:|native-code|uses-gl-es|launchable-activity)" || true
ls -l "$APK"
