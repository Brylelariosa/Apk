package com.zipapkbuilder.feature.buildlog

import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.zipapkbuilder.MainActivity
import com.zipapkbuilder.R
import com.zipapkbuilder.core.LogText
import com.zipapkbuilder.core.setStartIcon
import com.zipapkbuilder.net.GitHubApi
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

/**
 * In-app viewer for a GitHub Actions run's full log — [fetchAndShowWorkflowLog]
 * is the entry point (lists recent runs), [showLogDialog] renders whichever
 * one gets picked with error/warning highlighting and in-log search. This
 * fetches full logs on demand and holds nothing in memory afterward, unlike
 * [com.zipapkbuilder.feature.build.BuildFlowController]'s live streaming during
 * an active build.
 */
class BuildLogViewer(private val activity: MainActivity) {

    /** Entry point — fetches all runs and shows a picker dialog. */
    fun fetchAndShowWorkflowLog() {
        val token = activity.etToken.text.toString().trim()
        val repo  = activity.etRepo.text.toString().trim()
        if (token.isEmpty()) { activity.appendLog("⚠ Enter your GitHub token first."); return }
        if (repo.isEmpty())  { activity.appendLog("⚠ Enter a repository name first."); return }

        activity.setBusy(true)
        activity.appendLog("Fetching workflow runs from GitHub…")

        activity.bgExecutor.execute {
            try {
                // Resolve owner — use cached value or fetch from token (same pattern as
                // browseAllArtifacts / downloadLatestRunLogs)
                val owner = activity.lastOwner.ifEmpty {
                    (activity.buildFlowController.fetchOwner(token) ?: throw Exception(
                        "Could not verify token — check it has 'repo' scope."
                    )).also {
                        activity.lastOwner = it
                        activity.mainHandler.post { activity.tvOwnerInfo.text = "✓  @$it / $repo"; activity.tvOwnerInfo.visibility = android.view.View.VISIBLE }
                    }
                }

                val allRuns = mutableListOf<JSONObject>()
                // Fetch up to 3 pages × 30 = 90 runs (covers all recent history)
                for (page in 1..3) {
                    val url = "${GitHubApi.apiRuns(owner, repo)}?per_page=30&page=$page"
                    val (code, body) = GitHubApi.httpGet(token, url)
                    if (code != 200) break
                    val arr = JSONObject(body).getJSONArray("workflow_runs")
                    if (arr.length() == 0) break
                    for (i in 0 until arr.length()) allRuns.add(arr.getJSONObject(i))
                    if (arr.length() < 30) break
                }
                if (allRuns.isEmpty()) {
                    activity.appendLog("No workflow runs found in github.com/$owner/$repo")
                    activity.mainHandler.post { activity.setBusy(false) }
                    return@execute
                }
                activity.appendLog("Found ${allRuns.size} run(s) ✓")
                activity.mainHandler.post { activity.setBusy(false); showRunPickerDialog(token, owner, repo, allRuns) }
            } catch (e: Exception) {
                activity.appendLog("✗ ${e.message}")
                activity.mainHandler.post { activity.setBusy(false) }
            }
        }
    }

    /**
     * Shows workflow runs with custom adapter for correct colors, + Trigger button.
     */
    private fun showRunPickerDialog(
        token: String, owner: String, repo: String,
        runs: List<JSONObject>
    ) {
        val dp    = activity.resources.displayMetrics.density
        val fmt   = SimpleDateFormat("MMM d, HH:mm", Locale.US)
        val fmtIn = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
            .apply { timeZone = TimeZone.getTimeZone("UTC") }
        val branch = activity.etBranch.text.toString().trim().ifEmpty { "main" }

        // ── Custom title ──────────────────────────────────────────────────
        val titleRoot = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF1C2038.toInt())
        }
        val topBar = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((16*dp).toInt(), (12*dp).toInt(), (8*dp).toInt(), (8*dp).toInt())
        }
        val titleTv = TextView(activity).apply {
            text = "🔍  $owner / $repo"
            textSize = 14f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(0xFFE8EAED.toInt())
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val countBadge = TextView(activity).apply {
            text = " ${runs.size} runs "
            textSize = 10f
            setTextColor(0xFF00D4AA.toInt())
            setBackgroundColor(0xFF00251F.toInt())
            setPadding((8*dp).toInt(), (3*dp).toInt(), (8*dp).toInt(), (3*dp).toInt())
        }
        topBar.addView(titleTv); topBar.addView(countBadge)
        titleRoot.addView(topBar)

        // ── Status filter chips ────────────────────────────────────────────
        // Declared here (needs runInfos/filteredIndices/adapter, all built below) —
        // filled in and attached after those exist; see the block right after the
        // adapter is defined.
        val filterRow = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding((14*dp).toInt(), 0, (14*dp).toInt(), (8*dp).toInt())
        }
        titleRoot.addView(filterRow)

        titleRoot.addView(android.view.View(activity).apply {
            setBackgroundColor(0xFF232747.toInt())
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1)
        })

        // ── Custom adapter ────────────────────────────────────────────────
        data class RunInfo(val runNum: Long, val name: String, val icon: String,
                           val dateStr: String, val statusStr: String, val conclusion: String)
        val runInfos = runs.map { run ->
            val runNum     = run.optLong("run_number", 0L)
            val name       = run.optString("name", "build")
            val status     = run.optString("status", "")
            val conc       = run.optString("conclusion", "")
            val createdRaw = run.optString("created_at", "")
            val dateStr    = if (createdRaw.isNotEmpty()) {
                try { fmt.format(fmtIn.parse(createdRaw)!!) } catch (_: Exception) { "" }
            } else ""
            val icon = when (conc) {
                "success"   -> "✅"
                "failure"   -> "❌"
                "cancelled" -> "⛔"
                "skipped"   -> "⏭"
                else        -> if (status == "in_progress") "🔄" else "⏳"
            }
            val statusStr = if (conc.isNotEmpty()) conc else status
            RunInfo(runNum, name, icon, dateStr, statusStr, conc)
        }

        var selectedIndex = -1
        // Indices into runInfos/runs that are currently shown — separate from
        // position-in-the-list once the status filter chips (below) can hide some
        // entries, the same reasoning as the File Manager's search filteredItems.
        val filteredIndices = runInfos.indices.toMutableList()
        val listView = android.widget.ListView(activity).apply {
            setBackgroundColor(0xFF13162A.toInt())
            divider = android.graphics.drawable.ColorDrawable(0xFF1C2038.toInt())
            dividerHeight = 1
        }
        val adapter = object : android.widget.BaseAdapter() {
            override fun getCount() = filteredIndices.size
            override fun getItem(pos: Int) = runInfos[filteredIndices[pos]]
            override fun getItemId(pos: Int) = pos.toLong()
            override fun getView(pos: Int, convertView: android.view.View?, parent: android.view.ViewGroup): android.view.View {
                val info = runInfos[filteredIndices[pos]]
                val isSelected = (pos == selectedIndex)
                val bgColor = when {
                    isSelected               -> 0xFF221F4A.toInt()
                    info.conclusion == "failure" -> 0xFF1A0000.toInt()
                    info.conclusion == "success" -> 0xFF001A0D.toInt()
                    else -> 0xFF13162A.toInt()
                }
                val row = LinearLayout(parent.context).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setBackgroundColor(bgColor)
                    setPadding((14*dp).toInt(), (12*dp).toInt(), (12*dp).toInt(), (12*dp).toInt())
                }
                val iconTv = TextView(parent.context).apply {
                    text = info.icon
                    textSize = 18f
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).also { it.marginEnd = (12*dp).toInt() }
                }
                val col = LinearLayout(parent.context).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }
                val runNumTv = TextView(parent.context).apply {
                    text = "Run #${info.runNum}  ·  ${info.name}"
                    textSize = 13f
                    setTextColor(0xFFE8EAED.toInt())
                    setTypeface(null, android.graphics.Typeface.BOLD)
                }
                val metaTv = TextView(parent.context).apply {
                    text = buildString {
                        if (info.dateStr.isNotEmpty()) append(info.dateStr)
                        if (info.statusStr.isNotEmpty()) append("  ·  ${info.statusStr}")
                    }
                    textSize = 10.5f
                    setTextColor(when (info.conclusion) {
                        "success"  -> 0xFF2ECC71.toInt()
                        "failure"  -> 0xFFFF6B6B.toInt()
                        else       -> 0xFF50587A.toInt()
                    })
                }
                col.addView(runNumTv); col.addView(metaTv)
                row.addView(iconTv); row.addView(col)
                return row
            }
        }
        listView.adapter = adapter
        listView.setOnItemClickListener { _, _, pos, _ ->
            selectedIndex = pos
            adapter.notifyDataSetChanged()
        }

        fun applyRunFilter(conclusion: String?) {
            filteredIndices.clear()
            filteredIndices.addAll(
                runInfos.indices.filter { conclusion == null || runInfos[it].conclusion == conclusion }
            )
            selectedIndex = -1 // positions shift under a new filter — no longer meaningful
            adapter.notifyDataSetChanged()
        }
        fun filterChip(label: String, conclusion: String?) = TextView(activity).apply {
            text = label; textSize = 10.5f
            setTextColor(0xFFE8EAED.toInt())
            setBackgroundColor(0xFF2A2D4A.toInt())
            setPadding((10*dp).toInt(), (5*dp).toInt(), (10*dp).toInt(), (5*dp).toInt())
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { it.marginEnd = (6*dp).toInt() }
            setOnClickListener { applyRunFilter(conclusion) }
        }
        filterRow.addView(filterChip("All", null))
        filterRow.addView(filterChip("✅ Success", "success"))
        filterRow.addView(filterChip("❌ Failed", "failure"))

        val root = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF13162A.toInt())
        }
        // titleRoot is passed to setCustomTitle below — do NOT also addView it here
        val maxH = (activity.resources.displayMetrics.heightPixels * 0.58f).toInt()
        root.addView(android.widget.FrameLayout(activity).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, maxH)
            addView(listView)
        })

        val dlg = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
            .setCustomTitle(titleRoot)
            .setView(root)
            .setPositiveButton("View Log") { _, _ ->
                if (selectedIndex < 0) { activity.appendLog("⚠ Tap a run to select it first."); return@setPositiveButton }
                val run    = runs[filteredIndices[selectedIndex]]
                val runId  = run.getLong("id")
                val runNum = run.optLong("run_number", runId)
                activity.setBusy(true)
                activity.appendLog("Fetching log for run #$runNum…")
                activity.bgExecutor.execute { fetchLogForRun(token, owner, repo, runId, runNum) }
            }
            .setNeutralButton("Trigger") { _, _ ->
                activity.buildFlowController.triggerWorkflowDispatch(token, owner, repo, branch)
            }
            .setNegativeButton("Refresh") { _, _ -> fetchAndShowWorkflowLog() }
            .show()

        // Vector icon per button in place of the old emoji prefixes, colored to match
        // the semantic colors used for the same actions elsewhere in the app (Trigger =
        // orange, dismiss/neutral = gray). View Log keeps the theme's default purple.
        val colorPrimary = ContextCompat.getColor(activity, R.color.primary_light)
        val colorOrange  = ContextCompat.getColor(activity, R.color.accent_orange)
        val colorGray    = ContextCompat.getColor(activity, R.color.text_secondary)
        dlg.getButton(AlertDialog.BUTTON_POSITIVE)?.apply {
            setTextColor(colorPrimary)
            setStartIcon(activity, R.drawable.ic_log, colorPrimary, sizeDp = 18)
        }
        dlg.getButton(AlertDialog.BUTTON_NEUTRAL)?.apply {
            setTextColor(colorOrange)
            setStartIcon(activity, R.drawable.ic_flash, colorOrange, sizeDp = 18)
        }
        dlg.getButton(AlertDialog.BUTTON_NEGATIVE)?.apply {
            setTextColor(colorGray)
            setStartIcon(activity, R.drawable.ic_refresh, colorGray, sizeDp = 18)
        }
    }

    /** Fetches the log text for a specific run and shows it in showLogDialog. */
    private fun fetchLogForRun(token: String, owner: String, repo: String, runId: Long, runNum: Long) {
        try {
            val (jobsCode, jobsBody) = GitHubApi.httpGet(token, "${GitHubApi.apiRuns(owner, repo)}/$runId/jobs")
            if (jobsCode != 200) throw Exception("Could not fetch jobs (HTTP $jobsCode)")
            val jobsArr = JSONObject(jobsBody).optJSONArray("jobs")
                ?: throw Exception("No jobs array for run #$runNum")
            if (jobsArr.length() == 0) throw Exception("No jobs found for run #$runNum")

            // Show all jobs in the run, not just the first one
            val allJobLogs = StringBuilder()
            for (ji in 0 until jobsArr.length()) {
                val job   = jobsArr.getJSONObject(ji)
                val jobId = job.getLong("id")
                val jobName = job.optString("name", "job-$ji")
                activity.appendLog("Loading log for job '$jobName'…")

                val conn1 = (URL("https://api.github.com/repos/$owner/$repo/actions/jobs/$jobId/logs")
                    .openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    setRequestProperty("Authorization", "token $token")
                    setRequestProperty("Accept", "application/vnd.github.v3+json")
                    instanceFollowRedirects = false
                    connectTimeout = 30_000; readTimeout = 120_000
                }
                val text: String? = when (val c = conn1.responseCode) {
                    in 301..308 -> {
                        val loc = conn1.getHeaderField("Location"); conn1.disconnect()
                        try {
                            val c2 = (URL(loc).openConnection() as HttpURLConnection).apply {
                                requestMethod = "GET"; connectTimeout = 30_000; readTimeout = 120_000
                            }
                            if (c2.responseCode == 200) c2.inputStream.bufferedReader().readText()
                                .also { c2.disconnect() }
                            else { c2.disconnect(); null }
                        } catch (_: Exception) { null }
                    }
                    200  -> conn1.inputStream.bufferedReader().readText().also { conn1.disconnect() }
                    410  -> { conn1.disconnect(); "⚠ Log expired or unavailable for this run." }
                    else -> { conn1.disconnect(); "⚠ HTTP $c — log not available." }
                }
                if (text != null) {
                    if (jobsArr.length() > 1) {
                        allJobLogs.append("══════ JOB: $jobName ══════\n")
                    }
                    allJobLogs.append(text).append("\n")
                }
            }

            val logText = allJobLogs.toString()
            activity.appendLog("✓ Log: ${logText.length / 1024} KB, ${logText.lines().size} lines")
            activity.mainHandler.post { showLogDialog(logText, runNum) }
        } catch (e: Exception) {
            activity.appendLog("✗ Log error: ${e.message}")
        } finally {
            activity.setBusy(false)
        }
    }

    private fun showLogDialog(logText: String, runId: Long) {
        val lines = logText.lines()
        val allCleaned = lines
            .map(LogText::cleanLine)
            .filter { !LogText.isGroupMarker(it) }

        // Cap display at 1 500 lines to avoid OOM on large logs — full text still
        // available via "Copy All". Show tail (most relevant for build failures).
        val maxLines   = 1_500
        val truncated  = allCleaned.size > maxLines
        val cleaned    = if (truncated) allCleaned.takeLast(maxLines) else allCleaned

        val sizeStr = when {
            logText.length >= 1_048_576 -> "%.1f MB".format(logText.length / 1_048_576.0)
            logText.length >= 1_024     -> "${logText.length / 1024} KB"
            else                        -> "${logText.length} B"
        }

        val header = buildString {
            append("⚙  Run #$runId   •   $sizeStr   •   ${allCleaned.size} lines\n")
            if (truncated) append("⚠  Showing last $maxLines lines — tap Copy All for full log\n")
            append("─────────────────────────────────────\n")
        }

        val errorRx = Regex("""(?i)\b(error|failed|failure|exception)\b|##\[error]""")
        val warnRx  = Regex("""(?i)\bwarning\b|##\[warning]|\bdeprecated\b""")

        // Build display the same way Browse Artifacts does — styled TextView in a dark card,
        // but as a SpannableStringBuilder so error/warning lines and search hits can both be
        // colored — a plain String (the old approach) can't carry spans at all.
        val ctx = activity
        val body = android.text.SpannableStringBuilder()
        body.append(header)
        val lineErrorOffsets = mutableListOf<Int>() // start offset of each error line, for "jump to first error"
        cleaned.forEach { line ->
            val start = body.length
            body.append(line).append("\n")
            val color = when {
                errorRx.containsMatchIn(line) -> 0xFFFF6B6B.toInt().also { lineErrorOffsets.add(start) }
                warnRx.containsMatchIn(line)  -> 0xFFF5A623.toInt()
                else -> null
            }
            if (color != null) {
                body.setSpan(android.text.style.ForegroundColorSpan(color), start, body.length,
                    android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
        }

        val sv  = ScrollView(ctx)
        sv.setBackgroundColor(0xFF0D0D0D.toInt())
        val tv = TextView(ctx).apply {
            setText(body, TextView.BufferType.SPANNABLE)
            textSize = 9.5f
            setTextColor(0xFF00E676.toInt())   // same green as console log — default for uncolored lines
            typeface = android.graphics.Typeface.MONOSPACE
            setPadding(24, 24, 24, 24)
            setLineSpacing(0f, 1.25f)
        }
        sv.addView(tv)
        sv.post { sv.fullScroll(ScrollView.FOCUS_DOWN) }

        // ── Search bar: find in log, next/prev match, jump to first error ──
        val dp = activity.resources.displayMetrics.density
        val searchMatches = mutableListOf<Int>()
        var currentMatch = -1
        var searchSpans: List<Any> = emptyList()

        fun clearSearchHighlights() {
            val editable = tv.text as? android.text.Spannable ?: return
            for (span in searchSpans) editable.removeSpan(span)
            searchSpans = emptyList()
        }
        fun scrollToOffset(offset: Int) {
            val layout = tv.layout ?: return
            val line = layout.getLineForOffset(offset)
            sv.post { sv.scrollTo(0, layout.getLineTop(line)) }
        }
        val tvMatchCount = TextView(ctx).apply {
            text = ""; textSize = 10.5f; setTextColor(0xFF9AA0B8.toInt())
            gravity = Gravity.CENTER_VERTICAL
            setPadding((8*dp).toInt(), 0, (8*dp).toInt(), 0)
        }
        fun runSearch(query: String) {
            clearSearchHighlights()
            searchMatches.clear(); currentMatch = -1
            if (query.isEmpty()) { tvMatchCount.text = ""; return }
            val text = body.toString()
            var idx = text.indexOf(query, 0, ignoreCase = true)
            while (idx >= 0) { searchMatches.add(idx); idx = text.indexOf(query, idx + 1, ignoreCase = true) }
            if (searchMatches.isEmpty()) { tvMatchCount.text = "0/0"; return }
            val editable = tv.text as android.text.Spannable
            searchSpans = searchMatches.map { pos ->
                android.text.style.BackgroundColorSpan(0xFF5A4E1F.toInt()).also {
                    editable.setSpan(it, pos, pos + query.length, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
            }
            currentMatch = 0
            tvMatchCount.text = "1/${searchMatches.size}"
            scrollToOffset(searchMatches[0])
        }
        val etSearch = EditText(ctx).apply {
            hint = "Find in log…"; textSize = 11f; isSingleLine = true
            setTextColor(0xFFE8EAED.toInt()); setHintTextColor(0xFF50587A.toInt())
            setBackgroundColor(0xFF161B22.toInt())
            setPadding((10*dp).toInt(), (6*dp).toInt(), (10*dp).toInt(), (6*dp).toInt())
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: android.text.Editable?) { runSearch(s?.toString() ?: "") }
            })
        }
        fun barButton(label: String, onClick: () -> Unit) = TextView(ctx).apply {
            text = label; textSize = 13f; setTextColor(0xFF9AA0B8.toInt())
            setPadding((10*dp).toInt(), (6*dp).toInt(), (10*dp).toInt(), (6*dp).toInt())
            setOnClickListener { onClick() }
        }
        val searchBar = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(0xFF161B22.toInt())
            addView(etSearch); addView(tvMatchCount)
            addView(barButton("◀") {
                if (searchMatches.isEmpty()) return@barButton
                currentMatch = (currentMatch - 1 + searchMatches.size) % searchMatches.size
                tvMatchCount.text = "${currentMatch + 1}/${searchMatches.size}"
                scrollToOffset(searchMatches[currentMatch])
            })
            addView(barButton("▶") {
                if (searchMatches.isEmpty()) return@barButton
                currentMatch = (currentMatch + 1) % searchMatches.size
                tvMatchCount.text = "${currentMatch + 1}/${searchMatches.size}"
                scrollToOffset(searchMatches[currentMatch])
            })
            addView(barButton("⚠→") {
                if (lineErrorOffsets.isEmpty()) { activity.appendLog("ℹ No error-looking lines found in this log."); return@barButton }
                scrollToOffset(lineErrorOffsets.first())
            })
        }

        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            addView(searchBar)
            addView(sv)
        }

        AlertDialog.Builder(ctx, R.style.Theme_App_Dialog)
            .setTitle("🔍  Build Log — Run #$runId")
            .setView(root)
            .setPositiveButton("📋 Copy All") { _, _ ->
                (activity.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as ClipboardManager)
                    .setPrimaryClip(ClipData.newPlainText("Build Log", logText))
                activity.appendLog("✓ Full log copied ($sizeStr).")
            }
            .setNeutralButton("↙ Tail Console") { _, _ ->
                activity.appendLog("=== Log Run #$runId ===")
                cleaned.takeLast(60).forEach { activity.appendLog(it) }
                activity.appendLog("=== End ===")
            }
            .setNegativeButton("Close", null)
            .show()
    }
}
