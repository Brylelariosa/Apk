package com.mangatool.app.adapter

import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.AsyncListDiffer
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DecodeFormat
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.mangatool.app.AppMode
import com.mangatool.app.AppState
import com.mangatool.app.R
import com.mangatool.app.model.ImageGroup
import com.mangatool.app.model.ImageItem
import com.mangatool.app.util.ImageMerger
import com.mangatool.app.util.ThumbnailWorker
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Outer adapter: one row per ImageGroup. Each row can expand to show a grid of
 * thumbnails (via an inner ImageThumbAdapter) and a filtered-images section.
 *
 * v19 changes:
 *   • Cover thumbnail loading replaced with Glide — no CoroutineScope, no Job,
 *     no AppState.thumbCache. Glide handles cancellation, BitmapPool reuse,
 *     memory + disk caching automatically.
 *   • FilteredThumbAdapter similarly migrated to Glide.
 *   • VH.coverJob field removed — Glide.with(view).clear() in onViewRecycled.
 *   • ChapterAdapter.scope removed — only the inner ImageThumbAdapter/
 *     FilteredThumbAdapter scopes existed; both are now no-ops with Glide.
 */
class ChapterAdapter(
    private val groups: List<ImageGroup>,
    private val onImageClick: (groupIdx: Int, imageIdx: Int) -> Unit,
    private val onGroupRemove: (groupIdx: Int) -> Unit,
    private val onGroupShare: (groupIdx: Int) -> Unit,
    private val onGroupRename: (groupIdx: Int) -> Unit,
    private val onImageLongClick: ((ImageItem) -> Unit)? = null,
    private val onImageRestore: ((ImageItem) -> Unit)? = null,
    private val onFilteredPreview: ((groupIdx: Int, filteredImageIdx: Int) -> Unit)? = null,
    private val onBatchRestore: ((groupIdx: Int) -> Unit)? = null,
    // ── Lazy dims decode hook ─────────────────────────────────────────────────
    // Called the first time a chapter is expanded (and every subsequent expand,
    // but decodeDimsForGroup() is idempotent: it bails immediately if all images
    // already have width > 0). This keeps BitmapFactory.decodeBounds() work
    // strictly on-demand — no library-wide IO burst at the 6-second mark.
    private val onGroupExpand: ((ImageGroup) -> Unit)? = null
) : RecyclerView.Adapter<ChapterAdapter.VH>() {

    // ── Single-expand tracking ────────────────────────────────────────────────
    // ROOT CAUSE OF "3rd-row lag":
    //   expandedMain was a Set — all expanded chapters stayed alive simultaneously.
    //   Each expanded row keeps a live ImageThumbAdapter (~30 active Glide requests),
    //   a GridLayoutManager, and its RecycledViewPool in memory. By the 3rd expand:
    //     • 3 GridLayoutManagers measuring/laying out simultaneously
    //     • ~90 Glide thumbnail requests competing for the decoder thread pool
    //     • 3 × RecycledViewPool holding warm VHs (memory pressure)
    //   On a 2 GB device with slow eMMC, this saturates both RAM and storage bus.
    //
    // FIX: only ONE chapter can be expanded at a time.
    //   On expand: previous chapter is collapsed, its adapter destroyed, Glide
    //   requests cancelled. At most 30 active thumbnail loads at any moment.
    //
    // -1L = "no group expanded" sentinel (same value as RecyclerView.NO_ID).
    private var expandedGroupId         = -1L
    private var expandedFilteredGroupId = -1L

    // Weak reference to the host RecyclerView — used in cleanupAdapterForGroup()
    // to find and immediately update visible VHs without waiting for notifyItemChanged.
    // Set/cleared in onAttachedToRecyclerView / onDetachedFromRecyclerView.
    private var recyclerView: RecyclerView? = null

    // Thumb adapters are created on first expand and destroyed on collapse.
    // With single-expand, at most ONE adapter is alive in this map at any time.
    private val thumbAdapters    = mutableMapOf<Long, ImageThumbAdapter>()
    private val filteredAdapters = mutableMapOf<Long, FilteredThumbAdapter>()
    var touchHelper: ItemTouchHelper? = null

    // Shared RecycledViewPool — ViewHolder inflation cost amortised across all chapter grids.
    // RULE: only pool adapters with the SAME item layout (same ViewHolder class).
    //   sharedThumbPool     → ImageThumbAdapter (item_thumb / item_thumb_merge)
    //   sharedFilteredPool  → FilteredThumbAdapter (item_thumb_filtered)
    // Mixing pools across layout types causes ClassCastException at rebind time.
    private val sharedThumbPool = RecyclerView.RecycledViewPool().also {
        // v30: increased from 24 → 36.
        // Each expanded chapter shows up to 30 thumbnails (3-col grid × 10 rows).
        // With 24, the 3rd expand would exhaust the pool on chapters with >24 images,
        // forcing synchronous VH inflation for the remaining items — visible as a spike
        // in the layout pass. 36 covers a worst-case 30-image chapter with 6 VHs spare
        // for RecyclerView's own prefetch mechanism.
        it.setMaxRecycledViews(0, 36)
    }
    // PERF: Separate pool for filtered grids — all FilteredThumbAdapter instances
    // inflate item_thumb_filtered and can share ViewHolders across chapters.
    // Without this, each chapter's filtered section has its own pool → full
    // ViewHolder inflation cost each time the section is expanded.
    private val sharedFilteredPool = RecyclerView.RecycledViewPool().also {
        it.setMaxRecycledViews(0, 12)
    }

    companion object {
        /**
         * Placeholder shown for chapter covers where thumbnail is not yet available.
         * Dark gray (#2A2A2A) matches the chapter card background.
         * Shown only when thumbnailPath == null AND ThumbnailWorker has no cached path.
         */
        private val COVER_PLACEHOLDER = ColorDrawable(Color.parseColor("#2A2A2A"))
    }

    init { setHasStableIds(true) }
    override fun getItemId(position: Int): Long = groups[position].id

    // ── RecyclerView lifecycle ─────────────────────────────────────────────────
    override fun onAttachedToRecyclerView(rv: RecyclerView) {
        super.onAttachedToRecyclerView(rv); recyclerView = rv
    }
    override fun onDetachedFromRecyclerView(rv: RecyclerView) {
        super.onDetachedFromRecyclerView(rv); recyclerView = null
    }

    /**
     * Collapse a group and immediately release all associated resources.
     *
     * Called BEFORE expanding a new row and on explicit collapse.
     *
     * Three-phase cleanup:
     *   1. Destroy the ImageThumbAdapter — cancels all 30 in-flight Glide decode
     *      requests for that chapter's thumbnails immediately, not when the GC runs.
     *   2. If the VH for this group is currently visible, null its grid adapter
     *      synchronously — RecyclerView calls onViewRecycled() on every thumbnail
     *      VH, which calls Glide.clear(imageView) on each one. This frees ~1–3 MB
     *      of decoded bitmap memory before the new chapter's thumbnails start loading.
     *   3. notifyItemChanged() for the collapsed position so RecyclerView's
     *      item-view cache is invalidated — prevents a stale VH (with an old
     *      adapter reference) from bypassing onBindViewHolder on scroll-back.
     *
     * Timing:
     *   Called on the Main thread synchronously before the new expand attaches its
     *   adapter. The storage bus is clear for the new chapter's thumbnail reads.
     */
    private fun cleanupAdapterForGroup(groupId: Long) {
        // Phase 1: destroy the adapter (cancels Glide requests via destroy → glide=null)
        thumbAdapters.remove(groupId)?.destroy()

        // Also destroy filtered adapter if it was open for this group
        if (expandedFilteredGroupId == groupId) {
            filteredAdapters.remove(groupId)?.destroy()
            expandedFilteredGroupId = -1L
        }

        // Phase 2: if the VH is currently on screen, null its adapter immediately.
        // findViewHolderForItemId works because setHasStableIds(true) is set.
        // If the VH is off-screen (recycled), this is a no-op — onBindViewHolder
        // will handle cleanup when the item comes back into view.
        (recyclerView?.findViewHolderForItemId(groupId) as? VH)?.let { vh ->
            // Null the adapter: RecyclerView calls onViewRecycled for all child VHs,
            // each of which calls Glide.clear(image). Decoded bitmaps return to
            // Glide's BitmapPool immediately instead of lingering until GC.
            vh.grid.adapter = null
            vh.grid.recycledViewPool.clear()  // free warm VHs from the pool too
            vh.grid.visibility = View.GONE
            vh.arrow.text = "▼"
            vh.accentBar.visibility = View.GONE
            // Clean up the filtered grid in the same VH if open
            if (expandedFilteredGroupId == groupId) {
                vh.filteredGrid.adapter = null
                vh.filteredGrid.recycledViewPool.clear()
                vh.filteredGrid.visibility = View.GONE
                vh.filteredArrow.text = "▼"
            }
        }
    }

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val cover:           ImageView   = v.findViewById(R.id.chapter_cover)
        val numBadge:        TextView    = v.findViewById(R.id.chapter_num_badge)
        val name:            TextView    = v.findViewById(R.id.chapter_name)
        val count:           TextView    = v.findViewById(R.id.chapter_count)
        val filteredCount:   TextView    = v.findViewById(R.id.filtered_count)
        val arrow:           TextView    = v.findViewById(R.id.chapter_arrow)
        val removeBtn:       ImageButton = v.findViewById(R.id.chapter_remove)
        val renameBtn:       ImageButton = v.findViewById(R.id.chapter_rename)
        val shareBtn:        View        = v.findViewById(R.id.chapter_share)
        val dragHandle:      TextView    = v.findViewById(R.id.drag_handle)
        val header:          View        = v.findViewById(R.id.chapter_header)
        val grid:            RecyclerView= v.findViewById(R.id.chapter_grid)
        val filteredSection: View        = v.findViewById(R.id.filtered_section)
        val filteredHeader:  View        = v.findViewById(R.id.filtered_header)
        val filteredLabel:   TextView    = v.findViewById(R.id.filtered_section_label)
        val filteredArrow:   TextView    = v.findViewById(R.id.filtered_arrow)
        val filteredGrid:    RecyclerView= v.findViewById(R.id.filtered_grid)
        val btnRestoreAll:   Button      = v.findViewById(R.id.btn_restore_all)
        // v30: left accent bar — shown when this chapter is expanded
        val accentBar:       View        = v.findViewById(R.id.chapter_accent_bar)
        // No coverJob — Glide.with(view).clear(cover) in onViewRecycled instead
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_chapter, parent, false)
        val holder = VH(v)

        // ── PERF: All click/touch listeners registered ONCE at creation ────────
        //
        // BEFORE (original): Every onBindViewHolder call registered 6–8 new lambda
        // objects per VH — one for each setOnClickListener / setOnTouchListener.
        // For 50 groups: 300–400 new lambda allocations per adapter update().
        // These ~250 KB of short-lived objects trigger a minor GC at the exact
        // moment the post-extraction layout pass needs the frame budget: causing
        // the brief stutter visible right as the chapter list appears.
        //
        // AFTER: Zero listener allocations in onBindViewHolder.
        // Each lambda is created once per VH (≈ 8 total for the full list).
        //
        // bindingAdapterPosition is always fresh at interaction time — same safe
        // pattern already used by ImageThumbAdapter.onCreateViewHolder.

        holder.dragHandle.setOnTouchListener { _, event ->
            // Read mode at touch time (not bind time) — applyMode() can change it between binds.
            if (event.actionMasked == MotionEvent.ACTION_DOWN &&
                AppState.currentMode != AppMode.MERGE) {
                val pos = holder.bindingAdapterPosition
                if (pos != RecyclerView.NO_ID.toInt()) touchHelper?.startDrag(holder)
            }
            false
        }

        holder.removeBtn.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_ID.toInt()) onGroupRemove(pos)
        }

        holder.renameBtn.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_ID.toInt()) onGroupRename(pos)
        }

        holder.shareBtn.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_ID.toInt()) onGroupShare(pos)
        }

        holder.name.setOnLongClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_ID.toInt()) onGroupRename(pos)
            true
        }

        holder.header.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos == RecyclerView.NO_ID.toInt()) return@setOnClickListener
            val grp = groups[pos]

            if (grp.id == expandedGroupId) {
                // ── Collapsing the currently expanded row ─────────────────────
                expandedGroupId = -1L
                cleanupAdapterForGroup(grp.id)
                holder.accentBar.visibility = View.GONE
                // notifyItemChanged so the view-cache knows this item's state changed.
                // Without this, a VH in the item-view cache (setItemViewCacheSize range)
                // would skip onBindViewHolder on scroll-back, showing a stale grid.
                notifyItemChanged(pos)
            } else {
                // ── Expanding a new row ──────────────────────────────────────
                // Step 1: collapse and release the previously expanded row.
                // This is the key change: previously the Set allowed unlimited
                // simultaneous expanded rows. Now we enforce max-1.
                val prevId  = expandedGroupId
                val prevPos = if (prevId != -1L) groups.indexOfFirst { it.id == prevId } else -1
                if (prevId != -1L) {
                    cleanupAdapterForGroup(prevId)
                    if (prevPos >= 0) notifyItemChanged(prevPos)
                }

                // Step 2: expand this row.
                expandedGroupId = grp.id
                // Trigger lazy dims decode for this group only. The callback is
                // idempotent — if dims are already decoded it returns in O(N) with
                // zero IO. Safe to call before attachMainGrid() since the decode
                // runs on decodeDispatcher and posts back to Main only when done.
                onGroupExpand?.invoke(grp)
                attachMainGrid(holder, pos, grp)
                holder.grid.visibility = View.VISIBLE
                holder.arrow.text = "▲"
                holder.accentBar.visibility = View.VISIBLE
                // v30: notifyItemChanged(pos) REMOVED here.
                //
                // Previously this was called after direct VH manipulation, but
                // the VH is guaranteed on-screen (user just tapped it), so it
                // is NOT in the item-view cache. The notifyItemChanged scheduled
                // a second full onBindViewHolder → second attachMainGrid → second
                // inner grid layout measurement (30 child binds). On the 3rd expand
                // the sharedThumbPool is partially depleted, so those 30 binds
                // required fresh VH inflation — visible as a frame-drop spike.
                //
                // Without notifyItemChanged: the direct VH changes are immediately
                // visible. When the item scrolls off and returns via the view cache,
                // RecyclerView re-runs onBindViewHolder which handles the state.
                // When evicted to the recycled pool, onBindViewHolder also handles it.
            }
        }

        holder.filteredHeader.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos == RecyclerView.NO_ID.toInt()) return@setOnClickListener
            val grp = groups[pos]
            if (grp.id == expandedFilteredGroupId) {
                // Collapse filtered section — destroy adapter and clear pool
                expandedFilteredGroupId = -1L
                filteredAdapters.remove(grp.id)?.destroy()
                holder.filteredGrid.adapter = null
                holder.filteredGrid.recycledViewPool.clear()
                holder.filteredGrid.visibility = View.GONE
            } else {
                expandedFilteredGroupId = grp.id
                attachFilteredGrid(holder, pos, grp)
                holder.filteredGrid.visibility = View.VISIBLE
            }
            holder.filteredArrow.text = if (grp.id == expandedFilteredGroupId) "▲" else "▼"
        }

        holder.btnRestoreAll.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_ID.toInt()) onBatchRestore?.invoke(pos)
        }

        return holder
    }

    override fun getItemCount() = groups.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val group   = groups[position]
        val isMerge = AppState.currentMode == AppMode.MERGE
        // Single-expand: at most one group ID matches expandedGroupId at any time.
        val isExpanded = group.id == expandedGroupId

        // ── Number badge ──────────────────────────────────────────────────────
        holder.numBadge.text = "${position + 1}"

        // ── Cover thumbnail via Glide ─────────────────────────────────────────
        // v29: full-image fallback REMOVED.
        //
        // Previous behavior when thumbnailPath == null:
        //   Glide.load(File(coverImg.filePath)) → decoded 200–500 KB JPEG
        //   → visible jank on first scroll past chapters with no pre-generated thumbnail.
        //
        // New behavior:
        //   Primary path (thumbnailPath != null OR ThumbnailWorker cache hit) → Glide
        //   loads the pre-built 3–6 KB WebP; RGB_565 halves bitmap memory (~39 KB).
        //   Fallback path (no thumbnail yet) → ColorDrawable placeholder + queue
        //   background generation; notifyItemChanged when ready.
        val coverImg = group.displayImages.firstOrNull()
        if (coverImg != null) {
            val effectivePath = coverImg.thumbnailPath ?: ThumbnailWorker.getCached(coverImg.filePath)
            if (effectivePath != null) {
                Glide.with(holder.itemView)
                    .load(File(effectivePath))
                    .override(140)
                    .format(DecodeFormat.PREFER_RGB_565)
                    .dontAnimate()
                    .diskCacheStrategy(DiskCacheStrategy.NONE)
                    .skipMemoryCache(false)
                    .into(holder.cover)
            } else {
                // No thumbnail available — placeholder + background generation.
                // The full original image is NOT loaded here.
                Glide.with(holder.itemView).clear(holder.cover)
                holder.cover.setImageDrawable(COVER_PLACEHOLDER)
                val coverFilePath = coverImg.filePath
                val groupId = group.id
                ThumbnailWorker.generate(coverFilePath) { _ ->
                    val pos = groups.indexOfFirst { it.id == groupId }
                    if (pos >= 0) notifyItemChanged(pos)
                }
            }
        } else {
            Glide.with(holder.itemView).clear(holder.cover)
        }

        // ── Name + count ──────────────────────────────────────────────────────
        holder.name.text = group.groupName

        if (isMerge) {
            val pairs = (group.displayImages.size + 1) / 2
            holder.count.text = "${group.displayImages.size} images · $pairs pairs"
            holder.dragHandle.visibility = View.GONE
            holder.filteredCount.visibility = View.GONE
            holder.filteredSection.visibility = View.GONE
            holder.removeBtn.visibility = if (groups.size > 1) View.VISIBLE else View.GONE
        } else {
            holder.dragHandle.visibility = View.VISIBLE
            holder.removeBtn.visibility  = View.VISIBLE
            holder.count.text = "${group.displayImages.size} images"
            val fCount = group.filteredImages.size
            holder.filteredCount.visibility = if (fCount > 0) View.VISIBLE else View.GONE
            if (fCount > 0) holder.filteredCount.text = "⚠ $fCount filtered"
        }

        holder.arrow.text = if (isExpanded) "▲" else "▼"
        // v30: accent bar visible when expanded
        holder.accentBar.visibility = if (isExpanded) View.VISIBLE else View.GONE

        // ── Drag handle — listener set in onCreateViewHolder; no setup here ────
        // ── Per-chapter actions — listeners set in onCreateViewHolder ──────────

        // ── Expand / collapse ─────────────────────────────────────────────────
        // Listener set in onCreateViewHolder. Only expand state applied here.
        if (isExpanded) {
            attachMainGrid(holder, position, group)
            holder.grid.visibility = View.VISIBLE
        } else {
            if (holder.grid.adapter !== thumbAdapters[group.id]) {
                holder.grid.adapter = null
            }
            holder.grid.visibility = View.GONE
        }

        // ── Filtered section ──────────────────────────────────────────────────
        if (!isMerge && group.filteredImages.isNotEmpty()) {
            holder.filteredSection.visibility = View.VISIBLE
            holder.filteredLabel.text = "${group.filteredImages.size} filtered — tap to review"
            holder.filteredArrow.text = if (group.id == expandedFilteredGroupId) "▲" else "▼"
            // Listeners (filteredHeader, btnRestoreAll) set in onCreateViewHolder.
            if (group.id == expandedFilteredGroupId) {
                attachFilteredGrid(holder, position, group)
                holder.filteredGrid.visibility = View.VISIBLE
            } else {
                holder.filteredGrid.visibility = View.GONE
            }
        } else {
            holder.filteredSection.visibility = View.GONE
        }

        // ── v29: Prefetch thumbnails for this chapter's images ─────────────────
        // When a chapter row is bound (about to scroll into view), queue background
        // thumbnail generation for any images in this chapter that still lack
        // thumbnailPath. For MHTML-extracted chapters this is typically a no-op
        // (all thumbs generated during parse). Covers edge cases: failed generation,
        // picker imports. Bounded by ThumbnailWorker.Semaphore(3) — safe to call
        // on every bind; generate() deduplicates and short-circuits on cached items.
        if (!isMerge) {
            val missingPaths = group.displayImages
                .filter { it.thumbnailPath == null && ThumbnailWorker.getCached(it.filePath) == null }
                .map { it.filePath }
            if (missingPaths.isNotEmpty()) {
                ThumbnailWorker.prefetch(missingPaths, 0, missingPaths.size)
            }
        }
    }

    private fun attachMainGrid(holder: VH, position: Int, group: ImageGroup) {
        val isMerge = AppState.currentMode == AppMode.MERGE
        val items: List<Any> = if (isMerge) ImageMerger.pairImages(group.displayImages) else group.displayImages
        val cols = if (isMerge) 2 else 3
        val groupId = group.id

        val adapter = thumbAdapters.getOrPut(group.id) {
            // ── PERF: onItemClick captured ONCE at adapter creation ─────────────
            // BEFORE: adapter.onItemClick was reassigned AFTER getOrPut() on every
            // attachMainGrid() call — allocating a new lambda every onBindViewHolder
            // for each expanded chapter. For 50 expanded chapters that is 50 new
            // lambda objects per update() pass, adding ~25 KB of short-lived heap.
            //
            // AFTER: onItemClick is captured inside the getOrPut block, which runs
            // only when the adapter is first created. Subsequent attachMainGrid()
            // calls return the cached adapter without any allocation.
            // groupId is captured at adapter-creation time; groups.indexOfFirst()
            // at click-time resolves the correct position after any drag-reorder.
            ImageThumbAdapter(
                items, isMerge,
                group           = if (isMerge) group else null,
                groupIdx        = position,
                onItemClick     = { idx ->
                    val currentPos = groups.indexOfFirst { it.id == groupId }
                    if (currentPos != -1) onImageClick(currentPos, idx)
                },
                onItemLongClick = onImageLongClick,
                onSwapChanged   = null
            )
        }
        // NOTE: adapter.onItemClick NOT reassigned here — zero lambda allocation.

        if (holder.grid.layoutManager == null) {
            holder.grid.layoutManager = GridLayoutManager(holder.grid.context, cols).apply {
                // v30: increased from cols*2 (=6) to cols*3 (=9).
                // cols*2 pre-bound only the first row. cols*3 covers 1.5 rows so
                // RecyclerView can start showing content immediately without a
                // visible blank frame. Pre-binding runs on GapWorker — off Main.
                initialPrefetchItemCount = cols * 3
            }
            holder.grid.overScrollMode = View.OVER_SCROLL_NEVER
            // Null animator: eliminates 30 simultaneous ValueAnimator fade-ins on expand.
            holder.grid.itemAnimator = null
            // v28: disable nested scrolling on the inner grid.
            // By default, RecyclerView propagates unconsumed scroll events up the view
            // hierarchy via NestedScrollingChild. The inner grid never scrolls (it uses
            // wrap_content height to show all thumbnails), so every scroll event is
            // unconsumed and propagated to the outer list. Disabling this removes the
            // NestedScrolling dispatch overhead (a synchronized Dispatcher call per
            // scroll event) from the inner grids.
            holder.grid.isNestedScrollingEnabled = false
            // NOTE: setHasFixedSize(true) intentionally omitted — inner grids use
            // wrap_content height. setHasFixedSize requires a fixed size in the scroll
            // direction; using it with wrap_content causes layout measurement errors.
        }
        holder.grid.setRecycledViewPool(sharedThumbPool)
        // v28: reduced from 12 to 6.
        // Item view cache stores recently detached VHs to avoid re-binding on short
        // scroll reversals. The inner grid is not scrollable (all items visible at once),
        // so a cache > 0 is only useful for RecyclerView's internal prefetch. Keeping 6
        // (instead of 12) halves the warm-VH memory held by the inner grid while still
        // giving the prefetch mechanism enough headroom for one row of anticipation.
        holder.grid.setItemViewCacheSize(6)
        if (holder.grid.adapter !== adapter) {
            holder.grid.adapter = adapter
        }
    }

    private fun attachFilteredGrid(holder: VH, position: Int, group: ImageGroup) {
        val groupId = group.id
        val adapter = filteredAdapters.getOrPut(group.id) {
            // ── PERF: onPreview captured ONCE at adapter creation ──────────────
            // Same pattern as attachMainGrid — prevents lambda re-allocation on
            // every onBindViewHolder for expanded filtered sections.
            FilteredThumbAdapter(
                initialItems = group.filteredImages,
                groupIdx  = position,
                onPreview = { filtIdx ->
                    val currentPos = groups.indexOfFirst { it.id == groupId }
                    if (currentPos != -1) onFilteredPreview?.invoke(currentPos, filtIdx)
                },
                onRestore = { img -> img.forceKeep = true; img.userDeleted = false; onImageRestore?.invoke(img) }
            )
        }
        // NOTE: adapter.onPreview NOT reassigned here — zero lambda allocation.

        if (holder.filteredGrid.layoutManager == null) {
            holder.filteredGrid.layoutManager = GridLayoutManager(holder.filteredGrid.context, 3).apply {
                // v28: reduced from 9 to 4 (roughly one visible row of prefetch instead of 3).
                initialPrefetchItemCount = 4
            }
            holder.filteredGrid.overScrollMode = View.OVER_SCROLL_NEVER
            holder.filteredGrid.itemAnimator = null
            holder.filteredGrid.isNestedScrollingEnabled = false
            // setHasFixedSize omitted — filtered grid also uses wrap_content height.
        }
        // ── PERF: Share filtered ViewHolder pool across all chapters ───────────
        // BEFORE: each chapter's filteredGrid used its own isolated RecycledViewPool
        // (RecyclerView default). When a filtered section collapsed and re-expanded,
        // its ViewHolder pool was already cleared (filteredAdapters.remove() in
        // filteredHeader click), forcing full VH inflation on every expand.
        //
        // AFTER: all FilteredThumbAdapter instances share sharedFilteredPool.
        // A VH recycled when chapter A's filtered section collapses is reused when
        // chapter B's section expands — saves the inflate + findViewById cost.
        holder.filteredGrid.setRecycledViewPool(sharedFilteredPool)
        // v28: reduced from 8 to 4 — filtered section typically shows 3–6 items.
        holder.filteredGrid.setItemViewCacheSize(4)
        if (holder.filteredGrid.adapter !== adapter) {
            holder.filteredGrid.adapter = adapter
        }
    }

    private data class GroupSnapshot(val id: Long, val name: String, val displaySize: Int, val filteredSize: Int, val coverPath: String?)
    private var prevSnapshot: List<GroupSnapshot> = emptyList()

    fun destroyGroupAdapters(groupId: Long) {
        thumbAdapters.remove(groupId)?.destroy()
        filteredAdapters.remove(groupId)?.destroy()
        // Clear the expand sentinels if the removed group was the one expanded.
        // Without this, expandedGroupId would point to a now-deleted group ID,
        // causing onBindViewHolder to incorrectly expand the next group that
        // happens to reuse the same position (possible after drag-reorder).
        if (expandedGroupId == groupId)         expandedGroupId         = -1L
        if (expandedFilteredGroupId == groupId) expandedFilteredGroupId = -1L
    }

    suspend fun update() {
        val newGroups = AppState.groups
        val isMerge = AppState.currentMode == AppMode.MERGE
        newGroups.forEach { group ->
            thumbAdapters[group.id]?.let { adapter ->
                val newItems: List<Any> = if (isMerge)
                    ImageMerger.pairImages(group.displayImages)
                else
                    group.displayImages
                adapter.refreshItems(newItems)
            }
            filteredAdapters[group.id]?.refreshItems(group.filteredImages)
        }

        val newSnapshot = newGroups.map {
            GroupSnapshot(it.id, it.groupName, it.displayImages.size, it.filteredImages.size, it.displayImages.firstOrNull()?.filePath)
        }
        val oldSnapshot = prevSnapshot
        prevSnapshot = newSnapshot

        // ── DiffUtil off the Main thread ───────────────────────────────────
        // DiffUtil.calculateDiff() is O(N + D²) where D is the edit distance.
        // For 50–100 groups this is fast (~1 ms) BUT it runs synchronously on
        // whatever thread calls update(). update() was always called from Main,
        // so the diff blocked the Main thread for 1–5 ms at the exact moment the
        // RecyclerView was starting its post-extraction layout pass.
        //
        // withContext(Default) offloads the diff computation to the CPU pool.
        // dispatchUpdatesTo() is then called back on Main (the coroutine resumes
        // here because update() is a suspend fun called from a Main-thread coroutine
        // in refreshChapterList()). The net result: Main is free for layout during
        // the diff, and the adapter patch arrives one frame later — imperceptible.
        val diff = withContext(Dispatchers.Default) {
            DiffUtil.calculateDiff(object : DiffUtil.Callback() {
                override fun getOldListSize() = oldSnapshot.size
                override fun getNewListSize() = newSnapshot.size
                override fun areItemsTheSame(o: Int, n: Int) = oldSnapshot[o].id == newSnapshot[n].id
                override fun areContentsTheSame(o: Int, n: Int) = oldSnapshot[o] == newSnapshot[n]
            })
        }
        diff.dispatchUpdatesTo(this)
    }

    fun notifyImageDimsChanged(groupIdx: Int, displayIdx: Int) {
        val id = groups.getOrNull(groupIdx)?.id ?: return
        thumbAdapters[id]?.notifyItemChanged(displayIdx, ImageThumbAdapter.PAYLOAD_DIMS)
    }

    /**
     * Push an updated displayImages list into the inner ImageThumbAdapter for
     * the given group via AsyncListDiffer.submitList().
     *
     * This is the correct way to surface dimension changes.  The old
     * notifyImageDimsChanged() called notifyItemChanged(pos, PAYLOAD_DIMS) but
     * the differ's currentList was never refreshed, so onBindViewHolder always
     * read width=0 and the badge never appeared.
     *
     * submitList() diffs old vs new on a background thread and fires only the
     * targeted notifyItemChanged calls for items whose data actually changed.
     * The PAYLOAD_DIMS partial-bind path then runs correctly because
     * differ.currentList now contains the updated ImageItem with non-zero dims.
     */
    fun refreshGroupDisplayImages(group: com.mangatool.app.model.ImageGroup) {
        thumbAdapters[group.id]?.refreshItems(group.displayImages)
    }

    fun destroy() {
        // No adapter-level scope to cancel — Glide manages request lifecycle.
        thumbAdapters.values.forEach { it.destroy() }; thumbAdapters.clear()
        filteredAdapters.values.forEach { it.destroy() }; filteredAdapters.clear()
        expandedGroupId = -1L
        expandedFilteredGroupId = -1L
        recyclerView = null
    }

    override fun onViewRecycled(holder: VH) {
        // Cancel any in-flight Glide request for the cover ImageView and return
        // the Bitmap to Glide's BitmapPool rather than letting it linger in the
        // VH until the next bind overwrites it.
        Glide.with(holder.itemView).clear(holder.cover)
        super.onViewRecycled(holder)
    }
}

// ── Filtered thumbnail adapter ─────────────────────────────────────────────────
class FilteredThumbAdapter(
    initialItems: List<ImageItem>,
    private val groupIdx: Int = 0,
    // PERF: val — set once at adapter creation in attachFilteredGrid, never reassigned.
    val onPreview: (Int) -> Unit,
    private val onRestore: (ImageItem) -> Unit
) : RecyclerView.Adapter<FilteredThumbAdapter.VH>() {

    companion object {
        // Filtered images are stable by originalIdx; content changes when filterReason
        // or filePath changes (edge case: restore-then-re-filter).
        val ITEM_CALLBACK = object : DiffUtil.ItemCallback<ImageItem>() {
            override fun areItemsTheSame(o: ImageItem, n: ImageItem) =
                o.originalIdx == n.originalIdx
            override fun areContentsTheSame(o: ImageItem, n: ImageItem) =
                o.filePath == n.filePath && o.filterReason == n.filterReason
        }

        /** Placeholder for filtered items while thumbnail generates. Matches COVER_PLACEHOLDER. */
        private val FILTERED_PLACEHOLDER = ColorDrawable(Color.parseColor("#2A2A2A"))
    }

    private val differ = AsyncListDiffer(this, ITEM_CALLBACK)
    private val items: List<ImageItem> get() = differ.currentList

    init {
        // Stable IDs let RecyclerView skip full rebind when only unrelated data
        // changes — same benefit as in ImageThumbAdapter. Uses originalIdx (assigned
        // once at parse time) as the stable ID, which is unique within each group.
        setHasStableIds(true)
        differ.submitList(initialItems)
    }

    override fun getItemId(position: Int): Long =
        items.getOrNull(position)?.originalIdx?.toLong() ?: position.toLong()

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val image:   ImageView = v.findViewById(R.id.thumb_image)
        val reason:  TextView  = v.findViewById(R.id.reason_text)
        val preview: View      = v.findViewById(R.id.btn_preview)
        val restore: View      = v.findViewById(R.id.btn_restore)
        // No Job — Glide manages lifecycle
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_thumb_filtered, parent, false)
        val holder = VH(v)

        // ── PERF: Click listeners registered ONCE at VH creation ──────────────
        // BEFORE (v26): onBindViewHolder registered 3 new lambdas (itemView,
        // preview, restore) on EVERY bind — allocating ~3 objects × N filtered
        // items × M filter passes. For a library with 5 chapters × 8 filtered
        // images × 3 filter changes = 120 lambda allocations in one interaction,
        // adding GC pressure at the moment the adapter is refreshing.
        //
        // AFTER (v27): zero allocations in onBindViewHolder. The restore listener
        // reads items[bindingAdapterPosition] at click time — safe because
        // bindingAdapterPosition always reflects the current differ state.
        holder.itemView.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_ID.toInt()) onPreview(pos)
        }
        holder.preview.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_ID.toInt()) onPreview(pos)
        }
        holder.restore.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_ID.toInt()) onRestore(items[pos])
        }

        return holder
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val img = items[position]
        holder.reason.text = img.filterReason ?: "Filtered"

        // v29: full-image fallback REMOVED (same fix as ImageThumbAdapter + ChapterAdapter cover).
        // Primary: thumbnailPath or ThumbnailWorker cache → Glide loads pre-built WebP.
        // Fallback: placeholder + background generation; notifyItemChanged when ready.
        val effectivePath = img.thumbnailPath ?: ThumbnailWorker.getCached(img.filePath)
        if (effectivePath != null) {
            Glide.with(holder.itemView)
                .load(File(effectivePath))
                .override(140)
                .format(DecodeFormat.PREFER_RGB_565)
                .dontAnimate()
                .diskCacheStrategy(DiskCacheStrategy.NONE)
                .skipMemoryCache(false)
                .into(holder.image)
        } else {
            // Placeholder — the full original image is NOT loaded here.
            Glide.with(holder.itemView).clear(holder.image)
            holder.image.setImageDrawable(FILTERED_PLACEHOLDER)
            val filePath = img.filePath
            val originalIdx = img.originalIdx
            ThumbnailWorker.generate(filePath) { _ ->
                val pos = items.indexOfFirst { it.originalIdx == originalIdx }
                if (pos >= 0) notifyItemChanged(pos)
            }
        }
        // Click listeners registered once in onCreateViewHolder — no allocations here.
    }

    /**
     * Submit updated filtered list to AsyncListDiffer.
     * Only items whose filterReason or filePath changed will rebind —
     * a restore action on item N no longer forces all other filtered
     * thumbnails to re-issue their Glide requests.
     */
    fun refreshItems(newItems: List<ImageItem>) = differ.submitList(newItems)

    override fun onViewRecycled(holder: VH) {
        Glide.with(holder.itemView).clear(holder.image)
        super.onViewRecycled(holder)
    }

    /** No-op: Glide manages request lifecycle. */
    fun destroy() = Unit
}
