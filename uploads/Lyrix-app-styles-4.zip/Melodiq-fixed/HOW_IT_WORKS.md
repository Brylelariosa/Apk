# How Lyrix works

## 1. Finding your songs
1. On first launch Lyrix asks for permission to read audio files
   (`READ_MEDIA_AUDIO` on Android 13+, `READ_EXTERNAL_STORAGE` on older versions).
   If you deny it, a screen with **Allow access** and **Open app settings** buttons is shown.
2. `MusicRepository.syncLibrary()` asks Android's MediaStore for every music file of 30 s or longer
   and saves them in a local Room database (`songs` table). Only rows that are new or different are written, so an
   unchanged library leaves the table alone. Songs that no longer exist are removed in chunks of 500 ids (SQLite takes
   at most 999 values in one `IN (…)` on Android 11 and older), and only when the scan found songs: a scan that
   returns nothing right after the permission was granted must not erase the library.
3. Screens never read MediaStore directly — they observe the database, so lists update by themselves. The table is
   watched once and sorted once per change (by title, following the phone's language, in `MusicRepository`); the
   song list, *Recently played* and *Favourites* are all built from that one flow. Search looks through the songs
   already in memory and ignores capitals and accents ("beyonce" finds "Beyoncé").
4. If a file has no artist/album tag, MediaStore returns the text `<unknown>` (not null).
   `util/MediaTags.kt` turns that into "Unknown artist" / "Unknown album" everywhere.

## 2. Playing music
```
UI buttons ─▶ PlayerViewModel ─▶ PlayerManager ─▶ MediaController ─▶ MusicService ─▶ ExoPlayer
 (one copy         (state for         (one connection        (background service,
  for the app)      the screens)        for the app)           notification, audio focus)
```
* **MusicService** owns ExoPlayer and keeps playing when the app is closed with the home button. Swiping the app away from the recent apps, or dismissing the
  playback notification, closes everything at once (`MusicService.closeEverything()`): the floating lyrics window, the
  music, the notification and the service. `PlayerManager.release()` is part of that: the app's own controller keeps the
  service bound, and a bound service cannot stop.
* **PlayerManager** is connected once and never released while the app process lives. A tap that
  arrives before the connection is ready is remembered and played as soon as it connects.
* **PlayerViewModel** is created once in `AppRoot` and passed to every screen, so the mini player,
  the song lists and Now Playing always agree.
* Song position changes 5×/second, so it lives in its own flow (`progress`). Only the seek bar and the
  mini-player bar read it; song lists don't recompose while music plays.
* **Shuffle** is handled by `ShuffleCoordinator` (inside the service, next to ExoPlayer). It replaces ExoPlayer's
  random order with a *deck* (`ShuffleDeck`): a permutation of every song in the queue, the playing song first.
  - Each song appears exactly once per pass, so none is skipped and none repeats before the pass is over.
  - Turning shuffle on mid-way: songs already played stay behind the current one (that is what *Previous*
    walks back through) and only the unplayed songs are shuffled. If everything was played, a new pass starts.
  - *Repeat off* stops after the last song. *Repeat all* builds a new random deck when the last song starts.
  - The *Shuffle* buttons start shuffle mode with a random first song (`PlayerManager.playSongs(..., shuffle = true)`).
* **Notification / lock screen / headset buttons.** The media session is given `SkippablePlayer` (a
  `ForwardingPlayer` around ExoPlayer) that keeps *previous* and *next* available at all times. ExoPlayer withdraws
  *next* on the last song, which made the notification lose a button exactly when a queue ended (play jumped across;
  Android 13+ left an empty slot). *Next* on the last song just does nothing. The status-bar icon is
  `ic_stat_lyrix` (set on `DefaultMediaNotificationProvider`); the title comes from the media item's metadata.
* **Notification buttons.** Previous / play / next are drawn by Android (on Android 13+ from the playback state,
  with its own icons), so an app cannot restyle them. `NotificationButtons` (the session callback) adds two buttons
  with Lyrix's own icons: *shuffle* and *repeat* (`ic_notif_*`; a notification icon is painted one colour, so
  *on* is full brightness with a dot and *off* is dimmed). They are session custom commands: `onConnect` lets a
  controller press them, `onCustomCommand` flips shuffle / cycles repeat on the player, and a player listener
  re-sends the custom layout whenever either changes, so the icons are right even when the Now Playing screen or
  a headset changed it. Android 13+ shows them on either side of previous / next in the expanded media card.
* **A file that cannot be played is skipped.** When the player reports an error (a deleted, unreadable or broken
  file) and there is a next song, `MusicService` goes on to it and shows *Skipped a file that can't be played*;
  `PlaybackLogger` still saves the error report. After 5 errors in a row without a song playing in between (every
  file broken, with repeat all) it stops instead of looping for ever; a song that plays resets the count.
* **Who may control playback.** Lyrix itself (its screens and its notification), the system interface, Bluetooth,
  Android Auto and the Google voice assistant can do everything. Any other app that connects to the media session
  can still play, pause, seek and skip, but cannot load its own songs into the queue or use the shuffle / repeat
  buttons (`NotificationButtons.onConnect` holds the list of allowed package names).
* **Sleep timer** lives in `SleepTimerManager` (a singleton), so it still pauses the music after you
  close the app. It calls `pause()` — it never restarts music you already paused.

## 3. Lyrics
Lyrics come from the free LRCLIB service. `LyricsRepository` tries, in order, and stops at the first hit:

| Step | Request | Used when |
|------|---------|-----------|
| 1 | exact lookup `/api/get` (title + artist + album + length) | song has an artist tag |
| 2 | field search `/api/search?track_name=…` | always — works with the title alone |
| 3 | free-text search `/api/search?q=…` | last resort |

* Every step is tried with a **cleaned title** (`(Official Video)`, `[Lyrics]`, `01 - ` removed) and, for
  file-name style titles like `Artist - Title`, with that split as well.
* Search results are accepted only with real evidence: same title **and** length within 5 s when there is
  no artist, or matching artist. A title that merely contains your words never counts, so "Love" will
  not pull the lyrics of "Love Story".
* **Saved on the phone for good.** Found lyrics are stored in Room and never expire, so once a song's lyrics have
  loaded that song never needs the internet again (only *Try again* asks the service anew). "Not found" is retried
  after 1 day. A network failure is **never** saved, and shows a *Try again* button instead of "No lyrics": that means no
  connection, a timeout (408), a rate limit (429) or a server error (5xx). Any other 4xx answer counts as "nothing
  found" for that one request, and the next lookup is tried. On top
  of that `LyricsManager` keeps the last 12 results in memory, so returning to a song shows its lyrics without the
  spinner. (There is no purge: nothing would ever delete found lyrics.)
* **Online lyrics lookup** (Settings → Lyrics, on by default). Looking up lyrics is what uses the internet: a song's
  title, artist, album and length go to lrclib.net. With the switch off `LyricsRepository` makes no request at all:
  lyrics already saved on the phone (cached, or your own) are shown, otherwise *No lyrics*, and *Choose another
  version* answers *offline*. The switch is read straight from DataStore, so even the first lookup after the app
  starts follows it, and *Reset lyrics style* leaves it alone. The request logger exists in debug builds only, and
  the User-Agent carries the real version number.
* **Fullest wins.** LRCLIB often has several uploads of one song and some stop halfway. Among the trusted
  matches the one with the most lines is chosen (`TrackMatcher.pickBest`); a hit that looks cut short
  (`LyricsQuality.assess`: synced lines < 80 % of the plain lines, or the timing ends long before the song)
  is only kept as a fallback while the other steps look for a fuller one.
* **Missing tail.** If the synced lines are a prefix of the plain text, the remaining plain lines are appended
  without timing (`LyricsQuality.withMissingTail`) and shown dimmed, so nothing is missing from the screen.
  Lyrics that still look incomplete get a notice with a button to the version list.
* **Your own lyrics** (lyrics options, ⋮ above the lyrics): *Choose another version* (list of everything found,
  `LyricsRepository.findVersions`), *Edit or paste lyrics*, *Import .lrc/.txt*, *Back to automatic*, and *Sync
  timing*. Your choice and offset are stored per song as small JSON files (`CustomLyricsStore`, in the app's private
  `files/lyrics` folder) — deliberately not in Room, so they never expire and the database schema is untouched. They are
  written through `AtomicFile` (the old file stays until the new one is complete, so a crash in the middle of a save
  loses nothing), and an imported file is read in pieces and refused beyond 1 MB without loading it.
  Text with `[mm:ss.xx]` lines becomes synced lyrics, anything else plain lyrics.
* **Sync timing** is a panel above the lyrics (`LyricsSyncPanel`, opened by the *Sync* chip or from the lyrics
  options), not a dialog, so the lines can be watched moving while you adjust. Slider ±10 s, ±1 s buttons, ±0.1 s
  buttons that repeat while held; every change is saved at once (`LyricsTiming.MAX_OFFSET_MS` = ±30 s).
* **Edit lyrics** is a full screen (`LyricsEditorScreen`) laid over Now Playing, with `systemBarsPadding().imePadding()`:
  the keyboard pushes it up so the text field shrinks instead of being covered. Back closes the editor only.
* **Choose lyrics** marks the version already in use (`LyricsFingerprint` compares the first letters of the text,
  ignoring timestamps) and keeps the last 8 searches in memory (the *Search* button always asks again).
* **Auto-scroll** (`SyncedLyricsContent` / `centerLine`): the current line is scrolled to the middle of the list.
  The list has half a screen of padding above and below, and a line's `offset` is measured from the start of the
  *content* (below the padding), so the middle is `(viewportStartOffset + viewportEndOffset) / 2` — **not**
  `viewportSize / 2`, which put the line at the bottom edge. While a finger is on the list nothing scrolls; 3.5 s
  after it lets go the list glides back to the current line. Before the first line it returns to the top.
* **Try again** re-asks the service ignoring the cache.
* `LyricsManager` (singleton) holds the lyrics of the current song and the current line. Lyrics are only looked up
  when the Now Playing screen or the floating window asks, and the 100 ms position polling runs only while
  something is observing `activeLine` — a closed app with no floating window does no lyrics work.
* Lyrics are optional, so they are fenced off from the player: if anything unexpected fails while loading
  them, the app saves an error log, shows *Couldn't load lyrics* with a *Try again* button, and the music
  keeps playing.
* **Regex rule for Android:** the phone's regex engine (ICU) is stricter than a desktop JVM. Always escape
  literal `{ } [ ] ( )` with a backslash (`\{[^\}]*\}`, not `\{[^}]*}`), or the app crashes the first time
  the pattern is built.

## 4. Look, settings and floating lyrics
* **Settings** (`ui/screen/SettingsScreen.kt`, reached from the gear on Home / Now Playing). All options are
  data classes in `data/model/AppSettings.kt`, stored in DataStore by `SettingsRepository`. `settings` is a
  `StateFlow` rebuilt from the stored values, so Settings, Now Playing and the floating window (inside the
  service) always agree; `update { … }` changes the stored values atomically.
* **Now Playing look**: `AmbientBackground` (aurora / pulse / still / plain) and `NowPlayingCover` (rounded or
  circle, breathe / float / spin / none, halo). Both drive their animation from one float clock that only the
  draw / graphics-layer phase reads, capped at 30 fps for the background, and stopped while paused.
* **Now Playing picture** (Settings → *Picture*): `MusicVisualizer` (default; Ring / Bars / Waves), the album cover
  (`NowPlayingCover`), or *Auto* (cover only when the song has art; the screen learns that while it loads the art
  for the accent colour). The visualizer is a pretend spectrum — three sine waves per bar plus a steady beat — so it
  needs no audio permission; it settles when paused. One float clock, read only by the draw phase, 30 fps, stopped
  while paused (unless *Animate only while playing* is off).
* **Lyrics view** (`LyricsView.kt`): size, alignment, font, weight, current-line scale, dimming, distance fade,
  highlight colour (or album colour), glow, smooth scroll, tap to seek, keep screen on.
* **Floating lyrics** (`overlay/`): `FloatingLyricsOverlay` is created by `MusicService` (a foreground service
  while music plays, so Android keeps the window alive). It adds a `ComposeView` to `WindowManager`
  (`TYPE_APPLICATION_OVERLAY`) and draws `FloatingLyricsCard` — the same composable as the live preview in
  Settings. A window added from a service has no Activity, so `OverlayLifecycleOwner` supplies the lifecycle and
  saved-state owners the ComposeView needs. `OverlayDragLayout` moves the window using raw screen coordinates (the
  window moves under the finger, so view coordinates would jitter) and only after the touch slop, so the buttons
  inside still work. It shows only when: enabled + permission granted + a song is playing (pause, stop, a
  dismissed notification and a swiped-away app remove the window; a 0.4 s grace keeps it from blinking between songs) + the screen is on + Lyrix is not on screen (`AppForeground`, optional) + synced lyrics exist (optional).
  The window is taken away while the screen is off (`FloatingLyricsOverlay` listens for screen on / off while it
  runs), and with it the 100 ms line ticker, which only runs while something observes the current line.
  The permission is *Display over other apps* (`SYSTEM_ALERT_WINDOW`); `OverlayPermission` opens the system page.
* **A style for each app.** `AppLyricsProfile` = package + name + *visible* + a full `FloatingLyricsSettings`
  (its four "when to show" switches are ignored: those stay global, `withBehaviorOf`). `AppProfileRepository` keeps
  them as one JSON text in the same DataStore (`fl_app_profiles`, plus the master switch `fl_per_app`); every
  field has a default and a range, so an older or newer profile still reads. `ForegroundAppTracker` finds the app
  on screen by reading Android's log of app switches (`UsageStatsManager.queryEvents`, the permission is *Usage
  access*, `UsageAccessPermission`) about once a second, and **only while it can matter** (floating lyrics on, per-app
  on, at least one app or the home screen has a style of its own, something playing, screen on); the app that last
  "came to the front" is the app on screen. The overlay turns
  *default style + profiles + app on screen* into one `ResolvedFloating` (pure function `resolveFloating`) and
  everything else reads that: layout, content, visibility. `saveDraggedPosition` writes the dropped position into
  the profile of the app on screen (making one from the default style the first time), or into the default style
  when styles are not per app or the app is unknown (with no style at all yet nothing is tracked, so a drag saves
  into the default style until the first app is added in Settings). Settings: `AppProfilesSection` (list, *Add an app*) and
  `StyleEditorDialog` (full screen, same `FloatingStyleControls` as the default style) with `AppProfilesViewModel`.
  **Home screen & menu**: a launcher (an app with a HOME activity of normal priority, `InstalledApps.homePackages`;
  Settings' fallback "home" is skipped) in front means no app is open, so `ForegroundAppTracker` reports the reserved
  key `HOME_SCREEN_KEY` (`#home`, never a real package name) instead of the launcher's package. That key is stored
  and resolved like an app, so dragging on the home screen saves into it. A slot without a profile (home screen
  until it is edited, any app never touched) simply gets the default style; the first change to a slot makes its
  profile from the default (`AppProfileRepository.change`). *All other apps* in the list is the default style itself.

## 5. Buttons and icons
Every icon is a vector drawable in `app/src/main/res/drawable/ic_*.xml` (24×24, white fill, tinted in code).
No emoji and no text glyphs are used as icons.

The one exception is the **Lyrix logo** (the launcher icon), which is full-colour artwork. The picture is the bitmap
`res/drawable-*dpi/ic_launcher_logo.png`; the adaptive icon (`mipmap-anydpi-v26/ic_launcher*.xml`) is made of
`ic_launcher_background` (plain black, the colour around the artwork's glowing frame), `ic_launcher_foreground` (the
bitmap, inset 23 % so the whole logo stays inside the 66dp safe zone and no launcher shape cuts it) and
`ic_launcher_monochrome` (the Android 13 themed icon: just the note, one colour). Android 7 - 7.1 use the PNGs in
`mipmap-*dpi/ic_launcher*.png`, and the playback notification's `ic_stat_lyrix` is the same note. When the logo
changes, replace all of these together; the two note vectors are traced from the artwork.

| Component | File | Use |
|-----------|------|-----|
| `VectorIcon` | `ui/components/VectorIcon.kt` | draw any `ic_*` drawable with a tint |
| `IconActionButton` | `ui/components/Buttons.kt` | round icon-only button with ripple + accessibility label |
| `MelodiqButton` | `ui/components/Buttons.kt` | labelled button, optional icon, `Filled` / `Tonal` / `Outlined` |
| `EmptyState` | `ui/components/EmptyState.kt` | icon + title + hint + action buttons |
| `ArtworkImage` | `ui/components/ArtworkImage.kt` | album art with a built-in music-note fallback |
| `EqualizerBars` | `ui/components/EqualizerBars.kt` | animated "now playing" bars |

To add an icon: save a 24×24 vector as `res/drawable/ic_name.xml` (`android:fillColor="#FFFFFFFF"`), then
`VectorIcon(id = R.drawable.ic_name)` or `IconActionButton(icon = R.drawable.ic_name, …)`.

## 6. Playlists
* Stored in the `playlists` table that has always existed (`PlaylistEntity`: id, name, `songIdsJson`, createdAt), so
  no migration. A playlist is a name plus song ids in the order they were added; the songs stay in the library, and
  ids that no longer exist are skipped when a playlist is shown.
* `PlaylistRepository` serialises every change behind a mutex (two quick taps never overwrite each other).
  `PlaylistNames` trims / collapses spaces / caps at 40 characters and rejects blank or duplicate names.
* `PlaylistsViewModel` is created once in `AppRoot` (like the player and library view models). It combines the
  playlists with the library songs into `PlaylistItem`s; `uiState.loaded` stops the empty message flashing.
* Screens: `PlaylistsScreen` (the tab), `PlaylistDetailScreen` (route `playlist/{playlistId}`). Dialogs in
  `PlaylistDialogs.kt`: name (create / rename), confirm, add-to-playlist, multi-song picker.
* **⋮ on a song** = `SongMenuHost` (menu → pick a playlist → new playlist name). Put it *outside* a `LazyColumn`
  (a dialog inside a lazy item disappears when the item scrolls away). Extra rows can be added with `extraActions`.
* **Changing the database.** Raise `version` in `AppDatabase` **and** add a `Migration` to `data/db/Migrations.kt`
  (`ALL`, empty at version 1; the file shows how). A missing migration makes Room stop with an error instead of
  wiping playlists, favourites and saved lyrics. Only a *downgrade* (an older Lyrix installed over a newer database)
  starts from scratch (`fallbackToDestructiveMigrationOnDowngrade`). Every build writes the schema to
  `app/schemas/` (the CI run uploads it as `room-schemas`); keep those files in the repository.

## 7. Project map
```
data/        model, Room database (+ Migrations), LRCLIB service, repositories (music, lyrics, playlists, settings, per-app styles, custom lyrics)
player/      MusicService (ExoPlayer) + SkippablePlayer + NotificationButtons + PlayerManager (app-wide controller) + ShuffleCoordinator
lyrics/      LyricsManager — lyrics + current line of the playing song, shared by screen and floating window
overlay/     FloatingLyricsOverlay, OverlayLifecycleOwner, OverlayPermission, AppForeground,
             ForegroundAppTracker + UsageAccessPermission (which app is on screen), InstalledApps (app names / list)
ui/          AppNavigation (AppRoot), screens (incl. Settings), components, view models, theme
util/        MediaTags, TrackMatcher/TitleCleaner, LrcParser, LyricsQuality, LyricsCleanup, ShuffleDeck, helpers
```

## 8. Backup, privacy and tests
* **Backup** (`res/xml/data_extraction_rules.xml` for Android 12+, `res/xml/backup_rules.xml` for Android 11 and older,
  both referenced in the manifest). The settings (`files/datastore`) and the saved lyrics (`files/lyrics`) are backed
  up and restored. The database (`melodiq.db` with its `-wal`, `-shm` and `-journal` files) and `files/crash_reports`
  are left out: playlists, favourites and the song list key on MediaStore ids, which are different on every phone, so a
  restored copy would point at the wrong songs. A restored phone simply scans its own library again.
* **Privacy.** Music files stay on the phone. What is sent is a song's title, artist, album and length, to lrclib.net,
  to find its lyrics: the permission screen says so and Settings → Lyrics → *Online lyrics lookup* turns it off. Debug
  builds log every request address; release builds do not.
* **Tests.** `app/src/test` holds JUnit 4 tests for the pure helpers (`LrcParser`, `TrackMatcher`, `ShuffleDeck`,
  `LyricsQuality`, `PlaylistNames`, `MediaTags`). The CI workflow runs `./gradlew testDebugUnitTest` after the APK is
  built and uploaded; a failing test never fails the run (the report is uploaded as `build-reports`).
