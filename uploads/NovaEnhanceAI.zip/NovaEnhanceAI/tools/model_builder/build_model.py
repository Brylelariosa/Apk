"""
NovaEnhance AI - initial model builder.

WHAT THIS IS
    This is a ONE-TIME, OFFLINE step run by a developer on a desktop machine
    with Python + TensorFlow installed. It is NOT part of the Android Gradle
    build and NOT run by the GitHub Actions APK workflow - Gradle only ever
    *bundles* whatever .tflite file already exists under
    app/src/main/assets/models/. The Android app itself never invents a
    network architecture from nothing; it only ever continues training
    (the "train" signature) and running inference (the "infer" signature)
    against whichever .tflite is currently active. Re-run this script only if
    you want to change the architecture itself (more/fewer residual blocks,
    different tile size, etc).

WHY A SEPARATE PYTHON STEP AT ALL
    TensorFlow Lite's on-device training support works by exporting a model
    that already contains a "train" op graph (built with SELECT_TF_OPS +
    resource variables), produced by TensorFlow's Python API. There is no
    on-device API to author a new architecture - Kotlin/Java can only drive
    the signatures ("infer", "train", "save", "restore", "set_anchor") that
    this script bakes in.

ARCHITECTURE
    A small residual CNN for image restoration (denoise + sharpen + detail
    recovery + artifact removal in one pass):

        input (256x256x3, float32, [0,1])
          -> Conv 3x3, 128ch, ReLU                          (head)
          -> N x [Conv 3x3 -> ReLU -> Conv 3x3, +skip]       (residual blocks)
          -> Conv 3x3, 3ch                                  (tail, near-zero init)
          -> output = input + tail_output                   (global residual)

    The tail conv is initialized with a very small stddev so at t=0 (before
    any training) the network is approximately the identity function - i.e.
    a brand new install "enhances" photos as a safe no-op rather than
    emitting random-noise garbage, and visibly improves from there as the
    user trains it. This is a standard residual-learning initialization
    trick, not a placeholder.

SIGNATURES EXPORTED (the Kotlin/JNI contract - see
    ai/inference/TFLiteSignatureRunner.kt for the Android-side counterpart):

    infer(input_image: f32[1,256,256,3])
        -> output_image: f32[1,256,256,3]

    train(lq_batch: f32[None,256,256,3], hq_batch: f32[None,256,256,3],
          learning_rate: f32 scalar, l2_sp_lambda: f32 scalar)
        -> loss: f32 scalar
        Runs ONE gradient step (Adam) on an L1 reconstruction loss plus an
        L2-SP ("starting point") regularization term that penalizes drifting
        away from the weights captured by the last set_anchor() call - this
        is the anti-forgetting mechanism, paired on the Kotlin side with
        experience replay (mixing old training pairs into new batches).

    set_anchor(trigger: int32 scalar) -> success: bool
        Copies the CURRENT trainable weights into a parallel set of
        non-trainable "anchor" variables. Call this once per training
        session, immediately after restore(), before any train() calls.

    save(checkpoint_path: string scalar) -> checkpoint_path: string scalar
    restore(checkpoint_path: string scalar) -> checkpoint_path: string scalar
        Graph-mode-compatible checkpoint write/read (NOT the Python-only
        Checkpoint.save/.restore, which cannot run inside a tf.function).

USAGE
    python3 -m venv venv && source venv/bin/activate
    pip install -r requirements.txt
    python build_model.py --output ../../app/src/main/assets/models/general_v1

    This produces:
        general_v1.tflite       (bundled into the APK as an asset)
        general_v1.json         (parameter count / architecture metadata,
                                  read by ai/model/ModelMetadata.kt)

Requires TensorFlow 2.15+ (CPU-only is fine; no GPU or cloud needed).
"""
import argparse
import json
import os
import shutil
import tempfile

import tensorflow as tf

TILE_SIZE = 256
CHANNELS = 128
NUM_RESIDUAL_BLOCKS = 16
TAIL_INIT_STDDEV = 1e-3


def _residual_block(x: tf.Tensor, channels: int, block_index: int) -> tf.Tensor:
    shortcut = x
    x = tf.keras.layers.Conv2D(
        channels, 3, padding="same", name=f"res{block_index}_conv1"
    )(x)
    x = tf.keras.layers.ReLU(name=f"res{block_index}_relu")(x)
    x = tf.keras.layers.Conv2D(
        channels, 3, padding="same", name=f"res{block_index}_conv2"
    )(x)
    return tf.keras.layers.Add(name=f"res{block_index}_add")([shortcut, x])


def build_backbone() -> tf.keras.Model:
    inputs = tf.keras.Input(shape=(TILE_SIZE, TILE_SIZE, 3), dtype=tf.float32, name="lq_input")

    x = tf.keras.layers.Conv2D(CHANNELS, 3, padding="same", name="head_conv")(inputs)
    x = tf.keras.layers.ReLU(name="head_relu")(x)

    for i in range(NUM_RESIDUAL_BLOCKS):
        x = _residual_block(x, CHANNELS, i)

    # Near-zero init so the network starts as an (approximate) identity
    # function - see module docstring for why this matters for first-run UX.
    tail_init = tf.keras.initializers.RandomNormal(stddev=TAIL_INIT_STDDEV)
    residual = tf.keras.layers.Conv2D(
        3, 3, padding="same", name="tail_conv", kernel_initializer=tail_init
    )(x)

    outputs = tf.keras.layers.Add(name="global_residual_add")([inputs, residual])
    outputs = tf.keras.layers.Lambda(
        lambda t: tf.clip_by_value(t, 0.0, 1.0), name="clip_output"
    )(outputs)

    return tf.keras.Model(inputs=inputs, outputs=outputs, name="novaenhance_backbone")


class NovaEnhanceModule(tf.Module):
    """Bundles the backbone + optimizer + anchor weights + checkpointing
    behind the fixed signature contract described in the module docstring."""

    def __init__(self):
        super().__init__()
        self.backbone = build_backbone()
        # Keras builds weights lazily on first call; force that now so
        # trainable_variables / anchor_vars are populated before we use them.
        _ = self.backbone(tf.zeros([1, TILE_SIZE, TILE_SIZE, 3], dtype=tf.float32))

        self.optimizer = tf.optimizers.Adam(learning_rate=1e-4)
        self.anchor_vars = [
            tf.Variable(tf.zeros_like(v), trainable=False, name=f"anchor_{i}")
            for i, v in enumerate(self.backbone.trainable_variables)
        ]
        self.checkpoint = tf.train.Checkpoint(backbone=self.backbone, optimizer=self.optimizer)

    @tf.function(input_signature=[
        tf.TensorSpec([1, TILE_SIZE, TILE_SIZE, 3], tf.float32, name="input_image"),
    ])
    def infer(self, input_image):
        return {"output_image": self.backbone(input_image, training=False)}

    @tf.function(input_signature=[
        tf.TensorSpec([None, TILE_SIZE, TILE_SIZE, 3], tf.float32, name="lq_batch"),
        tf.TensorSpec([None, TILE_SIZE, TILE_SIZE, 3], tf.float32, name="hq_batch"),
        tf.TensorSpec([], tf.float32, name="learning_rate"),
        tf.TensorSpec([], tf.float32, name="l2_sp_lambda"),
    ])
    def train(self, lq_batch, hq_batch, learning_rate, l2_sp_lambda):
        self.optimizer.learning_rate.assign(learning_rate)

        with tf.GradientTape() as tape:
            predictions = self.backbone(lq_batch, training=True)
            # L1 (mean absolute error): more robust to the occasional
            # outlier pixel than L2, which tends to over-smooth edges in
            # image-restoration tasks.
            reconstruction_loss = tf.reduce_mean(tf.abs(predictions - hq_batch))

            l2_sp = tf.add_n([
                tf.reduce_sum(tf.square(v - anchor))
                for v, anchor in zip(self.backbone.trainable_variables, self.anchor_vars)
            ])

            loss = reconstruction_loss + l2_sp_lambda * l2_sp

        gradients = tape.gradient(loss, self.backbone.trainable_variables)
        self.optimizer.apply_gradients(zip(gradients, self.backbone.trainable_variables))
        return {"loss": loss}

    @tf.function(input_signature=[tf.TensorSpec([], tf.int32, name="trigger")])
    def set_anchor(self, trigger):
        del trigger  # unused; tf.function signatures need >=1 input tensor
        for v, anchor in zip(self.backbone.trainable_variables, self.anchor_vars):
            anchor.assign(v)
        return {"success": tf.constant(True)}

    @tf.function(input_signature=[tf.TensorSpec([], tf.string, name="checkpoint_path")])
    def save(self, checkpoint_path):
        # .write() (not .save()) is the graph-mode-compatible variant -
        # .save() does extra Python-side bookkeeping that can't run inside
        # a tf.function, which is what TFLite conversion requires here.
        written_path = self.checkpoint.write(checkpoint_path)
        return {"checkpoint_path": written_path}

    @tf.function(input_signature=[tf.TensorSpec([], tf.string, name="checkpoint_path")])
    def restore(self, checkpoint_path):
        self.checkpoint.read(checkpoint_path).expect_partial()
        return {"checkpoint_path": checkpoint_path}


def convert_to_tflite(module: "NovaEnhanceModule", output_path_no_ext: str) -> bytes:
    # NOTE on quantization: this model is NOT post-training INT8 quantized,
    # even though the product spec calls for "INT8 quantization support."
    # That's a deliberate trade-off, not an oversight: full integer
    # quantization and on-device trainability are in real tension with
    # today's TFLite tooling - the "train" signature needs float32 weights
    # and optimizer state for standard gradient descent, so quantizing the
    # trainable variables themselves would break training. If a future
    # version wants a smaller/faster *inference-only* artifact for a model
    # the user is done training, the right approach is a SEPARATE export
    # path: freeze the trained weights into a plain (non-trainable) inference
    # graph and quantize THAT with `converter.optimizations = [tf.lite.Optimize.DEFAULT]`
    # - this file intentionally keeps the trainable model unquantized so the
    # continual-learning story stays correct.
    with tempfile.TemporaryDirectory() as saved_model_dir:
        tf.saved_model.save(
            module,
            saved_model_dir,
            signatures={
                "infer": module.infer.get_concrete_function(),
                "train": module.train.get_concrete_function(),
                "set_anchor": module.set_anchor.get_concrete_function(),
                "save": module.save.get_concrete_function(),
                "restore": module.restore.get_concrete_function(),
            },
        )

        converter = tf.lite.TFLiteConverter.from_saved_model(saved_model_dir)
        converter.target_spec.supported_ops = [
            tf.lite.OpsSet.TFLITE_BUILTINS,
            tf.lite.OpsSet.SELECT_TF_OPS,
        ]
        # Required for the "train"/"save"/"restore" signatures, which rely on
        # TF resource variables (the optimizer's moment estimates, the
        # anchor weights, the checkpoint machinery).
        converter.experimental_enable_resource_variables = True
        return converter.convert()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", required=True,
        help="Output path WITHOUT extension, e.g. ../../app/src/main/assets/models/general_v1"
    )
    args = parser.parse_args()

    module = NovaEnhanceModule()
    param_count = int(module.backbone.count_params())
    print(f"Backbone parameter count: {param_count:,}")

    tflite_bytes = convert_to_tflite(module, args.output)

    output_dir = os.path.dirname(args.output)
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)

    tflite_path = f"{args.output}.tflite"
    with open(tflite_path, "wb") as f:
        f.write(tflite_bytes)

    metadata = {
        "modelName": "General Photo AI",
        "architecture": "residual-cnn",
        "tileSize": TILE_SIZE,
        "channels": CHANNELS,
        "residualBlocks": NUM_RESIDUAL_BLOCKS,
        "parameterCount": param_count,
        "versionNumber": 1,
        "signatures": ["infer", "train", "set_anchor", "save", "restore"],
    }
    with open(f"{args.output}.json", "w") as f:
        json.dump(metadata, f, indent=2)

    size_mb = len(tflite_bytes) / (1024 * 1024)
    print(f"Wrote {tflite_path} ({size_mb:.2f} MB) and metadata JSON.")


if __name__ == "__main__":
    main()
