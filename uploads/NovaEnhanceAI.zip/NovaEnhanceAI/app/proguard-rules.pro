# NovaEnhance AI - release shrinking rules.
# Goal: keep the release APK small (minifyEnabled + shrinkResources are on)
# while protecting the handful of classes that are accessed reflectively,
# via JNI, or via Room's generated code.

# --- TensorFlow Lite ---
# TFLite's native runtime looks up some Java classes/fields via JNI and
# reflection for delegate registration; stripping these breaks inference.
-keep class org.tensorflow.lite.** { *; }
-keep class org.tensorflow.lite.gpu.** { *; }
-dontwarn org.tensorflow.lite.**

# --- Room ---
# Entities/DAOs are referenced by generated code (*_Impl classes); keep
# field/annotation info so the generated implementations resolve correctly.
-keep class com.novaenhance.ai.database.entities.** { *; }
-keepclassmembers class com.novaenhance.ai.database.entities.** { *; }
-dontwarn androidx.room.**

# --- JNI (native image processing bridge) ---
# Native code calls into these methods by exact signature; R8 must not
# rename, inline, or remove them.
-keep class com.novaenhance.ai.ai.engine.NativeImageProcessor {
    native <methods>;
}

# --- Kotlin coroutines / metadata ---
-keepattributes Signature, InnerClasses, EnclosingMethod
-keepattributes *Annotation*
-dontwarn kotlinx.coroutines.**

# --- Compose (defensive; AGP's default compose rules already cover most of this) ---
-dontwarn androidx.compose.**
