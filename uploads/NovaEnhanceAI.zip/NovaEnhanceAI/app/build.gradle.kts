import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.devtools.ksp")
}

// Optional local signing override for developers building outside CI:
// app/keystore.properties (git-ignored) with storeFile/storePassword/keyAlias/keyPassword.
val keystoreProps = Properties().apply {
    val f = rootProject.file("app/keystore.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}

android {
    namespace = "com.novaenhance.ai"
    compileSdk = 34
    ndkVersion = "25.2.9519653"

    defaultConfig {
        applicationId = "com.novaenhance.ai"
        minSdk = 29 // Android 10+, per offline/on-device requirement
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        // Only build for real device ABIs actually in use on modern phones -
        // skip x86/x86_64 emulator ABIs to keep the release APK small.
        ndk {
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }

        externalNativeBuild {
            cmake {
                arguments += listOf("-DANDROID_STL=c++_shared")
                cppFlags += listOf("-O3", "-frtti", "-fexceptions")
            }
        }

        // Room schema export location, used for migration testing.
        ksp {
            arg("room.schemaLocation", "$projectDir/schemas")
            arg("room.incremental", "true")
        }
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    signingConfigs {
        create("release") {
            val storeFilePath = System.getenv("RELEASE_STORE_FILE")
                ?: keystoreProps.getProperty("storeFile")
            if (storeFilePath != null && file(storeFilePath).exists()) {
                storeFile = file(storeFilePath)
                storePassword = System.getenv("RELEASE_STORE_PASSWORD")
                    ?: keystoreProps.getProperty("storePassword")
                keyAlias = System.getenv("RELEASE_KEY_ALIAS")
                    ?: keystoreProps.getProperty("keyAlias")
                keyPassword = System.getenv("RELEASE_KEY_PASSWORD")
                    ?: keystoreProps.getProperty("keyPassword")
            }
            // If nothing is configured, this signing config simply has no
            // store attached below and release falls back to the debug key
            // (see buildTypes.release) so `assembleRelease` still succeeds
            // out of the box on a brand-new checkout with zero setup.
        }
    }

    buildTypes {
        debug {
            applicationIdSuffix = ".debug"
            isDebuggable = true
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = if (signingConfigs.getByName("release").storeFile != null) {
                signingConfigs.getByName("release")
            } else {
                signingConfigs.getByName("debug")
            }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        isCoreLibraryDesugaringEnabled = true
    }

    kotlinOptions {
        jvmTarget = "17"
        freeCompilerArgs += listOf(
            "-opt-in=kotlin.RequiresOptIn",
            // TopAppBar (used in every screen) and a few other Material3
            // components are still marked @ExperimentalMaterial3Api in this
            // Compose BOM version. Opting in globally here is simpler and
            // more honest than sprinkling @OptIn on 6+ near-identical
            // composables - the experimental-ness is a property of the
            // library version, not something that varies per screen.
            "-opt-in=androidx.compose.material3.ExperimentalMaterial3Api"
        )
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    composeOptions {
        // Compatible with Kotlin 1.9.24 per the JetBrains Compose-Kotlin
        // compatibility map.
        kotlinCompilerExtensionVersion = "1.5.14"
    }

    packaging {
        resources {
            excludes += setOf(
                "/META-INF/{AL2.0,LGPL2.1}",
                "META-INF/DEPENDENCIES",
                "META-INF/LICENSE",
                "META-INF/LICENSE.txt",
                "META-INF/NOTICE",
                "META-INF/NOTICE.txt"
            )
        }
        jniLibs {
            useLegacyPackaging = false
        }
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    // --- Core / Compose ---
    val composeBom = platform("androidx.compose:compose-bom:2024.06.00")
    implementation(composeBom)
    androidTestImplementation(composeBom)

    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.4")
    implementation("androidx.lifecycle:lifecycle-service:2.8.4")
    implementation("androidx.activity:activity-compose:1.9.1")
    implementation("androidx.navigation:navigation-compose:2.7.7")

    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    debugImplementation("androidx.compose.ui:ui-tooling")

    // --- Coroutines ---
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // --- Room (dataset / training history / model registry) ---
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    ksp("androidx.room:room-compiler:2.6.1")

    // --- WorkManager (background training) ---
    implementation("androidx.work:work-runtime-ktx:2.9.1")

    // --- DataStore (settings) ---
    implementation("androidx.datastore:datastore-preferences:1.1.1")

    // --- On-device AI inference + training ---
    implementation("org.tensorflow:tensorflow-lite:2.16.1")
    // Select TF ops are required to run the custom train/save/restore
    // signatures produced by tools/model_builder/build_model.py.
    implementation("org.tensorflow:tensorflow-lite-select-tf-ops:2.16.1")
    // NOTE: tensorflow-lite-support is intentionally NOT included - this app
    // never uses its ImageProcessor/TensorImage utilities (TensorImageCodec
    // is hand-rolled instead, see ai/engine/), so it was pure dead weight in
    // the APK. Removing it also eliminates a namespace-collision warning
    // AGP raised against tensorflow-lite-support-api.

    // --- Desugaring (java.time etc. on minSdk 29, kept for forward compat) ---
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.0.4")

    // --- Tests ---
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.8.1")
    // Android's unit-test stub android.jar does NOT implement org.json's
    // actual parsing behavior (methods throw unless stubbed) - this pulls in
    // the real reference implementation so ModelMetadataTest exercises real
    // JSON parsing rather than Android's "not mocked" stub.
    testImplementation("org.json:json:20231013")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.6.1")
}
