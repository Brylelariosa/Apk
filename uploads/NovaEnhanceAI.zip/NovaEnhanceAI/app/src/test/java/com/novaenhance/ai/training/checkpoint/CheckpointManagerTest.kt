package com.novaenhance.ai.training.checkpoint

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.io.File
import java.nio.file.Files

class CheckpointManagerTest {

    private lateinit var tempDir: File
    private lateinit var manager: CheckpointManager

    @Before
    fun setUp() {
        tempDir = Files.createTempDirectory("nova_checkpoint_test").toFile()
        manager = CheckpointManager()
    }

    private fun writeCheckpointShards(prefix: File, vararg suffixes: String) {
        prefix.parentFile.mkdirs()
        suffixes.forEach { suffix ->
            File(prefix.parentFile, prefix.name + suffix).writeText("fake-checkpoint-data-$suffix")
        }
    }

    @Test
    fun `filesForPrefix finds every sibling shard sharing the prefix basename`() {
        val prefix = File(tempDir, "v2.ckpt")
        writeCheckpointShards(prefix, ".index", ".data-00000-of-00001")
        // A file that merely starts similarly but is a different version must NOT match.
        File(tempDir, "v20.ckpt.index").writeText("unrelated")

        val found = manager.filesForPrefix(prefix)

        assertEquals(2, found.size)
        assertTrue(found.all { it.name.startsWith("v2.ckpt") })
    }

    @Test
    fun `totalSizeBytes sums every shard, not just one file`() {
        val prefix = File(tempDir, "v3.ckpt")
        writeCheckpointShards(prefix, ".index", ".data-00000-of-00001")

        val expected = manager.filesForPrefix(prefix).sumOf { it.length() }
        assertEquals(expected, manager.totalSizeBytes(prefix))
        assertTrue(expected > 0)
    }

    @Test
    fun `copyCheckpoint preserves each shard's suffix under the new prefix`() {
        val srcPrefix = File(tempDir, "src/v1.ckpt")
        writeCheckpointShards(srcPrefix, ".index", ".data-00000-of-00001")
        val destPrefix = File(tempDir, "dest/v1_copy.ckpt")

        manager.copyCheckpoint(srcPrefix, destPrefix)

        assertTrue(File(tempDir, "dest/v1_copy.ckpt.index").exists())
        assertTrue(File(tempDir, "dest/v1_copy.ckpt.data-00000-of-00001").exists())
    }

    @Test
    fun `deleteCheckpoint removes every shard`() {
        val prefix = File(tempDir, "v4.ckpt")
        writeCheckpointShards(prefix, ".index", ".data-00000-of-00001")

        manager.deleteCheckpoint(prefix)

        assertTrue(manager.filesForPrefix(prefix).isEmpty())
    }

    @Test
    fun `exportBundle then importBundle round-trips architecture, metadata, and checkpoint shards`() {
        val architecture = File(tempDir, "architecture.tflite").apply { writeText("fake-architecture-bytes") }
        val metadata = File(tempDir, "metadata.json").apply { writeText("""{"parameterCount": 123}""") }
        val checkpointPrefix = File(tempDir, "v5.ckpt")
        writeCheckpointShards(checkpointPrefix, ".index", ".data-00000-of-00001")

        val bundleZip = File(tempDir, "export.novamodel")
        manager.exportBundle(architecture, checkpointPrefix, metadata, bundleZip)
        assertTrue(bundleZip.exists())

        val destModelDir = File(tempDir, "imported/model")
        val destCheckpointDir = File(tempDir, "imported/checkpoints")
        val imported = manager.importBundle(bundleZip, destModelDir, destCheckpointDir, checkpointVersionNumber = 1)

        assertEquals("fake-architecture-bytes", imported.architectureFile.readText())
        assertEquals("""{"parameterCount": 123}""", imported.metadataFile.readText())
        assertTrue(imported.checkpointPrefix != null)
        assertTrue(manager.filesForPrefix(imported.checkpointPrefix!!).isNotEmpty())
    }

    @Test
    fun `exportBundle of an untrained version (no checkpoint) imports with a null checkpoint prefix`() {
        val architecture = File(tempDir, "architecture.tflite").apply { writeText("fake-architecture-bytes") }
        val metadata = File(tempDir, "metadata.json").apply { writeText("{}") }

        val bundleZip = File(tempDir, "export_v1.novamodel")
        manager.exportBundle(architecture, checkpointPrefix = null, metadataFile = metadata, destZip = bundleZip)

        val imported = manager.importBundle(
            bundleZip, File(tempDir, "imported2/model"), File(tempDir, "imported2/checkpoints"), checkpointVersionNumber = 1
        )

        assertTrue(imported.checkpointPrefix == null)
        assertFalse(imported.architectureFile.readText().isEmpty())
    }
}
