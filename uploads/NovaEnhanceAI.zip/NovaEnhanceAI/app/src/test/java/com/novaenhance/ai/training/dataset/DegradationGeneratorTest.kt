package com.novaenhance.ai.training.dataset

import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class DegradationGeneratorTest {

    @Test
    fun `randomRecipe never produces out-of-range values across many seeds`() {
        // Probabilistic generation logic isn't suited to exact-value
        // assertions - what matters is that every field stays within the
        // range DegradationGenerator.degrade()'s native calls actually
        // accept, across a wide sample of seeds and severities.
        repeat(200) { seed ->
            val generator = DegradationGenerator(Random(seed.toLong()))
            val severity = (seed % 10) / 10f // sweep 0.0..0.9

            val recipe = generator.randomRecipe(severity)

            assertTrue("blurSigma was negative: ${recipe.blurSigma}", recipe.blurSigma >= 0f)
            assertTrue("noiseAmount was negative: ${recipe.noiseAmount}", recipe.noiseAmount >= 0f)
            assertTrue(
                "jpegQuality out of [15,95]: ${recipe.jpegQuality}",
                recipe.jpegQuality in 15..95
            )
            assertTrue(
                "resolutionScale out of [0.25,1.0]: ${recipe.resolutionScale}",
                recipe.resolutionScale in 0.25f..1f
            )
            assertTrue("colorFadeAmount was negative: ${recipe.colorFadeAmount}", recipe.colorFadeAmount >= 0f)
            assertTrue("motionBlurLengthPx was negative: ${recipe.motionBlurLengthPx}", recipe.motionBlurLengthPx >= 0)
            assertTrue(
                "motionBlurAngle out of [0,180]: ${recipe.motionBlurAngle}",
                recipe.motionBlurAngle in 0f..180f
            )
        }
    }

    @Test
    fun `higher severity produces at least as harsh a jpeg quality ceiling on average`() {
        val generator = DegradationGenerator(Random(42))
        val lowSeverityQualities = (1..50).map { generator.randomRecipe(severity = 0.1f).jpegQuality }
        val highSeverityQualities = (1..50).map { generator.randomRecipe(severity = 0.9f).jpegQuality }

        // Lower "quality" number = harsher compression. High severity should
        // trend toward lower (harsher) quality values on average.
        assertTrue(
            "expected high-severity average jpegQuality (${highSeverityQualities.average()}) " +
                "to be lower than low-severity average (${lowSeverityQualities.average()})",
            highSeverityQualities.average() < lowSeverityQualities.average()
        )
    }
}
