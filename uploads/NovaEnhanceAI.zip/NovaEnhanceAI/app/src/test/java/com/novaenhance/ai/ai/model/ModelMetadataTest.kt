package com.novaenhance.ai.ai.model

import org.junit.Assert.assertEquals
import org.junit.Test
import java.io.File
import java.nio.file.Files

class ModelMetadataTest {

    @Test
    fun `toJson then fromFile round-trips every field exactly`() {
        val original = ModelMetadata(
            modelName = "General Photo AI",
            architecture = "residual-cnn",
            tileSize = 256,
            channels = 128,
            residualBlocks = 16,
            parameterCount = 5_312_003L,
            versionNumber = 3,
            signatures = listOf("infer", "train", "set_anchor", "save", "restore")
        )

        val tempFile = Files.createTempFile("metadata", ".json").toFile()
        tempFile.writeText(original.toJson())

        val parsed = ModelMetadata.fromFile(tempFile)

        assertEquals(original, parsed)
    }

    @Test
    fun `sidecarFor swaps the tflite extension for json`() {
        val tfliteFile = File("/some/dir/architecture.tflite")
        val sidecar = ModelMetadata.sidecarFor(tfliteFile)
        assertEquals(File("/some/dir/architecture.json"), sidecar)
    }

    @Test
    fun `sidecarFor handles version-numbered checkpoint-style names`() {
        val tfliteFile = File("/models/general/v3.tflite")
        val sidecar = ModelMetadata.sidecarFor(tfliteFile)
        assertEquals("v3.json", sidecar.name)
    }
}
