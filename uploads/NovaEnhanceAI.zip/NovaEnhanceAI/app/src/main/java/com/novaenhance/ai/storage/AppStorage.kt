package com.novaenhance.ai.storage

import android.content.Context
import com.novaenhance.ai.utils.Constants
import java.io.File

/**
 * Single source of truth for every on-disk location the app uses. Nothing
 * else in the codebase should call `context.getExternalFilesDir` or build a
 * `File(...)` path by hand - route it through here so storage layout only
 * has to change in one place.
 *
 * Models/checkpoints/datasets live under app-private external storage
 * (`getExternalFilesDir(null)`), which on API 29+ requires no storage
 * permission at all and is automatically cleaned up on uninstall - fitting
 * for an app that promises "no cloud, no accounts, no servers."
 */
class AppStorage(private val context: Context) {

    private val root: File
        get() = context.getExternalFilesDir(null) ?: context.filesDir

    fun modelsDir(): File = childDir(root, Constants.MODELS_DIR)
    fun checkpointsDir(): File = childDir(root, Constants.CHECKPOINTS_DIR)
    fun backupsDir(): File = childDir(root, Constants.BACKUPS_DIR)
    fun datasetsDir(): File = childDir(root, Constants.DATASET_DIR)
    fun enhancedOutputDir(): File = childDir(root, Constants.ENHANCED_OUTPUT_DIR)
    fun replayBufferDir(): File = childDir(root, "replay_buffer")
    fun cacheCapturesDir(): File = childDir(context.cacheDir, "captures")

    fun modelDir(modelId: String): File = childDir(modelsDir(), modelId)

    fun checkpointDir(modelId: String): File = childDir(checkpointsDir(), modelId)

    /** The single weights+optimizer-state file for one version - see NovaModelEngine's save/restore format. */
    fun weightsFile(modelId: String, versionNumber: Int): File =
        File(checkpointDir(modelId), "v$versionNumber.weights")

    fun datasetDir(modelId: String): File = childDir(datasetsDir(), modelId)
    fun datasetLowQualityDir(modelId: String): File = childDir(datasetDir(modelId), "low")
    fun datasetHighQualityDir(modelId: String): File = childDir(datasetDir(modelId), "high")

    /**
     * A ".novamodel" bundle is a plain ZIP containing one version's weights
     * file + metadata.json - i.e. everything needed to restore that exact
     * version on another install. See
     * [com.novaenhance.ai.training.checkpoint.CheckpointManager].
     */
    fun backupFile(modelId: String, versionNumber: Int, timestamp: Long): File =
        File(backupsDir(), "${modelId}_v${versionNumber}_$timestamp.novamodel")

    fun exportFile(modelId: String, versionNumber: Int): File =
        File(modelExportsDir(), "${modelId}_v$versionNumber.novamodel")

    /** Directory usable by [androidx.core.content.FileProvider] for sharing/export. */
    fun modelExportsDir(): File = childDir(root, "model_exports")

    private fun childDir(parent: File, name: String): File =
        File(parent, name).apply { if (!exists()) mkdirs() }
}
