package com.novaenhance.ai.di

import android.content.Context
import com.novaenhance.ai.ai.model.ModelRepository
import com.novaenhance.ai.database.AppDatabase
import com.novaenhance.ai.storage.AppStorage
import com.novaenhance.ai.storage.SettingsRepository
import com.novaenhance.ai.training.checkpoint.CheckpointManager
import com.novaenhance.ai.training.dataset.DatasetAnalyzer
import com.novaenhance.ai.training.dataset.DatasetManager
import com.novaenhance.ai.training.dataset.DegradationGenerator
import com.novaenhance.ai.training.trainer.AdaptiveTrainingController
import com.novaenhance.ai.training.trainer.ExperienceMemory
import com.novaenhance.ai.training.trainer.ModelTrainer
import com.novaenhance.ai.training.trainer.ModelValidator
import com.novaenhance.ai.training.trainer.SelfImprovementOrchestrator
import com.novaenhance.ai.training.trainer.TrainingControlFlow
import com.novaenhance.ai.utils.DeviceCapabilities

/**
 * A plain, hand-wired dependency container. This app deliberately does not
 * use Hilt/Dagger: for a single-module app of this size, a manual graph is
 * easier to read top-to-bottom, has zero annotation-processing surface to
 * go wrong in a from-scratch CI build, and every dependency edge below is
 * visible in one file rather than scattered across `@Module`/`@Provides`
 * declarations. If the codebase grows enough for that trade-off to flip,
 * swapping this one file for Hilt modules is a contained, mechanical change
 * - nothing outside this file references construction details.
 *
 * Everything here is a true singleton for the process lifetime (there is
 * exactly one [AppDatabase], one [ModelRepository], etc.), matching
 * [ModelRepository] and [TrainingForegroundService][com.novaenhance.ai.workers.TrainingForegroundService]'s
 * assumption that only one model/training session is ever active at once.
 */
class ServiceLocator private constructor(context: Context) {

    private val appContext = context.applicationContext

    val database: AppDatabase by lazy { AppDatabase.getInstance(appContext) }
    val storage: AppStorage by lazy { AppStorage(appContext) }
    val settingsRepository: SettingsRepository by lazy { SettingsRepository(appContext) }
    val deviceCapabilities: DeviceCapabilities by lazy { DeviceCapabilities(appContext) }
    val checkpointManager: CheckpointManager by lazy { CheckpointManager() }

    val modelRepository: ModelRepository by lazy {
        ModelRepository(storage, checkpointManager, database.modelDao(), database.modelVersionDao())
    }

    val datasetAnalyzer: DatasetAnalyzer by lazy { DatasetAnalyzer(database.datasetPairDao()) }
    val degradationGenerator: DegradationGenerator by lazy { DegradationGenerator() }
    val datasetManager: DatasetManager by lazy {
        DatasetManager(appContext, storage, database.datasetPairDao(), datasetAnalyzer, degradationGenerator)
    }

    val adaptiveTrainingController: AdaptiveTrainingController by lazy {
        AdaptiveTrainingController(deviceCapabilities, settingsRepository)
    }
    val experienceMemory: ExperienceMemory by lazy { ExperienceMemory(storage, database.replayBufferDao()) }
    val modelValidator: ModelValidator by lazy { ModelValidator() }

    val modelTrainer: ModelTrainer by lazy {
        ModelTrainer(
            modelRepository = modelRepository,
            datasetPairDao = database.datasetPairDao(),
            trainingSessionDao = database.trainingSessionDao(),
            lossHistoryDao = database.lossHistoryDao(),
            validationMetricDao = database.validationMetricDao(),
            modelVersionDao = database.modelVersionDao(),
            modelDao = database.modelDao(),
            datasetAnalyzer = datasetAnalyzer,
            adaptiveController = adaptiveTrainingController,
            experienceMemory = experienceMemory,
            validator = modelValidator,
            storage = storage,
            deviceCapabilities = deviceCapabilities
        )
    }

    val selfImprovementOrchestrator: SelfImprovementOrchestrator by lazy {
        SelfImprovementOrchestrator(modelTrainer, modelRepository, database.datasetPairDao())
    }

    /** Single shared pause/resume/cancel channel - see [TrainingForegroundService][com.novaenhance.ai.workers.TrainingForegroundService]. */
    val trainingControlFlow: TrainingControlFlow by lazy { TrainingControlFlow() }

    companion object {
        @Volatile private var instance: ServiceLocator? = null

        fun get(context: Context): ServiceLocator =
            instance ?: synchronized(this) {
                instance ?: ServiceLocator(context).also { instance = it }
            }
    }
}
