package com.novaenhance.ai.ai.engine

/**
 * Thin JNI bridge to `app/src/main/cpp/nn/network.cpp` - a small residual
 * CNN with hand-implemented (and gradient-checked - see
 * `tools/nn_verification/`) forward and backward passes, plus an Adam
 * optimizer. This is the entire "AI model": there is no TensorFlow, no
 * TFLite, no Python step, and no bundled model asset anywhere in this
 * app - a model is simply a [FloatArray] of [TOTAL_PARAMS] numbers that
 * [NativeNeuralEngine] can initialize, run forward on, or take one training
 * step against, all in a single native call.
 *
 * These constants MUST exactly match `nn/network.h`'s compile-time
 * constants - both sides hard-code the same fixed architecture rather than
 * negotiating shapes across the JNI boundary, which is deliberate (fewer
 * moving parts, no way for the two languages to silently disagree about a
 * dimension).
 */
object NativeNeuralEngine {

    init {
        System.loadLibrary("novaenhance_native")
    }

    const val TILE_SIZE = 64
    const val INPUT_CHANNELS = 3
    const val OUTPUT_CHANNELS = 3
    const val INPUT_FLOATS = TILE_SIZE * TILE_SIZE * INPUT_CHANNELS
    const val OUTPUT_FLOATS = TILE_SIZE * TILE_SIZE * OUTPUT_CHANNELS

    // Layout: conv1(3->32) + bias, conv2(32->32) + bias, conv3(32->32) + bias, conv4(32->3) + bias.
    // See nn/network.h's W1_SIZE..B4_SIZE/TOTAL_PARAMS for the derivation -
    // this is just the sum, kept here as a single source of truth on the
    // Kotlin side for allocating parameter/momentum/velocity arrays.
    const val TOTAL_PARAMS = 20259

    /** Randomly (He-init, near-zero tail layer) initializes a fresh [TOTAL_PARAMS]-sized parameter array in place. */
    fun initializeParams(params: FloatArray, seed: Long) {
        require(params.size == TOTAL_PARAMS) { "params must be exactly $TOTAL_PARAMS floats, got ${params.size}" }
        nativeInitializeParams(params, seed)
    }

    /** Forward pass only. `input` must be [INPUT_FLOATS] normalized [0,1] floats in HWC order; returns [OUTPUT_FLOATS] floats. */
    fun infer(input: FloatArray, params: FloatArray): FloatArray {
        require(input.size == INPUT_FLOATS) { "input must be exactly $INPUT_FLOATS floats, got ${input.size}" }
        require(params.size == TOTAL_PARAMS) { "params must be exactly $TOTAL_PARAMS floats, got ${params.size}" }
        return nativeInfer(input, params)
    }

    /**
     * Forward + backward + one Adam step over a batch, mutating
     * [params]/[momentum]/[velocity] in place. Returns the average L1 loss
     * over the batch (computed before the update). Pass `anchorParams =
     * null` and `l2SpLambda = 0f` to disable the anti-forgetting penalty
     * (e.g. a model's very first training session, with nothing yet to
     * protect).
     */
    fun trainStep(
        inputBatch: FloatArray,
        targetBatch: FloatArray,
        batchSize: Int,
        params: FloatArray,
        momentum: FloatArray,
        velocity: FloatArray,
        anchorParams: FloatArray?,
        adamStepNumber: Int,
        learningRate: Float,
        l2SpLambda: Float
    ): Float {
        require(inputBatch.size == INPUT_FLOATS * batchSize) { "inputBatch size mismatch" }
        require(targetBatch.size == OUTPUT_FLOATS * batchSize) { "targetBatch size mismatch" }
        require(params.size == TOTAL_PARAMS && momentum.size == TOTAL_PARAMS && velocity.size == TOTAL_PARAMS) {
            "params/momentum/velocity must each be exactly $TOTAL_PARAMS floats"
        }
        require(anchorParams == null || anchorParams.size == TOTAL_PARAMS) { "anchorParams must be exactly $TOTAL_PARAMS floats" }

        return nativeTrainStep(
            inputBatch, targetBatch, batchSize,
            params, momentum, velocity, anchorParams,
            adamStepNumber, learningRate, l2SpLambda
        )
    }

    // --- JNI declarations, implemented in native-lib.cpp ---
    private external fun nativeInitializeParams(params: FloatArray, seed: Long)
    private external fun nativeInfer(input: FloatArray, params: FloatArray): FloatArray
    private external fun nativeTrainStep(
        inputBatch: FloatArray, targetBatch: FloatArray, batchSize: Int,
        params: FloatArray, momentum: FloatArray, velocity: FloatArray,
        anchorParams: FloatArray?,
        adamStepNumber: Int, learningRate: Float, l2SpLambda: Float
    ): Float
}
