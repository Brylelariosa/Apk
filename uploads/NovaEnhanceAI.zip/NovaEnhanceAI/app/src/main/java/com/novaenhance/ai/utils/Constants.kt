package com.novaenhance.ai.utils

/**
 * Central home for tunables that would otherwise be duplicated/hardcoded
 * across the AI engine, training engine, and workers. Nothing in this file
 * is a hardcoded *path* - storage locations always go through [com.novaenhance.ai.storage.AppStorage],
 * which resolves them from Android's Context APIs at runtime.
 */
object Constants {

    // --- Tile-based processing (keeps peak memory bounded on 4GB devices) ---
    // Must match NativeNeuralEngine.TILE_SIZE exactly - the network's input
    // size is fixed at compile time (see app/src/main/cpp/nn/network.h),
    // not configurable per-model.
    const val TILE_SIZE_PX = 64
    const val TILE_OVERLAP_PX = 8 // blended overlap to avoid visible seams

    // --- Training defaults (starting points for the adaptive controller) ---
    // WARNING: this architecture's clip[0,1] output activation has zero
    // gradient outside that range, so a learning rate that's too high can
    // saturate the network and get it permanently stuck (verified
    // empirically, not just theoretically - see the comment on
    // clip01BackwardFromPre in nn/network.cpp and
    // tools/nn_verification/lr_saturation_check.cpp). 1e-4 is safely inside
    // the working range (confirmed up to 1.5x this, the adaptive
    // controller's ceiling, under a stress test far harsher than real
    // training); 0.02 reliably breaks within ~30 steps. Don't raise this
    // without re-running that check.
    const val DEFAULT_LEARNING_RATE = 1e-4f
    const val DEFAULT_BATCH_SIZE = 4
    const val DEFAULT_EPOCHS = 3
    const val MIN_BATCH_SIZE = 1
    const val MAX_BATCH_SIZE = 16

    // --- Adaptive controller thresholds ---
    const val LOW_RAM_THRESHOLD_MB = 2048L
    const val CRITICAL_RAM_THRESHOLD_MB = 1024L
    const val THERMAL_THROTTLE_CHECK_INTERVAL_MS = 5_000L

    // --- Experience replay (anti-forgetting) ---
    const val REPLAY_BUFFER_MAX_SIZE = 200
    const val REPLAY_BATCH_FRACTION = 0.25f // fraction of each batch drawn from replay buffer

    // --- Dataset analysis ---
    const val PERCEPTUAL_HASH_SIZE = 8 // 8x8 -> 64-bit dHash
    const val DUPLICATE_HASH_DISTANCE_THRESHOLD = 5 // Hamming distance
    const val MIN_VALID_PAIR_SIMILARITY = 0.15f // below this, pair is likely mismatched content
    const val MAX_VALID_PAIR_SIMILARITY = 0.98f // above this, pair has no enhancement signal

    // --- Model file layout (relative to app-private external files dir) ---
    const val MODELS_DIR = "models"
    const val CHECKPOINTS_DIR = "checkpoints"
    const val BACKUPS_DIR = "model_backups"
    const val DATASET_DIR = "datasets"
    const val ENHANCED_OUTPUT_DIR = "enhanced"

    // --- Notification channels ---
    const val NOTIFICATION_CHANNEL_TRAINING = "novaenhance_training"
    const val TRAINING_NOTIFICATION_ID = 1001

    // --- WorkManager unique work names ---
    const val WORK_NAME_TRAINING = "novaenhance_training_work"
    const val WORK_NAME_DATASET_ANALYSIS = "novaenhance_dataset_analysis_work"
}
