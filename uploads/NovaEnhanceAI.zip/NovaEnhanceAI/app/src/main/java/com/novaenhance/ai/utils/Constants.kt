package com.novaenhance.ai.utils

/**
 * Central home for tunables that would otherwise be duplicated/hardcoded
 * across the AI engine, training engine, and workers. Nothing in this file
 * is a hardcoded *path* - storage locations always go through [com.novaenhance.ai.storage.AppStorage],
 * which resolves them from Android's Context APIs at runtime.
 */
object Constants {

    // --- Tile-based processing (keeps peak memory bounded on 4GB devices) ---
    const val TILE_SIZE_PX = 256
    const val TILE_OVERLAP_PX = 16 // blended overlap to avoid visible seams

    // --- Model architecture target (per product spec: lightweight mobile model) ---
    const val TARGET_MIN_PARAMETERS = 5_000_000L
    const val TARGET_MAX_PARAMETERS = 10_000_000L

    // --- Training defaults (starting points for the adaptive controller) ---
    const val DEFAULT_LEARNING_RATE = 1e-4f
    const val DEFAULT_BATCH_SIZE = 4
    const val DEFAULT_EPOCHS = 3
    const val MIN_BATCH_SIZE = 1
    const val MAX_BATCH_SIZE = 16

    // --- Adaptive controller thresholds ---
    const val LOW_RAM_THRESHOLD_MB = 2048L
    const val CRITICAL_RAM_THRESHOLD_MB = 1024L
    const val THERMAL_THROTTLE_CHECK_INTERVAL_MS = 5_000L

    // --- Experience replay (anti-forgetting) ---
    const val REPLAY_BUFFER_MAX_SIZE = 200
    const val REPLAY_BATCH_FRACTION = 0.25f // fraction of each batch drawn from replay buffer

    // --- Dataset analysis ---
    const val PERCEPTUAL_HASH_SIZE = 8 // 8x8 -> 64-bit dHash
    const val DUPLICATE_HASH_DISTANCE_THRESHOLD = 5 // Hamming distance
    const val MIN_VALID_PAIR_SIMILARITY = 0.15f // below this, pair is likely mismatched content
    const val MAX_VALID_PAIR_SIMILARITY = 0.98f // above this, pair has no enhancement signal

    // --- Model file layout (relative to app-private external files dir) ---
    const val MODELS_DIR = "models"
    const val CHECKPOINTS_DIR = "checkpoints"
    const val BACKUPS_DIR = "model_backups"
    const val DATASET_DIR = "datasets"
    const val ENHANCED_OUTPUT_DIR = "enhanced"

    // --- Notification channels ---
    const val NOTIFICATION_CHANNEL_TRAINING = "novaenhance_training"
    const val TRAINING_NOTIFICATION_ID = 1001

    // --- WorkManager unique work names ---
    const val WORK_NAME_TRAINING = "novaenhance_training_work"
    const val WORK_NAME_DATASET_ANALYSIS = "novaenhance_dataset_analysis_work"
}
