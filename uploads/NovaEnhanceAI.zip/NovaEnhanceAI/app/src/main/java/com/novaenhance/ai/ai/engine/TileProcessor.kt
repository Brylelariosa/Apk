package com.novaenhance.ai.ai.engine

import android.graphics.Bitmap
import com.novaenhance.ai.utils.Constants
import kotlin.math.min

/**
 * Splits a full-resolution [Bitmap] into `tileSize x tileSize` tiles (with a
 * small overlap band) and calls [processTile] on each in raster order,
 * writing results directly into a single output bitmap.
 *
 * Memory strategy (per the "4GB RAM device" / tile-based requirement): the
 * only large allocation is the one output bitmap plus the source bitmap
 * itself - there is no full-image float accumulation buffer. Seams are
 * feathered by blending each tile's overlap band against whatever is
 * *already written* in the output bitmap from its left/top neighbor (which,
 * in raster order, is always processed first), rather than accumulating
 * weights globally. This is a lighter-weight approximation of full
 * multi-tile blending, and is visually seamless at the overlap widths this
 * app uses (16px, see [Constants.TILE_OVERLAP_PX]).
 */
class TileProcessor(
    private val tileSize: Int = Constants.TILE_SIZE_PX,
    private val overlap: Int = Constants.TILE_OVERLAP_PX
) {

    data class TileProgress(val tilesDone: Int, val tilesTotal: Int)

    suspend fun process(
        source: Bitmap,
        onProgress: ((TileProgress) -> Unit)? = null,
        processTile: suspend (pixels: IntArray, tileWidth: Int, tileHeight: Int) -> IntArray
    ): Bitmap {
        val width = source.width
        val height = source.height
        val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)

        val xPositions = tilePositions(width)
        val yPositions = tilePositions(height)
        val totalTiles = xPositions.size * yPositions.size
        var done = 0

        val srcTileBuffer = IntArray(tileSize * tileSize)
        val outTileBuffer = IntArray(tileSize * tileSize)

        for (ty in yPositions) {
            for (tx in xPositions) {
                val tileW = min(tileSize, width - tx)
                val tileH = min(tileSize, height - ty)

                // Reuse buffers sized for the max tile; only touch the
                // tileW x tileH region actually valid for edge tiles smaller
                // than a full tileSize x tileSize block.
                source.getPixels(srcTileBuffer, 0, tileW, tx, ty, tileW, tileH)

                val processed = if (tileW == tileSize && tileH == tileSize) {
                    processTile(srcTileBuffer, tileW, tileH)
                } else {
                    // Edge tile smaller than the model's fixed input size:
                    // pad by edge-replication up to tileSize, process, then
                    // crop back down - keeps the model's fixed-shape
                    // "infer" signature usable for every tile, including
                    // ragged edges.
                    val padded = PixelBufferOps.padByReplication(srcTileBuffer, tileW, tileH, tileSize)
                    val paddedResult = processTile(padded, tileSize, tileSize)
                    PixelBufferOps.cropTopLeft(paddedResult, tileSize, tileW, tileH)
                }

                blendIntoOutput(output, processed, tx, ty, tileW, tileH, outTileBuffer)

                done++
                onProgress?.invoke(TileProgress(done, totalTiles))
            }
        }

        return output
    }

    /** Tile start offsets covering [0, extent), with the last tile clamped to the edge instead of overshooting. */
    private fun tilePositions(extent: Int): List<Int> {
        if (extent <= tileSize) return listOf(0)
        val stride = tileSize - overlap
        val positions = mutableListOf<Int>()
        var pos = 0
        while (pos + tileSize < extent) {
            positions.add(pos)
            pos += stride
        }
        positions.add(extent - tileSize) // final tile flush with the edge
        return positions.distinct()
    }

    /**
     * Writes [processedTile] into [output] at ([tx],[ty]), feathering the
     * left/top overlap bands against pixels already present in [output]
     * (i.e. the previously-written left/top neighbor tiles).
     */
    private fun blendIntoOutput(
        output: Bitmap,
        processedTile: IntArray,
        tx: Int,
        ty: Int,
        tileW: Int,
        tileH: Int,
        scratch: IntArray
    ) {
        val hasLeftNeighbor = tx > 0
        val hasTopNeighbor = ty > 0
        val blendW = if (hasLeftNeighbor) min(overlap, tileW) else 0
        val blendH = if (hasTopNeighbor) min(overlap, tileH) else 0

        if (blendW == 0 && blendH == 0) {
            output.setPixels(processedTile, 0, tileW, tx, ty, tileW, tileH)
            return
        }

        // Read the existing (already-written) output region so we can
        // feather against it, then overwrite with the blended result.
        output.getPixels(scratch, 0, tileW, tx, ty, tileW, tileH)

        for (y in 0 until tileH) {
            for (x in 0 until tileW) {
                val idx = y * tileW + x
                var alpha = 1.0f // weight given to the NEW tile's pixel

                if (hasLeftNeighbor && x < blendW) {
                    alpha = min(alpha, x.toFloat() / blendW)
                }
                if (hasTopNeighbor && y < blendH) {
                    alpha = min(alpha, y.toFloat() / blendH)
                }

                scratch[idx] = if (alpha >= 1.0f) {
                    processedTile[idx]
                } else {
                    blendPixel(scratch[idx], processedTile[idx], alpha)
                }
            }
        }

        output.setPixels(scratch, 0, tileW, tx, ty, tileW, tileH)
    }

    private fun blendPixel(oldPixel: Int, newPixel: Int, newWeight: Float): Int {
        val oldWeight = 1.0f - newWeight
        val r = ((oldPixel shr 16 and 0xFF) * oldWeight + (newPixel shr 16 and 0xFF) * newWeight).toInt()
        val g = ((oldPixel shr 8 and 0xFF) * oldWeight + (newPixel shr 8 and 0xFF) * newWeight).toInt()
        val b = ((oldPixel and 0xFF) * oldWeight + (newPixel and 0xFF) * newWeight).toInt()
        return (0xFF shl 24) or
            (r.coerceIn(0, 255) shl 16) or
            (g.coerceIn(0, 255) shl 8) or
            b.coerceIn(0, 255)
    }
}
