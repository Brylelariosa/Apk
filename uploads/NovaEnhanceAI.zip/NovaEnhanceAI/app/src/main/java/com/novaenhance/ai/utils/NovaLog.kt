package com.novaenhance.ai.utils

import android.util.Log
import com.novaenhance.ai.BuildConfig

/**
 * Thin wrapper around [android.util.Log] that no-ops verbose/debug logs in
 * release builds. Kept intentionally tiny - this is not a logging framework,
 * just a seam so we're not sprinkling `if (BuildConfig.DEBUG)` everywhere.
 */
object NovaLog {
    private const val GLOBAL_TAG = "NovaEnhance"

    fun d(tag: String, message: String) {
        if (BuildConfig.DEBUG) Log.d("$GLOBAL_TAG:$tag", message)
    }

    fun i(tag: String, message: String) {
        Log.i("$GLOBAL_TAG:$tag", message)
    }

    fun w(tag: String, message: String, throwable: Throwable? = null) {
        Log.w("$GLOBAL_TAG:$tag", message, throwable)
    }

    fun e(tag: String, message: String, throwable: Throwable? = null) {
        Log.e("$GLOBAL_TAG:$tag", message, throwable)
    }
}
