package com.novaenhance.ai.ui.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.novaenhance.ai.database.dao.DatasetPairDao
import com.novaenhance.ai.database.dao.LossHistoryDao
import com.novaenhance.ai.database.dao.ModelDao
import com.novaenhance.ai.database.dao.TrainingSessionDao
import com.novaenhance.ai.database.dao.ValidationMetricDao
import com.novaenhance.ai.database.entities.LossHistoryEntity
import com.novaenhance.ai.database.entities.ModelEntity
import com.novaenhance.ai.database.entities.TrainingSessionEntity
import com.novaenhance.ai.database.entities.TrainingStatus
import com.novaenhance.ai.database.entities.ValidationMetricEntity
import com.novaenhance.ai.storage.SettingsRepository
import com.novaenhance.ai.training.dataset.DatasetManager
import com.novaenhance.ai.training.trainer.ModelTrainer
import com.novaenhance.ai.training.trainer.TrainingControlFlow
import com.novaenhance.ai.workers.TrainingScheduler
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class TrainingUiState(
    val activeModel: ModelEntity? = null,
    val datasetPairCount: Int = 0,
    /** The most recent session for this model, whatever its status - NOT filtered to RUNNING/PAUSED, so the UI can still tell what just finished. */
    val currentSession: TrainingSessionEntity? = null,
    val showKeepOrDeleteDatasetPrompt: Boolean = false,
    val message: String? = null
)

data class SessionDetailUiState(
    val lossHistory: List<LossHistoryEntity> = emptyList(),
    val validationMetrics: List<ValidationMetricEntity> = emptyList()
)

class TrainingViewModel(
    private val appContext: Context,
    private val modelDao: ModelDao,
    private val trainingSessionDao: TrainingSessionDao,
    private val lossHistoryDao: LossHistoryDao,
    private val validationMetricDao: ValidationMetricDao,
    private val modelTrainer: ModelTrainer,
    private val controlFlow: TrainingControlFlow,
    private val settingsRepository: SettingsRepository,
    private val datasetManager: DatasetManager,
    private val datasetPairDao: DatasetPairDao
) : ViewModel() {

    private val showPrompt = MutableStateFlow(false)
    private val message = MutableStateFlow<String?>(null)

    // Plain mutable state is fine here (unlike in a @Composable): a
    // ViewModel instance has a real, single lifecycle rather than being
    // re-invoked on every recomposition, so this correctly remembers which
    // sessions have already triggered the completion prompt.
    private var lastSeenStatusBySessionId = mutableMapOf<Long, TrainingStatus>()

    val uiState: StateFlow<TrainingUiState> = modelDao.observeActive()
        .flatMapLatest { model ->
            if (model == null) {
                flowOf(
                    TrainingUiState(
                        message = "No AI model is available yet. See Model Manager, or this app's " +
                            "README if you built it yourself - the initial model has to be generated " +
                            "by a one-time script before it's bundled in."
                    )
                )
            } else {
                combine(
                    trainingSessionDao.observeForModel(model.id),
                    datasetPairDao.observeForModel(model.id).map { it.size },
                    showPrompt,
                    message
                ) { sessions, count, prompt, msg ->
                    val mostRecent = sessions.maxByOrNull { it.startedAt }
                    detectCompletionTransition(mostRecent)
                    TrainingUiState(
                        activeModel = model,
                        datasetPairCount = count,
                        currentSession = mostRecent,
                        showKeepOrDeleteDatasetPrompt = prompt,
                        message = msg
                    )
                }
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), TrainingUiState())

    /** Live per-batch progress - separate from [uiState] since it updates far more frequently. */
    val liveProgress = modelTrainer.progress

    private val _sessionDetail = MutableStateFlow(SessionDetailUiState())
    val sessionDetail: StateFlow<SessionDetailUiState> = _sessionDetail.asStateFlow()

    /** A session just transitioning from RUNNING/PAUSED into a promoted COMPLETED state is when the dataset prompt should appear. */
    private fun detectCompletionTransition(session: TrainingSessionEntity?) {
        if (session == null) return
        val previousStatus = lastSeenStatusBySessionId[session.id]
        val wasActive = previousStatus == TrainingStatus.RUNNING || previousStatus == TrainingStatus.PAUSED
        if (wasActive && session.status == TrainingStatus.COMPLETED && session.wasPromoted) {
            showPrompt.value = true
        }
        lastSeenStatusBySessionId[session.id] = session.status
    }

    fun startOrResumeTraining() {
        viewModelScope.launch {
            val model = modelDao.getActive()
            if (model == null) {
                message.value = "No AI model is available yet - see Model Manager to set one up."
                return@launch
            }
            try {
                val settings = settingsRepository.settings.first()
                val resumeId = uiState.value.currentSession?.takeIf { it.status == TrainingStatus.PAUSED }?.id
                TrainingScheduler.start(appContext, model.id, resumeId, settings.trainOnlyWhileCharging)
            } catch (t: Throwable) {
                message.value = "Couldn't start training: ${t.message ?: t::class.simpleName}"
            }
        }
    }

    fun pauseTraining() = controlFlow.pause()

    fun cancelTraining() = controlFlow.cancel()

    fun keepDataset() {
        showPrompt.value = false
    }

    fun deleteDataset() {
        viewModelScope.launch {
            uiState.value.activeModel?.let { model -> datasetManager.deleteAllForModel(model.id) }
            showPrompt.value = false
        }
    }

    fun loadSessionDetail(sessionId: Long) {
        viewModelScope.launch {
            _sessionDetail.value = SessionDetailUiState(
                lossHistory = lossHistoryDao.getForSession(sessionId),
                validationMetrics = validationMetricDao.getForSession(sessionId)
            )
        }
    }
}
