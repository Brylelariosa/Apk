package com.novaenhance.ai.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.novaenhance.ai.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * The actual fix for "the preview is too small to see the difference": a
 * true full-screen view of one dataset pair, reusing [BeforeAfterSlider] so
 * dragging across the boundary compares the two images directly at a real
 * size - degradation that's invisible in a 72dp list thumbnail (blur,
 * noise, mild JPEG blocking) is generally obvious once you can drag back
 * and forth across it at screen size.
 *
 * Decodes both images at up to ~1080px on the longest side (not full
 * original resolution, not thumbnail-tiny) - large enough that subtle
 * degradation is visible, bounded so a giant source photo can't blow up
 * memory just for a comparison view.
 */
@Composable
fun PairPreviewDialog(
    lowQualityPath: String,
    highQualityPath: String,
    subtitle: String,
    onDismiss: () -> Unit
) {
    var lowBitmap by remember(lowQualityPath) { mutableStateOf<Bitmap?>(null) }
    var highBitmap by remember(highQualityPath) { mutableStateOf<Bitmap?>(null) }
    var failed by remember(lowQualityPath, highQualityPath) { mutableStateOf(false) }

    LaunchedEffect(lowQualityPath, highQualityPath) {
        val (low, high) = withContext(Dispatchers.IO) {
            decodeSampledBitmap(lowQualityPath, targetSizePx = 1080) to
                decodeSampledBitmap(highQualityPath, targetSizePx = 1080)
        }
        if (low == null || high == null) {
            failed = true
        } else {
            lowBitmap = low
            highBitmap = high
        }
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(modifier = Modifier.fillMaxSize()) {
            Column(modifier = Modifier.fillMaxSize()) {
                TopAppBar(
                    title = { Text("Drag to compare") },
                    navigationIcon = {
                        IconButton(onClick = onDismiss) {
                            Icon(painterResource(R.drawable.ic_back_arrow), contentDescription = "Close")
                        }
                    }
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )

                Box(modifier = Modifier.fillMaxSize().padding(16.dp), contentAlignment = Alignment.Center) {
                    val low = lowBitmap
                    val high = highBitmap
                    when {
                        low != null && high != null -> BeforeAfterSlider(
                            original = low,
                            enhanced = high,
                            modifier = Modifier.fillMaxSize()
                        )
                        failed -> Text(
                            "Couldn't load one or both images for this pair.",
                            color = MaterialTheme.colorScheme.error
                        )
                        else -> CircularProgressIndicator()
                    }
                }
            }
        }
    }
}
