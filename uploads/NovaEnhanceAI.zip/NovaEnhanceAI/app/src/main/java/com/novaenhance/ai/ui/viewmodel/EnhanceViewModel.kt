package com.novaenhance.ai.ui.viewmodel

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.novaenhance.ai.ai.engine.EnhancementEngine
import com.novaenhance.ai.ai.engine.EnhancementOptions
import com.novaenhance.ai.ai.model.ModelRepository
import com.novaenhance.ai.database.dao.ModelDao
import com.novaenhance.ai.storage.AppStorage
import com.novaenhance.ai.utils.NovaLog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private const val TAG = "EnhanceViewModel"

data class EnhanceUiState(
    val originalBitmap: Bitmap? = null,
    val enhancedBitmap: Bitmap? = null,
    val options: EnhancementOptions = EnhancementOptions(),
    val isProcessing: Boolean = false,
    val progressFraction: Float = 0f,
    val savedFile: File? = null,
    val errorMessage: String? = null
)

class EnhanceViewModel(
    private val appContext: Context,
    private val modelDao: ModelDao,
    private val modelRepository: ModelRepository,
    private val storage: AppStorage
) : ViewModel() {

    private val _uiState = MutableStateFlow(EnhanceUiState())
    val uiState: StateFlow<EnhanceUiState> = _uiState.asStateFlow()

    fun onImageSelected(uri: Uri) {
        viewModelScope.launch {
            val bitmap = withContext(Dispatchers.IO) {
                appContext.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
            }
            if (bitmap == null) {
                _uiState.value = _uiState.value.copy(errorMessage = "Could not open that image")
                return@launch
            }
            _uiState.value = EnhanceUiState(originalBitmap = bitmap, options = _uiState.value.options)
            runEnhancement()
        }
    }

    fun onOptionsChanged(options: EnhancementOptions) {
        _uiState.value = _uiState.value.copy(options = options)
        runEnhancement()
    }

    fun runEnhancement() {
        val original = _uiState.value.originalBitmap ?: return
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isProcessing = true, progressFraction = 0f, errorMessage = null)
            try {
                val activeModel = modelDao.getActive()
                if (activeModel == null) {
                    _uiState.value = _uiState.value.copy(isProcessing = false, errorMessage = "No AI model available yet")
                    return@launch
                }
                val engine = modelRepository.getEngine(activeModel.id)
                val enhancer = EnhancementEngine(engine)
                val options = _uiState.value.options

                val result = withContext(Dispatchers.Default) {
                    enhancer.enhance(original, options) { progress ->
                        _uiState.value = _uiState.value.copy(progressFraction = progress.fraction)
                    }
                }
                _uiState.value = _uiState.value.copy(enhancedBitmap = result, isProcessing = false, progressFraction = 1f)
            } catch (t: Throwable) {
                NovaLog.w(TAG, "Enhancement failed", t)
                _uiState.value = _uiState.value.copy(isProcessing = false, errorMessage = "Enhancement failed: ${t.message}")
            }
        }
    }

    fun saveResult() {
        val enhanced = _uiState.value.enhancedBitmap ?: return
        viewModelScope.launch {
            val file = withContext(Dispatchers.IO) {
                val dest = File(storage.enhancedOutputDir(), "enhanced_${System.currentTimeMillis()}.jpg")
                dest.outputStream().use { enhanced.compress(Bitmap.CompressFormat.JPEG, 95, it) }
                dest
            }
            _uiState.value = _uiState.value.copy(savedFile = file)
        }
    }

    override fun onCleared() {
        super.onCleared()
        // Bitmaps aren't Compose state we can rely on recomposition to clean
        // up - recycle explicitly so a large photo doesn't linger past this
        // screen's lifecycle on a memory-constrained device.
        _uiState.value.originalBitmap?.recycle()
        _uiState.value.enhancedBitmap?.recycle()
    }
}
