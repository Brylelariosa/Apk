package com.novaenhance.ai.training.trainer

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.novaenhance.ai.ai.engine.BitmapSimilarity
import com.novaenhance.ai.ai.engine.EnhancementEngine
import com.novaenhance.ai.ai.engine.EnhancementOptions
import com.novaenhance.ai.ai.model.ModelRepository
import com.novaenhance.ai.database.dao.DatasetPairDao
import com.novaenhance.ai.database.entities.DatasetPairEntity
import com.novaenhance.ai.database.entities.TrainingSessionEntity
import com.novaenhance.ai.database.entities.TrainingStatus
import com.novaenhance.ai.utils.NovaLog

private const val TAG = "SelfImprovementLoop"
private const val RESCORE_SAMPLE_SIZE = 50

/**
 * Ties the full "Self Improvement Loop" together:
 *
 *     Collect Training Data -> Train -> Evaluate -> Find Weak Areas
 *         -> Prioritize Similar Data -> Improve Again
 *
 * "Collect -> Train -> Evaluate" is [ModelTrainer.runSession] (dataset
 * analysis gate, adaptive planning, the batch loop, and validation-gated
 * promotion). This class adds the last two steps: after a session is
 * promoted, it re-runs the *newly active* model over a sample of the
 * remaining dataset and re-scores each pair's difficulty by how far the
 * model's own current output still is from the target. Pairs the model
 * still struggles with get a HIGHER difficulty score, so the next call to
 * [com.novaenhance.ai.database.dao.DatasetPairDao.getUsablePairsByDifficulty]
 * automatically surfaces them first - "prioritize similar data" without
 * needing a separate content-clustering system, since perceptual
 * difficulty (not just visual similarity) is exactly what should drive
 * priority.
 */
class SelfImprovementOrchestrator(
    private val modelTrainer: ModelTrainer,
    private val modelRepository: ModelRepository,
    private val datasetPairDao: DatasetPairDao
) {

    suspend fun runCycle(modelId: String, resumeSessionId: Long?, control: TrainingControlFlow): TrainingSessionEntity {
        val session = modelTrainer.runSession(modelId, resumeSessionId, control)
        if (session.status == TrainingStatus.COMPLETED && session.wasPromoted) {
            runCatching { rescoreWeakAreas(modelId) }
                .onFailure { NovaLog.w(TAG, "Weak-area rescoring failed (non-fatal, training result is unaffected)", it) }
        }
        return session
    }

    private suspend fun rescoreWeakAreas(modelId: String) {
        val engine = modelRepository.getEngine(modelId)
        val enhancer = EnhancementEngine(engine)
        val neutralOptions = EnhancementOptions(strength = 1f, sharpness = 0f, noiseReduction = 0f, colorRestoration = 0f)

        // Bounded sample, not the whole dataset - this runs after every
        // promoted session, and re-inferring the entire dataset each time
        // would grow unbounded as it accumulates.
        val sample = datasetPairDao.getUsablePairs(modelId).shuffled().take(RESCORE_SAMPLE_SIZE)
        val updated = mutableListOf<DatasetPairEntity>()

        for (pair in sample) {
            val lowBitmap = decodeBitmap(pair.lowQualityPath) ?: continue
            val targetBitmap = decodeBitmap(pair.highQualityPath) ?: run { lowBitmap.recycle(); continue }

            try {
                val enhanced = enhancer.enhance(lowBitmap, neutralOptions)
                val similarity = BitmapSimilarity.quickSimilarity(enhanced, targetBitmap)
                enhanced.recycle()
                // Still far from the target even after the model's own best
                // effort -> a genuine weak area, not just "started out hard."
                updated += pair.copy(difficultyScore = (1f - similarity).coerceIn(0f, 1f))
            } finally {
                lowBitmap.recycle()
                targetBitmap.recycle()
            }
        }

        if (updated.isNotEmpty()) {
            datasetPairDao.updateAll(updated)
            NovaLog.i(TAG, "Re-scored ${updated.size} pairs for $modelId based on current model performance")
        }
    }

    private fun decodeBitmap(path: String): Bitmap? = try {
        BitmapFactory.decodeFile(path)
    } catch (t: Throwable) {
        null
    }
}
