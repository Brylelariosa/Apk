package com.novaenhance.ai.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.novaenhance.ai.ui.viewmodel.ModelManagerViewModel
import com.novaenhance.ai.ui.viewmodel.NovaViewModelFactory
import java.text.DateFormat
import java.util.Date

@Composable
fun ModelManagerScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val viewModel: ModelManagerViewModel = viewModel(factory = NovaViewModelFactory(context))
    val state by viewModel.uiState.collectAsState()

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { viewModel.importModel(it, "Imported Model") }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Model Manager") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") } }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            OutlinedButton(
                onClick = { importLauncher.launch("*/*") },
                modifier = Modifier.fillMaxWidth().padding(16.dp)
            ) {
                Text("Import Model")
            }

            LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp)) {
                items(state.models, key = { it.id }) { model ->
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (model.id == state.selectedModelId) {
                                MaterialTheme.colorScheme.primaryContainer
                            } else {
                                MaterialTheme.colorScheme.surfaceVariant
                            }
                        ),
                        onClick = { viewModel.selectModel(model.id) }
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(model.displayName, style = MaterialTheme.typography.titleMedium)
                                if (model.isActive) Text("Active", style = MaterialTheme.typography.labelSmall)
                            }
                            Text(
                                "v${model.currentVersionNumber} - ${model.trainingSessionCount} sessions - ${model.totalImagesLearned} images learned",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                if (!model.isActive) {
                                    Button(onClick = { viewModel.switchActive(model.id) }) { Text("Switch") }
                                }
                                OutlinedButton(onClick = { viewModel.deleteModel(model.id) }) { Text("Delete") }
                            }

                            if (model.id == state.selectedModelId) {
                                Text(
                                    "Version history",
                                    style = MaterialTheme.typography.labelLarge,
                                    modifier = Modifier.padding(top = 8.dp)
                                )
                                state.versionsForSelected.forEach { version ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column {
                                            Text(
                                                "v${version.versionNumber}${if (version.isActive) " (active)" else ""}",
                                                style = MaterialTheme.typography.bodyMedium
                                            )
                                            Text(
                                                DateFormat.getDateInstance().format(Date(version.createdAt)),
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                            if (!version.isActive) {
                                                OutlinedButton(onClick = { viewModel.restoreVersion(model.id, version.id) }) {
                                                    Text("Restore")
                                                }
                                                OutlinedButton(onClick = { viewModel.deleteVersion(version.id) }) {
                                                    Text("Delete")
                                                }
                                            }
                                            OutlinedButton(onClick = { viewModel.backupVersion(version.id) }) { Text("Backup") }
                                            OutlinedButton(onClick = { viewModel.exportVersion(version.id) }) { Text("Export") }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
