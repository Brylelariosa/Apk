package com.novaenhance.ai.ai.inference

import com.novaenhance.ai.utils.NovaLog
import org.tensorflow.lite.Interpreter
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.charset.StandardCharsets

private const val TAG = "TFLiteSignatureRunner"

/**
 * Thin, typed wrapper over [org.tensorflow.lite.Interpreter.runSignature] for
 * the exact signature contract exported by
 * `tools/model_builder/build_model.py` (see that file's docstring for the
 * full tensor shape/name contract). This class knows nothing about tiling,
 * bitmaps, or training strategy - it only knows how to marshal Kotlin types
 * to/from the five named signatures. Higher-level orchestration lives in
 * [com.novaenhance.ai.ai.engine.TFLiteEngine].
 *
 * HIGHEST-RISK SPOT: the "save"/"restore" signatures take a scalar string
 * tensor (the checkpoint path). TFLite's Java API represents a scalar
 * DT_STRING tensor's buffer as the raw UTF-8 bytes of that single string
 * (no length-prefix table needed, since a length table is only required for
 * tensors with more than one string element). This is the one part of this
 * bridge that most needs an early real-device smoke test - everywhere else
 * uses plain float32 tensors via direct ByteBuffers, which is unambiguous.
 */
class TFLiteSignatureRunner(modelFile: File, numThreads: Int) : AutoCloseable {

    private val interpreter: Interpreter

    init {
        val options = Interpreter.Options().apply {
            setNumThreads(numThreads.coerceIn(1, 4))
            // Custom train/save/restore ops are CPU (Flex-delegate) ops; we
            // deliberately do NOT attach GPU/NNAPI delegates here since
            // those accelerate builtin ops only and the training graph would
            // otherwise silently fall back per-op anyway. Inference-only
            // "infer" calls could use a delegate in a future optimization
            // pass once profiling shows it's worth the added complexity.
        }
        interpreter = Interpreter(modelFile, options)
    }

    /** Runs one forward pass. `inputBuffer` must be a direct, native-order float32 buffer already sized/rewound. */
    fun infer(inputBuffer: ByteBuffer): ByteBuffer {
        val outputBuffer = ByteBuffer
            .allocateDirect(inputBuffer.capacity())
            .order(ByteOrder.nativeOrder())
        interpreter.runSignature(
            mapOf("input_image" to inputBuffer),
            mapOf("output_image" to outputBuffer),
            "infer"
        )
        outputBuffer.rewind()
        return outputBuffer
    }

    /** Runs one optimizer step over a batch; returns the scalar loss. */
    fun trainStep(
        lqBatch: ByteBuffer,
        hqBatch: ByteBuffer,
        learningRate: Float,
        l2SpLambda: Float
    ): Float {
        val lrBuffer = floatScalarBuffer(learningRate)
        val lambdaBuffer = floatScalarBuffer(l2SpLambda)
        val lossBuffer = ByteBuffer.allocateDirect(4).order(ByteOrder.nativeOrder())

        interpreter.runSignature(
            mapOf(
                "lq_batch" to lqBatch,
                "hq_batch" to hqBatch,
                "learning_rate" to lrBuffer,
                "l2_sp_lambda" to lambdaBuffer
            ),
            mapOf("loss" to lossBuffer),
            "train"
        )
        lossBuffer.rewind()
        return lossBuffer.float
    }

    /** Copies current trainable weights into the anchor variables used by L2-SP anti-forgetting. */
    fun setAnchor() {
        val triggerBuffer = ByteBuffer.allocateDirect(4).order(ByteOrder.nativeOrder()).apply { putInt(0); rewind() }
        val successBuffer = ByteBuffer.allocateDirect(1).order(ByteOrder.nativeOrder())
        interpreter.runSignature(
            mapOf("trigger" to triggerBuffer),
            mapOf("success" to successBuffer),
            "set_anchor"
        )
    }

    fun save(checkpointPathPrefix: String): String {
        val inputBytes = stringScalarBuffer(checkpointPathPrefix)
        // Output size is unknown ahead of time (TF may append a suffix);
        // over-allocate generously and trim trailing zero bytes.
        val outputBytes = ByteBuffer.allocateDirect(4096)
        interpreter.runSignature(
            mapOf("checkpoint_path" to inputBytes),
            mapOf("checkpoint_path" to outputBytes),
            "save"
        )
        return decodeStringScalar(outputBytes)
    }

    fun restore(checkpointPathPrefix: String) {
        val inputBytes = stringScalarBuffer(checkpointPathPrefix)
        val outputBytes = ByteBuffer.allocateDirect(4096)
        interpreter.runSignature(
            mapOf("checkpoint_path" to inputBytes),
            mapOf("checkpoint_path" to outputBytes),
            "restore"
        )
    }

    override fun close() {
        try {
            interpreter.close()
        } catch (t: Throwable) {
            NovaLog.w(TAG, "Error closing interpreter", t)
        }
    }

    private fun floatScalarBuffer(value: Float): ByteBuffer =
        ByteBuffer.allocateDirect(4).order(ByteOrder.nativeOrder()).apply { putFloat(value); rewind() }

    private fun stringScalarBuffer(value: String): ByteBuffer {
        val bytes = value.toByteArray(StandardCharsets.UTF_8)
        return ByteBuffer.allocateDirect(bytes.size).order(ByteOrder.nativeOrder()).apply {
            put(bytes)
            rewind()
        }
    }

    private fun decodeStringScalar(buffer: ByteBuffer): String {
        buffer.rewind()
        val bytes = ByteArray(buffer.remaining())
        buffer.get(bytes)
        // Trim trailing NUL padding from the over-allocated output buffer.
        val trimmed = bytes.takeWhile { it.toInt() != 0 }.toByteArray()
        return String(trimmed, StandardCharsets.UTF_8)
    }
}
