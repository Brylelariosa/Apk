package com.novaenhance.ai.ai.engine

import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Bridges [com.novaenhance.ai.ai.engine.TileProcessor]'s ARGB_8888 IntArray
 * tiles and the normalized (0-1) float32 NHWC tensors the model expects.
 * Kept separate from [com.novaenhance.ai.ai.inference.TFLiteSignatureRunner]
 * so the tensor-encoding concern doesn't leak into the signature-calling
 * concern, and so training (which needs to *batch* many tiles into one
 * buffer) and inference (always exactly one tile) can share this code.
 */
object TensorImageCodec {

    /** Encodes a single ARGB tile as a `[1, size, size, 3]` float32 buffer in `[0,1]`. */
    fun encodeSingle(pixels: IntArray, size: Int): ByteBuffer {
        val buffer = ByteBuffer
            .allocateDirect(4 * size * size * 3)
            .order(ByteOrder.nativeOrder())
        writeTile(buffer, pixels)
        buffer.rewind()
        return buffer
    }

    /** Encodes a batch of same-size ARGB tiles as a `[batch, size, size, 3]` float32 buffer. */
    fun encodeBatch(tiles: List<IntArray>, size: Int): ByteBuffer {
        val buffer = ByteBuffer
            .allocateDirect(4 * size * size * 3 * tiles.size)
            .order(ByteOrder.nativeOrder())
        for (tile in tiles) writeTile(buffer, tile)
        buffer.rewind()
        return buffer
    }

    /** Decodes a `[1, size, size, 3]` (or a single tile's worth of) float32 buffer back to ARGB pixels. */
    fun decodeSingle(buffer: ByteBuffer, size: Int): IntArray {
        buffer.rewind()
        val pixels = IntArray(size * size)
        for (i in pixels.indices) {
            // Round rather than truncate: this decodes the MODEL'S raw
            // output (not just re-decoding what encodeSingle wrote), and an
            // arbitrary float like 0.4999997 truncating to 127 instead of
            // rounding to 128 would introduce a small systematic darkening
            // bias across every pixel, every tile.
            val r = kotlin.math.round(buffer.float.coerceIn(0f, 1f) * 255f).toInt()
            val g = kotlin.math.round(buffer.float.coerceIn(0f, 1f) * 255f).toInt()
            val b = kotlin.math.round(buffer.float.coerceIn(0f, 1f) * 255f).toInt()
            pixels[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
        }
        return pixels
    }

    private fun writeTile(buffer: ByteBuffer, pixels: IntArray) {
        for (pixel in pixels) {
            val r = ((pixel shr 16) and 0xFF) / 255f
            val g = ((pixel shr 8) and 0xFF) / 255f
            val b = (pixel and 0xFF) / 255f
            buffer.putFloat(r)
            buffer.putFloat(g)
            buffer.putFloat(b)
        }
    }
}
