package com.novaenhance.ai.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.novaenhance.ai.storage.AppSettings
import com.novaenhance.ai.storage.SettingsRepository
import com.novaenhance.ai.storage.ThemePreference
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(private val settingsRepository: SettingsRepository) : ViewModel() {

    val settings: StateFlow<AppSettings> = settingsRepository.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppSettings())

    fun setTheme(theme: ThemePreference) = viewModelScope.launch { settingsRepository.setTheme(theme) }
    fun setTrainOnlyWhileCharging(enabled: Boolean) = viewModelScope.launch { settingsRepository.setTrainOnlyWhileCharging(enabled) }
    fun setThermalProtectionEnabled(enabled: Boolean) = viewModelScope.launch { settingsRepository.setThermalProtectionEnabled(enabled) }
    fun setLowRamModeEnabled(enabled: Boolean) = viewModelScope.launch { settingsRepository.setLowRamModeEnabled(enabled) }
}
