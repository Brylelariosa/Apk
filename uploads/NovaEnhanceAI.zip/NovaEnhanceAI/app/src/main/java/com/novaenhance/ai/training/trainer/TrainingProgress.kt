package com.novaenhance.ai.training.trainer

import com.novaenhance.ai.database.entities.TrainingStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Live snapshot for the Train AI screen: epoch, current pair, progress, loss, speed, ETA, memory. */
data class TrainingProgressState(
    val sessionId: Long,
    val epoch: Int,
    val totalEpochs: Int,
    val batchIndex: Int,
    val totalBatches: Int,
    val latestLoss: Float?,
    val imagesPerSecond: Float,
    val estimatedSecondsRemaining: Long,
    val memoryUsedMb: Long,
    val status: TrainingStatus
)

enum class TrainingCommand { RUN, PAUSE, CANCEL }

/**
 * The pause/resume/cancel channel between whatever is driving the UI
 * (Train AI screen buttons, or a notification action on the foreground
 * service) and [ModelTrainer]'s batch loop, which polls [command] between
 * batches - never mid-batch, so a pause/cancel always lands on a clean
 * checkpoint-safe boundary.
 */
class TrainingControlFlow {
    private val _command = MutableStateFlow(TrainingCommand.RUN)
    val command: StateFlow<TrainingCommand> = _command.asStateFlow()

    fun resume() { _command.value = TrainingCommand.RUN }
    fun pause() { _command.value = TrainingCommand.PAUSE }
    fun cancel() { _command.value = TrainingCommand.CANCEL }
}
