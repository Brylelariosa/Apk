package com.novaenhance.ai.ai.model

import org.json.JSONObject
import java.io.File

/**
 * Metadata describing a `.tflite` model file, read from the `.json` sidecar
 * written next to it (by [tools/model_builder/build_model.py] for the
 * initial model, or by [com.novaenhance.ai.training.checkpoint.CheckpointManager]
 * whenever a new version is promoted). TFLite's public Java API doesn't
 * expose a clean "how many parameters does this graph have" query for
 * arbitrary custom-training graphs, so this metadata is tracked
 * side-by-side instead of introspected from the model at load time.
 */
data class ModelMetadata(
    val modelName: String,
    val architecture: String,
    val tileSize: Int,
    val channels: Int,
    val residualBlocks: Int,
    val parameterCount: Long,
    val versionNumber: Int,
    val signatures: List<String>
) {
    companion object {
        fun fromFile(jsonFile: File): ModelMetadata {
            val json = JSONObject(jsonFile.readText())
            val signaturesArray = json.getJSONArray("signatures")
            val signatures = (0 until signaturesArray.length()).map { signaturesArray.getString(it) }
            return ModelMetadata(
                modelName = json.getString("modelName"),
                architecture = json.getString("architecture"),
                tileSize = json.getInt("tileSize"),
                channels = json.getInt("channels"),
                residualBlocks = json.getInt("residualBlocks"),
                parameterCount = json.getLong("parameterCount"),
                versionNumber = json.getInt("versionNumber"),
                signatures = signatures
            )
        }

        /** Sidecar path convention: `foo.tflite` <-> `foo.json`. */
        fun sidecarFor(tfliteFile: File): File =
            File(tfliteFile.parentFile, tfliteFile.nameWithoutExtension + ".json")
    }

    fun toJson(): String {
        val json = JSONObject()
        json.put("modelName", modelName)
        json.put("architecture", architecture)
        json.put("tileSize", tileSize)
        json.put("channels", channels)
        json.put("residualBlocks", residualBlocks)
        json.put("parameterCount", parameterCount)
        json.put("versionNumber", versionNumber)
        json.put("signatures", signatures)
        return json.toString(2)
    }
}
