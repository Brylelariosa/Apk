package com.novaenhance.ai.ui.screens

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.IconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import com.novaenhance.ai.ui.components.BeforeAfterSlider
import com.novaenhance.ai.ui.components.LabeledSlider
import com.novaenhance.ai.ui.viewmodel.EnhanceViewModel
import com.novaenhance.ai.ui.viewmodel.NovaViewModelFactory
import java.io.File

@Composable
fun EnhanceScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val viewModel: EnhanceViewModel = viewModel(factory = NovaViewModelFactory(context))
    val state by viewModel.uiState.collectAsState()

    val pickImageLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { viewModel.onImageSelected(it) }
    }

    var pendingCaptureFile by remember { mutableStateOf<File?>(null) }
    val captureLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        if (success) {
            pendingCaptureFile?.let { file ->
                val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                viewModel.onImageSelected(uri)
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Enhance Image") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (state.originalBitmap == null) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(onClick = { pickImageLauncher.launch("image/*") }, modifier = Modifier.fillMaxWidth()) {
                        Text("Select Image")
                    }
                    OutlinedButton(
                        onClick = {
                            val file = File(context.cacheDir, "capture_${System.currentTimeMillis()}.jpg")
                            pendingCaptureFile = file
                            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                            captureLauncher.launch(uri)
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Capture Image")
                    }
                }
            } else {
                Box(modifier = Modifier.fillMaxWidth().height(360.dp)) {
                    if (state.enhancedBitmap != null) {
                        BeforeAfterSlider(
                            original = state.originalBitmap!!,
                            enhanced = state.enhancedBitmap!!,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    if (state.isProcessing) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(progress = { state.progressFraction })
                        }
                    }
                }

                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    LabeledSlider("Enhancement strength", state.options.strength) {
                        viewModel.onOptionsChanged(state.options.copy(strength = it))
                    }
                    LabeledSlider("Sharpness", state.options.sharpness) {
                        viewModel.onOptionsChanged(state.options.copy(sharpness = it))
                    }
                    LabeledSlider("Noise reduction", state.options.noiseReduction) {
                        viewModel.onOptionsChanged(state.options.copy(noiseReduction = it))
                    }
                    LabeledSlider("Color restoration", state.options.colorRestoration) {
                        viewModel.onOptionsChanged(state.options.copy(colorRestoration = it))
                    }
                    Text("Upscaling", style = MaterialTheme.typography.bodyMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(1, 2, 4).forEach { factor ->
                            val selected = state.options.upscaleFactor == factor
                            OutlinedButton(onClick = { viewModel.onOptionsChanged(state.options.copy(upscaleFactor = factor)) }) {
                                Text(if (selected) "[${factor}x]" else "${factor}x")
                            }
                        }
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { viewModel.saveResult() }, modifier = Modifier.weight(1f)) { Text("Save") }
                    OutlinedButton(
                        onClick = {
                            state.savedFile?.let { file ->
                                val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                                val intent = Intent(Intent.ACTION_SEND).apply {
                                    type = "image/jpeg"
                                    putExtra(Intent.EXTRA_STREAM, uri)
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                context.startActivity(Intent.createChooser(intent, "Share enhanced image"))
                            }
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text("Share") }
                }
            }

            state.errorMessage?.let {
                Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}
