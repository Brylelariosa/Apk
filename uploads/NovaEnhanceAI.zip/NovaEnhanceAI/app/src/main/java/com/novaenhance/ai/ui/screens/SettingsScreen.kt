package com.novaenhance.ai.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.novaenhance.ai.storage.ThemePreference
import com.novaenhance.ai.ui.viewmodel.NovaViewModelFactory
import com.novaenhance.ai.ui.viewmodel.SettingsViewModel

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val viewModel: SettingsViewModel = viewModel(factory = NovaViewModelFactory(context))
    val settings by viewModel.settings.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") } }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Appearance", style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ThemePreference.entries.forEach { theme ->
                        val selected = settings.theme == theme
                        androidx.compose.material3.FilterChip(
                            selected = selected,
                            onClick = { viewModel.setTheme(theme) },
                            label = { Text(theme.name.lowercase().replaceFirstChar { it.uppercase() }) }
                        )
                    }
                }
            }

            SettingRow(
                title = "Train only while charging",
                subtitle = "Delays training until the device is plugged in",
                checked = settings.trainOnlyWhileCharging,
                onCheckedChange = { viewModel.setTrainOnlyWhileCharging(it) }
            )

            SettingRow(
                title = "Thermal protection",
                subtitle = "Automatically pauses training if the device gets too hot",
                checked = settings.thermalProtectionEnabled,
                onCheckedChange = { viewModel.setThermalProtectionEnabled(it) }
            )

            SettingRow(
                title = "Low RAM mode",
                subtitle = "Uses smaller batches and tiles to reduce memory use",
                checked = settings.lowRamModeEnabled,
                onCheckedChange = { viewModel.setLowRamModeEnabled(it) }
            )

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("CPU threads for AI inference/training", style = MaterialTheme.typography.titleMedium)
                Text(
                    "Auto leaves one core free for image processing that runs alongside it",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0, 1, 2, 4).forEach { limit ->
                        val selected = settings.cpuThreadLimit == limit
                        androidx.compose.material3.FilterChip(
                            selected = selected,
                            onClick = { viewModel.setCpuThreadLimit(limit) },
                            label = { Text(if (limit == 0) "Auto" else limit.toString()) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
