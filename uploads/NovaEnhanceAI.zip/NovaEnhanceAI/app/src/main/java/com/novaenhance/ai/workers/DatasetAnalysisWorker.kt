package com.novaenhance.ai.workers

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.Data
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.novaenhance.ai.di.ServiceLocator
import com.novaenhance.ai.utils.Constants
import com.novaenhance.ai.utils.NovaLog

private const val TAG = "DatasetAnalysisWorker"
private const val KEY_MODEL_ID = "modelId"

/**
 * Runs [com.novaenhance.ai.training.dataset.DatasetAnalyzer] for a model
 * under WorkManager rather than a plain coroutine, so a large bulk dataset
 * import (many pairs needing duplicate/quality/difficulty scoring) survives
 * the app process dying mid-analysis instead of silently leaving pairs
 * stuck "unanalyzed" forever.
 */
class DatasetAnalysisWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val modelId = inputData.getString(KEY_MODEL_ID) ?: return Result.failure()
        return try {
            val analyzer = ServiceLocator.get(applicationContext).datasetAnalyzer
            val count = analyzer.analyzeNewPairs(modelId)
            NovaLog.i(TAG, "Analyzed $count pairs for $modelId")
            Result.success()
        } catch (t: Throwable) {
            NovaLog.w(TAG, "Dataset analysis failed for $modelId", t)
            Result.retry()
        }
    }

    companion object {
        fun enqueue(context: Context, modelId: String) {
            val request = OneTimeWorkRequestBuilder<DatasetAnalysisWorker>()
                .setInputData(Data.Builder().putString(KEY_MODEL_ID, modelId).build())
                .build()
            WorkManager.getInstance(context).enqueueUniqueWork(
                "${Constants.WORK_NAME_DATASET_ANALYSIS}_$modelId",
                ExistingWorkPolicy.APPEND_OR_REPLACE,
                request
            )
        }
    }
}
