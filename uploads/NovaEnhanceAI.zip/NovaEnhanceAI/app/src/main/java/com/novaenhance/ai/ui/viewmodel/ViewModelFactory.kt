package com.novaenhance.ai.ui.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.CreationExtras
import com.novaenhance.ai.di.ServiceLocator

/**
 * One small factory for every screen's ViewModel, since this project uses
 * manual DI ([ServiceLocator]) rather than Hilt's generated
 * `@HiltViewModel` factories. Each `create()` branch is a plain constructor
 * call reading from the same [ServiceLocator] singleton - see that class's
 * doc comment for why manual DI was chosen for this app.
 */
class NovaViewModelFactory(private val appContext: Context) : ViewModelProvider.Factory {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>, extras: CreationExtras): T {
        val locator = ServiceLocator.get(appContext)
        return when (modelClass) {
            DashboardViewModel::class.java -> DashboardViewModel(
                locator.database.modelDao(), locator.database.trainingSessionDao()
            )
            EnhanceViewModel::class.java -> EnhanceViewModel(
                appContext, locator.modelRepository, locator.storage
            )
            TrainingViewModel::class.java -> TrainingViewModel(
                appContext, locator.database.modelDao(), locator.modelRepository, locator.database.trainingSessionDao(),
                locator.database.lossHistoryDao(), locator.database.validationMetricDao(),
                locator.modelTrainer, locator.trainingControlFlow, locator.settingsRepository,
                locator.datasetManager, locator.database.datasetPairDao()
            )
            DatasetViewModel::class.java -> DatasetViewModel(
                appContext, locator.database.modelDao(), locator.modelRepository, locator.datasetManager
            )
            ModelManagerViewModel::class.java -> ModelManagerViewModel(
                appContext, locator.database.modelDao(), locator.database.modelVersionDao(), locator.modelRepository
            )
            SettingsViewModel::class.java -> SettingsViewModel(locator.settingsRepository)
            else -> error("Unknown ViewModel class: $modelClass")
        } as T
    }
}
