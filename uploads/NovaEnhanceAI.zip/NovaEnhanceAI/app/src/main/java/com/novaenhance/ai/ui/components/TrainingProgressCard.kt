package com.novaenhance.ai.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import com.novaenhance.ai.training.trainer.TrainingProgressState

@Composable
fun TrainingProgressCard(state: TrainingProgressState, modifier: Modifier = Modifier) {
    Card(modifier = modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "Epoch ${state.epoch + 1} / ${state.totalEpochs}",
                style = MaterialTheme.typography.titleMedium
            )
            Spacer(modifier = Modifier.height(4.dp))
            LinearProgressIndicator(
                progress = { if (state.totalBatches > 0) state.batchIndex.toFloat() / state.totalBatches else 0f },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))

            val monoStyle = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace)
            Text(text = "Batch ${state.batchIndex + 1} / ${state.totalBatches}", style = monoStyle)
            Text(text = "Loss: ${state.latestLoss?.let { "%.4f".format(it) } ?: "-"}", style = monoStyle)
            Text(text = "Speed: ${"%.1f".format(state.imagesPerSecond)} img/s", style = monoStyle)
            Text(
                text = "ETA: ${if (state.estimatedSecondsRemaining >= 0) formatEta(state.estimatedSecondsRemaining) else "calculating..."}",
                style = monoStyle
            )
            Text(text = "Memory: ${state.memoryUsedMb} MB", style = monoStyle)
        }
    }
}

private fun formatEta(seconds: Long): String {
    val m = seconds / 60
    val s = seconds % 60
    return "${m}m ${s}s"
}
