package com.novaenhance.ai.ai.engine

import com.novaenhance.ai.ai.inference.TFLiteSignatureRunner
import com.novaenhance.ai.ai.model.ModelMetadata
import com.novaenhance.ai.utils.NovaLog
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.Executors

private const val TAG = "TFLiteEngine"

/**
 * Owns one loaded model's [TFLiteSignatureRunner] and confines every call to
 * it onto a single dedicated thread. `Interpreter` is not thread-safe for
 * concurrent invocation, and inference (from the Enhance screen) and
 * training (from the foreground service) can in principle be requested from
 * different coroutines - this dispatcher is what actually serializes them,
 * rather than relying on callers to remember to synchronize.
 *
 * One [TFLiteEngine] instance corresponds to one *loaded* model version; the
 * caller (see [com.novaenhance.ai.ai.model.ModelRepository]) is responsible
 * for closing the old engine and creating a new one when switching models or
 * promoting a new version.
 */
class TFLiteEngine(
    private val modelFile: File,
    val metadata: ModelMetadata,
    interpreterThreadCount: Int
) : AutoCloseable {

    private val dispatcher = Executors.newSingleThreadExecutor { r ->
        Thread(r, "novaenhance-tflite").apply { priority = Thread.NORM_PRIORITY - 1 }
    }.asCoroutineDispatcher()

    private val runner: TFLiteSignatureRunner = TFLiteSignatureRunner(modelFile, interpreterThreadCount.coerceAtLeast(1))

    val tileSize: Int get() = metadata.tileSize

    suspend fun inferTile(pixels: IntArray): IntArray = withContext(dispatcher) {
        val input = TensorImageCodec.encodeSingle(pixels, tileSize)
        val output = runner.infer(input)
        TensorImageCodec.decodeSingle(output, tileSize)
    }

    /**
     * Runs one training step over a batch of (low-quality, high-quality)
     * tile pairs and returns the loss. `l2SpLambda` is 0 to disable the
     * anti-forgetting penalty entirely (e.g. the very first training session
     * on a brand-new model, where there is nothing yet to protect).
     */
    suspend fun trainBatch(
        lowQualityTiles: List<IntArray>,
        highQualityTiles: List<IntArray>,
        learningRate: Float,
        l2SpLambda: Float
    ): Float = withContext(dispatcher) {
        require(lowQualityTiles.size == highQualityTiles.size) {
            "Batch size mismatch: ${lowQualityTiles.size} low-quality vs ${highQualityTiles.size} high-quality tiles"
        }
        val lqBuffer = TensorImageCodec.encodeBatch(lowQualityTiles, tileSize)
        val hqBuffer = TensorImageCodec.encodeBatch(highQualityTiles, tileSize)
        runner.trainStep(lqBuffer, hqBuffer, learningRate, l2SpLambda)
    }

    /** Snapshots current weights as the anti-forgetting anchor. Call once per session, before any [trainBatch]. */
    suspend fun setAnchor() = withContext(dispatcher) {
        runner.setAnchor()
    }

    suspend fun saveCheckpoint(checkpointPathPrefix: String): String = withContext(dispatcher) {
        runner.save(checkpointPathPrefix)
    }

    suspend fun restoreCheckpoint(checkpointPathPrefix: String) = withContext(dispatcher) {
        runner.restore(checkpointPathPrefix)
    }

    override fun close() {
        try {
            runner.close()
        } catch (t: Throwable) {
            NovaLog.w(TAG, "Error closing signature runner", t)
        } finally {
            dispatcher.close()
        }
    }
}
