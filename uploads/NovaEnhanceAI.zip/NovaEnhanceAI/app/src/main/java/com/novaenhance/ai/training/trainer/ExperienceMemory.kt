package com.novaenhance.ai.training.trainer

import com.novaenhance.ai.database.dao.ReplayBufferDao
import com.novaenhance.ai.database.entities.DatasetPairEntity
import com.novaenhance.ai.database.entities.ReplayBufferEntity
import com.novaenhance.ai.storage.AppStorage
import com.novaenhance.ai.utils.Constants
import java.io.File
import java.util.UUID

/**
 * "Experience Memory System" + the data half of the "Anti-Forgetting
 * System" (the other half - L2-SP regularization toward an anchor snapshot
 * of weights - lives in the model itself; see build_model.py and
 * [com.novaenhance.ai.ai.engine.TFLiteEngine.setAnchor]).
 *
 * This is a rehearsal/replay buffer: a small, curated set of past training
 * pairs that gets mixed into every future training batch, so the network
 * keeps seeing (a sample of) what it already learned even as new data comes
 * in. Deliberately keeps its OWN file copies (not references into the
 * user's live dataset) so "delete my training images" in Dataset Manager
 * can never silently degrade a model that already learned from them.
 */
class ExperienceMemory(
    private val storage: AppStorage,
    private val replayBufferDao: ReplayBufferDao
) {

    /** Call after a successful (promoted) training session to retain a sample of what it just learned from. */
    suspend fun remember(modelId: String, usedPairs: List<DatasetPairEntity>, maxToRetain: Int = 20) {
        if (usedPairs.isEmpty()) return

        // Prefer retaining the hardest examples: they carry the most
        // information about what the model currently struggles with, which
        // is exactly what's most valuable to keep rehearsing.
        val toRetain = usedPairs.sortedByDescending { it.difficultyScore }.take(maxToRetain)

        for (pair in toRetain) {
            val uid = UUID.randomUUID().toString()
            val lowDest = File(storage.replayBufferDir(), "${modelId}_${uid}_low.jpg")
            val highDest = File(storage.replayBufferDir(), "${modelId}_${uid}_high.jpg")

            val lowCopyResult = runCatching { File(pair.lowQualityPath).copyTo(lowDest, overwrite = true) }
            if (lowCopyResult.isFailure) continue

            val highCopyResult = runCatching { File(pair.highQualityPath).copyTo(highDest, overwrite = true) }
            if (highCopyResult.isFailure) {
                lowDest.delete()
                continue
            }

            replayBufferDao.insert(
                ReplayBufferEntity(
                    modelId = modelId,
                    lowQualityPath = lowDest.path,
                    highQualityPath = highDest.path,
                    originatingPairId = pair.id,
                    difficultyScore = pair.difficultyScore,
                    addedAt = System.currentTimeMillis()
                )
            )
        }

        val total = replayBufferDao.countForModel(modelId)
        if (total > Constants.REPLAY_BUFFER_MAX_SIZE) {
            replayBufferDao.evictLowestDifficulty(modelId, total - Constants.REPLAY_BUFFER_MAX_SIZE)
        }
    }

    /** Draws a random sample to mix into a new training batch; empty if nothing has been retained yet. */
    suspend fun sample(modelId: String, count: Int): List<ReplayBufferEntity> {
        if (count <= 0) return emptyList()
        return replayBufferDao.getRandomSample(modelId, count)
    }

    suspend fun bufferSize(modelId: String): Int = replayBufferDao.countForModel(modelId)
}
