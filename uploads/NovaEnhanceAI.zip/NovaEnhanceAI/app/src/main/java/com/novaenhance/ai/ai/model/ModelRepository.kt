package com.novaenhance.ai.ai.model

import android.content.Context
import com.novaenhance.ai.ai.engine.TFLiteEngine
import com.novaenhance.ai.database.dao.ModelDao
import com.novaenhance.ai.database.dao.ModelVersionDao
import com.novaenhance.ai.database.entities.ModelEntity
import com.novaenhance.ai.database.entities.ModelVersionEntity
import com.novaenhance.ai.storage.AppStorage
import com.novaenhance.ai.storage.SettingsRepository
import com.novaenhance.ai.storage.resolveInterpreterThreadCount
import com.novaenhance.ai.training.checkpoint.CheckpointManager
import com.novaenhance.ai.utils.NovaLog
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.File

private const val TAG = "ModelRepository"

/**
 * Owns the mapping from "which model is active" to "which [TFLiteEngine] is
 * currently loaded in memory," plus the Model Manager / Model Version
 * Management operations (switch/rename/export/import/backup/delete/
 * compare/restore).
 *
 * Only ever holds ONE [TFLiteEngine] loaded at a time - keeping multiple
 * multi-megabyte interpreters resident would fight the "4GB RAM device"
 * requirement for no benefit, since only one model is ever active for
 * Enhance Image or Train AI at once.
 *
 * See [ModelVersionEntity]'s doc comment for why "restoring an older
 * version" is just a database flag flip (no file copying) here: every
 * version of a model shares one constant architecture file, and only the
 * *checkpoint* that gets restored on top of it differs.
 */
class ModelRepository(
    private val context: Context,
    private val storage: AppStorage,
    private val checkpointManager: CheckpointManager,
    private val settingsRepository: SettingsRepository,
    private val modelDao: ModelDao,
    private val modelVersionDao: ModelVersionDao
) {
    private val loadMutex = Mutex()
    private var loadedEngine: TFLiteEngine? = null
    private var loadedModelId: String? = null

    suspend fun getEngine(modelId: String): TFLiteEngine = loadMutex.withLock {
        loadedEngine?.let { if (loadedModelId == modelId) return it }

        loadedEngine?.close()
        loadedEngine = null
        loadedModelId = null

        val activeVersion = modelVersionDao.getActiveVersion(modelId)
            ?: error("No active version registered for model $modelId")
        val architectureFile = File(activeVersion.architecturePath)
        require(architectureFile.exists()) { "Architecture file missing on disk: ${architectureFile.path}" }

        val metadataFile = ModelMetadata.sidecarFor(architectureFile)
        val metadata = ModelMetadata.fromFile(metadataFile)

        val engine = TFLiteEngine(architectureFile, metadata, settingsRepository.resolveInterpreterThreadCount())
        if (activeVersion.checkpointPathPrefix != null) {
            engine.restoreCheckpoint(activeVersion.checkpointPathPrefix)
        }
        // else: version 1, never trained - use the architecture's baked-in
        // (near-identity, see build_model.py) initial weights as-is.

        loadedEngine = engine
        loadedModelId = modelId
        engine
    }

    /** Bootstraps a brand-new model from a bundled asset (e.g. `models/general_v1`) the first time the app runs. */
    suspend fun createModelFromAsset(
        modelId: String,
        displayName: String,
        description: String,
        assetBaseName: String
    ): ModelEntity {
        val destArchitecture = storage.architectureFile(modelId)
        val destMetadata = ModelMetadata.sidecarFor(destArchitecture)

        context.assets.open("models/$assetBaseName.tflite").use { input ->
            destArchitecture.outputStream().use { output -> input.copyTo(output) }
        }
        context.assets.open("models/$assetBaseName.json").use { input ->
            destMetadata.outputStream().use { output -> input.copyTo(output) }
        }

        val metadata = ModelMetadata.fromFile(destMetadata)
        val now = System.currentTimeMillis()

        val model = ModelEntity(
            id = modelId,
            displayName = displayName,
            description = description,
            createdAt = now,
            currentVersionNumber = 1,
            parameterCount = metadata.parameterCount,
            sizeBytes = destArchitecture.length(),
            trainingSessionCount = 0,
            totalImagesLearned = 0,
            lastTrainedAt = null,
            improvementScore = 0f,
            isActive = modelDao.getActive() == null // first model created becomes active by default
        )
        modelDao.upsert(model)

        modelVersionDao.insert(
            ModelVersionEntity(
                modelId = modelId,
                versionNumber = 1,
                architecturePath = destArchitecture.path,
                checkpointPathPrefix = null,
                sizeBytes = destArchitecture.length(),
                parameterCount = metadata.parameterCount,
                createdAt = now,
                trainingSessionId = null,
                validationScore = 0f,
                isPromoted = true,
                isActive = true,
                notes = "Initial bundled model"
            )
        )
        return model
    }

    suspend fun switchActiveModel(modelId: String) {
        modelDao.deactivateAll()
        modelDao.setActive(modelId)
    }

    suspend fun renameModel(modelId: String, newName: String) {
        val model = modelDao.getById(modelId) ?: return
        modelDao.update(model.copy(displayName = newName))
    }

    /** Model Version Management: restore an older version as the active one - a DB flag flip, no file copying. */
    suspend fun restoreVersion(modelId: String, versionId: Long) = loadMutex.withLock {
        val version = modelVersionDao.getById(versionId) ?: return@withLock
        version.checkpointPathPrefix?.let {
            require(checkpointManager.filesForPrefix(File(it)).isNotEmpty()) { "Checkpoint files missing for version ${version.versionNumber}" }
        }

        modelVersionDao.deactivateAllForModel(modelId)
        modelVersionDao.activate(versionId)

        modelDao.getById(modelId)?.let { model ->
            modelDao.update(
                model.copy(
                    currentVersionNumber = version.versionNumber,
                    parameterCount = version.parameterCount,
                    sizeBytes = version.sizeBytes
                )
            )
        }

        if (loadedModelId == modelId) {
            loadedEngine?.close()
            loadedEngine = null
            loadedModelId = null
        }
        NovaLog.i(TAG, "Restored model $modelId to version ${version.versionNumber}")
    }

    suspend fun backupVersion(modelId: String, versionId: Long): File {
        val version = modelVersionDao.getById(versionId) ?: error("Version not found")
        val destZip = storage.backupFile(modelId, version.versionNumber, System.currentTimeMillis())
        checkpointManager.exportBundle(
            architectureFile = File(version.architecturePath),
            checkpointPrefix = version.checkpointPathPrefix?.let { File(it) },
            metadataFile = ModelMetadata.sidecarFor(File(version.architecturePath)),
            destZip = destZip
        )
        return destZip
    }

    /** Deletes a version's checkpoint files + DB row. Refuses to delete the currently active version or v1 (no checkpoint to delete; v1 is the model's baseline). */
    suspend fun deleteVersion(versionId: Long): Boolean {
        val version = modelVersionDao.getById(versionId) ?: return false
        if (version.isActive) {
            NovaLog.w(TAG, "Refusing to delete active version ${version.versionNumber} for ${version.modelId}")
            return false
        }
        if (version.checkpointPathPrefix == null) {
            NovaLog.w(TAG, "Refusing to delete version 1 (baseline, no checkpoint) for ${version.modelId}")
            return false
        }
        val deletedRows = modelVersionDao.deleteIfInactive(versionId)
        if (deletedRows > 0) {
            checkpointManager.deleteCheckpoint(File(version.checkpointPathPrefix))
        }
        return deletedRows > 0
    }

    suspend fun deleteModel(modelId: String) {
        if (loadedModelId == modelId) {
            loadedEngine?.close()
            loadedEngine = null
            loadedModelId = null
        }
        modelDao.delete(modelId) // cascades to model_versions/dataset_pairs/training_sessions/replay_buffer via FK
        storage.modelDir(modelId).deleteRecursively()
        storage.datasetDir(modelId).deleteRecursively()
        storage.checkpointDir(modelId).deleteRecursively()
    }

    /** Packages a version as a portable `.novamodel` bundle in the app's export directory, ready for FileProvider sharing. */
    suspend fun exportVersion(versionId: Long): File {
        val version = modelVersionDao.getById(versionId) ?: error("Version not found")
        val destZip = storage.exportFile(version.modelId, version.versionNumber)
        checkpointManager.exportBundle(
            architectureFile = File(version.architecturePath),
            checkpointPrefix = version.checkpointPathPrefix?.let { File(it) },
            metadataFile = ModelMetadata.sidecarFor(File(version.architecturePath)),
            destZip = destZip
        )
        return destZip
    }

    /** Imports a `.novamodel` bundle (see [CheckpointManager]) as a new model registry entry. */
    suspend fun importModel(bundleZip: File, modelId: String, displayName: String): ModelEntity {
        val imported = checkpointManager.importBundle(
            zipFile = bundleZip,
            destModelDir = storage.modelDir(modelId),
            destCheckpointDir = storage.checkpointDir(modelId),
            checkpointVersionNumber = 1
        )
        val metadata = ModelMetadata.fromFile(imported.metadataFile)
        val now = System.currentTimeMillis()
        val checkpointSize = imported.checkpointPrefix?.let { checkpointManager.totalSizeBytes(it) } ?: 0L
        val totalSize = imported.architectureFile.length() + checkpointSize

        val model = ModelEntity(
            id = modelId, displayName = displayName, description = "Imported model",
            createdAt = now, currentVersionNumber = 1, parameterCount = metadata.parameterCount,
            sizeBytes = totalSize, trainingSessionCount = 0, totalImagesLearned = 0,
            lastTrainedAt = null, improvementScore = 0f, isActive = false
        )
        modelDao.upsert(model)
        modelVersionDao.insert(
            ModelVersionEntity(
                modelId = modelId, versionNumber = 1,
                architecturePath = imported.architectureFile.path,
                checkpointPathPrefix = imported.checkpointPrefix?.path,
                sizeBytes = totalSize, parameterCount = metadata.parameterCount,
                createdAt = now, trainingSessionId = null, validationScore = 0f,
                isPromoted = true, isActive = true, notes = "Imported from ${bundleZip.name}"
            )
        )
        return model
    }
}
