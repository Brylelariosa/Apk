package com.novaenhance.ai.ai.model

import com.novaenhance.ai.ai.engine.NativeNeuralEngine
import com.novaenhance.ai.ai.engine.NovaModelEngine
import com.novaenhance.ai.database.dao.ModelDao
import com.novaenhance.ai.database.dao.ModelVersionDao
import com.novaenhance.ai.database.entities.ModelEntity
import com.novaenhance.ai.database.entities.ModelVersionEntity
import com.novaenhance.ai.storage.AppStorage
import com.novaenhance.ai.training.checkpoint.CheckpointManager
import com.novaenhance.ai.utils.NovaLog
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.File

private const val TAG = "ModelRepository"

/**
 * Owns the mapping from "which model is active" to "which [NovaModelEngine]
 * is currently loaded in memory," plus the Model Manager / Model Version
 * Management operations (switch/rename/export/import/backup/delete/
 * compare/restore).
 *
 * Only ever holds ONE [NovaModelEngine] loaded at a time - only one model
 * is ever active for Enhance Image or Train AI at once, so there's no
 * reason to keep more in memory.
 *
 * Unlike this project's earlier TFLite-based design, there is no bundled
 * asset to bootstrap from and no separate "architecture" file shared across
 * versions: [createModel] generates a brand-new model with randomly
 * initialized weights directly (see [NativeNeuralEngine.initializeParams]),
 * and each [ModelVersionEntity] is simply its own weights file.
 */
class ModelRepository(
    private val storage: AppStorage,
    private val checkpointManager: CheckpointManager,
    private val modelDao: ModelDao,
    private val modelVersionDao: ModelVersionDao
) {
    private val loadMutex = Mutex()
    private var loadedEngine: NovaModelEngine? = null
    private var loadedModelId: String? = null

    suspend fun getEngine(modelId: String): NovaModelEngine = loadMutex.withLock {
        loadedEngine?.let { if (loadedModelId == modelId) return it }

        loadedEngine = null
        loadedModelId = null

        val activeVersion = modelVersionDao.getActiveVersion(modelId)
            ?: error("No active version registered for model $modelId")
        val weightsFile = File(activeVersion.weightsFilePath)
        require(weightsFile.exists()) { "Weights file missing on disk: ${weightsFile.path}" }

        val engine = NovaModelEngine.loadFromCheckpoint(weightsFile.path)
        loadedEngine = engine
        loadedModelId = modelId
        engine
    }

    /**
     * Creates a brand-new model with freshly, randomly initialized weights -
     * no bundled asset, no external generation step. This IS the network's
     * starting point (near-identity output, see `nn/network.cpp`'s
     * `initializeParams` for why), not a placeholder waiting to be replaced.
     */
    suspend fun createModel(modelId: String, displayName: String, description: String): ModelEntity {
        val engine = NovaModelEngine.createFresh(seed = System.currentTimeMillis())
        val weightsFile = storage.weightsFile(modelId, 1)
        engine.saveCheckpoint(weightsFile.path)

        val metadata = ModelMetadata(modelName = displayName, parameterCount = NativeNeuralEngine.TOTAL_PARAMS, versionNumber = 1)
        ModelMetadata.sidecarFor(weightsFile).writeText(metadata.toJson())

        val now = System.currentTimeMillis()
        val model = ModelEntity(
            id = modelId,
            displayName = displayName,
            description = description,
            createdAt = now,
            currentVersionNumber = 1,
            parameterCount = NativeNeuralEngine.TOTAL_PARAMS.toLong(),
            sizeBytes = weightsFile.length(),
            trainingSessionCount = 0,
            totalImagesLearned = 0,
            lastTrainedAt = null,
            improvementScore = 0f,
            isActive = modelDao.getActive() == null // first model created becomes active by default
        )
        modelDao.upsert(model)

        modelVersionDao.insert(
            ModelVersionEntity(
                modelId = modelId,
                versionNumber = 1,
                weightsFilePath = weightsFile.path,
                sizeBytes = weightsFile.length(),
                parameterCount = NativeNeuralEngine.TOTAL_PARAMS.toLong(),
                createdAt = now,
                trainingSessionId = null,
                validationScore = 0f,
                isPromoted = true,
                isActive = true,
                notes = "Freshly initialized model"
            )
        )
        return model
    }

    suspend fun switchActiveModel(modelId: String) {
        modelDao.deactivateAll()
        modelDao.setActive(modelId)
    }

    suspend fun renameModel(modelId: String, newName: String) {
        val model = modelDao.getById(modelId) ?: return
        modelDao.update(model.copy(displayName = newName))
    }

    /** Model Version Management: restore an older version as the active one - a DB flag flip, the weights file was never deleted. */
    suspend fun restoreVersion(modelId: String, versionId: Long) = loadMutex.withLock {
        val version = modelVersionDao.getById(versionId) ?: return@withLock
        require(File(version.weightsFilePath).exists()) { "Weights file missing for version ${version.versionNumber}" }

        modelVersionDao.deactivateAllForModel(modelId)
        modelVersionDao.activate(versionId)

        modelDao.getById(modelId)?.let { model ->
            modelDao.update(
                model.copy(
                    currentVersionNumber = version.versionNumber,
                    parameterCount = version.parameterCount,
                    sizeBytes = version.sizeBytes
                )
            )
        }

        if (loadedModelId == modelId) {
            loadedEngine = null
            loadedModelId = null
        }
        NovaLog.i(TAG, "Restored model $modelId to version ${version.versionNumber}")
    }

    suspend fun backupVersion(modelId: String, versionId: Long): File {
        val version = modelVersionDao.getById(versionId) ?: error("Version not found")
        val destZip = storage.backupFile(modelId, version.versionNumber, System.currentTimeMillis())
        checkpointManager.exportBundle(
            weightsFile = File(version.weightsFilePath),
            metadataFile = ModelMetadata.sidecarFor(File(version.weightsFilePath)),
            destZip = destZip
        )
        return destZip
    }

    /** Deletes a version's weights file + DB row. Refuses to delete the currently active version or v1 (the model's baseline). */
    suspend fun deleteVersion(versionId: Long): Boolean {
        val version = modelVersionDao.getById(versionId) ?: return false
        if (version.isActive) {
            NovaLog.w(TAG, "Refusing to delete active version ${version.versionNumber} for ${version.modelId}")
            return false
        }
        if (version.versionNumber == 1) {
            NovaLog.w(TAG, "Refusing to delete version 1 (baseline) for ${version.modelId}")
            return false
        }
        val deletedRows = modelVersionDao.deleteIfInactive(versionId)
        if (deletedRows > 0) {
            File(version.weightsFilePath).delete()
            ModelMetadata.sidecarFor(File(version.weightsFilePath)).delete()
        }
        return deletedRows > 0
    }

    suspend fun deleteModel(modelId: String) {
        if (loadedModelId == modelId) {
            loadedEngine = null
            loadedModelId = null
        }
        modelDao.delete(modelId) // cascades to model_versions/dataset_pairs/training_sessions/replay_buffer via FK
        storage.modelDir(modelId).deleteRecursively()
        storage.datasetDir(modelId).deleteRecursively()
        storage.checkpointDir(modelId).deleteRecursively()
    }

    /** Packages a version as a portable `.novamodel` bundle in the app's export directory, ready for FileProvider sharing. */
    suspend fun exportVersion(versionId: Long): File {
        val version = modelVersionDao.getById(versionId) ?: error("Version not found")
        val destZip = storage.exportFile(version.modelId, version.versionNumber)
        checkpointManager.exportBundle(
            weightsFile = File(version.weightsFilePath),
            metadataFile = ModelMetadata.sidecarFor(File(version.weightsFilePath)),
            destZip = destZip
        )
        return destZip
    }

    /** Imports a `.novamodel` bundle (see [CheckpointManager]) as a new model registry entry. */
    suspend fun importModel(bundleZip: File, modelId: String, displayName: String): ModelEntity {
        val imported = checkpointManager.importBundle(
            zipFile = bundleZip,
            destDir = storage.checkpointDir(modelId),
            versionNumber = 1
        )
        val metadata = ModelMetadata.fromFile(imported.metadataFile)
        val now = System.currentTimeMillis()

        val model = ModelEntity(
            id = modelId, displayName = displayName, description = "Imported model",
            createdAt = now, currentVersionNumber = 1, parameterCount = metadata.parameterCount.toLong(),
            sizeBytes = imported.weightsFile.length(), trainingSessionCount = 0, totalImagesLearned = 0,
            lastTrainedAt = null, improvementScore = 0f, isActive = false
        )
        modelDao.upsert(model)
        modelVersionDao.insert(
            ModelVersionEntity(
                modelId = modelId, versionNumber = 1,
                weightsFilePath = imported.weightsFile.path,
                sizeBytes = imported.weightsFile.length(), parameterCount = metadata.parameterCount.toLong(),
                createdAt = now, trainingSessionId = null, validationScore = 0f,
                isPromoted = true, isActive = true, notes = "Imported from ${bundleZip.name}"
            )
        )
        return model
    }
}
