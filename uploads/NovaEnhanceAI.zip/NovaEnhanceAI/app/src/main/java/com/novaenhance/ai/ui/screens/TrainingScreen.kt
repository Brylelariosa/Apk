package com.novaenhance.ai.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.ui.res.painterResource
import com.novaenhance.ai.R
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.novaenhance.ai.database.entities.TrainingStatus
import com.novaenhance.ai.ui.components.TrainingProgressCard
import com.novaenhance.ai.ui.viewmodel.NovaViewModelFactory
import com.novaenhance.ai.ui.viewmodel.TrainingViewModel

@Composable
fun TrainingScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val viewModel: TrainingViewModel = viewModel(factory = NovaViewModelFactory(context))
    val state by viewModel.uiState.collectAsState()
    val progress by viewModel.liveProgress.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Train AI") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(painterResource(R.drawable.ic_back_arrow), contentDescription = "Back") } }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("Model: ${state.activeModel?.displayName ?: "None"}", style = MaterialTheme.typography.titleMedium)
            Text("Training pairs available: ${state.datasetPairCount}", style = MaterialTheme.typography.bodyMedium)

            progress?.let { TrainingProgressCard(it, modifier = Modifier.fillMaxWidth()) }

            when (state.currentSession?.status) {
                TrainingStatus.RUNNING -> {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { viewModel.pauseTraining() }, modifier = Modifier.weight(1f)) { Text("Pause") }
                        OutlinedButton(onClick = { viewModel.cancelTraining() }, modifier = Modifier.weight(1f)) { Text("Cancel") }
                    }
                }
                TrainingStatus.PAUSED -> {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { viewModel.startOrResumeTraining() }, modifier = Modifier.weight(1f)) { Text("Resume") }
                        OutlinedButton(onClick = { viewModel.cancelTraining() }, modifier = Modifier.weight(1f)) { Text("Cancel") }
                    }
                }
                else -> {
                    Button(
                        onClick = { viewModel.startOrResumeTraining() },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = state.datasetPairCount > 0
                    ) {
                        Text("Start Training")
                    }
                    if (state.datasetPairCount == 0) {
                        Text(
                            "Add training pairs in Dataset Manager first.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            state.message?.let {
                Text(it, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.error)
            }
        }
    }

    if (state.showKeepOrDeleteDatasetPrompt) {
        AlertDialog(
            onDismissRequest = { viewModel.keepDataset() },
            title = { Text("Training completed") },
            text = { Text("Delete the training images you used? Your AI's learned knowledge is kept either way.") },
            confirmButton = { TextButton(onClick = { viewModel.deleteDataset() }) { Text("Delete Dataset") } },
            dismissButton = { TextButton(onClick = { viewModel.keepDataset() }) { Text("Keep Dataset") } }
        )
    }
}
