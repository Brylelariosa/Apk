package com.novaenhance.ai.training.trainer

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.novaenhance.ai.ai.engine.NovaModelEngine
import com.novaenhance.ai.ai.engine.PixelBufferOps
import com.novaenhance.ai.ai.model.ModelRepository
import com.novaenhance.ai.database.dao.DatasetPairDao
import com.novaenhance.ai.database.dao.LossHistoryDao
import com.novaenhance.ai.database.dao.ModelDao
import com.novaenhance.ai.database.dao.ModelVersionDao
import com.novaenhance.ai.database.dao.TrainingSessionDao
import com.novaenhance.ai.database.dao.ValidationMetricDao
import com.novaenhance.ai.database.entities.DatasetPairEntity
import com.novaenhance.ai.database.entities.LossHistoryEntity
import com.novaenhance.ai.database.entities.ModelVersionEntity
import com.novaenhance.ai.database.entities.TrainingSessionEntity
import com.novaenhance.ai.database.entities.TrainingStatus
import com.novaenhance.ai.storage.AppStorage
import com.novaenhance.ai.training.dataset.DatasetAnalyzer
import com.novaenhance.ai.utils.DeviceCapabilities
import com.novaenhance.ai.utils.NovaLog
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.random.Random

private const val TAG = "ModelTrainer"
private const val CHECKPOINT_SAVE_EVERY_N_BATCHES = 20
private const val MIN_VALIDATION_HOLD_OUT = 1
private const val MAX_VALIDATION_HOLD_OUT = 20
private const val VALIDATION_HOLD_OUT_FRACTION = 0.15f

/**
 * The Self-Improvement Loop's engine room: collect data -> train -> evaluate
 * -> (find weak areas / prioritize similar data is handled one level up by
 * [SelfImprovementOrchestrator], which decides *when* to call this and with
 * what dataset slice). This class owns one training *session's* full
 * lifecycle: dataset analysis gate, adaptive planning, the pause/resume/
 * cancel-safe batch loop, periodic crash-recovery checkpoints, anti-
 * forgetting (anchor + replay), and validation-gated promotion.
 */
class ModelTrainer(
    private val modelRepository: ModelRepository,
    private val datasetPairDao: DatasetPairDao,
    private val trainingSessionDao: TrainingSessionDao,
    private val lossHistoryDao: LossHistoryDao,
    private val validationMetricDao: ValidationMetricDao,
    private val modelVersionDao: ModelVersionDao,
    private val modelDao: ModelDao,
    private val datasetAnalyzer: DatasetAnalyzer,
    private val adaptiveController: AdaptiveTrainingController,
    private val experienceMemory: ExperienceMemory,
    private val validator: ModelValidator,
    private val storage: AppStorage,
    private val deviceCapabilities: DeviceCapabilities
) {
    private val _progress = MutableStateFlow<TrainingProgressState?>(null)
    val progress: StateFlow<TrainingProgressState?> = _progress.asStateFlow()

    /** Crash recovery: call at app/service start to find a session that never reached a terminal state. */
    suspend fun findRecoverableSession(): TrainingSessionEntity? =
        trainingSessionDao.findLatestWithStatus(TrainingStatus.RUNNING)

    /**
     * Runs (or resumes) one training session to completion, pause, or
     * cancellation. Must be called from a background-appropriate dispatcher
     * (this does blocking bitmap I/O and CPU-bound tensor work) - see
     * [com.novaenhance.ai.workers.TrainingForegroundService].
     */
    suspend fun runSession(modelId: String, resumeSessionId: Long?, control: TrainingControlFlow): TrainingSessionEntity {
        datasetAnalyzer.analyzeNewPairs(modelId)
        val usablePairs = datasetPairDao.getUsablePairsByDifficulty(modelId)
        require(usablePairs.isNotEmpty()) { "No usable training pairs for model $modelId" }

        val holdOut = (usablePairs.size * VALIDATION_HOLD_OUT_FRACTION).toInt()
            .coerceIn(MIN_VALIDATION_HOLD_OUT, MAX_VALIDATION_HOLD_OUT)
            .coerceAtMost(usablePairs.size - 1)
            .coerceAtLeast(0)
        val validationPairs = if (holdOut > 0) usablePairs.takeLast(holdOut) else emptyList()
        val trainPairs = if (holdOut > 0) usablePairs.dropLast(holdOut) else usablePairs

        val recentSessions = trainingSessionDao.getRecentCompleted(modelId, limit = 5)
        val plan = adaptiveController.planSession(trainPairs.size, recentSessions)

        var session = resumeSessionId?.let { trainingSessionDao.getById(it) }
            ?: run {
                val fresh = TrainingSessionEntity(
                    modelId = modelId,
                    startedAt = System.currentTimeMillis(),
                    status = TrainingStatus.RUNNING,
                    plannedEpochs = plan.epochs,
                    batchSize = plan.batchSize,
                    learningRate = plan.learningRate,
                    replayFraction = plan.replayFraction,
                    datasetPairCount = trainPairs.size,
                    deviceRamMbAtStart = plan.deviceRamMbAtStart
                )
                val id = trainingSessionDao.insert(fresh)
                fresh.copy(id = id)
            }
        if (session.status != TrainingStatus.RUNNING) {
            session = session.copy(status = TrainingStatus.RUNNING)
            trainingSessionDao.update(session)
        }

        val activeVersion = modelVersionDao.getActiveVersion(modelId) ?: error("No active version for $modelId")
        val engine = modelRepository.getEngine(modelId)

        // Anti-forgetting anchor: snapshot pre-session weights once, before
        // any train() calls, so L2-SP can penalize drifting away from them.
        engine.setAnchor()

        val random = Random(System.currentTimeMillis())
        var initialLoss: Float? = null
        var lastLoss: Float? = null
        var batchesRun = 0
        val startMs = System.currentTimeMillis()
        val batchesPerEpoch = kotlin.math.ceil(trainPairs.size.toFloat() / plan.batchSize).toInt().coerceAtLeast(1)
        val totalPlannedBatches = batchesPerEpoch * (session.plannedEpochs - session.epochsCompleted)

        for (epoch in session.epochsCompleted until session.plannedEpochs) {
            val batches = buildBatches(trainPairs, plan.batchSize, plan.replayFraction, modelId)

            for ((batchIndex, batch) in batches.withIndex()) {
                when (control.command.value) {
                    TrainingCommand.CANCEL -> return finishAs(session, TrainingStatus.CANCELLED, epoch, null)
                    TrainingCommand.PAUSE -> return finishAs(session, TrainingStatus.PAUSED, epoch, null)
                    TrainingCommand.RUN -> Unit
                }
                if (adaptiveController.shouldPauseForDeviceSafety()) {
                    return finishAs(session, TrainingStatus.PAUSED, epoch, null, throttled = true)
                }

                val lowTiles = mutableListOf<IntArray>()
                val highTiles = mutableListOf<IntArray>()
                for ((lowPath, highPath) in batch) {
                    val (lowTile, highTile) = extractTrainingTile(lowPath, highPath, engine.tileSize, random) ?: continue
                    lowTiles += lowTile
                    highTiles += highTile
                }
                if (lowTiles.isEmpty()) continue

                val loss = engine.trainBatch(lowTiles, highTiles, plan.learningRate, plan.l2SpLambda)
                if (initialLoss == null) initialLoss = loss
                lastLoss = loss
                batchesRun++

                lossHistoryDao.insert(
                    LossHistoryEntity(sessionId = session.id, epoch = epoch, batchIndex = batchIndex, loss = loss, timestamp = System.currentTimeMillis())
                )

                publishProgress(session, epoch, plan, batchIndex, batches.size, loss, batchesRun, totalPlannedBatches, startMs)

                if (batchesRun % CHECKPOINT_SAVE_EVERY_N_BATCHES == 0) {
                    val inProgressFile = storage.weightsFile(modelId, activeVersion.versionNumber + 1)
                    runCatching { engine.saveCheckpoint(inProgressFile.path) }
                        .onFailure { NovaLog.w(TAG, "Mid-session checkpoint save failed", it) }
                }
            }
            session = session.copy(epochsCompleted = epoch + 1)
            trainingSessionDao.update(session)
        }

        return finalizeSession(modelId, session, engine, activeVersion, trainPairs, validationPairs, initialLoss, lastLoss)
    }

    private suspend fun finalizeSession(
        modelId: String,
        session: TrainingSessionEntity,
        engine: NovaModelEngine,
        activeVersion: ModelVersionEntity,
        trainPairs: List<DatasetPairEntity>,
        validationPairs: List<DatasetPairEntity>,
        initialLoss: Float?,
        finalLoss: Float?
    ): TrainingSessionEntity {
        val nextVersionNumber = (modelVersionDao.getLatestVersionNumber(modelId) ?: activeVersion.versionNumber) + 1
        val newWeightsFile = storage.weightsFile(modelId, nextVersionNumber)
        engine.saveCheckpoint(newWeightsFile.path)

        // Independent, unmutated "before" model for a fair comparison -
        // `engine` has already moved on to the freshly trained weights.
        // (No close()/cleanup needed - NovaModelEngine is a plain Kotlin
        // object with no native handle to leak.)
        val oldEngine = NovaModelEngine.loadFromCheckpoint(activeVersion.weightsFilePath)
        val validationResult = validator.validate(oldEngine, engine, validationPairs, session.id)
        if (validationResult.metrics.isNotEmpty()) {
            validationMetricDao.insertAll(validationResult.metrics)
        }

        val completedAt = System.currentTimeMillis()

        return if (validationResult.overallImproved) {
            modelVersionDao.deactivateAllForModel(modelId)
            val versionId = modelVersionDao.insert(
                ModelVersionEntity(
                    modelId = modelId,
                    versionNumber = nextVersionNumber,
                    weightsFilePath = newWeightsFile.path,
                    sizeBytes = newWeightsFile.length(),
                    parameterCount = activeVersion.parameterCount,
                    createdAt = completedAt,
                    trainingSessionId = session.id,
                    validationScore = validationResult.metrics.map { it.scoreAfterTraining }.average().toFloat(),
                    isPromoted = true,
                    isActive = true,
                    notes = "Trained on ${trainPairs.size} pairs"
                )
            )
            modelVersionDao.activate(versionId)

            datasetPairDao.markUsedInSession(trainPairs.map { it.id }, session.id)
            experienceMemory.remember(modelId, trainPairs)

            val improvementDelta = (validationResult.metrics.map { it.delta }.average() * 100).toFloat()
            modelDao.getById(modelId)?.let { model ->
                modelDao.recordTrainingPromotion(
                    modelId = modelId,
                    versionNumber = nextVersionNumber,
                    parameterCount = activeVersion.parameterCount,
                    sizeBytes = newWeightsFile.length(),
                    newImagesLearned = trainPairs.size,
                    trainedAt = completedAt,
                    improvementScore = (model.improvementScore * 0.7f + improvementDelta * 0.3f).coerceIn(0f, 100f)
                )
            }

            finishAs(session, TrainingStatus.COMPLETED, session.plannedEpochs, versionId, initialLoss = initialLoss, finalLoss = finalLoss, promoted = true)
        } else {
            // Reject: discard the new checkpoint, old version stays active.
            newWeightsFile.delete()
            finishAs(
                session, TrainingStatus.COMPLETED, session.plannedEpochs, null,
                initialLoss = initialLoss, finalLoss = finalLoss, promoted = false,
                failureReason = "Validation showed no overall improvement over the current model"
            )
        }
    }

    private suspend fun finishAs(
        session: TrainingSessionEntity,
        status: TrainingStatus,
        epochsCompleted: Int,
        resultVersionId: Long?,
        initialLoss: Float? = null,
        finalLoss: Float? = null,
        promoted: Boolean = false,
        failureReason: String? = null,
        throttled: Boolean = false
    ): TrainingSessionEntity {
        val updated = session.copy(
            status = status,
            epochsCompleted = epochsCompleted,
            completedAt = if (status == TrainingStatus.PAUSED) session.completedAt else System.currentTimeMillis(),
            resultModelVersionId = resultVersionId,
            wasPromoted = promoted,
            initialLoss = initialLoss ?: session.initialLoss,
            finalLoss = finalLoss ?: session.finalLoss,
            wasThrottledByThermal = session.wasThrottledByThermal || throttled,
            failureReason = failureReason
        )
        trainingSessionDao.update(updated)
        _progress.value = _progress.value?.copy(status = status)
        return updated
    }

    private fun publishProgress(
        session: TrainingSessionEntity,
        epoch: Int,
        plan: AdaptiveTrainingController.TrainingPlan,
        batchIndex: Int,
        batchesInEpoch: Int,
        loss: Float,
        batchesRun: Int,
        totalPlannedBatches: Int,
        startMs: Long
    ) {
        val elapsedSec = (System.currentTimeMillis() - startMs) / 1000.0
        val imagesPerSecond = if (elapsedSec > 0) (batchesRun * plan.batchSize) / elapsedSec else 0.0
        val remainingBatches = (totalPlannedBatches - batchesRun).coerceAtLeast(0)
        val etaSeconds = if (imagesPerSecond > 0) (remainingBatches * plan.batchSize / imagesPerSecond).toLong() else -1L
        val ram = deviceCapabilities.snapshot()

        _progress.value = TrainingProgressState(
            sessionId = session.id,
            epoch = epoch,
            totalEpochs = session.plannedEpochs,
            batchIndex = batchIndex,
            totalBatches = batchesInEpoch,
            latestLoss = loss,
            imagesPerSecond = imagesPerSecond.toFloat(),
            estimatedSecondsRemaining = etaSeconds,
            memoryUsedMb = ram.totalRamMb - ram.availableRamMb,
            status = TrainingStatus.RUNNING
        )
    }

    /** Builds batches mixing real training pairs with a fraction drawn from the anti-forgetting replay buffer. */
    private suspend fun buildBatches(
        trainPairs: List<DatasetPairEntity>,
        batchSize: Int,
        replayFraction: Float,
        modelId: String
    ): List<List<Pair<String, String>>> {
        val replayPerBatch = (batchSize * replayFraction).toInt().coerceIn(0, batchSize - 1)
        val realPerBatch = (batchSize - replayPerBatch).coerceAtLeast(1)

        val realChunks = trainPairs.map { it.lowQualityPath to it.highQualityPath }.chunked(realPerBatch)
        return realChunks.map { chunk ->
            val replaySample = if (replayPerBatch > 0) {
                experienceMemory.sample(modelId, replayPerBatch).map { it.lowQualityPath to it.highQualityPath }
            } else {
                emptyList()
            }
            chunk + replaySample
        }
    }

    /** Decodes a pair and extracts one matching random `tileSize x tileSize` patch from each (pixel-aligned). */
    private fun extractTrainingTile(lowPath: String, highPath: String, tileSize: Int, random: Random): Pair<IntArray, IntArray>? {
        val lowBitmap = decodeBitmap(lowPath) ?: return null
        val highBitmap = decodeBitmap(highPath) ?: run { lowBitmap.recycle(); return null }

        try {
            val w = minOf(lowBitmap.width, highBitmap.width)
            val h = minOf(lowBitmap.height, highBitmap.height)
            if (w <= 0 || h <= 0) return null

            val cropW = minOf(tileSize, w)
            val cropH = minOf(tileSize, h)
            val x = if (w > cropW) random.nextInt(w - cropW) else 0
            val y = if (h > cropH) random.nextInt(h - cropH) else 0

            val lowPixels = IntArray(cropW * cropH)
            val highPixels = IntArray(cropW * cropH)
            lowBitmap.getPixels(lowPixels, 0, cropW, x, y, cropW, cropH)
            highBitmap.getPixels(highPixels, 0, cropW, x, y, cropW, cropH)

            val lowTile = PixelBufferOps.padByReplication(lowPixels, cropW, cropH, tileSize)
            val highTile = PixelBufferOps.padByReplication(highPixels, cropW, cropH, tileSize)
            return lowTile to highTile
        } finally {
            lowBitmap.recycle()
            highBitmap.recycle()
        }
    }

    private fun decodeBitmap(path: String): Bitmap? = try {
        BitmapFactory.decodeFile(path)
    } catch (t: Throwable) {
        NovaLog.w(TAG, "Failed to decode training image $path", t)
        null
    }
}
