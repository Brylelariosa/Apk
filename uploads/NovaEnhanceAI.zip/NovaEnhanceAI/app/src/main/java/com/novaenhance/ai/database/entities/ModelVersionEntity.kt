package com.novaenhance.ai.database.entities

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * A single saved checkpoint in a model's version history
 * (v1 -> train -> v2 -> train -> v3, ...). A row is only ever created here
 * for a version that PASSED [com.novaenhance.ai.training.trainer.ModelValidator]
 * validation and was promoted - a rejected training attempt (the model got
 * worse) never becomes a version, since there'd be nothing useful about
 * letting a user "restore" or "compare" to a checkpoint known to be worse
 * than what's active. Rejected attempts are still recorded, just on
 * [TrainingSessionEntity] (`wasPromoted = false`, `failureReason`) instead,
 * which is where "what did I try and why didn't it stick" belongs.
 * `isPromoted` here is always true; it's kept (rather than removed) so a
 * query joining through training sessions doesn't need special-casing.
 *
 * IMPORTANT: a "version" is NOT a standalone `.tflite` file. TensorFlow
 * Lite's on-device training feature works by keeping ONE constant graph
 * file per model (`architecturePath`, holding the fixed network structure
 * plus its train/infer/save/restore signatures) and layering a TF
 * checkpoint (a set of sibling files sharing `checkpointPathPrefix`) on top
 * of it via the "restore" signature. Every version of a given model shares
 * the same `architecturePath`; what actually differs between v1, v2, v3...
 * is which checkpoint gets restored after the architecture is loaded.
 * `checkpointPathPrefix` is null only for version 1 (the freshly-bundled or
 * freshly-imported model, before any training) - see the near-identity
 * initialization in `tools/model_builder/build_model.py` for why that's a
 * safe default rather than random-weight garbage.
 */
@Entity(
    tableName = "model_versions",
    foreignKeys = [
        ForeignKey(
            entity = ModelEntity::class,
            parentColumns = ["id"],
            childColumns = ["modelId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("modelId")]
)
data class ModelVersionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val modelId: String,
    val versionNumber: Int,
    val architecturePath: String,
    val checkpointPathPrefix: String?,
    val sizeBytes: Long, // architecture size (v1) or checkpoint files' total size (v2+)
    val parameterCount: Long,
    val createdAt: Long,
    val trainingSessionId: Long?,
    val validationScore: Float,
    val isPromoted: Boolean, // false = training attempt that failed validation and was discarded from "active" but kept for history
    val isActive: Boolean,
    val notes: String
)
