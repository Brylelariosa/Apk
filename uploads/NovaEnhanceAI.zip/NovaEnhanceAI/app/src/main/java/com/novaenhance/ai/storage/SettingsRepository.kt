package com.novaenhance.ai.storage

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "novaenhance_settings")

enum class ThemePreference { SYSTEM, LIGHT, DARK }

data class AppSettings(
    val theme: ThemePreference = ThemePreference.SYSTEM,
    val trainOnlyWhileCharging: Boolean = false,
    val thermalProtectionEnabled: Boolean = true,
    val cpuThreadLimit: Int = 0, // 0 = auto (device core count - 1, see TFLiteEngine)
    val lowRamModeEnabled: Boolean = false
)

/** Backs the Settings screen. All reads are a [Flow] so the screen recomposes live as values change. */
class SettingsRepository(private val context: Context) {

    private object Keys {
        val THEME = stringPreferencesKey("theme")
        val TRAIN_ONLY_WHILE_CHARGING = booleanPreferencesKey("train_only_while_charging")
        val THERMAL_PROTECTION = booleanPreferencesKey("thermal_protection_enabled")
        val CPU_THREAD_LIMIT = intPreferencesKey("cpu_thread_limit")
        val LOW_RAM_MODE = booleanPreferencesKey("low_ram_mode_enabled")
    }

    val settings: Flow<AppSettings> = context.dataStore.data.map { prefs ->
        AppSettings(
            theme = prefs[Keys.THEME]?.let { runCatching { ThemePreference.valueOf(it) }.getOrNull() } ?: ThemePreference.SYSTEM,
            trainOnlyWhileCharging = prefs[Keys.TRAIN_ONLY_WHILE_CHARGING] ?: false,
            thermalProtectionEnabled = prefs[Keys.THERMAL_PROTECTION] ?: true,
            cpuThreadLimit = prefs[Keys.CPU_THREAD_LIMIT] ?: 0,
            lowRamModeEnabled = prefs[Keys.LOW_RAM_MODE] ?: false
        )
    }

    suspend fun setTheme(theme: ThemePreference) {
        context.dataStore.edit { it[Keys.THEME] = theme.name }
    }

    suspend fun setTrainOnlyWhileCharging(enabled: Boolean) {
        context.dataStore.edit { it[Keys.TRAIN_ONLY_WHILE_CHARGING] = enabled }
    }

    suspend fun setThermalProtectionEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.THERMAL_PROTECTION] = enabled }
    }

    suspend fun setCpuThreadLimit(limit: Int) {
        context.dataStore.edit { it[Keys.CPU_THREAD_LIMIT] = limit }
    }

    suspend fun setLowRamModeEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.LOW_RAM_MODE] = enabled }
    }
}

/**
 * The single place that turns "what the user asked for" (an explicit CPU
 * thread cap, or 0 for auto) into "how many threads TFLite's Interpreter
 * should actually use." In auto mode, one core is deliberately left free for
 * the classical/JNI filter work (denoise/sharpen/resize) that often runs
 * alongside inference - see [com.novaenhance.ai.ai.engine.TFLiteEngine].
 * Both [com.novaenhance.ai.ai.model.ModelRepository] (the "live" engine) and
 * [com.novaenhance.ai.training.trainer.ModelTrainer] (the independent
 * "before" engine used for validation) call this so the two never disagree
 * about thread budgeting.
 */
suspend fun SettingsRepository.resolveInterpreterThreadCount(): Int {
    val current = settings.first()
    val cores = Runtime.getRuntime().availableProcessors()
    return if (current.cpuThreadLimit > 0) {
        current.cpuThreadLimit.coerceAtMost(cores)
    } else {
        (cores - 1).coerceAtLeast(1)
    }
}
