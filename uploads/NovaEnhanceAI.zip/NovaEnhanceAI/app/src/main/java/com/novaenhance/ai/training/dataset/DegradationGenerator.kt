package com.novaenhance.ai.training.dataset

import android.graphics.Bitmap
import com.novaenhance.ai.ai.engine.NativeImageProcessor
import kotlin.random.Random

/**
 * "Automatic Dataset Generator": lets a user train from high-quality images
 * alone by synthesizing a plausible low-quality counterpart, so they don't
 * have to hunt down a matching bad/good pair for every example.
 *
 * Degradations are combined randomly (not always all at once) so the
 * network sees a realistic *variety* of quality problems rather than
 * overfitting to one fixed degradation recipe.
 */
class DegradationGenerator(private val random: Random = Random.Default) {

    data class DegradationRecipe(
        val blurSigma: Float,
        val noiseAmount: Float,
        val jpegQuality: Int,
        val resolutionScale: Float,
        val colorFadeAmount: Float,
        val motionBlurLengthPx: Int,
        val motionBlurAngle: Float
    )

    /** Picks a randomized-but-plausible degradation recipe. `severity` in 0f..1f scales how harsh it is overall. */
    fun randomRecipe(severity: Float = random.nextFloat().coerceIn(0.2f, 0.8f)): DegradationRecipe {
        return DegradationRecipe(
            blurSigma = if (random.nextFloat() < 0.7f) severity * 2.5f else 0f,
            noiseAmount = if (random.nextFloat() < 0.8f) severity * 0.6f else 0f,
            jpegQuality = (100 - (severity * 70)).toInt().coerceIn(15, 95),
            resolutionScale = (1f - severity * 0.6f).coerceIn(0.25f, 1f),
            colorFadeAmount = if (random.nextFloat() < 0.3f) severity * 0.4f else 0f,
            motionBlurLengthPx = if (random.nextFloat() < 0.25f) (severity * 12).toInt() + 2 else 0,
            motionBlurAngle = random.nextFloat() * 180f
        )
    }

    /** Applies [recipe] to [source], returning a new degraded bitmap. Caller owns/recycles [source]. */
    fun degrade(source: Bitmap, recipe: DegradationRecipe): Bitmap {
        val width = source.width
        val height = source.height
        var pixels = IntArray(width * height)
        source.getPixels(pixels, 0, width, 0, 0, width, height)

        if (recipe.motionBlurLengthPx > 1) {
            pixels = NativeImageProcessor.motionBlur(pixels, width, height, recipe.motionBlurAngle, recipe.motionBlurLengthPx)
        }
        if (recipe.blurSigma > 0f) {
            pixels = NativeImageProcessor.gaussianBlur(pixels, width, height, recipe.blurSigma)
        }
        if (recipe.colorFadeAmount > 0f) {
            pixels = NativeImageProcessor.colorFade(pixels, width, height, recipe.colorFadeAmount)
        }

        var resultWidth = width
        var resultHeight = height
        if (recipe.resolutionScale < 1f) {
            val downW = (width * recipe.resolutionScale).toInt().coerceAtLeast(1)
            val downH = (height * recipe.resolutionScale).toInt().coerceAtLeast(1)
            val downscaled = NativeImageProcessor.resizeBilinear(pixels, width, height, downW, downH)
            // Scale back up to original size so the pair is still pixel-aligned
            // for training (the model learns "recover detail lost by upscaling
            // a low-res capture," which is the realistic failure mode this
            // simulates - a phone photo taken at low resolution, not a
            // deliberately shrunk-then-regrown image).
            pixels = NativeImageProcessor.resizeBilinear(downscaled, downW, downH, width, height)
            resultWidth = width
            resultHeight = height
        }

        if (recipe.noiseAmount > 0f) {
            pixels = NativeImageProcessor.addGaussianNoise(pixels, resultWidth, resultHeight, recipe.noiseAmount, random.nextInt())
        }
        if (recipe.jpegQuality < 95) {
            pixels = NativeImageProcessor.simulateJpegArtifacts(pixels, resultWidth, resultHeight, recipe.jpegQuality)
        }

        return Bitmap.createBitmap(pixels, resultWidth, resultHeight, Bitmap.Config.ARGB_8888)
    }
}
