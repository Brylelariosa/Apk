package com.novaenhance.ai

import android.app.Application
import com.novaenhance.ai.di.ServiceLocator
import com.novaenhance.ai.utils.NovaLog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

private const val TAG = "NovaEnhanceApplication"
private const val DEFAULT_MODEL_ID = "general"
private const val DEFAULT_MODEL_ASSET = "general_v1"

class NovaEnhanceApplication : Application() {

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onCreate() {
        super.onCreate()
        val locator = ServiceLocator.get(this)

        appScope.launch {
            try {
                ensureDefaultModel(locator)
            } catch (t: Throwable) {
                // First-run bootstrap failure is serious (Enhance/Train will
                // have nothing to load) but must never crash app startup -
                // the Dashboard surfaces "no model available" and the user
                // can import one manually via Model Manager instead.
                NovaLog.e(TAG, "Failed to bootstrap default model", t)
            }
        }
    }

    private suspend fun ensureDefaultModel(locator: ServiceLocator) {
        val existing = locator.database.modelDao().getById(DEFAULT_MODEL_ID)
        if (existing != null) return

        locator.modelRepository.createModelFromAsset(
            modelId = DEFAULT_MODEL_ID,
            displayName = getString(R.string.default_model_name),
            description = getString(R.string.default_model_description),
            assetBaseName = DEFAULT_MODEL_ASSET
        )
        NovaLog.i(TAG, "Bootstrapped default model '$DEFAULT_MODEL_ID' from bundled asset")
    }
}
