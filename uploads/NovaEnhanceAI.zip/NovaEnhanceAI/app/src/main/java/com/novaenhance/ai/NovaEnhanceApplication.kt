package com.novaenhance.ai

import android.app.Application
import com.novaenhance.ai.di.ServiceLocator
import com.novaenhance.ai.utils.NovaLog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

private const val TAG = "NovaEnhanceApplication"
private const val DEFAULT_MODEL_ID = "general"

class NovaEnhanceApplication : Application() {

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onCreate() {
        super.onCreate()
        val locator = ServiceLocator.get(this)

        appScope.launch {
            try {
                ensureDefaultModel(locator)
            } catch (t: Throwable) {
                // Should essentially never happen now: unlike the project's
                // earlier TFLite-based design, creating a model needs no
                // bundled asset and no external generation step - it's just
                // in-memory random weight initialization (see
                // NativeNeuralEngine.initializeParams) followed by a normal
                // file write. A failure here means something more
                // fundamental is wrong (e.g. out of disk space), not a
                // missing setup step - but this still must never crash app
                // startup, so it's caught and logged either way.
                NovaLog.e(TAG, "Failed to bootstrap default model", t)
            }
        }
    }

    private suspend fun ensureDefaultModel(locator: ServiceLocator) {
        val existing = locator.database.modelDao().getById(DEFAULT_MODEL_ID)
        if (existing != null) return

        locator.modelRepository.createModel(
            modelId = DEFAULT_MODEL_ID,
            displayName = getString(R.string.default_model_name),
            description = getString(R.string.default_model_description)
        )
        NovaLog.i(TAG, "Created default model '$DEFAULT_MODEL_ID' with freshly initialized weights")
    }
}

