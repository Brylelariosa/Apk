package com.novaenhance.ai.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.ui.res.painterResource
import com.novaenhance.ai.R
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.novaenhance.ai.ui.viewmodel.DatasetViewModel
import com.novaenhance.ai.ui.viewmodel.NovaViewModelFactory
import android.net.Uri

@Composable
fun DatasetManagerScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val viewModel: DatasetViewModel = viewModel(factory = NovaViewModelFactory(context))
    val state by viewModel.uiState.collectAsState()

    var pendingLowUri by remember { mutableStateOf<Uri?>(null) }

    val pickLowLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        pendingLowUri = uri
    }
    val pickHighLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        val low = pendingLowUri
        if (low != null && uri != null) {
            viewModel.addManualPair(low, uri)
            pendingLowUri = null
        }
    }
    val pickSyntheticSourceLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { viewModel.addSyntheticPairs(it) }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { viewModel.importDataset(it) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Dataset Manager") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(painterResource(R.drawable.ic_back_arrow), contentDescription = "Back") } }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    "${state.pairs.size} pairs - ${formatBytes(state.totalSizeBytes)}",
                    style = MaterialTheme.typography.titleMedium
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { pickLowLauncher.launch("image/*") }, modifier = Modifier.weight(1f)) {
                        Text("Add Pair")
                    }
                    OutlinedButton(
                        onClick = { pickSyntheticSourceLauncher.launch("image/*") },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Auto-Generate")
                    }
                }
                if (pendingLowUri != null) {
                    Text(
                        "Now pick the matching high-quality image...",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Button(
                        onClick = { pickHighLauncher.launch("image/*") },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Select High-Quality Match") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { importLauncher.launch("application/zip") }, modifier = Modifier.weight(1f)) {
                        Text("Import Dataset")
                    }
                    OutlinedButton(
                        onClick = {
                            viewModel.exportDataset { file ->
                                val uri = androidx.core.content.FileProvider.getUriForFile(
                                    context, "${context.packageName}.fileprovider", file
                                )
                                val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                                    type = "application/zip"
                                    putExtra(android.content.Intent.EXTRA_STREAM, uri)
                                    addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                context.startActivity(android.content.Intent.createChooser(intent, "Share dataset"))
                            }
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Export Dataset")
                    }
                }
                state.message?.let {
                    Text(it, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.error)
                }
            }

            LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)) {
                items(state.pairs, key = { it.id }) { pair ->
                    Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    text = if (pair.isSynthetic) "Auto-generated pair" else "Manual pair",
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                Text(
                                    text = when {
                                        !pair.isValid -> "Invalid: ${pair.invalidReason}"
                                        pair.isDuplicate -> "Duplicate"
                                        pair.analyzedAt == null -> "Analyzing..."
                                        else -> "Quality ${(pair.qualityScore * 100).toInt()}% - Difficulty ${(pair.difficultyScore * 100).toInt()}%"
                                    },
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(onClick = { viewModel.removePair(pair) }) {
                                Icon(painterResource(R.drawable.ic_delete), contentDescription = "Remove pair")
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun formatBytes(bytes: Long): String = when {
    bytes >= 1_000_000 -> "%.1f MB".format(bytes / 1_000_000.0)
    bytes >= 1_000 -> "%.1f KB".format(bytes / 1_000.0)
    else -> "$bytes B"
}
