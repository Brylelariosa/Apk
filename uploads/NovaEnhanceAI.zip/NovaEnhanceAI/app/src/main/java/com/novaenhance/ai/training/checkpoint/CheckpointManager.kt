package com.novaenhance.ai.training.checkpoint

import com.novaenhance.ai.utils.NovaLog
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

private const val TAG = "CheckpointManager"
private const val ENTRY_ARCHITECTURE = "architecture.tflite"
private const val ENTRY_METADATA = "metadata.json"
private const val ENTRY_CHECKPOINT_PREFIX = "checkpoint/"

/**
 * TensorFlow's `tf.train.Checkpoint.write(prefix)` produces several sibling
 * files sharing `prefix` as a common basename start (typically an `.index`
 * file plus one or more `.data-NNNNN-of-MMMMM` shard files) - there is no
 * single "the checkpoint file." Everywhere else in this codebase treats a
 * checkpoint as an opaque unit via [File] "prefixes"; this class is the one
 * place that actually knows how to enumerate/copy/delete/zip the real files
 * behind that prefix.
 */
class CheckpointManager {

    /** All files on disk whose name starts with `prefix`'s file name (the sibling shard/index files). */
    fun filesForPrefix(prefix: File): List<File> {
        val dir = prefix.parentFile ?: return emptyList()
        val baseName = prefix.name
        return dir.listFiles { f -> f.isFile && f.name.startsWith(baseName) }?.toList() ?: emptyList()
    }

    fun totalSizeBytes(prefix: File): Long = filesForPrefix(prefix).sumOf { it.length() }

    fun copyCheckpoint(srcPrefix: File, destPrefix: File) {
        val destDir = destPrefix.parentFile?.apply { mkdirs() }
        for (src in filesForPrefix(srcPrefix)) {
            val suffix = src.name.removePrefix(srcPrefix.name)
            val dest = File(destDir, destPrefix.name + suffix)
            src.copyTo(dest, overwrite = true)
        }
    }

    fun deleteCheckpoint(prefix: File) {
        filesForPrefix(prefix).forEach { it.delete() }
    }

    /**
     * Packages one version into a self-contained, importable `.novamodel`
     * zip: the (shared, constant) architecture graph, this version's
     * checkpoint files if any (null for an untrained v1), and the metadata
     * sidecar. Used by both "Backup" and "Export."
     */
    fun exportBundle(
        architectureFile: File,
        checkpointPrefix: File?,
        metadataFile: File,
        destZip: File
    ) {
        destZip.parentFile?.mkdirs()
        ZipOutputStream(destZip.outputStream().buffered()).use { zip ->
            addEntry(zip, ENTRY_ARCHITECTURE, architectureFile)
            addEntry(zip, ENTRY_METADATA, metadataFile)
            checkpointPrefix?.let { prefix ->
                for (file in filesForPrefix(prefix)) {
                    addEntry(zip, ENTRY_CHECKPOINT_PREFIX + file.name, file)
                }
            }
        }
        NovaLog.i(TAG, "Exported bundle to ${destZip.path} (${destZip.length()} bytes)")
    }

    data class ImportedBundle(
        val architectureFile: File,
        val checkpointPrefix: File?,
        val metadataFile: File
    )

    /**
     * Unpacks a `.novamodel` bundle into [destModelDir] (architecture +
     * metadata) and [destCheckpointDir] (checkpoint files, if the bundle has
     * any - a bundle exported from a never-trained v1 won't).
     */
    fun importBundle(zipFile: File, destModelDir: File, destCheckpointDir: File, checkpointVersionNumber: Int): ImportedBundle {
        destModelDir.mkdirs()
        destCheckpointDir.mkdirs()

        val architectureFile = File(destModelDir, "architecture.tflite")
        val metadataFile = File(destModelDir, "metadata.json")
        var checkpointPrefix: File? = null
        val checkpointDestPrefix = File(destCheckpointDir, "v$checkpointVersionNumber.ckpt")

        ZipInputStream(zipFile.inputStream().buffered()).use { zip ->
            var entry: ZipEntry? = zip.nextEntry
            while (entry != null) {
                when {
                    entry.name == ENTRY_ARCHITECTURE -> writeEntry(zip, architectureFile)
                    entry.name == ENTRY_METADATA -> writeEntry(zip, metadataFile)
                    entry.name.startsWith(ENTRY_CHECKPOINT_PREFIX) -> {
                        val originalName = entry.name.removePrefix(ENTRY_CHECKPOINT_PREFIX)
                        // Preserve the shard/index suffix (everything after the
                        // original prefix's basename) but re-home it under the
                        // NEW version's checkpoint prefix for this install.
                        val suffix = originalName.substringAfter(".ckpt", missingDelimiterValue = "")
                        val destFile = File(destCheckpointDir, "v$checkpointVersionNumber.ckpt$suffix")
                        writeEntry(zip, destFile)
                        checkpointPrefix = checkpointDestPrefix
                    }
                }
                zip.closeEntry()
                entry = zip.nextEntry
            }
        }

        require(architectureFile.exists()) { "Bundle is missing architecture.tflite" }
        return ImportedBundle(architectureFile, checkpointPrefix, metadataFile)
    }

    private fun addEntry(zip: ZipOutputStream, name: String, file: File) {
        zip.putNextEntry(ZipEntry(name))
        file.inputStream().use { it.copyTo(zip) }
        zip.closeEntry()
    }

    private fun writeEntry(zip: ZipInputStream, dest: File) {
        dest.outputStream().use { out -> zip.copyTo(out) }
    }
}
