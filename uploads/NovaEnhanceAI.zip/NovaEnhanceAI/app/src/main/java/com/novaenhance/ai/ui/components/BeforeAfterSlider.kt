package com.novaenhance.ai.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.res.painterResource
import com.novaenhance.ai.R
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp

/**
 * The app's signature interaction: drag the teal divider to wipe between
 * the original (left) and AI-enhanced (right) image. This is the one place
 * the app takes a real visual/interaction risk - everywhere else in the UI
 * is calm and information-dense by comparison, which is deliberate (see
 * ui/theme's design note on the palette telling the enhancement story).
 */
@Composable
fun BeforeAfterSlider(
    original: Bitmap,
    enhanced: Bitmap,
    modifier: Modifier = Modifier
) {
    var dividerFraction by remember { mutableFloatStateOf(0.5f) }
    val originalImage = remember(original) { original.asImageBitmap() }
    val enhancedImage = remember(enhanced) { enhanced.asImageBitmap() }
    val handleColor = MaterialTheme.colorScheme.primary

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectDragGestures { change, _ ->
                    change.consume()
                    dividerFraction = (change.position.x / size.width).coerceIn(0f, 1f)
                }
            }
    ) {
        val widthPx = constraints.maxWidth.toFloat()
        val heightPx = constraints.maxHeight.toFloat()

        // "After" image fills the whole frame; "before" is clipped over the
        // left portion up to the divider, so dragging right reveals more of
        // the original and dragging left reveals more of the AI result.
        Image(
            bitmap = enhancedImage,
            contentDescription = "Enhanced image",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Fit
        )

        Canvas(modifier = Modifier.fillMaxSize()) {
            clipRect(right = widthPx * dividerFraction) {
                drawImage(originalImage)
            }
            drawLine(
                color = handleColor,
                start = Offset(widthPx * dividerFraction, 0f),
                end = Offset(widthPx * dividerFraction, heightPx),
                strokeWidth = 3.dp.toPx()
            )
        }

        val handleDiameter = 40.dp
        val handleOffsetX = with(androidx.compose.ui.platform.LocalDensity.current) {
            (widthPx * dividerFraction).toDp() - (handleDiameter / 2)
        }
        Surface(
            modifier = Modifier
                .align(Alignment.CenterStart)
                .offset(x = handleOffsetX)
                .size(handleDiameter),
            shape = CircleShape,
            color = handleColor,
            shadowElevation = 6.dp
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    painter = painterResource(R.drawable.ic_swap_horizontal),
                    contentDescription = "Drag to compare before and after",
                    tint = Color.White,
                    modifier = Modifier.padding(8.dp)
                )
            }
        }
    }
}
