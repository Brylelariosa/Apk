package com.novaenhance.ai.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.novaenhance.ai.database.dao.DatasetPairDao
import com.novaenhance.ai.database.dao.LossHistoryDao
import com.novaenhance.ai.database.dao.ModelDao
import com.novaenhance.ai.database.dao.ModelVersionDao
import com.novaenhance.ai.database.dao.ReplayBufferDao
import com.novaenhance.ai.database.dao.TrainingSessionDao
import com.novaenhance.ai.database.dao.ValidationMetricDao
import com.novaenhance.ai.database.entities.DatasetPairEntity
import com.novaenhance.ai.database.entities.LossHistoryEntity
import com.novaenhance.ai.database.entities.ModelEntity
import com.novaenhance.ai.database.entities.ModelVersionEntity
import com.novaenhance.ai.database.entities.ReplayBufferEntity
import com.novaenhance.ai.database.entities.TrainingSessionEntity
import com.novaenhance.ai.database.entities.ValidationMetricEntity

@Database(
    entities = [
        ModelEntity::class,
        ModelVersionEntity::class,
        DatasetPairEntity::class,
        TrainingSessionEntity::class,
        LossHistoryEntity::class,
        ValidationMetricEntity::class,
        ReplayBufferEntity::class
    ],
    version = 1,
    exportSchema = true
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun modelDao(): ModelDao
    abstract fun modelVersionDao(): ModelVersionDao
    abstract fun datasetPairDao(): DatasetPairDao
    abstract fun trainingSessionDao(): TrainingSessionDao
    abstract fun lossHistoryDao(): LossHistoryDao
    abstract fun validationMetricDao(): ValidationMetricDao
    abstract fun replayBufferDao(): ReplayBufferDao

    companion object {
        @Volatile private var instance: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "novaenhance.db"
                )
                    // No destructive fallback in production: a schema change
                    // must ship a real Migration so users never silently lose
                    // their training history / dataset registry.
                    .build()
                    .also { instance = it }
            }
    }
}
