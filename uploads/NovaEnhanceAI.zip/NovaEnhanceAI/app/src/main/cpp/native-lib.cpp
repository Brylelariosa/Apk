#include <jni.h>
#include <android/log.h>
#include <android/bitmap.h>
#include <vector>

#include "filters/convolution.h"
#include "filters/degradation.h"
#include "nn/network.h"

#define LOG_TAG "NovaEnhanceNative"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace {

// Copies a Java int[] into a std::vector<int32_t> without extra bounds churn.
std::vector<int32_t> toVector(JNIEnv* env, jintArray arr) {
    jsize len = env->GetArrayLength(arr);
    std::vector<int32_t> out(len);
    env->GetIntArrayRegion(arr, 0, len, reinterpret_cast<jint*>(out.data()));
    return out;
}

jintArray toJavaArray(JNIEnv* env, const std::vector<int32_t>& vec) {
    jintArray result = env->NewIntArray(static_cast<jsize>(vec.size()));
    if (result == nullptr) return nullptr;
    env->SetIntArrayRegion(result, 0, static_cast<jsize>(vec.size()),
                            reinterpret_cast<const jint*>(vec.data()));
    return result;
}

}  // namespace

extern "C" {

JNIEXPORT jintArray JNICALL
Java_com_novaenhance_ai_ai_engine_NativeImageProcessor_nativeGaussianBlur(
        JNIEnv* env, jobject /* this */, jintArray pixels, jint width, jint height, jfloat sigma) {
    auto in = toVector(env, pixels);
    auto out = novaenhance::gaussianBlur(in, width, height, sigma);
    return toJavaArray(env, out);
}

JNIEXPORT jintArray JNICALL
Java_com_novaenhance_ai_ai_engine_NativeImageProcessor_nativeUnsharpMask(
        JNIEnv* env, jobject, jintArray pixels, jint width, jint height, jfloat sigma, jfloat amount) {
    auto in = toVector(env, pixels);
    auto out = novaenhance::unsharpMask(in, width, height, sigma, amount);
    return toJavaArray(env, out);
}

JNIEXPORT jintArray JNICALL
Java_com_novaenhance_ai_ai_engine_NativeImageProcessor_nativeDenoiseBilateral(
        JNIEnv* env, jobject, jintArray pixels, jint width, jint height,
        jfloat spatialSigma, jfloat rangeSigma) {
    auto in = toVector(env, pixels);
    auto out = novaenhance::denoiseBilateral(in, width, height, spatialSigma, rangeSigma);
    return toJavaArray(env, out);
}

JNIEXPORT jintArray JNICALL
Java_com_novaenhance_ai_ai_engine_NativeImageProcessor_nativeResizeBilinear(
        JNIEnv* env, jobject, jintArray pixels, jint srcWidth, jint srcHeight,
        jint dstWidth, jint dstHeight) {
    auto in = toVector(env, pixels);
    auto out = novaenhance::resizeBilinear(in, srcWidth, srcHeight, dstWidth, dstHeight);
    return toJavaArray(env, out);
}

JNIEXPORT jfloat JNICALL
Java_com_novaenhance_ai_ai_engine_NativeImageProcessor_nativeQuickSimilarityScore(
        JNIEnv* env, jobject, jintArray a, jintArray b, jint width, jint height) {
    auto va = toVector(env, a);
    auto vb = toVector(env, b);
    return novaenhance::quickSimilarityScore(va, vb, width, height);
}

JNIEXPORT jintArray JNICALL
Java_com_novaenhance_ai_ai_engine_NativeImageProcessor_nativeAddGaussianNoise(
        JNIEnv* env, jobject, jintArray pixels, jint width, jint height, jfloat amount, jint seed) {
    auto in = toVector(env, pixels);
    auto out = novaenhance::addGaussianNoise(in, width, height, amount, static_cast<uint32_t>(seed));
    return toJavaArray(env, out);
}

JNIEXPORT jintArray JNICALL
Java_com_novaenhance_ai_ai_engine_NativeImageProcessor_nativeSimulateJpegArtifacts(
        JNIEnv* env, jobject, jintArray pixels, jint width, jint height, jint qualityPercent) {
    auto in = toVector(env, pixels);
    auto out = novaenhance::simulateJpegArtifacts(in, width, height, qualityPercent);
    return toJavaArray(env, out);
}

JNIEXPORT jintArray JNICALL
Java_com_novaenhance_ai_ai_engine_NativeImageProcessor_nativeMotionBlur(
        JNIEnv* env, jobject, jintArray pixels, jint width, jint height, jfloat angleDegrees, jint lengthPx) {
    auto in = toVector(env, pixels);
    auto out = novaenhance::motionBlur(in, width, height, angleDegrees, lengthPx);
    return toJavaArray(env, out);
}

JNIEXPORT jintArray JNICALL
Java_com_novaenhance_ai_ai_engine_NativeImageProcessor_nativeColorFade(
        JNIEnv* env, jobject, jintArray pixels, jint width, jint height, jfloat fadeAmount) {
    auto in = toVector(env, pixels);
    auto out = novaenhance::colorFade(in, width, height, fadeAmount);
    return toJavaArray(env, out);
}

// Direct-bitmap fast path used for cheap dashboard/gallery thumbnails, where
// copying through a Kotlin IntArray twice (Bitmap -> IntArray -> JNI -> IntArray
// -> Bitmap) would waste memory on top of the two Bitmap objects already
// involved. This is the one place we use jnigraphics' native bitmap locking
// directly instead of the int-array tile API.
// NOTE on byte order: AndroidBitmap_lockPixels exposes raw native memory in
// RGBA_8888 byte order, which is NOT the same int32 layout as the ARGB_8888
// ints Bitmap.getPixels()/setPixels() hand to the int-array pipeline above.
// resizeBilinear is safe to use directly on this raw buffer because it only
// does independent per-byte-slot linear interpolation and repacks each slot
// back into its original position - it never assigns channel-specific
// meaning (e.g. luma weighting) to a given slot. If a future native-bitmap
// function needs channel-aware math (denoise, color fade, similarity), it
// MUST NOT reuse resizeBilinear's assumption; convert to the int-array path
// (which is guaranteed ARGB_8888) or add explicit RGBA-aware channel maths.
JNIEXPORT jboolean JNICALL
Java_com_novaenhance_ai_ai_engine_NativeImageProcessor_nativeResizeBitmapInto(

        JNIEnv* env, jobject, jobject srcBitmap, jobject dstBitmap) {
    AndroidBitmapInfo srcInfo, dstInfo;
    void* srcPixels = nullptr;
    void* dstPixels = nullptr;

    if (AndroidBitmap_getInfo(env, srcBitmap, &srcInfo) < 0 ||
        AndroidBitmap_getInfo(env, dstBitmap, &dstInfo) < 0) {
        LOGE("nativeResizeBitmapInto: failed to read bitmap info");
        return JNI_FALSE;
    }
    if (srcInfo.format != ANDROID_BITMAP_FORMAT_RGBA_8888 ||
        dstInfo.format != ANDROID_BITMAP_FORMAT_RGBA_8888) {
        LOGE("nativeResizeBitmapInto: only RGBA_8888 is supported");
        return JNI_FALSE;
    }

    if (AndroidBitmap_lockPixels(env, srcBitmap, &srcPixels) < 0) return JNI_FALSE;
    if (AndroidBitmap_lockPixels(env, dstBitmap, &dstPixels) < 0) {
        AndroidBitmap_unlockPixels(env, srcBitmap);
        return JNI_FALSE;
    }

    std::vector<int32_t> srcVec(srcInfo.width * srcInfo.height);
    memcpy(srcVec.data(), srcPixels, srcVec.size() * sizeof(int32_t));

    auto resized = novaenhance::resizeBilinear(
            srcVec, static_cast<int>(srcInfo.width), static_cast<int>(srcInfo.height),
            static_cast<int>(dstInfo.width), static_cast<int>(dstInfo.height));

    memcpy(dstPixels, resized.data(), resized.size() * sizeof(int32_t));

    AndroidBitmap_unlockPixels(env, srcBitmap);
    AndroidBitmap_unlockPixels(env, dstBitmap);
    return JNI_TRUE;
}

// ============================================================================
// NativeNeuralEngine - the from-scratch (no TensorFlow) CNN. See
// nn/network.h for the architecture and nn/network.cpp for the verified
// forward/backward/Adam implementation. Every array here is passed by
// direct reference (GetFloatArrayElements, mode 0 on release) since
// nativeTrainStep mutates params/momentum/velocity IN PLACE - there's no
// native-side persistent state or handle to manage, which keeps the
// Kotlin/JNI lifetime story simple (nothing to leak, nothing to explicitly
// destroy).
// ============================================================================

JNIEXPORT void JNICALL
Java_com_novaenhance_ai_ai_engine_NativeNeuralEngine_nativeInitializeParams(
        JNIEnv* env, jobject, jfloatArray params, jlong seed) {
    jfloat* p = env->GetFloatArrayElements(params, nullptr);
    novaenhance::nn::initializeParams(p, static_cast<uint32_t>(seed));
    env->ReleaseFloatArrayElements(params, p, 0);
}

JNIEXPORT jfloatArray JNICALL
Java_com_novaenhance_ai_ai_engine_NativeNeuralEngine_nativeInfer(
        JNIEnv* env, jobject, jfloatArray input, jfloatArray params) {
    jfloat* inputPtr = env->GetFloatArrayElements(input, nullptr);
    jfloat* paramsPtr = env->GetFloatArrayElements(params, nullptr);

    std::vector<float> output(novaenhance::nn::OUTPUT_FLOATS);
    novaenhance::nn::inferForward(inputPtr, paramsPtr, output.data());

    env->ReleaseFloatArrayElements(input, inputPtr, JNI_ABORT);   // read-only, no need to copy back
    env->ReleaseFloatArrayElements(params, paramsPtr, JNI_ABORT); // read-only for inference

    jfloatArray result = env->NewFloatArray(static_cast<jsize>(output.size()));
    env->SetFloatArrayRegion(result, 0, static_cast<jsize>(output.size()), output.data());
    return result;
}

JNIEXPORT jfloat JNICALL
Java_com_novaenhance_ai_ai_engine_NativeNeuralEngine_nativeTrainStep(
        JNIEnv* env, jobject,
        jfloatArray inputBatch, jfloatArray targetBatch, jint batchSize,
        jfloatArray params, jfloatArray momentum, jfloatArray velocity,
        jfloatArray anchorParams,  // nullable
        jint adamStepNumber, jfloat learningRate, jfloat l2SpLambda) {
    jfloat* inputPtr = env->GetFloatArrayElements(inputBatch, nullptr);
    jfloat* targetPtr = env->GetFloatArrayElements(targetBatch, nullptr);
    jfloat* paramsPtr = env->GetFloatArrayElements(params, nullptr);
    jfloat* momentumPtr = env->GetFloatArrayElements(momentum, nullptr);
    jfloat* velocityPtr = env->GetFloatArrayElements(velocity, nullptr);
    jfloat* anchorPtr = anchorParams != nullptr ? env->GetFloatArrayElements(anchorParams, nullptr) : nullptr;

    float loss = novaenhance::nn::trainStep(
            inputPtr, targetPtr, batchSize,
            paramsPtr, momentumPtr, velocityPtr,
            anchorPtr, adamStepNumber, learningRate, l2SpLambda);

    env->ReleaseFloatArrayElements(inputBatch, inputPtr, JNI_ABORT);
    env->ReleaseFloatArrayElements(targetBatch, targetPtr, JNI_ABORT);
    env->ReleaseFloatArrayElements(params, paramsPtr, 0);      // mutated - commit back
    env->ReleaseFloatArrayElements(momentum, momentumPtr, 0);  // mutated - commit back
    env->ReleaseFloatArrayElements(velocity, velocityPtr, 0);  // mutated - commit back
    if (anchorParams != nullptr) {
        env->ReleaseFloatArrayElements(anchorParams, anchorPtr, JNI_ABORT);  // read-only
    }

    return loss;
}

}  // extern "C"

