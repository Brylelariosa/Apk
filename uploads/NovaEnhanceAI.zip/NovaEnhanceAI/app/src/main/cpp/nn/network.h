#ifndef NOVAENHANCE_NETWORK_H
#define NOVAENHANCE_NETWORK_H

#include <cstdint>
#include <vector>

namespace novaenhance::nn {

// ============================================================================
// FIXED ARCHITECTURE - a small residual CNN, hand-implemented (forward AND
// backward) with NO TensorFlow/TFLite dependency anywhere. This replaces the
// earlier TFLite-based design entirely: there is no .tflite file, no Python
// step, no SavedModel/checkpoint format. A model IS simply this flat array
// of floats; "training" is real gradient descent implemented below and
// verified against numerical gradient-checking before being ported here
// (see tools/nn_verification/ for the NumPy reference this was checked
// against - kept for anyone who wants to re-verify the math, not needed to
// build the app).
//
//   input (tileSize x tileSize x 3, float32 [0,1])
//     -> Conv 3x3, 3->32, ReLU
//     -> Conv 3x3, 32->32, ReLU
//     -> Conv 3x3, 32->32, ReLU
//     -> Conv 3x3, 32->3           (near-zero init - see initializeParams)
//     -> output = clip(input + conv4_out, 0, 1)     (global residual)
//
// Deliberately small (~20K parameters) rather than millions: every layer's
// backward pass is hand-derived and gradient-checked, and this network runs
// on a phone CPU with plain nested-loop convolution (no BLAS, no SIMD
// intrinsics, no GPU delegate) - capacity is traded for being small enough
// to verify correctly and fast enough to actually train in the background.
// ============================================================================

constexpr int TILE_SIZE = 64;
constexpr int KERNEL = 3;
constexpr int CIN = 3;
constexpr int C1 = 32;
constexpr int C2 = 32;
constexpr int COUT = 3;

// Flat parameter vector layout - every weight/bias for all 4 layers lives in
// ONE contiguous float array, at these fixed offsets. Both the C++ side and
// the Kotlin side (NetworkLayout.kt) hard-code these same numbers rather
// than negotiating shapes at runtime - one less thing that can silently
// disagree between the two languages.
constexpr int W1_SIZE = KERNEL * KERNEL * CIN * C1;   // 864
constexpr int B1_SIZE = C1;                            // 32
constexpr int W2_SIZE = KERNEL * KERNEL * C1 * C1;     // 9216
constexpr int B2_SIZE = C1;                            // 32
constexpr int W3_SIZE = KERNEL * KERNEL * C1 * C2;     // 9216
constexpr int B3_SIZE = C2;                            // 32
constexpr int W4_SIZE = KERNEL * KERNEL * C2 * COUT;   // 864
constexpr int B4_SIZE = COUT;                          // 3

constexpr int W1_OFFSET = 0;
constexpr int B1_OFFSET = W1_OFFSET + W1_SIZE;
constexpr int W2_OFFSET = B1_OFFSET + B1_SIZE;
constexpr int B2_OFFSET = W2_OFFSET + W2_SIZE;
constexpr int W3_OFFSET = B2_OFFSET + B2_SIZE;
constexpr int B3_OFFSET = W3_OFFSET + W3_SIZE;
constexpr int W4_OFFSET = B3_OFFSET + B3_SIZE;
constexpr int B4_OFFSET = W4_OFFSET + W4_SIZE;
constexpr int TOTAL_PARAMS = B4_OFFSET + B4_SIZE;      // 20259

constexpr int TILE_PIXELS = TILE_SIZE * TILE_SIZE;
constexpr int INPUT_FLOATS = TILE_PIXELS * CIN;
constexpr int OUTPUT_FLOATS = TILE_PIXELS * COUT;

// Global L2-norm ceiling for the gradient vector before each Adam update -
// see clipGradientNorm's doc comment in network.cpp for why this exists.
constexpr float MAX_GRADIENT_NORM = 1.0f;

/** He-initializes conv1-3, near-zeros conv4 (so the network starts as an
 * approximate identity function - same rationale as the original TFLite
 * design's tail-conv init), zeros all biases. */
void initializeParams(float* params, uint32_t seed);

/** Forward pass only (inference). input/output are TILE_SIZE x TILE_SIZE x {3,3} float32. */
void inferForward(const float* input, const float* params, float* output);

/**
 * Forward + backward + one Adam optimizer step, over a batch, entirely
 * in-place on `params`/`momentum`/`velocity`. Returns the average L1 loss
 * over the batch (pre-update, i.e. the loss the gradients were computed
 * from). `anchorParams` may be null (and l2SpLambda should be 0) to disable
 * the anti-forgetting penalty entirely, e.g. a model's very first session.
 */
float trainStep(
    const float* inputBatch,
    const float* targetBatch,
    int batchSize,
    float* params,
    float* momentum,
    float* velocity,
    const float* anchorParams,   // nullable
    int adamStepNumber,          // 1-indexed, for Adam bias correction
    float learningRate,
    float l2SpLambda
);

}  // namespace novaenhance::nn

#endif  // NOVAENHANCE_NETWORK_H
