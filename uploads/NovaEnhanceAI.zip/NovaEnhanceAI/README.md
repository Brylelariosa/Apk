# NovaEnhance AI

An offline, on-device AI photo enhancement app for Android. You teach the
model with your own low-quality/high-quality image pairs; it keeps improving
through real on-device training - no cloud, no accounts, no servers, no API
keys, anywhere in this codebase.

## What's actually running on-device

- **Inference & training**: TensorFlow Lite, using its on-device training
  feature (a `.tflite` graph exported with `train`/`infer`/`save`/`restore`/
  `set_anchor` signatures - see `tools/model_builder/build_model.py`). This is
  real backpropagation on the phone, not a simulated progress bar.
- **Classical image processing**: a small native (NDK/C++) library
  (`app/src/main/cpp`) doing tile-based Gaussian blur, unsharp-mask
  sharpening, bilateral denoise, bilinear resize, and the synthetic
  degradations (noise/JPEG-blocking/motion-blur/color-fade) used by the
  automatic dataset generator.
- **Anti-forgetting**: experience replay (a curated buffer of past training
  pairs mixed into every new session) + L2-SP regularization (a penalty for
  drifting away from an anchored snapshot of pre-session weights). This is
  described honestly as replay + L2-SP, not as full Elastic Weight
  Consolidation, which would need Fisher-information machinery this project
  doesn't implement.
- **Adaptive training / self-improvement loop**: rule-based heuristics
  (batch size / learning rate / epochs derived from RAM, thermal state, and
  recent loss trends) and a weak-area rescoring pass after each promoted
  session - see `training/trainer/AdaptiveTrainingController.kt` and
  `SelfImprovementOrchestrator.kt` for exactly what each does and why.

## Before your first build

This project ships **without** a pretrained `.tflite` file committed to git
(see `.gitignore` - it's a generated build artifact, not source). Two ways
to get one:

1. **GitHub Actions (automatic)**: `.github/workflows/android-build.yml`
   installs Python + TensorFlow and runs
   `tools/model_builder/build_model.py` before the Gradle build, writing
   `app/src/main/assets/models/general_v1.tflite` fresh every run. A clean
   checkout pushed to Actions just works.
2. **Local Android Studio build**: run the script yourself once:
   ```
   cd tools/model_builder
   python3 -m venv venv && source venv/bin/activate
   pip install -r requirements.txt
   python build_model.py --output ../../app/src/main/assets/models/general_v1
   ```
   Requires TensorFlow 2.15+ (CPU-only is fine). This is a one-time step to
   author the network *architecture* - after that, all real training happens
   in the Android app itself.

If neither has happened yet, the app does **not** crash: `ModelRepository`/
`NovaEnhanceApplication` catch the missing-asset case, the Dashboard shows
"No model yet," and Enhance/Train are inertly disabled with an explanatory
message until a model is available (bootstrapped this way, or imported as a
`.novamodel` bundle via Model Manager).

## Build commands

```
./gradlew assembleDebug --no-daemon --configuration-cache --build-cache --parallel
./gradlew assembleRelease --no-daemon --configuration-cache --build-cache --parallel
```

Requires JDK 17, Gradle 8.6 (the CI workflow materializes the wrapper itself
- see the workflow file's comments for why a wrapper jar isn't hand-committed),
Android SDK, NDK 25.2.9519653, CMake 3.22.1. Release builds fall back to
debug signing if no `RELEASE_STORE_*` secrets/`app/keystore.properties` are
configured, so `assembleRelease` succeeds on a brand-new checkout with zero
manual setup - replace that with real signing before shipping to users.

## Testing

`app/src/test` has JVM unit tests for every piece of pure logic that doesn't
need a real Android framework/device (pixel-buffer padding/cropping, tensor
codec round-trips including a regression test for a rounding-bias fix,
checkpoint file glob/copy/delete and the `.novamodel` bundle format, model
metadata JSON round-tripping, degradation-recipe range invariants, and the
result-type helpers). Run them with:

```
./gradlew testDebugUnitTest
```

Code that needs `android.graphics.Bitmap`, `Context`, or other
framework/device behavior (the AI engine's tile processing, dataset
analysis, the DAOs) is written to be exercised by instrumented tests
(`app/src/androidTest`) on a real device/emulator - none are included yet,
since I can't run an emulator in the environment this was built in to
verify them.

## Architecture

```
ui/            Jetpack Compose screens, ViewModels, navigation, theme
ai/
  engine/      TFLite engine lifecycle, tile processing, classical filters (JNI bridge)
  inference/   Low-level TFLite signature-runner wrapper
  model/       Model metadata + registry/version repository
training/
  trainer/     Adaptive controller, experience replay, validator, the training
               orchestrator itself, and the self-improvement loop
  dataset/     Dataset analysis (dedup/quality/difficulty), degradation generator,
               dataset manager (add/remove/import/export)
  checkpoint/  TF checkpoint file management + the .novamodel export/import bundle format
database/      Room entities/DAOs (model registry, versions, dataset, sessions,
               loss history, validation metrics, replay buffer)
storage/       Centralized file-path resolution + DataStore-backed settings
workers/       WorkManager (constraint scheduling) + the training foreground service
di/            Manual dependency-injection container (see ServiceLocator's doc
               comment for why this isn't Hilt)
```

`app/src/main/cpp` holds the native image-filter library; `tools/model_builder`
holds the offline Python step described above.

## Honest limitations

- This was built without the ability to run an actual Android/Gradle build
  or execute the on-device training code end-to-end - there's no Android
  SDK, emulator, or network access in the environment it was written in. The
  code has been written and reviewed carefully, and the architecture follows
  documented, real APIs (TFLite's on-device training signatures, Room,
  WorkManager, foreground services, JNI/NDK), but "the CI badge is green" is
  the actual verification step, not a claim made here.
- The `save`/`restore` signatures pass the checkpoint path as a scalar
  string tensor - this is the one part of the TFLite Java bridge most worth
  a real-device smoke test early (see the comment in
  `ai/inference/TFLiteSignatureRunner.kt` for exactly what's uncertain and why).
- The validation metrics (detail recovery, noise reduction, sharpness
  improvement, artifact removal) are deliberately simple, explainable
  proxies (PSNR, a Laplacian-based sharpness/noise estimate, a block-edge
  gradient ratio) - not a claim of research-grade no-reference image quality
  assessment, which remains an open problem.
- The shipped model is **not** post-training INT8 quantized. On-device
  trainability (the "train" signature) needs float32 weights and optimizer
  state for standard gradient descent, so quantizing those variables would
  break training - see the comment in `build_model.py`'s `convert_to_tflite`
  for the actual trade-off and a path to add a quantized *inference-only*
  export later for models a user is done training.
