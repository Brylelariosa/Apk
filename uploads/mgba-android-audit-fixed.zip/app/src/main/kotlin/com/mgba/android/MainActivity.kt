package com.mgba.android

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.text.InputType
import android.text.format.DateFormat
import android.util.Log
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.PixelCopy
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.Closeable
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.io.PrintWriter
import java.io.StringWriter
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.util.zip.ZipInputStream
import kotlin.math.abs
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity(), SurfaceHolder.Callback {

    private lateinit var surfaceView: SurfaceView
    private lateinit var settingsBtn: TextView
    private lateinit var settingsMenuOverlay: LinearLayout
    // ── Memory viewer (see showMemoryViewer()/buildMemoryViewer()) ──────────
    // FEATURE: live GBA memory inspector, requested for watching game state
    // (Pokémon battle values — HP, party data, etc. — were the specific
    // example) change in real time. Deliberately built as an overlay, same
    // built-once/shown-hidden pattern as Settings just below, rather than
    // its own Activity the way the ROM browser is — the whole point is to
    // watch memory *while the game keeps running underneath*, which an
    // Activity switch (pausing MainActivity, per the Android lifecycle)
    // would work against; showSettingsMenu() already establishes that
    // showing an overlay here does NOT stop the game loop, exactly what
    // this needs too. Read-only for now: inspects live RAM, as asked for,
    // not a cheat/poke tool — see showMemoryViewer()'s own doc comment.
    private lateinit var memoryViewerOverlay: LinearLayout
    private lateinit var memoryDumpText: TextView
    private lateinit var memoryAddressText: TextView
    private var memoryRegionIndex = 0
    private var memoryPageOffset = 0
    // ROM browser fields (romBrowserOverlay, romBrowserListLayout,
    // romBrowserPathText, romBrowserBackBtn, romBrowserDeviceRoot,
    // romBrowserStack, romBrowserGeneration) all moved out this pass
    // (Thirty-second) into RomBrowserActivity.kt, a separate Activity now —
    // see changeRom()/romBrowserLauncher below and RomBrowserActivity.kt's
    // own top-of-file comment for why (a real, twice-reproduced native
    // crash from forcing orientation on this screen while it lived here as
    // an overlay in the same window as the game surface).
    // ── Screen orientation (see applyScreenOrientationPref()/showVideoSettings()) ──
    private var screenOrientationChoice: Int = ORIENTATION_LANDSCAPE
    private var surfaceHolder: SurfaceHolder? = null
    private var gameThread:    Thread? = null
    @Volatile private var running   = false
    @Volatile private var romLoaded = false
    // ── Save states / battery save ────────────────────────────────────────
    // Identifies the loaded ROM for save-file naming (both the battery .sav
    // and save-state slots below) — see deriveRomBaseName(). Kept separate
    // from the fixed "rom_loaded.gba" cache path every ROM is copied to
    // (see romPicker) so switching ROMs (via Settings → Change ROM) never
    // mixes one game's save data into another's.
    @Volatile private var currentRomBaseName = "rom"
    // ── Triple-buffered framebuffers ────────────────────────────────────────
    // AUDIO FIX (this pass — root cause of crackle/stutter/perceived pitch
    // drift): renderFrame() (lockCanvas/drawBitmap/unlockCanvasAndPost) used
    // to run on the SAME thread as writePcm(), right after it, every frame.
    // Since writePcm() blocking IS the frame pacer now (see startGameLoop()),
    // any slow render — a GC pause, a busy compositor, a software-canvas
    // SurfaceView on a budget device — delayed the *next* audio write too.
    // That starves AudioTrack while the render is stuck, which is heard as a
    // click/pop when playback resumes (buffer underrun), and the resulting
    // irregular frame delivery reads as choppiness or "speed" wobble even
    // though no single sample is mispitched. This was flagged in an earlier
    // pass as a known, deferred risk ("the real fix is decoupling rendering
    // onto its own thread") rather than fixed outright.
    //
    // Fix: three Bitmap buffers, ping-ponged so the game thread never writes
    // into a buffer the renderer might currently be reading:
    //   writeIdx   — owned by the game thread; where nativeRunFrame() writes.
    //   readyIdx   — the most recently completed frame, swapped in under
    //                bufferLock once a frame finishes; -1 = none yet.
    //   displayIdx — owned by the Choreographer render callback; the buffer
    //                it last drew (and may still be drawing via the Surface).
    // The game thread always picks its next writeIdx as whichever of the 3
    // indices is neither readyIdx nor displayIdx — with 3 buffers and only
    // 2 "spoken for" at once, a free one always exists, so the writer never
    // blocks on the renderer and the renderer never tears mid-draw.
    // The renderer runs off Choreographer.postFrameCallback — i.e. paced by
    // the display's own vsync — completely independent of how fast the
    // audio-locked game thread is producing frames.
    private var frameBuffers: Array<Bitmap>? = null
    private var writeIdx = 0
    private val bufferLock = Object()
    private var readyIdx = -1
    private var displayIdx = -1
    @Volatile private var renderLoopActive = false
    private val renderCallback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!renderLoopActive) return
            val bufs = frameBuffers
            if (bufs != null) {
                var toDraw = -1
                synchronized(bufferLock) {
                    if (readyIdx != -1 && readyIdx != displayIdx) {
                        displayIdx = readyIdx
                    }
                    toDraw = displayIdx
                }
                if (toDraw != -1) renderFrame(bufs[toDraw])
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }
    private fun startRenderLoop() {
        // Choreographer is thread-affine (it binds to whichever thread first
        // asks for an instance) and stopGameLoop() can be called from a
        // background thread (see romPicker's reload path). Flip the volatile
        // flag immediately — doFrame() checks it before ever rescheduling
        // itself, so that alone halts the loop within one vsync tick — and
        // push the actual Choreographer registration through mainHandler so
        // it's always made from the main thread's Choreographer instance.
        renderLoopActive = true
        mainHandler.post {
            if (renderLoopActive) Choreographer.getInstance().postFrameCallback(renderCallback)
        }
    }
    private fun stopRenderLoop() {
        renderLoopActive = false
        mainHandler.post { Choreographer.getInstance().removeFrameCallback(renderCallback) }
    }
    private val gameMatrix  = Matrix()
    private val currentKeys = AtomicInteger(0)
    // BUG FIX ("buttons disappear while dragging"): this used to be a
    // `mutableListOf<ButtonDef>()` that buildControlLayout() mutated in
    // place — buttons.clear() followed by ~11 buttons += calls. That's
    // called on every ACTION_MOVE while dragging a button in the editor
    // (see onEditTouch), i.e. dozens of times a second, ON THE UI THREAD —
    // while the game thread's render loop reads this same list ~60x/sec to
    // draw it (drawControls()). There was no synchronization between the
    // two, so the render thread could paint a frame at the exact moment the
    // list was between clear() and being refilled: every button vanishes
    // for that one frame. Worse under load (exactly when you're actively
    // dragging), which matches "it freezes/disappears when you move it".
    // Fix: build a brand-new list off to the side and swap the *reference*
    // in one atomic write. The render thread then only ever sees a fully
    // "old" or fully "new" list, never a half-built one.
    @Volatile private var buttons: List<ButtonDef> = emptyList()
    private var controlsTop = 0f
    // pickerLive moved to RomBrowserActivity this pass — its only two uses
    // (romPicker, the classic single-file fallback) moved there with it.
    private lateinit var link: LinkMultiplayer
    private val mainHandler = Handler(Looper.getMainLooper())

    // ── Control layout editor ────────────────────────────────────────────────
    // Per-button position/size/opacity overrides, keyed by stable button id
    // ("dpad","a","b","start","select","l","r","ff", …). Absent from the
    // map == "use the default geometric layout computed in buildControlLayout()".
    // Positions are stored as FRACTIONS of screen width/height (not raw
    // pixels) so a saved layout still makes sense if the app is later run on
    // a different screen size. Persisted as JSON in SharedPreferences,
    // keyed per orientation (see orientationTag()) so a future portrait mode
    // doesn't inherit an unsuitable landscape layout — today the activity is
    // locked to landscape (android:screenOrientation="landscape"), so only
    // the "land" profile is ever active, but the storage format doesn't need
    // to change when portrait support is eventually added.
    private data class LayoutEntry(
        var xFrac: Float,
        var yFrac: Float,
        var scale: Float = 1f,
        var alphaOverride: Int = -1,   // -1 == inherit the global idle-alpha setting
        var locked: Boolean = false
    )
    private data class Geometry(val cx: Float, val cy: Float, val w: Float, val h: Float)

    private val customLayout = mutableMapOf<String, LayoutEntry>()
    private val defaultGeometry = mutableMapOf<String, Geometry>()
    private var lastSw = 0f
    private var lastSh = 0f

    // ── ADD/REMOVE CONTROL ──────────────────────────────────────────────
    // Button ids currently hidden from the on-screen layout (and therefore
    // excluded from buildControlLayout()'s `buttons`/ffBtnRect output, so
    // they're neither drawn nor hit-tested during normal gameplay). Entered
    // via hold-to-remove in the editor (see onEditTouch/showRemoveButtonMenu)
    // and reversed via "+ Add control" (see showAddControlMenu). Persisted
    // the same way/at the same points as customLayout — see
    // loadCustomLayout()/saveCustomLayout() — so Cancel discards a removal
    // exactly like it discards a drag, and Done makes it stick.
    private val removedButtons = mutableSetOf<String>()

    // "Extra" controls — the shoulder+face combos, the A/B combos, and the
    // three one-tap actions (quick save/load, screenshot). Opposite default
    // from removedButtons above: these start OFF and only ever appear once
    // explicitly added, rather than starting on and being explicitly
    // removed — shipping this feature should never dump 9 new buttons onto
    // a layout someone already has set up exactly how they want it. See
    // isButtonVisible()/allControlIds() for how the two sets combine, and
    // buildControlLayout() for where each of these is actually built.
    // "ta"/"tb" (Turbo A / Turbo B) joined this list this pass — previously
    // a single all-or-nothing Settings checkbox added both together (see
    // showInputSettings()'s old turboCheck, removed this pass); moved here
    // on request, so each can be added/positioned/removed independently,
    // same as every other opt-in extra.
    private val extraControlIds = listOf(
        "ta", "tb", "la", "lb", "ra", "rb", "ab", "abturbo", "quicksave", "quickload", "screenshot"
    )
    private val addedExtraButtons = mutableSetOf<String>()

    /** True if [id] should currently be drawn/hit-tested. Base controls
     *  (the original 8 — dpad/a/b/select/start/l/r/ff) are opt-OUT via
     *  removedButtons; extraControlIds are opt-IN via addedExtraButtons.
     *  addButton() gates on this; everywhere else that used to check
     *  removedButtons directly (hitTestEditable, the old add/remove
     *  toggles) now goes through this instead so both catalogs behave
     *  consistently. */
    private fun isButtonVisible(id: String): Boolean =
        if (id in extraControlIds) id in addedExtraButtons else id !in removedButtons

    @Volatile private var editModeActive = false
    private var editSelectedId: String? = null
    private var editDragPointerId = -1
    private var editDragOffX = 0f   // touch point minus button center, at drag start
    private var editDragOffY = 0f
    private var editResizing = false
    private var editResizeStartDist = 0f
    private var editResizeStartScale = 1f
    private var editDirty = false   // true once the working copy diverges from what's saved
    private lateinit var editTopBar: LinearLayout
    // FIX: promoted from a local val in the UI-building method to a field
    // — refreshEditToolbarPosition() needs this wrapper's own laid-out
    // height (not editTopBar's, the child it wraps) to compute topBound
    // accurately. See that fix, and editTopBarScroll's own construction
    // site, for the full reasoning.
    private lateinit var editTopBarScroll: HorizontalScrollView
    private lateinit var editButtonBar: LinearLayout
    private lateinit var editButtonLabel: TextView
    private lateinit var editLockBtn: Button
    // CUSTOMIZATION UI: editSizeLabel's text switches between "Game Screen
    // Size" and "Control Size" depending on what's selected — the clear,
    // non-abbreviated labels requested, rather than a single generic
    // "Size" for both. editOpacityRow is hidden entirely when the game
    // screen is selected: opacity has no effect on the live game image
    // (there's no such thing as "Game Screen Opacity" in this app), so
    // showing it there would be a control that visibly does nothing.
    // FIX (this pass): editSizeSlider/editOpacitySlider replace what used
    // to be a "-"/"+" editChip() pair in each row — see sliderRow() in
    // SharedUi.kt for the widget itself, and syncEditButtonBarToSelection()
    // below for what keeps them (and the two fields above) showing the
    // right thing as the selection/lock state changes.
    private lateinit var editSizeLabel: TextView
    private lateinit var editOpacityRow: LinearLayout
    private lateinit var editSizeSlider: SliderRow
    private lateinit var editOpacitySlider: SliderRow
    // HOLD-TO-REMOVE: armed on ACTION_DOWN over a button (plain grab, not a
    // corner resize-grab — see onEditTouch), cancelled by real movement or
    // by lifting the finger before it fires. See cancelEditLongPress().
    private var editLongPressPending: Runnable? = null
    private var editDownX = 0f
    private var editDownY = 0f
    private val editTouchSlop: Float by lazy { ViewConfiguration.get(this).scaledTouchSlop.toFloat() }
    // FEATURE: hold-for-speed-slider on the on-screen »/fast-forward
    // button, gameplay (not edit-mode) touch handling — see onGameTouch()
    // and showFastForwardSpeedSlider(). Same "armed on DOWN, cancelled if
    // it resolves as a tap before the timeout fires" shape as
    // editLongPressPending just above, for the same reason (Runnable
    // stays cancellable via mainHandler.removeCallbacks right up until it
    // actually runs).
    private var ffLongPressPending: Runnable? = null
    // FIX (this pass — audit's own design-tradeoff note): which pointer
    // currently owns the pending/armed FF gesture above, -1 for none. Was
    // implicit before (ffLongPressPending being non-null only ever meant
    // "the first/primary finger", since only ACTION_DOWN — by definition
    // the very first pointer — ever armed it). Now that a second/third
    // finger landing on ff (ACTION_POINTER_DOWN, see onGameTouch below)
    // can arm it too, the specific pointer id has to be tracked explicitly
    // so the matching lift — ACTION_UP for the primary finger, or
    // ACTION_POINTER_UP for a secondary one — can tell whether *this*
    // lifting finger is the one that armed it, rather than always assuming
    // pointer 0.
    private var ffDownPointerId: Int = -1

    // ── Fast-forward state ─────────────────────────────────────────────────
    @Volatile private var fastForwardSpeed  = 2.0f
    @Volatile private var fastForwardActive = false
    private var ffBtnRect  = RectF()
    private var ffFrameAccumulator = 0.0

    // FEATURE (this pass): the game screen is now a resizable/draggable
    // participant in the same edit-mode/customLayout system every button
    // already used — see resolvedRect("gamescreen", ...) in
    // updateGameMatrix(), and editRectFor()/hitTestEditable()/labelFor()
    // below. gameScreenRect is its resolved on-screen rect, kept as its
    // own field (not a ButtonDef in the buttons list) since it isn't a
    // real input control — no keyMask, never drawn as a button glyph
    // during normal gameplay, excluded from the long-press-to-remove menu
    // (see onEditTouch) since there's nothing sensible "removing" it
    // would mean.
    //
    // Replaces the previous Fullscreen checkbox (fullscreenMode) entirely
    // on request — a separate on/off toggle for "game covers the control
    // area" doesn't add anything once the screen itself can just be
    // dragged and resized to be exactly as big as wanted, controls
    // included or not.
    private var gameScreenRect = RectF()
    // FEATURE: distorts the image to fill the game area exactly instead of
    // preserving the GBA's native 3:2 aspect ratio — see updateGameMatrix().
    @Volatile private var stretchToFit = false
    // FEATURE: bilinear-smooths the upscaled image instead of showing
    // crisp/blocky pixels — see gamePaint/updateLinearFilterPaint() below.
    // FIX: this field itself was missing entirely through pass 35 — every
    // read of it (the pref-load line, updateLinearFilterPaint(), the
    // Video settings checkbox) compiled as an unresolved reference,
    // caught by the real CI build (this project has no compiler in the
    // sandbox that writes it — see every pass's own verification notes).
    // Wrongly assumed to already exist alongside stretchToFit/maxFrameSkips
    // above without actually checking for a declaration, not just a use —
    // the two lines it happened to share a grep result with were a load
    // line and a doc comment, neither of which is one.
    @Volatile private var linearFilterEnabled = false
    // FEATURE: MyBoy-style frame skipping for normal (non-fast-forward)
    // play — see maybeSkipRenderThisFrame() in the game loop. 0 = never
    // skip (always render every frame, the previous and still-default
    // behavior); up to maxFrameSkips consecutive frames may be emulated
    // without blitting if the loop is genuinely running behind.
    @Volatile private var maxFrameSkips = 0
    // FEATURE: state for maybeSkipRenderThisFrame's "are we behind" check
    // and its consecutive-skip budget — see startGameLoop().
    @Volatile private var consecutiveFrameSkips = 0
    // FIX (this pass — reported directly: "max frame skip at 10 it very
    // bad its laggy... the max frame skip it becomes slower", unlike a
    // reference emulator's own frame skip, which the report says makes
    // things faster): "are we behind" used to compare the *previous*
    // iteration's full wall-clock duration (old lastFrameLoopStartNs, a
    // timestamp) against frameBudgetNs. That total always includes the
    // blocking writePcm() call — the frame pacer by design, see the AUDIO
    // ARCHITECTURE comment above initAudioTrack() — which alone consumes
    // ~1 frame period of real time on *every* normal iteration, skip or
    // not. So total iteration time sits right on top of frameBudgetNs
    // essentially always, and which side of that exact threshold it lands
    // on is mostly scheduling/audio-buffer noise, not a signal the device
    // is actually struggling — "behind schedule" could fire close to half
    // the time on a perfectly healthy device. With no cooldown beyond a
    // single non-skip iteration, one false trip could then chain up to
    // maxFrameSkips visibly-stuck-on-one-frame iterations in a row before
    // the counter reset — worse the higher maxFrameSkips was set, exactly
    // backwards from the feature's own goal ("10 is laggier than a low
    // setting" instead of "closer to keeping pace than off").
    //
    // lastComputeNs replaces that timestamp with a duration: only the
    // CPU-bound portion of the *previous* iteration (nativeSetKeys through
    // nativeReadAudioSamples — see the loop below for exactly where this
    // is measured, and where it deliberately stops, before the blocking
    // write). Comparing *that* to frameBudgetNs actually answers "is the
    // device's own compute too slow for one frame's budget" — the
    // question this check was always meant to ask — instead of "did the
    // pacer's own intentional wait happen to land a hair over an exact
    // integer-nanosecond line," which it couldn't help but answer instead.
    private var lastComputeNs = 0L
    private val frameBudgetNs = 1_000_000_000L / 60  // one GBA frame at 60fps

    // ── Button / screen customization ─────────────────────────────────────
    private var buttonScaleMultiplier = 1.0f   // 0.75 / 1.0 / 1.25
    private var buttonBaseAlpha       = 160    // idle opacity 0-255
    private var gameScreenFraction    = GAME_FRAC_NORM  // 0.35–0.65
    // OUTLINE SKIN: stroke width for the line-art button style, recomputed
    // as a screen-size fraction in buildControlLayout() (same convention as
    // every other button dimension in that function) rather than a fixed
    // pixel constant, so it scales sensibly across phone sizes.
    private var outlineStrokeW        = 5f

    // ── Editor alignment grid (FEATURE — Thirty-ninth pass; square cells —
    //    Fortieth pass) ────────────────────────────────────────────────────
    // Purely an editing-time aid: a grid of square cells drawn over the
    // screen while the layout editor is open, with position/size optionally
    // snapping to it — see gridCellPx()/drawGrid()/snapPositionToGrid()/
    // snapScaleToGrid(), all only ever called from drawEditOverlay()/
    // onEditTouch(). None of the three fields below are read anywhere
    // outside edit mode, so they can never affect the actual gameplay
    // display, the default geometry any control falls back to, or anything
    // already saved in customLayout — showGrid in particular is pure
    // rendering state; toggling it never touches customLayout/
    // removedButtons/addedExtraButtons, so turning the visual grid off
    // can't ever surprise-reset a saved layout.
    // FIX (Fortieth pass): gridDivisions no longer means "N columns × N
    // rows". Reported directly as "not really box[es]", and true even
    // though every preset was labelled N×N — dividing width and height by
    // the same N produces a w/N-by-h/N rectangle on any non-square screen,
    // never an actual square. It now means "how many square cells fit
    // across the SHORTER of width/height" — see gridCellPx(), the one
    // place that size is computed; drawGrid() and both snap functions all
    // read it from there so what's drawn and what dragging/resizing snaps
    // to can never drift apart from each other. Also extended with a 64
    // preset this pass (was capped at 32) — see showGridSettingsDialog().
    private var gridDivisions = 8            // N — square cells, N of them across the shorter screen dimension
    @Volatile private var showGrid   = false
    @Volatile private var snapToGrid = false

    // ── Turbo (rapid-fire) A / B ────────────────────────────────────────────
    // Adds two extra red on-screen buttons — "A"/"B" in red — that
    // auto-repeat the A/B press while held instead of holding it
    // continuously. Individually opt-in via "+ Add control" (see
    // extraControlIds above) as of this pass — previously a single
    // Settings checkbox added both together with no way to get just one;
    // removed on request in favor of the same per-button system every
    // other extra control already used.
    @Volatile private var turboAHeld = false
    @Volatile private var turboBHeld = false
    // Half-period of the on/off square wave, in ms.
    // FIX (this pass): was 66ms (≈7-8 presses/sec), reported as feeling
    // slow — not really "rapid" fire. Halved to 30ms (≈16-17 presses/sec),
    // comfortably inside the range real turbo controllers typically run
    // at (roughly 10-30/sec), and still safely above the ~16.7ms a single
    // GBA frame takes at 60fps — each on/off phase still spans close to
    // two full frames, so the core should still reliably register every
    // edge as a distinct press rather than the two phases blurring
    // together into what would just look like a continuous hold again.
    private val turboHalfPeriodMs = 30L

    // ── Performance overlay (FEATURE — off by default) ─────────────────────
    // Small corner readout of emulated core FPS and the AudioTrack underrun
    // counter — the same underrun figure already logged periodically (see
    // writePcm()), just also surfaced on-screen for at-a-glance diagnosis
    // without needing logcat. Purely additive and opt-in: when disabled
    // (the default) the game thread does none of the counting work below,
    // so there's zero overhead on the thread that also paces audio.
    // Toggled in ⚙ Settings → Misc, next to the other gameplay tweaks.
    @Volatile private var showFpsOverlay = false
    @Volatile private var fpsOverlayText = ""
    private var fpsFrameCount    = 0
    private var fpsWindowStartNs = 0L

    // ── Audio ──────────────────────────────────────────────────────────────
    @Volatile private var audioTrack: AudioTrack? = null
    private val audioBuffer = ShortArray(2048)
    // FAST-FORWARD AUDIO: accumulates every sub-frame's PCM across one
    // fast-forward batch (see startGameLoop) before decimateForFastForward()
    // compresses it back down to about one frame's worth. Sized for
    // FF_MAX_BATCH_FRAMES sub-frames at audioBuffer's own per-read capacity.
    private val ffAccumBuffer = ShortArray(FF_MAX_BATCH_FRAMES * audioBuffer.size)
    private var audioDiagCounter = 0
    private var audioManager: AudioManager? = null
    // AUDIO FIX (this pass): audio focus was never requested. AudioTrack will
    // still *build* and accept writes without it, but several OEM audio HALs
    // (MIUI/ColorOS/FuntouchOS in particular) silently keep a stream's output
    // gain at zero — not muted, not erroring, just inaudible — until the app
    // holding the Surface/foreground also holds AUDIOFOCUS_GAIN. Requesting
    // it costs nothing on stock AOSP devices where sound already worked.
    private var audioFocusRequest: AudioFocusRequest? = null
    private val audioFocusListener = AudioManager.OnAudioFocusChangeListener { /* no-op: USAGE_GAME doesn't duck */ }

    // ── Audio settings — Enable sound / Sound volume / Sound frequency ─────
    // FEATURE (this pass): replaces the old standalone "Button click sound"
    // toggle (direct report asked for it removed — see updateGameKeys(),
    // which no longer has any click-sound logic at all) with a real Audio
    // settings screen matching a reference screenshot's own list: Enable
    // sound (game audio on/off), Sound volume (an in-app volume slider,
    // independent of the device media volume), and Sound frequency (output
    // sample rate, traded against CPU/battery use — the same lower-
    // fidelity-for-performance option other GBA emulators on Android,
    // MyBoy among them, expose). See showAudioSettings()/
    // showSoundVolumeDialog()/showSoundFrequencyDialog() and
    // applyGameVolume()/applySoundFrequencyFilter() below for where each
    // one actually takes effect.
    @Volatile private var soundEnabled = true
    @Volatile private var soundVolumePercent = 100
    // One of 44100/22050/11025 — see showSoundFrequencyDialog(). Stored as
    // the literal Hz value rather than an index: it's already exactly the
    // number initAudioTrack() needs, self-documenting in SharedPreferences,
    // and there's no ordering/migration to keep in sync with the dialog's
    // own option list this way.
    @Volatile private var soundFrequencyHz = 44100
    // soundFreqFactor/soundFreqAlpha are derived from soundFrequencyHz —
    // see updateSoundFrequencyFactor() — and cached rather than recomputed
    // inside applySoundFrequencyFilter()'s per-sample loop, which runs on
    // the game thread on every single writePcm() call. soundFreqLpL/R are
    // that filter's own continuous state, deliberately *not* reset every
    // call — see applySoundFrequencyFilter()'s own comment for why, in
    // contrast to decimateForFastForward()'s similar but call-scoped
    // filter above.
    @Volatile private var soundFreqFactor = 1
    @Volatile private var soundFreqAlpha = 0f
    private var soundFreqLpL = 0f
    private var soundFreqLpR = 0f
    // Set from the settings UI (main thread) when Sound frequency changes,
    // consumed and cleared from the game loop itself (see startGameLoop())
    // — changing an AudioTrack's sample rate means rebuilding it entirely
    // (initAudioTrack()), and that rebuild has to happen on the same
    // thread that owns the track's normal write/lifecycle, the same
    // reasoning writePcm()'s own ERROR_DEAD_OBJECT-triggered rebuild
    // already follows, rather than racing a UI-thread rebuild against a
    // concurrent game-thread write.
    @Volatile private var audioTrackRebuildPending = false

    companion object {
        private const val TAG             = "mGBA"
        private const val GAME_FRAC_NORM  = 0.52f

        // ── Per-item editor toolbar (refreshEditToolbarPosition) ────────────
        // Direct report: the popup "sometimes it get cut off its weird" when
        // dragged near an edge. Both values below used to be bare pixel
        // literals (4f/12f) inline in refreshEditToolbarPosition() — sub-1dp
        // on anything past ~mdpi, i.e. not a real margin at all, which is
        // what actually read as "cut off" even though the clamp itself was
        // never letting the bar go fully off-screen. Named + dp-scaled here
        // for the same reason resizeHandleTouchRadius() moved off a raw-pixel
        // radius (see that function's own comment).
        private const val EDIT_TOOLBAR_SCREEN_MARGIN_DP = 8   // gap kept from every screen edge
        private const val EDIT_TOOLBAR_GAP_DP = 12            // gap kept from the selected control / top bar

        // FEATURE (this pass — direct report: "make the pop up smaller"):
        // the two biggest single contributors to editButtonBar's footprint,
        // pulled out the same way EDIT_TOOLBAR_GAP_DP/_SCREEN_MARGIN_DP
        // already are above — each is read from two call sites (row1/row2's
        // bottomMargin; editSizeSlider's/editOpacitySlider's own row width),
        // so one named number keeps both sites in step instead of two
        // literals that could quietly drift apart in some future pass.
        // Smaller one-off cosmetic values (chip/label padding, text size)
        // stay as plain literals at their own call sites, same as
        // everywhere else in this file — these two are promoted because
        // they're shared, not because every size constant deserves to be.
        private const val EDIT_TOOLBAR_ROW_GAP_DP = 4          // was 6
        private const val EDIT_TOOLBAR_SLIDER_WIDTH_DP = 190   // was 240

        // ── GBA hardware timing ─────────────────────────────────────────────
        // AUDIO FIX (root cause #1): the old loop paced itself with
        // Thread.sleep(1_000_000_000.0 / 60.0) — i.e. it assumed an exact
        // 60.000 Hz refresh. Real GBA hardware runs at CPU_CLOCK / CYCLES_PER_FRAME
        // = 16777216 / 280896 ≈ 59.7275 Hz. Pacing 0.46% too fast meant the game
        // thread fed the blip_buf resampler audio slightly faster than a
        // 44.1 kHz AudioTrack could drain it. Since the old code wrote with
        // WRITE_NON_BLOCKING and never checked the return value, that constant
        // small surplus was silently dropped by AudioTrack roughly every 3–4
        // real seconds — an audible periodic "stutter" that would read as
        // "audio is a little broken" on a real device even though nothing was
        // ever fully silent. Below are the exact constants (matching
        // GBA_AUDIO_CLOCK in mgba_jni.c) used for the corrected pacing.
        private const val GBA_CPU_CLOCK_HZ    = 16_777_216L   // 2^24, ARM7TDMI clock
        private const val GBA_CYCLES_PER_FRAME = 280_896L     // 228 lines * 1232 cycles
        // Only used as a *fallback* pacer for frames that produce no audio
        // (e.g. the first frame or two right after a ROM loads, before the
        // blip_buf resamplers have accumulated a full sample). Normal frames
        // are paced by the AudioTrack itself — see startGameLoop().
        private val FALLBACK_FRAME_NS =
            GBA_CYCLES_PER_FRAME * 1_000_000_000L / GBA_CPU_CLOCK_HZ

        // Headroom above the 16x fast-forward speed clamp (see
        // showMiscSettings) for sizing ffAccumBuffer below.
        private const val FF_MAX_BATCH_FRAMES = 24

        // SharedPreferences
        // PREFS itself moved to SharedUi.kt this pass (top-level, shared
        // with RomBrowserActivity) — everything below is still just this
        // Activity's own keys within that same file.
        private const val PREF_FF_SPEED    = "ff_speed"
        private const val PREF_BTN_SCALE   = "btn_scale"
        private const val PREF_BTN_ALPHA   = "btn_alpha"
        private const val PREF_SCREEN_FRAC = "screen_frac"
        private const val PREF_STRETCH     = "stretch_to_fit"
        private const val PREF_MAX_SKIPS   = "max_frame_skips"
        private const val PREF_LINEAR_FILTER = "linear_filter"
        // PREF_BTN_SOUND removed this pass — the standalone button-click
        // sound feature it backed is gone entirely (direct report asked
        // for it removed), replaced by the three keys below.
        private const val PREF_SOUND_ENABLED = "sound_enabled"
        private const val PREF_SOUND_VOLUME  = "sound_volume"
        private const val PREF_SOUND_FREQ    = "sound_freq"
        // PREF_TURBO removed this pass — Turbo A/B moved into the same
        // added-extras layout persistence every other opt-in button
        // already uses (see extraControlIds/addedExtraButtons above),
        // rather than a separate on/off flag of their own.
        private const val PREF_SHOW_FPS    = "show_fps"
        // Editor alignment grid — see the gridDivisions/showGrid/snapToGrid
        // field comments. Deliberately NOT orientation-suffixed (unlike
        // PREF_LAYOUT_PREFIX below) — grid preference is a general editing
        // preference, not something that should differ between portrait
        // and landscape.
        private const val PREF_GRID_SIZE   = "grid_divisions"
        private const val PREF_SHOW_GRID   = "show_grid"
        private const val PREF_SNAP_GRID   = "snap_to_grid"
        private const val PREF_LAYOUT_PREFIX = "layout_"
        // ADD/REMOVE CONTROL feature — which button ids are hidden, per
        // orientation (same "land"/"port" split as PREF_LAYOUT_PREFIX above).
        // See removedButtons / loadCustomLayout() / saveCustomLayout().
        private const val PREF_REMOVED_PREFIX = "removed_"
        // Same idea, opposite default — which extraControlIds ids have been
        // explicitly added. See addedExtraButtons / isButtonVisible().
        private const val PREF_EXTRAS_PREFIX = "extras_"
        // The only two values orientationTag() ever returns — see its own
        // definition. Pulled out as a constant purely for
        // exportLayoutBackup()/importLayoutBackupIfNeeded() (pass 43) to
        // iterate both profiles at once without duplicating this pair of
        // literals a third time.
        private val ORIENTATION_TAGS = listOf("land", "port")
        private const val PREF_ORIENTATION   = "screen_orientation"  // Int, one of ORIENTATION_* below
        // FEATURE: user-chosen Storage folder for saves/states/screenshots —
        // see dataFolderTree()/showStorageSettings()/SaveEntry below. Absent
        // (the default) means every save-adjacent file lives exactly where
        // it always has: this app's own internal storage. Still a
        // persisted SAF tree Uri (unlike the ROM browser's own
        // PREF_ROMS_LAST_FOLDER, now in RomBrowserActivity.kt — a plain
        // path, and this Activity doesn't need to know it exists at all
        // any more) and read/write instead of read-only, since this one
        // gets written to.
        private const val PREF_DATA_FOLDER_URI = "data_folder_tree_uri"

        // Screen orientation choice, persisted under PREF_ORIENTATION — see
        // applyScreenOrientationPref() and the "Screen orientation" radio
        // group in showVideoSettings(). ORIENTATION_LANDSCAPE is the default
        // (and was previously the only, hardcoded option — see onCreate/
        // AndroidManifest.xml) so existing installs behave identically until
        // someone actually opens Video settings and changes it.
        private const val ORIENTATION_AUTO              = 0
        private const val ORIENTATION_LANDSCAPE          = 1
        private const val ORIENTATION_REVERSE_LANDSCAPE  = 2
        private const val ORIENTATION_PORTRAIT           = 3
        private const val ORIENTATION_SYSTEM             = 4

        // Number of independent save-state slots offered per ROM.
        private const val SAVE_STATE_SLOTS = 4

        // Save-state thumbnail width in px; height is derived per-capture from
        // the SurfaceView's actual aspect ratio at that moment (see
        // captureStateThumbnail) rather than hardcoded, since the surface may
        // be letterboxed/fullscreen differently across sessions and forcing a
        // fixed WxH here would stretch the image instead of just cropping it.
        private const val STATE_THUMB_WIDTH_PX = 200

        // Backstop cap for slotInfoCache below — see that field's own doc
        // comment for why this is a "shouldn't realistically matter"
        // safeguard rather than a fix for any actually-observed growth.
        private const val SLOT_INFO_CACHE_MAX = 500
    }

    private data class ButtonDef(
        val id: String, val rect: RectF, val keyMask: Int, val label: String, val color: Int,
        val isDpad: Boolean = false
    )

    // ── ROM picker ─────────────────────────────────────────────────────────

    // FIX: BLUETOOTH_CONNECT / BLUETOOTH_SCAN are runtime-dangerous permissions
    // on API 31+ (Android 12+). They were declared in the manifest but never
    // actually requested anywhere, so every Bluetooth link-cable action
    // (Host, Join, listing bonded devices) threw an uncaught SecurityException
    // and crashed the app on any Android 12+ device. This launcher requests
    // the permission on demand; [pendingBtAction] resumes whatever the user
    // was trying to do as soon as it's granted.
    private var pendingBtAction: (() -> Unit)? = null
    private val btPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        val action = pendingBtAction; pendingBtAction = null
        if (granted) action?.invoke()
        else uiToast("Bluetooth permission is required for BT link cable")
    }

    /** Runs [action] immediately if Bluetooth permission is already granted
     *  (or not needed on this API level), otherwise requests it first. */
    private fun ensureBluetoothPermission(action: () -> Unit) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) { action(); return }
        val granted = ContextCompat.checkSelfPermission(
            this, Manifest.permission.BLUETOOTH_CONNECT
        ) == PackageManager.PERMISSION_GRANTED
        if (granted) { action() }
        else { pendingBtAction = action; btPermissionLauncher.launch(Manifest.permission.BLUETOOTH_CONNECT) }
    }

    // FEATURE (Thirty-second pass): romPicker (the classic single-file SAF
    // picker) and the whole broad-file-access permission flow
    // (ensureBroadFileAccess() etc.) moved to RomBrowserActivity.kt along
    // with the rest of ROM browsing — see the field-block comment above and
    // RomBrowserActivity.kt's own top-of-file comment for why. What's left
    // here is just the launcher that starts that Activity and receives
    // whichever ROM it picked, mirroring how romPicker/dataFolderPicker
    // above already used registerForActivityResult() for a similar
    // "launch something, get a Uri back" shape.
    private val romBrowserLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            result.data?.data?.let { loadRomFromUri(it) }
        }
        // RESULT_CANCELED (backed out / denied permission / nothing
        // picked): do nothing, same as before — the surface just sits
        // idle and tapping it calls changeRom() again (see onGameTouch()).
    }

    // FEATURE: user-chosen Storage folder (see PREF_DATA_FOLDER_URI/
    // showStorageSettings()/SaveEntry). Unlike the ROM browser (its own
    // Activity now, see above), this still goes through a SAF tree picker
    // rather than the broad MANAGE_EXTERNAL_STORAGE permission — it needs
    // *write* access, and there's no reason to widen what this feature
    // touches just because the ROM browser needs the broader permission
    // for its own, separate reasons.
    private val dataFolderPicker = registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        uri ?: return@registerForActivityResult
        try {
            contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        } catch (e: Exception) {
            Log.e(TAG, "takePersistableUriPermission failed for data folder", e)
            uiToast("Couldn't get permission for that folder"); return@registerForActivityResult
        }
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .putString(PREF_DATA_FOLDER_URI, uri.toString())
            .apply()
        // Create the three subfolders right away so they're visible in a
        // file manager immediately, not only after the first save/
        // screenshot/(future) cheat file actually gets written.
        dataSubfolder("save"); dataSubfolder("cheat"); dataSubfolder("screenshot")
        uiToast("Folder set — new saves/states/screenshots go here from now on")
        refreshStorageSettingsUi?.invoke()
    }

    // isZipSignature()/zipContainsGba() moved to RomZipUtils.kt this pass
    // (Thirty-second) when the ROM browser became its own Activity —
    // RomBrowserActivity needs zipContainsGba() too, and this way there's
    // still only one copy of the byte comparison between it and
    // stageRomFile() below, same as when both lived in this class.

    /** Copies [uri] into [tmp]. If the source is a zip archive — detected by
     *  its real magic bytes (see RomZipUtils.isZipSignature()), not by file
     *  extension, so a misnamed archive still works and a .zip that somehow
     *  isn't a real zip is correctly rejected instead of handed to the core
     *  as garbage — the first .gba entry found inside is extracted instead
     *  of the raw archive bytes. This is what lets both the file browser
     *  and the classic system picker load a ROM straight out of a .zip with
     *  no separate extraction step. Returns false if nothing worth loading
     *  ended up in [tmp] (unreadable source, or a zip with no .gba entry). */
    private fun stageRomFile(uri: Uri, tmp: File): Boolean {
        val raw = contentResolver.openInputStream(uri) ?: return false
        raw.use { stream ->
            val input = stream.buffered()
            if (!RomZipUtils.isZipSignature(input)) {
                tmp.outputStream().use { o -> input.copyTo(o) }
                return true
            }
            ZipInputStream(input).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    if (!entry.isDirectory && entry.name.endsWith(".gba", ignoreCase = true)) {
                        tmp.outputStream().use { o -> zip.copyTo(o) }
                        return true
                    }
                    entry = zip.nextEntry
                }
            }
            return false
        }
    }

    /** Stages [uri] (transparently unzipping it first if needed — see
     *  stageRomFile()), swaps it into the running core, and updates the UI
     *  on success or failure. Shared by every ROM entry point — the classic
     *  system picker above and the in-app file browser's file rows below
     *  both just call this now, instead of each duplicating the load. */
    private fun loadRomFromUri(uri: Uri) {
        Thread {
            try {
                // FIX: nativeLoadROM() silently drops any active link session
                // as part of swapping the native core (see the "ROM swapped
                // while a link session was active" comment in mgba_jni.c) —
                // that side is careful to avoid leaving a dangling pointer,
                // but it has no way to tell the Kotlin side this happened.
                // Without this, link.isConnected and the ⬤ LINK overlay would
                // keep claiming "Connected" after a ROM swap even though the
                // native SIO driver backing the exchange no longer exists —
                // a silently broken multiplayer session with no indication
                // in the UI of why. Disconnect first so both sides agree.
                if (link.isConnected) stopLink()
                // FIX (Twenty-first pass): if a Storage folder is configured
                // and a ROM is already running, its battery save has only
                // ever been mirrored to internal storage (see
                // SaveEntry.batteryMirrorPath()) — the real document in the
                // chosen folder hasn't seen anything played since the last
                // sync point. Flush it out now, before that mirror file gets
                // reused for the ROM we're about to swap in, or whatever was
                // played this session never reaches the chosen folder at all.
                // mirrorToAutoFolder() alongside it: same flush moment, just
                // for the automatic own-folder mirror instead of a chosen
                // SAF folder — see the FEATURE block above dataFolderTree().
                if (romLoaded) {
                    batterySaveEntry(currentRomBaseName).syncBatteryMirror()
                    batterySaveEntry(currentRomBaseName).mirrorToAutoFolder()
                }
                // FIX: stop any in-progress game loop *before* touching the
                // native core, and reset transient input/FF state. Previously
                // there was no way to load a second ROM at all (loadRomBtn was
                // permanently hidden after the first successful load), so this
                // path was never exercised. nativeLoadROM() now builds the new
                // core fully before swapping it in, so a failed load here
                // leaves the previous session running rather than destroying
                // it (see mgba_jni.c).
                stopGameLoop()
                val tmp = cacheDir.resolve("rom_loaded.gba")
                if (!stageRomFile(uri, tmp)) {
                    uiToast("Couldn't read that file (or found no .gba inside the zip)")
                    return@Thread
                }
                // ROM SAVE: identify the ROM by its picked display name —
                // not the fixed "rom_loaded.gba" cache path above, which
                // every ROM shares — so its battery save persists under a
                // name stable across app restarts and re-picking the same
                // file later. See deriveRomBaseName()/batterySaveEntry().
                val baseName = deriveRomBaseName(uri)
                val saveEntry = batterySaveEntry(baseName)
                backupIfExists(saveEntry)   // FEATURE: auto save backup
                // FIX (Twenty-first pass): was saveEntry.nativePath(forWrite
                // = true).path — a /proc/self/fd bridge straight onto the SAF
                // document, mmap'd by the core for the whole session. See the
                // block comment above dataFolderTree() for why that doesn't
                // hold up on a real device. batteryMirrorPath() below is
                // always a plain local path; when a Storage folder is
                // configured it stages the existing save in from there first.
                val savePath = saveEntry.batteryMirrorPath()
                val ok = EmulatorEngine.nativeLoadROM(tmp.absolutePath, savePath)
                Handler(Looper.getMainLooper()).post romLoadDone@ {
                    // FIX: onDestroy() may have already run and freed the
                    // native core by the time this posts, if the load was
                    // slow (large ROM, a slow SAF/cloud-backed URI) and the
                    // user backed out of the app in the meantime. Without
                    // this check, the block below would re-init AudioTrack
                    // and start a brand new game thread + Choreographer
                    // registration after teardown — resources nothing would
                    // ever clean up, since onDestroy() has already run and
                    // won't run again for this instance.
                    if (isFinishing || isDestroyed) return@romLoadDone
                    // BUG FIX: this whole block runs on the MAIN thread,
                    // asynchronously, well after loadRomFromUri's own
                    // try/catch — wrapping the background Thread body above
                    // — has already finished and returned. That catch does
                    // NOT protect anything in here despite the misleading
                    // nesting; Handler.post() only schedules this lambda,
                    // it doesn't run it, so by the time this body actually
                    // executes the outer try is long gone. Any exception
                    // here (Bitmap.createBitmap, AudioTrack init, the
                    // thread/Choreographer setup in startGameLoop()) was
                    // previously a genuine uncaught exception on the main
                    // thread — a hard app crash, with the ROM having *just*
                    // finished loading successfully.
                    try {
                        if (ok) {
                            val w = EmulatorEngine.nativeGetWidth().coerceAtLeast(1)
                            val h = EmulatorEngine.nativeGetHeight().coerceAtLeast(1)
                            frameBuffers = Array(3) {
                                Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                            }
                            writeIdx = 0
                            readyIdx = -1
                            displayIdx = -1
                            romLoaded = true
                            // FIX (this pass): see applyScreenOrientationPref()'s
                            // own doc comment. This activity was Portrait the
                            // whole time RomBrowserActivity was open (idle —
                            // see that function) — now that a ROM is actually
                            // loaded, switch to the user's chosen gameplay
                            // orientation, before startGameLoop() below starts
                            // rendering.
                            applyScreenOrientationPref()
                            currentRomBaseName = baseName
                            clearPointerState()
                            currentKeys.set(0)
                            fastForwardActive = false
                            initAudioTrack()
                            startGameLoop()
                        } else {
                            romLoaded = false
                            uiToast("Unsupported ROM format")
                        }
                    } catch (e: Throwable) {
                        // Leave the app in a state the user can recover from
                        // instead of a crash: no half-started game, surface
                        // wiped, and romLoaded left false so a tap on the
                        // idle screen (see onGameTouch()) reopens the ROM
                        // browser instead of leaving a dead screen behind.
                        Log.e(TAG, "ROM load post-processing failed", e)
                        uiToast("Load error: ${e.message ?: e.javaClass.simpleName}")
                        romLoaded = false
                        clearSurfaceToBlack()
                    }
                }
            } catch (e: Throwable) {
                Log.e(TAG, "ROM load failed", e)
                uiToast("Load error: ${e.message ?: e.javaClass.simpleName}")
            }
        }.apply { name = "mGBA-load" }.start()
    }

    /** Entry point for loading/swapping the ROM — called from onCreate() on
     *  first launch, from closeGame() when backing out of a game, and from
     *  onGameTouch() when the idle (no-ROM-loaded) surface is tapped.
     *  Launches RomBrowserActivity (a separate Activity as of Thirty-second
     *  pass, not an overlay in this one — see its own top-of-file comment)
     *  and waits for a result; romBrowserLauncher above hands whatever it
     *  returns to loadRomFromUri(). Broad file access, the folder browsing
     *  itself, and the classic single-document SAF picker fallback are all
     *  that Activity's own concern now, not this one's. */
    private fun changeRom() {
        romBrowserLauncher.launch(Intent(this, RomBrowserActivity::class.java))
        // FIX (Fortieth pass — reported directly: opens in landscape,
        // "then it go to portrait instantly"). This app is normally in
        // landscape during play; RomBrowserActivity is manifest-locked to
        // portrait (see its own top-of-file comment for why that's a
        // static declaration and NOT a runtime requestedOrientation call —
        // this fix doesn't touch that at all, for the same reason).
        // Actually rotating the physical display for the new Activity is a
        // real reconfiguration, and the default slide/fade activity
        // transition gives it a couple of animated frames to be visible
        // mid-rotation, which is what reads as "opens landscape, then
        // snaps to portrait". overridePendingTransition(0, 0) collapses
        // that transition to nothing, so the swap is an instant cut
        // instead of an animated one with a wrong-orientation frame in the
        // middle. Deprecated as of API 34 (replaced by
        // overrideActivityTransition) but still fully functional at this
        // app's targetSdk 34 — kept as the plain call rather than a
        // version-gated branch since the two behave identically here and
        // there's nothing to verify a newer, unfamiliar signature against
        // in this sandbox (no compiler/device, as every pass). See
        // RomBrowserActivity's own finish() override for the matching
        // fix on the way back.
        @Suppress("DEPRECATION")
        overridePendingTransition(0, 0)
    }

    // ── Save / state file naming ─────────────────────────────────────────
    // SAF (Storage Access Framework) URIs don't carry a real filesystem
    // path, and the only identifier for "which ROM is this" that's stable
    // across app restarts and re-picking the same file is the picked
    // document's display name — queried via ContentResolver, since
    // uri.lastPathSegment is often an opaque provider-specific ID rather
    // than the actual filename on many document providers (Downloads,
    // Google Drive, etc).

    private fun deriveRomBaseName(uri: Uri): String {
        var display: String? = null
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { c ->
                    val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0 && c.moveToFirst()) display = c.getString(idx)
                }
        } catch (_: Exception) {
            // Provider didn't support the query — fall through to the
            // URI-based fallback below.
        }
        val base = (display ?: uri.lastPathSegment ?: "rom").substringBeforeLast('.')
        // Keep only filesystem-safe characters — a display name can contain
        // spaces, parentheses, unicode, anything a user or provider chose.
        val sanitized = base.replace(Regex("[^A-Za-z0-9_-]"), "_").take(80)
        return sanitized.ifBlank { "rom" }
    }

    private fun savesDir():  File = File(filesDir, "saves").apply  { mkdirs() }
    private fun statesDir(): File = File(filesDir, "states").apply { mkdirs() }

    /** Path for the cartridge's battery save (SRAM/Flash/EEPROM), in this
     *  app's own internal storage — the ONLY location before this feature
     *  existed, and still the fallback location: see SaveEntry below for
     *  where a save/state/screenshot actually ends up once a Storage
     *  folder has been chosen. */
    private fun batterySaveFile(baseName: String): File =
        File(savesDir(), "$baseName.sav")

    /** Legacy path for save-state slot [slot] (1-based). See batterySaveFile
     *  above re: "legacy". */
    private fun stateSlotFile(slot: Int): File =
        File(statesDir(), "$currentRomBaseName.state$slot")

    /**
     * Legacy path for save-state slot [slot]'s thumbnail PNG, sitting next
     * to the state file itself (same dir, same base name, `.png`
     * appended). Written by [captureStateThumbnail] right after a
     * successful save; simply absent for an empty slot, or for a slot
     * saved before this feature existed — both cases are handled the same
     * way by [showSaveStateSlotDialog].
     */
    private fun stateThumbFile(slot: Int): File =
        File(statesDir(), "$currentRomBaseName.state$slot.png")

    /** Legacy path for the dedicated "quick save" slot — separate from the
     *  numbered Slot 1..SAVE_STATE_SLOTS files above, so a tap on the
     *  on-screen Quick Save/Quick Load buttons (see actionButtonAt/
     *  triggerActionButton) never collides with, or gets confused for, a
     *  save the user deliberately put in one of the numbered slots via
     *  showSaveStateSlotDialog(). No thumbnail file for this one — it's
     *  only ever reached by a direct tap, never shown in a slot-picker
     *  list, so there's nothing that would ever display it. */
    private fun quickStateFile(): File =
        File(statesDir(), "$currentRomBaseName.quicksave")

    // ── FEATURE: Storage folder (saves/states/screenshots outside app data) ──
    //
    // Everything above this comment is untouched from before this feature
    // existed, and stays the fallback: someone who never opens Settings →
    // Storage sees exactly the same behavior as always, saves included.
    //
    // What's new: PREF_DATA_FOLDER_URI, set via showStorageSettings() below,
    // points at a folder the user picked with the system folder-picker
    // (SAF's OpenDocumentTree, via dataFolderPicker below — the ROM
    // browser used this same mechanism too until this pass, see
    // CHANGELOG.md/FILE_CHANGES.md's free-roam-file-manager entry for why
    // it moved to plain java.io.File instead; this feature has a
    // different tradeoff, see dataFolderPicker's own comment, and keeps
    // the SAF tree it already had). Once set, THREE
    // subfolders inside it — "save", "cheat", "screenshot" — hold
    // everything that used to live under this app's own internal storage:
    // battery saves and every save-state/thumbnail/quicksave under "save"
    // (there's only one user-facing "Save" action even though this app
    // internally has both battery saves and save-states, so they share one
    // folder rather than splitting a distinction the user never asked
    // for), "cheat" sits ready and empty for whenever a cheat-file feature
    // exists (see MainActivity's own "Cheats — not implemented yet" row —
    // this doesn't add that feature, just gives it somewhere to write once
    // it exists), and "screenshot" replaces the old
    // getExternalFilesDir()/Screenshots location (see saveScreenshotBitmap
    // further down).
    //
    // Deliberately still SAF, not MANAGE_EXTERNAL_STORAGE (the ROM browser's
    // own choice as of Thirty-second pass — see RomBrowserActivity.kt's
    // top-of-file comment): this feature only ever needs ONE folder, picked
    // once, with no reason to ever browse elsewhere afterward — exactly what
    // SAF's OpenDocumentTree is for. No scary system permission dialog for
    // something this occasional, no Play Store policy risk, works
    // identically across Android versions. The ROM browser needed the
    // broader permission specifically because free navigation *anywhere*
    // was the actual feature being asked for there — a different
    // requirement this one doesn't share, not a reason to switch this one
    // too just because that one did. The one wrinkle specific to
    // *this* feature: nativeSaveState()/nativeLoadState()/nativeLoadROM()'s
    // save path all expect a plain fopen()-able path string (they hand it
    // straight to mGBA's VFileOpen — see mgba_jni.c), and a SAF document's
    // content:// URI is not one.
    //
    // FIX (Twenty-first pass): the previous pass bridged that gap via
    // /proc/self/fd/<N> — reopening a ParcelFileDescriptor's fd as a plain
    // path and handing THAT straight to native VFileOpen, including for the
    // battery save, which the core mmaps for the entire session. That was
    // flagged in KNOWN_LIMITATIONS.md as unconfirmed on a real device, and a
    // real-device test this pass showed it doesn't hold up — the reported
    // symptom was exactly "doesn't save and load" once a Storage folder was
    // in use. Root cause: nothing forces a re-opened SAF fd to support
    // mmap/seek/O_TRUNC the way native VFileOpen needs, and that support is
    // provider-specific, not guaranteed by the framework.
    //
    // Replaced with a strictly simpler scheme native code can't get wrong:
    // native NEVER touches a SAF document directly. It always fopen()s a
    // plain file under this app's own internal storage — exactly as it did
    // before this feature existed — and Kotlin copies bytes to/from the
    // chosen folder's document on either side of that call, using
    // ContentResolver's stream APIs, which every DocumentsProvider is
    // required to support (unlike mmap/seek/truncate through a re-opened
    // descriptor). See SaveEntry.stageForRead()/stageForWrite()/
    // commitWrite() for the one-shot save-state/thumbnail case, and
    // batteryMirrorPath()/syncBatteryMirror() for the session-long battery
    // save. Slightly more I/O (a copy instead of a direct mmap), never
    // measurable next to a save file's actual size (a few KB to maybe a few
    // hundred KB), in exchange for not depending on undocumented provider
    // behavior for the one thing this feature actually has to get right.
    //
    // No migration: switching to a folder here does NOT move whatever
    // already exists under internal storage — only new saves/states/
    // screenshots go to the new location from that point on. Doing that
    // move automatically would mean silently rewriting or deleting a
    // user's actual game-save data with no real device available anywhere
    // in this project's history to verify it against — see
    // KNOWN_LIMITATIONS.md. showStorageSettings() says this plainly before
    // anyone taps "Choose folder".

    /** The user's chosen Storage folder, or null if none has been picked
     *  (the default — see the block comment above) or the app's
     *  permission for it is no longer valid (folder deleted/moved outside
     *  the app, permission revoked in system Settings, etc.) — in which
     *  case every SaveEntry below transparently falls back to its legacy
     *  internal-storage path, same as if nothing had ever been picked. */
    private fun dataFolderTree(): DocumentFile? {
        val uriStr = getSharedPreferences(PREFS, MODE_PRIVATE).getString(PREF_DATA_FOLDER_URI, null)
            ?: return null
        return try {
            val uri = Uri.parse(uriStr)
            val stillGranted = contentResolver.persistedUriPermissions.any {
                it.uri == uri && it.isReadPermission && it.isWritePermission
            }
            if (!stillGranted) return null
            DocumentFile.fromTreeUri(this, uri)?.takeIf { it.exists() && it.canWrite() }
        } catch (e: Exception) {
            Log.w(TAG, "dataFolderTree() unusable, falling back to internal storage", e)
            null
        }
    }

    /** Gets-or-creates one of the three fixed subfolders ("save", "cheat",
     *  "screenshot") inside the chosen Storage folder. Null if no folder is
     *  configured, or if creating the subfolder failed for any reason. */
    private fun dataSubfolder(name: String): DocumentFile? {
        val root = dataFolderTree() ?: return null
        return try {
            root.findFile(name)?.takeIf { it.isDirectory } ?: root.createDirectory(name)
        } catch (e: Exception) {
            Log.w(TAG, "dataSubfolder($name) failed", e)
            null
        }
    }

    // ── FEATURE (pass 43): automatic own-folder mirror ────────────────────
    //
    // Everything above (dataFolderTree()/dataSubfolder()/SaveEntry below) is
    // opt-in — nothing leaves this app's internal storage unless someone
    // actually visits Settings → Storage and picks a folder through the SAF
    // tree picker. Two direct reports this pass point at the same gap: this
    // app's own control layout resetting when its cache is cleared (see
    // exportLayoutBackup()/importLayoutBackupIfNeeded() near
    // saveCustomLayout()/loadCustomLayout() — loadCustomLayout() itself is
    // already untouched, it just had nothing durable outside this app's own
    // storage to fall back to), and a request for "its own folder, like My
    // Boy" — one obvious place saves/screenshots/layout always live, with no
    // setup trip required first the way the SAF picker above needs.
    //
    // This adds exactly that, without touching anything above: an automatic
    // mirror folder — Android/data/<pkg>/files/mGBA, entirely inside this
    // app's own external-files directory — created and kept in sync with NO
    // permission prompt and NO Settings visit, the same zero-permission
    // location screenshots already fell back to before this pass (see
    // saveScreenshotBitmap()'s "Legacy/fallback location" branch, now
    // nested one level deeper under this same root instead of sitting bare
    // under getExternalFilesDir()). It's always a MIRROR, never the only
    // copy: native save/state I/O still goes exactly where it always has
    // (SaveEntry's own [legacy], savesDir()/statesDir(), all untouched by
    // this feature) — this only ever copies bytes outward, best-effort,
    // after a write is already known to have succeeded, the same
    // "never risk the real save" discipline commitWrite()/
    // syncBatteryMirror() below already follow for the SAF case.
    //
    // Steps aside entirely once a Storage folder IS configured
    // (autoFolderMirrorActive() below) rather than keeping a second, less
    // visible copy next to a folder someone deliberately picked — one
    // visible "own folder" at a time, not two silently disagreeing ones.
    // Same reasoning extends to layout: exportLayoutBackup() only ever
    // writes into THIS folder, never into a chosen SAF one, since the SAF
    // side of this feature (dataSubfolder()'s fixed save/cheat/screenshot
    // set) was never extended to a 4th "layout" case and doesn't need to be
    // for what this pass's report actually asked for.

    /** True once the person has explicitly chosen a Storage folder above —
     *  see dataFolderTree(). The automatic mirror below only ever runs when
     *  this is false: a folder that was deliberately picked already IS this
     *  app's "own folder" going forward. */
    private fun autoFolderMirrorActive(): Boolean = dataFolderTree() == null

    /** Root of the automatic own-folder mirror. Lives at the top level of
     *  shared storage — /storage/emulated/0/mGBA, a sibling of /Android,
     *  not a folder inside it — matching the "like my boy emulator" ask
     *  this feature's own direct report already named, and matching this
     *  app's own free-roam file manager's storage model too (see
     *  RomBrowserActivity's own deviceRoot).
     *
     *  FIX (this pass — direct report: "not on Android data its hard to
     *  access... make it like myboy the folder is on same level as
     *  android folder not inside"): the previous pass's own version of
     *  this feature put this folder at getExternalFilesDir()/mGBA —
     *  Android/data/<pkg>/files/mGBA — which technically needs no
     *  permission at all, but is exactly the "hard to access" location
     *  this was supposed to be an alternative to: Android 11+ hides
     *  Android/data from every normal file manager (this app's own
     *  RomBrowserActivity included — it can no longer browse into its own
     *  package's Android/data on API 30+), so the previous fix solved
     *  "does the app make its own folder" without actually solving
     *  "...that a person can find". A genuinely top-level folder needs the
     *  same broad storage permission RomBrowserActivity's free-roam
     *  browsing already needs (MANAGE_EXTERNAL_STORAGE on API 30+,
     *  READ_EXTERNAL_STORAGE below that — see hasBroadFileAccess() in
     *  SharedUi.kt) — this only ever attempts the top-level path once
     *  that's actually granted, and falls back to the old zero-permission
     *  Android/data location otherwise, so a save/screenshot/layout mirror
     *  is never the reason someone hits a permission prompt they haven't
     *  already seen. In practice that permission is very rarely still
     *  ungranted by the time this matters: changeRom() (onCreate, below)
     *  sends every fresh install straight into RomBrowserActivity, whose
     *  own onCreate() already asks for exactly this permission before a
     *  ROM can even be picked — long before there's anything to mirror.
     *
     *  Null only in the genuinely rare case external storage isn't
     *  currently available at all (removable/unmounted, mid-swap, etc.) —
     *  every caller below already treats that as "skip this sync, there'll
     *  be another chance" rather than a hard failure, the same spirit as a
     *  failed SAF copy elsewhere in this feature. */
    private fun autoFolderRoot(): File? {
        val base = if (hasBroadFileAccess()) Environment.getExternalStorageDirectory()
                   else getExternalFilesDir(null)
        return base?.let { File(it, "mGBA") }
    }

    /** Gets-or-creates one of this mirror's named subfolders — "Saves",
     *  "Screenshots", "Layout" — mirroring dataSubfolder()'s role for the
     *  SAF side just above. */
    private fun autoMirrorSubdir(name: String): File? =
        autoFolderRoot()?.let { File(it, name).apply { mkdirs() } }

    /**
     * One save-adjacent file — a battery save, a numbered state slot, a
     * state thumbnail, or the quicksave slot — that transparently lives in
     * either this app's internal storage ([legacy], unchanged default) or
     * the [subfolder] ("save") of the user's chosen Storage folder, once
     * one is set. See the block comment above dataFolderTree() for the
     * full reasoning; this class is just the per-file interface onto it,
     * used from quickSaveState()/quickLoadState()/showSaveStateSlotDialog()/
     * captureStateThumbnail()/the two nativeLoadROM() call sites.
     */
    private inner class SaveEntry(private val legacy: File, private val subfolder: String = "save") {
        private fun doc(create: Boolean): DocumentFile? {
            val dir = dataSubfolder(subfolder) ?: return null
            return try {
                dir.findFile(legacy.name)
                    ?: if (create) dir.createFile("application/octet-stream", legacy.name) else null
            } catch (e: Exception) {
                Log.w(TAG, "SaveEntry.doc(${legacy.name}) failed", e); null
            }
        }

        // FIX: was `get() = dataFolderTree() != null` — re-resolved on
        // every single read (a SharedPreferences lookup +
        // persistedUriPermissions scan + DocumentFile.exists()/canWrite(),
        // the latter two real ContentProvider round-trips) instead of
        // once. SaveEntry instances are always freshly constructed per
        // logical operation — see batterySaveEntry()/stateSlotEntry()/
        // stateThumbEntry()/quickStateEntry()/backupEntry() below, none of
        // which hold or reuse an instance across separate operations — and
        // nearly every method on this class reads usesDataFolder at least
        // once, some (exists(), moveInto(), mirrorToAutoFolder()) more
        // than once within a single call chain: a single quickSaveState()
        // chain (backupIfExists -> stageForWrite -> commitWrite ->
        // mirrorToAutoFolder) triggered roughly 8-12 separate resolutions
        // of what's really one answer for this instance's entire short
        // lifetime. Computed once at construction instead — every read
        // below is unchanged (a plain val reads with the exact same
        // `usesDataFolder` syntax a get() property did), so this only
        // costs one resolution now instead of one per read. Only matters
        // in practice once the opt-in Storage folder feature is actually
        // configured — see dataFolderTree()'s own cheap short-circuit for
        // the (default) unconfigured case, which this doesn't change.
        private val usesDataFolder: Boolean = dataFolderTree() != null

        fun exists(): Boolean = if (usesDataFolder) doc(create = false) != null else legacy.exists()

        fun lastModified(): Long =
            if (usesDataFolder) (doc(create = false)?.lastModified() ?: 0L) else legacy.lastModified()

        /** Best-effort delete; used by backupIfExists' callers indirectly
         *  through overwrite semantics only — nothing currently calls this
         *  directly, kept for symmetry with the rest of this class. */
        fun delete(): Boolean = if (usesDataFolder) (doc(create = false)?.delete() ?: false) else legacy.delete()

        /** The sibling "<name>.bak" entry backupIfExists() copies this one
         *  into — same folder this entry itself resolves to, legacy or
         *  Storage folder alike. */
        fun backupEntry(): SaveEntry = SaveEntry(File(legacy.parentFile, "${legacy.name}.bak"), subfolder)

        /** For plain Kotlin-side writes (state thumbnails, and
         *  backupIfExists' own copy, and commitWrite()/syncBatteryMirror()
         *  below) — NOT for native fopen()-based calls, which always get a
         *  local path instead; see stageForRead()/stageForWrite() below.
         *  "wt" explicitly, not the 2-arg openOutputStream(uri)'s default
         *  "w": some providers only guarantee truncation with "wt" — a
         *  plain "w" that happens to write fewer bytes than the previous
         *  save could otherwise leave stale trailing bytes behind. */
        fun outputStream(): OutputStream {
            if (!usesDataFolder) return legacy.outputStream()
            val d = doc(create = true) ?: throw IOException("Couldn't create ${legacy.name} in the chosen folder")
            return contentResolver.openOutputStream(d.uri, "wt") ?: throw IOException("openOutputStream failed for ${legacy.name}")
        }

        /** Null if the entry doesn't exist yet — mirrors the legacy
         *  `if (!f.exists()) return` checks this replaces. */
        fun inputStream(): InputStream? {
            if (!usesDataFolder) return if (legacy.exists()) legacy.inputStream() else null
            val d = doc(create = false) ?: return null
            return contentResolver.openInputStream(d.uri)
        }

        /** Where stageForRead()/stageForWrite() below put their scratch
         *  copy — this app's own cache dir, one fixed name per (subfolder,
         *  legacy name) pair, so a repeated save/load against the same slot
         *  reuses the same scratch file instead of littering the cache. */
        private fun stagingFile(): File = File(cacheDir, "saf_stage_${subfolder}_${legacy.name}")

        /**
         * A LOCAL, REAL file path — never a content:// URI — that already
         * holds this entry's current bytes, ready for
         * nativeLoadState()/nativeLoadROM() to fopen() and read. Returns
         * null if the entry doesn't exist yet, same as the exists() checks
         * every caller already does first.
         *
         * When no Storage folder is configured this is just [legacy]'s own
         * path — already a real local file, nothing to stage. When one IS
         * configured, this copies the SAF document's bytes into a scratch
         * file under this app's cache dir first (via inputStream() above,
         * which every DocumentsProvider supports), then hands back THAT
         * path. See the block comment above dataFolderTree() for why this
         * replaced a direct SAF-fd bridge this pass.
         */
        fun stageForRead(): String? {
            if (!usesDataFolder) return if (legacy.exists()) legacy.absolutePath else null
            val input = inputStream() ?: return null
            val tmp = stagingFile()
            return try {
                input.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                tmp.absolutePath
            } catch (e: Exception) {
                Log.w(TAG, "SaveEntry.stageForRead(${legacy.name}) failed", e)
                null
            }
        }

        /**
         * A LOCAL, REAL file path for nativeSaveState() to fopen() and
         * write into. When no Storage folder is configured this is just
         * [legacy]'s own path — the write lands directly where it always
         * has, nothing further needed. When one IS configured, this is a
         * scratch file under this app's cache dir; the caller MUST call
         * commitWrite() with this same path immediately after a
         * *successful* native write, or the bytes never reach the chosen
         * folder — see commitWrite() below.
         */
        fun stageForWrite(): String {
            if (!usesDataFolder) return legacy.absolutePath
            return stagingFile().absolutePath
        }

        /** Copies whatever native just wrote at [localPath] (from a prior
         *  stageForWrite() call) into the real SAF document. No-op when no
         *  Storage folder is configured — native already wrote straight to
         *  [legacy] in that case, there's nothing left to copy. Callers
         *  must only invoke this after confirming the native write actually
         *  succeeded: calling it unconditionally would happily overwrite a
         *  perfectly good existing save with a partial/empty file on a
         *  failed write. */
        fun commitWrite(localPath: String) {
            if (!usesDataFolder) return
            try {
                File(localPath).inputStream().use { input ->
                    outputStream().use { out -> input.copyTo(out) }
                }
            } catch (e: Exception) {
                Log.w(TAG, "SaveEntry.commitWrite(${legacy.name}) failed — folder copy not updated, local save is still intact", e)
            }
        }

        /** FIX (menu-slot speed pass): moves this entry's current bytes into
         *  [dest] (its ".bak" sibling), replacing whatever was there —
         *  called right before this slot is about to be overwritten by a
         *  fresh save. When no Storage folder is configured this is a
         *  single File.renameTo(): an instant, metadata-only move on the
         *  same volume, NOT a byte-for-byte copy. backupIfExists() used to
         *  read this entry's full bytes and write them out again just to
         *  have nativeSaveState() immediately overwrite this same file
         *  anyway right after — up to 2x a save-state's worth of disk I/O
         *  on every single save, which was most of "pick a slot -> Saved"
         *  feeling slow. Deletes any existing [dest] first, since
         *  File.renameTo()'s platform behavior when the destination already
         *  exists isn't guaranteed. Falls back to copy (old behavior) if
         *  the rename fails for any reason, or whenever a Storage folder
         *  IS configured — DocumentFile has no equivalent plain rename
         *  here, so that path is unchanged from before this fix. */
        fun moveInto(dest: SaveEntry) {
            if (!usesDataFolder && !dest.usesDataFolder) {
                dest.legacy.delete()
                if (legacy.renameTo(dest.legacy)) return
            }
            inputStream()?.use { input -> dest.outputStream().use { out -> input.copyTo(out) } }
        }

        /**
         * The real, local, persistent path nativeLoadROM() mmaps this
         * entry's battery save through for the *entire* ROM session — the
         * one save-adjacent file that can't just be staged-and-discarded
         * per call, since the core keeps writing to it live for as long as
         * the ROM is running (see mgba_jni.c's core->loadSave() comment).
         *
         * When no Storage folder is configured this is just [legacy]
         * itself, exactly as before this feature existed. When one IS
         * configured, [legacy] is used as a local *mirror*: whatever bytes
         * already exist in the chosen folder are copied in here first (so
         * a save carries over from wherever it was last written), the core
         * then mmaps this same local file for the whole session same as
         * always, and syncBatteryMirror() below copies its current bytes
         * back out to the real document at the points in this file that
         * call it (onPause, before swapping ROMs, onDestroy). A failed
         * copy-in here just means starting from whatever's already local
         * (same as a fresh save) rather than losing the load entirely.
         */
        fun batteryMirrorPath(): String {
            if (usesDataFolder) {
                try {
                    inputStream()?.use { input -> legacy.outputStream().use { out -> input.copyTo(out) } }
                } catch (e: Exception) {
                    Log.w(TAG, "SaveEntry.batteryMirrorPath(${legacy.name}): couldn't stage existing save from the chosen folder, continuing from whatever's already local", e)
                }
            }
            return legacy.absolutePath
        }

        /** Copies [legacy]'s current bytes — the mirror nativeLoadROM has
         *  been mmap-writing to all session — out to the real SAF
         *  document. No-op when no Storage folder is configured, or if
         *  [legacy] doesn't exist yet (nothing played, nothing to sync). */
        fun syncBatteryMirror() {
            if (!usesDataFolder || !legacy.exists()) return
            try {
                legacy.inputStream().use { input -> outputStream().use { out -> input.copyTo(out) } }
            } catch (e: Exception) {
                Log.w(TAG, "SaveEntry.syncBatteryMirror(${legacy.name}) failed — folder copy may be stale, local mirror still has the latest", e)
            }
        }

        /** Best-effort copy of [legacy]'s current bytes into the automatic
         *  own-folder mirror's "Saves" subfolder — see
         *  autoFolderMirrorActive()/autoFolderRoot() above. Skipped
         *  entirely once a Storage folder is configured (usesDataFolder) —
         *  that's this app's "own folder" now, see autoFolderMirrorActive()
         *  — and whenever [legacy] doesn't exist yet, same as every other
         *  method here. Deliberately reads from [legacy] specifically
         *  rather than going through outputStream()/doc(): [legacy] is only
         *  guaranteed to hold this entry's current bytes when
         *  !usesDataFolder (see stageForWrite()'s own doc comment — a
         *  configured Storage folder stages state-slot writes through a
         *  scratch cache file instead), which is exactly the one condition
         *  this method already requires before doing anything. Never
         *  throws: same "must never block or fail the real save" discipline
         *  as syncBatteryMirror()/commitWrite() above — this is purely a
         *  convenience copy on top of a write that has already succeeded. */
        fun mirrorToAutoFolder() {
            if (usesDataFolder || !legacy.exists()) return
            val dest = autoMirrorSubdir("Saves") ?: return
            try {
                legacy.copyTo(File(dest, legacy.name), overwrite = true)
            } catch (e: Exception) {
                Log.w(TAG, "SaveEntry.mirrorToAutoFolder(${legacy.name}) failed", e)
            }
        }
    }

    private fun batterySaveEntry(baseName: String): SaveEntry = SaveEntry(batterySaveFile(baseName), "save")
    private fun stateSlotEntry(slot: Int): SaveEntry = SaveEntry(stateSlotFile(slot), "save")
    private fun stateThumbEntry(slot: Int): SaveEntry = SaveEntry(stateThumbFile(slot), "save")
    private fun quickStateEntry(): SaveEntry = SaveEntry(quickStateFile(), "save")

    /** Set only while showStorageSettings()'s dialog is on screen, so
     *  dataFolderPicker's callback above can refresh its status text in
     *  place instead of needing the user to close and reopen it. */
    private var refreshStorageSettingsUi: (() -> Unit)? = null

    /** FIX (quicksave race pass): guards quickSaveState()/quickLoadState()
     *  against overlapping calls. Both used to spawn a brand-new, totally
     *  unsynchronized Thread on every tap — a fast double-tap of Quick Save,
     *  or Quick Save immediately followed by Quick Load (exactly the "test
     *  saving/loading fast" case), fired two Threads with no ordering
     *  between them. g_core_mutex on the native side only serializes the
     *  moment of the actual file write/read against the running game
     *  thread — it does NOT decide which Kotlin thread reaches that point
     *  first. So a fast second tap could win that race and load the file
     *  from BEFORE the first tap's save had written it (looks like it
     *  "loaded the old/first save"), or two saves could land in either
     *  order (looks like it "saved a different frame" than expected). This
     *  flag makes a tap that arrives while one is still in flight a no-op
     *  (with its own toast) instead of racing — same one-thing-at-a-time
     *  guarantee MyBoy's pause-then-menu flow gets for free by construction.
     *
     *  FIX (audit pass): renamed from quickStateBusy and now also guards
     *  showSaveStateSlotDialog()'s save/load Thread, which had the exact
     *  same unguarded pattern — every reason above applies identically
     *  there (it calls the same nativeSaveState()/nativeLoadState(), off
     *  the same kind of bare background Thread, with no ordering between
     *  overlapping calls either). Narrower to actually hit in practice —
     *  the slot dialog dismisses itself after one tap, so it takes two
     *  separate menu visits in quick succession rather than one fast
     *  double-tap on an always-visible button — but it's the identical
     *  underlying race, and one flag correctly covering *every* save-state
     *  operation (quick or slot) is simpler and safer than two flags that
     *  would each need to know about the other to close the gap between
     *  them (a quick-save racing a slot-load, etc.). */
    private val saveStateBusy = java.util.concurrent.atomic.AtomicBoolean(false)

    private fun quickSaveState() {
        if (!romLoaded) { uiToast("Load a ROM first"); return }
        if (!saveStateBusy.compareAndSet(false, true)) {
            uiToast("Still saving/loading — try again in a moment"); return
        }
        val entry = quickStateEntry()
        // Off the UI thread — same reasoning as showSaveStateSlotDialog's
        // Thread below: touches disk and briefly holds the native core's
        // mutex against the running game thread.
        Thread {
            try {
                backupIfExists(entry)
                val localPath = entry.stageForWrite()
                val ok = EmulatorEngine.nativeSaveState(localPath)
                if (ok) {
                    entry.commitWrite(localPath)
                    entry.mirrorToAutoFolder()
                }
                uiToast(if (ok) "Quick saved" else "Quick save failed")
            } finally {
                saveStateBusy.set(false)
            }
        }.apply { name = "mGBA-quicksave" }.start()
    }

    private fun quickLoadState() {
        if (!romLoaded) { uiToast("Load a ROM first"); return }
        if (!saveStateBusy.compareAndSet(false, true)) {
            uiToast("Still saving/loading — try again in a moment"); return
        }
        val entry = quickStateEntry()
        // FIX (lag pass): entry.exists() used to run right here, on the UI
        // thread, before ever spawning a background thread — the same
        // SAF-round-trip cost as showSaveStateSlotDialog's old exists()
        // calls, just once instead of a dozen. Moved inside the thread
        // below so a slow/SAF-backed check can't stall the UI either.
        Thread {
            try {
                if (!entry.exists()) { uiToast("No quick save yet"); return@Thread }
                val localPath = entry.stageForRead()
                val ok = localPath != null && EmulatorEngine.nativeLoadState(localPath)
                uiToast(if (ok) "Quick loaded" else "Quick load failed — may be from a different ROM")
            } finally {
                saveStateBusy.set(false)
            }
        }.apply { name = "mGBA-quickload" }.start()
    }

    /**
     * FEATURE: auto save backup. Copies [entry] to its sibling
     * [SaveEntry.backupEntry] — same folder [entry] itself resolves to,
     * legacy internal storage or the chosen Storage folder alike — if it
     * already exists, right before it's about to be overwritten: the
     * battery save is re-opened read/write and mmap'd by the native core
     * on every ROM load (see nativeLoadROM), and a save-state slot is
     * truncated the instant "Save State" is tapped (see nativeSaveState/
     * showSaveStateSlotDialog). Best-effort and silent: a backup failure
     * must never block the actual save, so any exception here is only
     * logged, never surfaced to the user.
     *
     * This is a single rolling backup, not a history — each new backup
     * replaces the last. It's a one-level rollback if the current session's
     * save turns out to be corrupt (app killed mid-write, storage fills up,
     * a bad ROM stomps save memory it shouldn't, etc.), not a substitute
     * for the user making their own backups of anything precious. There is
     * currently no in-app "restore from backup" UI — see KNOWN_LIMITATIONS.md.
     */
    private fun backupIfExists(entry: SaveEntry) {
        if (!entry.exists()) return
        try {
            entry.moveInto(entry.backupEntry())
        } catch (e: Exception) {
            Log.w(TAG, "Backup failed (continuing without one)", e)
        }
    }

    // ── Lifecycle ──────────────────────────────────────────────────────────

    /** FEATURE: new — self-service crash log. W can't pull logcat off this
     *  device for reasons neither of us has pinned down, which blocks the
     *  normal "send me the stack trace" loop entirely. This sidesteps that:
     *  it wraps whatever the default uncaught-exception handler already
     *  was, so a crash still behaves exactly as it always did (process
     *  dies, system shows its usual "stopped" behavior) — but first writes
     *  the full exception, stack trace, thread name, and device info to a
     *  plain file this app owns outright (File(filesDir, "crash_log.txt"),
     *  same pattern as the FIX 17 link-debug log). Exposed through the
     *  existing ⚙ menu's new "Copy crash log" row (see showGameMenu() /
     *  copyCrashLog() below) so it can be grabbed with nothing but a tap +
     *  paste, no PC/adb/logcat involved. Overwrites on each crash (not
     *  appended) so it always reflects the MOST RECENT crash, never a
     *  stale one from an already-fixed issue.
     *
     *  Everything in here is wrapped defensively — a crash handler that
     *  itself throws (e.g. disk full while writing the report) must still
     *  fall through to the real handler below, or the app would hang
     *  instead of dying cleanly, which is a worse failure mode than simply
     *  losing that one report. */
    private fun installCrashLogger() {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val trace = StringWriter().also { throwable.printStackTrace(PrintWriter(it)) }.toString()
                val report = buildString {
                    appendLine("mGBA crash report")
                    appendLine("Time: ${java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US).format(java.util.Date())}")
                    appendLine("Thread: ${thread.name}")
                    appendLine("Device: ${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})")
                    appendLine()
                    append(trace)
                }
                File(filesDir, "crash_log.txt").writeText(report)
            } catch (_: Throwable) {
                // See doc comment above — must not block the real handoff below.
            }
            if (previous != null) {
                previous.uncaughtException(thread, throwable)
            } else {
                android.os.Process.killProcess(android.os.Process.myPid())
                kotlin.system.exitProcess(10)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // FEATURE: new — self-service crash log, no logcat/adb needed. See
        // installCrashLogger()'s own doc comment. Installed as the literal
        // first thing after super.onCreate() so it's active before
        // anything else in this method — or any background thread this
        // method goes on to spawn, e.g. loadRomFromUri()'s — gets a chance
        // to throw.
        installCrashLogger()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        // FIX: let the window draw into the camera-cutout area instead of
        // leaving the default black bar there. LAYOUT_IN_DISPLAY_CUTOUT_MODE_
        // DEFAULT letterboxes around the cutout on whichever edge it sits
        // on — most visible in landscape (still the default orientation
        // below), where the cutout (normally the phone's physical top edge,
        // a "short" edge) ends up intruding into the middle of the
        // horizontal game view instead of just sitting inside a status bar
        // that's already hidden.
        //
        // FIX (this pass): reported as still a lot of black area around the
        // cutout even with SHORT_EDGES. Upgraded to ALWAYS on API 30+,
        // which is a strict superset of SHORT_EDGES — "content is always
        // allowed to extend into the cutout areas" outright, with none of
        // SHORT_EDGES's own conditions about which edge or bar state — so
        // this can only extend the drawable area further, never shrink it.
        // ALWAYS needs API 30 specifically (SHORT_EDGES, the previous only
        // option here, needs API 28); below 30 this still falls back to
        // SHORT_EDGES exactly as before. Genuinely uncertain this fully
        // explains what was reported rather than just being a real,
        // separate improvement alongside it — no device in this sandbox to
        // confirm either way, and "a lot of black screen" without a
        // screenshot leaves real room for this being partly/wholly a
        // different area entirely (see RomBrowserActivity.kt, which had no
        // cutout handling at all before this pass — a confirmed gap, not a
        // guess, since that Activity is new this same overall changeset).
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            }
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        // Load saved preferences
        getSharedPreferences(PREFS, MODE_PRIVATE).also { p ->
            fastForwardSpeed      = p.getFloat(PREF_FF_SPEED,    2.0f)
            buttonScaleMultiplier = p.getFloat(PREF_BTN_SCALE,   1.0f)
            buttonBaseAlpha       = p.getInt(PREF_BTN_ALPHA,      160)
            gameScreenFraction    = p.getFloat(PREF_SCREEN_FRAC, GAME_FRAC_NORM)
            stretchToFit          = p.getBoolean(PREF_STRETCH,    false)
            maxFrameSkips         = p.getInt(PREF_MAX_SKIPS,      0)
            linearFilterEnabled   = p.getBoolean(PREF_LINEAR_FILTER, false)
            soundEnabled          = p.getBoolean(PREF_SOUND_ENABLED, true)
            soundVolumePercent    = p.getInt(PREF_SOUND_VOLUME,   100)
            soundFrequencyHz      = p.getInt(PREF_SOUND_FREQ,     44100)
            showFpsOverlay        = p.getBoolean(PREF_SHOW_FPS,   false)
            gridDivisions         = p.getInt(PREF_GRID_SIZE,      8)
            showGrid              = p.getBoolean(PREF_SHOW_GRID,  false)
            snapToGrid            = p.getBoolean(PREF_SNAP_GRID,  false)
            screenOrientationChoice = p.getInt(PREF_ORIENTATION, ORIENTATION_LANDSCAPE)
        }
        updateLinearFilterPaint()
        updateSoundFrequencyFactor()
        // FEATURE: screen orientation setting (Video settings, see
        // applyScreenOrientationPref()/showVideoSettings()). This used to be
        // a fixed requestedOrientation = SCREEN_ORIENTATION_LANDSCAPE right
        // here, with android:screenOrientation="landscape" in the manifest
        // on top of it — see AndroidManifest.xml for why that attribute is
        // now "unspecified" instead. android:configChanges there already
        // keeps this activity (and the running core) alive across whatever
        // orientation change this causes, exactly as it did for the old
        // hardcoded assignment, so nothing about restart/config-change
        // handling needed to change for this.
        applyScreenOrientationPref()
        audioManager = getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        // FIX (pass 43 — direct report: "if i clear cache my button reset"):
        // pre-fills SharedPreferences from the automatic own-folder backup
        // when — and only when — it has nothing of its own to offer
        // loadCustomLayout() right below. See importLayoutBackupIfNeeded()'s
        // own doc comment; loadCustomLayout() itself is unchanged.
        importLayoutBackupIfNeeded()
        loadCustomLayout()

        link = LinkMultiplayer(this)

        // FIX 17: durable link-debug logging that doesn't depend on OS
        // logcat access — see KNOWN_LIMITATIONS.md's "The debug-log tool
        // doesn't work on every phone" and copyLinkDebugLog() below, which
        // now reads this file instead of shelling out to `logcat`. filesDir
        // is always writable by this app, on every device, with no
        // permission needed — unlike reading back the system's own logcat
        // buffer, which some OEM builds restrict even for an app reading
        // its own output.
        EmulatorEngine.nativeSetLinkLogPath(File(filesDir, "link_debug.log").absolutePath)
        // FIX 9: previously nothing ever told this side when the *other*
        // phone disconnected — isConnected only ever went back to false via
        // our own local "Disconnect" tap. link.onPeerLost fires from
        // LinkMultiplayer's liveness watchdog / BYE handling, already on the
        // main thread, so this can update UI directly.
        link.onPeerLost = { EmulatorEngine.nativeLinkStop(); uiToast("Peer disconnected") }
        val root = FrameLayout(this)
        surfaceView = SurfaceView(this)
        surfaceView.holder.addCallback(this)
        root.addView(surfaceView, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        // FIX (this pass): the floating "▶ Load ROM" button that used to sit
        // here is gone. It was a Button, and a stock Material Button carries
        // a small default elevation even when nothing sets one explicitly —
        // enough that Android's Z-order draws it ABOVE the opaque
        // settingsMenuOverlay added later in this method (and, before it
        // became a separate Activity, the ROM browser overlay too),
        // regardless of add order. Since changeRom() (below, and on Close —
        // see closeGame()) already opens the ROM browser automatically any
        // time there's no ROM loaded, that button was floating uselessly on
        // top of the browser it was supposed to sit *behind* — visible as a
        // stray purple pill hovering over the file list. Removed outright
        // rather than patched (e.g. elevation = 0f), since changeRom()
        // already covers every case it existed for. The one thing it also
        // did — give the user a way back in in the two edge cases where
        // nothing else is on screen (the folder picker gets cancelled
        // before any folder's ever been chosen, or a ROM load fails) — is
        // now handled by onGameTouch() below: tapping the idle surface while
        // no ROM is loaded calls changeRom() directly.

        // UI: the 🔗 Link and 📂 change-ROM buttons that used to float here
        // (top-right, always on top of the game view) are gone — both now
        // live as rows inside the Settings list instead ("Link remote",
        // "Link local", "Change ROM" — see buildSettingsMenu()), reached via
        // the ⚙ button below. One less pair of icons sitting over gameplay,
        // and Settings was already scrollable so the extra rows just fit.
        settingsBtn = TextView(this).apply {
            text = "⚙"; textSize = 18f
            // FIX: setPadding below was raw pixels, not dp — the same
            // "forgot this one spot" gap this file's own comments already
            // trace for several other paddings/margins (e.g. the per-item
            // editor bar's own EDIT_TOOLBAR_GAP_DP fix, and this same
            // button's own topMargin/leftMargin just below).
            setTextColor(Color.WHITE); setPadding(dp(20), dp(6), dp(20), dp(6))
            background = iconChipBackground()
            setOnClickListener { showGameMenu() }
        }
        root.addView(settingsBtn, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT
        ).also {
            it.gravity = Gravity.TOP or Gravity.START
            // FIX: was raw topMargin = 8; leftMargin = 8 — 8 *pixels*, not
            // 8dp, same bug class as setPadding just above. On a
            // high-density phone this button sat only a couple of dp from
            // the true screen corner instead of the intended 8dp.
            it.topMargin = dp(8); it.leftMargin = dp(8)
        })

        // ── Control-layout editor UI ────────────────────────────────────────
        // Two small real-View toolbars layered above the SurfaceView. Editing
        // itself (drag/resize hit-testing) happens on the SurfaceView's touch
        // events (see onEditTouch) exactly like normal gameplay input — these
        // bars are just chrome: mode controls + per-button fine adjustment.
        // FIX (Fortieth pass — reported directly: "control size... plus
        // and minus... really hard to click its very small"): setPadding
        // below took raw pixels, not dp, unlike every other size in this
        // file (which all go through dp()) — on a real, higher-density
        // phone that's a handful of actual pixels, not the "18/4" it reads
        // as in the source. Barely visible on the worded top-bar chips
        // ("Add Control" etc.), where the text itself provides most of the
        // width either way, but it's nearly a single-glyph "-"/"+" chip's
        // *entire* size — exactly the ones called out. minTouchDp lets a
        // specific chip additionally guarantee a real minimum touch target
        // (Android's own 48dp guideline) no matter how little content/
        // padding would otherwise produce; only the four "-"/"+" call
        // sites below pass it — every other chip keeps its old
        // hug-content sizing, just with the dp() padding fix applied.
        fun editChip(label: String, minTouchDp: Int = 0, onClick: () -> Unit) = Button(this).apply {
            text = label; textSize = 12f; setPadding(dp(18), dp(4), dp(18), dp(4))
            val minPx = if (minTouchDp > 0) dp(minTouchDp) else 0
            minWidth = minPx; minimumWidth = minPx; minHeight = minPx; minimumHeight = minPx
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#552A2A3A"))
            setOnClickListener { onClick() }
        }

        // CUSTOMIZATION UI (this pass): every label below is plain text —
        // no emoji/dingbat glyphs anywhere in this editor UI, per the
        // request. "Reset All" is now "Reset Controls" (matches the wording
        // asked for); a "Grid" entry point was added alongside it — see
        // showGridSettingsDialog().
        editTopBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            // FIX: both setPadding calls in this block were raw pixels,
            // not dp — same bug class as editTopBarScroll's own topMargin
            // fix just below this bar's construction, and directly part of
            // the same "control customization popup" reported as cut
            // off/cramped.
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setBackgroundColor(Color.parseColor("#DD1A1A22"))
            visibility = View.GONE
            addView(TextView(this@MainActivity).apply {
                text = "Edit Layout"
                setTextColor(Color.parseColor("#FFEE58")); textSize = 12f
                setPadding(dp(8), dp(8), dp(24), dp(8))
            })
            // ADD/REMOVE CONTROL — opens the picker of currently-hidden
            // controls (see showAddControlMenu). Removing one is done by
            // holding it instead (see onEditTouch/showRemoveButtonMenu) —
            // full instructions are in the toast shown on entering edit
            // mode (enterEditMode()), kept off this bar so it stays short
            // enough to fit alongside these buttons in landscape.
            addView(editChip("Add Control")    { showAddControlMenu() })
            addView(editChip("Reset Controls") { confirmResetAllLayout() })
            addView(editChip("Grid")           { showGridSettingsDialog() })
            addView(editChip("Cancel")         { exitEditMode(save = false) })
            addView(editChip("Done")           { exitEditMode(save = true) })
        }
        // Wrapped in a HorizontalScrollView so this row degrades to
        // scrollable (instead of clipping off-screen) on narrower landscape
        // widths now that it holds five buttons instead of three — see the
        // BUG FIX comments around the button-editor's hitbox/precision
        // issues above for the broader "landscape + this editor" theme.
        // Visibility is still toggled on editTopBar itself (enterEditMode/
        // exitEditMode) — a GONE child collapses this wrapper to nothing,
        // so no extra plumbing needed here for that.
        editTopBarScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(editTopBar)
        }
        // FIX (this pass — same direct report as four previous passes'
        // refreshEditToolbarPosition() fix attempts: "if you move it
        // sometimes it disappears or get cutoff"): topMargin below was raw
        // pixels, not dp — the same bug class this file's own comments
        // already trace for several other paddings/margins, this time on
        // the one input every one of those previous fix attempts assumed
        // was already correct. refreshEditToolbarPosition() computes the
        // per-item bar's minimum allowed top (topBound, right below) from
        // this bar's own laid-out height/position, so every previous pass
        // was re-deriving the clamp math against a *slightly wrong* input
        // — on a high-density phone this sat only a couple of dp from the
        // top instead of the intended 8dp, and topBound was reading
        // editTopBar's own height directly rather than this wrapper's
        // (see that fix for the rest of it). Neither gap alone was large,
        // but both fed the exact same downstream clamp, and no previous
        // pass's fix touched either one — each just re-tuned the clamp
        // formula itself against inputs that were quietly off to begin
        // with, which is consistent with the bug surviving that many
        // separate attempts at the formula alone.
        root.addView(editTopBarScroll, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT
        ).also { it.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; it.topMargin = dp(EDIT_TOOLBAR_SCREEN_MARGIN_DP) })

        // Per-item bar, restructured (this pass) into three stacked rows
        // instead of one long horizontal strip of chips — the requested
        // labels ("Game Screen Size", "Control Size", "Control Opacity")
        // are full words, not something that fits cleanly as bare "Size±"/
        // "Op±" chip text the way the old single-row version had them.
        // Row 1: which control is selected, its lock state, and its own
        //         reset — unchanged in spirit, plain text instead of
        //         lock emoji/↺ glyph.
        // Row 2: size, label switches between "Game Screen Size" and
        //         "Control Size" — see onEditTouch's ACTION_DOWN.
        // Row 3: opacity — hidden outright when the game screen is
        //         selected (see editOpacityRow's own field comment).
        // FIX (this pass — direct report: "make the pop up smaller"): was
        // setPadding(14, 4, 14, 4) — raw pixels, not dp, the exact same
        // mistake EDIT_TOOLBAR_GAP_DP's own comment already traces for the
        // bar's margin/gap (≈4-5dp on a typical ~3x-density phone, not the
        // 14dp it reads as in code). Fixed to real dp here too, and sized
        // down at the same time — textSize 13→12 and a smaller dp() padding
        // that's still consistent across every density, instead of an
        // accidentally-tiny raw-px value that only *looked* small on this
        // pass's own test device.
        editButtonLabel = TextView(this).apply {
            textSize = 12f; setTextColor(Color.WHITE); setPadding(dp(8), dp(3), dp(8), dp(3))
        }
        editLockBtn = editChip("Unlocked") { toggleSelectedLock() }
        val editRow1 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(editButtonLabel)
            addView(editLockBtn)
            addView(editChip("Reset") { editSelectedId?.let { resetSingleButton(it) } })
        }
        // FIX (this pass): "-"/"+" chips replaced with a real slider (drag
        // anywhere along it) plus a tap-to-type-exact-number readout — see
        // sliderRow()/SliderRow in SharedUi.kt. Direct report: "in control
        // size there's plus and minus but it really hard to click its very
        // small... maybe a slider with number or percent and you can type
        // the number". editSizeLabel stays a separate field (rather than a
        // label baked into sliderRow itself) because its text keeps
        // swapping between "Control Size"/"Game Screen Size" after
        // construction — see syncEditButtonBarToSelection(). Both rows are
        // given an explicit width (dp(EDIT_TOOLBAR_SLIDER_WIDTH_DP) below)
        // rather than left at WRAP_CONTENT: the SeekBar's own weight=1 (see sliderRow()) only
        // has room to expand into an *exact*-width parent, not a
        // WRAP_CONTENT one, since there's no "extra space" for weight to
        // distribute otherwise.
        //
        // FIX (this pass — direct report: "the slider and number input box
        // aligned horizontally and vertically"): editSizeLabel and the
        // opacity row's label used to each be their own bare TextView,
        // sized to hug whichever text they held — "Control Size"/"Game
        // Screen Size" for one, the always-fixed "Control Opacity" for the
        // other. Since those strings are different lengths, the sliders
        // sitting right after them landed at two different x positions,
        // one row not lined up under the other. editRowLabel() below gives
        // every label in this bar the exact same look in one place, and
        // both rows now pin that label to editRowLabelWidth — measured
        // from the *longest* string either one can ever show ("Game Screen
        // Size") rather than guessed as a constant, so it's exactly wide
        // enough on any device/font and never clips. With both labels the
        // same width, both sliders start at the same x — one steady
        // two-column grid instead of two rows that happen to independently
        // wrap their own content.
        // labelText, not text: TextView has its own "text" property, and
        // an unqualified "text" on the right of an assignment *inside*
        // this apply{} block would resolve to that (silently reading back
        // whatever the TextView's own text already was, i.e. always
        // ""/empty here) rather than this function's parameter — the same
        // implicit-receiver-shadows-outer-name trap sliderRow()'s own
        // comment already calls out for SeekBar.max, just one property
        // name over. Distinct names sidesteps it the same way.
        // FIX (this pass — direct report: "make the pop up smaller"): text
        // 12→11sp and tighter start/end padding. editRowLabelWidth right
        // below is *measured* from this exact paint/padding, so shrinking
        // either one here automatically narrows both row2 and the opacity
        // row — nothing to keep in sync by hand.
        fun editRowLabel(labelText: String = "") = TextView(this).apply {
            text = labelText
            textSize = 11f; setTextColor(Color.parseColor("#CCCCCC")); setPadding(dp(8), dp(3), dp(6), dp(3))
        }
        editSizeLabel = editRowLabel()
        val editRowLabelWidth = editSizeLabel.paint.measureText("Game Screen Size").toInt() +
            editSizeLabel.paddingLeft + editSizeLabel.paddingRight + dp(4)
        editSizeSlider = sliderRow(
            min = 50, max = 800, initial = 100,
            label = { editSizeLabel.text.toString() }
        ) { setSelectedScalePercent(it) }
        val editRow2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(editSizeLabel, LinearLayout.LayoutParams(editRowLabelWidth, LinearLayout.LayoutParams.WRAP_CONTENT))
            addView(editSizeSlider.root, LinearLayout.LayoutParams(dp(EDIT_TOOLBAR_SLIDER_WIDTH_DP), LinearLayout.LayoutParams.WRAP_CONTENT))
        }
        // Opacity's own floor: alphaToPercent(60), not 0 — see that
        // function's own comment for why a control can be dimmed a lot but
        // never made fully invisible/undiscoverable this way.
        editOpacitySlider = sliderRow(
            min = alphaToPercent(60), max = 100, initial = 100,
            label = { "Control Opacity" }
        ) { setSelectedAlphaPercent(it) }
        editOpacityRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(editRowLabel("Control Opacity"), LinearLayout.LayoutParams(editRowLabelWidth, LinearLayout.LayoutParams.WRAP_CONTENT))
            addView(editOpacitySlider.root, LinearLayout.LayoutParams(dp(EDIT_TOOLBAR_SLIDER_WIDTH_DP), LinearLayout.LayoutParams.WRAP_CONTENT))
        }
        editButtonBar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            // FIX (this pass — direct report: "make the pop up smaller"):
            // was dp(10)/dp(6) — trimmed alongside every other size in this
            // block; see EDIT_TOOLBAR_ROW_GAP_DP/_SLIDER_WIDTH_DP's own
            // comment in the companion object for the rest of this pass.
            setPadding(dp(8), dp(5), dp(8), dp(5))
            // FIX (this pass — direct report: "make pop up circle edge"):
            // was a flat setBackgroundColor() — square corners — see
            // editToolbarBackground() in SharedUi.kt for the same fill
            // rounded to match every other popup in the app.
            background = editToolbarBackground()
            visibility = View.GONE
            // FIX (this pass — direct reports: the popup "get cut off" and
            // "the slider and box is not aligned"): editSizeSlider's/
            // editOpacitySlider's own value boxes (36dp tall at the time —
            // see EDIT_TOOLBAR_VALUE_BOX_HEIGHT_DP in SharedUi.kt for the
            // current number) are taller than editRow1's plain
            // chips/text, so with all three rows stacked directly against
            // each other there was no room for that extra height without
            // visually spilling into the row above/below — that's what
            // actually read as "cut off"/"not aligned" here, on top of
            // refreshEditToolbarPosition()'s own separate off-screen-
            // clamping fix below. A small explicit gap between rows fixes
            // it without shrinking the touch target any further.
            //
            // FIX (this pass — direct report: "make the pop up smaller"):
            // 6dp → EDIT_TOOLBAR_ROW_GAP_DP (4dp) — still a clearly visible
            // gap between rows, just tighter, now that the value boxes
            // themselves are also shorter (see EDIT_TOOLBAR_VALUE_BOX_
            // HEIGHT_DP in SharedUi.kt) so there's less height to separate.
            val rowGap = dp(EDIT_TOOLBAR_ROW_GAP_DP)
            addView(editRow1, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = rowGap })
            addView(editRow2, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = rowGap })
            addView(editOpacityRow)
        }
        // Positioned dynamically (see refreshEditToolbarPosition) — x/y set
        // directly rather than via gravity, since it needs to track whichever
        // button is currently selected.
        root.addView(editButtonBar, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT))

        // ── Settings screen ──────────────────────────────────────────────
        // Built once and just shown/hidden (same pattern as editTopBar
        // above) — it has no dynamic state of its own, unlike the category
        // dialogs it opens, which rebuild their fields fresh every time.
        settingsMenuOverlay = buildSettingsMenu().apply { visibility = View.GONE }
        root.addView(settingsMenuOverlay, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        // ── Memory viewer ────────────────────────────────────────────────
        // Same built-once/shown-hidden pattern as Settings just above — see
        // showMemoryViewer()'s doc comment for why this is an overlay
        // rather than its own Activity (needs the game loop to keep
        // running underneath it, unlike the ROM browser).
        memoryViewerOverlay = buildMemoryViewer().apply { visibility = View.GONE }
        root.addView(memoryViewerOverlay, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        // ROM file browser: was built and attached here as an overlay,
        // same built-once/shown-hidden pattern as the Settings screen just
        // above — now RomBrowserActivity.kt, its own Activity, launched via
        // changeRom()/romBrowserLauncher instead. Nothing to build here.

        setContentView(root)
        surfaceView.setOnTouchListener { _, ev -> onGameTouch(ev); true }
        setImmersive()

        // FEATURE: land straight in ROM selection instead of requiring an
        // explicit tap first — changeRom() launches RomBrowserActivity
        // unconditionally; whether that lands the user straight in the
        // folder they last browsed, prompts for permission first, or
        // whatever else, is entirely that Activity's own concern now (see
        // RomBrowserActivity.kt), not something this onCreate() needs to
        // know about. If the user backs out of it with nothing picked
        // (permission denied, cancelled, whatever), romBrowserLauncher's
        // callback above does nothing and the surface just sits idle —
        // tapping it calls changeRom() again (see onGameTouch()), so
        // there's still a way back in without any button needed underneath.
        changeRom()
    }

    override fun onDestroy() {
        super.onDestroy()
        stopGameLoop()
        // FIX (Twenty-first pass): last-resort flush of the battery-save
        // mirror to the chosen Storage folder, if one is configured — see
        // SaveEntry.syncBatteryMirror(). onPause() below is the main place
        // this happens; this is just a backstop for whatever's played
        // between onPause and the process actually going away, e.g. a
        // resumed session that's then killed outright rather than just
        // backgrounded. mirrorToAutoFolder() alongside it — see the FEATURE
        // block above dataFolderTree() — for the same backstop, but for the
        // automatic own-folder mirror instead of a chosen SAF folder.
        if (romLoaded) {
            batterySaveEntry(currentRomBaseName).syncBatteryMirror()
            batterySaveEntry(currentRomBaseName).mirrorToAutoFolder()
        }
        releaseAudio()
        EmulatorEngine.nativeLinkStop()
        link.disconnect()
        EmulatorEngine.nativeDestroy()
    }

    // FIX: no onPause/onResume existed at all. The emulation thread and the
    // AudioTrack were only ever stopped from surfaceDestroyed()/onDestroy(),
    // but backgrounding an app (Home button, recents, notification shade)
    // does not reliably or promptly destroy a SurfaceView's Surface — so the
    // game kept running full-speed and audio kept playing while the app was
    // not visible, burning battery/CPU and producing audio "leaking" behind
    // whatever the user switched to. This is exactly the kind of background
    // battery-drain behavior Play Console's background-usage checks flag.
    override fun onPause() {
        super.onPause()
        stopGameLoop()
        // FIX (Twenty-first pass): flush the battery-save mirror out to the
        // chosen Storage folder (no-op if none is configured, or if nothing
        // has been played yet — see SaveEntry.syncBatteryMirror()). Backgrounding
        // is the single most common way a session actually ends on Android —
        // Home button, notification shade, a phone call — far more often
        // than onDestroy() ever runs, so this is the flush that actually
        // matters in practice; onDestroy()'s own call is just a backstop.
        // mirrorToAutoFolder() alongside it — see the FEATURE block above
        // dataFolderTree() — same flush, automatic own-folder mirror
        // instead of a chosen SAF folder.
        if (romLoaded) {
            batterySaveEntry(currentRomBaseName).syncBatteryMirror()
            batterySaveEntry(currentRomBaseName).mirrorToAutoFolder()
        }
        try {
            audioTrack?.pause()
            // AUDIO FIX: pause() alone leaves whatever was already queued in
            // the AudioTrack's internal buffer intact. If the app is
            // backgrounded for a while and then resumed, that stale audio
            // would play first, ahead of anything the resumed game loop
            // writes — an audible "blip" of old sound. flush() (only valid
            // once paused/stopped) discards it so resume always starts clean.
            audioTrack?.flush()
        } catch (_: Exception) {}
    }

    override fun onResume() {
        super.onResume()
        if (romLoaded && surfaceHolder != null && !running) {
            startGameLoop()
        }
    }

    // FIX: setImmersive() was only ever called once, at the very end of
    // onCreate. Every AlertDialog this app opens — the game menu, each
    // Settings category, save-state prompts, all of them — takes window
    // focus away and back, and that resets the old systemUiVisibility
    // flags, so the status/nav bars crept back in the moment any dialog was
    // shown and dismissed. Re-applying on every focus regain (not just
    // launch) is the standard fix for immersive mode "not sticking".
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) setImmersive()
    }

    // ── Audio ──────────────────────────────────────────────────────────────
    //
    // AUDIO ARCHITECTURE (rewritten)
    // ───────────────────────────────
    // Old design: game thread ran nativeRunFrame() once, wrote PCM to
    // AudioTrack with WRITE_NON_BLOCKING (return value discarded), then slept
    // for a *fixed* 1/60 s to pace itself. Two compounding problems:
    //   1. 1/60 s is not the GBA's real frame period (see GBA_CYCLES_PER_FRAME
    //      above), so the loop fed audio ~0.46% faster than it could play.
    //   2. WRITE_NON_BLOCKING silently drops whatever doesn't fit — so that
    //      surplus was thrown away in little bursts instead of building
    //      genuine latency, producing a small periodic glitch.
    //
    // New design: the game thread writes PCM with a genuine *blocking* write
    // and does NOT sleep on its own for the normal-speed case — the blocking
    // write against a real audio clock (the DAC/HAL drain rate) becomes the
    // frame pacer. This is the same "audio-locked" sync strategy used by most
    // well-engineered software emulators: the audio hardware clock is far more
    // stable than Thread.sleep(), which is at the mercy of OS scheduling
    // jitter, so tying video pacing to it removes drift entirely instead of
    // approximating a fixed wall-clock rate. A short fallback sleep
    // (FALLBACK_FRAME_NS) only kicks in for frames that produce zero audio
    // samples (e.g. immediately after a ROM loads), so the loop never spins
    // unpaced if audio is temporarily unavailable.
    //
    // Fast-forward now plays audio too, instead of dropping it outright.
    // Each FF batch's sub-frame audio is accumulated (ffAccumBuffer) and
    // then box-filter decimated down to roughly one frame's worth — see
    // decimateForFastForward() below — before going through the same
    // blocking writePcm() pacer as normal playback. That keeps the loop's
    // real-time pacing (and therefore the actual speedup) intact while
    // producing real, audible, pitched-up audio: the same "sped-up tape"
    // effect classic emulators use for FF sound, not a pitch-accurate
    // resample. A proper interpolating resampler would sound cleaner but is
    // a substantially bigger DSP undertaking for a fairly small audible gain
    // over this.
    // (audioTrack / audioBuffer / audioDiagCounter fields are declared above,
    // grouped with the rest of the class's mutable state.)

    /**
     * (Re)creates the AudioTrack.
     *
     * Buffer size: minBuf * 3. This used to be minBuf * 2 for lower latency,
     * but that cut it too close: rendering used to run on this same thread
     * right after each writePcm() call, and a slow render (a GC pause, a
     * busy compositor) could stall the next write long enough for AudioTrack
     * to run dry — an underrun, heard as a click/pop. Rendering is now
     * decoupled onto its own Choreographer-driven loop (see the triple-buffer
     * fields near the top of this class and startGameLoop()), which removes
     * that particular stall, but minBuf*3 is left as-is: it's cheap headroom
     * against ordinary OS scheduling jitter on the write thread itself, and
     * there's no benefit to shaving it back down.
     *
     * PERFORMANCE_MODE_LOW_LATENCY (API 26+) opts into the platform's fast
     * mixer path when the device supports it. It's a request, not a
     * guarantee — unsupported devices silently fall back to the normal path
     * with no functional risk, so it's safe to always ask for it.
     */
    private fun initAudioTrack() {
        releaseAudio()
        // Any pending Sound-frequency-triggered rebuild is satisfied by
        // this call itself, whichever path actually triggered it — see
        // audioTrackRebuildPending's own field comment.
        audioTrackRebuildPending = false
        val minBuf = AudioTrack.getMinBufferSize(
            soundFrequencyHz,
            AudioFormat.CHANNEL_OUT_STEREO,
            AudioFormat.ENCODING_PCM_16BIT
        ).coerceAtLeast(4096)
        val bufferBytes = (minBuf * 3).coerceAtLeast(6144)

        val builder = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(soundFrequencyHz)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                    .build()
            )
            .setBufferSizeInBytes(bufferBytes)
            .setTransferMode(AudioTrack.MODE_STREAM)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder.setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
        }

        audioTrack = try { builder.build() } catch (e: Exception) {
            Log.e(TAG, "AudioTrack.Builder failed, retrying without low-latency mode", e)
            // Some OEM audio HALs reject PERFORMANCE_MODE_LOW_LATENCY outright
            // instead of gracefully degrading. Retry once without it so a
            // quirky device still gets sound, even if not the fast path.
            try {
                AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build())
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(soundFrequencyHz)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                            .build())
                    .setBufferSizeInBytes(bufferBytes)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()
            } catch (e2: Exception) {
                Log.e(TAG, "AudioTrack unavailable on this device", e2)
                null
            }
        }
        // FIX (this pass): used to be a hardcoded setVolume(1.0f) — now
        // applies the actual Enable sound / Sound volume settings, the
        // same call the settings UI itself uses live (see
        // applyGameVolume()) so a freshly (re)built track always starts at
        // whatever the person last chose instead of momentarily full
        // volume regardless of it.
        applyGameVolume()
        requestAudioFocus()
        audioTrack?.play()
        audioDiagCounter = 0
        Log.d(TAG, "AudioTrack started (bufferBytes=$bufferBytes, minBuf=$minBuf, " +
                "sampleRate=$soundFrequencyHz, lowLatency=${Build.VERSION.SDK_INT >= Build.VERSION_CODES.O})")
    }

    /** Applies [soundEnabled]/[soundVolumePercent] to the live AudioTrack —
     *  called from initAudioTrack() itself (so a freshly built track always
     *  starts right) and directly from the settings UI on every change, for
     *  an immediate live update. Unlike a sample-rate change (see
     *  [audioTrackRebuildPending]'s own comment on why that one has to
     *  defer to the game thread), AudioTrack.setVolume() is explicitly
     *  documented as safe to call at any time from any thread while the
     *  track plays — a lightweight live parameter, not a lifecycle
     *  operation — so this can apply straight from the main thread with no
     *  special handling. */
    private fun applyGameVolume() {
        val gain = if (soundEnabled) soundVolumePercent / 100f else 0f
        try { audioTrack?.setVolume(gain.coerceIn(0f, 1f)) } catch (_: Exception) {}
    }

    /** Recomputes [soundFreqFactor]/[soundFreqAlpha] from [soundFrequencyHz]
     *  and resets the filter's continuous state — called once at startup
     *  (after loading the saved preference) and again whenever Sound
     *  frequency changes in settings, right alongside persisting the new
     *  value. See [applySoundFrequencyFilter] for what these actually
     *  drive. */
    private fun updateSoundFrequencyFactor() {
        soundFreqFactor = (44100 / soundFrequencyHz).coerceAtLeast(1)
        soundFreqAlpha = 2f / (soundFreqFactor + 1)
        soundFreqLpL = 0f
        soundFreqLpR = 0f
    }

    /** See the comment on [audioFocusRequest] for why this exists. */
    private fun requestAudioFocus() {
        val am = audioManager ?: return
        val granted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build())
                .setOnAudioFocusChangeListener(audioFocusListener)
                .build()
            audioFocusRequest = req
            am.requestAudioFocus(req) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        } else {
            @Suppress("DEPRECATION")
            am.requestAudioFocus(
                audioFocusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN
            ) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        }
        Log.d(TAG, "Audio focus granted=$granted")
    }

    private fun abandonAudioFocus() {
        val am = audioManager ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            audioFocusRequest?.let { am.abandonAudioFocusRequest(it) }
            audioFocusRequest = null
        } else {
            @Suppress("DEPRECATION")
            am.abandonAudioFocus(audioFocusListener)
        }
    }

    private fun releaseAudio() {
        try { audioTrack?.stop(); audioTrack?.release() } catch (_: Exception) {}
        audioTrack = null
        abandonAudioFocus()
    }

    /**
     * Blocking write of [count] interleaved stereo PCM pairs from
     * [audioBuffer] to the AudioTrack. Called from the game thread only.
     *
     * Unlike the old WRITE_NON_BLOCKING call (whose return value was
     * discarded), this checks the result:
     *   - a short write (0 < written < requested) retries the remainder —
     *     legitimate under blocking mode only if playback state changed
     *     mid-write (e.g. onPause() firing concurrently), in which case
     *     finishing the write is harmless and cheap.
     *   - ERROR_DEAD_OBJECT means the audio server died/restarted under us
     *     (e.g. mediaserver crash, or another app seized exclusive audio) —
     *     recreate the AudioTrack once and retry, rather than staying silent
     *     for the rest of the session.
     *   - any other negative error code is logged and the frame's audio is
     *     dropped; retrying indefinitely inside the game loop would risk
     *     hanging it.
     *
     * FEATURE (this pass): [applySoundFrequencyFilter] runs first, right
     * here, rather than at each of the game loop's 3 separate
     * nativeReadAudioSamples()/writePcm() call sites — one place applies
     * Sound frequency uniformly to all of them, including composing
     * correctly with decimateForFastForward()'s own output during fast-
     * forward automatically (its result is still 44100Hz-rate audio, same
     * as a normal frame's — see that function's own comment — so it needs
     * exactly the same treatment here, no special case).
     */
    private fun writePcm(count: Int) {
        if (count <= 0) return
        val pairs = applySoundFrequencyFilter(count)
        if (pairs <= 0) return
        val totalShorts = pairs * 2
        var track = audioTrack ?: return
        var offset = 0
        var attempts = 0
        while (offset < totalShorts && attempts < 2) {
            val n = try {
                track.write(audioBuffer, offset, totalShorts - offset, AudioTrack.WRITE_BLOCKING)
            } catch (e: Exception) {
                Log.e(TAG, "AudioTrack.write threw", e); return
            }
            when {
                n > 0 -> offset += n
                n == AudioTrack.ERROR_DEAD_OBJECT -> {
                    Log.w(TAG, "AudioTrack died — reinitializing")
                    initAudioTrack()
                    track = audioTrack ?: return
                    attempts++
                }
                n < 0 -> { Log.e(TAG, "AudioTrack.write error=$n"); return }
                else  -> return // n == 0: track not started / no progress possible right now
            }
        }
        // Lightweight real-device diagnostics: log the underrun counter every
        // ~5s (300 frames @ ~60Hz) rather than every frame, so it's cheap
        // enough to leave in a release build's logcat for field debugging.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            audioDiagCounter++
            if (audioDiagCounter >= 300) {
                audioDiagCounter = 0
                Log.d(TAG, "AudioTrack underrunCount=${audioTrack?.underrunCount}")
            }
        }
    }

    /**
     * Downsamples the first [count] stereo pairs of [audioBuffer] in place
     * to match [soundFrequencyHz] (see showSoundFrequencyDialog()) when
     * it's below the 44100Hz the core always produces, returning the new
     * (possibly smaller) pair count — a no-op returning [count] unchanged
     * at the default 44100Hz ([soundFreqFactor] == 1).
     *
     * Same "textbook" shape as decimateForFastForward() below — a one-pole
     * low-pass ahead of the downsample rather than plain box averaging, for
     * the same anti-aliasing reason — but with its own persistent
     * [soundFreqLpL]/[soundFreqLpR] state instead of resetting fresh every
     * call: decimateForFastForward() only ever runs once per accumulated
     * fast-forward batch, a genuinely fresh block each time, but this runs
     * on every single writePcm() call at normal speed — one real GBA
     * frame's worth of samples, back to back — so resetting the filter
     * every call would reintroduce a small transient at every frame
     * boundary instead of one continuous filter across the whole session.
     *
     * In place is safe here for the same reason it is in
     * decimateForFastForward(): the output index (i / [soundFreqFactor])
     * is never ahead of the input index i it's derived from, so a write
     * never clobbers a sample a later iteration still needs to read.
     *
     * IMPORTANT — why the AudioTrack's own configured rate has to match:
     * writePcm()'s blocking write is the game loop's actual frame pacer
     * (see its own doc comment and startGameLoop()'s) — it blocks until
     * the AudioTrack has room, and that room drains at whatever rate the
     * track is *configured* for (see initAudioTrack()'s own
     * setSampleRate(soundFrequencyHz)). Writing fewer samples at a
     * proportionally lower configured rate keeps the real-world duration
     * those samples represent the same either way, which is exactly what
     * keeps the core paced correctly — get the factor wrong (downsample
     * the data but leave the track at 44100, or vice versa) and the core
     * would end up running at the wrong *speed*, not just sounding wrong.
     * [soundFreqFactor] is always exactly 44100/soundFrequencyHz (1, 2, or
     * 4 — see updateSoundFrequencyFactor()), so this and initAudioTrack()
     * can never disagree.
     */
    private fun applySoundFrequencyFilter(count: Int): Int {
        val factor = soundFreqFactor
        if (factor <= 1) return count
        val outPairs = count / factor
        for (i in 0 until count) {
            soundFreqLpL += soundFreqAlpha * (audioBuffer[i * 2] - soundFreqLpL)
            soundFreqLpR += soundFreqAlpha * (audioBuffer[i * 2 + 1] - soundFreqLpR)
            if (i % factor == factor - 1) {
                val o = i / factor
                if (o < outPairs) {
                    audioBuffer[o * 2] = soundFreqLpL.toInt().coerceIn(-32768, 32767).toShort()
                    audioBuffer[o * 2 + 1] = soundFreqLpR.toInt().coerceIn(-32768, 32767).toShort()
                }
            }
        }
        return outPairs
    }

    /**
     * Fast-forward audio compression. Filters and downsamples [accumPairs]
     * stereo pairs in [ffAccumBuffer] (collected across [factor] emulated
     * sub-frames — see the game loop in startGameLoop) down into
     * `audioBuffer`, roughly [factor]x shorter, and returns how many pairs
     * it wrote there. Playing the shorter result back at the normal
     * 44.1kHz rate is what produces the audible pitch-up — expected,
     * inherent to speeding up audio this way, the same "chipmunk" effect
     * any sped-up tape/tune has, not something this function tries to
     * hide.
     *
     * FIX (this pass): reported as sounding "weird" during fast-forward —
     * on top of that expected pitch-up, there was a second, avoidable
     * problem. This used to be plain box-filter decimation (each output
     * pair the equal-weighted mean of one block of [factor] consecutive
     * input pairs), which the original version's own doc comment already
     * called "a cheap stand-in for a proper low-pass filter ahead of the
     * downsample." That stand-in has real weaknesses as an anti-aliasing
     * filter — weak stopband rejection lets high-frequency content fold
     * back down as audible harshness/grain on top of the pitch-up, and its
     * passband isn't flat either, adding a muffled quality. Replaced with
     * the textbook-standard shape instead — filter, then downsample,
     * rather than trying to make the averaging do both jobs at once: a
     * one-pole low-pass runs continuously across the whole accumulated
     * block first (cheap, one multiply-add per sample, so no heavier on
     * this thread than the box average it replaces), then every [factor]th
     * *filtered* sample is kept. alpha follows the standard
     * period-to-EMA-smoothing conversion (2/(period+1)) so the filter's
     * cutoff scales down as [factor] grows, same direction the box
     * average's own implicit cutoff moved, just with a real filter shape
     * behind it instead of a rectangular window's.
     */
    private fun decimateForFastForward(accumPairs: Int, factor: Int): Int {
        if (factor <= 1) {
            val n = accumPairs.coerceAtMost(audioBuffer.size / 2)
            System.arraycopy(ffAccumBuffer, 0, audioBuffer, 0, n * 2)
            return n
        }
        val outPairs = (accumPairs / factor).coerceAtMost(audioBuffer.size / 2)
        val alpha = 2f / (factor + 1)
        var lpL = ffAccumBuffer[0].toFloat()
        var lpR = ffAccumBuffer[1].toFloat()
        var out = 0
        for (i in 0 until accumPairs) {
            lpL += alpha * (ffAccumBuffer[i * 2]     - lpL)
            lpR += alpha * (ffAccumBuffer[i * 2 + 1] - lpR)
            if (out < outPairs && i % factor == factor - 1) {
                audioBuffer[out * 2]     = lpL.toInt().coerceIn(-32768, 32767).toShort()
                audioBuffer[out * 2 + 1] = lpR.toInt().coerceIn(-32768, 32767).toShort()
                out++
            }
        }
        return outPairs
    }

    // ── Surface ────────────────────────────────────────────────────────────

    override fun surfaceCreated(holder: SurfaceHolder)                          { surfaceHolder = holder }
    override fun surfaceDestroyed(holder: SurfaceHolder)                        { stopGameLoop(); surfaceHolder = null }
    override fun surfaceChanged(holder: SurfaceHolder, fmt: Int, w: Int, h: Int) {
        surfaceHolder = holder
        buildControlLayout(w.toFloat(), h.toFloat())   // also calls updateGameMatrix() internally now
        if (romLoaded && !running) startGameLoop()
        // BUG FIX: this fires on every resize — a user-triggered orientation
        // change (see applyScreenOrientationPref()), entering/exiting
        // split-screen, etc. A SurfaceView's buffer doesn't repaint itself
        // just because it changed size — whatever pixels were already in it
        // stay there, stretched/cropped to the new dimensions, until
        // something actually draws again. Without this, that could briefly
        // be a stretched copy of the last black-cleared frame (harmless) or,
        // in some resize orderings, genuinely undefined content — either
        // way, repainting black immediately at the new size is cheap and
        // removes any doubt.
        else clearSurfaceToBlack()
    }

    // ── Game loop ──────────────────────────────────────────────────────────

    private fun startGameLoop() {
        if (running) return
        val bufs = frameBuffers ?: return
        val holder = surfaceHolder ?: return
        val sw = holder.surfaceFrame.width().toFloat()
        val sh = holder.surfaceFrame.height().toFloat()
        if (sw > 0f && sh > 0f) buildControlLayout(sw, sh)   // also calls updateGameMatrix() internally now
        try { audioTrack?.play() } catch (_: Exception) {}
        running = true
        ffFrameAccumulator = 0.0
        consecutiveFrameSkips = 0
        lastComputeNs = 0L
        fpsFrameCount = 0
        fpsWindowStartNs = 0L
        startRenderLoop()
        gameThread = Thread {
            while (running) {
                try {
                    // FEATURE (this pass): Sound frequency changed in
                    // settings while this loop was already running — see
                    // audioTrackRebuildPending's own field comment for why
                    // the actual rebuild has to happen here, on this
                    // thread, rather than immediately from the settings UI
                    // itself. Checked before t0 below so a rebuild's own
                    // (one-off) cost is never counted against
                    // lastComputeNs's "are we behind" measurement.
                    if (audioTrackRebuildPending) initAudioTrack()
                    val t0 = System.nanoTime()
                    // FEATURE: maybeSkipRenderThisFrame's "are we behind"
                    // signal. Compares the *previous* iteration's own
                    // compute-only duration (lastComputeNs — see that
                    // field's own comment for why total wall-clock time
                    // was the wrong thing to measure) against one frame's
                    // budget: only genuine device slowness trips this now,
                    // not the pacer's own intentional wait. The skip
                    // decision itself only ever applies to the
                    // framesToRun == 1 branch below — fast-forward already
                    // has its own, unrelated skip-blit logic for every
                    // sub-frame but the batch's last.
                    val behindSchedule = lastComputeNs > frameBudgetNs
                    val speed = if (fastForwardActive) fastForwardSpeed else 1f

                    val framesToRun: Int
                    if (fastForwardActive) {
                        ffFrameAccumulator += speed
                        framesToRun = ffFrameAccumulator.toInt().coerceAtLeast(1)
                        ffFrameAccumulator -= framesToRun
                    } else {
                        framesToRun = 1
                        ffFrameAccumulator = 0.0
                    }

                    EmulatorEngine.nativeSetKeys(effectiveKeysForCore())
                    var wroteAudio = false
                    // FIX (this pass): reported as flickering / flashing white
                    // screen once Max frame skips was actually turned on.
                    // Root cause: a skipped frame was still going through the
                    // *publish* step below unconditionally — readyIdx claimed
                    // whatever buffer writeIdx pointed at even though
                    // nativeRunFrame(null) never wrote a single pixel into it
                    // this iteration. Early on, or after several skips in a
                    // row, that buffer can be one none of the 3 have ever
                    // actually been rendered into yet — publishing it hands
                    // the Choreographer renderer genuinely uninitialized
                    // bitmap contents to draw, which is exactly a "flash of
                    // garbage" (often reading as white). Fast-forward's own
                    // sub-frame skipping never had this problem — every
                    // batch's *last* sub-frame still always writes real
                    // pixels into backBmp before the one publish at the end —
                    // only this pass's new normal-speed skip path shared the
                    // unconditional publish without sharing that guarantee.
                    // Fixed by moving the publish inside the "a real render
                    // actually happened" branch: a skipped frame now claims
                    // no buffer and changes nothing about readyIdx/displayIdx
                    // at all, so the renderer just keeps showing whatever it
                    // was already showing — the correct, safe meaning of
                    // "skip this frame's visual update."
                    val skipBlit = framesToRun == 1 && maxFrameSkips > 0 &&
                        behindSchedule && consecutiveFrameSkips < maxFrameSkips
                    if (skipBlit) {
                        EmulatorEngine.nativeRunFrame(null)
                        consecutiveFrameSkips++
                        val n = EmulatorEngine.nativeReadAudioSamples(audioBuffer, audioBuffer.size / 2)
                        // FIX (this pass): captured here — after the actual
                        // work, before the blocking write below — so the
                        // *next* iteration's behindSchedule check reflects
                        // real compute time, not the pacer's wait. See
                        // lastComputeNs's own field comment.
                        lastComputeNs = System.nanoTime() - t0
                        if (n > 0) { writePcm(n); wroteAudio = true }   // blocking — this *is* the frame pacer now, deliberately timed outside lastComputeNs
                    } else {
                        consecutiveFrameSkips = 0
                        // Sub-frames of a fast-forward batch all render into
                        // the same back buffer — only the last one ends up on
                        // screen, same as before; only the publish step below
                        // is new.
                        val backBmp = bufs[writeIdx]
                        if (framesToRun == 1) {
                            EmulatorEngine.nativeRunFrame(backBmp)
                            val n = EmulatorEngine.nativeReadAudioSamples(audioBuffer, audioBuffer.size / 2)
                            lastComputeNs = System.nanoTime() - t0   // see the FIX note in the skipBlit branch above
                            if (n > 0) { writePcm(n); wroteAudio = true }   // blocking — this *is* the frame pacer now, deliberately timed outside lastComputeNs
                        } else {
                            // Fast-forward batch: run every sub-frame, collecting
                            // each one's audio into ffAccumBuffer instead of
                            // discarding it, then compress the whole batch down
                            // to about one frame's worth (decimateForFastForward)
                            // so it can go through the same blocking writePcm()
                            // pacer below — see the audio-architecture note above.
                            var accumPairs = 0
                            for (i in 0 until framesToRun) {
                                // PERF: only the LAST sub-frame in the batch is
                                // ever displayed (see the buffer-publish step
                                // below), so earlier ones pass null and skip the
                                // pixel-copy blit entirely — see FIX 5 in
                                // mgba_jni.c. Emulation and audio still run in
                                // full for every sub-frame.
                                val bmpForThisSubFrame = if (i == framesToRun - 1) backBmp else null
                                EmulatorEngine.nativeRunFrame(bmpForThisSubFrame)
                                val n = EmulatorEngine.nativeReadAudioSamples(audioBuffer, audioBuffer.size / 2)
                                if (n > 0 && accumPairs + n <= ffAccumBuffer.size / 2) {
                                    System.arraycopy(audioBuffer, 0, ffAccumBuffer, accumPairs * 2, n * 2)
                                    accumPairs += n
                                }
                            }
                            // Skip-decision timing normally doesn't apply
                            // here (skipBlit only ever gates framesToRun ==
                            // 1, never a fast-forward batch — see
                            // behindSchedule's own comment above), but
                            // lastComputeNs is still refreshed on this
                            // branch too so it isn't a stale pre-fast-
                            // forward reading the instant fast-forward ends
                            // and framesToRun == 1 resumes next iteration.
                            lastComputeNs = System.nanoTime() - t0
                            if (accumPairs > 0) {
                                val outPairs = decimateForFastForward(accumPairs, framesToRun)
                                if (outPairs > 0) { writePcm(outPairs); wroteAudio = true }
                            }
                        }

                        // Publish the completed frame for the Choreographer
                        // renderer (see the field comments above) and claim
                        // whichever of the 3 buffers is free for next time —
                        // never the one just published or the one the renderer
                        // may currently be drawing. Only ever reached here, on
                        // the branch that actually wrote real pixels into
                        // backBmp — see the FIX note above.
                        synchronized(bufferLock) {
                            readyIdx = writeIdx
                            writeIdx = (0..2).first { it != readyIdx && it != displayIdx }
                        }
                    }

                    if (showFpsOverlay) {
                        // FEATURE: performance overlay — counts every emulated
                        // GBA frame, so a 4x fast-forward batch counts as 4,
                        // matching the "core FPS" figure emulators
                        // conventionally show. Gated behind the toggle so
                        // there is no counting work at all on this thread —
                        // the one pacing audio — when the overlay is off.
                        if (fpsWindowStartNs == 0L) fpsWindowStartNs = t0
                        fpsFrameCount += framesToRun
                        val windowNs = t0 - fpsWindowStartNs
                        if (windowNs >= 1_000_000_000L) {
                            val fps = fpsFrameCount * 1_000_000_000.0 / windowNs
                            val underruns = try { audioTrack?.underrunCount ?: 0 } catch (_: Exception) { 0 }
                            fpsOverlayText = "%.1f fps  ·  %d underruns".format(fps, underruns)
                            fpsFrameCount = 0
                            fpsWindowStartNs = t0
                        }
                    }

                    if (!wroteAudio) {
                        // Fallback pacer for the rare batch that produced no audio
                        // (e.g. immediately after a ROM loads, before blip_buf has
                        // accumulated a full sample, or if this device has no usable
                        // AudioTrack at all). Uses the real GBA frame period, scaled
                        // down by `speed` during FF so this edge case doesn't stall
                        // fast-forward back to real-time.
                        val elapsed = System.nanoTime() - t0
                        val fallbackNs = (FALLBACK_FRAME_NS / speed).toLong()
                        val sleepMs = (fallbackNs - elapsed) / 1_000_000L
                        if (sleepMs > 0L) Thread.sleep(sleepMs)
                    }
                    // Normal case: writePcm() above already blocked until the
                    // audio HAL had room for this batch's samples, which paces
                    // the loop against the real device audio clock — no
                    // Thread.sleep() needed and no drift accumulates, whether
                    // this iteration ran one GBA frame or a fast-forward batch
                    // of them. Rendering is no longer on this thread at all, so
                    // a slow frame draw can no longer delay the next audio write.
                } catch (_: InterruptedException) { break }
                catch (e: Throwable) { Log.e(TAG, "Loop error", e); uiToast("Error: ${e.message}"); break }
            }
            running = false
        }.also { it.name = "mGBA-loop"; it.start() }
    }

    private fun stopGameLoop() {
        running = false
        // 750ms rather than 500ms: the game thread may be inside a blocking
        // AudioTrack.write() call (see writePcm()). Android unblocks a
        // pending write when the track's play state changes from another
        // thread, so this should return almost immediately in practice —
        // the extra margin only matters on a slow/unusual audio HAL.
        gameThread?.join(750)
        gameThread = null
        stopRenderLoop()
    }

    private fun renderFrame(bmp: Bitmap) {
        val holder = surfaceHolder ?: return
        // PERF: lockHardwareCanvas() (API 23+, always available at our
        // minSdk 24) hands back a GPU-composited canvas instead of the plain
        // software Skia canvas lockCanvas() gives — the scaled drawBitmap()
        // plus the dozen-odd drawRoundRect/drawText calls for the on-screen
        // controls get composited on the GPU instead of the CPU every frame.
        // Falls back to a software canvas automatically on devices/drivers
        // that don't support it, so this is a strict upside with no
        // compatibility risk. Every draw call below (drawColor, drawBitmap
        // with a Matrix, drawRoundRect, drawText, drawCircle) is a basic op
        // fully supported under hardware acceleration — nothing here relies
        // on a software-only Xfermode/PathEffect/Shader.
        val canvas: Canvas = try { holder.lockHardwareCanvas() ?: return } catch (_: Exception) { return }
        try {
            canvas.drawColor(Color.BLACK)
            canvas.drawBitmap(bmp, gameMatrix, gamePaint)
            drawControls(canvas)
            if (editModeActive) drawEditOverlay(canvas)
            if (link.isConnected) drawLinkStatus(canvas)
            if (showFpsOverlay) drawFpsOverlay(canvas)
        } finally { try { holder.unlockCanvasAndPost(canvas) } catch (_: Exception) {} }
    }

    /** Paints one solid black frame straight onto the SurfaceView, bypassing
     *  the triple-buffered game frames entirely. A SurfaceView keeps showing
     *  whatever it last drew until something draws over it again — so
     *  without this, closing a game (closeGame()) left its last emulated
     *  frame sitting on screen (behind/around whatever comes up next) until
     *  a new ROM loaded and rendered its own first frame. Safe to call
     *  right after stopGameLoop(): that join()s the game thread and flips
     *  the @Volatile renderLoopActive flag synchronously before returning,
     *  and renderFrame() is only ever reached through that flag (see
     *  renderCallback.doFrame), so nothing can race this with another draw.
     *
     *  BUG FIX (real crash, confirmed via two matching device crash logs —
     *  see BUGS_FIXED.md): this used to call the plain software
     *  holder.lockCanvas() instead of lockHardwareCanvas(). Two different
     *  APIs backed by two different rendering paths on the SAME
     *  SurfaceHolder — renderFrame() below has always used the hardware one
     *  (see its own PERF comment) — and switching a Surface between a
     *  software Skia canvas and a hardware GL/Skia-on-GL canvas across
     *  calls is a known way to leave the EGL/GL surface binding in a broken
     *  state on some devices/drivers. That matches the reported crash
     *  precisely: SIGABRT on Android's own RenderThread, "drawRenderNode
     *  called on a context with no surface!", every time, right after a ROM
     *  finishes loading — exactly the point where this function (called
     *  from surfaceChanged()/closeGame() while browsing ROMs) hands off to
     *  renderFrame()'s hardware-locked rendering for the first time in the
     *  session. Now locks the same way renderFrame() does, so this
     *  SurfaceHolder is never touched through two different rendering
     *  backends. No manual fallback to the software lock if this returns
     *  null — matching renderFrame()'s own handling (see its comment): on a
     *  device where hardware locking genuinely isn't available, skipping
     *  one black-clear is harmless, where falling back to software would
     *  reintroduce the exact mismatch this fix removes. */
    private fun clearSurfaceToBlack() {
        val holder = surfaceHolder ?: return
        val canvas: Canvas = try { holder.lockHardwareCanvas() ?: return } catch (_: Exception) { return }
        try { canvas.drawColor(Color.BLACK) } finally { try { holder.unlockCanvasAndPost(canvas) } catch (_: Exception) {} }
    }

    // ── Game matrix ────────────────────────────────────────────────────────

    /** BUG FIX (this pass — see CHANGELOG.md/BUGS_FIXED.md for the full
     *  report): the previous version of this function built the editable
     *  "gamescreen" box as `resolvedRect("gamescreen", ..., w = sw, h =
     *  defaultH)` — FULL SCREEN WIDTH by a fraction of the height, an area
     *  that does NOT match the GBA's 3:2 image aspect ratio at all. Since
     *  the non-stretch branch then aspect-fit the actual bitmap *inside*
     *  that oversized area (see the old minOf() call), the box the editor
     *  let you drag/resize was mostly dead pillarboxed space — resizing
     *  "Game Screen Size" was really resizing a big mostly-empty rectangle
     *  that the small visible image sat somewhere inside of, which is
     *  exactly what read as "resizing enlarges a black area/container
     *  instead of just the image" in the report.
     *
     *  Root-cause fix, not a workaround: the box's DEFAULT geometry is now
     *  itself aspect-correct (matches the live framebuffer's own w:h), so
     *  the editable box IS the image with no baked-in margin. scale (one
     *  uniform float — see LayoutEntry) then grows/shrinks both dimensions
     *  together from that correct baseline, so "Game Screen Size" really
     *  can only ever resize the actual picture. clampRectToScreen() below
     *  additionally caps the box to the screen's own bounds, so no
     *  amount of resizing can push it past the edges of the display
     *  ("enlarge the entire emulator container").
     *
     *  controlsTop/padH (buildControlLayout, unchanged by this pass) were
     *  already computed from gameScreenFraction directly, never from this
     *  box's own current size — so every button's position is completely
     *  unaffected by any of this, in either direction. Resizing the game
     *  screen bigger/smaller never moves them, and the reverse is also
     *  still true. (This comment used to also mention a dark control-strip
     *  background drawn from controlsTop down — colorControlsBg — which
     *  the Fortieth pass removed entirely; see drawControls()'s own note.)
     *
     *  Stretch to Fit is a distinct, fixed mode rather than a different fit
     *  computed over the *same* customizable box: when on, the box is
     *  pinned to exactly (0, 0, sw, sh) — the *entire* screen, both
     *  dimensions — independent of any saved "gamescreen" customLayout
     *  entry, and the bitmap is scaled non-uniformly to fill that exactly
     *  (distorting the 3:2 aspect on purpose — that's what "stretch"
     *  means; unchanged from before).
     *
     *  FIX (this pass — direct report: "if i on stretch to fit screen it
     *  only stretch left to right not at the bottom", further clarified as
     *  "if the half screen is design choice just remove it it's not really
     *  useful because i move button at the top of the screen then i
     *  customize my button"): used to pin the box to (0, 0, sw, availH)
     *  instead — sw the full width, but availH only the reserved area
     *  *above* the control dock (gameScreenFraction, ~52% of sh by
     *  default) — so the image stretched edge-to-edge horizontally but
     *  always stopped partway down, leaving a dead black strip underneath
     *  it no matter how "stretched" the setting claimed to be. That
     *  reservation still means something for buildControlLayout's own
     *  controlsTop/padH — completely untouched by this fix — since that's
     *  still where every button *defaults* to before anyone drags it
     *  anywhere else. It never meant anything for the image itself, and
     *  even less so now that a customized layout already lets every
     *  control float freely to wherever it's dragged, edit mode included,
     *  rather than staying docked below a reserved line. hitTestEditable()
     *  below still skips "gamescreen" entirely while this is on — filling
     *  the screen is the whole point of the mode, so there's nothing left
     *  to usefully drag or resize until it's turned back off. */
    private fun updateGameMatrix(sw: Float, sh: Float) {
        val bmp = frameBuffers?.get(0) ?: return
        gameMatrix.reset()
        if (stretchToFit) {
            gameScreenRect = RectF(0f, 0f, sw, sh)
            gameMatrix.postScale(sw / bmp.width, sh / bmp.height)
        } else {
            // Reserved height above the control dock — see controlsTop.
            // Only the non-stretch default box below still anchors to
            // this; Stretch to Fit itself (above) fills the full screen.
            val availH = sh * gameScreenFraction
            val bmpAspect = bmp.width.toFloat() / bmp.height.toFloat()
            var defaultH = availH
            var defaultW = defaultH * bmpAspect
            if (defaultW > sw) { defaultW = sw; defaultH = sw / bmpAspect }
            val raw = resolvedRect("gamescreen", sw / 2f, defaultH / 2f, defaultW, defaultH)
            gameScreenRect = clampRectToScreen(raw, sw, sh)
            val areaW = gameScreenRect.width()
            val areaH = gameScreenRect.height()
            // Box is already aspect-correct, so this scale is effectively
            // the same for both dimensions — minOf() stays only as a
            // rounding-safe guard, not a real letterbox/pillarbox source.
            val scale = minOf(areaW / bmp.width, areaH / bmp.height)
            gameMatrix.postScale(scale, scale)
            gameMatrix.postTranslate(
                gameScreenRect.left + (areaW - bmp.width  * scale) / 2f,
                gameScreenRect.top  + (areaH - bmp.height * scale) / 2f
            )
        }
    }

    /** Shrinks [rect] to fit within a 0,0..sw,sh screen if it doesn't
     *  already, re-centering it within bounds afterward — the actual
     *  guardrail behind "resizing the game screen can't enlarge the whole
     *  container past the screen's own edges". Only ever needed at the
     *  extreme end of the resize range (8.0x — see setSelectedScalePercent's
     *  own cap); a no-op RectF unchanged for every normal size. */
    private fun clampRectToScreen(rect: RectF, sw: Float, sh: Float): RectF {
        val w = rect.width().coerceAtMost(sw.coerceAtLeast(1f))
        val h = rect.height().coerceAtMost(sh.coerceAtLeast(1f))
        val left = (rect.centerX() - w / 2f).coerceIn(0f, (sw - w).coerceAtLeast(0f))
        val top  = (rect.centerY() - h / 2f).coerceIn(0f, (sh - h).coerceAtLeast(0f))
        return RectF(left, top, left + w, top + h)
    }

    /** Keeps a [size]-long box, positioned at [pos] along one axis, fully
     *  within [0, screenSize] with [margin] of breathing room from either
     *  edge — used by refreshEditToolbarPosition() for both its x and y,
     *  so the two axes share one clamp instead of two independently
     *  hand-rolled `coerceIn()` calls that could quietly drift apart from
     *  each other over some future edit. Distinct from clampRectToScreen()
     *  just above: that one is a zero-margin flush-to-edge clamp (right for
     *  the resizable game screen, which should be allowed to touch the
     *  edges); this one is for UI chrome like the editor popup, which
     *  shouldn't — see the companion object's EDIT_TOOLBAR_SCREEN_MARGIN_DP
     *  for why that margin needs to be a real dp value. Only falls back to
     *  a bare on-screen clamp (no margin) if [size] itself leaves less than
     *  2×[margin] of room — the popup must never be pushed off-screen just
     *  because there wasn't space to also give it a comfortable gap. */
    private fun clampToScreenAxis(pos: Float, size: Float, screenSize: Float, margin: Float): Float {
        val maxPos = (screenSize - size - margin).coerceAtLeast(margin)
        return pos.coerceIn(margin, maxPos)
    }

    // ── Controls layout ────────────────────────────────────────────────────

    /**
     * Builds the on-screen button rects.
     * buttonScaleMultiplier (0.75 / 1.0 / 1.25) scales all button sizes.
     * gameScreenFraction controls where the controls strip begins — the
     * game screen's own actual rendered size can now be independently
     * dragged/resized past this (see gameScreenRect/updateGameMatrix()),
     * but this is still what determines where controls sit.
     */
    // ── Layout persistence ───────────────────────────────────────────────────

    private fun orientationTag(): String =
        if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) "land" else "port"

    private fun loadCustomLayout() {
        customLayout.clear()
        removedButtons.clear()
        addedExtraButtons.clear()
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val raw = prefs.getString(PREF_LAYOUT_PREFIX + orientationTag(), null)
        if (raw != null) {
            try {
                val arr = JSONArray(raw)
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    customLayout[o.getString("id")] = LayoutEntry(
                        xFrac = o.getDouble("x").toFloat(),
                        yFrac = o.getDouble("y").toFloat(),
                        scale = o.optDouble("scale", 1.0).toFloat(),
                        alphaOverride = o.optInt("alpha", -1),
                        locked = o.optBoolean("locked", false)
                    )
                }
            } catch (e: Exception) {
                Log.e(TAG, "Corrupt saved layout, ignoring", e)
            }
        }
        // ADD/REMOVE CONTROL — see the removedButtons field comment.
        val rawRemoved = prefs.getString(PREF_REMOVED_PREFIX + orientationTag(), null)
        if (rawRemoved != null) {
            try {
                val arr = JSONArray(rawRemoved)
                for (i in 0 until arr.length()) removedButtons.add(arr.getString(i))
            } catch (e: Exception) {
                Log.e(TAG, "Corrupt removed-controls list, ignoring", e)
            }
        }
        // Extra (opt-in) controls — see the addedExtraButtons field comment.
        val rawExtras = prefs.getString(PREF_EXTRAS_PREFIX + orientationTag(), null)
        if (rawExtras != null) {
            try {
                val arr = JSONArray(rawExtras)
                for (i in 0 until arr.length()) addedExtraButtons.add(arr.getString(i))
            } catch (e: Exception) {
                Log.e(TAG, "Corrupt extra-controls list, ignoring", e)
            }
        }
    }

    private fun saveCustomLayout() {
        try {
            val arr = JSONArray()
            for ((id, e) in customLayout) {
                arr.put(JSONObject().apply {
                    put("id", id); put("x", e.xFrac.toDouble()); put("y", e.yFrac.toDouble())
                    put("scale", e.scale.toDouble()); put("alpha", e.alphaOverride); put("locked", e.locked)
                })
            }
            val removedArr = JSONArray().apply { removedButtons.forEach { put(it) } }
            val extrasArr = JSONArray().apply { addedExtraButtons.forEach { put(it) } }
            getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString(PREF_LAYOUT_PREFIX + orientationTag(), arr.toString())
                .putString(PREF_REMOVED_PREFIX + orientationTag(), removedArr.toString())
                .putString(PREF_EXTRAS_PREFIX + orientationTag(), extrasArr.toString())
                .apply()
            exportLayoutBackup()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to save layout", e)
            uiToast("Couldn't save layout")
        }
        editDirty = false
    }

    /** Mirrors the layout SharedPreferences data saveCustomLayout() just
     *  wrote out to a plain JSON file in the automatic own-folder mirror —
     *  see the FEATURE block above dataFolderTree(). Both orientation
     *  profiles ("land" and "port"), not just whichever one's active right
     *  now, so a restore later doesn't depend on which orientation happened
     *  to be live when the backup was taken. Steps aside once a Storage
     *  folder is configured, same as mirrorToAutoFolder() — see
     *  autoFolderMirrorActive()'s own doc comment for why. Never throws:
     *  same "must never fail the real save" discipline as every other
     *  mirror in this feature — SharedPreferences is already the save at
     *  this point, this is purely an extra copy on top of it. */
    private fun exportLayoutBackup() {
        if (!autoFolderMirrorActive()) return
        val dir = autoMirrorSubdir("Layout") ?: return
        try {
            val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val out = JSONObject()
            for (tag in ORIENTATION_TAGS) {
                val entry = JSONObject()
                prefs.getString(PREF_LAYOUT_PREFIX + tag, null)?.let { entry.put("layout", JSONArray(it)) }
                prefs.getString(PREF_REMOVED_PREFIX + tag, null)?.let { entry.put("removed", JSONArray(it)) }
                prefs.getString(PREF_EXTRAS_PREFIX + tag, null)?.let { entry.put("extras", JSONArray(it)) }
                out.put(tag, entry)
            }
            File(dir, "controls_backup.json").writeText(out.toString(2))
        } catch (e: Exception) {
            Log.w(TAG, "exportLayoutBackup() failed", e)
        }
    }

    /** Restores the file exportLayoutBackup() above writes, but ONLY when
     *  SharedPreferences has genuinely never seen a saved layout for EITHER
     *  orientation profile — this pass's direct report ("if i clear cache my
     *  button reset") is exactly that: the live copy is gone from wherever
     *  it was cleared, but a copy in the automatic own-folder mirror
     *  survived, since that's outside this app's own storage entirely (see
     *  the FEATURE block above dataFolderTree()). Never overwrites a layout
     *  that's actually in use: if a save has ever landed in SharedPreferences
     *  for either orientation, however long ago, this does nothing at all —
     *  a stale backup restoring over live, current settings would be a worse
     *  bug than the one this fixes. Called once, from onCreate(), before
     *  loadCustomLayout() reads SharedPreferences as normal — this only
     *  ever pre-fills that read, loadCustomLayout() itself needs no changes. */
    private fun importLayoutBackupIfNeeded() {
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val alreadyHasLayout = ORIENTATION_TAGS.any {
            prefs.contains(PREF_LAYOUT_PREFIX + it) ||
            prefs.contains(PREF_REMOVED_PREFIX + it) ||
            prefs.contains(PREF_EXTRAS_PREFIX + it)
        }
        if (alreadyHasLayout) return
        val dir = autoMirrorSubdir("Layout") ?: return
        val file = File(dir, "controls_backup.json")
        if (!file.exists()) return
        try {
            val root = JSONObject(file.readText())
            val editor = prefs.edit()
            var restoredAny = false
            for (tag in ORIENTATION_TAGS) {
                val entry = root.optJSONObject(tag) ?: continue
                entry.optJSONArray("layout")?.let { editor.putString(PREF_LAYOUT_PREFIX + tag, it.toString()); restoredAny = true }
                entry.optJSONArray("removed")?.let { editor.putString(PREF_REMOVED_PREFIX + tag, it.toString()); restoredAny = true }
                entry.optJSONArray("extras")?.let { editor.putString(PREF_EXTRAS_PREFIX + tag, it.toString()); restoredAny = true }
            }
            if (restoredAny) {
                editor.apply()
                Log.i(TAG, "Restored control layout from the automatic own-folder backup")
            }
        } catch (e: Exception) {
            Log.w(TAG, "importLayoutBackupIfNeeded() failed", e)
        }
    }

    /** Computes the on-screen rect for [id] given its DEFAULT center/size,
     *  applying any saved/in-progress override. Always records the default
     *  geometry so "reset this button" and a brand-new drag both have a
     *  known baseline to work from, even if a saved override already exists. */
    private fun resolvedRect(id: String, cx: Float, cy: Float, w: Float, h: Float): RectF {
        defaultGeometry[id] = Geometry(cx, cy, w, h)
        val ov = customLayout[id]
        val fcx = if (ov != null) ov.xFrac * lastSw else cx
        val fcy = if (ov != null) ov.yFrac * lastSh else cy
        val scale = ov?.scale ?: 1f
        val fw = (w * scale).coerceAtLeast(1f)
        val fh = (h * scale).coerceAtLeast(1f)
        return RectF(fcx - fw / 2f, fcy - fh / 2f, fcx + fw / 2f, fcy + fh / 2f)
    }

    // Scratch list buildControlLayout() appends into via addButton(); only
    // ever touched from the UI thread, then published atomically to
    // `buttons` in one assignment at the end of buildControlLayout().
    private var buildingButtons = mutableListOf<ButtonDef>()

    private fun addButton(id: String, cx: Float, cy: Float, w: Float, h: Float, mask: Int, label: String, color: Int, isDpad: Boolean = false) {
        // Always resolve — and so record defaultGeometry — even if [id] is
        // currently hidden, so "+ Add control" (showAddControlMenu) has a
        // sane default position/size to bring it back at rather than
        // whatever stale geometry happened to be lying around.
        val rect = resolvedRect(id, cx, cy, w, h)
        if (!isButtonVisible(id)) return   // ADD/REMOVE CONTROL — hidden, skip drawing/hit-testing
        buildingButtons += ButtonDef(id, rect, mask, label, color, isDpad)
    }

    // ── Control layout (positions/sizes) ────────────────────────────────────
    //
    // CONTROL EDITOR (feature #2): every button below is now addressable by a
    // stable id and routed through resolvedRect()/addButton(), which checks
    // customLayout for a saved override before falling back to the default
    // formula. The formulas themselves are UNCHANGED from the original
    // design — they're still exactly what you get on a fresh install or
    // after "Reset all" — only the indirection through an override is new.
    private fun buildControlLayout(sw: Float, sh: Float) {
        buildingButtons = mutableListOf()
        lastSw = sw; lastSh = sh
        controlsTop = sh * gameScreenFraction
        val padH = sh - controlsTop

        // Apply scale multiplier to all button sizes
        val s      = buttonScaleMultiplier
        val btnSz  = minOf(padH * 0.24f, sw * 0.084f) * s
        val abSz   = btnSz * 0.94f
        outlineStrokeW = (minOf(sw, sh) * 0.006f).coerceIn(3f, 7f)

        // ── D-pad (left side) ────────────────────────────────────────────
        // FEATURE: unified into ONE control (id "dpad") instead of four
        // separate up/down/left/right hitboxes. Two problems that fixes:
        //  1. Editor UX — previously you had to drag/resize 4 buttons
        //     individually to reshape the d-pad, easy to knock out of
        //     alignment. Now it's one object, exactly like My Boy!'s pad.
        //  2. Diagonals — the old 4 separate rects had gaps between them
        //     (arranged in a cross with `step` spacing), so touching between
        //     e.g. up and right hit NEITHER hitbox — diagonal input was
        //     physically impossible. The unified pad hit-tests by angle
        //     (see dpadKeysFor()) so diagonals work like a real d-pad.
        val dpCx = sw * 0.18f
        val dpCy = controlsTop + padH * 0.52f
        val dpadSize = btnSz * 3.0f
        addButton("dpad", dpCx, dpCy, dpadSize, dpadSize, 0, "", colorAccentLight, isDpad = true)

        // ── A / B (right side) ────────────────────────────────────────────
        // OUTLINE SKIN: back to the same light/neutral accent as every other
        // button. The red outline read as a "turbo/rapid-fire" A/B variant
        // (that's the usual convention in emulator skins) rather than the
        // normal buttons, so A/B now match D-pad / L / R / Select / Start.
        val abCx  = sw * 0.82f
        val abCy  = controlsTop + padH * 0.52f
        val abGap = abSz * 1.2f
        addButton("a", abCx+abGap, abCy, abSz, abSz, EmulatorEngine.KEY_A, "A", colorAccentLight)
        addButton("b", abCx-abGap, abCy, abSz, abSz, EmulatorEngine.KEY_B, "B", colorAccentLight)

        // ── Turbo A / Turbo B (small red satellites, optional) ─────────────
        // FEATURE (this pass): moved from a single all-or-nothing Settings
        // checkbox (added both together, no way to get just one or to
        // reposition them independently) to the same opt-in-per-button
        // system as every other extra control — see extraControlIds above.
        // No "if" here any more: addButton() already checks
        // isButtonVisible() internally and only actually adds anything
        // tappable when the id's been added via "+ Add control", same as
        // "abturbo"/"ab"/etc. just above and below this block — these two
        // just weren't following that same pattern until now.
        //
        // Label changed from "T" to "A"/"B": "T" was identical on both
        // buttons, so there was no way to tell Turbo A from Turbo B by
        // looking at them — matches "abturbo"'s own convention instead
        // (reuses the equivalent normal button's letter, red color is what
        // signals "this one's the turbo version").
        //
        // keyMask is 0 here on purpose — they must NOT get OR'd straight
        // into currentKeys like a normal button (that'd just be a
        // continuous hold, not rapid-fire). Their held state is tracked
        // separately (turboAHeld/turboBHeld, set in updateGameKeys()) and
        // turned into an actual on/off square wave only at the point it's
        // sent to the core — see nativeSetKeys() call in startGameLoop().
        // BUG FIX (pass 43 — direct report: "turbo a and b not the same
        // size as normal a and b"): tSz was abSz * 0.75f — a fixed 75%
        // shrink baked into the DEFAULT size, applied underneath (before)
        // each button's own independent Control Size slider, not instead
        // of it. That meant Turbo A/B looked smaller than A/B even at
        // matching slider percentages — both set to the same 100% still
        // rendered two different sizes, since 100% of a smaller base is
        // still smaller. Turbo A/B keep their own independent
        // position/scale entries — still draggable/resizable separately
        // from A/B, same as before — only the DEFAULT size this scales
        // from now matches A/B's, so the same number on both sliders
        // actually means the same size on screen.
        val tSz = abSz
        val tOffX = abSz * 0.75f
        val tOffY = abSz * 0.95f
        addButton("ta", abCx+abGap+tOffX, abCy-tOffY, tSz, tSz, 0, "A", colorAccentRed)
        addButton("tb", abCx-abGap-tOffX, abCy-tOffY, tSz, tSz, 0, "B", colorAccentRed)

        // ── Select / Start (centre) ───────────────────────────────────────
        // Shortened from the old 0.11×/0.038× (≈6.4:1 — a long thin bar)
        // down to a squatter ≈3:1 pill.
        val ssW  = sw * 0.072f * s;  val ssH  = sh * 0.052f * s
        val ssCy = controlsTop + padH * 0.82f + ssH / 2f
        val ssGap = sw * 0.07f
        addButton("select", sw/2f-ssGap-ssW/2f, ssCy, ssW, ssH, EmulatorEngine.KEY_SELECT, "SEL", colorAccentLight)
        addButton("start",  sw/2f+ssGap+ssW/2f, ssCy, ssW, ssH, EmulatorEngine.KEY_START,  "STA", colorAccentLight)

        // ── L / R shoulder buttons ─────────────────────────────────────────
        // Reshaped to match the reference skin: a squat ~2:1 trigger glyph
        // (flat hinge edge + one big rounded sweep — see shoulderButtonPath())
        // instead of the old 0.13×/0.042× (~6.9:1) long thin bar.
        val lrW = sw * 0.07f  * s;  val lrH = sh * 0.075f * s
        val lrY = controlsTop + padH * 0.06f + lrH / 2f
        val lrCxL = sw*0.03f+lrW/2f
        val lrCxR = sw-sw*0.03f-lrW/2f
        addButton("l", lrCxL, lrY, lrW, lrH, EmulatorEngine.KEY_L, "L", colorAccentLight)
        addButton("r", lrCxR, lrY, lrW, lrH, EmulatorEngine.KEY_R, "R", colorAccentLight)

        // ── ⏩ Fast-forward — docked directly under R (matching the
        // reference layout) instead of floating above SEL/STA. Roughly
        // square, sized off R's own height, with about one R-height of gap
        // between them.
        // Not pushed into `buttons` (it isn't a GBA key — see onGameTouch),
        // but still routed through resolvedRect() so it's just as draggable
        // and resizable in the editor as every other button.
        val utilSize = lrH
        val utilY = lrY + lrH/2f + lrH + utilSize/2f
        val ffRect = resolvedRect("ff", lrCxR, utilY, utilSize, utilSize)
        // ADD/REMOVE CONTROL: an empty RectF.contains() is always false for
        // any point, so this alone is enough to make a hidden ff both
        // undrawable and untappable — see drawControls()/onGameTouch().
        ffBtnRect = if (isButtonVisible("ff")) ffRect else RectF()
        // NOTE: fsBtnRect REMOVED — fullscreen is now in ⚙ Settings only

        // ── Extra controls (opt-in via "+ Add control") ────────────────────
        // FEATURE: new — the shoulder+face combos (TL+A/TL+B/TR+A/TR+B),
        // the A/B combos (plain + turbo), and three one-tap actions (quick
        // save/load, screenshot), matching the reference app's own "Add
        // control" catalog. Hidden until explicitly added (extraControlIds/
        // addedExtraButtons/isButtonVisible) — every one of these is a
        // completely ordinary addButton() entry once visible, so it's just
        // as draggable/resizable/lockable/removable as any base button with
        // no extra plumbing. This default spot (a small two-row cluster
        // between the shoulder buttons and the D-pad/A-B row — clear of
        // both at every screen size this app targets) only has to be a
        // reasonable starting point, since where it ends up is entirely up
        // to whoever adds it.
        val exSz    = btnSz * 0.56f
        val exGapX  = exSz * 1.35f
        val exRow1Y = controlsTop + padH * 0.27f
        val exRow2Y = controlsTop + padH * 0.42f
        val exRow1X0 = sw * 0.5f - exGapX * 2f
        addButton("la", exRow1X0,             exRow1Y, exSz, exSz, EmulatorEngine.KEY_L or EmulatorEngine.KEY_A, "LA", colorAccentLight)
        addButton("lb", exRow1X0 + exGapX,    exRow1Y, exSz, exSz, EmulatorEngine.KEY_L or EmulatorEngine.KEY_B, "LB", colorAccentLight)
        addButton("ab", exRow1X0 + exGapX*2f, exRow1Y, exSz, exSz, EmulatorEngine.KEY_A or EmulatorEngine.KEY_B, "AB", colorAccentLight)
        addButton("ra", exRow1X0 + exGapX*3f, exRow1Y, exSz, exSz, EmulatorEngine.KEY_R or EmulatorEngine.KEY_A, "RA", colorAccentLight)
        addButton("rb", exRow1X0 + exGapX*4f, exRow1Y, exSz, exSz, EmulatorEngine.KEY_R or EmulatorEngine.KEY_B, "RB", colorAccentLight)
        val exRow2X0 = sw * 0.5f - exGapX * 1.5f
        // "abturbo" reuses the same red-for-turbo convention as ta/tb above
        // (see updateGameKeys()'s "abturbo" case for how it actually drives
        // both satellites' phase-square-wave at once).
        addButton("abturbo",    exRow2X0,             exRow2Y, exSz, exSz, 0, "AB", colorAccentRed)
        addButton("quicksave",  exRow2X0 + exGapX,    exRow2Y, exSz, exSz, 0, "💾", colorAccentLight)
        addButton("quickload",  exRow2X0 + exGapX*2f, exRow2Y, exSz, exSz, 0, "📂", colorAccentLight)
        addButton("screenshot", exRow2X0 + exGapX*3f, exRow2Y, exSz, exSz, 0, "📷", colorAccentLight)

        // Publish the whole list in one atomic reference write — see the
        // `buttons` field comment for why this matters.
        buttons = buildingButtons

        // FEATURE: keeps gameScreenRect (and the actual rendered image —
        // updateGameMatrix() is what gameScreenRect ultimately drives) in
        // sync with every button-layout change, live drag/resize included,
        // rather than needing updateGameMatrix() threaded individually
        // through every one of buildControlLayout's own call sites. Safe
        // to call unconditionally — updateGameMatrix() already no-ops via
        // its own frameBuffers null check on any call site reached before
        // a ROM is loaded.
        updateGameMatrix(sw, sh)

        if (editModeActive) refreshEditToolbarPosition()
    }

    // ── Draw controls ──────────────────────────────────────────────────────

    private val fillPaint   = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    // FEATURE: linearFilterEnabled (declared above with stretchToFit/
    // maxFrameSkips — see the FIX note there for why its declaration is
    // worth a second look) wired up here. Bilinear (isFilterBitmap = true)
    // softens the GBA's blocky upscaled pixels; nearest-neighbor (false,
    // the default, matching every previous pass's actual on-screen
    // behavior since this used to always be a plain `null` Paint, which
    // the Canvas API treats as filtering off) keeps them crisp. One
    // shared, mutable Paint instead of a fresh one per frame —
    // updateLinearFilterPaint() below flips isFilterBitmap on the same
    // instance whenever the setting changes, rather than needing a new
    // object either way.
    private val gamePaint = Paint().apply { isFilterBitmap = false }
    private fun updateLinearFilterPaint() { gamePaint.isFilterBitmap = linearFilterEnabled }
    private val labelPaint  = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textAlign = Paint.Align.CENTER
    }

    // PERF FIX: these were previously Color.parseColor("#...") calls made
    // INSIDE drawControls()/drawDpad() — i.e. re-parsed from a hex string on
    // every single rendered frame (the d-pad alone re-parsed the same string
    // 4×/frame). That's pure wasted CPU sitting on the exact thread that
    // also paces audio playback (see startGameLoop()) — any extra time spent
    // here delays the next AudioTrack.write(), which is what an underrun
    // "click" actually is. Precomputing these once is a zero-risk, visually
    // identical change (same values, same Color.parseColor, just evaluated
    // once instead of ~6-7×/frame).
    // colorControlsBg (was Color.parseColor("#CC111122"), a semi-opaque
    // dark-navy fill drawn from controlsTop down every frame — see the old
    // drawControls()) is gone as of the Fortieth pass: reported directly
    // as an unwanted "black transparent" band behind the on-screen
    // controls. No replacement fill — canvas.drawColor(Color.BLACK) in
    // renderFrame() already clears the whole canvas before drawControls()
    // runs, so removing the rect just leaves that area plain black instead
    // of tinted; nothing left to redraw, no stale-frame/unfilled-gap risk.
    private val colorFfActive   = Color.parseColor("#CC7700")
    // OUTLINE SKIN: every control is now a stroked (line-art) shape instead
    // of a filled one, matching the requested reference skin — one shared
    // light/neutral accent for every button (D-pad / A / B / L / R /
    // Select / Start / FF-idle). The old solid colorFfIdle / colorDpadBase /
    // colorDpadArm fills are gone: there's no shared d-pad base plate any
    // more either — see drawDpad(), each arm is its own outlined button.
    // (colorAccentLight itself moved to SharedUi.kt this pass — RomBrowserActivity needs it too.)
    // Used only by the optional Turbo A/B satellites — red reads as
    // "rapid-fire" (the usual emulator-skin convention), which is exactly
    // right here since that's what they are, unlike the normal A/B.
    private val colorAccentRed   = Color.parseColor("#E5484D")

    private fun drawControls(canvas: Canvas) {
        // ADD/REMOVE CONTROL: `buttons` can now legitimately be empty (every
        // normal button removed) while ff is still shown, or vice versa —
        // used to be a flat "buttons.isEmpty() => bail entirely", which was
        // fine back when buttons was only empty before the very first
        // buildControlLayout() call. Now it'd also silently hide a still-
        // present ff button any time every OTHER control was removed. Bail
        // only when there is truly nothing to draw.
        val ffVisible = ffBtnRect.width() > 0f
        if (buttons.isEmpty() && !ffVisible) return

        val keys       = currentKeys.get()
        // Idle alpha scales with user preference; press brightens by +80.
        // Per-button opacity overrides from the editor take priority — see
        // the loop below.
        val idleAlpha  = buttonBaseAlpha

        for (btn in buttons) {
            val ov = customLayout[btn.id]?.alphaOverride ?: -1
            val btnIdle = if (ov >= 0) ov else idleAlpha
            if (btn.isDpad) {
                drawDpad(canvas, btn.rect, keys, btnIdle)
                continue
            }
            val pressed = when (btn.id) {
                "ta" -> turboAHeld
                "tb" -> turboBHeld
                "abturbo" -> turboAHeld && turboBHeld
                // BUG FIX: was `keys and btn.keyMask != 0` — correct for a
                // single-bit mask, but for the new combo buttons (e.g. "la"
                // = KEY_L|KEY_A) that lit up as soon as EITHER key was down
                // from any source, not just when this specific combo's own
                // full press was active. Requiring every bit fixes that and
                // is equivalent to the old check for every single-bit button.
                else -> btn.keyMask != 0 && keys and btn.keyMask == btn.keyMask
            }
            drawOutlineButton(canvas, btn.rect, btn.id, btn.label, btn.color, btnIdle, pressed)
        }

        // ── » Fast-forward button ────────────────────────────────────────
        if (!ffVisible) return
        val ffPressed = fastForwardActive
        val ffAlpha = (idleAlpha + 20).coerceAtMost(255)
        strokePaint.color = if (ffPressed) colorFfActive else colorAccentLight
        strokePaint.alpha = ffAlpha
        strokePaint.strokeWidth = outlineStrokeW
        if (ffPressed) {
            fillPaint.color = colorFfActive
            fillPaint.alpha = (ffAlpha * 0.35f).toInt().coerceIn(0, 255)
            canvas.drawRoundRect(ffBtnRect, 8f, 8f, fillPaint)
        }
        canvas.drawRoundRect(ffBtnRect, 8f, 8f, strokePaint)
        labelPaint.textSize = (ffBtnRect.height() * 0.52f).coerceAtLeast(12f)
        // FIX (this pass): used to show "» 4×" (the active speed) while
        // toggled on — reported as an indicator that shouldn't be there at
        // all. The color/fill change above (colorFfActive, the translucent
        // fill) already shows on/off state on its own; just "»" either way
        // now, no text distinguishing the two beyond that.
        canvas.drawText("»",
            ffBtnRect.centerX(), ffBtnRect.centerY() + labelPaint.textSize * 0.36f, labelPaint)
        // NOTE: ⛶ fullscreen button no longer drawn here — it lives in ⚙ Settings
    }

    /** Builds the L/R shoulder-trigger glyph: a flat hinge edge (left edge
     *  for L, right edge for R) with small rounded corners, a flat top edge,
     *  a short flat bottom segment on the hinge side, and one big smooth
     *  sweep on the outer side connecting the top corner down to where that
     *  bottom segment starts — the classic controller-bumper silhouette from
     *  the reference skin, instead of a plain pill. `mirrored = true` flips
     *  it for R.
     *
     *  PERF FIX (pass 43 — direct report: shoulderButtonPath() allocated a
     *  brand-new Path — a moveTo, 2 quadTo, a cubicTo, a lineTo and a
     *  close, not a cheap object — on every single call): this is invoked
     *  twice per rendered frame (L and R, from drawOutlineButton() below)
     *  for as long as a game is running, so 120 Path allocations/sec at
     *  60fps — the same permanent GC churn as drawDpad()'s old RectF
     *  allocations above, and for the same reason it matters (see that
     *  PERF FIX comment). The glyph's shape only actually changes when
     *  [rect] itself does (editor drag/resize, orientation change, scale
     *  change) — not every frame during normal play — so it's now built
     *  into one of two reusable Path instances (L and R need independent,
     *  simultaneously-live geometry, hence two, not one), rewound and
     *  rebuilt only when [rect] differs from the last frame's for that
     *  side, and simply returned as-is otherwise. `Path.rewind()`
     *  (clears the drawn geometry but keeps the Path's own internal
     *  arrays for reuse) rather than `.reset()` (also releases them) on
     *  purpose — same "don't let a hot path release and immediately
     *  reallocate its own storage" reasoning as reusing the RectF fields
     *  above instead of `new`-ing them. */
    private val shoulderPathL = Path()
    private val shoulderPathR = Path()
    private val shoulderRectL = RectF()
    private val shoulderRectR = RectF()

    private fun shoulderButtonPath(rect: RectF, mirrored: Boolean): Path {
        val path = if (mirrored) shoulderPathR else shoulderPathL
        val cachedRect = if (mirrored) shoulderRectR else shoulderRectL
        if (cachedRect == rect) return path   // geometry unchanged since last frame — reuse as-is
        cachedRect.set(rect)
        val w = rect.width(); val h = rect.height()
        val c = h * 0.22f              // small round on the two hinge-side corners
        val bottomRun = w * 0.30f      // length of the short flat bottom segment
        val left = rect.left; val top = rect.top; val right = rect.right; val bottom = rect.bottom
        path.rewind()
        if (!mirrored) {
            // L: hinge (flat) edge on the LEFT, big sweep on the RIGHT.
            path.moveTo(left, top + c)
            path.quadTo(left, top, left + c, top)
            path.lineTo(right, top)
            path.cubicTo(
                right + w * 0.02f, top + h * 0.35f,
                right - w * 0.04f, bottom - h * 0.10f,
                left + bottomRun, bottom
            )
            path.lineTo(left + c, bottom)
            path.quadTo(left, bottom, left, bottom - c)
            path.close()
        } else {
            // R: mirror of the above — hinge (flat) edge on the RIGHT.
            path.moveTo(right, top + c)
            path.quadTo(right, top, right - c, top)
            path.lineTo(left, top)
            path.cubicTo(
                left - w * 0.02f, top + h * 0.35f,
                left + w * 0.04f, bottom - h * 0.10f,
                right - bottomRun, bottom
            )
            path.lineTo(right - c, bottom)
            path.quadTo(right, bottom, right, bottom - c)
            path.close()
        }
        return path
    }

    /** Draws one outlined control button — a stroked circle for A/B (and the
     *  optional Turbo A/B satellites), a stroked shoulder-trigger glyph for
     *  L/R, a stroked pill (fully-rounded rect) for Select/Start, and a
     *  stroked rounded rect as a fallback for anything else. This is the
     *  line-art skin: no solid fill at rest, just a stroke — a soft matching
     *  fill fades in underneath only while the button is actually held, as
     *  the sole "pressed" cue. */
    private fun drawOutlineButton(
        canvas: Canvas, rect: RectF, id: String, label: String,
        accent: Int, idleAlpha: Int, pressed: Boolean
    ) {
        val alpha = if (pressed) (idleAlpha + 80).coerceAtMost(255) else idleAlpha
        strokePaint.color = accent
        strokePaint.alpha = alpha
        strokePaint.strokeWidth = outlineStrokeW
        if (pressed) {
            fillPaint.color = accent
            fillPaint.alpha = (alpha * 0.30f).toInt().coerceIn(0, 255)
        }
        var labelDx = 0f
        when (id) {
            "a", "b", "ta", "tb" -> {
                val cx = rect.centerX(); val cy = rect.centerY()
                val radius = minOf(rect.width(), rect.height()) / 2f - outlineStrokeW / 2f
                if (pressed) canvas.drawCircle(cx, cy, radius, fillPaint)
                canvas.drawCircle(cx, cy, radius, strokePaint)
            }
            "l", "r" -> {
                val p = shoulderButtonPath(rect, mirrored = id == "r")
                if (pressed) canvas.drawPath(p, fillPaint)
                canvas.drawPath(p, strokePaint)
                // Nudge the label into the "meat" of the glyph (the flat
                // hinge side), away from the tapering sweep.
                labelDx = if (id == "l") -rect.width() * 0.18f else rect.width() * 0.18f
            }
            "select", "start" -> {
                val r = rect.height() / 2f
                if (pressed) canvas.drawRoundRect(rect, r, r, fillPaint)
                canvas.drawRoundRect(rect, r, r, strokePaint)
            }
            else -> {
                if (pressed) canvas.drawRoundRect(rect, 12f, 12f, fillPaint)
                canvas.drawRoundRect(rect, 12f, 12f, strokePaint)
            }
        }
        if (label.isNotEmpty()) {
            labelPaint.textSize = (rect.height() * 0.42f).coerceAtLeast(13f)
            canvas.drawText(label, rect.centerX() + labelDx,
                rect.centerY() + labelPaint.textSize * 0.36f, labelPaint)
        }
    }

    /** Renders four independently-outlined direction buttons — no shared
     *  base plate — arranged in a loose cross, matching the reference skin
     *  where the D-pad reads as four separate line-art buttons rather than
     *  one filled plate. Hit-testing is UNCHANGED: dpadKeysFor() still
     *  resolves the whole unified [rect] by angle (see its own doc comment),
     *  so diagonals still work exactly as before even though visually
     *  you're now tapping between two shapes rather than on a solid arm.
     *
     *  PERF FIX (pass 43 — direct report: drawDpad() allocated a fresh
     *  RectF for each of the 4 arms on every single call): this runs once
     *  per rendered frame for as long as a game is running, so 4
     *  allocations/frame is 240 allocations/sec at 60fps — permanent GC
     *  churn on the exact thread that also paces audio playback (see the
     *  colorFfActive PERF FIX comment elsewhere in this file for why that
     *  specifically matters: any extra time spent allocating/collecting
     *  here delays the next AudioTrack.write(), which is what an underrun
     *  "click" actually is). The 4 arms only actually change shape when
     *  the d-pad's own bounding [rect] does (editor drag/resize,
     *  orientation change, scale change) — not every frame during normal
     *  play — so they're now precomputed once into 4 reusable RectF
     *  fields, refreshed only when [rect] differs from the last frame's
     *  (updateDpadArmRects() below, a plain RectF.equals() check — no
     *  allocation either way), and just redrawn (current pressed/alpha
     *  state, genuinely per-frame data) the rest of the time. */
    private val dpadArmRectUp = RectF()
    private val dpadArmRectDown = RectF()
    private val dpadArmRectLeft = RectF()
    private val dpadArmRectRight = RectF()
    // Deliberately inverted (right < left) so it can never equal a real
    // d-pad rect — guarantees the very first call always computes rather
    // than reading 4 empty RectFs, without needing a separate boolean flag.
    private val dpadLastRect = RectF(0f, 0f, -1f, -1f)
    private var dpadArmCorner = 0f

    /** Recomputes the 4 arm RectFs (and the shared corner radius) from the
     *  d-pad's overall [rect] — only when [rect] has actually changed
     *  since the last call. See drawDpad()'s own PERF FIX comment above
     *  for why this exists as a separate, cache-checked step instead of
     *  inline in drawDpad() the way it used to be. */
    private fun updateDpadArmRects(rect: RectF) {
        if (dpadLastRect == rect) return
        dpadLastRect.set(rect)
        val cx = rect.centerX(); val cy = rect.centerY()
        val r  = minOf(rect.width(), rect.height()) / 2f
        val armLen = r * 0.62f
        val armW   = r * 0.60f
        dpadArmCorner = armW * 0.24f
        fun place(out: RectF, dx: Float, dy: Float) {
            val ax = cx + dx * armLen; val ay = cy + dy * armLen
            out.set(ax - armW / 2f, ay - armW / 2f, ax + armW / 2f, ay + armW / 2f)
        }
        place(dpadArmRectUp,     0f, -1f)
        place(dpadArmRectDown,   0f,  1f)
        place(dpadArmRectLeft,  -1f,  0f)
        place(dpadArmRectRight,  1f,  0f)
    }

    private fun drawDpad(canvas: Canvas, rect: RectF, keys: Int, idleAlpha: Int) {
        updateDpadArmRects(rect)
        fun drawArm(armRect: RectF, pressed: Boolean, label: String) {
            val alpha = if (pressed) (idleAlpha + 80).coerceAtMost(255) else idleAlpha
            if (pressed) {
                fillPaint.color = colorAccentLight
                fillPaint.alpha = (alpha * 0.30f).toInt().coerceIn(0, 255)
                canvas.drawRoundRect(armRect, dpadArmCorner, dpadArmCorner, fillPaint)
            }
            strokePaint.color = colorAccentLight
            strokePaint.alpha = alpha
            strokePaint.strokeWidth = outlineStrokeW
            canvas.drawRoundRect(armRect, dpadArmCorner, dpadArmCorner, strokePaint)
            labelPaint.textSize = (armRect.width() * 0.44f).coerceAtLeast(12f)
            canvas.drawText(label, armRect.centerX(), armRect.centerY() + labelPaint.textSize * 0.36f, labelPaint)
        }
        drawArm(dpadArmRectUp,    keys and EmulatorEngine.KEY_UP    != 0, "▲")
        drawArm(dpadArmRectDown,  keys and EmulatorEngine.KEY_DOWN  != 0, "▼")
        drawArm(dpadArmRectLeft,  keys and EmulatorEngine.KEY_LEFT  != 0, "◀")
        drawArm(dpadArmRectRight, keys and EmulatorEngine.KEY_RIGHT != 0, "▶")
    }

    /** Maps a touch point inside the unified d-pad rect to a GBA key-bit
     *  combination by angle from center, split into 8 x 45° sectors — the
     *  4 cardinal sectors give a single direction, the 4 sectors between
     *  them give the two adjacent bits (a genuine diagonal). A small
     *  circular dead-zone at the very center avoids accidental input from
     *  a light tap that lands near the middle. */
    private fun dpadKeysFor(rect: RectF, x: Float, y: Float): Int {
        val cx = rect.centerX(); val cy = rect.centerY()
        val halfW = (rect.width() / 2f).coerceAtLeast(1f)
        val halfH = (rect.height() / 2f).coerceAtLeast(1f)
        val dx = x - cx; val dy = y - cy
        val distNorm = maxOf(abs(dx) / halfW, abs(dy) / halfH)
        if (distNorm < 0.16f) return 0   // dead zone — no accidental direction from a center tap

        var deg = Math.toDegrees(kotlin.math.atan2(-dy.toDouble(), dx.toDouble()))
        if (deg < 0) deg += 360.0
        val U = EmulatorEngine.KEY_UP; val D = EmulatorEngine.KEY_DOWN
        val L = EmulatorEngine.KEY_LEFT; val R = EmulatorEngine.KEY_RIGHT
        return when {
            deg >= 337.5 || deg < 22.5  -> R
            deg < 67.5                  -> U or R
            deg < 112.5                 -> U
            deg < 157.5                 -> U or L
            deg < 202.5                 -> L
            deg < 247.5                 -> D or L
            deg < 292.5                 -> D
            else                         -> D or R
        }
    }

    /** REMOVED (this pass): used to draw "⏩ Nx" in the top-left corner
     *  whenever fast-forward was active — reported as an unwanted
     *  always-on-top speed indicator (see CHANGELOG.md). The button's own
     *  color/fill change (see drawControls()'s ffPressed branch) already
     *  shows on/off state, so nothing replaces this — it's just gone.
     *  formatSpeed() below is still used by the Misc settings text field
     *  and the hold-for-speed-slider popup, so it stays. */
    private fun formatSpeed(s: Float): String =
        if (s == s.toLong().toFloat()) s.toLong().toString() else "%.1f".format(s)

    /** Hold-the-»-button speed picker — a slider (0.5–16×, half-speed
     *  steps, matching the existing text-field validation's own range —
     *  see the Fast-forward speed setting in Misc) plus a Done button,
     *  requested as a faster way to change speed than opening Settings
     *  every time. Setting the value here writes the exact same
     *  fastForwardSpeed field/PREF_FF_SPEED pref that setting's own text
     *  field does — either one changes what the other shows next time. */
    private fun showFastForwardSpeedSlider() {
        val ctx = this
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val layout = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(4), dp(24), dp(0))
        }
        val valueText = TextView(ctx).apply {
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        layout.addView(valueText)
        // SeekBar only deals in whole-number steps — 0..31 here maps to
        // 0.5..16.0 in steps of 0.5, matching the Misc speed field's own
        // 0.5–16 range exactly (see its "Speed must be 0.5 – 16" check).
        fun speedFor(progress: Int) = 0.5f + progress * 0.5f
        val seek = SeekBar(ctx).apply {
            max = 31
            progress = ((fastForwardSpeed - 0.5f) / 0.5f).toInt().coerceIn(0, 31)
        }
        valueText.text = "${formatSpeed(speedFor(seek.progress))}×"
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, value: Int, fromUser: Boolean) {
                valueText.text = "${formatSpeed(speedFor(value))}×"
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })
        layout.addView(seek)

        val dialog = AlertDialog.Builder(ctx)
            .setTitle("Fast-forward speed")
            .setView(layout)
            .setPositiveButton("Done") { _, _ ->
                val speed = speedFor(seek.progress)
                fastForwardSpeed = speed
                prefs.edit().putFloat(PREF_FF_SPEED, speed).apply()
            }
            .create()
        dialog.window?.setBackgroundDrawable(roundedDialogBackground())
        dialog.show()
    }

    // ── Touch handling ─────────────────────────────────────────────────────
    //
    // STICKY DRAG-OFF: once a finger is down on a control, it keeps
    // contributing that control's key(s) even after the finger drags
    // outside that control's own hit-box — right up until that specific
    // finger actually lifts (ACTION_UP / ACTION_POINTER_UP) or the gesture
    // is cancelled. Previously updateGameKeys() re-hit-tested every
    // pointer's CURRENT position on every single call with nothing carried
    // over, so straying off a button's rect by even a pixel — while still
    // pressing down — read as an immediate release. That doesn't match how
    // a physical button (or basically any touch gamepad) behaves.
    //
    // Tracked per pointer ID (not per button) so multiple fingers can each
    // independently hold their own button, and so a finger sliding from one
    // button straight onto a different one correctly switches instead of
    // both buttons lighting up.
    private val pointerKeys   = mutableMapOf<Int, Int>()  // pointerId -> GBA key bits that finger last hit
    private val pointerTurboA = mutableSetOf<Int>()       // pointerIds currently "holding" the Turbo-A satellite
    private val pointerTurboB = mutableSetOf<Int>()       // pointerIds currently "holding" the Turbo-B satellite

    private fun clearPointerState() {
        pointerKeys.clear(); pointerTurboA.clear(); pointerTurboB.clear()
    }

    // FIX (this pass): replaces the removed floating "Load ROM" button (see
    // the FIX comment in onCreate where it used to be built) as the way
    // back into ROM selection whenever nothing else is on screen — the
    // folder picker gets cancelled before any folder's ever been chosen, or
    // a ROM load fails (see loadRomFromUri's catch block). Gated on
    // !romLoaded specifically so this never fires mid-game: settingsMenuOverlay
    // sits on top of the surface while Settings are open and marks itself
    // isClickable = true precisely to swallow touches before they'd ever
    // reach here (the ROM browser doesn't need the same guard any more —
    // it's RomBrowserActivity, a separate Activity now, so MainActivity's
    // own surface simply isn't the foreground window, let alone touchable,
    // whenever it's showing). ACTION_UP (not ACTION_DOWN) so a
    // drag that started on the idle screen doesn't fire this.
    private fun onGameTouch(event: MotionEvent) {
        if (!romLoaded) {
            if (event.actionMasked == MotionEvent.ACTION_UP) changeRom()
            return
        }
        if (editModeActive) { onEditTouch(event); return }
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val x = event.x; val y = event.y
                // FEATURE (this pass): »/fast-forward no longer toggles the
                // instant it's touched — a hold now shows a speed slider
                // instead (see showFastForwardSpeedSlider()), so this has
                // to wait and see which one it turns out to be. Arms a
                // delayed Runnable exactly like the editor's own
                // hold-to-remove gesture (editLongPressPending above);
                // ACTION_UP/ACTION_POINTER_UP below cancel it and toggle
                // normally if they get there first (a real tap), otherwise
                // the Runnable itself fires, opens the slider, and there's
                // nothing left for either of those to do. See
                // armFfLongPress()'s own doc comment for why this is now
                // shared with ACTION_POINTER_DOWN below.
                if (ffBtnRect.contains(x, y)) {
                    armFfLongPress(event.getPointerId(0))
                    return
                }
                // NOTE: fullscreen ⛶ touch removed — use ⚙ Settings to toggle fullscreen
                // One-tap extra controls (quick save/load, screenshot) — see
                // actionButtonAt(). Deliberately still first-finger-only,
                // unlike ff just above — these are meant as one-off
                // deliberate taps, not something you'd chord mid-gesture
                // with a direction already held, so there's no equivalent
                // case for reaching them from a second finger the way
                // there is for fast-forward (see ACTION_POINTER_DOWN below).
                actionButtonAt(x, y)?.let { id -> triggerActionButton(id); return }
                updateGameKeys(event)
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                // FIX (this pass — audit's own design-tradeoff note): a
                // second/third finger landing on ff now gets the exact same
                // long-press-for-slider / tap-to-toggle treatment
                // ACTION_DOWN already gives the very first finger — "hold a
                // direction, tap FF to speed through a corridor" is an
                // ordinary GBA-play gesture this made impossible before,
                // since only ACTION_DOWN (by definition the first pointer)
                // ever checked ffBtnRect. quicksave/quickload/screenshot
                // above stay first-finger-only on purpose — see
                // actionButtonAt()'s call site comment in ACTION_DOWN.
                val idx = event.actionIndex
                if (ffLongPressPending == null && ffBtnRect.contains(event.getX(idx), event.getY(idx))) {
                    armFfLongPress(event.getPointerId(idx))
                    return
                }
                updateGameKeys(event)
            }
            MotionEvent.ACTION_MOVE -> updateGameKeys(event)
            MotionEvent.ACTION_UP -> {
                // FIX (this pass): was `if (ffBtnRect.contains(event.x,
                // event.y))` — required the lifting finger to still be
                // exactly over the button, so pressing ff then drifting
                // off it slightly before releasing (ordinary finger
                // wobble, well within normal tap tolerance) fell through
                // to here *without* cancelling ffLongPressPending, which
                // could then still fire and pop the slider open later,
                // seemingly out of nowhere, after the finger was long
                // gone. Tracking *which pointer* armed the gesture
                // (ffDownPointerId, needed anyway for the new
                // ACTION_POINTER_DOWN case above) fixes both at once: any
                // lift of that specific finger — wherever it currently is
                // — resolves the gesture one way or the other, so there's
                // no path left where it's forgotten about mid-air.
                if (ffDownPointerId != -1 && ffDownPointerId == event.getPointerId(0)) {
                    completeFfTap()
                    return
                }
                clearPointerState()
                currentKeys.set(0)
                turboAHeld = false; turboBHeld = false
            }
            MotionEvent.ACTION_POINTER_UP -> {
                val liftedId = event.getPointerId(event.actionIndex)
                // Matching half of ACTION_UP's own fix just above — the
                // ff-arming finger isn't necessarily the *last* one down
                // now that a second/third finger can arm it too, so this
                // needs the exact same check, not just ACTION_UP.
                if (ffDownPointerId != -1 && ffDownPointerId == liftedId) {
                    completeFfTap()
                    return
                }
                // Evict just the lifting finger's sticky state — it's the
                // only one actually going away. The explicit remove() here
                // AND excludePointerIndex below are both needed: this same
                // MotionEvent still reports the lifting pointer at its last
                // coordinates (it's only dropped from the *next* event), so
                // without excluding its index in updateGameKeys(), the
                // hit-test would immediately re-add it to pointerKeys and
                // undo the remove().
                pointerKeys.remove(liftedId)
                pointerTurboA.remove(liftedId)
                pointerTurboB.remove(liftedId)
                updateGameKeys(event, excludePointerIndex = event.actionIndex)
            }
            else                          -> {
                ffLongPressPending?.let { mainHandler.removeCallbacks(it) }
                ffLongPressPending = null
                ffDownPointerId = -1
                clearPointerState()
                currentKeys.set(0)
                turboAHeld = false; turboBHeld = false
            }
        }
    }

    /** Arms the ff long-press-for-slider Runnable for [pointerId] — shared
     *  by ACTION_DOWN (the first finger touching down fresh) and
     *  ACTION_POINTER_DOWN (a second or third finger landing on ff while
     *  another is already held for a direction) so both go through the
     *  exact same tap-vs-hold logic rather than two independently
     *  maintained copies of it. Only ff gets this multi-finger treatment —
     *  see actionButtonAt()'s call site comment in onGameTouch's
     *  ACTION_DOWN for why quicksave/quickload/screenshot deliberately
     *  don't. */
    private fun armFfLongPress(pointerId: Int) {
        ffDownPointerId = pointerId
        val lp = Runnable {
            ffLongPressPending = null
            ffDownPointerId = -1
            showFastForwardSpeedSlider()
        }
        ffLongPressPending = lp
        mainHandler.postDelayed(lp, ViewConfiguration.getLongPressTimeout().toLong())
    }

    /** The matching "this finger lifted before the long-press fired" half
     *  of [armFfLongPress] — a genuine tap, so toggle fastForwardActive
     *  normally. Called once onGameTouch has already confirmed the
     *  *specific* finger that armed the gesture is the one lifting (either
     *  ACTION_UP, if it was the last finger down, or ACTION_POINTER_UP if
     *  another is still held) — safe to call unconditionally at that
     *  point: a no-op `?.let` if the long press already fired
     *  (ffLongPressPending is already null and the slider is open by
     *  then — toggling fast-forward out from under it here would be
     *  wrong), otherwise cancels the pending Runnable and toggles. Either
     *  way, ffDownPointerId always clears — this finger's gesture is
     *  resolved now, one way or the other. */
    private fun completeFfTap() {
        ffLongPressPending?.let { pending ->
            mainHandler.removeCallbacks(pending)
            ffLongPressPending = null
            fastForwardActive = !fastForwardActive
        }
        ffDownPointerId = -1
    }

    private fun updateGameKeys(event: MotionEvent, excludePointerIndex: Int = -1) {
        for (i in 0 until event.pointerCount) {
            if (i == excludePointerIndex) continue
            val pid = event.getPointerId(i)
            val x = event.getX(i); val y = event.getY(i)
            var hitAny = false
            var hitKeys = 0
            var hitTa = false
            var hitTb = false
            for (btn in buttons) {
                if (!btn.rect.contains(x, y)) continue
                hitAny = true
                when (btn.id) {
                    // Turbo satellites don't feed currentKeys directly (that
                    // would just be a continuous hold) — see the on/off
                    // square-wave applied in startGameLoop() before
                    // nativeSetKeys().
                    "ta" -> hitTa = true
                    "tb" -> hitTb = true
                    // "A/B turbo" combo — both satellites at once, reusing
                    // the exact same pointerTurboA/pointerTurboB machinery
                    // as ta/tb individually. Both share one phaseOn value
                    // in effectiveKeysForCore(), so driving both from a
                    // single touch square-waves A and B together in sync,
                    // rather than needing a third independent turbo channel.
                    "abturbo" -> { hitTa = true; hitTb = true }
                    else -> hitKeys = hitKeys or (if (btn.isDpad) dpadKeysFor(btn.rect, x, y) else btn.keyMask)
                }
            }
            if (hitAny) {
                // Overwrite (don't merge with) this pointer's previous
                // sticky state — a finger that's moved onto a different
                // button, or off Turbo onto a normal button, should read
                // as ONLY what it's on now, not accumulate stale bits from
                // wherever it used to be.
                pointerKeys[pid] = hitKeys
                if (hitTa) pointerTurboA.add(pid) else pointerTurboA.remove(pid)
                if (hitTb) pointerTurboB.add(pid) else pointerTurboB.remove(pid)
            }
            // else: this pointer is over empty space right now. Leave
            // pointerKeys[pid] / pointerTurboA / pointerTurboB exactly as
            // they were — that's the fix itself: a control that was
            // pressed keeps reading as pressed while dragged off it, until
            // this specific pointer lifts (handled in onGameTouch above).
        }

        var keys = 0
        for (k in pointerKeys.values) keys = keys or k
        currentKeys.set(keys)
        turboAHeld = pointerTurboA.isNotEmpty()
        turboBHeld = pointerTurboB.isNotEmpty()
    }

    /** currentKeys as touched, plus the Turbo A/B on/off square wave mixed
     *  in if either is currently held. Kept separate from currentKeys
     *  itself so the on-screen "pressed" glow stays a simple, steady held
     *  state (see drawControls()) — only what actually reaches the core
     *  flickers. Called once per emulated frame from startGameLoop(), which
     *  at turboHalfPeriodMs=66 is plenty of resolution for the wave to read
     *  cleanly even under fast-forward. */
    private fun effectiveKeysForCore(): Int {
        var keys = currentKeys.get()
        if (turboAHeld || turboBHeld) {
            val phaseOn = (System.currentTimeMillis() / turboHalfPeriodMs) % 2L == 0L
            if (turboAHeld) keys = if (phaseOn) keys or EmulatorEngine.KEY_A else keys and EmulatorEngine.KEY_A.inv()
            if (turboBHeld) keys = if (phaseOn) keys or EmulatorEngine.KEY_B else keys and EmulatorEngine.KEY_B.inv()
        }
        return keys
    }

    // ── One-tap extra controls (quick save/load, screenshot) ────────────────
    // FEATURE: new. Unlike every other button, these don't feed
    // currentKeys/nativeSetKeys at all (keyMask 0 — see buildControlLayout)
    // — a tap fires the action once, immediately, the same way the ⏩
    // button toggles fastForwardActive in onGameTouch's ACTION_DOWN rather
    // than going through updateGameKeys.
    private val actionButtonIds = setOf("quicksave", "quickload", "screenshot")

    private fun actionButtonAt(x: Float, y: Float): String? =
        buttons.firstOrNull { it.id in actionButtonIds && it.rect.contains(x, y) }?.id

    private fun triggerActionButton(id: String) {
        when (id) {
            "quicksave"  -> quickSaveState()
            "quickload"  -> quickLoadState()
            "screenshot" -> takeScreenshot()
        }
    }

    // ── Control layout editor ────────────────────────────────────────────────
    //
    // FEATURE #2 — a My Boy!-style layout editor. Scope for this pass: every
    // button (D-pad × 4, A, B, Start, Select, L, R, Fast-Forward) can be
    // freely dragged anywhere on screen and resized via a corner handle, with
    // a per-button opacity override and a per-button lock, all live-previewed
    // over the actual running game and persisted across sessions. Deliberately
    // NOT built in this pass (flagged rather than silently skipped):
    // per-button rotation/mirroring (unusual for a D-pad/AB layout — mostly
    // relevant for decorative custom skins, low value here), snap-to-guides /
    // alignment grid, and named/duplicatable layout profiles beyond the
    // automatic portrait/landscape split already wired into the storage
    // format. Per-game layouts are a storage-key change away (see
    // orientationTag()/PREF_LAYOUT_PREFIX) but need a ROM-identity concept
    // (hash or path) this codebase doesn't have yet, so it's out of scope
    // until that exists rather than faked with a no-op toggle.

    private fun labelFor(id: String): String = when (id) {
        "dpad" -> "D-Pad"
        "a" -> "A Button"; "b" -> "B Button"; "start" -> "Start"; "select" -> "Select"
        "l" -> "L Shoulder"; "r" -> "R Shoulder"; "ff" -> "Fast-Forward"
        "ta" -> "Turbo A"; "tb" -> "Turbo B"
        "la" -> "TL+A"; "lb" -> "TL+B"; "ra" -> "TR+A"; "rb" -> "TR+B"
        "ab" -> "A/B"; "abturbo" -> "A/B Turbo"
        "quicksave" -> "Quick Save"; "quickload" -> "Quick Load"; "screenshot" -> "Screenshot"
        "gamescreen" -> "Game Screen"
        else -> id
    }

    private fun editRectFor(id: String): RectF? = when (id) {
        "ff" -> ffBtnRect
        "gamescreen" -> gameScreenRect
        else -> buttons.find { it.id == id }?.rect
    }

    private fun resizeHandleRadius(rect: RectF): Float =
        (minOf(rect.width(), rect.height()) * 0.22f).coerceIn(22f, 36f)

    // BUG FIX ("hitbox for dragging to resize is not accurate", most
    // noticeable in landscape): resizeHandleRadius() above is a *visual*
    // size — deliberately small so the dot doesn't look oversized on a tiny
    // button — but onEditTouch() used that exact same tiny radius as the
    // TOUCH target too, and worse, in raw pixels rather than dp. Its
    // 22–36f clamp is 22–36 *pixels*, which on a typical ~2.5–3x density
    // phone is only a ~15–24dp hit diameter — well under Android's own
    // 48dp minimum recommended touch target — and landscape specifically
    // makes it worse: buttons sit in a vertically-squeezed strip there
    // (see buildControlLayout's padH), so minOf(width,height) is smaller
    // and the radius bottoms out at the 22px floor even more often.
    // This is the touch-only hit radius: same visual dot, a much more
    // generous invisible grab zone around it (standard "small glyph, big
    // tap target" pattern), floored at a real 24dp regardless of how small
    // the button itself has been resized down to.
    private fun resizeHandleTouchRadius(rect: RectF): Float =
        maxOf(resizeHandleRadius(rect), dp(24).toFloat())

    private fun dist(x1: Float, y1: Float, x2: Float, y2: Float): Float {
        val dx = x1 - x2; val dy = y1 - y2
        return kotlin.math.sqrt(dx * dx + dy * dy)
    }

    /** Gets-or-creates the override entry for [id], seeded from its current
     *  default geometry so a freshly-touched button starts exactly where it
     *  visually already is, not at some arbitrary origin. */
    private fun entryFor(id: String): LayoutEntry = customLayout.getOrPut(id) {
        val g = defaultGeometry[id]
        LayoutEntry(
            xFrac = (g?.cx ?: lastSw / 2f) / lastSw.coerceAtLeast(1f),
            yFrac = (g?.cy ?: lastSh / 2f) / lastSh.coerceAtLeast(1f)
        )
    }

    // ── Editor alignment grid — position/size snapping ──────────────────────
    // FIX (Fortieth pass): grid cells are real squares now, not a w/N-by-h/N
    // rectangle — see gridDivisions' own field comment above for the report
    // this traces back to. gridCellPx() is the one place that size is
    // computed; drawGrid() and both snap functions below all call it
    // instead of each re-deriving a cell size from lastSw/lastSh
    // independently — same idea as before (draw and snap must agree), just
    // one shared square number now instead of two independent non-square
    // ones.

    /** Pixel size of one square grid cell. gridDivisions cells fit across
     *  whichever of lastSw/lastSh is smaller; the longer dimension gets
     *  however many whole cells happen to fit at that same size (see
     *  drawGrid()) — that's what makes the cells actual squares on a
     *  non-square screen instead of gridDivisions columns by gridDivisions
     *  rows. */
    private fun gridCellPx(): Float =
        (minOf(lastSw, lastSh) / gridDivisions.coerceAtLeast(1)).coerceAtLeast(0.01f)

    /** Snaps a single pixel coordinate ([v], along either axis — the cell
     *  is square, so which axis it is no longer changes the math) to the
     *  nearest grid line. Used for the drag/position case — called on both
     *  X and Y independently, after the existing on-screen clamp, so a
     *  snapped point is always the true final value (never nudged again
     *  afterward) — see onEditTouch()'s own note on why clamp-then-snap,
     *  not the other way around. */
    private fun snapPositionToGrid(v: Float): Float {
        val cell = gridCellPx()
        return Math.round(v / cell) * cell
    }

    /** Snaps a resize so the element's WIDTH lands on a whole number of
     *  grid cells (at least 1), then derives the scale that produces
     *  exactly that width from [id]'s own default (unscaled) width.
     *  Deliberately width-only rather than snapping width and height
     *  independently: every entry (buttons and the game screen alike)
     *  resizes through one uniform `scale` float (see LayoutEntry) so its
     *  aspect ratio never distorts — snapping both dimensions separately
     *  would either break that invariant or leave one of the two
     *  dimensions off-grid, which is exactly the "slightly off-grid"
     *  outcome this is meant to avoid. Snapping the width consistently
     *  means every resize in this app now has one predictable rule,
     *  rather than a different one depending on which control it's
     *  dragged from. Height still follows it exactly (same scale, fixed
     *  aspect), it just isn't independently forced onto its own grid
     *  line. */
    private fun snapScaleToGrid(id: String, scale: Float): Float {
        val base = defaultGeometry[id] ?: return scale
        val cell = gridCellPx()
        if (cell <= 0f || base.w <= 0f) return scale
        val rawWidth = base.w * scale
        val cells = Math.round(rawWidth / cell).coerceAtLeast(1)
        return ((cells * cell) / base.w).coerceIn(0.5f, 8.0f)
    }

    private fun hitTestEditable(x: Float, y: Float): String? {
        // BUG FIX (resize hitbox "not accurate"), part 2: the resize dot is
        // drawn CENTERED ON the button's corner (drawEditOverlay:
        // drawCircle(rect.right, rect.bottom, ...)), so roughly half of its
        // visible area sits outside the button's own rect. The plain
        // rect.contains() checks below reject any touch that lands outside
        // the rect — including a touch square on the visible dot — so
        // grabbing the *outer* half of a handle you can plainly see used to
        // just deselect the button instead of resizing it. Checking the
        // already-selected button's handle FIRST, with the expanded
        // touch-friendly radius above, and allowing that check to succeed
        // even outside the rect, fixes it — while unselected buttons still
        // use plain rect.contains() (no handle is drawn for them, so there's
        // nothing extra to grab yet).
        editSelectedId?.let { id ->
            if (isButtonVisible(id)) {   // a hidden button's rect is zero-size, not "small" — never treat it as a handle target
                val rect = editRectFor(id)
                if (rect != null && dist(x, y, rect.right, rect.bottom) <= resizeHandleTouchRadius(rect)) return id
            }
        }
        if (ffBtnRect.contains(x, y)) return "ff"
        for (b in buttons) if (b.rect.contains(x, y)) return b.id
        // Lowest priority, checked last: the screen occupies a much larger
        // area than any button, so anything that *did* land on an actual
        // button was already returned above — this is only reached for
        // taps that missed every one of them.
        // BUG FIX (an earlier pass): while Stretch to Fit is on,
        // gameScreenRect is a fixed box — the full screen, (0,0,sw,sh) as
        // of this pass, see updateGameMatrix() — recomputed every frame
        // from the screen size alone. Letting it be "selected" here used
        // to let SIZE+/SIZE- silently edit a customLayout entry that mode
        // never even reads, which looked like the size controls had just
        // stopped doing anything. Nothing useful to drag/resize while the
        // box is pinned to the full screen, so it's skipped entirely until
        // Stretch to Fit is turned back off.
        if (!stretchToFit && gameScreenRect.contains(x, y)) return "gamescreen"
        return null
    }

    private fun enterEditMode() {
        if (!romLoaded) {
            uiToast("Load a ROM first — the editor previews live over the running game")
            return
        }
        editModeActive = true
        editSelectedId = null
        clearPointerState()  // else the finger that opened the editor stays "stuck" in
        currentKeys.set(0)   // pointerKeys and comes back held the instant the editor closes
        turboAHeld = false; turboBHeld = false
        editTopBar.visibility = View.VISIBLE
        editButtonBar.visibility = View.GONE
        uiToast("Drag to move • corner dot to resize • hold to remove")
    }

    private fun exitEditMode(save: Boolean) {
        editModeActive = false
        editSelectedId = null
        editDragPointerId = -1
        editResizing = false
        cancelEditLongPress()
        editTopBar.visibility = View.GONE
        editButtonBar.visibility = View.GONE
        if (save) { saveCustomLayout(); uiToast("Layout saved") }
        else { loadCustomLayout(); uiToast("Changes discarded") }
        buildControlLayout(lastSw, lastSh)
    }

    private fun confirmResetAllLayout() {
        AlertDialog.Builder(this)
            .setTitle("Reset layout?")
            .setMessage("This clears every custom position/size for this orientation, brings back any removed controls, and clears any extra controls you've added. You can still Cancel afterward to undo.")
            .setPositiveButton("Reset") { _, _ ->
                customLayout.clear()
                removedButtons.clear()
                addedExtraButtons.clear()
                editDirty = true
                editSelectedId = null
                editButtonBar.visibility = View.GONE
                buildControlLayout(lastSw, lastSh)
                uiToast("Reset — tap Done to save, or Cancel to undo")
            }
            .setNegativeButton("Keep", null)
            .show()
    }

    private fun resetSingleButton(id: String) {
        customLayout.remove(id)
        editDirty = true
        // The sliders show a live value now (the old "-"/"+" chips didn't),
        // so a Reset needs to refresh them back to the default too, or
        // they'd keep showing whatever was selected right before the reset.
        //
        // FIX (this pass): that sync now runs BEFORE rebuilding/
        // repositioning, not after. Reset can also flip a locked control
        // back to unlocked, which changes editLockBtn's text ("Locked" ->
        // the wider "Unlocked") — syncing too late meant the toolbar got
        // measured+positioned for the shorter label it had *before* this
        // call, so the wider one (applied a moment later, but never
        // re-clamped against) could spill past where it was just placed.
        // buildControlLayout() below already repositions the toolbar
        // itself once editModeActive (see its own trailing
        // refreshEditToolbarPosition() call), so the old explicit call
        // after it was also just dead weight.
        syncEditButtonBarToSelection()
        buildControlLayout(lastSw, lastSh)
    }

    // ── Control Size / Control Opacity — percent ↔ stored-unit conversion ──
    // FIX (this pass): the old "-"/"+" chips only ever nudged by a fixed
    // step (adjustSelectedScale()/adjustSelectedAlpha(), both replaced this
    // pass), so they never needed to convert *to* a display unit — only
    // ever read/wrote the stored float scale or raw alpha byte directly.
    // The new slider (sliderRow() in SharedUi.kt) shows and accepts a
    // plain percent either way — matching the direct report ("a slider
    // with number or percent") — so conversion happens here, both
    // directions, each used by exactly one function below.

    /** Opacity percent (0-100, what the slider and its typed-value dialog
     *  show/accept) ↔ the raw alpha byte (60-255) LayoutEntry.alphaOverride
     *  actually stores. percentToAlpha() re-clamps to [60, 255] regardless
     *  of the percent passed in — the same floor adjustSelectedAlpha()
     *  always enforced (a control can be dimmed a lot, never made fully
     *  invisible/undiscoverable) — so it still holds even for a value a
     *  rounding hair below the slider's own displayed minimum. */
    private fun alphaToPercent(alpha: Int): Int = (alpha * 100) / 255
    private fun percentToAlpha(percent: Int): Int = (percent * 255 / 100).coerceIn(60, 255)

    /** Pure reads for the sliders' own display — deliberately plain map
     *  lookups, not entryFor(id): simply *selecting* a control (to look
     *  at, not yet to change) should never create a customLayout override
     *  as a side effect the way entryFor()'s getOrPut would. */
    private fun currentScalePercent(id: String): Int =
        ((customLayout[id]?.scale ?: 1f) * 100).roundToInt()
    private fun currentAlphaPercent(id: String): Int =
        alphaToPercent(customLayout[id]?.alphaOverride?.takeIf { it >= 0 } ?: buttonBaseAlpha)
    private fun isSelectedLocked(id: String): Boolean = customLayout[id]?.locked == true

    /** Sets the selected control's size directly to [percent] (50-800,
     *  matching the slider's own range) — replaces the old delta-based
     *  adjustSelectedScale() now that a real slider (drag, or type an
     *  exact number) replaced the "-"/"+" chip pair. Same 0.5x-8.0x clamp
     *  as before, for the same reason: still a real, finite ceiling rather
     *  than none at all, just far enough out it should be a rare,
     *  deliberate choice rather than a wall anyone runs into. */
    private fun setSelectedScalePercent(percent: Int) {
        val id = editSelectedId ?: return
        val e = entryFor(id)
        if (e.locked) { uiToast("Unlock this control first"); return }
        e.scale = (percent / 100f).coerceIn(0.5f, 8.0f)
        editDirty = true
        // buildControlLayout() already repositions the toolbar itself once
        // editModeActive (see its own trailing refreshEditToolbarPosition()
        // call) — the separate call this used to make right after was
        // redundant (harmless here, but see resetSingleButton() just above
        // for a case where the same redundant-call pattern actually mattered).
        buildControlLayout(lastSw, lastSh)
    }

    /** Sets the selected control's opacity directly to [percent] —
     *  replaces the old delta-based adjustSelectedAlpha(). */
    private fun setSelectedAlphaPercent(percent: Int) {
        val id = editSelectedId ?: return
        val e = entryFor(id)
        if (e.locked) { uiToast("Unlock this control first"); return }
        e.alphaOverride = percentToAlpha(percent)
        editDirty = true
    }

    private fun toggleSelectedLock() {
        val id = editSelectedId ?: return
        val e = entryFor(id)
        e.locked = !e.locked
        editDirty = true
        syncEditButtonBarToSelection()
    }

    /** Refreshes every part of the per-item editor bar that depends on
     *  which control is selected and that control's own live state — label
     *  text (including the "Game Screen Size"/"Control Size" swap),
     *  Locked/Unlocked text, the opacity row's visibility (hidden for the
     *  game screen — see editOpacityRow's own field comment), and both
     *  sliders' position/enabled state.
     *
     *  FIX (this pass): folds in what used to be
     *  updateEditButtonBarLockIcon() (deleted — this is its one caller's
     *  replacement too) plus onEditTouch's own inline label/visibility
     *  lines — one place instead of three, and specifically the one that
     *  now needs to run after Reset and the lock toggle too, now that the
     *  sliders show a live value those two can change out from under them
     *  (the old chips had no live value that could ever go stale). Does
     *  nothing if nothing is selected. */
    private fun syncEditButtonBarToSelection() {
        val id = editSelectedId ?: return
        editButtonLabel.text = labelFor(id)
        editSizeLabel.text = if (id == "gamescreen") "Game Screen Size" else "Control Size"
        editOpacityRow.visibility = if (id == "gamescreen") View.GONE else View.VISIBLE
        val locked = isSelectedLocked(id)
        editLockBtn.text = if (locked) "Locked" else "Unlocked"
        editSizeSlider.setValue(currentScalePercent(id))
        editSizeSlider.setEnabled(!locked)
        if (id != "gamescreen") {
            editOpacitySlider.setValue(currentAlphaPercent(id))
            editOpacitySlider.setEnabled(!locked)
        }
    }

    /** Repositions the per-button toolbar just above (or below, if that
     *  would collide with the top bar) the currently selected control.
     *
     *  FIX (an earlier pass — direct report: the popup "sometimes it get
     *  cut off its weird"): used to read editButtonBar.width/.height
     *  straight off the view — only accurate *after* a layout pass had
     *  actually measured it at its current content, which changes size
     *  every time a different control gets selected (see
     *  syncEditButtonBarToSelection() above: the opacity row alone can
     *  appear/disappear) — deferred via .post{} to try to land after that
     *  pass, with 480/110 as a guessed fallback for whenever it didn't.
     *  Calling measure() directly (still done below) sidesteps that race
     *  entirely: safe any time, no fallback guess left to be wrong, no
     *  post{} delay before the bar lands in the right place.
     *
     *  FIX (an earlier pass — same direct report, still reproducible after
     *  the above): the clamp was only ever as good as its margin, and that
     *  margin used to be a bare `4f`/`12f` inline — four and twelve *raw
     *  pixels*, sub-1dp and ~4dp respectively on anything past ~mdpi. Not a
     *  real margin, which is exactly what read as "cut off": dragging a
     *  control into a corner clamped the bar flush against the screen edge
     *  with no visible gap at all, even though w/h were already accurate
     *  and nothing was technically clipped. Same raw-px-vs-dp mistake
     *  resizeHandleTouchRadius() had; fixed the same way, via the named dp
     *  constants in the companion object and the shared clampToScreenAxis()
     *  helper (next to clampRectToScreen()) instead of two hand-rolled
     *  coerceIn() calls for tx/ty.
     *
     *  FIX (this pass — same direct report yet again: "still cut off
     *  specially if you move the button at the bottom of the screen"):
     *  both fixes above are still in effect and still correct, but neither
     *  one actually finished the job. measure() computes accurate w/h —
     *  fine for the tx/ty math right below it — but measure() alone never
     *  lays editButtonBar's children out at those sizes; that still only
     *  happens on Android's own next layout pass, scheduled asynchronously
     *  off the visibility flip in onEditTouch, i.e. the exact same
     *  "accurate only after a layout pass has run" race the very first fix
     *  above already named, just moved one step later instead of actually
     *  closed. A single tap-to-select usually has a frame of slack before
     *  anything's drawn, so that pass lands in time and looks fine — which
     *  is exactly why this kept slipping past testing. A resize/move drag
     *  calls this function on every ACTION_MOVE tick, competing with that
     *  same pending pass far more often, and whatever frame actually got
     *  drawn could still be showing editRow2/editOpacityRow laid out at an
     *  earlier, smaller state (or not laid out at all yet) — on screen,
     *  that reads as only row 1 rendering and the rest "cut off", worse
     *  the longer/more actively a control near an edge gets dragged.
     *  layout() below forces that pass to happen right here, synchronously,
     *  against the exact sizes just measured, so editButtonBar's own
     *  children can never lag a frame behind the number this function
     *  already computed.
     *
     *  FIX (this pass — same direct report yet again: "still get cut off
     *  if you move button down"): all three fixes above are still correct
     *  and still in effect, but none of them ever touched the actual
     *  placement *decision* — only how accurately w/h got measured before
     *  it. That decision was a one-sided threshold: "does placing the bar
     *  above the control get too close to the top bar?" It never asked the
     *  other half of the question — how much room *below* actually had —
     *  so a control dragged low enough that "above" barely cleared that
     *  one threshold still got the above placement even when below would
     *  have had far more room to give, and on this app's normal landscape
     *  orientation (a short screen) that's exactly the configuration where
     *  the trailing clampToScreenAxis() call had the least slack left to
     *  work with, reading on screen as the bar's own bottom rows running
     *  out of room. Replaced with an explicit comparison of the real room
     *  on both sides — whichever side has more wins, "above" kept as the
     *  tiebreak so a normal, comfortably-placed control looks unchanged —
     *  plus a hard coerceAtLeast(topBound) after the usual clamp, so the
     *  bar can never end up above the top bar even in the one remaining
     *  case (topBound+h doesn't fit below lastSh at all) neither placement
     *  choice can fully solve. Shrinking the panel itself this same pass
     *  (EDIT_TOOLBAR_ROW_GAP_DP/_SLIDER_WIDTH_DP here, SharedUi.kt's
     *  EDIT_TOOLBAR_VALUE_BOX_* for the readout boxes) is the other half
     *  of this fix — a smaller h/w makes that one remaining case
     *  correspondingly harder to ever reach on a real device.
     *
     *  FIX (pass 43 — same direct report yet again: "if you move it
     *  sometimes it disappears or get cutoff"): the fix directly above
     *  already named this gap by exact name ("the one remaining case
     *  (topBound+h doesn't fit below lastSh at all)") but only ever
     *  documented it, never closed it — clampToScreenAxis() provably
     *  keeps clampedTy within [margin, lastSh-h-margin] (see that
     *  function's own doc comment), but the trailing
     *  .coerceAtLeast(topBound) ran *after* that guarantee as a second,
     *  independent floor with no ceiling of its own, so on a short enough
     *  effective screen — a small/older phone in this app's normal
     *  landscape orientation, or a resizable/multi-window session,
     *  nothing exotic — topBound can legitimately exceed
     *  lastSh-h-margin, and coerceAtLeast doesn't know that: it pushes
     *  clampedTy up past the ceiling clampToScreenAxis() just
     *  established, out the bottom of the screen. That's "disappears" at
     *  the extreme (genuinely off-screen) and "get cutoff" for a milder
     *  overshoot — the same root cause either way. "If you move it" was
     *  never a coincidence: dragging low enough for roomBelow to shrink
     *  toward zero is exactly what lands ty in the branch this affects.
     *  Fixed below by making topBound a *preference* clamped alongside
     *  everything else in one coerceIn, not an independent floor applied
     *  after the fact — see the inline comment at the fix itself.
     *
     *  FIX (this pass — same direct report a fifth time): the clamp math
     *  itself, as of pass 43 directly above, is sound — every input it's
     *  given provably stays within bounds. What wasn't sound was one of
     *  those inputs: topBound read editTopBar.height alone, but editTopBar
     *  is wrapped in editTopBarScroll (a HorizontalScrollView, added so
     *  the row degrades to scrollable instead of clipping — see its own
     *  construction site) which is what's actually positioned in root with
     *  its own topMargin, a margin topBound never accounted for at all.
     *  That margin was *also* raw pixels rather than dp (editTopBarScroll's
     *  own fix, right where it's built) — on a high-density phone, small
     *  on its own, but compounding with topBound's separate blind spot to
     *  feed the exact same downstream clamp four previous fix attempts
     *  each re-tuned without ever checking. topBound now reads
     *  editTopBarScroll's own height plus the same margin constant that
     *  wrapper's topMargin actually uses (below), instead of the unwrapped
     *  child and an implicit assumption of zero. */
    private fun refreshEditToolbarPosition() {
        val id = editSelectedId ?: return
        val rect = editRectFor(id) ?: return
        editButtonBar.measure(
            View.MeasureSpec.makeMeasureSpec(lastSw.toInt().coerceAtLeast(1), View.MeasureSpec.AT_MOST),
            View.MeasureSpec.makeMeasureSpec(lastSh.toInt().coerceAtLeast(1), View.MeasureSpec.AT_MOST)
        )
        val w = editButtonBar.measuredWidth
        val h = editButtonBar.measuredHeight
        // See "this pass" above: measure() alone doesn't lay children out —
        // this does, synchronously, right now, against w/h. (0,0,w,h) is a
        // local/pre-translation rect, not a screen position; .x/.y below
        // (translation, applied on top of whatever left/top layout() just
        // set) is still what actually places the bar on screen, unchanged
        // from before.
        editButtonBar.layout(0, 0, w, h)
        val gap = dp(EDIT_TOOLBAR_GAP_DP).toFloat()
        val margin = dp(EDIT_TOOLBAR_SCREEN_MARGIN_DP).toFloat()
        // The bar must never render above this line on either side. Reads
        // editTopBarScroll — the actual view positioned in root, margin
        // and all — not editTopBar, the child it wraps (see this pass's
        // fix in the doc comment above): margin is the exact same
        // dp(EDIT_TOOLBAR_SCREEN_MARGIN_DP) editTopBarScroll's own
        // topMargin uses at its construction site, so this can never
        // silently drift out of sync with the real view again the way
        // editTopBar.height alone did.
        val topBound = margin + editTopBarScroll.height + gap
        val roomAbove = rect.top - gap - topBound
        val roomBelow = (lastSh - margin) - (rect.bottom + gap)
        // The actual fix: compare both sides instead of only ever checking
        // "does above avoid the top bar?". Above wins ties so an unmoved/
        // centered control is positioned exactly as before.
        val ty = if (roomAbove >= h || roomAbove >= roomBelow) {
            rect.top - h - gap
        } else {
            rect.bottom + gap
        }
        val tx = clampToScreenAxis(rect.centerX() - w / 2f, w.toFloat(), lastSw, margin)
        // FIX (pass 43): topBound is now honored only when there's room to
        // do so without ever pushing the bar past the bottom of the
        // screen (topBound <= maxTy) — otherwise this falls back to the
        // screen's own top margin instead, trading "the bar might touch
        // the top bar's own strip" (still fully visible and usable) for
        // "the bar might run off the bottom of the screen" (not visible
        // or usable at all). One coerceIn, not clamp-then-separately-
        // floor, so the result can never land outside [minTy, maxTy]
        // regardless of how topBound/h/lastSh relate to each other —
        // minTy <= maxTy always holds since maxTy is itself never below
        // margin, and minTy is only ever topBound when topBound already
        // fits under that same maxTy. See this function's own doc
        // comment for the full reasoning/report this closes.
        val maxTy = (lastSh - h - margin).coerceAtLeast(margin)
        val minTy = if (topBound <= maxTy) topBound else margin
        val clampedTy = ty.coerceIn(minTy, maxTy)
        editButtonBar.x = tx
        editButtonBar.y = clampedTy
    }

    private fun onEditTouch(event: MotionEvent) {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val x = event.x; val y = event.y
                val hitId = hitTestEditable(x, y)
                if (hitId == null) {
                    editSelectedId = null
                    editButtonBar.visibility = View.GONE
                    return
                }
                editSelectedId = hitId
                editDragPointerId = event.getPointerId(0)
                editDownX = x; editDownY = y
                val rect = editRectFor(hitId) ?: return
                // BUG FIX: was resizeHandleRadius(rect) * 1.6f — a tiny,
                // non-dp-aware radius (see resizeHandleTouchRadius's own
                // comment for the full root-cause). This is the down-time
                // decision for "did this touch grab the resize handle", now
                // using the same generous, density-aware radius that
                // hitTestEditable() uses to even let the touch reach here.
                val handleR = resizeHandleTouchRadius(rect)
                editResizing = dist(x, y, rect.right, rect.bottom) <= handleR
                if (editResizing) {
                    editResizeStartDist = dist(x, y, rect.centerX(), rect.centerY()).coerceAtLeast(1f)
                    editResizeStartScale = customLayout[hitId]?.scale ?: 1f
                } else {
                    editDragOffX = x - rect.centerX()
                    editDragOffY = y - rect.centerY()
                    // ADD/REMOVE CONTROL — hold-to-remove: armed only for a
                    // plain grab (not a resize-grab, so holding the corner
                    // handle still just resizes). Cancelled by real movement
                    // (ACTION_MOVE below) or the finger lifting first.
                    val pressedId = hitId
                    val longPress = Runnable {
                        if (editSelectedId == pressedId && editDragPointerId != -1) {
                            editLongPressPending = null
                            editDragPointerId = -1   // gesture is now "consumed" by the menu, not a drag
                            showRemoveButtonMenu(pressedId)
                        }
                    }
                    editLongPressPending = longPress
                    mainHandler.postDelayed(longPress, ViewConfiguration.getLongPressTimeout().toLong())
                }
                // CUSTOMIZATION UI: label text, "Game Screen Size" vs
                // "Control Size", opacity-row visibility, lock text, and
                // both sliders — everything that depends on which control
                // is now selected — all come from one place; see that
                // function's own comment for why.
                syncEditButtonBarToSelection()
                editButtonBar.visibility = View.VISIBLE
                refreshEditToolbarPosition()
            }
            MotionEvent.ACTION_MOVE -> {
                val id = editSelectedId ?: return
                // BUG FIX (this pass): gameScreenRect is a fixed box while
                // Stretch to Fit is on (see updateGameMatrix()) — it can
                // still be *selected* here if it was selected before
                // Settings > Video > Stretch to Fit got toggled on without
                // leaving the editor first, but dragging/resizing it any
                // further would only edit a customLayout entry that mode
                // never reads. hitTestEditable() already stops it from
                // being newly selected while stretched; this stops that
                // one narrow leftover path too.
                if (id == "gamescreen" && stretchToFit) return
                val ptr = event.findPointerIndex(editDragPointerId)
                if (ptr < 0) return
                val e = entryFor(id)
                if (e.locked) return
                val x = event.getX(ptr); val y = event.getY(ptr)
                if (editLongPressPending != null && dist(x, y, editDownX, editDownY) > editTouchSlop) {
                    cancelEditLongPress()
                }
                if (editResizing) {
                    val c = editRectFor(id)
                    val d = dist(x, y, c?.centerX() ?: x, c?.centerY() ?: y)
                    // Matches setSelectedScalePercent()'s own cap above —
                    // see its comment for why 8x, not the old 2.5x/4x.
                    var newScale = (editResizeStartScale * (d / editResizeStartDist)).coerceIn(0.5f, 8.0f)
                    // GRID: snap AFTER computing the raw scale, so the
                    // stored value is always exactly on-grid when enabled
                    // — never "close" to a grid line, see
                    // snapScaleToGrid()'s own comment for why width is the
                    // single source of truth here.
                    if (snapToGrid) newScale = snapScaleToGrid(id, newScale)
                    e.scale = newScale
                    // FIX (this pass): the Control Size slider needs to
                    // track this corner-drag gesture too, not just its own
                    // drag — otherwise it'd show a stale value the instant
                    // this *other* resize gesture changes e.scale out from
                    // under it. Only the size slider (not a full
                    // syncEditButtonBarToSelection()) since that's the only
                    // thing this particular gesture can change, and this
                    // runs on every ACTION_MOVE tick.
                    editSizeSlider.setValue(currentScalePercent(id))
                } else {
                    var cx = (x - editDragOffX).coerceIn(lastSw * 0.03f, lastSw * 0.97f)
                    var cy = (y - editDragOffY).coerceIn(lastSh * 0.03f, lastSh * 0.97f)
                    // GRID: snap AFTER the existing on-screen clamp (not
                    // before) so snapping is always the last word on the
                    // final position — clamping a snapped point could
                    // nudge it back off-grid, snapping a clamped point
                    // never does.
                    if (snapToGrid) {
                        cx = snapPositionToGrid(cx)
                        cy = snapPositionToGrid(cy)
                    }
                    e.xFrac = cx / lastSw.coerceAtLeast(1f)
                    e.yFrac = cy / lastSh.coerceAtLeast(1f)
                }
                editDirty = true
                buildControlLayout(lastSw, lastSh)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                if (event.getPointerId(event.actionIndex) == editDragPointerId) {
                    cancelEditLongPress()
                    editDragPointerId = -1
                    editResizing = false
                }
            }
            MotionEvent.ACTION_CANCEL -> {
                cancelEditLongPress()
                editDragPointerId = -1
                editResizing = false
            }
        }
    }

    private fun cancelEditLongPress() {
        editLongPressPending?.let { mainHandler.removeCallbacks(it) }
        editLongPressPending = null
    }

    /** Hold-to-remove popup — shown when [id]'s long-press timer fires in
     *  onEditTouch(). Deliberately a single tap-to-confirm action rather
     *  than a second confirmation dialog: removal is already low-stakes
     *  since "Add Control" (showAddControlMenu) and Cancel both undo it. */
    private fun showRemoveButtonMenu(id: String) {
        // "gamescreen" isn't a real, removable control the way every other
        // id here is — there's nothing sensible "remove the game screen"
        // would even mean. Guarded here rather than at the long-press
        // arming site so this stays the one choke point regardless of what
        // ends up calling it.
        if (editSelectedId != id || id == "gamescreen") return
        val dialog = AlertDialog.Builder(this)
            .setItems(arrayOf("Remove ${labelFor(id)}")) { _, _ -> removeButton(id) }
            .setNegativeButton("Cancel", null)
            .create()
        dialog.window?.setBackgroundDrawable(roundedDialogBackground())
        dialog.show()
    }

    private fun removeButton(id: String) {
        if (id in extraControlIds) addedExtraButtons.remove(id) else removedButtons.add(id)
        if (editSelectedId == id) {
            editSelectedId = null
            editButtonBar.visibility = View.GONE
        }
        editDirty = true
        buildControlLayout(lastSw, lastSh)
        uiToast("${labelFor(id)} removed — tap Add Control to bring it back")
    }

    /** Every button id the editor knows how to draw — the source list for
     *  "+ Add control" (showAddControlMenu). extraControlIds (Turbo A/B,
     *  the shoulder/A-B combos, and the quick save/load/screenshot
     *  actions) are always listed here — each is independently opt-in via
     *  this same per-button add/remove system, with nothing else that has
     *  to be enabled first for any of them to work.
     *
     *  FIX (stale-comment cleanup, this pass): this used to say Turbo A/B
     *  only counted as "addable" while a separate Turbo setting (⚙
     *  Settings → Input) was on. PREF_TURBO was removed a previous pass —
     *  see the comment where extraControlIds is declared — and Turbo A/B
     *  moved into this exact opt-in-per-button system alongside everything
     *  else here; ta/tb work exactly like any other extraControlIds entry
     *  now, no separate gate left to describe. */
    private fun allControlIds(): List<String> {
        val ids = mutableListOf("dpad", "a", "b", "select", "start", "l", "r", "ff")
        ids += extraControlIds
        return ids
    }

    private fun showAddControlMenu() {
        val hidden = allControlIds().filter { !isButtonVisible(it) }
        if (hidden.isEmpty()) { uiToast("Every control is already on screen"); return }
        val labels = hidden.map { labelFor(it) }.toTypedArray()
        val dialog = AlertDialog.Builder(this)
            .setTitle("Add control")
            .setItems(labels) { _, which ->
                val id = hidden[which]
                if (id in extraControlIds) addedExtraButtons.add(id) else removedButtons.remove(id)
                editDirty = true
                buildControlLayout(lastSw, lastSh)
                uiToast("${labelFor(id)} added")
            }
            .setNegativeButton("Cancel", null)
            .create()
        dialog.window?.setBackgroundDrawable(roundedDialogBackground())
        dialog.show()
    }

    /** Grid Size / Show Grid / Snap to Grid — reached from the "Grid" chip
     *  on the editor's own top bar (see editTopBar in onCreate) rather
     *  than buried in the Settings screens, since none of it means
     *  anything outside the editor. Same Save/Cancel shape as
     *  showLayoutsSettings() just below — applies together on Save,
     *  consistent with every other multi-control popup in this app.
     *  Grid Size offers presets rather than free-entry, matching the
     *  request directly ("Example: 4×4, 8×8, 16×16") and every other
     *  size-like setting in this app (Button size, Button opacity), which
     *  are already presets, not free text fields, for the same reason. */
    private fun showGridSettingsDialog() {
        val ctx = this
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val layout = ctx.dialogContentLayout()

        layout.addView(TextView(ctx).apply {
            text = "Grid Size"; textSize = 12f; setTextColor(Color.WHITE)
        })
        // FIX (Fortieth pass): 64 added (was capped at 32 — "add more like
        // 60 not just 30", direct request) and labels are now the bare
        // number instead of "N×N" — cells are square (gridCellPx()), so an
        // N×N label would claim N columns AND N rows, which stopped being
        // true the moment the cell size started coming from just the
        // shorter dimension. The description text below spells out what
        // the number actually means instead.
        val gridOptions = listOf(4, 8, 16, 32, 64)
        val gridRadio = dlgRadioGroup(horizontal = false)
        gridOptions.forEach { n -> gridRadio.dlgAddOpt("$n") }
        val curGridIdx = gridOptions.indexOf(gridDivisions).takeIf { it >= 0 } ?: 1
        (gridRadio.getChildAt(curGridIdx) as RadioButton).isChecked = true
        layout.addView(gridRadio)

        val showGridCheck = CheckBox(ctx).apply {
            text = "Show Grid"
            isChecked = showGrid
            setTextColor(Color.WHITE)
            setPadding(0, dp(24), 0, 0)
        }
        layout.addView(showGridCheck)

        val snapGridCheck = CheckBox(ctx).apply {
            text = "Snap to Grid"
            isChecked = snapToGrid
            setTextColor(Color.WHITE)
            setPadding(0, dp(8), 0, 0)
        }
        layout.addView(snapGridCheck)

        layout.addView(TextView(ctx).apply {
            text = "Aligns buttons and the game screen while customizing. Doesn't change the actual gameplay display. " +
                "Cells are always square — the number is how many fit across the shorter side of the screen."
            textSize = 11f; setTextColor(Color.parseColor("#888892"))
            setPadding(0, dp(16), 0, 0)
        })

        AlertDialog.Builder(ctx)
            .setTitle("Grid Settings")
            .setView(ScrollView(ctx).also { it.addView(layout) })
            .setPositiveButton("Save") { _, _ ->
                val selIdx = (0 until gridRadio.childCount)
                    .firstOrNull { (gridRadio.getChildAt(it) as RadioButton).isChecked } ?: curGridIdx
                gridDivisions = gridOptions[selIdx]
                showGrid   = showGridCheck.isChecked
                snapToGrid = snapGridCheck.isChecked
                prefs.edit()
                    .putInt(PREF_GRID_SIZE, gridDivisions)
                    .putBoolean(PREF_SHOW_GRID, showGrid)
                    .putBoolean(PREF_SNAP_GRID, snapToGrid)
                    .apply()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private val editHighlightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 4f; color = Color.parseColor("#FFEE58")
    }
    private val editHandlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL; color = Color.parseColor("#FFEE58")
    }
    private val editDimPaint = Paint().apply { color = Color.parseColor("#22000000") }
    private val gridLinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 2f; color = Color.parseColor("#33FFFFFF")
    }

    /** Draws the alignment grid — gridDivisions square cells across the
     *  shorter screen dimension, see gridCellPx() — over the whole screen.
     *  Purely a rendering aid — reads only gridDivisions/showGrid (via
     *  gridCellPx()/lastSw/lastSh), never writes anything, so it can never
     *  itself change what's actually saved for any control. Independent of
     *  editSelectedId on purpose: "visible while customizing if enabled"
     *  means visible any time the editor is open, not just while something
     *  is selected. FIX (Fortieth pass): draws lines a fixed cell-size
     *  apart instead of exactly N lines spanning the width and N spanning
     *  the height — see gridCellPx()'s own comment for why that's what
     *  makes the cells square instead of a w/N-by-h/N rectangle. */
    private fun drawGrid(canvas: Canvas) {
        if (!showGrid) return
        val cell = gridCellPx()
        if (cell <= 0f) return
        val w = canvas.width.toFloat(); val h = canvas.height.toFloat()
        var x = cell
        while (x < w) { canvas.drawLine(x, 0f, x, h, gridLinePaint); x += cell }
        var y = cell
        while (y < h) { canvas.drawLine(0f, y, w, y, gridLinePaint); y += cell }
    }

    private fun drawEditOverlay(canvas: Canvas) {
        canvas.drawRect(0f, 0f, canvas.width.toFloat(), canvas.height.toFloat(), editDimPaint)
        drawGrid(canvas)
        val id = editSelectedId ?: return
        val rect = editRectFor(id) ?: return
        canvas.drawRoundRect(rect, 12f, 12f, editHighlightPaint)
        canvas.drawCircle(rect.right, rect.bottom, resizeHandleRadius(rect), editHandlePaint)
    }

    // ── Settings screen ────────────────────────────────────────────────────
    //
    // RESKIN: the old single scrolling dialog is now a full-screen category
    // list — Video / Audio / Input / Layouts / Misc / Advanced / About —
    // matching the requested reference layout. Every setting that existed
    // before still exists, just regrouped:
    //   Video    — game screen size, fullscreen              (was GAME SCREEN)
    //   Audio    — button click sound
    //   Input    — the drag/resize button-layout editor
    //   Layouts  — button size, button opacity                (was CONTROLS)
    //   Misc     — fast-forward speed                         (was EMULATION)
    //   Advanced — reset all settings to defaults (new — nothing else in
    //              this app currently qualifies as "advanced")
    //   About    — app name / version (new)
    //
    // Link remote / Link local were added later, moved here from floating
    // buttons that used to sit on top of the game view (📂 top-right, 🔗
    // top-right) — see the comment in onCreate where settingsBtn is built.
    // Link remote is the Wi-Fi flow, Link local is Bluetooth; both used to
    // live behind one combined dialog, now split into their own rows to
    // match. Nothing about the underlying connect logic changed (see
    // showLinkRemoteDialog()/showLinkLocalDialog()). Both rows are also on
    // the quick game menu now for a faster path to the same actions (see
    // showGameMenu()) — harmless to leave duplicated here too.
    //
    // REMOVED: the Change ROM and Save States rows. changeRom() now lives
    // only on the initial "▶ Load ROM" button, and on Close, which now goes
    // straight to ROM selection itself rather than just that button (see
    // the BUG FIX comment on closeGame()). Save/Load moved to the quick
    // game menu's own rows, which already called showSaveStateSlotDialog()
    // directly rather than through this screen's old showSaveStateMenu()
    // — that function is now unused; left in place rather than deleted in
    // case it's wanted back.
    //
    // settingsMenuOverlay itself is built once in onCreate and just shown/
    // hidden (see buildSettingsMenu()) — it has no dynamic state of its own.
    // Each category still opens as an AlertDialog exactly like the old
    // settings screen did, rebuilding its fields fresh every time it's
    // opened, so Save/Cancel behaves exactly as before; dismissing that
    // dialog reveals the category list again underneath.

    // dp() and iconChipBackground() moved to SharedUi.kt this pass (Thirty-
    // second) as Context extension functions — RomBrowserActivity needs
    // them too, and every call site here (dp(20), iconChipBackground(), ...)
    // keeps working unchanged since both are in the same package.

    // ── Memory viewer ─────────────────────────────────────────────────────

    private data class MemRegion(val label: String, val base: Int, val size: Int)

    // Standard GBA memory map — fixed by the hardware, not this app; the
    // same addresses any GBA devkit/emulator/disassembler uses. EWRAM
    // listed first/default since that's where most games, Pokémon
    // included, keep the bulk of their live state (party data, battle
    // structs, etc.) — IWRAM is smaller and mostly used for hot/
    // performance-critical data, less likely to be what's actually being
    // looked for here.
    private val memRegions = listOf(
        MemRegion("EWRAM",   0x02000000, 0x40000),
        MemRegion("IWRAM",   0x03000000, 0x8000),
        MemRegion("Palette", 0x05000000, 0x400),
        MemRegion("VRAM",    0x06000000, 0x18000),
        MemRegion("OAM",     0x07000000, 0x400)
    )
    // 32 rows of 16 bytes — fits one screen without scrolling on most
    // phones at the dump's text size, without paging through hundreds of
    // screens to cross a 256KB region like EWRAM one page at a time.
    private val memoryPageBytes = 512
    private val memoryRefreshMs = 500L

    /** Shows the live memory viewer overlay — read-only inspection of the
     *  running core's RAM, requested for watching game state (a Pokémon
     *  battle's HP/party data was the specific example) change turn by
     *  turn. Values are read through mCore's own busRead8() (see
     *  nativeReadMemory() in mgba_jni.c) — the same bus mGBA's own cheat
     *  system reads through — rather than a raw pointer into EWRAM/IWRAM
     *  specifically, so every region (I/O registers, palette, VRAM, OAM,
     *  even ROM) works through one path instead of needing one per region.
     *
     *  Read-only for now, deliberately: "inspect live RAM" is what was
     *  asked for. Writing to memory (poking values — an actual cheat/edit
     *  tool) is a natural next step from here — a busWrite8() counterpart
     *  to nativeReadMemory() would be a small, symmetric addition — but is
     *  a materially different feature (anything that changes game state
     *  deserves its own explicit ask rather than riding along with
     *  "inspect"), so it's not included here.
     *
     *  Does not stop the game loop (see the field-block comment above
     *  where memoryViewerOverlay is declared) — gameplay keeps running
     *  underneath while this is open, and a self-rescheduling
     *  Handler.postDelayed() loop (see scheduleMemoryRefresh()) keeps the
     *  dump current every memoryRefreshMs while the overlay stays visible. */
    private fun showMemoryViewer() {
        memoryRegionIndex = 0
        memoryPageOffset = 0
        memoryViewerOverlay.visibility = View.VISIBLE
        refreshMemoryDump()
        scheduleMemoryRefresh()
    }

    private fun hideMemoryViewer() {
        memoryViewerOverlay.visibility = View.GONE
    }

    private fun scheduleMemoryRefresh() {
        mainHandler.postDelayed({
            if (isFinishing || isDestroyed) return@postDelayed
            if (memoryViewerOverlay.visibility != View.VISIBLE) return@postDelayed
            refreshMemoryDump()
            scheduleMemoryRefresh()
        }, memoryRefreshMs)
    }

    private fun refreshMemoryDump() {
        val region = memRegions[memoryRegionIndex]
        memoryAddressText.text = "%s   0x%08X".format(region.label, region.base + memoryPageOffset)
        if (!romLoaded) { memoryDumpText.text = "Load a ROM first"; return }
        val length = memoryPageBytes.coerceAtMost(region.size - memoryPageOffset)
        if (length <= 0) { memoryDumpText.text = "End of region"; return }
        val address = region.base + memoryPageOffset
        val buf = ByteArray(length)
        val n = EmulatorEngine.nativeReadMemory(address, buf, length)
        memoryDumpText.text = if (n <= 0) "Not available right now" else formatHexDump(address, buf, n)
    }

    /** Classic hex-dump layout: 8-digit address, 16 hex bytes (a mid-row gap
     *  after the 8th, same convention as `hexdump -C`/most hex editors),
     *  then the same 16 bytes as ASCII (printable range 0x20–0x7E, '.' for
     *  everything else). */
    private fun formatHexDump(baseAddress: Int, bytes: ByteArray, length: Int): String {
        val sb = StringBuilder()
        var i = 0
        while (i < length) {
            val rowLen = minOf(16, length - i)
            sb.append(String.format("%08X  ", baseAddress + i))
            for (j in 0 until 16) {
                if (j < rowLen) sb.append(String.format("%02X ", bytes[i + j])) else sb.append("   ")
                if (j == 7) sb.append(' ')
            }
            sb.append(' ')
            for (j in 0 until rowLen) {
                val b = bytes[i + j].toInt() and 0xFF
                sb.append(if (b in 0x20..0x7E) b.toChar() else '.')
            }
            sb.append('\n')
            i += 16
        }
        return sb.toString()
    }

    private fun buildMemoryViewer(): LinearLayout {
        val ctx = this

        val header = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(16), dp(16), dp(14))
            addView(TextView(ctx).apply {
                text = "Memory"; textSize = 22f; typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.WHITE)
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(TextView(ctx).apply {
                text = "✕ Close"; textSize = 13f
                setTextColor(colorAccentLight)
                setPadding(dp(14), dp(8), dp(14), dp(8))
                isClickable = true; isFocusable = true
                background = iconChipBackground()
                setOnClickListener { hideMemoryViewer() }
            })
        }

        // Chip TextViews kept in a list (indexed the same as memRegions) so
        // tapping one can restyle every chip's highlight directly, rather
        // than rebuilding this row (or the whole overlay) from scratch on
        // every tap.
        val regionChips = mutableListOf<TextView>()
        val regionRow = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(16), dp(0), dp(16), dp(10))
            memRegions.forEachIndexed { index, region ->
                val chip = TextView(ctx).apply {
                    text = region.label; textSize = 12f
                    setTextColor(if (index == memoryRegionIndex) Color.WHITE else colorAccentLight)
                    setPadding(dp(10), dp(8), dp(10), dp(8))
                    isClickable = true; isFocusable = true
                    background = iconChipBackground()
                }
                regionChips.add(chip)
                chip.setOnClickListener {
                    memoryRegionIndex = index
                    memoryPageOffset = 0
                    regionChips.forEachIndexed { i, c -> c.setTextColor(if (i == index) Color.WHITE else colorAccentLight) }
                    refreshMemoryDump()
                }
                addView(chip, LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
                ).also { it.rightMargin = dp(8) })
            }
        }

        val pageRow = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(0), dp(20), dp(10))
            addView(TextView(ctx).apply {
                text = "◀"; textSize = 16f
                setTextColor(Color.WHITE)
                setPadding(dp(10), dp(4), dp(20), dp(4))
                isClickable = true; isFocusable = true
                background = iconChipBackground()
                setOnClickListener {
                    memoryPageOffset = (memoryPageOffset - memoryPageBytes).coerceAtLeast(0)
                    refreshMemoryDump()
                }
            })
            memoryAddressText = TextView(ctx).apply {
                textSize = 13f
                typeface = Typeface.MONOSPACE
                setTextColor(colorAccentLight)
            }
            addView(memoryAddressText, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(TextView(ctx).apply {
                text = "▶"; textSize = 16f
                setTextColor(Color.WHITE)
                setPadding(dp(20), dp(4), dp(10), dp(4))
                isClickable = true; isFocusable = true
                background = iconChipBackground()
                setOnClickListener {
                    val region = memRegions[memoryRegionIndex]
                    // FIX: was (region.size - 1).coerceAtLeast(0) — the cap
                    // needs to be the start offset of the *last full page*,
                    // not the last valid *byte*. Every region here
                    // (EWRAM/IWRAM/Palette/VRAM/OAM) is an exact multiple of
                    // memoryPageBytes, so the old cap let one extra tap of ▶
                    // past the last full page land on a degenerate 1-byte
                    // "page" — just the final byte already visible on the
                    // previous page — instead of ▶ simply having nothing
                    // left to do once the last full page is showing.
                    memoryPageOffset = (memoryPageOffset + memoryPageBytes).coerceAtMost(
                        (region.size - memoryPageBytes).coerceAtLeast(0))
                    refreshMemoryDump()
                }
            })
        }

        memoryDumpText = TextView(ctx).apply {
            typeface = Typeface.MONOSPACE
            textSize = 11f
            setTextColor(Color.parseColor("#D8D8DE"))
            setPadding(dp(16), dp(0), dp(16), dp(16))
        }

        val footer = TextView(ctx).apply {
            text = "Read-only — refreshes automatically every ${memoryRefreshMs / 1000.0}s while open"
            textSize = 11f
            setTextColor(Color.parseColor("#888892"))
            setPadding(dp(20), dp(4), dp(20), dp(16))
        }

        return LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#FF17171B"))
            isClickable = true; isFocusable = true
            addView(header)
            addView(View(ctx).apply { setBackgroundColor(Color.parseColor("#22FFFFFF")) },
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1).coerceAtLeast(1)))
            addView(regionRow)
            addView(pageRow)
            addView(ScrollView(ctx).apply { addView(memoryDumpText) },
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
            addView(footer)
        }
    }

    private fun buildSettingsMenu(): LinearLayout {
        val ctx = this

        val header = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(16), dp(16), dp(14))
            addView(TextView(ctx).apply {
                text = "Settings"; textSize = 22f; typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.WHITE)
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(TextView(ctx).apply {
                text = "✕ Close"; textSize = 13f
                setTextColor(colorAccentLight)
                setPadding(dp(14), dp(8), dp(14), dp(8))
                isClickable = true; isFocusable = true
                background = iconChipBackground()
                setOnClickListener { settingsMenuOverlay.visibility = View.GONE }
            })
        }

        val rows = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            addView(settingsRow("🖥", "Video",    "Screen size, orientation & effects") { showVideoSettings() })
            addView(settingsRow("🔊", "Audio",    "Enable sound, volume & frequency")            { showAudioSettings() })
            addView(settingsRow("🕹", "Input",    "Edit on-screen button layout")  { showInputSettings() })
            addView(settingsRow("▦", "Layouts",  "Button size & opacity")         { showLayoutsSettings() })
            addView(settingsRow("👤", "Misc",     "Fast-forward speed")            { showMiscSettings() })
            addView(settingsRow("💾", "Storage",  "Where saves/states/screenshots live") { showStorageSettings() })
            addView(settingsRow("🔗", "Link remote", "Multiplayer over Wi-Fi")     { showLinkRemoteDialog() })
            addView(settingsRow("📶", "Link local",  "Multiplayer over Bluetooth") { showLinkLocalDialog() })
            addView(settingsRow("🎚", "Advanced", "Reset settings to defaults")    { showAdvancedSettings() })
            addView(settingsRow("ℹ️", "About",    "Version & info")                { showAboutDialog() })
        }

        return LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#FF17171B"))
            isClickable = true; isFocusable = true   // swallow touches — nothing behind this should be reachable
            addView(header)
            addView(View(ctx).apply { setBackgroundColor(Color.parseColor("#22FFFFFF")) },
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1).coerceAtLeast(1)))
            // Scrollable: this app is locked to landscape (see onCreate), so
            // available height can be quite short on a lot of phones — eleven
            // rows plus a header can easily exceed that, which would make
            // "About" unreachable without this. (Was seven rows before Change
            // ROM / Link remote / Link local moved in from floating buttons —
            // already scrollable, so they just slot in.)
            addView(ScrollView(ctx).apply { addView(rows) },
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        }
    }

    private fun settingsRow(icon: String, title: String, subtitle: String, onClick: () -> Unit): View {
        val ctx = this
        return LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            isClickable = true; isFocusable = true
            setBackgroundResource(rippleBackgroundResId())
            setPadding(dp(20), dp(14), dp(20), dp(14))
            addView(TextView(ctx).apply {
                text = icon; textSize = 20f
                setTextColor(colorAccentLight)
            }, LinearLayout.LayoutParams(dp(44), LinearLayout.LayoutParams.WRAP_CONTENT))
            addView(LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                addView(TextView(ctx).apply {
                    text = title; textSize = 17f
                    setTextColor(Color.WHITE)
                })
                addView(TextView(ctx).apply {
                    text = subtitle; textSize = 12f
                    setTextColor(Color.parseColor("#888892"))
                    setPadding(0, dp(2), 0, 0)
                })
            })
            setOnClickListener { onClick() }
        }
    }

    private fun showSettingsMenu() {
        settingsMenuOverlay.visibility = View.VISIBLE
    }

    /** Applies the *right* orientation for whatever this activity is doing
     *  right now — not just [screenOrientationChoice] in isolation. Safe to
     *  call any time, not just from onCreate — e.g. showVideoSettings()'s
     *  Save button calls this too, right after persisting a new choice.
     *  android:configChanges in the manifest already keeps this activity
     *  (and the running core) alive across whatever orientation change this
     *  triggers, rather than recreating it.
     *
     *  FIX (this pass — direct report: file browser "still landscape at
     *  first then open and then instantly go portrait"): this used to
     *  apply [screenOrientationChoice] unconditionally, every single time,
     *  including while idle with no ROM loaded — which is also the exact
     *  moment changeRom() launches RomBrowserActivity (onCreate's own first
     *  call below, and again from closeGame() right after backing out of a
     *  game). RomBrowserActivity is Portrait, hard-locked in the manifest
     *  (see its own file-header comment for why that has to stay a
     *  manifest default rather than a runtime call) — so every time this
     *  activity requested Landscape while idle, opening the browser meant
     *  an immediate landscape→portrait rotation of the physical display
     *  *during* that activity transition, which is the flash that was
     *  reported: a real frame or two of RomBrowserActivity's own window
     *  still catching up to its new orientation before it settles.
     *  overridePendingTransition(0,0) (both directions — see changeRom()
     *  below and RomBrowserActivity's finish() override) was already added
     *  last pass and helps with the *transition animation* itself, but
     *  can't fix a rotation that still has to happen at all.
     *
     *  The actual fix: stop treating the file browser and gameplay as
     *  though they share one orientation. [romLoaded] is already the
     *  single source of truth for "is a game actually running" everywhere
     *  else in this class, so it's used the same way here — Portrait while
     *  idle (which now means: cold start in onCreate, and again the moment
     *  closeGame() clears romLoaded, both called *before* changeRom()
     *  runs), and [screenOrientationChoice] only once a ROM is actually
     *  loaded (this is called again right after romLoaded flips true in
     *  the load-success path below). With both this activity and
     *  RomBrowserActivity already agreeing on Portrait by the time the
     *  browser actually launches, there's nothing left for the system to
     *  rotate mid-transition — any landscape↔portrait rotation now happens
     *  once, cleanly, on this activity's own idle screen (always after
     *  stopGameLoop() has already halted rendering — see closeGame() — so
     *  there's never a live SurfaceView draw in flight when it happens),
     *  the same as a user manually turning their phone, not smeared across
     *  an activity launch.
     *
     *  BUG FIX: wrapped in try/catch. setRequestedOrientation() has a known
     *  Android crash — IllegalStateException("Only fullscreen opaque
     *  activities can request orientation") — thrown on API 26+ whenever
     *  the system doesn't currently consider this activity fullscreen (e.g.
     *  split-screen/multi-window/freeform, or some OEM launcher/window
     *  quirks entirely outside this app's control). This call already
     *  existed before the fix (app start, Video settings' Save button),
     *  just rarely enough that this was a latent, never-hit risk; a later
     *  pass temporarily added far more call sites — every ROM browser
     *  open/close/load, back when it forced Portrait for that screen from
     *  right here in this class — which is exactly where a crash "opening
     *  a ROM" started actually showing up. Those extra call sites are gone
     *  now (the ROM browser is RomBrowserActivity, its own Activity,
     *  locked to Portrait statically via the manifest instead of any
     *  requestedOrientation call — see its top-of-file comment). This
     *  pass adds two more call sites of its own (closeGame(), the ROM-load
     *  success path) but they're both still just this same function,
     *  still just this one place that ever touches requestedOrientation —
     *  the try/catch stays regardless: cheap insurance, and the underlying
     *  platform quirk it guards against has nothing to do with how many
     *  call sites there are. Worst case with the catch: that one
     *  orientation change silently doesn't happen; without it, the whole
     *  app crashes. */
    private fun applyScreenOrientationPref() {
        try {
            requestedOrientation = if (!romLoaded) {
                // Idle — no game running. Always Portrait, matching
                // RomBrowserActivity exactly; see the function doc above.
                ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            } else when (screenOrientationChoice) {
                ORIENTATION_AUTO             -> ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
                ORIENTATION_REVERSE_LANDSCAPE -> ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE
                ORIENTATION_PORTRAIT         -> ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                ORIENTATION_SYSTEM           -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                else                         -> ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE  // ORIENTATION_LANDSCAPE + any bad stored value
            }
        } catch (e: Exception) {
            Log.e(TAG, "setRequestedOrientation failed, ignoring", e)
        }
    }

    // ── ROM file browser — now RomBrowserActivity.kt, a separate Activity ──
    //
    // buildBrowserStack(), openRomBrowserAtRoot(), romBrowserUp(),
    // refreshRomBrowserList(), renderRomBrowserList(), romBrowserMessageRow(),
    // romBrowserRow(), and buildRomBrowser() all moved to RomBrowserActivity.kt
    // this pass (Thirty-second) — see that file for the current versions and
    // its own top-of-file comment for why this is a separate Activity now
    // instead of an overlay here (a real, twice-reproduced native crash from
    // forcing orientation on this screen while it lived in this Activity's
    // own window, alongside the game surface).

    // FIX: ⚙ used to call showSettingsMenu() directly, jumping straight into
    // the full Video/Audio/Input/Layouts/... category list with no menu in
    // between. This is the quick game menu that now opens first — Load,
    // Save and Fast forward act immediately; Settings hands off to the
    // screen below.
    //
    // MENU REDESIGN: restyled from a bare .setItems() list (default system
    // row styling) to plain rows via a custom ArrayAdapter, to match the
    // reference screenshot — and folded Link remote/local back in here
    // alongside three new actions (Screenshot, Reset, Close), matching that
    // reference's full ten-item list. It's one continuous list; AlertDialog's
    // own internal ListView scrolls it automatically once it overflows the
    // dialog's height, exactly like it already did for the old 5-item
    // version — nothing extra needed for that part. Settings, Link remote
    // and Link local are still also reachable from the Settings screen,
    // unchanged (see buildSettingsMenu()) — this just adds a faster path to
    // the same actions, matching how My Boy's own menu is laid out.
    private fun showGameMenu() {
        val items = listOf(
            "Load", "Save", "Fast forward", "Cheats", "Settings",
            "Link remote", "Link local", "Screenshot", "Reset",
            "Copy link log", "Copy crash log", "Memory", "Close"
        )
        // FEATURE: "Memory" (index 11) added right before "Close" rather
        // than in a more thematically-grouped spot (e.g. next to "Cheats")
        // specifically so every other item's index stays exactly what it
        // was — this list is dispatched purely by position below, and
        // inserting in the middle would have meant renumbering every case
        // after it for no functional reason.
        val needsRom = setOf(0, 1, 2, 7, 8, 11) // Load, Save, Fast forward, Screenshot, Reset, Memory
        val adapter = object : ArrayAdapter<String>(this, 0, items) {
            override fun getView(position: Int, recycled: View?, parent: ViewGroup): View {
                val row = recycled as? TextView ?: gameMenuRow()
                row.text = getItem(position)
                return row
            }
        }
        val dialog = AlertDialog.Builder(this)
            .setAdapter(adapter) { _, which ->
                if (which in needsRom && !romLoaded) { uiToast("Load a ROM first"); return@setAdapter }
                when (which) {
                    0 -> showSaveStateSlotDialog(forSave = false)
                    1 -> showSaveStateSlotDialog(forSave = true)
                    2 -> {
                        fastForwardActive = !fastForwardActive
                        uiToast(if (fastForwardActive) "Fast forward ON" else "Fast forward OFF")
                    }
                    3 -> uiToast("Cheats — not implemented yet")
                    4 -> showSettingsMenu()
                    5 -> showLinkRemoteDialog()
                    6 -> showLinkLocalDialog()
                    7 -> takeScreenshot()
                    8 -> resetGame()
                    9 -> copyLinkDebugLog()
                    10 -> copyCrashLog()
                    11 -> showMemoryViewer()
                    12 -> closeGame()
                }
            }
            .create()
        // Dark rounded panel to match the reference screenshot explicitly —
        // the system default AlertDialog background varies more by device/
        // OEM skin (Infinix's XOS included) than the plain row styling
        // above does, so this is pinned rather than left to the theme.
        dialog.window?.setBackgroundDrawable(roundedDialogBackground())
        dialog.show()
    }

    /** Plain-text row for the quick game menu above — larger and simpler
     *  than settingsRow() (no icon/subtitle) to match the reference
     *  screenshot: a scrollable list of plain rows, nothing else.
     *
     *  FIX (Eleventh pass): this row must NOT be isClickable/isFocusable,
     *  and previously was — copied from settingsRow() below without
     *  noticing the two are backed by completely different click paths.
     *  settingsRow() is a plain LinearLayout child added via addView(),
     *  which has no click handling of its own, so it needs to be
     *  clickable/focusable AND carry its own setOnClickListener. This row
     *  is the convertView inside showGameMenu()'s ListView (AlertDialog's
     *  setAdapter), where the *only* click handling is that ListView's own
     *  OnItemClickListener — the `{ _, which -> ... }` lambda passed to
     *  setAdapter() above. A clickable/focusable child steals the touch
     *  before the ListView ever gets to fire that listener, so every row
     *  quietly ate its own tap: the ripple still played (the background
     *  is a pressed-state drawable, and ListView forwards pressed state to
     *  whichever child is under the touch regardless of its own clickable
     *  flag) but `which` was never delivered — which is why Load, Save,
     *  Settings, Link remote, Link local, etc. all silently did nothing
     *  after this menu was restyled. Removing the two flags here restores
     *  the same plain-list-item behavior the old .setItems() version had,
     *  while keeping the ripple background exactly as it was. */
    private fun gameMenuRow(): TextView {
        return TextView(this).apply {
            textSize = 17f
            setTextColor(Color.WHITE)
            setPadding(dp(28), dp(20), dp(28), dp(20))
            setBackgroundResource(rippleBackgroundResId())
        }
    }

    // ── Link debug log ───────────────────────────────────────────────────
    // FEATURE: new (Twelfth pass). The multiplayer subsystem has a real,
    // still-open issue (see KNOWN_LIMITATIONS.md / BUGS_FIXED.md, "Sixth"
    // through "Seventeenth" passes): the app-level Wi-Fi/Bluetooth handshake
    // can succeed while the ROM's own in-game link/multiplayer screen never
    // reacts to it. mgba_jni.c's FIX 11 already added permanent trace
    // logging for exactly this (tag mGBA-JNI, plus mGBA-Link on the Kotlin
    // side) — every pass since concluded the *next* real step needs that
    // actual log output, not another guess.
    //
    // FIX 17: this used to shell out to `logcat`, which works for reading
    // back a process's own output without root or READ_LOGS on stock
    // Android, but which W's own device split (real output on one phone,
    // nothing at all on the other, both running this exact build) confirmed
    // some OEM builds restrict further than that. Now reads a plain private
    // file this app owns outright instead (see EmulatorEngine.
    // nativeSetLinkLogPath, called once from onCreate) — every LOGI/LOGW/
    // LOGE in mgba_jni.c, plus this class's own connection-lifecycle lines
    // (see LinkMultiplayer.kt's FIX 17 entry), now mirrors into it. Needs no
    // logcat/READ_LOGS access at all, on any OEM build, since it was never
    // reading logcat to begin with — just a file in this app's own
    // filesDir. The native side truncates it fresh at the start of every
    // link session (see nativeLinkStart()'s own FIX 17 comment), so a
    // capture reflects one connection attempt, not an accumulation.
    //
    // Meant to be opened right after reproducing the issue being chased —
    // both phones' ROMs actually navigated into their in-game link menus,
    // not just the app-level "Connected" toast, and (for a disconnect
    // report specifically) after actually tapping Disconnect and giving the
    // other phone a few seconds — so the log actually covers a real
    // attempt. Whether *any* "SIO write addr=..." line shows up at all is
    // the specific thing every recent pass has been unable to check: none
    // at all points upstream of the SIO driver entirely (wrong mode
    // selected, or the driver never truly took); several, with the exchange
    // completing, points at the protocol logic instead. Copies to the
    // clipboard automatically (paste it straight back) and also shows it
    // on-screen in case the clipboard isn't available for some reason.
    /** BUG FIX (real ANR, not a guess — caught via the Crash Log Viewer
     *  app): "Input dispatching timed out... Waited 5000ms", with the main
     *  thread's stack sitting inside TextView/Editor draw code under a
     *  ScrollView at the moment it hung — exactly the shape of
     *  showLinkDebugLogDialog()/showCrashLogDialog() below. A real link
     *  session logs a line (sometimes several) per SIO write and per child
     *  exchange — see LinkMultiplayer.kt's own log calls — which adds up to
     *  a genuinely huge file over a real testing session, especially on
     *  whichever side is host. Rendering that much text in a
     *  setTextIsSelectable(true) TextView is known to be catastrophically
     *  slow (selectable text needs a much heavier internal layout the
     *  plain non-selectable path doesn't), and that's exactly what froze
     *  the main thread long enough to trip Android's own ANR watchdog.
     *  Caps to the most recent [maxChars] — still tens of thousands of
     *  characters of context, plenty to debug from, but bounded — applied
     *  once here so it protects both the on-screen dialog and the
     *  clipboard copy, not just one of them. */
    private fun capLogText(text: String, maxChars: Int = 40_000): String =
        if (text.length <= maxChars) text
        else "…[${text.length - maxChars} earlier characters truncated — showing the most recent $maxChars]…\n\n" + text.takeLast(maxChars)

    private fun copyLinkDebugLog() {
        uiToast("Reading log…")
        Thread {
            val text = try {
                val f = File(filesDir, "link_debug.log")
                if (f.exists()) capLogText(f.readText()) else ""
            } catch (e: Exception) {
                Log.e(TAG, "link log file read failed", e)
                "Couldn't read the log file directly (${e.message})."
            }
            // FIX 19: stamp the exact moment THIS device's copy happened, in
            // the same MM-DD HH:MM:SS.mmm layout the log lines themselves
            // use (see link_log_write_locked()'s own comment in mgba_jni.c)
            // — two phones' copies never land at quite the same instant (a
            // human taps one button, then walks to the other phone and taps
            // its button too), and until now the only way to tell how far
            // apart two captures really were was comparing the last real SIO
            // line on each side, which only works if both sides were still
            // actively exchanging data right up to the tap — not during a
            // lull, and not at all if one side's tail is mostly idle
            // padding. This line answers "how far apart were these two
            // captures" directly, every time.
            val stamp = java.text.SimpleDateFormat("MM-dd HH:mm:ss.SSS", java.util.Locale.US)
                .format(java.util.Date())
            val stamped = if (text.isBlank()) text else "$text\n=== copied at $stamp ==="
            runOnUiThread { showLinkDebugLogDialog(stamped) }
        }.start()
    }

    private fun showLinkDebugLogDialog(logText: String) {
        val shown = logText.ifBlank {
            "(empty — make sure both phones' ROMs were actually navigated " +
            "into their in-game link/multiplayer menu during this session, " +
            "not just the app-level Connected step; for a disconnect issue, " +
            "also actually tap Disconnect and wait a few seconds before " +
            "reading this log. If this stays empty even after a real " +
            // FIX (this pass): nativeSetLinkLogPath() no longer opens the
            // file itself (see its own KDoc in EmulatorEngine.kt) — it's
            // opened when a link session actually starts, so the relevant
            // Logcat line to check for moved too.
            "attempt, check Logcat for \"Link log path recorded\" around " +
            "app startup, and \"Link multiplayer started\" when connecting " +
            "— if neither appears, or the second one does but this is " +
            "still empty, that's the actual file-open failing.)"
        }
        try {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("mGBA link log", shown))
        } catch (e: Exception) {
            Log.w(TAG, "Clipboard copy failed (log is still shown below)", e)
        }
        // BUG FIX: was setTextIsSelectable(true) — see capLogText()'s doc
        // comment. The clipboard copy just above already covers "get this
        // text out of the phone"; on-screen selection was a nice-to-have
        // that turned out to cause a real ANR, so it's gone rather than
        // just gated behind a length check — not worth the risk twice.
        val textView = TextView(this).apply {
            text = shown
            textSize = 11f
            typeface = Typeface.MONOSPACE
            setTextColor(Color.WHITE)
            setPadding(dp(20), dp(16), dp(20), dp(16))
        }
        AlertDialog.Builder(this)
            .setTitle("Link debug log (copied to clipboard)")
            .setView(ScrollView(this).apply { addView(textView) })
            .setPositiveButton("Close", null)
            .show()
    }

    // ── Crash log ─────────────────────────────────────────────────────────
    // See installCrashLogger()'s doc comment (near onCreate) for the why —
    // this just reads back what that handler wrote, the same read-off-
    // main-thread-then-show-a-dialog shape as copyLinkDebugLog() above.
    private fun copyCrashLog() {
        uiToast("Reading crash log…")
        Thread {
            val text = try {
                val f = File(filesDir, "crash_log.txt")
                if (f.exists()) capLogText(f.readText()) else ""
            } catch (e: Exception) {
                Log.e(TAG, "crash log file read failed", e)
                "Couldn't read the crash log file directly (${e.message})."
            }
            runOnUiThread { showCrashLogDialog(text) }
        }.start()
    }

    private fun showCrashLogDialog(logText: String) {
        val shown = logText.ifBlank {
            "(empty — no crash recorded since this build was installed. If " +
            "it crashes again, come straight back here afterward; the next " +
            "launch will have written a fresh report before you even see " +
            "this menu again.)"
        }
        try {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("mGBA crash log", shown))
        } catch (e: Exception) {
            Log.w(TAG, "Clipboard copy failed (log is still shown below)", e)
        }
        // BUG FIX: see capLogText()'s doc comment — same reasoning as
        // showLinkDebugLogDialog() above.
        val textView = TextView(this).apply {
            text = shown
            textSize = 11f
            typeface = Typeface.MONOSPACE
            setTextColor(Color.WHITE)
            setPadding(dp(20), dp(16), dp(20), dp(16))
        }
        AlertDialog.Builder(this)
            .setTitle("Crash log (copied to clipboard)")
            .setView(ScrollView(this).apply { addView(textView) })
            .setPositiveButton("Close", null)
            .show()
    }

    // ── Screenshot ───────────────────────────────────────────────────────
    // FEATURE: new — didn't exist before. Uses PixelCopy against the
    // SurfaceView itself (API 24+, matches this app's minSdk, no version
    // check needed) rather than reaching into frameBuffers/displayIdx
    // directly, so it always grabs exactly what's currently on screen
    // without needing to reason about the triple-buffer's own
    // synchronization from an unrelated call site.

    private fun takeScreenshot() {
        if (!romLoaded) { uiToast("Load a ROM first"); return }
        val w = surfaceView.width
        val h = surfaceView.height
        if (w <= 0 || h <= 0) { uiToast("Screenshot failed"); return }
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        PixelCopy.request(surfaceView, bmp, { result ->
            if (result == PixelCopy.SUCCESS) {
                // FIX: saveScreenshotBitmap() does real work — a PNG
                // compress plus a blocking file (or SAF) write, the latter
                // potentially slow on a cloud-backed Storage folder — but
                // this completion callback is posted to the main thread
                // (the Handler just below), so all of that used to run
                // right there, a visible stutter on every screenshot. Same
                // "move the actual I/O off whatever thread happened to
                // call this" fix as quickSaveState()/quickLoadState()'s own
                // lag-pass fix and the link-log dialog's ANR fix —
                // captureStateThumbnail() already does the equivalent of
                // this correctly for save-state slot thumbnails.
                Thread { saveScreenshotBitmap(bmp) }.apply { name = "mGBA-screenshot" }.start()
            } else uiToast("Screenshot failed")
        }, Handler(Looper.getMainLooper()))
    }

    private fun saveScreenshotBitmap(bmp: Bitmap) {
        val stamp = DateFormat.format("yyyyMMdd_HHmmss", System.currentTimeMillis())
        val name = "${currentRomBaseName}_$stamp.png"
        try {
            // FEATURE: Storage folder — see the block comment above
            // dataFolderTree(). Screenshots always create a brand-new,
            // uniquely-timestamped file, never look up an existing one, so
            // this doesn't need the full find-or-create SaveEntry
            // machinery the save/state files below do — just create it
            // directly in the "screenshot" subfolder when one's configured.
            val subDir = dataSubfolder("screenshot")
            if (subDir != null) {
                val doc = subDir.createFile("image/png", name)
                    ?: throw IOException("Couldn't create $name in the chosen folder")
                contentResolver.openOutputStream(doc.uri)?.use { out ->
                    bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
                } ?: throw IOException("openOutputStream failed for $name")
            } else {
                // FIX (pass 43): used to be a bare "Screenshots" folder
                // directly under getExternalFilesDir(null) — still correct
                // (zero permission, survives Settings → Storage → Clear
                // cache) but sitting apart from saves/states/layout instead
                // of alongside them under one obvious root. Now nested under
                // the same automatic mirror root those use — see
                // autoFolderRoot()/autoMirrorSubdir() above dataSubfolder().
                val dir = autoMirrorSubdir("Screenshots")
                    ?: File(getExternalFilesDir(null), "Screenshots").apply { mkdirs() }
                File(dir, name).outputStream().use { out -> bmp.compress(Bitmap.CompressFormat.PNG, 100, out) }
            }
            uiToast("Saved $name")
        } catch (e: Exception) {
            Log.e(TAG, "Screenshot save failed", e)
            uiToast("Screenshot save failed")
        }
    }

    // ── Reset ────────────────────────────────────────────────────────────
    // FEATURE: new. There's no standalone core-reset entry point on the
    // native side — core->reset() is only ever called from inside
    // nativeLoadROM() itself (see mgba_jni.c) — and this project's own
    // history shows JNI signature mismatches only turning up once a real CI
    // build ran against the actual pinned mGBA headers (see FIX 8 in
    // mgba_jni.c). A brand-new hand-written JNI export isn't worth that
    // build-and-pray risk just for this, so this reuses nativeLoadROM()
    // instead: the last-loaded ROM's bytes are still sitting at the fixed
    // cache path below (see the ROM-picker callback above — it's never
    // deleted), so reloading from there with the same battery-save path is
    // a full power-cycle — same user-visible effect as a hardware reset,
    // save data intact — through a path that's already proven to build and
    // work rather than a new, unverifiable one.

    private fun resetGame() {
        if (!romLoaded) { uiToast("Load a ROM first"); return }
        val tmp = cacheDir.resolve("rom_loaded.gba")
        if (!tmp.exists()) { uiToast("Can't reset — try Close, then Load ROM"); return }
        if (link.isConnected) stopLink()
        stopGameLoop()
        val baseName = currentRomBaseName
        Thread {
            val saveEntry = batterySaveEntry(baseName)
            backupIfExists(saveEntry)
            // FIX (Twenty-first pass): see loadRomFromUri's own comment on
            // batteryMirrorPath() replacing the /proc/self/fd bridge.
            val savePath = saveEntry.batteryMirrorPath()
            val ok = EmulatorEngine.nativeLoadROM(tmp.absolutePath, savePath)
            // FIX: onPause()/closeGame() both flush the battery-save mirror
            // (syncBatteryMirror()/mirrorToAutoFolder()) right after a
            // session ends; resetGame() didn't, so Reset → force-kill the
            // app before it's ever paused or closed again could leave the
            // opt-in Storage-folder/auto-folder mirror one session behind.
            // Local save data itself was never at risk (it's the same .sav
            // file the core writes to directly) — this only keeps the
            // mirror consistent with the rest of this class's own pattern.
            // Reuses the saveEntry already in scope above rather than
            // constructing a fresh batterySaveEntry(currentRomBaseName)
            // like the other two call sites — same underlying file, no
            // need for a second resolution. Already off the main thread
            // here (this whole block runs on the background Thread this
            // function starts below), unlike onPause()'s own main-thread
            // calls — strictly better for the same reason takeScreenshot()
            // was just moved off it too.
            if (ok) { saveEntry.syncBatteryMirror(); saveEntry.mirrorToAutoFolder() }
            Handler(Looper.getMainLooper()).post {
                if (isFinishing || isDestroyed) return@post
                if (ok) {
                    val w = EmulatorEngine.nativeGetWidth().coerceAtLeast(1)
                    val h = EmulatorEngine.nativeGetHeight().coerceAtLeast(1)
                    frameBuffers = Array(3) { Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888) }
                    writeIdx = 0; readyIdx = -1; displayIdx = -1
                    clearPointerState(); currentKeys.set(0); fastForwardActive = false
                    initAudioTrack()
                    startGameLoop()
                    uiToast("Game reset")
                } else {
                    romLoaded = false
                    uiToast("Reset failed — ROM may be missing from cache")
                }
            }
        }.apply { name = "mGBA-reset" }.start()
    }

    // ── Close ────────────────────────────────────────────────────────────
    // FEATURE: new. Stops the current game and drops back to ROM selection.
    // Nothing needs freeing on the native side for this — nativeLoadROM()
    // already swaps cores cleanly on the next load (see the FIX comment
    // above the ROM-picker callback) — so this just stops the loop/audio
    // and restores the pre-load UI.
    //
    // BUG FIX (earlier pass): Close used to only flip the old floating
    // "Load ROM" button back to VISIBLE and stop there, leaving the
    // SurfaceView untouched. A SurfaceView just keeps showing whatever it
    // last drew until something draws over it again, so the closed game's
    // last frame stayed sitting there until a new ROM was loaded and
    // rendered its own first frame. Fixed by wiping the surface to black
    // immediately (clearSurfaceToBlack()) and handing off straight to
    // changeRom(), which opens the file browser directly if a ROM folder's
    // already been picked, otherwise prompts to pick one. That button is
    // gone now (see the FIX comment in onCreate where it used to be built)
    // — romLoaded is left false here, so if changeRom()'s own picker gets
    // cancelled, a tap on the idle surface (see onGameTouch()) is the way
    // back in instead.
    private fun closeGame() {
        if (!romLoaded) return
        if (link.isConnected) stopLink()
        stopGameLoop()
        try { audioTrack?.pause(); audioTrack?.flush() } catch (_: Exception) {}
        // FIX (Twenty-first pass): flush the battery-save mirror out to the
        // chosen Storage folder before this ROM's session is considered
        // over — see onPause()'s own copy of this call for the fuller
        // explanation. Closing back to the ROM browser is exactly the kind
        // of "I'm done with this game for now" moment that should sync,
        // same as backgrounding the app. mirrorToAutoFolder() alongside it
        // — see the FEATURE block above dataFolderTree() — same sync,
        // automatic own-folder mirror instead of a chosen SAF folder.
        batterySaveEntry(currentRomBaseName).syncBatteryMirror()
        batterySaveEntry(currentRomBaseName).mirrorToAutoFolder()
        romLoaded = false
        // FIX (this pass): see applyScreenOrientationPref()'s own doc
        // comment. Flips this activity back to Portrait right here, before
        // changeRom() below reopens RomBrowserActivity — stopGameLoop()
        // above has already halted rendering, so this is a clean single
        // rotation on this activity's own idle screen, not one smeared
        // across the browser's launch transition.
        applyScreenOrientationPref()
        clearSurfaceToBlack()
        uiToast("Game closed")
        changeRom()
    }

    // ── Shared dialog-building helpers (used by several categories below) ──

    private fun dlgRadioGroup(horizontal: Boolean = true) = RadioGroup(this).apply {
        if (horizontal) orientation = LinearLayout.HORIZONTAL
    }
    private fun RadioGroup.dlgAddOpt(label: String): RadioButton = RadioButton(context).apply {
        text = label
        id   = View.generateViewId()
        setTextColor(Color.WHITE)
        textSize = 13f
    }.also { addView(it) }

    /** Plain tappable row for the Video list — no icon, unlike settingsRow()
     *  above (that one's for the Settings category list one level up; this
     *  screen's own reference screenshot has no icons on its rows at all). */
    private fun videoListRow(title: String, subtitle: String?, onClick: () -> Unit): View {
        val ctx = this
        return LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            isClickable = true; isFocusable = true
            setBackgroundResource(rippleBackgroundResId())
            setPadding(dp(20), dp(14), dp(20), dp(14))
            addView(TextView(ctx).apply { text = title; textSize = 16f; setTextColor(Color.WHITE) })
            if (subtitle != null) {
                addView(TextView(ctx).apply {
                    text = subtitle; textSize = 12f
                    setTextColor(Color.parseColor("#888892"))
                    setPadding(0, dp(2), 0, 0)
                })
            }
            setOnClickListener { onClick() }
        }
    }

    private fun videoCheckRow(title: String, subtitle: String?, checked: Boolean, onToggle: (Boolean) -> Unit): View {
        val ctx = this
        val textCol = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextView(ctx).apply { text = title; textSize = 16f; setTextColor(Color.WHITE) })
            if (subtitle != null) {
                addView(TextView(ctx).apply {
                    text = subtitle; textSize = 12f
                    setTextColor(Color.parseColor("#888892"))
                    setPadding(0, dp(2), 0, 0)
                })
            }
        }
        val box = CheckBox(ctx).apply { isChecked = checked }
        box.setOnCheckedChangeListener { _, isChecked -> onToggle(isChecked) }
        return LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(14), dp(20), dp(14))
            isClickable = true; isFocusable = true
            setOnClickListener { box.isChecked = !box.isChecked }
            addView(textCol, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(box)
        }
    }

    private fun videoDivider(): View = View(this).apply {
        setBackgroundColor(Color.parseColor("#22FFFFFF"))
    }

    // roundedDialogBackground() moved to SharedUi.kt — sliderRow() there
    // needs it too, and it's exactly the kind of small/stateless/cosmetic
    // helper that file already exists for. Every call site below is
    // unchanged (still an unqualified same-package extension-function
    // call).

    // ── Video ────────────────────────────────────────────────────────────
    //
    // FEATURE (this pass): rebuilt to match a reference screenshot's plain
    // list layout (title + optional gray subtitle per row, checkboxes on
    // the boolean ones, thin dividers) instead of the previous single form
    // with everything crammed into one Save/Cancel dialog. "Screen size"
    // and "Screen orientation" now each open their own follow-on screen
    // rather than showing inline controls here — showScreenOrientationDialog()
    // and showMaxFrameSkipsDialog() below.
    //
    // "Enable OpenGL" and "GLSL Shader" from that same reference screenshot
    // are deliberately NOT here. This app's renderer has only ever been a
    // Canvas/SurfaceView pipeline (see updateGameMatrix()/renderFrame()) —
    // there's no OpenGL rendering path to switch to at all, let alone a
    // shader system to plug GLSL into. A checkbox that doesn't actually
    // change anything is worse than no checkbox — building the real thing
    // (an EGL/GLSurfaceView pipeline alongside or replacing the current
    // one) would be a genuinely large, separate undertaking, not something
    // to fake here alongside everything else this pass. "Linear filtering"
    // doesn't need OpenGL to be real, so it's included and fully wired
    // (see gamePaint/updateLinearFilterPaint() above) — just not gated
    // behind an OpenGL toggle that doesn't exist.
    private fun showVideoSettings() {
        val ctx = this
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        var dialog: AlertDialog? = null
        val layout = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }

        layout.addView(videoCheckRow(
            "Stretch to fit screen",
            "Always stretch to fill the entire screen in landscape mode",
            stretchToFit
        ) { isChecked ->
            stretchToFit = isChecked
            prefs.edit().putBoolean(PREF_STRETCH, isChecked).apply()
            if (running) updateGameMatrix(lastSw, lastSh)
        })
        layout.addView(videoDivider())

        // FEATURE: used to open a 35/44/52/65% picker here, then (last
        // pass) just a navigation fix into the editor with nothing
        // resizable to do once there. This pass: the game screen is a
        // real drag-and-resize participant in that editor now, same as
        // any button — see gameScreenRect/resolvedRect("gamescreen", ...)
        // in updateGameMatrix(). Opening the editor is enough; nothing
        // more specific to navigate to.
        //
        // FIX (this pass): reported as not actually appearing until
        // Settings was closed first. dialog?.dismiss() only ever closed
        // this Video popup — settingsMenuOverlay (the Settings screen
        // *underneath* it, a separate full-screen opaque overlay) was
        // never touched, so it stayed covering the editor that had, in
        // fact, already started underneath it the whole time. Both need
        // to close for the editor to actually become visible/usable.
        layout.addView(videoListRow("Screen size", "Drag and resize the game screen directly") {
            dialog?.dismiss()
            settingsMenuOverlay.visibility = View.GONE
            enterEditMode()
        })
        layout.addView(videoDivider())

        layout.addView(videoListRow("Screen orientation", null) {
            showScreenOrientationDialog()
        })
        layout.addView(videoDivider())

        layout.addView(videoListRow("Max frame skips", "Maximum number of consecutive frame skips") {
            showMaxFrameSkipsDialog()
        })
        layout.addView(videoDivider())

        layout.addView(videoCheckRow(
            "Linear filtering",
            "Smooths the upscaled image instead of showing crisp pixels",
            linearFilterEnabled
        ) { isChecked ->
            linearFilterEnabled = isChecked
            prefs.edit().putBoolean(PREF_LINEAR_FILTER, isChecked).apply()
            updateLinearFilterPaint()
        })

        dialog = AlertDialog.Builder(ctx)
            .setTitle("🖥  Video")
            .setView(ScrollView(ctx).also { it.addView(layout) })
            .setNegativeButton("Close", null)
            .create()
        dialog.window?.setBackgroundDrawable(roundedDialogBackground())
        dialog.show()
    }

    /** Standalone orientation picker — a reference screenshot's own popup
     *  style (title + single-choice list + Cancel only, no separate
     *  Save/OK) rather than the inline radio group this used to be part
     *  of inside showVideoSettings(). Applies immediately on tap, same as
     *  that reference's own behavior reads: there's no reason to make
     *  someone confirm a second time for a single choice like this one. */
    private fun showScreenOrientationDialog() {
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val options = listOf(
            "Auto rotate"       to ORIENTATION_AUTO,
            "Landscape"         to ORIENTATION_LANDSCAPE,
            "Reverse landscape" to ORIENTATION_REVERSE_LANDSCAPE,
            "Portrait"          to ORIENTATION_PORTRAIT,
            "System default"    to ORIENTATION_SYSTEM
        )
        val curIdx = options.indexOfFirst { it.second == screenOrientationChoice }.takeIf { it >= 0 } ?: 1
        val dialog = AlertDialog.Builder(this)
            .setTitle("Screen orientation")
            .setSingleChoiceItems(options.map { it.first }.toTypedArray(), curIdx) { d, which ->
                val newOrientation = options[which].second
                screenOrientationChoice = newOrientation
                prefs.edit().putInt(PREF_ORIENTATION, newOrientation).apply()
                applyScreenOrientationPref()
                d.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .create()
        dialog.window?.setBackgroundDrawable(roundedDialogBackground())
        dialog.show()
    }

    /** Max frame skips picker — a reference screenshot's own slider-dialog
     *  style (title + centered number readout + slider + Cancel/OK).
     *  0 keeps every frame (default, previous behavior); 1–10 lets the
     *  game loop skip up to that many consecutive blits while genuinely
     *  behind — see maybeSkipRenderThisFrame's logic inline in
     *  startGameLoop(). */
    private fun showMaxFrameSkipsDialog() {
        val ctx = this
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val layout = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(4), dp(24), dp(0))
        }
        val valueText = TextView(ctx).apply {
            text = maxFrameSkips.toString()
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        layout.addView(valueText)
        val seek = SeekBar(ctx).apply {
            max = 10
            progress = maxFrameSkips
        }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, value: Int, fromUser: Boolean) { valueText.text = value.toString() }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })
        layout.addView(seek)

        val dialog = AlertDialog.Builder(ctx)
            .setTitle("Max frame skips")
            .setView(layout)
            .setPositiveButton("OK") { _, _ ->
                maxFrameSkips = seek.progress
                prefs.edit().putInt(PREF_MAX_SKIPS, maxFrameSkips).apply()
            }
            .setNegativeButton("Cancel", null)
            .create()
        dialog.window?.setBackgroundDrawable(roundedDialogBackground())
        dialog.show()
    }

    // ── Audio ────────────────────────────────────────────────────────────
    //
    // FEATURE (this pass): rebuilt to match a reference screenshot's own
    // list layout — Enable sound / Sound volume / Sound frequency — the
    // same "list of rows, Close-only, each row applies immediately" shape
    // showVideoSettings() above already moved to, replacing the old single
    // Save/Cancel form this used to be (that old form held just one
    // setting: the button-click sound toggle, removed this pass per a
    // direct report — see the field comments near soundEnabled and
    // updateGameKeys() above, which no longer has any click-sound logic at
    // all).

    private fun showAudioSettings() {
        val ctx = this
        val layout = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }

        layout.addView(videoCheckRow(
            "Enable sound",
            "Plays game audio normally when on; muted when off",
            soundEnabled
        ) { isChecked ->
            soundEnabled = isChecked
            getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putBoolean(PREF_SOUND_ENABLED, isChecked).apply()
            applyGameVolume()
        })
        layout.addView(videoDivider())

        layout.addView(videoListRow(
            "Sound volume",
            "In-app volume, independent of the device's own media volume"
        ) { showSoundVolumeDialog() })
        layout.addView(videoDivider())

        layout.addView(videoListRow(
            "Sound frequency",
            "Lower rates use less CPU/battery at reduced audio quality"
        ) { showSoundFrequencyDialog() })

        val dialog = AlertDialog.Builder(ctx)
            .setTitle("🔊  Audio")
            .setView(ScrollView(ctx).also { it.addView(layout) })
            .setNegativeButton("Close", null)
            .create()
        dialog.window?.setBackgroundDrawable(roundedDialogBackground())
        dialog.show()
    }

    /** Sound volume picker — same reference screenshot's own slider-dialog
     *  style showMaxFrameSkipsDialog() above already uses (title + centered
     *  number readout + slider + Cancel/OK). Applies to the live
     *  AudioTrack immediately on OK via applyGameVolume() — same as
     *  Enable sound's own checkbox — rather than waiting for anything else
     *  to reload. */
    private fun showSoundVolumeDialog() {
        val ctx = this
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val layout = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(4), dp(24), dp(0))
        }
        val valueText = TextView(ctx).apply {
            text = soundVolumePercent.toString()
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        layout.addView(valueText)
        val seek = SeekBar(ctx).apply {
            max = 100
            progress = soundVolumePercent
        }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, value: Int, fromUser: Boolean) { valueText.text = value.toString() }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })
        layout.addView(seek)

        val dialog = AlertDialog.Builder(ctx)
            .setTitle("Sound volume")
            .setView(layout)
            .setPositiveButton("OK") { _, _ ->
                soundVolumePercent = seek.progress
                prefs.edit().putInt(PREF_SOUND_VOLUME, soundVolumePercent).apply()
                applyGameVolume()
            }
            .setNegativeButton("Cancel", null)
            .create()
        dialog.window?.setBackgroundDrawable(roundedDialogBackground())
        dialog.show()
    }

    /** Sound frequency picker — same reference screenshot's own single-
     *  choice style showScreenOrientationDialog() above already uses
     *  (title + radio list + Cancel only, applies immediately on tap
     *  rather than needing a second confirm for a single choice like this
     *  one). 44100/22050/11025 Hz, matching MyBoy's own equivalent setting
     *  (direct reference) — output sample rate traded against CPU/battery
     *  use. See applySoundFrequencyFilter()'s own comment for how a lower
     *  choice here actually gets applied without breaking the emulator's
     *  own frame pacing. A rebuild is needed to actually change a live
     *  AudioTrack's rate (see audioTrackRebuildPending's field comment),
     *  but only while a game is actually running: while idle there's
     *  nothing audible to update anyway, and the persisted preference
     *  gets picked up regardless the next time a ROM loads — that path
     *  always calls initAudioTrack() fresh (see loadRomFromUri()). */
    private fun showSoundFrequencyDialog() {
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val options = listOf("44100 Hz" to 44100, "22050 Hz" to 22050, "11025 Hz" to 11025)
        val curIdx = options.indexOfFirst { it.second == soundFrequencyHz }.takeIf { it >= 0 } ?: 0
        val dialog = AlertDialog.Builder(this)
            .setTitle("Sound frequency")
            .setSingleChoiceItems(options.map { it.first }.toTypedArray(), curIdx) { d, which ->
                soundFrequencyHz = options[which].second
                prefs.edit().putInt(PREF_SOUND_FREQ, soundFrequencyHz).apply()
                updateSoundFrequencyFactor()
                if (romLoaded) audioTrackRebuildPending = true
                d.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .create()
        dialog.window?.setBackgroundDrawable(roundedDialogBackground())
        dialog.show()
    }

    // ── Input ────────────────────────────────────────────────────────────

    private fun showInputSettings() {
        val ctx = this
        val layout = ctx.dialogContentLayout().apply {
            addView(TextView(ctx).apply {
                text = "Drag any button to move it, or drag its corner handle to resize — live, over the running game."
                textSize = 12f; setTextColor(Color.WHITE)
            })
        }

        // Turbo A/B checkbox removed this pass — "⚡ Turbo A / Turbo B
        // buttons" used to live here, adding/removing both red rapid-fire
        // satellites together with no way to get just one. Now individually
        // reachable through "+ Add control" below instead (they're in
        // extraControlIds, same as every other opt-in extra), on request.

        // FEATURE #2: My Boy!-style per-button layout editor entry point.
        // Dismisses both this dialog and the settings menu behind it, then
        // opens the live drag/resize editor over the running game (see
        // enterEditMode()).
        val editLayoutBtn = Button(ctx).apply {
            text = "Edit Button Layout…"
            setPadding(0, dp(16), 0, 0)
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#553A3A4A"))
        }
        layout.addView(editLayoutBtn)

        val dlg = AlertDialog.Builder(ctx)
            .setTitle("🕹  Input")
            .setView(layout)
            .setNegativeButton("Close", null)
            .show()
        editLayoutBtn.setOnClickListener {
            dlg.dismiss()
            settingsMenuOverlay.visibility = View.GONE
            enterEditMode()
        }
    }

    // ── Layouts ──────────────────────────────────────────────────────────

    private fun showLayoutsSettings() {
        val ctx = this
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val layout = ctx.dialogContentLayout()

        layout.addView(TextView(ctx).apply {
            text = "Button size"; textSize = 12f; setTextColor(Color.WHITE)
        })
        val sizeOptions = listOf("Small" to 0.75f, "Normal" to 1.0f, "Large" to 1.25f)
        val sizeRadio   = dlgRadioGroup()
        sizeOptions.forEach { (label, _) -> sizeRadio.dlgAddOpt(label) }
        val curSizeIdx = sizeOptions.indexOfFirst { abs(it.second - buttonScaleMultiplier) < 0.05f }
            .takeIf { it >= 0 } ?: 1
        (sizeRadio.getChildAt(curSizeIdx) as RadioButton).isChecked = true
        layout.addView(sizeRadio)

        layout.addView(TextView(ctx).apply {
            text = "Button opacity"; textSize = 12f; setTextColor(Color.WHITE)
            setPadding(0, dp(16), 0, 0)
        })
        val alphaOptions = listOf("Low" to 90, "Normal" to 160, "High" to 220)
        val alphaRadio   = dlgRadioGroup()
        alphaOptions.forEach { (label, _) -> alphaRadio.dlgAddOpt(label) }
        val curAlphaIdx = alphaOptions.indexOfFirst { abs(it.second - buttonBaseAlpha) < 40 }
            .takeIf { it >= 0 } ?: 1
        (alphaRadio.getChildAt(curAlphaIdx) as RadioButton).isChecked = true
        layout.addView(alphaRadio)

        AlertDialog.Builder(ctx)
            .setTitle("▦  Layouts")
            .setView(ScrollView(ctx).also { it.addView(layout) })
            .setPositiveButton("Save") { _, _ ->
                val selSizeIdx = (0 until sizeRadio.childCount)
                    .firstOrNull { (sizeRadio.getChildAt(it) as RadioButton).isChecked } ?: curSizeIdx
                val newScale = sizeOptions[selSizeIdx].second

                val selAlphaIdx = (0 until alphaRadio.childCount)
                    .firstOrNull { (alphaRadio.getChildAt(it) as RadioButton).isChecked } ?: curAlphaIdx
                val newAlpha = alphaOptions[selAlphaIdx].second

                val needsRelayout = newScale != buttonScaleMultiplier
                buttonScaleMultiplier = newScale
                buttonBaseAlpha       = newAlpha

                prefs.edit()
                    .putFloat(PREF_BTN_SCALE, newScale)
                    .putInt(PREF_BTN_ALPHA,   newAlpha)
                    .apply()

                if (needsRelayout) applyLayoutSettings()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ── Misc ─────────────────────────────────────────────────────────────

    private fun showMiscSettings() {
        val ctx = this
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val layout = ctx.dialogContentLayout()

        layout.addView(TextView(ctx).apply {
            text = "Fast-forward speed (0.5 – 16×)\nTap » on screen to activate"
            textSize = 12f; setTextColor(Color.WHITE)
        })
        val ffEdit = EditText(ctx).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText(formatSpeed(fastForwardSpeed))
            hint = "e.g. 2, 4, 4.5"
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        layout.addView(ffEdit)

        val fpsCheck = CheckBox(ctx).apply {
            text = "Show performance overlay (FPS / audio underruns)"
            isChecked = showFpsOverlay
            setTextColor(Color.WHITE)
            setPadding(0, dp(24), 0, 0)
        }
        layout.addView(fpsCheck)

        AlertDialog.Builder(ctx)
            .setTitle("👤  Misc")
            .setView(layout)
            .setPositiveButton("Save") { _, _ ->
                val ffVal = ffEdit.text.toString().toFloatOrNull()
                if (ffVal != null) {
                    when {
                        ffVal < 0.5f || ffVal > 16f -> uiToast("Speed must be 0.5 – 16")
                        else -> {
                            fastForwardSpeed = ffVal
                            prefs.edit().putFloat(PREF_FF_SPEED, fastForwardSpeed).apply()
                        }
                    }
                } else {
                    // FIX: empty/unparseable input used to fail silently —
                    // the dialog just closed and quietly kept the old
                    // speed, with no indication anything was wrong, unlike
                    // the out-of-range case just above which already
                    // toasts.
                    uiToast("Enter a valid number")
                }
                showFpsOverlay = fpsCheck.isChecked
                prefs.edit().putBoolean(PREF_SHOW_FPS, showFpsOverlay).apply()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ── Storage ──────────────────────────────────────────────────────────
    // FEATURE: new. See the block comment above dataFolderTree() (right
    // before batterySaveFile/stateSlotFile/etc.) for the full reasoning —
    // this is just the settings screen that lets someone actually pick a
    // folder, or go back to the app-internal default.

    private fun showStorageSettings() {
        val ctx = this
        lateinit var statusText: TextView
        lateinit var chooseBtn: Button
        lateinit var resetBtn: Button

        // FIX (spotted while reviewing this pass's own storage-text
        // changes just below): originally took no parameter and called
        // dataFolderTree() itself — correct on its own, but refresh()
        // right below *also* resolves dataFolderTree() into its own
        // `tree` local and calls this function too, so a single refresh()
        // call could trigger the exact repeated-resolution pattern item 7
        // elsewhere in this file (SaveEntry.usesDataFolder) was just fixed
        // for — the same DocumentFile round-trip, just here instead of
        // there. Takes the caller's already-resolved tree instead.
        fun currentFolderLabel(tree: DocumentFile?): String = when {
            tree != null -> tree.name ?: "(chosen folder)"
            hasBroadFileAccess() -> "\"mGBA\" folder (default — top-level storage)"
            else -> "\"mGBA\" folder (default — app-internal for now)"
        }

        fun refresh() {
            val tree = dataFolderTree()
            statusText.text = "Current folder: ${currentFolderLabel(tree)}\n\n" +
                (when {
                    tree != null ->
                        "Holds three subfolders — save, cheat, screenshot — for " +
                        "battery saves, save-states and their thumbnails, the " +
                        "(future) cheat file feature, and screenshots. Visible in " +
                        "any file manager, not tucked away under Android/data."
                    hasBroadFileAccess() ->
                        // FIX (this pass): now that autoFolderRoot() actually
                        // uses a top-level folder once storage access is
                        // granted, this can finally say so accurately — this
                        // branch replaces the old single "under this app's own
                        // storage" wording, which was true of the fallback
                        // below but not of this, the now-common case.
                        "No folder chosen, so saves/states/screenshots/layout " +
                        "are all kept automatically in an \"mGBA\" folder right " +
                        "alongside your phone's other folders — same idea as " +
                        "My Boy's own folder, no setup needed, visible in any " +
                        "file manager. Survives Settings → Storage → Clear " +
                        "cache *and* Clear storage/data, since — unlike the " +
                        "app-internal fallback below — it isn't app-private " +
                        "storage at all."
                    else ->
                        "No folder chosen, so saves/states/screenshots/layout " +
                        "are all kept automatically in an \"mGBA\" folder under " +
                        "this app's own storage for now — no setup needed, and " +
                        "it survives Settings → Storage → Clear cache. Grant " +
                        "storage access (you'll be asked next time you browse " +
                        "for a ROM) to move this to a top-level folder any " +
                        "file manager can browse into directly, same as " +
                        "picking a folder below."
                }) +
                "\n\nSwitching folders does NOT move anything already saved — " +
                "only saves/states/screenshots made after switching go to the " +
                "new location. Nothing already there is deleted either; it's " +
                "just not used anymore until you switch back."
            resetBtn.visibility = if (tree != null) View.VISIBLE else View.GONE
        }

        val layout = ctx.dialogContentLayout().apply {
            statusText = TextView(ctx).apply { textSize = 12f; setTextColor(Color.WHITE) }
            addView(statusText)
            chooseBtn = Button(ctx).apply {
                text = "📁  Choose folder"
                setPadding(0, dp(16), 0, 0)
                setTextColor(Color.WHITE)
                setBackgroundColor(Color.parseColor("#553A3A4A"))
            }
            addView(chooseBtn)
            resetBtn = Button(ctx).apply {
                // FIX: was "Use app-internal storage instead" — accurate
                // before this pass, since the automatic fallback really was
                // always internal storage. Now that autoFolderRoot() (see
                // its own fix) normally resolves to a top-level folder
                // instead, generic wording that's correct either way beats
                // re-explaining both cases on a button label — the full
                // explanation already lives in statusText above.
                text = "↺  Use the automatic folder instead"
                setPadding(0, dp(16), 0, 0)
                setTextColor(Color.WHITE)
                setBackgroundColor(Color.parseColor("#553A3A4A"))
            }
            addView(resetBtn)
        }
        refresh()

        AlertDialog.Builder(ctx)
            .setTitle("💾  Storage")
            .setView(layout)
            .setNegativeButton("Close", null)
            .setOnDismissListener { refreshStorageSettingsUi = null }
            .show()
        refreshStorageSettingsUi = { refresh() }

        chooseBtn.setOnClickListener {
            // OpenDocumentTree's launch() takes an optional initial-location
            // Uri, not an Intent — read+write permission for whatever the
            // user picks comes back on the result URI automatically (that's
            // the whole point of a tree pick); dataFolderPicker's own
            // callback above is what persists it via
            // takePersistableUriPermission() so it survives app restarts.
            dataFolderPicker.launch(null)
        }
        resetBtn.setOnClickListener {
            AlertDialog.Builder(ctx)
                .setTitle("Use the automatic folder?")
                .setMessage("New saves/states/screenshots go back to the automatic \"mGBA\" folder described above. Nothing in the chosen folder is deleted.")
                .setPositiveButton("Switch back") { _, _ ->
                    getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove(PREF_DATA_FOLDER_URI).apply()
                    uiToast("Back to the automatic folder")
                    refresh()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    // ── Advanced ─────────────────────────────────────────────────────────

    private fun showAdvancedSettings() {
        val ctx = this
        val layout = ctx.dialogContentLayout().apply {
            addView(TextView(ctx).apply {
                text = "Resets game screen size, fullscreen, button size/opacity, sound settings, and fast-forward speed back to their defaults.\n\nThis does NOT clear custom button positions — reset those from Input → Edit Button Layout instead."
                textSize = 12f; setTextColor(Color.WHITE)
            })
        }
        val resetBtn = Button(ctx).apply {
            text = "↺  Reset settings to defaults"
            setPadding(0, dp(16), 0, 0)
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#553A3A4A"))
        }
        layout.addView(resetBtn)

        val dlg = AlertDialog.Builder(ctx)
            .setTitle("🎚  Advanced")
            .setView(layout)
            .setNegativeButton("Close", null)
            .show()

        resetBtn.setOnClickListener {
            AlertDialog.Builder(ctx)
                .setTitle("Reset settings?")
                .setMessage("This resets Video/Audio/Layouts/Misc settings to defaults.")
                .setPositiveButton("Reset") { _, _ ->
                    fastForwardSpeed      = 2.0f
                    buttonScaleMultiplier = 1.0f
                    buttonBaseAlpha       = 160
                    gameScreenFraction    = GAME_FRAC_NORM
                    // FIX: screenOrientationChoice/PREF_ORIENTATION was
                    // missing from this reset entirely, even though the
                    // confirm dialog above explicitly promises "Video"
                    // settings reset and Screen orientation is one (🖥
                    // Video → Screen orientation) — the exact same "added
                    // later, never wired into this reset block" gap this
                    // comment block already documents for
                    // stretchToFit/maxFrameSkips/linearFilterEnabled just
                    // below, just not caught the same pass.
                    screenOrientationChoice = ORIENTATION_LANDSCAPE
                    // FIX: stretchToFit/maxFrameSkips/linearFilterEnabled
                    // (all added two passes ago) were missing from this
                    // reset entirely — a gap from when they were added,
                    // not something this pass changed on purpose. Included
                    // now, alongside removing fullscreenMode, which no
                    // longer exists at all (see the field comment where
                    // gameScreenRect is declared).
                    stretchToFit          = false
                    maxFrameSkips         = 0
                    linearFilterEnabled   = false
                    // FIX (this pass): buttonSoundEnabled reset replaced —
                    // that field is gone along with the rest of the old
                    // button-click-sound feature (see showAudioSettings())
                    // — with the three settings that took its place.
                    soundEnabled          = true
                    soundVolumePercent    = 100
                    soundFrequencyHz      = 44100
                    showFpsOverlay        = false
                    gridDivisions         = 8
                    showGrid              = false
                    snapToGrid            = false
                    updateLinearFilterPaint()
                    updateSoundFrequencyFactor()
                    // Volume is always safe to (re)apply, live-idle or not
                    // — a no-op via audioTrack's own ?. if nothing's built
                    // yet. The frequency rebuild only matters while a game
                    // is actually running; see showSoundFrequencyDialog()'s
                    // own comment for why idle skips it.
                    applyGameVolume()
                    if (romLoaded) audioTrackRebuildPending = true
                    // Safe to call unconditionally regardless of romLoaded
                    // — applyScreenOrientationPref() already only applies
                    // screenOrientationChoice while a game is actually
                    // running, forcing Portrait otherwise (see its own doc
                    // comment), same as every other call site.
                    applyScreenOrientationPref()
                    getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                        .putFloat(PREF_FF_SPEED, fastForwardSpeed)
                        .putFloat(PREF_BTN_SCALE, buttonScaleMultiplier)
                        .putInt(PREF_BTN_ALPHA, buttonBaseAlpha)
                        .putFloat(PREF_SCREEN_FRAC, gameScreenFraction)
                        .putInt(PREF_ORIENTATION, screenOrientationChoice)
                        .putBoolean(PREF_STRETCH, stretchToFit)
                        .putInt(PREF_MAX_SKIPS, maxFrameSkips)
                        .putBoolean(PREF_LINEAR_FILTER, linearFilterEnabled)
                        .putBoolean(PREF_SOUND_ENABLED, soundEnabled)
                        .putInt(PREF_SOUND_VOLUME, soundVolumePercent)
                        .putInt(PREF_SOUND_FREQ, soundFrequencyHz)
                        .putBoolean(PREF_SHOW_FPS, showFpsOverlay)
                        .putInt(PREF_GRID_SIZE, gridDivisions)
                        .putBoolean(PREF_SHOW_GRID, showGrid)
                        .putBoolean(PREF_SNAP_GRID, snapToGrid)
                        .apply()
                    applyLayoutSettings()
                    uiToast("Settings reset to defaults")
                    dlg.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    // ── About ────────────────────────────────────────────────────────────

    private fun showAboutDialog() {
        val ctx = this
        val versionName = try {
            packageManager.getPackageInfo(packageName, 0).versionName ?: "—"
        } catch (e: PackageManager.NameNotFoundException) { "—" }

        val layout = ctx.dialogContentLayout().apply {
            addView(TextView(ctx).apply {
                text = getString(R.string.app_name); textSize = 18f; typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.WHITE)
            })
            addView(TextView(ctx).apply {
                text = "Version $versionName"
                textSize = 12f; setTextColor(Color.parseColor("#AAAAAA"))
                setPadding(0, dp(6), 0, dp(16))
            })
            addView(TextView(ctx).apply {
                text = "A custom Android build wrapping the mGBA core via JNI."
                textSize = 12f; setTextColor(Color.WHITE)
            })
        }

        AlertDialog.Builder(ctx)
            .setTitle("ℹ️  About")
            .setView(layout)
            .setPositiveButton("OK", null)
            .show()
    }

    /**
     * Rebuild control layout and game matrix after settings change.
     * Called on main thread; game thread picks up changes on next frame.
     * FIX: the explicit updateGameMatrix() call this used to make right
     * after buildControlLayout() is gone — buildControlLayout() calls it
     * internally now (see the note at its own end), so this was calling
     * it twice for no benefit.
     */
    private fun applyLayoutSettings() {
        val holder = surfaceHolder ?: return
        val sw = holder.surfaceFrame.width().toFloat()
        val sh = holder.surfaceFrame.height().toFloat()
        if (sw > 0f && sh > 0f) buildControlLayout(sw, sh)
    }

    // ── Save states ──────────────────────────────────────────────────────
    // Independent of the automatic battery save (see romPicker/nativeLoadROM)
    // — that persists whatever the *game itself* lets you save; these are
    // full emulator snapshots that let you resume from any exact moment,
    // GBA-hardware-save-menu or not. SAVE_STATE_SLOTS per-ROM slots, each a
    // plain file under statesDir(), named/keyed by currentRomBaseName so
    // switching ROMs never shows another game's slots.

    private fun showSaveStateMenu() {
        if (!romLoaded) { uiToast("Load a ROM first"); return }
        AlertDialog.Builder(this)
            .setTitle("💾  Save States")
            .setItems(arrayOf("Save State", "Load State")) { _, which ->
                showSaveStateSlotDialog(forSave = which == 0)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ── Save-state thumbnails ────────────────────────────────────────────
    // FEATURE: new. Reuses takeScreenshot()'s exact technique (PixelCopy off
    // the live SurfaceView) rather than adding any new native/JNI surface —
    // this project's own history shows hand-written JNI exports are exactly
    // where build-vs-sandbox mismatches turn up (see FIX 8 in mgba_jni.c),
    // so avoiding a new one here entirely sidesteps that risk. The one
    // difference from takeScreenshot(): this runs on the state-save
    // background thread (see showSaveStateSlotDialog) rather than the UI
    // thread, and PixelCopy.request() only takes a Handler for where its
    // *result callback* lands, not for which thread it may be called from —
    // so a CountDownLatch turns that callback back into a plain blocking
    // call, keeping the save flow linear instead of splitting it across two
    // independent async paths.
    private fun captureStateThumbnail(slot: Int) {
        try {
            val w = surfaceView.width
            val h = surfaceView.height
            if (w <= 0 || h <= 0) return
            val full = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val latch = CountDownLatch(1)
            var ok = false
            PixelCopy.request(surfaceView, full, { result ->
                ok = (result == PixelCopy.SUCCESS)
                latch.countDown()
            }, Handler(Looper.getMainLooper()))
            latch.await(500, TimeUnit.MILLISECONDS)
            if (!ok) return
            // Derive height from the surface's own current aspect ratio
            // instead of hardcoding one — see STATE_THUMB_WIDTH_PX's comment.
            val thumbH = (STATE_THUMB_WIDTH_PX.toLong() * h / w).toInt().coerceAtLeast(1)
            val thumb = Bitmap.createScaledBitmap(full, STATE_THUMB_WIDTH_PX, thumbH, true)
            val thumbEntry = stateThumbEntry(slot)
            thumbEntry.outputStream().use { out -> thumb.compress(Bitmap.CompressFormat.PNG, 90, out) }
            thumbEntry.mirrorToAutoFolder()
        } catch (e: Exception) {
            // Best-effort, same spirit as backupIfExists(): a thumbnail
            // failure must never be surfaced as a save failure.
            Log.w(TAG, "State thumbnail capture failed (save itself is unaffected)", e)
        }
    }

    /**
     *  Row view for showSaveStateSlotDialog()'s ListView.
     *
     *  FIX (Eleventh pass) applies here too, deliberately: do NOT set
     *  isClickable/isFocusable on this row or on either child, and do not
     *  give the row its own setOnClickListener. This is a ListView item
     *  inside an AlertDialog exactly like gameMenuRow() — see that
     *  function's comment and BUGS_FIXED.md's Eleventh-pass entry for the
     *  full explanation of why that combination silently eats every tap.
     *  Clicks here are meant to reach the ListView's own OnItemClickListener
     *  (the `{ _, which -> ... }` lambda passed to setAdapter() below) and
     *  nothing else.
     */
    private fun stateSlotRow(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(24), dp(14), dp(24), dp(14))
            setBackgroundResource(rippleBackgroundResId())
            addView(ImageView(this@MainActivity).apply {
                layoutParams = LinearLayout.LayoutParams(dp(96), dp(64))
                scaleType = ImageView.ScaleType.CENTER_CROP
                setBackgroundColor(Color.parseColor("#2A2A2A"))
            })
            addView(TextView(this@MainActivity).apply {
                layoutParams = LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f
                ).apply { marginStart = dp(24) }
                textSize = 16f
                setTextColor(Color.WHITE)
            })
        }
    }

    /** Row data for showSaveStateSlotDialog()'s ListView — hoisted out of
     *  that function (it used to be a local `data class`) so slotInfoCache
     *  below can hold instances of it between calls. */
    private data class SlotInfo(val slot: Int, val entry: SaveEntry, val exists: Boolean, val modified: Long, val label: String, val thumb: Bitmap?)

    /** FIX (menu-slot speed pass): cache of each slot's already-decoded
     *  SlotInfo, keyed by "$currentRomBaseName:$slot" (the ROM name is
     *  part of the key since slot *numbers* repeat across ROMs but refer
     *  to different underlying files). showSaveStateSlotDialog() below
     *  re-decodes a slot's thumbnail from disk only when that slot's
     *  exists/modified no longer match what's cached — i.e. only when the
     *  data's actually stale, typically right after a save to that same
     *  slot. Before this, opening the dialog re-read and re-decoded every
     *  slot's PNG from disk on *every single open*, even when nothing had
     *  changed since the last time you looked — most of what made
     *  "menu tap -> slot list appearing" feel slow on repeat opens.
     *  ConcurrentHashMap since a fast reopen could plausibly start a
     *  second listing thread before the first one's finished.
     *
     *  FIX: was genuinely unbounded — grows by one entry per (ROM name,
     *  slot) combination ever viewed, for the life of the process. In
     *  practice this stays tiny (thumbnails are only STATE_THUMB_WIDTH_PX
     *  wide and there are only SAVE_STATE_SLOTS slots, so even a long
     *  session across many ROMs stays in the low single-digit MB) — this
     *  cap is a cheap backstop on principle rather than a fix for any
     *  actually-observed growth. Simplest possible bound rather than real
     *  LRU eviction: once the cache would exceed SLOT_INFO_CACHE_MAX
     *  entries, it's cleared outright (a plain ConcurrentHashMap has no
     *  built-in ordering to evict-oldest-first with, and reaching this cap
     *  at all would already mean hundreds of distinct ROMs played in one
     *  process lifetime) — the next dialog open just repopulates whatever
     *  it needs, same cost as any other cache miss. */
    private val slotInfoCache = java.util.concurrent.ConcurrentHashMap<String, SlotInfo>()
    private fun cacheSlotInfo(key: String, info: SlotInfo): SlotInfo {
        if (slotInfoCache.size >= SLOT_INFO_CACHE_MAX) slotInfoCache.clear()
        slotInfoCache[key] = info
        return info
    }

    private fun showSaveStateSlotDialog(forSave: Boolean) {
        Thread {
            // One folder resolution + one listing, reused for every slot
            // and every thumbnail below — instead of SaveEntry.doc()
            // re-resolving and re-listing this same folder from scratch
            // for each of the ~12 lookups this dialog used to make.
            val folderRoot = dataSubfolder("save")
            val docsByName: Map<String, DocumentFile>? =
                folderRoot?.listFiles()?.mapNotNull { d -> d.name?.let { it to d } }?.toMap()

            val slots = (1..SAVE_STATE_SLOTS).map { slot ->
                val entry = stateSlotEntry(slot)
                val exists: Boolean
                val modified: Long
                if (docsByName != null) {
                    val stateDoc = docsByName[stateSlotFile(slot).name]
                    exists = stateDoc != null
                    modified = stateDoc?.lastModified() ?: 0L
                } else {
                    // No Storage folder configured — plain internal-storage
                    // File calls, same as before this fix, just now off
                    // the UI thread too for consistency.
                    exists = entry.exists()
                    modified = entry.lastModified()
                }

                val cacheKey = "$currentRomBaseName:$slot"
                val cached = slotInfoCache[cacheKey]
                if (cached != null && cached.exists == exists && cached.modified == modified) {
                    // Cache hit — nothing about this slot has changed since
                    // the last time we decoded it, so skip the disk read
                    // and PNG decode entirely.
                    cached
                } else {
                    val thumbStream: InputStream? = if (docsByName != null) {
                        docsByName[stateThumbFile(slot).name]?.let {
                            try { contentResolver.openInputStream(it.uri) } catch (e: Exception) { null }
                        }
                    } else {
                        stateThumbEntry(slot).inputStream()
                    }
                    val label = if (exists) "Slot $slot — ${DateFormat.format("MMM d, h:mm a", modified)}"
                                else         "Slot $slot — Empty"
                    val bmp = try {
                        thumbStream?.use { BitmapFactory.decodeStream(it) }
                    } catch (e: Exception) {
                        Log.w(TAG, "Corrupt state thumbnail for slot $slot", e); null
                    }
                    cacheSlotInfo(cacheKey, SlotInfo(slot, entry, exists, modified, label, bmp))
                }
            }

            Handler(Looper.getMainLooper()).post {
                if (isFinishing || isDestroyed) return@post

                val adapter = object : ArrayAdapter<SlotInfo>(this, 0, slots) {
                    override fun getView(position: Int, recycled: View?, parent: ViewGroup): View {
                        val row = recycled as? LinearLayout ?: stateSlotRow()
                        val info = getItem(position)!!
                        (row.getChildAt(1) as TextView).text = info.label
                        val icon = row.getChildAt(0) as ImageView
                        if (info.thumb != null) icon.setImageBitmap(info.thumb) else icon.setImageDrawable(null)
                        return row
                    }
                }

                AlertDialog.Builder(this)
                    .setTitle(if (forSave) "Save to which slot?" else "Load which slot?")
                    .setAdapter(adapter) { _, index ->
                        val info = slots[index]
                        val slot = info.slot
                        val entry = info.entry
                        // Reuses the exists flag this same background pass
                        // already computed, instead of calling
                        // entry.exists() again here on the UI thread.
                        if (!forSave && !info.exists) {
                            uiToast("Slot $slot is empty"); return@setAdapter
                        }
                        // FIX (audit pass): same guard quickSaveState()/
                        // quickLoadState() already have and for the same
                        // reason — see saveStateBusy's own doc comment.
                        // Picking a slot dismisses this dialog, so hitting
                        // this needs two separate menu visits in quick
                        // succession rather than one fast double-tap, but
                        // the underlying race (two unordered Threads both
                        // calling nativeSaveState()/nativeLoadState()) is
                        // identical.
                        if (!saveStateBusy.compareAndSet(false, true)) {
                            uiToast("Still saving/loading — try again in a moment"); return@setAdapter
                        }
                        // Runs off the UI thread — same pattern as romPicker above —
                        // since this touches disk and briefly holds the native
                        // core's mutex against the running game thread.
                        Thread {
                            try {
                            // FEATURE: auto save backup — nativeSaveState() truncates
                            // this slot's file the instant it's called (VFileOpen
                            // uses O_TRUNC — see mgba_jni.c), so anything already in
                            // it is gone the moment a save starts, even if the write
                            // itself then fails partway through. The thumbnail gets
                            // the same one-level rolling backup, for the same reason.
                            if (forSave) { backupIfExists(entry); backupIfExists(stateThumbEntry(slot)) }
                            val ok = if (forSave) {
                                val localPath = entry.stageForWrite()
                                val saved = EmulatorEngine.nativeSaveState(localPath)
                                if (saved) {
                                    entry.commitWrite(localPath)
                                    entry.mirrorToAutoFolder()
                                }
                                saved
                            } else {
                                val localPath = entry.stageForRead()
                                localPath != null && EmulatorEngine.nativeLoadState(localPath)
                            }
                            // FIX (this pass): confirmation now fires right here,
                            // the instant the actual save/load call above
                            // returns, instead of after captureStateThumbnail()
                            // below. Thumbnail capture waits on PixelCopy (up to
                            // 500ms — see its own comment) and then scales/PNG-
                            // encodes a full-screen bitmap, so leaving the toast
                            // after it made every single save feel sluggish even
                            // though the actual state write is already done and
                            // safe on disk by this point. uiToast() posts to the
                            // main thread and returns immediately, so this still
                            // doesn't block the thumbnail capture that follows —
                            // it just no longer waits on it first.
                            uiToast(when {
                                ok && forSave -> "Saved to Slot $slot"
                                ok            -> "Loaded Slot $slot"
                                forSave       -> "Save failed"
                                else          -> "Load failed — slot may be from a different ROM"
                            })
                            // Thumbnail only on a *successful* save — an old
                            // thumbnail surviving a failed save (whose backupIfExists
                            // call above already preserved it under .bak regardless)
                            // is more useful than no thumbnail at all. Runs after
                            // the confirmation above now, so the slot list simply
                            // won't show the new thumbnail until it's next opened,
                            // rather than the save itself feeling delayed.
                            if (ok && forSave) captureStateThumbnail(slot)
                            } finally {
                                // FIX (audit pass): mirrors quickSaveState()/
                                // quickLoadState()'s finally block — always
                                // clears the guard, success or failure, so a
                                // save/load that throws can't leave every
                                // future attempt permanently blocked.
                                saveStateBusy.set(false)
                            }
                        }.apply { name = "mGBA-state" }.start()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
        }.apply { name = "mGBA-slot-list" }.start()
    }

    // ── Link cable UI ──────────────────────────────────────────────────────
    // Split into two Settings rows — "Link remote" (Wi-Fi) and "Link local"
    // (Bluetooth) — instead of one combined dialog behind the old floating
    // 🔗 button (see buildSettingsMenu()). Nothing about the connect logic
    // itself changed, just how it's reached. Status used to also update
    // that floating button's label; now it's toasts only, plus the existing
    // ⬤ LINK canvas overlay (drawLinkStatus, below) for "still connected".

    private fun showLinkRemoteDialog() {
        if (link.isConnected) { showLinkDisconnectDialog(); return }
        AlertDialog.Builder(this).setTitle("Link Remote — Wi-Fi")
            .setItems(arrayOf("Host", "Join")) { _, i ->
                when (i) {
                    0 -> link.startWifiHost(
                        onReady     = { ip -> uiToast("Waiting…\nIP: $ip") },
                        onConnected = { onLinkConnected(true,  "Wi-Fi") },
                        onError     = { uiToast("Host error: $it") })
                    1 -> {
                        uiToast("Scanning…")
                        link.discoverWifiHosts(
                            onFound = { hosts ->
                                if (hosts.isEmpty()) showIpDialog()
                                else AlertDialog.Builder(this)
                                    .setTitle("Select host")
                                    .setItems(hosts.toTypedArray()) { _, j -> joinWifi(hosts[j]) }
                                    .setNegativeButton("Enter IP") { _, _ -> showIpDialog() }.show()
                            },
                            onError = { showIpDialog() })
                    }
                }
            }.show()
    }

    private fun showLinkLocalDialog() {
        if (link.isConnected) { showLinkDisconnectDialog(); return }
        AlertDialog.Builder(this).setTitle("Link Local — Bluetooth")
            .setItems(arrayOf("Host", "Join")) { _, i ->
                when (i) {
                    // FIX: BLUETOOTH_CONNECT is a runtime-dangerous permission on API 31+.
                    // It was declared in the manifest but never requested, so tapping either
                    // of these two options crashed the app on Android 12+ with an uncaught
                    // SecurityException from listenUsingInsecureRfcommWithServiceRecord() /
                    // createInsecureRfcommSocketToServiceRecord() / getBondedDevices().
                    0 -> ensureBluetoothPermission {
                        uiToast("Starting host…")
                        link.startBluetoothHost(
                            onConnected = { onLinkConnected(true,  "Bluetooth") },
                            onError     = { uiToast("BT error: $it") })
                    }
                    1 -> ensureBluetoothPermission {
                        val devs = link.getBondedDevices()
                        if (devs.isEmpty()) { uiToast("No paired devices"); return@ensureBluetoothPermission }
                        AlertDialog.Builder(this).setTitle("Choose device")
                            .setItems(devs.map { it.name ?: it.address }.toTypedArray()) { _, j ->
                                uiToast("Connecting…")
                                link.connectBluetooth(devs[j],
                                    onConnected = { onLinkConnected(false, "Bluetooth") },
                                    onError     = { uiToast("BT error: $it") })
                            }.show()
                    }
                }
            }.show()
    }

    private fun showLinkDisconnectDialog() {
        AlertDialog.Builder(this).setTitle("Link Connected ✓")
            .setItems(arrayOf("Disconnect")) { _, _ -> stopLink() }.show()
    }

    private fun showIpDialog() {
        val et = EditText(this).apply { hint = "192.168.x.x" }
        AlertDialog.Builder(this).setTitle("Host IP").setView(et)
            .setPositiveButton("Connect") { _, _ -> joinWifi(et.text.toString().trim()) }.show()
    }

    private fun joinWifi(ip: String) {
        if (ip.isBlank()) return
        uiToast("Connecting…")
        link.connectWifi(ip,
            onConnected = { onLinkConnected(false, "Wi-Fi") },
            onError     = { uiToast("Connect error: $it") })
    }

    private fun onLinkConnected(isHost: Boolean, via: String) {
        val ok = EmulatorEngine.nativeLinkStart(link, isHost)
        uiToast("Link via $via${if (!ok) " (SIO error)" else ""}")
    }

    private fun stopLink() {
        EmulatorEngine.nativeLinkStop(); link.disconnect()
        uiToast("Disconnected")
    }

    // ── Link status overlay ────────────────────────────────────────────────

    private val linkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#CC22BB77"); textSize = 26f
    }
    private fun drawLinkStatus(canvas: Canvas) =
        canvas.drawText("⬤ LINK", 14f, canvas.height - 14f, linkPaint)

    // ── Performance overlay (FEATURE — see the field comments above) ───────

    private val fpsPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#CCFFFFFF"); textSize = 24f; textAlign = Paint.Align.RIGHT
    }
    private fun drawFpsOverlay(canvas: Canvas) =
        canvas.drawText(fpsOverlayText, canvas.width - 14f, 32f, fpsPaint)

    // ── Helpers ────────────────────────────────────────────────────────────

    // uiToast() moved to SharedUi.kt this pass as an Activity extension —
    // RomBrowserActivity needs it too for permission-flow messages.

    @Suppress("DEPRECATION")
    private fun setImmersive() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
    }
}
