/* AI Empire Tycoon - game logic (no DOM access in this file) */
(function () {
  'use strict';
  const G = window.G, D = G.D, U = G.U;
  const clamp = U.clamp;
  const MONTH = 600, YEAR = MONTH * 12; // one in-game month lasts ten real minutes
  G.MONTH = MONTH; G.YEAR = YEAR;
  G.act = {};
  D.pmap = {};
  D.partners.forEach((p) => (D.pmap[p.id] = p));
  const nowMs = () => Date.now();

  /* ---------- tuning constants ---------- */
  const K = (G.K = {
    startCash: 6000, startUsers: 500,
    adsRpu: 0.0011, conv0: 0.03, apiRate: 0.0012, apiBase: 45, imgRate: 0.05, imgPrice: 5, agentRate: 0.0006, agentPrice: 900,
    payBase: 0.15, payPct: 0.2, powerPrice: 18, revBase: 1.5, upkeep: 0.000018, growth0: 0.004, churn: 0.003,
    mkt: [0, 0.02, 0.05, 0.1, 0.18], mktG: [1, 1.2, 1.5, 1.9, 2.5], rd: [0, 0.03, 0.07, 0.12], rdSpd: [1, 1.15, 1.35, 1.7]
  });

  /* ---------- tiny event bus ---------- */
  const L = {};
  G.on = (t, f) => { (L[t] = L[t] || []).push(f); };
  G.emit = (t, p) => {
    const a = L[t];
    if (!a) return;
    for (const f of a) { try { f(p); } catch (e) { if (G.err) G.err(e); } }
  };
  G.quiet = false;
  G.log = [];
  function note(kind, text, toast) {
    const s = G.state;
    s.feed.unshift({ t: nowMs(), k: kind, x: text });
    if (s.feed.length > 40) s.feed.length = 40;
    if (G.quiet) G.log.push({ k: kind, x: text });
    else if (toast !== false) G.emit('toast', { kind, text });
  }
  G.note = note;
  function fail(msg) { G.emit('toast', { kind: 'warn', text: msg }); return { ok: false, msg }; }
  const OK = { ok: true };

  /* ---------- state ---------- */
  G.newState = function (carry) {
    carry = carry || {};
    const t = nowMs();
    const pres = carry.pres || { patents: 0, total: 0, count: 0, up: {}, skin: 'midnight', skins: { midnight: true } };
    const seedLvl = (pres.up && pres.up.seed) || 0;
    const s = {
      v: 1, created: t, lastSeen: t, lastSave: t, gt: 0, name: carry.name || 'Lumora AI',
      cash: K.startCash * Math.pow(2.2, seedLvl), users: K.startUsers, sat: 70, hype: 0,
      price: 6, ads: true, mkt: 0, rd: 0,
      models: { basic: { st: 'rel', tune: 0, rev: 0, at: t } }, active: 'basic', job: null,
      res: { done: {}, q: [] },
      inf: { g1: 2, g2: 0, g3: 0, g4: 0, g5: 0, racks: 1, dc: 0, cool: 0, pwr: 0, net: 0, lab: 0, hq: 0 },
      build: [], infraValue: 0, contracts: {}, regions: { na: { hub: 1 } },
      comp: {}, ach: carry.ach || {}, daily: { day: '', list: [] },
      pres,
      set: carry.set || { music: 0.3, sfx: 0.7, anim: 1 },
      stats: carry.stats || { rev: 0, exp: 0, jobs: 0, research: 0, servers: 0, builds: 0, contracts: 0, releases: 0, userGain: 0, tunes: 0, play: 0, offlineEarned: 0, peakUsers: 0 },
      feed: [], hist: [], nextEvt: 600 + Math.random() * 600, _acc: 0
    };
    for (const c of D.comps) s.comp[c.id] = { intel: c.intel0, buzz: 0, next: U.lerp(c.every[0], c.every[1], Math.random()) * 0.6, launches: 0 };
    const fk = (pres.up && pres.up.founder) || 0;
    for (let i = 0; i < fk; i++) for (const id of D.founderKit[i]) s.res.done[id] = 1;
    return s;
  };

  /* ---------- modifiers ---------- */
  const RED = ['trainCost', 'dem', 'serve', 'pw', 'opex', 'resCost'];
  function applyEff(M, e, mul) {
    if (!e) return;
    for (const k in e) {
      if (k === 'flag') { M.flags[e[k]] = 1; continue; }
      const v = e[k] * (mul || 1);
      if (k === 'offCap') M.offCap += v * 3600;
      else if (RED.indexOf(k) >= 0) M[k] *= Math.max(0.05, 1 - v);
      else if (k in M) M[k] += v;
    }
  }
  G.mods = function (s) {
    const M = {
      intel: 1, appeal: 1, trainSpeed: 1, conv: 1, growth: 1, ent: 1, api: 1, img: 1, agent: 1, resSpeed: 1, util: 1, cap: 1, cool: 1,
      net: 0, sat: 0, entSlots: 0, resSlots: 1, offEff: 0.5, rev: K.revBase, compRes: 0, trainCost: 1, dem: 1, serve: 1, pw: 1, opex: 1, resCost: 1,
      offCap: 6 * 3600, flags: {}
    };
    for (const id in s.res.done) { const n = D.rmap[id]; if (n) applyEff(M, n.eff); }
    applyEff(M, D.ladders.hq[s.inf.hq].eff);
    applyEff(M, D.ladders.lab[s.inf.lab].eff);
    for (const id in s.pres.up) { const l = D.legacyMap[id]; if (l) applyEff(M, l.eff, s.pres.up[id]); }
    M.rev += 0.01 * Object.keys(s.ach).length + 0.3 * Math.sqrt(s.pres.total);
    M.resSpeed *= K.rdSpd[s.rd] || 1;
    M.offEff = Math.min(0.9, M.offEff);
    M.compRes = Math.min(0.6, M.compRes);
    return M;
  };

  /* ---------- derived economy snapshot ---------- */
  G.calc = function () {
    const s = G.state, M = G.mods(s), F = M.flags;
    const m = D.mmap[s.active] || D.models[0];
    const ms = s.models[m.id] || { tune: 0 };
    const tune = ms.tune || 0;
    const gen = m.gen;
    const C = { M, F, m, gen };
    C.intel = m.intel * (1 + 0.08 * tune) * M.intel;
    C.speed = m.speed * (1 + 0.05 * tune);
    C.appeal = Math.min(0.8, m.adopt * (1 + 0.05 * tune) * M.appeal);
    C.st = { premium: !!F.premium, api: !!F.api, ent: !!F.ent, img: !!F.img && gen >= 5, voice: !!F.voice && gen >= 6, code: !!F.code && gen >= 7, agent: !!F.agent && gen >= 8, video: !!F.video && !!F.img && gen >= 5 };
    const st = C.st;

    // hardware, power, cooling
    let raw = 0, draw = 0, nSrv = 0;
    for (const h of D.hw) { const n = s.inf[h.k] || 0; raw += n * h.tf; draw += n * h.mw; nSrv += n; }
    C.nServers = nSrv;
    const net = D.ladders.net[s.inf.net], cool = D.ladders.cool[s.inf.cool], pw = D.ladders.pwr[s.inf.pwr];
    let hubs = 0, nReg = 0;
    for (const id in s.regions) { hubs += s.regions[id].hub; nReg++; }
    C.nRegions = nReg;
    C.netEff = Math.min(1, net.eff + M.net);
    C.rawCap = raw * M.cap * (1 + 0.02 * hubs) * (1 + D.ladders.dc[s.inf.dc].bonus) * C.netEff * M.util;
    C.powerCap = pw.cap; C.powerDraw = draw;
    C.powerRatio = draw > 0 ? Math.min(1, pw.cap / draw) : 1;
    C.heat = draw * 0.9 * C.powerRatio;
    C.coolCap = cool.cap * M.cool;
    C.overheat = Math.max(0, C.heat / C.coolCap - 1);
    C.rel = clamp(1 - 0.45 * C.overheat, 0.4, 1);
    C.capEff = C.rawCap * C.powerRatio * C.rel;
    let ctf = 0, nC = 0, entMrr = 0;
    for (const id in s.contracts) { const p = D.pmap[id]; if (p) { ctf += p.tf; entMrr += p.mrr; nC++; } }
    C.nContracts = nC; C.ctf = ctf;
    C.jobTf = s.job ? s.job.tf : 0;
    C.capAvail = Math.max(0, C.capEff - ctf - C.jobTf);
    C.slotsTotal = s.inf.racks * D.rack.slots; C.slotsUsed = nSrv; C.rackCap = D.ladders.dc[s.inf.dc].racks;

    // demand and service quality
    const load = 1 + (st.img ? 0.25 : 0) + (st.video ? 0.3 : 0) + (st.voice ? 0.2 : 0) + (st.agent ? 0.6 : 0);
    C.load = load;
    C.demand = s.users * m.cpu * load * M.dem;
    C.sr = C.demand <= 1e-9 ? 1 : clamp(C.capAvail / C.demand, 0, 1);
    C.uptime = clamp(99.95 - (1 - C.rel) * 40 - (1 - C.sr) * 30, 20, 99.99);
    C.util = C.capEff > 0 ? clamp((C.demand + ctf + C.jobTf) / C.capEff, 0, 9.99) : 9.99;

    // competition and potential users
    let cs = 0;
    for (const c of D.comps) { const k = s.comp[c.id]; cs += Math.pow(k.intel, 1.15) * c.mkt * (1 + k.buzz); }
    C.cs = cs;
    const hype = Math.min(s.hype, 3);
    const ps = Math.pow(C.intel, 1.15) * (0.6 + (0.8 * s.sat) / 100) * (1 + 0.08 * s.mkt) * (1 + 0.3 * hype);
    C.ps = ps;
    let pot = 0, wA = 0, wO = 0, wG = 0, wI = 0, popSum = 0, shareW = 0;
    C.reg = {};
    for (const r of D.regions) {
      const rs = s.regions[r.id];
      if (!rs) continue;
      const sh = ps / (ps + cs * r.comp * (1 - M.compRes));
      const reach = D.hubReach[rs.hub];
      const p = Math.min(r.pop * 1e6 * reach * 0.92, r.pop * 1e6 * C.appeal * sh * reach * (1 + 0.06 * s.mkt) * (1 + 0.6 * hype));
      C.reg[r.id] = { share: sh, pot: p, reach };
      pot += p; wA += p * r.arpu; wO += p * r.opex; wG += p * r.growth; wI += p * r.infra;
      popSum += r.pop * reach; shareW += sh * r.pop * reach;
    }
    C.pot = pot;
    C.share = popSum > 0 ? shareW / popSum : 0;
    C.arpuMul = pot > 0 ? wA / pot : 1; C.opexMul = pot > 0 ? wO / pot : 1; C.growthMul = pot > 0 ? wG / pot : 1; C.infraMul = pot > 0 ? wI / pot : 1;
    // market share bar (player vs rivals)
    C.shares = [{ id: 'me', name: s.name, share: C.share, color: '#3dd6c6' }];
    const rival = 1 - C.share;
    for (const c of D.comps) { const k = s.comp[c.id]; const v = Math.pow(k.intel, 1.15) * c.mkt * (1 + k.buzz); C.shares.push({ id: c.id, name: c.name, share: cs > 0 ? rival * v / cs : 0, color: c.color }); }

    // revenue
    const served = s.users * C.sr;
    C.served = served;
    const fair = m.fair * (1 + (st.voice ? 0.15 : 0)) * (1 + 0.04 * tune);
    C.fair = fair;
    const pf = clamp(Math.pow(fair / Math.max(1, s.price), 1.5), 0.04, 2.0);
    C.conv = st.premium ? clamp(K.conv0 * M.conv * pf * (0.5 + s.sat / 100), 0, 0.3) : 0;
    C.subs = served * C.conv;
    const R = { ads: 0, subs: 0, api: 0, ent: 0, img: 0, agent: 0, total: 0 };
    R.ads = s.ads ? (served - C.subs) * K.adsRpu * (1 + 0.15 * (gen - 1)) : 0;
    R.subs = (C.subs * s.price) / MONTH;
    C.apiCust = st.api ? served * K.apiRate * M.api : 0;
    R.api = (C.apiCust * K.apiBase * Math.pow(Math.max(1, C.intel) / 10, 0.55)) / MONTH;
    C.imgUsers = st.img ? served * K.imgRate : 0;
    R.img = (C.imgUsers * K.imgPrice * M.img) / MONTH;
    C.agents = st.agent ? served * K.agentRate : 0;
    R.agent = (C.agents * K.agentPrice * M.agent) / MONTH;
    const gm = M.rev * C.arpuMul;
    R.ads *= gm; R.subs *= gm; R.api *= gm; R.img *= gm; R.agent *= gm;
    R.ent = (entMrr * M.ent * (C.uptime >= 90 ? 1 : 0.6) * M.rev) / MONTH;
    R.total = R.ads + R.subs + R.api + R.ent + R.img + R.agent;
    C.rev = R;

    // expenses
    const E = {};
    E.power = draw * C.powerRatio * cool.pue * pw.price * K.powerPrice * M.pw * C.opexMul;
    E.upkeep = s.infraValue * K.upkeep * M.opex;
    E.serve = served * m.op * M.serve * C.opexMul;
    E.payroll = (K.payBase * Math.pow(6, s.inf.hq) + K.payPct * R.total) * M.opex * C.opexMul;
    E.mkt = R.total * K.mkt[s.mkt];
    E.rd = R.total * K.rd[s.rd];
    E.total = E.power + E.upkeep + E.serve + E.payroll + E.mkt + E.rd;
    C.exp = E;
    C.net = R.total - E.total;
    C.margin = R.total > 0 ? C.net / R.total : 0;
    C.val = s.cash + 0.6 * s.infraValue + R.total * YEAR * (3 + 1.4 * gen + 8 * C.share) + s.users * 0.6;

    // dynamics targets
    C.growth = K.growth0 * M.growth * K.mktG[s.mkt] * C.growthMul * (0.5 + (0.8 * s.sat) / 100) * (0.3 + 0.7 * C.sr) * (1 + 0.5 * hype) * (s.ads ? 0.95 : 1);
    let satT = 58 + Math.min(25, Math.sqrt(C.intel) * 1.2) + M.sat;
    satT -= (1 - C.rel) * 50 + (1 - C.sr) * 30;
    if (s.ads) satT -= 4;
    if (s.price > fair * 1.4) satT -= Math.min(15, (s.price / fair - 1.4) * 20);
    satT += 4 * Math.min(1, hype);
    C.satT = clamp(satT, 5, 100);
    C.resSlots = Math.floor(M.resSlots);
    G.C = C;
    return C;
  };
  G.cm = () => (G.C && G.C.infraMul) || 1;

  /* ---------- timers ---------- */
  function progressBuild(s, dt) {
    for (let i = s.build.length - 1; i >= 0; i--) {
      const b = s.build[i];
      b.left -= dt;
      if (b.left <= 0) {
        s.build.splice(i, 1);
        if (b.k === 'reg') s.regions[b.id] = { hub: b.to };
        else s.inf[b.k] = b.to;
        s.stats.builds++;
        const nm = b.k === 'reg' ? D.rgmap[b.id].name + (b.to > 1 ? ' hub level ' + b.to : ' region') : D.ladders[b.k][b.to].name;
        note('build', nm + ' is ready.');
        G.emit('build_done', b);
      }
    }
  }
  function progressResearch(s, C, dt) {
    const q = s.res.q;
    for (let i = q.length - 1; i >= 0; i--) {
      const p = q[i];
      p.left -= dt * C.M.resSpeed;
      if (p.left <= 0) {
        q.splice(i, 1);
        s.res.done[p.id] = 1;
        s.stats.research++;
        note('research', D.rmap[p.id].name + ' research complete.');
        G.emit('research_done', D.rmap[p.id]);
      }
    }
  }
  function progressJob(s, C, dt) {
    const j = s.job;
    if (!j) return;
    j.left -= dt * C.M.trainSpeed;
    if (j.left <= 0) {
      s.job = null;
      if (j.kind === 'new') {
        s.models[j.id] = { st: 'trained', tune: 0, rev: 0, at: nowMs() };
        note('train', D.mmap[j.id].name + ' finished training and is ready to release.');
      } else {
        s.models[j.id].tune = (s.models[j.id].tune || 0) + 1;
        s.stats.tunes++;
        note('train', D.mmap[j.id].name + ' fine-tuning complete (level ' + s.models[j.id].tune + ').');
      }
      G.emit('train_done', j);
    }
  }
  function progressComp(s, C, dt) {
    for (const c of D.comps) {
      const k = s.comp[c.id];
      k.buzz *= Math.exp(-dt * 0.002);
      if (s.gt >= k.next) {
        const target = D.compCurve(s.gt) * c.f;
        k.intel = Math.max(k.intel * 1.02, target * U.lerp(0.97, 1.08, Math.random()));
        k.buzz = Math.min(1.5, k.buzz + 0.6);
        k.next = s.gt + U.lerp(c.every[0], c.every[1], Math.random());
        k.launches++;
        note('comp', c.name + ' launched ' + U.pick(D.compProducts) + '-' + (k.launches + 1) + '. Rivals are gaining ground.');
      }
    }
    if (s.gt >= s.nextEvt) {
      s.hype = Math.min(4, s.hype + 0.5);
      s.nextEvt = s.gt + 700 + Math.random() * 800;
      note('event', U.pick(D.hypeNews).replace('{m}', (D.mmap[s.active] || D.models[0]).name));
    }
  }

  /* ---------- main tick ---------- */
  G.hist = [];
  G.tick = function (dt, econ) {
    const s = G.state;
    if (!(dt > 0)) return;
    if (econ === undefined) econ = 1;
    const C = G.calc();
    const e = dt * econ;
    s.gt += dt;
    if (!G.quiet) s.stats.play += dt;
    progressBuild(s, dt);
    progressResearch(s, C, dt);
    progressJob(s, C, dt);
    progressComp(s, C, dt);
    s.hype = s.hype * Math.exp(-dt * 0.0046);
    if (s.hype < 0.001) s.hype = 0;

    const u0 = s.users;
    if (s.users < C.pot) s.users += (C.pot - s.users) * (1 - Math.exp(-C.growth * e));
    else s.users -= (s.users - C.pot) * (1 - Math.exp(-K.churn * e));
    if (s.users > u0) s.stats.userGain += s.users - u0;
    if (s.users > s.stats.peakUsers) s.stats.peakUsers = s.users;
    s.sat += (C.satT - s.sat) * (1 - Math.exp(-0.03 * e));
    const gain = C.net * e;
    s.cash = Math.max(0, s.cash + gain);
    s.stats.rev += C.rev.total * e;
    s.stats.exp += C.exp.total * e;
    const am = s.models[s.active];
    if (am) am.rev = (am.rev || 0) + C.rev.total * e;
    G.fix(s);

    s._acc += dt;
    if (s._acc >= 1) {
      s._acc = 0;
      checkAch(s, C);
      G.ensureDaily();
      if (!G.quiet) {
        G.hist.push({ r: C.rev.total, e: C.exp.total, n: C.net, u: s.users });
        if (G.hist.length > 90) G.hist.shift();
      }
    }
  };
  G.fix = function (s) {
    for (const k of ['cash', 'users', 'sat', 'hype', 'gt']) if (!isFinite(s[k]) || s[k] < 0) s[k] = k === 'users' ? K.startUsers : 0;
    if (s.sat > 100) s.sat = 100;
  };

  /* ---------- time handling (live and offline) ---------- */
  G.frame = function () {
    const s = G.state, t = nowMs();
    let gap = (t - s.lastSeen) / 1000;
    s.lastSeen = t;
    if (!(gap > 0)) return null;
    if (gap > 5) {
      const r = G.offline(gap);
      return gap >= 45 ? r : null;
    }
    G.tick(gap, 1);
    return null;
  };
  G.offline = function (away) {
    const s = G.state;
    const M = G.calc().M;
    const sim = Math.min(away, M.offCap);
    const snap = { rev: s.stats.rev, exp: s.stats.exp, users: s.users, cash: s.cash, done: Object.keys(s.res.done).length };
    G.quiet = true;
    G.log = [];
    const n = Math.min(2400, Math.max(1, Math.ceil(sim / 3)));
    const step = sim / n;
    for (let i = 0; i < n; i++) G.tick(step, M.offEff);
    G.quiet = false;
    // rivals may erode your audience while you are away, but never by more than 15%
    s.users = Math.max(s.users, snap.users * 0.85);
    const out = {
      away, sim, capped: away > M.offCap, cap: M.offCap, eff: M.offEff,
      rev: s.stats.rev - snap.rev, exp: s.stats.exp - snap.exp, users0: snap.users, users1: s.users, cash0: snap.cash, events: G.log.slice(0, 14)
    };
    out.net = out.rev - out.exp;
    s.stats.offlineEarned += Math.max(0, out.net);
    G.log = [];
    return out;
  };

  /* ---------- costs and helpers ---------- */
  G.hwCost = (k, qty, owned) => {
    const h = D.hwmap[k], n = owned === undefined ? G.state.inf[k] : owned;
    return Math.ceil((h.cost * Math.pow(h.g, n) * (Math.pow(h.g, qty) - 1)) / (h.g - 1) * G.cm());
  };
  G.rackBase = () => D.rack.cost * Math.pow(D.rack.tier, G.state.inf.dc);
  G.rackCost = (qty, owned) => {
    const r = D.rack, n = owned === undefined ? G.state.inf.racks : owned;
    return Math.ceil((G.rackBase() * Math.pow(r.g, n) * (Math.pow(r.g, qty) - 1)) / (r.g - 1) * G.cm());
  };
  function maxByCost(base, g, owned, cash, mul) {
    const first = base * Math.pow(g, owned) * mul;
    if (first > cash) return 0;
    return Math.max(0, Math.floor(Math.log(1 + (cash * (g - 1)) / first) / Math.log(g)));
  }
  G.maxHw = (k) => {
    const s = G.state, h = D.hwmap[k];
    const room = s.inf.racks * D.rack.slots - G.C.nServers;
    return Math.max(0, Math.min(room, maxByCost(h.cost, h.g, s.inf[k], s.cash, G.cm())));
  };
  G.maxRack = () => {
    const s = G.state;
    const room = D.ladders.dc[s.inf.dc].racks - s.inf.racks;
    return Math.max(0, Math.min(room, maxByCost(G.rackBase(), D.rack.g, s.inf.racks, s.cash, G.cm())));
  };
  G.hwUnlocked = (k) => { const h = D.hwmap[k]; return !h.req || !!G.state.res.done[h.req]; };

  /* ---------- actions: infrastructure ---------- */
  G.act.buyHw = function (k, qty) {
    const s = G.state, h = D.hwmap[k];
    qty = Math.floor(qty);
    if (!h || !(qty > 0)) return fail('Invalid purchase.');
    if (!G.hwUnlocked(k)) return fail('Research ' + D.rmap[h.req].name + ' first.');
    const room = s.inf.racks * D.rack.slots - G.C.nServers;
    if (room < 1) return fail('No free rack slots. Buy more racks.');
    qty = Math.min(qty, room);
    const cost = G.hwCost(k, qty);
    if (!(cost >= 0) || s.cash < cost) return fail('Not enough cash.');
    s.cash -= cost; s.inf[k] += qty; s.infraValue += cost; s.stats.servers += qty;
    G.emit('purchase', { kind: 'hw', k, qty, cost });
    return OK;
  };
  G.unitPrice = (k, n) => D.hwmap[k].cost * Math.pow(D.hwmap[k].g, n) * G.cm();
  G.sellValue = (k) => { const n = G.state.inf[k]; return n > 0 ? Math.floor(0.5 * G.unitPrice(k, n - 1)) : 0; };
  G.act.sellHw = function (k, qty) {
    const s = G.state;
    qty = Math.min(Math.floor(qty), s.inf[k] || 0);
    if (!(qty > 0)) return fail('Nothing to decommission.');
    let got = 0;
    for (let i = 0; i < qty; i++) {
      const n = s.inf[k];
      got += Math.floor(0.5 * G.unitPrice(k, n - 1));
      s.infraValue = Math.max(0, s.infraValue - G.unitPrice(k, n - 1));
      s.inf[k] = n - 1;
    }
    s.cash += got;
    G.emit('purchase', { kind: 'sell', k, qty, cost: -got });
    return OK;
  };
  // buy better servers, decommissioning the weakest ones for free slots when the racks are full
  G.act.upgradeHw = function (k, qty) {
    const s = G.state, h = D.hwmap[k];
    if (!G.hwUnlocked(k)) return fail('Research ' + D.rmap[h.req].name + ' first.');
    let bought = 0;
    for (let i = 0; i < Math.floor(qty); i++) {
      let used = 0;
      for (const x of D.hw) used += s.inf[x.k];
      if (s.inf.racks * D.rack.slots - used < 1) {
        const low = D.hw.find((x) => x.tf < h.tf && s.inf[x.k] > 0);
        if (!low) break;
        const n = s.inf[low.k];
        const back = Math.floor(0.5 * G.unitPrice(low.k, n - 1));
        const cost = G.hwCost(k, 1);
        if (s.cash + back < cost) break;
        s.cash += back; s.infraValue = Math.max(0, s.infraValue - G.unitPrice(low.k, n - 1)); s.inf[low.k] = n - 1;
      }
      const cost = G.hwCost(k, 1);
      if (s.cash < cost) break;
      s.cash -= cost; s.inf[k] += 1; s.infraValue += cost; s.stats.servers += 1; bought++;
    }
    if (!bought) return fail('Not enough cash or nothing to replace.');
    G.emit('purchase', { kind: 'hw', k, qty: bought, cost: 0 });
    return OK;
  };
  G.act.buyRack = function (qty) {
    const s = G.state;
    qty = Math.floor(qty);
    if (!(qty > 0)) return fail('Invalid purchase.');
    const room = D.ladders.dc[s.inf.dc].racks - s.inf.racks;
    if (room < 1) return fail('No floor space. Build a bigger data center.');
    qty = Math.min(qty, room);
    const cost = G.rackCost(qty);
    if (s.cash < cost) return fail('Not enough cash.');
    s.cash -= cost; s.inf.racks += qty; s.infraValue += cost;
    G.emit('purchase', { kind: 'rack', qty, cost });
    return OK;
  };
  G.ladderNext = (k) => { const lvl = G.state.inf[k], lad = D.ladders[k]; return lvl + 1 < lad.length ? lad[lvl + 1] : null; };
  G.building = (k, id) => G.state.build.find((b) => b.k === k && (id === undefined || b.id === id));
  G.ladderCost = (t) => Math.ceil(t.cost * G.cm());
  // true when the next level of a building can be started right now (unlocked, not under construction, enough cash)
  G.canBuild = (k) => { const st = G.state, t = G.ladderNext(k); return !!t && !G.building(k) && !(t.req && !st.res.done[t.req]) && st.cash >= G.ladderCost(t); };
  G.act.build = function (k) {
    const s = G.state;
    const t = G.ladderNext(k);
    if (!t) return fail('Already at the highest level.');
    if (G.building(k)) return fail('Already under construction.');
    if (t.req && !s.res.done[t.req]) return fail('Research ' + D.rmap[t.req].name + ' first.');
    const cost = G.ladderCost(t);
    if (s.cash < cost) return fail('Not enough cash.');
    s.cash -= cost; s.infraValue += cost * (k === 'hq' || k === 'lab' ? 0 : 1);
    s.build.push({ k, to: s.inf[k] + 1, left: t.time, total: t.time });
    G.emit('purchase', { kind: 'build', k, cost });
    note('build', 'Construction started: ' + t.name + '.', false);
    return OK;
  };

  /* ---------- actions: research ---------- */
  G.researchStatus = function (id) {
    const s = G.state, n = D.rmap[id];
    if (s.res.done[id]) return 'done';
    if (s.res.q.some((p) => p.id === id)) return 'active';
    if (G.researchReqs(id).every((r) => r.ok)) return 'ready';
    return 'locked';
  };
  G.researchReqs = function (id) {
    const s = G.state, n = D.rmap[id], out = [];
    for (const r of n.req) out.push({ ok: !!s.res.done[r], text: D.rmap[r].name });
    if (n.reqModel) out.push({ ok: (s.models[n.reqModel] || {}).st === 'rel', text: D.mmap[n.reqModel].name + ' released' });
    return out;
  };
  G.researchCost = (n) => Math.ceil(n.cost * G.C.M.resCost);
  G.act.research = function (id) {
    const s = G.state, n = D.rmap[id], C = G.C;
    if (!n) return fail('Unknown project.');
    const stt = G.researchStatus(id);
    if (stt === 'done') return fail('Already researched.');
    if (stt === 'active') return fail('Already in progress.');
    if (stt === 'locked') return fail('Prerequisites are missing.');
    if (s.res.q.length >= C.resSlots) return fail('All research slots are busy.');
    const cost = G.researchCost(n);
    if (s.cash < cost) return fail('Not enough cash.');
    s.cash -= cost;
    s.res.q.push({ id, left: n.time, total: n.time });
    G.emit('purchase', { kind: 'research', id, cost });
    return OK;
  };

  /* ---------- actions: models ---------- */
  G.modelReqs = function (id) {
    const s = G.state, m = D.mmap[id], out = [];
    for (const r of m.req) out.push({ ok: !!s.res.done[r], text: D.rmap[r].name });
    if (m.gen > 1) { const p = D.models[m.gen - 2]; out.push({ ok: (s.models[p.id] || {}).st === 'rel', text: p.name + ' released' }); }
    return out;
  };
  G.modelStatus = function (id) {
    const s = G.state, ms = s.models[id];
    if (ms && ms.st === 'rel') return 'rel';
    if (ms && ms.st === 'trained') return 'trained';
    if (s.job && s.job.kind === 'new' && s.job.id === id) return 'training';
    return G.modelReqs(id).every((r) => r.ok) ? 'ready' : 'locked';
  };
  G.trainCost = (m) => Math.ceil(m.cost * G.C.M.trainCost);
  G.tuneInfo = function (id) {
    const s = G.state, m = D.mmap[id], ms = s.models[id];
    const lvl = (ms && ms.tune) || 0;
    if (!ms || ms.st !== 'rel' || lvl >= 5) return null;
    return { lvl, cost: Math.ceil((m.cost || 3000) * 0.12 * Math.pow(1.9, lvl) * G.C.M.trainCost), time: Math.max(30, Math.round((m.time || 90) * 0.3 * (1 + 0.25 * lvl))), tf: m.tf * 0.5 };
  };
  G.act.train = function (id) {
    const s = G.state, C = G.C, m = D.mmap[id];
    if (!m) return fail('Unknown model.');
    if (s.job) return fail('The lab is already busy.');
    if (G.modelStatus(id) !== 'ready') return fail('Requirements are not met.');
    const cost = G.trainCost(m);
    if (s.cash < cost) return fail('Not enough cash.');
    if (C.capEff - C.ctf < m.tf) return fail('Needs ' + U.tf(m.tf) + ' of free compute.');
    s.cash -= cost;
    s.job = { kind: 'new', id, left: m.time, total: m.time, tf: m.tf, cost };
    s.stats.jobs++;
    G.emit('purchase', { kind: 'train', id, cost });
    return OK;
  };
  G.act.tune = function (id) {
    const s = G.state, C = G.C;
    if (s.job) return fail('The lab is already busy.');
    const t = G.tuneInfo(id);
    if (!t) return fail('This model cannot be improved further.');
    if (s.cash < t.cost) return fail('Not enough cash.');
    if (C.capEff - C.ctf < t.tf) return fail('Needs ' + U.tf(t.tf) + ' of free compute.');
    s.cash -= t.cost;
    s.job = { kind: 'tune', id, left: t.time, total: t.time, tf: t.tf, cost: t.cost };
    s.stats.jobs++;
    G.emit('purchase', { kind: 'train', id, cost: t.cost });
    return OK;
  };
  G.act.release = function (id) {
    const s = G.state, ms = s.models[id], m = D.mmap[id];
    if (!ms || ms.st !== 'trained') return fail('This model is not ready.');
    const b = G.calc();
    const before = { users: s.users, pot: b.pot, rev: b.rev.total, intel: b.intel, share: b.share };
    ms.st = 'rel'; ms.at = nowMs(); s.active = id;
    s.hype = Math.min(4, s.hype + 1 + 0.12 * m.gen);
    s.stats.releases++;
    const a = G.calc();
    s.users += Math.max(0, a.pot - s.users) * 0.06;
    const after = { users: s.users, pot: a.pot, rev: a.rev.total, intel: a.intel, share: a.share };
    s.hist.push({ id, at: nowMs(), gt: s.gt, users: Math.round(s.users) });
    note('release', m.name + ' is live. User interest is surging.', false);
    G.emit('release', { id, before, after });
    return OK;
  };
  G.act.deploy = function (id) {
    const s = G.state, ms = s.models[id];
    if (!ms || ms.st !== 'rel') return fail('Release the model first.');
    s.active = id;
    G.calc();
    G.emit('deploy', { id });
    return OK;
  };

  /* ---------- actions: business ---------- */
  G.act.setPrice = (v) => { G.state.price = clamp(Math.round(v), 1, 100); return OK; };
  G.act.setAds = (on) => { G.state.ads = !!on; return OK; };
  G.act.setMkt = (v) => { G.state.mkt = clamp(Math.floor(v), 0, 4); return OK; };
  G.act.setRd = (v) => { G.state.rd = clamp(Math.floor(v), 0, 3); return OK; };
  G.contractSlots = () => (G.C.F.ent ? Math.floor(G.C.M.entSlots) : 0);
  G.act.signContract = function (id) {
    const s = G.state, C = G.C, p = D.pmap[id];
    if (!p) return fail('Unknown partner.');
    if (!C.F.ent) return fail('Research Enterprise Sales first.');
    if (s.contracts[id]) return fail('Already signed.');
    if (C.nContracts >= G.contractSlots()) return fail('No free partnership slots.');
    if (C.intel < p.intel) return fail('Needs an intelligence rating of ' + p.intel + '.');
    if (C.uptime < 90) return fail('Service uptime is too low.');
    if (s.cash < p.fee) return fail('Not enough cash.');
    if (C.capAvail < p.tf) return fail('Needs ' + U.tf(p.tf) + ' of free compute.');
    s.cash -= p.fee;
    s.contracts[id] = nowMs();
    s.stats.contracts++;
    note('contract', p.name + ' signed an enterprise contract.');
    G.emit('purchase', { kind: 'contract', id });
    return OK;
  };
  G.act.dropContract = function (id) {
    if (!G.state.contracts[id]) return OK;
    delete G.state.contracts[id];
    return OK;
  };

  /* ---------- regions ---------- */
  G.regionReqs = function (id) {
    const s = G.state, r = D.rgmap[id], out = [];
    if (r.req.model) out.push({ ok: (s.models[r.req.model] || {}).st === 'rel', text: D.mmap[r.req.model].name + ' released' });
    if (r.req.regions) out.push({ ok: Object.keys(s.regions).length >= r.req.regions, text: r.req.regions + ' regions open' });
    return out;
  };
  G.regionNext = (id) => {
    const s = G.state, r = D.rgmap[id], rs = s.regions[id], to = rs ? rs.hub + 1 : 1;
    if (to > 3) return null;
    const cost = Math.ceil(to === 1 ? r.cost : r.up[to - 2]);
    const time = to === 1 ? r.time : Math.max(60, Math.round(r.time * to * 0.8));
    return { to, cost, time };
  };
  G.regionStatus = function (id) {
    const s = G.state, rs = s.regions[id];
    if (G.building('reg', id)) return 'building';
    if (rs) return rs.hub >= 3 ? 'max' : 'open';
    return G.regionReqs(id).every((r) => r.ok) ? 'ready' : 'locked';
  };
  G.act.region = function (id) {
    const s = G.state, r = D.rgmap[id];
    const n = G.regionNext(id);
    if (!n) return fail('Already at the highest level.');
    if (G.building('reg', id)) return fail('Already under construction.');
    if (n.to === 1 && !G.regionReqs(id).every((q) => q.ok)) return fail('Requirements are not met.');
    if (s.cash < n.cost) return fail('Not enough cash.');
    s.cash -= n.cost;
    s.build.push({ k: 'reg', id, to: n.to, left: n.time, total: n.time });
    G.emit('purchase', { kind: 'region', id, cost: n.cost });
    note('region', 'Construction started in ' + r.name + '.', false);
    return OK;
  };

  /* ---------- achievements and goals ---------- */
  function checkAch(s, C) {
    for (const a of D.ach) {
      if (s.ach[a.id]) continue;
      let ok = false;
      try { ok = a.t(s, C); } catch (e) { ok = false; }
      if (!ok) continue;
      s.ach[a.id] = nowMs();
      const reward = Math.max(a.floor, a.min * 60 * Math.max(0, C.net));
      s.cash += reward;
      if (a.patents) { s.pres.patents += a.patents; s.pres.total += a.patents; }
      if (a.skin) s.pres.skins[a.skin] = true;
      note('ach', 'Achievement: ' + a.name, false);
      G.emit('ach', { a, reward });
    }
  }

  /* ---------- daily missions ---------- */
  function dayKey() {
    const d = new Date();
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  }
  G.dayKey = dayKey;
  G.ensureDaily = function () {
    const s = G.state, k = dayKey();
    if (s.daily.list.length && s.daily.day >= k) return;
    const C = G.C || G.calc();
    let seed = 0;
    for (let i = 0; i < k.length; i++) seed = (seed * 31 + k.charCodeAt(i)) >>> 0;
    const rng = U.rng(seed);
    const pool = D.missions.filter((m) => !m.need || m.need(s, C));
    const list = [];
    while (list.length < 3 && pool.length) {
      const m = pool.splice(Math.floor(rng() * pool.length), 1)[0];
      list.push({ id: m.id, goal: m.goal(s, C), base: s.stats[m.stat] || 0, claimed: false });
    }
    s.daily = { day: k, list };
  };
  G.missionProg = (it) => { const m = D.mimap[it.id]; return clamp((G.state.stats[m.stat] || 0) - it.base, 0, it.goal); };
  G.act.claimMission = function (i) {
    const s = G.state, it = s.daily.list[i];
    if (!it || it.claimed) return fail('Already claimed.');
    if (G.missionProg(it) < it.goal) return fail('Not finished yet.');
    it.claimed = true;
    const m = D.mimap[it.id];
    const reward = Math.max(1000, m.min * 60 * Math.max(0, G.C.net));
    s.cash += reward;
    G.emit('reward', { reward, text: 'Mission complete' });
    return OK;
  };

  /* ---------- prestige ---------- */
  G.canReinvent = () => G.C.val >= D.prestige.min;
  G.reinventGain = () => D.patentsFor(G.C.val);
  G.act.reinvent = function () {
    if (!G.canReinvent()) return fail('Reach a $' + U.num(D.prestige.min) + ' valuation first.');
    const s = G.state, gain = G.reinventGain();
    const pres = s.pres;
    pres.patents += gain; pres.total += gain; pres.count += 1;
    const daily = s.daily;
    G.state = G.newState({ name: s.name, pres, set: s.set, ach: s.ach, stats: s.stats });
    G.state.daily = daily;
    G.hist = [];
    G.calc();
    G.emit('prestige', { gain });
    return { ok: true, gain };
  };
  G.act.buyLegacy = function (id) {
    const s = G.state, l = D.legacyMap[id];
    const lvl = s.pres.up[id] || 0;
    if (!l || lvl >= l.max) return fail('Already at the highest level.');
    const cost = D.legacyCost(l, lvl);
    if (s.pres.patents < cost) return fail('Not enough Legacy Patents.');
    s.pres.patents -= cost;
    s.pres.up[id] = lvl + 1;
    // Seed Capital and Founder Knowledge also help the company you are running right now
    if (id === 'seed') s.cash += K.startCash * (Math.pow(2.2, lvl + 1) - Math.pow(2.2, lvl));
    if (id === 'founder') for (const rid of D.founderKit[lvl]) { s.res.done[rid] = 1; s.res.q = s.res.q.filter((p) => p.id !== rid); }
    G.emit('purchase', { kind: 'legacy', id, cost });
    return OK;
  };
  G.act.setSkin = function (id) {
    const s = G.state;
    if (!s.pres.skins[id]) return fail('This look is still locked.');
    s.pres.skin = id;
    G.emit('skin', { id });
    return OK;
  };

  /* ---------- guidance ---------- */
  G.hint = function () {
    const s = G.state, C = G.C;
    if (!C) return null;
    const d = s.res.done;
    if (!d.p1) return { text: 'Research Subscription Plans', tab: 'research' };
    const trained = D.models.find((m) => (s.models[m.id] || {}).st === 'trained');
    if (trained) return { text: 'Release ' + trained.name, tab: 'models' };
    if (C.sr < 0.9 && G.maxHw('g1') > 0) return { text: 'Servers are overloaded. Add capacity.', tab: 'infra' };
    const nm = D.models.find((m) => !s.models[m.id]);
    if (nm && !s.job) {
      const st = G.modelStatus(nm.id);
      if (st === 'ready') return { text: 'Train ' + nm.name, tab: 'models' };
      if (st === 'locked') {
        const miss = G.modelReqs(nm.id).find((r) => !r.ok);
        if (miss && D.research.some((n) => n.name === miss.text) && s.res.q.length < C.resSlots) return { text: 'Research ' + miss.text, tab: 'research' };
      }
    }
    if (G.canReinvent()) return { text: 'Corporate Reinvention is available', tab: 'achv' };
    if (C.sr < 0.98 && C.nServers < C.slotsTotal) return { text: 'Add servers to serve more users', tab: 'infra' };
    for (const k of ['hq', 'lab']) {
      if (G.canBuild(k)) { const t = G.ladderNext(k); return { text: 'Upgrade to ' + t.name + ' for ' + U.money(G.ladderCost(t)), tab: 'hq', sheet: true }; }
    }
    return { text: 'Open new regions and upgrade your campus', tab: 'global' };
  };

  /* ---------- save / load ---------- */
  const KEY = 'aiempire.save.v1';
  G.save = function () {
    const s = G.state;
    s.lastSave = nowMs();
    s.lastSeen = s.lastSave;
    const str = JSON.stringify(s);
    try { if (typeof window.NativeBridge !== 'undefined' && window.NativeBridge.save) window.NativeBridge.save(str); } catch (e) { /* ignore */ }
    try { window.localStorage.setItem(KEY, str); } catch (e) { /* ignore */ }
    return str.length;
  };
  G.loadRaw = function () {
    let raw = '';
    try { if (typeof window.NativeBridge !== 'undefined' && window.NativeBridge.load) raw = window.NativeBridge.load() || ''; } catch (e) { raw = ''; }
    if (!raw) { try { raw = window.localStorage.getItem(KEY) || ''; } catch (e) { raw = ''; } }
    return raw;
  };
  function merge(def, src) {
    if (src === undefined || src === null) return def;
    if (typeof def !== 'object' || def === null || Array.isArray(def)) return typeof src === typeof def || def === null ? src : def;
    if (typeof src !== 'object' || Array.isArray(src)) return def;
    const out = {};
    for (const k in def) out[k] = merge(def[k], src[k]);
    for (const k in src) if (!(k in def)) out[k] = src[k];
    return out;
  }
  G.migrate = (o) => merge(G.newState(), o);
  G.load = function () {
    const raw = G.loadRaw();
    if (!raw) return false;
    try {
      G.state = G.migrate(JSON.parse(raw));
      G.fix(G.state);
      return true;
    } catch (e) {
      if (G.err) G.err(e);
      return false;
    }
  };
  G.exportSave = () => { try { return btoa(unescape(encodeURIComponent(JSON.stringify(G.state)))); } catch (e) { return ''; } };
  G.importSave = function (txt) {
    try {
      const o = JSON.parse(decodeURIComponent(escape(atob(txt.trim()))));
      if (!o || typeof o !== 'object' || !o.inf || !o.res) return false;
      G.state = G.migrate(o);
      G.fix(G.state);
      G.state.lastSeen = nowMs();
      G.calc();
      return true;
    } catch (e) { return false; }
  };
  G.reset = function () { G.state = G.newState(); G.hist = []; G.calc(); };
  G.boot = function () {
    const had = G.load();
    if (!had) G.state = G.newState();
    G.calc();
    G.ensureDaily();
    const r = had ? G.frame() : null;
    G.calc();
    return { had, offline: r };
  };
})();
