/* AI Empire Tycoon - utilities (formatting, math, colour, DOM, icons) */
(function () {
  'use strict';
  const G = (window.G = window.G || {});
  G.VER = '1.1.0';
  const U = (G.U = {});

  U.clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  U.lerp = (a, b, t) => a + (b - a) * t;
  U.ease = {
    out: (t) => 1 - Math.pow(1 - t, 3),
    inOut: (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2),
    back: (t) => { const c = 1.70158; return 1 + (c + 1) * Math.pow(t - 1, 3) + c * Math.pow(t - 1, 2); }
  };

  /* ---------- number formatting ---------- */
  const SUF = ['', 'K', 'M', 'B', 'T', 'Qa', 'Qi', 'Sx', 'Sp', 'Oc', 'No', 'Dc'];
  const trim = (s) => (s.indexOf('.') >= 0 ? s.replace(/0+$/, '').replace(/\.$/, '') : s);
  U.num = function (n) {
    if (!isFinite(n)) return '0';
    const neg = n < 0 ? '-' : '';
    n = Math.abs(n);
    if (n < 1000) return neg + trim(n < 10 ? n.toFixed(2) : n < 100 ? n.toFixed(1) : n.toFixed(0));
    let k = Math.min(SUF.length - 1, Math.floor(Math.log10(n) / 3));
    let v = n / Math.pow(1000, k);
    let s = v < 10 ? v.toFixed(2) : v < 100 ? v.toFixed(1) : v.toFixed(0);
    if (parseFloat(s) >= 1000 && k < SUF.length - 1) { k++; v = n / Math.pow(1000, k); s = v.toFixed(2); }
    return neg + trim(s) + SUF[k];
  };
  U.money = (n) => (n < 0 ? '-$' : '$') + U.num(Math.abs(n));
  U.int = (n) => U.num(Math.floor(n + 1e-9));
  U.pct = (x, d) => (x * 100).toFixed(d || 0) + '%';
  U.tf = function (n) {
    const u = ['TF', 'PF', 'EF', 'ZF', 'YF'];
    let k = 0;
    while (n >= 1000 && k < u.length - 1) { n /= 1000; k++; }
    const s = n < 10 ? n.toFixed(2) : n < 100 ? n.toFixed(1) : n.toFixed(0);
    return trim(s) + ' ' + u[k];
  };
  U.mw = (n) => (n < 1 ? trim((n * 1000).toFixed(0)) + ' kW' : trim(n < 10 ? n.toFixed(2) : n.toFixed(0)) + ' MW');
  U.dur = function (s) {
    s = Math.max(0, Math.ceil(s));
    if (s < 60) return s + 's';
    const m = Math.floor(s / 60);
    if (s < 3600) return m + 'm ' + String(s % 60).padStart(2, '0') + 's';
    const h = Math.floor(s / 3600);
    if (s < 86400) return h + 'h ' + String(Math.floor((s % 3600) / 60)).padStart(2, '0') + 'm';
    return Math.floor(s / 86400) + 'd ' + Math.floor((s % 86400) / 3600) + 'h';
  };
  U.clock = (s) => { s = Math.max(0, Math.floor(s)); const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60); return (h ? h + ':' + String(m).padStart(2, '0') : m) + ':' + String(s % 60).padStart(2, '0'); };

  /* ---------- random ---------- */
  U.rng = function (seed) {
    let a = seed >>> 0;
    return function () {
      a = (a + 0x6d2b79f5) >>> 0;
      let t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  };
  U.pick = (arr, r) => arr[Math.floor((r ? r() : Math.random()) * arr.length) % arr.length];

  /* ---------- colour ---------- */
  const hexCache = {};
  U.rgb = function (hex) {
    if (hexCache[hex]) return hexCache[hex];
    let h = hex.replace('#', '');
    if (h.length === 3) h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
    const v = [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)];
    hexCache[hex] = v;
    return v;
  };
  U.shade = function (hex, k) {
    const c = U.rgb(hex);
    const f = (x) => Math.max(0, Math.min(255, Math.round(x * k)));
    return 'rgb(' + f(c[0]) + ',' + f(c[1]) + ',' + f(c[2]) + ')';
  };
  U.mix = function (a, b, t) {
    const x = U.rgb(a), y = U.rgb(b);
    return 'rgb(' + Math.round(x[0] + (y[0] - x[0]) * t) + ',' + Math.round(x[1] + (y[1] - x[1]) * t) + ',' + Math.round(x[2] + (y[2] - x[2]) * t) + ')';
  };
  U.rgba = function (hex, a) { const c = U.rgb(hex); return 'rgba(' + c[0] + ',' + c[1] + ',' + c[2] + ',' + a + ')'; };

  /* ---------- DOM ---------- */
  U.h = function (tag, a) {
    const el = document.createElement(tag);
    if (a) {
      for (const k in a) {
        const v = a[k];
        if (v == null || v === false) continue;
        if (k === 'class') el.className = v;
        else if (k === 'html') el.innerHTML = v;
        else if (k === 'style' && typeof v === 'object') { for (const pk in v) { if (pk.charCodeAt(0) === 45) el.style.setProperty(pk, v[pk]); else el.style[pk] = v[pk]; } }
        else if (k.length > 2 && k[0] === 'o' && k[1] === 'n') el.addEventListener(k.slice(2), v);
        else el.setAttribute(k, v === true ? '' : v);
      }
    }
    for (let i = 2; i < arguments.length; i++) {
      const kids = Array.isArray(arguments[i]) ? arguments[i] : [arguments[i]];
      for (const c of kids) {
        if (c == null || c === false) continue;
        el.append(c.nodeType ? c : document.createTextNode(String(c)));
      }
    }
    return el;
  };

  /* ---------- original icon set (24x24, stroke based) ---------- */
  const I = {
    hq: '<path d="M4 20V8.5l8-5 8 5V20M2.5 20h19M9.5 20v-5.5h5V20M8 10.5h.01M12 10.5h.01M16 10.5h.01"/>',
    ai: '<circle cx="12" cy="12" r="3"/><circle cx="5" cy="6" r="1.9"/><circle cx="19" cy="6" r="1.9"/><circle cx="5" cy="18" r="1.9"/><circle cx="19" cy="18" r="1.9"/><path d="M6.4 7.3l3.2 3.1M17.6 7.3l-3.2 3.1M6.4 16.7l3.2-3.1M17.6 16.7l-3.2-3.1"/>',
    research: '<path d="M9 3h6M10 3v6.2L4.8 18.4a2 2 0 0 0 1.7 3.1h11a2 2 0 0 0 1.7-3.1L14 9.2V3M7.5 15h9"/>',
    infra: '<rect x="3" y="3.5" width="18" height="6.5" rx="1.6"/><rect x="3" y="14" width="18" height="6.5" rx="1.6"/><path d="M7 6.75h.01M7 17.25h.01M11 6.75h6M11 17.25h6"/>',
    business: '<path d="M3.5 20.5h17"/><rect x="5" y="12" width="3.2" height="6.5" rx=".9"/><rect x="10.4" y="8" width="3.2" height="10.5" rx=".9"/><rect x="15.8" y="4" width="3.2" height="14.5" rx=".9"/>',
    globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.8 2.8 4 5.8 4 9s-1.2 6.2-4 9c-2.8-2.8-4-5.8-4-9s1.2-6.2 4-9z"/>',
    trophy: '<path d="M8 4h8v5a4 4 0 0 1-8 0V4zM8 6H5v1.5A3 3 0 0 0 8 10.5M16 6h3v1.5a3 3 0 0 1-3 3M12 13v4M8.5 20h7M10 17h4"/>',
    gear: '<circle cx="12" cy="12" r="3.2"/><circle cx="12" cy="12" r="7.2"/><path d="M12 2.5v2.3M12 19.2v2.3M2.5 12h2.3M19.2 12h2.3M5.3 5.3l1.6 1.6M17.1 17.1l1.6 1.6M18.7 5.3l-1.6 1.6M6.9 17.1l-1.6 1.6"/>',
    cash: '<circle cx="12" cy="12" r="9"/><path d="M14.8 9.2c-.5-.9-1.5-1.4-2.8-1.4-1.6 0-2.7.8-2.7 2 0 3 5.6 1.4 5.6 4.4 0 1.2-1.2 2-2.9 2-1.4 0-2.5-.6-3-1.6M12 6v1.8M12 16.2V18"/>',
    users: '<circle cx="9" cy="8" r="3.2"/><path d="M3 20c0-3.5 2.7-6 6-6s6 2.5 6 6"/><circle cx="17" cy="9" r="2.4"/><path d="M16.5 14.2c2.6.2 4.5 2.2 4.5 5.3"/>',
    bolt: '<path d="M13 2.5L4.5 13.5H11L10 21.5l8.5-11H12.5z"/>',
    cpu: '<rect x="6" y="6" width="12" height="12" rx="2"/><rect x="9.5" y="9.5" width="5" height="5" rx=".8"/><path d="M9 2.5V6M15 2.5V6M9 18v3.5M15 18v3.5M2.5 9H6M2.5 15H6M18 9h3.5M18 15h3.5"/>',
    temp: '<path d="M10 14.5V5a2 2 0 0 1 4 0v9.5a4 4 0 1 1-4 0zM12 9v7"/>',
    snow: '<path d="M12 2.5v19M3.8 7.2l16.4 9.6M3.8 16.8L20.2 7.2M9.5 4.3L12 6.5l2.5-2.2M9.5 19.7L12 17.5l2.5 2.2"/>',
    net: '<circle cx="12" cy="5" r="2.2"/><circle cx="5" cy="18" r="2.2"/><circle cx="19" cy="18" r="2.2"/><path d="M12 7.2v4.3M12 11.5l-5.6 4.8M12 11.5l5.6 4.8"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.2 2"/>',
    check: '<path d="M4.5 12.5l5 5 10-11"/>',
    lock: '<rect x="5" y="10.5" width="14" height="10" rx="2.2"/><path d="M8 10.5V8a4 4 0 0 1 8 0v2.5"/>',
    play: '<path d="M7 4.5v15l12-7.5z"/>',
    rocket: '<path d="M12 3c3.5 1.8 5.5 5 5.5 9.2L12 17.5l-5.5-5.3C6.5 8 8.5 4.8 12 3zM12 10.2h.01M6.5 12.2L4 15l3.2.6M17.5 12.2L20 15l-3.2.6M10 19.5c.6 1.1 1.2 1.9 2 2.5.8-.6 1.4-1.4 2-2.5"/>',
    star: '<path d="M12 3.5l2.5 5.3 5.8.8-4.2 4.1 1 5.8-5.1-2.8-5.1 2.8 1-5.8-4.2-4.1 5.8-.8z"/>',
    chev: '<path d="M9 5l7 7-7 7"/>',
    close: '<path d="M6 6l12 12M18 6L6 18"/>',
    up: '<path d="M12 19V5M6 11l6-6 6 6"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    save: '<path d="M5 4h11l3 3v13H5zM8 4v5h7V4M8 20v-6h8v6"/>',
    music: '<path d="M9 18V6l10-2v12"/><circle cx="6.5" cy="18" r="2.5"/><circle cx="16.5" cy="16" r="2.5"/>',
    vol: '<path d="M4 9.5v5h3.5L12 18.5v-13L7.5 9.5zM15.5 9a4 4 0 0 1 0 6M18 6.5a8 8 0 0 1 0 11"/>',
    gauge: '<path d="M4 17a8 8 0 1 1 16 0M12 17l4-5"/>',
    sparkle: '<path d="M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2.5 2.5M15.5 15.5L18 18M18 6l-2.5 2.5M8.5 15.5L6 18"/>',
    shield: '<path d="M12 3l8 3v6c0 4.5-3.2 7.8-8 9-4.8-1.2-8-4.5-8-9V6z"/>',
    doc: '<path d="M7 3h7l4 4v14H7zM14 3v4h4M10 12h5M10 16h5"/>',
    mega: '<path d="M4 10v4h3l7 4V6L7 10zM17 9.5a3.5 3.5 0 0 1 0 5"/>',
    heart: '<path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.5A4 4 0 0 1 19 10c0 5.6-7 10-7 10z"/>',
    trend: '<path d="M3 17l6-6 4 4 8-9M15 6h6v6"/>',
    crown: '<path d="M3.5 18.5l1.5-10 5 4 2-6.5 2 6.5 5-4 1.5 10zM4 21h16"/>',
    wrench: '<path d="M14.7 6.3a4 4 0 0 0-5 5L3 18l3 3 6.7-6.7a4 4 0 0 0 5-5l-2.5 2.5-2.5-.5-.5-2.5z"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>',
    warn: '<path d="M12 3.5l10 17.5H2z"/><path d="M12 10v5M12 18h.01"/>',
    target: '<circle cx="12" cy="12" r="3"/><path d="M12 2v4M12 18v4M2 12h4M18 12h4"/>',
    chat: '<path d="M4 5h16v11H9.5L4 20z"/>',
    bulb: '<path d="M9 18h6M10 21h4M12 3a6 6 0 0 0-3.6 10.8c.6.5 1 1.2 1 2V16h5.2v-.2c0-.8.4-1.5 1-2A6 6 0 0 0 12 3z"/>',
    logic: '<path d="M4 6h7M4 12h16M4 18h11M15 4l5 2-5 2zM18 16l2 2-2 2"/>',
    eye: '<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    image: '<rect x="3.5" y="4.5" width="17" height="15" rx="2.5"/><path d="M3.5 16l5-5 4 4 3-3 5 5M9 9h.01"/>',
    mic: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5.5 11a6.5 6.5 0 0 0 13 0M12 17.5V21M9 21h6"/>',
    code: '<path d="M8 7l-5 5 5 5M16 7l5 5-5 5M13.5 5l-3 14"/>',
    bot: '<rect x="5" y="8" width="14" height="11" rx="3"/><path d="M12 8V5M9.5 13h.01M14.5 13h.01M9.5 16h5"/><circle cx="12" cy="3.8" r="1.1"/>',
    omni: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4.5"/><circle cx="12" cy="12" r="1"/>',
    atom: '<circle cx="12" cy="12" r="1.6"/><ellipse cx="12" cy="12" rx="9.5" ry="3.8"/><ellipse cx="12" cy="12" rx="9.5" ry="3.8" transform="rotate(60 12 12)"/><ellipse cx="12" cy="12" rx="9.5" ry="3.8" transform="rotate(120 12 12)"/>',
    layers: '<path d="M12 3l9 5-9 5-9-5zM3 12.5l9 5 9-5M3 16.5l9 5 9-5"/>',
    video: '<rect x="3" y="6" width="13" height="12" rx="2.5"/><path d="M16 10.5l5-3v9l-5-3z"/>',
    chart: '<path d="M4 4v16h16M8 15l3-4 3 2 4-6"/>',
    build: '<path d="M3 21h18M6 21V10l6-4 6 4v11M10 21v-5h4v5"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2.5v2.5M12 19v2.5M2.5 12H5M19 12h2.5M5.3 5.3l1.8 1.8M16.9 16.9l1.8 1.8M18.7 5.3l-1.8 1.8M7.1 16.9l-1.8 1.8"/>',
    tag: '<path d="M3 12.5V4h8.5L21 13.5 13.5 21z"/><circle cx="8" cy="8.5" r="1.4"/>',
    refresh: '<path d="M20 11a8 8 0 0 0-14.5-4.2M4 4v4h4M4 13a8 8 0 0 0 14.5 4.2M20 20v-4h-4"/>',
    copy: '<rect x="8.5" y="8.5" width="12" height="12" rx="2"/><path d="M15.5 8.5V5.5a2 2 0 0 0-2-2h-8a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h3"/>',
    list: '<path d="M8 6h12M8 12h12M8 18h12M4 6h.01M4 12h.01M4 18h.01"/>'
  };
  U.icons = I;
  U.ic = function (name, size, cls) {
    return '<svg class="ic ' + (cls || '') + '" viewBox="0 0 24 24" width="' + (size || 20) + '" height="' + (size || 20) + '" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (I[name] || I.info) + '</svg>';
  };
  U.icon = function (name, size, cls) {
    const s = document.createElement('span');
    s.className = 'icw';
    s.innerHTML = U.ic(name, size, cls);
    return s;
  };
})();
