package com.quickshare

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

/**
 * Minimal foreground service whose sole purpose is to prevent Android from
 * killing the process during active file transfers.
 *
 * The transfer coroutines live in MainActivity's lifecycleScope. As long as
 * this service is in the foreground, Android will not reclaim the process,
 * so those coroutines keep running even when the app is in the background.
 *
 * Usage:
 *   TransferForegroundService.start(ctx, "📤 Sending 3 file(s)…")
 *   TransferForegroundService.updateProgress(ctx, "photo.jpg", 42)
 *   TransferForegroundService.stop(ctx)
 */
class TransferForegroundService : Service() {

    companion object {
        private const val NOTIF_ID    = 9001
        private const val CHANNEL_ID  = "qs_transfer_fg"
        private const val EXTRA_MSG   = "msg"
        private const val EXTRA_FILE  = "fn"
        private const val EXTRA_PCT   = "pct"
        private const val EXTRA_UPD   = "upd"

        /** Start (or restart) the foreground service with an initial message. */
        fun start(ctx: Context, message: String) {
            val i = Intent(ctx, TransferForegroundService::class.java)
                .putExtra(EXTRA_MSG, message)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                ctx.startForegroundService(i)
            } else {
                ctx.startService(i)
            }
        }

        /** Push a lightweight notification update (throttle at the call-site). */
        fun updateProgress(ctx: Context, fileName: String, percent: Int) {
            ctx.startService(
                Intent(ctx, TransferForegroundService::class.java)
                    .putExtra(EXTRA_UPD,  true)
                    .putExtra(EXTRA_FILE, fileName)
                    .putExtra(EXTRA_PCT,  percent)
            )
        }

        /** Stop the service once the transfer is finished or cancelled. */
        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, TransferForegroundService::class.java))
        }
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val isUpdate = intent?.getBooleanExtra(EXTRA_UPD, false) == true

        if (isUpdate) {
            // Just refresh the notification — don't call startForeground again.
            val fn  = intent?.getStringExtra(EXTRA_FILE) ?: ""
            val pct = intent?.getIntExtra(EXTRA_PCT, 0) ?: 0
            getSystemService(NotificationManager::class.java)
                .notify(NOTIF_ID, buildNotif(fn, pct))
        } else {
            val msg = intent?.getStringExtra(EXTRA_MSG) ?: "Transferring files…"
            // API 29+ requires the foreground service type to be passed here.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    NOTIF_ID,
                    buildNotif(msg, -1),
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
                )
            } else {
                startForeground(NOTIF_ID, buildNotif(msg, -1))
            }
        }
        // Don't restart automatically — if killed the transfer is already dead.
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // ── Helpers ───────────────────────────────────────────────────────────────

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(
                CHANNEL_ID,
                "Active Transfers",
                NotificationManager.IMPORTANCE_LOW   // Silent — no sound/vibration
            ).apply {
                description = "Shows file transfer progress"
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    private fun buildNotif(title: String, percent: Int): Notification {
        val pi = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
            },
            PendingIntent.FLAG_IMMUTABLE
        )
        val indeterminate = percent < 0
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle(title)
            .setContentText(if (indeterminate) "Starting…" else "$percent% complete")
            .setProgress(100, if (indeterminate) 0 else percent, indeterminate)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(pi)
            .build()
    }
}
