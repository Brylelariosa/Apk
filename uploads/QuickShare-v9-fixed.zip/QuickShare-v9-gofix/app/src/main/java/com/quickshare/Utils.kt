package com.quickshare

import java.text.DecimalFormat
import kotlin.math.log10
import kotlin.math.pow

object Utils {

    // ── Size formatting ───────────────────────────────────────────────────────

    fun formatSize(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        val i = (log10(bytes.toDouble()) / log10(1024.0)).toInt().coerceAtMost(4)
        return "${DecimalFormat("#,##0.#").format(bytes / 1024.0.pow(i.toDouble()))} ${units[i]}"
    }

    // ── Duration formatting (for ETA) ─────────────────────────────────────────

    fun formatDuration(seconds: Long): String {
        return when {
            seconds < 0   -> "?"
            seconds < 60  -> "${seconds}s"
            seconds < 3600 -> "${seconds / 60}m ${seconds % 60}s"
            else           -> "${seconds / 3600}h ${(seconds % 3600) / 60}m"
        }
    }

    // ── MIME type helper ──────────────────────────────────────────────────────

    fun getMimeType(fileName: String): String {
        val ext = fileName.substringAfterLast('.', "").lowercase()
        return when (ext) {
            // Images
            "jpg", "jpeg"        -> "image/jpeg"
            "png"                -> "image/png"
            "gif"                -> "image/gif"
            "webp"               -> "image/webp"
            "bmp"                -> "image/bmp"
            "heic", "heif"       -> "image/heic"
            // Video
            "mp4"                -> "video/mp4"
            "mkv"                -> "video/x-matroska"
            "avi"                -> "video/x-msvideo"
            "mov"                -> "video/quicktime"
            "webm"               -> "video/webm"
            "3gp"                -> "video/3gpp"
            "flv"                -> "video/x-flv"
            // Audio
            "mp3"                -> "audio/mpeg"
            "flac"               -> "audio/flac"
            "wav"                -> "audio/wav"
            "aac"                -> "audio/aac"
            "ogg"                -> "audio/ogg"
            "m4a"                -> "audio/m4a"
            "opus"               -> "audio/opus"
            // Documents
            "pdf"                -> "application/pdf"
            "doc"                -> "application/msword"
            "docx"               -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            "xls"                -> "application/vnd.ms-excel"
            "xlsx"               -> "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            "ppt"                -> "application/vnd.ms-powerpoint"
            "pptx"               -> "application/vnd.openxmlformats-officedocument.presentationml.presentation"
            // Text
            "txt"                -> "text/plain"
            "md"                 -> "text/markdown"
            "html", "htm"        -> "text/html"
            "xml"                -> "text/xml"
            "json"               -> "application/json"
            "csv"                -> "text/csv"
            // Archives
            "zip"                -> "application/zip"
            "rar"                -> "application/x-rar-compressed"
            "7z"                 -> "application/x-7z-compressed"
            "tar"                -> "application/x-tar"
            "gz"                 -> "application/gzip"
            // Android
            "apk"                -> "application/vnd.android.package-archive"
            else                 -> "application/octet-stream"
        }
    }

    // ── File type emoji ───────────────────────────────────────────────────────

    fun fileTypeEmoji(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        return when (ext) {
            "jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif" -> "🖼️"
            "mp4", "mkv", "avi", "mov", "webm", "3gp", "flv"           -> "🎬"
            "mp3", "flac", "wav", "aac", "ogg", "m4a", "opus"          -> "🎵"
            "pdf"                                                        -> "📄"
            "doc", "docx"                                                -> "📝"
            "xls", "xlsx", "csv"                                         -> "📊"
            "ppt", "pptx"                                                -> "📊"
            "zip", "rar", "7z", "tar", "gz", "bz2", "xz"               -> "🗜️"
            "apk"                                                        -> "📦"
            "txt", "md", "log"                                           -> "📃"
            "html", "htm", "xml", "json"                                 -> "🌐"
            else                                                         -> "📁"
        }
    }
}
