package com.quickshare

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.media.MediaScannerConnection
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.Uri
import android.net.wifi.WifiConfiguration
import android.net.wifi.WifiManager
import android.net.wifi.WifiNetworkSpecifier
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pDevice
import android.net.wifi.p2p.WifiP2pInfo
import android.net.wifi.p2p.WifiP2pManager
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.PowerManager
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.InputType
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.CheckedTextView
import android.widget.EditText
import android.widget.ImageView
import android.widget.ListView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import android.content.pm.ResolveInfo
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanIntentResult
import com.journeyapps.barcodescanner.ScanOptions
import com.quickshare.databinding.ActivityMainBinding
import kotlinx.coroutines.*
import org.json.JSONObject
import java.io.*
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.UUID
import java.util.zip.CRC32

class MainActivity : AppCompatActivity(), WifiP2pManager.ChannelListener {

    override fun attachBaseContext(newBase: Context) {
        val config = Configuration(newBase.resources.configuration)
        if (config.fontScale > 1.0f) {
            config.fontScale = 1.0f
            super.attachBaseContext(newBase.createConfigurationContext(config))
        } else {
            super.attachBaseContext(newBase)
        }
    }

    private lateinit var binding: ActivityMainBinding
    private lateinit var manager: WifiP2pManager
    private lateinit var channel: WifiP2pManager.Channel
    private lateinit var receiver: BroadcastReceiver

    private var isWifiP2pEnabled = false
    private var connectedDeviceInfo: WifiP2pInfo? = null
    private val peers = mutableListOf<WifiP2pDevice>()
    private lateinit var deviceAdapter: DeviceAdapter

    private var isReceiverMode = false
    private var isHotspotMode  = false
    private var boundNetwork: Network? = null
    private var detectedGoIp: String? = null
    private var peerClientIp: String? = null
    private var wifiNetworkCallback: ConnectivityManager.NetworkCallback? = null

    // Multi-file selection
    private val selectedFiles = mutableListOf<SelectedFile>()
    private lateinit var selectedFilesAdapter: SelectedFilesAdapter

    private val SERVER_PORT = 8988
    private val BUFFER_SIZE = 1024 * 256   // 256 KB I/O buffer

    private var serverJob: Job? = null

    // BUG-03 FIX: @Volatile ensures the IO-dispatcher coroutine always sees
    // the latest value written from the main thread.
    @Volatile private var isReceiving = false

    private var hotspotConnectJob: Job?  = null
    private var discoveryRetryJob: Job?  = null

    // BUG-07 FIX: Store a reference to the active ServerSocket so we can close
    // it from stopReceiveServer() — closing it immediately unblocks accept().
    @Volatile private var activeServerSocket: ServerSocket? = null

    // Cancel support
    @Volatile private var transferCancelled = false
    private var currentReceiveSocket: Socket? = null

    // Rolling speed tracking (last 2 s window)
    private val speedSamples = ArrayDeque<Pair<Long, Long>>()

    // Peer name for history
    private var peerDeviceName = "Unknown"

    // BUG-12 FIX: Serialize unique-filename generation across concurrent transfers.
    private val fileNameLock = Any()

    // Notification throttle — update foreground notification at most once per second.
    private var lastNotifUpdate = 0L
    private var currentTransferFileName = ""

    // BUG-18 FIX: Partial wake lock keeps CPU running during transfers.
    private var wakeLock: PowerManager.WakeLock? = null

    companion object {
        private const val TAG        = "QuickShare"
        private const val QR_PREFIX  = "QS:"
        private const val GO_IP      = "192.168.49.1"
        private const val NOTIF_CHANNEL = "qs_transfers"
    }

    // ── Activity Result Launchers ─────────────────────────────────────────────

    private val qrScanLauncher = registerForActivityResult(ScanContract()) { result: ScanIntentResult ->
        result.contents?.let { parseAndConnectQR(it) }
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        if (permissions.values.all { it }) initWifiDirect()
        else showToast("Some permissions denied — features may be limited")
    }

    private val imagePickerLauncher = registerForActivityResult(
        ActivityResultContracts.GetMultipleContents()
    ) { uris -> addSelectedFiles(uris) }

    private val filePickerLauncher = registerForActivityResult(
        ActivityResultContracts.GetMultipleContents()
    ) { uris -> addSelectedFiles(uris) }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        createNotificationChannel()
        setupUI()
        checkPermissionsAndInit()
    }

    override fun onResume() {
        super.onResume()
        if (::receiver.isInitialized) {
            try { registerWifiReceiver() } catch (_: Exception) {}
        }
    }

    override fun onPause() {
        super.onPause()
        if (::receiver.isInitialized) {
            try { unregisterReceiver(receiver) } catch (_: Exception) {}
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        serverJob?.cancel()
        discoveryRetryJob?.cancel()
        hotspotConnectJob?.cancel()
        releaseNetworkCallback()
        releaseWakeLock()
    }

    // ── Wake Lock ─────────────────────────────────────────────────────────────

    /** Acquire a PARTIAL_WAKE_LOCK so the CPU keeps running when the screen turns off. */
    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "QuickShare:Transfer"
        ).also {
            it.acquire(30 * 60 * 1000L) // 30-minute safety cap
        }
    }

    private fun releaseWakeLock() {
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (_: Exception) {}
        wakeLock = null
    }

    // ── UI Setup ──────────────────────────────────────────────────────────────

    private fun setupUI() {
        deviceAdapter = DeviceAdapter(peers) { device -> connectToDevice(device) }
        binding.rvDevices.layoutManager = LinearLayoutManager(this)
        binding.rvDevices.adapter = deviceAdapter

        selectedFilesAdapter = SelectedFilesAdapter(selectedFiles) { position ->
            selectedFiles.removeAt(position)
            selectedFilesAdapter.notifyItemRemoved(position)
            updateSelectedFilesUI()
        }
        binding.rvSelectedFiles.layoutManager = LinearLayoutManager(this)
        binding.rvSelectedFiles.adapter = selectedFilesAdapter
        binding.rvSelectedFiles.isNestedScrollingEnabled = false

        binding.btnReceive.setOnClickListener {
            if (isReceiverMode) { stopReceiveMode(); return@setOnClickListener }
            if (isHotspotMode) { showToast("Disconnect first before switching to receive mode"); return@setOnClickListener }
            if (!isWifiEnabled()) { showWifiOffDialog("Receiving requires WiFi to be on."); return@setOnClickListener }
            startReceiveMode()
        }

        binding.btnScanQR.setOnClickListener { scanQR() }

        binding.btnDiscover.setOnClickListener {
            if (!isWifiEnabled()) { showWifiOffDialog("Discovery requires WiFi."); return@setOnClickListener }
            if (!isWifiP2pEnabled) { showToast("WiFi Direct not ready — enable WiFi"); return@setOnClickListener }
            discoverPeers()
        }

        binding.btnPickImages.setOnClickListener { imagePickerLauncher.launch("image/*") }
        binding.btnPickFiles.setOnClickListener  { filePickerLauncher.launch("*/*") }
        binding.btnPickApk.setOnClickListener { launchAppPicker() }
        binding.btnPickText.setOnClickListener { showTextInputDialog() }

        binding.btnHistory.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }

        binding.btnClearFiles.setOnClickListener {
            selectedFiles.clear()
            selectedFilesAdapter.notifyDataSetChanged()
            updateSelectedFilesUI()
        }

        binding.btnSendFile.setOnClickListener {
            if (selectedFiles.isEmpty())  { showToast("Pick at least one file first"); return@setOnClickListener }
            if (!isConnectedInAnyMode())  { showToast("Connect to a receiver first");  return@setOnClickListener }
            sendFiles()
        }

        binding.btnDisconnect.setOnClickListener { disconnect() }

        binding.btnCancelTransfer.setOnClickListener {
            transferCancelled = true
            try { currentReceiveSocket?.close() } catch (_: Exception) {}
            showToast("Cancelling…")
            binding.btnCancelTransfer.isEnabled = false
        }

        updateStatus("Ready — tap 📥 Receive on the receiver, 📷 Scan QR on the sender")
        updateConnectionUI(false)
    }

    // ── App Picker ────────────────────────────────────────────────────────────

    private fun launchAppPicker() {
        showToast("Loading apps…")
        lifecycleScope.launch {
            val pm = packageManager
            val launcherIntent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
            }

            val resolveInfos = withContext(Dispatchers.IO) {
                pm.queryIntentActivities(launcherIntent, PackageManager.GET_META_DATA)
                    .filter { it.activityInfo.packageName != packageName }
                    .sortedBy { it.loadLabel(pm).toString() }
            }
            val icons = withContext(Dispatchers.IO) {
                resolveInfos.map { info ->
                    try { info.loadIcon(pm) } catch (_: Exception) { null }
                }
            }

            if (resolveInfos.isEmpty()) { showToast("No apps found"); return@launch }

            val checked   = BooleanArray(resolveInfos.size)
            val allLabels = resolveInfos.map { it.loadLabel(pm).toString() }

            val searchBox = EditText(this@MainActivity).apply {
                hint      = "Search apps…"
                inputType = InputType.TYPE_CLASS_TEXT
                setPadding(40, 20, 40, 10)
                setTextColor(Color.WHITE)
                setHintTextColor(Color.GRAY)
            }

            val container = android.widget.LinearLayout(this@MainActivity).apply {
                orientation = android.widget.LinearLayout.VERTICAL
            }

            val listView = ListView(this@MainActivity)
            val adapter = object : ArrayAdapter<ResolveInfo>(this@MainActivity, 0, resolveInfos.toMutableList()) {
                override fun getView(pos: Int, convertView: View?, parent: ViewGroup): View {
                    val view = convertView ?: LayoutInflater.from(context)
                        .inflate(android.R.layout.simple_list_item_multiple_choice, parent, false)
                    val tv   = view.findViewById<CheckedTextView>(android.R.id.text1)
                    val info = getItem(pos) ?: return view
                    val originalIndex = resolveInfos.indexOf(info)
                    tv.text    = if (originalIndex >= 0) allLabels[originalIndex] else info.loadLabel(pm)
                    val icon   = if (originalIndex >= 0) icons[originalIndex] else null
                    if (icon != null) {
                        icon.setBounds(0, 0, 80, 80)
                        tv.setCompoundDrawables(icon, null, null, null)
                    } else {
                        tv.setCompoundDrawables(null, null, null, null)
                    }
                    tv.compoundDrawablePadding = 20
                    tv.isChecked = if (originalIndex >= 0) checked[originalIndex] else false
                    return view
                }
            }

            listView.adapter    = adapter
            listView.choiceMode = ListView.CHOICE_MODE_MULTIPLE
            listView.setOnItemClickListener { _, _, pos, _ ->
                val info          = adapter.getItem(pos) ?: return@setOnItemClickListener
                val originalIndex = resolveInfos.indexOf(info)
                if (originalIndex >= 0) {
                    checked[originalIndex] = !checked[originalIndex]
                    listView.setItemChecked(pos, checked[originalIndex])
                }
            }

            searchBox.addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: android.text.Editable?) {
                    val query = s.toString().trim().lowercase()
                    adapter.clear()
                    adapter.addAll(if (query.isEmpty()) resolveInfos else
                        resolveInfos.filter { it.loadLabel(pm).toString().lowercase().contains(query) })
                    adapter.notifyDataSetChanged()
                }
            })

            container.addView(searchBox)
            container.addView(listView)

            AlertDialog.Builder(this@MainActivity)
                .setTitle("Select Apps to Send")
                .setView(container)
                .setPositiveButton("Add") { _, _ ->
                    var added = 0
                    for (i in resolveInfos.indices) {
                        if (checked[i]) {
                            val appInfo = resolveInfos[i].activityInfo.applicationInfo
                            val apkFile = File(appInfo.sourceDir)
                            val uri     = Uri.fromFile(apkFile)
                            val name    = allLabels[i] + ".apk"
                            val size    = apkFile.length()
                            if (selectedFiles.none { it.uri == uri }) {
                                selectedFiles.add(SelectedFile(uri, name, size))
                                added++
                            }
                        }
                    }
                    if (added > 0) {
                        selectedFilesAdapter.notifyDataSetChanged()
                        updateSelectedFilesUI()
                        showToast("$added app(s) added")
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    // ── Text input dialog ─────────────────────────────────────────────────────

    private fun showTextInputDialog() {
        val editText = EditText(this).apply {
            hint      = "Enter text to send…"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines  = 4
            maxLines  = 10
            setPadding(40, 20, 40, 20)
        }
        AlertDialog.Builder(this)
            .setTitle("📝 Send Text")
            .setView(editText)
            .setPositiveButton("Add to Queue") { _, _ ->
                val text = editText.text.toString()
                if (text.isBlank()) { showToast("Text is empty"); return@setPositiveButton }
                val fileName = "text_${System.currentTimeMillis()}.txt"
                val file     = File(cacheDir, fileName)
                file.writeText(text, Charsets.UTF_8)
                val uri = Uri.fromFile(file)
                selectedFiles.add(SelectedFile(uri, fileName, file.length()))
                selectedFilesAdapter.notifyDataSetChanged()
                updateSelectedFilesUI()
                showToast("Text added to queue")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ── Speed / ETA helpers ───────────────────────────────────────────────────

    private fun recordSpeed(totalTransferred: Long) {
        val now = System.currentTimeMillis()
        speedSamples.addLast(Pair(now, totalTransferred))
        while (speedSamples.size > 1 && now - speedSamples.first().first > 2000) {
            speedSamples.removeFirst()
        }
    }

    private fun rollingSpeedMBps(): Double {
        if (speedSamples.size < 2) return 0.0
        val (t0, b0) = speedSamples.first()
        val (t1, b1) = speedSamples.last()
        val elapsed  = (t1 - t0) / 1000.0
        return if (elapsed > 0) (b1 - b0).toDouble() / elapsed / 1024 / 1024 else 0.0
    }

    /** Returns remaining seconds, or -1 if speed is unknown. */
    private fun calcEta(received: Long, total: Long, speedMBps: Double): Long {
        if (speedMBps <= 0.0 || received >= total) return -1L
        val remaining = total - received
        return (remaining / (speedMBps * 1024.0 * 1024.0)).toLong()
    }

    // ── Filename sanitization (BUG-04 FIX) ───────────────────────────────────

    /**
     * Strip any characters that could be used for path-traversal attacks.
     * A sender could send "../../../data/data/…" as a filename — we must
     * reduce it to a flat, safe name before writing it to disk.
     */
    private fun sanitizeFileName(name: String): String {
        return name
            .replace('\u0000', '_')  // Null bytes
            .replace('/',     '_')   // Unix path separator
            .replace('\\',    '_')   // Windows path separator
            .replace("..",    "__")  // Parent directory traversal
            .trim()
            .ifEmpty { "received_file_${System.currentTimeMillis()}" }
            .take(200)               // Android max filename ≈ 255 chars; keep headroom
    }

    // ── Notifications ─────────────────────────────────────────────────────────

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                NOTIF_CHANNEL, "File Transfers", NotificationManager.IMPORTANCE_DEFAULT
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notifyReceiveComplete(fileCount: Int, totalBytes: Long) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED) return

        val notif = NotificationCompat.Builder(this, NOTIF_CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle("QuickShare — Files Received")
            .setContentText("✅ $fileCount file(s) · ${Utils.formatSize(totalBytes)} → Downloads")
            .setAutoCancel(true)
            .build()

        getSystemService(NotificationManager::class.java)
            .notify(System.currentTimeMillis().toInt() and 0xFFFF, notif)
    }

    // ── Shared helpers ────────────────────────────────────────────────────────

    private fun isConnectedInAnyMode() = connectedDeviceInfo != null || isHotspotMode

    private fun isWifiEnabled(): Boolean {
        val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
        return wm.isWifiEnabled
    }

    private fun showWifiOffDialog(message: String) {
        AlertDialog.Builder(this)
            .setTitle("WiFi is Off")
            .setMessage("$message\n\nOpen WiFi settings?")
            .setPositiveButton("Open Settings") { _, _ -> startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ── Selected Files ────────────────────────────────────────────────────────

    private fun addSelectedFiles(uris: List<Uri>) {
        var added = 0
        for (uri in uris) {
            if (selectedFiles.none { it.uri == uri }) {
                val (name, size) = getFileInfo(uri)
                selectedFiles.add(SelectedFile(uri, name, size))
                added++
            }
        }
        if (added > 0) selectedFilesAdapter.notifyDataSetChanged()
        updateSelectedFilesUI()
    }

    private fun updateSelectedFilesUI() {
        if (selectedFiles.isEmpty()) {
            binding.cardSelectedFiles.visibility = View.GONE
        } else {
            binding.cardSelectedFiles.visibility = View.VISIBLE
            val totalSize = selectedFiles.sumOf { it.size }
            binding.tvSelectedFilesHeader.text =
                "${selectedFiles.size} file(s) selected • ${Utils.formatSize(totalSize)}"
        }
        binding.btnSendFile.isEnabled = selectedFiles.isNotEmpty() && isConnectedInAnyMode()
    }

    // ── Permissions ───────────────────────────────────────────────────────────

    private fun checkPermissionsAndInit() {
        val perms = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.CAMERA
        )
        when {
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU -> {
                perms += listOf(
                    Manifest.permission.NEARBY_WIFI_DEVICES,
                    Manifest.permission.READ_MEDIA_IMAGES,
                    Manifest.permission.READ_MEDIA_VIDEO,
                    Manifest.permission.READ_MEDIA_AUDIO,
                    Manifest.permission.POST_NOTIFICATIONS
                )
                // API 34+: photo picker partial access
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                    perms += Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED
                }
            }
            Build.VERSION.SDK_INT <= Build.VERSION_CODES.P -> {
                // API 28-: need both READ and WRITE for Downloads
                perms += Manifest.permission.READ_EXTERNAL_STORAGE
                perms += Manifest.permission.WRITE_EXTERNAL_STORAGE   // BUG-09 FIX
            }
            else -> {
                // API 29–32
                perms += Manifest.permission.READ_EXTERNAL_STORAGE
                // No WRITE needed: requestLegacyExternalStorage + MediaStore cover this
            }
        }
        val missing = perms.filter {
            ActivityCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) initWifiDirect() else permissionLauncher.launch(missing.toTypedArray())
    }

    // ── WiFi Direct ───────────────────────────────────────────────────────────

    private fun initWifiDirect() {
        manager  = getSystemService(Context.WIFI_P2P_SERVICE) as WifiP2pManager
        channel  = manager.initialize(this, mainLooper, this)
        receiver = WiFiDirectBroadcastReceiver(manager, channel, this)
        registerWifiReceiver()
    }

    private fun registerWifiReceiver() {
        val filter = IntentFilter().apply {
            addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION)
        }
        registerReceiver(receiver, filter)
    }

    fun setWifiP2pEnabled(enabled: Boolean) {
        isWifiP2pEnabled = enabled
        if (!enabled) {
            updateStatus("WiFi is OFF — please enable WiFi")
            updateConnectionUI(false)
        }
    }

    private fun discoverPeers() {
        discoveryRetryJob?.cancel()
        updateStatus("🔍 Scanning for nearby devices…")
        binding.progressBar.visibility = View.VISIBLE
        if (!hasLocationPerm()) { showToast("Location permission needed"); return }

        manager.discoverPeers(channel, object : WifiP2pManager.ActionListener {
            override fun onSuccess() {
                updateStatus("Scanning… (auto-retry if nothing found)")
                discoveryRetryJob = lifecycleScope.launch {
                    delay(8000)
                    if (peers.isEmpty() && isWifiP2pEnabled) {
                        updateStatus("Nothing found yet — retrying…")
                        discoverPeers()
                    }
                }
            }
            override fun onFailure(reason: Int) {
                binding.progressBar.visibility = View.GONE
                val msg = when (reason) {
                    WifiP2pManager.P2P_UNSUPPORTED -> "WiFi Direct not supported on this device"
                    WifiP2pManager.BUSY            -> {
                        discoveryRetryJob = lifecycleScope.launch {
                            delay(5000)
                            if (peers.isEmpty() && isWifiP2pEnabled) discoverPeers()
                        }
                        "System busy — retrying scan in 5 s…"
                    }
                    else -> "Discovery failed (code $reason)"
                }
                updateStatus(msg); showToast(msg)
            }
        })
    }

    fun updatePeerList(deviceList: Collection<WifiP2pDevice>) {
        binding.progressBar.visibility = View.GONE
        peers.clear(); peers.addAll(deviceList)
        deviceAdapter.notifyDataSetChanged()
        if (peers.isEmpty()) {
            updateStatus("No devices found — make sure receiver tapped 📥 Receive")
            binding.tvNoPeers.visibility = View.VISIBLE
        } else {
            discoveryRetryJob?.cancel()
            updateStatus("Found ${peers.size} device(s) — tap to connect")
            binding.tvNoPeers.visibility = View.GONE
        }
    }

    private fun connectToDevice(device: WifiP2pDevice) {
        peerDeviceName = device.deviceName.ifEmpty { "Unknown Device" }
        val config = WifiP2pConfig().apply { deviceAddress = device.deviceAddress }
        if (!hasLocationPerm()) return
        updateStatus("Connecting to ${device.deviceName}…")
        binding.progressBar.visibility = View.VISIBLE

        manager.connect(channel, config, object : WifiP2pManager.ActionListener {
            override fun onSuccess() { showToast("Connection request sent to ${device.deviceName}") }
            override fun onFailure(reason: Int) {
                binding.progressBar.visibility = View.GONE
                showToast("Connection failed: $reason")
                updateStatus("Connection failed — try again")
            }
        })
    }

    fun onConnectionInfoAvailable(info: WifiP2pInfo) {
        binding.progressBar.visibility = View.GONE
        connectedDeviceInfo = info

        if (info.groupFormed) {
            val role = if (info.isGroupOwner) "Host (GO)" else "Client"
            val goIp = info.groupOwnerAddress?.hostAddress ?: "?"
            updateStatus("✓ P2P Connected as $role — GO IP: $goIp")
            updateConnectionUI(true)

            // BUG-02 FIX: P2P client registers its IP with the GO immediately.
            // The GO records the client IP when it accepts this 0-file connection,
            // so that the GO can subsequently initiate a transfer to the client.
            if (!info.isGroupOwner) {
                val goAddress = info.groupOwnerAddress?.hostAddress
                if (goAddress != null) {
                    registerWithServer(goAddress, null)
                }
            }

            if (isReceiverMode && !isReceiving) {
                startReceiveServer()
            }
        }
    }

    private fun disconnect() {
        discoveryRetryJob?.cancel()
        releaseNetworkCallback()
        if (connectedDeviceInfo != null) {
            manager.removeGroup(channel, object : WifiP2pManager.ActionListener {
                override fun onSuccess()    = resetConnectionState()
                override fun onFailure(r: Int) = resetConnectionState()
            })
        } else {
            resetConnectionState()
        }
    }

    internal fun resetConnectionState() {
        connectedDeviceInfo = null
        isHotspotMode       = false
        boundNetwork        = null
        detectedGoIp        = null
        peerClientIp        = null
        isReceiverMode      = false
        stopReceiveServer()
        updateConnectionUI(false)
        updateStatus("Disconnected — Ready")
        updateSelectedFilesUI()
    }

    override fun onChannelDisconnected() {
        showToast("WiFi Direct channel lost — reconnecting…")
        if (::manager.isInitialized) channel = manager.initialize(this, mainLooper, this)
    }

    // ── Receive Mode ──────────────────────────────────────────────────────────

    private fun startReceiveMode() {
        if (!::manager.isInitialized) { showToast("WiFi not ready yet — try again"); return }
        isReceiverMode = true
        binding.btnReceive.text = "⏹ Stop Receiving"
        binding.btnReceive.setBackgroundColor(getColor(R.color.red))
        updateStatus("Setting up hotspot…")
        binding.progressBar.visibility = View.VISIBLE

        manager.removeGroup(channel, object : WifiP2pManager.ActionListener {
            override fun onSuccess()       = createGroupForReceiving()
            override fun onFailure(r: Int) = createGroupForReceiving()
        })
    }

    private fun createGroupForReceiving() {
        if (!hasLocationPerm()) {
            binding.progressBar.visibility = View.GONE
            showToast("Location permission needed")
            return
        }
        manager.createGroup(channel, object : WifiP2pManager.ActionListener {
            override fun onSuccess() {
                lifecycleScope.launch {
                    delay(600)
                    manager.requestGroupInfo(channel) { group ->
                        binding.progressBar.visibility = View.GONE
                        startReceiveServer()
                        if (group != null) {
                            updateStatus("📥 Ready to receive — show QR to sender")
                            showQRDialog(group.networkName, group.passphrase)
                        } else {
                            updateStatus("📥 Server active — sender can use Discover")
                        }
                    }
                }
            }
            override fun onFailure(reason: Int) {
                manager.requestGroupInfo(channel) { group ->
                    binding.progressBar.visibility = View.GONE
                    startReceiveServer()
                    if (group != null) {
                        updateStatus("📥 Ready to receive — show QR to sender")
                        showQRDialog(group.networkName, group.passphrase)
                    } else {
                        updateStatus("📥 Server active (createGroup failed: $reason) — use Discover")
                        showToast("Hotspot setup issue — try WiFi Direct discovery")
                    }
                }
            }
        })
    }

    private fun stopReceiveMode() {
        isReceiverMode = false
        stopReceiveServer()
        manager.removeGroup(channel, object : WifiP2pManager.ActionListener {
            override fun onSuccess()       {}
            override fun onFailure(r: Int) {}
        })
        binding.btnReceive.text = "📥 Receive"
        binding.btnReceive.setBackgroundColor(getColor(R.color.green))
        updateStatus("Receive mode stopped")
    }

    // ── QR Code ───────────────────────────────────────────────────────────────

    private fun showQRDialog(ssid: String, passphrase: String) {
        val json    = JSONObject().apply { put("s", ssid); put("p", passphrase) }.toString()
        val content = QR_PREFIX + json
        val size    = 600
        val hints   = mapOf(
            EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.M,
            EncodeHintType.MARGIN to 2
        )
        val matrix = QRCodeWriter().encode(content, BarcodeFormat.QR_CODE, size, size, hints)
        val bmp    = Bitmap.createBitmap(size, size, Bitmap.Config.RGB_565)
        for (x in 0 until size) for (y in 0 until size)
            bmp.setPixel(x, y, if (matrix[x, y]) Color.BLACK else Color.WHITE)

        val iv = ImageView(this).apply { setImageBitmap(bmp); setPadding(40, 40, 40, 16) }

        AlertDialog.Builder(this)
            .setTitle("📥 Ready to Receive")
            .setMessage("Have the sender tap 📷 Scan QR and scan this code")
            .setView(iv)
            .setPositiveButton("Keep Active") { d, _ -> d.dismiss() }
            .setNegativeButton("Stop Receiving") { d, _ -> d.dismiss(); stopReceiveMode() }
            .setCancelable(false)
            .show()
    }

    private fun scanQR() {
        val options = ScanOptions()
            .setDesiredBarcodeFormats(ScanOptions.QR_CODE)
            .setPrompt("Scan the receiver's QR code")
            .setCameraId(0)
            .setBeepEnabled(true)
            .setBarcodeImageEnabled(false)
        qrScanLauncher.launch(options)
    }

    private fun parseAndConnectQR(content: String) {
        try {
            val json       = content.removePrefix(QR_PREFIX)
            val obj        = JSONObject(json)
            val ssid       = obj.getString("s")
            val passphrase = obj.getString("p")
            peerDeviceName = "QR Connection"
            updateStatus("QR scanned — connecting to $ssid…")
            connectViaHotspot(ssid, passphrase)
        } catch (e: Exception) {
            showToast("Invalid QR code")
            Log.e(TAG, "QR parse error: ${e.message}")
        }
    }

    // ── Hotspot Connection ────────────────────────────────────────────────────

    private fun connectViaHotspot(ssid: String, passphrase: String) {
        binding.progressBar.visibility = View.VISIBLE
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            connectViaNetworkSpecifier(ssid, passphrase)
        } else {
            @Suppress("DEPRECATION")
            connectLegacyWifi(ssid, passphrase)
        }
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    private fun connectViaNetworkSpecifier(ssid: String, passphrase: String) {
        val specifier = WifiNetworkSpecifier.Builder().setSsid(ssid).setWpa2Passphrase(passphrase).build()
        val request   = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .setNetworkSpecifier(specifier).build()
        val cm = getSystemService(ConnectivityManager::class.java)
        releaseNetworkCallback()

        hotspotConnectJob?.cancel()
        hotspotConnectJob = lifecycleScope.launch {
            delay(15_000)
            if (!isHotspotMode) {
                releaseNetworkCallback()
                binding.progressBar.visibility = View.GONE
                updateStatus("⏱ Connection timed out — make sure receiver's QR is still active")
                showToast("Timed out — try scanning QR again")
            }
        }

        wifiNetworkCallback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                hotspotConnectJob?.cancel()
                boundNetwork  = network
                isHotspotMode = true

                val linkProps = cm.getLinkProperties(network)
                detectedGoIp = linkProps?.routes
                    ?.firstOrNull { it.gateway != null && !it.gateway!!.isLoopbackAddress }
                    ?.gateway?.hostAddress
                    ?: GO_IP

                runOnUiThread {
                    binding.progressBar.visibility = View.GONE
                    updateStatus("✅ Connected! (GO: $detectedGoIp) — Pick files and tap 🚀 Send Files")
                    updateConnectionUI(true)
                    startReceiveServer()
                    // BUG-02 FIX: Register our IP with the GO so it can send to us.
                    registerWithServer(detectedGoIp ?: GO_IP, network)
                }
            }
            override fun onUnavailable() {
                hotspotConnectJob?.cancel()
                runOnUiThread {
                    binding.progressBar.visibility = View.GONE
                    updateStatus("❌ Could not connect — receiver may need to restart Receive mode")
                    showToast("Connection failed — try again")
                }
            }
            override fun onLost(network: Network) {
                if (boundNetwork == network) {
                    boundNetwork = null; isHotspotMode = false
                    runOnUiThread { updateStatus("Connection lost") }
                }
            }
        }
        cm.requestNetwork(request, wifiNetworkCallback!!)
        updateStatus("Connecting to receiver's hotspot…")
    }

    @Suppress("DEPRECATION")
    private fun connectLegacyWifi(ssid: String, passphrase: String) {
        val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
        val cfg = WifiConfiguration().apply {
            SSID           = "\"$ssid\""
            preSharedKey   = "\"$passphrase\""
            allowedKeyManagement.set(WifiConfiguration.KeyMgmt.WPA_PSK)
        }
        val id = wm.addNetwork(cfg)
        if (id == -1) {
            binding.progressBar.visibility = View.GONE
            showToast("Failed to configure WiFi — connect manually to: $ssid")
            return
        }
        wm.disconnect(); wm.enableNetwork(id, true); wm.reconnect()

        lifecycleScope.launch {
            val deadline = System.currentTimeMillis() + 12_000
            while (System.currentTimeMillis() < deadline) {
                delay(1000)
                @Suppress("DEPRECATION")
                val currentSsid = wm.connectionInfo?.ssid?.trim('"') ?: ""
                if (currentSsid == ssid) {
                    isHotspotMode = true; boundNetwork = null
                    @Suppress("DEPRECATION")
                    val dhcp = wm.dhcpInfo
                    detectedGoIp = if (dhcp.gateway != 0) intToIp(dhcp.gateway) else GO_IP
                    withContext(Dispatchers.Main) {
                        binding.progressBar.visibility = View.GONE
                        updateStatus("✅ Connected! (GO: $detectedGoIp) — Pick files and tap 🚀 Send Files")
                        updateConnectionUI(true)
                        startReceiveServer()
                        // BUG-02 FIX: Register our IP with the GO.
                        registerWithServer(detectedGoIp ?: GO_IP, null)
                    }
                    return@launch
                }
            }
            withContext(Dispatchers.Main) {
                binding.progressBar.visibility = View.GONE
                isHotspotMode = true; boundNetwork = null
                updateStatus("⚠️ Connection unconfirmed — try tapping 🚀 Send Files")
                updateConnectionUI(true)
            }
        }
    }

    /** Convert Android's little-endian int IP (from DhcpInfo) to dotted string. */
    private fun intToIp(i: Int) =
        "${i and 0xFF}.${i shr 8 and 0xFF}.${i shr 16 and 0xFF}.${i shr 24 and 0xFF}"

    private fun releaseNetworkCallback() {
        wifiNetworkCallback?.let {
            try { getSystemService(ConnectivityManager::class.java).unregisterNetworkCallback(it) }
            catch (_: Exception) {}
            wifiNetworkCallback = null
        }
    }

    // ── Registration ping (BUG-02 FIX) ───────────────────────────────────────

    /**
     * Sends a zero-file "hello" packet to [hostIp]:[SERVER_PORT] so the remote
     * device's receive server can record our IP address in [peerClientIp].
     *
     * This is the only mechanism by which the Group Owner learns the client IP,
     * enabling bidirectional transfers after the initial QR/P2P connection.
     *
     * A fileCount of 0 is handled gracefully by [handleIncomingFiles] (early
     * return, no history entry, just records the socket's source address).
     */
    private fun registerWithServer(hostIp: String, network: Network?) {
        lifecycleScope.launch(Dispatchers.IO) {
            delay(400) // Let the local receive server start first
            try {
                val s = Socket()
                s.tcpNoDelay = true
                network?.bindSocket(s)
                s.connect(InetSocketAddress(hostIp, SERVER_PORT), 5000)
                DataOutputStream(s.getOutputStream()).apply {
                    writeInt(0) // 0 files = registration ping only
                    flush()
                }
                s.close()
                Log.d(TAG, "Registration ping sent to $hostIp")
            } catch (e: Exception) {
                // Non-critical — the other side just won't have our IP yet.
                Log.d(TAG, "Registration ping failed (non-critical): ${e.message}")
            }
        }
    }

    // ── TCP Receive Server ────────────────────────────────────────────────────

    private fun startReceiveServer() {
        if (isReceiving) return
        isReceiving = true

        serverJob?.cancel()
        serverJob = lifecycleScope.launch(Dispatchers.IO) {
            var serverSocket: ServerSocket? = null
            try {
                serverSocket = ServerSocket(SERVER_PORT).also {
                    it.reuseAddress     = true
                    it.receiveBufferSize = BUFFER_SIZE
                    // BUG-07 FIX: soTimeout lets accept() wake up every 2 s to
                    // check isActive/isReceiving, so cancel() is never stuck.
                    it.soTimeout        = 2000
                    activeServerSocket  = it   // BUG-07 FIX: expose for external close
                }
                Log.d(TAG, "Server listening on :$SERVER_PORT")

                while (isActive && isReceiving) {
                    try {
                        val client = serverSocket.accept()
                        client.soTimeout         = 60_000
                        client.receiveBufferSize = BUFFER_SIZE
                        launch { handleIncomingFiles(client) }
                    } catch (e: java.net.SocketTimeoutException) {
                        // Normal periodic wake-up — just loop and check isActive.
                        continue
                    } catch (e: Exception) {
                        if (isActive && isReceiving) Log.e(TAG, "Accept error: ${e.message}")
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Server error: ${e.message}")
                withContext(Dispatchers.Main) { showToast("Server error: ${e.message}") }
            } finally {
                activeServerSocket = null
                serverSocket?.close()
            }
        }
    }

    private fun stopReceiveServer() {
        isReceiving = false
        // BUG-07 FIX: Close the socket NOW so accept() is unblocked immediately.
        try { activeServerSocket?.close() } catch (_: Exception) {}
        activeServerSocket = null
        serverJob?.cancel()
        serverJob = null
    }

    // ── Incoming file handler ─────────────────────────────────────────────────

    /**
     * Protocol (little-endian, DataInputStream/DataOutputStream):
     *   [int]  fileCount   — 0 = registration ping (IP-only, no transfer)
     *   For each file:
     *     [int]   nameLen
     *     [bytes] name (UTF-8)
     *     [long]  fileSize
     *     [bytes] file data
     *     [int]   CRC32
     */
    private suspend fun handleIncomingFiles(socket: Socket) {
        currentReceiveSocket = socket
        // Record sender IP so the GO can send back to a P2P/hotspot client.
        socket.inetAddress.hostAddress?.let { peerClientIp = it }

        val fileNames   = mutableListOf<String>()
        var allReceived = 0L
        var status      = "success"

        try {
            val input     = DataInputStream(BufferedInputStream(socket.getInputStream(), BUFFER_SIZE))
            val fileCount = input.readInt()

            // BUG-02 FIX: 0-file packet is a registration ping — record IP, return.
            if (fileCount == 0) {
                Log.d(TAG, "Registration ping from ${socket.inetAddress.hostAddress}")
                return
            }

            withContext(Dispatchers.Main) {
                transferCancelled = false
                speedSamples.clear()
                updateStatus("Receiving $fileCount file(s)…")
                acquireWakeLock()
                TransferForegroundService.start(
                    this@MainActivity, "📥 Receiving $fileCount file(s)…"
                )
            }

            for (i in 1..fileCount) {
                if (transferCancelled) { status = "cancelled"; break }

                val nameLen   = input.readInt()
                val nameBytes = ByteArray(nameLen)
                input.readFully(nameBytes)
                // BUG-04 FIX: sanitize received filename before any disk I/O.
                val fileName  = sanitizeFileName(String(nameBytes, Charsets.UTF_8))
                val fileSize  = input.readLong()
                fileNames.add(fileName)

                withContext(Dispatchers.Main) {
                    showProgressUI(true, fileName, fileSize, i, fileCount)
                    updateStatus("Receiving $i/$fileCount: $fileName (${Utils.formatSize(fileSize)})")
                }

                var received = 0L

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    // ── BUG-01 FIX: MediaStore for Android 10+ ──────────────
                    val cv = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                        put(MediaStore.Downloads.MIME_TYPE,    Utils.getMimeType(fileName))
                        put(MediaStore.Downloads.IS_PENDING,   1)
                    }
                    val uri = contentResolver.insert(
                        MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv
                    ) ?: throw IOException("MediaStore insert failed for $fileName")

                    var committed = false
                    try {
                        contentResolver.openOutputStream(uri)?.buffered(BUFFER_SIZE)?.use { rawOut ->
                            val buffer = ByteArray(BUFFER_SIZE)
                            val crc    = CRC32()

                            while (received < fileSize) {
                                if (transferCancelled) break
                                val toRead = minOf(buffer.size.toLong(), fileSize - received).toInt()
                                val read   = input.read(buffer, 0, toRead)
                                if (read == -1) break
                                rawOut.write(buffer, 0, read)
                                crc.update(buffer, 0, read)
                                received    += read
                                allReceived += read
                                recordSpeed(allReceived)
                                val pct      = if (fileSize > 0) ((received * 100) / fileSize).toInt() else 100
                                val speed    = rollingSpeedMBps()
                                val eta      = calcEta(received, fileSize, speed)
                                withContext(Dispatchers.Main) {
                                    updateProgress(pct, received, fileSize, speed, eta)
                                }
                            }
                            rawOut.flush()

                            if (!transferCancelled) {
                                val senderCrc = input.readInt()
                                if (senderCrc != crc.value.toInt()) {
                                    withContext(Dispatchers.Main) {
                                        showToast("⚠️ $fileName may be corrupted (CRC mismatch)")
                                    }
                                }
                                committed = true
                            }
                        } ?: throw IOException("Cannot open output stream for $fileName")

                        if (committed) {
                            // Publish the file — makes it visible in Downloads.
                            contentResolver.update(uri, ContentValues().apply {
                                put(MediaStore.Downloads.IS_PENDING, 0)
                            }, null, null)
                        } else {
                            contentResolver.delete(uri, null, null)
                            if (transferCancelled) { status = "cancelled"; break }
                        }
                    } catch (e: Exception) {
                        contentResolver.delete(uri, null, null)
                        throw e
                    }

                } else {
                    // ── Android 8/9: direct FileOutputStream ────────────────
                    val downloadsDir = Environment
                        .getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                    downloadsDir.mkdirs()

                    // BUG-12 FIX: synchronized unique-name check.
                    val uniqueName = synchronized(fileNameLock) {
                        getUniqueFileName(downloadsDir, fileName)
                    }
                    val outFile = File(downloadsDir, uniqueName)
                    val buffer  = ByteArray(BUFFER_SIZE)
                    val crc     = CRC32()
                    var crcOk   = false

                    try {
                        BufferedOutputStream(FileOutputStream(outFile), BUFFER_SIZE).use { output ->
                            while (received < fileSize) {
                                if (transferCancelled) break
                                val toRead = minOf(buffer.size.toLong(), fileSize - received).toInt()
                                val read   = input.read(buffer, 0, toRead)
                                if (read == -1) break
                                output.write(buffer, 0, read)
                                crc.update(buffer, 0, read)
                                received    += read
                                allReceived += read
                                recordSpeed(allReceived)
                                val pct  = if (fileSize > 0) ((received * 100) / fileSize).toInt() else 100
                                val speed = rollingSpeedMBps()
                                val eta   = calcEta(received, fileSize, speed)
                                withContext(Dispatchers.Main) {
                                    updateProgress(pct, received, fileSize, speed, eta)
                                }
                            }
                            output.flush()
                        }

                        if (transferCancelled) {
                            outFile.delete()
                            status = "cancelled"
                            break
                        }

                        val senderCrc = input.readInt()
                        crcOk = senderCrc == crc.value.toInt()
                        if (!crcOk) {
                            val corrupt = File(outFile.parent, "CORRUPTED_${outFile.name}")
                            outFile.renameTo(corrupt)
                            withContext(Dispatchers.Main) {
                                showToast("⚠️ $fileName may be corrupted (CRC mismatch)")
                            }
                        } else {
                            // BUG-11 FIX: Tell the media scanner about the new file
                            // so it appears in gallery/file-manager apps immediately.
                            MediaScannerConnection.scanFile(
                                this@MainActivity,
                                arrayOf(outFile.absolutePath),
                                arrayOf(Utils.getMimeType(outFile.name)),
                                null
                            )
                        }
                    } catch (e: Exception) {
                        outFile.delete()
                        throw e
                    }
                }
            }

            input.close()

            withContext(Dispatchers.Main) {
                showProgressUI(false, "", 0)
                when (status) {
                    "cancelled" -> updateStatus("⛔ Transfer cancelled")
                    else -> {
                        updateStatus("✅ Received ${fileNames.size} file(s) — ${Utils.formatSize(allReceived)} total → Downloads")
                        showToast("${fileNames.size} file(s) saved to Downloads")
                        notifyReceiveComplete(fileNames.size, allReceived)
                    }
                }
            }

        } catch (e: java.net.SocketTimeoutException) {
            status = "failed"
            Log.e(TAG, "Receive timeout: ${e.message}")
            withContext(Dispatchers.Main) {
                showProgressUI(false, "", 0)
                updateStatus("❌ Receive timed out — sender may have disconnected")
                showToast("Transfer timed out")
            }
        } catch (e: Exception) {
            status = "failed"
            Log.e(TAG, "Receive error: ${e.message}")
            withContext(Dispatchers.Main) {
                showProgressUI(false, "", 0)
                updateStatus("❌ Receive failed: ${e.message}")
            }
        } finally {
            currentReceiveSocket = null
            try { socket.close() } catch (_: Exception) {}
            withContext(Dispatchers.Main) {
                releaseWakeLock()
                TransferForegroundService.stop(this@MainActivity)
            }
            // Only add a history entry when actual files were involved.
            if (fileNames.isNotEmpty()) {
                HistoryManager.add(this@MainActivity, TransferRecord(
                    id         = UUID.randomUUID().toString(),
                    timestamp  = System.currentTimeMillis(),
                    direction  = "received",
                    fileNames  = fileNames,
                    totalBytes = allReceived,
                    peerName   = peerDeviceName,
                    status     = status
                ))
            }
        }
    }

    // ── TCP Send ──────────────────────────────────────────────────────────────

    private fun sendFiles() {
        val hostIp: String = when {
            isHotspotMode ->
                detectedGoIp ?: GO_IP
            connectedDeviceInfo?.isGroupOwner == false ->
                connectedDeviceInfo?.groupOwnerAddress?.hostAddress ?: run {
                    showToast("Cannot determine receiver IP"); return
                }
            connectedDeviceInfo?.isGroupOwner == true && peerClientIp != null ->
                peerClientIp!!
            else -> {
                showToast("Cannot reach other device — receiver must tap 📥 Receive first so we learn their IP")
                return
            }
        }

        val filesToSend = selectedFiles.toList()

        lifecycleScope.launch(Dispatchers.IO) {
            var socket: Socket? = null
            var totalBytesSent  = 0L
            var status          = "success"

            withContext(Dispatchers.Main) {
                transferCancelled = false
                speedSamples.clear()
                acquireWakeLock()
                TransferForegroundService.start(
                    this@MainActivity, "📤 Sending ${filesToSend.size} file(s)…"
                )
                updateStatus("Connecting to $hostIp…")
                showProgressUI(true, filesToSend.first().name, filesToSend.first().size, 1, filesToSend.size)
            }

            try {
                socket = connectToHost(hostIp)
                val output = DataOutputStream(BufferedOutputStream(socket.getOutputStream(), BUFFER_SIZE))

                output.writeInt(filesToSend.size)

                for ((index, file) in filesToSend.withIndex()) {
                    if (transferCancelled) { status = "cancelled"; break }

                    val actualSize = resolveActualSize(file)

                    withContext(Dispatchers.Main) {
                        showProgressUI(true, file.name, actualSize, index + 1, filesToSend.size)
                        updateStatus("Sending ${index + 1}/${filesToSend.size}: ${file.name}")
                    }

                    val nameBytes = file.name.toByteArray(Charsets.UTF_8)
                    output.writeInt(nameBytes.size)
                    output.write(nameBytes)
                    output.writeLong(actualSize)

                    val inputStream = openFileStream(file)
                        ?: throw IOException("Cannot open: ${file.name}")
                    val buffer = ByteArray(BUFFER_SIZE)
                    val crc    = CRC32()
                    var sent   = 0L

                    while (true) {
                        if (transferCancelled) break
                        val read = inputStream.read(buffer)
                        if (read == -1) break
                        output.write(buffer, 0, read)
                        crc.update(buffer, 0, read)
                        sent           += read
                        totalBytesSent += read

                        recordSpeed(totalBytesSent)
                        val pct   = if (actualSize > 0) ((sent * 100) / actualSize).toInt() else 100
                        val speed = rollingSpeedMBps()
                        val eta   = calcEta(sent, actualSize, speed)
                        withContext(Dispatchers.Main) {
                            updateProgress(pct, sent, actualSize, speed, eta)
                        }
                    }
                    inputStream.close()

                    if (transferCancelled) { status = "cancelled"; break }

                    output.writeInt(crc.value.toInt())
                }
                output.flush()

                withContext(Dispatchers.Main) {
                    showProgressUI(false, "", 0)
                    when (status) {
                        "cancelled" -> updateStatus("⛔ Transfer cancelled")
                        else -> {
                            updateStatus("✅ Sent ${filesToSend.size} file(s) — ${Utils.formatSize(totalBytesSent)} total")
                            showToast("${filesToSend.size} file(s) sent!")
                        }
                    }
                }

            } catch (e: Exception) {
                status = "failed"
                Log.e(TAG, "Send error: ${e.message}")
                withContext(Dispatchers.Main) {
                    showProgressUI(false, "", 0)
                    updateStatus("❌ Send failed: ${e.message}")
                    showToast("Send failed: ${e.message}")
                }
            } finally {
                try { socket?.close() } catch (_: Exception) {}

                // Delete temp text snippets from cacheDir
                filesToSend.forEach { f ->
                    if (f.uri.scheme == "file" &&
                        f.uri.path?.startsWith(cacheDir.path) == true) {
                        try { File(f.uri.path!!).delete() } catch (_: Exception) {}
                    }
                }

                withContext(Dispatchers.Main) {
                    releaseWakeLock()
                    TransferForegroundService.stop(this@MainActivity)
                }

                HistoryManager.add(this@MainActivity, TransferRecord(
                    id         = UUID.randomUUID().toString(),
                    timestamp  = System.currentTimeMillis(),
                    direction  = "sent",
                    fileNames  = filesToSend.map { it.name },
                    totalBytes = totalBytesSent,
                    peerName   = peerDeviceName,
                    status     = status
                ))
            }
        }
    }

    private fun openFileStream(file: SelectedFile): InputStream? {
        return if (file.uri.scheme == "file") {
            try { FileInputStream(File(file.uri.path!!)) } catch (_: Exception) { null }
        } else {
            contentResolver.openInputStream(file.uri)
        }
    }

    private fun resolveActualSize(file: SelectedFile): Long {
        if (file.uri.scheme == "file") return File(file.uri.path!!).length()
        return try {
            contentResolver.openFileDescriptor(file.uri, "r")?.use { it.statSize } ?: file.size
        } catch (_: Exception) { file.size }
    }

    private suspend fun connectToHost(hostIp: String): Socket {
        val maxAttempts = 3
        var lastException: Exception? = null
        for (attempt in 1..maxAttempts) {
            try {
                val s = Socket()
                s.sendBufferSize = BUFFER_SIZE
                s.tcpNoDelay     = true
                boundNetwork?.bindSocket(s)
                s.connect(InetSocketAddress(hostIp, SERVER_PORT), 6000)
                return s
            } catch (e: Exception) {
                lastException = e
                if (attempt < maxAttempts) {
                    withContext(Dispatchers.Main) { updateStatus("Attempt $attempt failed — retrying…") }
                    delay(2000)
                }
            }
        }
        throw lastException ?: IOException("Could not connect after $maxAttempts attempts")
    }

    // ── UI Helpers ────────────────────────────────────────────────────────────

    private fun updateStatus(msg: String) { binding.tvStatus.text = msg }

    private fun updateConnectionUI(connected: Boolean) {
        binding.btnDisconnect.visibility = if (connected) View.VISIBLE else View.GONE
        binding.btnSendFile.isEnabled    = connected && selectedFiles.isNotEmpty()
        if (!connected) {
            connectedDeviceInfo = null; isHotspotMode = false; boundNetwork = null
        }
    }

    private fun showProgressUI(
        show: Boolean, fileName: String, fileSize: Long,
        fileIndex: Int = 1, fileCount: Int = 1
    ) {
        binding.cardProgress.visibility      = if (show) View.VISIBLE else View.GONE
        binding.btnCancelTransfer.visibility = if (show) View.VISIBLE else View.GONE
        binding.btnCancelTransfer.isEnabled  = show

        if (show) {
            currentTransferFileName = fileName
            binding.tvProgressFile.text       = fileName
            binding.tvProgressSize.text       = Utils.formatSize(fileSize)
            binding.progressTransfer.progress = 0
            binding.tvProgressPercent.text    = "0%"
            binding.tvProgressSpeed.text      = ""
            if (fileCount > 1) {
                binding.tvProgressFileCount.text       = "File $fileIndex / $fileCount"
                binding.tvProgressFileCount.visibility = View.VISIBLE
            } else {
                binding.tvProgressFileCount.visibility = View.GONE
            }
        }
    }

    /**
     * BUG-15 FIX: [etaSecs] is now calculated and appended to the speed line.
     * No layout change required — speed and ETA share [tvProgressSpeed].
     */
    private fun updateProgress(
        percent: Int, transferred: Long, total: Long,
        speedMBps: Double, etaSecs: Long = -1
    ) {
        binding.progressTransfer.progress  = percent
        binding.tvProgressPercent.text     = "$percent%"
        binding.tvProgressTransferred.text =
            "${Utils.formatSize(transferred)} / ${Utils.formatSize(total)}"

        val speedStr = "${String.format("%.1f", speedMBps)} MB/s"
        val etaStr   = if (etaSecs >= 0) " · ETA ${Utils.formatDuration(etaSecs)}" else ""
        binding.tvProgressSpeed.text = "$speedStr$etaStr"

        // Throttled foreground-notification update (~1 s cadence).
        val now = System.currentTimeMillis()
        if (now - lastNotifUpdate >= 1000) {
            lastNotifUpdate = now
            TransferForegroundService.updateProgress(this, currentTransferFileName, percent)
        }
    }

    private fun getFileInfo(uri: Uri): Pair<String, Long> {
        if (uri.scheme == "file") {
            val f = File(uri.path!!); return Pair(f.name, f.length())
        }
        var name = "unknown_file"; var size = 0L
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val ni = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val si = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (ni >= 0) name = cursor.getString(ni) ?: name
                if (si >= 0) size = cursor.getLong(si)
            }
        }
        return Pair(name, size)
    }

    /** Must be called inside [fileNameLock] when used from concurrent transfers. */
    private fun getUniqueFileName(dir: File, name: String): String {
        var result = name; var counter = 1
        while (File(dir, result).exists()) {
            val dot = name.lastIndexOf('.')
            result  = if (dot > 0)
                "${name.substring(0, dot)}($counter)${name.substring(dot)}"
            else "$name($counter)"
            counter++
        }
        return result
    }

    private fun hasLocationPerm(): Boolean {
        val hasLocation = ActivityCompat.checkSelfPermission(
            this, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        val hasNearby = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ActivityCompat.checkSelfPermission(
                this, Manifest.permission.NEARBY_WIFI_DEVICES
            ) == PackageManager.PERMISSION_GRANTED
        } else true
        return hasLocation && hasNearby
    }

    private fun showToast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
