# ─── QuickShare ProGuard Rules ────────────────────────────────────────────────

# Keep Activities, Services, BroadcastReceivers (Android instantiates by name)
-keep public class com.quickshare.MainActivity
-keep public class com.quickshare.HistoryActivity
-keep public class com.quickshare.ReceiveActivity
-keep public class com.quickshare.WiFiDirectBroadcastReceiver
# BUG-20 FIX: TransferForegroundService was missing from ProGuard keep rules.
-keep public class com.quickshare.TransferForegroundService

# Keep data classes used with JSON serialization
-keepclassmembers class com.quickshare.TransferRecord { *; }
-keepclassmembers class com.quickshare.SelectedFile { *; }

# Keep ViewBinding (generated classes referenced by name at runtime)
-keep class com.quickshare.databinding.** { *; }

# ─── ZXing ────────────────────────────────────────────────────────────────────
-keep class com.google.zxing.** { *; }
-keep class com.journeyapps.barcodescanner.** { *; }

# ─── AndroidX / Kotlin ────────────────────────────────────────────────────────
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}
-keepclassmembernames class kotlinx.** {
    volatile <fields>;
}

# Keep Parcelable creators
-keepclassmembers class * implements android.os.Parcelable {
    public static final ** CREATOR;
}

# Keep enum values
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}

# Keep R classes
-keepclassmembers class **.R$* {
    public static <fields>;
}

# Remove logging in release
-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
    public static *** i(...);
    public static *** w(...);
    public static *** e(...);
}
