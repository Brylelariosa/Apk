VoxelGame GPU Fix v2

Changes:
- Prevents clusters becoming READY when GPU allocation fails
- Invalid GPU meshes reset to EMPTY state
- Skips rendering invalid offsets
- Fixes permanent invisible chunk holes at higher render distances

This version removes the broken LOGE allocator patch
that caused compilation failure.
