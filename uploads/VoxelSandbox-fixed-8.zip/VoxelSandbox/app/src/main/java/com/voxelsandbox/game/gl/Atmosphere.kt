package com.voxelsandbox.game.gl

import kotlin.math.sqrt

/**
 * The fixed look of the sky, shared by every pass that has to agree about it: the sky
 * gradient itself, the distance fog (distant terrain dissolves into the horizon colour),
 * the sun glint on the water and the shading of distant slopes.
 */
object Atmosphere {
    // Sky colour at the horizon. Also the fog colour, so terrain fades seamlessly into it.
    const val HORIZON_R = 0.66f
    const val HORIZON_G = 0.79f
    const val HORIZON_B = 0.93f

    // Sky colour straight overhead.
    const val ZENITH_R = 0.27f
    const val ZENITH_G = 0.48f
    const val ZENITH_B = 0.85f

    // Fog colour while the camera is inside a water block.
    const val UNDERWATER_R = 0.16f
    const val UNDERWATER_G = 0.36f
    const val UNDERWATER_B = 0.70f

    /** Unit vector pointing at the sun (about 30 degrees above the horizon). */
    val SUN: FloatArray = normalized(0.55f, 0.50f, -0.67f)

    private fun normalized(x: Float, y: Float, z: Float): FloatArray {
        val len = sqrt(x * x + y * y + z * z)
        return floatArrayOf(x / len, y / len, z / len)
    }
}
