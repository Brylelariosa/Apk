package com.voxelsandbox.game.player

import com.voxelsandbox.game.world.BlockType
import com.voxelsandbox.game.world.World
import kotlin.math.abs
import kotlin.math.floor

data class RaycastHit(
    val blockX: Int, val blockY: Int, val blockZ: Int,
    val faceX: Int, val faceY: Int, val faceZ: Int
)

/**
 * Small-step incremental raymarch rather than a grid-DDA traversal: this only runs
 * once per frame (crosshair targeting) over a short 6-block reach, so the extra
 * steps are free in practice, and a straight raymarch is much easier to verify
 * correct by inspection than a DDA implementation's edge cases — worth the trade
 * given there's no compiler/test loop to catch a subtle mistake.
 */
object Raycaster {
    private const val STEP = 0.05f

    /** Selection box of a plant inside its cell (local 0..1 coordinates). A tuft or flower
     *  is only hit while the ray is inside this box, so the crosshair can pass through the
     *  empty rest of the cell. A flat plant (lily pad) is a thin slab at the cell bottom. */
    const val PLANT_MIN = 0.15f
    const val PLANT_MAX = 0.85f
    const val PLANT_HEIGHT = 0.8f
    const val FLAT_HEIGHT = 0.2f

    private fun insidePlantBox(block: BlockType, lx: Float, ly: Float, lz: Float): Boolean {
        if (block.flat) return ly < FLAT_HEIGHT
        return lx > PLANT_MIN && lx < PLANT_MAX && lz > PLANT_MIN && lz < PLANT_MAX && ly < PLANT_HEIGHT
    }

    fun cast(
        world: World,
        originX: Float, originY: Float, originZ: Float,
        dirX: Float, dirY: Float, dirZ: Float,
        maxDist: Float
    ): RaycastHit? {
        var t = 0f
        var lastBx = floor(originX).toInt()
        var lastBy = floor(originY).toInt()
        var lastBz = floor(originZ).toInt()

        while (t < maxDist) {
            val x = originX + dirX * t
            val y = originY + dirY * t
            val z = originZ + dirZ * t
            val bx = floor(x).toInt()
            val by = floor(y).toInt()
            val bz = floor(z).toInt()

            val block = world.getBlock(bx, by, bz)
            if (block != BlockType.AIR && block != BlockType.WATER &&
                (!block.plant || insidePlantBox(block, x - bx, y - by, z - bz))
            ) {
                val dx = lastBx - bx
                val dy = lastBy - by
                val dz = lastBz - bz
                // Keep only the dominant axis as the "entered face" — at grazing
                // corners more than one axis can differ in a single step; picking
                // the largest keeps the result a well-defined face of the block.
                val face = when {
                    dx != 0 && abs(dx) >= abs(dy) && abs(dx) >= abs(dz) -> Triple(dx, 0, 0)
                    dy != 0 && abs(dy) >= abs(dz) -> Triple(0, dy, 0)
                    dz != 0 -> Triple(0, 0, dz)
                    else -> Triple(0, 0, 0)
                }
                return RaycastHit(bx, by, bz, face.first, face.second, face.third)
            }
            lastBx = bx; lastBy = by; lastBz = bz
            t += STEP
        }
        return null
    }
}
