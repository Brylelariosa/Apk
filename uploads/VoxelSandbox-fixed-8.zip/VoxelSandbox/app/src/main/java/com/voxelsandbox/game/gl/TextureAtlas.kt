package com.voxelsandbox.game.gl

import android.opengl.GLES30
import com.voxelsandbox.game.world.AtlasCell
import java.nio.ByteBuffer
import java.nio.ByteOrder

data class UVRect(val u0: Float, val v0: Float, val u1: Float, val v1: Float)

/**
 * Packs the procedural block textures ([BlockTextures]) into one atlas and uploads it.
 * Every block texture is generated at startup rather than shipped as an image asset, so
 * the project stays asset-free. The atlas is plain ARGB int arrays: no Bitmap/Canvas,
 * which means it can be built on any thread, needs no GL context, and keeps *straight*
 * (non-premultiplied) alpha. That matters for the leaf tiles, whose transparent holes
 * would otherwise darken the colour of their neighbours when mip-mapped.
 *
 * Every tile sits in a larger "pitch" cell with a [PAD_PX] gutter all around it. The
 * gutter is filled with the tile's own pattern (wrapped for seamless ground tiles,
 * edge-extended for the rest), so anisotropic / mip filtering that reaches past a tile
 * edge samples more of the same block instead of a neighbouring tile of the atlas. That
 * is what used to draw thin dark/odd lines along the edges of sand, grass and other
 * blocks seen at a low angle. The mip chain is built by hand (alpha-weighted box
 * filter). [uploadToGL] needs the GL context and is called from the renderer on the GL
 * thread.
 *
 * Image row 0 is the TOP of a tile and maps to the smallest v; the mesher relies on that
 * to put grass fringes / bark streaks the right way up on side faces.
 */
class TextureAtlas {
    companion object {
        const val GRID = 8

        /** Content size of one tile. */
        const val CELL_PX = 32

        /** Gutter around every tile (texels at mip level 0). */
        const val PAD_PX = 16

        /** Distance between two tiles in the atlas: content plus a gutter on each side. */
        const val PITCH_PX = CELL_PX + 2 * PAD_PX
        const val SIZE_PX = GRID * PITCH_PX

        /** 512, 256, 128, 64, 32, 16 px. */
        const val MIP_LEVELS = 6

        const val WATER_CELL = AtlasCell.WATER

        /** A plain white cell, reused (tinted via the shader's fog/shade/alpha
         *  uniforms) for clouds and the highlight so no extra texture is needed. */
        const val WHITE_CELL = AtlasCell.WHITE

        /** A palette the distant-terrain mesh samples by U (colour column) and V (colour
         *  row, see [rampV]). Row [RAMP_ROW_SURFACE] holds ground colours, row
         *  [RAMP_ROW_FOLIAGE] holds tree colours. The columns are grouped by type (first
         *  column of each group below, two to five shades light -> dark) and are derived
         *  from the average colour of the matching block texture. */
        const val RAMP_CELL = AtlasCell.RAMP
        const val RAMP_ROW_SURFACE = 0
        const val RAMP_ROW_FOLIAGE = 1
        const val RAMP_SAND = 0f
        const val RAMP_GRASS = 3f
        const val RAMP_DIRT = 8f
        const val RAMP_STONE = 11f
        const val RAMP_DRY = 14f
        const val RAMP_DESERT = 17f
        const val RAMP_SNOW = 20f
        const val RAMP_GRAVEL = 23f

        // columns of the foliage row
        const val RAMP_OAK_LEAF = 0f
        const val RAMP_BIRCH_LEAF = 3f
        const val RAMP_SPRUCE_LEAF = 6f
        const val RAMP_OAK_WOOD = 9f
        const val RAMP_BIRCH_WOOD = 11f
        const val RAMP_SPRUCE_WOOD = 13f

        /** Keeps sampling just inside a tile (in texels). */
        private const val UV_INSET_PX = 0.15f

        private val EMPTY_UV = UVRect(0f, 0f, 0f, 0f)

        /** Every in-grid cell's rect, computed once: uvFor runs per emitted mesh face on
         *  the mesh-worker threads and per particle per frame, and a UVRect depends on
         *  nothing but the cell index. */
        private val UV_TABLE: Array<UVRect> = Array(GRID * GRID) { computeUv(it) }

        private fun computeUv(cell: Int): UVRect {
            val cx = cell % GRID
            val cy = cell / GRID
            val ox = cx * PITCH_PX + PAD_PX
            val oy = cy * PITCH_PX + PAD_PX
            val u0 = (ox + UV_INSET_PX) / SIZE_PX
            val v0 = (oy + UV_INSET_PX) / SIZE_PX
            val u1 = (ox + CELL_PX - UV_INSET_PX) / SIZE_PX
            val v1 = (oy + CELL_PX - UV_INSET_PX) / SIZE_PX
            return UVRect(u0, v0, u1, v1)
        }

        /** U coordinate at the centre of ramp column [t] (0..CELL_PX-1, fractional allowed). */
        fun rampU(t: Float): Float {
            val max = (CELL_PX - 1).toFloat()
            val c = if (t < 0f) 0f else if (t > max) max else t
            val cx = RAMP_CELL % GRID
            return (cx * PITCH_PX + PAD_PX + c + 0.5f) / SIZE_PX
        }

        /** V coordinate inside the ramp cell for colour row [row] (RAMP_ROW_*); every row
         *  owns 8 texel rows of the cell. */
        fun rampV(row: Int = 0): Float {
            val cy = RAMP_CELL / GRID
            return (cy * PITCH_PX + PAD_PX + row * 8 + 4f) / SIZE_PX
        }

        // ---- atlas assembly -----------------------------------------------------------

        private fun rgb(r: Int, g: Int, b: Int): Int = (255 shl 24) or (r shl 16) or (g shl 8) or b

        /** Copies [pixels] (a CELL_PX x CELL_PX tile) into grid cell [cell] of [atlas] and
         *  fills the gutter around it: with the tile's own pattern repeated when [wrap]
         *  (tiles that are seamless by construction), otherwise with its edge texels. */
        private fun blit(atlas: IntArray, cell: Int, pixels: IntArray, wrap: Boolean = false) {
            val ox = (cell % GRID) * PITCH_PX
            val oy = (cell / GRID) * PITCH_PX
            for (y in 0 until PITCH_PX) {
                val ty = y - PAD_PX
                val sy = if (wrap) Math.floorMod(ty, CELL_PX) else if (ty < 0) 0 else if (ty >= CELL_PX) CELL_PX - 1 else ty
                val rowBase = sy * CELL_PX
                val dstBase = (oy + y) * SIZE_PX + ox
                for (x in 0 until PITCH_PX) {
                    val tx = x - PAD_PX
                    val sx = if (wrap) Math.floorMod(tx, CELL_PX) else if (tx < 0) 0 else if (tx >= CELL_PX) CELL_PX - 1 else tx
                    atlas[dstBase + x] = pixels[rowBase + sx]
                }
            }
        }

        /**
         * The distant-terrain colour ramp. Each group is the average colour of the real block
         * texture it stands in for, scaled light -> dark, so far-away terrain matches the
         * voxel terrain it fades into.
         */
        private fun ramp(
            grass: Int, dirt: Int, stone: Int, sand: Int, dryGrass: Int, snow: Int, gravel: Int
        ): IntArray {
            val out = IntArray(CELL_PX)
            java.util.Arrays.fill(out, BlockTextures.scaleColor(stone, 0.8f))
            fun put(first: Float, color: Int, factors: FloatArray) {
                for (i in factors.indices) out[first.toInt() + i] = BlockTextures.scaleColor(color, factors[i])
            }
            put(RAMP_SAND, sand, floatArrayOf(1.06f, 0.99f, 0.90f))
            put(RAMP_GRASS, grass, floatArrayOf(1.10f, 1.03f, 0.96f, 0.86f, 0.72f))
            put(RAMP_DIRT, dirt, floatArrayOf(1.10f, 1.0f, 0.86f))
            put(RAMP_STONE, stone, floatArrayOf(1.12f, 1.0f, 0.86f))
            put(RAMP_DRY, dryGrass, floatArrayOf(1.10f, 1.0f, 0.88f))
            // Desert ground is the same sand, nudged warmer so it reads as a region of its own.
            val warmSand = rgb(
                (((sand shr 16) and 0xFF) * 1.03f).toInt().coerceAtMost(255),
                (((sand shr 8) and 0xFF) * 0.97f).toInt(),
                ((sand and 0xFF) * 0.86f).toInt()
            )
            put(RAMP_DESERT, warmSand, floatArrayOf(1.04f, 0.97f, 0.90f))
            put(RAMP_SNOW, snow, floatArrayOf(1.0f, 0.95f, 0.88f))
            put(RAMP_GRAVEL, gravel, floatArrayOf(1.10f, 1.0f, 0.88f))
            return out
        }

        /** Tree colours for the distant-terrain mesh (leaf and wood averages, light -> dark). */
        private fun foliageRamp(
            oakLeaf: Int, birchLeaf: Int, spruceLeaf: Int, oakWood: Int, birchWood: Int, spruceWood: Int
        ): IntArray {
            val out = IntArray(CELL_PX)
            java.util.Arrays.fill(out, BlockTextures.scaleColor(oakLeaf, 0.8f))
            fun put(first: Float, color: Int, factors: FloatArray) {
                for (i in factors.indices) out[first.toInt() + i] = BlockTextures.scaleColor(color, factors[i])
            }
            put(RAMP_OAK_LEAF, oakLeaf, floatArrayOf(1.0f, 0.88f, 0.74f))
            put(RAMP_BIRCH_LEAF, birchLeaf, floatArrayOf(1.0f, 0.88f, 0.74f))
            put(RAMP_SPRUCE_LEAF, spruceLeaf, floatArrayOf(1.1f, 0.95f, 0.8f))
            put(RAMP_OAK_WOOD, oakWood, floatArrayOf(1.0f, 0.8f))
            put(RAMP_BIRCH_WOOD, birchWood, floatArrayOf(1.0f, 0.85f))
            put(RAMP_SPRUCE_WOOD, spruceWood, floatArrayOf(1.0f, 0.8f))
            return out
        }

        private fun buildBase(): IntArray {
            val atlas = IntArray(SIZE_PX * SIZE_PX)
            // Unused cells are loud magenta so a wrong cell index is obvious, never silently dark.
            java.util.Arrays.fill(atlas, rgb(255, 0, 255))

            val grassTop = BlockTextures.grassTop()
            val dirt = BlockTextures.dirt()
            val stone = BlockTextures.stone()
            val sand = BlockTextures.sand()
            val dryGrassTop = BlockTextures.dryGrassTop()
            val snow = BlockTextures.snow()
            val gravel = BlockTextures.gravel()

            val oakBark = BlockTextures.oakBark()
            val birchBark = BlockTextures.birchBark()
            val spruceBark = BlockTextures.spruceBark()
            val oakLeaves = BlockTextures.oakLeaves()
            val birchLeaves = BlockTextures.birchLeaves()
            val spruceLeaves = BlockTextures.spruceLeaves()

            // Tiles that are periodic by construction wrap into their gutter; the rest extend their edge.
            blit(atlas, AtlasCell.GRASS_TOP, grassTop, true)
            blit(atlas, AtlasCell.GRASS_SIDE, BlockTextures.grassSide())
            blit(atlas, AtlasCell.DIRT, dirt, true)
            blit(atlas, AtlasCell.STONE, stone, true)
            blit(atlas, AtlasCell.SAND, sand, true)
            blit(atlas, AtlasCell.OAK_BARK, oakBark, true)
            blit(atlas, AtlasCell.OAK_RINGS, BlockTextures.oakRings())
            blit(atlas, AtlasCell.OAK_LEAVES, oakLeaves, true)
            blit(atlas, AtlasCell.COAL_ORE, BlockTextures.coalOre())
            blit(atlas, AtlasCell.WATER, BlockTextures.water(), true)
            blit(atlas, AtlasCell.WHITE, BlockTextures.white(), true)
            blit(atlas, AtlasCell.BIRCH_BARK, birchBark, true)
            blit(atlas, AtlasCell.BIRCH_LEAVES, birchLeaves, true)
            blit(atlas, AtlasCell.SPRUCE_LEAVES, spruceLeaves, true)
            blit(atlas, AtlasCell.SPRUCE_BARK, spruceBark, true)
            blit(atlas, AtlasCell.BIRCH_RINGS, BlockTextures.birchRings())
            blit(atlas, AtlasCell.SPRUCE_RINGS, BlockTextures.spruceRings())
            blit(atlas, AtlasCell.SNOW, snow, true)
            blit(atlas, AtlasCell.SNOW_SIDE, BlockTextures.snowSide())
            blit(atlas, AtlasCell.GRAVEL, gravel, true)
            blit(atlas, AtlasCell.SANDSTONE_SIDE, BlockTextures.sandstoneSide())
            blit(atlas, AtlasCell.SANDSTONE_TOP, BlockTextures.sandstoneTop(), true)
            blit(atlas, AtlasCell.DRY_GRASS_TOP, dryGrassTop, true)
            blit(atlas, AtlasCell.DRY_GRASS_SIDE, BlockTextures.dryGrassSide())
            blit(atlas, AtlasCell.TALL_GRASS, BlockTextures.tallGrass())
            blit(atlas, AtlasCell.POPPY, BlockTextures.poppy())
            blit(atlas, AtlasCell.DANDELION, BlockTextures.dandelion())
            blit(atlas, AtlasCell.DEAD_BUSH, BlockTextures.deadBush())
            blit(atlas, AtlasCell.CACTUS_SIDE, BlockTextures.cactusSide())
            blit(atlas, AtlasCell.CACTUS_TOP, BlockTextures.cactusTop())
            blit(atlas, AtlasCell.LILY_PAD, BlockTextures.lilyPad())

            val rampColors = ramp(
                BlockTextures.averageColor(grassTop),
                BlockTextures.averageColor(dirt),
                BlockTextures.averageColor(stone),
                BlockTextures.averageColor(sand),
                BlockTextures.averageColor(dryGrassTop),
                BlockTextures.averageColor(snow),
                BlockTextures.averageColor(gravel)
            )
            val foliageColors = foliageRamp(
                BlockTextures.averageColor(oakLeaves),
                BlockTextures.averageColor(birchLeaves),
                BlockTextures.averageColor(spruceLeaves),
                BlockTextures.averageColor(oakBark),
                BlockTextures.averageColor(birchBark),
                BlockTextures.averageColor(spruceBark)
            )
            // Rows 0-7 of the cell are the surface palette, rows 8-15 the foliage palette
            // (see rampV); the rest repeats the surface palette.
            val rampTile = IntArray(CELL_PX * CELL_PX)
            for (y in 0 until CELL_PX) {
                val src = if (y >= 8 && y < 16) foliageColors else rampColors
                System.arraycopy(src, 0, rampTile, y * CELL_PX, CELL_PX)
            }
            blit(atlas, RAMP_CELL, rampTile)
            return atlas
        }

        /** Alpha-weighted 2x2 box filter: transparent texels (leaf holes) don't drag the
         *  colour of the surviving texels toward black, while alpha itself is a plain
         *  average so distant foliage keeps its coverage. */
        private fun halve(src: IntArray, srcSize: Int): IntArray {
            val s = srcSize / 2
            val out = IntArray(s * s)
            for (y in 0 until s) {
                for (x in 0 until s) {
                    var rs = 0
                    var gs = 0
                    var bs = 0
                    var asum = 0
                    for (dy in 0 until 2) {
                        for (dx in 0 until 2) {
                            val p = src[(y * 2 + dy) * srcSize + (x * 2 + dx)]
                            val a = p ushr 24
                            rs += ((p shr 16) and 0xFF) * a
                            gs += ((p shr 8) and 0xFF) * a
                            bs += (p and 0xFF) * a
                            asum += a
                        }
                    }
                    out[y * s + x] = if (asum == 0) {
                        0
                    } else {
                        ((asum / 4) shl 24) or ((rs / asum) shl 16) or ((gs / asum) shl 8) or (bs / asum)
                    }
                }
            }
            return out
        }

        // GL_EXT_texture_filter_anisotropic (not in the core GLES30 bindings)
        private const val GL_TEXTURE_MAX_ANISOTROPY_EXT = 0x84FE
        private const val GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT = 0x84FF
        private const val ANISOTROPY = 4f
    }

    private val mips: Array<IntArray> = buildMips()
    private var textureId: Int = 0

    private fun buildMips(): Array<IntArray> {
        val levels = ArrayList<IntArray>(MIP_LEVELS)
        var cur = buildBase()
        var size = SIZE_PX
        levels.add(cur)
        for (i in 1 until MIP_LEVELS) {
            cur = halve(cur, size)
            size /= 2
            levels.add(cur)
        }
        return levels.toTypedArray()
    }

    fun uvFor(cell: Int): UVRect {
        if (cell < 0) return EMPTY_UV
        // Out-of-grid cells (never used by any block) keep the original computed
        // result rather than indexing past the table.
        return if (cell < UV_TABLE.size) UV_TABLE[cell] else computeUv(cell)
    }

    fun uploadToGL() {
        val ids = IntArray(1)
        GLES30.glGenTextures(1, ids, 0)
        textureId = ids[0]
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textureId)
        // Crisp pixels up close, smooth blend between mip levels in the distance (this is
        // what removes the shimmering/noise on far terrain).
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_NEAREST_MIPMAP_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_NEAREST)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_BASE_LEVEL, 0)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAX_LEVEL, MIP_LEVELS - 1)
        enableAnisotropy()

        var size = SIZE_PX
        for (level in 0 until MIP_LEVELS) {
            val pixels = mips[level]
            val buf = ByteBuffer.allocateDirect(size * size * 4).order(ByteOrder.nativeOrder())
            for (p in pixels) {
                buf.put(((p shr 16) and 0xFF).toByte())
                buf.put(((p shr 8) and 0xFF).toByte())
                buf.put((p and 0xFF).toByte())
                buf.put((p ushr 24).toByte())
            }
            buf.position(0)
            GLES30.glTexImage2D(
                GLES30.GL_TEXTURE_2D, level, GLES30.GL_RGBA, size, size, 0,
                GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, buf
            )
            size /= 2
        }
    }

    /** Sharper ground at grazing angles where the driver offers anisotropic filtering;
     *  silently skipped everywhere else. */
    private fun enableAnisotropy() {
        try {
            val extensions = GLES30.glGetString(GLES30.GL_EXTENSIONS) ?: return
            if (!extensions.contains("GL_EXT_texture_filter_anisotropic")) return
            val limit = FloatArray(1)
            GLES30.glGetFloatv(GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT, limit, 0)
            if (limit[0] > 1f) {
                GLES30.glTexParameterf(GLES30.GL_TEXTURE_2D, GL_TEXTURE_MAX_ANISOTROPY_EXT, minOf(ANISOTROPY, limit[0]))
            }
        } catch (t: Throwable) {
            // purely cosmetic; ignore
        }
    }

    fun bind(unit: Int = 0) {
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0 + unit)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textureId)
    }
}
