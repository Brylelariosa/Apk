package com.voxelsandbox.game.player

import com.voxelsandbox.game.util.AABB
import com.voxelsandbox.game.util.Vec3
import com.voxelsandbox.game.world.World
import com.voxelsandbox.game.world.WorldConfig
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Axis-separated AABB-vs-voxel-grid collision: X, then Z, then Y are resolved
 * independently against solid blocks. This is simpler and much easier to verify
 * correct by inspection than full swept-AABB continuous collision, and is entirely
 * adequate at the movement speeds this game uses.
 */
class PhysicsController(private val world: World) {
    companion object {
        // Snappy, Minecraft-like jump: ~1.25 blocks high, ~0.55 s in the air.
        const val GRAVITY = 32f
        const val TERMINAL_VELOCITY = -55f
        const val JUMP_SPEED = 8.9f
        const val MOVE_SPEED = 4.3f
    }

    /** worldMoveX/worldMoveZ are already-rotated world-space direction components
     *  (see GameEngine, which turns joystick forward/strafe + yaw into these).
     *  [autoJumpEnabled] mirrors the Auto Jump setting (see GameSettings): when on,
     *  walking into a climbable 1-block step triggers the same jump impulse as
     *  pressing the jump button, instead of just stopping at the wall. */
    fun step(player: Player, worldMoveX: Float, worldMoveZ: Float, wantsJump: Boolean, autoJumpEnabled: Boolean, dt: Float) {
        var box = boxAt(player.position)

        val effectiveJump = wantsJump ||
            (autoJumpEnabled && player.onGround && shouldAutoJump(box, worldMoveX, worldMoveZ))

        player.velocity.y = max(player.velocity.y - GRAVITY * dt, TERMINAL_VELOCITY)
        if (effectiveJump && player.onGround) {
            player.velocity.y = JUMP_SPEED
        }

        val dx = resolveHorizontal(box, worldMoveX * MOVE_SPEED * dt, isX = true)
        box = box.offset(dx, 0f, 0f)
        val dz = resolveHorizontal(box, worldMoveZ * MOVE_SPEED * dt, isX = false)
        box = box.offset(0f, 0f, dz)

        val desiredDy = player.velocity.y * dt
        val dy = resolveVertical(box, desiredDy)

        if (desiredDy < 0f && dy > desiredDy) {
            player.onGround = true
            player.velocity.y = 0f
        } else if (desiredDy > 0f && dy < desiredDy) {
            player.velocity.y = 0f
            player.onGround = false
        } else {
            player.onGround = false
        }

        player.position.add(dx, dy, dz)

        // Fell into the void (e.g. an edge case in generation): return to spawn
        // height rather than falling forever.
        if (player.position.y < com.voxelsandbox.game.world.WorldConfig.VOID_Y) {
            player.position.set(player.position.x, WorldConfig.WORLD_HEIGHT + 8f, player.position.z)
            player.velocity.set(0f, 0f, 0f)
        }
    }

    /** Creative flight: [vx]/[vy]/[vz] are velocities in blocks per second set straight from
     *  the controls (no gravity, no momentum). Terrain still blocks the player, except when
     *  the player is already inside solid blocks (flown into a chunk that was not loaded
     *  yet), where collision is skipped so they can never get stuck. */
    fun flyStep(player: Player, vx: Float, vy: Float, vz: Float, dt: Float) {
        player.velocity.set(0f, 0f, 0f)
        player.onGround = false
        val inside = world.isSolid(
            floor(player.position.x).toInt(),
            floor(player.position.y + 0.9f).toInt(),
            floor(player.position.z).toInt()
        )
        if (inside) {
            player.position.add(vx * dt, vy * dt, vz * dt)
            return
        }
        var box = boxAt(player.position)
        val dx = resolveHorizontal(box, vx * dt, isX = true)
        box = box.offset(dx, 0f, 0f)
        val dz = resolveHorizontal(box, vz * dt, isX = false)
        box = box.offset(0f, 0f, dz)
        val dy = resolveVertical(box, vy * dt)
        player.position.add(dx, dy, dz)
        if (player.position.y < WorldConfig.VOID_Y) {
            player.position.set(player.position.x, WorldConfig.WORLD_HEIGHT + 8f, player.position.z)
        }
    }

    private fun boxAt(pos: Vec3): AABB {
        val hw = Player.WIDTH / 2f
        return AABB(pos.x - hw, pos.y, pos.z - hw, pos.x + hw, pos.y + Player.HEIGHT, pos.z + hw)
    }

    /** Auto Jump: probes one short step ahead of the player's leading edge, at foot
     *  height, in the direction they're currently moving. If that cell is solid but
     *  the cell directly above it is clear, it's a climbable 1-block step, so this
     *  returns true to trigger a normal jump impulse (see step()) — the same feel as
     *  a player manually bunny-hopping over a curb. Taller obstacles still just
     *  block movement, same as with Auto Jump off, since only one cell up is checked. */
    private fun shouldAutoJump(box: AABB, worldMoveX: Float, worldMoveZ: Float): Boolean {
        val len = hypot(worldMoveX.toDouble(), worldMoveZ.toDouble()).toFloat()
        if (len < 0.001f) return false
        val dirX = worldMoveX / len
        val dirZ = worldMoveZ / len
        val hw = Player.WIDTH / 2f
        val probeX = (box.minX + box.maxX) / 2f + dirX * (hw + 0.15f)
        val probeZ = (box.minZ + box.maxZ) / 2f + dirZ * (hw + 0.15f)
        val footBlockY = floor(box.minY + 0.05f).toInt()
        val blockX = floor(probeX).toInt()
        val blockZ = floor(probeZ).toInt()
        if (!world.isSolid(blockX, footBlockY, blockZ)) return false
        return !world.isSolid(blockX, footBlockY + 1, blockZ)
    }

    private fun resolveHorizontal(box: AABB, delta: Float, isX: Boolean): Float {
        if (delta == 0f) return 0f
        var d = delta
        val moved = if (isX) box.offset(d, 0f, 0f) else box.offset(0f, 0f, d)

        val minX = floor(min(box.minX, moved.minX)).toInt()
        val maxX = floor(max(box.maxX, moved.maxX) - 0.001f).toInt()
        val minY = floor(box.minY + 0.001f).toInt()
        val maxY = floor(box.maxY - 0.001f).toInt()
        val minZ = floor(min(box.minZ, moved.minZ)).toInt()
        val maxZ = floor(max(box.maxZ, moved.maxZ) - 0.001f).toInt()

        for (bx in minX..maxX) for (by in minY..maxY) for (bz in minZ..maxZ) {
            if (!world.isSolid(bx, by, bz)) continue
            val bb = AABB(bx.toFloat(), by.toFloat(), bz.toFloat(), bx + 1f, by + 1f, bz + 1f)
            d = if (isX) {
                when {
                    d > 0f -> min(d, bb.minX - box.maxX)
                    d < 0f -> max(d, bb.maxX - box.minX)
                    else -> d
                }
            } else {
                when {
                    d > 0f -> min(d, bb.minZ - box.maxZ)
                    d < 0f -> max(d, bb.maxZ - box.minZ)
                    else -> d
                }
            }
        }
        return d
    }

    private fun resolveVertical(box: AABB, delta: Float): Float {
        if (delta == 0f) return 0f
        var d = delta
        val moved = box.offset(0f, d, 0f)

        val minX = floor(box.minX).toInt()
        val maxX = floor(box.maxX - 0.001f).toInt()
        val minY = floor(min(box.minY, moved.minY)).toInt()
        val maxY = floor(max(box.maxY, moved.maxY)).toInt()
        val minZ = floor(box.minZ).toInt()
        val maxZ = floor(box.maxZ - 0.001f).toInt()

        for (bx in minX..maxX) for (by in minY..maxY) for (bz in minZ..maxZ) {
            if (!world.isSolid(bx, by, bz)) continue
            val bb = AABB(bx.toFloat(), by.toFloat(), bz.toFloat(), bx + 1f, by + 1f, bz + 1f)
            d = if (d > 0f) min(d, bb.minY - box.maxY) else max(d, bb.maxY - box.minY)
        }
        return d
    }
}
