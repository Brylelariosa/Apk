package com.voxelsandbox.game.gl

import android.opengl.GLES30

/**
 * Draws the sky gradient and sun as one full-screen triangle, before anything else. No
 * vertex buffer is needed (the vertex shader derives the corners from gl_VertexID) and no
 * depth is read or written, so everything else simply draws on top.
 */
class SkyRenderer {
    private lateinit var program: ShaderProgram
    private var uForward = 0
    private var uRight = 0
    private var uUp = 0
    private var uTan = 0
    private var uHorizon = 0
    private var uZenith = 0
    private var uSunDir = 0

    /** Call from onSurfaceCreated (a new GL context needs fresh programs). */
    fun init() {
        program = ShaderProgram(Shaders.SKY_VERTEX, Shaders.SKY_FRAGMENT)
        uForward = program.uniform("uForward")
        uRight = program.uniform("uRight")
        uUp = program.uniform("uUp")
        uTan = program.uniform("uTan")
        uHorizon = program.uniform("uHorizon")
        uZenith = program.uniform("uZenith")
        uSunDir = program.uniform("uSunDir")
    }

    fun draw(frame: FrameState) {
        GLES30.glDisable(GLES30.GL_DEPTH_TEST)
        GLES30.glDisable(GLES30.GL_CULL_FACE)
        program.use()
        GLES30.glUniform3f(uForward, frame.forwardX, frame.forwardY, frame.forwardZ)
        GLES30.glUniform3f(uRight, frame.rightX, frame.rightY, frame.rightZ)
        GLES30.glUniform3f(uUp, frame.upX, frame.upY, frame.upZ)
        GLES30.glUniform2f(uTan, frame.tanHalfFovX, frame.tanHalfFovY)
        GLES30.glUniform3f(uHorizon, Atmosphere.HORIZON_R, Atmosphere.HORIZON_G, Atmosphere.HORIZON_B)
        GLES30.glUniform3f(uZenith, Atmosphere.ZENITH_R, Atmosphere.ZENITH_G, Atmosphere.ZENITH_B)
        GLES30.glUniform3f(uSunDir, Atmosphere.SUN[0], Atmosphere.SUN[1], Atmosphere.SUN[2])
        GLES30.glBindVertexArray(0)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
        GLES30.glEnable(GLES30.GL_DEPTH_TEST)
        GLES30.glEnable(GLES30.GL_CULL_FACE)
    }
}
