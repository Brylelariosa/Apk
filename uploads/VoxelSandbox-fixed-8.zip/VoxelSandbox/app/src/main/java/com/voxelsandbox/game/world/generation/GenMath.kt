package com.voxelsandbox.game.world.generation

/** Small shared helpers for the terrain generators (all pure, allocation free). */

/** Hermite blend: 0 below [a], 1 above [b], smooth in between. */
internal fun smoothStep(a: Double, b: Double, x: Double): Double {
    val t = ((x - a) / (b - a)).coerceIn(0.0, 1.0)
    return t * t * (3.0 - 2.0 * t)
}

/** Piecewise-linear interpolation through (xs[i], ys[i]); [xs] must be ascending.
 *  Inputs outside the table clamp to its first / last value. */
internal fun interpolate(x: Double, xs: DoubleArray, ys: DoubleArray): Double {
    if (x <= xs[0]) return ys[0]
    val last = xs.size - 1
    if (x >= xs[last]) return ys[last]
    var i = 1
    while (x > xs[i]) i++
    val t = (x - xs[i - 1]) / (xs[i] - xs[i - 1])
    return ys[i - 1] + (ys[i] - ys[i - 1]) * t
}

/** Derives an independent noise seed for feature [salt] from the world seed. */
internal fun mixSeed(seed: Long, salt: Int): Long =
    seed * 6364136223846793005L + salt.toLong() * 1442695040888963407L + 0x2545F4914F6CDD1DL
