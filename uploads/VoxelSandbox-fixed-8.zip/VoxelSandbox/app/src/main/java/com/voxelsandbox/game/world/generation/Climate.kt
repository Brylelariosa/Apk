package com.voxelsandbox.game.world.generation

import com.voxelsandbox.game.world.WorldConfig
import kotlin.math.max

/** What covers the ground at a point of dry land. Shared by the chunk generator (which
 *  turns it into blocks) and the distant-terrain builder (which turns it into a colour),
 *  so a hillside looks the same colour from far away as it does up close. */
enum class SurfaceKind { GRASS, DRY_GRASS, DESERT, BEACH, SNOW, ROCK, GRAVEL }

/** The named regions of the world. A biome is decided by the (very slow) climate fields,
 *  the smooth coastline and the altitude -- never by the local one-block bumps of the
 *  ground -- so each one is a big contiguous region instead of a patchwork. */
enum class Biome(val displayName: String) {
    DEEP_OCEAN("Deep Ocean"),
    OCEAN("Ocean"),
    LAKE("Lake / River"),
    BEACH("Beach"),
    SNOWY_SHORE("Snowy Shore"),
    PLAINS("Plains"),
    FOREST("Forest"),
    BIRCH_FOREST("Birch Forest"),
    TAIGA("Taiga"),
    SNOWY_PLAINS("Snowy Plains"),
    SNOWY_TAIGA("Snowy Taiga"),
    SAVANNA("Savanna"),
    DESERT("Desert"),
    MOUNTAINS("Mountains"),
    SNOWY_PEAKS("Snowy Peaks")
}

/**
 * Temperature, humidity and forest cover as smooth pure functions of position, plus the
 * rules that turn them (with elevation, slope and the distance to the sea) into a [Biome]
 * and a [SurfaceKind]:
 *  - cold climates are snowy (snow plains, snowy taiga) with a gravel shore -- never sand,
 *  - temperate ones are plains / forest / birch forest, cool ones taiga,
 *  - hot + dry = desert, hot + fairly dry = savanna,
 *  - high ground is mountains, with a snow line that is lower in cold regions,
 *  - only a thin band along the smooth coastline is beach (and only in warm climates).
 */
class Climate(seed: Long) {
    private val temperatureNoise = NoiseGenerator(mixSeed(seed, 11))
    private val humidityNoise = NoiseGenerator(mixSeed(seed, 12))
    private val forestNoise = NoiseGenerator(mixSeed(seed, 13))
    private val jitterNoise = NoiseGenerator(mixSeed(seed, 16))
    private val variantNoise = NoiseGenerator(mixSeed(seed, 17))

    /** Sea-level temperature in -1 (arctic) .. 1 (tropical). Slow: climate zones span
     *  a thousand blocks or more. */
    fun baseTemperature(wx: Double, wz: Double): Double =
        (temperatureNoise.fbm2D(wx * 0.0008 + 31.0, wz * 0.0008 - 17.0, 3, 0.5, 2.0) * 1.5 + 0.12).coerceIn(-1.0, 1.0)

    /** Humidity in -1 (arid) .. 1 (wet). */
    fun humidity(wx: Double, wz: Double): Double =
        (humidityNoise.fbm2D(wx * 0.0009 - 70.0, wz * 0.0009 + 44.0, 3, 0.5, 2.0) * 1.6).coerceIn(-1.0, 1.0)

    /** Forest-ness in 0..1 (0 = open ground, 1 = dense forest). Drives tree density and
     *  the darker green the distant terrain uses over forests. */
    fun forest(wx: Double, wz: Double): Double {
        val f = forestNoise.fbm2D(wx * 0.011, wz * 0.011, 2, 0.5, 2.0)
        return ((f + 0.02) / 0.5).coerceIn(0.0, 1.0)
    }

    /** Height above sea level where permanent snow starts: lower in cold regions. */
    private fun snowLine(t: Double): Double = 62.0 + 28.0 * t

    /**
     * Biome of dry land at ground height [h] with local [slope] (blocks of rise per block,
     * measured over a 2-block baseline). [coast] is the smooth base elevation above sea level
     * (see TerrainShape.coastElevation): small only along real coastlines.
     */
    fun biome(wx: Double, wz: Double, h: Double, slope: Double, coast: Double): Biome {
        val t = baseTemperature(wx, wz)
        val hum = humidity(wx, wz)
        val alt = h - SEA
        val jitter = jitterNoise.noise2D(wx * 0.05 + 5.0, wz * 0.05 - 3.0)

        if (alt >= MOUNTAIN_ALT + jitter * 4.0) {
            return if (alt >= snowLine(t) + jitter * 5.0) Biome.SNOWY_PEAKS else Biome.MOUNTAINS
        }
        if (coast < 2.4 && alt < 7.0 && slope < 1.1) {
            return if (t < COLD) Biome.SNOWY_SHORE else Biome.BEACH
        }
        if (t < COLD) return if (hum > -0.15) Biome.SNOWY_TAIGA else Biome.SNOWY_PLAINS
        if (t < COOL) return if (hum > -0.25) Biome.TAIGA else Biome.PLAINS
        val aridity = 0.9 * t - hum
        if (aridity > 0.58) return Biome.DESERT
        if (aridity > 0.30) return Biome.SAVANNA
        if (hum > 0.10) {
            val v = variantNoise.fbm2D(wx * 0.0012 + 3.0, wz * 0.0012 - 8.0, 2, 0.5, 2.0)
            return if (v > 0.10) Biome.BIRCH_FOREST else Biome.FOREST
        }
        return Biome.PLAINS
    }

    /** Biome of a water column [depth] blocks below sea level. */
    fun waterBiome(depth: Double, coast: Double): Biome {
        if (coast >= 1.0) return Biome.LAKE
        return if (depth > 14.0) Biome.DEEP_OCEAN else Biome.OCEAN
    }

    /** Ground cover of dry land in [biome] at height [h] with local [slope]. */
    fun surfaceFor(biome: Biome, wx: Double, wz: Double, h: Double, slope: Double): SurfaceKind {
        val alt = h - SEA
        val jitter = jitterNoise.noise2D(wx * 0.09 + 5.0, wz * 0.09 - 3.0)
        val kind = when (biome) {
            Biome.DESERT -> SurfaceKind.DESERT
            Biome.SAVANNA -> SurfaceKind.DRY_GRASS
            Biome.BEACH -> SurfaceKind.BEACH
            Biome.SNOWY_SHORE -> SurfaceKind.GRAVEL
            Biome.SNOWY_PLAINS, Biome.SNOWY_TAIGA, Biome.SNOWY_PEAKS -> SurfaceKind.SNOW
            Biome.MOUNTAINS -> if (alt > ROCK_ALT + jitter * 5.0) SurfaceKind.ROCK else SurfaceKind.GRASS
            else -> SurfaceKind.GRASS
        }
        if (biome == Biome.BEACH || biome == Biome.SNOWY_SHORE) return kind
        if (alt > 3.0 && slope > 1.1 + 0.25 * jitter) return SurfaceKind.ROCK // cliffs
        if (biome == Biome.SNOWY_PEAKS) return SurfaceKind.SNOW
        if (kind != SurfaceKind.SNOW && alt > 20.0 && slope > 0.75 + 0.2 * jitter) return SurfaceKind.GRAVEL // scree
        return kind
    }

    companion object {
        /** Below this sea-level temperature it is snowy; below [COOL] it is taiga. */
        const val COLD = -0.32
        const val COOL = -0.08

        /** Height above sea level where the mountain biome starts, and where it turns to bare rock. */
        const val MOUNTAIN_ALT = 46.0
        const val ROCK_ALT = 54.0

        private val SEA: Double = WorldConfig.SEA_LEVEL.toDouble()
    }
}
