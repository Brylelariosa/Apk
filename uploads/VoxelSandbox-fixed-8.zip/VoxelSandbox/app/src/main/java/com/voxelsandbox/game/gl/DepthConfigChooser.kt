package com.voxelsandbox.game.gl

import android.opengl.GLSurfaceView
import javax.microedition.khronos.egl.EGL10
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.egl.EGLDisplay

/**
 * Behaves like GLSurfaceView's stock chooser (RGB888, no alpha, ES 3.0 capable) with one
 * difference: it prefers a 24-bit depth buffer. The stock chooser takes the first match
 * with >= 16 bits, and EGL sorts "smaller depth first", so many phones silently end up
 * with a 16-bit depth buffer. That is far too coarse once geometry stretches out to
 * hundreds of blocks (distant hills and the water plane would fight each other), and 24
 * bits is available on essentially every GPU that supports ES 3.0.
 */
class DepthConfigChooser : GLSurfaceView.EGLConfigChooser {

    override fun chooseConfig(egl: EGL10, display: EGLDisplay): EGLConfig {
        val spec = intArrayOf(
            EGL10.EGL_RED_SIZE, 8,
            EGL10.EGL_GREEN_SIZE, 8,
            EGL10.EGL_BLUE_SIZE, 8,
            EGL10.EGL_ALPHA_SIZE, 0,
            EGL10.EGL_DEPTH_SIZE, 16,
            EGL10.EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT_KHR,
            EGL10.EGL_NONE
        )
        val count = IntArray(1)
        if (!egl.eglChooseConfig(display, spec, null, 0, count) || count[0] <= 0) {
            throw IllegalArgumentException("No EGL config matches the requested ES 3.0 spec")
        }
        val configs = arrayOfNulls<EGLConfig>(count[0])
        if (!egl.eglChooseConfig(display, spec, configs, count[0], count)) {
            throw IllegalArgumentException("eglChooseConfig failed")
        }

        val value = IntArray(1)
        var best: EGLConfig? = null
        var bestScore = -1
        for (i in 0 until count[0]) {
            val config = configs[i] ?: continue
            // Exactly RGB888 without alpha, like the stock chooser insists on.
            if (attrib(egl, display, config, EGL10.EGL_RED_SIZE, value) != 8) continue
            if (attrib(egl, display, config, EGL10.EGL_GREEN_SIZE, value) != 8) continue
            if (attrib(egl, display, config, EGL10.EGL_BLUE_SIZE, value) != 8) continue
            if (attrib(egl, display, config, EGL10.EGL_ALPHA_SIZE, value) != 0) continue

            val depth = attrib(egl, display, config, EGL10.EGL_DEPTH_SIZE, value)
            val stencil = attrib(egl, display, config, EGL10.EGL_STENCIL_SIZE, value)
            val score = if (depth >= 24 && stencil == 0) 3 else if (depth >= 24) 2 else 1
            if (score > bestScore) {
                best = config
                bestScore = score
            }
        }
        // Nothing exact: fall back to whatever EGL ranked first rather than failing to start.
        return best ?: configs[0] ?: throw IllegalArgumentException("No usable EGL config")
    }

    private fun attrib(egl: EGL10, display: EGLDisplay, config: EGLConfig, attribute: Int, out: IntArray): Int =
        if (egl.eglGetConfigAttrib(display, config, attribute, out)) out[0] else 0

    companion object {
        /** EGL_OPENGL_ES3_BIT_KHR: what GLSurfaceView itself requests for a version 3 context. */
        private const val EGL_OPENGL_ES3_BIT_KHR = 0x40
    }
}
