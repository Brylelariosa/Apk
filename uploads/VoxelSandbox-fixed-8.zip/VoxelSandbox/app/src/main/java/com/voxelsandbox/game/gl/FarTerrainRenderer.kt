package com.voxelsandbox.game.gl

import android.opengl.GLES30
import com.voxelsandbox.game.world.far.FarEvent
import com.voxelsandbox.game.world.far.FarTerrain
import java.util.concurrent.LinkedBlockingQueue
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt

/**
 * The GPU side of the distant terrain (see [FarTerrain] for how tiles are built): holds the
 * uploaded tile meshes and draws them, level by level, as an opaque land pass and a
 * translucent water pass. Everything here is GL-thread only.
 */
class FarTerrainRenderer {
    private class GpuTile(
        val land: ChunkGpuMesh?,
        val water: ChunkGpuMesh?,
        val level: Int,
        val x0: Float,
        val z0: Float,
        val size: Float,
        val minY: Float,
        val maxY: Float
    ) {
        fun dispose() {
            land?.dispose()
            water?.dispose()
        }
    }

    private val tiles = HashMap<Long, GpuTile>()

    private lateinit var program: ShaderProgram
    private var uViewProj = 0
    private var uTexture = 0
    private var uFogColor = 0
    private var uFogStart = 0
    private var uFogEnd = 0
    private var uClip = 0
    private var uCenter = 0
    private var uBand = 0

    // Stats for the FPS overlay.
    var drawnTiles = 0
        private set
    var totalTiles = 0
        private set
    var drawnTriangles = 0
        private set

    /** Zeroes the overlay statistics (used on frames where distant terrain is not drawn). */
    fun clearStats() {
        drawnTiles = 0
        totalTiles = 0
        drawnTriangles = 0
    }

    fun init() {
        program = ShaderProgram(Shaders.FAR_VERTEX, Shaders.FAR_FRAGMENT)
        uViewProj = program.uniform("uViewProj")
        uTexture = program.uniform("uTexture")
        uFogColor = program.uniform("uFogColor")
        uFogStart = program.uniform("uFogStart")
        uFogEnd = program.uniform("uFogEnd")
        uClip = program.uniform("uClip")
        uCenter = program.uniform("uCenter")
        uBand = program.uniform("uBand")
    }

    /** The GL context was recreated: every handle is dead, forget them (no GL calls). */
    fun invalidateForContextLoss() {
        for (tile in tiles.values) {
            tile.land?.invalidateForContextLoss()
            tile.water?.invalidateForContextLoss()
        }
        tiles.clear()
    }

    /** Applies tile adds/removals in the order the builder produced them. Removals are cheap
     *  and always processed; uploads are limited to [maxUploads] per call. */
    fun drain(events: LinkedBlockingQueue<FarEvent>, maxUploads: Int) {
        var uploads = 0
        while (uploads < maxUploads) {
            val event = events.poll() ?: break
            tiles.remove(event.key)?.dispose()
            val tile = event.tile ?: continue

            var land: ChunkGpuMesh? = null
            if (!tile.land.isEmpty()) {
                land = ChunkGpuMesh()
                land.upload(tile.land)
            }
            var water: ChunkGpuMesh? = null
            if (!tile.water.isEmpty()) {
                water = ChunkGpuMesh()
                water.upload(tile.water)
            }
            tiles[event.key] = GpuTile(land, water, tile.level, tile.x0, tile.z0, tile.size, tile.minY, tile.maxY)
            uploads++
        }
    }

    /** Opaque ground. Each level draws only inside its own ring (enforced in the shader). */
    fun drawLand(frame: FrameState, frustum: Frustum) {
        drawnTiles = 0
        drawnTriangles = 0
        totalTiles = tiles.size
        if (tiles.isEmpty()) return

        program.use()
        GLES30.glUniformMatrix4fv(uViewProj, 1, false, frame.viewProj, 0)
        GLES30.glUniform3f(uFogColor, frame.fogR, frame.fogG, frame.fogB)
        GLES30.glUniform1f(uFogStart, frame.fogStart)
        GLES30.glUniform1f(uFogEnd, frame.fogEnd)
        GLES30.glUniform1i(uTexture, 0)
        // Everything inside the cover circle is drawn by real voxel chunks: discard it so the
        // two never overlap. (The renderer passes a radius a little smaller than the proven
        // coverage, so there is no seam gap.)
        GLES30.glUniform3f(uClip, frame.coverX, frame.coverZ, frame.coverRadius * frame.coverRadius)
        GLES30.glUniform2f(uCenter, frame.eyeX, frame.eyeZ)

        for (level in 0 until FarTerrain.LEVELS) {
            val inner = FarTerrain.bandInner(level)
            val outer = FarTerrain.bandDrawOuter(level)
            // Sink amount at the inner edge: half a cell of this level, which is always
            // more than the height difference between two samplings of smooth ground.
            val sink = if (level == 0) 0f else 0.5f * FarTerrain.step(level)
            GLES30.glUniform4f(uBand, inner, outer, sink, FarTerrain.bandOverlapAtStart(level))

            for (tile in tiles.values) {
                if (tile.level != level) continue
                val land = tile.land ?: continue
                if (!isVisible(tile, frame, frustum, inner, outer)) continue
                land.draw()
                drawnTiles++
                drawnTriangles += land.triangleCount
            }
        }
    }

    /** Translucent sea / lake surfaces, to be drawn between [WaterRenderer.begin] and
     *  [WaterRenderer.end] after [drawLand]. */
    fun drawWater(frame: FrameState, frustum: Frustum, water: WaterRenderer) {
        if (tiles.isEmpty()) return
        // Water is flat, so rings can meet exactly (no overlap, and so no double blending).
        for (level in FarTerrain.LEVELS - 1 downTo 0) {
            water.useFarBand(frame, FarTerrain.bandInner(level), FarTerrain.bandOuter(level))
            for (tile in tiles.values) {
                if (tile.level != level) continue
                val mesh = tile.water ?: continue
                if (!isVisible(tile, frame, frustum, FarTerrain.bandInner(level), FarTerrain.bandOuter(level))) continue
                mesh.draw()
                drawnTriangles += mesh.triangleCount
            }
        }
    }

    /** True if some part of the tile can be on screen: inside the ring, outside the
     *  voxel-covered circle and inside the view frustum. */
    private fun isVisible(tile: GpuTile, frame: FrameState, frustum: Frustum, inner: Float, outer: Float): Boolean {
        val x1 = tile.x0 + tile.size
        val z1 = tile.z0 + tile.size

        // distance from the player to the nearest / farthest point of the tile
        val nx = if (frame.eyeX < tile.x0) tile.x0 else if (frame.eyeX > x1) x1 else frame.eyeX
        val nz = if (frame.eyeZ < tile.z0) tile.z0 else if (frame.eyeZ > z1) z1 else frame.eyeZ
        val near = sqrt((frame.eyeX - nx) * (frame.eyeX - nx) + (frame.eyeZ - nz) * (frame.eyeZ - nz))
        if (near > outer) return false
        val fx = max(abs(frame.eyeX - tile.x0), abs(frame.eyeX - x1))
        val fz = max(abs(frame.eyeZ - tile.z0), abs(frame.eyeZ - z1))
        if (sqrt(fx * fx + fz * fz) < inner) return false

        // entirely inside the circle real chunks cover?
        val cx = max(abs(frame.coverX - tile.x0), abs(frame.coverX - x1))
        val cz = max(abs(frame.coverZ - tile.z0), abs(frame.coverZ - z1))
        if (cx * cx + cz * cz < frame.coverRadius * frame.coverRadius) return false

        return frustum.isBoxVisible(tile.x0, tile.minY, tile.z0, x1, tile.maxY, z1)
    }
}
