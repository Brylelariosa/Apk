package com.voxelsandbox.game.gl

import android.opengl.GLES30
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.floor

/**
 * The cloud layer: one big flat sheet centred on the camera, textured with a blocky
 * (nearest-filtered) cloud mask that tiles every 1,536 blocks and drifts slowly with the
 * wind. Unlike the old plain translucent square, the sheet has no visible edge: clouds
 * fade out with distance (well before the sheet ends or the fog does), and only the
 * mask's cloud cells are drawn at all.
 *
 * The mask is generated once on the CPU from tiling value noise. GL-thread only.
 */
class CloudRenderer {
    private lateinit var program: ShaderProgram
    private var uViewProj = 0
    private var uCenter = 0
    private var uHalf = 0
    private var uCloudTex = 0
    private var uEye = 0
    private var uShift = 0
    private var uRadius = 0
    private var uFogColor = 0
    private var uFogStart = 0
    private var uFogEnd = 0
    private var textureId = 0

    /** Call from onSurfaceCreated (a new GL context needs a fresh program and texture). */
    fun init() {
        program = ShaderProgram(Shaders.CLOUD_VERTEX, Shaders.CLOUD_FRAGMENT)
        uViewProj = program.uniform("uViewProj")
        uCenter = program.uniform("uCenter")
        uHalf = program.uniform("uHalf")
        uCloudTex = program.uniform("uCloudTex")
        uEye = program.uniform("uEye")
        uShift = program.uniform("uShift")
        uRadius = program.uniform("uRadius")
        uFogColor = program.uniform("uFogColor")
        uFogStart = program.uniform("uFogStart")
        uFogEnd = program.uniform("uFogEnd")
        textureId = createMaskTexture()
    }

    /** Draws the sheet at height [cloudY], fading out at [radius] blocks from the eye.
     *  Uses whatever view-projection [frame] holds; leaves blending, depth writes and
     *  face culling as it found them (culling on, blending off, depth writes on). */
    fun draw(frame: FrameState, cloudY: Float, radius: Float) {
        if (radius < 8f) return
        program.use()
        GLES30.glUniformMatrix4fv(uViewProj, 1, false, frame.viewProj, 0)
        GLES30.glUniform3f(uCenter, frame.eyeX, cloudY, frame.eyeZ)
        GLES30.glUniform1f(uHalf, radius)
        GLES30.glUniform3f(uEye, frame.eyeX, frame.eyeY, frame.eyeZ)
        // 1.536 blocks/s for the 1,000 s the texture clock runs before it wraps = exactly one
        // 1,536-block repeat of the mask, so the drift never jumps.
        GLES30.glUniform1f(uShift, frame.textureTime * 1.536f)
        GLES30.glUniform1f(uRadius, radius)
        GLES30.glUniform3f(uFogColor, frame.fogR, frame.fogG, frame.fogB)
        GLES30.glUniform1f(uFogStart, frame.fogStart)
        GLES30.glUniform1f(uFogEnd, frame.fogEnd)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textureId)
        GLES30.glUniform1i(uCloudTex, 0)

        GLES30.glDisable(GLES30.GL_CULL_FACE)
        GLES30.glEnable(GLES30.GL_BLEND)
        GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA, GLES30.GL_ONE_MINUS_SRC_ALPHA)
        GLES30.glDepthMask(false)
        GLES30.glBindVertexArray(0)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4)
        GLES30.glDepthMask(true)
        GLES30.glDisable(GLES30.GL_BLEND)
        GLES30.glEnable(GLES30.GL_CULL_FACE)
    }

    // ---- the cloud mask -----------------------------------------------------------------

    private fun createMaskTexture(): Int {
        val size = MASK_SIZE
        val buf = ByteBuffer.allocateDirect(size * size).order(ByteOrder.nativeOrder())
        for (y in 0 until size) {
            for (x in 0 until size) {
                val v = 0.6f * valueNoise(x, y, 8, 1) + 0.4f * valueNoise(x, y, 4, 2)
                buf.put(if (v > THRESHOLD) 0xFF.toByte() else 0.toByte())
            }
        }
        buf.position(0)

        val ids = IntArray(1)
        GLES30.glGenTextures(1, ids, 0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, ids[0])
        GLES30.glPixelStorei(GLES30.GL_UNPACK_ALIGNMENT, 1)
        GLES30.glTexImage2D(
            GLES30.GL_TEXTURE_2D, 0, GLES30.GL_R8, size, size, 0,
            GLES30.GL_RED, GLES30.GL_UNSIGNED_BYTE, buf
        )
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_NEAREST)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_NEAREST)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_REPEAT)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_REPEAT)
        return ids[0]
    }

    /** Smooth value noise in 0..1 that repeats every MASK_SIZE texels (lattice spacing [cell]). */
    private fun valueNoise(x: Int, y: Int, cell: Int, salt: Int): Float {
        val period = MASK_SIZE / cell
        val fx = x.toFloat() / cell
        val fy = y.toFloat() / cell
        val ix = floor(fx).toInt()
        val iy = floor(fy).toInt()
        var tx = fx - ix
        var ty = fy - iy
        tx = tx * tx * (3f - 2f * tx)
        ty = ty * ty * (3f - 2f * ty)
        val a = lattice(ix, iy, period, salt)
        val b = lattice(ix + 1, iy, period, salt)
        val c = lattice(ix, iy + 1, period, salt)
        val d = lattice(ix + 1, iy + 1, period, salt)
        val top = a + (b - a) * tx
        val bottom = c + (d - c) * tx
        return top + (bottom - top) * ty
    }

    private fun lattice(ix: Int, iy: Int, period: Int, salt: Int): Float {
        val x = Math.floorMod(ix, period)
        val y = Math.floorMod(iy, period)
        var h = x * 374761393 + y * 668265263 + salt * 1274126177
        h = (h xor (h ushr 13)) * 1274126177
        h = h xor (h ushr 16)
        return ((h ushr 8) and 0xFFFF) / 65535f
    }

    private companion object {
        const val MASK_SIZE = 64

        /** Noise above this is cloud; about a third of the sky ends up covered. */
        const val THRESHOLD = 0.55f
    }
}
