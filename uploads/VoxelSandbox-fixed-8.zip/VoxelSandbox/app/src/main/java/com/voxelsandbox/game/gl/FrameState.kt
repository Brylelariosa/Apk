package com.voxelsandbox.game.gl

/**
 * Per-frame values the render passes share. GameRenderer fills one instance in place
 * each frame (no per-frame allocation) and hands it to the passes, so a pass never has to
 * be told about fog, camera or time one uniform at a time.
 */
class FrameState {
    /** Combined view-projection matrix of the pass being drawn (a copy, see GameRenderer). */
    val viewProj = FloatArray(16)

    var eyeX = 0f
    var eyeY = 0f
    var eyeZ = 0f

    // Camera basis (unit vectors) and field of view, for the sky gradient.
    var forwardX = 0f
    var forwardY = 0f
    var forwardZ = -1f
    var rightX = 1f
    var rightY = 0f
    var rightZ = 0f
    var upX = 0f
    var upY = 1f
    var upZ = 0f

    /** tan(vertical fov / 2) and the same times the aspect ratio. */
    var tanHalfFovY = 0.7f
    var tanHalfFovX = 1.2f

    var fogR = 0f
    var fogG = 0f
    var fogB = 0f
    var fogStart = 0f
    var fogEnd = 0f

    /** Seconds, wrapped every [TEXTURE_TIME_PERIOD] so float precision never degrades;
     *  drives the scrolling of the water texture. */
    var textureTime = 0f

    /** Seconds, wrapped every [WAVE_TIME_PERIOD]; drives the vertical swell of the water. */
    var waveTime = 0f

    /** Centre (world X/Z) and radius of the area real voxel chunks completely cover. Distant
     *  terrain is measured from the centre and never drawn inside the radius. */
    var coverX = 0f
    var coverZ = 0f
    var coverRadius = 0f

    companion object {
        /** All the water-texture scroll speeds (see Shaders) are whole multiples of 1/1000
         *  per second, so the scroll offsets are whole texture repeats at this period. */
        const val TEXTURE_TIME_PERIOD = 1000.0

        /** 2*pi / 0.05: a whole number of periods of every swell frequency in the water shader. */
        const val WAVE_TIME_PERIOD = 125.66370614359172
    }
}
