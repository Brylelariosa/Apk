package com.voxelsandbox.game.world.generation

import com.voxelsandbox.game.world.BlockType
import com.voxelsandbox.game.world.Chunk
import com.voxelsandbox.game.world.ChunkPos
import com.voxelsandbox.game.world.WorldConfig
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin

/** A good place to start a new world: dry, gentle ground well away from the shore. */
class SpawnPoint(val x: Int, val z: Int)

/**
 * Deterministic seeded terrain generator: the same (seed, chunkX, chunkZ) always
 * produces the same chunk, which is what lets SaveManager store only player-modified
 * chunks and regenerate everything else from the seed on load.
 *
 * The landscape itself lives in [TerrainShape] (height) and [Climate] (temperature,
 * humidity, surface type); this class turns those pure functions into blocks:
 * layered soil per surface type, plants, cacti and trees.
 *
 * Trees are placed without any neighbour coordination and still cross chunk borders
 * cleanly: every chunk independently evaluates the (pure, position-hashed) tree
 * candidates in its own area *plus a margin*, and writes only the tree blocks that fall
 * inside itself. A canopy that straddles a border is therefore assembled from the same
 * deterministic tree by both chunks, with no cross-chunk writes and no races. The
 * terrain height is a pure function of (x, z), so a chunk can also ask "how high is the
 * ground under that neighbouring tree" without the neighbour existing.
 */
class TerrainGenerator(private val seed: Long) {
    /** Land-form (height); also sampled directly by the distant-terrain builder. */
    val shape = TerrainShape(seed)

    /** Temperature / humidity / surface type; also sampled by the distant-terrain builder. */
    val climate = Climate(seed)

    private val oreNoise = NoiseGenerator(mixSeed(seed, 20))
    private val lilyNoise = NoiseGenerator(mixSeed(seed, 21))
    private val seedMix: Int = seed.toInt() * 1274126177
    private val trees = TreeBuilder(seedMix)

    fun generate(pos: ChunkPos): Chunk {
        val chunk = Chunk(pos)
        val size = WorldConfig.CHUNK_SIZE
        val baseX = pos.x * size
        val baseZ = pos.z * size

        // Raw ground heights for the chunk plus a two-block border: one block so the slope of
        // edge columns is exact without needing the neighbouring chunks, one more so the
        // lone-bump filter below can look at the neighbours of those border columns.
        val r = size + 4
        val raw = IntArray(r * r)
        for (gz in 0 until r) {
            for (gx in 0 until r) {
                raw[gz * r + gx] = rawHeight(baseX + gx - 2, baseZ + gz - 2)
            }
        }
        val g = size + 2
        val heights = IntArray(g * g)
        for (gz in 0 until g) {
            for (gx in 0 until g) {
                val i = (gz + 1) * r + (gx + 1)
                heights[gz * g + gx] = despike(raw[i], raw[i - r], raw[i + 1], raw[i + r], raw[i - 1])
            }
        }

        for (lz in 0 until size) {
            for (lx in 0 until size) {
                val i = (lz + 1) * g + (lx + 1)
                val rise = max(abs(heights[i + 1] - heights[i - 1]), abs(heights[i + g] - heights[i - g]))
                fillColumn(chunk, lx, lz, baseX + lx, baseZ + lz, heights[i], rise * 0.5)
            }
        }
        placeTrees(ChunkCanvas(chunk, baseX, baseZ), baseX, baseZ)
        return chunk
    }

    private fun rawHeight(wx: Int, wz: Int): Int = floor(shape.height(wx.toDouble(), wz.toDouble())).toInt()

    /** Removes a lone one-block bump (higher than all four neighbours by exactly one) or
     *  one-block pit, so flat country stays flat instead of being studded with single blocks. */
    private fun despike(c: Int, n: Int, e: Int, s: Int, w: Int): Int {
        val hi = max(max(n, e), max(s, w))
        val lo = minOf(minOf(n, e), minOf(s, w))
        if (c > hi && c - hi == 1) return hi
        if (c < lo && lo - c == 1) return lo
        return c
    }

    /** Y of the topmost solid block at (wx, wz). Pure function of position (it evaluates the
     *  same filtered height the chunk generator uses); the distant-terrain builder and the tree
     *  placement sample it directly without generating any chunk. */
    fun surfaceHeight(wx: Int, wz: Int): Int = despike(
        rawHeight(wx, wz), rawHeight(wx, wz - 1), rawHeight(wx + 1, wz), rawHeight(wx, wz + 1), rawHeight(wx - 1, wz)
    )

    /** Forest-ness in 0..1 (0 = open plains, 1 = dense forest). */
    fun forestFactor(wx: Int, wz: Int): Double = climate.forest(wx.toDouble(), wz.toDouble())

    // ---- Spawn ------------------------------------------------------------------------------

    /**
     * Searches outward from the origin, ring by ring, for the nearest pleasant spot to
     * start: dry gentle grassland with no water or cliff within a few blocks. Pure and
     * deterministic, so a world always starts in the same place for the same seed.
     */
    fun findSpawn(): SpawnPoint {
        for (ring in 0..SPAWN_MAX_RINGS) {
            val radius = ring * SPAWN_STEP
            val count = if (ring == 0) 1 else max(8, (2.0 * PI * radius / SPAWN_STEP).toInt())
            val phase = ring * 0.61
            for (k in 0 until count) {
                val a = phase + 2.0 * PI * k / count
                val x = (radius * cos(a)).roundToInt()
                val z = (radius * sin(a)).roundToInt()
                if (isGoodSpawn(x, z)) return SpawnPoint(x, z)
            }
        }
        return SpawnPoint(0, 0)
    }

    private fun isGoodSpawn(x: Int, z: Int): Boolean {
        val sea = WorldConfig.SEA_LEVEL
        val h = surfaceHeight(x, z)
        if (h < sea + 3 || h > sea + 24) return false
        var i = 0
        while (i < SPAWN_PROBES.size) {
            val h2 = surfaceHeight(x + SPAWN_PROBES[i], z + SPAWN_PROBES[i + 1])
            if (h2 < sea + 1 || abs(h2 - h) > 5) return false
            i += 2
        }
        return when (biomeAtGround(x, z, h)) {
            Biome.PLAINS, Biome.FOREST, Biome.BIRCH_FOREST, Biome.SAVANNA, Biome.TAIGA -> true
            else -> false
        }
    }

    // ---- Biomes -----------------------------------------------------------------------------

    /** Biome of dry ground at (wx, wz) whose top block is at [ground]. Measures the slope
     *  itself (four extra height samples), so use it for sparse queries only. */
    private fun biomeAtGround(wx: Int, wz: Int, ground: Int): Biome {
        val rise = max(
            abs(surfaceHeight(wx + 1, wz) - surfaceHeight(wx - 1, wz)),
            abs(surfaceHeight(wx, wz + 1) - surfaceHeight(wx, wz - 1))
        )
        val x = wx.toDouble()
        val z = wz.toDouble()
        return climate.biome(x, z, ground.toDouble(), rise * 0.5, shape.coastElevation(x, z))
    }

    /** The biome at column (wx, wz), water columns included. A pure function of position. */
    fun biomeAt(wx: Int, wz: Int): Biome {
        val h = surfaceHeight(wx, wz)
        if (h < WorldConfig.SEA_LEVEL) {
            return climate.waterBiome(
                (WorldConfig.SEA_LEVEL - h).toDouble(),
                shape.coastElevation(wx.toDouble(), wz.toDouble())
            )
        }
        return biomeAtGround(wx, wz, h)
    }

    private fun fillColumn(chunk: Chunk, lx: Int, lz: Int, wx: Int, wz: Int, height: Int, slope: Double) {
        val sea = WorldConfig.SEA_LEVEL
        val x = wx.toDouble()
        val z = wz.toDouble()
        val h = height.toDouble()
        val humid = climate.humidity(x, z)

        var kind = SurfaceKind.GRASS
        var biome = Biome.PLAINS
        var topBlock = BlockType.GRASS
        var soilBlock = BlockType.DIRT
        var soilLayers = 3
        var strataBlock = BlockType.STONE
        var strataLayers = 0

        if (height < sea) {
            // Sea / lake / river bed: sand in the shallows of warm water, gravel in the deep
            // and everywhere in cold water.
            val deep = sea - height > 8
            val cold = climate.baseTemperature(x, z) < Climate.COLD
            topBlock = if (deep || cold) BlockType.GRAVEL else BlockType.SAND
            soilBlock = topBlock
            soilLayers = 2
        } else {
            biome = climate.biome(x, z, h, slope, shape.coastElevation(x, z))
            kind = climate.surfaceFor(biome, x, z, h, slope)
            when (kind) {
                SurfaceKind.GRASS -> {}
                SurfaceKind.DRY_GRASS -> topBlock = BlockType.DRY_GRASS
                SurfaceKind.DESERT -> {
                    topBlock = BlockType.SAND
                    soilBlock = BlockType.SAND
                    soilLayers = 3
                    strataBlock = BlockType.SANDSTONE
                    strataLayers = 4
                }
                SurfaceKind.BEACH -> {
                    topBlock = BlockType.SAND
                    soilBlock = BlockType.SAND
                    soilLayers = 2
                }
                SurfaceKind.SNOW -> topBlock = BlockType.SNOW
                SurfaceKind.ROCK -> {
                    topBlock = BlockType.STONE
                    soilBlock = BlockType.STONE
                    soilLayers = 0
                }
                SurfaceKind.GRAVEL -> {
                    topBlock = BlockType.GRAVEL
                    soilBlock = BlockType.GRAVEL
                    soilLayers = 2
                }
            }
        }

        val topY = max(height, sea)
        for (y in 0..topY) {
            val block: BlockType = when {
                y > height -> BlockType.WATER // only below sea level (height < y <= sea)
                y == height -> topBlock
                y == 0 -> BlockType.STONE
                else -> {
                    val depth = height - y
                    when {
                        depth <= soilLayers -> soilBlock
                        depth <= soilLayers + strataLayers -> strataBlock
                        isCoalOre(wx, y, wz) -> BlockType.COAL_ORE
                        else -> BlockType.STONE
                    }
                }
            }
            chunk.setBlock(lx, y, lz, block)
        }

        if (height >= sea && height + 2 < WorldConfig.WORLD_HEIGHT) {
            scatterPlants(chunk, lx, lz, wx, wz, height, kind, biome, humid)
        } else if (height < sea && height >= sea - LILY_MAX_DEPTH && climate.baseTemperature(x, z) > LILY_MIN_TEMP) {
            // Lily pads float on shallow, not-freezing water, in loose patches.
            val patch = lilyNoise.noise2D(x * 0.07 + 13.0, z * 0.07 - 29.0)
            if (patch > 0.28 && ((hash3(wx, 11, wz) ushr 7) and 3) == 0) {
                chunk.setBlock(lx, sea + 1, lz, BlockType.LILY_PAD)
            }
        }
    }

    private fun isCoalOre(wx: Int, y: Int, wz: Int): Boolean {
        if (y > WorldConfig.SEA_LEVEL - 4) return false
        val n = oreNoise.noise2D(wx * 0.35 + y * 0.7, wz * 0.35 - y * 0.4)
        return n > 0.90
    }

    // ---- Ground cover ---------------------------------------------------------------------

    /** Grass tufts, flowers, dead bushes and cacti on top of the ground block. */
    private fun scatterPlants(chunk: Chunk, lx: Int, lz: Int, wx: Int, wz: Int, height: Int, kind: SurfaceKind, biome: Biome, humid: Double) {
        val bits = hash3(wx, 7, wz)
        val u = ((bits ushr 8) and 0xFFFF) / 65536.0
        val y = height + 1
        when (kind) {
            SurfaceKind.GRASS -> {
                val tufts = 0.10 + 0.14 * (humid + 1.0) * 0.5 // thicker in wet country
                val flowers = when (biome) {
                    Biome.PLAINS -> 0.035 // meadows are full of flowers
                    Biome.FOREST, Biome.BIRCH_FOREST -> 0.016
                    else -> 0.006
                }
                if (u < tufts) {
                    chunk.setBlock(lx, y, lz, BlockType.TALL_GRASS)
                } else if (u < tufts + flowers) {
                    chunk.setBlock(lx, y, lz, if ((bits and 1) == 0) BlockType.POPPY else BlockType.DANDELION)
                }
            }
            SurfaceKind.DRY_GRASS -> {
                if (u < 0.09) {
                    chunk.setBlock(lx, y, lz, BlockType.TALL_GRASS)
                } else if (u < 0.10) {
                    chunk.setBlock(lx, y, lz, BlockType.DEAD_BUSH)
                }
            }
            SurfaceKind.DESERT -> {
                if (u < 0.012) {
                    chunk.setBlock(lx, y, lz, BlockType.DEAD_BUSH)
                } else if (u < 0.019) {
                    val cactusHeight = 1 + ((bits ushr 3) and 3) % 3
                    for (k in 0 until cactusHeight) chunk.setBlock(lx, y + k, lz, BlockType.CACTUS)
                }
            }
            else -> {}
        }
    }

    // ---- Trees ----------------------------------------------------------------------------

    private fun placeTrees(canvas: ChunkCanvas, baseX: Int, baseZ: Int) {
        val size = WorldConfig.CHUNK_SIZE
        val minCellX = Math.floorDiv(baseX - TREE_REACH, CELL)
        val maxCellX = Math.floorDiv(baseX + size - 1 + TREE_REACH, CELL)
        val minCellZ = Math.floorDiv(baseZ - TREE_REACH, CELL)
        val maxCellZ = Math.floorDiv(baseZ + size - 1 + TREE_REACH, CELL)

        for (cz in minCellZ..maxCellZ) {
            for (cx in minCellX..maxCellX) {
                // Deterministic per-4x4 cell: at most one tree candidate at a hash-chosen spot.
                val th = cellHash(cx, cz)
                val wx = cx * CELL + ((th ushr 8) and 3)
                val wz = cz * CELL + ((th ushr 10) and 3)
                if (wx < baseX - TREE_REACH || wx >= baseX + size + TREE_REACH) continue
                if (wz < baseZ - TREE_REACH || wz >= baseZ + size + TREE_REACH) continue

                val spot = treeSpot(cx, cz) ?: continue
                trees.grow(canvas, spot.species, spot.x, spot.z, spot.ground, spot.th)
            }
        }
    }

    /** A tree candidate that passed every check: where it stands and what it is. */
    class TreeSpot(val x: Int, val z: Int, val ground: Int, val species: TreeSpecies, val th: Int)

    /**
     * The tree (if any) of the 4x4 cell ([cx], [cz]) -- a pure function of the cell, used both
     * by the chunk generator and by the distant-terrain builder, so far-away trees stand exactly
     * where the real ones will grow.
     */
    fun treeSpot(cx: Int, cz: Int): TreeSpot? {
        val th = cellHash(cx, cz)
        val wx = cx * CELL + ((th ushr 8) and 3)
        val wz = cz * CELL + ((th ushr 10) and 3)
        val forest = forestFactor(wx, wz)
        val chance = 0.02 + 0.30 * forest * forest // sparse in open ground, thick in forests
        if ((th and 0xFF) >= (chance * 256.0).toInt()) return null // cheap early-out

        val ground = surfaceHeight(wx, wz)
        if (ground <= WorldConfig.SEA_LEVEL + 2) return null // beaches / shallows stay bare
        val biome = biomeAtGround(wx, wz, ground)
        val density = treeDensity(biome)
        if (density <= 0.0 || (th and 0xFF) >= (chance * density * 256.0).toInt()) return null
        val species = pickSpecies(biome, ground, th) ?: return null
        return TreeSpot(wx, wz, ground, species, th)
    }

    /** Share of the forest-noise tree chance that survives in [biome] (0 = no trees). */
    fun treeDensity(biome: Biome): Double = when (biome) {
        Biome.FOREST, Biome.BIRCH_FOREST, Biome.TAIGA -> 1.0
        Biome.SNOWY_TAIGA -> 0.9
        Biome.MOUNTAINS -> 0.45
        Biome.PLAINS -> 0.35
        Biome.SNOWY_PLAINS, Biome.SAVANNA -> 0.25
        else -> 0.0 // desert, shores, oceans, snowy peaks
    }

    /** Chance (0..1) that a 4x4 cell holds a tree, given the forest noise [forest] there. */
    fun treeChance(biome: Biome, forest: Double): Double = (0.02 + 0.30 * forest * forest) * treeDensity(biome)

    /** Which tree grows in [biome] for the hash roll in [th]. */
    private fun pickSpecies(biome: Biome, ground: Int, th: Int): TreeSpecies? {
        val roll = (th ushr 12) and 0xFF
        return when (biome) {
            Biome.FOREST -> if (roll < 200) TreeSpecies.OAK else TreeSpecies.BIRCH
            Biome.BIRCH_FOREST -> if (roll < 215) TreeSpecies.BIRCH else TreeSpecies.OAK
            Biome.PLAINS -> if (roll < 190) TreeSpecies.OAK else TreeSpecies.BIRCH
            Biome.SAVANNA -> TreeSpecies.OAK
            Biome.TAIGA -> if (roll < 235) TreeSpecies.SPRUCE else TreeSpecies.BIRCH
            Biome.SNOWY_TAIGA, Biome.SNOWY_PLAINS -> TreeSpecies.SPRUCE
            Biome.MOUNTAINS -> if (ground < WorldConfig.SEA_LEVEL + 40) TreeSpecies.SPRUCE else null
            else -> null
        }
    }

    private fun cellHash(x: Int, z: Int): Int {
        var h = x * 374761393 + z * 668265263 + seed.toInt() * 1274126177
        h = (h xor (h ushr 13)) * -1028477387
        return h xor (h ushr 16)
    }

    private fun hash3(x: Int, y: Int, z: Int): Int {
        var h = x * 374761393 + y * 668265263 + z * 1274126177 + seedMix
        h = (h xor (h ushr 13)) * -1028477387
        return h xor (h ushr 16)
    }

    private companion object {
        const val CELL = 4

        /** Widest a canopy ever reaches from its trunk, plus one block of slack. */
        const val TREE_REACH = 4

        /** Lily pads grow in water at most this deep, in water warmer than this. */
        const val LILY_MAX_DEPTH = 5
        const val LILY_MIN_TEMP = -0.2

        const val SPAWN_STEP = 24
        const val SPAWN_MAX_RINGS = 120

        /** (dx, dz) pairs probed around a candidate spawn: all must be dry and level-ish. */
        val SPAWN_PROBES = intArrayOf(6, 0, -6, 0, 0, 6, 0, -6, 5, 5, -5, 5, 5, -5, -5, -5)
    }
}
