package com.voxelsandbox.game.world

/**
 * Chunk offsets (dx, dz) inside a DISC of the given radius, sorted nearest-first. (A disc,
 * not the bounding square: the square's corners sit ~41% further out than its edges, so
 * loading them meant ~27% more chunks than the fog distance could ever show.)
 * Both WorldManager (deciding what to load) and GameRenderer (working out how far the
 * loaded-and-meshed area really reaches) walk this same ordering, so they always agree on
 * which chunks come "first". Results are cached because the arrays are a few thousand
 * entries; a tiny cache is plenty since the radius only changes with the settings.
 */
object ChunkRing {
    private val cache = HashMap<Int, Array<IntArray>>()

    @Synchronized
    fun offsets(radius: Int): Array<IntArray> {
        val r = if (radius < 0) 0 else radius
        val hit = cache[r]
        if (hit != null) return hit
        val list = ArrayList<IntArray>((2 * r + 1) * (2 * r + 1))
        // r*r + r instead of r*r so the chunks straight out along each axis (exactly r
        // away) are always included and the edge of the disc has no ragged single chunks.
        val limit = r * r + r
        for (dx in -r..r) {
            for (dz in -r..r) {
                if (dx * dx + dz * dz <= limit) list.add(intArrayOf(dx, dz))
            }
        }
        list.sortBy { it[0] * it[0] + it[1] * it[1] }
        val arr = list.toTypedArray()
        if (cache.size >= 4) cache.clear()
        cache[r] = arr
        return arr
    }
}
