package com.voxelsandbox.game.world

/**
 * Indices of the cells in the procedural texture atlas (an 8x8 grid, see TextureAtlas).
 *
 * Kept in the world package, next to [BlockType], because block definitions refer to
 * cells by index; TextureAtlas imports this so the two can never drift apart.
 */
object AtlasCell {
    const val GRASS_TOP = 0
    const val GRASS_SIDE = 1
    const val DIRT = 2
    const val STONE = 3
    const val SAND = 4
    const val OAK_BARK = 5
    const val OAK_RINGS = 6
    const val OAK_LEAVES = 7
    const val COAL_ORE = 8
    const val WATER = 9
    const val WHITE = 10
    const val BIRCH_BARK = 11
    const val BIRCH_LEAVES = 12
    const val SPRUCE_LEAVES = 13
    const val SPRUCE_BARK = 14

    /** One-cell-tall colour strip sampled by the distant-terrain mesh. */
    const val RAMP = 15
    const val BIRCH_RINGS = 16
    const val SPRUCE_RINGS = 17
    const val SNOW = 18
    const val SNOW_SIDE = 19
    const val GRAVEL = 20
    const val SANDSTONE_SIDE = 21
    const val SANDSTONE_TOP = 22
    const val DRY_GRASS_TOP = 23
    const val DRY_GRASS_SIDE = 24
    const val TALL_GRASS = 25
    const val POPPY = 26
    const val DANDELION = 27
    const val DEAD_BUSH = 28
    const val CACTUS_SIDE = 29
    const val CACTUS_TOP = 30
    const val LILY_PAD = 31
}
