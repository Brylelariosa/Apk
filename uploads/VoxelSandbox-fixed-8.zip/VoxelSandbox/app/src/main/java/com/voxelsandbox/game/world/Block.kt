package com.voxelsandbox.game.world

/**
 * All block types are original (no Minecraft asset/name reuse). Each entry carries its
 * own top/side/bottom texture-atlas cell indices (see [AtlasCell]) so the mesher can
 * look up UVs without any per-face special-casing.
 */
enum class BlockType(
    val id: Byte,
    val displayName: String,
    val solid: Boolean,
    val opaque: Boolean,
    val breakable: Boolean,
    val placeable: Boolean,
    val topCell: Int,
    val sideCell: Int,
    val bottomCell: Int,
    /** Foliage-style block: its texture has transparent holes (alpha-tested in the
     *  shader), so it is not [opaque] for culling neighbours, but faces between two
     *  cutout blocks are still skipped (see ChunkMesher) to keep canopies cheap. */
    val cutout: Boolean = false,
    /** Cross-shaped decoration (grass tufts, flowers, dead bushes): drawn as two
     *  crossed quads instead of a cube. Plants are walk-through, can be targeted with
     *  the crosshair (by their small box, not the whole cell), broken instantly, and are
     *  simply replaced when a block is placed into their cell. */
    val plant: Boolean = false,
    /** A plant that is one flat horizontal quad at the bottom of its cell (lily pad). */
    val flat: Boolean = false
) {
    AIR(0, "Air", solid = false, opaque = false, breakable = false, placeable = false, topCell = -1, sideCell = -1, bottomCell = -1),
    GRASS(1, "Grass", solid = true, opaque = true, breakable = true, placeable = true, topCell = AtlasCell.GRASS_TOP, sideCell = AtlasCell.GRASS_SIDE, bottomCell = AtlasCell.DIRT),
    DIRT(2, "Dirt", solid = true, opaque = true, breakable = true, placeable = true, topCell = AtlasCell.DIRT, sideCell = AtlasCell.DIRT, bottomCell = AtlasCell.DIRT),
    STONE(3, "Stone", solid = true, opaque = true, breakable = true, placeable = true, topCell = AtlasCell.STONE, sideCell = AtlasCell.STONE, bottomCell = AtlasCell.STONE),
    SAND(4, "Sand", solid = true, opaque = true, breakable = true, placeable = true, topCell = AtlasCell.SAND, sideCell = AtlasCell.SAND, bottomCell = AtlasCell.SAND),
    WOOD(5, "Wood", solid = true, opaque = true, breakable = true, placeable = true, topCell = AtlasCell.OAK_RINGS, sideCell = AtlasCell.OAK_BARK, bottomCell = AtlasCell.OAK_RINGS),
    LEAVES(6, "Leaves", solid = true, opaque = false, breakable = true, placeable = true, topCell = AtlasCell.OAK_LEAVES, sideCell = AtlasCell.OAK_LEAVES, bottomCell = AtlasCell.OAK_LEAVES, cutout = true),
    COAL_ORE(7, "Coal Ore", solid = true, opaque = true, breakable = true, placeable = true, topCell = AtlasCell.COAL_ORE, sideCell = AtlasCell.COAL_ORE, bottomCell = AtlasCell.COAL_ORE),

    /** Rendered by the dedicated animated-water pass (see ChunkMesher / GameRenderer);
     *  the cell is only used for the particles a splash would use. */
    WATER(8, "Water", solid = false, opaque = false, breakable = false, placeable = false, topCell = AtlasCell.WATER, sideCell = AtlasCell.WATER, bottomCell = AtlasCell.WATER),

    // Tree species. They are separate blocks (own bark / leaf textures) but drop the basic
    // Wood / Leaves item, so the hotbar is unchanged.
    BIRCH_WOOD(9, "Birch Wood", solid = true, opaque = true, breakable = true, placeable = false, topCell = AtlasCell.BIRCH_RINGS, sideCell = AtlasCell.BIRCH_BARK, bottomCell = AtlasCell.BIRCH_RINGS),
    BIRCH_LEAVES(10, "Birch Leaves", solid = true, opaque = false, breakable = true, placeable = false, topCell = AtlasCell.BIRCH_LEAVES, sideCell = AtlasCell.BIRCH_LEAVES, bottomCell = AtlasCell.BIRCH_LEAVES, cutout = true),
    SPRUCE_WOOD(11, "Spruce Wood", solid = true, opaque = true, breakable = true, placeable = false, topCell = AtlasCell.SPRUCE_RINGS, sideCell = AtlasCell.SPRUCE_BARK, bottomCell = AtlasCell.SPRUCE_RINGS),
    SPRUCE_LEAVES(12, "Spruce Leaves", solid = true, opaque = false, breakable = true, placeable = false, topCell = AtlasCell.SPRUCE_LEAVES, sideCell = AtlasCell.SPRUCE_LEAVES, bottomCell = AtlasCell.SPRUCE_LEAVES, cutout = true),

    // Terrain materials added with the realistic-terrain generator (biomes, mountains).
    SNOW(13, "Snow", solid = true, opaque = true, breakable = true, placeable = false, topCell = AtlasCell.SNOW, sideCell = AtlasCell.SNOW_SIDE, bottomCell = AtlasCell.DIRT),
    GRAVEL(14, "Gravel", solid = true, opaque = true, breakable = true, placeable = false, topCell = AtlasCell.GRAVEL, sideCell = AtlasCell.GRAVEL, bottomCell = AtlasCell.GRAVEL),
    SANDSTONE(15, "Sandstone", solid = true, opaque = true, breakable = true, placeable = false, topCell = AtlasCell.SANDSTONE_TOP, sideCell = AtlasCell.SANDSTONE_SIDE, bottomCell = AtlasCell.SANDSTONE_TOP),
    DRY_GRASS(16, "Dry Grass", solid = true, opaque = true, breakable = true, placeable = false, topCell = AtlasCell.DRY_GRASS_TOP, sideCell = AtlasCell.DRY_GRASS_SIDE, bottomCell = AtlasCell.DIRT),
    CACTUS(21, "Cactus", solid = true, opaque = true, breakable = true, placeable = false, topCell = AtlasCell.CACTUS_TOP, sideCell = AtlasCell.CACTUS_SIDE, bottomCell = AtlasCell.CACTUS_TOP),

    // Decorative plants (cross-shaped, walk-through).
    TALL_GRASS(17, "Tall Grass", solid = false, opaque = false, breakable = true, placeable = false, topCell = AtlasCell.TALL_GRASS, sideCell = AtlasCell.TALL_GRASS, bottomCell = AtlasCell.TALL_GRASS, plant = true),
    POPPY(18, "Poppy", solid = false, opaque = false, breakable = true, placeable = false, topCell = AtlasCell.POPPY, sideCell = AtlasCell.POPPY, bottomCell = AtlasCell.POPPY, plant = true),
    DANDELION(19, "Dandelion", solid = false, opaque = false, breakable = true, placeable = false, topCell = AtlasCell.DANDELION, sideCell = AtlasCell.DANDELION, bottomCell = AtlasCell.DANDELION, plant = true),
    DEAD_BUSH(20, "Dead Bush", solid = false, opaque = false, breakable = true, placeable = false, topCell = AtlasCell.DEAD_BUSH, sideCell = AtlasCell.DEAD_BUSH, bottomCell = AtlasCell.DEAD_BUSH, plant = true),

    /** Floats on the water surface: one flat quad just above the water (see ChunkMesher). */
    LILY_PAD(22, "Lily Pad", solid = false, opaque = false, breakable = true, placeable = false, topCell = AtlasCell.LILY_PAD, sideCell = AtlasCell.LILY_PAD, bottomCell = AtlasCell.LILY_PAD, plant = true, flat = true);

    /** What the player receives when breaking this block. Variants fold into the basic
     *  hotbar items; blocks without a hotbar slot are simply not collected. */
    val drop: BlockType
        get() = when (this) {
            BIRCH_WOOD, SPRUCE_WOOD -> WOOD
            BIRCH_LEAVES, SPRUCE_LEAVES -> LEAVES
            DRY_GRASS -> GRASS
            SNOW -> DIRT
            GRAVEL -> STONE
            SANDSTONE -> SAND
            else -> this
        }

    /** True if a block being placed may overwrite this cell (air, water or a plant). */
    val replaceable: Boolean
        get() = this == AIR || this == WATER || plant

    fun cellFor(face: Face): Int = when (face) {
        Face.TOP -> topCell
        Face.BOTTOM -> bottomCell
        else -> sideCell
    }

    companion object {
        /** Block ids are always below this; per-id lookup tables use it (mask with
         *  `TABLE_SIZE - 1`) so a corrupt id byte can never index out of bounds. */
        const val TABLE_SIZE = 32

        private val byId: Array<BlockType?> = arrayOfNulls<BlockType>(TABLE_SIZE).also { arr ->
            values().forEach { arr[it.id.toInt()] = it }
        }

        /** Per-id "hides the face behind it" table shared by the mesher's hot loops. */
        val OPAQUE_BY_ID: BooleanArray = BooleanArray(TABLE_SIZE).also { table ->
            values().forEach { table[it.id.toInt()] = it.opaque }
        }

        fun fromId(id: Byte): BlockType = byId.getOrNull(id.toInt() and (TABLE_SIZE - 1)) ?: AIR

        /** The fixed set of block types placeable from the hotbar, in slot order.
         *  Water is intentionally excluded (not player-placeable in this version). */
        val HOTBAR_ORDER: List<BlockType> = listOf(GRASS, DIRT, STONE, SAND, WOOD, LEAVES, COAL_ORE)
    }
}

enum class Face(val dx: Int, val dy: Int, val dz: Int) {
    TOP(0, 1, 0),
    BOTTOM(0, -1, 0),
    NORTH(0, 0, -1),
    SOUTH(0, 0, 1),
    EAST(1, 0, 0),
    WEST(-1, 0, 0);

    companion object {
        val ALL = values()
    }
}
