package com.voxelsandbox.game.gl

import android.opengl.GLES30
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * A small tiling noise texture the water shader scrolls to make ripples: the red and
 * green channels hold the surface slope (0.5 = flat) and blue the wave height. The noise
 * is "ridged" (1 - |2n - 1|), which gives the sharp crests and soft troughs of real
 * ripples rather than lumpy blobs. Built on the CPU once; wraps in both directions.
 */
class WaterTexture {
    private var textureId = 0

    fun upload() {
        val ids = IntArray(1)
        GLES30.glGenTextures(1, ids, 0)
        textureId = ids[0]
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textureId)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR_MIPMAP_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_REPEAT)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_REPEAT)

        val height = buildHeights()
        val buf = ByteBuffer.allocateDirect(SIZE * SIZE * 4).order(ByteOrder.nativeOrder())
        for (y in 0 until SIZE) {
            for (x in 0 until SIZE) {
                // central differences, wrapping at the edges
                val dx = height[y * SIZE + (x + 1) % SIZE] - height[y * SIZE + (x + SIZE - 1) % SIZE]
                val dy = height[((y + 1) % SIZE) * SIZE + x] - height[((y + SIZE - 1) % SIZE) * SIZE + x]
                buf.put(toByte(0.5f + dx * SLOPE_GAIN))
                buf.put(toByte(0.5f + dy * SLOPE_GAIN))
                buf.put(toByte(height[y * SIZE + x]))
                buf.put(255.toByte())
            }
        }
        buf.position(0)
        GLES30.glTexImage2D(
            GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RGBA, SIZE, SIZE, 0,
            GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, buf
        )
        GLES30.glGenerateMipmap(GLES30.GL_TEXTURE_2D)
    }

    fun bind(unit: Int) {
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0 + unit)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textureId)
    }

    private fun toByte(v: Float): Byte {
        val i = (v * 255f + 0.5f).toInt()
        return (if (i < 0) 0 else if (i > 255) 255 else i).toByte()
    }

    /** Wave heights in 0..1, SIZE x SIZE, periodic in both directions. */
    private fun buildHeights(): FloatArray {
        val out = FloatArray(SIZE * SIZE)
        for (y in 0 until SIZE) {
            for (x in 0 until SIZE) {
                var h = 0f
                var amp = 0.55f
                var cells = 4
                var salt = 7
                while (cells <= 16) {
                    val n = valueNoise(x, y, cells, salt)
                    val ridge = 1f - Math.abs(2f * n - 1f)
                    h += ridge * amp
                    amp *= 0.55f
                    cells *= 2
                    salt += 13
                }
                out[y * SIZE + x] = (h / 0.87f).coerceIn(0f, 1f)
            }
        }
        return out
    }

    /** Smooth value noise in 0..1 with [cells] lattice cells across the tile (wraps). */
    private fun valueNoise(x: Int, y: Int, cells: Int, salt: Int): Float {
        val cellPx = SIZE / cells
        val ix = x / cellPx
        val iy = y / cellPx
        val fx = (x - ix * cellPx).toFloat() / cellPx
        val fy = (y - iy * cellPx).toFloat() / cellPx
        val tx = fx * fx * (3f - 2f * fx)
        val ty = fy * fy * (3f - 2f * fy)
        val x0 = ix % cells
        val x1 = (ix + 1) % cells
        val y0 = iy % cells
        val y1 = (iy + 1) % cells
        val a = lattice(x0, y0, salt)
        val b = lattice(x1, y0, salt)
        val c = lattice(x0, y1, salt)
        val d = lattice(x1, y1, salt)
        val top = a + (b - a) * tx
        val bottom = c + (d - c) * tx
        return top + (bottom - top) * ty
    }

    private fun lattice(x: Int, y: Int, salt: Int): Float {
        var h = x * 374761393 + y * 668265263 + salt * 1274126177
        h = (h xor (h ushr 13)) * 1274126177
        h = h xor (h ushr 16)
        return ((h ushr 8) and 0xFF) / 255f
    }

    private companion object {
        const val SIZE = 64

        /** Height differences are small (a fraction of 1); this brings the slope into 0..1. */
        const val SLOPE_GAIN = 2.2f
    }
}
