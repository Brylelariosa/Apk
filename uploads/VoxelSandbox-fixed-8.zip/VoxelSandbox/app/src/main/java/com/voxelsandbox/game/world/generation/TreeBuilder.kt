package com.voxelsandbox.game.world.generation

import com.voxelsandbox.game.world.BlockType
import com.voxelsandbox.game.world.Chunk
import com.voxelsandbox.game.world.WorldConfig
import kotlin.math.ceil
import kotlin.math.min

enum class TreeSpecies { OAK, BIRCH, SPRUCE }

/**
 * A write window onto one chunk addressed in world coordinates. Writes that fall outside
 * the chunk are silently dropped, which is what lets every chunk build "its share" of a
 * tree that straddles a border with no coordination between neighbours.
 */
internal class ChunkCanvas(private val chunk: Chunk, private val baseX: Int, private val baseZ: Int) {
    /** Writes [block] at world (wx, y, wz) if that cell lies inside this chunk and is free.
     *  Free means air or a decorative plant; logs may also replace another tree's leaves. */
    fun put(wx: Int, y: Int, wz: Int, block: BlockType, replaceFoliage: Boolean) {
        if (y < 0 || y >= WorldConfig.WORLD_HEIGHT) return
        val lx = wx - baseX
        val lz = wz - baseZ
        if (lx < 0 || lx >= WorldConfig.CHUNK_SIZE || lz < 0 || lz >= WorldConfig.CHUNK_SIZE) return
        val existing = chunk.getBlock(lx, y, lz)
        if (existing == BlockType.AIR || existing.plant || (replaceFoliage && existing.cutout)) {
            chunk.setBlock(lx, y, lz, block)
        }
    }
}

/**
 * Tree shapes. Every shape is a pure function of its arguments (the position hash [th]
 * picks the size and the little irregularities), so two chunks that both draw the same
 * tree produce identical blocks on their side of the border.
 */
internal class TreeBuilder(private val seedMix: Int) {

    fun grow(canvas: ChunkCanvas, species: TreeSpecies, wx: Int, wz: Int, ground: Int, th: Int) {
        val wood = when (species) {
            TreeSpecies.BIRCH -> BlockType.BIRCH_WOOD
            TreeSpecies.SPRUCE -> BlockType.SPRUCE_WOOD
            TreeSpecies.OAK -> BlockType.WOOD
        }
        val leaf = when (species) {
            TreeSpecies.BIRCH -> BlockType.BIRCH_LEAVES
            TreeSpecies.SPRUCE -> BlockType.SPRUCE_LEAVES
            TreeSpecies.OAK -> BlockType.LEAVES
        }

        if (species != TreeSpecies.SPRUCE && ((th ushr 20) and 15) == 0) {
            // a low leafy bush: one log and a small rounded cluster of leaves
            canvas.put(wx, ground + 1, wz, wood, true)
            blob(canvas, wx, ground + 2, wz, leaf, 1.7, 1.3)
            return
        }

        when (species) {
            TreeSpecies.SPRUCE -> growSpruce(canvas, wx, wz, ground, th, wood, leaf)
            TreeSpecies.BIRCH -> {
                val trunk = 6 + ((th ushr 4) % 4) // 6..9, tall and slim
                trunkAndBlob(canvas, wx, wz, ground, trunk, wood, leaf, 2.0, 2.8)
            }
            TreeSpecies.OAK -> {
                val big = ((th ushr 24) and 7) == 0 // roughly one in eight is a broad old oak
                if (big) {
                    trunkAndBlob(canvas, wx, wz, ground, 7 + ((th ushr 4) % 3), wood, leaf, 3.3, 3.0)
                } else {
                    trunkAndBlob(canvas, wx, wz, ground, 5 + ((th ushr 4) % 4), wood, leaf, 2.5, 2.3)
                }
            }
        }
    }

    private fun trunkAndBlob(
        canvas: ChunkCanvas, wx: Int, wz: Int, ground: Int,
        trunk: Int, wood: BlockType, leaf: BlockType, rH: Double, rV: Double
    ) {
        val topY = ground + trunk
        for (y in (ground + 1)..topY) canvas.put(wx, y, wz, wood, true)
        blob(canvas, wx, topY - 1, wz, leaf, rH, rV)
    }

    /** A rough ellipsoid of leaves around (cx, cy, cz). Each boundary block is nudged in or
     *  out by a position hash, which is what makes canopies look organic instead of
     *  like perfect spheres. */
    private fun blob(canvas: ChunkCanvas, cx: Int, cy: Int, cz: Int, leaf: BlockType, rH: Double, rV: Double) {
        val ex = ceil(rH).toInt()
        val ey = ceil(rV).toInt()
        for (dy in -ey..ey) {
            for (dx in -ex..ex) {
                for (dz in -ex..ex) {
                    val e = (dx * dx + dz * dz) / (rH * rH) + (dy * dy) / (rV * rV)
                    val jitter = ((hash3(cx + dx, cy + dy, cz + dz) ushr 6) and 15) / 15.0 * 0.5 - 0.15
                    if (e <= 1.0 + jitter) canvas.put(cx + dx, cy + dy, cz + dz, leaf, false)
                }
            }
        }
    }

    /** Tall tiered cone: a slender boreal conifer, 7..13 blocks of trunk. */
    private fun growSpruce(
        canvas: ChunkCanvas, wx: Int, wz: Int, ground: Int, th: Int,
        wood: BlockType, leaf: BlockType
    ) {
        val trunk = 7 + ((th ushr 4) % 7)
        val topY = ground + trunk
        for (y in (ground + 1)..topY) canvas.put(wx, y, wz, wood, true)

        // Layer 0 is the single-block tip; the radius grows toward the bottom.
        for (y in (ground + 3)..(topY + 1)) {
            val t = topY + 1 - y
            val r = SPRUCE_RADII[min(t, SPRUCE_RADII.size - 1)]
            if (r == 0) {
                canvas.put(wx, y, wz, leaf, false)
                continue
            }
            val lim = r * r + r
            for (dx in -r..r) {
                for (dz in -r..r) {
                    val d2 = dx * dx + dz * dz
                    if (d2 > lim) continue
                    // thin out the outer rim a little so the cone isn't machine-perfect
                    if (d2 >= r * r && (hash3(wx + dx, y, wz + dz) and 3) == 0) continue
                    canvas.put(wx + dx, y, wz + dz, leaf, false)
                }
            }
        }
    }

    private fun hash3(x: Int, y: Int, z: Int): Int {
        var h = x * 374761393 + y * 668265263 + z * 1274126177 + seedMix
        h = (h xor (h ushr 13)) * -1028477387
        return h xor (h ushr 16)
    }

    private companion object {
        /** Cone radius by distance below the tip (alternating tiers read as branches). */
        val SPRUCE_RADII = intArrayOf(0, 1, 1, 2, 2, 3, 2, 3, 3, 3, 3, 3)
    }
}
