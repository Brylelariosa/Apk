package com.voxelsandbox.game.world.far

import com.voxelsandbox.game.gl.TextureAtlas
import com.voxelsandbox.game.world.WorldConfig
import com.voxelsandbox.game.world.generation.Biome
import com.voxelsandbox.game.world.generation.Climate
import com.voxelsandbox.game.world.generation.SurfaceKind
import com.voxelsandbox.game.world.generation.TerrainGenerator
import com.voxelsandbox.game.world.generation.TreeSpecies
import com.voxelsandbox.game.world.mesh.MeshData
import java.util.concurrent.LinkedBlockingQueue
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/** Tile add ([tile] != null) or removal ([tile] == null) for [key], delivered to the GL
 *  thread strictly in the order the worker produced them. A single ordered stream matters:
 *  with separate "ready" and "unload" queues a tile that was built, unloaded and rebuilt
 *  could be applied in the wrong order and leave a ghost mesh behind. */
class FarEvent(val key: Long, val tile: FarTile?)

/** One finished distant-terrain tile, ready for the GL thread to upload: the opaque land
 *  mesh and (where the tile touches water) the translucent water mesh. */
class FarTile(
    val key: Long,
    val land: MeshData,
    val water: MeshData,
    val minY: Float,
    val maxY: Float
) {
    val level: Int get() = FarTerrain.levelOf(key)

    /** Edge length of the (square) tile in blocks. */
    val size: Float get() = FarTerrain.tileBlocks(level).toFloat()

    /** World-space X/Z of the tile's lower corner. */
    val x0: Float get() = FarTerrain.tileX(key) * size
    val z0: Float get() = FarTerrain.tileZ(key) * size
}

/**
 * Distant terrain: cheap blocky "voxel-style" columns (with little trees) that fill the space
 * between the full-detail voxel chunks and the horizon, so the view distance can be many
 * times larger than what voxel chunks could ever afford (memory- or draw-call-wise).
 *
 * Nothing here touches the voxel world. Heights come straight from the terrain
 * generator's pure height function, so a tile can exist for terrain that no chunk has
 * generated yet — which is also why the horizon is there instantly at start-up and why
 * it fills any gap while real chunks are still streaming in.
 *
 * Level of detail: there are [LEVELS] levels. Level L tiles are (256 << L) blocks wide
 * with a column every (4 << L) blocks, so every tile is the same 64 x 64 cells whatever
 * its size (big tiles keep the number of draw calls low). Each level owns a distance band around the player (see [bandInner] /
 * [bandOuter]): detail halves as the distance doubles, which keeps the triangle count of a
 * 3,200-block view at roughly that of a 600-block one. The band limits are enforced by the
 * GL side (it discards fragments outside the band) rather than by cutting tiles, and
 * neighbouring bands deliberately overlap a little with the coarser surface nudged down
 * inside the overlap, so the seam between two levels can never open a crack.
 *
 * Tiles of one level sample exactly the same heights along their shared edges, so there are
 * no cracks inside a level either. Colour comes from a palette in the texture atlas chosen
 * from the surface type (see [SurfaceKind]), height and forest density, so a tile needs no
 * per-block textures. Where the ground is below sea level the tile also gets a
 * water mesh whose vertices carry the water depth, drawn by the animated-water shader.
 *
 * Everything is built on one background thread, nearest tile first. [coveredRadiusBlocks]
 * reports how far from the player the tiles are contiguously complete, which the renderer
 * uses to keep the fog in front of any still-missing ground.
 */
class FarTerrain(private val generator: TerrainGenerator) {

    @Volatile private var running = false
    @Volatile private var enabled = true
    @Volatile private var playerX = 0f
    @Volatile private var playerZ = 0f
    @Volatile private var radiusBlocks = 0f
    @Volatile private var resetRequested = false

    /** Tiles to add / remove, in order, for the GL thread to apply. */
    val events = LinkedBlockingQueue<FarEvent>()

    /** Distance from the player out to which every wanted tile has been built. */
    @Volatile var coveredRadiusBlocks: Float = 0f
        private set

    private var thread: Thread? = null

    fun start() {
        if (running) return
        running = true
        thread = Thread({ workerLoop() }, "voxel-far").apply {
            isDaemon = true
            start()
        }
    }

    fun shutdown() {
        running = false
        thread?.interrupt()
        thread = null
    }

    /** Cheap; safe to call every frame. [radius] is the render distance in blocks. */
    fun updatePlayer(x: Float, z: Float, radius: Float, enable: Boolean) {
        playerX = x
        playerZ = z
        radiusBlocks = radius
        enabled = enable
    }

    /** The renderer lost its GL objects (context recreated): everything must be rebuilt
     *  and re-sent, since the CPU copies are not kept after upload. */
    fun invalidateAll() {
        resetRequested = true
    }

    // ---- worker ---------------------------------------------------------------------------

    private class Candidate(val level: Int, val tx: Int, val tz: Int, val key: Long, val nearDist: Float)

    private fun workerLoop() {
        try {
            android.os.Process.setThreadPriority(
                android.os.Process.THREAD_PRIORITY_BACKGROUND + android.os.Process.THREAD_PRIORITY_MORE_FAVORABLE
            )
        } catch (t: Throwable) {
            // best effort only
        }

        val built = HashSet<Long>()
        while (running) {
            try {
                if (resetRequested) {
                    resetRequested = false
                    built.clear()
                    events.clear()
                    coveredRadiusBlocks = 0f
                }

                val radius = radiusBlocks
                if (!enabled || radius < 32f) {
                    if (built.isNotEmpty()) {
                        for (k in built) events.put(FarEvent(k, null))
                        built.clear()
                    }
                    coveredRadiusBlocks = 0f
                    Thread.sleep(250)
                    continue
                }

                val px = playerX
                val pz = playerZ
                val wanted = planTiles(px, pz, radius)
                unloadStale(built, px, pz, radius)

                var replan = false
                for (cand in wanted) {
                    if (!running) return
                    if (built.contains(cand.key)) continue

                    // Wanted tiles are sorted nearest-first and every nearer one is already
                    // built, so contiguous coverage ends exactly where this tile begins.
                    coveredRadiusBlocks = cand.nearDist

                    // Backpressure: the GL thread uploads only a couple per frame.
                    while (running && events.size >= MAX_QUEUED_EVENTS) Thread.sleep(4)

                    val tile = buildTile(cand.level, cand.tx, cand.tz)
                    events.put(FarEvent(tile.key, tile))
                    built.add(cand.key)

                    if (resetRequested || !enabled || radiusBlocks != radius ||
                        abs(playerX - px) > REPLAN_DISTANCE || abs(playerZ - pz) > REPLAN_DISTANCE
                    ) {
                        replan = true
                        break
                    }
                }
                if (!replan) {
                    coveredRadiusBlocks = radius
                    Thread.sleep(120)
                }
            } catch (e: InterruptedException) {
                return
            } catch (t: Throwable) {
                // A bad tile must never kill the whole horizon; back off briefly and retry.
                try {
                    Thread.sleep(250)
                } catch (e: InterruptedException) {
                    return
                }
            }
        }
    }

    /** Every tile that must exist for the current position and render distance, across all
     *  levels, nearest first. */
    private fun planTiles(px: Float, pz: Float, radius: Float): ArrayList<Candidate> {
        val out = ArrayList<Candidate>()
        for (level in 0 until LEVELS) {
            val inner = bandInner(level)
            if (inner > radius) break
            val outer = min(bandDrawOuter(level), radius)
            val size = tileBlocks(level)
            val minTx = Math.floorDiv(floor(px - outer).toInt(), size)
            val maxTx = Math.floorDiv(floor(px + outer).toInt(), size)
            val minTz = Math.floorDiv(floor(pz - outer).toInt(), size)
            val maxTz = Math.floorDiv(floor(pz + outer).toInt(), size)
            for (tz in minTz..maxTz) {
                for (tx in minTx..maxTx) {
                    val near = nearestDistance(tx, tz, size, px, pz)
                    if (near > outer) continue
                    if (inner > 0f && farthestDistance(tx, tz, size, px, pz) < inner) continue
                    out.add(Candidate(level, tx, tz, tileKey(level, tx, tz), near))
                }
            }
        }
        out.sortBy { it.nearDist }
        return out
    }

    /** Drops tiles that are well outside their band. The margin (one tile) is the
     *  hysteresis that stops a tile on the edge of a band being rebuilt back and forth. */
    private fun unloadStale(built: HashSet<Long>, px: Float, pz: Float, radius: Float) {
        var stale: ArrayList<Long>? = null
        for (key in built) {
            val level = levelOf(key)
            val size = tileBlocks(level)
            val tx = tileX(key)
            val tz = tileZ(key)
            val near = nearestDistance(tx, tz, size, px, pz)
            val outer = min(bandDrawOuter(level), radius)
            val tooFar = near > outer + size
            val tooNear = bandInner(level) > 0f && farthestDistance(tx, tz, size, px, pz) < bandInner(level) - size
            if (tooFar || tooNear) {
                if (stale == null) stale = ArrayList()
                stale.add(key)
            }
        }
        if (stale != null) {
            for (key in stale) {
                built.remove(key)
                events.put(FarEvent(key, null))
            }
        }
    }

    private fun nearestDistance(tx: Int, tz: Int, size: Int, px: Float, pz: Float): Float {
        val x0 = (tx * size).toFloat()
        val z0 = (tz * size).toFloat()
        val cx = if (px < x0) x0 else if (px > x0 + size) x0 + size else px
        val cz = if (pz < z0) z0 else if (pz > z0 + size) z0 + size else pz
        val dx = px - cx
        val dz = pz - cz
        return sqrt(dx * dx + dz * dz)
    }

    private fun farthestDistance(tx: Int, tz: Int, size: Int, px: Float, pz: Float): Float {
        val x0 = (tx * size).toFloat()
        val z0 = (tz * size).toFloat()
        val dx = max(abs(px - x0), abs(px - (x0 + size)))
        val dz = max(abs(pz - z0), abs(pz - (z0 + size)))
        return sqrt(dx * dx + dz * dz)
    }

    // ---- tile construction ----------------------------------------------------------------

    private fun buildTile(level: Int, tx: Int, tz: Int): FarTile {
        val step = step(level)
        val size = tileBlocks(level)
        val x0 = tx * size
        val z0 = tz * size
        val shape = generator.shape

        // The ground height of every cell (sampled at its centre) plus a one-cell ring around
        // the tile, so the walls along the tile's edges know their neighbours. Array index
        // (i, j) is tile cell (i - 1, j - 1).
        val n = CELLS + 2
        val heights = IntArray(n * n)
        var lowest = Int.MAX_VALUE
        var highest = Int.MIN_VALUE
        for (j in 0 until n) {
            val wz = z0 + (j - 0.5) * step
            for (i in 0 until n) {
                val wx = x0 + (i - 0.5) * step
                val h = floor(shape.height(wx, wz, level)).toInt()
                heights[j * n + i] = h
                if (i in 1..CELLS && j in 1..CELLS) {
                    if (h < lowest) lowest = h
                    if (h > highest) highest = h
                }
            }
        }

        // Ground that is far below the surface is hidden by (near-opaque) deep water, so a
        // tile that is entirely deep ocean needs only its water mesh.
        val hasLand = highest + LAND_Y_OFFSET > WATER_Y - DEEP_WATER
        val hasWater = lowest + LAND_Y_OFFSET < WATER_Y

        var minY = Float.MAX_VALUE
        var maxY = -Float.MAX_VALUE
        val land = if (hasLand) buildLandMesh(level, tx, tz, x0, z0, heights) else MeshData.EMPTY
        if (!land.isEmpty()) {
            minY = land.minY
            maxY = land.maxY
        }
        val water = if (hasWater) buildWaterMesh(level, x0, z0, heights) else MeshData.EMPTY
        if (!water.isEmpty()) {
            minY = min(minY, WATER_Y)
            maxY = max(maxY, WATER_Y)
        }
        if (minY > maxY) {
            minY = WATER_Y
            maxY = WATER_Y
        }
        return FarTile(tileKey(level, tx, tz), land, water, minY, maxY)
    }

    /**
     * The land of one tile as blocky, voxel-style columns: every cell is a flat-topped column
     * at its (whole-block) ground height with vertical walls wherever a neighbour is lower,
     * all in flat colours from the atlas palette. Equal neighbours along a row are merged into
     * one long quad, so flat country costs very little. Level 0 also stands real little trees
     * (a trunk box and a canopy box, at exactly the places the chunk generator will grow them)
     * on the ground; coarser levels raise the cells of forests into a dark canopy layer.
     */
    private fun buildLandMesh(level: Int, tx: Int, tz: Int, x0: Int, z0: Int, heights: IntArray): MeshData {
        val step = step(level)
        val n = CELLS + 2
        val cellCount = n * n
        val topY = FloatArray(cellCount)
        val col = IntArray(cellCount)
        val skip = BooleanArray(cellCount)
        val climate = generator.climate
        val shape = generator.shape
        val sea = WorldConfig.SEA_LEVEL
        val span = 2f * step
        val slopeGain = SLOPE_GAIN[level]
        val deepFloor = WATER_Y - DEEP_WATER

        for (j in 0 until n) {
            val jm = if (j > 0) j - 1 else 0
            val jp = if (j < n - 1) j + 1 else n - 1
            val wz = z0 + (j - 0.5) * step
            for (i in 0 until n) {
                val im = if (i > 0) i - 1 else 0
                val ip = if (i < n - 1) i + 1 else n - 1
                val c = j * n + i
                val h = heights[c]
                val wx = x0 + (i - 0.5) * step
                val groundTop = h + LAND_Y_OFFSET // voxel top face is at h + 1; sit just under it
                topY[c] = groundTop
                if (groundTop <= deepFloor) {
                    skip[c] = true // hidden under deep water
                    continue
                }
                if (h < sea) {
                    val cold = climate.baseTemperature(wx, wz) < Climate.COLD
                    val deep = sea - h > 8
                    val bed = if (deep || cold) TextureAtlas.RAMP_GRAVEL + 1f else TextureAtlas.RAMP_SAND + 2f
                    col[c] = colorKey(TextureAtlas.RAMP_ROW_SURFACE, bed)
                    continue
                }

                val dhdx = (heights[j * n + ip] - heights[j * n + im]) / span
                val dhdz = (heights[jp * n + i] - heights[jm * n + i]) / span
                val slope = max(abs(dhdx), abs(dhdz)) * slopeGain
                val hd = h.toDouble()
                val biome = climate.biome(wx, wz, hd, slope.toDouble(), shape.coastElevation(wx, wz))
                val kind = climate.surfaceFor(biome, wx, wz, hd, slope.toDouble())
                val fx = wx.toFloat()
                val fz = wz.toFloat()
                val forest = climate.forest(wx, wz).toFloat()
                // Large soft patches, so a field of one surface type is not one flat colour.
                val patch = (0.5f + 0.25f * sin(fx * 0.043f + 1.7f) * cos(fz * 0.057f) + 0.25f * sin((fx + fz) * 0.021f))
                    .coerceIn(0f, 1f)
                val t = when (kind) {
                    SurfaceKind.BEACH -> TextureAtlas.RAMP_SAND + (if (h <= sea) 2f else if (h == sea + 1) 1f else 0f)
                    SurfaceKind.GRASS -> TextureAtlas.RAMP_GRASS + 0.3f + patch * 2.0f + forest * 1.9f
                    SurfaceKind.DRY_GRASS -> TextureAtlas.RAMP_DRY + patch * 1.8f + forest * 0.6f
                    SurfaceKind.DESERT -> TextureAtlas.RAMP_DESERT + patch * 2.0f
                    SurfaceKind.SNOW -> TextureAtlas.RAMP_SNOW + patch * 1.8f
                    SurfaceKind.ROCK -> TextureAtlas.RAMP_STONE + patch * 2.0f
                    SurfaceKind.GRAVEL -> TextureAtlas.RAMP_GRAVEL + patch * 2.0f
                }
                col[c] = colorKey(TextureAtlas.RAMP_ROW_SURFACE, t)

                // Coarse levels: forested cells are raised into a canopy layer.
                if (level >= 1 && h >= sea + 2 && generator.treeDensity(biome) > 0.0) {
                    val cover = min(0.92, generator.treeChance(biome, forest.toDouble()) * 2.4)
                    val gx = tx * CELLS + (i - 1)
                    val gz = tz * CELLS + (j - 1)
                    if (cellRandom(gx, gz, level).toDouble() < cover) {
                        val rr = cellRandom(gx, gz, level + 7)
                        val leafBase = when (biome) {
                            Biome.TAIGA, Biome.SNOWY_TAIGA, Biome.SNOWY_PLAINS, Biome.MOUNTAINS -> TextureAtlas.RAMP_SPRUCE_LEAF
                            Biome.BIRCH_FOREST -> TextureAtlas.RAMP_BIRCH_LEAF
                            else -> TextureAtlas.RAMP_OAK_LEAF
                        }
                        val raise = (if (leafBase == TextureAtlas.RAMP_SPRUCE_LEAF) 7f else 4.5f) + 3f * rr
                        topY[c] = groundTop + raise
                        col[c] = colorKey(TextureAtlas.RAMP_ROW_FOLIAGE, leafBase + (if (rr < 0.5f) 0f else 1f))
                    }
                }
            }
        }

        val b = LodBuilder(CELLS * CELLS / 2)
        val sizeF = step.toFloat()

        // Tops, merged into runs along X.
        for (j in 0 until CELLS) {
            val za = (z0 + j * step).toFloat()
            val zb = za + sizeF
            var i = 0
            while (i < CELLS) {
                val c = (j + 1) * n + (i + 1)
                if (skip[c]) {
                    i++
                    continue
                }
                var run = 1
                while (i + run < CELLS) {
                    val c2 = c + run
                    if (skip[c2] || topY[c2] != topY[c] || col[c2] != col[c]) break
                    run++
                }
                val xa = (x0 + i * step).toFloat()
                emitTop(b, xa, xa + run * sizeF, za, zb, topY[c], keyU(col[c]), keyV(col[c]), SHADE_TOP)
                i += run
            }
        }

        // Walls on the edges between row j and row j + 1 (j = -1 is the tile's own edge), merged along X.
        for (j in -1 until CELLS) {
            val z = (z0 + (j + 1) * step).toFloat()
            val aInside = j >= 0
            val bInside = j + 1 < CELLS
            var i = 0
            while (i < CELLS) {
                val a = (j + 1) * n + (i + 1)
                val dir = edgeDir(topY, a, a + n, aInside, bInside)
                if (dir == 0) {
                    i++
                    continue
                }
                val hi = if (dir > 0) a else a + n
                val lo = if (dir > 0) a + n else a
                if (skip[hi]) {
                    i++
                    continue
                }
                var run = 1
                while (i + run < CELLS) {
                    val a2 = a + run
                    if (edgeDir(topY, a2, a2 + n, aInside, bInside) != dir) break
                    val hi2 = if (dir > 0) a2 else a2 + n
                    val lo2 = if (dir > 0) a2 + n else a2
                    if (skip[hi2] || topY[hi2] != topY[hi] || topY[lo2] != topY[lo] || col[hi2] != col[hi]) break
                    run++
                }
                val yt = topY[hi]
                val yb = max(topY[lo], deepFloor)
                if (yt > yb) {
                    val xa = (x0 + i * step).toFloat()
                    val xb = xa + run * sizeF
                    if (dir > 0) {
                        emitWallPosZ(b, z, xa, xb, yb, yt, keyU(col[hi]), keyV(col[hi]), SHADE_Z)
                    } else {
                        emitWallNegZ(b, z, xa, xb, yb, yt, keyU(col[hi]), keyV(col[hi]), SHADE_Z)
                    }
                }
                i += run
            }
        }

        // Walls on the edges between column i and column i + 1, merged along Z.
        for (i in -1 until CELLS) {
            val x = (x0 + (i + 1) * step).toFloat()
            val aInside = i >= 0
            val bInside = i + 1 < CELLS
            var j = 0
            while (j < CELLS) {
                val a = (j + 1) * n + (i + 1)
                val dir = edgeDir(topY, a, a + 1, aInside, bInside)
                if (dir == 0) {
                    j++
                    continue
                }
                val hi = if (dir > 0) a else a + 1
                val lo = if (dir > 0) a + 1 else a
                if (skip[hi]) {
                    j++
                    continue
                }
                var run = 1
                while (j + run < CELLS) {
                    val a2 = a + run * n
                    if (edgeDir(topY, a2, a2 + 1, aInside, bInside) != dir) break
                    val hi2 = if (dir > 0) a2 else a2 + 1
                    val lo2 = if (dir > 0) a2 + 1 else a2
                    if (skip[hi2] || topY[hi2] != topY[hi] || topY[lo2] != topY[lo] || col[hi2] != col[hi]) break
                    run++
                }
                val yt = topY[hi]
                val yb = max(topY[lo], deepFloor)
                if (yt > yb) {
                    val za = (z0 + j * step).toFloat()
                    val zb = za + run * sizeF
                    if (dir > 0) {
                        emitWallPosX(b, x, za, zb, yb, yt, keyU(col[hi]), keyV(col[hi]), SHADE_X)
                    } else {
                        emitWallNegX(b, x, za, zb, yb, yt, keyU(col[hi]), keyV(col[hi]), SHADE_X)
                    }
                }
                j += run
            }
        }

        // Level 0: real trees, where the chunk generator will grow them.
        if (level == 0) {
            for (j in 0 until CELLS) {
                for (i in 0 until CELLS) {
                    val c = (j + 1) * n + (i + 1)
                    if (skip[c] || heights[c] < sea + 1) continue
                    val spot = generator.treeSpot(tx * CELLS + i, tz * CELLS + j) ?: continue
                    emitTree(b, spot, topY[c])
                }
            }
        }
        return b.build()
    }

    /** Which side of the edge between cells [a] and [b] gets a wall: 1 = a's (a is higher and
     *  inside this tile), -1 = b's, 0 = none (level, or the higher cell belongs to the
     *  neighbouring tile, which emits that wall itself). */
    private fun edgeDir(topY: FloatArray, a: Int, b: Int, aInside: Boolean, bInside: Boolean): Int {
        if (topY[a] > topY[b]) return if (aInside) 1 else 0
        if (topY[b] > topY[a]) return if (bInside) -1 else 0
        return 0
    }

    /** Deterministic 0..1 value for a cell of the LOD grid. */
    private fun cellRandom(gx: Int, gz: Int, salt: Int): Float {
        var h = gx * 73856093 xor gz * 19349663 xor salt * 83492791
        h = h xor (h ushr 15)
        h *= 739982445
        h = h xor (h ushr 13)
        return ((h ushr 8) and 0xFFFF) / 65536f
    }

    private fun colorKey(row: Int, column: Float): Int {
        val q = (column * 4f + 0.5f).toInt()
        return row * 256 + (if (q < 0) 0 else if (q > 124) 124 else q)
    }

    private fun keyU(key: Int): Float = TextureAtlas.rampU((key and 255) / 4f)

    private fun keyV(key: Int): Float = TextureAtlas.rampV(key shr 8)

    // Flat-coloured quads, each wound counter-clockwise as seen from outside.

    private fun emitTop(b: LodBuilder, xa: Float, xb: Float, za: Float, zb: Float, y: Float, u: Float, v: Float, shade: Float) {
        b.quad(xa, y, za, xa, y, zb, xb, y, zb, xb, y, za, u, v, shade)
    }

    private fun emitWallPosX(b: LodBuilder, x: Float, za: Float, zb: Float, yb: Float, yt: Float, u: Float, v: Float, shade: Float) {
        b.quad(x, yb, zb, x, yb, za, x, yt, za, x, yt, zb, u, v, shade)
    }

    private fun emitWallNegX(b: LodBuilder, x: Float, za: Float, zb: Float, yb: Float, yt: Float, u: Float, v: Float, shade: Float) {
        b.quad(x, yb, za, x, yb, zb, x, yt, zb, x, yt, za, u, v, shade)
    }

    private fun emitWallPosZ(b: LodBuilder, z: Float, xa: Float, xb: Float, yb: Float, yt: Float, u: Float, v: Float, shade: Float) {
        b.quad(xa, yb, z, xb, yb, z, xb, yt, z, xa, yt, z, u, v, shade)
    }

    private fun emitWallNegZ(b: LodBuilder, z: Float, xa: Float, xb: Float, yb: Float, yt: Float, u: Float, v: Float, shade: Float) {
        b.quad(xb, yb, z, xa, yb, z, xa, yt, z, xb, yt, z, u, v, shade)
    }

    /** An open-bottomed box: a top and four walls. */
    private fun emitBox(
        b: LodBuilder, xa: Float, xb: Float, za: Float, zb: Float, yb: Float, yt: Float, topKey: Int, sideKey: Int
    ) {
        if (yt <= yb) return
        emitTop(b, xa, xb, za, zb, yt, keyU(topKey), keyV(topKey), SHADE_TOP)
        val su = keyU(sideKey)
        val sv = keyV(sideKey)
        emitWallPosX(b, xb, za, zb, yb, yt, su, sv, SHADE_X)
        emitWallNegX(b, xa, za, zb, yb, yt, su, sv, SHADE_X)
        emitWallPosZ(b, zb, xa, xb, yb, yt, su, sv, SHADE_Z)
        emitWallNegZ(b, za, xa, xb, yb, yt, su, sv, SHADE_Z)
    }

    /**
     * One distant tree as boxes: a trunk and a canopy (two stacked canopy boxes for a spruce),
     * sized to match what [com.voxelsandbox.game.world.generation.TreeBuilder] grows.
     * [cellTop] is the LOD ground the tree stands on; the trunk reaches down to it so a tree
     * never floats above the flat cell top on a slope.
     */
    private fun emitTree(b: LodBuilder, spot: TerrainGenerator.TreeSpot, cellTop: Float) {
        val th = spot.th
        val species = spot.species
        val base = spot.ground + 1f
        val x = spot.x.toFloat()
        val z = spot.z.toFloat()
        val variant = ((th ushr 3) and 1).toFloat()
        val bush = species != TreeSpecies.SPRUCE && ((th ushr 20) and 15) == 0
        val leafBase = when (species) {
            TreeSpecies.BIRCH -> TextureAtlas.RAMP_BIRCH_LEAF
            TreeSpecies.SPRUCE -> TextureAtlas.RAMP_SPRUCE_LEAF
            TreeSpecies.OAK -> TextureAtlas.RAMP_OAK_LEAF
        }
        val woodBase = when (species) {
            TreeSpecies.BIRCH -> TextureAtlas.RAMP_BIRCH_WOOD
            TreeSpecies.SPRUCE -> TextureAtlas.RAMP_SPRUCE_WOOD
            TreeSpecies.OAK -> TextureAtlas.RAMP_OAK_WOOD
        }
        val topKey = colorKey(TextureAtlas.RAMP_ROW_FOLIAGE, leafBase + variant)
        val sideKey = colorKey(TextureAtlas.RAMP_ROW_FOLIAGE, leafBase + 1f + variant)
        val woodKey = colorKey(TextureAtlas.RAMP_ROW_FOLIAGE, woodBase)
        val bigOak = species == TreeSpecies.OAK && ((th ushr 24) and 7) == 0
        val trunk = when {
            bush -> 1
            species == TreeSpecies.BIRCH -> 6 + ((th ushr 4) % 4)
            species == TreeSpecies.SPRUCE -> 7 + ((th ushr 4) % 7)
            bigOak -> 7 + ((th ushr 4) % 3)
            else -> 5 + ((th ushr 4) % 4)
        }

        if (!bush) {
            emitBox(b, x, x + 1f, z, z + 1f, min(base - 0.25f, cellTop), base + trunk, woodKey, woodKey)
        }
        val cx = x + 0.5f
        val cz = z + 0.5f
        val tf = trunk.toFloat()
        when {
            bush -> emitBox(b, cx - 1.5f, cx + 1.5f, cz - 1.5f, cz + 1.5f, base, base + 3f, topKey, sideKey)
            species == TreeSpecies.SPRUCE -> {
                emitBox(b, cx - 3.25f, cx + 3.25f, cz - 3.25f, cz + 3.25f, base + 2f, base + tf - 4f, topKey, sideKey)
                emitBox(b, cx - 1.7f, cx + 1.7f, cz - 1.7f, cz + 1.7f, base + tf - 4f, base + tf + 1f, topKey, sideKey)
            }
            species == TreeSpecies.BIRCH ->
                emitBox(b, cx - 2f, cx + 2f, cz - 2f, cz + 2f, base + tf - 4f, base + tf + 1f, topKey, sideKey)
            bigOak ->
                emitBox(b, cx - 3.5f, cx + 3.5f, cz - 3.5f, cz + 3.5f, base + tf - 4f, base + tf + 1f, topKey, sideKey)
            else ->
                emitBox(b, cx - 2.5f, cx + 2.5f, cz - 2.5f, cz + 2.5f, base + tf - 4f, base + tf + 1f, topKey, sideKey)
        }
    }

    /** The sea / lake / river surface of a tile: a flat grid at [WATER_Y] whose vertices
     *  carry the depth of the ground below (averaged over the four cells that meet there),
     *  and only the cells that touch water. */
    private fun buildWaterMesh(level: Int, x0: Int, z0: Int, heights: IntArray): MeshData {
        val step = step(level)
        val n = CELLS + 2
        val vertexData = FloatArray(VERTS * VERTS * MeshData.FLOATS_PER_VERTEX)
        val depths = FloatArray(VERTS * VERTS)
        var vi = 0
        for (j in 0 until VERTS) {
            for (i in 0 until VERTS) {
                // The four cells meeting at vertex (i, j) are array cells (i, j) .. (i + 1, j + 1).
                val c = j * n + i
                val depth = (cellDepth(heights[c]) + cellDepth(heights[c + 1]) +
                    cellDepth(heights[c + n]) + cellDepth(heights[c + n + 1])) * 0.25f
                depths[j * VERTS + i] = depth
                vertexData[vi++] = (x0 + i * step).toFloat()
                vertexData[vi++] = WATER_Y
                vertexData[vi++] = (z0 + j * step).toFloat()
                vertexData[vi++] = depth // the water shader reads depth from the "u" slot
                vertexData[vi++] = 0f
                vertexData[vi++] = 1f
            }
        }

        val indices = IntArray(CELLS * CELLS * 6)
        var ii = 0
        for (j in 0 until CELLS) {
            for (i in 0 until CELLS) {
                val a = j * VERTS + i
                val b = a + 1
                val d = a + VERTS
                val c = d + 1
                if (depths[a] <= 0f && depths[b] <= 0f && depths[c] <= 0f && depths[d] <= 0f) continue
                indices[ii++] = a; indices[ii++] = c; indices[ii++] = b
                indices[ii++] = a; indices[ii++] = d; indices[ii++] = c
            }
        }
        if (ii == 0) return MeshData.EMPTY
        return MeshData(vertexData, indices.copyOf(ii), VERTS * VERTS, WATER_Y, WATER_Y)
    }

    private fun cellDepth(h: Int): Float = (WATER_Y - (h + LAND_Y_OFFSET)).coerceIn(0f, DEEP_WATER)

    companion object {
        /** Number of detail levels (0 = finest). */
        const val LEVELS = 4

        /** Every tile is CELLS x CELLS columns whatever its level. */
        const val CELLS = 64
        const val VERTS = CELLS + 1

        /** Column size and tile edge of level 0, in blocks. Each level doubles both. */
        const val BASE_STEP = 4
        const val BASE_TILE_BLOCKS = BASE_STEP * CELLS // 256

        fun step(level: Int): Int = BASE_STEP shl level
        fun tileBlocks(level: Int): Int = BASE_TILE_BLOCKS shl level

        /** Nominal outer edge of each level's distance band, in blocks from the player. The
         *  last level has no outer edge (it reaches the render distance). */
        private val BAND_OUTER = floatArrayOf(512f, 1024f, 2048f, 1.0e9f)

        /** How far past its nominal edge a level keeps drawing so the next, coarser level
         *  can blend in underneath (see the class comment). */
        private val BAND_OVERLAP = floatArrayOf(32f, 64f, 128f, 0f)

        /** Distance at which a level's band starts (level 0 starts at the voxel terrain). */
        fun bandInner(level: Int): Float = if (level == 0) 0f else BAND_OUTER[level - 1]

        /** Nominal outer edge of the band; water (flat, so seam-free) is clipped exactly here. */
        fun bandOuter(level: Int): Float = BAND_OUTER[level]

        /** Outer edge for land, including the overlap. */
        fun bandDrawOuter(level: Int): Float = BAND_OUTER[level] + BAND_OVERLAP[level]

        /** Length of the overlap zone at the start of a (coarser) level's band. */
        fun bandOverlapAtStart(level: Int): Float = if (level == 0) 0f else BAND_OVERLAP[level - 1]

        /** Far-terrain slopes are measured over a coarser baseline than the voxel terrain's,
         *  which smooths them; these gains restore the rock / scree coverage the voxel
         *  generator would give, so a mountainside keeps its colour with distance. */
        private val SLOPE_GAIN = floatArrayOf(1.2f, 1.5f, 1.9f, 2.7f)

        /** Voxel water surfaces sit at SEA_LEVEL + 0.875 (see ChunkMesher). */
        const val WATER_Y = WorldConfig.SEA_LEVEL + 0.875f

        /** Land vertices sit this far above the top block's floor: just under the voxel top
         *  face (which is at +1), so real voxel terrain always wins where both exist. */
        private const val LAND_Y_OFFSET = 0.75f

        /** Water at least this deep is drawn (near-)opaque, so ground beneath it is skipped. */
        private const val DEEP_WATER = 10f

        private const val MAX_QUEUED_EVENTS = 12

        // Shading of the flat-coloured columns: tops like a voxel top face, walls like voxel sides.
        private const val SHADE_TOP = 0.97f
        private const val SHADE_Z = 0.80f
        private const val SHADE_X = 0.68f
        private const val REPLAN_DISTANCE = 24f

        // Fixed light direction (normalised) used to shade slopes: the sun (see Atmosphere)
        // pulled toward straight up, so flat ground comes out as bright as a voxel top face.
        private const val LIGHT_X = 0.29f
        private const val LIGHT_Y = 0.89f
        private const val LIGHT_Z = -0.35f

        // Tile key = level (3 bits) | tx (29 bits, signed) | tz (29 bits, signed).
        private const val COORD_MASK = 0x1FFFFFFFL

        fun tileKey(level: Int, tx: Int, tz: Int): Long =
            (level.toLong() shl 58) or ((tx.toLong() and COORD_MASK) shl 29) or (tz.toLong() and COORD_MASK)

        fun levelOf(key: Long): Int = (key ushr 58).toInt()
        fun tileX(key: Long): Int = (((key ushr 29) and COORD_MASK).toInt() shl 3) shr 3
        fun tileZ(key: Long): Int = ((key and COORD_MASK).toInt() shl 3) shr 3
    }
}

/** Collects flat-coloured quads (all four vertices share one palette colour and shade) for a
 *  distant-terrain tile. Same vertex layout as the voxel meshes: position, uv, shade. */
private class LodBuilder(initialQuads: Int) {
    private var floats = FloatArray(initialQuads * 4 * MeshData.FLOATS_PER_VERTEX)
    private var indices = IntArray(initialQuads * 6)
    private var verts = 0
    private var idx = 0
    private var minY = Float.MAX_VALUE
    private var maxY = -Float.MAX_VALUE

    /** One quad; (0,1,2) and (0,2,3) must be counter-clockwise seen from the front. */
    fun quad(
        x0: Float, y0: Float, z0: Float,
        x1: Float, y1: Float, z1: Float,
        x2: Float, y2: Float, z2: Float,
        x3: Float, y3: Float, z3: Float,
        u: Float, v: Float, shade: Float
    ) {
        val stride = MeshData.FLOATS_PER_VERTEX
        if ((verts + 4) * stride > floats.size) floats = floats.copyOf(max(floats.size * 2, (verts + 4) * stride))
        if (idx + 6 > indices.size) indices = indices.copyOf(max(indices.size * 2, idx + 6))
        val f = floats
        var i = verts * stride
        f[i++] = x0; f[i++] = y0; f[i++] = z0; f[i++] = u; f[i++] = v; f[i++] = shade
        f[i++] = x1; f[i++] = y1; f[i++] = z1; f[i++] = u; f[i++] = v; f[i++] = shade
        f[i++] = x2; f[i++] = y2; f[i++] = z2; f[i++] = u; f[i++] = v; f[i++] = shade
        f[i++] = x3; f[i++] = y3; f[i++] = z3; f[i++] = u; f[i++] = v; f[i] = shade
        val ix = indices
        ix[idx++] = verts; ix[idx++] = verts + 1; ix[idx++] = verts + 2
        ix[idx++] = verts; ix[idx++] = verts + 2; ix[idx++] = verts + 3
        verts += 4
        if (y0 < minY) minY = y0
        if (y1 < minY) minY = y1
        if (y2 < minY) minY = y2
        if (y3 < minY) minY = y3
        if (y0 > maxY) maxY = y0
        if (y1 > maxY) maxY = y1
        if (y2 > maxY) maxY = y2
        if (y3 > maxY) maxY = y3
    }

    fun build(): MeshData {
        if (verts == 0) return MeshData.EMPTY
        return MeshData(
            floats.copyOf(verts * MeshData.FLOATS_PER_VERTEX),
            indices.copyOf(idx),
            verts,
            minY,
            maxY
        )
    }
}
