package com.voxelsandbox.game

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.FrameLayout
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.ScrollView
import android.widget.TextView
import com.voxelsandbox.game.crash.CrashReporter
import com.voxelsandbox.game.engine.GameEngine
import com.voxelsandbox.game.gl.DepthConfigChooser
import com.voxelsandbox.game.gl.GameRenderer
import com.voxelsandbox.game.save.LoadedSave
import com.voxelsandbox.game.save.SaveManager
import com.voxelsandbox.game.settings.GameSettings
import com.voxelsandbox.game.settings.GraphicsQuality
import com.voxelsandbox.game.ui.HudController
import com.voxelsandbox.game.world.WorldConfig
import java.util.concurrent.Executors

/**
 * The app's only Activity. Gameplay screens (main menu / loading / playing / paused /
 * settings) are overlay Views toggled on one root layout rather than separate
 * Activities, so the GL context and world state never need to survive an Activity
 * transition — only a much simpler show/hide of a few FrameLayouts.
 */
class GameActivity : Activity() {

    private enum class Screen { MAIN_MENU, LOADING, PLAYING, PAUSED, SETTINGS }

    private lateinit var settings: GameSettings
    private lateinit var saveManager: SaveManager
    private val ioExecutor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    private var glSurfaceView: GLSurfaceView? = null
    private var renderer: GameRenderer? = null
    private var engine: GameEngine? = null
    private var hud: HudController? = null

    private var currentScreen = Screen.MAIN_MENU
    private var settingsOpenedFrom = Screen.MAIN_MENU

    private lateinit var glContainer: FrameLayout
    private lateinit var mainMenuOverlay: View
    private lateinit var pauseOverlay: View
    private lateinit var settingsOverlay: View
    private lateinit var loadingOverlay: View
    private lateinit var hudOverlay: View

    private lateinit var seekRenderDistance: SeekBar
    private lateinit var seekDetailDistance: SeekBar
    private lateinit var textRenderDistance: TextView
    private lateinit var textDetailDistance: TextView
    private lateinit var switchFarTerrain: Switch
    private lateinit var spinnerGraphicsQuality: Spinner
    private lateinit var seekTouchSensitivity: SeekBar
    private lateinit var seekLookSensitivity: SeekBar
    private lateinit var switchFps: Switch
    private lateinit var switchBobbing: Switch
    private lateinit var switchClouds: Switch
    private lateinit var switchParticles: Switch
    private lateinit var switchAutoJump: Switch
    private lateinit var switchAdaptiveDistance: Switch
    private lateinit var switchCreative: Switch
    private lateinit var seekFlySpeed: SeekBar
    private lateinit var textFlySpeed: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        CrashReporter.install(this) // first line, deliberately before super.onCreate — see CrashReporter kdoc
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game)

        settings = GameSettings(this)
        saveManager = SaveManager(this)

        glContainer = findViewById(R.id.gl_container)
        mainMenuOverlay = findViewById(R.id.main_menu_overlay)
        pauseOverlay = findViewById(R.id.pause_overlay)
        settingsOverlay = findViewById(R.id.settings_overlay)
        loadingOverlay = findViewById(R.id.loading_overlay)
        hudOverlay = findViewById(R.id.hud_overlay)

        findViewById<Button>(R.id.btn_new_world).setOnClickListener { startNewWorld() }
        findViewById<Button>(R.id.btn_continue_world).setOnClickListener { continueWorld() }
        findViewById<Button>(R.id.btn_menu_settings).setOnClickListener { openSettings(Screen.MAIN_MENU) }
        findViewById<Button>(R.id.btn_exit).setOnClickListener { finish() }
        setUpCrashReportButton()

        findViewById<Button>(R.id.btn_resume).setOnClickListener { resumeFromPause() }
        findViewById<Button>(R.id.btn_pause_settings).setOnClickListener { openSettings(Screen.PAUSED) }
        findViewById<Button>(R.id.btn_customize_hud).setOnClickListener { customizeHud() }
        findViewById<Button>(R.id.btn_save_quit).setOnClickListener { saveAndQuitToMenu() }

        findViewById<Button>(R.id.btn_settings_back).setOnClickListener { closeSettings() }
        findViewById<Button>(R.id.btn_settings_apply).setOnClickListener { applySettings(); closeSettings() }

        setupSettingsControls()
        showScreen(Screen.MAIN_MENU)
    }

    /** Shows the (normally hidden) "View Last Crash Report" button on the main menu
     *  only when CrashReporter found a report from the previous run, and wires it to
     *  a dialog with the report as selectable text plus a Copy button — there's no
     *  ADB on this workflow, so a way to get the text onto the clipboard and out of
     *  the phone (into a chat message, a note, etc.) is the whole point. */
    private fun setUpCrashReportButton() {
        val report = CrashReporter.readPendingCrash(this) ?: return
        val button = findViewById<Button>(R.id.btn_crash_report)
        button.visibility = View.VISIBLE
        button.setOnClickListener {
            val textView = TextView(this).apply {
                text = report
                setTextIsSelectable(true) // NOT a Kotlin property: getter/setter names
                // are asymmetric (isTextSelectable()/setTextIsSelectable()), so
                // Kotlin can't synthesize "textIsSelectable" — this exact mismatch
                // is what broke the last build (compileReleaseKotlin: "Unresolved
                // reference: textIsSelectable").
                setPadding(40, 32, 40, 32)
            }
            AlertDialog.Builder(this)
                .setTitle(R.string.view_crash_report)
                .setView(ScrollView(this).apply { addView(textView) })
                .setPositiveButton("Copy") { _, _ ->
                    val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                    clipboard.setPrimaryClip(ClipData.newPlainText("Crash report", report))
                }
                .setNegativeButton("Dismiss") { _, _ ->
                    CrashReporter.clearPendingCrash(this)
                    button.visibility = View.GONE
                }
                .setCancelable(true)
                .show()
        }
    }

    // ---- Screen management ------------------------------------------------------

    private fun showScreen(screen: Screen) {
        currentScreen = screen
        mainMenuOverlay.visibility = if (screen == Screen.MAIN_MENU) View.VISIBLE else View.GONE
        loadingOverlay.visibility = if (screen == Screen.LOADING) View.VISIBLE else View.GONE
        pauseOverlay.visibility = if (screen == Screen.PAUSED) View.VISIBLE else View.GONE
        settingsOverlay.visibility = if (screen == Screen.SETTINGS) View.VISIBLE else View.GONE
        hudOverlay.visibility = if (screen == Screen.PLAYING) View.VISIBLE else View.GONE
        renderer?.paused = (screen != Screen.PLAYING)

        if (screen == Screen.MAIN_MENU) {
            findViewById<Button>(R.id.btn_continue_world).isEnabled = saveManager.hasSave()
        }
    }

    private fun startNewWorld() {
        createEngineAndPlay(null)
    }

    private fun continueWorld() {
        showScreen(Screen.LOADING)
        ioExecutor.execute {
            val loaded = saveManager.load()
            mainHandler.post { createEngineAndPlay(loaded) }
        }
    }

    private fun createEngineAndPlay(loaded: LoadedSave?) {
        teardownEngine()

        val newEngine = GameEngine(settings, loaded)
        engine = newEngine

        val gl = GLSurfaceView(this).apply {
            setEGLContextClientVersion(3)
            setEGLConfigChooser(DepthConfigChooser()) // must precede setRenderer
            preserveEGLContextOnPause = true
        }
        applyResolutionScale(gl, settings.graphicsQuality)
        val newRenderer = GameRenderer(newEngine) { statsText -> onPeriodicTick(statsText) }
        gl.setRenderer(newRenderer)
        renderer = newRenderer
        glContainer.removeAllViews()
        glContainer.addView(gl)
        glSurfaceView = gl

        hud = HudController(
            hudOverlay, newEngine.input, newEngine.inventory,
            onPause = { pauseGame() },
            onCreativeToggle = { toggleCreative() }
        )
        hud?.setCreativeUi(settings.creativeMode, settings.creativeMode)
        showScreen(Screen.PLAYING)
    }

    private fun onPeriodicTick(statsText: String?) {
        val h = hud ?: return
        if (statsText != null) {
            h.debugText.visibility = View.VISIBLE
            h.debugText.text = statsText
        } else {
            h.debugText.visibility = View.GONE
        }
        h.refreshHotbar()
        val e = engine
        if (e != null) {
            h.statusText.text = e.statusLine()
            h.statusText.visibility = View.VISIBLE
            h.setCreativeUi(settings.creativeMode, e.player.flying)
        }
    }

    /** The star button on the HUD: switches creative mode on (flight starts) or off. */
    private fun toggleCreative() {
        settings.creativeMode = !settings.creativeMode
        settings.persist()
        hud?.setCreativeUi(settings.creativeMode, settings.creativeMode)
    }

    private fun pauseGame() {
        hud?.releaseAllInputs()
        hud?.exitCustomizeMode() // safety net: never carry a frozen edit session into the pause menu
        showScreen(Screen.PAUSED)
    }

    private fun resumeFromPause() {
        showScreen(Screen.PLAYING)
    }

    private fun customizeHud() {
        resumeFromPause() // same transition Resume uses; edit mode overlays live gameplay
        hud?.enterCustomizeMode()
    }

    private fun openSettings(from: Screen) {
        settingsOpenedFrom = from
        loadSettingsIntoControls()
        showScreen(Screen.SETTINGS)
    }

    private fun closeSettings() {
        showScreen(settingsOpenedFrom)
    }

    private fun saveAndQuitToMenu() {
        val eng = engine ?: return
        showScreen(Screen.LOADING)
        eng.worldManager.shutdown() // stop background gen/mesh so the save snapshot is stable
        ioExecutor.execute {
            try {
                saveManager.save(eng.seed, eng.player, eng.inventory, eng.world)
            } catch (t: Throwable) {
                // Best-effort: failing to save shouldn't trap the player outside the menu.
            }
            mainHandler.post {
                teardownEngine()
                showScreen(Screen.MAIN_MENU)
            }
        }
    }

    private fun teardownEngine() {
        glSurfaceView?.onPause()
        engine?.shutdown()
        glContainer.removeAllViews()
        glSurfaceView = null
        renderer = null
        engine = null
        hud = null
    }

    /** Graphics Quality's main lever: renders into a smaller GL surface buffer than
     *  the physical screen and lets the compositor upscale it, trading a little
     *  sharpness for a roughly quadratic drop in fragment/fill-rate GPU cost — see
     *  GraphicsQuality.resolutionScale. setFixedSize can be called on an existing,
     *  already-visible surface too (triggering a fresh onSurfaceChanged with the new
     *  size), so this also covers changing the setting mid-game via applySettings,
     *  not just the initial size at surface creation. */
    private fun applyResolutionScale(gl: GLSurfaceView, quality: GraphicsQuality) {
        val dm = resources.displayMetrics
        val w = (dm.widthPixels * quality.resolutionScale).toInt().coerceAtLeast(1)
        val h = (dm.heightPixels * quality.resolutionScale).toInt().coerceAtLeast(1)
        gl.holder.setFixedSize(w, h)
    }

    // ---- Settings screen ----------------------------------------------------------

    private fun setupSettingsControls() {
        seekRenderDistance = findViewById(R.id.seek_render_distance)
        seekDetailDistance = findViewById(R.id.seek_detail_distance)
        textRenderDistance = findViewById(R.id.text_render_distance)
        textDetailDistance = findViewById(R.id.text_detail_distance)
        switchFarTerrain = findViewById(R.id.switch_far_terrain)
        spinnerGraphicsQuality = findViewById(R.id.spinner_graphics_quality)
        seekTouchSensitivity = findViewById(R.id.seek_touch_sensitivity)
        seekLookSensitivity = findViewById(R.id.seek_look_sensitivity)
        switchFps = findViewById(R.id.switch_fps)
        switchBobbing = findViewById(R.id.switch_bobbing)
        switchClouds = findViewById(R.id.switch_clouds)
        switchParticles = findViewById(R.id.switch_particles)
        switchAutoJump = findViewById(R.id.switch_auto_jump)
        switchAdaptiveDistance = findViewById(R.id.switch_adaptive_distance)
        switchCreative = findViewById(R.id.switch_creative)
        seekFlySpeed = findViewById(R.id.seek_fly_speed)
        textFlySpeed = findViewById(R.id.text_fly_speed)
        seekFlySpeed.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                updateFlySpeedLabel()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}

            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        seekRenderDistance.max = GameSettings.MAX_RENDER_CHUNKS - GameSettings.MIN_RENDER_CHUNKS
        seekDetailDistance.max = GameSettings.MAX_DETAIL_CHUNKS - GameSettings.MIN_DETAIL_CHUNKS
        val labelUpdater = object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                updateDistanceLabels()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}

            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        }
        seekRenderDistance.setOnSeekBarChangeListener(labelUpdater)
        seekDetailDistance.setOnSeekBarChangeListener(labelUpdater)
        // With the distant terrain off, the voxel chunks must cover the whole render
        // distance themselves, so a separate detail distance no longer means anything.
        switchFarTerrain.setOnCheckedChangeListener { _, checked ->
            seekDetailDistance.isEnabled = checked
            updateDistanceLabels()
        }
        spinnerGraphicsQuality.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            GraphicsQuality.values().map { it.label }
        )
    }

    /** Fly speed on the settings slider: 0..100 maps exponentially onto MIN..MAX blocks/s. */
    private fun flySpeedFromProgress(progress: Int): Float =
        GameSettings.MIN_FLY_SPEED *
            Math.pow((GameSettings.MAX_FLY_SPEED / GameSettings.MIN_FLY_SPEED).toDouble(), progress / 100.0).toFloat()

    private fun progressFromFlySpeed(speed: Float): Int =
        (Math.log((speed / GameSettings.MIN_FLY_SPEED).toDouble()) /
            Math.log((GameSettings.MAX_FLY_SPEED / GameSettings.MIN_FLY_SPEED).toDouble()) * 100.0).toInt().coerceIn(0, 100)

    private fun updateFlySpeedLabel() {
        textFlySpeed.text = getString(R.string.fly_speed_value, flySpeedFromProgress(seekFlySpeed.progress).toInt())
    }

    private fun updateDistanceLabels() {
        val render = GameSettings.MIN_RENDER_CHUNKS + seekRenderDistance.progress
        val detail = GameSettings.MIN_DETAIL_CHUNKS + seekDetailDistance.progress
        textRenderDistance.text = getString(R.string.render_distance_value, render, render * WorldConfig.CHUNK_SIZE)
        textDetailDistance.text = getString(R.string.detail_distance_value, detail)
    }

    private fun loadSettingsIntoControls() {
        seekRenderDistance.progress = settings.renderDistanceChunks - GameSettings.MIN_RENDER_CHUNKS
        seekDetailDistance.progress = settings.detailDistanceChunks - GameSettings.MIN_DETAIL_CHUNKS
        switchFarTerrain.isChecked = settings.farTerrain
        seekDetailDistance.isEnabled = settings.farTerrain
        updateDistanceLabels()
        spinnerGraphicsQuality.setSelection(settings.graphicsQuality.ordinal)
        seekTouchSensitivity.progress = (settings.touchSensitivity * 100).toInt()
        seekLookSensitivity.progress = (settings.lookSensitivity * 100).toInt()
        switchFps.isChecked = settings.showFps
        switchBobbing.isChecked = settings.viewBobbing
        switchClouds.isChecked = settings.cloudsEnabled
        switchParticles.isChecked = settings.particlesEnabled
        switchAutoJump.isChecked = settings.autoJump
        switchAdaptiveDistance.isChecked = settings.adaptiveDistance
        switchCreative.isChecked = settings.creativeMode
        seekFlySpeed.progress = progressFromFlySpeed(settings.flySpeed)
        updateFlySpeedLabel()
    }

    private fun applySettings() {
        settings.renderDistanceChunks = GameSettings.MIN_RENDER_CHUNKS + seekRenderDistance.progress
        settings.detailDistanceChunks = GameSettings.MIN_DETAIL_CHUNKS + seekDetailDistance.progress
        settings.farTerrain = switchFarTerrain.isChecked
        val newQuality = GraphicsQuality.fromOrdinalSafe(spinnerGraphicsQuality.selectedItemPosition)
        val qualityChanged = newQuality != settings.graphicsQuality
        settings.graphicsQuality = newQuality
        settings.touchSensitivity = seekTouchSensitivity.progress / 100f
        settings.lookSensitivity = seekLookSensitivity.progress / 100f
        settings.showFps = switchFps.isChecked
        settings.viewBobbing = switchBobbing.isChecked
        settings.cloudsEnabled = switchClouds.isChecked
        settings.particlesEnabled = switchParticles.isChecked
        settings.autoJump = switchAutoJump.isChecked
        settings.adaptiveDistance = switchAdaptiveDistance.isChecked
        settings.creativeMode = switchCreative.isChecked
        settings.flySpeed = flySpeedFromProgress(seekFlySpeed.progress)
        settings.persist()
        hud?.setCreativeUi(settings.creativeMode, settings.creativeMode && (engine?.player?.flying ?: true))
        if (!settings.showFps) hud?.debugText?.visibility = View.GONE
        if (qualityChanged) glSurfaceView?.let { applyResolutionScale(it, newQuality) }
    }

    // ---- Lifecycle ------------------------------------------------------------

    override fun onResume() {
        super.onResume()
        glSurfaceView?.onResume()
        hideSystemBars()
    }

    override fun onPause() {
        super.onPause()
        glSurfaceView?.onPause()
        if (currentScreen == Screen.PLAYING) {
            hud?.releaseAllInputs()
            hud?.exitCustomizeMode()
            showScreen(Screen.PAUSED)
        }
        autoSaveIfActive()
    }

    override fun onDestroy() {
        super.onDestroy()
        engine?.shutdown()
        ioExecutor.shutdown()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        when (currentScreen) {
            Screen.PLAYING -> pauseGame()
            Screen.PAUSED -> resumeFromPause()
            Screen.SETTINGS -> closeSettings()
            Screen.LOADING -> { /* ignore back while a load/save is in flight */ }
            Screen.MAIN_MENU -> super.onBackPressed()
        }
    }

    private fun autoSaveIfActive() {
        val eng = engine ?: return
        ioExecutor.execute {
            try {
                saveManager.save(eng.seed, eng.player, eng.inventory, eng.world)
            } catch (t: Throwable) {
                // Best-effort autosave on backgrounding; never let this crash the app.
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun hideSystemBars() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            )
    }
}
