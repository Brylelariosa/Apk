package com.voxelsandbox.game.world.mesh

import com.voxelsandbox.game.gl.TextureAtlas
import com.voxelsandbox.game.world.BlockType
import com.voxelsandbox.game.world.Chunk
import com.voxelsandbox.game.world.ChunkPos
import com.voxelsandbox.game.world.Face
import com.voxelsandbox.game.world.World
import com.voxelsandbox.game.world.WorldConfig

class MeshData(
    val vertexData: FloatArray,
    val indices: IntArray,
    val vertexCount: Int,
    /** Lowest / highest world-space Y of any vertex. Lets the renderer build a tight
     *  frustum-culling box per column instead of always testing the full world height. */
    val minY: Float = 0f,
    val maxY: Float = 0f
) {
    fun isEmpty(): Boolean = vertexCount == 0

    companion object {
        val EMPTY = MeshData(FloatArray(0), IntArray(0), 0)

        /** Floats per vertex in [vertexData]: position(3) + uv(2) + shade(1). Public
         *  (unlike MeshBuilder's private copy of the same number) so GameRenderer can
         *  correctly concatenate multiple subchunks' MeshData into one combined
         *  per-column buffer without duplicating/guessing the stride. */
        const val FLOATS_PER_VERTEX = 6
    }
}

/** The two layers one subchunk is drawn in: opaque / alpha-cut terrain, and the
 *  translucent water surface (drawn afterwards by its own animated shader). */
class SubChunkMesh(val solid: MeshData, val water: MeshData) {
    fun isEmpty(): Boolean = solid.isEmpty() && water.isEmpty()

    companion object {
        val EMPTY = SubChunkMesh(MeshData.EMPTY, MeshData.EMPTY)
    }
}

/** Interleaved vertex layout: position(3) + uv(2) + shade(1) = 6 floats/vertex. Kept
 *  private to this file — nothing outside the mesher needs to know the layout details,
 *  only the resulting MeshData.
 *
 *  One builder is kept per mesh-worker thread and reset between jobs (see
 *  ChunkMesher.builders): its arrays only ever grow to the high-water mark of the
 *  biggest subchunk that thread has meshed, instead of every job re-growing fresh
 *  arrays from 128 vertices by repeated doubling (~3x the final size in garbage). */
private class MeshBuilder(initialVerts: Int = 1024) {
    companion object { const val FLOATS_PER_VERTEX = 6 }

    private var floats = FloatArray(initialVerts * FLOATS_PER_VERTEX)
    private var indices = IntArray(initialVerts * 3 / 2)
    private var vertCount = 0
    private var indexCount = 0
    private var minY = Float.MAX_VALUE
    private var maxY = -Float.MAX_VALUE

    fun reset() {
        vertCount = 0
        indexCount = 0
        minY = Float.MAX_VALUE
        maxY = -Float.MAX_VALUE
    }

    /** Emits one quad (4 vertices, 2 triangles). Vertices are v0..v3 in the order given;
     *  uv rect corners map to them as v0=(u0,va) v1=(u1,va) v2=(u1,vb) v3=(u0,vb), so a
     *  caller passes va/vb swapped to flip a texture vertically.
     *
     *  [flip] reverses the triangle winding without touching vertex positions or UVs,
     *  which is how TOP/BOTTOM faces get the same counter-clockwise-from-outside winding
     *  the four side faces are already authored with (see ChunkMesher) so back-face
     *  culling can be on. [altDiagonal] splits the quad along v1-v3 instead of v0-v2;
     *  the mesher picks whichever diagonal passes through the darker corners so ambient-
     *  occlusion gradients don't turn into visible triangle seams. */
    fun quad(
        x0: Float, y0: Float, z0: Float,
        x1: Float, y1: Float, z1: Float,
        x2: Float, y2: Float, z2: Float,
        x3: Float, y3: Float, z3: Float,
        u0: Float, va: Float, u1: Float, vb: Float,
        s0: Float, s1: Float, s2: Float, s3: Float,
        flip: Boolean,
        altDiagonal: Boolean
    ) {
        reserve()
        val f = floats
        var i = vertCount * FLOATS_PER_VERTEX
        f[i++] = x0; f[i++] = y0; f[i++] = z0; f[i++] = u0; f[i++] = va; f[i++] = s0
        f[i++] = x1; f[i++] = y1; f[i++] = z1; f[i++] = u1; f[i++] = va; f[i++] = s1
        f[i++] = x2; f[i++] = y2; f[i++] = z2; f[i++] = u1; f[i++] = vb; f[i++] = s2
        f[i++] = x3; f[i++] = y3; f[i++] = z3; f[i++] = u0; f[i++] = vb; f[i] = s3
        finishQuad(y0, y1, y2, y3, flip, altDiagonal)
    }

    /** Emits one water-surface quad (always an upward-facing TOP face, so wound like one).
     *  Water has no texture: the "u" slot of each vertex carries the water depth below it
     *  (in blocks), which the water shader turns into colour and opacity, and the shade
     *  slot is a constant 1. */
    fun waterQuad(
        x0: Float, y0: Float, z0: Float, d0: Float,
        x1: Float, y1: Float, z1: Float, d1: Float,
        x2: Float, y2: Float, z2: Float, d2: Float,
        x3: Float, y3: Float, z3: Float, d3: Float,
        altDiagonal: Boolean
    ) {
        reserve()
        val f = floats
        var i = vertCount * FLOATS_PER_VERTEX
        f[i++] = x0; f[i++] = y0; f[i++] = z0; f[i++] = d0; f[i++] = 0f; f[i++] = 1f
        f[i++] = x1; f[i++] = y1; f[i++] = z1; f[i++] = d1; f[i++] = 0f; f[i++] = 1f
        f[i++] = x2; f[i++] = y2; f[i++] = z2; f[i++] = d2; f[i++] = 0f; f[i++] = 1f
        f[i++] = x3; f[i++] = y3; f[i++] = z3; f[i++] = d3; f[i++] = 0f; f[i] = 1f
        finishQuad(y0, y1, y2, y3, true, altDiagonal)
    }

    private fun reserve() {
        val neededFloats = (vertCount + 4) * FLOATS_PER_VERTEX
        if (neededFloats > floats.size) floats = floats.copyOf(maxOf(floats.size * 2, neededFloats))
        val neededIdx = indexCount + 6
        if (neededIdx > indices.size) indices = indices.copyOf(maxOf(indices.size * 2, neededIdx))
    }

    /** Writes the two triangles for the 4 vertices just stored and updates the Y bounds. */
    private fun finishQuad(y0: Float, y1: Float, y2: Float, y3: Float, flip: Boolean, altDiagonal: Boolean) {
        val lo = minOf(minOf(y0, y1), minOf(y2, y3))
        val hi = maxOf(maxOf(y0, y1), maxOf(y2, y3))
        if (lo < minY) minY = lo
        if (hi > maxY) maxY = hi

        val b = vertCount
        val ix = indices
        var k = indexCount
        if (!altDiagonal) {
            if (flip) {
                ix[k++] = b; ix[k++] = b + 2; ix[k++] = b + 1
                ix[k++] = b; ix[k++] = b + 3; ix[k] = b + 2
            } else {
                ix[k++] = b; ix[k++] = b + 1; ix[k++] = b + 2
                ix[k++] = b; ix[k++] = b + 2; ix[k] = b + 3
            }
        } else {
            if (flip) {
                ix[k++] = b + 1; ix[k++] = b + 3; ix[k++] = b + 2
                ix[k++] = b + 1; ix[k++] = b; ix[k] = b + 3
            } else {
                ix[k++] = b + 1; ix[k++] = b + 2; ix[k++] = b + 3
                ix[k++] = b + 1; ix[k++] = b + 3; ix[k] = b
            }
        }
        vertCount += 4
        indexCount += 6
    }

    fun build(): MeshData =
        if (vertCount == 0) MeshData.EMPTY
        else MeshData(
            floats.copyOf(vertCount * FLOATS_PER_VERTEX),
            indices.copyOf(indexCount),
            vertCount,
            minY,
            maxY
        )
}

/** One solid + one water builder per mesh-worker thread. */
private class BuilderPair {
    val solid = MeshBuilder()
    val water = MeshBuilder(256)
}

/**
 * Builds one mesh per subchunk using face culling: a face is emitted only when the
 * neighboring cell is non-opaque (an unloaded neighbor chunk reads as non-opaque too
 * — see World — so boundary faces render rather than leaving holes, until the real
 * neighbor loads and both sides remesh).
 *
 * Faces that can never be seen are not emitted at all:
 *  - water: only the top surface is meshed (into its own translucent layer, see
 *    emitWaterSurface); sides and bottoms of a lake or ocean are never drawn;
 *  - foliage against foliage (leaf textures are alpha-cut, but the inside of a canopy
 *    is never worth its triangles);
 *  - the bottom faces of the world floor (y = 0), which no legal camera position can
 *    ever see (that alone was ~30% of a typical chunk's geometry).
 * All-air subchunks return immediately without scanning their 4096 cells.
 *
 * Lighting is baked into the per-vertex shade: a fixed brightness per face direction,
 * classic "smooth lighting" ambient occlusion at every corner (so creases, tree bases
 * and cliff feet get soft contact shadows), and a very small per-block brightness
 * variation that breaks up the visible tiling of large flat areas.
 *
 * Winding: the four side faces are authored counter-clockwise as seen from outside;
 * TOP and BOTTOM were authored clockwise, so they are emitted with flip = true. That
 * makes every face front-facing from outside, which lets GameRenderer enable back-face
 * culling.
 */
object ChunkMesher {
    private val builders = object : ThreadLocal<BuilderPair>() {
        override fun initialValue(): BuilderPair = BuilderPair()
    }

    private const val SIZE = WorldConfig.CHUNK_SIZE
    private const val SUB_H = WorldConfig.SUBCHUNK_HEIGHT

    /** Corner brightness for ambient-occlusion level 0 (fully boxed in) .. 3 (open). */
    private val AO_SHADE = floatArrayOf(0.58f, 0.72f, 0.86f, 1.0f)

    /** Opacity by block id, so the hot loops read one boolean instead of going through
     *  the enum (ids are masked to the table size, see BlockType.TABLE_SIZE). */
    private val OPAQUE: BooleanArray = BlockType.OPAQUE_BY_ID
    private const val ID_MASK = BlockType.TABLE_SIZE - 1

    /** Top of a water cell's surface above the cell floor. Slightly below 1 so water sits a
     *  hair under the neighbouring shore blocks and the shader's waves (+-0.06) never
     *  poke above them. */
    private const val WATER_SURFACE = 0.875f

    /** Water deeper than this reads as "deep" in the shader, so there is no point counting
     *  further down. */
    private const val WATER_DEPTH_CAP = 10

    /** Vertex offsets (x, y, z for v0..v3) of each face's quad, in Face enum order
     *  (TOP, BOTTOM, NORTH, SOUTH, EAST, WEST). Must match the winding the quads were
     *  authored with — see MeshBuilder.quad. */
    private val FACE_VERTS: Array<IntArray> = arrayOf(
        intArrayOf(0, 1, 0, 1, 1, 0, 1, 1, 1, 0, 1, 1), // TOP
        intArrayOf(0, 0, 1, 1, 0, 1, 1, 0, 0, 0, 0, 0), // BOTTOM
        intArrayOf(1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 0), // NORTH
        intArrayOf(0, 0, 1, 1, 0, 1, 1, 1, 1, 0, 1, 1), // SOUTH
        intArrayOf(1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 1, 1), // EAST
        intArrayOf(0, 0, 0, 0, 0, 1, 0, 1, 1, 0, 1, 0)  // WEST
    )

    /** For every face and each of its four vertices: the three cells (side 1, side 2,
     *  corner) that can shadow that vertex, as dx,dy,dz triples relative to the cell in
     *  FRONT of the face. 6 faces * 4 vertices * 9 ints. Derived from FACE_VERTS so the
     *  two can never disagree. */
    private val AO_CELLS: IntArray = buildAoCells()

    private fun buildAoCells(): IntArray {
        val out = IntArray(6 * 4 * 9)
        for (face in Face.ALL) {
            val fv = FACE_VERTS[face.ordinal]
            for (k in 0 until 4) {
                // Sign of each in-plane axis for this vertex; the face-normal axis stays 0.
                val sx = if (face.dx != 0) 0 else if (fv[k * 3] == 1) 1 else -1
                val sy = if (face.dy != 0) 0 else if (fv[k * 3 + 1] == 1) 1 else -1
                val sz = if (face.dz != 0) 0 else if (fv[k * 3 + 2] == 1) 1 else -1
                var ax = 0
                var ay = 0
                var az = 0
                var bx = 0
                var by = 0
                var bz = 0
                var haveFirst = false
                if (sx != 0) {
                    ax = sx
                    haveFirst = true
                }
                if (sy != 0) {
                    if (haveFirst) {
                        by = sy
                    } else {
                        ay = sy
                        haveFirst = true
                    }
                }
                if (sz != 0) {
                    if (haveFirst) {
                        bz = sz
                    } else {
                        az = sz
                    }
                }
                val base = (face.ordinal * 4 + k) * 9
                out[base] = ax; out[base + 1] = ay; out[base + 2] = az
                out[base + 3] = bx; out[base + 4] = by; out[base + 5] = bz
                out[base + 6] = ax + bx; out[base + 7] = ay + by; out[base + 8] = az + bz
            }
        }
        return out
    }

    /** Everything one subchunk mesh needs to look up cells around itself. */
    private class SubMeshJob(
        val world: World,
        val chunk: Chunk,
        val blocks: ByteArray,
        val baseX: Int,
        val baseY: Int,
        val baseZ: Int
    ) {
        /** Is the cell at subchunk-local (lx, ly, lz) opaque? Coordinates may fall up to a
         *  cell outside the subchunk; the in-array case (the vast majority) is a plain
         *  array read, everything else goes through chunk / world lookups. */
        fun opaqueAt(lx: Int, ly: Int, lz: Int): Boolean {
            val size = WorldConfig.CHUNK_SIZE
            if (lx >= 0 && lx < size && lz >= 0 && lz < size && ly >= 0 && ly < WorldConfig.SUBCHUNK_HEIGHT) {
                return ChunkMesher.OPAQUE[blocks[(ly * size + lz) * size + lx].toInt() and ChunkMesher.ID_MASK]
            }
            val wy = baseY + ly
            if (wy < 0 || wy >= WorldConfig.WORLD_HEIGHT) return false
            return if (lx >= 0 && lx < size && lz >= 0 && lz < size) {
                chunk.getBlock(lx, wy, lz).opaque
            } else {
                world.getBlock(baseX + lx, wy, baseZ + lz).opaque
            }
        }

        /** Block at subchunk-local x/z and absolute world height [wy] (the cell may lie in
         *  another subchunk or, at the rim, in a neighbouring chunk). */
        fun blockAtWorldY(lx: Int, wy: Int, lz: Int): BlockType {
            val size = WorldConfig.CHUNK_SIZE
            return if (lx >= 0 && lx < size && lz >= 0 && lz < size) {
                chunk.getBlock(lx, wy, lz)
            } else {
                world.getBlock(baseX + lx, wy, baseZ + lz)
            }
        }
    }

    fun buildSubChunkMesh(world: World, chunkX: Int, chunkZ: Int, subY: Int, atlas: TextureAtlas): SubChunkMesh {
        // The caller (WorldManager's mesh worker) already confirmed this chunk is
        // GENERATED and loaded before enqueueing the job; getChunk returning null
        // here would only mean it was unloaded in the tiny window since then, in
        // which case there's nothing left to mesh.
        val chunk = world.getChunk(ChunkPos(chunkX, chunkZ)) ?: return SubChunkMesh.EMPTY
        if (subY < 0 || subY >= WorldConfig.SUBCHUNKS_PER_CHUNK) return SubChunkMesh.EMPTY

        val sub = chunk.subChunks[subY]
        if (sub.isAllAir()) return SubChunkMesh.EMPTY
        val blocks = sub.blocks

        val pair = builders.get()
        val builder = pair.solid
        val waterBuilder = pair.water
        builder.reset()
        waterBuilder.reset()

        val baseX = chunkX * SIZE
        val baseZ = chunkZ * SIZE
        val baseY = subY * SUB_H
        val job = SubMeshJob(world, chunk, blocks, baseX, baseY, baseZ)

        for (ly in 0 until SUB_H) {
            val wy = baseY + ly
            for (lz in 0 until SIZE) {
                for (lx in 0 until SIZE) {
                    val block = BlockType.fromId(blocks[(ly * SIZE + lz) * SIZE + lx])
                    if (block == BlockType.AIR) continue

                    val wx = baseX + lx
                    val wz = baseZ + lz

                    if (block == BlockType.WATER) {
                        // Only the surface is drawn: a cell whose upper neighbour is neither
                        // water nor opaque.
                        val above = if (ly + 1 < SUB_H) {
                            BlockType.fromId(blocks[((ly + 1) * SIZE + lz) * SIZE + lx])
                        } else {
                            outsideBlockAt(world, chunk, baseX, baseZ, lx, wy + 1, lz)
                        }
                        if (above != BlockType.WATER && !above.opaque) {
                            emitWaterSurface(waterBuilder, job, lx, lz, wx, wy, wz)
                        }
                        continue
                    }
                    if (block.flat) {
                        emitLilyPad(builder, atlas, block, wx, wy, wz)
                        continue
                    }
                    if (block.plant) {
                        emitPlant(builder, atlas, block, wx, wy, wz)
                        continue
                    }

                    for (face in Face.ALL) {
                        val wny = wy + face.dy
                        if (wny < 0) continue // below the world floor: never visible

                        val nx = lx + face.dx
                        val ny = ly + face.dy
                        val nz = lz + face.dz
                        // Neighbors inside this same subchunk (the overwhelming majority)
                        // are read straight from the local array; only the one-cell rim
                        // falls back to chunk/world lookups.
                        val neighbor = if (nx >= 0 && nx < SIZE && nz >= 0 && nz < SIZE && ny >= 0 && ny < SUB_H) {
                            BlockType.fromId(blocks[(ny * SIZE + nz) * SIZE + nx])
                        } else {
                            outsideBlockAt(world, chunk, baseX, baseZ, nx, wny, nz)
                        }
                        if (neighbor.opaque) continue
                        if (block.cutout && neighbor.cutout) continue
                        emitFace(builder, job, atlas, block, face, lx, ly, lz, wx, wy, wz)
                    }
                }
            }
        }
        return SubChunkMesh(builder.build(), waterBuilder.build())
    }

    /** Neighbor lookup for cells that fall outside this subchunk's own array: still
     *  inside this chunk (another subchunk) -> this chunk's own arrays; across the
     *  chunk edge -> World, where an unloaded neighbor reads as AIR (see World). */
    private fun outsideBlockAt(world: World, chunk: Chunk, baseX: Int, baseZ: Int, lx: Int, y: Int, lz: Int): BlockType =
        if (lx >= 0 && lx < SIZE && lz >= 0 && lz < SIZE) {
            chunk.getBlock(lx, y, lz)
        } else {
            world.getBlock(baseX + lx, y, baseZ + lz)
        }

    /** 0 (fully boxed in) .. 3 (open) occlusion level of one face vertex. */
    private fun aoLevel(job: SubMeshJob, nx: Int, ny: Int, nz: Int, base: Int): Int {
        val side1 = job.opaqueAt(nx + AO_CELLS[base], ny + AO_CELLS[base + 1], nz + AO_CELLS[base + 2])
        val side2 = job.opaqueAt(nx + AO_CELLS[base + 3], ny + AO_CELLS[base + 4], nz + AO_CELLS[base + 5])
        if (side1 && side2) return 0
        val corner = job.opaqueAt(nx + AO_CELLS[base + 6], ny + AO_CELLS[base + 7], nz + AO_CELLS[base + 8])
        return 3 - (if (side1) 1 else 0) - (if (side2) 1 else 0) - (if (corner) 1 else 0)
    }

    private fun emitFace(
        builder: MeshBuilder, job: SubMeshJob, atlas: TextureAtlas,
        block: BlockType, face: Face,
        lx: Int, ly: Int, lz: Int, wx: Int, wy: Int, wz: Int
    ) {
        val fx = wx.toFloat()
        val fy = wy.toFloat()
        val fz = wz.toFloat()
        val uv = atlas.uvFor(block.cellFor(face))

        val shade = shadeFor(face) * variation(wx, wy, wz, if (block.cutout) 0.14f else 0.06f)
        val nx = lx + face.dx
        val ny = ly + face.dy
        val nz = lz + face.dz
        val base = face.ordinal * 36
        val a0 = aoLevel(job, nx, ny, nz, base)
        val a1 = aoLevel(job, nx, ny, nz, base + 9)
        val a2 = aoLevel(job, nx, ny, nz, base + 18)
        val a3 = aoLevel(job, nx, ny, nz, base + 27)
        val s0 = shade * AO_SHADE[a0]
        val s1 = shade * AO_SHADE[a1]
        val s2 = shade * AO_SHADE[a2]
        val s3 = shade * AO_SHADE[a3]
        // Split along the diagonal that runs through the darker corners.
        val alt = (a0 + a2) > (a1 + a3)

        val v = FACE_VERTS[face.ordinal]
        val x0 = fx + v[0]; val y0 = fy + v[1]; val z0 = fz + v[2]
        val x1 = fx + v[3]; val y1 = fy + v[4]; val z1 = fz + v[5]
        val x2 = fx + v[6]; val y2 = fy + v[7]; val z2 = fz + v[8]
        val x3 = fx + v[9]; val y3 = fy + v[10]; val z3 = fz + v[11]

        if (face == Face.TOP || face == Face.BOTTOM) {
            builder.quad(
                x0, y0, z0, x1, y1, z1, x2, y2, z2, x3, y3, z3,
                uv.u0, uv.v0, uv.u1, uv.v1, s0, s1, s2, s3, true, alt
            )
        } else {
            // Side faces: the first two vertices are the bottom edge. Image row 0 is the
            // top of a tile, so the bottom edge takes the tile's bottom row (v1) and the
            // top edge its top row (v0) — this is what keeps grass fringes, bark streaks
            // and the like the right way up.
            builder.quad(
                x0, y0, z0, x1, y1, z1, x2, y2, z2, x3, y3, z3,
                uv.u0, uv.v1, uv.u1, uv.v0, s0, s1, s2, s3, false, alt
            )
        }
    }

    /**
     * One animated-water surface quad for the water cell at (wx, wy, wz). Each vertex
     * carries the water depth beneath it, averaged over the four columns that meet at
     * that corner, so neighbouring quads agree on shared corners and the depth (hence
     * the colour and opacity) fades smoothly from the shore into open water.
     */
    private fun emitWaterSurface(builder: MeshBuilder, job: SubMeshJob, lx: Int, lz: Int, wx: Int, wy: Int, wz: Int) {
        val v = FACE_VERTS[Face.TOP.ordinal]
        val d0 = cornerWaterDepth(job, lx + v[0], lz + v[2], wy)
        val d1 = cornerWaterDepth(job, lx + v[3], lz + v[5], wy)
        val d2 = cornerWaterDepth(job, lx + v[6], lz + v[8], wy)
        val d3 = cornerWaterDepth(job, lx + v[9], lz + v[11], wy)
        val fx = wx.toFloat()
        val fz = wz.toFloat()
        val y = wy + WATER_SURFACE
        // Same triangulation rule as terrain: split through the shallower pair.
        val alt = (d0 + d2) < (d1 + d3)
        builder.waterQuad(
            fx + v[0], y, fz + v[2], d0,
            fx + v[3], y, fz + v[5], d1,
            fx + v[6], y, fz + v[8], d2,
            fx + v[9], y, fz + v[11], d3,
            alt
        )
    }

    /** Mean water depth (blocks, capped) of the four columns around the corner at local
     *  block-corner coordinates (cornerX, cornerZ), measured down from height [wy]. */
    private fun cornerWaterDepth(job: SubMeshJob, cornerX: Int, cornerZ: Int, wy: Int): Float {
        val sum = columnWaterDepth(job, cornerX - 1, cornerZ - 1, wy) +
            columnWaterDepth(job, cornerX, cornerZ - 1, wy) +
            columnWaterDepth(job, cornerX - 1, cornerZ, wy) +
            columnWaterDepth(job, cornerX, cornerZ, wy)
        return sum * 0.25f
    }

    /** Number of consecutive water cells in a column counting down from [wy] (inclusive). */
    private fun columnWaterDepth(job: SubMeshJob, lx: Int, lz: Int, wy: Int): Int {
        var depth = 0
        var y = wy
        while (depth < WATER_DEPTH_CAP && y >= 0 && job.blockAtWorldY(lx, y, lz) == BlockType.WATER) {
            depth++
            y--
        }
        return depth
    }

    /**
     * A cross-shaped plant: two vertical quads along the cell's diagonals, each emitted in
     * both windings so it shows from every side with back-face culling on. A position
     * hash nudges each plant off the block grid so meadows don't look stamped; the quad
     * is a little darker at the root, which grounds it without any lighting data.
     */
    private fun emitPlant(builder: MeshBuilder, atlas: TextureAtlas, block: BlockType, wx: Int, wy: Int, wz: Int) {
        val uv = atlas.uvFor(block.topCell)
        val bits = (wx * 73856093) xor (wz * 19349663) xor (wy * 83492791)
        val jx = ((bits ushr 4) and 7) / 7f * 0.24f - 0.12f
        val jz = ((bits ushr 8) and 7) / 7f * 0.24f - 0.12f
        val bright = variation(wx, wy, wz, 0.18f)
        val root = 0.74f * bright
        val tip = 1.0f * bright
        val x = wx + 0.5f + jx
        val z = wz + 0.5f + jz
        val y0 = wy.toFloat()
        val y1 = wy + 1f
        val r = 0.46f
        // diagonal A: (-r,-r) -> (+r,+r); diagonal B: (+r,-r) -> (-r,+r)
        for (flip in 0..1) {
            val f = flip == 1
            builder.quad(
                x - r, y0, z - r, x + r, y0, z + r, x + r, y1, z + r, x - r, y1, z - r,
                uv.u0, uv.v1, uv.u1, uv.v0, root, root, tip, tip, f, false
            )
            builder.quad(
                x + r, y0, z - r, x - r, y0, z + r, x - r, y1, z + r, x + r, y1, z - r,
                uv.u0, uv.v1, uv.u1, uv.v0, root, root, tip, tip, f, false
            )
        }
    }

    /** A lily pad: one horizontal quad just above the water, emitted in both windings so it
     *  shows from above and from below. */
    private fun emitLilyPad(builder: MeshBuilder, atlas: TextureAtlas, block: BlockType, wx: Int, wy: Int, wz: Int) {
        val uv = atlas.uvFor(block.topCell)
        val bits = (wx * 73856093) xor (wz * 19349663) xor (wy * 83492791)
        val jx = ((bits ushr 4) and 7) / 7f * 0.16f - 0.08f
        val jz = ((bits ushr 8) and 7) / 7f * 0.16f - 0.08f
        val shade = variation(wx, wy, wz, 0.14f)
        val x = wx + 0.5f + jx
        val z = wz + 0.5f + jz
        val y = wy + 0.03f
        val r = 0.5f
        for (flip in 0..1) {
            builder.quad(
                x - r, y, z - r, x - r, y, z + r, x + r, y, z + r, x + r, y, z - r,
                uv.u0, uv.v0, uv.u1, uv.v1, shade, shade, shade, shade, flip == 1, false
            )
        }
    }

    /** Per-block brightness multiplier in (1 - range)..1, a pure function of position. */
    private fun variation(x: Int, y: Int, z: Int, range: Float): Float {
        var h = x * 73856093 xor y * 19349663 xor z * 83492791
        h = h xor (h ushr 15)
        h *= 739982445
        h = h xor (h ushr 13)
        return 1f - range * (((h ushr 8) and 0xFF) / 255f)
    }

    private fun shadeFor(face: Face): Float = when (face) {
        Face.TOP -> 1.0f
        Face.BOTTOM -> 0.4f
        Face.NORTH, Face.SOUTH -> 0.82f
        Face.EAST, Face.WEST -> 0.70f
    }
}
