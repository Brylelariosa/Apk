package com.voxelsandbox.game.world.generation

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Deterministic seeded 2D simplex noise (the classic, widely-known lattice-skewing
 * scheme: a generic decades-old algorithm with no relation to any specific game).
 * Simplex noise has no visible axis-aligned grain, which matters a lot for terrain:
 * ridges, coastlines and rivers built on it do not line up with the block grid.
 *
 * Everything the world looks like is derived from this plus the seed, so the same seed
 * always reproduces the same world.
 */
class NoiseGenerator(seed: Long) {
    private val perm = IntArray(512)

    init {
        val p = IntArray(256) { it }
        val rnd = Random(seed)
        for (i in 255 downTo 1) {
            val j = rnd.nextInt(i + 1)
            val tmp = p[i]; p[i] = p[j]; p[j] = tmp
        }
        for (i in 0 until 512) perm[i] = p[i and 255]
    }

    /** Single octave of simplex noise, normalised to roughly [-1, 1]. */
    fun noise2D(x: Double, y: Double): Double {
        val s = (x + y) * F2
        val i = fastFloor(x + s)
        val j = fastFloor(y + s)
        val t = (i + j) * G2
        val x0 = x - (i - t)
        val y0 = y - (j - t)
        val i1 = if (x0 > y0) 1 else 0
        val j1 = 1 - i1
        val x1 = x0 - i1 + G2
        val y1 = y0 - j1 + G2
        val x2 = x0 - 1.0 + 2.0 * G2
        val y2 = y0 - 1.0 + 2.0 * G2
        val ii = i and 255
        val jj = j and 255
        val g0 = perm[ii + perm[jj]] and 15
        val g1 = perm[ii + i1 + perm[jj + j1]] and 15
        val g2 = perm[ii + 1 + perm[jj + 1]] and 15
        return SCALE * (corner(x0, y0, g0) + corner(x1, y1, g1) + corner(x2, y2, g2))
    }

    /** Fractal Brownian motion: sums several octaves of the base noise for more
     *  natural-looking terrain (broad shapes + fine detail). Result is in ~[-1,1]. */
    fun fbm2D(x: Double, y: Double, octaves: Int, persistence: Double, lacunarity: Double): Double {
        var total = 0.0
        var freq = 1.0
        var amp = 1.0
        var maxAmp = 0.0
        for (o in 0 until octaves) {
            total += noise2D(x * freq, y * freq) * amp
            maxAmp += amp
            amp *= persistence
            freq *= lacunarity
        }
        return total / maxAmp
    }

    /** Ridged multifractal: sharp crests with broad valleys between them, the shape of
     *  real mountain ranges. Each octave's contribution is weighted by the previous one so
     *  crests stay detailed while valley floors stay smooth. Result is in ~[0, 1]. */
    fun ridged2D(x: Double, y: Double, octaves: Int, lacunarity: Double, gain: Double): Double {
        var total = 0.0
        var freq = 1.0
        var amp = 0.5
        var weight = 1.0
        var norm = 0.0
        for (o in 0 until octaves) {
            var n = 1.0 - abs(noise2D(x * freq, y * freq))
            n *= n
            total += n * amp * weight
            norm += amp
            weight = (n * gain).coerceIn(0.0, 1.0)
            freq *= lacunarity
            amp *= 0.5
        }
        return total / norm
    }

    private fun corner(x: Double, y: Double, g: Int): Double {
        var t = 0.5 - x * x - y * y
        if (t <= 0.0) return 0.0
        t *= t
        return t * t * (GX[g] * x + GY[g] * y)
    }

    private fun fastFloor(v: Double): Int {
        val i = v.toInt()
        return if (v < i) i - 1 else i
    }

    private companion object {
        val F2: Double = 0.5 * (sqrt(3.0) - 1.0)
        val G2: Double = (3.0 - sqrt(3.0)) / 6.0

        /** Scales the raw simplex sum so a single octave spans ~[-1, 1]. */
        const val SCALE = 99.0

        /** 16 evenly spread unit gradients: avoids the diagonal bias of the usual 8/12. */
        val GX = DoubleArray(16) { cos((it + 0.5) * 2.0 * PI / 16.0) }
        val GY = DoubleArray(16) { sin((it + 0.5) * 2.0 * PI / 16.0) }
    }
}
