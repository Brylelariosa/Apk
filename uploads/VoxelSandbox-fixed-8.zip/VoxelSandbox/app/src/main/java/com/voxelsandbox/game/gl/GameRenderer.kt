package com.voxelsandbox.game.gl

import android.opengl.GLES30
import android.os.Handler
import android.os.Looper
import com.voxelsandbox.game.engine.GameEngine
import com.voxelsandbox.game.player.Raycaster
import com.voxelsandbox.game.world.BlockType
import com.voxelsandbox.game.world.ChunkPos
import com.voxelsandbox.game.world.ChunkRing
import com.voxelsandbox.game.world.WorldConfig
import com.voxelsandbox.game.world.mesh.MeshData
import java.util.Arrays
import java.util.Locale
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

/**
 * All GL work lives here and only here — GameEngine (physics/streaming/inventory) is
 * completely GL-agnostic, so this class's job is: call engine.update(dt), move
 * finished background work (mesh uploads, unloads) onto the GPU, and draw.
 *
 * Frame-cost levers (all visually lossless unless noted):
 *  - far plane == fog end: everything at/after fog end is 100% fog colour (== clear
 *    colour), so clipping it changes nothing on screen, but the CPU frustum test then
 *    also skips every column past it;
 *  - back-face culling (see ChunkMesher for the winding fix that makes it safe);
 *  - columns drawn front-to-back so the depth test rejects hidden fragments early;
 *  - tight per-column culling boxes (real min/max terrain height, not 0..64);
 *  - mesh uploads are coalesced per column and time-budgeted per frame;
 *  - an optional adaptive-distance governor that only shortens fog when FPS is low;
 *  - distant terrain tiles (few, large, cheap, several levels of detail) instead of voxel
 *    chunks past the detail radius, clipped in the shader so they never overdraw the
 *    chunks that cover that area (see FarTerrainRenderer);
 *  - two depth ranges: distant terrain is drawn first with a far larger near plane (so its
 *    depth precision stays excellent out to thousands of blocks), then the depth buffer is
 *    cleared and the voxel world is drawn over it with the usual tight near plane.
 *
 * Pass order per frame: sky -> distant land -> distant water -> clouds -> [clear depth] ->
 * voxel chunks -> voxel water -> block outline -> particles -> laser (-> clouds, when there
 * is no distant-terrain pass to draw them in).
 *
 * Voxel chunk meshes are batched per REGION of 2x2 chunk columns (one GPU buffer, one draw
 * call): on the phones this game targets the cost of a frame is dominated by the number of
 * draw calls, not the number of triangles.
 */
class GameRenderer(
    private val engine: GameEngine,
    /** Invoked ~2-3x/sec on the main thread regardless of the FPS-counter setting
     *  (the HUD uses every tick to refresh the hotbar); the string argument is the
     *  formatted FPS/debug text when showFps is on, or null when it's off. */
    private val onPeriodicTick: (String?) -> Unit
) : android.opengl.GLSurfaceView.Renderer {

    /** When true, onDrawFrame keeps rendering the last state (so the world stays
     *  visible, frozen, behind a menu overlay) but stops calling engine.update —
     *  set by GameActivity whenever a menu is shown over active gameplay. */
    @Volatile var paused = false

    private val atlas = engine.atlas
    private lateinit var shader: ShaderProgram
    private var uViewProj = 0
    private var uTexture = 0
    private var uFogColor = 0
    private var uFogStart = 0
    private var uFogEnd = 0
    private var uAlpha = 0

    // The other render passes; each owns its own program and GPU objects.
    private val sky = SkyRenderer()
    private val water = WaterRenderer()
    private val far = FarTerrainRenderer()
    private val frame = FrameState()
    private val startNanos = System.nanoTime()

    private val camera = Camera()
    private val frustum = Frustum()
    private var aspect = 1f

    // One GPU buffer per REGION of 2x2 chunk columns (one draw call for up to four columns
    // and eight subchunks each). columnMeshData / columnWaterData cache each column's latest
    // raw subchunk meshes on the CPU, so a region can be re-combined into its single buffer
    // whenever any one of its columns changes. The translucent water layer is drawn in its
    // own pass and so lives in its own region buffers.
    private val regionMeshes = HashMap<Long, ChunkGpuMesh>()
    private val columnMeshData = HashMap<ChunkPos, Array<MeshData?>>()
    private val regionWaterMeshes = HashMap<Long, ChunkGpuMesh>()
    private val columnWaterData = HashMap<ChunkPos, Array<MeshData?>>()

    /** Columns (packed) whose solid geometry is on the GPU: what the fog coverage scan uses. */
    private val uploadedColumns = HashSet<Long>()

    /** Regions whose CPU-side data changed and whose GPU buffer must be rebuilt.
     *  [urgentRegions] (player edits) are always flushed the same frame; the rest
     *  (streaming) are flushed nearest-first until the per-frame time budget is spent. */
    private val dirtyRegions = LinkedHashSet<Long>()
    private val urgentRegions = LinkedHashSet<Long>()

    // Scratch for combining a region's columns (columns x subchunks).
    private val regionParts = arrayOfNulls<MeshData>(REGION_SIZE * REGION_SIZE * WorldConfig.SUBCHUNKS_PER_CHUNK)
    private val regionWaterParts = arrayOfNulls<MeshData>(REGION_SIZE * REGION_SIZE * WorldConfig.SUBCHUNKS_PER_CHUNK)

    // How far the full-detail chunks around the player are really complete (in chunks,
    // measured from the centre of the chunk the player was in when last scanned), and
    // the smoothed distance the fog is allowed to reach given everything that is loaded.
    private var nearCoveredChunks = 0f
    private var nearCenterX = 0f
    private var nearCenterZ = 0f
    private var nearScanTimer = 99f
    private var fogCover = 40f

    private val particleMesh = ChunkGpuMesh()
    private val highlightMesh = ChunkGpuMesh()
    private val laserMesh = ChunkGpuMesh()
    private val clouds = CloudRenderer()

    private var highlightValid = false
    private var highlightX = 0
    private var highlightY = 0
    private var highlightZ = 0
    private var highlightShape = 0 // 0 = whole block, 1 = plant, 2 = flat plant (lily pad)

    private val laserFloats = FloatArray(8 * 6)
    private val laserIndices = intArrayOf(0, 1, 2, 0, 2, 3, 4, 5, 6, 4, 6, 7)

    private var particleFloats = FloatArray(0)
    private var particleIndices = IntArray(0)
    private var particleVerts = 0
    private var particleIdx = 0

    // Draw list scratch (visible columns sorted front-to-back), reused every frame.
    private var sortKeys = LongArray(512)
    private var sortMeshes = arrayOfNulls<ChunkGpuMesh>(512)
    private var waterSortKeys = LongArray(128)
    private var waterSortMeshes = arrayOfNulls<ChunkGpuMesh>(128)

    // Adaptive distance governor state.
    private var distScale = 1f
    private var govTime = 0f
    private var govFrames = 0

    // Frame stats (shown in the FPS overlay).
    private var lastFrameTimeNanos = 0L
    private var fpsAccumTime = 0f
    private var fpsAccumFrames = 0
    private var currentFps = 0f
    private var statWorstDt = 0f
    private var statCpuAccumMs = 0f
    private var statCpuMaxMs = 0f
    private var statUploadAccumNs = 0L
    private var statDrawnCols = 0
    private var statTotalCols = 0
    private var statTris = 0
    private var statWaterTris = 0
    private val mainHandler = Handler(Looper.getMainLooper())

    companion object {
        // Camera inside a water block: short blue fog instead of the sky colour.
        private const val UNDERWATER_FOG_START = 2f
        private const val UNDERWATER_FOG_END = 26f

        private const val MAX_POLL_PER_FRAME = 48
        private const val UPLOAD_BUDGET_NS = 3_000_000L // ~3 ms of GL-thread time per frame

        // A distant tile is a big mesh now (64x64 columns); one upload per frame keeps hitches away.
        private const val FAR_UPLOADS_PER_FRAME = 1

        /** Chunk columns per side of one batched region (2 -> 2x2 columns = 32x32 blocks). */
        private const val REGION_SIZE = 2
        private const val REGION_SHIFT = 1

        /** Longest the cloud sheet reaches from the eye, however far the fog is. */
        private const val MAX_CLOUD_RADIUS = 2400f

        /** Length of the drawn laser beam (matches GameEngine's laser range). */
        private const val LASER_LENGTH = 96f

        /** Near plane for the voxel world: close enough to stand against a wall. */
        private const val NEAR_PLANE = 0.15f
        private const val NEAR_SCAN_INTERVAL = 0.25f

        private const val GOV_WINDOW_SEC = 1.0f
        private const val GOV_LOW_FPS = 42f
        private const val GOV_HIGH_FPS = 56f
        private const val GOV_STEP_DOWN = 0.07f
        private const val GOV_STEP_UP = 0.03f
        private const val GOV_MIN_SCALE = 0.65f
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        shader = ShaderProgram(Shaders.VERTEX, Shaders.FRAGMENT)
        uViewProj = shader.uniform("uViewProj")
        uTexture = shader.uniform("uTexture")
        uFogColor = shader.uniform("uFogColor")
        uFogStart = shader.uniform("uFogStart")
        uFogEnd = shader.uniform("uFogEnd")
        uAlpha = shader.uniform("uAlpha")

        sky.init()
        water.init()
        far.init()
        clouds.init()

        atlas.uploadToGL()

        GLES30.glEnable(GLES30.GL_DEPTH_TEST)
        GLES30.glDepthFunc(GLES30.GL_LEQUAL)
        // Every terrain face is wound counter-clockwise as seen from outside (see
        // ChunkMesher), so back faces can be dropped before rasterization.
        GLES30.glEnable(GLES30.GL_CULL_FACE)
        GLES30.glCullFace(GLES30.GL_BACK)
        GLES30.glFrontFace(GLES30.GL_CCW)
        GLES30.glClearColor(Atmosphere.HORIZON_R, Atmosphere.HORIZON_G, Atmosphere.HORIZON_B, 1f)

        // The context (and any GPU handles in it) may have just been recreated
        // (e.g. after backgrounding) while world/chunk state persisted — drop our
        // now-invalid mesh handles and ask WorldManager to remesh everything it
        // still has loaded so the terrain reappears instead of staying blank.
        // particle/cloud/highlight are long-lived instances reused across frames, so
        // each needs telling explicitly that its old handles no longer mean anything.
        regionMeshes.clear()
        regionWaterMeshes.clear()
        columnMeshData.clear()
        columnWaterData.clear()
        uploadedColumns.clear()
        dirtyRegions.clear()
        urgentRegions.clear()
        particleMesh.invalidateForContextLoss()
        highlightMesh.invalidateForContextLoss()
        laserMesh.invalidateForContextLoss()
        highlightValid = false
        far.invalidateForContextLoss()
        nearScanTimer = 99f
        engine.farTerrain.invalidateAll()
        engine.worldManager.remeshAllLoaded()
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES30.glViewport(0, 0, width, height)
        aspect = if (height > 0) width.toFloat() / height.toFloat() else 1f
    }

    override fun onDrawFrame(gl: GL10?) {
        val now = System.nanoTime()
        val dt = if (lastFrameTimeNanos == 0L) 0.016f else ((now - lastFrameTimeNanos) / 1_000_000_000f).coerceIn(0f, 0.1f)
        lastFrameTimeNanos = now

        if (!paused) engine.update(dt)
        drainUnloads()
        drainMeshUploads()
        far.drain(engine.farTerrain.events, FAR_UPLOADS_PER_FRAME)

        val p = engine.player
        val eyeX = p.eyeX()
        val eyeY = p.eyeY() + engine.bobOffset
        val eyeZ = p.eyeZ()
        // Underwater = the eye is inside a water cell AND below that water's surface. The surface
        // sits a little under the top of the cell (see ChunkMesher.WATER_SURFACE), so an eye in
        // the top sliver of a water cell is already above it.
        val eyeBlockX = floor(eyeX).toInt()
        val eyeBlockY = floor(eyeY).toInt()
        val eyeBlockZ = floor(eyeZ).toInt()
        val underwater = engine.world.getBlock(eyeBlockX, eyeBlockY, eyeBlockZ) == BlockType.WATER &&
            (eyeY - eyeBlockY < 0.875f || engine.world.getBlock(eyeBlockX, eyeBlockY + 1, eyeBlockZ) == BlockType.WATER)

        val settings = engine.settings
        val farOn = settings.farTerrain
        updateGovernor(dt, underwater)

        nearScanTimer += dt
        if (nearScanTimer >= NEAR_SCAN_INTERVAL) {
            nearScanTimer = 0f
            updateNearCoverage(eyeX, eyeZ, settings.nearChunks())
        }

        // The fog may only reach as far as there is actually something behind it: the
        // contiguous area covered by finished chunk meshes (and, if enabled, distant
        // terrain tiles), capped by the chosen render distance. That is what keeps
        // not-yet-loaded ground from ever showing as a hole in the world: it simply
        // sits in the fog until it arrives. Shrinks instantly, grows smoothly.
        val renderBlocks = settings.renderDistanceChunks * WorldConfig.CHUNK_SIZE.toFloat()
        // (-1.5 chunks: the scan measures from the centre of the player's chunk to the
        // centre of the first missing one, so a missing chunk can really begin up to ~1.4
        // chunks closer than that figure.)
        val nearBlocks = max(0f, nearCoveredChunks - 1.5f) * WorldConfig.CHUNK_SIZE
        val coveredBlocks = if (farOn) max(nearBlocks, engine.farTerrain.coveredRadiusBlocks) else nearBlocks
        val coverTarget = min(renderBlocks, coveredBlocks)
        fogCover = if (coverTarget < fogCover) coverTarget else fogCover + (coverTarget - fogCover) * min(1f, dt * 3f)

        val fogEnd: Float
        val fogStart: Float
        val fogR: Float
        val fogG: Float
        val fogB: Float
        if (underwater) {
            fogEnd = UNDERWATER_FOG_END
            fogStart = UNDERWATER_FOG_START
            fogR = Atmosphere.UNDERWATER_R; fogG = Atmosphere.UNDERWATER_G; fogB = Atmosphere.UNDERWATER_B
        } else {
            fogEnd = max(24f, fogCover * 0.95f * distScale)
            fogStart = fogEnd * 0.6f
            fogR = Atmosphere.HORIZON_R; fogG = Atmosphere.HORIZON_G; fogB = Atmosphere.HORIZON_B
        }

        GLES30.glClearColor(fogR, fogG, fogB, 1f)
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)

        // ---- shared per-frame state -------------------------------------------------------
        val clipRadius = max(0f, (nearCoveredChunks - 0.75f) * WorldConfig.CHUNK_SIZE)
        fillFrameState(eyeX, eyeY, eyeZ, p.yaw, p.pitch, fogR, fogG, fogB, fogStart, fogEnd, clipRadius)

        val farPass = farOn && !underwater
        val cloudY = (WorldConfig.WORLD_HEIGHT + 24).toFloat()
        val cloudRadius = min(fogEnd * 0.92f, MAX_CLOUD_RADIUS)
        if (!underwater) sky.draw(frame)

        // ---- pass 1: distant terrain, in its own depth range --------------------------------
        // Nothing here is closer than the edge of the voxel-covered circle, so the near plane
        // can sit far out; that keeps the depth buffer precise even 3000+ blocks away. (Safe
        // limit: a visible fragment is at least cos(~64 degrees) ~ 0.43 of its distance away
        // along the view axis, and is at least clipRadius - 11 blocks from the eye, hence 0.4.)
        // (Anything at or beyond fogEnd is already 100% fog colour == the horizon colour, so
        // putting the far plane just past it removes nothing visible.)
        if (farPass) {
            atlas.bind(0) // the far-terrain colour ramp lives in the block atlas
            applyProjection(max(0.5f, (clipRadius - 20f) * 0.4f), fogEnd + 1f, eyeX, eyeY, eyeZ, p.yaw, p.pitch)
            far.drawLand(frame, frustum)
            water.begin(frame)
            far.drawWater(frame, frustum, water)
            water.end()
            // Clouds are drawn here, in the distant-terrain depth range (its far plane reaches the
            // fog), so they are depth-tested against the far land and never clipped early.
            if (settings.cloudsEnabled) clouds.draw(frame, cloudY, cloudRadius)
            // The voxel world is always in front of distant terrain, so it may simply be
            // drawn over it with fresh depth values.
            GLES30.glClear(GLES30.GL_DEPTH_BUFFER_BIT)
        } else {
            far.clearStats()
        }

        // ---- pass 2: the voxel world --------------------------------------------------------
        val voxelFar = if (farPass) min(fogEnd, settings.nearChunks() * WorldConfig.CHUNK_SIZE + 40f) else fogEnd
        applyProjection(NEAR_PLANE, voxelFar + 1f, eyeX, eyeY, eyeZ, p.yaw, p.pitch)

        shader.use()
        GLES30.glUniformMatrix4fv(uViewProj, 1, false, camera.viewProjMatrix, 0)
        GLES30.glUniform3f(uFogColor, fogR, fogG, fogB)
        GLES30.glUniform1f(uFogStart, fogStart)
        GLES30.glUniform1f(uFogEnd, fogEnd)
        GLES30.glUniform1f(uAlpha, 1f)
        atlas.bind(0)
        GLES30.glUniform1i(uTexture, 0)

        GLES30.glEnable(GLES30.GL_CULL_FACE)
        drawChunks(eyeX, eyeZ)
        statWaterTris = 0
        if (!underwater) {
            drawNearWater(eyeX, eyeZ)
            shader.use() // back to the main program for the overlay passes below
            atlas.bind(0)
        }
        drawHighlight()

        // Particle cubes and the laser beam aren't wound for culling: draw them as-is.
        GLES30.glDisable(GLES30.GL_CULL_FACE)
        if (engine.settings.particlesEnabled) drawParticles()
        if (engine.laserActive) drawLaser(eyeX, eyeY, eyeZ)
        if (!underwater && !farPass && settings.cloudsEnabled) clouds.draw(frame, cloudY, cloudRadius)

        // Leave no VAO bound between frames. (Mesh uploads now bind their own VAO, but
        // stale bindings are exactly how the old corruption bug crept in.)
        GLES30.glBindVertexArray(0)

        val cpuMs = (System.nanoTime() - now) / 1_000_000f
        updateFps(dt, cpuMs, underwater)
    }

    /** Sets the camera for one depth range and mirrors the result into [frame] and [frustum]. */
    private fun applyProjection(nearPlane: Float, farPlane: Float, eyeX: Float, eyeY: Float, eyeZ: Float, yaw: Float, pitch: Float) {
        camera.nearPlane = nearPlane
        // The fog distance can briefly lag behind the (immediately updated) voxel coverage while
        // the world is loading; never let the far plane fall to or below the near plane.
        camera.farPlane = max(farPlane, nearPlane + 1f)
        camera.setPerspective(aspect)
        camera.updateView(eyeX, eyeY, eyeZ, yaw, pitch)
        System.arraycopy(camera.viewProjMatrix, 0, frame.viewProj, 0, 16)
        frustum.update(frame.viewProj)
    }

    private fun fillFrameState(
        eyeX: Float, eyeY: Float, eyeZ: Float, yaw: Float, pitch: Float,
        fogR: Float, fogG: Float, fogB: Float, fogStart: Float, fogEnd: Float, clipRadius: Float
    ) {
        frame.eyeX = eyeX
        frame.eyeY = eyeY
        frame.eyeZ = eyeZ

        // Camera basis; see Camera.updateView for the convention (yaw 0 looks down -Z).
        val cp = cos(pitch)
        val sp = sin(pitch)
        val cy = cos(yaw)
        val sy = sin(yaw)
        frame.forwardX = cp * sy
        frame.forwardY = sp
        frame.forwardZ = -cp * cy
        frame.rightX = cy
        frame.rightY = 0f
        frame.rightZ = sy
        frame.upX = -sy * sp
        frame.upY = cp
        frame.upZ = cy * sp
        val tanHalf = tan(Math.toRadians(camera.fovYDegrees.toDouble()) / 2.0).toFloat()
        frame.tanHalfFovY = tanHalf
        frame.tanHalfFovX = tanHalf * aspect

        frame.fogR = fogR
        frame.fogG = fogG
        frame.fogB = fogB
        frame.fogStart = fogStart
        frame.fogEnd = fogEnd

        val seconds = (System.nanoTime() - startNanos) / 1_000_000_000.0
        frame.textureTime = (seconds % FrameState.TEXTURE_TIME_PERIOD).toFloat()
        frame.waveTime = (seconds % FrameState.WAVE_TIME_PERIOD).toFloat()

        frame.coverX = nearCenterX
        frame.coverZ = nearCenterZ
        frame.coverRadius = clipRadius
    }

    // ---- Adaptive distance ----------------------------------------------------------

    /** Slowly pulls the fog/far distance in while the frame rate stays low and lets it
     *  back out once there's headroom. Never goes below GOV_MIN_SCALE of the chosen
     *  render distance and does nothing at all while FPS is healthy. */
    private fun updateGovernor(dt: Float, underwater: Boolean) {
        if (!engine.settings.adaptiveDistance) {
            distScale = 1f
            govTime = 0f
            govFrames = 0
            return
        }
        if (paused || underwater || engine.player.waitingForSpawn) {
            govTime = 0f
            govFrames = 0
            return
        }
        govTime += dt
        govFrames++
        if (govTime >= GOV_WINDOW_SEC) {
            val fps = govFrames / govTime
            if (fps < GOV_LOW_FPS) {
                distScale = max(GOV_MIN_SCALE, distScale - GOV_STEP_DOWN)
            } else if (fps > GOV_HIGH_FPS) {
                distScale = min(1f, distScale + GOV_STEP_UP)
            }
            govTime = 0f
            govFrames = 0
        }
    }

    // ---- Streaming hand-off (background threads -> GPU) ---------------------------

    private fun drainMeshUploads() {
        val startNs = System.nanoTime()
        val queue = engine.worldManager.pendingMeshUploads

        // Phase 1: pull finished meshes into the per-column CPU cache (cheap) and note
        // which regions now need their GPU buffer rebuilt. Polling is cheap, so it's
        // not budgeted; the expensive part (combine + glBufferData) is, below.
        var polled = 0
        while (polled < MAX_POLL_PER_FRAME) {
            val result = queue.poll() ?: break
            polled++
            val pos = result.pos
            if (result.subY < 0 || result.subY >= WorldConfig.SUBCHUNKS_PER_CHUNK) continue
            // Chunk was unloaded while this mesh was in flight: drop it rather than
            // resurrecting a ghost column that nothing would ever unload again.
            if (engine.world.getChunk(pos) == null) continue

            val slots = columnMeshData.getOrPut(pos) { arrayOfNulls(WorldConfig.SUBCHUNKS_PER_CHUNK) }
            val previous = slots[result.subY]
            val incoming: MeshData? = if (result.solid.isEmpty()) null else result.solid

            val waterSlots = columnWaterData.getOrPut(pos) { arrayOfNulls(WorldConfig.SUBCHUNKS_PER_CHUNK) }
            val previousWater = waterSlots[result.subY]
            val incomingWater: MeshData? = if (result.water.isEmpty()) null else result.water

            if (incoming == null && previous == null && incomingWater == null && previousWater == null) continue // empty -> still empty
            slots[result.subY] = incoming
            waterSlots[result.subY] = incomingWater

            val key = regionKey(pos.x, pos.z)
            if (result.priority == Long.MIN_VALUE) urgentRegions.add(key) else dirtyRegions.add(key)
        }

        // Phase 2a: player edits go up immediately, budget or not, so a placed/broken
        // block never waits behind streaming work.
        if (urgentRegions.isNotEmpty()) {
            for (key in urgentRegions) {
                dirtyRegions.remove(key)
                uploadRegion(key)
            }
            urgentRegions.clear()
        }

        // Phase 2b: streaming regions, nearest first (queue order), until this frame's
        // upload budget is spent. Whatever is left simply stays dirty for next frame.
        if (dirtyRegions.isNotEmpty()) {
            val iter = dirtyRegions.iterator()
            while (iter.hasNext()) {
                val key = iter.next()
                iter.remove()
                uploadRegion(key)
                if (System.nanoTime() - startNs >= UPLOAD_BUDGET_NS) break
            }
        }

        statUploadAccumNs += System.nanoTime() - startNs
    }

    private fun regionKey(cx: Int, cz: Int): Long =
        ((cx shr REGION_SHIFT).toLong() shl 32) or ((cz shr REGION_SHIFT).toLong() and 0xFFFFFFFFL)

    private fun packColumn(cx: Int, cz: Int): Long = (cx.toLong() shl 32) or (cz.toLong() and 0xFFFFFFFFL)

    /** Rebuilds one region's solid and water buffers from the cached data of its columns. */
    private fun uploadRegion(key: Long) {
        val rx = (key shr 32).toInt()
        val rz = key.toInt()
        val parts = regionParts
        val waterParts = regionWaterParts
        var anySolid = false
        var anyWater = false
        var k = 0
        for (dz in 0 until REGION_SIZE) {
            for (dx in 0 until REGION_SIZE) {
                val cx = rx * REGION_SIZE + dx
                val cz = rz * REGION_SIZE + dz
                val pos = ChunkPos(cx, cz)
                val slots = columnMeshData[pos]
                val waterSlots = columnWaterData[pos]
                var columnSolid = false
                for (s in 0 until WorldConfig.SUBCHUNKS_PER_CHUNK) {
                    val solid = slots?.get(s)
                    parts[k] = solid
                    if (solid != null) {
                        anySolid = true
                        columnSolid = true
                    }
                    val wet = waterSlots?.get(s)
                    waterParts[k] = wet
                    if (wet != null) anyWater = true
                    k++
                }
                val ck = packColumn(cx, cz)
                if (columnSolid) uploadedColumns.add(ck) else uploadedColumns.remove(ck)
            }
        }

        if (anySolid) {
            regionMeshes.getOrPut(key) { ChunkGpuMesh() }.uploadColumn(parts)
        } else {
            regionMeshes.remove(key)?.dispose()
        }
        if (anyWater) {
            regionWaterMeshes.getOrPut(key) { ChunkGpuMesh() }.uploadColumn(waterParts)
        } else {
            regionWaterMeshes.remove(key)?.dispose() // the last of this region's water is gone
        }
    }

    private fun drainUnloads() {
        while (true) {
            val pos = engine.worldManager.pendingUnloads.poll() ?: break
            columnMeshData.remove(pos)
            columnWaterData.remove(pos)
            uploadedColumns.remove(packColumn(pos.x, pos.z))
            // The region is rebuilt without this column (or dropped if it was the last one).
            dirtyRegions.add(regionKey(pos.x, pos.z))
        }
    }

    // ---- Distant terrain & coverage ---------------------------------------------------

    /** Walks the chunks around the player nearest-first and finds the first one with no
     *  finished mesh; everything closer than that is guaranteed to be on screen. */
    private fun updateNearCoverage(eyeX: Float, eyeZ: Float, nearRadius: Int) {
        val center = ChunkPos.fromWorld(eyeX, eyeZ)
        val offsets = ChunkRing.offsets(nearRadius)
        val cap = min(offsets.size, engine.worldManager.maxLoadedChunks)
        var covered = -1f
        for (i in 0 until cap) {
            val o = offsets[i]
            if (!uploadedColumns.contains(packColumn(center.x + o[0], center.z + o[1]))) {
                covered = sqrt((o[0] * o[0] + o[1] * o[1]).toFloat())
                break
            }
        }
        if (covered < 0f) {
            val last = offsets[max(0, cap - 1)]
            covered = sqrt((last[0] * last[0] + last[1] * last[1]).toFloat())
        }
        nearCoveredChunks = covered
        nearCenterX = (center.x + 0.5f) * WorldConfig.CHUNK_SIZE
        nearCenterZ = (center.z + 0.5f) * WorldConfig.CHUNK_SIZE
    }

    // ---- Drawing --------------------------------------------------------------

    private fun drawChunks(eyeX: Float, eyeZ: Float) {
        var n = 0
        var total = 0
        val regionBlocks = (REGION_SIZE * WorldConfig.CHUNK_SIZE).toFloat()
        for ((key, mesh) in regionMeshes) {
            if (!mesh.hasContent) continue // skip the frustum test too: nothing to draw here
            total++
            val baseX = (key shr 32).toInt() * regionBlocks
            val baseZ = key.toInt() * regionBlocks
            // Box hugs the region's real geometry (its actual min/max height), so a
            // region whose terrain sits entirely outside the view's vertical range is
            // culled even though the full world-height box would still poke in.
            if (!frustum.isBoxVisible(baseX, mesh.minY, baseZ, baseX + regionBlocks, mesh.maxY, baseZ + regionBlocks)) continue

            if (n == sortKeys.size) {
                sortKeys = sortKeys.copyOf(n * 2)
                sortMeshes = sortMeshes.copyOf(n * 2)
            }
            val dx = baseX + regionBlocks * 0.5f - eyeX
            val dz = baseZ + regionBlocks * 0.5f - eyeZ
            val d2 = (dx * dx + dz * dz).toInt()
            sortKeys[n] = (d2.toLong() shl 32) or n.toLong()
            sortMeshes[n] = mesh
            n++
        }

        // Front-to-back: nearest terrain first means the depth test throws away the
        // fragments of everything hidden behind it before they're ever shaded.
        Arrays.sort(sortKeys, 0, n)

        var tris = 0
        for (i in 0 until n) {
            val mesh = sortMeshes[(sortKeys[i] and 0xFFFFFFFFL).toInt()] ?: continue
            mesh.draw()
            tris += mesh.triangleCount
        }
        statDrawnCols = n
        statTotalCols = total
        statTris = tris
    }

    /** The translucent voxel-chunk water, farthest region first so blending composes correctly. */
    private fun drawNearWater(eyeX: Float, eyeZ: Float) {
        var n = 0
        val regionBlocks = (REGION_SIZE * WorldConfig.CHUNK_SIZE).toFloat()
        for ((key, mesh) in regionWaterMeshes) {
            if (!mesh.hasContent) continue
            val baseX = (key shr 32).toInt() * regionBlocks
            val baseZ = key.toInt() * regionBlocks
            // a hair of vertical padding for the swell the vertex shader adds
            if (!frustum.isBoxVisible(baseX, mesh.minY - 0.1f, baseZ, baseX + regionBlocks, mesh.maxY + 0.1f, baseZ + regionBlocks)) continue

            if (n == waterSortKeys.size) {
                waterSortKeys = waterSortKeys.copyOf(n * 2)
                waterSortMeshes = waterSortMeshes.copyOf(n * 2)
            }
            val dx = baseX + regionBlocks * 0.5f - eyeX
            val dz = baseZ + regionBlocks * 0.5f - eyeZ
            waterSortKeys[n] = ((dx * dx + dz * dz).toInt().toLong() shl 32) or n.toLong()
            waterSortMeshes[n] = mesh
            n++
        }
        if (n == 0) return
        Arrays.sort(waterSortKeys, 0, n)

        water.begin(frame)
        water.useNearArea(frame)
        var tris = 0
        for (i in n - 1 downTo 0) {
            val mesh = waterSortMeshes[(waterSortKeys[i] and 0xFFFFFFFFL).toInt()] ?: continue
            mesh.draw()
            tris += mesh.triangleCount
        }
        water.end()
        statWaterTris = tris
    }

    private fun drawHighlight() {
        val hit = engine.lastHit
        if (hit == null) {
            highlightValid = false
            return
        }
        val block = engine.world.getBlock(hit.blockX, hit.blockY, hit.blockZ)
        val shape = if (block.flat) 2 else if (block.plant) 1 else 0
        if (!highlightValid || hit.blockX != highlightX || hit.blockY != highlightY || hit.blockZ != highlightZ ||
            shape != highlightShape
        ) {
            highlightValid = true
            highlightX = hit.blockX
            highlightY = hit.blockY
            highlightZ = hit.blockZ
            highlightShape = shape
            uploadHighlightBox(hit.blockX.toFloat(), hit.blockY.toFloat(), hit.blockZ.toFloat(), shape)
        }
        GLES30.glUniform1f(uAlpha, 1f)
        highlightMesh.draw(GLES30.GL_LINES)
    }

    /** Outline of the targeted block: the whole cell for a solid block, the small selection
     *  box (see Raycaster) for a plant. */
    private fun uploadHighlightBox(x: Float, y: Float, z: Float, shape: Int) {
        val e = 0.002f // tiny outward expansion avoids z-fighting with the block's own faces
        var minX = 0f
        var maxX = 1f
        var maxY = 1f
        var minZ = 0f
        var maxZ = 1f
        if (shape == 1) {
            minX = Raycaster.PLANT_MIN
            maxX = Raycaster.PLANT_MAX
            minZ = Raycaster.PLANT_MIN
            maxZ = Raycaster.PLANT_MAX
            maxY = Raycaster.PLANT_HEIGHT
        } else if (shape == 2) {
            maxY = Raycaster.FLAT_HEIGHT
        }
        val x0 = x + minX - e; val x1 = x + maxX + e
        val y0 = y - e; val y1 = y + maxY + e
        val z0 = z + minZ - e; val z1 = z + maxZ + e
        val corners = arrayOf(
            floatArrayOf(x0, y0, z0), floatArrayOf(x1, y0, z0), floatArrayOf(x1, y0, z1), floatArrayOf(x0, y0, z1),
            floatArrayOf(x0, y1, z0), floatArrayOf(x1, y1, z0), floatArrayOf(x1, y1, z1), floatArrayOf(x0, y1, z1)
        )
        val edges = arrayOf(
            0 to 1, 1 to 2, 2 to 3, 3 to 0,
            4 to 5, 5 to 6, 6 to 7, 7 to 4,
            0 to 4, 1 to 5, 2 to 6, 3 to 7
        )
        val uv = atlas.uvFor(TextureAtlas.WHITE_CELL)
        val floats = FloatArray(edges.size * 2 * 6)
        var fi = 0
        for ((a, b) in edges) {
            for (idx in intArrayOf(a, b)) {
                val c = corners[idx]
                floats[fi++] = c[0]; floats[fi++] = c[1]; floats[fi++] = c[2]
                floats[fi++] = uv.u0; floats[fi++] = uv.v0
                floats[fi++] = 1.3f // >1 shade reads as a bright, unmistakable outline
            }
        }
        val indices = IntArray(edges.size * 2) { it }
        highlightMesh.upload(MeshData(floats, indices, edges.size * 2))
    }

    private fun drawParticles() {
        val ps = engine.particles
        val n = ps.count()
        if (n == 0) return

        val neededFloats = n * 24 * 6
        val neededIndices = n * 36
        if (particleFloats.size < neededFloats) particleFloats = FloatArray(neededFloats)
        if (particleIndices.size < neededIndices) particleIndices = IntArray(neededIndices)
        particleVerts = 0
        particleIdx = 0

        for (p in 0 until n) {
            val cx = ps.x(p); val cy = ps.y(p); val cz = ps.z(p)
            val half = ps.scale(p)
            val uv = atlas.uvFor(ps.cellOf(p))
            val x0 = cx - half; val x1 = cx + half
            val y0 = cy - half; val y1 = cy + half
            val z0 = cz - half; val z1 = cz + half

            addParticleFace(x0, y1, z0, x1, y1, z0, x1, y1, z1, x0, y1, z1, uv) // top
            addParticleFace(x0, y0, z1, x1, y0, z1, x1, y0, z0, x0, y0, z0, uv) // bottom
            addParticleFace(x1, y0, z0, x0, y0, z0, x0, y1, z0, x1, y1, z0, uv) // north
            addParticleFace(x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1, uv) // south
            addParticleFace(x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1, z0, uv) // west
            addParticleFace(x1, y0, z1, x1, y0, z0, x1, y1, z0, x1, y1, z1, uv) // east
        }

        particleMesh.uploadRaw(particleFloats, particleVerts * 6, particleIndices, particleIdx)
        GLES30.glUniform1f(uAlpha, 1f)
        particleMesh.draw()
    }

    /** Appends one particle quad straight into the shared scratch arrays (no per-face
     *  or per-particle allocation, unlike the arrays-of-arrays this replaced). */
    private fun addParticleFace(
        ax: Float, ay: Float, az: Float,
        bx: Float, by: Float, bz: Float,
        cx: Float, cy: Float, cz: Float,
        dx: Float, dy: Float, dz: Float,
        uv: UVRect
    ) {
        val f = particleFloats
        var fi = particleVerts * 6
        f[fi++] = ax; f[fi++] = ay; f[fi++] = az; f[fi++] = uv.u0; f[fi++] = uv.v0; f[fi++] = 1f
        f[fi++] = bx; f[fi++] = by; f[fi++] = bz; f[fi++] = uv.u1; f[fi++] = uv.v0; f[fi++] = 1f
        f[fi++] = cx; f[fi++] = cy; f[fi++] = cz; f[fi++] = uv.u1; f[fi++] = uv.v1; f[fi++] = 1f
        f[fi++] = dx; f[fi++] = dy; f[fi++] = dz; f[fi++] = uv.u0; f[fi++] = uv.v1; f[fi] = 1f

        val base = particleVerts
        val ix = particleIndices
        var k = particleIdx
        ix[k++] = base; ix[k++] = base + 1; ix[k++] = base + 2
        ix[k++] = base; ix[k++] = base + 2; ix[k++] = base + 3
        particleIdx = k
        particleVerts += 4
    }

    /** The creative destroy-laser beam: two crossed quads from just right of and below the eye
     *  out to [LASER_LENGTH] blocks along the view direction, in bright light blue. */
    private fun drawLaser(eyeX: Float, eyeY: Float, eyeZ: Float) {
        val fx = frame.forwardX
        val fy = frame.forwardY
        val fz = frame.forwardZ
        val sx = eyeX + frame.rightX * 0.22f - frame.upX * 0.18f + fx * 0.5f
        val sy = eyeY + frame.rightY * 0.22f - frame.upY * 0.18f + fy * 0.5f
        val sz = eyeZ + frame.rightZ * 0.22f - frame.upZ * 0.18f + fz * 0.5f
        val ex = eyeX + fx * LASER_LENGTH
        val ey = eyeY + fy * LASER_LENGTH
        val ez = eyeZ + fz * LASER_LENGTH
        val r = 0.07f
        val uv = atlas.uvFor(TextureAtlas.WATER_CELL)
        val f = laserFloats
        var i = 0
        // quad A, spread along the camera's right vector; quad B, along its up vector
        for (q in 0 until 2) {
            val ox = if (q == 0) frame.rightX * r else frame.upX * r
            val oy = if (q == 0) frame.rightY * r else frame.upY * r
            val oz = if (q == 0) frame.rightZ * r else frame.upZ * r
            f[i++] = sx - ox; f[i++] = sy - oy; f[i++] = sz - oz; f[i++] = uv.u0; f[i++] = uv.v0; f[i++] = 1.6f
            f[i++] = sx + ox; f[i++] = sy + oy; f[i++] = sz + oz; f[i++] = uv.u0; f[i++] = uv.v0; f[i++] = 1.6f
            f[i++] = ex + ox; f[i++] = ey + oy; f[i++] = ez + oz; f[i++] = uv.u0; f[i++] = uv.v0; f[i++] = 1.6f
            f[i++] = ex - ox; f[i++] = ey - oy; f[i++] = ez - oz; f[i++] = uv.u0; f[i++] = uv.v0; f[i++] = 1.6f
        }
        laserMesh.uploadRaw(f, 8 * 6, laserIndices, laserIndices.size)
        GLES30.glUniform1f(uAlpha, 1f)
        laserMesh.draw()
    }

    // ---- Stats overlay ----------------------------------------------------------------

    private fun updateFps(dt: Float, cpuMs: Float, underwater: Boolean) {
        fpsAccumTime += dt
        fpsAccumFrames++
        if (dt > statWorstDt) statWorstDt = dt
        statCpuAccumMs += cpuMs
        if (cpuMs > statCpuMaxMs) statCpuMaxMs = cpuMs

        if (fpsAccumTime >= 0.4f) {
            currentFps = fpsAccumFrames / fpsAccumTime
            val statsText = if (engine.settings.showFps) buildStatsText(underwater) else null
            fpsAccumTime = 0f
            fpsAccumFrames = 0
            statWorstDt = 0f
            statCpuAccumMs = 0f
            statCpuMaxMs = 0f
            statUploadAccumNs = 0L
            mainHandler.post { onPeriodicTick(statsText) }
        }
    }

    /** cpu = time the GL thread spent building this frame's commands (NOT gpu time):
     *  low cpu but low FPS means the GPU is the bottleneck; high cpu means the game
     *  thread is. worst = longest single frame in the window (hitches). up = time spent
     *  in mesh uploads per frame. dist = current adaptive-distance scale. */
    private fun buildStatsText(underwater: Boolean): String {
        val frames = max(1, fpsAccumFrames)
        val cpuAvg = statCpuAccumMs / frames
        val upAvgMs = (statUploadAccumNs / 1_000_000f) / frames
        val dist = if (underwater) "water" else "${(distScale * 100f).toInt()}%"
        return String.format(
            Locale.US,
            "FPS: %d  worst: %dms\ncpu: %.1fms (max %.1f)  up: %.1fms\nreg: %d/%d  tris: %dk  dist: %s\nfar: %d/%d  tris: %dk  water: %dk  cover: %dm\n%s",
            currentFps.toInt(), (statWorstDt * 1000f).toInt(),
            cpuAvg, statCpuMaxMs, upAvgMs,
            statDrawnCols, statTotalCols, statTris / 1000, dist,
            far.drawnTiles, far.totalTiles, far.drawnTriangles / 1000, statWaterTris / 1000, fogCover.toInt(),
            engine.debugStats()
        )
    }
}
