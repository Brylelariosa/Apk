package com.voxelsandbox.game.world

/**
 * Central sizing constants for the voxel world.
 *
 * The world is 128 blocks tall with sea level at 40. That is the vertical room natural
 * looking terrain needs: ocean floors well below sea level, lowland plains just above
 * it and mountain ranges that climb ~80 blocks higher. Memory stays bounded because
 * (a) the mostly-empty upper sub-chunks of a chunk share one immutable all-air array and
 * (b) WorldManager caps how many chunks stay resident (see RESIDENT_BYTES_PER_CHUNK).
 */
object WorldConfig {
    const val CHUNK_SIZE = 16 // X/Z extent of a chunk
    const val SUBCHUNK_HEIGHT = 16
    const val SUBCHUNKS_PER_CHUNK = 8
    const val WORLD_HEIGHT = SUBCHUNK_HEIGHT * SUBCHUNKS_PER_CHUNK // 128

    const val SEA_LEVEL = 40

    const val BLOCKS_PER_SUBCHUNK = CHUNK_SIZE * SUBCHUNK_HEIGHT * CHUNK_SIZE // 4096
    const val BYTES_PER_CHUNK = CHUNK_SIZE * WORLD_HEIGHT * CHUNK_SIZE // 32768 (worst case)

    /**
     * Rough resident cost of one loaded chunk, used by WorldManager to turn the heap size
     * into a chunk budget. It covers the block data of the (typically 4-6) non-empty
     * sub-chunks plus the CPU-side mesh cache kept for every visible chunk, which is
     * several times larger than the raw blocks.
     */
    const val RESIDENT_BYTES_PER_CHUNK = 96 * 1024

    const val MAX_INTERACT_REACH = 6f

    /** Player falling below this Y (e.g. an unloaded/void column) is teleported back
     *  above the terrain rather than falling forever. */
    const val VOID_Y = -16f
}
