package com.zipapkbuilder

import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.Base64
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.widget.NestedScrollView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    // ── UI ──────────────────────────────────────────────────────────────────
    private lateinit var etToken: EditText
    private lateinit var tvOwnerInfo: TextView
    private lateinit var etRepo: EditText
    private lateinit var etBranch: EditText
    private lateinit var btnPickZip: Button
    private lateinit var tvFileName: TextView
    private lateinit var btnUploadBuild: Button
    private lateinit var tvStatus: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var btnDownloadApk: Button
    private lateinit var tvLog: TextView
    private lateinit var scrollLog: NestedScrollView
    private lateinit var btnManageZips: Button
    private lateinit var btnWorkflowLog: Button
    private lateinit var btnBrowseArtifacts: Button
    private lateinit var btnCopyLog: Button
    private lateinit var btnSaveLog: Button

    // ── State ────────────────────────────────────────────────────────────────
    private val mainHandler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("cfg", MODE_PRIVATE) }

    private var selectedZipUri: Uri? = null
    private var selectedZipName = ""
    private var artifactDownloadUrl: String? = null
    private var isBusy = false

    private var lastOwner      = ""
    private var lastRemotePath = ""
    private var lastFileSha: String? = null
    private var lastRunId: Long = -1L

    // ── SharedPreferences keys ────────────────────────────────────────────────
    companion object {
        private const val PREF_ARTIFACT_URL  = "artifact_url"
        private const val PREF_ARTIFACT_NAME = "artifact_name"
        private const val PREF_LAST_RUN_ID   = "last_run_id"
        private const val PREF_LAST_OWNER    = "last_owner"
        private const val PREF_LAST_REPO_KEY = "last_repo_saved"
    }

    // ── Embedded workflow YAML ────────────────────────────────────────────────
    private val WORKFLOW_YAML: String by lazy {
        val d = "\$"
        """
name: Build APK

on:
  push:
    branches: [ main, master ]
    paths:
      - 'uploads/**'
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    permissions:
      contents: write

    steps:
      - name: Checkout code
        uses: actions/checkout@v4
        with:
          token: ${d}{{ secrets.GITHUB_TOKEN }}

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          java-version: '17'
          distribution: 'temurin'

      - name: Setup Android SDK
        uses: android-actions/setup-android@v3

      - name: Cache NDK and CMake
        id: cache-ndk
        uses: actions/cache@v4
        with:
          path: |
            ${d}{{ env.ANDROID_HOME }}/ndk/25.2.9519653
            ${d}{{ env.ANDROID_HOME }}/ndk/25.1.8937393
            ${d}{{ env.ANDROID_HOME }}/cmake/3.22.1
          key: ndk-25.2.9519653-25.1.8937393-cmake-3.22.1

      - name: Install NDK and CMake
        run: |
          for NDK_VER in "25.2.9519653" "25.1.8937393"; do
            if [ ! -d "${d}ANDROID_SDK_ROOT/ndk/${d}NDK_VER" ]; then
              echo "Installing NDK ${d}NDK_VER..."
              sdkmanager --install "ndk;${d}NDK_VER"
            else
              echo "NDK ${d}NDK_VER already present"
            fi
          done
          if [ ! -d "${d}ANDROID_SDK_ROOT/cmake/3.22.1" ]; then
            sdkmanager --install "cmake;3.22.1"
          fi
          echo "ANDROID_NDK_HOME=${d}ANDROID_SDK_ROOT/ndk/25.2.9519653" >> ${d}GITHUB_ENV

      - name: Setup Gradle
        uses: gradle/actions/setup-gradle@v3
        with:
          gradle-version: '8.6'
          cache-read-only: false

      - name: Unzip project
        run: |
          ZIP=${d}(find . -path './.git' -prune -o -maxdepth 3 -name "*.zip" -printf "%T@ %p\n" | sort -rn | head -1 | cut -d" " -f2-)
          if [ -z "${d}ZIP" ]; then
            echo "##[error]No ZIP file found in repository!"
            exit 1
          fi
          ZIP_NAME=${d}(basename "${d}ZIP" .zip)
          echo "zip_name=${d}ZIP_NAME" >> ${d}GITHUB_ENV
          echo "zip_path=${d}ZIP" >> ${d}GITHUB_ENV
          echo "Found zip: ${d}ZIP"
          unzip -q "${d}ZIP" -d extracted

      - name: Find project directory
        id: find_project
        run: |
          RESULT=${d}(find extracted -maxdepth 4 \( -name "settings.gradle" -o -name "settings.gradle.kts" \) | head -1)
          if [ -z "${d}RESULT" ]; then
            echo "##[error]No settings.gradle found inside the zip!"
            find extracted | sort
            exit 1
          fi
          PROJECT_DIR=${d}(dirname "${d}RESULT")
          echo "Found project at: ${d}PROJECT_DIR"
          echo "project_dir=${d}PROJECT_DIR" >> ${d}GITHUB_OUTPUT

      - name: Cache CMake / C++ build outputs
        uses: actions/cache@v4
        with:
          path: ${d}{{ steps.find_project.outputs.project_dir }}/app/.cxx
          key: cxx-debug-${d}{{ hashFiles('**/CMakeLists.txt', '**/core/*.cpp', '**/core/*.h', '**/jni_bridge.cpp') }}
          restore-keys: cxx-debug-

      - name: Fetch gradle-wrapper.jar
        working-directory: ${d}{{ steps.find_project.outputs.project_dir }}
        run: |
          GRADLE_VERSION="8.6"
          JAR="gradle/wrapper/gradle-wrapper.jar"
          mkdir -p gradle/wrapper
          curl --fail --silent --show-error --location \
            "https://raw.githubusercontent.com/gradle/gradle/v${d}{GRADLE_VERSION}.0/gradle/wrapper/gradle-wrapper.jar" \
            -o "${d}JAR"
          SIZE=${d}(stat -c%s "${d}JAR")
          if [ "${d}SIZE" -lt 10000 ]; then
            echo "ERROR: gradle-wrapper.jar too small (${d}{SIZE} bytes)"
            exit 1
          fi

      - name: Make gradlew executable
        working-directory: ${d}{{ steps.find_project.outputs.project_dir }}
        run: chmod +x gradlew && sed -i 's/\r//' gradlew

      - name: Build Debug APK
        id: build
        working-directory: ${d}{{ steps.find_project.outputs.project_dir }}
        run: ./gradlew assembleDebug --no-daemon --configuration-cache --build-cache --parallel
        env:
          ANDROID_NDK_HOME: ${d}{{ env.ANDROID_NDK_HOME }}

      - name: Upload APK artifact
        if: success()
        uses: actions/upload-artifact@v4
        with:
          name: ${d}{{ env.zip_name }}-debug-v${d}{{ github.run_number }}
          path: ${d}{{ steps.find_project.outputs.project_dir }}/app/build/outputs/apk/debug/*.apk
          retention-days: 30

      - name: Clean up - delete zip after successful build
        if: success()
        run: |
          ZIP="${d}{{ env.zip_path }}"
          if [ -n "${d}ZIP" ] && [ -f "${d}ZIP" ]; then
            git config user.name "github-actions[bot]"
            git config user.email "github-actions[bot]@users.noreply.github.com"
            git rm "${d}ZIP"
            git commit -m "ci: remove ${d}ZIP after build #${d}{{ github.run_number }} [skip ci]"
            git push
          fi

      - name: Clean up - delete zip after failed build
        if: failure()
        run: |
          ZIP="${d}{{ env.zip_path }}"
          if [ -n "${d}ZIP" ] && [ -f "${d}ZIP" ]; then
            git config user.name "github-actions[bot]"
            git config user.email "github-actions[bot]@users.noreply.github.com"
            git rm "${d}ZIP"
            git commit -m "ci: remove ${d}ZIP (build failed #${d}{{ github.run_number }}) [skip ci]"
            git push
          fi
        """.trimIndent()
    }

    // ── File picker ──────────────────────────────────────────────────────────
    private val pickZip = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri ?: return@registerForActivityResult
        selectedZipUri = uri
        selectedZipName = resolveFileName(uri)
        tvFileName.text = selectedZipName
        appendLog("Selected: $selectedZipName")
    }

    // ── Lifecycle ────────────────────────────────────────────────────────────
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etToken        = findViewById(R.id.etToken)
        tvOwnerInfo    = findViewById(R.id.tvOwnerInfo)
        etRepo         = findViewById(R.id.etRepo)
        etBranch       = findViewById(R.id.etBranch)
        btnPickZip     = findViewById(R.id.btnPickZip)
        tvFileName     = findViewById(R.id.tvFileName)
        btnUploadBuild = findViewById(R.id.btnUploadBuild)
        tvStatus       = findViewById(R.id.tvStatus)
        progressBar    = findViewById(R.id.progressBar)
        btnDownloadApk = findViewById(R.id.btnDownloadApk)
        btnBrowseArtifacts = findViewById(R.id.btnBrowseArtifacts)
        btnManageZips  = findViewById(R.id.btnManageZips)
        btnWorkflowLog = findViewById(R.id.btnWorkflowLog)
        btnCopyLog     = findViewById(R.id.btnCopyLog)
        btnSaveLog     = findViewById(R.id.btnSaveLog)
        tvLog          = findViewById(R.id.tvLog)
        scrollLog      = findViewById(R.id.scrollLog)

        etToken.setText(prefs.getString("token", ""))
        etRepo.setText(prefs.getString("repo", ""))
        etBranch.setText(prefs.getString("branch", "main"))

        btnPickZip.setOnClickListener     { if (!isBusy) pickZip.launch("application/zip") }
        btnUploadBuild.setOnClickListener  { if (!isBusy) startFlow() }
        btnDownloadApk.setOnClickListener  { artifactDownloadUrl?.let { downloadArtifact(it) } }
        btnBrowseArtifacts.setOnClickListener { if (!isBusy) browseAllArtifacts() }
        btnManageZips.setOnClickListener   { if (!isBusy) showManageFilesDialog() }
        btnWorkflowLog.setOnClickListener  { if (!isBusy) fetchAndShowWorkflowLog() }
        btnCopyLog.setOnClickListener      { copyLogToClipboard() }
        btnSaveLog.setOnClickListener      { saveLogToFile() }

        // Restore any previously completed build so Download still works after restart
        restoreSavedBuildState()
    }

    // ── Build state persistence ───────────────────────────────────────────────

    private fun saveBuildState(artUrl: String, artName: String, runId: Long, owner: String, repo: String) {
        prefs.edit()
            .putString(PREF_ARTIFACT_URL,  artUrl)
            .putString(PREF_ARTIFACT_NAME, artName)
            .putLong(PREF_LAST_RUN_ID,     runId)
            .putString(PREF_LAST_OWNER,    owner)
            .putString(PREF_LAST_REPO_KEY, repo)
            .apply()
    }

    private fun clearBuildState() {
        prefs.edit()
            .remove(PREF_ARTIFACT_URL)
            .remove(PREF_ARTIFACT_NAME)
            .remove(PREF_LAST_RUN_ID)
            .remove(PREF_LAST_OWNER)
            .remove(PREF_LAST_REPO_KEY)
            .apply()
    }

    /**
     * On cold start, checks SharedPreferences for the last successful build.
     * If found, immediately re-enables the Download button so the user can still
     * download the APK even after killing and reopening the app.
     */
    private fun restoreSavedBuildState() {
        val savedUrl   = prefs.getString(PREF_ARTIFACT_URL, null)
        val savedName  = prefs.getString(PREF_ARTIFACT_NAME, "APK") ?: "APK"
        val savedRunId = prefs.getLong(PREF_LAST_RUN_ID, -1L)
        val savedOwner = prefs.getString(PREF_LAST_OWNER, "") ?: ""
        val savedRepo  = prefs.getString(PREF_LAST_REPO_KEY, "") ?: ""

        if (!savedUrl.isNullOrEmpty()) {
            artifactDownloadUrl      = savedUrl
            lastRunId                = savedRunId
            lastOwner                = savedOwner
            btnDownloadApk.isEnabled = true
            btnWorkflowLog.isEnabled = savedRunId != -1L

            if (savedOwner.isNotEmpty()) tvOwnerInfo.text = "✓  @$savedOwner (last build)"

            setStatus("Ready ✓")
            appendLog("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
            appendLog("✓ Previous build restored!")
            appendLog("  Artifact : $savedName")
            if (savedRepo.isNotEmpty())  appendLog("  Repo     : $savedRepo")
            if (savedRunId != -1L)       appendLog("  Run #    : $savedRunId")
            appendLog("  ▸ Tap  📲 Download & Install APK  to save to your phone.")
            appendLog("  ▸ Tap  🚀 Upload & Build  to start a new build.")
            appendLog("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        } else {
            setStatus("Idle")
        }
    }

    // ── Entry point ──────────────────────────────────────────────────────────
    private fun startFlow() {
        val token  = etToken.text.toString().trim()
        val repo   = etRepo.text.toString().trim()
        val branch = etBranch.text.toString().trim().ifEmpty { "main" }
        val uri    = selectedZipUri

        if (token.isEmpty()) { appendLog("⚠ Enter your GitHub Personal Access Token."); return }
        if (repo.isEmpty())  { appendLog("⚠ Enter a repository name."); return }
        if (uri == null)     { appendLog("⚠ Pick a ZIP file first."); return }

        prefs.edit()
            .putString("token",  token)
            .putString("repo",   repo)
            .putString("branch", branch)
            .apply()

        // Clear old build state so stale URL doesn't linger
        clearBuildState()

        setBusy(true)
        tvLog.text = ""
        artifactDownloadUrl      = null
        btnDownloadApk.isEnabled = false
        lastOwner      = ""
        lastRemotePath = ""
        lastFileSha    = null
        lastRunId      = -1L
        mainHandler.post {
            tvOwnerInfo.text         = ""
            btnWorkflowLog.isEnabled = false
        }

        thread { runFlow(token, repo, branch, uri) }
    }

    // ── Main flow ────────────────────────────────────────────────────────────
    private fun runFlow(token: String, repo: String, branch: String, uri: Uri) {
        try {
            setStatus("Verifying token…")
            appendLog("Verifying GitHub token…")
            val owner = fetchOwner(token)
                ?: throw Exception("Token invalid or no network. Make sure your PAT has 'repo' scope.")
            appendLog("✓  Signed in as @$owner")
            lastOwner = owner
            mainHandler.post { tvOwnerInfo.text = "✓  @$owner" }

            setStatus("Checking repo…")
            appendLog("Checking github.com/$owner/$repo …")
            ensureRepo(token, owner, repo)

            setStatus("Setting up workflow…")
            ensureWorkflow(token, owner, repo, branch)

            setStatus("Reading ZIP…")
            appendLog("Reading ZIP…")
            val bytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
            val b64   = Base64.encodeToString(bytes, Base64.NO_WRAP)
            appendLog("Size: ${bytes.size / 1024} KB  →  encoded: ${b64.length / 1024} KB")
            if (b64.length > 95 * 1024 * 1024) {
                throw Exception("ZIP too large for GitHub Contents API (> ~70 MB raw).")
            }

            setStatus("Uploading…")
            appendLog("Uploading to github.com/$owner/$repo …")
            val remotePath  = "uploads/$selectedZipName"
            val existingSha = fetchFileSha(token, owner, repo, remotePath)
            val uploadJson  = JSONObject().apply {
                put("message", "ci: upload $selectedZipName [run ${System.currentTimeMillis()}]")
                put("content", b64)
                put("branch",  branch)
                if (existingSha != null) {
                    put("sha", existingSha)
                    appendLog("Replacing existing file (SHA: ${existingSha.take(8)}…)")
                }
            }.toString()

            val (upCode, upBody) = httpPut(token, apiContents(owner, repo, remotePath), uploadJson)
            if (upCode !in 200..201) throw Exception("Upload failed ($upCode): ${upBody.take(400)}")
            lastRemotePath = remotePath
            lastFileSha = try {
                JSONObject(upBody).optJSONObject("content")?.optString("sha")
            } catch (_: Exception) { null }
            appendLog("Upload OK — GitHub Actions will start shortly…")

            setStatus("Waiting for build…")
            appendLog("Waiting for GitHub Actions to pick up the commit…")
            val afterMs = System.currentTimeMillis()
            Thread.sleep(6_000)

            val runId = waitForRun(token, owner, repo, branch, afterMs)
                ?: throw Exception("No workflow run appeared within 3 minutes. " +
                    "Check that build.yml is on the $branch branch.")
            lastRunId = runId
            mainHandler.post { btnWorkflowLog.isEnabled = true }
            appendLog("Run #$runId started — streaming live build log…")
            appendLog("─────────────────────────────────────")

            setStatus("Building…")
            val success = streamBuildLog(token, owner, repo, runId)
            if (!success) throw Exception("Build failed. Tap '🔍 Build Log' for the full output.")

            setStatus("Fetching APK…")
            appendLog("Build succeeded! Looking for APK artifact…")
            val (artName, artUrl) = fetchArtifact(token, owner, repo, runId)
                ?: throw Exception("Run succeeded but no artifact found.")

            artifactDownloadUrl = artUrl
            appendLog("Artifact ready: $artName")
            setStatus("Ready ✓")

            // ─── Persist so Download button works after any app restart ──────
            saveBuildState(artUrl, artName, runId, owner, repo)

            mainHandler.post { btnDownloadApk.isEnabled = true }

        } catch (e: Exception) {
            appendLog("✗ ${e.message}")
            setStatus("Failed")
        } finally {
            setBusy(false)
        }
    }

    // ── Auto-setup helpers ────────────────────────────────────────────────────

    private fun fetchOwner(token: String): String? = try {
        val (code, body) = httpGet(token, "https://api.github.com/user")
        if (code == 200) JSONObject(body).optString("login").takeIf { it.isNotEmpty() }
        else null
    } catch (_: Exception) { null }

    private fun ensureRepo(token: String, owner: String, repo: String) {
        val (code, _) = httpGet(token, "https://api.github.com/repos/$owner/$repo")
        if (code == 200) { appendLog("Repo already exists ✓"); return }
        appendLog("Repo not found — creating github.com/$owner/$repo …")
        val body = JSONObject().apply {
            put("name",        repo)
            put("private",     false)
            put("auto_init",   true)
            put("description", "APK build repo — managed by ZipApkBuilder")
        }.toString()
        val (createCode, createBody) = httpPost(token, "https://api.github.com/user/repos", body)
        if (createCode !in 200..201) throw Exception("Could not create repo ($createCode): ${createBody.take(300)}")
        appendLog("Repo created ✓ — waiting for GitHub to initialise it…")
        Thread.sleep(4_000)
    }

    private fun ensureWorkflow(token: String, owner: String, repo: String, branch: String) {
        val path = ".github/workflows/build.yml"
        val existingSha = fetchFileSha(token, owner, repo, path)
        if (existingSha != null) { appendLog("Workflow already present ✓"); return }
        appendLog("Committing build workflow to repo…")
        val encoded = Base64.encodeToString(WORKFLOW_YAML.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
        val payload = JSONObject().apply {
            put("message", "ci: add GitHub Actions build workflow")
            put("content", encoded)
            put("branch",  branch)
        }.toString()
        val (code, body) = httpPut(token, apiContents(owner, repo, path), payload)
        if (code !in 200..201) throw Exception("Could not commit workflow ($code): ${body.take(300)}")
        appendLog("Workflow committed ✓")
        Thread.sleep(2_000)
    }

    // ── GitHub API helpers ────────────────────────────────────────────────────

    private fun fetchFileSha(token: String, owner: String, repo: String, path: String): String? =
        try {
            val (code, body) = httpGet(token, apiContents(owner, repo, path))
            if (code == 200) JSONObject(body).optString("sha").takeIf { it.isNotEmpty() }
            else null
        } catch (_: Exception) { null }

    private fun waitForRun(token: String, owner: String, repo: String, branch: String, afterMs: Long): Long? {
        val deadline = System.currentTimeMillis() + 3 * 60_000L
        while (System.currentTimeMillis() < deadline) {
            try {
                val url = "${apiRuns(owner, repo)}?branch=$branch&per_page=10&event=push"
                val (code, body) = httpGet(token, url)
                if (code == 200) {
                    val runs = JSONObject(body).getJSONArray("workflow_runs")
                    for (i in 0 until runs.length()) {
                        val run   = runs.getJSONObject(i)
                        val runMs = parseIso8601(run.getString("created_at"))
                        if (runMs >= afterMs - 15_000) return run.getLong("id")
                    }
                }
            } catch (_: Exception) {}
            Thread.sleep(10_000)
        }
        return null
    }

    private fun streamBuildLog(token: String, owner: String, repo: String, runId: Long): Boolean {
        val deadline    = System.currentTimeMillis() + 45 * 60_000L
        val stepStarted  = mutableSetOf<Int>()
        val stepFinished = mutableSetOf<Int>()
        val tsRegex      = Regex("""^\d{4}-\d{2}-\d{2}T[\d:.]+Z\s""")
        val ansiRegex    = Regex("""\x1B\[[0-9;]*[A-Za-z]""")
        var conclusion   = ""

        while (System.currentTimeMillis() < deadline) {
            try {
                val (jCode, jBody) = httpGet(token, "${apiRuns(owner, repo)}/$runId/jobs")
                if (jCode == 200) {
                    val jobsArr = JSONObject(jBody).optJSONArray("jobs")
                    if (jobsArr != null && jobsArr.length() > 0) {
                        val steps = jobsArr.getJSONObject(0).optJSONArray("steps")
                        if (steps != null) {
                            for (i in 0 until steps.length()) {
                                val step     = steps.getJSONObject(i)
                                val num      = step.getInt("number")
                                val name     = step.getString("name")
                                val status   = step.optString("status", "")
                                val stepConc = step.optString("conclusion", "")
                                if (status == "in_progress" && stepStarted.add(num)) appendLog("▶ $name")
                                if (status == "completed" && stepFinished.add(num)) {
                                    if (!stepStarted.contains(num)) appendLog("▶ $name")
                                    val icon = if (stepConc == "success") "✓" else "✗"
                                    val started   = step.optString("started_at", "")
                                    val completed = step.optString("completed_at", "")
                                    val dur = if (started.isNotEmpty() && completed.isNotEmpty()) {
                                        try {
                                            val e = parseIso8601(completed); val s = parseIso8601(started)
                                            if (e > s) "  ${(e - s) / 1000}s" else ""
                                        } catch (_: Exception) { "" }
                                    } else ""
                                    appendLog("  $icon $name$dur")
                                }
                            }
                        }
                    }
                }
                val (sCode, sBody) = httpGet(token, "${apiRuns(owner, repo)}/$runId")
                if (sCode == 200) {
                    val obj = JSONObject(sBody)
                    conclusion = obj.optString("conclusion", "")
                    if (obj.getString("status") == "completed") break
                }
            } catch (_: Exception) {}
            Thread.sleep(5_000)
        }

        // Fetch and append full log text
        try {
            val (jCode, jBody) = httpGet(token, "${apiRuns(owner, repo)}/$runId/jobs")
            if (jCode == 200) {
                val jobsArr = JSONObject(jBody).optJSONArray("jobs")
                if (jobsArr != null && jobsArr.length() > 0) {
                    val jobId  = jobsArr.getJSONObject(0).getLong("id")
                    val logUrl = "https://api.github.com/repos/$owner/$repo/actions/jobs/$jobId/logs"
                    val conn1  = (URL(logUrl).openConnection() as HttpURLConnection).apply {
                        requestMethod = "GET"
                        setRequestProperty("Authorization", "token $token")
                        setRequestProperty("Accept", "application/vnd.github.v3+json")
                        instanceFollowRedirects = false
                        connectTimeout = 20_000; readTimeout = 60_000
                    }
                    val rawLog: String? = when (val c = conn1.responseCode) {
                        in 301..308 -> {
                            val loc = conn1.getHeaderField("Location"); conn1.disconnect()
                            try {
                                val c2 = (URL(loc).openConnection() as HttpURLConnection).apply {
                                    requestMethod = "GET"; connectTimeout = 20_000; readTimeout = 60_000
                                }
                                if (c2.responseCode == 200) c2.inputStream.bufferedReader().readText().also { c2.disconnect() }
                                else { c2.disconnect(); null }
                            } catch (_: Exception) { null }
                        }
                        200  -> conn1.inputStream.bufferedReader().readText().also { conn1.disconnect() }
                        else -> { conn1.disconnect(); null }
                    }
                    if (rawLog != null) {
                        appendLog("─────────────────────────────────────")
                        val groupRx = Regex("""^##\[(?:group|endgroup)\]""")
                        for (raw in rawLog.lines()) {
                            val line = ansiRegex.replace(tsRegex.replace(raw, ""), "")
                            if (!groupRx.containsMatchIn(line) && line.isNotBlank()) appendLog(line)
                        }
                    }
                }
            }
        } catch (_: Exception) {}

        appendLog("─────────────────────────────────────")
        appendLog(if (conclusion == "success") "✓ Build completed successfully" else "✗ Build $conclusion")
        return conclusion == "success"
    }

    private fun fetchArtifact(token: String, owner: String, repo: String, runId: Long): Pair<String, String>? {
        val (code, body) = httpGet(token, "${apiRuns(owner, repo)}/$runId/artifacts")
        if (code != 200) return null
        val artifacts = JSONObject(body).getJSONArray("artifacts")
        if (artifacts.length() == 0) return null
        val art = artifacts.getJSONObject(0)
        return art.getString("name") to art.getString("archive_download_url")
    }

    // ── Download & Install ────────────────────────────────────────────────────

    private fun downloadArtifact(downloadUrl: String) {
        if (isBusy) return
        setBusy(true)
        setStatus("Downloading…")
        appendLog("Downloading artifact ZIP from GitHub…")
        val token = etToken.text.toString().trim()

        // Use the artifact name exactly as GitHub names it (same as the website)
        val rawName = prefs.getString(PREF_ARTIFACT_NAME, "artifact") ?: "artifact"
        val zipFileName = if (rawName.endsWith(".zip", ignoreCase = true)) rawName else "$rawName.zip"

        thread {
            try {
                // 1. Resolve GitHub's redirect to the actual download URL
                val conn0 = URL(downloadUrl).openConnection() as HttpURLConnection
                conn0.setRequestProperty("Authorization", "token $token")
                conn0.setRequestProperty("Accept", "application/vnd.github.v3+json")
                conn0.instanceFollowRedirects = false
                conn0.connectTimeout = 30_000
                conn0.readTimeout    = 30_000
                conn0.connect()
                val realUrl = if (conn0.responseCode in 301..308) {
                    val loc = conn0.getHeaderField("Location")
                    conn0.disconnect(); loc
                } else { conn0.disconnect(); downloadUrl }

                // 2. Download the artifact ZIP
                val dlConn = URL(realUrl).openConnection() as HttpURLConnection
                dlConn.connectTimeout = 60_000
                dlConn.readTimeout   = 300_000
                val total = dlConn.contentLength
                appendLog("Downloading… (${if (total > 0) "${total / 1024} KB" else "size unknown"})")

                val artifactZip = File(cacheDir, "artifact_${System.currentTimeMillis()}.zip")
                dlConn.inputStream.use { inp -> FileOutputStream(artifactZip).use { inp.copyTo(it) } }
                dlConn.disconnect()
                appendLog("Downloaded: ${artifactZip.length() / 1024} KB")

                // 3. Save the ZIP directly to Downloads using the artifact name (no rename, no APK extraction)
                setStatus("Saving…")
                val savedPath = saveZipToDownloads(artifactZip, zipFileName)
                appendLog("✓ Saved to Downloads!")
                appendLog("  File : $zipFileName")
                appendLog("  Path : $savedPath")
                appendLog("  Size : ${artifactZip.length() / 1024} KB")
                appendLog("  Open your Downloads app to find it anytime.")
                setStatus("Ready ✓")
                mainHandler.post { btnDownloadApk.isEnabled = true }

            } catch (e: Exception) {
                appendLog("✗ Download error: ${e.message}")
                setStatus("Download failed")
                mainHandler.post { btnDownloadApk.isEnabled = true }
            } finally {
                setBusy(false)
            }
        }
    }

    /**
     * Saves [zipFile] to the public Downloads directory as [fileName] (a .zip).
     *
     * Android 10+ (API 29+): MediaStore API — no storage permission required.
     * Android 7–9  (API 24–28): direct file write (needs WRITE_EXTERNAL_STORAGE).
     *
     * Returns the absolute path of the saved file.
     */
    private fun saveZipToDownloads(zipFile: File, fileName: String): String {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // Android 10+ — MediaStore.Downloads (no permission needed)
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                put(MediaStore.Downloads.MIME_TYPE, "application/zip")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val collection = MediaStore.Downloads
                .getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            val itemUri = contentResolver.insert(collection, values)
                ?: throw Exception("MediaStore insert failed.")

            contentResolver.openOutputStream(itemUri)!!.use { out: OutputStream ->
                zipFile.inputStream().use { it.copyTo(out) }
            }

            // Clear IS_PENDING so it appears in Downloads app right away
            values.clear()
            values.put(MediaStore.Downloads.IS_PENDING, 0)
            contentResolver.update(itemUri, values, null, null)

            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                .absolutePath + "/$fileName"

        } else {
            // Android 7–9 — direct file write (needs WRITE_EXTERNAL_STORAGE)
            val dir  = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            dir.mkdirs()
            val dest = File(dir, fileName)
            zipFile.copyTo(dest, overwrite = true)
            dest.absolutePath
        }
    }

    // ── Browse All Artifacts (persists across reinstall — reads from GitHub) ─

    /**
     * Fetches every artifact for the repo from GitHub API — exactly what the
     * GitHub website shows on the Actions → Artifacts page.  Works even after
     * the app is uninstalled and reinstalled because the data lives on GitHub,
     * not in SharedPreferences.
     */
    private fun browseAllArtifacts() {
        val token = etToken.text.toString().trim()
        val repo  = etRepo.text.toString().trim()
        if (token.isEmpty()) { appendLog("⚠ Enter your GitHub token first."); return }
        if (repo.isEmpty())  { appendLog("⚠ Enter a repository name first."); return }

        setBusy(true)
        appendLog("Fetching all artifacts from GitHub…")

        thread {
            try {
                val owner = lastOwner.ifEmpty {
                    (fetchOwner(token) ?: throw Exception("Could not verify token.")).also { lastOwner = it }
                }

                // Collect up to 5 pages × 30 = 150 artifacts (same as GitHub website)
                val allArtifacts = mutableListOf<JSONObject>()
                var page = 1
                while (page <= 5) {
                    val url = "https://api.github.com/repos/$owner/$repo/actions/artifacts?per_page=30&page=$page"
                    val (code, body) = httpGet(token, url)
                    if (code != 200) break
                    val obj  = JSONObject(body)
                    val arr  = obj.getJSONArray("artifacts")
                    if (arr.length() == 0) break
                    for (i in 0 until arr.length()) allArtifacts.add(arr.getJSONObject(i))
                    val totalCount = obj.optInt("total_count", 0)
                    if (allArtifacts.size >= totalCount) break
                    page++
                }

                mainHandler.post {
                    setBusy(false)
                    if (allArtifacts.isEmpty()) {
                        appendLog("No artifacts found in github.com/$owner/$repo")
                        appendLog("  Artifacts are kept for 30 days after each build.")
                        AlertDialog.Builder(this)
                            .setTitle("📁 No Artifacts Found")
                            .setMessage(
                                "No artifacts were found in:\ngithub.com/$owner/$repo\n\n" +
                                "Possible reasons:\n" +
                                "• All artifacts have expired (30-day limit)\n" +
                                "• The repo name is wrong\n" +
                                "• No builds have been run yet\n\n" +
                                "Start a new build with 🚀 Upload & Build."
                            )
                            .setPositiveButton("OK", null)
                            .show()
                    } else {
                        appendLog("Found ${allArtifacts.size} artifact(s) ✓")
                        showArtifactBrowserDialog(token, owner, repo, allArtifacts)
                    }
                }
            } catch (e: Exception) {
                appendLog("✗ ${e.message}")
                mainHandler.post { setBusy(false) }
            }
        }
    }

    /**
     * Displays all artifacts in a dialog — same information as the GitHub website:
     * name, size, creation date, expiry date, and a Download button per artifact.
     */
    private fun showArtifactBrowserDialog(
        token: String, owner: String, repo: String,
        artifacts: List<JSONObject>
    ) {
        // Build display labels: "🟢 name  •  1.2 MB  •  expires May 15"
        val fmt      = SimpleDateFormat("MMM d, yyyy", Locale.US)
        val fmtIn    = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }
        val labels = artifacts.map { art ->
            val name      = art.getString("name")
            val sizeBytes = art.optLong("size_in_bytes", 0L)
            val sizeStr   = when {
                sizeBytes >= 1_048_576 -> "%.1f MB".format(sizeBytes / 1_048_576.0)
                sizeBytes >= 1_024     -> "${sizeBytes / 1024} KB"
                else                   -> "$sizeBytes B"
            }
            val expired     = art.optBoolean("expired", false)
            val expiresRaw  = art.optString("expires_at", "")
            val expiresStr  = if (expiresRaw.isNotEmpty()) {
                try { "expires " + fmt.format(fmtIn.parse(expiresRaw)!!) }
                catch (_: Exception) { "" }
            } else ""
            val createdRaw  = art.optString("created_at", "")
            val createdStr  = if (createdRaw.isNotEmpty()) {
                try { fmt.format(fmtIn.parse(createdRaw)!!) }
                catch (_: Exception) { "" }
            } else ""
            val icon = if (expired) "🔴" else "🟢"
            buildString {
                append("$icon $name")
                append("\n    $sizeStr")
                if (createdStr.isNotEmpty()) append("  •  built $createdStr")
                if (expiresStr.isNotEmpty()) append("\n    $expiresStr")
                if (expired) append("  ⚠ expired")
            }
        }.toTypedArray()

        var selectedIndex = -1

        AlertDialog.Builder(this)
            .setTitle("📁  All Artifacts  (${artifacts.size})")
            .setSingleChoiceItems(labels, -1) { _, which -> selectedIndex = which }
            .setPositiveButton("📲 Download Selected") { _, _ ->
                if (selectedIndex < 0) {
                    appendLog("⚠ Tap an artifact to select it first.")
                    return@setPositiveButton
                }
                val art = artifacts[selectedIndex]
                if (art.optBoolean("expired", false)) {
                    appendLog("✗ That artifact has expired — it can no longer be downloaded.")
                    AlertDialog.Builder(this)
                        .setTitle("Artifact Expired")
                        .setMessage(
                            "\"${art.getString("name")}\" has expired.\n\n" +
                            "GitHub keeps artifacts for 30 days. " +
                            "Start a new build to get a fresh APK."
                        )
                        .setPositiveButton("OK", null).show()
                    return@setPositiveButton
                }
                val dlUrl  = art.getString("archive_download_url")
                val dlName = art.getString("name")
                // Save so the Download button on the main screen also works
                val runId  = art.optLong("workflow_run", 0L).let {
                    // archive_download_url contains the run id in some cases; use artifact id instead
                    art.optLong("id", -1L)
                }
                saveBuildState(dlUrl, dlName, runId, owner, repo)
                artifactDownloadUrl      = dlUrl
                lastRunId                = runId
                btnDownloadApk.isEnabled = true
                appendLog("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
                appendLog("Selected artifact: $dlName")
                appendLog("Starting download…")
                appendLog("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
                downloadArtifact(dlUrl)
            }
            .setNegativeButton("Close", null)
            .show()
    }

    // ── Manage ZIPs dialog ────────────────────────────────────────────────────

    private fun showManageFilesDialog() {
        val token = etToken.text.toString().trim()
        val repo  = etRepo.text.toString().trim()
        if (token.isEmpty()) { appendLog("⚠ Enter your GitHub token first."); return }
        if (repo.isEmpty())  { appendLog("⚠ Enter a repository name first."); return }

        setBusy(true)
        appendLog("Listing ZIPs in repo uploads/ …")

        thread {
            try {
                val owner = lastOwner.ifEmpty {
                    (fetchOwner(token) ?: throw Exception("Could not verify token.")).also { lastOwner = it }
                }
                val (code, body) = httpGet(token, apiContents(owner, repo, "uploads"))
                when {
                    code == 404 -> { mainHandler.post { setBusy(false); appendLog("No uploads/ directory found.") }; return@thread }
                    code != 200 -> throw Exception("Could not list uploads/ (HTTP $code)")
                }
                val arr      = JSONArray(body)
                val zipFiles = mutableListOf<Triple<String, String, String>>()
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    if (obj.optString("type") == "file" && obj.getString("name").lowercase().endsWith(".zip"))
                        zipFiles.add(Triple(obj.getString("path"), obj.optString("sha"), obj.getString("name")))
                }
                mainHandler.post {
                    setBusy(false)
                    if (zipFiles.isEmpty()) appendLog("No ZIP files in uploads/ — repo is clean.")
                    else showZipSelectionDialog(token, owner, repo, zipFiles)
                }
            } catch (e: Exception) {
                appendLog("✗ ${e.message}")
                mainHandler.post { setBusy(false) }
            }
        }
    }

    private fun showZipSelectionDialog(
        token: String, owner: String, repo: String,
        zipFiles: List<Triple<String, String, String>>
    ) {
        val names   = zipFiles.map { it.third }.toTypedArray()
        val checked = BooleanArray(zipFiles.size) { false }
        AlertDialog.Builder(this)
            .setTitle("🗂️  Select ZIPs to Delete")
            .setMultiChoiceItems(names, checked) { _, which, isChecked -> checked[which] = isChecked }
            .setPositiveButton("Delete Selected") { _, _ ->
                val toDelete = zipFiles.filterIndexed { i, _ -> checked[i] }
                if (toDelete.isEmpty()) { appendLog("No files selected."); return@setPositiveButton }
                val list = toDelete.joinToString("\n• ", prefix = "• ") { it.third }
                AlertDialog.Builder(this)
                    .setTitle("Confirm Deletion")
                    .setMessage("Permanently delete ${toDelete.size} file(s) from repo?\n\n$list")
                    .setPositiveButton("Delete") { _, _ ->
                        val branch = etBranch.text.toString().trim().ifEmpty { "main" }
                        setBusy(true)
                        thread { deleteSelectedFiles(token, owner, repo, branch, toDelete) }
                    }
                    .setNegativeButton("Cancel", null).show()
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun deleteSelectedFiles(
        token: String, owner: String, repo: String, branch: String,
        files: List<Triple<String, String, String>>
    ) {
        try {
            for ((path, sha, name) in files) {
                appendLog("Deleting $name …")
                val body = JSONObject().apply {
                    put("message", "ci: delete $path via ZipApkBuilder [skip ci]")
                    put("sha",     sha)
                    put("branch",  branch)
                }.toString()
                val (code, resp) = httpDelete(token, apiContents(owner, repo, path), body)
                if (code in 200..204) { appendLog("✓ Deleted: $name"); if (path == lastRemotePath) lastFileSha = null }
                else appendLog("✗ Failed ($code): ${resp.take(120)}")
            }
        } catch (e: Exception) { appendLog("✗ ${e.message}") }
        finally { setBusy(false) }
    }

    // ── In-app workflow log viewer ────────────────────────────────────────────

    private fun fetchAndShowWorkflowLog() {
        if (lastRunId == -1L || lastOwner.isEmpty()) {
            appendLog("⚠ No workflow run available — build a project first.")
            return
        }
        val token = etToken.text.toString().trim()
        val repo  = etRepo.text.toString().trim()
        setBusy(true)
        appendLog("Fetching build log from GitHub…")

        thread {
            try {
                val (jobsCode, jobsBody) = httpGet(token, "${apiRuns(lastOwner, repo)}/$lastRunId/jobs")
                if (jobsCode != 200) throw Exception("Could not fetch jobs (HTTP $jobsCode)")
                val jobsArr = JSONObject(jobsBody).getJSONArray("jobs")
                if (jobsArr.length() == 0) throw Exception("No jobs found for run #$lastRunId")
                val job    = jobsArr.getJSONObject(0)
                val jobId  = job.getLong("id")
                appendLog("Loading logs for '${job.optString("name", "build")}' (job #$jobId)…")

                val conn1 = (URL("https://api.github.com/repos/$lastOwner/$repo/actions/jobs/$jobId/logs")
                    .openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    setRequestProperty("Authorization", "token $token")
                    setRequestProperty("Accept", "application/vnd.github.v3+json")
                    instanceFollowRedirects = false
                    connectTimeout = 30_000; readTimeout = 30_000
                }
                val logText: String = when (conn1.responseCode) {
                    in 301..308 -> {
                        val loc = conn1.getHeaderField("Location"); conn1.disconnect()
                        val c2 = (URL(loc).openConnection() as HttpURLConnection).apply {
                            requestMethod = "GET"; connectTimeout = 30_000; readTimeout = 120_000
                        }
                        if (c2.responseCode == 200) c2.inputStream.bufferedReader().readText().also { c2.disconnect() }
                        else { c2.disconnect(); throw Exception("HTTP ${c2.responseCode}") }
                    }
                    200 -> conn1.inputStream.bufferedReader().readText().also { conn1.disconnect() }
                    else -> {
                        val err = conn1.errorStream?.bufferedReader()?.readText() ?: ""
                        conn1.disconnect(); throw Exception("Log API HTTP ${conn1.responseCode}: ${err.take(200)}")
                    }
                }
                appendLog("✓ Log: ${logText.length / 1024} KB, ${logText.lines().size} lines")
                mainHandler.post { showLogDialog(logText, lastRunId) }
            } catch (e: Exception) { appendLog("✗ Log error: ${e.message}") }
            finally { setBusy(false) }
        }
    }

    private fun showLogDialog(logText: String, runId: Long) {
        val lines   = logText.lines()
        val maxLines = 300
        val display = buildString {
            if (lines.size > maxLines) append("⚠ Showing last $maxLines of ${lines.size} lines.\n\n")
            append((if (lines.size > maxLines) lines.takeLast(maxLines) else lines).joinToString("\n"))
        }
        val sv = ScrollView(this)
        sv.addView(TextView(this).apply {
            text = display; textSize = 9.5f
            setTextColor(0xFFCCCCCC.toInt())
            typeface = android.graphics.Typeface.MONOSPACE
            setPadding(24, 24, 24, 24)
        })
        sv.post { sv.fullScroll(ScrollView.FOCUS_DOWN) }
        AlertDialog.Builder(this)
            .setTitle("🔍  Build Log — Run #$runId")
            .setView(sv)
            .setPositiveButton("Copy All") { _, _ ->
                (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager)
                    .setPrimaryClip(ClipData.newPlainText("Build Log", logText))
                appendLog("✓ Full log copied (${logText.length / 1024} KB).")
            }
            .setNeutralButton("Tail to Console") { _, _ ->
                appendLog("=== Log Run #$runId ===")
                lines.takeLast(60).forEach { appendLog(it) }
                appendLog("=== End ===")
            }
            .setNegativeButton("Close", null).show()
    }

    // ── Clipboard & share ─────────────────────────────────────────────────────

    private fun copyLogToClipboard() {
        val text = tvLog.text.toString()
        if (text.isEmpty()) { appendLog("Log is empty."); return }
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager)
            .setPrimaryClip(ClipData.newPlainText("Build Log", text))
        appendLog("✓ Log copied to clipboard.")
    }

    private fun saveLogToFile() {
        val text = tvLog.text.toString()
        if (text.isEmpty()) { appendLog("Log is empty."); return }
        thread {
            try {
                val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(java.util.Date())
                val file  = File(cacheDir, "build_log_$stamp.txt").also { it.writeText(text) }
                val uri   = FileProvider.getUriForFile(this, "${packageName}.provider", file)
                mainHandler.post {
                    startActivity(Intent.createChooser(
                        Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_STREAM, uri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }, "Share Build Log"))
                }
            } catch (e: Exception) { appendLog("✗ Share error: ${e.message}") }
        }
    }

    // ── HTTP ──────────────────────────────────────────────────────────────────

    private fun httpGet(token: String, urlStr: String) =
        readResponse((URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            setRequestProperty("Authorization", "token $token")
            setRequestProperty("Accept", "application/vnd.github.v3+json")
            connectTimeout = 30_000; readTimeout = 30_000
        })

    private fun httpPut(token: String, urlStr: String, body: String) =
        readResponse((URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = "PUT"
            setRequestProperty("Authorization", "token $token")
            setRequestProperty("Accept", "application/vnd.github.v3+json")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            doOutput = true; connectTimeout = 120_000; readTimeout = 120_000
        }.also { it.outputStream.bufferedWriter().use { w -> w.write(body) } })

    private fun httpPost(token: String, urlStr: String, body: String) =
        readResponse((URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            setRequestProperty("Authorization", "token $token")
            setRequestProperty("Accept", "application/vnd.github.v3+json")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            doOutput = true; connectTimeout = 30_000; readTimeout = 30_000
        }.also { it.outputStream.bufferedWriter().use { w -> w.write(body) } })

    private fun httpDelete(token: String, urlStr: String, body: String) =
        readResponse((URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = "DELETE"
            setRequestProperty("Authorization", "token $token")
            setRequestProperty("Accept", "application/vnd.github.v3+json")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            doOutput = true; connectTimeout = 30_000; readTimeout = 30_000
        }.also { it.outputStream.bufferedWriter().use { w -> w.write(body) } })

    private fun readResponse(conn: HttpURLConnection): Pair<Int, String> =
        try {
            val code = conn.responseCode
            Pair(code, (if (code < 400) conn.inputStream else conn.errorStream)
                ?.bufferedReader()?.readText() ?: "")
        } finally { conn.disconnect() }

    // ── URL builders ──────────────────────────────────────────────────────────

    private fun apiContents(owner: String, repo: String, path: String) =
        "https://api.github.com/repos/$owner/$repo/contents/$path"

    private fun apiRuns(owner: String, repo: String) =
        "https://api.github.com/repos/$owner/$repo/actions/runs"

    // ── UI helpers ────────────────────────────────────────────────────────────

    private fun setStatus(text: String) = mainHandler.post {
        tvStatus.text = text
        tvStatus.setTextColor(when {
            text.contains("✓") || text.startsWith("Ready") -> 0xFF4CAF50.toInt()
            text.contains("✗") || text.contains("failed")  -> 0xFFFF5252.toInt()
            else                                             -> 0xFFFFFFFF.toInt()
        })
    }

    private fun appendLog(msg: String) = mainHandler.post {
        tvLog.append("$msg\n")
        scrollLog.post { scrollLog.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun setBusy(busy: Boolean) = mainHandler.post {
        isBusy                   = busy
        progressBar.visibility   = if (busy) View.VISIBLE else View.GONE
        btnUploadBuild.isEnabled = !busy
        btnPickZip.isEnabled     = !busy
        btnManageZips.isEnabled  = !busy
        // Download button: only re-enable when not busy AND an artifact URL is known
        if (!busy) btnDownloadApk.isEnabled = (artifactDownloadUrl != null)
    }

    // ── Utilities ─────────────────────────────────────────────────────────────

    private fun resolveFileName(uri: Uri): String {
        var name = "project.zip"
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val col = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (c.moveToFirst() && col >= 0) name = c.getString(col)
        }
        name = name.replace(Regex("[^a-zA-Z0-9._\\-]"), "_")
        if (!name.lowercase().endsWith(".zip")) name += ".zip"
        return name
    }

    private fun parseIso8601(s: String): Long = try {
        SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
            .apply { timeZone = TimeZone.getTimeZone("UTC") }
            .parse(s)?.time ?: 0L
    } catch (_: Exception) { 0L }
}
