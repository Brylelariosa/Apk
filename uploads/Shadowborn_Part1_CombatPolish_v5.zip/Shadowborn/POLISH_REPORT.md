# Shadowborn - combat / movement polish (work in progress)

Status: **iteration 5 of the critic loop**. Compiles against the headless Android stubs and passes the whole regression
(`tools/headless/run.sh`: 40 sim checks + 107 mechanics checks + 720 000-frame monkey soak, ~20 s). NOT yet built with the
real Android SDK or played on a device - please build it with your GitHub Actions workflow and tell me what still feels off.
Contact sheets of the real game frames are in `tools/headless/samples/` (rendered through a Java2D stand-in, so colours and
anti-aliasing differ slightly from a phone).

## Feedback on v4: "attacks are all downward or upward swings, the sword is out in front when running, and it is a lightsaber"
* **Sword**: the glowing cyan bar is gone. It is now a real sword drawn in `Art.sword()`: tapered steel blade with a lit upper edge,
  darker lower face and a fuller, brass cross-guard, leather grip and pommel, only a faint rim light. The Umbral Edge upgrade is a
  dark blade with a crimson edge; enemy and boss swords use the same drawing in rusty blood-steel. The slash trail is a thin cold
  steel-white swoosh (lighter fill, clean line) instead of a neon wedge.
* **Running / dashing**: the sword is carried low and streams back behind the hip (the arm pumps a little with the stride, the
  blade trails), also while skidding and dashing. It no longer pokes out in front. The idle guard is unchanged.
* **Attacks** no longer chop down and up. Ground combo: **horizontal slash** (sword drawn back behind the shoulder, then a flat sweep
  across the front at chest height) -> **lunging thrust** (hand pulled back to the hip, blade levelled, arm shoots straight out)
  -> **spin slash** finisher (crouch and coil, one full turn with the blade held out flat, hits front and back). Air combo:
  horizontal slash -> spin slash -> plunge (the plunge stays a downward stab). Dash slash is a low flat sweep at knee height.
  Damage, frame tables and chaining are unchanged apart from the finisher's active window (6 -> 9 frames) and the air spin (5 -> 8).
* How: the rig got one new pose parameter, `az` = the turn of the whole sword arm about the vertical axis through the shoulder
  (0 = screen plane, PI/2 = end-on, PI = pointing back). The horizontal part of the arm and blade is foreshortened by cos(az) and
  the depth part shows as a small vertical shift (the camera looks slightly down), so sweeping az from PI to 0 gives a flat slash
  whose tip traces a shallow smile. With az = 0 the solver is exactly the old one.
* Consequences handled: a slash that starts behind the back must not hit what stands behind, so slash, thrust, air slash and dash
  slash only count the part of the blade in front of the hero's centre line (`Player.blade()`, shared with the tests); the spin hits
  all round. The old floor clamp rotated the arm and pinned the dash sword to the front, so it is replaced by cutting the blade
  short at the floor line (continuous, hit test sees the same blade). A blade tip speed limit (40 units/frame outside strikes) stops
  a dash that cancels a wind-up from whipping the sword, attacks take the short way round for the arm's turn, and a pose with the
  blade trailing behind starts a sweep without the arm swinging round (the pose has an exact mirror representation).
* Tests: the "blade already moving on the press frame" check and the whiff/soundness helper were rewritten for the new moves (they
  assumed an overhead chop); new checks guard the look: the blade trails behind while running and dashing, every move except the
  plunge sweeps flat (tip travels >= 2.5x further sideways than up/down), and the blade never pokes through the floor.

## Feedback on v3: "still bad animation, and when attacking the other leg is in the air" - what I found
* The leg complaint was **real and measurable**: in v3 the idle foot hovered up to **8 units** above the floor in grounded
  poses (lunges, landing crouch, dash). All grounded poses now use a two-bone IK foot-planting solver: worst gap over
  attacks / dash / landing / idle is now under 0.6 units (the suite fails if a foot floats).
* A random-play scan found **pose pops** (the blade flipping 90-160 degrees in one frame at dash-slash start, when the floor
  clamp changed sides, at plunge landing and at dash start). Over 60 000 frames: v3 = 15 body-joint pops (>18 units), 760 blade
  snaps (>45) outside strikes and 183 (>60) inside strikes; v4 = 0 / 0 / 0. Fixed at the source (dash slash starts from the dash
  pose, hysteresis on the floor clamp, landing blends from the pose on screen) plus a per-frame slew limiter.
* **Frame pacing** (probably the biggest hidden cause on a phone): the loop slept 16 ms and stepped physics at 60 Hz with no
  interpolation. On a 90 Hz screen that gives a 1-1-2 update cadence (stutter on every animation), and even on 60 Hz about
  1.3% of frames ran 0 or 2 updates from 0.3 ms of jitter. Now: `FrameClock` (frame-time snapping, capped catch-up) + render
  interpolation of hero, enemies, boss, projectiles and camera, and no fixed 16 ms sleep (frames follow the display rate).
  Tested headlessly at 60 / 90 / 120 Hz; NOT verified on a real device.
* Smoother wind-ups and strike sweeps (no frame covers more than ~30% of a swing), the finisher's coil keeps tightening while
  it holds, the landing squash is quicker and shallower, the blade is cut off at the floor line when a chop sweeps through it.

## What changed in total
* **Player rewritten** (`Player.java`): explicit move tables (startup / active / recovery frames), pose-blend animation,
  swept-blade hit detection. Public fields used elsewhere (hp, facing, atk, atkT, dodgeT, dodgeCd, invuln ...) kept.
* **Jump**: asymmetric gravity (snappier fall), apex hang, gravity-based jump cut (smooth short hops, min hop 34 units),
  coyote 0.10 s, buffer 0.14 s, ceiling-corner nudge, ledge step-up (<= 7 units), air drag / reverse-turn accel,
  landing squash scaled by impact. Full-jump height 86.6 (was 85.8) and run-jump reach 133 (was 130): level geometry unchanged.
* **Double jump**: somersault with tucked pose, wraith afterimages, double ring, feather burst, redirect on press,
  "smart" buffering (a press just before landing becomes a ground jump instead of wasting the double jump),
  floatier descent after the second jump (keeps the DJ-gated gaps as forgiving as before).
* **Dash**: instant full speed, eased exit (no hard stop), full-figure afterimages, speed streaks, dust, ring, camera kick,
  wall bump instead of grinding, sub-stepped collision, cooldown shown on the button.
  **Air dash now needs Wraith Stride** (see "bug found").
* **Attacks**: ground combo 10/12/22 (same damage), aerial combo (slash, reverse slash, plunge finisher 22 + landing slam),
  dash slash. Hits register only when the swept blade touches the enemy (before: hit at frame 4 with the blade still
  overhead, up to ~70 units away; stage 3 hit with the blade behind the hero). Smooth slash arcs, hit-stop, flash,
  directional sparks, camera kick. Lunge auto-spaces to the nearest enemy.
* **Bug found in the original**: jump + air dodge crossed the 6-tile chasm WITHOUT the double jump (2154 of 3528 tested
  timings). The old bot test never pressed dodge. Fixed: the air dash is part of Wraith Stride; ground dash unchanged.

## Exploits the new gating search found in MY OWN first draft (all fixed)
The mechanics suite throws 20 000 random jump / attack / dash programs per spot at the double-jump gates:
1. Aerial-slash hover applied while still rising = anti-gravity (+16..60 units): reached the secret ledge without the double jump.
   Now the hover is only earned when an aerial slash connects, and only slows a fall.
2. Ground dash -> dash slash -> coyote jump launched from mid-chasm at dash speed. Coyote time is now void when leaving the
   ground mid-dash or above run speed, and a jump's takeoff speed is capped at run speed.
3. A jump cancelled out of a dash used the dash's zero gravity on its first frame (+8.7 units of apex). Fixed.
Result with 20 000 programs per spot: chasm closest approach 37 units short, secret ledge 40 units short (needs the double jump).

## Known limitations / not done
* Nothing here was run on a phone: feel, touch ergonomics and the new frame loop need your eyes. Tell me which move still looks
  wrong (e.g. "finisher wind-up", "landing") and I will fix that move specifically.
* Planted feet slide during lunges (with dust); turning around is an instant mirror (no turn animation); the slash arcs are
  large; enemy and boss poses were not touched (only their sword drawing changed).
* Flat sweeps pass a moment (about one frame) where the blade points at the camera and shows as a short stub; the spin's far half
  draws the sword behind the body but the arm itself is not depth-sorted.
* The ground combo no longer reaches the Wraith's hover height (it never could from a flat swing); jump attacks do.

## Tests added (tools/headless/sim/.../Mechanics.java, run by run.sh)
Input latency (press frame = frame 0), buffers, coyote, corner nudge, ledge step-up, jump height/air-time/reach vs the
original, double-jump rules and resets, smart buffering, dash distance/cooldown/i-frames/wall collision/tunnelling,
attack frame tables, blade-vs-hit synchronisation (no hit without the blade near, no whiff through the blade),
cancels and combos, random-input invariant fuzz (360 000 frames), gating search, allocation per frame.

## Tools added
* `tools/headless/shots.sh` + `sheet.py`: renders real game frames to PNG through a Java2D shim and builds contact sheets
  (this is how the animations were inspected). It approximates, not reproduces, Android's Canvas.
