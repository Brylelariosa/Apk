# Shadowborn  (Part 1: playable foundation)

A dark-fantasy stickman metroidvania for Android, written in plain Java with a custom Canvas renderer.
No Unity or Godot, no AndroidX or AppCompat, no third-party libraries, no network access, and no image
files: every sprite, background, button and effect is drawn procedurally in code.

Package `com.shadowborn.game`, minSdk 30 (Android 11), targetSdk / compileSdk 34, AGP 8.2.2, Gradle 8.6, Java 11 source level.

## Build

Requirements: JDK 17 and the Android SDK (platform 34 and its build-tools; Gradle can download them once
the licences are accepted).

**Android Studio:** File > Open > pick this folder, then Run the `app` configuration on a device or emulator.

**Command line:**

    ./gradlew assembleDebug
    # -> app/build/outputs/apk/debug/app-debug.apk

`gradle/wrapper/gradle-wrapper.jar` is a binary and is not part of this ZIP. The Build APK GitHub workflow
downloads it automatically. To build locally without Android Studio run `gradle wrapper --gradle-version 8.6`
once to create it.

**GitHub Actions:** push this ZIP into the repository's `uploads/` folder. The Build APK workflow unzips it,
finds `settings.gradle`, builds `assembleDebug` (or `assembleRelease` when keystore secrets exist) and uploads
the APK as an artifact. No APK is bundled here because it could not be built in the authoring environment.

## How to play

Bottom-left: LEFT / RIGHT. Bottom-right: JUMP, ATTACK and DODGE. Top-right: pause. Several buttons can be held at once.

* **JUMP** - hold for a higher jump, tap for a hop. A press just before landing is remembered, and so is a press just
  after walking off a ledge. After the Wraith Stride shrine, press again in mid-air for a somersault double jump.
* **ATTACK** - tap repeatedly for a 3-hit ground combo (10 / 12 / 22 damage): horizontal slash, thrust, spin slash. In the air the
  same button gives a horizontal slash, a spin slash and a plunge finisher that dives to the ground (a slash that connects holds
  you up briefly). Pressing attack in the middle of a dash turns it into a low dash slash that chains into the combo.
* **DODGE** - a fast dash with invulnerability in the direction you hold (the way you face if nothing is held).
  The button darkens while it recharges. After Wraith Stride you can also dash once per jump in mid-air.
* A jump or a dash cancels an attack at once; a dash can be buffered just before it recharges.

Route: ASHEN GATE -> GLOOM CRYPT -> HOLLOW SANCTUM. Collect shards, light the ember shrines (checkpoints,
full heal), take the Wraith Stride shrine (double jump) in the crypt to cross the chasm, then defeat the
Ashen Warden. A shard cache high above the first hall needs the double jump to reach. In the pause menu shards
buy Vitality (+20 max HP, up to 5 times).

## Source map (app/src/main/java/com/shadowborn/game)

| File | Role |
| --- | --- |
| MainActivity, GameView | fullscreen landscape activity, surface, 60 Hz loop thread, multi-touch |
| Game | state machine (menu, play, pause, settings, death), rooms, camera, checkpoints, progression |
| World | three tile rooms (built in code), collision queries, tile rendering |
| Body, Player, Enemy, Boss, Proj, Pickup | physics, hero combat, two enemy types, mini-boss, projectiles, items |
| Art, Fx, Ui, Controls, Input | procedural drawing, particles/trail/shake, menus and HUD, touch buttons |
| Save | SharedPreferences save and settings |

## Headless tests

`tools/headless/run.sh` compiles the game against tiny Android stubs and runs a scripted bot simulation, the
mechanics suite (input latency, jump / double jump / dash numbers, blade-vs-hit synchronisation, combos, an invariant
fuzz and a random-input search that the double-jump gates cannot be bypassed) and a random-input soak test. It needs
only a JDK. These check game logic, not graphics.

`tools/headless/shots.sh <dir> [scenario ...]` renders real game frames to PNG through a Java2D stand-in for
android.graphics (scenarios: run, jump, djump, attack, airattack, plunge, dash, dashslash, hitsync ...) and
`sheet.py` builds labelled contact sheets from them. The stand-in approximates Android's Canvas; it is for
inspecting poses and effects, not a pixel-exact preview.
