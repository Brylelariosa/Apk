package com.shadowborn.game;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.imageio.ImageIO;

/**
 * Headless frame renderer (not shipped in the APK): runs scripted input through the real Game and writes cropped
 * PNG frames plus a per-frame state CSV, so poses and effects can be inspected without a device.
 * Usage: java Shots <outDir> [scenario ...]
 */
public class Shots {
    static final float DT = 1f / 60f;
    static final float VW = 320f, S = 4f;
    static final float FLOOR = 10 * 32f;

    static final class Scn {
        final String name;
        final int n;
        final boolean[] l, r, j, a, d;
        final List<Integer> caps = new ArrayList<>();
        boolean dj, hud;
        float startX = 44 * 32f + 8f;
        float cropW = 150f, cropH = 120f, cropUp = 84f;
        int dummyAt = -1;           // distance in front of the player for a training dummy (-1 = none)
        Scn(String name, int n) {
            this.name = name;
            this.n = n;
            l = new boolean[n]; r = new boolean[n]; j = new boolean[n]; a = new boolean[n]; d = new boolean[n];
        }
        Scn hold(boolean[] arr, int from, int to) { for (int i = Math.max(0, from); i < Math.min(n, to); i++) arr[i] = true; return this; }
        Scn cap(int from, int step, int count) { for (int i = 0; i < count; i++) caps.add(from + i * step); return this; }
        Scn capAt(int... fs) { for (int f : fs) caps.add(f); return this; }
    }

    static final int T0 = 20;   // first scripted frame after the settle period

    static List<Scn> scenarios() {
        List<Scn> out = new ArrayList<>();

        Scn run = new Scn("run", 90);
        run.hold(run.r, 0, 90).cap(52, 3, 9);
        run.cropW = 100f; run.cropH = 78f; run.cropUp = 56f;
        out.add(run);

        Scn idle = new Scn("idle", 90);
        idle.cap(0, 11, 8);
        idle.cropW = 100f; idle.cropH = 78f; idle.cropUp = 56f;
        out.add(idle);

        Scn jump = new Scn("jump", 80);
        jump.hold(jump.j, T0, T0 + 24).cap(T0 - 2, 3, 9).cap(T0 + 25, 3, 9);
        jump.cropW = 110f; jump.cropH = 190f; jump.cropUp = 160f;
        out.add(jump);

        Scn jumpTap = new Scn("jumptap", 60);
        jumpTap.hold(jumpTap.j, T0, T0 + 3).cap(T0 - 1, 3, 12);
        jumpTap.cropW = 110f; jumpTap.cropH = 120f; jumpTap.cropUp = 92f;
        out.add(jumpTap);

        Scn dj = new Scn("djump", 100);
        dj.dj = true;
        dj.hold(dj.j, T0, T0 + 22).hold(dj.j, T0 + 30, T0 + 52).cap(T0 - 1, 3, 9).cap(T0 + 26, 3, 9);
        dj.cropW = 130f; dj.cropH = 250f; dj.cropUp = 214f;
        out.add(dj);

        Scn atk = new Scn("attack", 80);
        atk.hold(atk.a, T0, T0 + 2).hold(atk.a, T0 + 14, T0 + 16).hold(atk.a, T0 + 30, T0 + 32);
        atk.cap(T0 - 1, 3, 9).cap(T0 + 26, 3, 9);
        atk.cropW = 130f; atk.cropH = 84f; atk.cropUp = 62f;
        out.add(atk);

        Scn air = new Scn("airattack", 90);
        air.hold(air.j, T0, T0 + 22).hold(air.a, T0 + 4, T0 + 6).hold(air.a, T0 + 12, T0 + 14).hold(air.a, T0 + 20, T0 + 22);
        air.cap(T0 + 2, 3, 18);
        air.cropW = 130f; air.cropH = 170f; air.cropUp = 140f;
        out.add(air);

        Scn dash = new Scn("dash", 70);
        dash.hold(dash.r, T0, T0 + 8).hold(dash.d, T0 + 6, T0 + 8);
        dash.cap(T0 + 4, 2, 9);
        dash.cropW = 170f; dash.cropH = 80f; dash.cropUp = 58f;
        out.add(dash);

        Scn airdash = new Scn("airdash", 80);
        airdash.hold(airdash.j, T0, T0 + 20).hold(airdash.r, T0, T0 + 50).hold(airdash.d, T0 + 24, T0 + 26);
        airdash.cap(T0 + 20, 3, 12);
        airdash.cropW = 190f; airdash.cropH = 170f; airdash.cropUp = 130f;
        out.add(airdash);

        Scn mix = new Scn("mix", 150);
        mix.dj = true;
        mix.hold(mix.r, T0, T0 + 60).hold(mix.j, T0, T0 + 20).hold(mix.j, T0 + 26, T0 + 44)
           .hold(mix.a, T0 + 34, T0 + 36).hold(mix.d, T0 + 46, T0 + 48).hold(mix.a, T0 + 56, T0 + 58);
        mix.cap(T0 + 2, 4, 16);
        mix.cropW = 200f; mix.cropH = 220f; mix.cropUp = 170f;
        out.add(mix);

        Scn plunge = new Scn("plunge", 100);
        plunge.hold(plunge.j, T0, T0 + 22).hold(plunge.a, T0 + 4, T0 + 6).hold(plunge.a, T0 + 12, T0 + 14).hold(plunge.a, T0 + 20, T0 + 22);
        plunge.cap(T0 + 20, 2, 18);
        plunge.cropW = 130f; plunge.cropH = 170f; plunge.cropUp = 140f;
        out.add(plunge);

        Scn dslash = new Scn("dashslash", 80);
        dslash.hold(dslash.r, T0, T0 + 14).hold(dslash.d, T0 + 2, T0 + 4).hold(dslash.a, T0 + 6, T0 + 8).hold(dslash.a, T0 + 22, T0 + 24);
        dslash.cap(T0 + 2, 2, 18);
        dslash.cropW = 190f; dslash.cropH = 84f; dslash.cropUp = 62f;
        out.add(dslash);

        Scn hit = new Scn("hitsync", 60);
        hit.hold(hit.a, T0, T0 + 2);
        hit.dummyAt = 46;
        hit.cap(T0 + 1, 1, 12);
        hit.cropW = 150f; hit.cropH = 84f; hit.cropUp = 62f;
        out.add(hit);

        Scn turn = new Scn("turn", 70);
        turn.hold(turn.r, T0, T0 + 22).hold(turn.l, T0 + 22, T0 + 40);
        turn.cap(T0 + 20, 2, 12);
        turn.cropW = 110f; turn.cropH = 84f; turn.cropUp = 62f;
        out.add(turn);

        Scn hudDash = new Scn("hud_dash", 70);
        hudDash.hud = true;
        hudDash.hold(hudDash.d, T0, T0 + 2);
        hudDash.capAt(T0 - 2, T0 + 3, T0 + 12, T0 + 22, T0 + 32, T0 + 40);
        hudDash.cropW = 200f; hudDash.cropH = 200f;
        out.add(hudDash);

        Scn hudAir = new Scn("hud_air", 50);
        hudAir.hud = true;
        hudAir.hold(hudAir.j, T0, T0 + 20);
        hudAir.capAt(T0 - 2, T0 + 12, T0 + 40);
        hudAir.cropW = 200f; hudAir.cropH = 200f;
        out.add(hudAir);

        Scn hudAirDj = new Scn("hud_airdj", 50);
        hudAirDj.hud = true;
        hudAirDj.dj = true;
        hudAirDj.hold(hudAirDj.j, T0, T0 + 20);
        hudAirDj.capAt(T0 + 12);
        hudAirDj.cropW = 200f; hudAirDj.cropH = 200f;
        out.add(hudAirDj);

        Scn d1 = new Scn("dense_atk1", 60);
        d1.hold(d1.a, T0, T0 + 2).cap(T0 - 1, 1, 20);
        d1.cropW = 110f; d1.cropH = 80f; d1.cropUp = 58f;
        out.add(d1);

        Scn d3 = new Scn("dense_atk3", 90);
        d3.hold(d3.a, T0, T0 + 2).hold(d3.a, T0 + 7, T0 + 9).hold(d3.a, T0 + 15, T0 + 17);
        d3.cap(T0 + 14, 1, 24);
        d3.cropW = 110f; d3.cropH = 80f; d3.cropUp = 58f;
        out.add(d3);

        Scn dl = new Scn("dense_land", 90);
        dl.hold(dl.j, T0, T0 + 20).cap(T0 + 36, 1, 20);
        dl.cropW = 110f; dl.cropH = 80f; dl.cropUp = 58f;
        out.add(dl);

        Scn ra = new Scn("runattack", 70);
        ra.hold(ra.r, T0, T0 + 24).hold(ra.a, T0 + 20, T0 + 22);
        ra.cap(T0 + 18, 1, 14);
        ra.cropW = 110f; ra.cropH = 80f; ra.cropUp = 58f;
        out.add(ra);

        return out;
    }

    static void state(PrintWriter csv, int f, Game g) {
        Player p = g.player;
        csv.println(f + "," + String.format("%.1f,%.1f,%.1f,%.1f", p.x, p.y, p.vx, p.vy) + "," + p.onGround + "," + p.atk
            + "," + String.format("%.3f,%.3f,%.3f,%.3f", p.atkT, p.atkDur, p.dodgeT, p.dodgeCd));
    }

    public static void main(String[] args) throws Exception {
        String outDir = args.length > 0 ? args[0] : "/tmp/shots";
        new File(outDir).mkdirs();
        for (Scn s : scenarios()) {
            if (args.length > 1) {
                boolean want = false;
                for (int i = 1; i < args.length; i++) if (args[i].equals(s.name)) want = true;
                if (!want) continue;
            }
            Game g = Sim.newGame(new Sim.Prefs());
            g.save.shake = false;
            g.save.ctrlOpacity = s.hud ? 100 : 0;
            g.save.dj = s.dj;
            g.setSize(VW, S);
            Sim.tap(g, g.btnPlay);
            g.enemies.clear(); g.projs.clear(); g.pickups.clear(); g.boss = null;
            g.player.hasDJ = s.dj;
            g.player.place(s.startX, FLOOR - g.player.h);
            for (int i = 0; i < 140; i++) { g.input.clear(); g.bannerT = 0f; g.update(DT); }
            if (s.dummyAt >= 0) {
                Enemy e = new Enemy(Enemy.HUSK, g.player.cx() + s.dummyAt - 8f, FLOOR - 30f);
                g.enemies.add(e);
            }
            BufferedImage img = new BufferedImage((int) (VW * S), (int) (Game.VH * S), BufferedImage.TYPE_INT_ARGB);
            android.graphics.Canvas cv = new android.graphics.Canvas(img);
            PrintWriter csv = new PrintWriter(new File(outDir, s.name + ".csv"));
            csv.println("frame,x,y,vx,vy,ground,atk,atkT,atkDur,dodgeT,dodgeCd");
            for (int f = 0; f < s.n; f++) {
                g.input.set(s.l[f], s.r[f], s.j[f], s.a[f], s.d[f]);
                g.bannerT = 0f;
                g.update(DT);
                state(csv, f, g);
                if (s.caps.contains(f)) {
                    g.render(cv);
                    float sx = (g.player.cx() - g.camX) * S, sy = (g.player.y + g.player.h - g.camY) * S;
                    int cw = (int) (s.cropW * S), ch = (int) (s.cropH * S);
                    int x0 = Math.max(0, Math.min(img.getWidth() - cw, (int) (sx - cw / 2f)));
                    int y0 = Math.max(0, Math.min(img.getHeight() - ch, (int) (sy - s.cropUp * S)));
                    if (s.hud) { x0 = img.getWidth() - cw; y0 = img.getHeight() - ch; }
                    BufferedImage crop = img.getSubimage(x0, y0, cw, ch);
                    BufferedImage rgb = new BufferedImage(cw, ch, BufferedImage.TYPE_INT_RGB);
                    rgb.createGraphics().drawImage(crop, 0, 0, null);
                    ImageIO.write(rgb, "png", new File(outDir, String.format("%s_%03d.png", s.name, f)));
                }
            }
            csv.close();
            System.out.println("rendered " + s.name + " (" + s.caps.size() + " frames)");
        }
    }
}
