#!/bin/sh
# Headless regression harness. Compiles the game sources against tiny Android API stubs (no SDK needed),
# then runs (1) a scripted-bot simulation with ~40 checks, (2) the mechanics suite (jump / double jump / dash / attack
# timing, blade-vs-hit sync, combos, invariant fuzz, progression-gating search, allocation) and (3) a random-input soak test.
# Needs a JDK (javac) or a JRE that ships the jdk.compiler module.
set -e
cd "$(dirname "$0")"
OUT=$(mktemp -d)
if command -v javac >/dev/null 2>&1; then JAVAC="javac"; else JAVAC="java -m jdk.compiler/com.sun.tools.javac.Main"; fi
$JAVAC -nowarn -d "$OUT" $(find stubs -name '*.java') $(find ../../app/src/main/java -name '*.java') $(find sim -name '*.java')
java -cp "$OUT" com.shadowborn.game.Sim
java -cp "$OUT" com.shadowborn.game.Mechanics ${GATING_PROGRAMS:-12000}
java -cp "$OUT" com.shadowborn.game.Monkey
