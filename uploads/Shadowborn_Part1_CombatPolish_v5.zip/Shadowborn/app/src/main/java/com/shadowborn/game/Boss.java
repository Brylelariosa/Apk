package com.shadowborn.game;

import android.graphics.Canvas;
import android.graphics.Paint;

/** The Ashen Warden: mini-boss with sweep, leap-slam and blade-fan attacks, plus a phase-2 charge. */
final class Boss extends Body {
    private static final int SLEEP = 0, IDLE = 1, TELE = 2, ACT = 3, REC = 4, ROAR = 5, DYING = 6;
    private static final int A_SWEEP = 0, A_SLAM = 1, A_FAN = 2, A_CHARGE = 3;

    int hp = 280, maxHp = 280, lastSwing = -1;
    boolean phase2, dead;
    private int state = SLEEP, atk, dir = -1;
    private boolean hitDone;
    private float stateT, flash, t, idleT, recT;
    private final Art.Fig fig = new Art.Fig();

    Boss(float x, float y) {
        this.x = x;
        this.y = y;
        w = 34f;
        h = 70f;
    }

    boolean vulnerable() { return state != SLEEP && state != DYING && !dead; }

    boolean active() { return state != SLEEP && !dead; }

    void wake() {
        if (state == SLEEP) {
            state = IDLE;
            stateT = 0f;
            idleT = 1.4f;
        }
    }

    private float spd() { return phase2 ? 1.3f : 1f; }

    private float teleTime() {
        float base = atk == A_SWEEP ? 0.75f : (atk == A_SLAM ? 0.55f : (atk == A_FAN ? 0.7f : 0.6f));
        return base / spd();
    }

    private void rec(float time) {
        state = REC;
        stateT = 0f;
        recT = time / spd();
    }

    void update(Game g, float dt) {
        t += dt;
        stateT += dt;
        if (flash > 0f) flash -= dt;
        Player p = g.player;
        float dx = p.cx() - cx(), adx = Math.abs(dx);
        if (state == DYING) {
            vx = 0f;
            physics(g.world, dt);
            if (((int) (t * 30f) & 3) == 0) {
                g.fx.burst(cx() + (g.rnd.nextFloat() - 0.5f) * 30f, y + g.rnd.nextFloat() * h, 2, 0xFFFF3050, 90f, 0.6f, 2.6f);
            }
            if (stateT > 2.4f) dead = true;
            return;
        }
        if (state == SLEEP) {
            physics(g.world, dt);
            return;
        }
        float sp = spd();
        switch (state) {
            case IDLE:
                dir = dx > 0f ? 1 : -1;
                vx = adx > 80f ? dir * 62f * sp : 0f;
                idleT -= dt;
                if (idleT <= 0f && !p.dead) chooseAttack(g, adx);
                break;
            case TELE:
                vx = 0f;
                if (stateT >= teleTime()) {
                    state = ACT;
                    stateT = 0f;
                    startAct(g, p, dx);
                }
                break;
            case ACT:
                act(g, p);
                break;
            case REC:
                vx = approach(vx, 0f, 900f * dt);
                if (stateT >= recT) {
                    state = IDLE;
                    stateT = 0f;
                    idleT = 0.45f / sp + g.rnd.nextFloat() * 0.5f;
                }
                break;
            default:
                vx = 0f;
                if (stateT >= 1.0f) {
                    state = IDLE;
                    stateT = 0f;
                    idleT = 0.4f;
                }
                break;
        }
        physics(g.world, dt);
    }

    private void chooseAttack(Game g, float adx) {
        float r = g.rnd.nextFloat();
        if (adx < 110f) atk = r < 0.55f ? A_SWEEP : A_SLAM;
        else if (phase2 && r < 0.35f) atk = A_CHARGE;
        else atk = r < 0.6f ? A_FAN : A_SLAM;
        state = TELE;
        stateT = 0f;
        hitDone = false;
    }

    private void startAct(Game g, Player p, float dx) {
        hitDone = false;
        switch (atk) {
            case A_SWEEP:
                g.fx.shake(3f);
                break;
            case A_SLAM:
                vy = -640f;
                vx = clamp(dx * 1.25f, -300f, 300f);
                onGround = false;
                break;
            case A_FAN: {
                float ox = cx() + dir * 40f, oy = y + 24f;
                float a0 = (float) Math.atan2(p.cy() - oy, p.cx() - ox);
                int n = phase2 ? 5 : 3;
                for (int i = 0; i < n; i++) {
                    float a = a0 + (i - (n - 1) * 0.5f) * 0.24f;
                    g.projs.add(new Proj(Proj.BLADE, ox, oy, (float) Math.cos(a) * 230f, (float) Math.sin(a) * 230f, 14, 3f));
                }
                g.fx.burst(ox, oy, 10, 0xFFFF3050, 140f, 0.3f, 2.5f);
                g.fx.shake(2f);
                break;
            }
            default:
                vx = dir * 440f;
                break;
        }
    }

    private void act(Game g, Player p) {
        switch (atk) {
            case A_SWEEP:
                if (!hitDone && !p.dead) {
                    float hx = dir > 0 ? cx() - 6f : cx() - 90f;
                    if (overlap(hx, y + 8f, 96f, h - 8f, p.x, p.y, p.w, p.h)) {
                        hitDone = true;
                        p.hurt(g, 26, cx());
                    }
                }
                if (stateT > 0.28f) rec(0.8f);
                break;
            case A_SLAM:
                if (stateT > 0.2f && onGround) {
                    g.fx.shake(9f);
                    g.fx.ring(cx(), y + h, 90f, 0xFFFF3050);
                    g.fx.burst(cx(), y + h, 14, 0xFFB8B0C8, 160f, 0.5f, 2.6f);
                    if (!p.dead && p.onGround && Math.abs(p.cx() - cx()) < 64f) p.hurt(g, 24, cx());
                    g.projs.add(new Proj(Proj.WAVE, cx() - 30f, y + h, -230f, 0f, 18, 1.8f));
                    g.projs.add(new Proj(Proj.WAVE, cx() + 30f, y + h, 230f, 0f, 18, 1.8f));
                    rec(0.95f);
                } else if (stateT > 2.5f) {
                    rec(0.5f);
                }
                break;
            case A_FAN:
                if (stateT > 0.25f) rec(0.8f);
                break;
            default:
                vx = dir * 440f;
                if (!hitDone && !p.dead && overlap(x - 4f, y + 4f, w + 8f, h - 4f, p.x, p.y, p.w, p.h)) {
                    hitDone = true;
                    p.hurt(g, 26, cx());
                }
                if (hitWall || stateT > 0.8f) {
                    vx = 0f;
                    g.fx.shake(6f);
                    rec(1.0f);
                }
                break;
        }
    }

    void hurt(Game g, int dmg) {
        if (!vulnerable()) return;
        hp -= dmg;
        flash = 0.1f;
        g.fx.sparks(cx(), cy(), -dir, 0xFFFFE8B0);
        g.fx.ring(cx(), cy(), 24f, 0xFFFFFFFF);
        g.fx.text(cx(), y - 6f, String.valueOf(dmg), 0xFFFFE0A0);
        if (hp <= 0) {
            hp = 0;
            state = DYING;
            stateT = 0f;
            vx = 0f;
            g.onBossDefeated(this);
            return;
        }
        if (!phase2 && hp <= maxHp / 2) {
            phase2 = true;
            state = ROAR;
            stateT = 0f;
            vx = 0f;
            g.fx.shake(10f);
            g.fx.ring(cx(), cy(), 120f, 0xFFFF7030);
            g.fx.flashA = 0.3f;
            g.fx.flashC = 0xFFFF5020;
            g.banner("THE WARDEN ENRAGES", "");
        }
    }

    private void pose() {
        Art.Fig f = fig;
        f.x = cx();
        f.y = y + h;
        f.s = 2f;
        f.dir = dir;
        f.t = t;
        f.vx = vx;
        f.core = 0xFF0A0810;
        f.glow = phase2 ? 0xFFFF5A20 : 0xFFD02850;
        f.eye = 0xFFFFE070;
        f.blade = 0xFFC9A0AC;
        f.bladeGlow = phase2 ? 0xFFFF7A30 : 0xFFFF2850;
        f.guard = 0xFF6A4A52;
        f.grip = 0xFF1A0C10;
        f.aura = 0.6f;
        f.bladeLen = 30f;
        f.horns = true;
        f.chest = true;
        f.scarf = false;
        f.flash = flash > 0f ? 1f : 0f;
        f.alpha = 255;
        float walk = Math.min(1f, Math.abs(vx) / 60f);
        float sn = (float) Math.sin(t * 5f);
        f.lean = 0.12f;
        f.legF = sn * 0.5f * walk + 0.15f;
        f.legB = -sn * 0.5f * walk - 0.15f;
        f.kneeF = 0.15f;
        f.kneeB = 0.15f;
        f.armB = 0.3f;
        f.swordAng = 0.75f;
        switch (state) {
            case TELE: {
                float k = Math.min(1f, stateT / teleTime());
                if (atk == A_SWEEP) {
                    f.lean = -0.2f * k; f.swordAng = 3.0f + 0.9f * k; f.armB = 2.4f;
                    f.legF = 0.6f; f.legB = -0.6f; f.kneeF = 0.5f; f.kneeB = 0.4f;
                } else if (atk == A_SLAM) {
                    f.lean = 0.2f; f.legF = 0.9f; f.legB = -0.7f; f.kneeF = 1.4f; f.kneeB = 1.2f; f.swordAng = 3.3f; f.armB = 2.8f;
                } else if (atk == A_FAN) {
                    f.lean = -0.1f; f.swordAng = 1.45f + 0.5f * k; f.armB = 1.0f;
                } else {
                    f.lean = 0.5f; f.legF = 1.0f; f.legB = -0.9f; f.kneeF = 1.3f; f.kneeB = 1.1f; f.swordAng = 1.5f; f.armB = -0.5f;
                }
                break;
            }
            case ACT:
                if (atk == A_SWEEP) {
                    float k = Math.min(1f, stateT / 0.2f);
                    f.lean = 0.6f; f.legF = 1.0f; f.legB = -0.8f; f.kneeF = 0.3f; f.kneeB = 0.5f; f.armB = -0.3f;
                    f.swordAng = 3.9f - 3.0f * (1f - (1f - k) * (1f - k));
                } else if (atk == A_SLAM) {
                    f.lean = 0.3f; f.legF = 0.5f; f.kneeF = 1.2f; f.legB = -0.3f; f.kneeB = 1.0f; f.swordAng = 3.0f; f.armB = 2.6f;
                } else if (atk == A_FAN) {
                    f.lean = 0.3f; f.swordAng = 1.4f; f.armB = -0.3f; f.legF = 0.5f; f.legB = -0.5f;
                } else {
                    float rs = (float) Math.sin(t * 22f);
                    f.lean = 0.7f; f.legF = rs * 1.1f; f.legB = -rs * 1.1f; f.kneeF = 0.6f; f.kneeB = 0.6f; f.swordAng = 1.5f; f.armB = -0.8f;
                }
                break;
            case REC:
                f.lean = 0.35f; f.swordAng = atk == A_SLAM ? 0.15f : 0.5f;
                f.legF = 0.4f; f.legB = -0.4f; f.kneeF = 0.4f; f.kneeB = 0.4f;
                break;
            case ROAR:
                f.lean = -0.3f; f.swordAng = 2.9f; f.armB = 2.9f + (float) Math.sin(t * 50f) * 0.1f;
                break;
            case DYING: {
                float k = Math.min(1f, stateT / 0.8f);
                f.lean = 0.3f + 0.4f * k; f.legF = 1.0f + 0.3f * k; f.kneeF = 1.6f + 0.6f * k;
                f.legB = -0.5f; f.kneeB = 1.9f; f.swordAng = 0.2f; f.armB = 0.8f;
                f.alpha = (int) (255f * Math.max(0f, 1f - Math.max(0f, stateT - 1.2f) / 1.1f));
                break;
            }
            default:
                break;
        }
    }

    void draw(Canvas c) {
        pose();
        float al = fig.alpha / 255f;
        Art.glow(c, Art.GLOW_RED, cx(), y + h * 0.5f, 130f, (phase2 ? 0.55f : 0.35f) * al);
        if (state == TELE) telegraph(c);
        Art.draw(c, fig);
        if (state == TELE && atk == A_FAN) {
            float k = Math.min(1f, stateT / teleTime());
            Art.glow(c, Art.GLOW_RED, fig.j[22], fig.j[23], 10f + 26f * k, 0.5f + 0.5f * k);
        }
    }

    private void telegraph(Canvas c) {
        float k = Math.min(1f, stateT / teleTime());
        Paint p = Art.P;
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFFF2040);
        if (atk == A_SWEEP) {
            float hx = dir > 0 ? cx() - 6f : cx() - 90f;
            p.setAlpha((int) (30f + 70f * k));
            c.drawRect(hx, y + 8f, hx + 96f, y + h, p);
        } else if (atk == A_CHARGE) {
            float hx = dir > 0 ? cx() : cx() - 420f;
            p.setAlpha((int) (20f + 50f * k));
            c.drawRect(hx, y + h - 24f, hx + 420f, y + h, p);
        } else if (atk == A_SLAM) {
            Art.glow(c, Art.GLOW_RED, cx(), y + h, 50f + 40f * k, 0.5f + 0.5f * k);
        }
    }
}
