package com.shadowborn.game;

/**
 * Turns real frame times into fixed 60 Hz update steps plus an interpolation factor for drawing.
 * Kept free of Android classes so the headless tests can exercise the exact logic the game loop uses.
 */
final class FrameClock {
    static final float STEP = 1f / 60f;
    private static final float MAX_FRAME = 0.1f, SNAP = 0.0012f;
    private static final int MAX_STEPS = 5;
    private float acc;

    /** Returns how many update steps to run for a frame that took dt seconds. */
    int advance(float dt) {
        if (dt > MAX_FRAME) dt = MAX_FRAME;
        // frames locked to a 60 Hz display still jitter by a fraction of a millisecond; treat them as exact so the fixed
        // step does not alternate between zero and two updates (visible as a stutter)
        if (Math.abs(dt - STEP) < SNAP) dt = STEP;
        acc += dt;
        int steps = 0;
        while (acc >= STEP && steps < MAX_STEPS) {
            acc -= STEP;
            steps++;
        }
        if (steps == MAX_STEPS) acc = 0f;
        return steps;
    }

    /** How far the display time is between the previous update step (0) and the latest one (1). */
    float alpha() {
        return Math.min(1f, acc / STEP);
    }

    void reset() {
        acc = 0f;
    }
}
