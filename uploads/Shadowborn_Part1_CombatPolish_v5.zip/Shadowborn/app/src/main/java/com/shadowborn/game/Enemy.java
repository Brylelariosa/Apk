package com.shadowborn.game;

import android.graphics.Canvas;
import android.graphics.Paint;

/** Ground husks (patrol, chase, telegraphed lunge) and floating wraiths (hover, charge, fire orbs). */
final class Enemy extends Body {
    static final int HUSK = 0, WRAITH = 1;
    private static final int PATROL = 0, CHASE = 1, WINDUP = 2, STRIKE = 3, RECOVER = 4, HURT = 5, HOVER = 6, CHARGE = 7;

    final int type;
    int hp, maxHp, lastSwing = -1;
    boolean dead, remove;
    private int state, dir = 1;
    private float stateT, flash, deathT, t, shootCd, phase;
    private boolean hitDone;
    private final Art.Fig fig = new Art.Fig();

    Enemy(int type, float x, float y) {
        this.type = type;
        this.x = x;
        this.y = y;
        if (type == HUSK) {
            w = 16f;
            h = 30f;
            hp = 34;
            state = PATROL;
        } else {
            w = 20f;
            h = 24f;
            hp = 22;
            gravity = 0f;
            state = HOVER;
            shootCd = 1.2f + (float) Math.random();
        }
        maxHp = hp;
        dir = Math.random() < 0.5 ? -1 : 1;
        t = (float) (Math.random() * 6.0);
    }

    void update(Game g, float dt) {
        t += dt;
        stateT += dt;
        if (flash > 0f) flash -= dt;
        if (dead) {
            deathT += dt;
            vx = approach(vx, 0f, 500f * dt);
            physics(g.world, dt);
            if (deathT > 0.5f) remove = true;
            return;
        }
        Player p = g.player;
        float dx = p.cx() - cx(), dy = p.cy() - cy();
        if (type == HUSK) husk(g, p, dx, dy, dt);
        else wraith(g, p, dx, dy, dt);
        physics(g.world, dt);
        phase += Math.abs(vx) * dt * 0.09f;
        if (y > g.world.room.h * World.TS + 80f) {
            dead = true;
            remove = true;
        }
    }

    private boolean blocked(World wd) {
        if (hitWall) return true;
        float fx = dir > 0 ? x + w + 4f : x - 4f;
        int tx = (int) Math.floor(fx / World.TS);
        if (wd.solid(tx, (int) Math.floor((y + h * 0.5f) / World.TS))) return true;
        return onGround && !wd.solid(tx, (int) Math.floor((y + h + 6f) / World.TS));
    }

    private void husk(Game g, Player p, float dx, float dy, float dt) {
        float adx = Math.abs(dx);
        switch (state) {
            case PATROL:
                vx = dir * 40f;
                if (blocked(g.world)) {
                    dir = -dir;
                    vx = dir * 40f;
                }
                if (!p.dead && adx < 170f && Math.abs(dy) < 70f) {
                    state = CHASE;
                    stateT = 0f;
                }
                break;
            case CHASE:
                dir = dx > 0f ? 1 : -1;
                vx = blocked(g.world) ? 0f : dir * 82f;
                if (!p.dead && adx < 44f && Math.abs(dy) < 44f && stateT > 0.3f) {
                    state = WINDUP;
                    stateT = 0f;
                    vx = 0f;
                } else if (p.dead || adx > 300f || Math.abs(dy) > 140f) {
                    state = PATROL;
                    stateT = 0f;
                }
                break;
            case WINDUP:
                vx = 0f;
                if (stateT > 0.55f) {
                    state = STRIKE;
                    stateT = 0f;
                    hitDone = false;
                    vx = dir * 210f;
                }
                break;
            case STRIKE:
                vx = approach(vx, 0f, 700f * dt);
                if (!hitDone && !p.dead) {
                    float hx = dir > 0 ? cx() : cx() - 40f;
                    if (overlap(hx, y - 4f, 40f, h + 6f, p.x, p.y, p.w, p.h)) {
                        hitDone = true;
                        p.hurt(g, 16, cx());
                    }
                }
                if (stateT > 0.2f) {
                    state = RECOVER;
                    stateT = 0f;
                    vx = 0f;
                }
                break;
            case RECOVER:
                vx = 0f;
                if (stateT > 0.7f) {
                    state = CHASE;
                    stateT = 0f;
                }
                break;
            default:
                vx = approach(vx, 0f, 600f * dt);
                if (stateT > 0.28f) {
                    state = CHASE;
                    stateT = 0f;
                }
                break;
        }
    }

    private void wraith(Game g, Player p, float dx, float dy, float dt) {
        float adx = Math.abs(dx);
        dir = dx > 0f ? 1 : -1;
        if (state == HOVER) {
            float tvx = adx < 120f ? -dir * 70f : (adx > 200f ? dir * 70f : (float) Math.sin(t * 0.9f) * 40f);
            if (p.dead) tvx = 0f;
            vx = approach(vx, tvx, 300f * dt);
            float target = p.y - 46f + (float) Math.sin(t * 2f) * 16f;
            vy = approach(vy, clamp((target - y) * 2.5f, -80f, 80f), 400f * dt);
            shootCd -= dt;
            if (shootCd <= 0f && adx < 340f && Math.abs(dy) < 220f && !p.dead) {
                state = CHARGE;
                stateT = 0f;
            }
        } else if (state == CHARGE) {
            vx = approach(vx, 0f, 400f * dt);
            vy = approach(vy, 0f, 400f * dt);
            if (stateT > 0.75f) {
                float ox = cx() + dir * 8f, oy = cy();
                float ax = p.cx() - ox, ay = p.cy() - oy;
                float len = (float) Math.sqrt(ax * ax + ay * ay) + 0.001f;
                g.projs.add(new Proj(Proj.ORB, ox, oy, ax / len * 170f, ay / len * 170f, 12, 4f));
                g.fx.burst(ox, oy, 8, 0xFFB070FF, 90f, 0.3f, 2.5f);
                state = HOVER;
                stateT = 0f;
                shootCd = 2.2f + g.rnd.nextFloat() * 1.2f;
            }
        } else {
            vx = approach(vx, 0f, 400f * dt);
            vy = approach(vy, 0f, 400f * dt);
            if (stateT > 0.3f) {
                state = HOVER;
                stateT = 0f;
            }
        }
    }

    void hurt(Game g, int dmg, float srcX, float kb) {
        if (dead) return;
        hp -= dmg;
        flash = 0.12f;
        float d = cx() < srcX ? -1f : 1f;
        if (type == HUSK) {
            vx = d * kb;
            vy = -140f;
            hitDone = true;
        } else {
            vx = d * kb * 0.8f;
            vy = -40f;
        }
        state = HURT;
        stateT = 0f;
        g.fx.sparks(cx(), cy(), d, 0xFFFFE8B0);
        g.fx.ring(cx(), cy(), 18f, 0xFFFFFFFF);
        g.fx.text(cx(), y - 4f, String.valueOf(dmg), 0xFFFFE0A0);
        if (hp <= 0) die(g);
    }

    private void die(Game g) {
        dead = true;
        deathT = 0f;
        if (type == WRAITH) gravity = 600f;
        g.fx.burst(cx(), cy(), 22, type == HUSK ? 0xFFFF3050 : 0xFFB070FF, 160f, 0.7f, 3f);
        g.fx.shake(3f);
        g.addShards(type == HUSK ? 4 : 3, cx(), y - 14f, true);
    }

    private void poseHusk(float al) {
        Art.Fig f = fig;
        f.x = cx();
        f.y = y + h;
        f.s = 0.95f;
        f.dir = dir;
        f.t = t;
        f.vx = vx;
        f.core = 0xFF160A1A;
        f.glow = 0xFFFF3050;
        f.eye = 0xFFFF9AA8;
        f.blade = 0xFFA06A74;      // rusted blood-steel
        f.bladeGlow = 0xFFFF2040;
        f.guard = 0xFF5A3A44;
        f.grip = 0xFF1A0C10;
        f.aura = 0.45f;
        f.bladeLen = 22f;
        f.scarf = false;
        f.horns = false;
        f.chest = false;
        f.alpha = (int) (255f * al);
        f.flash = flash > 0f ? 1f : 0f;
        float sp = Math.min(1f, Math.abs(vx) / 85f);
        switch (state) {
            case WINDUP: {
                float k = Math.min(1f, stateT / 0.55f);
                f.lean = -0.25f * k; f.legF = 0.5f; f.kneeF = 0.5f; f.legB = -0.5f; f.kneeB = 0.4f; f.armB = 2.0f;
                f.swordAng = 2.5f + 0.5f * k + (float) Math.sin(stateT * 40f) * 0.04f;
                break;
            }
            case STRIKE: {
                float k = Math.min(1f, stateT / 0.12f);
                f.lean = 0.55f; f.legF = 0.9f; f.kneeF = 0.4f; f.legB = -0.9f; f.kneeB = 0.3f; f.armB = -0.4f;
                f.swordAng = 3.0f - 2.2f * k;
                break;
            }
            case RECOVER:
                f.lean = 0.35f; f.legF = 0.4f; f.kneeF = 0.3f; f.legB = -0.4f; f.kneeB = 0.3f; f.armB = 0.3f; f.swordAng = 0.5f;
                break;
            case HURT:
                f.lean = -0.35f; f.legF = 0.3f; f.kneeF = 0.4f; f.legB = -0.5f; f.kneeB = 0.6f; f.armB = 2.4f; f.swordAng = 2.6f;
                break;
            default: {
                float cs = (float) Math.cos(phase), sn = (float) Math.sin(phase);
                f.lean = 0.3f;
                f.legF = sn * 0.7f * sp;
                f.legB = -f.legF;
                f.kneeF = 0.15f + Math.max(0f, cs) * 0.6f * sp;
                f.kneeB = 0.15f + Math.max(0f, -cs) * 0.6f * sp;
                f.armB = 0.5f + sn * 0.4f * sp;
                f.swordAng = 0.8f - sn * 0.2f * sp;
                break;
            }
        }
    }

    void draw(Canvas c) {
        float al = dead ? Math.max(0f, 1f - deathT / 0.5f) : 1f;
        if (type == HUSK) {
            Art.glow(c, Art.GLOW_RED, cx(), cy(), 40f, 0.28f * al);
            poseHusk(al);
            Art.draw(c, fig);
            if (state == WINDUP && !dead) {
                float k = Math.min(1f, stateT / 0.55f);
                Art.glow(c, Art.GLOW_RED, fig.j[22], fig.j[23], 8f + 18f * k, 0.5f + 0.5f * k);
            }
        } else {
            Art.wraith(c, cx(), cy(), t, dir, state == CHARGE ? Math.min(1f, stateT / 0.75f) : 0f, flash > 0f ? 1f : 0f, al);
        }
        if (!dead && hp < maxHp) {
            Paint p = Art.P;
            p.setStyle(Paint.Style.FILL);
            float bx = cx() - 12f, by = y - 10f;
            p.setColor(0xAA000000);
            c.drawRect(bx - 1f, by - 1f, bx + 25f, by + 4f, p);
            p.setColor(0xFFE03050);
            c.drawRect(bx, by, bx + 24f * hp / maxHp, by + 3f, p);
        }
    }
}
