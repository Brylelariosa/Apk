package com.mgba.android

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.widget.Toast

// Split out of MainActivity (Thirty-second pass) when the ROM browser
// became its own Activity (see RomBrowserActivity.kt) and needed the same
// small set of UI helpers MainActivity already had as private methods.
// Extension functions on Context/Activity rather than a shared base class —
// avoids touching MainActivity's class hierarchy at all for what's a small,
// stateless, purely-cosmetic set of helpers; every existing unqualified
// call site (dp(20), uiToast("..."), etc.) keeps compiling unchanged since
// these live in the same package.

/** SharedPreferences file name both Activities read/write. */
internal const val PREFS = "mgba_prefs"

internal val colorAccentLight = Color.parseColor("#D8D8DE")

internal fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

/** Transparent, outlined "chip" background for corner icon buttons. */
internal fun Context.iconChipBackground(): GradientDrawable = GradientDrawable().apply {
    shape = GradientDrawable.RECTANGLE
    cornerRadius = dp(10).toFloat()
    setColor(Color.parseColor("#33000000"))
    setStroke(dp(1).coerceAtLeast(2), colorAccentLight)
}

internal fun Activity.uiToast(msg: String) =
    Handler(Looper.getMainLooper()).post { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
