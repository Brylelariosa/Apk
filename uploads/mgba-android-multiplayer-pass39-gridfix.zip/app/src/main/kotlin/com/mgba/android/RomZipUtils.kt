package com.mgba.android

import android.content.ContentResolver
import android.net.Uri
import java.io.BufferedInputStream
import java.util.zip.ZipInputStream

/** Zip-content helpers shared between MainActivity's stageRomFile() (the
 *  actual ROM load — extracts the .gba it finds out of a zip) and
 *  RomBrowserActivity's content-verified zip filtering (zipContainsGba() —
 *  just checks whether a .gba entry exists, without touching the
 *  filesystem). Split into its own file (Thirty-second pass) when the ROM
 *  browser moved from an overlay inside MainActivity to its own Activity —
 *  before that, both call sites were instance methods of the same class and
 *  could just call each other directly; now they're two different classes,
 *  and this is the one thing about zip handling both still need identically. */
object RomZipUtils {

    /** Checks the real leading bytes for the zip local-file-header signature
     *  ("PK\x03\x04") on a mark/reset-capable stream, leaving its read
     *  position exactly where it was either way. Takes BufferedInputStream
     *  specifically (not the plain InputStream base type) so the mark/reset
     *  contract this needs is visible at the call site rather than only
     *  true "if the caller remembered to buffer it". */
    fun isZipSignature(input: BufferedInputStream): Boolean {
        input.mark(4)
        val sig = ByteArray(4)
        val n = input.read(sig)
        input.reset()
        return n == 4 && sig[0] == 0x50.toByte() && sig[1] == 0x4B.toByte() &&
                          sig[2] == 0x03.toByte() && sig[3] == 0x04.toByte()
    }

    /** Peeks inside a .zip [uri] for a .gba entry without extracting or
     *  writing anything — lets the ROM browser show only the .zip files
     *  that are actually GBA ROMs instead of every .zip in the folder by
     *  name alone (a save-data backup, a screenshot batch, or any other
     *  archive kept alongside ROMs would otherwise look exactly like one).
     *  Same real-magic-bytes-first check as MainActivity.stageRomFile(),
     *  and the same false-on-anything-unreadable contract; unlike
     *  stageRomFile() this never touches the filesystem and returns the
     *  instant a match is found rather than reading every remaining entry.
     *  [resolver] is passed in explicitly (rather than this being an
     *  Activity/Context extension) since it's the only piece either caller
     *  actually needs — no reason to couple this to a whole Context. */
    fun zipContainsGba(resolver: ContentResolver, uri: Uri): Boolean {
        val raw = resolver.openInputStream(uri) ?: return false
        raw.use { stream ->
            val input = stream.buffered()
            if (!isZipSignature(input)) return false
            ZipInputStream(input).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    if (!entry.isDirectory && entry.name.endsWith(".gba", ignoreCase = true)) return true
                    entry = zip.nextEntry
                }
            }
            return false
        }
    }
}
