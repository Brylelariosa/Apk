package com.zipapkbuilder.feature.upload

import android.app.AlertDialog
import com.zipapkbuilder.MainActivity
import com.zipapkbuilder.R
import com.zipapkbuilder.core.Formatters
import com.zipapkbuilder.core.FloatingTransferIndicator
import com.zipapkbuilder.net.GitHubApi
import com.zipapkbuilder.net.NetworkReliability
import org.json.JSONArray
import org.json.JSONObject

/**
 * Drives a single reliable, progress-tracked upload to GitHub: the upload
 * progress dialog, retry-with-backoff policy, and the large-file Git Data API
 * path (blob → tree → commit → ref update) that [BuildFlowController][com.zipapkbuilder.feature.build.BuildFlowController]
 * uses for anything too big for a single Contents API PUT.
 */
class UploadCoordinator(
    private val activity: MainActivity,
    private val networkReliability: NetworkReliability
) {
    /** Set by the upload dialog's Cancel button; polled by every chunked write and retry loop. */
    @Volatile var uploadCancelled = false

    /**
     * Drives the shared [com.zipapkbuilder.core.FloatingTransferIndicator]
     * bubble for one upload instead of the old screen-covering, non-cancelable
     * "Uploading" [AlertDialog] — the whole point of the floating bubble is
     * that it never forces itself in front of the app, so uploading no longer
     * blocks the user from doing anything else while it runs.
     *
     * Cancellation moves from an always-visible "✕ Cancel" button (which the
     * old modal needed since it blocked everything else) to a confirmation
     * prompt shown only when the user deliberately taps the bubble — the
     * upload keeps running silently in the background otherwise.
     */
    inner class UploadProgressHandle(private val fileName: String, private val totalBytes: Long) {
        private var lastSpeedTime  = System.currentTimeMillis()
        private var lastSpeedBytes = 0L

        init {
            activity.mainHandler.post {
                activity.floatingTransferIndicator.show(FloatingTransferIndicator.Mode.UPLOAD) { confirmCancel() }
                activity.floatingTransferIndicator.updateProgress(if (totalBytes > 0) 0 else -1)
                activity.setStatus("Uploading $fileName…")
            }
        }

        private fun confirmCancel() {
            AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
                .setTitle("Cancel upload?")
                .setMessage("Stop uploading \"$fileName\"?")
                .setPositiveButton("Cancel Upload") { _, _ ->
                    uploadCancelled = true
                    activity.appendLog("⚠ Cancelling upload…")
                }
                .setNegativeButton("Keep Uploading", null)
                .show()
        }

        /** Reports transfer progress; safe to call from a background thread. */
        val onProgress: (written: Long, total: Long) -> Unit = { written, total ->
            val now     = System.currentTimeMillis()
            val elapsed = now - lastSpeedTime
            if (elapsed >= 200) {
                val speedBps = (written - lastSpeedBytes) * 1000L / elapsed.coerceAtLeast(1)
                lastSpeedTime  = now; lastSpeedBytes = written
                val pct    = if (total > 0) (written * 100L / total).toInt() else -1
                val pctStr = if (total > 0) "${"%.0f".format(written * 100.0 / total)}%" else "…"
                activity.mainHandler.post {
                    activity.floatingTransferIndicator.updateProgress(pct)
                    activity.setStatus("Uploading… $pctStr (${Formatters.fmtBytes(speedBps)}/s)")
                }
            }
        }

        /** Surfaces a status line (retry/backoff/offline messages) without a popup. */
        fun setStatus(text: String) {
            activity.mainHandler.post { activity.setStatus(text) }
        }

        /** Call once the upload attempt is fully done (success, failure, or
         *  cancellation) so the bubble reflects the outcome and fades itself out. */
        fun finish(success: Boolean) {
            activity.mainHandler.post {
                if (success) {
                    activity.floatingTransferIndicator.complete(FloatingTransferIndicator.Mode.UPLOAD) { }
                } else {
                    activity.floatingTransferIndicator.hide()
                }
            }
        }
    }

    /** Starts tracking one upload's progress via the floating bubble. Safe to
     *  call from a background thread. */
    fun beginUpload(fileName: String, totalBytes: Long): UploadProgressHandle =
        UploadProgressHandle(fileName, totalBytes)

    /**
     * Applies the same network-reliability policy downloads get from the
     * download engine to a single upload attempt — without byte-level
     * resume, since none of GitHub's upload endpoints (Contents API PUT, or
     * the blob/tree/commit sequence in [uploadViaGitDataApi]) support
     * resuming a partial request the way a download's Range header does.
     * Instead, a failed attempt is retried *from scratch*, which is safe here
     * because every step involved is naturally idempotent or cheap to redo:
     * Git blobs and trees are content-addressed (recreating one with the same
     * bytes just returns the same SHA, at negligible cost), and a retried
     * commit/ref-update simply produces one small additional commit rather
     * than corrupting anything.
     *
     * - A dropped connection while genuinely offline pauses (shown via
     *   [UploadProgressHandle.setStatus]) and resumes automatically the instant
     *   connectivity returns — this never counts against [maxRetries].
     * - A transient HTTP failure (429/500/502/503/504, recognized via
     *   [NetworkReliability.retryableHttpCodeIn] since these arrive as thrown
     *   messages, not return codes) or an I/O error while the network still
     *   tests as reachable retries with exponential backoff, up to
     *   [maxRetries] times.
     * - Anything else (auth failure, payload too large, cancellation) is
     *   fatal immediately.
     *
     * Must be called from a background thread.
     */
    fun <T> withUploadRetry(
        dlUi: UploadProgressHandle,
        maxRetries: Int = NetworkReliability.MAX_DOWNLOAD_RETRIES,
        attempt: () -> T
    ): T {
        var retryAttempt = 0
        var backoffMs = NetworkReliability.INITIAL_RETRY_BACKOFF_MS
        while (true) {
            if (uploadCancelled) throw Exception("Cancelled by user")
            try {
                return attempt()
            } catch (e: Exception) {
                if (e.message == "Cancelled by user" || uploadCancelled) throw e

                val retryableCode = networkReliability.retryableHttpCodeIn(e.message)
                val isIoIssue = e is java.io.IOException

                if (isIoIssue && !networkReliability.isNetworkAvailable()) {
                    dlUi.setStatus("⚠ Paused (No Internet) — will resume automatically")
                    val reconnected = networkReliability.waitForNetwork { uploadCancelled }
                    if (!reconnected) throw Exception("Cancelled by user")
                    activity.appendLog("↻ Back online — retrying upload…")
                    continue
                }

                if (isIoIssue || retryableCode != null) {
                    retryAttempt++
                    if (retryAttempt > maxRetries) {
                        throw Exception("${Formatters.friendlyError(e)} — gave up after $maxRetries retries.")
                    }
                    dlUi.setStatus("Retrying in ${backoffMs / 1000}s… (attempt $retryAttempt/$maxRetries)")
                    networkReliability.sleepCancellable(backoffMs) { uploadCancelled }
                    backoffMs = (backoffMs * 2).coerceAtMost(NetworkReliability.MAX_RETRY_BACKOFF_MS)
                    continue
                }

                throw e // not network/transient-server-related — fatal
            }
        }
    }

    /**
     * Uploads [b64Content] (base64-encoded file bytes) to [filePath] using the
     * Git Data API.  This path bypasses the Contents API's 50 MB file limit and
     * supports up to ~99 MB raw.
     *
     * Steps: create blob → get branch tip → get base tree →
     *        create tree → create commit → advance ref.
     *
     * Returns the blob SHA (stored as lastFileSha for later ops).
     */
    fun uploadViaGitDataApi(
        token: String, owner: String, repo: String, branch: String,
        filePath: String, b64Content: String, displayName: String,
        onProgress: (Long, Long) -> Unit
    ): String? {
        // 1. Create blob (largest network call — drives the progress bar)
        activity.appendLog("  Uploading blob…")
        val blobBody = "{\"content\":${JSONObject.quote(b64Content)},\"encoding\":\"base64\"}"
        val (blobCode, blobResp) = GitHubApi.httpPostWithProgress(
            token, "https://api.github.com/repos/$owner/$repo/git/blobs",
            blobBody, isCancelled = { uploadCancelled }, onProgress = onProgress
        )
        if (blobCode !in 200..201)
            throw Exception("Blob upload failed ($blobCode): ${blobResp.take(300)}")
        val blobSha = JSONObject(blobResp).getString("sha")
        activity.appendLog("  Blob created ✓ (${blobSha.take(12)}…)")

        // 2. Get the current branch tip commit SHA
        val (refCode, refBody) = GitHubApi.httpGet(token,
            "https://api.github.com/repos/$owner/$repo/git/ref/heads/$branch")
        if (refCode != 200) throw Exception("Could not read branch ref ($refCode)")
        val tipSha = JSONObject(refBody).getJSONObject("object").getString("sha")

        // 3. Get base tree SHA from tip commit
        val (commitCode, commitBody) = GitHubApi.httpGet(token,
            "https://api.github.com/repos/$owner/$repo/git/commits/$tipSha")
        if (commitCode != 200) throw Exception("Could not read tip commit ($commitCode)")
        val baseSha = JSONObject(commitBody).getJSONObject("tree").getString("sha")

        // 4. Create a new tree with the file
        activity.appendLog("  Creating tree…")
        val treeBody = JSONObject().apply {
            put("base_tree", baseSha)
            put("tree", JSONArray().put(JSONObject().apply {
                put("path", filePath)
                put("mode", "100644")
                put("type", "blob")
                put("sha",  blobSha)
            }))
        }.toString()
        val (treeCode, treeResp) = GitHubApi.httpPost(token,
            "https://api.github.com/repos/$owner/$repo/git/trees", treeBody)
        if (treeCode !in 200..201)
            throw Exception("Tree creation failed ($treeCode): ${treeResp.take(300)}")
        val newTreeSha = JSONObject(treeResp).getString("sha")

        // 5. Create new commit
        activity.appendLog("  Committing…")
        val newCommitBody = JSONObject().apply {
            put("message", "ci: upload $displayName [run ${System.currentTimeMillis()}]")
            put("tree",    newTreeSha)
            put("parents", JSONArray().put(tipSha))
        }.toString()
        val (newCommitCode, newCommitResp) = GitHubApi.httpPost(token,
            "https://api.github.com/repos/$owner/$repo/git/commits", newCommitBody)
        if (newCommitCode !in 200..201)
            throw Exception("Commit failed ($newCommitCode): ${newCommitResp.take(300)}")
        val newCommitSha = JSONObject(newCommitResp).getString("sha")

        // 6. Advance branch ref
        activity.appendLog("  Advancing branch ref…")
        val refPatchBody = JSONObject().apply {
            put("sha",   newCommitSha)
            put("force", false)
        }.toString()
        val (patchCode, patchResp) = GitHubApi.httpPatch(token,
            "https://api.github.com/repos/$owner/$repo/git/refs/heads/$branch", refPatchBody)
        if (patchCode !in 200..201)
            throw Exception("Ref update failed ($patchCode): ${patchResp.take(300)}")

        return blobSha
    }
}
