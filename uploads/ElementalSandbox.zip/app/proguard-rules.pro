# Default R8/ProGuard rules. AGP auto-generates keep rules for classes
# referenced from XML (e.g. the custom SandboxView), so no manual
# -keep is needed for this project's own code.
