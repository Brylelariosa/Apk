package com.jarry.elementalsand

import android.graphics.Color

/** Broad physical behaviour category driving how a cell moves each tick. */
enum class Phase { NONE, STATIC, POWDER, LIQUID, GAS }

/**
 * Every element the sandbox understands. [density] only matters for POWDER/LIQUID
 * (higher sinks through lower). GAS and STATIC ignore it.
 */
enum class Material(
    val phase: Phase,
    val density: Int,
    val flammable: Boolean,
    val baseColor: Int,
    val label: String
) {
    EMPTY(Phase.NONE, 0, false, Color.rgb(14, 16, 20), "Eraser"),
    SAND(Phase.POWDER, 6, false, Color.rgb(237, 201, 175), "Sand"),
    WATER(Phase.LIQUID, 3, false, Color.rgb(64, 164, 223), "Water"),
    OIL(Phase.LIQUID, 2, true, Color.rgb(96, 74, 42), "Oil"),
    STONE(Phase.STATIC, 100, false, Color.rgb(120, 120, 128), "Stone"),
    WOOD(Phase.STATIC, 100, true, Color.rgb(112, 74, 40), "Wood"),
    FIRE(Phase.GAS, 0, false, Color.rgb(255, 130, 20), "Fire"),
    SMOKE(Phase.GAS, 0, false, Color.rgb(95, 95, 95), "Smoke"),
    STEAM(Phase.GAS, 0, false, Color.rgb(213, 213, 222), "Steam"),
    LAVA(Phase.LIQUID, 7, false, Color.rgb(232, 72, 20), "Lava"),
    ACID(Phase.LIQUID, 3, false, Color.rgb(154, 224, 64), "Acid"),
    ICE(Phase.STATIC, 100, false, Color.rgb(192, 232, 250), "Ice"),
    PLANT(Phase.STATIC, 100, true, Color.rgb(52, 152, 62), "Plant"),
    GUNPOWDER(Phase.POWDER, 5, true, Color.rgb(72, 72, 82), "Powder"),
    ASH(Phase.POWDER, 4, false, Color.rgb(150, 150, 150), "Ash")
}
