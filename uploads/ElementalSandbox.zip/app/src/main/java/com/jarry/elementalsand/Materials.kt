package com.jarry.elementalsand

import android.graphics.Color

/** Broad physical behaviour category driving how a cell moves each tick. */
enum class Phase { NONE, STATIC, POWDER, LIQUID, GAS }

/** Grouping used to filter the palette into tabs. */
enum class Category { TOOL, POWDER, LIQUID, GAS, SOLID }

/**
 * Every element the sandbox understands. [density] only matters for POWDER/LIQUID
 * (higher sinks through lower). GAS and STATIC ignore it.
 */
enum class Material(
    val phase: Phase,
    val density: Int,
    val flammable: Boolean,
    val baseColor: Int,
    val label: String,
    val category: Category
) {
    EMPTY(Phase.NONE, 0, false, Color.rgb(14, 16, 20), "Eraser", Category.TOOL),
    VOID(Phase.STATIC, 100, false, Color.rgb(30, 10, 40), "Void", Category.TOOL),
    SPRING(Phase.STATIC, 100, false, Color.rgb(70, 150, 165), "Spring", Category.TOOL),

    SAND(Phase.POWDER, 6, false, Color.rgb(237, 201, 175), "Sand", Category.POWDER),
    SALT(Phase.POWDER, 5, false, Color.rgb(235, 235, 232), "Salt", Category.POWDER),
    GUNPOWDER(Phase.POWDER, 5, true, Color.rgb(72, 72, 82), "Powder", Category.POWDER),
    ASH(Phase.POWDER, 4, false, Color.rgb(150, 150, 150), "Ash", Category.POWDER),
    MUD(Phase.POWDER, 6, false, Color.rgb(84, 64, 48), "Mud", Category.POWDER),

    WATER(Phase.LIQUID, 3, false, Color.rgb(64, 164, 223), "Water", Category.LIQUID),
    OIL(Phase.LIQUID, 2, true, Color.rgb(96, 74, 42), "Oil", Category.LIQUID),
    LAVA(Phase.LIQUID, 7, false, Color.rgb(232, 72, 20), "Lava", Category.LIQUID),
    ACID(Phase.LIQUID, 3, false, Color.rgb(154, 224, 64), "Acid", Category.LIQUID),
    MOLTEN_METAL(Phase.LIQUID, 9, false, Color.rgb(255, 176, 64), "Molten Metal", Category.LIQUID),
    SLIME(Phase.LIQUID, 4, true, Color.rgb(120, 200, 90), "Slime", Category.LIQUID),

    FIRE(Phase.GAS, 0, false, Color.rgb(255, 130, 20), "Fire", Category.GAS),
    SMOKE(Phase.GAS, 0, false, Color.rgb(95, 95, 95), "Smoke", Category.GAS),
    STEAM(Phase.GAS, 0, false, Color.rgb(213, 213, 222), "Steam", Category.GAS),

    STONE(Phase.STATIC, 100, false, Color.rgb(120, 120, 128), "Stone", Category.SOLID),
    WOOD(Phase.STATIC, 100, true, Color.rgb(112, 74, 40), "Wood", Category.SOLID),
    ICE(Phase.STATIC, 100, false, Color.rgb(192, 232, 250), "Ice", Category.SOLID),
    PLANT(Phase.STATIC, 100, true, Color.rgb(52, 152, 62), "Plant", Category.SOLID),
    METAL(Phase.STATIC, 100, false, Color.rgb(150, 155, 165), "Metal", Category.SOLID),
    GLASS(Phase.STATIC, 100, false, Color.rgb(224, 218, 196), "Glass", Category.SOLID)
}
