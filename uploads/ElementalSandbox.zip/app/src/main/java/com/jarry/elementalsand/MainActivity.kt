package com.jarry.elementalsand

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

class MainActivity : AppCompatActivity() {

    private lateinit var sandboxView: SandboxView
    private val paletteDrawables = mutableMapOf<Material, GradientDrawable>()

    private val requestPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                saveToGallery()
            } else {
                Toast.makeText(this, R.string.permission_needed_toast, Toast.LENGTH_SHORT).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        hideSystemBars()

        sandboxView = findViewById(R.id.sandboxView)
        sandboxView.keepScreenOn = true

        val playPauseBtn = findViewById<Button>(R.id.playPauseBtn)
        val clearBtn = findViewById<Button>(R.id.clearBtn)
        val gravityBtn = findViewById<Button>(R.id.gravityBtn)
        val saveBtn = findViewById<Button>(R.id.saveBtn)
        val brushSeekBar = findViewById<SeekBar>(R.id.brushSeekBar)
        val paletteContainer = findViewById<LinearLayout>(R.id.paletteContainer)

        playPauseBtn.setOnClickListener {
            sandboxView.isRunning = !sandboxView.isRunning
            playPauseBtn.text = if (sandboxView.isRunning) "⏸" else "▶"
        }
        clearBtn.setOnClickListener { sandboxView.clearAll() }
        gravityBtn.setOnClickListener { gravityBtn.text = sandboxView.cycleGravity() }

        brushSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                sandboxView.brushRadius = progress + 1
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        sandboxView.brushRadius = brushSeekBar.progress + 1

        for (material in Material.values()) {
            paletteContainer.addView(createPaletteButton(material))
        }
        highlightSelected(Material.SAND)

        saveBtn.setOnClickListener { trySave() }
    }

    private fun hideSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.systemBars())
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    private fun createPaletteButton(material: Material): TextView {
        val size = dp(64)
        val tv = TextView(this)
        tv.layoutParams = LinearLayout.LayoutParams(size, size).apply {
            marginEnd = dp(8)
        }
        tv.gravity = Gravity.CENTER
        tv.text = material.label
        tv.textSize = 11f
        tv.setTextColor(if (isLight(material.baseColor)) Color.BLACK else Color.WHITE)

        val bg = GradientDrawable()
        bg.shape = GradientDrawable.RECTANGLE
        bg.cornerRadius = dp(10).toFloat()
        bg.setColor(material.baseColor)
        bg.setStroke(dp(1), Color.parseColor("#3A3F46"))
        tv.background = bg
        paletteDrawables[material] = bg

        tv.setOnClickListener {
            sandboxView.selectedMaterial = material
            highlightSelected(material)
        }
        return tv
    }

    private fun highlightSelected(material: Material) {
        for ((m, drawable) in paletteDrawables) {
            if (m == material) drawable.setStroke(dp(3), Color.WHITE)
            else drawable.setStroke(dp(1), Color.parseColor("#3A3F46"))
        }
    }

    private fun isLight(color: Int): Boolean {
        val r = Color.red(color)
        val g = Color.green(color)
        val b = Color.blue(color)
        val luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255.0
        return luminance > 0.6
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun trySave() {
        val needsPermission = Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) !=
            PackageManager.PERMISSION_GRANTED
        if (needsPermission) {
            requestPermissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        } else {
            saveToGallery()
        }
    }

    private fun saveToGallery() {
        val bmp = sandboxView.exportBitmap() ?: return
        try {
            val filename = "ElementalSandbox_${System.currentTimeMillis()}.png"
            val resolver = contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, filename)
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/ElementalSandbox")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
            }
            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            if (uri != null) {
                resolver.openOutputStream(uri)?.use { out ->
                    bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    values.clear()
                    values.put(MediaStore.Images.Media.IS_PENDING, 0)
                    resolver.update(uri, values, null, null)
                }
                Toast.makeText(this, R.string.saved_toast, Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, R.string.save_failed_toast, Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, R.string.save_failed_toast, Toast.LENGTH_SHORT).show()
        }
    }
}
