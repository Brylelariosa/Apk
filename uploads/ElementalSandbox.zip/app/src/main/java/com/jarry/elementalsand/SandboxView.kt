package com.jarry.elementalsand

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot
import kotlin.random.Random

/**
 * A self-contained falling-sand style particle sandbox.
 *
 * The simulation runs on a low-resolution grid (one cell per [cellSize] screen
 * pixels) which is rendered by writing directly into an ARGB bitmap and
 * scaling it up with nearest-neighbour sampling, so full-screen updates stay
 * cheap even on modest phones.
 */
class SandboxView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    // ---- Public, tweakable from the host Activity -------------------------------------------
    var selectedMaterial: Material = Material.SAND
    var brushRadius: Int = 3
    var isRunning: Boolean = true

    // ---- Grid state -----------------------------------------------------------------------
    private val cellSize = 8 // screen px per simulation cell
    private var cols = 0
    private var rows = 0
    private var ready = false

    private lateinit var grid: Array<Material>
    private lateinit var colorGrid: IntArray
    private lateinit var lifeGrid: IntArray
    private lateinit var updatedFrame: IntArray
    private lateinit var bitmap: Bitmap
    private val srcRect = Rect()
    private val dstRect = Rect()
    private val paint = Paint().apply {
        isFilterBitmap = false
        isAntiAlias = false
        isDither = false
    }

    private var frameCounter = 0

    // Gravity direction, one of the 4 cardinal directions. Cycled via cycleGravity().
    private var gravityDx = 0
    private var gravityDy = 1
    private var gravityIndex = 0

    private var lastTouchX = -1f
    private var lastTouchY = -1f

    // ---- Lifecycle ------------------------------------------------------------------------
    private val loop = object : Runnable {
        override fun run() {
            if (ready) {
                if (isRunning) step()
                bitmap.setPixels(colorGrid, 0, cols, 0, 0, cols, rows)
                invalidate()
            }
            postOnAnimation(this)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        postOnAnimation(loop)
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        removeCallbacks(loop)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w <= 0 || h <= 0) return
        cols = (w / cellSize).coerceAtLeast(1)
        rows = (h / cellSize).coerceAtLeast(1)
        val size = cols * rows
        grid = Array(size) { Material.EMPTY }
        colorGrid = IntArray(size) { Material.EMPTY.baseColor }
        lifeGrid = IntArray(size)
        updatedFrame = IntArray(size) { -1 }
        bitmap = Bitmap.createBitmap(cols, rows, Bitmap.Config.ARGB_8888)
        srcRect.set(0, 0, cols, rows)
        dstRect.set(0, 0, w, h)
        ready = true
    }

    override fun onDraw(canvas: Canvas) {
        if (!ready) return
        canvas.drawBitmap(bitmap, srcRect, dstRect, paint)
    }

    // ---- Touch input ------------------------------------------------------------------------
    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                paintAt(event.x, event.y)
                lastTouchX = event.x
                lastTouchY = event.y
            }
            MotionEvent.ACTION_MOVE -> {
                paintLine(lastTouchX, lastTouchY, event.x, event.y)
                lastTouchX = event.x
                lastTouchY = event.y
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                lastTouchX = -1f
                lastTouchY = -1f
            }
        }
        return true
    }

    private fun paintLine(x0: Float, y0: Float, x1: Float, y1: Float) {
        if (!ready) return
        if (x0 < 0f) {
            paintAt(x1, y1)
            return
        }
        val dist = hypot((x1 - x0).toDouble(), (y1 - y0).toDouble()).toFloat()
        val steps = (dist / (cellSize * 0.5f)).toInt().coerceAtLeast(1)
        for (i in 0..steps) {
            val t = i.toFloat() / steps
            paintAt(x0 + (x1 - x0) * t, y0 + (y1 - y0) * t)
        }
    }

    private fun paintAt(px: Float, py: Float) {
        if (!ready) return
        placeBrush((px / cellSize).toInt(), (py / cellSize).toInt())
    }

    private fun placeBrush(gx: Int, gy: Int) {
        val r = brushRadius
        val overwrites = selectedMaterial == Material.STONE || selectedMaterial == Material.EMPTY
        for (dy in -r..r) {
            for (dx in -r..r) {
                if (dx * dx + dy * dy > r * r) continue
                val nx = gx + dx
                val ny = gy + dy
                if (!inBounds(nx, ny)) continue
                val ni = index(nx, ny)
                if (!overwrites) {
                    if (grid[ni] != Material.EMPTY) continue
                    if (Random.nextInt(100) < 25) continue // sparse organic brush edge
                }
                setCell(ni, selectedMaterial, spawnLife(selectedMaterial))
            }
        }
    }

    private fun spawnLife(m: Material): Int = when (m) {
        Material.FIRE -> Random.nextInt(35, 70)
        Material.SMOKE -> Random.nextInt(90, 170)
        Material.STEAM -> Random.nextInt(90, 150)
        Material.ACID -> 30
        Material.PLANT -> Random.nextInt(25, 60)
        else -> 0
    }

    // ---- Public controls used by MainActivity ------------------------------------------------
    fun clearAll() {
        if (!ready) return
        for (i in grid.indices) {
            grid[i] = Material.EMPTY
            colorGrid[i] = Material.EMPTY.baseColor
            lifeGrid[i] = 0
        }
    }

    fun cycleGravity(): String {
        gravityIndex = (gravityIndex + 1) % 4
        return when (gravityIndex) {
            0 -> { gravityDx = 0; gravityDy = 1; "Gravity ↓" }
            1 -> { gravityDx = 0; gravityDy = -1; "Gravity ↑" }
            2 -> { gravityDx = -1; gravityDy = 0; "Gravity ←" }
            else -> { gravityDx = 1; gravityDy = 0; "Gravity →" }
        }
    }

    /** Upscaled, crisp copy of the current frame suitable for saving to the gallery. */
    fun exportBitmap(): Bitmap? {
        if (!ready) return null
        return Bitmap.createScaledBitmap(bitmap, cols * cellSize, rows * cellSize, false)
    }

    // ---- Grid helpers -------------------------------------------------------------------------
    private fun index(x: Int, y: Int) = y * cols + x
    private fun inBounds(x: Int, y: Int) = x in 0 until cols && y in 0 until rows

    private fun variantColor(base: Int): Int {
        val v = 14
        val r = ((base shr 16 and 0xFF) + Random.nextInt(-v, v + 1)).coerceIn(0, 255)
        val g = ((base shr 8 and 0xFF) + Random.nextInt(-v, v + 1)).coerceIn(0, 255)
        val b = ((base and 0xFF) + Random.nextInt(-v, v + 1)).coerceIn(0, 255)
        return (0xFF shl 24) or (r shl 16) or (g shl 8) or b
    }

    private fun setCell(idx: Int, material: Material, life: Int) {
        grid[idx] = material
        colorGrid[idx] = if (material == Material.EMPTY) material.baseColor else variantColor(material.baseColor)
        lifeGrid[idx] = life
        updatedFrame[idx] = frameCounter
    }

    private fun swap(i1: Int, i2: Int) {
        val tm = grid[i1]; grid[i1] = grid[i2]; grid[i2] = tm
        val tc = colorGrid[i1]; colorGrid[i1] = colorGrid[i2]; colorGrid[i2] = tc
        val tl = lifeGrid[i1]; lifeGrid[i1] = lifeGrid[i2]; lifeGrid[i2] = tl
        updatedFrame[i1] = frameCounter
        updatedFrame[i2] = frameCounter
    }

    private inline fun forEachNeighbor4(x: Int, y: Int, action: (nx: Int, ny: Int, idx: Int) -> Unit) {
        if (inBounds(x, y - 1)) action(x, y - 1, index(x, y - 1))
        if (inBounds(x, y + 1)) action(x, y + 1, index(x, y + 1))
        if (inBounds(x - 1, y)) action(x - 1, y, index(x - 1, y))
        if (inBounds(x + 1, y)) action(x + 1, y, index(x + 1, y))
    }

    private fun canEnter(targetIdx: Int, self: Material): Boolean {
        val t = grid[targetIdx]
        if (t == Material.EMPTY) return true
        if (self.phase == Phase.GAS) return false
        return (t.phase == Phase.LIQUID || t.phase == Phase.POWDER) && t.density < self.density
    }

    // ---- Simulation step ------------------------------------------------------------------
    private fun step() {
        frameCounter++
        val leftToRight = frameCounter % 2 == 0
        for (y in rows - 1 downTo 0) {
            if (leftToRight) {
                for (x in 0 until cols) updateCellIfNeeded(x, y)
            } else {
                for (x in cols - 1 downTo 0) updateCellIfNeeded(x, y)
            }
        }
    }

    private fun updateCellIfNeeded(x: Int, y: Int) {
        val idx = index(x, y)
        if (updatedFrame[idx] == frameCounter) return
        val m = grid[idx]
        if (m == Material.EMPTY) {
            updatedFrame[idx] = frameCounter
            return
        }
        updatedFrame[idx] = frameCounter
        val changed = applyReactions(x, y, idx, m)
        if (changed) return
        when (grid[idx].phase) {
            Phase.POWDER, Phase.LIQUID -> movePowderOrLiquid(x, y, idx, grid[idx])
            Phase.GAS -> moveGas(x, y, idx, grid[idx])
            else -> {}
        }
    }

    private fun movePowderOrLiquid(x: Int, y: Int, idx: Int, m: Material): Boolean {
        val fx = gravityDx
        val fy = gravityDy
        val px = -gravityDy
        val py = gravityDx

        var nx = x + fx
        var ny = y + fy
        if (inBounds(nx, ny)) {
            val ti = index(nx, ny)
            if (canEnter(ti, m)) { swap(idx, ti); return true }
        }

        val order = if (Random.nextBoolean()) intArrayOf(1, -1) else intArrayOf(-1, 1)
        for (s in order) {
            nx = x + fx + px * s
            ny = y + fy + py * s
            if (inBounds(nx, ny)) {
                val ti = index(nx, ny)
                if (canEnter(ti, m)) { swap(idx, ti); return true }
            }
        }

        if (m.phase == Phase.LIQUID) {
            for (s in order) {
                nx = x + px * s
                ny = y + py * s
                if (inBounds(nx, ny)) {
                    val ti = index(nx, ny)
                    if (canEnter(ti, m)) { swap(idx, ti); return true }
                }
            }
        }
        return false
    }

    private fun moveGas(x: Int, y: Int, idx: Int, m: Material): Boolean {
        val fx = -gravityDx
        val fy = -gravityDy
        val px = -gravityDy
        val py = gravityDx

        var nx = x + fx
        var ny = y + fy
        if (inBounds(nx, ny) && grid[index(nx, ny)] == Material.EMPTY) {
            swap(idx, index(nx, ny)); return true
        }

        val order = if (Random.nextBoolean()) intArrayOf(1, -1) else intArrayOf(-1, 1)
        for (s in order) {
            nx = x + fx + px * s
            ny = y + fy + py * s
            if (inBounds(nx, ny) && grid[index(nx, ny)] == Material.EMPTY) {
                swap(idx, index(nx, ny)); return true
            }
        }
        for (s in order) {
            nx = x + px * s
            ny = y + py * s
            if (inBounds(nx, ny) && grid[index(nx, ny)] == Material.EMPTY) {
                swap(idx, index(nx, ny)); return true
            }
        }
        return false
    }

    /** Returns true if the cell at (x,y) itself changed identity this tick (so it should not also move). */
    private fun applyReactions(x: Int, y: Int, idx: Int, m: Material): Boolean {
        when (m) {
            Material.FIRE -> {
                lifeGrid[idx]--
                var extinguished = false
                forEachNeighbor4(x, y) { nx2, ny2, ni ->
                    if (updatedFrame[ni] != frameCounter) {
                        val nm = grid[ni]
                        when {
                            nm == Material.GUNPOWDER && Random.nextInt(100) < 12 -> explode(nx2, ny2)
                            nm.flammable && Random.nextInt(100) < 10 -> setCell(ni, Material.FIRE, Random.nextInt(35, 70))
                            nm == Material.WATER && Random.nextInt(100) < 35 -> {
                                setCell(ni, Material.STEAM, Random.nextInt(90, 150))
                                extinguished = true
                            }
                            nm == Material.ICE && Random.nextInt(100) < 15 ->
                                setCell(ni, Material.WATER, 0)
                        }
                    }
                }
                if (extinguished || lifeGrid[idx] <= 0) {
                    if (Random.nextInt(100) < 25) setCell(idx, Material.ASH, 0)
                    else setCell(idx, Material.SMOKE, Random.nextInt(90, 170))
                    return true
                }
                return false
            }
            Material.LAVA -> {
                var turnedToStone = false
                forEachNeighbor4(x, y) { nx2, ny2, ni ->
                    if (updatedFrame[ni] != frameCounter) {
                        val nm = grid[ni]
                        when {
                            nm == Material.GUNPOWDER && Random.nextInt(100) < 15 -> explode(nx2, ny2)
                            nm.flammable && Random.nextInt(100) < 12 -> setCell(ni, Material.FIRE, Random.nextInt(35, 70))
                            (nm == Material.WATER || nm == Material.ICE) && Random.nextInt(100) < 40 -> {
                                setCell(ni, Material.STEAM, Random.nextInt(90, 150))
                                turnedToStone = true
                            }
                        }
                    }
                }
                if (turnedToStone) { setCell(idx, Material.STONE, 0); return true }
                // lava is viscous: only moves on every other tick
                if (frameCounter % 2 != 0) return true
                return false
            }
            Material.ACID -> {
                var dissolvedSomething = false
                forEachNeighbor4(x, y) { _, _, ni ->
                    if (updatedFrame[ni] != frameCounter) {
                        val nm = grid[ni]
                        if (nm != Material.EMPTY && nm != Material.ACID && nm != Material.STONE && Random.nextInt(100) < 18) {
                            setCell(ni, Material.EMPTY, 0)
                            dissolvedSomething = true
                        }
                    }
                }
                if (dissolvedSomething) {
                    lifeGrid[idx] -= 7
                    if (lifeGrid[idx] <= 0) { setCell(idx, Material.EMPTY, 0); return true }
                }
                return false
            }
            Material.ICE -> {
                var melted = false
                forEachNeighbor4(x, y) { _, _, ni ->
                    if (!melted) {
                        val nm = grid[ni]
                        if ((nm == Material.FIRE || nm == Material.LAVA) && Random.nextInt(100) < 10) {
                            setCell(idx, Material.WATER, 0)
                            melted = true
                        }
                    }
                }
                return melted
            }
            Material.PLANT -> {
                if (lifeGrid[idx] > 0) {
                    lifeGrid[idx]--
                    return false
                }
                var waterIdx = -1
                forEachNeighbor4(x, y) { _, _, ni ->
                    if (waterIdx == -1 && grid[ni] == Material.WATER) waterIdx = ni
                }
                if (waterIdx != -1) {
                    val aboveX = x - gravityDx
                    val aboveY = y - gravityDy
                    if (inBounds(aboveX, aboveY)) {
                        val ai = index(aboveX, aboveY)
                        if (grid[ai] == Material.EMPTY && Random.nextInt(100) < 20) {
                            setCell(ai, Material.PLANT, Random.nextInt(25, 60))
                            setCell(waterIdx, Material.EMPTY, 0)
                        }
                    }
                    lifeGrid[idx] = Random.nextInt(25, 60)
                }
                return false
            }
            Material.SMOKE, Material.STEAM -> {
                lifeGrid[idx]--
                if (lifeGrid[idx] <= 0) {
                    if (m == Material.STEAM && Random.nextInt(100) < 40) setCell(idx, Material.WATER, 0)
                    else setCell(idx, Material.EMPTY, 0)
                    return true
                }
                return false
            }
            else -> return false
        }
    }

    /** Gunpowder ignition: clears a small crater and leaves a ring of fire. */
    private fun explode(cx: Int, cy: Int) {
        val radius = 3
        for (dy in -radius..radius) {
            for (dx in -radius..radius) {
                val dist = hypot(dx.toDouble(), dy.toDouble())
                if (dist > radius) continue
                val nx = cx + dx
                val ny = cy + dy
                if (!inBounds(nx, ny)) continue
                val ni = index(nx, ny)
                if (grid[ni] == Material.STONE) continue
                if (dist < radius * 0.55) {
                    setCell(ni, Material.EMPTY, 0)
                } else if (Random.nextInt(100) < 70) {
                    setCell(ni, Material.FIRE, Random.nextInt(10, 25))
                }
            }
        }
    }
}
