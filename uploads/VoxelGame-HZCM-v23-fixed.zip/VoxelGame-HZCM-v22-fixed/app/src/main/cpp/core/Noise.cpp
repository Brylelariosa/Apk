#include "Noise.h"
#include <cmath>
#include <algorithm>

// ── Constructor ────────────────────────────────────────────────────────────────
Noise::Noise(int seed) {
    // Fill permutation table with identity
    for (int i = 0; i < 256; i++) perm[i] = i;

    // Fisher-Yates shuffle seeded by a simple LCG
    unsigned int s = (unsigned int)seed;
    for (int i = 255; i > 0; i--) {
        s = s * 1664525u + 1013904223u;
        int j = (int)(s & 0xFFu) % (i + 1);
        int tmp = perm[i]; perm[i] = perm[j]; perm[j] = tmp;
    }

    // Duplicate to avoid modular indexing
    for (int i = 0; i < 256; i++) perm[256 + i] = perm[i];
}

// ── Gradient helper ────────────────────────────────────────────────────────────
float Noise::grad(int hash, float x, float y) const {
    int h = hash & 7;
    float u = h < 4 ? x : y;
    float v = h < 4 ? y : x;
    return ((h & 1) ? -u : u) + ((h & 2) ? -v : v);
}

// ── Single-octave Perlin noise ─────────────────────────────────────────────────
float Noise::noise2D(float x, float y) const {
    int xi = (int)floorf(x) & 255;
    int yi = (int)floorf(y) & 255;
    float xf = x - floorf(x);
    float yf = y - floorf(y);

    float u = fade(xf);
    float v = fade(yf);

    int aa = perm[perm[xi]     + yi    ];
    int ab = perm[perm[xi]     + yi + 1];
    int ba = perm[perm[xi + 1] + yi    ];
    int bb = perm[perm[xi + 1] + yi + 1];

    float res = lerp(
        lerp(grad(aa, xf,       yf      ), grad(ba, xf - 1.f, yf      ), u),
        lerp(grad(ab, xf,       yf - 1.f), grad(bb, xf - 1.f, yf - 1.f), u),
        v
    );
    return res;  // approximately in [-1, 1]
}

// ── FBM ────────────────────────────────────────────────────────────────────────
float Noise::fbm(float x, float y, int octaves,
                  float lacunarity, float gain) const {
    float value     = 0.0f;
    float amplitude = 0.5f;
    float frequency = 1.0f;
    float maxValue  = 0.0f;

    for (int i = 0; i < octaves; ++i) {
        value    += noise2D(x * frequency, y * frequency) * amplitude;
        maxValue += amplitude;
        amplitude *= gain;
        frequency *= lacunarity;
    }

    return value / maxValue;  // normalised to [-1, 1]
}

// ── Ridged noise ───────────────────────────────────────────────────────────────
// Reflects |noise2D| to produce sharp peaks where the underlying Perlin noise
// crosses zero.  Output in [0, 1] — peaks = 1.0, valleys = 0.0.
float Noise::ridgedNoise2D(float x, float y) const {
    float n = noise2D(x, y);
    return 1.0f - std::abs(n);
}

// ── Ridged FBM ─────────────────────────────────────────────────────────────────
// Layered sum of ridgedNoise2D octaves, normalised to [0, 1].
// Produces dramatic ridgelines and mountain spines; combine with a continental
// mask so mountain ranges only appear in elevated regions.
float Noise::fbmRidged(float x, float y, int octaves,
                        float lacunarity, float gain) const {
    float value     = 0.0f;
    float amplitude = 0.5f;
    float frequency = 1.0f;
    float maxValue  = 0.0f;

    for (int i = 0; i < octaves; ++i) {
        value    += ridgedNoise2D(x * frequency, y * frequency) * amplitude;
        maxValue += amplitude;
        amplitude *= gain;
        frequency *= lacunarity;
    }

    return (maxValue > 0.0f) ? (value / maxValue) : 0.0f;  // [0, 1]
}
