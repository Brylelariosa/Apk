#pragma once

class Noise {
public:
    explicit Noise(int seed = 12345);

    // Single-octave Perlin noise in [-1, 1]
    float noise2D(float x, float y) const;

    // Fractional Brownian Motion: weighted sum of octaves, normalised to [-1, 1]
    float fbm(float x, float y, int octaves,
              float lacunarity = 2.0f, float gain = 0.5f) const;

    // Ridged noise: 1 - |noise2D(x,y)|  → [0, 1], with sharp peaks at 0-crossings
    // Use as a mountain-ridge basis (peaks where underlying noise crosses zero).
    float ridgedNoise2D(float x, float y) const;

    // FBM built from ridged noise.
    // Returns [0, 1].  Produces dramatic ridgelines and mountain ranges when
    // layered over a broad continental base.
    float fbmRidged(float x, float y, int octaves,
                    float lacunarity = 2.0f, float gain = 0.5f) const;

private:
    int perm[512];
    float grad(int hash, float x, float y) const;
    static float fade(float t) { return t * t * t * (t * (t * 6.f - 15.f) + 10.f); }
    static float lerp(float a, float b, float t) { return a + t * (b - a); }
};
