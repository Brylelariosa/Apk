#pragma once
// ============================================================================
// TextureAtlas.h  — v21
// Procedural 16×16 pixel-art tile generator for GL_TEXTURE_2D_ARRAY atlas.
//
// 20 tiles (layers 0-19), each 16×16 RGBA8.
// Tiles are designed to tile seamlessly: all patterns are modular in x,y.
// Nearest-neighbour filtering (GL_NEAREST) gives pixel-art look.
// GL_REPEAT is used so greedy-merged multi-block quads tile automatically.
//
// Tile index mapping — matches ATLAS_TILE[48] in the vertex shader:
//   0  DEBUG / missing (magenta)
//   1  GRASS_TOP
//   2  GRASS_SIDE
//   3  DIRT
//   4  STONE
//   5  SAND
//   6  SNOW_TOP
//   7  SNOW_SIDE
//   8  WOOD_SIDE  (bark)
//   9  WOOD_TOP   (rings)
//  10  LEAVES
//  11  WATER
//  12  GRAVEL
//  13  RED_SAND
//  14  CLAY
//  15  ICE
//  16  CACTUS_SIDE
//  17  CACTUS_TOP
//  18  BASALT
//  19  COBBLE
// ============================================================================
#include <cstdint>
#include <cstring>

// ── Compile-time constants ────────────────────────────────────────────────────
static constexpr int ATLAS_TILE_COUNT  = 20;
static constexpr int ATLAS_TILE_W      = 16;
static constexpr int ATLAS_TILE_H      = 16;
static constexpr int ATLAS_TILE_PIXELS = ATLAS_TILE_W * ATLAS_TILE_H;  // 256
static constexpr int ATLAS_TILE_BYTES  = ATLAS_TILE_PIXELS * 4;        // 1024

// ── RGBA pixel ────────────────────────────────────────────────────────────────
struct AtlasRGBA { uint8_t r, g, b, a; };

// ── Deterministic per-pixel hash [0,3] ───────────────────────────────────────
// Produces stable variation that tiles seamlessly since x,y are already [0,15].
static inline uint8_t ph(int x, int y, int seed) {
    uint32_t h = (uint32_t)(x * 1619 + y * 31337 + seed * 6971);
    h ^= h >> 13;
    h *= 0x9E3779B9u;
    h ^= h >> 11;
    return (uint8_t)(h & 3u);
}

// Variant: full [0,255] hash
static inline uint8_t ph8(int x, int y, int seed) {
    uint32_t h = (uint32_t)(x * 2341 + y * 17863 + seed * 9001);
    h ^= h >> 9;
    h *= 0xBF58476Du;
    h ^= h >> 13;
    return (uint8_t)(h & 0xFFu);
}

// ── Tile generation ───────────────────────────────────────────────────────────
// Each function writes 16×16×4 bytes into `out` in row-major order (y=0 top).
// out layout: pixel(x,y) at out + (y*16+x)*4

static inline void genTile_Debug(AtlasRGBA* p) {
    // Magenta checker — immediately visible if assigned to wrong face
    for (int y = 0; y < 16; ++y)
        for (int x = 0; x < 16; ++x)
            p[y*16+x] = ((x^y)&1) ? AtlasRGBA{255,0,255,255} : AtlasRGBA{200,0,200,255};
}

static inline void genTile_GrassTop(AtlasRGBA* p) {
    // Vivid green with light/dark variation and occasional lighter speck
    static const AtlasRGBA pal[4] = {
        {74,  174,  46, 255},  // base
        {82,  186,  52, 255},  // light
        {66,  162,  40, 255},  // dark
        {92,  198,  60, 255},  // bright highlight
    };
    for (int y = 0; y < 16; ++y)
        for (int x = 0; x < 16; ++x)
            p[y*16+x] = pal[ph(x,y,1)];
}

static inline void genTile_GrassSide(AtlasRGBA* p) {
    // Top 3 rows: green cap; rows 3-15: earthy brown dirt body
    static const AtlasRGBA green[4] = {
        {74,  174,  46, 255},
        {66,  162,  40, 255},
        {82,  186,  52, 255},
        {60,  150,  36, 255},
    };
    static const AtlasRGBA dirt[4] = {
        {140,  96,  56, 255},
        {128,  86,  48, 255},
        {152, 106,  62, 255},
        {120,  80,  44, 255},
    };
    for (int y = 0; y < 16; ++y)
        for (int x = 0; x < 16; ++x) {
            if (y < 3) p[y*16+x] = green[ph(x,y,2)];
            else       p[y*16+x] = dirt [ph(x,y,3)];
        }
}

static inline void genTile_Dirt(AtlasRGBA* p) {
    static const AtlasRGBA pal[4] = {
        {140,  96,  56, 255},
        {128,  86,  48, 255},
        {152, 106,  62, 255},
        {116,  78,  42, 255},
    };
    for (int y = 0; y < 16; ++y)
        for (int x = 0; x < 16; ++x) {
            int v = ph(x,y,4);
            // Occasional dark clump
            if (ph8(x,y,40) < 20) v = 3;
            p[y*16+x] = pal[v];
        }
}

static inline void genTile_Stone(AtlasRGBA* p) {
    static const AtlasRGBA pal[4] = {
        {128, 128, 128, 255},
        {140, 140, 140, 255},
        {116, 116, 116, 255},
        {152, 152, 152, 255},
    };
    for (int y = 0; y < 16; ++y)
        for (int x = 0; x < 16; ++x) {
            p[y*16+x] = pal[ph(x,y,5)];
            // Horizontal crack lines at y=5 and y=11
            if ((y==5 || y==11) && ph8(x,y,51)>160)
                p[y*16+x] = AtlasRGBA{100,100,100,255};
            // Vertical crack
            if ((x==7) && ph8(x,y,52)>180)
                p[y*16+x] = AtlasRGBA{108,108,108,255};
        }
}

static inline void genTile_Sand(AtlasRGBA* p) {
    static const AtlasRGBA pal[4] = {
        {228, 210, 144, 255},
        {220, 200, 134, 255},
        {236, 220, 154, 255},
        {216, 196, 128, 255},
    };
    for (int y = 0; y < 16; ++y)
        for (int x = 0; x < 16; ++x)
            p[y*16+x] = pal[ph(x,y,6)];
}

static inline void genTile_SnowTop(AtlasRGBA* p) {
    static const AtlasRGBA pal[4] = {
        {246, 246, 255, 255},
        {255, 255, 255, 255},
        {236, 238, 252, 255},
        {250, 252, 255, 255},
    };
    for (int y = 0; y < 16; ++y)
        for (int x = 0; x < 16; ++x)
            p[y*16+x] = pal[ph(x,y,7)];
}

static inline void genTile_SnowSide(AtlasRGBA* p) {
    // Cool gray with subtle variation, lighter at top
    for (int y = 0; y < 16; ++y)
        for (int x = 0; x < 16; ++x) {
            uint8_t base = (uint8_t)(200 + ph(x,y,8)*8 + (16-y));
            p[y*16+x] = AtlasRGBA{base, base, (uint8_t)(base+4), 255};
        }
}

static inline void genTile_WoodSide(AtlasRGBA* p) {
    // Dark brown bark with 3 vertical grain stripes
    static const AtlasRGBA pal[4] = {
        {115,  82,  46, 255},
        {104,  74,  40, 255},
        {126,  90,  52, 255},
        { 96,  68,  36, 255},
    };
    for (int y = 0; y < 16; ++y)
        for (int x = 0; x < 16; ++x) {
            int v = ph(x,y,9);
            // Vertical dark grain lines at x=4 and x=12
            if ((x==4||x==5||x==12||x==13) && (ph8(x,y,90)>80))
                v = 3;
            p[y*16+x] = pal[v];
        }
}

static inline void genTile_WoodTop(AtlasRGBA* p) {
    // Concentric rings from center; center is darkest
    static const AtlasRGBA pal[4] = {
        {132,  94,  52, 255},  // ring colour
        {144, 106,  62, 255},  // between rings
        {120,  84,  44, 255},  // inner dark
        {154, 116,  70, 255},  // outer light
    };
    for (int y = 0; y < 16; ++y)
        for (int x = 0; x < 16; ++x) {
            float dx = (float)(x - 7) + 0.5f;
            float dy = (float)(y - 7) + 0.5f;
            float r  = dx*dx + dy*dy;
            // Rings at sqrt(r) = 2,4,6 → alternates
            int ring = ((int)(r * 0.09f)) & 1;
            int v    = ring ? 1 : 0;
            // Slight variation
            if (ph8(x,y,91) < 30) v = (v+2)&3;
            p[y*16+x] = pal[v];
        }
}

static inline void genTile_Leaves(AtlasRGBA* p) {
    // Dithered dark/medium green with some holes (alpha stays 255 — mesher handles geometry)
    static const AtlasRGBA pal[4] = {
        { 51, 133,  31, 255},
        { 40, 110,  25, 255},
        { 62, 148,  38, 255},
        { 46, 122,  28, 255},
    };
    for (int y = 0; y < 16; ++y)
        for (int x = 0; x < 16; ++x)
            p[y*16+x] = pal[ph(x,y,10)];
}

static inline void genTile_Water(AtlasRGBA* p) {
    // Blue with subtle wave ripple rows
    for (int y = 0; y < 16; ++y)
        for (int x = 0; x < 16; ++x) {
            // Wave at y=4 and y=12
            bool wave = ((y==4||y==5||y==12||y==13) && ph8(x,y,111)>100);
            uint8_t r = wave ? 80  : 46;
            uint8_t g = wave ? 160 : 115;
            uint8_t b = wave ? 220 : 199;
            uint8_t var = ph(x,y,11) * 6;
            p[y*16+x] = AtlasRGBA{
                (uint8_t)(r+var), (uint8_t)(g+var), (uint8_t)(b+var), 200};
        }
}

static inline void genTile_Gravel(AtlasRGBA* p) {
    // Speckled medium-gray with brown flecks
    static const AtlasRGBA pal[4] = {
        {140, 133, 128, 255},
        {120, 115, 110, 255},
        {158, 150, 144, 255},
        {162, 120,  92, 255},  // brown pebble fleck
    };
    for (int y = 0; y < 16; ++y)
        for (int x = 0; x < 16; ++x) {
            int v = ph(x,y,12);
            // Occasional brown pebble
            if (ph8(x,y,120) < 25) v = 3;
            p[y*16+x] = pal[v];
        }
}

static inline void genTile_RedSand(AtlasRGBA* p) {
    // Warm terracotta with horizontal strata lines
    static const AtlasRGBA pal[4] = {
        {199, 102,  51, 255},
        {186,  92,  44, 255},
        {212, 114,  58, 255},
        {172,  82,  36, 255},
    };
    for (int y = 0; y < 16; ++y)
        for (int x = 0; x < 16; ++x) {
            int v = ph(x,y,13);
            // Strata every 4 rows
            if ((y & 3)==0 && ph8(x,y,130)>160) v = 3;
            p[y*16+x] = pal[v];
        }
}

static inline void genTile_Clay(AtlasRGBA* p) {
    // Pale blue-grey, very uniform
    static const AtlasRGBA pal[4] = {
        {161, 148, 128, 255},
        {152, 140, 120, 255},
        {170, 156, 136, 255},
        {158, 144, 124, 255},
    };
    for (int y = 0; y < 16; ++y)
        for (int x = 0; x < 16; ++x)
            p[y*16+x] = pal[ph(x,y,14)];
}

static inline void genTile_Ice(AtlasRGBA* p) {
    // Bright cyan-white with diagonal crack veins
    static const AtlasRGBA pal[4] = {
        {184, 224, 249, 255},
        {196, 232, 252, 255},
        {172, 212, 242, 255},
        {160, 200, 236, 255},
    };
    for (int y = 0; y < 16; ++y)
        for (int x = 0; x < 16; ++x) {
            int v = ph(x,y,15);
            // Crack: diagonal from top-right
            if ((x+y==8||x+y==9) && ph8(x,y,150)>140) v = 3;
            if ((x-y==4||x-y==5) && ph8(x,y,151)>160) v = 3;
            p[y*16+x] = pal[v];
        }
}

static inline void genTile_CactusSide(AtlasRGBA* p) {
    // Bright green with darker rib lines at x=4 and x=12
    static const AtlasRGBA pal[4] = {
        { 56, 153,  43, 255},
        { 46, 140,  36, 255},
        { 68, 166,  50, 255},
        { 36, 120,  28, 255},
    };
    for (int y = 0; y < 16; ++y)
        for (int x = 0; x < 16; ++x) {
            int v = ph(x,y,16);
            // Ribs
            if (x==4||x==5||x==11||x==12) v = 3;
            p[y*16+x] = pal[v];
        }
}

static inline void genTile_CactusTop(AtlasRGBA* p) {
    // Green with cross/star pattern
    static const AtlasRGBA pal[4] = {
        { 46, 133,  36, 255},
        { 38, 120,  30, 255},
        { 56, 148,  44, 255},
        { 28, 108,  22, 255},
    };
    for (int y = 0; y < 16; ++y)
        for (int x = 0; x < 16; ++x) {
            int v = ph(x,y,17);
            // Central cross
            bool cx = (x>=7&&x<=8);
            bool cy = (y>=7&&y<=8);
            if (cx||cy) v = 2;
            p[y*16+x] = pal[v];
        }
}

static inline void genTile_Basalt(AtlasRGBA* p) {
    // Very dark near-black with faint hexagonal column hints
    static const AtlasRGBA pal[4] = {
        { 56,  51,  59, 255},
        { 48,  44,  52, 255},
        { 64,  58,  66, 255},
        { 40,  36,  44, 255},
    };
    for (int y = 0; y < 16; ++y)
        for (int x = 0; x < 16; ++x) {
            int v = ph(x,y,18);
            // Faint horizontal fractures every 5 rows
            if ((y%5==0) && ph8(x,y,180)>180) v = 3;
            p[y*16+x] = pal[v];
        }
}

static inline void genTile_Cobble(AtlasRGBA* p) {
    // Medium gray, stacked rough stone look with outline pattern
    static const AtlasRGBA pal[4] = {
        {120, 115, 110, 255},
        {108, 104,  99, 255},
        {134, 128, 122, 255},
        { 94,  90,  87, 255},  // outline / grout
    };
    // Define stone outlines using alternating brick-like offset rows
    for (int y = 0; y < 16; ++y)
        for (int x = 0; x < 16; ++x) {
            int v = ph(x,y,19);
            // Grout lines: horizontal at y=0,7,8,15; vertical offset per row group
            bool hLine = (y==0||y==7||y==8||y==15);
            int offset = ((y<8)?0:8);
            bool vLine = ((x+offset)%8==0 || (x+offset)%8==7);
            if (hLine||vLine) v = 3;  // dark grout
            p[y*16+x] = pal[v];
        }
}

// ── Top-level generator ───────────────────────────────────────────────────────
// Fills `out` with ATLAS_TILE_COUNT layers of ATLAS_TILE_W×ATLAS_TILE_H RGBA8.
// out must have space for ATLAS_TILE_COUNT * ATLAS_TILE_W * ATLAS_TILE_H * 4 bytes.
// Layers are stored consecutively: layer 0, then layer 1, etc.
static inline void generateAtlasData(uint8_t* out) {
    for (int tile = 0; tile < ATLAS_TILE_COUNT; ++tile) {
        AtlasRGBA* p = reinterpret_cast<AtlasRGBA*>(
            out + tile * ATLAS_TILE_BYTES);
        switch (tile) {
            case  0: genTile_Debug     (p); break;
            case  1: genTile_GrassTop  (p); break;
            case  2: genTile_GrassSide (p); break;
            case  3: genTile_Dirt      (p); break;
            case  4: genTile_Stone     (p); break;
            case  5: genTile_Sand      (p); break;
            case  6: genTile_SnowTop   (p); break;
            case  7: genTile_SnowSide  (p); break;
            case  8: genTile_WoodSide  (p); break;
            case  9: genTile_WoodTop   (p); break;
            case 10: genTile_Leaves    (p); break;
            case 11: genTile_Water     (p); break;
            case 12: genTile_Gravel    (p); break;
            case 13: genTile_RedSand   (p); break;
            case 14: genTile_Clay      (p); break;
            case 15: genTile_Ice       (p); break;
            case 16: genTile_CactusSide(p); break;
            case 17: genTile_CactusTop (p); break;
            case 18: genTile_Basalt    (p); break;
            case 19: genTile_Cobble    (p); break;
            default: genTile_Debug     (p); break;
        }
    }
}
