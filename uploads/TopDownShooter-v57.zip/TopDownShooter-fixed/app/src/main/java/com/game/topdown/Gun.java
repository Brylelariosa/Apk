package com.game.topdown;

public class Gun {
    public String name;
    public int    maxAmmo, ammo;
    public float  fireRate, damage, bulletSpeed, spread, zoom, range;
    public int    pellets, color;
    public long   reloadMs;

    // runtime state
    public boolean reloading;
    public volatile long    reloadStart, lastFireTime;

    public boolean canFireNow() {
        if (ammo <= 0 || reloading) return false;
        return System.currentTimeMillis() - lastFireTime >= (long)(1000f / fireRate);
    }
    public void markFired() { lastFireTime = System.currentTimeMillis(); }

    public void startReload() {
        if (!reloading && ammo < maxAmmo) { reloading = true; reloadStart = System.currentTimeMillis(); }
    }
    public void tick() { tick(1.0f); }
    public void tick(float reloadMult) {
        if (reloading && System.currentTimeMillis() - reloadStart >= (long)(reloadMs * reloadMult)) {
            ammo = maxAmmo; reloading = false;
        }
    }

    // ── Special-mechanic flags (read by spawnBullets) ────────────────────────
    public int     bulletBounces;   // how many wall bounces each bullet gets
    public boolean bulletPiercing;  // bullet passes through enemies
    public boolean bulletExplosive; // bullet detonates on wall/range
    public boolean bulletHoming;    // bullet steers toward enemies
    public boolean bulletGhost;     // bullet ignores walls

    // ── Normalised stat accessors (0–1) for HUD stat bars ─────────────────────
    // Reference maxima across all guns
    static final float MAX_DMG   = 95f;
    static final float MAX_SPD   = 1700f;
    static final float MAX_RANGE = 2100f;
    static final float MAX_RATE  = 22f;

    public float statDamage()   { return Math.min(1f, damage       / MAX_DMG);   }
    public float statSpeed()    { return Math.min(1f, bulletSpeed  / MAX_SPD);   }
    public float statRange()    { return Math.min(1f, range        / MAX_RANGE); }
    public float statFireRate() { return Math.min(1f, fireRate     / MAX_RATE);  }

    public static Gun[] createAll() {
        return new Gun[]{pistol(), smg(), shotgun(), assault(), sniper(), burst(), minigun(),
                         revolver(), lmg(), plasma(),
                         bouncer(), piercer(), seeker(), blaster(), ghost()};
    }

    // 1. Pistol – normal FOV, medium range
    public static Gun pistol() {
        Gun g=new Gun(); g.name="Pistol"; g.maxAmmo=12; g.ammo=12;
        g.fireRate=3f; g.damage=34f; g.bulletSpeed=1100f; g.range=650f;
        g.pellets=1; g.spread=0.04f; g.reloadMs=1200;
        g.color=0xFF4FC3F7; g.zoom=1.0f; return g;
    }
    // 2. SMG – zoomed in, short range
    public static Gun smg() {
        Gun g=new Gun(); g.name="SMG"; g.maxAmmo=30; g.ammo=30;
        g.fireRate=10f; g.damage=14f; g.bulletSpeed=900f; g.range=620f;
        g.pellets=1; g.spread=0.12f; g.reloadMs=2000;
        g.color=0xFF81C784; g.zoom=1.2f; return g;
    }
    // 3. Shotgun – most zoomed in, very short range
    public static Gun shotgun() {
        Gun g=new Gun(); g.name="Shotgun"; g.maxAmmo=8; g.ammo=8;
        g.fireRate=1.1f; g.damage=18f; g.bulletSpeed=800f; g.range=220f;
        g.pellets=6; g.spread=0.32f; g.reloadMs=2400;
        g.color=0xFFFF8A65; g.zoom=1.35f; return g;
    }
    // 4. Assault Rifle – medium-out, good range
    public static Gun assault() {
        Gun g=new Gun(); g.name="Assault"; g.maxAmmo=25; g.ammo=25;
        g.fireRate=7.5f; g.damage=19f; g.bulletSpeed=1050f; g.range=900f;
        g.pellets=1; g.spread=0.07f; g.reloadMs=1800;
        g.color=0xFFFFB347; g.zoom=0.85f; return g;
    }
    // 5. Sniper – max zoom out, extreme range
    public static Gun sniper() {
        Gun g=new Gun(); g.name="Sniper"; g.maxAmmo=5; g.ammo=5;
        g.fireRate=0.8f; g.damage=95f; g.bulletSpeed=1700f; g.range=2100f;
        g.pellets=1; g.spread=0.005f; g.reloadMs=2800;
        g.color=0xFFCE93D8; g.zoom=0.52f; return g;
    }
    // 6. Burst – slightly out, medium range
    public static Gun burst() {
        Gun g=new Gun(); g.name="Burst"; g.maxAmmo=24; g.ammo=24;
        g.fireRate=3f; g.damage=22f; g.bulletSpeed=1080f; g.range=720f;
        g.pellets=3; g.spread=0.035f; g.reloadMs=2000;
        g.color=0xFF4DD0E1; g.zoom=0.90f; return g;
    }
    // 7. Minigun – slightly in, short-medium range
    public static Gun minigun() {
        Gun g=new Gun(); g.name="Minigun"; g.maxAmmo=120; g.ammo=120;
        g.fireRate=18f; g.damage=9f; g.bulletSpeed=950f; g.range=420f;
        g.pellets=1; g.spread=0.22f; g.reloadMs=4500;
        g.color=0xFFFF5252; g.zoom=1.1f; return g;
    }
    // 8. Revolver – high damage per shot, medium-long range, small clip
    public static Gun revolver() {
        Gun g=new Gun(); g.name="Revolver"; g.maxAmmo=6; g.ammo=6;
        g.fireRate=2.2f; g.damage=55f; g.bulletSpeed=1200f; g.range=850f;
        g.pellets=1; g.spread=0.02f; g.reloadMs=2200;
        g.color=0xFFFFD54F; g.zoom=0.95f; return g;
    }
    // 9. LMG – large magazine, sustained suppression fire, medium range
    public static Gun lmg() {
        Gun g=new Gun(); g.name="LMG"; g.maxAmmo=80; g.ammo=80;
        g.fireRate=11f; g.damage=13f; g.bulletSpeed=980f; g.range=750f;
        g.pellets=1; g.spread=0.15f; g.reloadMs=3800;
        g.color=0xFF90A4AE; g.zoom=1.0f; return g;
    }
    // 10. Plasma Rifle – slow heavy projectile, high damage, long range
    public static Gun plasma() {
        Gun g=new Gun(); g.name="Plasma"; g.maxAmmo=15; g.ammo=15;
        g.fireRate=1.8f; g.damage=72f; g.bulletSpeed=550f; g.range=1100f;
        g.pellets=1; g.spread=0.015f; g.reloadMs=2600;
        g.color=0xFF00E5FF; g.zoom=0.78f; return g;
    }
    // 11. Bouncer – rubber bullet ricochets off walls 3 times
    public static Gun bouncer() {
        Gun g=new Gun(); g.name="Bouncer"; g.maxAmmo=8; g.ammo=8;
        g.fireRate=1.8f; g.damage=45f; g.bulletSpeed=520f; g.range=1400f;
        g.pellets=1; g.spread=0.02f; g.reloadMs=2000;
        g.color=0xFF69F0AE; g.zoom=0.90f;
        g.bulletBounces=3; return g;
    }
    // 12. Piercer – needle punches through every enemy in a line
    public static Gun piercer() {
        Gun g=new Gun(); g.name="Piercer"; g.maxAmmo=15; g.ammo=15;
        g.fireRate=2.2f; g.damage=32f; g.bulletSpeed=1450f; g.range=1000f;
        g.pellets=1; g.spread=0.004f; g.reloadMs=1800;
        g.color=0xFF40C4FF; g.zoom=0.85f;
        g.bulletPiercing=true; return g;
    }
    // 13. Seeker – slow homing missile that steers toward enemies
    public static Gun seeker() {
        Gun g=new Gun(); g.name="Seeker"; g.maxAmmo=6; g.ammo=6;
        g.fireRate=1.0f; g.damage=68f; g.bulletSpeed=360f; g.range=1500f;
        g.pellets=1; g.spread=0.0f; g.reloadMs=2800;
        g.color=0xFFFF6E40; g.zoom=0.80f;
        g.bulletHoming=true; return g;
    }
    // 14. Blaster – explosive round detonates on wall/range (120px AOE)
    public static Gun blaster() {
        Gun g=new Gun(); g.name="Blaster"; g.maxAmmo=6; g.ammo=6;
        g.fireRate=1.2f; g.damage=40f; g.bulletSpeed=850f; g.range=650f;
        g.pellets=1; g.spread=0.03f; g.reloadMs=2200;
        g.color=0xFFFFD740; g.zoom=0.88f;
        g.bulletExplosive=true; return g;
    }
    // 15. Ghost – bullets phase through walls, extreme close range
    public static Gun ghost() {
        Gun g=new Gun(); g.name="Ghost"; g.maxAmmo=14; g.ammo=14;
        g.fireRate=4.0f; g.damage=28f; g.bulletSpeed=920f; g.range=420f;
        g.pellets=1; g.spread=0.018f; g.reloadMs=1500;
        g.color=0xFFEA80FC; g.zoom=1.10f;
        g.bulletGhost=true; return g;
    }
}
