package com.browser.app

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.app.DownloadManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.GestureDetector
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ── Data classes ───────────────────────────────────────────────────────────

data class BrowserTab(
    val id: Int,
    val webView: ScrollAwareWebView,
    val isIncognito: Boolean = false,
    var url: String   = "",
    var title: String = "New Tab",
    var isDesktopMode: Boolean = false
)

// ══════════════════════════════════════════════════════════════════════════
class MainActivity : AppCompatActivity() {

    // ── Static views ───────────────────────────────────────────────────
    private lateinit var webViewContainer: FrameLayout
    private lateinit var urlBar:           LinearLayout
    private lateinit var urlInput:         EditText
    private lateinit var btnBack:          ImageButton
    private lateinit var btnForward:       ImageButton
    private lateinit var btnRefresh:       ImageButton
    private lateinit var btnBookmark:      ImageButton
    private lateinit var btnTabCount:      TextView
    private lateinit var btnOverflow:      ImageButton
    private lateinit var btnToggle:        ImageButton
    private lateinit var pageProgress:     ProgressBar
    private lateinit var incognitoBar:     View
    private lateinit var topEdgeZone:      View
    private lateinit var findBar:          LinearLayout
    private lateinit var findInput:        EditText
    private lateinit var findCount:        TextView
    private lateinit var debugOverlay:     TextView

    // ── Managers ───────────────────────────────────────────────────────
    private val prefs by lazy { getSharedPreferences("browser_v21", MODE_PRIVATE) }
    private val bookmarkMgr by lazy { BookmarkManager(prefs) }
    private val historyMgr  by lazy { HistoryManager(prefs) }

    // ── Tabs ───────────────────────────────────────────────────────────
    private val tabs            = mutableListOf<BrowserTab>()
    private var activeTabIndex  = 0
    private var tabIdCounter    = 0
    private val closedTabs      = ArrayDeque<Pair<String, String>>() // url, title (max 10)
    private var tabDialog: AlertDialog? = null
    private val webView get()   = tabs[activeTabIndex].webView
    private val activeTab get() = tabs[activeTabIndex]

    // ── File upload ────────────────────────────────────────────────────
    private var fileUploadCallback: ValueCallback<Array<Uri>>? = null
    private val filePickerLauncher = registerForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris -> fileUploadCallback?.onReceiveValue(uris.toTypedArray()); fileUploadCallback = null }

    // ── Gesture / state ────────────────────────────────────────────────
    private var gestureDetector: GestureDetector? = null

    private var urlBarVisible        = false
    private var toggleVisible        = true
    private var isOnHomePage         = false
    private var isImeVisible         = false
    private var webInputFocused      = false
    private var debugOverlayVisible  = false
    private var lastScrollMs         = 0L
    private var autoHideRunnable: Runnable? = null

    // ── Settings ───────────────────────────────────────────────────────
    @Volatile private var currentHost:         String? = null
    @Volatile private var adBlockEnabled        = true
    @Volatile private var dataSaverLevel        = 0
    @Volatile private var fabBehavior           = 0
    @Volatile private var hiddenUrlBarMode      = false
    @Volatile private var autoHideDelayMs       = 5000L  // -1 = never
    @Volatile private var scrollHideEnabled     = true
    @Volatile private var swipeNavEnabled       = false
    @Volatile private var hapticEnabled         = true
    @Volatile private var searchEngineIndex     = 0
    @Volatile private var customSearchUrl       = ""

    // ── Swipe navigation state ─────────────────────────────────────────
    private var swipeOverlay:   ImageView?    = null
    private var swipeDestPanel: LinearLayout? = null
    private var swipeSnapBmp:   Bitmap?       = null
    private var swipeStartX     = 0f
    private var swipeGoBack     = false
    private var swipeActive     = false

    private val resetWebInputFocused = Runnable { if (!isImeVisible) webInputFocused = false }

    companion object {
        private const val MOBILE_UA =
            "Mozilla/5.0 (Linux; Android 13; Pixel 7) " +
            "AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/124.0.0.0 Mobile Safari/537.36"
        private const val DESKTOP_UA =
            "Mozilla/5.0 (X11; Linux x86_64) " +
            "AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/124.0.0.0 Safari/537.36"

        private val SEARCH_ENGINES = arrayOf(
            "Google"      to "https://www.google.com/search?q=",
            "Bing"        to "https://www.bing.com/search?q=",
            "DuckDuckGo"  to "https://duckduckgo.com/?q=",
            "Brave"       to "https://search.brave.com/search?q=",
            "Startpage"   to "https://www.startpage.com/search?q=",
            "Custom"      to ""
        )

        private val HIDE_DELAY_LABELS = arrayOf("2 seconds", "5 seconds", "10 seconds", "Never")
        private val HIDE_DELAY_VALUES = longArrayOf(2000L, 5000L, 10000L, -1L)

        private val DATA_SAVER_LABELS = arrayOf(
            "Off", "High Quality (~20%)", "Medium Quality (~40%)",
            "Low Quality (~65%)", "No Images (~80%)")

        private val FAB_BEHAVIOR_LABELS = arrayOf(
            "Auto-hide on scroll", "Tap page to hide", "Always visible")

        private val DEFAULT_SPEED_DIAL = """[
{"url":"https://www.google.com","name":"Google"},
{"url":"https://www.youtube.com","name":"YouTube"},
{"url":"https://www.facebook.com","name":"Facebook"},
{"url":"https://www.reddit.com","name":"Reddit"},
{"url":"https://x.com","name":"X"},
{"url":"https://www.wikipedia.org","name":"Wikipedia"},
{"url":"https://github.com","name":"GitHub"},
{"url":"https://gmail.com","name":"Gmail"}]"""
    }

    // ══════════════════════════════════════════════════════════════════
    // Lifecycle
    // ══════════════════════════════════════════════════════════════════

    override fun onCreate(savedInstanceState: Bundle?) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P)
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        WindowCompat.setDecorFitsSystemWindows(window, false)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        CookieManager.getInstance().setAcceptCookie(true)

        ViewCompat.setOnApplyWindowInsetsListener(window.decorView) { v, insets ->
            val wasVis = isImeVisible
            isImeVisible = insets.isVisible(WindowInsetsCompat.Type.ime())
            when {
                !wasVis && isImeVisible  -> { webView.removeCallbacks(resetWebInputFocused); webInputFocused = true }
                wasVis  && !isImeVisible -> { webInputFocused = false; applyImmersiveMode() }
            }
            ViewCompat.onApplyWindowInsets(v, insets)
        }

        bindStaticViews()
        loadSettings()
        applyImmersiveMode()
        applyHiddenUrlBarMode()

        val first = createTab()
        switchToTab(0, false)
        loadHomePage(first.webView)
    }

    override fun onPause() { super.onPause(); CookieManager.getInstance().flush() }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && !isImeVisible && !webInputFocused)
            window.decorView.postDelayed({ if (!isImeVisible && !webInputFocused) applyImmersiveMode() }, 350)
    }

    // ══════════════════════════════════════════════════════════════════
    // Settings persistence
    // ══════════════════════════════════════════════════════════════════

    private fun loadSettings() {
        adBlockEnabled      = prefs.getBoolean("ad_block",         true)
        dataSaverLevel      = prefs.getInt    ("data_saver",       0)
        fabBehavior         = prefs.getInt    ("fab_behavior",     0)
        hiddenUrlBarMode    = prefs.getBoolean("hidden_url_bar",   false)
        autoHideDelayMs     = prefs.getLong   ("auto_hide_delay",  5000L)
        scrollHideEnabled   = prefs.getBoolean("scroll_hide",      true)
        swipeNavEnabled     = prefs.getBoolean("swipe_nav",        false)
        hapticEnabled       = prefs.getBoolean("haptic",           true)
        searchEngineIndex   = prefs.getInt    ("search_engine",    0)
        customSearchUrl     = prefs.getString ("custom_search",    "") ?: ""
    }

    private fun saveSettings() {
        prefs.edit()
            .putBoolean("ad_block",        adBlockEnabled)
            .putInt    ("data_saver",      dataSaverLevel)
            .putInt    ("fab_behavior",    fabBehavior)
            .putBoolean("hidden_url_bar",  hiddenUrlBarMode)
            .putLong   ("auto_hide_delay", autoHideDelayMs)
            .putBoolean("scroll_hide",     scrollHideEnabled)
            .putBoolean("swipe_nav",       swipeNavEnabled)
            .putBoolean("haptic",          hapticEnabled)
            .putInt    ("search_engine",   searchEngineIndex)
            .putString ("custom_search",   customSearchUrl)
            .apply()
    }

    // ══════════════════════════════════════════════════════════════════
    // Immersive / window mode
    // ══════════════════════════════════════════════════════════════════

    private fun applyImmersiveMode() {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.hide(WindowInsetsCompat.Type.systemBars())
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    private fun applyHiddenUrlBarMode() {
        if (hiddenUrlBarMode) {
            // Show the transparent top-edge touch zone; hide FAB
            topEdgeZone.visibility = if (!urlBarVisible) View.VISIBLE else View.GONE
            btnToggle.visibility   = View.GONE
        } else {
            topEdgeZone.visibility = View.GONE
            // Restore FAB based on fabBehavior
            btnToggle.visibility = View.VISIBLE
            when (fabBehavior) {
                2    -> { btnToggle.alpha = 1f; btnToggle.translationY = 0f; toggleVisible = true }
                else -> {}
            }
        }
    }

    // ══════════════════════════════════════════════════════════════════
    // Tabs
    // ══════════════════════════════════════════════════════════════════

    private fun createTab(incognito: Boolean = false): BrowserTab {
        val wv = ScrollAwareWebView(this)
        configureWebView(wv, incognito)
        val tab = BrowserTab(tabIdCounter++, wv, incognito)
        tabs.add(tab)
        return tab
    }

    private fun switchToTab(index: Int, animate: Boolean = true) {
        if (tabs.isEmpty()) return
        val ni = index.coerceIn(0, tabs.lastIndex)
        if (activeTabIndex < tabs.size) {
            val old = tabs[activeTabIndex].webView
            if (old.parent != null) {
                if (animate) old.animate().alpha(0f).translationX(-40f * resources.displayMetrics.density)
                    .setDuration(140).setInterpolator(AccelerateInterpolator())
                    .withEndAction { webViewContainer.removeView(old) }.start()
                else webViewContainer.removeView(old)
            }
        }
        activeTabIndex = ni
        val nw = tabs[ni].webView
        if (nw.parent == null) webViewContainer.addView(nw, 0,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        if (animate) {
            nw.alpha = 0f; nw.translationX = 40f * resources.displayMetrics.density
            nw.animate().alpha(1f).translationX(0f).setDuration(160).setInterpolator(DecelerateInterpolator()).start()
        } else { nw.alpha = 1f; nw.translationX = 0f }

        ViewCompat.setOnApplyWindowInsetsListener(nw) { v, ins ->
            v.setPadding(0, 0, 0, ins.getInsets(WindowInsetsCompat.Type.ime()).bottom); ins }

        updateTabCount()
        buildGestureDetector()
        syncNavButtons()
        updateIncognitoBar()
        updateBookmarkIcon()
    }

    private fun closeTab(i: Int) {
        val tab = tabs[i]
        // Remember for reopen
        if (tab.url.isNotBlank() && !tab.url.startsWith("data:")) {
            closedTabs.addFirst(tab.url to tab.title)
            if (closedTabs.size > 10) closedTabs.removeLast()
        }
        if (tab.isIncognito) {
            // Clear cookies for incognito (best-effort)
            CookieManager.getInstance().removeAllCookies(null)
        }
        if (tabs.size == 1) {
            webViewContainer.removeView(tabs[0].webView); tabs[0].webView.destroy()
            tabs.clear(); activeTabIndex = 0
            val t = createTab(); switchToTab(0, false); loadHomePage(t.webView); return
        }
        webViewContainer.removeView(tab.webView); tab.webView.destroy()
        tabs.removeAt(i)
        switchToTab(if (activeTabIndex >= tabs.size) tabs.lastIndex else activeTabIndex, false)
    }

    private fun openNewTab(url: String? = null, incognito: Boolean = false) {
        val t = createTab(incognito); switchToTab(tabs.lastIndex)
        if (url != null) t.webView.loadUrl(url) else loadHomePage(t.webView)
    }

    private fun updateTabCount() { btnTabCount.text = tabs.size.toString() }

    private fun updateIncognitoBar() {
        incognitoBar.visibility = if (activeTab.isIncognito) View.VISIBLE else View.GONE
    }

    private fun updateBookmarkIcon() {
        val url = activeTab.url
        val isBookmarked = url.isNotBlank() && !isOnHomePage && bookmarkMgr.isBookmarked(url)
        btnBookmark.alpha = if (isBookmarked) 1f else 0.5f
        btnBookmark.setImageResource(if (isBookmarked) R.drawable.ic_star_filled else R.drawable.ic_star)
    }

    // ── Grid tab switcher ──────────────────────────────────────────────

    private fun showGridTabSwitcher() {
        val dp   = resources.displayMetrics.density
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((12 * dp).toInt(), (8 * dp).toInt(), (12 * dp).toInt(), (12 * dp).toInt())
        }

        // Action row: New Tab | New Incognito | Reopen
        val actionRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, (10 * dp).toInt())
        }
        fun actionBtn(text: String, color: String, fn: () -> Unit): TextView =
            TextView(this).apply {
                this.text = text; textSize = 13f; setTextColor(Color.parseColor(color))
                setPadding((10 * dp).toInt(), (8 * dp).toInt(), (10 * dp).toInt(), (8 * dp).toInt())
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                gravity = Gravity.CENTER; setOnClickListener { fn(); tabDialog?.dismiss() }
            }
        actionRow.addView(actionBtn("+ New Tab", "#4FC3F7") { openNewTab() })
        actionRow.addView(actionBtn("+ Incognito", "#CE93D8") { openNewTab(incognito = true) })
        if (closedTabs.isNotEmpty())
            actionRow.addView(actionBtn("↩ Reopen", "#80CBC4") {
                val (url, _) = closedTabs.removeFirst(); openNewTab(url)
            })
        root.addView(actionRow)

        // Divider
        root.addView(View(this).apply {
            setBackgroundColor(Color.parseColor("#22FFFFFF"))
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1)
        })

        // Grid of tab cards (2 columns)
        val grid = android.widget.GridLayout(this).apply {
            columnCount = 2
            setPadding(0, (8 * dp).toInt(), 0, 0)
        }

        tabs.forEachIndexed { i, tab ->
            val isActive = i == activeTabIndex
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                val margin = (5 * dp).toInt()
                val params = android.widget.GridLayout.LayoutParams().apply {
                    width = 0; columnSpec = android.widget.GridLayout.spec(android.widget.GridLayout.UNDEFINED, 1f)
                    setMargins(margin, margin, margin, margin)
                }
                layoutParams = params
                setBackgroundColor(Color.parseColor(if (isActive) "#1A4FC3F7" else "#0DFFFFFF"))
                setPadding((10 * dp).toInt(), (10 * dp).toInt(), (10 * dp).toInt(), (10 * dp).toInt())
                elevation = if (isActive) (4 * dp) else (1 * dp)
                isClickable = true; isFocusable = true
            }

            // Header row: icon + close btn
            val headerRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            // Site initial circle
            val initial = tab.title.firstOrNull()?.uppercaseChar() ?: 'N'
            val color = if (tab.isIncognito) "#7B1FA2" else listOf("#1565C0","#2E7D32","#B71C1C","#E65100","#4A148C","#006064","#37474F")[(tab.id % 7)]
            val circle = TextView(this).apply {
                text = if (tab.isIncognito) "🕵" else initial.toString()
                textSize = if (tab.isIncognito) 12f else 13f; setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                val sz = (28 * dp).toInt()
                layoutParams = LinearLayout.LayoutParams(sz, sz).also { it.marginEnd = (6 * dp).toInt() }
                setBackgroundColor(Color.parseColor(color))
                // Round via clipToOutline would need custom view; skip for simplicity
            }
            headerRow.addView(circle)
            headerRow.addView(View(this).apply { layoutParams = LinearLayout.LayoutParams(0, 1, 1f) })
            val closeX = TextView(this).apply {
                text = "✕"; textSize = 13f; setTextColor(Color.parseColor("#66FFFFFF"))
                setPadding((6 * dp).toInt(), (4 * dp).toInt(), (2 * dp).toInt(), (4 * dp).toInt())
                val ci = i
                setOnClickListener { closeTab(ci); tabDialog?.dismiss() }
            }
            headerRow.addView(closeX)
            card.addView(headerRow)

            // Title
            card.addView(TextView(this).apply {
                text = tab.title.ifBlank { "New Tab" }
                setTextColor(if (isActive) Color.parseColor("#4FC3F7") else Color.WHITE)
                textSize = 11f; maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END
                setPadding(0, (4 * dp).toInt(), 0, (2 * dp).toInt())
            })

            // URL
            card.addView(TextView(this).apply {
                text = tab.url.ifBlank { "Home" }
                setTextColor(Color.parseColor("#55FFFFFF"))
                textSize = 9f; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
            })

            val ci = i
            card.setOnClickListener { switchToTab(ci); tabDialog?.dismiss() }
            grid.addView(card)
        }

        root.addView(grid)

        // Close all
        val closeAll = TextView(this).apply {
            text = "Close All Tabs"; textSize = 13f; setTextColor(Color.parseColor("#EF9A9A"))
            gravity = Gravity.CENTER
            setPadding(0, (14 * dp).toInt(), 0, (4 * dp).toInt())
            setOnClickListener {
                tabDialog?.dismiss()
                AlertDialog.Builder(this@MainActivity).setTitle("Close all tabs?")
                    .setPositiveButton("Close All") { _, _ ->
                        val count = tabs.size
                        repeat(count) { closeTab(0) }
                    }.setNegativeButton("Cancel", null).show().styleDialog()
            }
        }
        root.addView(closeAll)

        val sv = ScrollView(this).also { it.addView(root) }
        tabDialog = AlertDialog.Builder(this)
            .setTitle("Tabs (${tabs.size})")
            .setView(sv)
            .setNegativeButton("Done", null)
            .show().also { it.styleDialog() }
    }

    // ══════════════════════════════════════════════════════════════════
    // Static views — binding
    // ══════════════════════════════════════════════════════════════════

    @SuppressLint("ClickableViewAccessibility")
    private fun bindStaticViews() {
        webViewContainer = findViewById(R.id.webViewContainer)
        urlBar           = findViewById(R.id.urlBar)
        urlInput         = findViewById(R.id.urlInput)
        btnBack          = findViewById(R.id.btnBack)
        btnForward       = findViewById(R.id.btnForward)
        btnRefresh       = findViewById(R.id.btnRefresh)
        btnBookmark      = findViewById(R.id.btnBookmark)
        btnTabCount      = findViewById(R.id.btnTabCount)
        btnOverflow      = findViewById(R.id.btnOverflow)
        btnToggle        = findViewById(R.id.btnToggleUrlBar)
        pageProgress     = findViewById(R.id.pageProgress)
        incognitoBar     = findViewById(R.id.incognitoBar)
        topEdgeZone      = findViewById(R.id.topEdgeZone)
        findBar          = findViewById(R.id.findBar)
        findInput        = findViewById(R.id.findInput)
        findCount        = findViewById(R.id.findCount)

        // Debug overlay
        debugOverlay = TextView(this).apply {
            textSize = 9f; setTextColor(0xFFFFFF00.toInt()); setBackgroundColor(0xCC000000.toInt())
            setPadding(8, 8, 8, 8); elevation = 50f; visibility = View.GONE
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM)
        }
        (findViewById<FrameLayout>(android.R.id.content)).addView(debugOverlay)

        urlBar.post { urlBar.translationY = -urlBar.height.toFloat() }

        // URL bar buttons
        btnBack.setOnClickListener         { if (webView.canGoBack())    webView.goBack() }
        btnForward.setOnClickListener      { if (webView.canGoForward()) webView.goForward() }
        btnRefresh.setOnClickListener      { if (isOnHomePage) loadHomePage(webView) else webView.reload() }
        btnRefresh.setOnLongClickListener  {
            if (!isOnHomePage) { webView.clearCache(true); webView.reload()
                Toast.makeText(this, "Hard reloaded", Toast.LENGTH_SHORT).show() }; true }
        btnBookmark.setOnClickListener     { handleBookmarkTap() }
        btnTabCount.setOnClickListener     { showGridTabSwitcher() }
        btnOverflow.setOnClickListener     { showMenu() }
        btnToggle.setOnClickListener       { toggleUrlBar() }

        // URL input
        urlInput.setOnEditorActionListener { _, id, ev ->
            val ok = id in listOf(EditorInfo.IME_ACTION_GO, EditorInfo.IME_ACTION_SEARCH,
                EditorInfo.IME_ACTION_DONE, EditorInfo.IME_ACTION_UNSPECIFIED) ||
                (ev?.keyCode == KeyEvent.KEYCODE_ENTER && ev.action == KeyEvent.ACTION_DOWN)
            if (ok) { navigateTo(urlInput.text.toString()); true } else false
        }
        urlInput.setOnKeyListener { _, k, ev ->
            if (k == KeyEvent.KEYCODE_ENTER && ev.action == KeyEvent.ACTION_DOWN)
                { navigateTo(urlInput.text.toString()); true } else false
        }

        // Top edge zone (hidden URL bar mode)
        topEdgeZone.setOnClickListener {
            showUrlBar()
            // hide zone while bar is visible
            topEdgeZone.visibility = View.GONE
        }

        // Find bar
        val btnFindPrev  = findViewById<ImageButton>(R.id.btnFindPrev)
        val btnFindNext  = findViewById<ImageButton>(R.id.btnFindNext)
        val btnFindClose = findViewById<ImageButton>(R.id.btnFindClose)

        findInput.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                val q = s?.toString() ?: ""
                if (q.isBlank()) { webView.clearMatches(); findCount.text = "" }
                else webView.findAllAsync(q)
            }
        })
        btnFindPrev.setOnClickListener  { webView.findNext(false) }
        btnFindNext.setOnClickListener  { webView.findNext(true) }
        btnFindClose.setOnClickListener { hideFindBar() }
    }

    // ══════════════════════════════════════════════════════════════════
    // Overflow / more menu
    // ══════════════════════════════════════════════════════════════════

    private fun showMenu() {
        val dp   = resources.displayMetrics.density
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((4 * dp).toInt(), (8 * dp).toInt(), (4 * dp).toInt(), (8 * dp).toInt())
        }
        var dialog: AlertDialog? = null

        fun row(icon: String, label: String, sub: String = "", fn: () -> Unit) {
            val r = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding((16*dp).toInt(), (11*dp).toInt(), (16*dp).toInt(), (11*dp).toInt())
                isClickable = true; isFocusable = true
                val rv = android.util.TypedValue()
                theme.resolveAttribute(android.R.attr.selectableItemBackground, rv, true)
                if (rv.resourceId != 0) setBackgroundResource(rv.resourceId)
                setOnClickListener { dialog?.dismiss(); fn() }
            }
            r.addView(TextView(this).apply {
                text = icon; textSize = 16f; gravity = Gravity.CENTER
                val sz = (32*dp).toInt(); layoutParams = LinearLayout.LayoutParams(sz,sz).apply{ marginEnd=(14*dp).toInt() }
            })
            val info = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            info.addView(TextView(this).apply { text = label; textSize = 14f; setTextColor(Color.WHITE) })
            if (sub.isNotBlank()) info.addView(TextView(this).apply {
                text = sub; textSize = 11f; setTextColor(Color.parseColor("#66FFFFFF"))
                setPadding(0,(2*dp).toInt(),0,0)
            })
            r.addView(info)
            root.addView(r)
        }
        fun div() = root.addView(View(this).apply {
            setBackgroundColor(Color.parseColor("#1FFFFFFF"))
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1) })

        val desktopLabel = if (activeTab.isDesktopMode) "Switch to Mobile Site" else "Request Desktop Site"
        val readerLabel  = "Reader Mode"
        row("🔗", "Copy URL", activeTab.url.take(40)) { copyToClipboard(activeTab.url, "URL") }
        row("📋", "Copy Title") { copyToClipboard(activeTab.title, "Page title") }
        row("↗️", "Share Page") { sharePage() }
        row("🌐", "Open in Browser") { openInExternalBrowser() }
        row("⬛", "QR Code") { showQrCode() }
        div()
        row("🔍", "Find in Page") { showFindBar() }
        row("📖", readerLabel) { toggleReaderMode() }
        row("🖥️", desktopLabel) { toggleDesktopMode() }
        div()
        row("🕵️", "New Incognito Tab") { openNewTab(incognito = true) }
        row("🕐", "History") { showHistoryDialog() }
        row("🔖", "Bookmarks") { showBookmarksDialog() }
        div()
        row("💾", "Save Page Offline") { if (!isOnHomePage) savePageOffline() }
        row("📂", "Saved Pages") { showSavedPages() }
        row("⚙️", "Settings") { showSettingsDialog() }

        dialog = AlertDialog.Builder(this)
            .setView(ScrollView(this).also { it.addView(root) })
            .setNegativeButton("Close", null)
            .show().styleDialog()
    }

    // ══════════════════════════════════════════════════════════════════
    // Gesture detector — rebuilt per tab switch
    // ══════════════════════════════════════════════════════════════════

    @SuppressLint("ClickableViewAccessibility")
    private fun buildGestureDetector() {
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (urlBarVisible) { hideUrlBar(); return true }
                if (!urlBarVisible) { showUrlBar(); return true }
                return false
            }
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (!hiddenUrlBarMode && fabBehavior == 1 && toggleVisible && !urlBarVisible) {
                    hideToggleFab(); return true
                }
                return false
            }
        })
        gestureDetector = gd

        val edgePx = 72f * resources.displayMetrics.density

        webView.setOnTouchListener { v, ev ->
            if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
                webInputFocused = true
                webView.removeCallbacks(resetWebInputFocused)
                webView.postDelayed(resetWebInputFocused, 600)
            }
            gd.onTouchEvent(ev)

            if (swipeNavEnabled && !urlBarVisible) {
                when (ev.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        if (!swipeActive) {
                            val x = ev.x; val w = v.width.toFloat()
                            when {
                                x < edgePx && webView.canGoBack()        -> { vibrate(30); startSwipeDrag(x, true) }
                                x > w - edgePx && webView.canGoForward() -> { vibrate(30); startSwipeDrag(x, false) }
                            }
                        }
                    }
                    MotionEvent.ACTION_MOVE  -> { if (swipeActive) { updateSwipeDrag(ev.x); return@setOnTouchListener true } }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        if (swipeActive) { endSwipeDrag(ev.x, v.width); return@setOnTouchListener true }
                    }
                }
            }
            false
        }

        webView.onPullToRefresh = {
            runOnUiThread {
                if (!isOnHomePage) {
                    vibrate(30)
                    pageProgress.visibility = View.VISIBLE
                    webView.reload()
                    Toast.makeText(this, "Refreshing…", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    // ══════════════════════════════════════════════════════════════════
    // Swipe navigation
    // ══════════════════════════════════════════════════════════════════

    private fun startSwipeDrag(startX: Float, goBack: Boolean) {
        if (swipeActive) return
        val wv = webView
        try {
            val bmp = Bitmap.createBitmap(wv.width.coerceAtLeast(1), wv.height.coerceAtLeast(1), Bitmap.Config.RGB_565)
            wv.draw(Canvas(bmp))
            val hist    = wv.copyBackForwardList()
            val tgtIdx  = hist.currentIndex + (if (goBack) -1 else 1)
            val tgtItem = if (tgtIdx in 0 until hist.size) hist.getItemAtIndex(tgtIdx) else null
            val tgtTitle = tgtItem?.title?.takeIf { it.isNotBlank() } ?: if (goBack) "Previous" else "Next"
            val tgtUrl   = tgtItem?.url ?: ""
            val dp = resources.displayMetrics.density

            val destPanel = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
                setBackgroundColor(Color.parseColor("#0F172A"))
                layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
            }
            destPanel.addView(TextView(this).apply {
                text = if (goBack) "← Back" else "Forward →"
                setTextColor(Color.parseColor("#4FC3F7")); textSize = 12f; gravity = Gravity.CENTER
                setPadding(0, 0, 0, (10 * dp).toInt())
            })
            destPanel.addView(TextView(this).apply {
                text = tgtTitle; setTextColor(Color.WHITE); textSize = 17f; gravity = Gravity.CENTER
                setPadding((24 * dp).toInt(), 0, (24 * dp).toInt(), (6 * dp).toInt())
                maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END
            })
            if (tgtUrl.isNotBlank()) destPanel.addView(TextView(this).apply {
                text = tgtUrl; setTextColor(Color.parseColor("#6B7280")); textSize = 11f; gravity = Gravity.CENTER
                setPadding((24 * dp).toInt(), 0, (24 * dp).toInt(), 0)
                maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
            })

            val overlay = ImageView(this).apply {
                setImageBitmap(bmp)
                layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
                elevation = 10f; translationX = 0f
            }
            webViewContainer.addView(destPanel); webViewContainer.addView(overlay)
            swipeDestPanel = destPanel; swipeOverlay = overlay; swipeSnapBmp = bmp
            swipeStartX = startX; swipeGoBack = goBack; swipeActive = true
        } catch (_: Exception) { swipeActive = false }
    }

    private fun updateSwipeDrag(currentX: Float) {
        val overlay = swipeOverlay ?: return
        val delta   = currentX - swipeStartX
        val correct = if (swipeGoBack) delta >= 0f else delta <= 0f
        overlay.translationX = if (correct) delta else delta * 0.08f
    }

    private fun endSwipeDrag(currentX: Float, viewWidth: Int) {
        val overlay   = swipeOverlay ?: run { cleanSwipeDrag(); return }
        val destPanel = swipeDestPanel; val bmp = swipeSnapBmp; val goBack = swipeGoBack
        val delta     = currentX - swipeStartX; val threshold = viewWidth * 0.28f
        val committed = if (goBack) delta > threshold else delta < -threshold
        if (committed) {
            vibrate(40)
            val toX = viewWidth.toFloat() * (if (goBack) 1.2f else -1.2f)
            overlay.animate().translationX(toX).setDuration(175).setInterpolator(DecelerateInterpolator(1.6f))
                .withEndAction {
                    if (goBack) webView.goBack() else webView.goForward()
                    webViewContainer.removeView(overlay); destPanel?.let { webViewContainer.removeView(it) }
                    bmp?.recycle(); swipeOverlay=null; swipeDestPanel=null; swipeSnapBmp=null; swipeActive=false
                }.start()
        } else {
            overlay.animate().translationX(0f).setDuration(240).setInterpolator(DecelerateInterpolator(2.5f))
                .withEndAction {
                    webViewContainer.removeView(overlay); destPanel?.let { webViewContainer.removeView(it) }
                    bmp?.recycle(); swipeOverlay=null; swipeDestPanel=null; swipeSnapBmp=null; swipeActive=false
                }.start()
        }
    }

    private fun cleanSwipeDrag() {
        swipeOverlay?.let { webViewContainer.removeView(it) }
        swipeDestPanel?.let { webViewContainer.removeView(it) }
        swipeSnapBmp?.recycle()
        swipeOverlay=null; swipeDestPanel=null; swipeSnapBmp=null; swipeActive=false
    }

    // ══════════════════════════════════════════════════════════════════
    // WebView configuration
    // ══════════════════════════════════════════════════════════════════

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView(wv: ScrollAwareWebView, incognito: Boolean = false) {
        wv.isFocusable = true; wv.isFocusableInTouchMode = true

        wv.settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true; databaseEnabled = true
            setSupportZoom(true); builtInZoomControls = true; displayZoomControls = false
            userAgentString = MOBILE_UA; loadWithOverviewMode = true; useWideViewPort = true
            allowFileAccess = true
            @Suppress("DEPRECATION") mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            cacheMode = if (incognito) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT
        }

        if (incognito) {
            wv.settings.saveFormData = false
            wv.settings.savePassword = false
        }

        CookieManager.getInstance().setAcceptThirdPartyCookies(wv, !incognito)
        wv.addJavascriptInterface(WebKeyboardBridge(wv), "Android")
        wv.addJavascriptInterface(SpeedDialBridge(), "SpeedDial")
        wv.addJavascriptInterface(SearchBridge(), "NativeSearch")
        wv.onWebInputFocused = { showKeyboardFor(wv) }
        wv.onDebugEvent = { msg -> dbg(msg) }

        wv.onScrollCallback = { dy ->
            val now = System.currentTimeMillis()
            if (now - lastScrollMs > 40) {
                lastScrollMs = now
                if (scrollHideEnabled && !hiddenUrlBarMode) {
                    if (!urlBarVisible && !hiddenUrlBarMode && fabBehavior == 0)
                        if (dy > 8) hideToggleFab() else if (dy < -8) showToggleFab(true)
                }
                if (scrollHideEnabled && urlBarVisible) {
                    if (dy > 10) hideUrlBar()
                }
                if (scrollHideEnabled && !urlBarVisible && dy < -10) {
                    showUrlBar()
                }
            }
        }

        // Download listener
        wv.setDownloadListener { url, ua, contentDisposition, mimeType, _ ->
            try {
                val filename = URLUtil.guessFileName(url, contentDisposition, mimeType)
                val req = DownloadManager.Request(Uri.parse(url)).apply {
                    setMimeType(mimeType)
                    addRequestHeader("User-Agent", ua)
                    addRequestHeader("Cookie", CookieManager.getInstance().getCookie(url) ?: "")
                    setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, filename)
                    setTitle(filename); setDescription("Downloading via Browser")
                }
                (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
                vibrate(50)
                Toast.makeText(this, "Downloading $filename…", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Download failed: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }

        wv.webViewClient = object : WebViewClient() {
            override fun onPageStarted(v: WebView, url: String?, fav: Bitmap?) {
                pageProgress.visibility = View.VISIBLE; pageProgress.progress = 0
                val tab = tabs.find { it.webView === v }
                if (url == null || url.startsWith("data:") || url.startsWith("https://home.local")) {
                    isOnHomePage = true; urlInput.setText("Home")
                    tab?.url = ""; tab?.title = "Home"
                } else {
                    isOnHomePage = false
                    currentHost = try { java.net.URI(url).host?.removePrefix("www.") } catch (_: Exception) { null }
                    urlInput.setText(url); tab?.url = url
                }
                syncNavButtons(); updateBookmarkIcon()
            }

            override fun onPageFinished(v: WebView, url: String?) {
                pageProgress.visibility = View.GONE
                val tab = tabs.find { it.webView === v }
                val tabTitle = v.title ?: ""
                tab?.title = tabTitle; tab?.url = url ?: ""

                // Record history (skip incognito)
                if (tab?.isIncognito == false && url != null && !url.startsWith("data:"))
                    historyMgr.record(url, tabTitle)

                // Inject keyboard detection script
                v.evaluateJavascript("""(function(){if(window.__kbl)return;window.__kbl=true;
                  function isEd(el){if(!el||!el.tagName)return false;var t=el.tagName.toUpperCase();
                    if(t==='INPUT'){var ty=(el.getAttribute('type')||'text').toLowerCase();
                      return['checkbox','radio','submit','button','file','image','reset','hidden','range','color'].indexOf(ty)<0;}
                    if(t==='TEXTAREA')return true;
                    var r=(el.getAttribute('role')||'').toLowerCase();
                    if(r==='textbox'||r==='searchbox'||r==='combobox')return true;
                    var c=el.getAttribute('contenteditable');return c!==null&&c!=='false'||el.isContentEditable;}
                  function chk(e){var el=e.target;for(var i=0;i<5&&el;i++,el=el.parentElement){
                    if(isEd(el)){if(typeof Android!=='undefined')Android.onInputFocused();return;}}}
                  document.addEventListener('focusin',chk,true);})();""", null)

                if (url == null || url.startsWith("data:") || url.startsWith("https://home.local"))
                    { isOnHomePage = true; urlInput.setText("Home") }
                else isOnHomePage = false
                syncNavButtons(); updateBookmarkIcon()
            }

            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                if (adBlockEnabled && AdBlocker.shouldBlockNavigation(r.url?.host)) {
                    Toast.makeText(this@MainActivity, "🛡 Blocked redirect", Toast.LENGTH_SHORT).show()
                    return true
                }
                return false
            }

            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): android.webkit.WebResourceResponse? {
                if (adBlockEnabled && AdBlocker.shouldBlock(r, currentHost)) return AdBlocker.emptyResponse()
                if (dataSaverLevel > 0 && AdBlocker.shouldBlockForDataSaver(r, currentHost, dataSaverLevel)) return AdBlocker.emptyResponse()
                return null
            }
        }

        // Find result listener
        wv.setFindListener { activeMatchOrdinal, numberOfMatches, _ ->
            runOnUiThread {
                findCount.text = if (numberOfMatches > 0) "${activeMatchOrdinal + 1}/$numberOfMatches" else "0/0"
            }
        }

        wv.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView, p: Int) {
                if (p < 100) { pageProgress.visibility = View.VISIBLE; pageProgress.progress = p }
                else pageProgress.postDelayed({ pageProgress.visibility = View.GONE }, 200)
            }
            override fun onReceivedTitle(v: WebView, t: String?) { tabs.find { it.webView === v }?.title = t ?: "" }
            override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message?): Boolean {
                if (adBlockEnabled && !isUserGesture) return false
                if (isUserGesture && resultMsg != null) {
                    val t = createTab(); switchToTab(tabs.lastIndex)
                    val transport = resultMsg.obj as? WebView.WebViewTransport
                    transport?.webView = t.webView; resultMsg.sendToTarget(); return true
                }
                return false
            }
            override fun onShowFileChooser(v: WebView, callback: ValueCallback<Array<Uri>>, params: FileChooserParams): Boolean {
                fileUploadCallback?.onReceiveValue(null); fileUploadCallback = callback
                val types = params.acceptTypes?.filter { it.isNotBlank() }?.toTypedArray()?.takeIf { it.isNotEmpty() } ?: arrayOf("*/*")
                try { filePickerLauncher.launch(types) } catch (_: Exception) { fileUploadCallback = null; return false }
                return true
            }
        }
    }

    // ══════════════════════════════════════════════════════════════════
    // JS Bridges
    // ══════════════════════════════════════════════════════════════════

    inner class WebKeyboardBridge(private val wv: ScrollAwareWebView) {
        @JavascriptInterface
        fun onInputFocused() = runOnUiThread { webInputFocused = true; wv.removeCallbacks(resetWebInputFocused)
            wv.postDelayed({ showKeyboardFor(wv) }, 200) }
    }

    inner class SpeedDialBridge {
        @JavascriptInterface fun get()  = prefs.getString("speed_dial", null) ?: DEFAULT_SPEED_DIAL
        @JavascriptInterface fun save(json: String) = prefs.edit().putString("speed_dial", json).apply()
        @JavascriptInterface fun openAddDialog() = runOnUiThread { showNativeAddSpeedDialDialog() }
    }

    inner class SearchBridge {
        @JavascriptInterface fun openSearch() = runOnUiThread { showUrlBar() }
    }

    // ══════════════════════════════════════════════════════════════════
    // Bookmarks
    // ══════════════════════════════════════════════════════════════════

    private fun handleBookmarkTap() {
        val url = activeTab.url
        if (url.isBlank() || isOnHomePage) { showBookmarksDialog(); return }
        if (bookmarkMgr.isBookmarked(url)) {
            AlertDialog.Builder(this)
                .setTitle("Bookmark saved")
                .setMessage(activeTab.title.take(60))
                .setPositiveButton("Edit")  { _, _ -> showEditBookmarkDialog(url) }
                .setNegativeButton("Remove") { _, _ -> bookmarkMgr.remove(url); updateBookmarkIcon()
                    Toast.makeText(this, "Removed bookmark", Toast.LENGTH_SHORT).show() }
                .setNeutralButton("Done", null)
                .show().styleDialog()
        } else {
            bookmarkMgr.add(url, activeTab.title)
            updateBookmarkIcon()
            vibrate(30)
            Toast.makeText(this, "Bookmarked: ${activeTab.title.take(30)}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showEditBookmarkDialog(url: String) {
        val bm   = bookmarkMgr.getAll().find { it.url == url } ?: return
        val dp   = resources.displayMetrics.density
        val cont = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((20*dp).toInt(), (12*dp).toInt(), (20*dp).toInt(), (4*dp).toInt())
        }
        val titleEt = EditText(this).apply { setText(bm.title); setSingleLine(true) }
        cont.addView(TextView(this).apply { text = "Name"; textSize = 11f; setTextColor(Color.parseColor("#99FFFFFF")) })
        cont.addView(titleEt)
        AlertDialog.Builder(this).setTitle("Edit Bookmark").setView(cont)
            .setPositiveButton("Save") { _, _ ->
                bookmarkMgr.remove(url); bookmarkMgr.add(url, titleEt.text.toString().ifBlank { bm.title })
                updateBookmarkIcon()
            }
            .setNegativeButton("Cancel", null).show().styleDialog()
    }

    private fun showBookmarksDialog() {
        val dp   = resources.displayMetrics.density
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, (4*dp).toInt(), 0, (8*dp).toInt())
        }

        // Search field
        val searchEt = EditText(this).apply {
            hint = "Search bookmarks…"; textSize = 14f; setSingleLine(true)
            setHintTextColor(Color.parseColor("#66FFFFFF")); setTextColor(Color.WHITE)
            setPadding((16*dp).toInt(), (10*dp).toInt(), (16*dp).toInt(), (10*dp).toInt())
            setBackgroundColor(Color.parseColor("#0DFFFFFF"))
        }
        root.addView(searchEt)

        val listContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        fun buildList(query: String = "") {
            listContainer.removeAllViews()
            val items = bookmarkMgr.search(query)
            if (items.isEmpty()) {
                listContainer.addView(TextView(this).apply {
                    text = if (query.isBlank()) "No bookmarks yet.\nTap ★ to bookmark a page." else "No results"
                    setTextColor(Color.parseColor("#66FFFFFF")); textSize = 13f; gravity = Gravity.CENTER
                    setPadding((16*dp).toInt(), (24*dp).toInt(), (16*dp).toInt(), (24*dp).toInt())
                }); return
            }
            items.forEach { bm ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                    setPadding((16*dp).toInt(), (11*dp).toInt(), (8*dp).toInt(), (11*dp).toInt())
                    isClickable = true; isFocusable = true
                    val rv = android.util.TypedValue(); theme.resolveAttribute(android.R.attr.selectableItemBackground, rv, true)
                    if (rv.resourceId != 0) setBackgroundResource(rv.resourceId)
                }
                val info = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }
                info.addView(TextView(this).apply { text = bm.title; setTextColor(Color.WHITE); textSize = 13f; maxLines = 1
                    ellipsize = android.text.TextUtils.TruncateAt.END })
                info.addView(TextView(this).apply { text = bm.url; setTextColor(Color.parseColor("#55FFFFFF")); textSize = 10f
                    maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.MIDDLE; setPadding(0,(2*dp).toInt(),0,0) })
                val del = TextView(this).apply { text = "✕"; textSize = 14f; setTextColor(Color.parseColor("#55FFFFFF"))
                    setPadding((14*dp).toInt(), (8*dp).toInt(), (8*dp).toInt(), (8*dp).toInt()) }
                row.addView(info); row.addView(del)
                val url = bm.url
                row.setOnClickListener {
                    bmDialog?.dismiss()
                    navigateTo(url)
                }
                del.setOnClickListener { bookmarkMgr.remove(url); buildList(searchEt.text.toString()); updateBookmarkIcon() }
                listContainer.addView(row)
                listContainer.addView(View(this).apply {
                    setBackgroundColor(Color.parseColor("#15FFFFFF"))
                    layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1) })
            }
        }

        buildList()
        searchEt.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) { buildList(s?.toString() ?: "") }
        })

        root.addView(listContainer)

        var bmDialog: AlertDialog? = null
        bmDialog = AlertDialog.Builder(this)
            .setTitle("Bookmarks")
            .setView(ScrollView(this).also { it.addView(root) })
            .setNegativeButton("Close", null)
            .show().styleDialog()
    }

    // ══════════════════════════════════════════════════════════════════
    // History
    // ══════════════════════════════════════════════════════════════════

    private fun showHistoryDialog() {
        val dp   = resources.displayMetrics.density
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, (4*dp).toInt(), 0, (8*dp).toInt())
        }

        val searchEt = EditText(this).apply {
            hint = "Search history…"; textSize = 14f; setSingleLine(true)
            setHintTextColor(Color.parseColor("#66FFFFFF")); setTextColor(Color.WHITE)
            setPadding((16*dp).toInt(), (10*dp).toInt(), (16*dp).toInt(), (10*dp).toInt())
            setBackgroundColor(Color.parseColor("#0DFFFFFF"))
        }
        root.addView(searchEt)

        // Clear all button
        val clearBtn = TextView(this).apply {
            text = "Clear All History"; textSize = 12f; setTextColor(Color.parseColor("#EF9A9A"))
            gravity = Gravity.END; setPadding((16*dp).toInt(), (8*dp).toInt(), (16*dp).toInt(), (4*dp).toInt())
        }
        root.addView(clearBtn)

        val listContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        var histDialog: AlertDialog? = null

        fun buildList(query: String = "") {
            listContainer.removeAllViews()
            val groups = if (query.isBlank()) historyMgr.getGrouped()
                         else listOf("Results" to historyMgr.search(query))

            if (groups.all { it.second.isEmpty() }) {
                listContainer.addView(TextView(this).apply {
                    text = "No history"
                    setTextColor(Color.parseColor("#66FFFFFF")); textSize = 13f; gravity = Gravity.CENTER
                    setPadding((16*dp).toInt(), (24*dp).toInt(), (16*dp).toInt(), (24*dp).toInt())
                }); return
            }

            val fmt = SimpleDateFormat("HH:mm  dd MMM", Locale.getDefault())
            groups.forEach { (groupName, entries) ->
                if (entries.isEmpty()) return@forEach
                listContainer.addView(TextView(this).apply {
                    text = groupName; textSize = 11f; setTextColor(Color.parseColor("#4FC3F7"))
                    setPadding((16*dp).toInt(), (12*dp).toInt(), (16*dp).toInt(), (4*dp).toInt())
                    setTypeface(null, android.graphics.Typeface.BOLD)
                })
                entries.forEach { entry ->
                    val row = LinearLayout(this).apply {
                        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                        setPadding((16*dp).toInt(), (10*dp).toInt(), (8*dp).toInt(), (10*dp).toInt())
                        isClickable = true; isFocusable = true
                        val rv = android.util.TypedValue(); theme.resolveAttribute(android.R.attr.selectableItemBackground, rv, true)
                        if (rv.resourceId != 0) setBackgroundResource(rv.resourceId)
                    }
                    val info = LinearLayout(this).apply {
                        orientation = LinearLayout.VERTICAL
                        layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                    }
                    info.addView(TextView(this).apply { text = entry.title; setTextColor(Color.WHITE); textSize = 12f
                        maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END })
                    info.addView(TextView(this).apply {
                        text = "${fmt.format(Date(entry.timestamp))}  •  ${entry.url}"
                        setTextColor(Color.parseColor("#55FFFFFF")); textSize = 10f
                        maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.MIDDLE; setPadding(0,(2*dp).toInt(),0,0) })
                    val del = TextView(this).apply { text = "✕"; textSize = 13f; setTextColor(Color.parseColor("#44FFFFFF"))
                        setPadding((14*dp).toInt(), (8*dp).toInt(), (8*dp).toInt(), (8*dp).toInt()) }
                    row.addView(info); row.addView(del)
                    val url = entry.url
                    row.setOnClickListener { histDialog?.dismiss(); navigateTo(url) }
                    del.setOnClickListener { historyMgr.remove(url); buildList(searchEt.text.toString()) }
                    listContainer.addView(row)
                    listContainer.addView(View(this).apply {
                        setBackgroundColor(Color.parseColor("#10FFFFFF"))
                        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1) })
                }
            }
        }

        buildList()
        searchEt.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) { buildList(s?.toString() ?: "") }
        })
        clearBtn.setOnClickListener {
            AlertDialog.Builder(this).setTitle("Clear history?")
                .setPositiveButton("Clear") { _, _ -> historyMgr.clear(); buildList() }
                .setNegativeButton("Cancel", null).show().styleDialog()
        }

        root.addView(listContainer)

        histDialog = AlertDialog.Builder(this)
            .setTitle("History")
            .setView(ScrollView(this).also { it.addView(root) })
            .setNegativeButton("Close", null)
            .show().styleDialog()
    }

    // ══════════════════════════════════════════════════════════════════
    // Find in Page
    // ══════════════════════════════════════════════════════════════════

    private fun showFindBar() {
        if (findBar.visibility == View.VISIBLE) { findInput.requestFocus(); return }
        hideUrlBar()
        findBar.visibility = View.VISIBLE
        findBar.translationY = findBar.height.toFloat()
        findBar.animate().translationY(0f).setDuration(220).setInterpolator(DecelerateInterpolator()).start()
        findInput.setText("")
        findInput.requestFocus()
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.showSoftInput(findInput, InputMethodManager.SHOW_IMPLICIT)
    }

    private fun hideFindBar() {
        if (findBar.visibility != View.VISIBLE) return
        webView.clearMatches(); findCount.text = ""
        findBar.animate().translationY(findBar.height.toFloat()).setDuration(180)
            .setInterpolator(AccelerateInterpolator())
            .withEndAction { findBar.visibility = View.GONE }.start()
        dismissKeyboard()
    }

    // ══════════════════════════════════════════════════════════════════
    // Share / clipboard
    // ══════════════════════════════════════════════════════════════════

    private fun sharePage() {
        val url = activeTab.url
        if (url.isBlank() || isOnHomePage) { Toast.makeText(this,"Nothing to share",Toast.LENGTH_SHORT).show(); return }
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"; putExtra(Intent.EXTRA_TEXT, url); putExtra(Intent.EXTRA_SUBJECT, activeTab.title)
        }, "Share page"))
    }

    private fun openInExternalBrowser() {
        val url = activeTab.url.ifBlank { return }
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply { addCategory(Intent.CATEGORY_BROWSABLE) })
        } catch (_: Exception) { Toast.makeText(this, "No browser found", Toast.LENGTH_SHORT).show() }
    }

    private fun showQrCode() {
        val url = activeTab.url.ifBlank { return }
        // Open QR via web service in a new tab
        val qrUrl = "https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${Uri.encode(url)}"
        openNewTab(qrUrl)
    }

    private fun copyToClipboard(text: String, label: String) {
        if (text.isBlank()) return
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText(label, text))
        vibrate(30)
        Toast.makeText(this, "$label copied", Toast.LENGTH_SHORT).show()
    }

    // ══════════════════════════════════════════════════════════════════
    // Reader Mode
    // ══════════════════════════════════════════════════════════════════

    private fun toggleReaderMode() {
        if (isOnHomePage) return
        val js = """
(function(){
  if(window.__readerModeActive){
    var el=document.getElementById('__readerOverlay__');
    if(el){el.remove();window.__readerModeActive=false;}
    return;
  }
  window.__readerModeActive=true;
  var src=document.querySelector('article')||document.querySelector('[role="main"]')||
          document.querySelector('main')||document.querySelector('.post-content')||
          document.querySelector('.article-body')||document.querySelector('#content')||document.body;
  var overlay=document.createElement('div');
  overlay.id='__readerOverlay__';
  overlay.style='position:fixed;top:0;left:0;width:100%;height:100%;overflow-y:auto;z-index:2147483647;'+
    'background:#121212;color:#E0E0E0;font-family:Georgia,serif;font-size:18px;line-height:1.8;box-sizing:border-box;padding:24px 20px;';
  var closeBtn=document.createElement('div');
  closeBtn.style='position:sticky;top:0;text-align:right;margin-bottom:16px;';
  closeBtn.innerHTML='<button onclick="document.getElementById(\'__readerOverlay__\').remove();window.__readerModeActive=false;" '+
    'style="background:#1E1E1E;color:#4FC3F7;border:1px solid #333;border-radius:8px;padding:8px 16px;font-size:14px;cursor:pointer;">✕ Close Reader</button>';
  var titleEl=document.createElement('h1');
  titleEl.style='font-size:22px;color:#FFFFFF;line-height:1.4;margin-bottom:20px;border-bottom:1px solid #333;padding-bottom:16px;';
  titleEl.textContent=document.title;
  var content=document.createElement('div');
  content.innerHTML=src.innerHTML;
  content.querySelectorAll('script,style,iframe,nav,header,footer,aside,.ad,.ads,.advertisement').forEach(function(el){el.remove();});
  content.querySelectorAll('img').forEach(function(img){img.style.maxWidth='100%';img.style.height='auto';});
  content.querySelectorAll('a').forEach(function(a){a.style.color='#4FC3F7';});
  overlay.appendChild(closeBtn);overlay.appendChild(titleEl);overlay.appendChild(content);
  document.body.appendChild(overlay);
})();
""".trimIndent()
        webView.evaluateJavascript(js, null)
    }

    // ══════════════════════════════════════════════════════════════════
    // Desktop mode
    // ══════════════════════════════════════════════════════════════════

    private fun toggleDesktopMode() {
        val tab = activeTab
        tab.isDesktopMode = !tab.isDesktopMode
        webView.settings.userAgentString = if (tab.isDesktopMode) DESKTOP_UA else MOBILE_UA
        webView.settings.useWideViewPort = true
        webView.reload()
        Toast.makeText(this, if (tab.isDesktopMode) "Desktop mode on" else "Mobile mode", Toast.LENGTH_SHORT).show()
    }

    // ══════════════════════════════════════════════════════════════════
    // Speed Dial / Home
    // ══════════════════════════════════════════════════════════════════

    private fun showNativeAddSpeedDialDialog(prefillUrl: String = "", prefillName: String = "") {
        val dp = resources.displayMetrics.density
        val cont = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((20*dp).toInt(), (12*dp).toInt(), (20*dp).toInt(), (4*dp).toInt())
        }
        fun label(t: String) = TextView(this).apply { text = t; textSize = 11f; setTextColor(Color.parseColor("#99FFFFFF"))
            setPadding(0, (4*dp).toInt(), 0, (2*dp).toInt()) }
        val urlEt  = EditText(this).apply { hint = "https://example.com"; setText(prefillUrl); setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI }
        val nameEt = EditText(this).apply { hint = "Name"; setText(prefillName); setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_WORDS }
        urlEt.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                if (nameEt.text.isBlank()) try {
                    var u = s.toString(); if (!u.startsWith("http")) u = "https://$u"
                    val h = java.net.URI(u).host?.removePrefix("www.")?.split(".")?.first() ?: return
                    nameEt.setText(h.replaceFirstChar { it.uppercase() })
                } catch (_: Exception) {}
            }
        })
        cont.addView(label("URL")); cont.addView(urlEt)
        cont.addView(label("Name")); cont.addView(nameEt)
        AlertDialog.Builder(this).setTitle("Add to Speed Dial").setView(cont)
            .setPositiveButton("Add") { _, _ ->
                var url = urlEt.text.toString().trim()
                val name = nameEt.text.toString().trim().ifBlank { "Site" }
                if (url.isNotEmpty()) {
                    if (!url.startsWith("http")) url = "https://$url"
                    addToSpeedDial(url, name)
                }
            }.setNegativeButton("Cancel", null).show().styleDialog()
    }

    private fun addToSpeedDial(url: String, name: String) {
        val arr = try { JSONArray(prefs.getString("speed_dial", null) ?: DEFAULT_SPEED_DIAL) } catch (_: Exception) { JSONArray() }
        for (i in 0 until arr.length())
            if (arr.getJSONObject(i).optString("url") == url)
                { Toast.makeText(this,"Already in Speed Dial",Toast.LENGTH_SHORT).show(); return }
        arr.put(JSONObject().put("url", url).put("name", name))
        prefs.edit().putString("speed_dial", arr.toString()).apply()
        Toast.makeText(this,"Added: $name",Toast.LENGTH_SHORT).show()
        tabs.forEach { t ->
            val u = t.webView.url ?: ""
            if (u.startsWith("data:") || u.startsWith("https://home.local"))
                t.webView.evaluateJavascript("if(typeof refreshSpeedDial==='function')refreshSpeedDial()", null)
        }
    }

    // ══════════════════════════════════════════════════════════════════
    // Offline save / load
    // ══════════════════════════════════════════════════════════════════

    private fun savePageOffline() {
        if (isOnHomePage) { Toast.makeText(this,"Can't save home page",Toast.LENGTH_SHORT).show(); return }
        val dir  = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)?.also { it.mkdirs() } ?: File(filesDir, "offline").also { it.mkdirs() }
        val safe = (webView.title ?: "page").replace(Regex("[^a-zA-Z0-9 _-]"), "").trim().take(40).ifBlank { "page" }
        val file = File(dir, "${System.currentTimeMillis()}_$safe.mhtml")
        @Suppress("DEPRECATION")
        webView.saveWebArchive(file.absolutePath, false) { path ->
            runOnUiThread {
                if (path != null) Toast.makeText(this, "Saved: $safe.mhtml", Toast.LENGTH_LONG).show()
                else Toast.makeText(this, "Save failed", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun showSavedPages() {
        val dir   = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: File(filesDir, "offline")
        val files = dir.listFiles { f -> f.name.endsWith(".mhtml") || f.name.endsWith(".mht") }
            ?.sortedByDescending { it.lastModified() } ?: emptyList()
        if (files.isEmpty()) { Toast.makeText(this, "No saved pages", Toast.LENGTH_SHORT).show(); return }
        AlertDialog.Builder(this).setTitle("Saved Pages (${files.size})")
            .setItems(files.map { it.name.substringAfter("_").removeSuffix(".mhtml").removeSuffix(".mht") }.toTypedArray()) { _, i ->
                webView.loadUrl("file://${files[i].absolutePath}"); hideUrlBar()
            }
            .setNegativeButton("Close", null).show().styleDialog()
    }

    // ══════════════════════════════════════════════════════════════════
    // Home / navigation
    // ══════════════════════════════════════════════════════════════════

    private fun loadHomePage(wv: ScrollAwareWebView = webView) {
        isOnHomePage = true; urlInput.setText("Home")
        wv.loadDataWithBaseURL("https://home.local/", buildHomeHtml(), "text/html", "UTF-8", null)
    }

    private fun syncNavButtons() {
        btnBack.alpha    = if (webView.canGoBack())    1f else 0.28f
        btnForward.alpha = if (webView.canGoForward()) 1f else 0.28f
    }

    private fun navigateTo(raw: String) {
        val s = raw.trim(); if (s.isEmpty() || s == "Home") return
        val url = when {
            s.startsWith("http://") || s.startsWith("https://") -> s
            s.contains(".") && !s.contains(" ") -> "https://$s"
            else -> {
                val base = if (searchEngineIndex < SEARCH_ENGINES.size - 1)
                    SEARCH_ENGINES[searchEngineIndex].second
                else customSearchUrl.ifBlank { SEARCH_ENGINES[0].second }
                "$base${android.net.Uri.encode(s)}"
            }
        }
        webView.loadUrl(url); hideUrlBar()
    }

    private fun applyDataSaverSettings() {
        webView.settings.cacheMode = if (dataSaverLevel >= 3) WebSettings.LOAD_CACHE_ELSE_NETWORK else WebSettings.LOAD_DEFAULT
        webView.settings.loadsImagesAutomatically = dataSaverLevel < 4
    }

    // ══════════════════════════════════════════════════════════════════
    // URL bar show / hide
    // ══════════════════════════════════════════════════════════════════

    private fun toggleUrlBar() { if (urlBarVisible) hideUrlBar() else showUrlBar() }

    private fun showUrlBar() {
        if (urlBarVisible) return
        urlBarVisible = true
        cancelAutoHide()
        if (!hiddenUrlBarMode) showToggleFab(false)
        topEdgeZone.visibility = View.GONE

        urlBar.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        urlBar.visibility = View.VISIBLE
        urlBar.animate().translationY(0f).alpha(1f).setDuration(220).setInterpolator(DecelerateInterpolator())
            .withEndAction { urlBar.setLayerType(View.LAYER_TYPE_NONE, null) }.start()

        if (isOnHomePage) urlInput.setText("")
        urlInput.post {
            urlInput.isFocusable = true; urlInput.isFocusableInTouchMode = true
            urlInput.requestFocus(); urlInput.selectAll()
        }

        // Schedule auto-hide when in hidden bar mode
        if (hiddenUrlBarMode && autoHideDelayMs > 0) scheduleAutoHide()
    }

    private fun hideUrlBar() {
        if (!urlBarVisible) return
        urlBarVisible = false
        cancelAutoHide()
        dismissKeyboard(); urlInput.clearFocus()
        urlInput.isFocusable = false; urlInput.isFocusableInTouchMode = false
        webView.requestFocus()
        if (isOnHomePage) urlInput.setText("Home")

        urlBar.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        urlBar.animate().translationY(-urlBar.height.toFloat()).alpha(0f).setDuration(180)
            .setInterpolator(AccelerateInterpolator())
            .withEndAction {
                urlBar.visibility = View.INVISIBLE
                urlBar.setLayerType(View.LAYER_TYPE_NONE, null)
                if (hiddenUrlBarMode) topEdgeZone.visibility = View.VISIBLE
            }.start()
    }

    private fun scheduleAutoHide() {
        cancelAutoHide()
        if (autoHideDelayMs < 0) return
        autoHideRunnable = Runnable { hideUrlBar() }.also {
            urlBar.postDelayed(it, autoHideDelayMs)
        }
    }

    private fun cancelAutoHide() {
        autoHideRunnable?.let { urlBar.removeCallbacks(it) }
        autoHideRunnable = null
    }

    // ══════════════════════════════════════════════════════════════════
    // Globe FAB
    // ══════════════════════════════════════════════════════════════════

    private fun showToggleFab(animate: Boolean) {
        if (hiddenUrlBarMode) return
        if (toggleVisible || fabBehavior == 3) return
        toggleVisible = true
        if (animate) btnToggle.animate().alpha(1f).translationY(0f).setDuration(190).start()
        else { btnToggle.alpha = 1f; btnToggle.translationY = 0f }
    }

    private fun hideToggleFab() {
        if (hiddenUrlBarMode) return
        if (!toggleVisible || fabBehavior == 2) return
        toggleVisible = false
        btnToggle.animate().alpha(0f).translationY(22f * resources.displayMetrics.density).setDuration(170).start()
    }

    // ══════════════════════════════════════════════════════════════════
    // Keyboard
    // ══════════════════════════════════════════════════════════════════

    private fun showKeyboardFor(wv: ScrollAwareWebView) {
        webInputFocused = true; wv.removeCallbacks(resetWebInputFocused)
        if (!wv.hasFocus()) wv.requestFocusFromTouch()
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        val ok  = imm.showSoftInput(wv, InputMethodManager.SHOW_IMPLICIT)
        if (!ok) wv.postDelayed({
            val ok2 = imm.showSoftInput(wv, InputMethodManager.SHOW_FORCED)
            if (!ok2) WindowInsetsControllerCompat(window, wv).show(WindowInsetsCompat.Type.ime())
        }, 150)
    }

    private fun dismissKeyboard() {
        WindowInsetsControllerCompat(window, window.decorView).hide(WindowInsetsCompat.Type.ime())
    }

    // ══════════════════════════════════════════════════════════════════
    // Haptics
    // ══════════════════════════════════════════════════════════════════

    private fun vibrate(ms: Long) {
        if (!hapticEnabled) return
        try {
            val v = getSystemService(VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
            else @Suppress("DEPRECATION") v.vibrate(ms)
        } catch (_: Exception) {}
    }

    // ══════════════════════════════════════════════════════════════════
    // Back button
    // ══════════════════════════════════════════════════════════════════

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            findBar.visibility == View.VISIBLE -> hideFindBar()
            urlBarVisible      -> hideUrlBar()
            webView.canGoBack() -> webView.goBack()
            !isOnHomePage      -> loadHomePage()
            else -> @Suppress("DEPRECATION") super.onBackPressed()
        }
    }

    // ══════════════════════════════════════════════════════════════════
    // Settings dialog (organized into sections)
    // ══════════════════════════════════════════════════════════════════

    @SuppressLint("UseSwitchCompatOrMaterialCode")
    private fun showSettingsDialog() {
        val dp   = resources.displayMetrics.density
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((20*dp).toInt(), (12*dp).toInt(), (20*dp).toInt(), (8*dp).toInt())
        }

        fun div() = root.addView(View(this).apply { setBackgroundColor(Color.parseColor("#22FFFFFF"))
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1) })

        fun section(title: String) = root.addView(TextView(this).apply {
            text = title; textSize = 11f; setTextColor(Color.parseColor("#4FC3F7"))
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, (14*dp).toInt(), 0, (4*dp).toInt()) })

        fun toggle(label: String, desc: String, checked: Boolean, fn: (Boolean) -> Unit) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL; setPadding(0, (10*dp).toInt(), 0, (10*dp).toInt()) }
            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f) }
            box.addView(TextView(this).apply { text = label; textSize = 14f; setTextColor(Color.WHITE) })
            if (desc.isNotBlank()) box.addView(TextView(this).apply { text = desc; textSize = 11f
                setTextColor(Color.parseColor("#66FFFFFF")); setPadding(0, (2*dp).toInt(), 0, 0) })
            val sw = Switch(this).apply { isChecked = checked; setOnCheckedChangeListener { _, on -> fn(on) } }
            row.addView(box); row.addView(sw); root.addView(row); div()
        }

        fun chevron(label: String, value: () -> String, fn: (TextView) -> Unit) {
            val rv = android.util.TypedValue(); theme.resolveAttribute(android.R.attr.selectableItemBackground, rv, true)
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL; setPadding(0, (10*dp).toInt(), 0, (10*dp).toInt())
                isClickable = true; isFocusable = true; if (rv.resourceId != 0) setBackgroundResource(rv.resourceId) }
            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f); isClickable = false }
            box.addView(TextView(this).apply { text = label; textSize = 14f; setTextColor(Color.WHITE) })
            val vl = TextView(this).apply { text = value(); textSize = 11f; setTextColor(Color.parseColor("#4FC3F7"))
                setPadding(0, (2*dp).toInt(), 0, 0) }
            box.addView(vl); row.addView(box)
            row.addView(TextView(this).apply { text = "›"; textSize = 20f; setTextColor(Color.parseColor("#66FFFFFF"))
                setPadding((8*dp).toInt(), 0, 0, 0) })
            row.setOnClickListener { fn(vl) }; root.addView(row); div()
        }

        // ── Navigation section ─────────────────────────────────────────
        section("NAVIGATION")

        toggle("Hidden URL Bar Mode", "Tap top edge to reveal URL bar", hiddenUrlBarMode) { on ->
            hiddenUrlBarMode = on; saveSettings(); applyHiddenUrlBarMode() }

        if (hiddenUrlBarMode) {
            val delayIdx = HIDE_DELAY_VALUES.indexOfFirst { it == autoHideDelayMs }.coerceAtLeast(0)
            chevron("  Auto-hide Delay", { HIDE_DELAY_LABELS[HIDE_DELAY_VALUES.indexOfFirst { it == autoHideDelayMs }.coerceAtLeast(0)] }) { vl ->
                val ci = intArrayOf(delayIdx)
                AlertDialog.Builder(this).setTitle("Auto-hide Delay")
                    .setSingleChoiceItems(HIDE_DELAY_LABELS, ci[0]) { _, w -> ci[0] = w }
                    .setPositiveButton("Apply") { _, _ ->
                        autoHideDelayMs = HIDE_DELAY_VALUES[ci[0]]; vl.text = HIDE_DELAY_LABELS[ci[0]]; saveSettings() }
                    .setNegativeButton("Cancel", null).show().styleDialog()
            }
        }

        toggle("Scroll to Hide URL Bar", "URL bar hides on scroll down", scrollHideEnabled) { on ->
            scrollHideEnabled = on; saveSettings() }

        if (!hiddenUrlBarMode) {
            val fabLabels = arrayOf("Auto-hide (scroll)", "Tap page to hide", "Always visible")
            chevron("Globe Button", { fabLabels[fabBehavior.coerceIn(0, 2)] }) { vl ->
                val ci = intArrayOf(fabBehavior)
                AlertDialog.Builder(this).setTitle("Globe Button Behavior")
                    .setSingleChoiceItems(fabLabels, fabBehavior) { _, w -> ci[0] = w }
                    .setPositiveButton("Apply") { _, _ ->
                        fabBehavior = ci[0]; vl.text = fabLabels[fabBehavior]; saveSettings()
                        when (fabBehavior) { 2 -> showToggleFab(true); else -> {} }
                    }.setNegativeButton("Cancel", null).show().styleDialog()
            }
        }

        toggle("Swipe to Navigate", "Edge swipe for Back/Forward", swipeNavEnabled) { on ->
            swipeNavEnabled = on; saveSettings() }

        // ── Search section ─────────────────────────────────────────────
        section("SEARCH")

        val seLabels = SEARCH_ENGINES.map { it.first }.toTypedArray()
        chevron("Search Engine", { seLabels[searchEngineIndex.coerceIn(0, seLabels.lastIndex)] }) { vl ->
            val ci = intArrayOf(searchEngineIndex)
            AlertDialog.Builder(this).setTitle("Search Engine")
                .setSingleChoiceItems(seLabels, searchEngineIndex) { _, w -> ci[0] = w }
                .setPositiveButton("Apply") { _, _ ->
                    searchEngineIndex = ci[0]; vl.text = seLabels[searchEngineIndex]; saveSettings()
                    if (searchEngineIndex == seLabels.lastIndex) {
                        // Custom — prompt for URL
                        val et = EditText(this).apply { setText(customSearchUrl); hint = "https://example.com/search?q=" }
                        AlertDialog.Builder(this).setTitle("Custom Search URL").setView(et)
                            .setPositiveButton("Save") { _, _ -> customSearchUrl = et.text.toString().trim(); saveSettings() }
                            .setNegativeButton("Cancel", null).show().styleDialog()
                    }
                }.setNegativeButton("Cancel", null).show().styleDialog()
        }

        // ── Privacy section ────────────────────────────────────────────
        section("PRIVACY & SECURITY")

        toggle("Ad Blocker", "Block ads, trackers & pop-unders", adBlockEnabled) { on ->
            adBlockEnabled = on; saveSettings(); if (!isOnHomePage) webView.reload() }

        val dsShort = arrayOf("Off", "High", "Medium", "Low", "No Images")
        chevron("Data Saver", { dsShort[dataSaverLevel] }) { vl ->
            val ci = intArrayOf(dataSaverLevel)
            AlertDialog.Builder(this).setTitle("Data Saver")
                .setSingleChoiceItems(DATA_SAVER_LABELS, dataSaverLevel) { _, w -> ci[0] = w }
                .setPositiveButton("Apply") { _, _ ->
                    dataSaverLevel = ci[0]; vl.text = dsShort[dataSaverLevel]
                    applyDataSaverSettings(); saveSettings(); if (!isOnHomePage) webView.reload()
                }.setNegativeButton("Cancel", null).show().styleDialog()
        }

        // ── Appearance section ─────────────────────────────────────────
        section("APPEARANCE & FEEL")

        toggle("Haptic Feedback", "Vibrate on gestures and actions", hapticEnabled) { on ->
            hapticEnabled = on; saveSettings() }

        // ── Pages section ──────────────────────────────────────────────
        section("PAGES")

        val rv2 = android.util.TypedValue(); theme.resolveAttribute(android.R.attr.selectableItemBackground, rv2, true)
        fun action(label: String, desc: String, fn: () -> Unit) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL
                setPadding(0, (10*dp).toInt(), 0, (10*dp).toInt())
                isClickable = true; isFocusable = true; if (rv2.resourceId != 0) setBackgroundResource(rv2.resourceId) }
            row.addView(TextView(this).apply { text = label; textSize = 14f; setTextColor(Color.parseColor("#4FC3F7")) })
            if (desc.isNotBlank()) row.addView(TextView(this).apply { text = desc; textSize = 11f
                setTextColor(Color.parseColor("#55FFFFFF")); setPadding(0, (2*dp).toInt(), 0, 0) })
            row.setOnClickListener { fn() }; root.addView(row); div()
        }

        if (!isOnHomePage) action("Save Page Offline", "Save as MHTML for offline viewing") { savePageOffline() }
        action("Saved Pages", "Browse previously saved pages") { showSavedPages() }
        action("Clear Cookies", "Remove all cookies") {
            CookieManager.getInstance().removeAllCookies { Toast.makeText(this,"Cookies cleared",Toast.LENGTH_SHORT).show() }
        }
        action("Clear Cache", "Free up storage") {
            webView.clearCache(true)
            Toast.makeText(this,"Cache cleared",Toast.LENGTH_SHORT).show()
        }

        // ── Debug ──────────────────────────────────────────────────────
        section("ADVANCED")
        toggle("Debug Overlay", "Show live event log", debugOverlayVisible) { on ->
            debugOverlayVisible = on; debugOverlay.visibility = if (on) View.VISIBLE else View.GONE }

        val sv = ScrollView(this).also { it.addView(root) }
        AlertDialog.Builder(this).setTitle("Settings").setView(sv)
            .setPositiveButton("Done", null).show().styleDialog()
    }

    // ══════════════════════════════════════════════════════════════════
    // Home page HTML
    // ══════════════════════════════════════════════════════════════════

    private fun buildHomeHtml() = """<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
<style>
*{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent}
body{background:#080810;color:#fff;
  font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;
  min-height:100vh;display:flex;flex-direction:column;align-items:center;padding:56px 16px 30px}
.clock{font-size:72px;font-weight:200;letter-spacing:-4px;line-height:1;
  background:linear-gradient(135deg,#ffffff 30%,#4FC3F7 80%);
  -webkit-background-clip:text;-webkit-text-fill-color:transparent}
.date{font-size:13px;color:#555;margin-top:8px;margin-bottom:8px;letter-spacing:.5px}
.search-bar{display:flex;align-items:center;width:100%;max-width:400px;
  background:#111;border:1px solid #1e1e1e;border-radius:28px;
  padding:10px 18px;margin:16px 0 24px;gap:10px;cursor:pointer}
.search-bar span{color:#444;font-size:14px;flex:1}
.search-icon{font-size:16px;color:#333}
.grid{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;width:100%;max-width:400px}
a{text-decoration:none;color:inherit}
.card{display:flex;flex-direction:column;align-items:center;gap:7px;
  padding:14px 6px 11px;border-radius:18px;background:#0e0e16;
  border:1px solid #151520;position:relative;user-select:none;-webkit-user-select:none;
  transition:transform .1s,background .1s}
.card:active{background:#1a1a2a;transform:scale(.95)}
.card.editing{border-color:#222;outline:1px solid #1e1e2e}
.icon{width:46px;height:46px;border-radius:13px;display:flex;align-items:center;
  justify-content:center;overflow:hidden;background:#151520;flex-shrink:0}
.icon img{width:32px;height:32px;object-fit:contain;display:block}
.fallback{width:46px;height:46px;border-radius:13px;display:none;
  align-items:center;justify-content:center;font-size:20px;font-weight:800;color:#fff;
  background:linear-gradient(135deg,#1565C0,#0D47A1)}
.label{font-size:10px;color:#666;text-align:center;letter-spacing:.2px;
  width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.del-btn{position:absolute;top:-7px;right:-7px;width:22px;height:22px;border-radius:50%;
  background:#FF4444;display:none;align-items:center;justify-content:center;
  font-size:13px;color:#fff;z-index:20;font-weight:700}
.card.editing .del-btn{display:flex}
.add-card{cursor:pointer;border-style:dashed;border-color:#1a1a1a;background:#090912}
.done-bar{grid-column:1/-1;display:flex;align-items:center;justify-content:center;
  padding:11px;border-radius:12px;background:#0a1422;border:1px solid #4FC3F7;
  color:#4FC3F7;font-size:13px;font-weight:600;cursor:pointer;margin-top:2px}
</style>
</head>
<body>
<div class="clock" id="clk"></div>
<div class="date" id="dt"></div>
<div class="search-bar" onclick="if(typeof NativeSearch!=='undefined')NativeSearch.openSearch()">
  <span class="search-icon">🔍</span>
  <span>Search or enter address…</span>
</div>
<div class="grid" id="grid"></div>
<script>
var DEFAULTS=${DEFAULT_SPEED_DIAL.trimIndent()};
var editing=false;
function sdLoad(){
  try{
    if(typeof SpeedDial!=='undefined'){var d=SpeedDial.get();if(d&&d.length>2)return JSON.parse(d);}
    var s=localStorage.getItem('sd');return s?JSON.parse(s):DEFAULTS.slice();
  }catch(e){return DEFAULTS.slice();}
}
function sdSave(a){
  try{var j=JSON.stringify(a);
    if(typeof SpeedDial!=='undefined')SpeedDial.save(j);else localStorage.setItem('sd',j);
  }catch(e){}
}
function fav(url){
  try{var h=new URL(url).hostname;return'https://www.google.com/s2/favicons?domain='+h+'&sz=64';}
  catch(e){return'';}
}
function esc(s){return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');}
function render(){
  var items=sdLoad(),g=document.getElementById('grid');
  g.innerHTML='';
  items.forEach(function(it,i){
    var w=document.createElement('div');w.style.position='relative';
    var fi=fav(it.url),ini=it.name.charAt(0).toUpperCase();
    w.innerHTML='<a href="'+(editing?'javascript:void(0)':it.url)+'" class="sl">'
      +'<div class="card'+(editing?' editing':'')+'">'
      +'<div class="del-btn" data-del="'+i+'">&#10005;</div>'
      +'<div class="icon"><img src="'+fi+'" width="32" height="32"'
        +' onerror="this.style.display=\'none\';this.nextSibling.style.display=\'flex\'">'
      +'<div class="fallback">'+ini+'</div></div>'
      +'<span class="label">'+esc(it.name)+'</span></div></a>';
    var pt,pl=w.querySelector('.sl');
    pl.addEventListener('touchstart',function(){pt=setTimeout(function(){editing=true;render();},600);},{passive:true});
    pl.addEventListener('touchend',function(){clearTimeout(pt);});
    pl.addEventListener('touchmove',function(){clearTimeout(pt);});
    w.querySelector('.del-btn').addEventListener('click',function(e){
      e.preventDefault();e.stopPropagation();
      var a=sdLoad();a.splice(parseInt(this.dataset.del),1);sdSave(a);render();
    });
    g.appendChild(w);
  });
  var aw=document.createElement('div');aw.style.position='relative';
  aw.innerHTML='<div class="card add-card"><div class="icon" style="background:transparent;font-size:26px;color:#333">+</div><span class="label">Add</span></div>';
  aw.addEventListener('click',function(){
    editing=false;render();
    if(typeof SpeedDial!=='undefined')SpeedDial.openAddDialog();
  });
  g.appendChild(aw);
  if(editing){
    var db=document.createElement('div');db.className='done-bar';db.textContent='✓  Done';
    db.addEventListener('click',function(){editing=false;render();});
    g.appendChild(db);
  }
}
window.addToSpeedDial=function(url,name){
  var a=sdLoad();
  for(var i=0;i<a.length;i++){if(a[i].url===url)return;}
  a.push({url:url,name:name});sdSave(a);render();
};
window.refreshSpeedDial=function(){render();};
function tick(){
  var n=new Date(),h=n.getHours().toString().padStart(2,'0'),m=n.getMinutes().toString().padStart(2,'0'),
      days=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'],
      months=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  document.getElementById('clk').textContent=h+':'+m;
  document.getElementById('dt').textContent=days[n.getDay()]+', '+months[n.getMonth()]+' '+n.getDate();
}
tick();setInterval(tick,5000);render();
</script>
</body>
</html>"""

    // ══════════════════════════════════════════════════════════════════
    // Dialog style helper + debug
    // ══════════════════════════════════════════════════════════════════

    private val debugLog = ArrayDeque<String>()
    private fun dbg(msg: String) {
        android.util.Log.d("BrowserApp", msg)
        if (!debugOverlayVisible) return
        val ts = SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date())
        runOnUiThread {
            debugLog.addFirst("$ts  $msg"); if (debugLog.size > 8) debugLog.removeLast()
            debugOverlay.text = debugLog.joinToString("\n")
        }
    }

    private fun AlertDialog.styleDialog(): AlertDialog {
        window?.setBackgroundDrawableResource(android.R.color.background_dark)
        getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(Color.parseColor("#4FC3F7"))
        getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(Color.parseColor("#80FFFFFF"))
        getButton(AlertDialog.BUTTON_NEUTRAL)?.setTextColor(Color.parseColor("#80FFFFFF"))
        return this
    }
}

// ── Extension: iterate children ────────────────────────────────────────────
private val LinearLayout.children: Sequence<View> get() = sequence {
    for (i in 0 until childCount) yield(getChildAt(i))
}
