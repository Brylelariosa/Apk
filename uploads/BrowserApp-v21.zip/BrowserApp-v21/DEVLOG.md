# BrowserApp — Development Log

## v20 → v21

---

### ✨ Hidden URL Bar Mode

The FAB-based URL bar system has been extended with a clean "Hidden URL Bar Mode":

- When enabled in Settings → Navigation, the URL bar **and** the globe FAB are both hidden during browsing.
- A transparent 44dp touch strip (`topEdgeZone`) sits at the very top of the screen at elevation 25dp, above the WebView. Tapping it reveals the URL bar without the website below registering the touch (no conflicts with website inputs like Google's search bar — the overlay captures the event first).
- **Auto-hide delay** is configurable: 2 s / 5 s / 10 s / Never. The delay resets each time the URL bar is shown.
- **Double-tap** the page to toggle the URL bar at any time.
- **Scroll down** hides the URL bar; **scroll up** reveals it (when `scrollHideEnabled` is on).
- All preferences persist across restarts.

---

### ✨ Bookmarks

- Star button (`btnBookmark`) in the URL bar replaces the old Speed Dial star.
- Tap star on an unvisited page → bookmarks instantly with vibration confirmation.
- Tap star on a bookmarked page → shows "Edit / Remove / Done" dialog.
- **Bookmarks dialog** (via ⋮ menu): searchable list, swipe-friendly delete (✕), sorted newest-first.
- Stored in SharedPreferences as JSON under key `bookmarks_v2`.
- Star icon turns gold (filled) when the current page is bookmarked; fades otherwise.

---

### ✨ History

- Every page load is recorded automatically (incognito tabs are excluded).
- **History dialog** (via ⋮ menu): grouped into Today / Yesterday / This Week / Older, each entry shows title + timestamp + URL.
- Full text search across title and URL.
- Delete individual entries (✕) or clear all (with confirmation prompt).
- Stores up to 500 entries in `history_v2` SharedPreferences key.

---

### ✨ Incognito Tabs

- "New Incognito Tab" in the ⋮ menu opens a tab with:
  - `WebSettings.cacheMode = LOAD_NO_CACHE`
  - `saveFormData = false`, `savePassword = false`
  - Third-party cookies disabled
  - History recording skipped
- A **purple 3dp indicator strip** appears at the top of the screen when an incognito tab is active (color `#9C27B0`).
- Grid tab switcher shows a 🕵 icon and purple card accent for incognito tabs.
- Closing the last incognito tab triggers `CookieManager.removeAllCookies()` (best-effort cleanup).

---

### ✨ Find in Page

- Activated from ⋮ → "Find in Page".
- A slide-up bar at the bottom of the screen contains:
  - Search EditText
  - Live match counter (`X/Y` format, via `setFindListener`)
  - ↑ Previous / ↓ Next navigation buttons
  - ✕ Close button
- Uses `WebView.findAllAsync()` for non-blocking search.
- Find bar dismisses on back press. Clears `WebView.clearMatches()` on close.
- **Background:** `find_bar_bg.xml` — frosted-glass dark with rounded top corners.

---

### ✨ Share Menu (⋮ overflow)

All share/page actions live in the **⋮ overflow menu** for a clean URL bar:

| Item | Action |
|---|---|
| Copy URL | Clipboard + toast + haptic |
| Copy Title | Clipboard + toast |
| Share Page | Android `ACTION_SEND` chooser |
| Open in Browser | `ACTION_VIEW` external intent |
| QR Code | Opens `api.qrserver.com` in a new tab (no library dependency) |

---

### ✨ Search Engine Selection

- Settings → Search → "Search Engine"
- Built-in: **Google**, **Bing**, **DuckDuckGo**, **Brave Search**, **Startpage**
- **Custom**: prompts for a search URL with `?q=` placeholder
- Selection persists in prefs; used in `navigateTo()` for all non-URL queries.

---

### ✨ Desktop Site Toggle

- ⋮ → "Request Desktop Site" / "Switch to Mobile Site"
- Switches `userAgentString` between `MOBILE_UA` and `DESKTOP_UA`, then reloads.
- State stored per-tab in `BrowserTab.isDesktopMode`.

---

### ✨ Reader Mode

- ⋮ → "Reader Mode"
- Injects JavaScript that:
  1. Extracts the best candidate element (`article`, `[role=main]`, `main`, `.post-content`, etc.)
  2. Creates a full-screen fixed overlay (`z-index: 2147483647`) with dark background (`#121212`) and serif font
  3. Removes `script`, `style`, `iframe`, `nav`, `header`, `footer`, `aside`, `.ad` elements
  4. Adds a sticky "✕ Close Reader" button at the top
- Toggling a second time removes the overlay and restores the page.
- No external libraries; pure JS injection via `WebView.evaluateJavascript()`.

---

### ✨ Pull to Refresh

- Detected natively in `ScrollAwareWebView.onTouchEvent()`.
- When `scrollY == 0` and the user drags down ≥ 120dp, `onPullToRefresh` fires.
- Triggers `webView.reload()` + progress bar + short haptic vibration.
- Avoids false positives by resetting the pull state on `ACTION_UP` / `ACTION_CANCEL`.

---

### ✨ Haptic Feedback

- All meaningful interactions vibrate: bookmark add, swipe navigation commit, pull-to-refresh, download start, copy actions.
- Configurable toggle in Settings → Appearance → "Haptic Feedback".
- Uses `VibrationEffect.createOneShot()` on API 26+ with graceful fallback.

---

### ✨ Grid Tab Switcher

- Replaced the old scrolling list with a **2-column grid** of cards.
- Each card shows: colored initial circle, title (2 lines), URL, ✕ close.
- Active tab highlighted with blue accent (`#1A4FC3F7` background).
- Incognito tabs show 🕵 icon in purple.
- Action row at top: **+ New Tab** | **+ Incognito** | **↩ Reopen** (last closed, when available).
- "Close All Tabs" button at the bottom (with confirmation).

---

### ✨ Recently Closed Tabs

- `closedTabs: ArrayDeque<Pair<String, String>>` stores the last 10 closed tab URLs + titles.
- "↩ Reopen" button appears in the grid tab switcher header when the list is non-empty.

---

### ✨ Long-Press Refresh = Hard Reload

- Long-press the refresh button calls `webView.clearCache(true)` then `webView.reload()`.
- Shows a "Hard reloaded" toast.

---

### ✨ URL-Scheme Intent Handling

- `AndroidManifest.xml` now includes an `ACTION_VIEW` intent filter for `http://` and `https://` schemes.
- The app can be selected as a browser from external app link taps.

---

### 🔧 Architecture Changes

| Before | After |
|---|---|
| Settings star = Speed Dial | Settings star = Bookmark; Speed Dial still accessible from home |
| `btnSettings` in URL bar | `btnOverflow` (⋮) in URL bar; Settings inside overflow menu |
| `fabBehavior` 0–3 | `hiddenUrlBarMode` (boolean) + `fabBehavior` 0–2 for non-hidden modes |
| `ScrollAwareWebView` scroll only | Scroll + pull-to-refresh detection in `onTouchEvent` |
| Single MainActivity | `BookmarkManager.kt` + `HistoryManager.kt` extracted |

---

### 🐛 Known Constraints

- Reader mode is best-effort; complex SPAs or paywalled sites may not extract cleanly.
- QR code requires internet (loads `api.qrserver.com`).
- Incognito cookie isolation is partial — Android's `CookieManager` is process-wide; `removeAllCookies` on incognito close affects all sessions.
- Pull-to-refresh threshold (120dp) is intentionally high to avoid accidental triggers on bounce-heavy pages.
