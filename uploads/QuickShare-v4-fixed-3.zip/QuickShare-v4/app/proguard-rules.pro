# ─── QuickShare ProGuard Rules ────────────────────────────────────────────────

# Keep only what's actually needed — the old "-keep class com.quickshare.** { *; }"
# was keeping EVERYTHING and completely defeating minification.

# Keep Activities, BroadcastReceivers (Android needs to instantiate these by name)
-keep public class com.quickshare.MainActivity
-keep public class com.quickshare.HistoryActivity
-keep public class com.quickshare.ReceiveActivity
-keep public class com.quickshare.WiFiDirectBroadcastReceiver

# Keep data classes used with JSON serialization (TransferRecord, SelectedFile)
-keepclassmembers class com.quickshare.TransferRecord { *; }
-keepclassmembers class com.quickshare.SelectedFile { *; }

# Keep ViewBinding (generated classes referenced by name at runtime)
-keep class com.quickshare.databinding.** { *; }

# ─── ZXing ────────────────────────────────────────────────────────────────────
-keep class com.google.zxing.** { *; }
-keep class com.journeyapps.barcodescanner.** { *; }

# ─── AndroidX / Kotlin ────────────────────────────────────────────────────────
# Keep coroutines debug info only in debug builds (handled by buildType)
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}
-keepclassmembernames class kotlinx.** {
    volatile <fields>;
}

# Keep Parcelable creators
-keepclassmembers class * implements android.os.Parcelable {
    public static final ** CREATOR;
}

# Keep enum values
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}

# Keep R classes
-keepclassmembers class **.R$* {
    public static <fields>;
}

# Remove logging in release
-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
    public static *** i(...);
}
