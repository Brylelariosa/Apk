package com.quickshare

import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

data class SelectedFile(val uri: Uri, val name: String, val size: Long)

class SelectedFilesAdapter(
    private val files: MutableList<SelectedFile>,
    private val onRemove: (Int) -> Unit
) : RecyclerView.Adapter<SelectedFilesAdapter.VH>() {

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        val tvTypeIcon: TextView = view.findViewById(R.id.tvFileTypeIcon)
        val tvName:     TextView = view.findViewById(R.id.tvFileName)
        val tvSize:     TextView = view.findViewById(R.id.tvFileSize)
        val btnRemove:  View     = view.findViewById(R.id.btnRemoveFile)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_selected_file, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val file = files[position]
        holder.tvTypeIcon.text  = Utils.fileTypeEmoji(file.name)
        holder.tvName.text      = file.name
        holder.tvSize.text      = Utils.formatSize(file.size)
        holder.btnRemove.setOnClickListener { onRemove(holder.adapterPosition) }
    }

    override fun getItemCount() = files.size
}
