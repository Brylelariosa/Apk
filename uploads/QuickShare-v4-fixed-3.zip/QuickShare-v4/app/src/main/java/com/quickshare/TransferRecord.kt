package com.quickshare

data class TransferRecord(
    val id: String,
    val timestamp: Long,
    val direction: String,   // "sent" | "received"
    val fileNames: List<String>,
    val totalBytes: Long,
    val peerName: String,
    val status: String       // "success" | "failed" | "cancelled"
)
