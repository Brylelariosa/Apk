package com.quickshare

import java.text.DecimalFormat
import kotlin.math.log10
import kotlin.math.pow

object Utils {

    fun formatSize(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB")
        val i = (log10(bytes.toDouble()) / log10(1024.0)).toInt().coerceAtMost(3)
        return "${DecimalFormat("#,##0.#").format(bytes / 1024.0.pow(i.toDouble()))} ${units[i]}"
    }

    fun fileTypeEmoji(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        return when (ext) {
            "jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif" -> "🖼️"
            "mp4", "mkv", "avi", "mov", "webm", "3gp", "flv"           -> "🎬"
            "mp3", "flac", "wav", "aac", "ogg", "m4a", "opus"          -> "🎵"
            "pdf"                                                        -> "📄"
            "doc", "docx"                                                -> "📝"
            "xls", "xlsx", "csv"                                         -> "📊"
            "ppt", "pptx"                                                -> "📊"
            "zip", "rar", "7z", "tar", "gz", "bz2", "xz"               -> "🗜️"
            "apk"                                                        -> "📦"
            "txt", "md", "log"                                           -> "📃"
            "html", "htm", "xml", "json"                                 -> "🌐"
            else                                                         -> "📁"
        }
    }
}
