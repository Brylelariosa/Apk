package com.quickshare

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.quickshare.databinding.ActivityHistoryBinding

class HistoryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHistoryBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHistoryBinding.inflate(layoutInflater)
        setContentView(binding.root)
        loadHistory()

        binding.btnClearHistory.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Clear History")
                .setMessage("Delete all transfer records?")
                .setPositiveButton("Clear") { _, _ ->
                    HistoryManager.clear(this)
                    loadHistory()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    private fun loadHistory() {
        val records = HistoryManager.getAll(this)
        if (records.isEmpty()) {
            binding.rvHistory.visibility   = View.GONE
            binding.tvNoHistory.visibility = View.VISIBLE
        } else {
            binding.tvNoHistory.visibility = View.GONE
            binding.rvHistory.visibility   = View.VISIBLE
            binding.rvHistory.layoutManager = LinearLayoutManager(this)
            binding.rvHistory.adapter       = HistoryAdapter(records)
        }
    }
}
