package com.quickshare

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HistoryAdapter(
    private val records: List<TransferRecord>
) : RecyclerView.Adapter<HistoryAdapter.VH>() {

    private val dateFmt = SimpleDateFormat("MMM d, h:mm a", Locale.getDefault())

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        val icon:   TextView = view.findViewById(R.id.tvHistoryIcon)
        val files:  TextView = view.findViewById(R.id.tvHistoryFiles)
        val meta:   TextView = view.findViewById(R.id.tvHistoryMeta)
        val peer:   TextView = view.findViewById(R.id.tvHistoryPeer)
        val status: TextView = view.findViewById(R.id.tvHistoryStatus)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = VH(
        LayoutInflater.from(parent.context).inflate(R.layout.item_history, parent, false)
    )

    override fun getItemCount() = records.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val r = records[position]

        holder.icon.text = if (r.direction == "sent") "📤" else "📥"

        holder.files.text = when {
            r.fileNames.isEmpty()  -> "Unknown files"
            r.fileNames.size == 1  -> r.fileNames[0]
            else                   -> "${r.fileNames[0]} + ${r.fileNames.size - 1} more"
        }

        val date      = dateFmt.format(Date(r.timestamp))
        val sizeLabel = Utils.formatSize(r.totalBytes)
        val countLabel = "${r.fileNames.size} file${if (r.fileNames.size != 1) "s" else ""}"
        holder.meta.text = "$date • $countLabel • $sizeLabel"

        holder.peer.text = if (r.direction == "sent") "→ ${r.peerName}" else "← ${r.peerName}"

        holder.status.text = when (r.status) {
            "success"   -> "✅"
            "cancelled" -> "⛔"
            else        -> "❌"
        }
    }
}
