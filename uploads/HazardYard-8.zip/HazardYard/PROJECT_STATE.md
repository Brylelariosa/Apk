# PROJECT_STATE - Hazard Yard

Updated 2026-10-28 (session 9, Claude on a free plan). The user moves between free-plan AI sessions, so keep this file and `NEXT_TASK.md` current after every finished item. The live handoff is also in FileBridge shared memory (`memory_resume("hazardyard")`).

## STATUS OF THE 7 ITEMS IN NEXT_TASK.md
1. Drop-in (choose where to land): NOT started. Cheapest useful version: let the player tap a landing spot on the island map in the solo setup screen and pass it to `SoloEngine` -> `world.startMatch()` (hosted games keep the normal spawn); the full plane/parachute version needs a new phase, a wire message and HUD work (design in NEXT_TASK.md).
2+3. Loot of dead fighters + swapped guns stay on the ground: DONE by session 8, checked by session 9 (see changelog).
4. Map look: ground grid REMOVED, outdoor water REDRAWN. Trees and houses/roofs NOT touched (BlockRenderer, RoofRenderer, SurvivalHouses, SurvivalRenderer, MapTheme).
5. Survival death: overlay + respawn near the death spot done; root cause of "never revive" NOT found.
6. Knife / zombies: hit test, aim assist and knife numbers changed blind (nothing could be played).
7. Melee animation: slash trail + body lunge only. Arms/poses per weapon are still the old weapon-slides-across-the-body look (`UnitRenderer.meleePose`).

## Where things are
- Source ZIP: `HazardYard-7.zip` (workspace root, also shown under `ZIP/`). Unpacked copy: `HazardYard/`. The project root is `HazardYard/HazardYard/` (the ZIP has its own top-level `HazardYard/` folder; `list_files` names are relative to the folder you list).
- Java sources: `HazardYard/HazardYard/app/src/main/java/com/hazardyard/game/` with packages `core` (rules, no Android), `survival`, `bot`, `engine`, `net`, `input`, `render` (+ `render/model`), `settings`, `ui`, `audio`. `README.md` (project root) describes every system; its "Layout of the code" table is the best map.
- Off-device test harness: `docs/dev-harness/` (Android stubs, `compile.sh`, test tools). Last test report: `docs/TEST_REPORT.md`.

## How to work (read this first)
1. `resume_project("hazardyard")` then `memory_resume("hazardyard")` for the live state, then read `NEXT_TASK.md`.
2. FileBridge has no grep. Find code by reading the likely file. `read_file` returns at most 2000 lines per call; `edit_file` needs an `old_text` that occurs exactly once.
3. Nothing can be compiled on the phone. A compile error breaks the user's GitHub "Build APK" run, so: small edits, re-read each edited region afterwards, check that every method/field you call really exists (signatures below), plain Java 8 syntax, no new libraries.
4. The chat sandbox has a JDK 21 compiler but no network and no copy of the sources, so use it only for tiny self-contained helpers.
5. Deliver a new ZIP: `create_zip(source="HazardYard", output="ZIP/HazardYard-8.zip", exclude_patterns=["build/", ".gradle/", "*.apk"])`, then `verify_zip(..., expect_files=["HazardYard/app/build.gradle", "HazardYard/README.md"])`. Add a short "What is new" entry to README.md. Say honestly what is untested.
6. After every finished item call `project_checkpoint` (completed / pending / next_steps).

## Verified code facts (read this session)
Battleground = `GameMode` with `royale == true`; Survival = `mode.survival`. Both run in `core/GameWorld` (host rules); `survival/SurvivalSim` is attached for survival.
- `core/GameWorld` (862 lines): `startMatch()` places every fighter with `placeAtSpawn(p)` (spawn point farthest from living opponents) and enters `PHASE_COUNTDOWN` with `st.countdown = GameConfig.COUNTDOWN_SECONDS` (3 s); `step()` counts it down to `PHASE_PLAYING`; `updatePlayer(p, dt, live)`: when `live == false` nobody moves or shoots. `giveWeapon(p, id)` (two-slot logic) overwrites the gun in hand when both slots are full: the old gun is lost. `takePickup(p)` takes the pad (`pk.active=false`, `listener.onPickup`). `kill(v, killerId, weaponId)` zeroes `armor`, sets `alive=false`, drops nothing. `startSwing/resolveSwing` = melee against fighters; `sim.meleeSwing(p, d, atk)` = melee against zombies. `updatePickups` only respawns pads when `mode.pickupRespawn >= 0` (never in Battleground). Respawn branch: `if (live && !st.mode.royale) { respawnTimer -= dt; if <= 0 respawn(p) }` (look here for the survival "never revive" bug).
- `core/Pickup`: `final float x,y; final int item; boolean active; float timer;`. `core/GameState`: `pickups = new Pickup[map.pickupX.length]` filled from the map (identical on host and clients).
- `core/Pickups`: `worthTaking`, `nearest`, `offered` (HUD prompt) iterate `st.pickups`. `Items.effect(holder,item)` is the text on the Pick Up button.
- `core/Items` ids: `VEST_LIGHT=32` (armour 50), `VEST_HEAVY=33` (100), `MEDKIT=34`, `BACKPACK_1..3=67..69`, `AMMO_BOX=70`; weapon ids 0..20 (`WeaponDef`: guns 0..13, `KNIFE=14, BAT=15, CROWBAR=16, MACHETE=17, AXE=18, PICKAXE=19, FISTS=20`). Knife: dmg 24, interval 0.30 s, reach 34, arc 42 deg, hitDelay 0.08 s.
- `core/Player`: `slotWeapon[2]`, `slotAmmo[2]`, `slotReserve[2]`, `activeSlot`, `backpack`, `armor`, `weapon` (in hand), `respawnTimer` (unused in Battleground; sent as u8 in 1/10 s), `spawnProtect`, `resetForMatch()`.
- `net/SnapshotCodec`: pad bitmask `(pads+7)/8` bytes with `pads = st.pickups.length` on both sides (`ClientEngine` passes `st.pickups.length`); `Data.padActive` has `TileMap.MAX_PICKUPS` (=400) entries; per player 17 bytes (+8 royale gear bytes); countdown travels as u8 in 1/10 s (max 25.5 s); positions `Packets.quantizePos` (i16, 1/4 unit) and `quantizeUnsigned` (u16).
- `net/Protocol`: `VERSION = 7` (bump on any wire change), last client opcode `C_SWITCH = 10`, `MAX_FRAME = 4096`. `engine/HostEngine`: `snapshotWriter = new PacketWriter(512)`; `fixedUpdate` forwards `LocalInput` one-shots to `world.requestX`; `handle()` switches on `Protocol.C_*`. `engine/SoloEngine` forwards the same way. `engine/ClientEngine`: `applySnapshot()`, `sendPickup()`, `sendInput()`; no prediction outside `PHASE_PLAYING`.
- `core/TileMap`: `GameConfig.TILE = 32`; `isSolid(tx,ty)`, `isSolidAt(x,y)`, `isWaterAt(x,y)`, `houseAtPoint(x,y)`, `houses[]`; `MAX_PICKUPS = 400`; kinds `WATER=4`, `TREE=12`; ground types `G_*`.
- `core/LocalInput`: one-shots `reload, switchWeapon, dodge, pickup` + survival command queue.

## NOT read yet (read before editing)
BotBrain (how bots use pads), PickupRenderer, Presentation, HudRenderer (countdown + prompt), InputController / ControlGeometry / GameView (touch routing), Renderer (draw order), MiniTerrain / MapPreviewView (island map drawing), SurvivalSim (death, melee, zombies), GameMode, MeleeProfile, UnitRenderer / Puppet / PuppetRenderer (melee animation), TerrainRenderer / FloorRenderer / BlockRenderer / RoofRenderer / SurvivalRenderer / SurvivalHouses / MapTheme / MapShapes (map look).

## CHANGELOG (game code) - NOTHING BELOW HAS BEEN COMPILED OR PLAYED; the next build is the first test
Session 8 (another AI; it left no notes, session 9 verified the work by reading every touched file):
- Items 2+3, dynamic pads: `Pickup` (non-final x/y/item, `dynamic`, `ammo`, `reserve`), `GameConfig.DROP_PADS` extra pads after the map pads (`GameState.mapPads`), `Pickups.tooFresh/worthTaking` (rounds are kept), `GameWorld.dropLoot` (a fighter's things drop where they fall), `spawnDrop`, `giveWeapon` (the old gun is dropped on a swap), `takePickup`, `SnapshotCodec` (+ drops list), `Protocol.VERSION = 8`, `ClientEngine.applySnapshot`, `HostEngine` snapshot writer 1024 bytes. Bots read `st.pickups` by live index, so they also take dropped things.
Session 9 (Claude):
- Item 4 (part): `TerrainRenderer` ground colour is now smooth low-contrast noise (no per-tile checkerboard; `colorAt()` added); `FloorRenderer.drawLakes` draws outdoor water as one sheet (shallows band, foam line, rounded banks; arena maps still use `drawWater`); empty drop pads are hidden.
- Item 5: `SurvivalHud.drawDeath` (YOU DIED + countdown); `SurvivalSim` records `deathX/deathY/hasDeath`, `placeAtSpawn` brings a survivor back 170-400 units from where they fell, away from zombies (`zombieNear`). The respawn path in `GameWorld` (`updatePlayer` `!p.alive` branch, `kill`, `respawn`) reads correctly, so if "never revive" still happens the cause is elsewhere (what does the player actually see after the 6 s?).
- Items 6/7: `SurvivalSim.meleeSwing` hit test is more forgiving (+8 reach, +0.14 rad); `SurvivalSim.meleeAssistAngle` + `GameWorld.updatePlayer` turn the aim towards a zombie in front while swinging; `MeleeProfile` knife (thrust arc 0.8, damage 1.1/1.0, more knock and stagger); `UnitRenderer.drawSlash` (crescent or streak trail on every blow, also in the flat look) and the body leans into a blow (`G_BODY` offX, yaw 0.34).
- Lease note: session 8 left a lease on core/engine/net that blocked writes for 25 minutes. Always `file_lease release` before you stop.
