package android.app;
public class Activity extends android.content.Context {
    protected void onCreate(android.os.Bundle b) {}
    protected void onResume() {}
    protected void onPause() {}
    protected void onDestroy() {}
    protected void onStart() {}
    protected void onStop() {}
    public void setContentView(android.view.View v) {}
    public android.view.Window getWindow() { return new android.view.Window(); }
    public void finish() {}
    public void onBackPressed() {}
    public void onWindowFocusChanged(boolean f) {}
    public void runOnUiThread(Runnable r) { r.run(); }
    public void setRequestedOrientation(int o) {}
    public android.view.WindowManager getWindowManager() { return new android.view.WindowManager(); }
    public void onConfigurationChanged(android.content.res.Configuration c) {}
}
