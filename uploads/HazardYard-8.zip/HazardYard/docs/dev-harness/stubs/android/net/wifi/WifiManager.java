package android.net.wifi;
public class WifiManager {
    public static final int WIFI_MODE_FULL_LOW_LATENCY = 4, WIFI_MODE_FULL_HIGH_PERF = 3;
    public static class WifiLock { public void acquire() {} public void release() {} public boolean isHeld() { return false; } public void setReferenceCounted(boolean b) {} }
    public static class MulticastLock { public void acquire() {} public void release() {} public boolean isHeld() { return false; } public void setReferenceCounted(boolean b) {} }
    public WifiLock createWifiLock(int m, String t) { return new WifiLock(); }
    public MulticastLock createMulticastLock(String t) { return new MulticastLock(); }
}
