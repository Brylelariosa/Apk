package android.view;
public class WindowInsets {
    public static class Type { public static int displayCutout() { return 1; } public static int systemBars() { return 2; } }
    public android.graphics.Insets getInsets(int t) { return android.graphics.Insets.NONE; }
}
