package android.view;
public class Gravity { public static final int CENTER = 17, CENTER_VERTICAL = 16, CENTER_HORIZONTAL = 1, LEFT = 3, RIGHT = 5, TOP = 48, BOTTOM = 80, START = 8388611, END = 8388613, FILL_HORIZONTAL = 7, NO_GRAVITY = 0; }
