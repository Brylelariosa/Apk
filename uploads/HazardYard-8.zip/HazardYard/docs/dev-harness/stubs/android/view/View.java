package android.view;
public class View {
    public static final int VISIBLE = 0, INVISIBLE = 4, GONE = 8;
    public interface OnClickListener { void onClick(View v); }
    public interface OnTouchListener { boolean onTouch(View v, MotionEvent e); }
    public interface OnApplyWindowInsetsListener { WindowInsets onApplyWindowInsets(View v, WindowInsets insets); }
    protected android.content.Context ctx;
    public View(android.content.Context c) { ctx = c; }
    public android.content.Context getContext() { return ctx; }
    public android.content.res.Resources getResources() { return ctx == null ? new android.content.res.Resources() : ctx.getResources(); }
    public void setBackground(android.graphics.drawable.Drawable d) {}
    public void setBackgroundColor(int c) {}
    public void setPadding(int l, int t, int r, int b) {}
    public int getPaddingLeft() { return 0; } public int getPaddingTop() { return 0; } public int getPaddingRight() { return 0; } public int getPaddingBottom() { return 0; }
    public void setClickable(boolean b) {}
    public void setFocusable(boolean b) {}
    public void setEnabled(boolean b) {}
    public boolean isEnabled() { return true; }
    public void setOnClickListener(OnClickListener l) {}
    public void setOnTouchListener(OnTouchListener l) {}
    public void setVisibility(int v) {}
    public int getVisibility() { return VISIBLE; }
    public void setAlpha(float a) {}
    public void setLayoutParams(ViewGroup.LayoutParams p) {}
    public ViewGroup.LayoutParams getLayoutParams() { return null; }
    public int getWidth() { return 0; } public int getHeight() { return 0; }
    public boolean post(Runnable r) { return true; }
    public void invalidate() {}
    public void requestLayout() {}
    public void requestApplyInsets() {}
    public void setOnApplyWindowInsetsListener(OnApplyWindowInsetsListener l) {}
    public void setKeepScreenOn(boolean b) {}
    public void setSystemGestureExclusionRects(java.util.List<android.graphics.Rect> r) {}
    public boolean onTouchEvent(MotionEvent e) { return false; }
    public void setStateListAnimator(Object o) {}
    public void setTag(Object o) {}
    public Object getTag() { return null; }
    public void setId(int i) {}
    public void setMinimumHeight(int h) {}
    public void setMinimumWidth(int w) {}
    public void setSelected(boolean b) {}
    public void setElevation(float e) {}
    public void setFocusableInTouchMode(boolean b) {}
    public boolean requestFocus() { return true; }
    public void clearFocus() {}
    public void setHapticFeedbackEnabled(boolean b) {}
    public void setOverScrollMode(int m) {}
    public static final int OVER_SCROLL_NEVER = 2;
    protected void onDraw(android.graphics.Canvas c) {}
    public android.os.IBinder getWindowToken() { return null; }
    protected void onSizeChanged(int w, int h, int ow, int oh) {}
    protected void onMeasure(int w, int h) {}
    public void setMeasuredDimension(int w, int h) {}
    public static int resolveSize(int a, int b) { return a; }
    public void setWillNotDraw(boolean b) {}
    public int getMeasuredWidth() { return 0; }
    public void setLayerType(int t, android.graphics.Paint p) {}
    public void setScaleX(float s) {} public void setScaleY(float s) {}
    public void setTranslationY(float y) {}
}
