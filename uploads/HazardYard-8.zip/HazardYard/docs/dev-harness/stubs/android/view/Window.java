package android.view;
public class Window {
    public void setDecorFitsSystemWindows(boolean b) {}
    public WindowManager.LayoutParams getAttributes() { return new WindowManager.LayoutParams(); }
    public void setAttributes(WindowManager.LayoutParams p) {}
    public WindowInsetsController getInsetsController() { return null; }
    public void addFlags(int f) {}
}
