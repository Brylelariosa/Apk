package android.view.inputmethod;
public class EditorInfo { public static final int IME_ACTION_DONE = 6, IME_ACTION_GO = 2, IME_FLAG_NO_EXTRACT_UI = 0x10000000; }
