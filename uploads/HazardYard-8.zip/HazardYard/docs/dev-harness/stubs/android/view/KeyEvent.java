package android.view;
public class KeyEvent { public static final int KEYCODE_ENTER = 66, ACTION_DOWN = 0; public int getKeyCode() { return 0; } public int getAction() { return 0; } }
