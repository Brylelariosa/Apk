package android.view;
public class WindowManager {
    public static class LayoutParams { public static final int LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS = 3; public int layoutInDisplayCutoutMode; }
}
