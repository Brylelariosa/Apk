package android.view.inputmethod;
public class InputMethodManager { public boolean showSoftInput(android.view.View v, int f) { return true; } public boolean hideSoftInputFromWindow(Object t, int f) { return true; } }
