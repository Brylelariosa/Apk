package android.view;
public class ViewGroup extends View {
    public static class LayoutParams {
        public static final int MATCH_PARENT = -1, WRAP_CONTENT = -2;
        public int width, height;
        public LayoutParams(int w, int h) { width = w; height = h; }
        public LayoutParams(LayoutParams o) { width = o.width; height = o.height; }
    }
    public static class MarginLayoutParams extends LayoutParams {
        public int leftMargin, topMargin, rightMargin, bottomMargin;
        public MarginLayoutParams(int w, int h) { super(w, h); }
        public MarginLayoutParams(LayoutParams o) { super(o); }
        public void setMargins(int l, int t, int r, int b) { leftMargin = l; topMargin = t; rightMargin = r; bottomMargin = b; }
    }
    public ViewGroup(android.content.Context c) { super(c); }
    public void addView(View v) {}
    public void addView(View v, int index) {}
    public void addView(View v, LayoutParams p) {}
    public void addView(View v, int w, int h) {}
    public void removeView(View v) {}
    public void removeAllViews() {}
    public int getChildCount() { return 0; }
    public View getChildAt(int i) { return null; }
    public void setClipChildren(boolean b) {}
    public void setClipToPadding(boolean b) {}
}
