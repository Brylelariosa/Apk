package android;
public final class R { public static final class attr { public static final int state_pressed = 1, state_selected = 2, state_enabled = 3; } }
