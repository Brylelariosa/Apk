package android.graphics;
import java.awt.image.BufferedImage;
public class Bitmap {
    public enum Config { ARGB_8888, RGB_565, ALPHA_8 }
    public final BufferedImage img;
    private Bitmap(BufferedImage i) { img = i; }
    public static Bitmap createBitmap(int w, int h, Config c) { return new Bitmap(new BufferedImage(Math.max(1, w), Math.max(1, h), BufferedImage.TYPE_INT_ARGB)); }
    public int getWidth() { return img.getWidth(); }
    public int getHeight() { return img.getHeight(); }
    public void recycle() {}
    public boolean isRecycled() { return false; }
    public void setPixel(int x, int y, int c) { img.setRGB(x, y, c); }
    public int getPixel(int x, int y) { return img.getRGB(x, y); }
    public void setPixels(int[] px, int off, int stride, int x, int y, int w, int h) { img.setRGB(x, y, w, h, px, off, stride); }
    public void eraseColor(int c) { java.awt.Graphics2D g = img.createGraphics(); g.setComposite(java.awt.AlphaComposite.Src); g.setColor(new java.awt.Color(c, true)); g.fillRect(0, 0, img.getWidth(), img.getHeight()); g.dispose(); }
}
