package android.graphics;
import java.awt.geom.Path2D;
public class Path {
    public enum FillType { WINDING, EVEN_ODD, INVERSE_WINDING, INVERSE_EVEN_ODD }
    public enum Direction { CW, CCW }
    public Path2D.Float p = new Path2D.Float();
    public Path() {}
    public void reset() { p = new Path2D.Float(); }
    public void rewind() { reset(); }
    public void moveTo(float x, float y) { p.moveTo(x, y); }
    public void lineTo(float x, float y) { if (p.getCurrentPoint() == null) p.moveTo(x, y); else p.lineTo(x, y); }
    public void quadTo(float x1, float y1, float x2, float y2) { p.quadTo(x1, y1, x2, y2); }
    public void cubicTo(float x1, float y1, float x2, float y2, float x3, float y3) { p.curveTo(x1, y1, x2, y2, x3, y3); }
    public void close() { if (p.getCurrentPoint() != null) p.closePath(); }
    public void setFillType(FillType t) { p.setWindingRule(t == FillType.EVEN_ODD ? Path2D.WIND_EVEN_ODD : Path2D.WIND_NON_ZERO); }
    public void addRect(float l, float t, float r, float b, Direction d) { p.append(new java.awt.geom.Rectangle2D.Float(l, t, r - l, b - t), false); }
    public void addCircle(float x, float y, float r, Direction d) { p.append(new java.awt.geom.Ellipse2D.Float(x - r, y - r, 2 * r, 2 * r), false); }
    public void addOval(float l, float t, float r, float b, Direction d) { p.append(new java.awt.geom.Ellipse2D.Float(l, t, r - l, b - t), false); }
    public void addRoundRect(float l, float t, float r, float b, float rx, float ry, Direction d) { p.append(new java.awt.geom.RoundRectangle2D.Float(l, t, r - l, b - t, rx * 2, ry * 2), false); }
    public boolean isEmpty() { return p.getCurrentPoint() == null; }
}
