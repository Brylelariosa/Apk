package android.graphics;
import java.awt.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.util.ArrayDeque;
public class Canvas {
    public final BufferedImage image;
    public final Graphics2D g;
    private final ArrayDeque<AffineTransform> txStack = new ArrayDeque<>();
    private final ArrayDeque<Shape> clipStack = new ArrayDeque<>();
    public Canvas(BufferedImage im) {
        image = im;
        g = im.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
    }
    public Canvas(Bitmap b) { this(b.img); }
    public int getWidth() { return image.getWidth(); }
    public int getHeight() { return image.getHeight(); }
    public int save() { txStack.push(g.getTransform()); clipStack.push(g.getClip() == null ? new Rectangle(-100000, -100000, 200000, 200000) : g.getClip()); return txStack.size(); }
    public void restore() { if (!txStack.isEmpty()) { g.setTransform(txStack.pop()); g.setClip(clipStack.pop()); } }
    public void translate(float x, float y) { g.translate(x, y); }
    public void rotate(float deg) { g.rotate(Math.toRadians(deg)); }
    public void rotate(float deg, float px, float py) { g.rotate(Math.toRadians(deg), px, py); }
    public void scale(float sx, float sy) { g.scale(sx, sy); }
    public void scale(float sx, float sy, float px, float py) { g.translate(px, py); g.scale(sx, sy); g.translate(-px, -py); }
    public void clipRect(float l, float t, float r, float b) { g.clip(new Rectangle2D.Float(l, t, r - l, b - t)); }
    public void clipRect(RectF r) { clipRect(r.left, r.top, r.right, r.bottom); }
    public void clipPath(Path p) { g.clip(p.p); }
    public void drawColor(int color) { Composite old = g.getComposite(); g.setComposite(AlphaComposite.SrcOver); g.setColor(new Color(color, true)); Shape cl = g.getClip(); g.setClip(null); AffineTransform t = g.getTransform(); g.setTransform(new AffineTransform()); g.fillRect(0, 0, image.getWidth(), image.getHeight()); g.setTransform(t); g.setClip(cl); g.setComposite(old); }
    private void apply(Paint p) {
        if (p.shader != null) g.setPaint(p.shader.awt()); else g.setColor(new Color(p.color, true));
    }
    private BasicStroke stroke(Paint p) {
        int cap = p.cap == Paint.Cap.ROUND ? BasicStroke.CAP_ROUND : (p.cap == Paint.Cap.SQUARE ? BasicStroke.CAP_SQUARE : BasicStroke.CAP_BUTT);
        int join = p.join == Paint.Join.ROUND ? BasicStroke.JOIN_ROUND : (p.join == Paint.Join.BEVEL ? BasicStroke.JOIN_BEVEL : BasicStroke.JOIN_MITER);
        return new BasicStroke(Math.max(0.001f, p.strokeWidth), cap, join, 10f);
    }
    private void shape(Shape s, Paint p) {
        apply(p);
        if (p.style == Paint.Style.FILL || p.style == Paint.Style.FILL_AND_STROKE) g.fill(s);
        if (p.style == Paint.Style.STROKE || p.style == Paint.Style.FILL_AND_STROKE) { g.setStroke(stroke(p)); g.draw(s); }
    }
    public void drawCircle(float cx, float cy, float r, Paint p) { shape(new Ellipse2D.Float(cx - r, cy - r, 2 * r, 2 * r), p); }
    public void drawRect(float l, float t, float r, float b, Paint p) { shape(new Rectangle2D.Float(l, t, r - l, b - t), p); }
    public void drawRect(RectF r, Paint p) { drawRect(r.left, r.top, r.right, r.bottom, p); }
    public void drawRoundRect(RectF r, float rx, float ry, Paint p) { shape(new RoundRectangle2D.Float(r.left, r.top, r.width(), r.height(), rx * 2, ry * 2), p); }
    public void drawRoundRect(float l, float t, float r, float b, float rx, float ry, Paint p) { shape(new RoundRectangle2D.Float(l, t, r - l, b - t, rx * 2, ry * 2), p); }
    public void drawOval(RectF r, Paint p) { shape(new Ellipse2D.Float(r.left, r.top, r.width(), r.height()), p); }
    public void drawOval(float l, float t, float r, float b, Paint p) { shape(new Ellipse2D.Float(l, t, r - l, b - t), p); }
    public void drawLine(float x0, float y0, float x1, float y1, Paint p) { apply(p); g.setStroke(stroke(p)); g.draw(new Line2D.Float(x0, y0, x1, y1)); }
    public void drawLines(float[] pts, int off, int count, Paint p) { for (int i = off; i + 3 < off + count; i += 4) drawLine(pts[i], pts[i + 1], pts[i + 2], pts[i + 3], p); }
    public void drawLines(float[] pts, Paint p) { drawLines(pts, 0, pts.length, p); }
    public void drawPath(Path path, Paint p) { shape(path.p, p); }
    public void drawArc(RectF r, float start, float sweep, boolean center, Paint p) { drawArc(r.left, r.top, r.right, r.bottom, start, sweep, center, p); }
    public void drawArc(float l, float t, float r, float b, float start, float sweep, boolean center, Paint p) {
        shape(new Arc2D.Float(l, t, r - l, b - t, -start, -sweep, center ? Arc2D.PIE : Arc2D.OPEN), p);
    }
    public void drawText(String s, float x, float y, Paint p) {
        apply(p);
        Font f = new Font(p.typeface.family, p.typeface.style == 1 ? Font.BOLD : Font.PLAIN, 1).deriveFont(p.textSize);
        g.setFont(f);
        float w = (float) f.getStringBounds(s, g.getFontRenderContext()).getWidth();
        float ox = p.align == Paint.Align.CENTER ? -w / 2 : (p.align == Paint.Align.RIGHT ? -w : 0);
        g.drawString(s, x + ox, y);
    }
    public void drawBitmap(Bitmap b, float x, float y, Paint p) { g.drawImage(b.img, Math.round(x), Math.round(y), null); }
    public void drawBitmap(Bitmap b, Rect src, RectF dst, Paint p) {
        if (src == null) g.drawImage(b.img, Math.round(dst.left), Math.round(dst.top), Math.round(dst.width()), Math.round(dst.height()), null);
        else g.drawImage(b.img, Math.round(dst.left), Math.round(dst.top), Math.round(dst.right), Math.round(dst.bottom), src.left, src.top, src.right, src.bottom, null);
    }
    public void drawBitmap(Bitmap b, Rect src, Rect dst, Paint p) { drawBitmap(b, src, new RectF(dst.left, dst.top, dst.right, dst.bottom), p); }
}
