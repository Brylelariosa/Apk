package android.graphics;
public class Paint {
    public static final int ANTI_ALIAS_FLAG = 1, FILTER_BITMAP_FLAG = 2, DITHER_FLAG = 4;
    public enum Style { FILL, STROKE, FILL_AND_STROKE }
    public enum Cap { BUTT, ROUND, SQUARE }
    public enum Join { MITER, ROUND, BEVEL }
    public enum Align { LEFT, CENTER, RIGHT }
    public int color = 0xFF000000;
    public Style style = Style.FILL;
    public float strokeWidth = 0f;
    public Cap cap = Cap.BUTT;
    public Join join = Join.MITER;
    public float textSize = 12f;
    public Align align = Align.LEFT;
    public Typeface typeface = Typeface.DEFAULT;
    public Shader shader;
    public boolean aa;
    public Paint() {}
    public Paint(int flags) { aa = (flags & ANTI_ALIAS_FLAG) != 0; }
    public void setColor(int c) { color = c; }
    public int getColor() { return color; }
    public void setAlpha(int a) { color = (color & 0x00FFFFFF) | ((a & 255) << 24); }
    public int getAlpha() { return color >>> 24; }
    public void setStyle(Style s) { style = s; }
    public void setStrokeWidth(float w) { strokeWidth = w; }
    public void setStrokeCap(Cap c) { cap = c; }
    public void setStrokeJoin(Join j) { join = j; }
    public void setTextSize(float s) { textSize = s; }
    public float getTextSize() { return textSize; }
    public void setTextAlign(Align a) { align = a; }
    public Typeface setTypeface(Typeface t) { typeface = t; return t; }
    public Shader setShader(Shader s) { shader = s; return s; }
    public void setAntiAlias(boolean b) { aa = b; }
    public void setFilterBitmap(boolean b) {}
    public void setDither(boolean b) {}
    public void setShadowLayer(float r, float dx, float dy, int c) {}
    public void setFakeBoldText(boolean b) {}
    public float measureText(String s) {
        java.awt.Font f = new java.awt.Font(typeface.family, typeface.style == 1 ? java.awt.Font.BOLD : java.awt.Font.PLAIN, 1).deriveFont(textSize);
        java.awt.font.FontRenderContext frc = new java.awt.font.FontRenderContext(null, true, true);
        return (float) f.getStringBounds(s, frc).getWidth();
    }
    public float measureText(String s, int a, int b) { return measureText(s.substring(a, b)); }
    public static class FontMetrics { public float ascent, descent, top, bottom, leading; }
    public FontMetrics getFontMetrics() { FontMetrics m = new FontMetrics(); m.ascent = -textSize * 0.9f; m.descent = textSize * 0.25f; m.top = m.ascent; m.bottom = m.descent; return m; }
}
