package android.graphics;
public abstract class Shader {
    public enum TileMode { CLAMP, REPEAT, MIRROR }
    public abstract java.awt.Paint awt();
}
