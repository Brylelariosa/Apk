package android.graphics;
import java.awt.geom.Point2D;
public class LinearGradient extends Shader {
    private final java.awt.Paint p;
    public LinearGradient(float x0, float y0, float x1, float y1, int c0, int c1, TileMode tile) {
        p = new java.awt.GradientPaint(x0, y0, new java.awt.Color(c0, true), x1, y1, new java.awt.Color(c1, true));
    }
    public LinearGradient(float x0, float y0, float x1, float y1, int[] colors, float[] stops, TileMode tile) {
        java.awt.Color[] cs = new java.awt.Color[colors.length];
        for (int i = 0; i < cs.length; i++) cs[i] = new java.awt.Color(colors[i], true);
        float[] st = stops;
        if (st == null) { st = new float[colors.length]; for (int i = 0; i < st.length; i++) st[i] = i / (float) (st.length - 1); }
        float[] fixed = st.clone();
        for (int i = 1; i < fixed.length; i++) if (fixed[i] <= fixed[i - 1]) fixed[i] = fixed[i - 1] + 1e-4f;
        p = new java.awt.LinearGradientPaint(new Point2D.Float(x0, y0), new Point2D.Float(x1, y1), fixed, cs);
    }
    @Override public java.awt.Paint awt() { return p; }
}
