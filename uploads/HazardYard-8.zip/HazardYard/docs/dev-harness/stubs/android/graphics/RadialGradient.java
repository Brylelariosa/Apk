package android.graphics;
import java.awt.geom.Point2D;
public class RadialGradient extends Shader {
    private final java.awt.RadialGradientPaint p;
    public RadialGradient(float cx, float cy, float radius, int[] colors, float[] stops, TileMode tile) {
        java.awt.Color[] cs = new java.awt.Color[colors.length];
        for (int i = 0; i < cs.length; i++) cs[i] = new java.awt.Color(colors[i], true);
        float[] st = stops;
        if (st == null) { st = new float[colors.length]; for (int i = 0; i < st.length; i++) st[i] = i / (float) (st.length - 1); }
        // AWT needs strictly increasing fractions
        float[] fixed = st.clone();
        for (int i = 1; i < fixed.length; i++) if (fixed[i] <= fixed[i - 1]) fixed[i] = fixed[i - 1] + 1e-4f;
        p = new java.awt.RadialGradientPaint(new Point2D.Float(cx, cy), Math.max(0.01f, radius), new Point2D.Float(cx, cy), fixed, cs, java.awt.MultipleGradientPaint.CycleMethod.NO_CYCLE);
    }
    public RadialGradient(float cx, float cy, float radius, int c0, int c1, TileMode tile) {
        this(cx, cy, radius, new int[] {c0, c1}, new float[] {0f, 1f}, tile);
    }
    @Override public java.awt.Paint awt() { return p; }
}
