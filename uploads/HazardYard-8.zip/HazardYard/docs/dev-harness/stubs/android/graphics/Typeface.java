package android.graphics;
public class Typeface {
    public static final int NORMAL = 0, BOLD = 1, ITALIC = 2, BOLD_ITALIC = 3;
    public static final Typeface DEFAULT = new Typeface("SansSerif", 0);
    public static final Typeface DEFAULT_BOLD = new Typeface("SansSerif", 1);
    public static final Typeface SANS_SERIF = DEFAULT;
    public static final Typeface MONOSPACE = new Typeface("Monospaced", 0);
    public final String family; public final int style;
    private Typeface(String f, int s) { family = f; style = s; }
    public static Typeface create(String family, int style) {
        String f = "SansSerif";
        if (family != null && family.contains("condensed")) f = "DejaVu Sans Condensed";
        if (family != null && family.contains("medium")) f = "SansSerif";
        int st = style;
        if (family != null && family.contains("medium") && style == 0) st = 0;
        return new Typeface(f, st);
    }
    public static Typeface create(Typeface t, int style) { return new Typeface(t == null ? "SansSerif" : t.family, style); }
}
