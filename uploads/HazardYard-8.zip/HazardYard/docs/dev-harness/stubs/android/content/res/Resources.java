package android.content.res;
public class Resources {
    public static class DM { public float density = 2.6f; public float scaledDensity = 2.6f; public int widthPixels = 1800, heightPixels = 810; }
    public DM getDisplayMetrics() { return new DM(); }
    public Configuration getConfiguration() { return new Configuration(); }
}
