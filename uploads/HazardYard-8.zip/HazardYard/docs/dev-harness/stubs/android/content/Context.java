package android.content;
public class Context {
    public static final int MODE_PRIVATE = 0;
    public static final String WIFI_SERVICE = "wifi", INPUT_METHOD_SERVICE = "input_method", WINDOW_SERVICE = "window";
    public SharedPreferences getSharedPreferences(String n, int m) { return new SharedPreferences(); }
    public android.content.res.Resources getResources() { return new android.content.res.Resources(); }
    public Object getSystemService(String n) { return null; }
    public Context getApplicationContext() { return this; }
    public Context createConfigurationContext(android.content.res.Configuration c) { return this; }
    protected void attachBaseContext(Context base) {}
    public String getPackageName() { return "x"; }
}
