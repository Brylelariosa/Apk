package android.content;
public class SharedPreferences {
    public static class Editor {
        public Editor putInt(String k, int v) { return this; }
        public Editor putString(String k, String v) { return this; }
        public Editor putBoolean(String k, boolean v) { return this; }
        public Editor putFloat(String k, float v) { return this; }
        public Editor putLong(String k, long v) { return this; }
        public Editor remove(String k) { return this; }
        public void apply() {}
        public boolean commit() { return true; }
    }
    public int getInt(String k, int d) { return d; }
    public String getString(String k, String d) { return d; }
    public boolean getBoolean(String k, boolean d) { return d; }
    public float getFloat(String k, float d) { return d; }
    public long getLong(String k, long d) { return d; }
    public boolean contains(String k) { return false; }
    public Editor edit() { return new Editor(); }
}
