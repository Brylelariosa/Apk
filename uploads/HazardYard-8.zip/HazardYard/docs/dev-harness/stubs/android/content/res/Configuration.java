package android.content.res;
public class Configuration { public int orientation; public int screenWidthDp, screenHeightDp; public float fontScale = 1f; public Configuration() {} public Configuration(Configuration o) {} }
