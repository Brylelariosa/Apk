package android.media;
public class AudioTrack {
    public static final int MODE_STREAM = 1, PERFORMANCE_MODE_LOW_LATENCY = 1;
    public static int getMinBufferSize(int r, int c, int e) { return 4096; }
    public AudioTrack(AudioAttributes a, AudioFormat f, int b, int mode, int session) {}
    public static class Builder {
        public Builder setAudioAttributes(AudioAttributes a) { return this; }
        public Builder setAudioFormat(AudioFormat f) { return this; }
        public Builder setBufferSizeInBytes(int b) { return this; }
        public Builder setTransferMode(int m) { return this; }
        public Builder setPerformanceMode(int m) { return this; }
        public AudioTrack build() { return new AudioTrack(null, null, 0, 0, 0); }
    }
    public void play() {}
    public void stop() {}
    public void pause() {}
    public void flush() {}
    public void release() {}
    public int write(short[] d, int off, int n) { return n; }
    public int write(byte[] d, int off, int n) { return n; }
    public int getBufferSizeInFrames() { return 2048; }
    public int setBufferSizeInFrames(int f) { return f; }
    public int getUnderrunCount() { return 0; }
    public int getPlaybackHeadPosition() { return 0; }
    public int getState() { return 1; }
    public int getPlayState() { return 3; }
}
