package android.os;
public class HandlerThread extends Thread { public HandlerThread(String n) { super(n); }
    public HandlerThread(String n, int p) { super(n); } public Looper getLooper() { return new Looper(); } public boolean quitSafely() { return true; } }
