package android.widget;
public class SeekBar extends android.view.View {
    public interface OnSeekBarChangeListener { void onProgressChanged(SeekBar s, int p, boolean u); void onStartTrackingTouch(SeekBar s); void onStopTrackingTouch(SeekBar s); }
    public SeekBar(android.content.Context c) { super(c); }
    public void setMax(int m) {} public void setProgress(int p) {} public int getProgress() { return 0; }
    public void setOnSeekBarChangeListener(OnSeekBarChangeListener l) {}
    public void setProgressTintList(android.content.res.ColorStateList l) {}
    public void setThumbTintList(android.content.res.ColorStateList l) {}
    public void setProgressBackgroundTintList(android.content.res.ColorStateList l) {}
}
