package android.widget;
public class TextView extends android.view.View {
    public TextView(android.content.Context c) { super(c); }
    public void setText(CharSequence s) {}
    public CharSequence getText() { return ""; }
    public void setTextSize(int unit, float s) {}
    public void setTextSize(float s) {}
    public void setTextColor(int c) {}
    public void setTextColor(android.content.res.ColorStateList c) {}
    public void setTypeface(android.graphics.Typeface t) {}
    public void setIncludeFontPadding(boolean b) {}
    public void setGravity(int g) {}
    public void setSingleLine(boolean b) {}
    public void setSingleLine() {}
    public void setMaxLines(int n) {}
    public void setLines(int n) {}
    public void setAllCaps(boolean b) {}
    public void setMinHeight(int h) {}
    public void setHint(CharSequence s) {}
    public void setHintTextColor(int c) {}
    public void setLineSpacing(float a, float b) {}
    public void setEllipsize(Object e) {}
    public void setInputType(int t) {}
    public void setImeOptions(int o) {}
    public void setFilters(android.text.InputFilter[] f) {}
    public void addTextChangedListener(android.text.TextWatcher w) {}
    public void setOnEditorActionListener(OnEditorActionListener l) {}
    public void setCompoundDrawablePadding(int p) {}
    public void setSelectAllOnFocus(boolean b) {}
    public void setLetterSpacing(float s) {}
    public void setShadowLayer(float r, float dx, float dy, int c) {}
    public void setTextAlignment(int a) {}
    public interface OnEditorActionListener { boolean onEditorAction(TextView v, int actionId, android.view.KeyEvent e); }
}
