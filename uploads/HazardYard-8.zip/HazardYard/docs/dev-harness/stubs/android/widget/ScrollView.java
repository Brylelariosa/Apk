package android.widget;
public class ScrollView extends FrameLayout {
    public static class LayoutParams extends FrameLayout.LayoutParams { public LayoutParams(int w, int h) { super(w, h); } }
    public ScrollView(android.content.Context c) { super(c); }
    public void setVerticalScrollBarEnabled(boolean b) {}
    public void setFillViewport(boolean b) {}
    public void scrollTo(int x, int y) {}
    public void smoothScrollTo(int x, int y) {}
}
