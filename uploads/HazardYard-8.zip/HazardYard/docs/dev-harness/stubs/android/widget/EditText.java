package android.widget;
public class EditText extends TextView {
    public EditText(android.content.Context c) { super(c); }
    public android.text.Editable getText() { return null; }
    public void setSelection(int n) {}
    public void selectAll() {}
    public void setText(CharSequence s) {}
}
