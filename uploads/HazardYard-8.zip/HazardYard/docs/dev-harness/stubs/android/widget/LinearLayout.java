package android.widget;
public class LinearLayout extends android.view.ViewGroup {
    public static final int HORIZONTAL = 0, VERTICAL = 1;
    public static class LayoutParams extends MarginLayoutParams {
        public float weight; public int gravity;
        public LayoutParams(int w, int h) { super(w, h); }
        public LayoutParams(int w, int h, float wt) { super(w, h); weight = wt; }
    }
    public LinearLayout(android.content.Context c) { super(c); }
    public void setOrientation(int o) {}
    public void setGravity(int g) {}
    public void setWeightSum(float f) {}
}
