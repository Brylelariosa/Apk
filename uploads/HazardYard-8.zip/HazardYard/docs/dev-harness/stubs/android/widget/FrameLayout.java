package android.widget;
public class FrameLayout extends android.view.ViewGroup {
    public static class LayoutParams extends MarginLayoutParams {
        public int gravity;
        public LayoutParams(int w, int h) { super(w, h); }
        public LayoutParams(int w, int h, int g) { super(w, h); gravity = g; }
    }
    public FrameLayout(android.content.Context c) { super(c); }
}
