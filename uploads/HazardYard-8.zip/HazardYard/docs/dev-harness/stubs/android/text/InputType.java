package android.text;
public class InputType { public static final int TYPE_CLASS_TEXT = 1, TYPE_TEXT_FLAG_NO_SUGGESTIONS = 2, TYPE_TEXT_VARIATION_VISIBLE_PASSWORD = 4, TYPE_CLASS_NUMBER = 8, TYPE_CLASS_PHONE = 3; }
