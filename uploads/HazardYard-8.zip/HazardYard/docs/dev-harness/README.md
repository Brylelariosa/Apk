# Dev harness (not part of the app)

Lets you compile the whole game and run its logic with only a JDK, no Android SDK:

- `stubs/` : minimal stand-ins for the Android framework classes the game uses. `android.graphics` (Canvas, Paint, Path,
  gradients, Bitmap) is backed by Java2D, so the real renderer draws real frames into a `BufferedImage`.
- `compile.sh [srcdir]` : compiles stubs + `app/src/main/java` into `out/` (a JRE alone is enough:
  `java -m jdk.compiler/com.sun.tools.javac.Main`).
- `tools/` : tests and screenshot makers that run on top of that (compile with `-cp out`, run with `-cp out:tools_out`):
  - `CombatTest` : bat reach / direction / knock-back / knock-down / death -> ragdoll
  - `GearTest` : two weapons, per-weapon ammo and reload accounting, backpack caps, ammo crate, armour
  - `CodecTest` : snapshot gear fields and zombie state / event round-trips on the wire
  - `UiTest` : bag, close button vs pause button, drag and drop, spectator buttons
  - `DoorTest` : every Battleground house has a doorway and every doorway leads outside
  - `DropTest` : the Battleground drop (choice, fall, steering, landing), loot from a fallen bot, a replaced gun on the ground
  - `NetDropTest`, `NetSurvTest` : host + client over a real loopback socket: the drop choice, the fall, dropped loot, hosted survival
  - `MeleeStats` : many seeded duels per weapon (walkers, runners, a brute); `MeleeSheet` (+ `melee-sheet.sh`) : contact sheet of any attack
  - `RespawnSweep`, `DeadShot` : survival deaths over many worlds and the frames while dead; `RenderBench` : draw time of the world renderer
  - `ZoneTest`, `Sweep` : whole Battleground matches (1, 3, 7 bots) and ten-minute survival sessions, nothing may throw
  - `Shot`, `Fight`, `BagShot`, `BgShot`, `SpecShot`, `DoorShot`, `BgDoor`, `CarShot`, `Turn`, `Seq`, `PoseSheet` :
    render the PNGs used in `docs/`

Run `ZoneTest`, `Sweep` and the tests again after any change to `core/` or `survival/`.
