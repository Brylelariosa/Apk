# Dev harness (not part of the app)

Lets you compile the whole game and run its logic with only a JDK, no Android SDK:

- `stubs/` : minimal stand-ins for the Android framework classes the game uses. `android.graphics` (Canvas, Paint, Path,
  gradients, Bitmap) is backed by Java2D, so the real renderer draws real frames into a `BufferedImage`.
- `compile.sh [srcdir]` : compiles stubs + `app/src/main/java` into `out/` (a JRE alone is enough:
  `java -m jdk.compiler/com.sun.tools.javac.Main`).
- `tools/` : tests and screenshot makers that run on top of that (compile with `-cp out`, run with `-cp out:tools_out`):
  - `CombatTest` : bat reach / direction / knock-back / knock-down / death -> ragdoll
  - `GearTest` : two weapons, per-weapon ammo and reload accounting, backpack caps, ammo crate, armour
  - `CodecTest` : snapshot gear fields and zombie state / event round-trips on the wire
  - `UiTest` : bag, close button vs pause button, drag and drop, spectator buttons
  - `DoorTest` : every Battleground house has a doorway and every doorway leads outside
  - `ZoneTest`, `Sweep` : whole Battleground matches (1, 3, 7 bots) and ten-minute survival sessions, nothing may throw
  - `Shot`, `Fight`, `BagShot`, `BgShot`, `SpecShot`, `DoorShot`, `BgDoor`, `CarShot`, `Turn`, `Seq`, `PoseSheet` :
    render the PNGs used in `docs/`

Run `ZoneTest`, `Sweep` and the tests again after any change to `core/` or `survival/`.
