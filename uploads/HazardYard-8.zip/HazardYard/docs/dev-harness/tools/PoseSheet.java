package com.hazardyard.game.render;
import android.graphics.*;
import com.hazardyard.game.core.*;
import com.hazardyard.game.survival.*;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

public class PoseSheet {
    public static void main(String[] a) throws Exception {
        System.setProperty("java.awt.headless", "true");
        String out = a.length > 0 ? a[0] : "/tmp/poses.png";
        float zoom = a.length > 2 ? Float.parseFloat(a[2]) : 3.2f;
        int cols = 11, rows = a.length > 3 ? Integer.parseInt(a[3]) : 3;
        int cw = 62, ch = 74;
        int W = (int) (cols * cw * zoom), H = (int) (rows * ch * zoom);
        BufferedImage img = new BufferedImage(W, H, BufferedImage.TYPE_INT_ARGB);
        Canvas c = new Canvas(img);
        c.drawColor(0xFF5A8F46);
        PuppetRenderer pr = new PuppetRenderer(new PolyDrawer());
        Puppet pu = new Puppet();
        PuppetStyle style = new PuppetStyle();
        float[] wx = new float[Puppet.JOINTS], wy = new float[Puppet.JOINTS], wz = new float[Puppet.JOINTS];
        // states: {anim, t/phase param}
        String[] names = {"idle", "walk.0", "walk.2", "run.0", "run.2", "atk.25", "atk.55", "atk.8", "hit", "stumble", "fall.3"};
        for (int r = 0; r < rows; r++) {
            for (int col = 0; col < cols; col++) {
                int type = r;
                ZombieLook.fill(type, ZombieLook.lookOf(7 + col * 3 + r * 11), style);
                pu.scale = style.scale; pu.width = style.width; pu.build = style.build;
                pu.seed = ((col * 37 + r * 11) % 100) / 100f;
                pu.clock = 1.3f + col; pu.gait = 0; pu.t = 0; pu.hitT = 9f; pu.hitK = 0; pu.attackP = 0; pu.reach = 1f;
                pu.fallX = -1; pu.fallY = 0;
                switch (col) {
                    case 0: pu.anim = Puppet.A_IDLE; break;
                    case 1: pu.anim = Puppet.A_WALK; pu.gait = 1f; pu.phase = 0.4f; break;
                    case 2: pu.anim = Puppet.A_WALK; pu.gait = 1f; pu.phase = 2.4f; break;
                    case 3: pu.anim = Puppet.A_RUN; pu.gait = 1.4f; pu.phase = 0.6f; break;
                    case 4: pu.anim = Puppet.A_RUN; pu.gait = 1.4f; pu.phase = 2.6f; break;
                    case 5: pu.anim = Puppet.A_ATTACK; pu.attackP = 0.25f; break;
                    case 6: pu.anim = Puppet.A_ATTACK; pu.attackP = 0.55f; break;
                    case 7: pu.anim = Puppet.A_ATTACK; pu.attackP = 0.85f; break;
                    case 8: pu.anim = Puppet.A_HIT; pu.hitX = -1; pu.hitY = 0; pu.hitK = 1f; pu.hitT = 0.07f; break;
                    case 9: pu.anim = Puppet.A_STUMBLE; pu.hitX = -0.6f; pu.hitY = 0.8f; pu.t = 0.3f; break;
                    case 10: pu.anim = Puppet.A_FALL; pu.t = 0.25f; pu.fallX = -1; pu.fallY = 0; break;
                }
                pu.compute();
                float aim = 0f; // facing east
                if (a.length > 1 && a[1].equals("south")) aim = (float) Math.PI / 2;
                pu.toWorld(0, 0, aim, wx, wy, wz);
                c.save();
                c.translate((col * cw + cw * 0.5f) * zoom, (r * ch + ch * 0.62f) * zoom);
                c.scale(zoom, zoom);
                pr.draw(c, wx, wy, wz, style, 0f, 1f, 2);
                c.restore();
                Paint p = new Paint(); p.setColor(0xFFFFFFFF); p.setTextSize(11); 
                c.drawText(names[col], col * cw * zoom + 6, (r * ch + 10) * zoom * 0.5f + 12, p);
            }
        }
        ImageIO.write(img, "png", new File(out));
        System.out.println("ok " + W + "x" + H);
    }
}
