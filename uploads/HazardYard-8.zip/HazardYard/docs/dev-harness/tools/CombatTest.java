import com.hazardyard.game.core.*;
import com.hazardyard.game.engine.*;
import com.hazardyard.game.survival.*;

public class CombatTest {
    static int fails = 0;
    static void check(boolean ok, String what) { System.out.println((ok ? "PASS " : "FAIL ") + what); if (!ok) fails++; }

    public static void main(String[] a) throws Exception {
        SoloEngine eng = new SoloEngine(GameMode.SURVIVAL, 0, 3, 1, "Bru", 99);
        GameState st = eng.state();
        SurvivalState sv = st.survival;
        LocalInput li = new LocalInput();
        Player me = st.local();
        for (int i = 0; i < 400; i++) eng.fixedUpdate(1f / 60f, li);
        // clear the board
        for (Zombie z : sv.zombies) z.active = false;
        // find open ground: move the player to a spot and make sure it is open by testing
        float px = me.x, py = me.y;
        System.out.println("player at " + px + "," + py);
        // give the player a bat in slot 0
        sv.inv[0].item[0] = WeaponDef.BAT; sv.inv[0].count[0] = 1; sv.inv[0].selected = 0;
        // run 2 ticks so the engine equips the selected item
        for (int i = 0; i < 4; i++) eng.fixedUpdate(1f / 60f, li);
        check(me.weapon.def.id == WeaponDef.BAT, "bat equipped (got " + me.weapon.def.name + ")");
        MeleeProfile prof = me.weapon.def.profile;
        check(prof != null && prof.attacks.length == 4, "bat has a 4-attack combo (swing, backhand, overhead, spin)");

        // Place a zombie straight ahead (east), at 40 units; face east
        me.aim = 0f; me.aimTarget = 0f;
        Zombie z = spawn(sv, 1, px + 40f, py, Zombie.WALKER);
        li.aim = 0f; li.firing = true;
        float zy0 = z.y;
        // swing 1: variant 0 = left-to-right => pushes to the attacker's right = +y when facing east (+x)
        int var0 = -1;
        for (int i = 0; i < 90 && z.hp == Zombie.maxHp(Zombie.WALKER); i++) { eng.fixedUpdate(1f / 60f, li); if (var0 < 0 && me.swingT < 0.2f) var0 = me.swingVariant; }
        li.firing = false;
        for (int i = 0; i < 40; i++) eng.fixedUpdate(1f / 60f, li);
        System.out.println("after swing: variant " + var0 + " zombie hp " + z.hp + " pos " + z.x + "," + z.y + " state " + z.state + " vx " + z.vx + " vy " + z.vy);
        check(var0 == MeleeProfile.SWING_LR || var0 == 0, "first swing is the left-to-right one");
        check(z.hp < Zombie.maxHp(Zombie.WALKER), "zombie took damage");
        check(z.y - zy0 > 6f, "left-to-right swing pushed the zombie to the attacker's right (+y), moved " + (z.y - zy0));
        check(z.x - (px + 40f) > 2f, "...and also away from the attacker");

        // reach: a zombie out of range must not be hit
        for (Zombie q : sv.zombies) q.active = false;
        me.x = px; me.y = py;
        for (int i = 0; i < 80; i++) eng.fixedUpdate(1f / 60f, li);   // let the combo window lapse
        Zombie far = spawn(sv, 2, px + 120f, py, Zombie.WALKER);
        far.stunT = 100f; // keep it standing still and harmless
        li.firing = true;
        for (int i = 0; i < 60; i++) eng.fixedUpdate(1f / 60f, li);
        li.firing = false;
        check(far.hp == Zombie.maxHp(Zombie.WALKER), "a zombie 120 units away is not hit by a bat (reach " + me.weapon.def.reach + ")");

        // a zombie behind the player is not hit
        for (Zombie q : sv.zombies) q.active = false;
        Zombie behind = spawn(sv, 3, px - 35f, py, Zombie.WALKER);
        behind.stunT = 100f;
        li.firing = true;
        for (int i = 0; i < 60; i++) eng.fixedUpdate(1f / 60f, li);
        li.firing = false;
        check(behind.hp == Zombie.maxHp(Zombie.WALKER), "a zombie behind the player is not hit");

        // knockdown & death: smash a zombie repeatedly, count events
        for (Zombie q : sv.zombies) q.active = false;
        Zombie t = spawn(sv, 4, px + 36f, py, Zombie.WALKER);
        t.hp = 400; // survive long enough to see a knockdown
        t.stunT = 0f;
        int downs = 0, stumbles = 0;
        li.firing = true;
        boolean everDown = false, everStumble = false;
        for (int i = 0; i < 60 * 12; i++) {
            eng.fixedUpdate(1f / 60f, li);
            if (t.state == Puppet.A_FALL || t.state == Puppet.A_DOWN) everDown = true;
            if (t.state == Puppet.A_STUMBLE) everStumble = true;
            // keep it in front of the bat
            if (t.isDownish() == false && t.active) { t.x = px + 36f; t.y = py; }
            if (t.hp <= 0) break;
        }
        li.firing = false;
        check(everStumble, "bat hits make a zombie stumble");
        check(everDown, "heavy bat hits eventually knock a zombie down");
        // ragdoll on death
        for (Zombie q : sv.zombies) q.active = false;
        Zombie d = spawn(sv, 5, px + 36f, py, Zombie.WALKER);
        d.hp = 5;
        li.firing = true;
        for (int i = 0; i < 90 && d.active; i++) eng.fixedUpdate(1f / 60f, li);
        li.firing = false;
        check(!d.active, "killed zombie is removed");
        check(st.ragdolls.activeCount() >= 1, "a ragdoll was spawned for the kill (" + st.ragdolls.activeCount() + ")");
        // let the ragdoll settle and check it moved away along the blow and came to rest
        int ri = -1; for (int i = 0; i < Ragdolls.MAX; i++) if (st.ragdolls.active[i]) ri = i;
        float hx0 = st.ragdolls.x[ri][Puppet.J_HIP_L];
        for (int i = 0; i < 60 * 4; i++) eng.fixedUpdate(1f / 60f, li);
        float hz = st.ragdolls.z[ri][Puppet.J_HEAD];
        System.out.println("ragdoll head z after settling: " + hz + " hip x moved " + (st.ragdolls.x[ri][Puppet.J_HIP_L] - hx0));
        check(hz < 8f, "ragdoll lies on the ground (head height " + hz + ")");
        System.out.println(fails == 0 ? "ALL PASSED" : (fails + " FAILED"));
        System.exit(fails == 0 ? 0 : 1);
    }

    public static Zombie spawnAt(SurvivalState sv, int id, float x, float y, int type) { Zombie z = spawn(sv, id, x, y, type); z.target = 0; z.attackCd = 0.2f; return z; }
    static Zombie spawn(SurvivalState sv, int id, float x, float y, int type) {
        for (Zombie z : sv.zombies) if (!z.active) {
            z.active = true; z.id = id; z.type = type; z.x = z.rx = x; z.y = z.ry = y; z.aim = z.rAim = (float) Math.PI;
            z.hp = Zombie.maxHp(type); z.state = Puppet.A_IDLE; z.stateT = 0; z.vx = z.vy = 0; z.stunT = 0; z.downT = 0; z.windT = 0;
            z.target = -1; z.attackCd = 5f; z.hitT = 9f; z.dying = false;
            return z;
        }
        throw new RuntimeException("no free zombie");
    }
}
