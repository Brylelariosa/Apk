import com.hazardyard.game.core.*;
import com.hazardyard.game.engine.*;
public class Dbg {
    public static void main(String[] a) {
        SoloEngine eng = new SoloEngine(GameMode.SURVIVAL, 0, 3, 1, "Bru", 1234);
        GameState st = eng.state();
        LocalInput li = new LocalInput();
        Player me = st.local();
        System.out.println("phase " + st.phase + " alive " + me.alive + " connected " + me.connected + " pos " + me.x + "," + me.y + " r " + me.rx + "," + me.ry + " viewId " + st.viewId);
        for (int i = 0; i < 300; i++) eng.fixedUpdate(1f / 60f, li);
        eng.frameUpdate(1f/60f, 1f);
        System.out.println("phase " + st.phase + " alive " + me.alive + " pos " + me.x + "," + me.y + " r " + me.rx + "," + me.ry + " hp " + me.health);
    }
}
