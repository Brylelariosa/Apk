import com.hazardyard.game.core.*;
import com.hazardyard.game.engine.*;
public class SpawnDbg {
    public static void main(String[] a) {
        for (int seed : new int[] {1, 2, 3, 99, 1234, 777}) {
            SoloEngine eng = new SoloEngine(GameMode.SURVIVAL, 0, 3, 1, "Bru", seed);
            Player me = eng.state().local();
            System.out.println("seed " + seed + " spawn " + me.x + "," + me.y);
        }
    }
}
