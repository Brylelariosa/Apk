import com.hazardyard.game.core.*;
import com.hazardyard.game.engine.*;
import com.hazardyard.game.survival.*;
public class CarDbg {
    public static void main(String[] a) {
        SoloEngine eng = new SoloEngine(GameMode.SURVIVAL, 0, 3, 1, "Bru", 1234);
        GameState st = eng.state(); SurvivalState sv = st.survival; LocalInput li = new LocalInput();
        for (int i = 0; i < 400; i++) eng.fixedUpdate(1f / 60f, li);
        System.out.println("cars " + sv.cars.length);
        Player me = st.local();
        Car car = sv.cars[0]; car.active = true; car.x = car.rx = me.x; car.y = car.ry = me.y - 80;
        System.out.println("active " + car.active + " at " + car.rx + "," + car.ry + " player " + me.x + "," + me.y);
        for (int i = 0; i < 3; i++) eng.fixedUpdate(1f / 60f, li);
        System.out.println("after ticks active " + car.active + " at " + car.x + "," + car.y);
        Camera cam = new Camera(); cam.setViewport(1800, 810, 1e9f, 1e9f); cam.snapZoom(2.4f); cam.snapTo(me.x, me.y);
        System.out.println("visible " + cam.isVisible(car.rx, car.ry, 80f));
    }
}
