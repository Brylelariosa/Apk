import com.hazardyard.game.survival.*;
public class FindTrees {
    public static void main(String[] a) {
        SurvivalTerrain t = new SurvivalTerrain(1234);
        int best = 0, bx = 0, by = 0;
        for (int y = -80; y < 120; y += 4) for (int x = -80; x < 140; x += 4) {
            int n = 0; boolean hasPine = false;
            for (int j = 0; j < 8; j++) for (int i = 0; i < 14; i++) if (t.objAt(x + i, y + j) == Obj.TREE) n++;
            if (n > best) { best = n; bx = x + 7; by = y + 4; }
        }
        System.out.println(best + " trees around tile " + bx + "," + by + " -> world " + (bx * 32) + " " + (by * 32));
    }
}
