import android.graphics.Canvas;
import com.hazardyard.game.core.*;
import com.hazardyard.game.engine.*;
import com.hazardyard.game.input.InputController;
import com.hazardyard.game.render.*;
import com.hazardyard.game.settings.GameSettings;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

public class Shot {
    public static void main(String[] a) throws Exception {
        System.setProperty("java.awt.headless", "true");
        String mode = a.length > 0 ? a[0] : "survival";
        String out = a.length > 1 ? a[1] : "/tmp/shot.png";
        float px = a.length > 2 ? Float.parseFloat(a[2]) : Float.NaN;
        float py = a.length > 3 ? Float.parseFloat(a[3]) : Float.NaN;
        int W = 1800, H = 810;
        float d = 2.6f;
        GameSettings gs = new GameSettings();
        InputController in = new InputController(gs.controls);
        in.setViewport(W, H, d, 0, 0, 0, 0);
        in.survivalUi.active = mode.equals("survival");
        int modeId = mode.equals("survival") ? GameMode.SURVIVAL : (mode.equals("bg") ? GameMode.BATTLEGROUND : GameMode.CLASSIC);
        SoloEngine eng = new SoloEngine(modeId, 0, 3, 1, "Bru", 1234);
        GameState st = eng.state();
        LocalInput li = new LocalInput();
        Player me = st.local();
        if (!Float.isNaN(px)) { me.x = px; me.y = py; me.rx = px; me.ry = py; }
        if (modeId == GameMode.BATTLEGROUND) { li.dropConfirm = true; eng.fixedUpdate(1f / 60f, li); li.dropConfirm = false; }
        for (int i = 0; i < 60 * 5; i++) eng.fixedUpdate(1f / 60f, li);
        eng.frameUpdate(1f / 60f, 1f);
        Camera cam = new Camera();
        cam.setUnbounded(st.survival != null); cam.setViewport(W, H, st.survival != null ? 1e9f : st.map.worldW, st.survival != null ? 1e9f : st.map.worldH);
        cam.snapZoom(a.length > 4 ? Float.parseFloat(a[4]) : me.weapon.def.zoom);
        cam.snapTo(me.rx, me.ry);
        BufferedImage img = new BufferedImage(W, H, BufferedImage.TYPE_INT_ARGB);
        Canvas c = new Canvas(img);
        Renderer r = new Renderer(gs);
        HudRenderer hud = new HudRenderer();
        float time = 3f;
        for (int k = 0; k < 40; k++) { r.draw(c, st, cam, time); time += 0.016f; }
        if (a.length < 6) hud.draw(c, st, cam, in, 0, d, time);
        ImageIO.write(img, "png", new File(out));
        System.out.println("wrote " + out + " player at " + me.x + "," + me.y);
    }
}
