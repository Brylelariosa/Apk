import com.hazardyard.game.core.*;
import com.hazardyard.game.engine.*;
import com.hazardyard.game.survival.*;

public class RespawnSweep {
    public static void main(String[] a) throws Exception {
        int bad = 0, fallback = 0, n = 150; double maxD = 0, minD = 1e9;
        for (int seed = 1; seed <= n; seed++) {
            SoloEngine eng = new SoloEngine(GameMode.SURVIVAL, 0, 3, 1, "Bru", seed * 7919);
            GameState st = eng.state(); SurvivalState sv = st.survival; LocalInput li = new LocalInput();
            Player me = st.local();
            for (int i = 0; i < 60; i++) eng.fixedUpdate(1f / 60f, li);
            for (Zombie z : sv.zombies) z.active = false;
            me.x = me.rx = 3000 + seed * 50; me.y = me.ry = -2000 + seed * 31;
            for (int i = 0; i < 30; i++) eng.fixedUpdate(1f / 60f, li);
            sv.hunger[0] = 0; me.health = 1;
            boolean died = false, back = false;
            for (int i = 0; i < 60 * 40 && !back; i++) {
                eng.fixedUpdate(1f / 60f, li);
                if (!me.alive) died = true;
                if (died && me.alive) back = true;
            }
            if (!back) { bad++; System.out.println("seed " + seed + ": never came back (died=" + died + ")"); continue; }
            double dd = Math.hypot(me.x - me.deathX, me.y - me.deathY); maxD = Math.max(maxD, dd); minD = Math.min(minD, dd);
            int tx = SurvivalTerrain.tileOf(me.x), ty = SurvivalTerrain.tileOf(me.y);
            boolean walk = sv.terrain.walkable(tx, ty);
            if (!walk || (me.x == 16f && me.y == 16f)) { fallback++; System.out.println("seed " + seed + ": respawned at " + me.x + "," + me.y + " walkable=" + walk); }
        }
        System.out.println("respawn distance from where they fell: " + (int) minD + " .. " + (int) maxD + " units");
        System.out.println("never back: " + bad + ", bad spawn: " + fallback + " of " + n);
    }
}
