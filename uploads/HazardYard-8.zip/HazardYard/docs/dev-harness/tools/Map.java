import com.hazardyard.game.survival.*;
public class Map {
    public static void main(String[] a) {
        SurvivalTerrain t = new SurvivalTerrain(99);
        int x0 = Integer.parseInt(a[0]), y0 = Integer.parseInt(a[1]), x1 = Integer.parseInt(a[2]), y1 = Integer.parseInt(a[3]);
        for (int y = y0; y <= y1; y++) {
            StringBuilder sb = new StringBuilder(String.format("%3d ", y));
            for (int x = x0; x <= x1; x++) {
                byte o = t.objAt(x, y);
                int g = t.groundAt(x, y);
                char ch;
                switch (o) {
                    case Obj.WALL: ch = Obj.wallHasWindow(t.metaAt(x, y)) ? 'W' : '#'; break;
                    case Obj.DOOR: ch = (t.metaAt(x, y) & 1) != 0 ? 'd' : 'D'; break;
                    case Obj.NONE: ch = g == 5 ? ',' : (g == 2 ? '.' : (g == 3 ? '_' : (g == 4 ? '~' : ' '))); break;
                    case Obj.RUBBLE: ch = 'r'; break;
                    case Obj.TREE: ch = 'T'; break;
                    case Obj.BUSH: ch = 'b'; break;
                    default: ch = 'f';
                }
                sb.append(ch);
            }
            System.out.println(sb);
        }
    }
}
