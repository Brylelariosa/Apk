import android.graphics.Canvas;
import com.hazardyard.game.core.*;
import com.hazardyard.game.engine.*;
import com.hazardyard.game.input.*;
import com.hazardyard.game.render.*;
import com.hazardyard.game.settings.GameSettings;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

public class BgShot {
    public static void main(String[] a) throws Exception {
        System.setProperty("java.awt.headless", "true");
        String out = a[0];
        int W = 1800, H = 810; float d = 2.6f;
        GameSettings gs = new GameSettings();
        InputController in = new InputController(gs.controls);
        in.setViewport(W, H, d, 0, 0, 0, 0);
        in.switchEnabled = true;
        SoloEngine eng = new SoloEngine(GameMode.BATTLEGROUND, 0, 3, 1, "Bru", 1234);
        GameState st = eng.state(); LocalInput li = new LocalInput();
        Player me = st.local();
        for (int i = 0; i < 60 * 8; i++) eng.fixedUpdate(1f / 60f, li);
        // give gear
        me.slotWeapon[0] = WeaponDef.PISTOL; me.slotWeapon[1] = WeaponDef.RIFLE; me.slotAmmo[0] = 9; me.slotAmmo[1] = 30;
        me.slotReserve[0] = 24; me.slotReserve[1] = 90; me.activeSlot = 1; me.backpack = 2; me.armor = 62; me.health = 74;
        me.weapon.equip(WeaponDef.byId(WeaponDef.RIFLE)); me.weapon.ammo = 22;
        eng.frameUpdate(1f / 60f, 1f);
        Camera cam = new Camera();
        cam.setViewport(W, H, st.map.worldW, st.map.worldH); cam.snapZoom(me.weapon.def.zoom); cam.snapTo(me.rx, me.ry);
        BufferedImage img = new BufferedImage(W, H, BufferedImage.TYPE_INT_ARGB);
        Canvas c = new Canvas(img);
        Renderer r = new Renderer(gs);
        HudRenderer hud = new HudRenderer();
        float time = 9f;
        for (int k = 0; k < 3; k++) { r.draw(c, st, cam, time); time += 0.016f; }
        hud.draw(c, st, cam, in, 0, d, time);
        ImageIO.write(img, "png", new File(out));
        System.out.println("ok");
    }
}
