import android.graphics.Canvas;
import com.hazardyard.game.core.*;
import com.hazardyard.game.engine.*;
import com.hazardyard.game.input.InputController;
import com.hazardyard.game.render.*;
import com.hazardyard.game.settings.GameSettings;
import com.hazardyard.game.survival.*;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

/** Renders survival frames while the survivor is dead, to see whether any renderer throws. */
public class DeadShot {
    public static void main(String[] a) throws Exception {
        System.setProperty("java.awt.headless", "true");
        int W = 1800, H = 810; float d = 2.6f;
        GameSettings gs = new GameSettings();
        InputController in = new InputController(gs.controls);
        in.setViewport(W, H, d, 0, 0, 0, 0);
        in.survivalUi.active = true;
        SoloEngine eng = new SoloEngine(GameMode.SURVIVAL, 0, 3, 1, "Bru", 99);
        GameState st = eng.state(); SurvivalState sv = st.survival; LocalInput li = new LocalInput();
        Player me = st.local();
        for (int i = 0; i < 400; i++) eng.fixedUpdate(1f / 60f, li);
        Camera cam = new Camera();
        cam.setUnbounded(true); cam.setViewport(W, H, 1e9f, 1e9f);
        cam.snapZoom(1.25f); cam.snapTo(me.rx, me.ry);
        BufferedImage img = new BufferedImage(W, H, BufferedImage.TYPE_INT_ARGB);
        Canvas c = new Canvas(img);
        Renderer r = new Renderer(gs);
        HudRenderer hud = new HudRenderer();
        float time = 5f;
        int errors = 0;
        // open the bag then die with it open
        in.survivalUi.bagOpen = a.length > 0 && a[0].equals("bag");
        me.health = 0; me.alive = true;
        for (Zombie z : sv.zombies) z.active = false;
        CombatTest.spawnAt(sv, 77, me.x + 25, me.y, Zombie.BRUTE).target = 0;
        me.health = 1;
        for (int i = 0; i < 60 * 14; i++) {
            eng.fixedUpdate(1f / 60f, li);
            eng.frameUpdate(1f / 60f, 1f);
            cam.follow(me.rx, me.ry, 1f / 60f);
            time += 1f / 60f;
            try {
                r.draw(c, st, cam, time);
                hud.draw(c, st, cam, in, 0, d, time);
            } catch (Throwable t) {
                errors++;
                if (errors < 3) { System.out.println("EXCEPTION at tick " + i + " alive=" + me.alive); t.printStackTrace(System.out); }
            }
            if (i == 120) ImageIO.write(img, "png", new File("/tmp/dead1.png"));
            if (i == 60 * 8) ImageIO.write(img, "png", new File("/tmp/dead2.png"));
            if (i == 60 * 13) ImageIO.write(img, "png", new File("/tmp/dead3.png"));
        }
        System.out.println("done, render errors: " + errors + " alive=" + me.alive);
    }
}
