import com.hazardyard.game.core.*;
public class BgAscii {
    public static void main(String[] a) {
        TileMap m = MapLibrary.get(MapLibrary.BATTLEGROUND);
        System.out.println("size " + m.width + "x" + m.height + " world " + m.worldW + "x" + m.worldH);
        int step = 2;
        for (int y = 0; y < m.height; y += step * 2) {
            StringBuilder sb = new StringBuilder();
            for (int x = 0; x < m.width; x += step) {
                byte g = m.groundAt(x, y);
                char ch;
                if ((m.kindAt(x, y) != TileMap.FLOOR && m.kindAt(x, y) != TileMap.WATER)) ch = '#';
                else if (m.kindAt(x, y) == TileMap.WATER) ch = '~'; else switch (g) {
                    case TileMap.G_WATER: ch = '~'; break;
                    case TileMap.G_SAND: ch = '.'; break;
                    case TileMap.G_ROAD: case TileMap.G_ROAD_H: case TileMap.G_ROAD_V: ch = '='; break;
                    case TileMap.G_FOREST: ch = 'f'; break;
                    case TileMap.G_BRIDGE: ch = 'B'; break;
                    case TileMap.G_FIELD: ch = 'F'; break;
                    case TileMap.G_MEADOW: ch = ','; break;
                    default: ch = ' ';
                }
                sb.append(ch);
            }
            System.out.printf("%3d %s%n", y, sb);
        }
    }
}
