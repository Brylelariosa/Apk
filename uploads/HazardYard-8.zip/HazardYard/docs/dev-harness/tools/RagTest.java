import com.hazardyard.game.core.*;
public class RagTest {
    public static void main(String[] a) {
        for (float s : new float[] {0.3f, 0.6f, 1.0f, 1.4f}) {
            Ragdolls r = new Ragdolls();
            Puppet pu = new Puppet(); PuppetStyle st = new PuppetStyle(); st.scale = 1f; st.width = 1f;
            pu.build = Puppet.B_NORMAL; pu.compute();
            r.spawn(pu, 0, 0, 0f, st, 1f, 0f, s);
            float t = 0; int asleepAt = -1;
            for (int i = 0; i < 60 * 6; i++) { r.update(1f / 60f, null); }
            float hx = (r.x[0][Puppet.J_HIP_L] + r.x[0][Puppet.J_HIP_R]) / 2, hy = (r.y[0][Puppet.J_HIP_L] + r.y[0][Puppet.J_HIP_R]) / 2;
            System.out.printf("strength %.1f -> hips at (%.1f, %.1f) head z %.1f%n", s, hx, hy, r.z[0][Puppet.J_HEAD]);
        }
    }
}
