import com.hazardyard.game.core.*;
import com.hazardyard.game.engine.*;
import com.hazardyard.game.net.*;

/** Host and client over a real loopback socket: the drop choice, the fall, and dropped loot all arrive. */
public class NetDropTest {
    static int fails = 0;
    static void check(boolean ok, String what) { System.out.println((ok ? "PASS " : "FAIL ") + what); if (!ok) fails++; }

    public static void main(String[] a) throws Exception {
        HostManager host = new HostManager(47821, 47822);
        host.start("Hosty");
        host.setModeId(GameMode.BATTLEGROUND);
        host.setMapId(MapLibrary.BATTLEGROUND);
        ClientManager client = new ClientManager();
        client.connect("127.0.0.1", host.port(), "Clienty", new ClientManager.Listener() {
            public void onConnected(int id) {}
            public void onLobbyChanged() {}
            public void onRejected(int r) { System.out.println("rejected " + r); }
            public void onMatchStart() {}
            public void onReturnToLobby() {}
            public void onDisconnected(String why) { System.out.println("disconnected " + why); }
        });
        long t0 = System.currentTimeMillis();
        while (host.lobby().count() < 2 && System.currentTimeMillis() - t0 < 6000) Thread.sleep(20);
        check(host.lobby().count() == 2, "client joined the lobby");
        client.sendReady(true);
        host.lobby().setReady(0, true);
        t0 = System.currentTimeMillis();
        boolean started = false;
        while (!started && System.currentTimeMillis() - t0 < 5000) { started = host.startMatch(); Thread.sleep(50); }
        check(started, "host started the match");
        t0 = System.currentTimeMillis();
        while (!client.isInMatch() && System.currentTimeMillis() - t0 < 5000) Thread.sleep(20);
        check(client.isInMatch(), "client is told the match began");
        HostEngine he = new HostEngine(host);
        ClientEngine ce = new ClientEngine(client);
        GameState hs = he.state(), cs = ce.state();
        LocalInput hin = new LocalInput(), cin = new LocalInput();
        int myId = client.localPlayerId();
        System.out.println("client is player " + myId + "; host state has " + hs.pickups.length + " pads, client " + cs.pickups.length);
        check(hs.pickups.length == cs.pickups.length, "both sides have the same number of pads incl. loot slots");
        // step both for a second so the first snapshots flow
        for (int i = 0; i < 90; i++) { he.fixedUpdate(1f / 60f, hin); ce.fixedUpdate(1f / 60f, cin); Thread.sleep(8); }
        check(cs.phase == GameState.PHASE_COUNTDOWN, "client sees the drop choice phase (" + cs.phase + ")");
        // the client taps the map and confirms; the host does too
        cin.dropChoose = true; cin.dropX = 2500f; cin.dropY = 3100f; cin.dropConfirm = true;
        hin.dropChoose = true; hin.dropX = 3400f; hin.dropY = 2000f; hin.dropConfirm = true;
        for (int i = 0; i < 2; i++) { he.fixedUpdate(1f / 60f, hin); ce.fixedUpdate(1f / 60f, cin); Thread.sleep(8); cin.dropChoose = cin.dropConfirm = false; hin.dropChoose = hin.dropConfirm = false; }
        Player hostView = hs.players[myId];
        for (int i = 0; i < 40; i++) { he.fixedUpdate(1f / 60f, hin); ce.fixedUpdate(1f / 60f, cin); Thread.sleep(8); }
        check(hs.phase == GameState.PHASE_PLAYING, "host: the drop began once both were ready");
        check(hostView.dropSet && Math.abs(hostView.dropX - 2500f) < 2f, "host got the client's chosen place (" + hostView.dropX + "," + hostView.dropY + ")");
        Player cme = cs.players[myId];
        System.out.println("client sees: phase " + cs.phase + " air " + cme.air + " host-side air " + hostView.air);
        check(cs.phase == GameState.PHASE_PLAYING, "client: playing");
        check(cme.air > 0f && hostView.air > 0f, "both agree the client is still in the air");
        check(Math.abs(cme.air - hostView.air) < 70f, "heights agree within a snapshot or two (" + cme.air + " vs " + hostView.air + ")");
        // the client steers a little
        cin.moveX = 1f;
        float x0 = hostView.x;
        for (int i = 0; i < 50; i++) { he.fixedUpdate(1f / 60f, hin); ce.fixedUpdate(1f / 60f, cin); Thread.sleep(8); }
        cin.moveX = 0f;
        check(hostView.x > x0 + 30f, "steering in the air reaches the host (" + (hostView.x - x0) + ")");
        for (int i = 0; i < 400 && (hostView.air > 0f || cme.air > 0f); i++) { he.fixedUpdate(1f / 60f, hin); ce.fixedUpdate(1f / 60f, cin); Thread.sleep(8); }
        for (int i = 0; i < 60; i++) { he.fixedUpdate(1f / 60f, hin); ce.fixedUpdate(1f / 60f, cin); Thread.sleep(8); }
        check(hostView.air == 0f && cme.air == 0f, "everybody landed");
        double dist = Math.hypot(hostView.x - cme.x, hostView.y - cme.y);
        check(dist < 40, "client and host agree where the client stands (" + (int) dist + " units apart)");
        // ---- loot: the host kills a bot (no bots in a 2-human hosted game?) or the host player itself
        int bots = 0; for (Player p : hs.players) if (p.connected && p.bot) bots++;
        System.out.println("bots in the match: " + bots);
        Player victim = null;
        for (Player p : hs.players) if (p.connected && p.alive && p.id != myId && p.id != 0) { victim = p; break; }
        if (victim == null) victim = hs.players[0];
        java.lang.reflect.Field f = HostEngine.class.getDeclaredField("world");
        f.setAccessible(true);
        GameWorld w = (GameWorld) f.get(he);
        victim.armor = 100;
        java.lang.reflect.Method dm = GameWorld.class.getDeclaredMethod("damage", int.class, int.class, int.class, int.class, int.class, float.class, float.class);
        dm.setAccessible(true);
        victim.spawnProtect = 0f; victim.health = 1;
        dm.invoke(w, victim.id, myId, 60, WeaponDef.PISTOL, 0, victim.x, victim.y);
        check(!victim.alive, "victim is down");
        int hostLoot = 0; for (int i = hs.mapPads; i < hs.pickups.length; i++) if (hs.pickups[i].active) hostLoot++;
        for (int i = 0; i < 60; i++) { he.fixedUpdate(1f / 60f, hin); ce.fixedUpdate(1f / 60f, cin); Thread.sleep(8); }
        int clientLoot = 0; boolean match = true;
        for (int i = hs.mapPads; i < hs.pickups.length; i++) {
            Pickup hp = hs.pickups[i], cp = cs.pickups[i];
            if (cp.active) clientLoot++;
            if (hp.active != cp.active) match = false;
            if (hp.active && (hp.item != cp.item || Math.abs(hp.x - cp.x) > 1f || Math.abs(hp.y - cp.y) > 1f || hp.ammo != cp.ammo)) match = false;
        }
        System.out.println("loot on host " + hostLoot + ", on client " + clientLoot);
        check(hostLoot >= 2 && clientLoot == hostLoot, "the client sees every dropped item the host has");
        check(match, "dropped items carry the same item, position and rounds on both sides");
        System.out.println(fails == 0 ? "ALL PASSED" : (fails + " FAILED"));
        client.close(); host.close();
        System.exit(fails == 0 ? 0 : 1);
    }
}
