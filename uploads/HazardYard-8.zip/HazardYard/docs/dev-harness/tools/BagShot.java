import android.graphics.Canvas;
import com.hazardyard.game.core.*;
import com.hazardyard.game.engine.*;
import com.hazardyard.game.input.*;
import com.hazardyard.game.render.*;
import com.hazardyard.game.settings.GameSettings;
import com.hazardyard.game.survival.*;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

public class BagShot {
    public static void main(String[] a) throws Exception {
        System.setProperty("java.awt.headless", "true");
        String out = a[0]; int tab = Integer.parseInt(a[1]); int sel = Integer.parseInt(a[2]);
        int W = 1800, H = 810; float d = 2.6f;
        GameSettings gs = new GameSettings();
        InputController in = new InputController(gs.controls);
        in.setViewport(W, H, d, 0, 0, 0, 0);
        in.survivalUi.active = true;
        SoloEngine eng = new SoloEngine(GameMode.SURVIVAL, 0, 3, 1, "Bru", 99);
        GameState st = eng.state(); SurvivalState sv = st.survival; LocalInput li = new LocalInput();
        for (int i = 0; i < 400; i++) eng.fixedUpdate(1f / 60f, li);
        Inventory inv = sv.inv[0];
        int[] items = {WeaponDef.KNIFE, Items.BANDAGE, Items.CANNED, WeaponDef.PISTOL, WeaponDef.BAT, Items.WOOD, Items.STONE, Items.NAILS, Items.CLOTH, WeaponDef.AXE, Items.APPLE, Items.VEST_LIGHT};
        for (int i = 0; i < items.length; i++) { inv.item[i] = items[i]; inv.count[i] = i % 3 == 0 ? 1 : 3 + i; }
        inv.selected = 0;
        eng.fixedUpdate(1f / 60f, li);
        in.survivalUi.bagOpen = true;
        in.survivalUi.tab = tab;
        in.survivalUi.selSlot = sel;
        in.survivalUi.selRecipe = 1;
        eng.frameUpdate(1f / 60f, 1f);
        Camera cam = new Camera();
        cam.setUnbounded(true); cam.setViewport(W, H, 1e9f, 1e9f); cam.snapZoom(1.2f); cam.snapTo(st.local().rx, st.local().ry);
        BufferedImage img = new BufferedImage(W, H, BufferedImage.TYPE_INT_ARGB);
        Canvas c = new Canvas(img);
        Renderer r = new Renderer(gs);
        HudRenderer hud = new HudRenderer();
        float time = 6f;
        r.draw(c, st, cam, time);
        hud.draw(c, st, cam, in, 0, d, time);
        ImageIO.write(img, "png", new File(out));
        System.out.println("ok");
    }
}
