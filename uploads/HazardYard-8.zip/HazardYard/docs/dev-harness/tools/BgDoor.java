import android.graphics.Canvas;
import com.hazardyard.game.core.*;
import com.hazardyard.game.engine.*;
import com.hazardyard.game.render.*;
import com.hazardyard.game.settings.GameSettings;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;
public class BgDoor {
    public static void main(String[] a) throws Exception {
        System.setProperty("java.awt.headless", "true");
        int W = 1800, H = 810;
        GameSettings gs = new GameSettings();
        SoloEngine eng = new SoloEngine(GameMode.BATTLEGROUND, 0, 1, 1, "Bru", 1234);
        GameState st = eng.state(); LocalInput li = new LocalInput(); li.dropConfirm = true; eng.fixedUpdate(1f / 60f, li); li.dropConfirm = false; /* the match opens with the drop choice: confirm it */
        for (int i = 0; i < 60 * 5; i++) eng.fixedUpdate(1f / 60f, li);
        int[] d = st.map.doorways();
        int idx = Integer.parseInt(a[1]);
        int h = d[idx * 4], side = d[idx * 4 + 1], start = d[idx * 4 + 2];
        int x0 = st.map.houses[h * 5], y0 = st.map.houses[h * 5 + 1], x1 = st.map.houses[h * 5 + 2], y1 = st.map.houses[h * 5 + 3];
        float cx = ((x0 + x1 + 1) / 2f) * 32f, cy = ((y0 + y1 + 1) / 2f) * 32f;
        System.out.println("house " + h + " rect " + x0 + "," + y0 + " " + x1 + "," + y1 + " door side " + side);
        Camera cam = new Camera();
        cam.setViewport(W, H, st.map.worldW, st.map.worldH); cam.snapZoom(0.9f); cam.snapTo(cx, cy + 40);
        BufferedImage img = new BufferedImage(W, H, BufferedImage.TYPE_INT_ARGB);
        Canvas c = new Canvas(img);
        Renderer r = new Renderer(gs);
        float time = 6f;
        for (int k = 0; k < 4; k++) { r.draw(c, st, cam, time); time += 0.016f; }
        ImageIO.write(img, "png", new File(a[0]));
    }
}
