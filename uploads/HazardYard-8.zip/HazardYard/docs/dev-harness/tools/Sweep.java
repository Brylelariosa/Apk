import com.hazardyard.game.core.*;
import com.hazardyard.game.engine.*;
import com.hazardyard.game.survival.*;
import java.util.Random;

public class Sweep {
    public static void main(String[] a) throws Exception {
        Random rnd = new Random(5);
        int bad = 0;
        // ---- Battleground with 1, 3 and 7 bots: the match must finish, with a winner, in a sane time
        for (int bots : new int[] {1, 3, 7}) {
            for (int seed = 1; seed <= 3; seed++) {
                SoloEngine eng = new SoloEngine(GameMode.BATTLEGROUND, 0, bots, seed % 3, "Bru", seed * 31 + bots);
                GameState st = eng.state(); LocalInput li = new LocalInput(); li.dropConfirm = true; eng.fixedUpdate(1f / 60f, li); li.dropConfirm = false; /* the match opens with the drop choice: confirm it */
                int ticks = 0; boolean ok = true;
                int players = 0; for (Player p : st.players) if (p.connected) players++;
                try {
                    while (st.phase != GameState.PHASE_ENDED && ticks < 60 * 800) {
                        if (ticks % 30 == 0) { li.moveX = rnd.nextFloat() * 2 - 1; li.moveY = rnd.nextFloat() * 2 - 1; li.aim = rnd.nextFloat() * 6.28f; li.firing = rnd.nextInt(3) == 0; }
                        if (ticks % 200 == 100) li.switchWeapon = true;
                        eng.fixedUpdate(1f / 60f, li);
                        li.switchWeapon = false; li.reload = false;
                        ticks++;
                    }
                } catch (Throwable t) { ok = false; t.printStackTrace(); }
                boolean ended = st.phase == GameState.PHASE_ENDED;
                System.out.printf("BG bots=%d seed=%d fighters=%d: ended=%b after %.0fs winner=%d alive=%d zoneRadius=%.0f%n", bots, seed, players, ended, ticks / 60f, st.winnerId, st.aliveCount(), st.zone.radius);
                if (!ok || !ended) bad++;
            }
        }
        // ---- Survival: ten minutes of a flailing survivor among zombies, nothing may throw
        for (int seed : new int[] {3, 11}) {
            SoloEngine eng = new SoloEngine(GameMode.SURVIVAL, 0, 3, 1, "Bru", seed);
            GameState st = eng.state(); LocalInput li = new LocalInput();
            int maxRag = 0, maxZ = 0, kills = 0; boolean ok = true;
            try {
                for (int ticks = 0; ticks < 60 * 600; ticks++) {
                    if (ticks % 40 == 0) { li.moveX = rnd.nextFloat() * 2 - 1; li.moveY = rnd.nextFloat() * 2 - 1; li.aim = rnd.nextFloat() * 6.28f; li.firing = true; }
                    if (ticks % 500 == 0) li.pushCommand(SurvivalSim.CMD_SELECT, rnd.nextInt(6), 0);
                    eng.fixedUpdate(1f / 60f, li);
                    if (ticks % 6 == 0) eng.frameUpdate(1f / 60f, 1f);
                    int z = 0; for (Zombie q : st.survival.zombies) if (q.active) z++;
                    maxZ = Math.max(maxZ, z); maxRag = Math.max(maxRag, st.ragdolls.activeCount());
                    if (!st.local().alive) { eng.state().local().alive = true; st.local().health = 100; }
                }
            } catch (Throwable t) { ok = false; t.printStackTrace(); }
            System.out.printf("Survival seed=%d: ok=%b max zombies %d, max ragdolls %d, player kills %d%n", seed, ok, maxZ, maxRag, st.local().kills);
            if (!ok) bad++;
        }
        System.out.println(bad == 0 ? "SWEEP OK" : (bad + " PROBLEMS"));
    }
}
