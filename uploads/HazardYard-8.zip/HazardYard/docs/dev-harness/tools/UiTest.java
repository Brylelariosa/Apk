import com.hazardyard.game.core.*;
import com.hazardyard.game.engine.*;
import com.hazardyard.game.input.*;
import com.hazardyard.game.settings.*;
import com.hazardyard.game.survival.*;

public class UiTest {
    static int fails = 0;
    static void check(boolean ok, String what) { System.out.println((ok ? "PASS " : "FAIL ") + what); if (!ok) fails++; }
    static int pauses, leaves;
    static void tap(InputController in, int id, float x, float y) { in.onPointerDown(id, x, y); in.onPointerUp(id); }
    public static void main(String[] a) {
        GameSettings gs = new GameSettings();
        InputController in = new InputController(gs.controls);
        in.setViewport(1800, 810, 2.6f, 0, 0, 0, 0);
        in.setListener(new InputController.Listener() {
            public void onPausePressed() { pauses++; }
            public void onLeavePressed() { leaves++; }
        });
        SoloEngine eng = new SoloEngine(GameMode.SURVIVAL, 0, 3, 1, "Bru", 99);
        GameState st = eng.state(); LocalInput li = new LocalInput();
        for (int i = 0; i < 400; i++) eng.fixedUpdate(1f / 60f, li);
        Inventory inv = st.survival.inv[0];
        SurvivalUi ui = in.survivalUi; ui.active = true;
        ui.layout(1800, 810, 2.6f, 0, 0, 0, 0);
        ui.setContext(inv, false, false);
        ControlGeometry g = null;
        // open the bag with its button
        tap(in, 1, ui.bagBtnX + ui.bagBtnS / 2, ui.bagBtnY + ui.bagBtnS / 2);
        check(ui.bagOpen, "the bag button opens the bag");
        // the old bug: the close button lies on the pause button
        float cx = ui.closeX + ui.closeS / 2, cy = ui.closeY + ui.closeS / 2;
        pauses = 0;
        tap(in, 2, cx, cy);
        check(!ui.bagOpen, "the close (X) button closes the bag");
        check(pauses == 0, "...without opening the pause menu");
        // outside the bag, the pause button still works
        tap(in, 3, 1706f, 95f);
        check(pauses == 1, "the pause button works when the bag is closed");
        // select and swap two slots
        tap(in, 1, ui.bagBtnX + ui.bagBtnS / 2, ui.bagBtnY + ui.bagBtnS / 2);
        int itemA = inv.item[1], itemB = inv.item[8];
        tap(in, 4, ui.cellX(1) + ui.cell / 2, ui.cellY(1) + ui.cell / 2);
        check(ui.selSlot == 1, "tapping an item selects it");
        tap(in, 4, ui.cellX(8) + ui.cell / 2, ui.cellY(8) + ui.cell / 2);
        in.sample(li);
        boolean swap = false; for (int i = 0; i < li.cmdCount; i++) if (li.cmdType[i] == SurvivalSim.CMD_SWAP && li.cmdA[i] == 1 && li.cmdB[i] == 8) swap = true;
        check(swap, "tapping a second slot sends a swap");
        li.cmdCount = 0;
        // drag and drop
        in.onPointerDown(5, ui.cellX(1) + ui.cell / 2, ui.cellY(1) + ui.cell / 2);
        in.onPointerMove(5, ui.cellX(1) + ui.cell / 2 + 30f, ui.cellY(1) + ui.cell / 2 + 60f);
        check(ui.dragging, "dragging an item picks it up");
        in.onPointerMove(5, ui.cellX(10) + ui.cell / 2, ui.cellY(10) + ui.cell / 2);
        in.onPointerUp(5);
        in.sample(li);
        swap = false; for (int i = 0; i < li.cmdCount; i++) if (li.cmdType[i] == SurvivalSim.CMD_SWAP && li.cmdA[i] == 1 && li.cmdB[i] == 10) swap = true;
        check(swap, "dropping it on another slot sends a swap");
        li.cmdCount = 0;
        // tabs and crafting
        tap(in, 6, ui.tabX(1) + ui.tabW / 2, ui.tabY + ui.tabH / 2);
        check(ui.tab == SurvivalUi.TAB_CRAFT, "the Craft tab opens");
        tap(in, 6, ui.listX0 + 50f, ui.rowY(0) + ui.rowH / 2);
        check(ui.selRecipe == 0, "a recipe can be picked");
        // a tap outside the panel closes it
        tap(in, 7, 4f, 4f);
        check(!ui.bagOpen, "a tap outside the bag closes it");
        // while the bag is open the game controls under it get nothing
        tap(in, 1, ui.bagBtnX + ui.bagBtnS / 2, ui.bagBtnY + ui.bagBtnS / 2);
        in.onPointerDown(8, 1706f, 95f);   // the pause button's place: a finger on the bag's header
        in.onPointerUp(8);
        pauses = 0;
        check(pauses == 0, "a touch on the bag never reaches the pause button");
        ui.closeBag();
        // spectator buttons
        in.spectatorUi.active = true;
        in.spectatorUi.layout(1800, 810, 2.6f, 0);
        SpectatorUi sp = in.spectatorUi;
        tap(in, 9, sp.nextX, sp.nextY);
        check(sp.takeDirection() == 1, "Next steps to the next fighter");
        tap(in, 9, sp.prevX, sp.prevY);
        check(sp.takeDirection() == -1, "Previous steps back");
        leaves = 0;
        tap(in, 9, sp.leaveX + sp.leaveW / 2, sp.leaveY + sp.leaveH / 2);
        check(leaves == 1, "Leave match tells the screen to leave");
        System.out.println(fails == 0 ? "ALL PASSED" : (fails + " FAILED"));
        System.exit(fails == 0 ? 0 : 1);
    }
}
