import com.hazardyard.game.core.*;
import java.util.*;
public class DoorTest {
    public static void main(String[] a) {
        int fails = 0;
        for (int id = 0; id < MapLibrary.COUNT; id++) {
            TileMap m = MapLibrary.get(id);
            int[] d = m.doorways();
            int n = m.doorwayCount();
            int housesNoDoor = 0;
            boolean[] has = new boolean[Math.max(1, m.houseCount)];
            for (int i = 0; i < n; i++) has[d[i * 4]] = true;
            for (int h = 0; h < m.houseCount; h++) if (!has[h]) housesNoDoor++;
            // reachability: flood fill from the outside tile of each doorway over walkable floor, must reach >= 600 tiles
            int unreachable = 0;
            for (int i = 0; i < n; i++) {
                int h = d[i * 4], side = d[i * 4 + 1], st = d[i * 4 + 2];
                int x0 = m.houses[h * 5], y0 = m.houses[h * 5 + 1], x1 = m.houses[h * 5 + 2], y1 = m.houses[h * 5 + 3];
                int tx = side == 1 ? x1 + 1 : (side == 3 ? x0 - 1 : st);
                int ty = side == 2 ? y1 + 1 : (side == 0 ? y0 - 1 : st);
                if (flood(m, tx, ty) < 600) unreachable++;
            }
            System.out.printf("map %d: %d houses, %d doorways, %d houses without a doorway, %d unreachable doorways%n", id, m.houseCount, n, housesNoDoor, unreachable);
            if (id == MapLibrary.COUNT - 1) { if (housesNoDoor > 0 || unreachable > 0) fails++; }
        }
        System.out.println(fails == 0 ? "OK" : "PROBLEMS");
    }
    static int flood(TileMap m, int sx, int sy) {
        boolean[] seen = new boolean[m.width * m.height];
        ArrayDeque<int[]> q = new ArrayDeque<>();
        q.add(new int[] {sx, sy}); seen[sy * m.width + sx] = true; int n = 0;
        while (!q.isEmpty() && n < 5000) {
            int[] p = q.poll(); n++;
            int[][] dd = {{1,0},{-1,0},{0,1},{0,-1}};
            for (int[] e : dd) {
                int nx = p[0] + e[0], ny = p[1] + e[1];
                if (nx < 0 || ny < 0 || nx >= m.width || ny >= m.height || seen[ny * m.width + nx]) continue;
                if (m.kindAt(nx, ny) != TileMap.FLOOR) continue;
                seen[ny * m.width + nx] = true; q.add(new int[] {nx, ny});
            }
        }
        return n;
    }
}
