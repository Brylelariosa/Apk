import android.graphics.Canvas;
import com.hazardyard.game.core.*;
import com.hazardyard.game.engine.*;
import com.hazardyard.game.input.InputController;
import com.hazardyard.game.render.*;
import com.hazardyard.game.settings.GameSettings;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

/** Renders the drop-select screen and frames of the fall. */
public class DropShot {
    public static void main(String[] a) throws Exception {
        System.setProperty("java.awt.headless", "true");
        int W = 1800, H = 810; float d = 2.6f;
        GameSettings gs = new GameSettings();
        InputController in = new InputController(gs.controls);
        in.setViewport(W, H, d, 0, 0, 0, 0);
        SoloEngine eng = new SoloEngine(GameMode.BATTLEGROUND, MapLibrary.BATTLEGROUND, 7, 1, "Bru", 4242);
        GameState st = eng.state(); LocalInput li = new LocalInput();
        Player me = st.local();
        Camera cam = new Camera();
        cam.setUnbounded(false); cam.setViewport(W, H, st.map.worldW, st.map.worldH);
        cam.snapZoom(1.0f); cam.snapTo(me.rx, me.ry);
        BufferedImage img = new BufferedImage(W, H, BufferedImage.TYPE_INT_ARGB);
        Canvas c = new Canvas(img);
        Renderer r = new Renderer(gs);
        HudRenderer hud = new HudRenderer();
        float time = 3f;
        in.dropUi.setWorld(st.map.worldW, st.map.worldH);
        in.dropUi.setActive(true);
        for (int i = 0; i < 90; i++) { eng.fixedUpdate(1f / 60f, li); time += 1f/60f; }
        // tap the island
        in.onPointerDown(1, in.dropUi.mapX + in.dropUi.mapW * 0.52f, in.dropUi.mapY + in.dropUi.mapH * 0.40f);
        in.onPointerUp(1);
        in.sample(li);
        eng.fixedUpdate(1f / 60f, li);
        cam.follow(me.rx, me.ry, 1f / 60f);
        r.draw(c, st, cam, time);
        hud.draw(c, st, cam, in, 0, d, time);
        ImageIO.write(img, "png", new File("/tmp/drop_select.png"));
        // confirm and fall
        float bx = in.dropUi.btnX + 20, by = in.dropUi.btnY + 20;
        in.onPointerDown(2, bx, by); in.onPointerUp(2);
        in.dropUi.setActive(false);
        in.sample(li);
        li.dropChoose = true; li.dropX = 0.52f * st.map.worldW; li.dropY = 0.4f * st.map.worldH; li.dropConfirm = true;
        eng.fixedUpdate(1f / 60f, li);
        System.out.println("after confirm: phase=" + st.phase + " countdown=" + st.countdown + " air=" + me.air + " ready=" + me.dropReady + " set=" + me.dropSet);
        li.dropChoose = false; li.dropConfirm = false;
        int[] snaps = {5, 60, 120, 170, 215};
        cam.snapTo(me.rx, me.ry);
        int k = 0;
        for (int tick = 1; tick <= 260 && k < snaps.length; tick++) {
            eng.fixedUpdate(1f / 60f, li); eng.frameUpdate(1f / 60f, 1f); time += 1f / 60f;
            cam.follow(me.rx, me.ry, 1f / 60f);
            if (tick == snaps[k]) {
                r.draw(c, st, cam, time);
                hud.draw(c, st, cam, in, 0, d, time);
                ImageIO.write(img, "png", new File("/tmp/drop_fall" + k + ".png"));
                System.out.println("tick " + tick + " air=" + me.air + " pos " + (int) me.x + "," + (int) me.y);
                k++;
            }
        }
    }
}
