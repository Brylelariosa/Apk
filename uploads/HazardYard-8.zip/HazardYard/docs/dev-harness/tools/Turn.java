package com.hazardyard.game.render;
import android.graphics.*;
import com.hazardyard.game.core.*;
import com.hazardyard.game.survival.*;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

public class Turn {
    public static void main(String[] a) throws Exception {
        System.setProperty("java.awt.headless", "true");
        String out = a[0];
        int anim = Integer.parseInt(a[1]);
        float tparam = Float.parseFloat(a[2]);
        float zoom = 9f;
        int cols = 6, rows = 3, cw = 46, ch = 52;
        BufferedImage img = new BufferedImage((int) (cols * cw * zoom / 1.0f * 0.5f), (int) (rows * ch * zoom * 0.5f), BufferedImage.TYPE_INT_ARGB);
        Canvas c = new Canvas(img);
        c.drawColor(0xFF5A8F46);
        PuppetRenderer pr = new PuppetRenderer(new PolyDrawer());
        Puppet pu = new Puppet();
        PuppetStyle style = new PuppetStyle();
        float[] wx = new float[Puppet.JOINTS], wy = new float[Puppet.JOINTS], wz = new float[Puppet.JOINTS];
        for (int r = 0; r < rows; r++) {
            for (int col = 0; col < cols; col++) {
                ZombieLook.fill(r, ZombieLook.lookOf(5 + col * 7 + r * 13), style);
                pu.scale = style.scale; pu.width = style.width; pu.build = style.build;
                pu.seed = ((col * 37 + r * 11) % 100) / 100f;
                pu.clock = 1.3f; pu.gait = 0; pu.t = 0; pu.hitT = 9f; pu.hitK = 0; pu.attackP = 0; pu.reach = 1f;
                pu.fallX = -1; pu.fallY = 0;
                pu.anim = anim;
                if (anim == Puppet.A_WALK) { pu.gait = 1f; pu.phase = tparam; }
                if (anim == Puppet.A_RUN) { pu.gait = 1.4f; pu.phase = tparam; }
                if (anim == Puppet.A_ATTACK) { pu.attackP = tparam; }
                if (anim == Puppet.A_FALL || anim == Puppet.A_GETUP || anim == Puppet.A_STUMBLE) { pu.t = tparam; pu.hitX = 1; pu.hitY = 0; }
                if (anim == Puppet.A_HIT) { pu.hitX = 1; pu.hitY = 0; pu.hitK = 1f; pu.hitT = tparam; }
                pu.compute();
                float aim = (float) (col * Math.PI * 2 / cols);
                pu.toWorld(0, 0, aim, wx, wy, wz);
                c.save();
                c.translate((col * cw + cw * 0.5f) * zoom * 0.5f, (r * ch + ch * 0.66f) * zoom * 0.5f);
                c.scale(zoom * 0.5f, zoom * 0.5f);
                pr.draw(c, wx, wy, wz, style, 0f, 1f, 2);
                c.restore();
            }
        }
        ImageIO.write(img, "png", new File(out));
        System.out.println("ok");
    }
}
