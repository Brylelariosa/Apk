import com.hazardyard.game.core.*;
import com.hazardyard.game.engine.*;
import com.hazardyard.game.survival.*;
public class Dbg2 {
    public static void main(String[] a) {
        SoloEngine eng = new SoloEngine(GameMode.SURVIVAL, 0, 3, 1, "Bru", 99);
        GameState st = eng.state(); SurvivalState sv = st.survival; LocalInput li = new LocalInput();
        for (int i = 0; i < 10; i++) eng.fixedUpdate(1f / 60f, li);
        System.out.println("item0 " + sv.inv[0].item[0] + " sel " + sv.inv[0].selected + " weapon " + st.local().weapon.def.name + " BAT id " + WeaponDef.BAT + " KNIFE " + WeaponDef.KNIFE);
        sv.inv[0].item[0] = WeaponDef.BAT; sv.inv[0].count[0] = 1;
        for (int i = 0; i < 10; i++) eng.fixedUpdate(1f / 60f, li);
        System.out.println("after: weapon " + st.local().weapon.def.name);
    }
}
