package com.hazardyard.game.render;
import android.graphics.*;
import com.hazardyard.game.core.*;
import com.hazardyard.game.survival.*;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

public class Seq {
    // usage: Seq out anim t0 t1 type look [aimDegrees...]
    public static void main(String[] a) throws Exception {
        System.setProperty("java.awt.headless", "true");
        String out = a[0];
        int anim = Integer.parseInt(a[1]);
        float t0 = Float.parseFloat(a[2]), t1 = Float.parseFloat(a[3]);
        int type = Integer.parseInt(a[4]);
        int look = Integer.parseInt(a[5]);
        int rows = a.length - 6;
        float zoom = 5.5f;
        int cols = 8, cw = 50, ch = 54;
        BufferedImage img = new BufferedImage((int) (cols * cw * zoom), (int) (rows * ch * zoom), BufferedImage.TYPE_INT_ARGB);
        Canvas c = new Canvas(img);
        c.drawColor(0xFF5A8F46);
        PuppetRenderer pr = new PuppetRenderer(new PolyDrawer());
        Puppet pu = new Puppet();
        PuppetStyle style = new PuppetStyle();
        float[] wx = new float[Puppet.JOINTS], wy = new float[Puppet.JOINTS], wz = new float[Puppet.JOINTS];
        for (int r = 0; r < rows; r++) {
            float aim = (float) Math.toRadians(Float.parseFloat(a[6 + r]));
            for (int col = 0; col < cols; col++) {
                float tt = t0 + (t1 - t0) * col / (cols - 1);
                ZombieLook.fill(type, ZombieLook.lookOf(look), style);
                pu.scale = style.scale; pu.width = style.width; pu.build = style.build;
                pu.seed = 0.3f; pu.clock = 1.3f; pu.gait = 0; pu.t = 0; pu.hitT = 9f; pu.hitK = 0; pu.attackP = 0; pu.reach = 1f;
                pu.fallX = -1; pu.fallY = 0;
                pu.anim = anim;
                if (anim == Puppet.A_WALK) { pu.gait = 1f; pu.phase = tt; }
                if (anim == Puppet.A_RUN) { pu.gait = 1.4f; pu.phase = tt; }
                if (anim == Puppet.A_ATTACK) { pu.attackP = tt; }
                if (anim == Puppet.A_FALL || anim == Puppet.A_GETUP || anim == Puppet.A_STUMBLE) { pu.t = tt; pu.hitX = 1; pu.hitY = 0; }
                if (anim == Puppet.A_HIT) { pu.hitX = -1; pu.hitY = 0; pu.hitK = 1f; pu.hitT = tt; }
                pu.compute();
                pu.toWorld(0, 0, aim, wx, wy, wz);
                c.save();
                c.translate((col * cw + cw * 0.5f) * zoom, (r * ch + ch * 0.62f) * zoom);
                c.scale(zoom, zoom);
                pr.draw(c, wx, wy, wz, style, 0f, 1f, 2);
                c.restore();
            }
        }
        ImageIO.write(img, "png", new File(out));
        System.out.println("ok");
    }
}
