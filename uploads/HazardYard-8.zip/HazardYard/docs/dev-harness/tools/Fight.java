import android.graphics.Canvas;
import com.hazardyard.game.core.*;
import com.hazardyard.game.engine.*;
import com.hazardyard.game.input.InputController;
import com.hazardyard.game.render.*;
import com.hazardyard.game.settings.GameSettings;
import com.hazardyard.game.survival.*;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

/** Renders a survival fight: a ring of zombies around the player with a bat, at a chosen number of ticks after the swing. */
public class Fight {
    public static void main(String[] a) throws Exception {
        System.setProperty("java.awt.headless", "true");
        String out = a[0];
        int weapon = Integer.parseInt(a[1]);
        int ticksAfter = Integer.parseInt(a[2]);
        int W = 1800, H = 810; float d = 2.6f;
        GameSettings gs = new GameSettings();
        InputController in = new InputController(gs.controls);
        in.setViewport(W, H, d, 0, 0, 0, 0);
        in.survivalUi.active = true;
        SoloEngine eng = new SoloEngine(GameMode.SURVIVAL, 0, 3, 1, "Bru", 99);
        GameState st = eng.state(); SurvivalState sv = st.survival; LocalInput li = new LocalInput();
        Player me = st.local();
        for (int i = 0; i < 400; i++) eng.fixedUpdate(1f / 60f, li);
        for (Zombie z : sv.zombies) z.active = false;
        sv.inv[0].item[0] = weapon; sv.inv[0].count[0] = 1; sv.inv[0].selected = 0;
        for (int i = 0; i < 4; i++) eng.fixedUpdate(1f / 60f, li);
        float px = me.x, py = me.y;
        me.aim = 0; li.aim = 0;
        int[] types = {0, 1, 0, 2, 0, 1, 0, 0};
        for (int k = 0; k < 8; k++) {
            double ang = k * Math.PI / 4 + 0.2;
            float r = 38f + (k % 3) * 22f;
            CombatTest.spawnAt(sv, 100 + k, px + (float) Math.cos(ang) * r, py + (float) Math.sin(ang) * r, types[k]);
        }
        li.firing = true;
        for (int i = 0; i < 20; i++) eng.fixedUpdate(1f / 60f, li);
        li.firing = false;
        for (int i = 0; i < ticksAfter; i++) eng.fixedUpdate(1f / 60f, li);
        eng.frameUpdate(1f / 60f, 1f);
        Camera cam = new Camera();
        cam.setUnbounded(true); cam.setViewport(W, H, 1e9f, 1e9f);
        cam.snapZoom(1.25f);
        cam.snapTo(me.rx, me.ry);
        BufferedImage img = new BufferedImage(W, H, BufferedImage.TYPE_INT_ARGB);
        Canvas c = new Canvas(img);
        Renderer r = new Renderer(gs);
        HudRenderer hud = new HudRenderer();
        float time = 6f;
        for (int k = 0; k < 3; k++) { r.draw(c, st, cam, time); time += 0.016f; }
        hud.draw(c, st, cam, in, 0, d, time);
        ImageIO.write(img, "png", new File(out));
        System.out.println("ok ragdolls " + st.ragdolls.activeCount() + " weapon " + me.weapon.def.name);
    }
}
