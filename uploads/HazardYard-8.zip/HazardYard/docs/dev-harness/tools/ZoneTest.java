import com.hazardyard.game.core.*;
import com.hazardyard.game.engine.*;

public class ZoneTest {
    public static void main(String[] a) throws Exception {
        int seed = a.length > 0 ? Integer.parseInt(a[0]) : 7;
        SoloEngine eng = new SoloEngine(GameMode.BATTLEGROUND, 0, 3, 1, "Bru", seed);
        GameState st = eng.state(); LocalInput li = new LocalInput();
        float t = 0; int lastPhase = -1; boolean lastShr = false; int tick = 0;
        float lastR = Float.MAX_VALUE; boolean shrankMonotonic = true;
        while (t < 800 && st.phase != GameState.PHASE_ENDED) {
            eng.fixedUpdate(1f / 60f, li);
            tick++; t = tick / 60f;
            Zone z = st.zone;
            if (st.phase == GameState.PHASE_PLAYING) {
                if (z.radius > lastR + 0.01f) shrankMonotonic = false;
                lastR = z.radius;
                if (z.phase != lastPhase || z.shrinking != lastShr) {
                    System.out.printf("t=%5.1f zone phase %d shrinking=%b radius=%.0f target=%.0f alive=%d%n", t, z.phase, z.shrinking, z.radius, z.toRadius, st.aliveCount());
                    lastPhase = z.phase; lastShr = z.shrinking;
                }
            }
        }
        System.out.printf("END t=%.1f phase=%d winner=%d alive=%d zoneRadius=%.0f collapsed=%b monotonic=%b%n", t, st.phase, st.winnerId, st.aliveCount(), st.zone.radius, st.zone.collapsed, shrankMonotonic);
    }
}
