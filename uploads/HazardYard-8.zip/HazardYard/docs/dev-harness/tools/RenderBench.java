import android.graphics.Canvas;
import com.hazardyard.game.core.*;
import com.hazardyard.game.engine.*;
import com.hazardyard.game.render.*;
import com.hazardyard.game.settings.GameSettings;
import java.awt.image.BufferedImage;

/** Times the world renderer: ms per frame at several places of the Battleground map and the survival world. */
public class RenderBench {
    static double run(int modeId, float px, float py, float zoom, int frames) throws Exception {
        int W = 1800, H = 810;
        GameSettings gs = new GameSettings();
        SoloEngine eng = new SoloEngine(modeId, modeId == GameMode.BATTLEGROUND ? MapLibrary.BATTLEGROUND : 0, 3, 1, "Bru", 1234);
        GameState st = eng.state(); LocalInput li = new LocalInput();
        Player me = st.local();
        me.x = me.rx = px; me.y = me.ry = py;
        if (modeId == GameMode.BATTLEGROUND) { try { LocalInput.class.getField("dropConfirm").setBoolean(li, true); } catch (Exception e) { } eng.fixedUpdate(1f / 60f, li); try { LocalInput.class.getField("dropConfirm").setBoolean(li, false); } catch (Exception e) { } }
        for (int i = 0; i < 600; i++) eng.fixedUpdate(1f / 60f, li);
        Camera cam = new Camera();
        cam.setUnbounded(modeId == GameMode.SURVIVAL); cam.setViewport(W, H, st.map.worldW, st.map.worldH);
        cam.snapZoom(zoom); cam.snapTo(me.rx, me.ry);
        BufferedImage img = new BufferedImage(W, H, BufferedImage.TYPE_INT_ARGB);
        Canvas c = new Canvas(img);
        Renderer r = new Renderer(gs);
        for (int i = 0; i < 10; i++) r.draw(c, st, cam, 1f + i * 0.016f);
        long t0 = System.nanoTime();
        for (int i = 0; i < frames; i++) r.draw(c, st, cam, 2f + i * 0.016f);
        return (System.nanoTime() - t0) / 1e6 / frames;
    }
    static double[] prof() { try { Class<?> k = Class.forName("com.hazardyard.game.render.TerrainRenderer"); java.lang.reflect.Field f = k.getDeclaredField("PROF"); f.setAccessible(true); long[] p = (long[]) f.get(null); double[] o = new double[6]; for (int i = 0; i < 6; i++) o[i] = p[i] / 1e6 / 50; return o; } catch (Throwable t) { return new double[0]; } }
    public static void main(String[] a) throws Exception {
        System.setProperty("java.awt.headless", "true");
        System.out.printf("BG town     %.1f ms/frame%n", run(GameMode.BATTLEGROUND, 3000, 2000, 1.0f, 40));
        System.out.printf("BG shore    %.1f ms/frame%n", run(GameMode.BATTLEGROUND, 830, 1800, 1.0f, 40));
        System.out.printf("BG forest   %.1f ms/frame%n", run(GameMode.BATTLEGROUND, 3070, 2200, 0.85f, 40));
        System.out.println("terrain stages ms/frame (cache, base, blot, feather, shores, decor): " + java.util.Arrays.toString(prof()));
        System.out.printf("Survival    %.1f ms/frame%n", run(GameMode.SURVIVAL, 16, -144, 1.0f, 40));
    }
}
