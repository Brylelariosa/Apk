import com.hazardyard.game.survival.*;
public class Bld {
    public static void main(String[] a) {
        SurvivalGen g = new SurvivalGen(Integer.parseInt(a.length > 0 ? a[0] : "99"));
        int[] out = new int[SurvivalGen.B_STRIDE * 40];
        int n = g.buildingsInRect(0, 0, 60, 50, out);
        for (int i = 0; i < n; i++) {
            int o = i * SurvivalGen.B_STRIDE;
            System.out.printf("b%d x=%d y=%d w=%d h=%d kind=%d style=%d side=%d along=%d%n", i, out[o], out[o+1], out[o+2], out[o+3], out[o+4], out[o+5], out[o+6], out[o+7]);
        }
    }
}
