package com.hazardyard.game.render;
import android.graphics.*;
import com.hazardyard.game.core.*;
import com.hazardyard.game.engine.*;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

/** usage: MeleeSheet out.png weaponId attackIndex aimDeg [perRow] [frames] — frames across the swing in a grid. */
public class MeleeSheet {
    public static void main(String[] a) throws Exception {
        System.setProperty("java.awt.headless", "true");
        String out = a[0];
        int weapon = Integer.parseInt(a[1]);
        int idx = Integer.parseInt(a[2]);
        float aim = (float) Math.toRadians(Float.parseFloat(a[3]));
        int perRow = a.length > 4 ? Integer.parseInt(a[4]) : 4;
        int frames = a.length > 5 ? Integer.parseInt(a[5]) : 8;
        float zoom = Float.parseFloat(System.getProperty("zoom", "5"));
        int rows = (frames + perRow - 1) / perRow;
        int cw = 84, ch = 70;
        BufferedImage img = new BufferedImage((int) (perRow * cw * zoom), (int) (rows * ch * zoom), BufferedImage.TYPE_INT_ARGB);
        Canvas c = new Canvas(img);
        c.drawColor(0xFF5E9A44);
        SoloEngine eng = new SoloEngine(GameMode.SURVIVAL, 0, 3, 1, "Bru", 99);
        GameState st = eng.state();
        Player me = st.local();
        WeaponDef d = WeaponDef.byId(weapon);
        me.weapon.equip(d);
        UnitRenderer ur = new UnitRenderer(new PolyDrawer());
        Paint tp = new Paint(); tp.setColor(0xFFFFFFFF); tp.setTextSize(16);
        for (int f = 0; f < frames; f++) {
            int r = f / perRow, col = f % perRow;
            float u = f == 0 ? 1f : (f / (float) (frames - 1)) * 0.96f;
            me.rx = me.x = 0; me.ry = me.y = 0;
            me.rAim = me.aim = aim;
            me.swingWeapon = weapon; me.swingVariant = idx; me.swingDur = 0.4f;
            me.swingT = f == 0 ? 1f : u;
            c.save();
            c.translate((col * cw + cw * 0.5f) * zoom, (r * ch + ch * 0.56f) * zoom);
            c.scale(zoom, zoom);
            ur.update(st, 1f); ur.update(st, 1.02f);
            ur.draw(c, st, 0, 1.03f, true);
            c.restore();
            c.drawText(f == 0 ? "guard" : String.format("u=%.2f", u), col * cw * zoom + 6, r * ch * zoom + 18, tp);
        }
        ImageIO.write(img, "png", new File(out));
        MeleeProfile prof = d.profile;
        System.out.println("ok " + d.name + " attack " + idx + (prof != null ? " kind " + prof.attack(idx).kind : ""));
    }
}
