package com.hazardyard.game.render;
import android.graphics.*;
import com.hazardyard.game.core.*;
import com.hazardyard.game.survival.*;
import java.awt.image.BufferedImage;
public class FaceCount {
    public static void main(String[] a) {
        Canvas c = new Canvas(new BufferedImage(200, 200, BufferedImage.TYPE_INT_ARGB));
        PuppetRenderer pr = new PuppetRenderer(new PolyDrawer());
        Puppet pu = new Puppet(); PuppetStyle st = new PuppetStyle();
        float[] x = new float[13], y = new float[13], z = new float[13];
        for (int detail = 0; detail <= 2; detail++) {
            int min = 999, max = 0, sum = 0, n = 0;
            for (int type = 0; type < 3; type++) for (int look = 0; look < 60; look++) {
                ZombieLook.fill(type, ZombieLook.lookOf(look), st);
                pu.scale = st.scale; pu.width = st.width; pu.build = st.build; pu.anim = Puppet.A_WALK; pu.gait = 1f; pu.phase = look; pu.hitT = 9; pu.compute();
                pu.toWorld(100, 100, look * 0.7f, x, y, z);
                pr.draw(c, x, y, z, st, 0f, 1f, detail);
                min = Math.min(min, pr.lastFaces); max = Math.max(max, pr.lastFaces); sum += pr.lastFaces; n++;
            }
            System.out.println("detail " + detail + ": faces min " + min + " avg " + (sum / n) + " max " + max);
        }
    }
}
