import com.hazardyard.game.core.*;
import com.hazardyard.game.engine.*;
import com.hazardyard.game.survival.*;

/** Statistical melee duels: a player who walks up to the nearest zombie and swings, many seeds per scenario. */
public class MeleeStats {
    static float[] duel(int weapon, int type, int count, int seed) throws Exception {
        SoloEngine eng = new SoloEngine(GameMode.SURVIVAL, 0, 3, 1, "Bru", seed * 101 + 7);
        GameState st = eng.state();
        SurvivalState sv = st.survival;
        LocalInput li = new LocalInput();
        Player me = st.local();
        for (int i = 0; i < 300; i++) eng.fixedUpdate(1f / 60f, li);
        for (Zombie z : sv.zombies) z.active = false;
        sv.inv[0].clear();
        sv.inv[0].item[0] = weapon; sv.inv[0].count[0] = 1; sv.inv[0].selected = 0;
        for (int i = 0; i < 4; i++) eng.fixedUpdate(1f / 60f, li);
        float px = me.x, py = me.y;
        Zombie[] zs = new Zombie[count];
        for (int k = 0; k < count; k++) {
            float ang = (float) (Math.PI * 0.3 * (k - (count - 1) / 2f));
            zs[k] = CombatTest.spawnAt(sv, 50 + k, px + 170f * (float) Math.cos(ang), py + 170f * (float) Math.sin(ang), type);
            zs[k].target = 0;
        }
        me.health = 100;
        li.firing = true;
        float clear = -1f;
        boolean[] gone = new boolean[count];
        for (int i = 0; i < 60 * 30; i++) {
            Zombie best = null; float bd = 1e9f;
            for (int k = 0; k < count; k++) {
                Zombie z = zs[k];
                if (!z.active || z.hp <= 0) gone[k] = true;      // a dead slot is reused by the spawner far away: never look at it again
                if (gone[k]) continue;
                float d = (z.x - me.x) * (z.x - me.x) + (z.y - me.y) * (z.y - me.y); if (d < bd) { bd = d; best = z; } }
            if (best == null) { clear = i / 60f; break; }
            if (!me.alive) break;
            float dd = (float) Math.sqrt(bd);
            // a human aims roughly at the zombie (not perfectly), and walks up to it
            float want = (float) Math.atan2(best.y - me.y, best.x - me.x);
            li.aim = want + 0.18f * (float) Math.sin(i * 0.11f);
            if (dd > 44f) { li.moveX = (best.x - me.x) / dd; li.moveY = (best.y - me.y) / dd; }
            else { li.moveX = 0; li.moveY = 0; }
            eng.fixedUpdate(1f / 60f, li);
        }
        int killed = 0; for (boolean g : gone) if (g) killed++;
        return new float[]{killed / (float) count, clear, me.alive ? 100 - me.health : 100, me.alive ? 1 : 0};
    }
    public static void main(String[] a) throws Exception {
        int N = 12;
        int[][] scen = {{Zombie.WALKER, 1}, {Zombie.WALKER, 3}, {Zombie.WALKER, 5}, {Zombie.RUNNER, 2}, {Zombie.BRUTE, 1}};
        System.out.printf("%-14s", "weapon");
        for (int[] s : scen) System.out.printf(" | %-22s", s[1] + "x" + Zombie.typeName(s[0]));
        System.out.println();
        for (int w : new int[]{WeaponDef.FISTS, WeaponDef.KNIFE, WeaponDef.BAT, WeaponDef.CROWBAR, WeaponDef.MACHETE, WeaponDef.AXE, WeaponDef.PICKAXE}) {
            System.out.printf("%-14s", WeaponDef.byId(w).name);
            for (int[] s : scen) {
                float clearSum = 0, hpSum = 0, survive = 0, kills = 0; int cleared = 0;
                for (int k = 0; k < N; k++) {
                    float[] r = duel(w, s[0], s[1], k + 1);
                    kills += r[0]; hpSum += r[2]; survive += r[3];
                    if (r[1] >= 0) { clearSum += r[1]; cleared++; }
                }
                System.out.printf(" | clr %2d/%d %4.1fs lost%3.0f", cleared, N, cleared > 0 ? clearSum / cleared : 0, hpSum / N);
            }
            System.out.println();
        }
    }
}
