import com.hazardyard.game.core.*;
import com.hazardyard.game.engine.*;

/** Battleground drop-in and loot rules on the host side. */
public class DropTest {
    static int fails = 0;
    static void check(boolean ok, String what) { System.out.println((ok ? "PASS " : "FAIL ") + what); if (!ok) fails++; }

    public static void main(String[] a) throws Exception {
        SoloEngine eng = new SoloEngine(GameMode.BATTLEGROUND, MapLibrary.BATTLEGROUND, 7, 1, "Bru", 4242);
        GameState st = eng.state();
        LocalInput li = new LocalInput();
        Player me = st.local();
        check(st.phase == GameState.PHASE_COUNTDOWN, "match starts in the drop choice (countdown phase)");
        check(Math.abs(st.countdown - GameConfig.DROP_SELECT_SECONDS) < 0.5f, "the choice lasts " + st.countdown + " s");
        check(st.pickups.length == st.mapPads + GameConfig.LOOT_SLOTS, "loot slots appended: " + st.mapPads + " map pads + " + GameConfig.LOOT_SLOTS);
        int botsChosen = 0; for (Player p : st.players) if (p.connected && p.bot && p.dropSet) botsChosen++;
        check(botsChosen == 7, "all 7 bots chose a drop point");
        // the player taps the map near a town and confirms
        li.dropChoose = true; li.dropX = 3000f; li.dropY = 2000f; li.dropConfirm = true;
        eng.fixedUpdate(1f / 60f, li);
        li.dropChoose = false; li.dropConfirm = false;
        eng.fixedUpdate(1f / 60f, li);
        check(st.phase == GameState.PHASE_PLAYING, "everyone ready -> the drop begins at once");
        check(me.air > 200f, "player is in the air at " + me.air);
        System.out.println("player at " + me.x + "," + me.y + " (asked 3000,2000)");
        check(Math.abs(me.x - 3000f) < 160f && Math.abs(me.y - 2000f) < 160f, "player is over the chosen place");
        // nothing hurts them in the air, and they steer
        float x0 = me.x;
        li.moveX = 1f;
        for (int i = 0; i < 60; i++) eng.fixedUpdate(1f / 60f, li);
        check(me.x > x0 + 60f, "steering moves the player in the air (moved " + (me.x - x0) + ")");
        int hp = me.health;
        check(me.air > 0f, "still falling after 1 s");
        li.moveX = 0f;
        int ticks = 0;
        while (me.air > 0f && ticks < 60 * 10) { eng.fixedUpdate(1f / 60f, li); ticks++; }
        check(me.air == 0f, "lands after about " + (ticks / 60f + 1f) + " s");
        check(ticks / 60f + 1f > 3f && ticks / 60f + 1f < 7f, "the fall takes 3-7 s");
        check(st.map.kindAt((int) (me.x / 32f), (int) (me.y / 32f)) == TileMap.FLOOR, "landed on standable ground");
        check(me.health == hp && me.spawnProtect > 0f, "landing protection on");
        // keep running until every bot is down
        for (int i = 0; i < 60 * 8; i++) eng.fixedUpdate(1f / 60f, li);
        int airborne = 0; for (Player p : st.players) if (p.connected && p.air > 0f) airborne++;
        check(airborne == 0, "every fighter has landed");
        // ---- loot from a fallen bot
        Player bot = null;
        for (Player p : st.players) if (p.connected && p.bot && p.alive) { bot = p; break; }
        bot.armor = 100; bot.backpack = 2;
        float bx = bot.x, by = bot.y; int botGun = bot.weapon.def.id;
        float maxBorn = 0; for (int i = st.mapPads; i < st.pickups.length; i++) maxBorn = Math.max(maxBorn, st.pickups[i].born);
        int before = countLoot(st);
        bot.health = 1; bot.spawnProtect = 0f;
        // shoot it with a bullet-equivalent: let the host kill it through the public damage path (a melee hit)
        killBot(eng, st, bot, li);
        check(!bot.alive, "bot is down");
        int fresh = 0;
        boolean gun = false, vest = false, pack = false;
        for (int i = st.mapPads; i < st.pickups.length; i++) {
            Pickup pk = st.pickups[i]; if (!pk.active || pk.born <= maxBorn) continue;
            fresh++;
            System.out.println("  new loot: " + Items.name(pk.item) + " ammo " + pk.ammo + " reserve " + pk.reserve + " at " + (int) pk.x + "," + (int) pk.y);
            if (pk.item == botGun) gun = true; if (Items.isVest(pk.item)) vest = true; if (Items.isBackpack(pk.item)) pack = true;
            double d = Math.hypot(pk.x - bx, pk.y - by); if (d > 60) check(false, "loot lies close to the body (" + d + ")");
        }
        check(fresh >= 3, "the fallen bot left at least its gun, vest and backpack (" + fresh + ")");
        check(gun && vest && pack, "gun, vest and backpack are on the ground");
        // ---- swapping guns leaves the old one on the ground
        int padA = -1, padB = -1;
        for (int i = 0; i < st.mapPads; i++) {
            Pickup pk = st.pickups[i];
            if (!pk.active || !Items.isWeapon(pk.item) || WeaponDef.byId(pk.item).melee) continue;
            if (padA < 0) padA = i;
            else if (pk.item != st.pickups[padA].item) { padB = i; break; }
        }
        System.out.println("pads " + padA + " (" + Items.name(st.pickups[padA].item) + ") and " + padB + " (" + Items.name(st.pickups[padB].item) + ")");
        me.health = 100; me.alive = true;
        li.firing = false;
        Pickup A = st.pickups[padA], B = st.pickups[padB];
        me.x = me.rx = A.x; me.y = me.ry = A.y;
        eng.fixedUpdate(1f / 60f, li);
        li.pickup = true; eng.fixedUpdate(1f / 60f, li); li.pickup = false;
        for (int i = 0; i < 5; i++) eng.fixedUpdate(1f / 60f, li);
        System.out.println("after first pickup: slots " + me.slotWeapon[0] + "," + me.slotWeapon[1] + " active " + me.activeSlot + " hand " + me.weapon.def.name);
        check(me.slotWeapon[1] == A.item || me.slotWeapon[0] == A.item, "took " + Items.name(A.item) + " into a slot");
        int held = me.weapon.def.id;
        int ammoHeld = me.weapon.ammo;
        float maxBorn2 = 0; for (int i = st.mapPads; i < st.pickups.length; i++) maxBorn2 = Math.max(maxBorn2, st.pickups[i].born);
        me.x = me.rx = B.x; me.y = me.ry = B.y;
        eng.fixedUpdate(1f / 60f, li);
        li.pickup = true; eng.fixedUpdate(1f / 60f, li); li.pickup = false;
        for (int i = 0; i < 5; i++) eng.fixedUpdate(1f / 60f, li);
        System.out.println("after second pickup: slots " + me.slotWeapon[0] + "," + me.slotWeapon[1] + " hand " + me.weapon.def.name);
        boolean found = false;
        for (int i = st.mapPads; i < st.pickups.length; i++) {
            Pickup pk = st.pickups[i];
            if (pk.active && pk.born > maxBorn2 && pk.item == held) { found = true; System.out.println("  old gun on the ground: " + Items.name(pk.item) + " ammo " + pk.ammo + " reserve " + pk.reserve + " (it had " + ammoHeld + " in the mag)"); check(pk.ammo == ammoHeld, "it keeps the rounds it had"); }
        }
        check(found, "the gun that was replaced lies on the ground, pickable");
        check(me.weapon.def.id == B.item, "the new gun is in hand");
        // pick the old one up again: it swaps back and the second one drops
        Pickup old = null; int oldIdx = -1;
        for (int i = st.mapPads; i < st.pickups.length; i++) if (st.pickups[i].active && st.pickups[i].born > maxBorn2 && st.pickups[i].item == held) { old = st.pickups[i]; oldIdx = i; }
        me.x = me.rx = old.x; me.y = me.ry = old.y;
        eng.fixedUpdate(1f / 60f, li);
        li.pickup = true; eng.fixedUpdate(1f / 60f, li); li.pickup = false;
        for (int i = 0; i < 5; i++) eng.fixedUpdate(1f / 60f, li);
        check(!st.pickups[oldIdx].active || st.pickups[oldIdx].item != held, "taking it again clears its slot");
        check(me.weapon.def.id == held, "swapped back to the first gun");
        System.out.println(fails == 0 ? "ALL PASSED" : (fails + " FAILED"));
    }
    static class World { World(Object o) {} }

    static int countLoot(GameState st) { int n = 0; for (int i = st.mapPads; i < st.pickups.length; i++) if (st.pickups[i].active) n++; return n; }

    static void killBot(SoloEngine eng, GameState st, Player bot, LocalInput li) throws Exception {
        // standing next to it with a stolen gun is awkward: kill it with the zone instead (storm damage path), by putting it outside and starving health
        java.lang.reflect.Field f = SoloEngine.class.getDeclaredField("world");
        f.setAccessible(true);
        GameWorld w = (GameWorld) f.get(eng);
        java.lang.reflect.Method m = GameWorld.class.getDeclaredMethod("damage", int.class, int.class, int.class, int.class, int.class, float.class, float.class);
        m.setAccessible(true);
        m.invoke(w, bot.id, 0, 60, WeaponDef.PISTOL, 0, bot.x, bot.y);
    }
}
