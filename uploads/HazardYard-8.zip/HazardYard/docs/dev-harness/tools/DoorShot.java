import android.graphics.Canvas;
import com.hazardyard.game.core.*;
import com.hazardyard.game.engine.*;
import com.hazardyard.game.input.*;
import com.hazardyard.game.render.*;
import com.hazardyard.game.settings.GameSettings;
import com.hazardyard.game.survival.*;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

public class DoorShot {
    public static void main(String[] a) throws Exception {
        System.setProperty("java.awt.headless", "true");
        String out = a[0]; int want = Integer.parseInt(a[1]); float zoom = Float.parseFloat(a[2]);
        boolean inside = a.length > 3 && a[3].equals("in");
        int W = 1800, H = 810; float d = 2.6f;
        GameSettings gs = new GameSettings();
        SoloEngine eng = new SoloEngine(GameMode.SURVIVAL, 0, 3, 1, "Bru", 1234);
        GameState st = eng.state(); SurvivalState sv = st.survival; LocalInput li = new LocalInput();
        for (int i = 0; i < 400; i++) eng.fixedUpdate(1f / 60f, li);
        for (Zombie z : sv.zombies) z.active = false;
        int[] recs = new int[SurvivalGen.B_STRIDE * 40];
        SurvivalTerrain t = sv.terrain;
        int n = t.gen.buildingsInRect(0, 0, 60, 60, recs);
        int found = 0; int tx = -1, ty = -1, ox = 0, oy = 0;
        for (int i = 0; i < n && tx < 0; i++) {
            int o = i * SurvivalGen.B_STRIDE;
            int x0 = recs[o], y0 = recs[o + 1], w = recs[o + 2], h = recs[o + 3], side = recs[o + 6], along = recs[o + 7];
            int dx, dy, px = 0, py = 0;
            if (side == 2) { dx = x0 + along; dy = y0 + h - 1; py = 1; }
            else if (side == 3) { dx = x0; dy = y0 + along; px = -1; }
            else { dx = x0 + w - 1; dy = y0 + along; px = 1; }
            if (t.objAt(dx, dy) != Obj.DOOR) continue;
            boolean open = (t.metaAt(dx, dy) & 1) != 0;
            if (open != (want == 1)) continue;
            tx = dx; ty = dy; ox = inside ? -px : px; oy = inside ? -py : py;
            System.out.println("door at " + dx + "," + dy + " side " + side + " open " + open);
        }
        Player me = st.local();
        me.x = me.rx = (tx + ox + 0.5f) * 32f; me.y = me.ry = (ty + oy + 0.5f) * 32f + (oy > 0 ? 10f : 0f);
        eng.frameUpdate(1f / 60f, 1f);
        Camera cam = new Camera();
        cam.setUnbounded(true); cam.setViewport(W, H, 1e9f, 1e9f); cam.snapZoom(zoom); cam.snapTo((tx + 0.5f) * 32f, (ty + 0.5f) * 32f);
        BufferedImage img = new BufferedImage(W, H, BufferedImage.TYPE_INT_ARGB);
        Canvas c = new Canvas(img);
        Renderer r = new Renderer(gs);
        float time = 6f;
        for (int k = 0; k < 40; k++) { r.draw(c, st, cam, time); time += 0.016f; }
        ImageIO.write(img, "png", new File(out));
    }
}
