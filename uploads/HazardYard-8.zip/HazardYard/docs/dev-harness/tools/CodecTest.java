import com.hazardyard.game.core.*;
import com.hazardyard.game.engine.*;
import com.hazardyard.game.net.*;
import com.hazardyard.game.survival.*;

public class CodecTest {
    static int fails = 0;
    static void check(boolean ok, String what) { System.out.println((ok ? "PASS " : "FAIL ") + what); if (!ok) fails++; }
    public static void main(String[] a) throws Exception {
        // ---- Battleground gear through the snapshot
        SoloEngine eng = new SoloEngine(GameMode.BATTLEGROUND, 0, 7, 1, "Bru", 5);
        GameState st = eng.state(); LocalInput li = new LocalInput(); li.dropConfirm = true; eng.fixedUpdate(1f / 60f, li); li.dropConfirm = false; /* the match opens with the drop choice: confirm it */
        for (int i = 0; i < 60 * 6; i++) eng.fixedUpdate(1f / 60f, li);
        Player me = st.local();
        me.slotWeapon[0] = WeaponDef.PISTOL; me.slotWeapon[1] = WeaponDef.RIFLE; me.slotAmmo[0] = 7; me.slotAmmo[1] = 21;
        me.slotReserve[0] = 30; me.slotReserve[1] = 77; me.activeSlot = 1; me.backpack = 3; me.armor = 55;
        me.weapon.equip(WeaponDef.byId(WeaponDef.RIFLE)); me.weapon.ammo = 21;
        PacketWriter w = new PacketWriter(2048);
        byte[] frame = SnapshotCodec.encode(w, st, 77);
        PacketReader r = new PacketReader().wrap(frame, 3, frame.length - 3);
        SnapshotCodec.Data d = new SnapshotCodec.Data();
        SnapshotCodec.decode(r, d, st.pickups.length, true);
        check(r.remaining() == 0, "snapshot decoded with nothing left over");
        check((d.gear[0] & 1) == 1 && ((d.gear[0] >> 1) & 3) == 3, "active slot and backpack level survive the snapshot");
        check(d.slot0[0] == WeaponDef.PISTOL && d.slot1[0] == WeaponDef.RIFLE, "both weapons of the slots are carried");
        check(d.otherAmmo[0] == 7 && d.reserve0[0] == 30 && d.reserve1[0] == 77, "each weapon keeps its own ammunition");
        check(d.armor[0] == 55, "armour value is carried");
        check(d.slot0[1] == st.players[1].weapon.def.id && d.reserve0[1] == 65535, "bots send their single weapon with unlimited ammo");
        System.out.println("snapshot size " + frame.length + " bytes for " + st.players.length + " players");

        // ---- Battleground drop-in: the height above the ground, dropped items, the choice of where to land
        me.air = 150f;
        byte[] af = SnapshotCodec.encode(new PacketWriter(2048), st, 78);
        SnapshotCodec.Data da = new SnapshotCodec.Data();
        SnapshotCodec.decode(new PacketReader().wrap(af, 3, af.length - 3), da, st.pickups.length, true);
        check(da.air[0] == 150, "height above the ground survives the snapshot (" + da.air[0] + ")");
        check(af.length == frame.length, "the airborne flag costs no extra bytes");
        me.air = 0f;
        Packets.Loot lp = new Packets.Loot();
        lp.slot = 230; lp.item = 3; lp.x = 1234.5f; lp.y = 4000.25f; lp.ammo = 17; lp.reserve = 90;
        byte[] lf = lp.encode(new PacketWriter(64));
        Packets.Loot lg = new Packets.Loot();
        lg.read(new PacketReader().wrap(lf, 3, lf.length - 3));
        check(lg.slot == 230 && lg.item == 3 && lg.ammo == 17 && lg.reserve == 90, "loot packet: slot, item and rounds round-trip");
        check(Math.abs(lg.x - 1234.5f) < 0.3f && Math.abs(lg.y - 4000.25f) < 0.3f, "loot packet: position round-trips");
        lp.item = -1; lp.ammo = -1; lp.reserve = -1;
        lf = lp.encode(new PacketWriter(64)); lg.read(new PacketReader().wrap(lf, 3, lf.length - 3));
        check(lg.item == -1 && lg.ammo == -1 && lg.reserve == -1, "loot packet: 'empty' and 'no rounds recorded' round-trip");
        Packets.Drop dp = new Packets.Drop();
        dp.choose = true; dp.confirm = true; dp.x = 3216.25f; dp.y = 2448.5f;
        byte[] df = dp.encode(new PacketWriter(32));
        Packets.Drop dg = new Packets.Drop();
        dg.read(new PacketReader().wrap(df, 3, df.length - 3));
        check(dg.choose && dg.confirm && Math.abs(dg.x - 3216.25f) < 0.3f && Math.abs(dg.y - 2448.5f) < 0.3f, "drop choice round-trips");
        check(Protocol.VERSION == 8, "the protocol version moved on (" + Protocol.VERSION + ")");

        // ---- survival: zombie state and events
        SoloEngine se = new SoloEngine(GameMode.SURVIVAL, 0, 3, 1, "Bru", 99);
        GameState ss = se.state(); SurvivalState sv = ss.survival;
        for (int i = 0; i < 400; i++) se.fixedUpdate(1f / 60f, li);
        for (Zombie z : sv.zombies) z.active = false;
        Zombie z0 = CombatTest.spawnAt(sv, 321, ss.local().x + 100, ss.local().y, Zombie.RUNNER);
        z0.setState(Puppet.A_STUMBLE); z0.hurt = 0.1f;
        PacketWriter w2 = new PacketWriter(4096);
        byte[] sf = SurvivalCodec.encodeState(w2, ss);
        GameState client = new SoloEngine(GameMode.SURVIVAL, 0, 3, 1, "Cli", 99).state();
        PacketReader r2 = new PacketReader().wrap(sf, 3, sf.length - 3);
        SurvivalCodec.decodeState(r2, client);
        Zombie dz = null; for (Zombie z : client.survival.zombies) if (z.active && z.id == 321) dz = z;
        check(dz != null, "zombie reaches the client");
        check(dz != null && dz.type == Zombie.RUNNER && dz.state == Puppet.A_STUMBLE, "zombie type and animation state survive the wire");
        byte[] ev = SurvivalCodec.encodeZombieEvent(new PacketWriter(64), 321, Zombie.BRUTE, Zombie.EV_KNOCKDOWN, 12.5f, -40f, 1.2f, 0.9f, 33);
        PacketReader r3 = new PacketReader().wrap(ev, 3, ev.length - 3);
        int kind = r3.u8();
        int id = r3.u16(); int kt = r3.u8(); float x = r3.i32() / GameConfig.POS_SCALE; float y = r3.i32() / GameConfig.POS_SCALE;
        check(kind == 2 && id == 321 && (kt & 15) == Zombie.EV_KNOCKDOWN && ((kt >> 4) & 3) == Zombie.BRUTE, "zombie event fields round-trip");
        check(Math.abs(x - 12.5f) < 0.1f && Math.abs(y + 40f) < 0.1f, "zombie event position round-trips");
        System.out.println(fails == 0 ? "ALL PASSED" : (fails + " FAILED"));
        System.exit(fails == 0 ? 0 : 1);
    }
}
