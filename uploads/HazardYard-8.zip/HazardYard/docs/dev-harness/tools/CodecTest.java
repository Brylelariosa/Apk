import com.hazardyard.game.core.*;
import com.hazardyard.game.engine.*;
import com.hazardyard.game.net.*;
import com.hazardyard.game.survival.*;

public class CodecTest {
    static int fails = 0;
    static void check(boolean ok, String what) { System.out.println((ok ? "PASS " : "FAIL ") + what); if (!ok) fails++; }
    public static void main(String[] a) throws Exception {
        // ---- Battleground gear through the snapshot
        SoloEngine eng = new SoloEngine(GameMode.BATTLEGROUND, 0, 7, 1, "Bru", 5);
        GameState st = eng.state(); LocalInput li = new LocalInput();
        for (int i = 0; i < 60 * 6; i++) eng.fixedUpdate(1f / 60f, li);
        Player me = st.local();
        me.slotWeapon[0] = WeaponDef.PISTOL; me.slotWeapon[1] = WeaponDef.RIFLE; me.slotAmmo[0] = 7; me.slotAmmo[1] = 21;
        me.slotReserve[0] = 30; me.slotReserve[1] = 77; me.activeSlot = 1; me.backpack = 3; me.armor = 55;
        me.weapon.equip(WeaponDef.byId(WeaponDef.RIFLE)); me.weapon.ammo = 21;
        PacketWriter w = new PacketWriter(2048);
        byte[] frame = SnapshotCodec.encode(w, st, 77);
        PacketReader r = new PacketReader().wrap(frame, 3, frame.length - 3);
        SnapshotCodec.Data d = new SnapshotCodec.Data();
        SnapshotCodec.decode(r, d, st.pickups.length, true);
        check(r.remaining() == 0, "snapshot decoded with nothing left over");
        check((d.gear[0] & 1) == 1 && ((d.gear[0] >> 1) & 3) == 3, "active slot and backpack level survive the snapshot");
        check(d.slot0[0] == WeaponDef.PISTOL && d.slot1[0] == WeaponDef.RIFLE, "both weapons of the slots are carried");
        check(d.otherAmmo[0] == 7 && d.reserve0[0] == 30 && d.reserve1[0] == 77, "each weapon keeps its own ammunition");
        check(d.armor[0] == 55, "armour value is carried");
        check(d.slot0[1] == st.players[1].weapon.def.id && d.reserve0[1] == 65535, "bots send their single weapon with unlimited ammo");
        System.out.println("snapshot size " + frame.length + " bytes for " + st.players.length + " players");

        // ---- survival: zombie state and events
        SoloEngine se = new SoloEngine(GameMode.SURVIVAL, 0, 3, 1, "Bru", 99);
        GameState ss = se.state(); SurvivalState sv = ss.survival;
        for (int i = 0; i < 400; i++) se.fixedUpdate(1f / 60f, li);
        for (Zombie z : sv.zombies) z.active = false;
        Zombie z0 = CombatTest.spawnAt(sv, 321, ss.local().x + 100, ss.local().y, Zombie.RUNNER);
        z0.setState(Puppet.A_STUMBLE); z0.hurt = 0.1f;
        PacketWriter w2 = new PacketWriter(4096);
        byte[] sf = SurvivalCodec.encodeState(w2, ss);
        GameState client = new SoloEngine(GameMode.SURVIVAL, 0, 3, 1, "Cli", 99).state();
        PacketReader r2 = new PacketReader().wrap(sf, 3, sf.length - 3);
        SurvivalCodec.decodeState(r2, client);
        Zombie dz = null; for (Zombie z : client.survival.zombies) if (z.active && z.id == 321) dz = z;
        check(dz != null, "zombie reaches the client");
        check(dz != null && dz.type == Zombie.RUNNER && dz.state == Puppet.A_STUMBLE, "zombie type and animation state survive the wire");
        byte[] ev = SurvivalCodec.encodeZombieEvent(new PacketWriter(64), 321, Zombie.BRUTE, Zombie.EV_KNOCKDOWN, 12.5f, -40f, 1.2f, 0.9f, 33);
        PacketReader r3 = new PacketReader().wrap(ev, 3, ev.length - 3);
        int kind = r3.u8();
        int id = r3.u16(); int kt = r3.u8(); float x = r3.i32() / GameConfig.POS_SCALE; float y = r3.i32() / GameConfig.POS_SCALE;
        check(kind == 2 && id == 321 && (kt & 15) == Zombie.EV_KNOCKDOWN && ((kt >> 4) & 3) == Zombie.BRUTE, "zombie event fields round-trip");
        check(Math.abs(x - 12.5f) < 0.1f && Math.abs(y + 40f) < 0.1f, "zombie event position round-trips");
        System.out.println(fails == 0 ? "ALL PASSED" : (fails + " FAILED"));
        System.exit(fails == 0 ? 0 : 1);
    }
}
