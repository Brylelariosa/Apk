import com.hazardyard.game.core.*;
import com.hazardyard.game.engine.*;
import java.lang.reflect.Method;

public class GearTest {
    static int fails = 0;
    static void check(boolean ok, String what) { System.out.println((ok ? "PASS " : "FAIL ") + what); if (!ok) fails++; }
    static Object call(GameWorld w, String name, Class<?>[] types, Object... args) throws Exception {
        Method m = GameWorld.class.getDeclaredMethod(name, types); m.setAccessible(true); return m.invoke(w, args);
    }
    public static void main(String[] a) throws Exception {
        SoloEngine eng = new SoloEngine(GameMode.BATTLEGROUND, 0, 3, 1, "Bru", 5);
        GameState st = eng.state(); LocalInput li = new LocalInput(); li.dropConfirm = true; eng.fixedUpdate(1f / 60f, li); li.dropConfirm = false; /* the match opens with the drop choice: confirm it */
        for (int i = 0; i < 60 * 6; i++) eng.fixedUpdate(1f / 60f, li);
        java.lang.reflect.Field wf = SoloEngine.class.getDeclaredField("world"); wf.setAccessible(true);
        GameWorld world = (GameWorld) wf.get(eng);
        Player me = st.local();
        check(world.usesSlots(me), "the human uses the two-weapon system");
        check(!world.usesSlots(st.players[1]), "bots keep the single-weapon rules");
        check(me.slotWeapon[0] == WeaponDef.PISTOL && me.slotWeapon[1] == -1, "starts with a pistol and an empty second slot");
        check(me.slotReserve[0] == 24, "starts with two spare pistol magazines (" + me.slotReserve[0] + ")");
        call(world, "giveWeapon", new Class<?>[] {Player.class, int.class}, me, WeaponDef.RIFLE);
        check(me.slotWeapon[1] == WeaponDef.RIFLE && me.activeSlot == 1 && me.weapon.def.id == WeaponDef.RIFLE, "a picked-up rifle goes to the empty slot and is taken out");
        check(me.weapon.ammo == WeaponDef.byId(WeaponDef.RIFLE).magSize, "the rifle comes loaded");
        check(me.slotReserve[1] == WeaponDef.byId(WeaponDef.RIFLE).magSize * 2, "the rifle brings its own two spare magazines (" + me.slotReserve[1] + ")");
        check(me.switchTimer > 0f, "the swap takes a moment");
        // wait out the swap, shoot some rifle rounds
        for (int i = 0; i < 40; i++) eng.fixedUpdate(1f / 60f, li);
        li.aim = 0f; li.firing = true;
        for (int i = 0; i < 60; i++) eng.fixedUpdate(1f / 60f, li);
        li.firing = false;
        int rifleAmmo = me.weapon.ammo;
        check(rifleAmmo < WeaponDef.byId(WeaponDef.RIFLE).magSize, "firing uses the rifle's magazine (" + rifleAmmo + ")");
        // switch to the pistol: its own numbers
        li.switchWeapon = true; eng.fixedUpdate(1f / 60f, li); li.switchWeapon = false;
        check(me.activeSlot == 0 && me.weapon.def.id == WeaponDef.PISTOL, "switching takes out the pistol");
        check(me.weapon.ammo == WeaponDef.byId(WeaponDef.PISTOL).magSize, "the pistol still has its own full magazine");
        check(me.slotAmmo[1] == rifleAmmo, "the rifle's rounds were remembered while put away");
        // fire during the swap must not work
        li.firing = true; eng.fixedUpdate(1f / 60f, li); li.firing = false;
        check(me.weapon.ammo == WeaponDef.byId(WeaponDef.PISTOL).magSize, "cannot fire while the weapon is coming up");
        for (int i = 0; i < 40; i++) eng.fixedUpdate(1f / 60f, li);
        // spend the pistol magazine, then reload from its own supply
        li.firing = true; for (int i = 0; i < 200 && me.weapon.ammo > 3; i++) eng.fixedUpdate(1f / 60f, li); li.firing = false;
        int before = me.slotReserve[0], pa = me.weapon.ammo;
        li.reload = true; eng.fixedUpdate(1f / 60f, li); li.reload = false;
        for (int i = 0; i < 200; i++) eng.fixedUpdate(1f / 60f, li);
        int loaded = me.weapon.ammo - pa;
        check(me.weapon.ammo == WeaponDef.byId(WeaponDef.PISTOL).magSize, "the reload fills the magazine (" + me.weapon.ammo + ")");
        check(before - me.slotReserve[0] == loaded, "...and takes exactly those rounds from the pistol's supply (" + before + " -> " + me.slotReserve[0] + ")");
        check(me.slotReserve[1] == WeaponDef.byId(WeaponDef.RIFLE).magSize * 2, "the rifle's supply is untouched");
        // supply caps follow the backpack
        WeaponDef rd = WeaponDef.byId(WeaponDef.RIFLE);
        check(Pickups.reserveCap(me, rd) == rd.magSize * 3, "no backpack: three magazines of reserve");
        me.backpack = 3;
        check(Pickups.reserveCap(me, rd) == rd.magSize * 9, "a large backpack: nine magazines");
        // an ammo crate refills both
        call(world, "refillSupplies", new Class<?>[] {Player.class, int.class}, me, 2);
        check(me.slotReserve[0] > before - loaded && me.slotReserve[1] == Math.min(Pickups.reserveCap(me, rd), rd.magSize * 4), "an ammo crate adds magazines for both weapons");
        // armour absorbs damage and shows on its own bar value
        me.armor = 50; me.health = 100;
        int h0 = me.health, a0 = me.armor;
        world.hurt(me.id, 20, 1, 0, me.x, me.y);
        System.out.println("armour " + a0 + " -> " + me.armor + ", health " + h0 + " -> " + me.health);
        check(me.armor < a0 && me.health < h0 && me.health > 100 - 20, "armour soaks part of a hit");
        System.out.println(fails == 0 ? "ALL PASSED" : (fails + " FAILED"));
        System.exit(fails == 0 ? 0 : 1);
    }
}
