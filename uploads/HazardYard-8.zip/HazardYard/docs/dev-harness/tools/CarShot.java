import android.graphics.Canvas;
import com.hazardyard.game.core.*;
import com.hazardyard.game.engine.*;
import com.hazardyard.game.render.*;
import com.hazardyard.game.settings.GameSettings;
import com.hazardyard.game.survival.*;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;
public class CarShot {
    public static void main(String[] a) throws Exception {
        System.setProperty("java.awt.headless", "true");
        int W = 1800, H = 810;
        GameSettings gs = new GameSettings();
        SoloEngine eng = new SoloEngine(GameMode.SURVIVAL, 0, 3, 1, "Bru", 1234);
        GameState st = eng.state(); SurvivalState sv = st.survival; LocalInput li = new LocalInput();
        for (int i = 0; i < 400; i++) eng.fixedUpdate(1f / 60f, li);
        for (Zombie z : sv.zombies) z.active = false;
        Player me = st.local();
        float bx = me.x, by = me.y;
        for (int k = 0; k < 6; k++) {
            Car car = sv.cars[k]; car.active = true; car.x = car.rx = bx - 120 + (k % 3) * 100; car.y = car.ry = by - 100 + (k / 3) * 70;
            car.heading = car.rHeading = (float) (k * 0.35); car.variant = k * 2 + (k / 2) * 6; car.running = k == 1; car.engineOk = k != 4; car.batteryOk = true; car.tyresOk = true; car.hp = 100; car.fuel = 50;
        }
        me.x = me.rx = bx; me.y = me.ry = by;
        eng.frameUpdate(1f / 60f, 1f);
        Camera cam = new Camera();
        cam.setUnbounded(true); cam.setViewport(W, H, 1e9f, 1e9f); cam.snapZoom(2.4f); cam.snapTo(bx - 20, by - 65);
        BufferedImage img = new BufferedImage(W, H, BufferedImage.TYPE_INT_ARGB);
        Canvas c = new Canvas(img);
        Renderer r = new Renderer(gs);
        float time = 6f;
        for (int k = 0; k < 4; k++) { r.draw(c, st, cam, time); time += 0.016f; }
        System.out.println("cam " + cam.x + "," + cam.y + " player " + me.rx + "," + me.ry + " car0 " + sv.cars[0].rx + "," + sv.cars[0].ry + " vis " + cam.isVisible(sv.cars[0].rx, sv.cars[0].ry, 80f) + " active " + sv.cars[0].active);
        ImageIO.write(img, "png", new File(a[0]));
        System.out.println("ok");
    }
}
