import com.hazardyard.game.core.*;
import com.hazardyard.game.engine.*;
import com.hazardyard.game.net.*;
import com.hazardyard.game.survival.*;

/** Hosted survival over a real loopback socket: does the client get the world, and do its commands reach the host? */
public class NetSurvTest {
    static int fails = 0;
    static void check(boolean ok, String what) { System.out.println((ok ? "PASS " : "FAIL ") + what); if (!ok) fails++; }
    public static void main(String[] a) throws Exception {
        HostManager host = new HostManager(47831, 47832);
        host.start("Hosty");
        host.setModeId(GameMode.SURVIVAL);
        ClientManager client = new ClientManager();
        client.connect("127.0.0.1", host.port(), "Clienty", new ClientManager.Listener() {
            public void onConnected(int id) {} public void onLobbyChanged() {} public void onRejected(int r) {}
            public void onMatchStart() {} public void onReturnToLobby() {} public void onDisconnected(String why) { System.out.println("disconnected " + why); }
        });
        long t0 = System.currentTimeMillis();
        while (host.lobby().count() < 2 && System.currentTimeMillis() - t0 < 6000) Thread.sleep(20);
        client.sendReady(true); host.lobby().setReady(0, true);
        boolean started = false; t0 = System.currentTimeMillis();
        while (!started && System.currentTimeMillis() - t0 < 5000) { started = host.startMatch(); Thread.sleep(50); }
        t0 = System.currentTimeMillis();
        while (!client.isInMatch() && System.currentTimeMillis() - t0 < 5000) Thread.sleep(20);
        HostEngine he = new HostEngine(host);
        ClientEngine ce = new ClientEngine(client);
        GameState hs = he.state(), cs = ce.state();
        LocalInput hin = new LocalInput(), cin = new LocalInput();
        for (int i = 0; i < 700; i++) { he.fixedUpdate(1f / 60f, hin); ce.fixedUpdate(1f / 60f, cin); Thread.sleep(3); }
        int hz = 0, cz = 0;
        for (Zombie z : hs.survival.zombies) if (z.active) hz++;
        for (Zombie z : cs.survival.zombies) if (z.active) cz++;
        System.out.println("zombies host " + hz + " client " + cz + " finished? " + ce.isFinished());
        check(!ce.isFinished(), "the client is still running");
        check(hz > 0 && cz > 0, "the client sees zombies (" + cz + " of " + hz + ")");
        int myId = client.localPlayerId();
        check(cs.survival.hunger[myId] > 0f, "client gets survival state (hunger " + cs.survival.hunger[myId] + ")");
        // a client command reaches the host: select hotbar slot 2
        int before = hs.survival.inv[myId].selected;
        int slot = before == 1 ? 2 : 1;
        cin.cmdCount = 1; cin.cmdType[0] = SurvivalSim.CMD_SELECT; cin.cmdA[0] = slot; cin.cmdB[0] = 0;
        for (int i = 0; i < 10; i++) { he.fixedUpdate(1f / 60f, hin); ce.fixedUpdate(1f / 60f, cin); Thread.sleep(8); cin.cmdCount = 0; }
        System.out.println("selected slot on host: " + hs.survival.inv[myId].selected + " (asked " + slot + ", was " + before + ")");
        check(hs.survival.inv[myId].selected == slot, "a survival command from the client reaches the host");
        System.out.println(fails == 0 ? "ALL PASSED" : (fails + " FAILED"));
        client.close(); host.close(); System.exit(fails == 0 ? 0 : 1);
    }
}
