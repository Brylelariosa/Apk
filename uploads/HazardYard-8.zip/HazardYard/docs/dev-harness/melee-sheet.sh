#!/bin/bash
cd /home/claude/harness
java -Dzoom=${ZOOM:-4.2} -Djava.awt.headless=true -cp out:tools_out com.hazardyard.game.render.MeleeSheet "$@" 2>&1 | tail -2
