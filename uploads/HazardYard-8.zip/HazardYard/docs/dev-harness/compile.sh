#!/bin/bash
# usage: compile.sh [srcdir]   -> compiles stubs + project to /home/claude/harness/out
SRC=${1:-/home/claude/HazardYard/app/src/main/java}
rm -rf /home/claude/harness/out && mkdir -p /home/claude/harness/out
find /home/claude/harness/stubs -name "*.java" > /tmp/files.txt
find $SRC -name "*.java" >> /tmp/files.txt
java -m jdk.compiler/com.sun.tools.javac.Main -nowarn -Xmaxerrs 400 -d /home/claude/harness/out @/tmp/files.txt 2>&1
