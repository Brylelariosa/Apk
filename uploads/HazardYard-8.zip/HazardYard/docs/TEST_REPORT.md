# HazardYard 1.4 - what was tested, and how

This build was prepared without an Android device or the Android SDK, so everything that does not need a real screen,
finger or speaker was tested **headless on a PC JVM** (the game logic, bots, networking and sound synthesis are plain
Java), and the drawing code was run through a Java2D stand-in for `android.graphics` to produce the pictures in this
folder. **Not tested here: touch input on a real phone, how the sounds actually *sound* through a speaker, real frame
rates on a phone, and the Android view screens (menus) running on a device.** Those were compile-checked and reviewed,
nothing more. Please try the items marked "on device" below first.

## Results

| Area | How it was checked | Result |
|---|---|---|
| Whole project compiles | `javac` over every source file against stubs of the Android API; the **original** 1.3 project compiles against the same stubs with zero errors, so the stubs match real use | 0 errors |
| Pistol / SMG / Magnum / Shotgun (and the other four guns): reload | 114 rule tests: total time, moment the ammunition comes back (`seatFraction`), shotgun loads one shell per 0.42 s, rounds stay when interrupted | all pass |
| Reload interruption | new trigger pull cancels (keeps ammo, no refill); a trigger held before the reload does not; empty magazine gun cannot be interrupted; dodge cancels, empty gun reloads again after the roll; weapon pickup cancels; reload pressed mid-roll waits | all pass |
| Reload / dodge / pickup sounds follow the game state | recorded sound events: start x1, shell-in x4, ready x1 for the shotgun, also on a networked client; exactly **one** dodge sound when the dodge button is mashed; no "ready" sound for a cancelled reload; pump/bolt/hammer sounds scheduled 0.34 / 0.46 / 0.20 s after the shot | all pass |
| Gun sounds are different | A-weighted spectrogram distance between every pair of guns (min 9.6 dB, the original 1.3 shots were 8.4); every reload stage across the 8 guns has a pairwise distance of at least 9.7 dB; no two sounds share a waveform; no clipping, no clicks at the ends | pass (**listen on device**) |
| Manual pickup | standing on a weapon for 2 s takes nothing; the prompt appears only within reach and with a clear line; the press takes it, swaps the gun, refills the same gun; not during a roll; pads refill after their respawn time; every pad of every map is valid | all pass |
| Battleground, 2 real players + bots | real TCP loopback: host + 1 client -> 2 humans + 6 bots, client mirrors all 8 fighters, names, pads, weapons | pass |
| Battleground, 4 real players + bots | host + 3 clients -> 4 humans + 4 bots; a human who leaves is not replaced by a bot | pass |
| Pickup / reload / dodge over the network | client presses Pick Up -> host swaps the gun -> client sees it; reload and dodge interruption over the wire | pass |
| Full Battleground matches | 7 bots, 6 minutes each: matches end, 70-90 kills per match, bots empty ~80 pads, no NaN / out-of-map positions, 99% of ticks under 0.2 ms of game logic | pass |
| Map | 120 x 80 tiles (3.8x the area of the biggest classic map), 32 weapon pads, 24 spawns; every spawn can reach every pad (791 routes checked) | pass |
| Bot shaking (measured, 10 runs of 90 s) | heading reversals per second **12.5 -> 0.55**, aim reversals per second **13.9 -> 1.1**, big heading jumps 25% -> 2.3%, aim snaps 25% -> 6%, leg direction flips (with the old animation code) 12.2 -> 1.2 per second | fixed |
| Soldier leg flip (animation side of the shaking) | the legs now follow the smoothed velocity and only turn around with hysteresis (see `UnitRenderer`) | by construction + replay of the old logic |
| "Circle character" (quality governor) | simulated frame-time traces: slow first seconds, a 2 s slow patch, hitches, a really slow phone, recovery, flip-flop, 120 Hz screens | 12/12 pass |
| HUD layout | default layout has no overlaps on 20:9, 19.5:9, 16:9, 4:3 and 640x360 dp screens; an element can never leave the screen (also at maximum size in a corner); hit area grows exactly with the size | pass (one 533x320 dp case still overlaps, as the 1.3 layout did) |
| Customize HUD vs Controls | HUD editor only touches position and size (`copyLayoutFrom`), Controls only touches options (`resetOptions`); editor picture rendered (see `hud-editor.png`) | pass (**touch on device**) |

## Please try on a device first
1. Battleground with a friend (and with 3-4 phones): lobby mode switch, bots filling the roster.
2. Pick Up: walk over a weapon (nothing should happen), press the button.
3. A reload of each gun: sounds and the arm movement; fire in the middle of a reload.
4. Pause -> Customize HUD (drag, pinch, slider, Reset layout, Save/Cancel) and Pause -> Controls.
5. The sounds themselves: if one of them is not to your taste, the recipes are in `audio/SoundBank.java`.

## Version 1.5 (battle royale, melee, survival)

Checked the same way as before: every non-UI source file compiled with a stand-in for the Android graphics API, the pure-Java
logic run on a JVM, and real frames of the real renderers drawn to PNG (see the screenshots in this folder). The UI classes
(`ui/`, `MainActivity`) cannot be built off the phone; they were compiled together with everything else and every error
that remained was a missing Android framework class, none a project symbol. What cannot be judged without a device:
how the controls feel under a thumb, frame rate on the Infinix, and how the sounds actually sound.

**Battleground (battle royale)**
- 14 matches of 8 bots on the new island: every match ended with one winner holding place 1 and all places 1..8 handed out
  exactly once; matches lasted 90-260 s (bots find each other fast; a human takes longer). Vests were picked up 5-13 times and
  kits 1-5 times a match. Armour values never left 0..100.
- `Zone`: 300 random zones, every next circle lies inside the previous one, no target centre on water or a wall, and the
  collapse takes 476 s on average (the schedule adds up to 475 s).
- The island builds in about 120 ms on a laptop (192 x 192 tiles, 79 buildings, 190+ item pads, 20+ spawn points), is one
  connected stretch of ground (anything unreachable is filled in), and is identical on every run.
- Wire format: a battle-royale snapshot round-trips armour, places, positions beyond 4096 units, all 220 pad bits and the zone
  (125 bytes with 4 players).
- Classic arenas (all 8, 4 bots each) still play and end as before.

**Melee and guns**: a blow lands after its hit delay, does not reach 240 units, does not hit behind the fighter, a vest takes
60% (knife 24: armour 50 -> 36, health 100 -> 90), and an axe kills in a few blows.

**Sound**: the assault rifle shot is byte for byte the original; the other 13 gun shots, 14 x 3 reloads, the swings and the
survival sounds are all in range (peak 0.8-0.95) and the guns share the rifle's loudness (RMS 0.24-0.39 against its 0.32).
`gun-sounds.png` shows the envelopes and spectrograms: same attack-and-decay shape, separate size and tail per gun, and
distinct mechanical events in the reloads.

**Survival**: a scripted solo game on a fresh world: spawn with a kit, search 12 pieces of furniture in the start town (50
items), craft an axe and a workbench, place a wall, till soil, plant and grow a crop to ripe, fight 25 zombies at night (34 kills
with a knife, 0.05 ms of simulation per step), find a wreck, fit tyre, battery and engine parts with a wrench and fuel, get in, drive
(251 units/s after four seconds, the survivor follows the car), get out; die (the pack drops) and respawn with the starter kit.
The survival state frame holds 1291 bytes with 44 zombies, 12 cars and 40 items in sight (limit 4096), and zombies, cars, items,
hunger, fishing, the clock, inventories, commands and tile edits all round-trip through `SurvivalCodec` (including positions
100,000 units from the origin). Generating the 49 chunks round the start takes a few milliseconds.

# Version 1.6 checks

Everything below was run headless against the real classes (see `docs/dev-harness`): the Android framework is replaced
by stubs, `android.graphics` by Java2D, so the real renderer produced the screenshots in `docs/`. It has not been run on a
phone: the numbers about speed below count draw work, they are not frame times.

| Check | Result |
|---|---|
| Whole project compiles (about 27,000 lines) against the stubs | 0 errors |
| `CombatTest`: a bat equipped from the bag has a 3-attack combo; the first swing pushes a zombie 40 units ahead *to the attacker's right*; a zombie 120 units away or behind the player is not hit; repeated hits make zombies stumble and fall; a kill removes the zombie and starts a ragdoll that ends lying on the ground | 13 / 13 pass |
| `GearTest`: the human uses two weapon slots, bots keep one; a picked-up rifle goes to the empty slot and brings 2 spare magazines; each weapon keeps its own magazine and supply when switched; no firing while the weapon comes up; a reload takes exactly the rounds it loads from that weapon's supply only; supply caps follow the backpack (3 magazines, 9 with a large one); an ammo crate refills both; armour absorbs part of a hit | 20 / 20 pass |
| `CodecTest`: gear (active slot, backpack, both weapons, other magazine, both supplies) survives the snapshot; bots send one weapon with unlimited ammo; zombie type and animation state, and the zombie hit event, survive the wire; snapshot for 8 players is 257 bytes | 10 / 10 pass |
| `UiTest`: touch logic of the new screens: the bag button opens the bag; **its close (X) button closes the bag without opening the pause menu** (the old bug); the pause button still works with the bag shut; tap-to-select and tap-to-swap, drag and drop, the Craft tab, a recipe pick, a tap outside closes the bag, a touch on the bag never reaches the pause button; spectator Previous / Next / Leave | 15 / 15 pass |
| `DoorTest`: the island has 87 houses and 93 doorways; every house has at least one and each leads outside (flood fill from the step reaches 600+ tiles) | pass |
| `ZoneTest` / `Sweep`: 9 Battleground matches with 1, 3 and 7 bots, 3 seeds each, a random-input player: all end with a winner (57-170 s); the radius never grows; the circle is down to 390-1317 units (6-21% of the map) when it ends instead of 1400-2600 | pass |
| `Sweep`: two ten-minute survival sessions (up to 30 zombies, a flailing survivor firing all the time) | no exception; at most 8 ragdolls alive |
| Pose, turntable and fall / attack sequence renders (`docs/zombies-walk.png`, `docs/zombie-fall.png`) | looked at, tuned |

Cost, counted (`FaceCount`): a zombie is about 18 polygons at the lowest detail, 53 at the middle and 79 at the highest. The renderer picks
the level from how many bodies are on screen (up to 5: full; up to 10: middle; more: lowest; the "light" quality setting is one level lower), so
the whole crowd stays near 570 polygons at most. At most 10 ragdolls are alive (each sleeps once it stops moving, then fades), and the physics runs at most three
60 Hz steps per frame. Blood decals are limited to 40, particles to the old pool size.

Known limits: the HUD and the new screens were checked at 1800 x 810 only; the real game also has its sound and touch
handling, which this harness cannot exercise (the touch code is plain Java and was reasoned through: the bag is modal, the spectator
buttons own their touches). The first run on a device should look at the Battleground Switch button (it sits above Dodge by default and can be
moved in the HUD editor) and at frame times with a crowd of zombies on an older phone.

## Version 1.7 (drop-in and loot, melee, map, survival respawn)

Same method as 1.5: everything was run headless against the real classes through the stand-in harness (`docs/dev-harness`); the
screenshots in `docs/` were drawn by the real renderer. **Not run on a phone**: touch input on the drop map, real frame times, sound.

| Check | Result |
|---|---|
| Whole project compiles against the stubs | 0 errors |
| `CombatTest` (the bat now has a 4-attack combo: swing, backhand, overhead, spin) | 13 / 13 pass |
| `GearTest` (the gun replaced by a pickup now drops; the two-argument `giveWeapon` is kept for the test) | 20 / 20 pass |
| `CodecTest`: + the height above the ground survives the snapshot (no extra bytes), loot packet (slot, item, rounds, position, "empty"), drop-choice packet, protocol version 8 | 17 / 17 pass |
| `UiTest` | 15 / 15 pass |
| `DropTest`: the match opens in the drop choice (16 s, the 7 bots already chose); a tap + Drop starts the drop at once; the player is over the chosen place; steering moves them (96 units/s); the fall takes ~3.8 s; they land on standable ground with protection; every bot lands; a fallen bot leaves its gun (with its rounds), heavy vest and backpack within 60 units; picking up a second map gun puts the replaced one on the ground with its rounds, and taking that again swaps back | 23 / 23 pass |
| `NetDropTest` (real loopback socket: host + 1 client + 6 bots): the client's chosen place reaches the host, both sides agree it is in the air and how high, steering reaches the host, both land and agree to within 0 units, and the loot the host drops is on the client with the same item, position and rounds | 16 / 16 pass |
| `NetSurvTest` (hosted survival over a socket: the client sees zombies and its hunger, a hotbar command reaches the host) | 4 / 4 pass - **this test found that hosted survival never worked** (see below) |
| `RespawnSweep`: 150 world seeds, a survivor starving far from the start with a full pack | everybody comes back; respawn 133-747 units from where they fell, always on open ground |
| `MeleeStats` (12 seeded duels per cell, a player who walks up and swings with a slightly shaky aim; original -> new): fists vs 3 walkers 2/12 -> 7/12 cleared; fists vs a brute 12.7 s -> 9.7 s and 43 -> 11 health lost (11/12 cleared instead of 12/12); pickaxe vs 5 walkers 10/12 -> 12/12 cleared and 87 -> 48 health lost; fire axe vs 3 walkers 11/12 -> 12/12 and 46 -> 23 lost; knife vs 5 walkers 5.1 s -> 4.5 s; bat, crowbar and machete about the same. **Worse**: against a single brute the knife now loses about 26 health (was 0), the fire axe 21 (was 2) and the pickaxe 16 (was 0): the faster kills are bought with stepping into the brute's reach | mostly better, brutes are a little more dangerous |
| `ZoneTest` / `Sweep`: Battleground matches with the drop (1, 3 and 7 bots) all end with a winner (72-192 s); ten-minute survival sessions | no exception |
| Melee poses | a contact sheet of every attack of every weapon was looked at (`docs/melee-*.png`, `MeleeSheet`) |
| Render cost (`RenderBench`, Java2D stand-in = software rendering, so only the *ratio* means something; original -> new): Battleground town 26 -> 31 ms, shore 21 -> 20-26 ms, forest 33 -> 39-42 ms; survival 17 -> 34 ms in one scene and 29 -> 29 ms in another. The light graphics level skips the ground blotches, the blending of grounds, foam, glints, leaf speckle and roof detail | **time it on a phone** |

Found while testing: **`HostManager` ignored every survival command (`C_SURV`) from a client, and `ClientManager` ignored every survival frame
(`S_SURV`, `S_SURV_EVENT`, `S_SURV_EDIT`, `S_SURV_INV`) from the host**, so a second player in a hosted survival game saw an empty world.
Both whitelists now let them through. The new `C_DROP` and `S_LOOT` messages needed the same.

About "if you die in survival you never revive": it could not be reproduced here (solo and hosted, 150 worlds, starvation and zombies, far
from the start, with the bag open). So the change is defensive: the death screen now says you will get back up and where your pack is, a
watchdog respawns anyone still dead two seconds after the timer, and you come back near where you fell instead of at the start. If it still
happens on a phone, please note what was on screen (the text, whether the world kept moving): that points at the cause.

Please try on a device first: (1) the drop map: tap, drag the marker, Drop here, then steer on the way down; (2) loot from a bot you
killed, and swapping guns; (3) every melee weapon on zombies: the stab, the lunge, the spin; (4) frame rate in Battleground towns and in the
survival forest on an older phone; (5) hosted Battleground and survival with a second phone (both sides need this build: the protocol is 8).
