package com.hazardyard.game.core;

/** Smooth top-down camera that follows the local player and never shows beyond the map edge. */
public final class Camera {
    /** World position shown at the centre of the screen. */
    public float x, y;
    /** Screen pixels per world unit: {@link #baseScale} times the current gun {@link #zoom}. */
    public float scale = 1f;
    public int viewW = 1, viewH = 1;
    private float worldW = 1f, worldH = 1f;
    /** Pixels per world unit of the standard (zoom 1) view. */
    private float baseScale = 1f;
    /** Current zoom multiplier, eased towards {@link #zoomTarget}. */
    private float zoom = 1f;
    private float zoomTarget = 1f;
    /** A short shake for heavy hits: an offset added to the view when drawing (it does not move the camera itself). */
    public float shakeX, shakeY;
    private float shakeAmp;
    private int shakeSeed = 12345;

    /** Chooses a base scale so at least VIEW_MIN_WIDTH x VIEW_MIN_HEIGHT world units are visible on any screen. */
    public void setViewport(int w, int h, float worldWidth, float worldHeight) {
        viewW = Math.max(1, w);
        viewH = Math.max(1, h);
        worldW = worldWidth;
        worldH = worldHeight;
        baseScale = Math.min(viewH / GameConfig.VIEW_MIN_HEIGHT, viewW / GameConfig.VIEW_MIN_WIDTH);
        scale = baseScale * zoom;
        clampToWorld();
    }

    /** The zoom to ease towards (a gun's {@link WeaponDef#zoom}); below 1 shows more of the world, above 1 less. */
    public void setZoomTarget(float z) {
        zoomTarget = MathUtil.clamp(z, GameConfig.ZOOM_MIN, GameConfig.ZOOM_MAX);
    }

    /** Jumps straight to a zoom without easing (first frame of a match). */
    public void snapZoom(float z) {
        setZoomTarget(z);
        zoom = zoomTarget;
        scale = baseScale * zoom;
        clampToWorld();
    }

    /** Eases the zoom towards its target; call once per frame. */
    public void updateZoom(float dt) {
        if (zoom == zoomTarget) return;
        float k = 1f - (float) Math.exp(-GameConfig.ZOOM_RATE * dt);
        zoom += (zoomTarget - zoom) * k;
        if (Math.abs(zoomTarget - zoom) < 0.0005f) zoom = zoomTarget;
        scale = baseScale * zoom;
        clampToWorld();
    }

    /** Starts (or strengthens) a shake of about {@code amplitude} world units; it dies away within a fraction of a second. */
    public void shake(float amplitude) {
        shakeAmp = Math.max(shakeAmp, Math.min(amplitude, 7f));
    }

    /** Advances the shake; call once per frame. */
    public void updateShake(float dt) {
        if (shakeAmp < 0.05f) {
            shakeAmp = 0f;
            shakeX = 0f;
            shakeY = 0f;
            return;
        }
        shakeSeed = shakeSeed * 1103515245 + 12345;
        float a = ((shakeSeed >>> 8) & 0xFFFF) / 32768f - 1f;
        shakeSeed = shakeSeed * 1103515245 + 12345;
        float b = ((shakeSeed >>> 8) & 0xFFFF) / 32768f - 1f;
        shakeX = a * shakeAmp;
        shakeY = b * shakeAmp;
        shakeAmp *= (float) Math.exp(-16f * dt);
    }

    public float zoom() {
        return zoom;
    }

    public void snapTo(float tx, float ty) {
        x = tx;
        y = ty;
        clampToWorld();
    }

    public void follow(float tx, float ty, float dt) {
        float k = 1f - (float) Math.exp(-GameConfig.CAMERA_FOLLOW_RATE * dt);
        x += (tx - x) * k;
        y += (ty - y) * k;
        clampToWorld();
    }

    public float halfViewWorldW() {
        return viewW * 0.5f / scale;
    }

    public float halfViewWorldH() {
        return viewH * 0.5f / scale;
    }

    /**
     * The survival world has no edges (and reaches into negative coordinates), so its camera must not be held inside
     * [0, world]: that left the survivor off-centre near the start.
     */
    private boolean unbounded;

    public void setUnbounded(boolean b) {
        unbounded = b;
    }

    private void clampToWorld() {
        if (unbounded) return;
        float hw = halfViewWorldW();
        float hh = halfViewWorldH();
        x = worldW <= hw * 2f ? worldW * 0.5f : MathUtil.clamp(x, hw, worldW - hw);
        y = worldH <= hh * 2f ? worldH * 0.5f : MathUtil.clamp(y, hh, worldH - hh);
    }

    public float screenX(float wx) {
        return (wx - x) * scale + viewW * 0.5f;
    }

    public float screenY(float wy) {
        return (wy - y) * scale + viewH * 0.5f;
    }

    /** True when a point (with a margin in world units) lies inside the visible area. */
    public boolean isVisible(float wx, float wy, float margin) {
        return Math.abs(wx - x) <= halfViewWorldW() + margin && Math.abs(wy - y) <= halfViewWorldH() + margin;
    }
}
