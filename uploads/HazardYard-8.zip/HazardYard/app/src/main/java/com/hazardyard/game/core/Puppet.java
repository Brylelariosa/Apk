package com.hazardyard.game.core;

/**
 * A little procedural skeleton for everything that walks, swings, falls over and ends up on the ground: zombies (alive,
 * hit, stumbling, knocked down, getting up) and the starting pose of a ragdoll. A pose is thirteen joints in the body's
 * own frame (x forward, y to its right, z up); {@link #toWorld} turns it into world coordinates.
 *
 * <p>Nothing here allocates after construction. Every animation is a pure function of the inputs, so two devices that
 * show the same zombie in the same state show the same movement, and blending between states is a matter of changing
 * the inputs smoothly (the renderer eases {@link #gait} and the overlays instead of switching poses).
 */
public final class Puppet {
    public static final int J_HEAD = 0, J_SH_L = 1, J_SH_R = 2, J_HIP_L = 3, J_HIP_R = 4, J_ELB_L = 5, J_HAND_L = 6,
            J_ELB_R = 7, J_HAND_R = 8, J_KNEE_L = 9, J_FOOT_L = 10, J_KNEE_R = 11, J_FOOT_R = 12;
    public static final int JOINTS = 13;

    /** Animation states (also the zombie state numbers on the wire). */
    public static final int A_IDLE = 0, A_WALK = 1, A_RUN = 2, A_ATTACK = 3, A_HIT = 4, A_STUMBLE = 5, A_FALL = 6, A_DOWN = 7,
            A_GETUP = 8;

    /** Body builds: they decide posture and stride. */
    public static final int B_NORMAL = 0, B_RUNNER = 1, B_BRUTE = 2, B_SOLDIER = 3;

    // ---- proportions at scale 1
    public static final float HIP_Z = 11.2f, SHOULDER_Z = 19.0f, HEAD_Z = 24.4f;
    private static final float THIGH = 5.9f, SHIN = 5.5f, UPPER_ARM = 5.3f, FOREARM = 5.5f;
    /** Height of a body part resting on the floor. */
    public static final float FLOOR_Z = 1.9f;

    // ------------------------------------------------------------------ inputs
    public int anim;
    /** Seconds spent in the current state (fall, get-up, stumble). */
    public float t;
    /** Walk cycle angle in radians. */
    public float phase;
    /** 0 standing still .. 1 full walking stride; above 1 running. */
    public float gait;
    /** Global clock (seconds) for idle sway. */
    public float clock;
    /** A constant per individual in [0, 1): decides limp side, head lean, twitch timing. */
    public float seed;
    /** 0..1 progress of an attack swing. */
    public float attackP;
    /** Unit direction (body frame) the last blow pushed this body along; {@link #hitK} is how hard, {@link #hitT} how long ago. */
    public float hitX, hitY, hitK, hitT = 9f;
    /** Unit direction (body frame) a falling body goes down in: its head ends up that way. */
    public float fallX = -1f, fallY;
    public float scale = 1f;
    public float width = 1f;
    public int build = B_NORMAL;
    /** How far the arms are raised for the reach (0 hanging, 1 stretched out in front), eased by the caller. */
    public float reach = 1f;

    // ------------------------------------------------------------------ output
    /** Thirteen joints, x / y / z each, in the body frame. */
    public final float[] j = new float[JOINTS * 3];

    private final float[] a = new float[JOINTS * 3];
    private final float[] b = new float[JOINTS * 3];
    private final float[] ik = new float[6];

    public static float smooth(float x) {
        x = MathUtil.clamp(x, 0f, 1f);
        return x * x * (3f - 2f * x);
    }

    private void set(float[] o, int joint, float x, float y, float z) {
        o[joint * 3] = x;
        o[joint * 3 + 1] = y;
        o[joint * 3 + 2] = z;
    }

    /** Computes the pose for the current inputs into {@link #j}. */
    public void compute() {
        switch (anim) {
            case A_FALL: fall(); break;
            case A_DOWN: lying(j, clock); break;
            case A_GETUP: getUp(); break;
            default: upright(j, true); break;
        }
    }

    // ------------------------------------------------------------------ upright poses

    private void upright(float[] o, boolean overlays) {
        final float s = scale;
        final boolean run = build == B_RUNNER || gait > 1.15f;
        final boolean brute = build == B_BRUTE;
        float g = MathUtil.clamp(gait, 0f, 1.6f);
        float stride = (run ? 8.0f : (brute ? 5.2f : 6.0f)) * Math.min(g, 1.2f);
        float sn = (float) Math.sin(phase), cs = (float) Math.cos(phase);
        float bob = Math.abs(sn) * (run ? 1.5f : 0.95f) * Math.min(g, 1.3f);
        // a shuffling limp: one leg drags a little shorter and the body leans towards it
        float limp = seed < 0.5f ? -1f : 1f;
        float drag = 0.28f * Math.min(g, 1f) * (build == B_SOLDIER ? 0f : 1f);
        float sw = (float) Math.sin(clock * 0.9f + seed * 11f);

        float shW = 5.0f * width, hpW = 3.0f * width;
        if (build == B_SOLDIER) { shW = 6.6f * width; hpW = 3.7f * width; }
        float leanF = run ? 4.4f : (brute ? 2.6f : 1.5f);
        if (build == B_SOLDIER) leanF = 0.6f;
        leanF += (1f - Math.min(g, 1f)) * (brute ? 0.5f : 0.3f);

        float hipZ = HIP_Z - bob;
        float shZ = SHOULDER_Z - bob * 0.55f - (brute ? 1.2f : 0f) - (run ? 1.2f : 0f);
        float hdZ = HEAD_Z - bob * 0.5f - (brute ? 1.9f : 0.7f) - (run ? 0.8f : 0f);
        float sway = sn * 0.7f * Math.min(g, 1f) + sw * 0.35f * (1f - Math.min(g, 1f));
        float twist = sn * (run ? 1.6f : 0.9f) * Math.min(g, 1f);

        // hips
        set(o, J_HIP_L, 0f, -hpW + sway * 0.5f, hipZ);
        set(o, J_HIP_R, 0f, hpW + sway * 0.5f, hipZ);
        // shoulders (twist against the hips) and head
        float shX = leanF + (limp * sn > 0 ? 0f : 0f);
        set(o, J_SH_L, shX + twist, -shW - sway * 0.6f, shZ);
        set(o, J_SH_R, shX - twist, shW - sway * 0.6f, shZ);
        float headLolls = (float) Math.sin(phase * 0.5f + seed * 9f) * 0.9f * Math.min(g, 1f) + sw * 0.8f * (1f - Math.min(g, 1f));
        float headX = shX + (run ? 2.6f : (brute ? 1.1f : 1.5f)) + (build == B_SOLDIER ? -0.6f : 0f);
        set(o, J_HEAD, headX, headLolls + limp * 0.6f * drag * 3f, hdZ);

        // legs: feet swing forward and back, lift on the way forward
        float footL = sn * stride;
        float footR = -sn * stride;
        float liftL = Math.max(0f, cs) * (run ? 3.2f : 2.1f) * Math.min(g, 1.3f);
        float liftR = Math.max(0f, -cs) * (run ? 3.2f : 2.1f) * Math.min(g, 1.3f);
        if (limp < 0f) { footL *= 1f - drag; liftL *= 1f - drag * 1.4f; } else { footR *= 1f - drag; liftR *= 1f - drag * 1.4f; }
        float footSide = hpW * 1.08f;
        // standing stance is a touch wider and one foot sits slightly ahead
        float idleK = 1f - Math.min(g, 1f);
        footL += idleK * (limp < 0f ? 0.8f : -0.4f);
        footR += idleK * (limp < 0f ? -0.4f : 0.8f);
        set(o, J_FOOT_L, footL, -footSide, FLOOR_Z * 0.5f + liftL);
        set(o, J_FOOT_R, footR, footSide, FLOOR_Z * 0.5f + liftR);

        // arms
        armsLocomotion(o, shX, shW, shZ, sn, cs, g, run, brute);

        if (overlays) {
            if (anim == A_ATTACK) attackOverlay(o, shW);
            if (anim == A_STUMBLE) stumbleOverlay(o);
            if (hitT < 0.4f && hitK > 0f) flinchOverlay(o);
        }
        solveLimbs(o, shW);
        if (s != 1f) for (int i = 0; i < o.length; i++) o[i] *= s;
    }

    private void armsLocomotion(float[] o, float shX, float shW, float shZ, float sn, float cs, float g, boolean run, boolean brute) {
        float idleK = 1f - Math.min(g, 1f);
        float hx, hz, hy;
        // left and right hand
        for (int side = 0; side < 2; side++) {
            float sg = side == 0 ? -1f : 1f;                 // -1 = left, +1 = right
            float ph = side == 0 ? sn : -sn;
            if (build == B_SOLDIER) {
                hx = shX + 4.8f + ph * 2.2f * Math.min(g, 1f);
                hy = sg * (shW + 0.4f);
                hz = shZ - 6.8f;
            } else if (run) {
                // arms pump back and forth with bent elbows
                hx = shX + 4.2f + (side == 0 ? -sn : sn) * 5.8f;
                hy = sg * (shW * 0.78f);
                hz = shZ - 4.4f + (side == 0 ? cs : -cs) * 1.6f;
            } else if (brute) {
                // long arms hang low and swing heavily, with the hands held out a little
                hx = shX + 4.4f * (0.4f + 0.6f * reach) + ph * 3.4f * Math.min(g, 1f);
                hy = sg * (shW + 2.6f);
                hz = shZ - 8.4f + 0.8f * reach;
            } else {
                // the classic reach: both arms out in front, bobbing against each other
                float r = 0.35f + 0.65f * reach;
                hx = shX + 9.2f * r + (side == 0 ? 0.8f : 0f) * idleK + (ph * 1.0f) * Math.min(g, 1f);
                hy = sg * (shW * 0.62f);
                hz = shZ - 3.0f - (1f - r) * 6.2f + ph * 1.3f * Math.min(g, 1f) + (float) Math.sin(clock * 1.3f + side * 2f + seed * 7f) * 0.55f * idleK;
            }
            set(o, side == 0 ? J_HAND_L : J_HAND_R, hx, hy, hz);
        }
    }

    private void attackOverlay(float[] o, float shW) {
        float p = attackP;
        boolean swipe = build == B_RUNNER;
        float wind = smooth(p / 0.42f) * (1f - smooth((p - 0.42f) / 0.10f));
        float strike = smooth((p - 0.40f) / 0.20f) * (1f - smooth((p - 0.74f) / 0.26f));
        float lunge = strike;
        // torso rocks back during the wind-up and lunges forward on the strike
        float lean = -2.2f * wind + 5.4f * lunge;
        for (int jn : new int[] {J_SH_L, J_SH_R}) o[jn * 3] += lean;
        o[J_HEAD * 3] += lean * 1.35f + 1.2f * lunge;
        o[J_HEAD * 3 + 2] -= 1.6f * lunge - 0.6f * wind;
        o[J_SH_L * 3 + 2] -= 1.6f * lunge;
        o[J_SH_R * 3 + 2] -= 1.6f * lunge;
        o[J_HIP_L * 3] += lunge * 1.6f;
        o[J_HIP_R * 3] += lunge * 1.6f;
        o[J_FOOT_L * 3] += lunge * 2.8f;     // a step into the blow
        o[J_FOOT_R * 3] -= lunge * 1.2f;
        for (int side = 0; side < 2; side++) {
            float sg = side == 0 ? -1f : 1f;
            int hj = side == 0 ? J_HAND_L : J_HAND_R;
            float hx0 = o[hj * 3], hy0 = o[hj * 3 + 1], hz0 = o[hj * 3 + 2];
            float hx, hy, hz;
            if (swipe) {
                // a claw swipe across the body, alternating hands
                float dir = side == 0 ? 1f : -1f;
                hx = hx0 + 2.5f + 4.0f * lunge;
                hy = sg * 3.0f + dir * (-6.5f * wind + 9.0f * lunge) * (side == 0 ? 1f : 1f);
                hz = hz0 + 2.0f * wind - 1.5f * lunge;
            } else {
                hx = lerp(hx0, 3.6f + lean * 0.5f, wind) + 10.5f * lunge;
                hy = lerp(hy0, sg * (shW * 0.8f), wind);
                hz = lerp(hz0, 25.8f, wind) - 15.0f * lunge;
            }
            o[hj * 3] = hx;
            o[hj * 3 + 1] = hy;
            o[hj * 3 + 2] = hz;
        }
    }

    private void stumbleOverlay(float[] o) {
        float k = (float) Math.sin(Math.PI * MathUtil.clamp(t / 0.6f, 0f, 1f));
        float hx = -hitX, hy = -hitY;       // a stumble goes the way the blow pushed: lean along (hitX, hitY)
        hx = hitX;
        hy = hitY;
        for (int jn : new int[] {J_SH_L, J_SH_R}) { o[jn * 3] += hx * 4.6f * k; o[jn * 3 + 1] += hy * 4.6f * k; o[jn * 3 + 2] -= 2.2f * k; }
        o[J_HEAD * 3] += hx * 7.0f * k;
        o[J_HEAD * 3 + 1] += hy * 7.0f * k;
        o[J_HEAD * 3 + 2] -= 2.4f * k;
        for (int jn : new int[] {J_HIP_L, J_HIP_R}) { o[jn * 3] += hx * 1.6f * k; o[jn * 3 + 1] += hy * 1.6f * k; o[jn * 3 + 2] -= 1.0f * k; }
        // the trailing foot is dragged, the leading one reaches out
        o[J_FOOT_L * 3] += hx * 5.0f * k; o[J_FOOT_L * 3 + 1] += hy * 5.0f * k - 1.2f * k;
        o[J_FOOT_R * 3] -= hx * 2.2f * k; o[J_FOOT_R * 3 + 1] -= hy * 2.2f * k;
        // arms flail out and up
        float fl = (float) Math.sin(t * 16f);
        o[J_HAND_L * 3] = o[J_SH_L * 3] - hx * 3.5f * k + 1.5f * fl;
        o[J_HAND_L * 3 + 1] = o[J_SH_L * 3 + 1] - 7.5f * k - hy * 3.0f * k;
        o[J_HAND_L * 3 + 2] = SHOULDER_Z + 4.2f * k + fl * 1.5f;
        o[J_HAND_R * 3] = o[J_SH_R * 3] - hx * 3.5f * k - 1.5f * fl;
        o[J_HAND_R * 3 + 1] = o[J_SH_R * 3 + 1] + 7.5f * k - hy * 3.0f * k;
        o[J_HAND_R * 3 + 2] = SHOULDER_Z + 4.2f * k - fl * 1.5f;
    }

    /** A blow shoves the upper body the way it went and the arms fly the other way; the effect dies away quickly. */
    private void flinchOverlay(float[] o) {
        float e = 1f - hitT / 0.4f;
        e = e * e * MathUtil.clamp(hitK, 0f, 1.25f);
        float hx = hitX, hy = hitY;
        for (int jn : new int[] {J_SH_L, J_SH_R}) {
            o[jn * 3] += hx * 3.2f * e;
            o[jn * 3 + 1] += hy * 3.2f * e;
            o[jn * 3 + 2] -= 1.1f * e;
        }
        // the head lags behind and snaps
        float lag = Math.min(1f, hitT / 0.12f);
        float snap = e * (1.25f - 0.35f * lag);
        o[J_HEAD * 3] += hx * 5.2f * snap;
        o[J_HEAD * 3 + 1] += hy * 5.2f * snap;
        o[J_HEAD * 3 + 2] += 0.5f * e;
        for (int jn : new int[] {J_HIP_L, J_HIP_R}) {
            o[jn * 3] += hx * 1.1f * e;
            o[jn * 3 + 1] += hy * 1.1f * e;
            o[jn * 3 + 2] -= 1.3f * e;                    // the knees buckle
        }
        for (int jn : new int[] {J_HAND_L, J_HAND_R}) {
            o[jn * 3] -= hx * 3.4f * e;
            o[jn * 3 + 1] -= hy * 3.4f * e + (jn == J_HAND_L ? -1f : 1f) * 1.5f * e;
            o[jn * 3 + 2] += 2.4f * e;
        }
    }

    /** Keeps the limbs a believable length: the elbows and knees come from two-bone IK and the torso stays in one piece. */
    private void solveLimbs(float[] o, float shW) {
        // knees bend forward
        for (int side = 0; side < 2; side++) {
            int hip = side == 0 ? J_HIP_L : J_HIP_R, knee = side == 0 ? J_KNEE_L : J_KNEE_R, foot = side == 0 ? J_FOOT_L : J_FOOT_R;
            twoBone(o, hip, foot, knee, THIGH, SHIN, 1f, 0f, 0.05f);
        }
        // elbows bend down and slightly outwards
        for (int side = 0; side < 2; side++) {
            int sh = side == 0 ? J_SH_L : J_SH_R, el = side == 0 ? J_ELB_L : J_ELB_R, hand = side == 0 ? J_HAND_L : J_HAND_R;
            float out = side == 0 ? -0.45f : 0.45f;
            twoBone(o, sh, hand, el, UPPER_ARM, FOREARM, 0f, out, -1f);
        }
    }

    /**
     * Two-bone IK: puts the middle joint so the chain root -> end has bones of length l1 and l2, bending towards the
     * direction (bx, by, bz). If the end is out of reach it is pulled in to the longest stretch.
     */
    private void twoBone(float[] o, int root, int end, int mid, float l1, float l2, float bx, float by, float bz) {
        float rx = o[root * 3], ry = o[root * 3 + 1], rz = o[root * 3 + 2];
        float ex = o[end * 3] - rx, ey = o[end * 3 + 1] - ry, ez = o[end * 3 + 2] - rz;
        float d = (float) Math.sqrt(ex * ex + ey * ey + ez * ez);
        float maxD = (l1 + l2) * scaleInv() * 0.995f;
        if (d > maxD) {
            float k = maxD / d;
            ex *= k; ey *= k; ez *= k; d = maxD;
            o[end * 3] = rx + ex; o[end * 3 + 1] = ry + ey; o[end * 3 + 2] = rz + ez;
        }
        if (d < 1e-3f) { o[mid * 3] = rx; o[mid * 3 + 1] = ry; o[mid * 3 + 2] = rz - l1; return; }
        float ux = ex / d, uy = ey / d, uz = ez / d;
        float aLen = (l1 * l1 - l2 * l2 + d * d) / (2f * d);
        float h2 = l1 * l1 - aLen * aLen;
        float h = h2 > 0f ? (float) Math.sqrt(h2) : 0f;
        // bend direction made perpendicular to the chain
        float dot = bx * ux + by * uy + bz * uz;
        float px = bx - ux * dot, py = by - uy * dot, pz = bz - uz * dot;
        float pl = (float) Math.sqrt(px * px + py * py + pz * pz);
        if (pl < 1e-3f) { px = 0f; py = 1f; pz = 0f; pl = 1f; }
        px /= pl; py /= pl; pz /= pl;
        o[mid * 3] = rx + ux * aLen + px * h;
        o[mid * 3 + 1] = ry + uy * aLen + py * h;
        o[mid * 3 + 2] = rz + uz * aLen + pz * h;
    }

    private float scaleInv() {
        return 1f;
    }

    // ------------------------------------------------------------------ on the ground

    /** The body lying on its back: head towards (fallX, fallY), arms spread, legs a little apart. {@code clk} adds a faint breathing and twitching. */
    private void lying(float[] o, float clk) {
        float hx = fallX, hy = fallY;
        float px = -hy, py = hx;            // sideways (perpendicular, to the body's right of the fall direction)
        float zf = FLOOR_Z;
        float br = (float) Math.sin(clk * 2.4f + seed * 6f) * 0.28f;
        float tw = (float) Math.sin(clk * 17f + seed * 30f) * Math.max(0f, (float) Math.sin(clk * 0.9f + seed * 13f) - 0.8f) * 5f;
        float shW = 5.0f * width, hpW = 3.0f * width;
        if (build == B_SOLDIER) { shW = 6.6f * width; hpW = 3.7f * width; }
        float bodyLen = build == B_BRUTE ? 1.12f : 1f;
        // pelvis at the origin
        place(o, J_HIP_L, hx * -0.4f - px * hpW, hy * -0.4f - py * hpW, zf + 0.2f);
        place(o, J_HIP_R, hx * -0.4f + px * hpW, hy * -0.4f + py * hpW, zf + 0.2f);
        place(o, J_SH_L, hx * 9.6f * bodyLen - px * shW, hy * 9.6f * bodyLen - py * shW, zf + 0.5f + br);
        place(o, J_SH_R, hx * 9.6f * bodyLen + px * shW, hy * 9.6f * bodyLen + py * shW, zf + 0.5f + br);
        place(o, J_HEAD, hx * 16.8f * bodyLen + px * 0.9f, hy * 16.8f * bodyLen + py * 0.9f, zf + 1.4f + br * 0.5f);
        place(o, J_ELB_L, hx * 8.2f - px * (shW + 3.8f), hy * 8.2f - py * (shW + 3.8f), zf);
        place(o, J_HAND_L, hx * 11.6f - px * (shW + 6.4f), hy * 11.6f - py * (shW + 6.4f), zf - 0.1f);
        place(o, J_ELB_R, hx * 7.2f + px * (shW + 3.4f), hy * 7.2f + py * (shW + 3.4f), zf);
        place(o, J_HAND_R, hx * 4.5f + px * (shW + 6.8f), hy * 4.5f + py * (shW + 6.8f), zf - 0.1f);
        place(o, J_KNEE_L, hx * -6.2f - px * (hpW + 1.2f), hy * -6.2f - py * (hpW + 1.2f), zf);
        place(o, J_FOOT_L, hx * -12.0f - px * (hpW + 2.6f) + hx * tw * 0.2f, hy * -12.0f - py * (hpW + 2.6f) + hy * tw * 0.2f, zf - 0.2f);
        place(o, J_KNEE_R, hx * -5.8f + px * (hpW + 2.2f), hy * -5.8f + py * (hpW + 2.2f), zf);
        place(o, J_FOOT_R, hx * -11.0f + px * (hpW + 5.0f) + px * tw * 0.3f, hy * -11.0f + py * (hpW + 5.0f) + py * tw * 0.3f, zf - 0.2f);
        if (scale != 1f) for (int i = 0; i < o.length; i++) o[i] *= scale;
    }

    private static void place(float[] o, int joint, float x, float y, float z) {
        o[joint * 3] = x;
        o[joint * 3 + 1] = y;
        o[joint * 3 + 2] = z;
    }

    /** A body-shaped crouch used half-way up from the ground. */
    private void crouch(float[] o) {
        float hpW = 3.0f * width, shW = 5.0f * width;
        if (build == B_SOLDIER) { hpW = 3.7f * width; shW = 6.6f * width; }
        place(o, J_HIP_L, -1.2f, -hpW, 6.2f);
        place(o, J_HIP_R, -1.2f, hpW, 6.2f);
        place(o, J_SH_L, 3.6f, -shW, 14.0f);
        place(o, J_SH_R, 3.6f, shW, 14.0f);
        place(o, J_HEAD, 6.8f, 0.4f, 19.0f);
        place(o, J_HAND_L, 8.4f, -shW - 1.0f, 3.0f);
        place(o, J_HAND_R, 8.4f, shW + 1.0f, 3.0f);
        place(o, J_FOOT_L, 1.4f, -hpW - 0.4f, 0.9f);
        place(o, J_FOOT_R, -0.4f, hpW + 0.4f, 0.9f);
        solveLimbs(o, shW);
        if (scale != 1f) for (int i = 0; i < o.length; i++) o[i] *= scale;
    }

    private void fall() {
        // 0..1 over the fall
        float f = MathUtil.clamp(t / FALL_TIME, 0f, 1f);
        float theta = f * f * 1.5708f;                      // gravity: slow to start, quick to finish
        // start from a standing pose and tip it over the feet towards the fall direction
        int savedAnim = anim;
        float savedT = t;
        anim = A_IDLE;
        float savedGait = gait;
        gait = 0f;
        float sHit = hitT;
        upright(a, false);
        anim = savedAnim;
        gait = savedGait;
        t = savedT;
        hitT = sHit;
        lying(b, clock);
        float c = (float) Math.cos(theta), sn = (float) Math.sin(theta);
        float hx = fallX, hy = fallY;
        float px = -hy, py = hx;
        float settle = smooth((f - 0.62f) / 0.38f);
        float slide = smooth(f) * HIP_Z * scale;          // the feet slide back as the body goes over them
        for (int i = 0; i < JOINTS; i++) {
            float x = a[i * 3], y = a[i * 3 + 1], z = a[i * 3 + 2];
            float ah = x * hx + y * hy;                       // along the fall direction
            float ap = x * px + y * py;                       // sideways
            // arms fling out sideways while falling
            if (i == J_HAND_L || i == J_HAND_R || i == J_ELB_L || i == J_ELB_R) ap += (i == J_HAND_L || i == J_ELB_L ? -1f : 1f) * 6.5f * smooth(f * 1.4f) * scale;
            float nh = ah * c + z * sn - slide;
            float nz = -ah * sn + z * c;
            if (nz < FLOOR_Z * 0.5f) nz = FLOOR_Z * 0.5f;
            float nx = hx * nh + px * ap;
            float ny = hy * nh + py * ap;
            // blend towards the settled lying pose at the end
            j[i * 3] = lerp(nx, b[i * 3], settle);
            j[i * 3 + 1] = lerp(ny, b[i * 3 + 1], settle);
            j[i * 3 + 2] = lerp(nz, b[i * 3 + 2], settle);
        }
        // the body bounces a little as it lands
        float land = f > 0.85f ? (float) Math.sin((f - 0.85f) / 0.15f * Math.PI) * 0.7f : 0f;
        for (int i = 0; i < JOINTS; i++) if (j[i * 3 + 2] > FLOOR_Z + 0.5f) j[i * 3 + 2] += land;
    }

    private void getUp() {
        float u = MathUtil.clamp(t / GETUP_TIME, 0f, 1f);
        float savedGait = gait;
        int savedAnim = anim;
        float sHit = hitT;
        lying(a, 0f);
        crouch(b);
        anim = A_IDLE;
        gait = 0f;
        upright(this.c3, false);
        anim = savedAnim;
        gait = savedGait;
        hitT = sHit;
        if (u < 0.55f) {
            float k = smooth(u / 0.55f);
            for (int i = 0; i < j.length; i++) j[i] = lerp(a[i], b[i], k);
        } else {
            float k = smooth((u - 0.55f) / 0.45f);
            for (int i = 0; i < j.length; i++) j[i] = lerp(b[i], c3[i], k);
        }
    }

    private final float[] c3 = new float[JOINTS * 3];

    public static final float FALL_TIME = 0.46f;
    public static final float GETUP_TIME = 0.85f;

    // ------------------------------------------------------------------ to the world

    /**
     * Writes the current pose into world coordinates: the body stands at (x, y) facing {@code aim}. Heights stay as they are.
     */
    public void toWorld(float x, float y, float aim, float[] wx, float[] wy, float[] wz) {
        float c = (float) Math.cos(aim), s = (float) Math.sin(aim);
        for (int i = 0; i < JOINTS; i++) {
            float lx = j[i * 3], ly = j[i * 3 + 1];
            wx[i] = x + lx * c - ly * s;
            wy[i] = y + lx * s + ly * c;
            wz[i] = j[i * 3 + 2];
        }
    }

    /** Converts a world direction into the body frame of something facing {@code aim}. */
    public static float localX(float dx, float dy, float aim) {
        return dx * (float) Math.cos(aim) + dy * (float) Math.sin(aim);
    }

    public static float localY(float dx, float dy, float aim) {
        return -dx * (float) Math.sin(aim) + dy * (float) Math.cos(aim);
    }

    private static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }
}
