package com.hazardyard.game.render;

import android.graphics.Canvas;
import android.graphics.Paint;

import com.hazardyard.game.core.Effects;
import com.hazardyard.game.core.Puppet;
import com.hazardyard.game.core.PuppetStyle;
import com.hazardyard.game.core.Ragdolls;
import com.hazardyard.game.survival.Zombie;
import com.hazardyard.game.survival.ZombieAnim;
import com.hazardyard.game.survival.ZombieLook;

/**
 * Draws the things that are bodies rather than soldiers: living zombies (posed from their state every frame), ragdolls
 * of the fallen (zombies and soldiers) with the blood pool under them, and the stains of blood left on the ground.
 * One instance per renderer; it owns the scratch data so nothing is allocated while drawing.
 */
final class BodyDrawer {
    private final PolyDrawer poly = new PolyDrawer();
    private final PuppetRenderer puppets = new PuppetRenderer(poly);
    private final Puppet pu = new Puppet();
    private final PuppetStyle style = new PuppetStyle();
    private final float[] jx = new float[Puppet.JOINTS];
    private final float[] jy = new float[Puppet.JOINTS];
    private final float[] jz = new float[Puppet.JOINTS];
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float lastTime = -1f;
    private float dt;

    BodyDrawer() {
        fill.setStyle(Paint.Style.FILL);
    }

    /** Call once per frame before drawing: it measures the time since the last frame for the zombies' walk blending. */
    void beginFrame(float time) {
        dt = lastTime < 0f ? 0f : Math.max(0f, Math.min(0.1f, time - lastTime));
        lastTime = time;
    }

    /** How much detail to draw for a crowd of {@code visible} bodies: the fewer, the more. */
    static int detailFor(int visible, boolean lite) {
        // about 18 polygons per body at level 0, 53 at level 1 and 79 at level 2: the whole crowd stays near 570 at most
        if (lite) return visible <= 4 ? 1 : 0;
        if (visible <= 5) return 2;
        if (visible <= 10) return 1;
        return 0;
    }

    void drawZombie(Canvas c, Zombie z, float time, int detail) {
        if (z.dying) return;
        ZombieLook.fill(z.type, ZombieLook.lookOf(z.id), style);
        float target = ZombieAnim.gaitFor(z);
        z.gait += (target - z.gait) * Math.min(1f, dt * 9f);
        ZombieAnim.pose(z, style, pu, time);
        pu.toWorld(z.rx, z.ry, z.rAim, jx, jy, jz);
        float flash = z.hurt > 0f ? Math.min(1f, z.hurt / 0.18f) : 0f;
        puppets.draw(c, jx, jy, jz, style, flash, 1f, detail);
    }

    void drawRagdoll(Canvas c, Ragdolls r, int i, int detail) {
        float fade = r.fade[i];
        // the blood pool spreads from under the body
        float px = (r.x[i][Puppet.J_HIP_L] + r.x[i][Puppet.J_HIP_R]) * 0.5f, py = (r.y[i][Puppet.J_HIP_L] + r.y[i][Puppet.J_HIP_R]) * 0.5f;
        float pool = r.pool[i];
        if (pool > 0.02f && r.style[i].build != Puppet.B_SOLDIER) {
            float rad = (6f + 8f * pool) * r.style[i].scale;
            int a = (int) (0x70 * Math.min(1f, pool * 1.5f) * fade);
            fill.setColor((a << 24) | 0x701212);
            c.drawOval(px - rad, py - rad * 0.62f + 1f, px + rad, py + rad * 0.62f + 1f, fill);
        } else if (pool > 0.02f) {
            float rad = 5f + 6f * pool;
            int a = (int) (0x50 * Math.min(1f, pool * 1.5f) * fade);
            fill.setColor((a << 24) | 0x701212);
            c.drawOval(px - rad, py - rad * 0.62f + 1f, px + rad, py + rad * 0.62f + 1f, fill);
        }
        float flash = r.flash[i] > 0f ? Math.min(1f, r.flash[i] / 0.25f) : 0f;
        puppets.draw(c, r.x[i], r.y[i], r.z[i], r.style[i], flash, fade, detail);
    }

    /** Blood stains on the ground: flattened blobs that fade over the last part of their life. */
    void drawDecals(Canvas c, Effects fx, float vx0, float vx1, float vy0, float vy1) {
        for (int i = 0; i < Effects.DECAL_MAX; i++) {
            if (!fx.decalActive[i]) continue;
            float x = fx.decalX[i], y = fx.decalY[i], r = fx.decalR[i];
            if (x < vx0 - r || x > vx1 + r || y < vy0 - r || y > vy1 + r) continue;
            float left = fx.decalLife[i] - fx.decalAge[i];
            float k = Math.min(1f, left / (fx.decalLife[i] * 0.3f));
            float grow = Math.min(1f, fx.decalAge[i] / 0.25f);
            int base = fx.decalColor[i];
            int a = (int) (((base >>> 24) & 0xFF) * k);
            fill.setColor((a << 24) | (base & 0x00FFFFFF));
            c.save();
            c.translate(x, y);
            c.rotate((float) Math.toDegrees(fx.decalAngle[i]));
            float rr = r * (0.35f + 0.65f * grow);
            c.drawOval(-rr, -rr * 0.55f, rr * 1.15f, rr * 0.55f, fill);
            c.drawCircle(rr * 0.9f, rr * 0.25f, rr * 0.28f, fill);
            c.restore();
        }
    }
}
