package com.hazardyard.game.render;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;

import com.hazardyard.game.core.Camera;
import com.hazardyard.game.core.Effects;
import com.hazardyard.game.core.GameConfig;
import com.hazardyard.game.core.GameState;
import com.hazardyard.game.core.Items;
import com.hazardyard.game.core.Pickup;
import com.hazardyard.game.core.Player;
import com.hazardyard.game.core.PlayerColors;
import com.hazardyard.game.core.TileMap;
import com.hazardyard.game.core.Weapon;
import com.hazardyard.game.core.WeaponDef;
import com.hazardyard.game.input.ControlGeometry;
import com.hazardyard.game.input.DropUi;
import com.hazardyard.game.input.InputController;
import com.hazardyard.game.settings.ControlSettings;

/**
 * Screen-space interface drawn over the world: match timer and scores, minimap, the on-screen
 * controls, the ammo readout, a slim health strip, the kill feed, edge arrows towards shots that were
 * heard, and the countdown / respawn / results overlays. The centre of the screen stays free for the
 * action.
 *
 * <p>The five information widgets (minimap, timer and scores, ammo, health, kill feed) sit where the
 * player's HUD layout puts them and are drawn at the size the player chose: each one is drawn in its own
 * little coordinate system centred on its position, which is scaled as a whole. The same code draws them
 * live in a match and, with sample data, in the HUD editor. Sizes are in dp (density scaled) and text is
 * fitted to its box, so the layout holds on any resolution, aspect ratio or system font. Allocation-free
 * per frame.
 */
public final class HudRenderer {
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final Path path = new Path();
    private final Typeface bold = Typeface.create("sans-serif-condensed", Typeface.BOLD);
    private final Typeface medium = Typeface.create("sans-serif-medium", Typeface.NORMAL);
    private final int[] order = new int[GameConfig.MAX_PLAYERS];
    private final ControlsRenderer controls = new ControlsRenderer();
    /** The walls of the minimap never change during a match, so they are drawn once into this bitmap. */
    private final Paint miniPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private Bitmap miniBitmap;
    private int miniKey;
    /** Lighter than {@link Palette#PANEL}: HUD plates should not shout over the game. */
    private static final int PLATE = 0x8A131A22;

    private int lastSeconds = -1;
    private String timerText = "0:00";
    private final SurvivalHud survivalHud = new SurvivalHud();
    private GameState curState;
    private float d = 1f;
    private int w = 1;
    private int h = 1;
    // safe area (display cutout / system bars): the HUD keeps clear of it, the world draws under it
    private float sl, st_, sr, sb;
    /** Horizontal centre of the safe area. */
    private float mid;

    public HudRenderer() {
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
    }

    public void draw(Canvas c, GameState st, Camera cam, InputController in, int pingMs, float density, float time) {
        ControlGeometry geo = in.geometry();
        begin(cam.viewW, cam.viewH, density, geo);
        Player me = st.local();
        curState = st;

        if (st.survival != null) {         // survival: no minimap or score, but the hotbar, hunger, clock and the bag
            drawDamageTint(c, me);
            controls.draw(c, in, st, me, d, time);
            widgetAmmo(c, me, geo);
            widgetHealth(c, me, geo);
            survivalHud.draw(c, st, in.survivalUi, w, h, d, time, sl, st_, sr, sb);
            drawCenterMessage(c, st, me, time);
            return;
        }

        if (st.mode.royale && st.phase == GameState.PHASE_COUNTDOWN && me.connected) {
            drawDropSelect(c, st, in.dropUi, geo, time);       // the choice of where to land comes before everything else
            return;
        }
        drawDamageTint(c, me);
        drawStormWarning(c, st, st.view(), time);
        drawHeardArrows(c, st, cam);
        widgetMinimap(c, st, cam, geo, pingMs);
        widgetScore(c, st, geo);
        widgetKillFeed(c, st, geo);
        boolean spectating = st.mode.royale && st.phase == GameState.PHASE_PLAYING && me.connected && !me.alive;
        if (spectating) {
            drawSpectator(c, st, me, in.spectatorUi, time);
        } else {
            controls.draw(c, in, st, me, d, time);
            widgetAmmo(c, me, geo);
            widgetHealth(c, me, geo);
            drawCenterMessage(c, st, me, time);
        }
        if (st.phase == GameState.PHASE_ENDED) drawResults(c, st, in.spectatorUi);
    }

    /**
     * The HUD editor's picture of the five widgets, drawn from a made-up match so the player sees exactly
     * what each element looks like where it will sit. {@code selected} (or -1) gets a highlight; widgets whose
     * boxes overlap another element are outlined in red.
     */
    public void drawEditorWidgets(Canvas c, GameState sample, ControlGeometry geo, ControlSettings layout, int selected,
                                  float density) {
        begin(geo.width, geo.height, density, geo);
        Player me = sample.local();
        widgetMinimap(c, sample, null, geo, 42);
        widgetScore(c, sample, geo);
        widgetKillFeed(c, sample, geo);
        widgetAmmo(c, me, geo);
        widgetHealth(c, me, geo);
        for (int i = ControlSettings.CONTROL_COUNT; i < ControlSettings.COUNT; i++) {
            if (ControlSettings.isControl(i)) continue;
            outline(c, geo, i, i == selected, clashes(geo, layout, i));
        }
    }

    /** True when element {@code i} overlaps another element that is visible in the current layout. */
    public static boolean clashes(ControlGeometry geo, ControlSettings layout, int i) {
        for (int j = 0; j < ControlSettings.COUNT; j++) {
            if (j == i || (j == ControlSettings.FIRE && !layout.fireButtonEnabled())) continue;
            if (geo.overlaps(i, j)) return true;
        }
        return false;
    }

    /** A rounded outline around an element's box: accent for the selected one, red where it overlaps something. */
    public void outline(Canvas c, ControlGeometry geo, int element, boolean selected, boolean clash) {
        if (!selected && !clash) return;
        float pad = 4f * d;
        rect.set(geo.cx[element] - geo.hw[element] - pad, geo.cy[element] - geo.hh[element] - pad,
                geo.cx[element] + geo.hw[element] + pad, geo.cy[element] + geo.hh[element] + pad);
        stroke.setColor(selected ? Palette.ACCENT : Palette.withAlpha(Palette.BAD, 220));
        stroke.setStrokeWidth((selected ? 2.4f : 1.8f) * d);
        c.drawRoundRect(rect, 10f * d, 10f * d, stroke);
    }

    private void begin(int viewW, int viewH, float density, ControlGeometry geo) {
        d = density;
        w = viewW;
        h = viewH;
        sl = geo.insetL;
        st_ = geo.insetT;
        sr = geo.insetR;
        sb = geo.insetB;
        mid = sl + (w - sl - sr) * 0.5f;
    }

    /** Moves the origin to the centre of a widget and applies the player's size for it: draw in local, dp-based coordinates. */
    private void enter(Canvas c, ControlGeometry geo, int element) {
        c.save();
        c.translate(geo.cx[element], geo.cy[element]);
        c.scale(geo.sc[element], geo.sc[element]);
    }

    // ------------------------------------------------------------------ helpers

    private void label(Canvas c, String s, float x, float y, float sizeDp, int color, Paint.Align align, Typeface tf) {
        text.setTypeface(tf);
        text.setTextSize(sizeDp * d);
        text.setColor(color);
        text.setTextAlign(align);
        c.drawText(s, x, y, text);
    }

    private float measure(String s, float sizeDp, Typeface tf) {
        text.setTypeface(tf);
        text.setTextSize(sizeDp * d);
        return text.measureText(s);
    }

    /** Like {@link #label} but shrinks the text (down to 60%) so it never wider than {@code maxWidthDp}, whatever font the phone uses. */
    private void labelFit(Canvas c, String s, float x, float y, float sizeDp, float maxWidthDp, int color,
                          Paint.Align align, Typeface tf) {
        float wpx = measure(s, sizeDp, tf);
        float maxPx = maxWidthDp * d;
        if (wpx > maxPx && wpx > 0f) sizeDp = Math.max(sizeDp * 0.6f, sizeDp * maxPx / wpx);
        label(c, s, x, y, sizeDp, color, align, tf);
    }

    /** Width of a string once fitted to {@code maxWidthDp}, in pixels. */
    private float measureFit(String s, float sizeDp, float maxWidthDp, Typeface tf) {
        float wpx = measure(s, sizeDp, tf);
        float maxPx = maxWidthDp * d;
        if (wpx > maxPx && wpx > 0f) {
            sizeDp = Math.max(sizeDp * 0.6f, sizeDp * maxPx / wpx);
            return measure(s, sizeDp, tf);
        }
        return wpx;
    }

    private void panel(Canvas c, float l, float t, float r, float b, float radiusDp) {
        rect.set(l, t, r, b);
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(PLATE);
        c.drawRoundRect(rect, radiusDp * d, radiusDp * d, fill);
    }

    // ------------------------------------------------------------------ overlays on the whole screen

    private void drawDamageTint(Canvas c, Player me) {
        if (me.hitFlash <= 0f) return;
        int a = (int) (80f * Math.min(1f, me.hitFlash / 0.15f));
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(Palette.withAlpha(Palette.BAD, a));
        c.drawRect(0f, 0f, w, h, fill);
    }

    /** In the storm: a pulsing red edge, a warning, and an arrow towards the safe zone. */
    private void drawStormWarning(Canvas c, GameState st, Player v, float time) {
        com.hazardyard.game.core.Zone z = st.zone;
        if (!z.enabled || !v.connected || !v.alive || z.inside(v.rx, v.ry)) return;
        float pulse = 0.5f + 0.5f * (float) Math.sin(time * 5f);
        int a = 40 + (int) (50f * pulse);
        fill.setStyle(Paint.Style.FILL);
        float edge = Math.min(w, h) * 0.18f;
        fill.setColor(Palette.withAlpha(0xFFE0301F, a));
        c.drawRect(0f, 0f, w, edge * 0.35f, fill);
        c.drawRect(0f, h - edge * 0.35f, w, h, fill);
        c.drawRect(0f, 0f, edge * 0.35f, h, fill);
        c.drawRect(w - edge * 0.35f, 0f, w, h, fill);
        label(c, "You are in the storm", mid, h * 0.22f, 16f, Palette.BAD, Paint.Align.CENTER, bold);
        label(c, "Get inside the zone", mid, h * 0.22f + 20f * d, 12f, Palette.TEXT, Paint.Align.CENTER, medium);
        // arrow towards the centre of the safe zone, circling the player
        float dx = z.cx - v.rx;
        float dy = z.cy - v.ry;
        float len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len < 1f) return;
        dx /= len;
        dy /= len;
        float cx = mid;
        float cy = st_ + (h - st_ - sb) * 0.5f;
        float r = Math.min(w, h) * 0.30f;
        float ax = cx + dx * r;
        float ay = cy + dy * r;
        float sz = 14f * d;
        path.reset();
        path.moveTo(ax + dx * sz, ay + dy * sz);
        path.lineTo(ax - dx * sz * 0.5f - dy * sz * 0.8f, ay - dy * sz * 0.5f + dx * sz * 0.8f);
        path.lineTo(ax - dx * sz * 0.5f + dy * sz * 0.8f, ay - dy * sz * 0.5f - dx * sz * 0.8f);
        path.close();
        fill.setColor(Palette.withAlpha(0xFF58A6FF, 230));
        c.drawPath(path, fill);
    }

    /**
     * Edge arrows towards shots the player has just heard from off-screen. Enemies are not tracked:
     * an arrow only exists for a moment after somebody fires and points at where the shot came from.
     */
    private void drawHeardArrows(Canvas c, GameState st, Camera cam) {
        Effects fx = st.effects;
        float margin = 30f * d;
        for (int i = 0; i < st.players.length; i++) {
            Player p = st.players[i];
            if (i == st.localId || !p.connected || !p.alive) continue;
            float strength = fx.noiseStrength(i);
            if (strength <= 0f) continue;
            float sx = cam.screenX(fx.noiseX[i]);
            float sy = cam.screenY(fx.noiseY[i]);
            if (sx >= 0f && sx <= w && sy >= 0f && sy <= h) continue;
            float cx = mid;
            float cy = st_ + (h - st_ - sb) * 0.5f;
            float dx = sx - cx;
            float dy = sy - cy;
            float halfW = (w - sl - sr) * 0.5f - margin;
            float halfH = (h - st_ - sb) * 0.5f - margin;
            float kx = Math.abs(dx) > 1e-3f ? halfW / Math.abs(dx) : Float.MAX_VALUE;
            float ky = Math.abs(dy) > 1e-3f ? halfH / Math.abs(dy) : Float.MAX_VALUE;
            float k = Math.min(kx, ky);
            float ax = cx + dx * k;
            float ay = cy + dy * k;
            float ang = (float) Math.atan2(dy, dx);
            float ca = (float) Math.cos(ang);
            float sa = (float) Math.sin(ang);
            float s = 11f * d;
            int color = PlayerColors.of(i);
            int alpha = 70 + (int) (170f * strength);
            path.reset();
            path.moveTo(ax + ca * s, ay + sa * s);
            path.lineTo(ax - ca * s * 0.6f - sa * s * 0.85f, ay - sa * s * 0.6f + ca * s * 0.85f);
            path.lineTo(ax - ca * s * 0.6f + sa * s * 0.85f, ay - sa * s * 0.6f - ca * s * 0.85f);
            path.close();
            fill.setStyle(Paint.Style.FILL);
            fill.setColor(Palette.withAlpha(color, alpha));
            c.drawPath(path, fill);
            stroke.setColor(Palette.withAlpha(0xFF0B0F14, alpha * 200 / 255));
            stroke.setStrokeWidth(1.5f * d);
            c.drawPath(path, stroke);
            // a ring that grows while the sound is fresh: "something just fired over there"
            float grow = Math.min(1f, fx.noiseAge[i] / 0.5f);
            stroke.setColor(Palette.withAlpha(color, (int) (alpha * (1f - grow) * 0.7f)));
            stroke.setStrokeWidth(1.6f * d);
            c.drawCircle(ax - ca * s * 0.2f, ay - sa * s * 0.2f, (s * 0.9f) + grow * 12f * d, stroke);
        }
    }


    // ------------------------------------------------------------------ Battleground: where to land

    private Bitmap dropBitmap;
    private int dropKey;

    /**
     * The drop-in screen: the island on a big map, the first safe circle on it, the place the player chose marked with a
     * parachute, the seconds left, and the Drop button. What is drawn here is what {@link DropUi} lets the player touch.
     */
    private void drawDropSelect(Canvas c, GameState st, DropUi ui, ControlGeometry geo, float time) {
        TileMap map = st.map;
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(0xF4080D13);
        c.drawRect(0f, 0f, w, h, fill);
        float mx = ui.mapX, my = ui.mapY, mw = ui.mapW, mh = ui.mapH;
        if (mw < 8f || mh < 8f) return;

        // the island
        rect.set(mx - 4f * d, my - 4f * d, mx + mw + 4f * d, my + mh + 4f * d);
        fill.setColor(0xFF22303D);
        c.drawRoundRect(rect, 8f * d, 8f * d, fill);
        int bw = Math.max(2, (int) mw), bh = Math.max(2, (int) mh);
        int key = (map.id * 7919 + bw) * 7919 + bh;
        if (dropBitmap == null || dropKey != key) {
            if (dropBitmap != null) dropBitmap.recycle();
            dropBitmap = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888);
            dropKey = key;
            MiniTerrain.paint(dropBitmap, map);
        }
        rect.set(mx, my, mx + mw, my + mh);
        c.drawBitmap(dropBitmap, null, rect, miniPaint);

        // the safe circles: the one the zone is closing to (white) and the playing area (blue)
        com.hazardyard.game.core.Zone z = st.zone;
        float sx = mw / map.worldW, sy = mh / map.worldH;
        c.save();
        c.clipRect(mx, my, mx + mw, my + mh);
        stroke.setStyle(Paint.Style.STROKE);
        if (z.enabled) {
            if (z.toRadius > 0.5f) {
                stroke.setColor(0xFFFFFFFF);
                stroke.setStrokeWidth(2f * d);
                c.drawCircle(mx + z.toCx * sx, my + z.toCy * sy, z.toRadius * sx, stroke);
            }
            stroke.setColor(0xFF4FA0FF);
            stroke.setStrokeWidth(2f * d);
            c.drawCircle(mx + z.cx * sx, my + z.cy * sy, Math.max(0.5f, z.radius * sx), stroke);
        }
        c.restore();

        // the chosen place
        if (ui.hasChoice) {
            float px = ui.screenX(), py = ui.screenY();
            float pulse = 0.5f + 0.5f * (float) Math.sin(time * 5f);
            stroke.setColor(Palette.withAlpha(0xFFFFFFFF, 220));
            stroke.setStrokeWidth(1.8f * d);
            c.drawCircle(px, py, (8f + 4f * pulse) * d, stroke);
            fill.setColor(Palette.ACCENT);
            c.drawCircle(px, py, 3.6f * d, fill);
            // a small canopy above the mark
            rect.set(px - 9f * d, py - 24f * d, px + 9f * d, py - 4f * d);
            fill.setColor(0xFFF1F1F1);
            c.drawArc(rect, 180f, 180f, true, fill);
            fill.setColor(Palette.ACCENT);
            c.drawArc(rect, 180f, 60f, true, fill);
            c.drawArc(rect, 300f, 60f, true, fill);
            stroke.setColor(0xFF101820);
            stroke.setStrokeWidth(1f * d);
            c.drawArc(rect, 180f, 180f, false, stroke);
            c.drawLine(px - 9f * d, py - 14f * d, px, py - 4f * d, stroke);
            c.drawLine(px + 9f * d, py - 14f * d, px, py - 4f * d, stroke);
        } else {
            label(c, "Tap the island to choose where you land", mx + mw * 0.5f, my + mh - 10f * d, 12f, 0xFFFFFFFF,
                    Paint.Align.CENTER, medium);
        }

        // title and the clock
        label(c, "CHOOSE YOUR DROP", mid, st_ + 28f * d, 21f, Palette.TEXT, Paint.Align.CENTER, bold);
        int n = Math.max(1, (int) Math.ceil(st.countdown));
        float lx = Math.max(sl + 70f * d, mx * 0.5f);
        label(c, Txt.of(n), lx + 2f * d, h * 0.5f + 2f * d, 72f, 0x66000000, Paint.Align.CENTER, bold);
        label(c, Txt.of(n), lx, h * 0.5f, 72f, Palette.ACCENT, Paint.Align.CENTER, bold);
        label(c, "seconds to drop", lx, h * 0.5f + 24f * d, 12f, Palette.TEXT_DIM, Paint.Align.CENTER, medium);
        float tx = lx - Math.min(78f * d, mx * 0.45f);
        label(c, "White circle: where the", tx, h * 0.5f + 60f * d, 11f, Palette.TEXT_DIM, Paint.Align.LEFT, medium);
        label(c, "first safe zone will be.", tx, h * 0.5f + 74f * d, 11f, Palette.TEXT_DIM, Paint.Align.LEFT, medium);
        label(c, "Steer with the left stick", tx, h * 0.5f + 94f * d, 11f, Palette.TEXT_DIM, Paint.Align.LEFT, medium);
        label(c, "while you fall.", tx, h * 0.5f + 108f * d, 11f, Palette.TEXT_DIM, Paint.Align.LEFT, medium);

        // the button
        rect.set(ui.btnX, ui.btnY, ui.btnX + ui.btnW, ui.btnY + ui.btnH);
        fill.setColor(ui.confirmed ? 0xFF3A4654 : Palette.ACCENT);
        c.drawRoundRect(rect, 10f * d, 10f * d, fill);
        String caption = ui.confirmed ? "READY" : (ui.hasChoice ? "DROP HERE" : "RANDOM DROP");
        label(c, caption, ui.btnX + ui.btnW * 0.5f, ui.btnY + ui.btnH * 0.5f + 6f * d, 17f,
                ui.confirmed ? Palette.TEXT_DIM : 0xFF10161D, Paint.Align.CENTER, bold);
        if (ui.confirmed) {
            label(c, "Waiting for the others", ui.btnX + ui.btnW * 0.5f, ui.btnY + ui.btnH + 18f * d, 11f, Palette.TEXT_DIM,
                    Paint.Align.CENTER, medium);
        }
        controls.drawPause(c, geo, 1f, d);
    }

    // ------------------------------------------------------------------ top of the screen

    /** The minimap sits in a fixed 128 x 88 dp panel; the map is fitted into it whatever its shape. */
    private void widgetMinimap(Canvas c, GameState st, Camera cam, ControlGeometry geo, int pingMs) {
        TileMap map = st.map;
        enter(c, geo, ControlSettings.MINIMAP);
        float pw = 128f * d;
        float ph = 88f * d;
        panel(c, -pw * 0.5f, -ph * 0.5f, pw * 0.5f, ph * 0.5f, 8f);
        float s = Math.min(120f * d / map.worldW, 80f * d / map.worldH);
        float mw = map.worldW * s;
        float mh = map.worldH * s;
        float mx = -mw * 0.5f;
        float my = -mh * 0.5f;
        MapTheme th = MapTheme.of(map.id);
        fill.setStyle(Paint.Style.FILL);
        drawMinimapWalls(c, map, th, mx, my, mw, mh, geo.sc[ControlSettings.MINIMAP]);
        if (!st.mode.royale) {          // a battle royale does not show where the loot is
            for (int i = 0; i < st.pickups.length; i++) {
                Pickup pk = st.pickups[i];
                if (!pk.active) continue;
                fill.setColor(Items.color(pk.item));
                c.drawCircle(mx + pk.x * s, my + pk.y * s, (map.worldW > 2400f ? 1.3f : 1.6f) * d, fill);
            }
        }
        if (st.zone.enabled) drawMinimapZone(c, st.zone, mx, my, s, mw, mh);
        if (cam != null) {
            float vx0 = Math.max(0f, cam.x - cam.halfViewWorldW());
            float vy0 = Math.max(0f, cam.y - cam.halfViewWorldH());
            float vx1 = Math.min(map.worldW, cam.x + cam.halfViewWorldW());
            float vy1 = Math.min(map.worldH, cam.y + cam.halfViewWorldH());
            stroke.setColor(Palette.withAlpha(0xFFFFFFFF, 90));
            stroke.setStrokeWidth(1f * d);
            c.drawRect(mx + vx0 * s, my + vy0 * s, mx + vx1 * s, my + vy1 * s, stroke);
        }

        // Other players are NOT tracked: one shows up only where (and while) its gun was just heard.
        Effects fx = st.effects;
        for (int i = 0; i < st.players.length; i++) {
            Player p = st.players[i];
            if (i == st.localId || !p.connected || !p.alive) continue;
            float strength = fx.noiseStrength(i);
            if (strength <= 0f) continue;
            float px = mx + fx.noiseX[i] * s;
            float py = my + fx.noiseY[i] * s;
            int color = PlayerColors.of(i);
            float grow = Math.min(1f, fx.noiseAge[i] / 0.55f);
            stroke.setColor(Palette.withAlpha(color, (int) (210f * strength * (1f - grow * 0.65f))));
            stroke.setStrokeWidth(1.3f * d);
            c.drawCircle(px, py, (3f + 8f * grow) * d, stroke);
            fill.setColor(Palette.withAlpha(color, 90 + (int) (165f * strength)));
            c.drawCircle(px, py, 2.6f * d, fill);
        }
        Player me = st.view();
        if (me.connected && me.alive) {
            float px = mx + me.rx * s;
            float py = my + me.ry * s;
            fill.setColor(PlayerColors.of(st.viewId));
            c.drawCircle(px, py, 3f * d, fill);
            stroke.setColor(0xFFFFFFFF);
            stroke.setStrokeWidth(1.2f * d);
            c.drawCircle(px, py, 5f * d, stroke);
        }
        if (pingMs > 0) {
            float y = ph * 0.5f + 14f * d;
            float x = -pw * 0.5f + 4f * d;
            label(c, "Ping ", x, y, 11f, Palette.TEXT_DIM, Paint.Align.LEFT, medium);
            x += measure("Ping ", 11f, medium);
            label(c, Txt.of(pingMs), x, y, 11f, pingMs > 120 ? Palette.WARN : Palette.TEXT_DIM, Paint.Align.LEFT, medium);
            x += measure(Txt.of(pingMs), 11f, medium);
            label(c, " ms", x, y, 11f, Palette.TEXT_DIM, Paint.Align.LEFT, medium);
        }
        c.restore();
    }

    /** The safe circle (blue) and the circle it is closing towards (white) on the minimap, clipped to the map. */
    private void drawMinimapZone(Canvas c, com.hazardyard.game.core.Zone z, float mx, float my, float s, float mw, float mh) {
        c.save();
        c.clipRect(mx, my, mx + mw, my + mh);
        if (!z.collapsed && z.toRadius > 0.5f) {
            stroke.setColor(0xFFFFFFFF);
            stroke.setStrokeWidth(1.2f * d);
            c.drawCircle(mx + z.toCx * s, my + z.toCy * s, z.toRadius * s, stroke);
        }
        stroke.setColor(z.shrinking || z.collapsed ? 0xFFFF5A4A : 0xFF4FA0FF);
        stroke.setStrokeWidth(1.6f * d);
        c.drawCircle(mx + z.cx * s, my + z.cy * s, Math.max(0.5f, z.radius * s), stroke);
        c.restore();
    }

    /**
     * Blits the minimap's walls in local coordinates; the bitmap is rebuilt only when the map or its on-screen
     * size changes (it is drawn at the size it is shown, so a big minimap stays sharp).
     */
    private void drawMinimapWalls(Canvas c, TileMap map, MapTheme th, float mx, float my, float mw, float mh, float userScale) {
        int bw = Math.max(2, (int) Math.ceil(mw * userScale));
        int bh = Math.max(2, (int) Math.ceil(mh * userScale));
        int key = (map.id * 7919 + bw) * 7919 + bh;
        if (miniBitmap == null || miniKey != key) {
            if (miniBitmap != null) miniBitmap.recycle();
            miniBitmap = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888);
            miniKey = key;
            if (map.hasTerrain()) {
                MiniTerrain.paint(miniBitmap, map);
                rect.set(mx, my, mx + mw, my + mh);
                c.drawBitmap(miniBitmap, null, rect, miniPaint);
                return;
            }
            Canvas mc = new Canvas(miniBitmap);
            float s = bw / map.worldW;
            float thin = Math.max(1f, 0.8f * d);
            fill.setStyle(Paint.Style.FILL);
            for (int pass = 0; pass < 4; pass++) {
                for (int b = 0; b < map.blockCount; b++) {
                    int kind = map.blocks[b * 5 + 4];
                    if (MapShapes.layerOf(kind) != pass) continue;
                    switch (kind) {
                        case TileMap.WATER: fill.setColor(Palette.withAlpha(th.waterLight, 190)); break;
                        case TileMap.FENCE:
                        case TileMap.FENCE_JOINT: fill.setColor(Palette.withAlpha(th.fence, 200)); break;
                        case TileMap.CRATE: fill.setColor(0xFF9C6A2E); break;
                        case TileMap.PILLAR:
                        case TileMap.TANK: fill.setColor(0xFF8497B4); break;
                        default: fill.setColor(0xFF6F809A); break;
                    }
                    MapShapes.fill(mc, map, b, 0f, 0f, s, fill, path, thin);
                }
            }
        }
        rect.set(mx, my, mx + mw, my + mh);
        c.drawBitmap(miniBitmap, null, rect, map.hasTerrain() ? miniPaint : null);
    }

    /** Battle royale: the zone's countdown on a plate, fighters left and your kills in a row beneath it. */
    private void widgetScoreRoyale(Canvas c, GameState st, ControlGeometry geo) {
        com.hazardyard.game.core.Zone z = st.zone;
        enter(c, geo, ControlSettings.SCORE);
        float pw = 128f * d;
        float ph = 34f * d;
        float top = -28f * d;
        panel(c, -pw * 0.5f, top, pw * 0.5f, top + ph, 10f);
        String caption;
        int secs = (int) Math.ceil(z.timer);
        int color = Palette.TEXT;
        String timer;
        if (z.collapsed) {
            caption = "FINAL STORM";
            timer = "No safe zone";
            color = Palette.BAD;
        } else if (z.shrinking) {
            caption = "ZONE " + z.displayedShrink() + " CLOSING";
            timer = Txt.of(secs / 60) + (secs % 60 < 10 ? ":0" : ":") + Txt.of(secs % 60);
            color = Palette.WARN;
        } else {
            caption = "ZONE " + z.displayedShrink() + " IN";
            timer = Txt.of(secs / 60) + (secs % 60 < 10 ? ":0" : ":") + Txt.of(secs % 60);
        }
        labelFit(c, caption, 0f, top + 11.5f * d, 9.5f, 112f, Palette.TEXT_DIM, Paint.Align.CENTER, medium);
        labelFit(c, timer, 0f, top + ph * 0.86f, 18f, 112f, color, Paint.Align.CENTER, bold);
        float chh = 20f * d;
        float y = top + ph + 5f * d;
        float cw = 62f * d;
        float gap = 4f * d;
        int alive = st.aliveCount();
        panel(c, -cw - gap * 0.5f, y, -gap * 0.5f, y + chh, 8f);
        labelFit(c, "ALIVE " + alive, -cw * 0.5f - gap * 0.5f, y + chh * 0.72f, 12f, 56f, Palette.TEXT, Paint.Align.CENTER, bold);
        panel(c, gap * 0.5f, y, cw + gap * 0.5f, y + chh, 8f);
        labelFit(c, "KILLS " + st.local().kills, cw * 0.5f + gap * 0.5f, y + chh * 0.72f, 12f, 56f, Palette.ACCENT, Paint.Align.CENTER, bold);
        c.restore();
    }

    /** Timer on a plate, the fighters' scores in a row beneath it (compact numbers in their colours when there are many). */
    private void widgetScore(Canvas c, GameState st, ControlGeometry geo) {
        if (st.mode.royale && st.zone.enabled) {
            widgetScoreRoyale(c, st, geo);
            return;
        }
        enter(c, geo, ControlSettings.SCORE);
        float pw = 92f * d;
        float ph = 30f * d;
        float top = -28f * d;
        panel(c, -pw * 0.5f, top, pw * 0.5f, top + ph, 10f);
        int secs = (int) Math.ceil(st.timeLeft);
        if (secs != lastSeconds) {
            lastSeconds = secs;
            int sec = secs % 60;
            timerText = Txt.of(secs / 60) + (sec < 10 ? ":0" : ":") + Txt.of(sec);
        }
        boolean urgent = st.phase == GameState.PHASE_PLAYING && secs <= 10;
        labelFit(c, timerText, 0f, top + ph * 0.73f, 20f, 76f, urgent ? Palette.BAD : Palette.TEXT, Paint.Align.CENTER, bold);

        int n = 0;
        for (int i = 0; i < st.players.length; i++) if (st.players[i].connected) n++;
        if (n == 0) {
            c.restore();
            return;
        }
        float gap = 4f * d;
        float maxTotal = 196f * d;
        float cw = Math.min(44f * d, (maxTotal - (n - 1) * gap) / n);
        boolean compact = cw < 34f * d;
        float chh = 20f * d;
        float total = n * cw + (n - 1) * gap;
        float x = -total * 0.5f;
        float y = top + ph + 5f * d;
        for (int i = 0; i < st.players.length; i++) {
            Player p = st.players[i];
            if (!p.connected) continue;
            panel(c, x, y, x + cw, y + chh, 8f);
            if (i == st.localId) {
                stroke.setColor(Palette.withAlpha(Palette.ACCENT, 190));
                stroke.setStrokeWidth(1.3f * d);
                c.drawRoundRect(rect, 8f * d, 8f * d, stroke);
            }
            if (compact) {
                labelFit(c, Txt.of(p.kills), x + cw * 0.5f, y + chh * 0.74f, 13f, cw / d - 2f, PlayerColors.of(i), Paint.Align.CENTER, bold);
            } else {
                fill.setStyle(Paint.Style.FILL);
                fill.setColor(PlayerColors.of(i));
                c.drawCircle(x + 10f * d, y + chh * 0.5f, 4.6f * d, fill);
                labelFit(c, Txt.of(p.kills), x + cw - 8f * d, y + chh * 0.74f, 13f, 22f, Palette.TEXT, Paint.Align.RIGHT, bold);
            }
            x += cw + gap;
        }
        c.restore();
    }

    private void widgetKillFeed(Canvas c, GameState st, ControlGeometry geo) {
        Effects fx = st.effects;
        enter(c, geo, ControlSettings.FEED);
        float left = -88f * d;
        float top = -39f * d;
        for (int i = fx.feedCount - 1, k = 0; i >= 0 && k < 3; i--, k++) {
            int victim = fx.feedVictim[i];
            int killer = fx.feedKiller[i];
            if (victim < 0 || victim >= st.players.length) continue;
            float fade = Effects.FEED_LIFE - fx.feedAge[i];
            int alpha = fade < 0.8f ? (int) (255f * Math.max(0f, fade) / 0.8f) : 255;
            String vn = st.players[victim].name;
            boolean hasKiller = killer >= 0 && killer < st.players.length;
            String kn = hasKiller ? st.players[killer].name : "";
            String joint = hasKiller ? "  \u00BB  " : (st.mode.royale ? " was caught by the storm" : " was eliminated");
            float wk = hasKiller ? measureFit(kn, 13f, 84f, medium) : 0f;
            float wm = measure(joint, 13f, medium);
            float wv = measureFit(vn, 13f, 84f, medium);
            float total = wk + wm + wv;
            float y = top + k * 26f * d;
            rect.set(left, y, left + total + 16f * d, y + 22f * d);
            fill.setStyle(Paint.Style.FILL);
            fill.setColor(Palette.withAlpha(0xFF131A22, (int) (alpha * 0.7f)));
            c.drawRoundRect(rect, 8f * d, 8f * d, fill);
            float x = left + 8f * d;
            float by = y + 16f * d;
            if (hasKiller) {
                labelFit(c, kn, x, by, 13f, 84f, Palette.withAlpha(PlayerColors.of(killer), alpha), Paint.Align.LEFT, medium);
                x += wk;
                label(c, joint, x, by, 13f, Palette.withAlpha(Palette.TEXT_DIM, alpha), Paint.Align.LEFT, medium);
                x += wm;
                labelFit(c, vn, x, by, 13f, 84f, Palette.withAlpha(PlayerColors.of(victim), alpha), Paint.Align.LEFT, medium);
            } else {
                labelFit(c, vn, x, by, 13f, 84f, Palette.withAlpha(PlayerColors.of(victim), alpha), Paint.Align.LEFT, medium);
                x += wv;
                label(c, joint, x, by, 13f, Palette.withAlpha(Palette.TEXT_DIM, alpha), Paint.Align.LEFT, medium);
            }
        }
        c.restore();
    }

    // ------------------------------------------------------------------ ammo and health

    /**
     * Ammunition and the weapon's name, in a small box the player can place anywhere. While the gun reloads the
     * name line says so, and the number shows the rounds that are really in the gun (a shotgun counts up shell by shell).
     */
    private void widgetAmmo(Canvas c, Player me, ControlGeometry geo) {
        enter(c, geo, ControlSettings.AMMO);
        Weapon wp = me.weapon;
        if (curState != null && curState.mode.royale && curState.survival == null) {
            gearPanel(c, me);
            c.restore();
            return;
        }
        float top = -23f * d;
        if (wp.def.melee) {            // a melee weapon has no ammunition: just its name
            labelFit(c, wp.def.name, 0f, top + 24f * d, 15f, 74f, Palette.TEXT, Paint.Align.CENTER, bold);
            label(c, "melee", 0f, top + 38f * d, 11f, Palette.TEXT_DIM, Paint.Align.CENTER, medium);
            c.restore();
            return;
        }
        int mag = wp.def.magSize;
        int ammoColor = wp.ammo == 0 ? Palette.BAD : (wp.ammo * 4 <= mag ? Palette.WARN : Palette.TEXT);
        String ammo = Txt.of(wp.ammo);
        String magText = Txt.of(mag);
        if (curState != null && curState.survival != null) {       // survival: the number after the slash is what is left in the pack
            int item = com.hazardyard.game.core.Items.ammoFor(wp.def.id);
            magText = Txt.of(item < 0 ? 0 : curState.survival.inv[curState.localId].countOf(item));
        }
        float wa = measure(ammo, 24f, bold);
        float ws = measure("/", 12f, bold);
        float wm = measure(magText, 12f, bold);
        float gap = 2f * d;
        float x = -(wa + gap + ws + wm) * 0.5f;
        float by = top + 24f * d;
        label(c, ammo, x, by, 24f, ammoColor, Paint.Align.LEFT, bold);
        label(c, "/", x + wa + gap, by, 12f, Palette.TEXT_DIM, Paint.Align.LEFT, bold);
        label(c, magText, x + wa + gap + ws, by, 12f, Palette.TEXT_DIM, Paint.Align.LEFT, bold);
        if (wp.reloading) {
            labelFit(c, "Reloading", 0f, top + 38f * d, 11f, 66f, Palette.ACCENT, Paint.Align.CENTER, medium);
        } else {
            labelFit(c, wp.def.name, 0f, top + 38f * d, 11f, 66f, Palette.TEXT_DIM, Paint.Align.CENTER, medium);
        }
        c.restore();
    }

    /**
     * Battleground: the weapon in hand with its magazine and its own spare rounds, the other weapon (dimmed, with its own
     * numbers), and the gear: backpack size and vest. One compact panel, so the HUD does not fill up.
     */
    private void gearPanel(Canvas c, Player me) {
        float hw = 46f * d, hh = 31f * d;
        rect.set(-hw, -hh, hw, hh);
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(0x66101820);
        c.drawRoundRect(rect, 9f * d, 9f * d, fill);
        Weapon wp = me.weapon;
        boolean melee = wp.def.melee;
        int act = me.activeSlot;
        int reserve = act == 0 || act == 1 ? me.slotReserve[act] : 0;
        boolean unlimited = reserve == Integer.MAX_VALUE || reserve >= 65535;
        // ---- the weapon in hand
        float iy = -hh + 15f * d;
        ItemGlyph.draw(c, fill, path, -hw + 15f * d, iy, 9.5f * d, wp.def.id, 0xFFFFFFFF);
        if (melee) {
            labelFit(c, wp.def.name, -hw + 56f * d, iy + 4f * d, 12f, 56f, Palette.TEXT, Paint.Align.CENTER, bold);
        } else {
            int mag = wp.def.magSize;
            int ammoColor = wp.ammo == 0 ? Palette.BAD : (wp.ammo * 4 <= mag ? Palette.WARN : Palette.TEXT);
            String ammo = Txt.of(wp.ammo);
            String res = unlimited ? "\u221E" : Txt.of(reserve);
            float wa = measure(ammo, 21f, bold);
            float x = -hw + 29f * d;
            label(c, ammo, x, iy + 8f * d, 21f, ammoColor, Paint.Align.LEFT, bold);
            label(c, "/" + res, x + wa + 2f * d, iy + 8f * d, 11f, !unlimited && reserve == 0 ? Palette.BAD : Palette.TEXT_DIM, Paint.Align.LEFT, bold);
        }
        if (wp.reloading) {
            rect.set(-hw + 28f * d, iy + 12f * d, hw - 6f * d, iy + 15f * d);
            fill.setColor(0x55FFFFFF);
            c.drawRoundRect(rect, 1.5f * d, 1.5f * d, fill);
            rect.set(-hw + 28f * d, iy + 12f * d, -hw + 28f * d + (hw * 2f - 34f * d) * Math.max(0.03f, wp.reloadFraction), iy + 15f * d);
            fill.setColor(Palette.ACCENT);
            c.drawRoundRect(rect, 1.5f * d, 1.5f * d, fill);
        } else if (me.switchTimer > 0f) {
            label(c, "Switching", hw - 6f * d, iy + 14f * d, 8.5f, Palette.ACCENT, Paint.Align.RIGHT, medium);
        }
        // ---- the other weapon
        int other = 1 - act;
        int oid = me.slotWeapon[other];
        float oy = iy + 22f * d;
        fill.setColor(0x33FFFFFF);
        rect.set(-hw + 6f * d, oy - 9f * d, hw - 6f * d, oy + 9f * d);
        c.drawRoundRect(rect, 6f * d, 6f * d, fill);
        label(c, Txt.of(other + 1), -hw + 10f * d, oy + 3.2f * d, 8.5f, 0x88FFFFFF, Paint.Align.LEFT, bold);
        if (oid >= 0) {
            WeaponDef od = WeaponDef.byId(oid);
            ItemGlyph.draw(c, fill, path, -hw + 28f * d, oy, 7f * d, oid, 0xCCFFFFFF);
            if (!od.melee) {
                int or = me.slotReserve[other];
                String t = Txt.of(me.slotAmmo[other]) + "/" + (or >= 65535 || or == Integer.MAX_VALUE ? "\u221E" : Txt.of(or));
                label(c, t, hw - 9f * d, oy + 3.6f * d, 10f, 0xFFB8C4D8, Paint.Align.RIGHT, bold);
            } else {
                label(c, od.name, hw - 9f * d, oy + 3.6f * d, 9.5f, 0xFFB8C4D8, Paint.Align.RIGHT, medium);
            }
        } else {
            label(c, "empty slot", hw - 9f * d, oy + 3.4f * d, 9.5f, 0x77FFFFFF, Paint.Align.RIGHT, medium);
        }
        // ---- the gear: backpack with its size in pips, and the vest
        float gy = hh - 8f * d;
        ItemGlyph.drawBackpack(c, fill, path, -hw + 13f * d, gy, 5.2f * d, me.backpack > 0 ? 0xFFC8A06A : 0x55C8A06A);
        for (int i = 0; i < 3; i++) {
            fill.setColor(i < me.backpack ? 0xFFFFD34A : 0x33FFFFFF);
            c.drawCircle(-hw + 24f * d + i * 5.6f * d, gy, 1.7f * d, fill);
        }
        ItemGlyph.draw(c, fill, path, 4f * d, gy, 5.2f * d, com.hazardyard.game.core.Items.VEST_LIGHT, me.armor > 0 ? 0xFF58A6FF : 0x5558A6FF);
        label(c, me.armor > 0 ? Txt.of(me.armor) : "\u2014", 13f * d, gy + 3.4f * d, 9.5f, me.armor > 0 ? 0xFF8FC4FF : 0x77FFFFFF, Paint.Align.LEFT, bold);
    }

    /** A thin strip, faint while health is full. */
    private void widgetHealth(Canvas c, Player me, ControlGeometry geo) {
        if (!me.connected || !me.alive) return;
        enter(c, geo, ControlSettings.HEALTH);
        if (curState != null && curState.mode.royale && curState.survival == null) {
            vitals(c, me);
            c.restore();
            return;
        }
        float bw = 150f * d;
        float bh = 6f * d;
        float textW = 26f * d;
        float bx = -(bw + 6f * d + textW) * 0.5f;
        float by = -bh * 0.5f - 1f * d;
        int hp = Math.max(0, me.health);
        float frac = Math.max(0f, Math.min(1f, hp / (float) GameConfig.PLAYER_MAX_HEALTH));
        boolean full = hp >= GameConfig.PLAYER_MAX_HEALTH;
        float a = full ? 0.45f : 1f;
        fill.setStyle(Paint.Style.FILL);
        rect.set(bx, by, bx + bw, by + bh);
        fill.setColor(Palette.withAlpha(0xFFFFFFFF, (int) (48f * a)));
        c.drawRoundRect(rect, bh * 0.5f, bh * 0.5f, fill);
        if (frac > 0f) {
            rect.set(bx, by, bx + bw * frac, by + bh);
            int base = frac > 0.5f ? Palette.GOOD : (frac > 0.25f ? Palette.WARN : Palette.BAD);
            fill.setColor(Palette.withAlpha(base, (int) (255f * a)));
            c.drawRoundRect(rect, bh * 0.5f, bh * 0.5f, fill);
        }
        label(c, Txt.of(hp), bx + bw + 6f * d, by + bh + 2.5f * d, 11f, Palette.withAlpha(Palette.TEXT, (int) (255f * a)),
                Paint.Align.LEFT, bold);
        if (me.armor > 0) {            // the vest: a blue strip above the health
            float ay = by - 9f * d;
            float ah = 5f * d;
            float af = Math.max(0f, Math.min(1f, me.armor / (float) GameConfig.ARMOR_MAX));
            rect.set(bx, ay, bx + bw, ay + ah);
            fill.setColor(Palette.withAlpha(0xFFFFFFFF, 48));
            c.drawRoundRect(rect, ah * 0.5f, ah * 0.5f, fill);
            rect.set(bx, ay, bx + bw * af, ay + ah);
            fill.setColor(0xFF58A6FF);
            c.drawRoundRect(rect, ah * 0.5f, ah * 0.5f, fill);
            label(c, Txt.of(me.armor), bx + bw + 6f * d, ay + ah + 1.5f * d, 11f, 0xFF8FC4FF, Paint.Align.LEFT, bold);
        }
        c.restore();
    }

    /** Battleground vitals: a blue armour bar over the green health bar, each with its own icon and number. The armour bar is always there. */
    private void vitals(Canvas c, Player me) {
        float bw = 138f * d;
        float x0 = -bw * 0.5f - 8f * d;
        int hp = Math.max(0, me.health);
        float hf = Math.max(0f, Math.min(1f, hp / (float) GameConfig.PLAYER_MAX_HEALTH));
        float af = Math.max(0f, Math.min(1f, me.armor / (float) GameConfig.ARMOR_MAX));
        fill.setStyle(Paint.Style.FILL);
        // armour (top)
        float ay = -12f * d, ah = 7f * d;
        shield(c, x0 - 8f * d, ay + ah * 0.5f, 5f * d, me.armor > 0 ? 0xFF58A6FF : 0x6658A6FF);
        rect.set(x0 + 4f * d, ay, x0 + 4f * d + bw, ay + ah);
        fill.setColor(0x55FFFFFF);
        c.drawRoundRect(rect, ah * 0.5f, ah * 0.5f, fill);
        if (af > 0f) {
            rect.set(x0 + 4f * d, ay, x0 + 4f * d + Math.max(ah, bw * af), ay + ah);
            fill.setColor(0xFF58A6FF);
            c.drawRoundRect(rect, ah * 0.5f, ah * 0.5f, fill);
        }
        label(c, me.armor > 0 ? Txt.of(me.armor) : "0", x0 + bw + 10f * d, ay + ah + 1.5f * d, 10.5f, me.armor > 0 ? 0xFF8FC4FF : 0x778FC4FF, Paint.Align.LEFT, bold);
        // health (bottom)
        float by = -1f * d, bh = 9f * d;
        heart(c, x0 - 8f * d, by + bh * 0.5f, 5f * d, hf > 0.25f ? 0xFFE8505B : Palette.BAD);
        rect.set(x0 + 4f * d, by, x0 + 4f * d + bw, by + bh);
        fill.setColor(0x55FFFFFF);
        c.drawRoundRect(rect, bh * 0.5f, bh * 0.5f, fill);
        if (hf > 0f) {
            rect.set(x0 + 4f * d, by, x0 + 4f * d + Math.max(bh, bw * hf), by + bh);
            fill.setColor(hf > 0.5f ? Palette.GOOD : (hf > 0.25f ? Palette.WARN : Palette.BAD));
            c.drawRoundRect(rect, bh * 0.5f, bh * 0.5f, fill);
        }
        label(c, Txt.of(hp), x0 + bw + 10f * d, by + bh + 1.5f * d, 11.5f, Palette.TEXT, Paint.Align.LEFT, bold);
    }

    private void shield(Canvas c, float cx, float cy, float u, int color) {
        path.reset();
        path.moveTo(cx - u, cy - u * 0.8f);
        path.lineTo(cx + u, cy - u * 0.8f);
        path.lineTo(cx + u, cy + u * 0.1f);
        path.quadTo(cx + u * 0.9f, cy + u * 0.9f, cx, cy + u * 1.25f);
        path.quadTo(cx - u * 0.9f, cy + u * 0.9f, cx - u, cy + u * 0.1f);
        path.close();
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(color);
        c.drawPath(path, fill);
    }

    private void heart(Canvas c, float cx, float cy, float u, int color) {
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(color);
        c.drawCircle(cx - u * 0.5f, cy - u * 0.25f, u * 0.62f, fill);
        c.drawCircle(cx + u * 0.5f, cy - u * 0.25f, u * 0.62f, fill);
        path.reset();
        path.moveTo(cx - u * 1.08f, cy - u * 0.05f);
        path.lineTo(cx + u * 1.08f, cy - u * 0.05f);
        path.lineTo(cx, cy + u * 1.1f);
        path.close();
        c.drawPath(path, fill);
    }

    /**
     * An eliminated fighter watching the rest of a Battleground match: where they finished, who they are watching (with
     * that fighter's health, armour and weapon), Previous / Next buttons to change fighter and a Leave button.
     */
    private void drawSpectator(Canvas c, GameState st, Player me, com.hazardyard.game.input.SpectatorUi ui, float time) {
        float cx = mid;
        // top: the result so far
        float ty = st_ + 80f * d;
        rect.set(cx - 118f * d, st_ + 62f * d, cx + 118f * d, st_ + 104f * d);
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(0xAA10151C);
        c.drawRoundRect(rect, 12f * d, 12f * d, fill);
        label(c, "ELIMINATED", cx, ty, 16f, Palette.BAD, Paint.Align.CENTER, bold);
        if (me.placement > 0) label(c, "You finished #" + me.placement + " of " + st.players.length, cx, ty + 17f * d, 11.5f, Palette.TEXT, Paint.Align.CENTER, medium);
        // the buttons
        for (int b = 0; b < 2; b++) {
            float bx = b == 0 ? ui.prevX : ui.nextX;
            boolean held = ui.isHeld(b);
            fill.setColor(held ? 0xFF3A5A8C : 0xCC141B26);
            c.drawCircle(bx, ui.prevY, ui.btnR, fill);
            stroke.setColor(held ? 0xFF9CC4FF : 0xCCB8C4D8);
            stroke.setStrokeWidth(2.2f * d);
            c.drawCircle(bx, ui.prevY, ui.btnR, stroke);
            float k = ui.btnR * 0.32f, dir = b == 0 ? 1f : -1f;
            stroke.setColor(0xFFFFFFFF);
            stroke.setStrokeWidth(3f * d);
            stroke.setStrokeCap(Paint.Cap.ROUND);
            c.drawLine(bx + dir * k * 0.6f, ui.prevY - k * 1.3f, bx - dir * k * 0.7f, ui.prevY, stroke);
            c.drawLine(bx - dir * k * 0.7f, ui.prevY, bx + dir * k * 0.6f, ui.prevY + k * 1.3f, stroke);
            stroke.setStrokeCap(Paint.Cap.BUTT);
        }
        // who is being watched
        Player v = st.view();
        rect.set(ui.barX0, ui.barY, ui.barX1, ui.barY + ui.barH);
        fill.setColor(0xCC10151C);
        c.drawRoundRect(rect, 14f * d, 14f * d, fill);
        if (v != null && v != me && v.connected) {
            int col = PlayerColors.of(st.viewId);
            fill.setColor(col);
            c.drawCircle(ui.barX0 + 18f * d, ui.barY + ui.barH * 0.5f, 7f * d, fill);
            labelFit(c, "Watching " + v.name, ui.barX0 + 32f * d, ui.barY + 19f * d, 14f, (ui.barX1 - ui.barX0) * 0.5f / d, Palette.TEXT, Paint.Align.LEFT, bold);
            // health and armour of the fighter being watched
            float bx0 = ui.barX0 + 32f * d, bw = (ui.barX1 - ui.barX0) * 0.42f;
            float hf = Math.max(0f, Math.min(1f, v.health / (float) GameConfig.PLAYER_MAX_HEALTH));
            float af = Math.max(0f, Math.min(1f, v.armor / (float) GameConfig.ARMOR_MAX));
            rect.set(bx0, ui.barY + 27f * d, bx0 + bw, ui.barY + 33f * d);
            fill.setColor(0x44FFFFFF);
            c.drawRoundRect(rect, 3f * d, 3f * d, fill);
            rect.set(bx0, ui.barY + 27f * d, bx0 + Math.max(4f * d, bw * hf), ui.barY + 33f * d);
            fill.setColor(hf > 0.5f ? Palette.GOOD : (hf > 0.25f ? Palette.WARN : Palette.BAD));
            c.drawRoundRect(rect, 3f * d, 3f * d, fill);
            if (af > 0f) {
                rect.set(bx0, ui.barY + 35f * d, bx0 + Math.max(4f * d, bw * af), ui.barY + 39f * d);
                fill.setColor(0xFF58A6FF);
                c.drawRoundRect(rect, 2f * d, 2f * d, fill);
            }
            // the weapon in their hands and their kills
            float rx = ui.barX1 - 14f * d;
            ItemGlyph.draw(c, fill, path, rx - 8f * d, ui.barY + 34f * d, 8.5f * d, v.weapon.def.id, 0xFFFFFFFF);
            label(c, Txt.of(v.kills) + (v.kills == 1 ? " kill" : " kills"), rx, ui.barY + 21f * d, 12f, Palette.ACCENT, Paint.Align.RIGHT, bold);
        } else {
            label(c, "No one left to watch", (ui.barX0 + ui.barX1) * 0.5f, ui.barY + ui.barH * 0.58f, 14f, Palette.TEXT_DIM, Paint.Align.CENTER, medium);
        }
        // leave
        boolean lh = ui.isHeld(com.hazardyard.game.input.SpectatorUi.BTN_LEAVE);
        rect.set(ui.leaveX, ui.leaveY, ui.leaveX + ui.leaveW, ui.leaveY + ui.leaveH);
        fill.setColor(lh ? 0xFF8A3A2E : 0xDD5A2A24);
        c.drawRoundRect(rect, 12f * d, 12f * d, fill);
        stroke.setColor(0xCCFFFFFF);
        stroke.setStrokeWidth(1.4f * d);
        c.drawRoundRect(rect, 12f * d, 12f * d, stroke);
        label(c, "Leave match", ui.leaveX + ui.leaveW * 0.5f + 8f * d, ui.leaveY + ui.leaveH * 0.64f, 14f, 0xFFFFFFFF, Paint.Align.CENTER, bold);
        // a little door glyph
        float gx = ui.leaveX + 20f * d, gy = ui.leaveY + ui.leaveH * 0.5f;
        stroke.setColor(0xFFFFFFFF);
        stroke.setStrokeWidth(2f * d);
        c.drawRect(gx - 5f * d, gy - 8f * d, gx + 3f * d, gy + 8f * d, stroke);
        c.drawLine(gx - 1f * d, gy, gx + 9f * d, gy, stroke);
        c.drawLine(gx + 5f * d, gy - 3f * d, gx + 9f * d, gy, stroke);
        c.drawLine(gx + 5f * d, gy + 3f * d, gx + 9f * d, gy, stroke);
    }

    // ------------------------------------------------------------------ centre messages

    private void drawCenterMessage(Canvas c, GameState st, Player me, float time) {
        float cx = mid;
        float cy = h * 0.5f;
        switch (st.phase) {
            case GameState.PHASE_LOBBY:
                label(c, "Waiting for the host\u2026", cx, cy, 20f, Palette.TEXT, Paint.Align.CENTER, medium);
                return;
            case GameState.PHASE_COUNTDOWN: {
                int n = Math.max(1, (int) Math.ceil(st.countdown));
                label(c, Txt.of(n), cx + 2f * d, cy + 34f * d + 2f * d, 96f, 0x66000000, Paint.Align.CENTER, bold);
                label(c, Txt.of(n), cx, cy + 34f * d, 96f, Palette.ACCENT, Paint.Align.CENTER, bold);
                label(c, "Get ready", cx, cy - 56f * d, 18f, Palette.TEXT, Paint.Align.CENTER, medium);
                return;
            }
            case GameState.PHASE_PLAYING:
                if (!me.alive && st.mode.royale) {
                    label(c, "Eliminated", cx, h * 0.30f, 30f, Palette.BAD, Paint.Align.CENTER, bold);
                    if (me.placement > 0) {
                        label(c, "You finished #" + me.placement + " of " + st.players.length, cx, h * 0.30f + 26f * d, 16f,
                                Palette.TEXT, Paint.Align.CENTER, medium);
                    }
                    Player v = st.view();
                    if (v != me && v.connected) {
                        labelFit(c, "Watching " + v.name, cx, h * 0.30f + 48f * d, 13f, 220f, PlayerColors.of(st.viewId),
                                Paint.Align.CENTER, medium);
                    }
                } else if (!me.alive) {
                    boolean survival = st.survival != null;
                    // a survivor comes back: say so, and where the belongings are
                    label(c, survival ? "You died" : "Eliminated", cx, h * 0.34f, 30f, Palette.BAD, Paint.Align.CENTER, bold);
                    int s = Math.max(1, (int) Math.ceil(me.respawnTimer));
                    label(c, survival ? "You will get back up in" : "Respawning in", cx - 12f * d, h * 0.34f + 28f * d, 16f, Palette.TEXT, Paint.Align.RIGHT, medium);
                    label(c, Txt.of(s), cx - 6f * d, h * 0.34f + 28f * d, 18f, Palette.ACCENT, Paint.Align.LEFT, bold);
                    if (survival) label(c, "Your pack is on the ground where you fell", cx, h * 0.34f + 52f * d, 12f, Palette.TEXT_DIM, Paint.Align.CENTER, medium);
                } else if (me.spawnProtect > 0f) {
                    label(c, "Spawn shield", cx, h * 0.27f, 13f, Palette.SHIELD, Paint.Align.CENTER, medium);
                }
                return;
            default:
                return;
        }
    }

    private boolean ranksAbove(GameState st, int a, int b) {
        Player pa = st.players[a];
        Player pb = st.players[b];
        if (st.mode.royale) {      // by place: 1 first; a fighter without a place counts as last
            int qa = pa.placement > 0 ? pa.placement : 99;
            int qb = pb.placement > 0 ? pb.placement : 99;
            return qa < qb || (qa == qb && pa.kills > pb.kills);
        }
        return pa.kills > pb.kills || (pa.kills == pb.kills && pa.deaths < pb.deaths);
    }

    private void drawResults(Canvas c, GameState st, com.hazardyard.game.input.SpectatorUi spec) {
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(0x99000000);
        c.drawRect(0f, 0f, w, h, fill);

        int n = 0;
        for (int i = 0; i < st.players.length; i++) if (st.players[i].connected) order[n++] = i;
        for (int a = 1; a < n; a++) {
            int v = order[a];
            int b = a - 1;
            while (b >= 0 && ranksAbove(st, v, order[b])) {
                order[b + 1] = order[b];
                b--;
            }
            order[b + 1] = v;
        }

        float pw = 360f * d;
        // Up to eight fighters have to fit into the screen height: the rows shrink when there are many.
        float rowH = Math.max(20f * d, Math.min(36f * d, (h - st_ - sb - 196f * d) / Math.max(1, n)));
        float ph = 184f * d + n * rowH;
        float px = mid - pw * 0.5f;
        float py = Math.max(10f * d, (h - ph) * 0.5f);
        rect.set(px, py, px + pw, py + ph);
        fill.setColor(Palette.PANEL_SOLID);
        c.drawRoundRect(rect, 14f * d, 14f * d, fill);
        stroke.setColor(Palette.PANEL_EDGE);
        stroke.setStrokeWidth(1.5f * d);
        c.drawRoundRect(rect, 14f * d, 14f * d, stroke);

        float cx = mid;
        if (st.winnerId == st.localId) {
            label(c, st.mode.royale ? "Last one standing" : "Victory", cx, py + 44f * d, st.mode.royale ? 28f : 34f, Palette.ACCENT, Paint.Align.CENTER, bold);
        } else if (st.winnerId >= 0 && st.winnerId < st.players.length) {
            labelFit(c, st.players[st.winnerId].name, cx, py + 40f * d, 26f, 300f, PlayerColors.of(st.winnerId), Paint.Align.CENTER, bold);
            label(c, "wins the match", cx, py + 60f * d, 13f, Palette.TEXT_DIM, Paint.Align.CENTER, medium);
        } else {
            label(c, "Draw", cx, py + 44f * d, 34f, Palette.TEXT, Paint.Align.CENTER, bold);
        }
        float hy = py + 82f * d;
        label(c, "K", px + pw - 70f * d, hy, 12f, Palette.TEXT_DIM, Paint.Align.RIGHT, bold);
        label(c, st.mode.royale ? "" : "D", px + pw - 24f * d, hy, 12f, Palette.TEXT_DIM, Paint.Align.RIGHT, bold);
        for (int r = 0; r < n; r++) {
            int i = order[r];
            Player p = st.players[i];
            float y = py + 90f * d + r * rowH;
            if (i == st.localId) {
                rect.set(px + 8f * d, y + 2f * d, px + pw - 8f * d, y + rowH - 4f * d);
                fill.setColor(0x22FFFFFF);
                c.drawRoundRect(rect, 8f * d, 8f * d, fill);
            }
            float by = y + rowH * 0.62f;
            label(c, "#" + Txt.of(st.mode.royale && p.placement > 0 ? p.placement : r + 1), px + 26f * d, by, 15f, Palette.TEXT_DIM, Paint.Align.CENTER, bold);
            fill.setColor(PlayerColors.of(i));
            c.drawCircle(px + 52f * d, y + rowH * 0.5f - 1f * d, 7f * d, fill);
            labelFit(c, p.name, px + 68f * d, by, 16f, 180f, Palette.TEXT, Paint.Align.LEFT, medium);
            label(c, Txt.of(p.kills), px + pw - 70f * d, by, 18f, Palette.TEXT, Paint.Align.RIGHT, bold);
            if (!st.mode.royale) label(c, Txt.of(p.deaths), px + pw - 24f * d, by, 18f, Palette.TEXT_DIM, Paint.Align.RIGHT, bold);
        }
        int secs = Math.max(0, (int) Math.ceil(st.resultsTimer));
        label(c, "Returning in", cx - 6f * d, py + ph - 52f * d, 12f, Palette.TEXT_DIM, Paint.Align.RIGHT, medium);
        label(c, Txt.of(secs), cx, py + ph - 52f * d, 13f, Palette.ACCENT, Paint.Align.LEFT, bold);
        // Continue: skips the wait
        float bw = 170f * d, bh = 34f * d;
        spec.placeLeave(cx - bw * 0.5f, py + ph - 42f * d, bw, bh);
        boolean held = spec.isHeld(com.hazardyard.game.input.SpectatorUi.BTN_LEAVE);
        rect.set(cx - bw * 0.5f, py + ph - 42f * d, cx + bw * 0.5f, py + ph - 42f * d + bh);
        fill.setColor(held ? 0xFF3A7A52 : 0xFF2E6A44);
        c.drawRoundRect(rect, 12f * d, 12f * d, fill);
        stroke.setColor(0xCCFFFFFF);
        stroke.setStrokeWidth(1.4f * d);
        c.drawRoundRect(rect, 12f * d, 12f * d, stroke);
        label(c, "Continue", cx, py + ph - 42f * d + bh * 0.66f, 15f, 0xFFFFFFFF, Paint.Align.CENTER, bold);
    }
}
