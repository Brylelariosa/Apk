package com.hazardyard.game.core;

/**
 * Bodies that have been killed (a zombie, a soldier) and now flop about under physics until they come to rest: a small
 * Verlet simulation of thirteen joints held together by bone-length constraints, with gravity, ground contact with
 * friction and a bounce, and walls that stop them. A blow gives the body an impulse along the way it was struck, so a
 * bat swung left to right sends the body spinning off to the right and a rifle round throws it backwards, arms trailing.
 *
 * <p>Purely visual: it never affects gameplay, so every device simulates its own and they need not agree exactly. A
 * body that has stopped moving sleeps (costs nothing) and after a while fades out, so the number alive stays small.
 * Nothing allocates after construction.
 */
public final class Ragdolls {
    public static final int MAX = 10;
    private static final int P = Puppet.JOINTS;
    private static final float G = 640f;
    private static final float STEP = 1f / 60f;
    /** Seconds a body lies before it starts to fade, and how long the fade is. */
    private static final float LIFE = 13f, FADE = 2.2f;

    // constraint pairs: bones, the torso box with its braces, and soft limits
    private static final int[] CA = {
            Puppet.J_SH_L, Puppet.J_HIP_L, Puppet.J_SH_L, Puppet.J_SH_R, Puppet.J_SH_L, Puppet.J_SH_R,
            Puppet.J_HEAD, Puppet.J_HEAD, Puppet.J_SH_L, Puppet.J_ELB_L, Puppet.J_SH_R, Puppet.J_ELB_R,
            Puppet.J_HIP_L, Puppet.J_KNEE_L, Puppet.J_HIP_R, Puppet.J_KNEE_R};
    private static final int[] CB = {
            Puppet.J_SH_R, Puppet.J_HIP_R, Puppet.J_HIP_L, Puppet.J_HIP_R, Puppet.J_HIP_R, Puppet.J_HIP_L,
            Puppet.J_SH_L, Puppet.J_SH_R, Puppet.J_ELB_L, Puppet.J_HAND_L, Puppet.J_ELB_R, Puppet.J_HAND_R,
            Puppet.J_KNEE_L, Puppet.J_FOOT_L, Puppet.J_KNEE_R, Puppet.J_FOOT_R};
    // keep the head from folding into the hips, hands and feet from crossing
    private static final int[] MA = {Puppet.J_HEAD, Puppet.J_HEAD, Puppet.J_HAND_L, Puppet.J_FOOT_L, Puppet.J_KNEE_L};
    private static final int[] MB = {Puppet.J_HIP_L, Puppet.J_HIP_R, Puppet.J_HAND_R, Puppet.J_FOOT_R, Puppet.J_KNEE_R};

    public final boolean[] active = new boolean[MAX];
    /** Joint positions in the world (x, y, height above the ground). */
    public final float[][] x = new float[MAX][P];
    public final float[][] y = new float[MAX][P];
    public final float[][] z = new float[MAX][P];
    private final float[][] px = new float[MAX][P];
    private final float[][] py = new float[MAX][P];
    private final float[][] pz = new float[MAX][P];
    private final float[][] rest = new float[MAX][CA.length];
    private final float[][] minRest = new float[MAX][MA.length];
    public final PuppetStyle[] style = new PuppetStyle[MAX];
    /** Seconds since the body was made. */
    public final float[] age = new float[MAX];
    private final float[] calm = new float[MAX];
    private final float[] acc = new float[MAX];
    private final boolean[] asleep = new boolean[MAX];
    /** 0..1 visibility (1 while lying, fading to 0 at the end of its life). */
    public final float[] fade = new float[MAX];
    /** Radius of the blood pool under the body. */
    public final float[] pool = new float[MAX];
    /** A white flash for the first moments after a hit. */
    public final float[] flash = new float[MAX];
    private int next;

    public Ragdolls() {
        for (int i = 0; i < MAX; i++) style[i] = new PuppetStyle();
    }

    public void clear() {
        for (int i = 0; i < MAX; i++) active[i] = false;
        next = 0;
    }

    public int activeCount() {
        int n = 0;
        for (int i = 0; i < MAX; i++) if (active[i]) n++;
        return n;
    }

    /**
     * Makes a body from a posed puppet standing at (cx, cy) facing {@code aim}, and throws it along (dirX, dirY)
     * with the given strength (about 0.3 for a pistol round, 1 for a bat swing, 1.5 for a car).
     */
    public void spawn(Puppet pose, float cx, float cy, float aim, PuppetStyle s, float dirX, float dirY, float strength) {
        int slot = -1;
        float oldest = -1f;
        for (int i = 0; i < MAX; i++) {
            if (!active[i]) {
                slot = i;
                break;
            }
            if (age[i] > oldest) {
                oldest = age[i];
                slot = i;
            }
        }
        active[slot] = true;
        style[slot].copyFrom(s);
        age[slot] = 0f;
        calm[slot] = 0f;
        acc[slot] = 0f;
        asleep[slot] = false;
        fade[slot] = 1f;
        pool[slot] = 0f;
        flash[slot] = 0.25f;
        float c = (float) Math.cos(aim), sn = (float) Math.sin(aim);
        float[] lx = pose.j;
        float len = (float) Math.sqrt(dirX * dirX + dirY * dirY);
        if (len < 1e-3f) {
            dirX = (float) Math.cos(aim);
            dirY = (float) Math.sin(aim);
            len = 1f;
        }
        dirX /= len;
        dirY /= len;
        float speed = (22f + 76f * Math.min(strength, 1.6f)) * STEP;      // units per step
        float pop = (28f + 45f * Math.min(strength, 1.6f)) * STEP;
        float perpX = -dirY, perpY = dirX;
        for (int j = 0; j < P; j++) {
            float fx = lx[j * 3], fy = lx[j * 3 + 1], fz = lx[j * 3 + 2];
            float wx = cx + fx * c - fy * sn, wy = cy + fx * sn + fy * c;
            x[slot][j] = wx;
            y[slot][j] = wy;
            z[slot][j] = fz;
            // a blow lands high on the body: the head and chest fly further than the feet, which makes it tumble
            float k = 0.55f + 0.7f * Math.min(1f, fz / 22f);
            float side = (j == Puppet.J_SH_L || j == Puppet.J_HIP_L || j == Puppet.J_HAND_L || j == Puppet.J_ELB_L || j == Puppet.J_FOOT_L || j == Puppet.J_KNEE_L) ? -1f : 1f;
            float spin = side * 0.28f * speed * (fz / 20f);
            px[slot][j] = wx - (dirX * speed * k + perpX * spin);
            py[slot][j] = wy - (dirY * speed * k + perpY * spin);
            pz[slot][j] = fz - pop * (0.7f + 0.5f * (fz / 24f));
        }
        for (int i = 0; i < CA.length; i++) rest[slot][i] = dist(slot, CA[i], CB[i]);
        for (int i = 0; i < MA.length; i++) minRest[slot][i] = dist(slot, MA[i], MB[i]) * 0.82f;
    }

    private float dist(int s, int a, int b) {
        float dx = x[s][a] - x[s][b], dy = y[s][a] - y[s][b], dz = z[s][a] - z[s][b];
        return (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    /** Advances every body; {@code terrain} (may be null) stops them at walls. */
    public void update(float dt, Terrain terrain) {
        if (dt > 0.05f) dt = 0.05f;
        for (int s = 0; s < MAX; s++) {
            if (!active[s]) continue;
            age[s] += dt;
            if (flash[s] > 0f) flash[s] -= dt;
            if (age[s] > LIFE) {
                fade[s] = Math.max(0f, 1f - (age[s] - LIFE) / FADE);
                if (fade[s] <= 0f) {
                    active[s] = false;
                    continue;
                }
            }
            float target = Math.min(1f, age[s] / 2.6f);
            if (pool[s] < target) pool[s] = target;
            if (asleep[s]) continue;
            acc[s] += dt;
            int steps = 0;
            while (acc[s] >= STEP && steps < 3) {
                acc[s] -= STEP;
                steps++;
                step(s, terrain);
            }
            if (acc[s] > STEP * 3f) acc[s] = 0f;
        }
    }

    private void step(int s, Terrain terrain) {
        float[] X = x[s], Y = y[s], Z = z[s], PX = px[s], PY = py[s], PZ = pz[s];
        float energy = 0f;
        for (int j = 0; j < P; j++) {
            float vx = (X[j] - PX[j]) * 0.997f, vy = (Y[j] - PY[j]) * 0.997f, vz = (Z[j] - PZ[j]) * 0.997f;
            PX[j] = X[j];
            PY[j] = Y[j];
            PZ[j] = Z[j];
            X[j] += vx;
            Y[j] += vy;
            Z[j] += vz - G * STEP * STEP;
            energy += Math.abs(vx) + Math.abs(vy) + Math.abs(vz);
        }
        for (int it = 0; it < 4; it++) {
            for (int i = 0; i < CA.length; i++) bone(X, Y, Z, CA[i], CB[i], rest[s][i], 0.5f, 0.5f, true);
            for (int i = 0; i < MA.length; i++) bone(X, Y, Z, MA[i], MB[i], minRest[s][i], 0.5f, 0.5f, false);
            for (int j = 0; j < P; j++) {
                float r = j == Puppet.J_HEAD ? 2.6f : Puppet.FLOOR_Z * 0.55f;
                if (Z[j] < r) {
                    Z[j] = r;
                    float vz = Z[j] - PZ[j];
                    if (vz < -0.5f) PZ[j] = Z[j] + vz * 0.22f;     // a small bounce
                    // ground friction: drag the previous position towards the current one
                    PX[j] += (X[j] - PX[j]) * 0.10f;
                    PY[j] += (Y[j] - PY[j]) * 0.10f;
                }
            }
        }
        if (terrain != null) {
            for (int j = 0; j < P; j++) {
                int tx = (int) Math.floor(X[j] / GameConfig.TILE), ty = (int) Math.floor(Y[j] / GameConfig.TILE);
                if (terrain.isSolid(tx, ty)) {
                    int ox = (int) Math.floor(PX[j] / GameConfig.TILE), oy = (int) Math.floor(PY[j] / GameConfig.TILE);
                    if (!terrain.isSolid(tx, oy)) { Y[j] = PY[j]; PY[j] = Y[j]; }
                    else if (!terrain.isSolid(ox, ty)) { X[j] = PX[j]; PX[j] = X[j]; }
                    else { X[j] = PX[j]; Y[j] = PY[j]; }
                }
            }
        }
        if (energy < 0.9f) {
            calm[s] += STEP;
            if (calm[s] > 0.7f) asleep[s] = true;
        } else {
            calm[s] = 0f;
        }
    }

    /** Moves two joints so their distance is {@code len} (or at least {@code len} for a minimum constraint). */
    private static void bone(float[] X, float[] Y, float[] Z, int a, int b, float len, float wa, float wb, boolean exact) {
        float dx = X[b] - X[a], dy = Y[b] - Y[a], dz = Z[b] - Z[a];
        float d = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (d < 1e-4f) return;
        if (!exact && d >= len) return;
        float diff = (d - len) / d;
        X[a] += dx * diff * wa;
        Y[a] += dy * diff * wa;
        Z[a] += dz * diff * wa;
        X[b] -= dx * diff * wb;
        Y[b] -= dy * diff * wb;
        Z[b] -= dz * diff * wb;
    }
}
