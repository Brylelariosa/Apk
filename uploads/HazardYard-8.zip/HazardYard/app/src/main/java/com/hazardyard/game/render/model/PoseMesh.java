package com.hazardyard.game.render.model;

/**
 * Builds a posed low-poly body out of oriented boxes and prisms every frame and hands the lit, depth-sorted faces to a
 * {@link FaceSink}. It lights and sorts exactly like {@link SceneBuffer} (the soldiers) so a zombie, a ragdoll and a
 * soldier share one look, but its parts are placed freely in the world rather than being rigid groups of a fixed model:
 * that is what lets limbs bend, bodies fall over and ragdolls flop.
 *
 * <p>Allocation-free after construction. One instance per thread.
 */
public final class PoseMesh {
    private static final float AMBIENT = 0.46f;
    private static final float LIGHT_X = -0.46f, LIGHT_Y = -0.38f, LIGHT_Z = 0.80f;
    private static final float LIGHT_NORM = (float) Math.sqrt(LIGHT_X * LIGHT_X + LIGHT_Y * LIGHT_Y + LIGHT_Z * LIGHT_Z);

    private final float[] xs;
    private final float[] ys;
    private final int[] faceOffset;
    private final int[] faceCount;
    private final int[] faceColor;
    private final float[] faceDepth;
    private final int[] order;
    private int faces;
    private int verts;

    /** 0..1: blends every colour towards white (a hit flash). */
    public float whiten;
    /** 1 opaque .. 0 invisible. */
    public float alpha = 1f;

    // scratch: corners of the box being built
    private final float[] cx = new float[8], cy = new float[8], cz = new float[8];
    private final float[] px = new float[16], py = new float[16], pz = new float[16];

    public PoseMesh(int maxFaces, int maxVerts) {
        xs = new float[maxVerts];
        ys = new float[maxVerts];
        faceOffset = new int[maxFaces];
        faceCount = new int[maxFaces];
        faceColor = new int[maxFaces];
        faceDepth = new float[maxFaces];
        order = new int[maxFaces];
    }

    public void begin() {
        faces = 0;
        verts = 0;
        whiten = 0f;
        alpha = 1f;
    }

    public int faceCount() {
        return faces;
    }

    // ------------------------------------------------------------------ solids

    /**
     * An oriented box: centre (x, y, z), half sizes (ha, hb, hc) along the unit axis a, the unit axis b and their cross
     * product c = a x b.
     */
    public void box(float x, float y, float z, float ha, float hb, float hc, float ax, float ay, float az, float bx, float by, float bz,
                    int color, boolean emissive) {
        float cxv = ay * bz - az * by, cyv = az * bx - ax * bz, czv = ax * by - ay * bx;
        float cl = (float) Math.sqrt(cxv * cxv + cyv * cyv + czv * czv);
        if (cl < 1e-5f) return;
        cxv /= cl;
        cyv /= cl;
        czv /= cl;
        for (int i = 0; i < 8; i++) {
            float sa = (i & 1) == 0 ? -ha : ha, sb = (i & 2) == 0 ? -hb : hb, sc = (i & 4) == 0 ? -hc : hc;
            cx[i] = x + ax * sa + bx * sb + cxv * sc;
            cy[i] = y + ay * sa + by * sb + cyv * sc;
            cz[i] = z + az * sa + bz * sb + czv * sc;
        }
        // corner index = (a:+1 -> bit0) | (b:+1 -> bit1) | (c:+1 -> bit2)
        face4(1, 3, 7, 5, ax, ay, az, color, emissive);         // +a
        face4(0, 4, 6, 2, -ax, -ay, -az, color, emissive);      // -a
        face4(2, 6, 7, 3, bx, by, bz, color, emissive);         // +b
        face4(0, 1, 5, 4, -bx, -by, -bz, color, emissive);      // -b
        face4(4, 5, 7, 6, cxv, cyv, czv, color, emissive);      // +c
        face4(0, 2, 3, 1, -cxv, -cyv, -czv, color, emissive);   // -c
    }

    /**
     * A box from point A to point B with a rectangular cross-section {@code w} wide (sideways) and {@code h} thick,
     * extended by {@code over} at both ends so joints overlap without gaps. The side axis is horizontal where possible.
     */
    public void beam(float ax, float ay, float az, float bx, float by, float bz, float w, float h, float over, int color) {
        float dx = bx - ax, dy = by - ay, dz = bz - az;
        float len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1e-4f) return;
        dx /= len;
        dy /= len;
        dz /= len;
        // side = horizontal, perpendicular to the beam
        float sx = -dy, sy = dx, sz = 0f;
        float sl = (float) Math.sqrt(sx * sx + sy * sy);
        if (sl < 1e-3f) {
            sx = 1f;
            sy = 0f;
            sl = 1f;
        }
        sx /= sl;
        sy /= sl;
        box((ax + bx) * 0.5f, (ay + by) * 0.5f, (az + bz) * 0.5f, len * 0.5f + over, w * 0.5f, h * 0.5f, dx, dy, dz, sx, sy, sz, color, false);
    }

    /** A flat-topped prism with {@code sides} faces around the axis through (x, y, z) pointing along u; p is a unit vector across it. */
    public void prism(float x, float y, float z, float ux, float uy, float uz, float rx, float ry, float rz, float radius, float halfHeight,
                      int sides, int color) {
        // q = u x p
        float qx = uy * rz - uz * ry, qy = uz * rx - ux * rz, qz = ux * ry - uy * rx;
        float ql = (float) Math.sqrt(qx * qx + qy * qy + qz * qz);
        if (ql < 1e-5f) return;
        qx /= ql;
        qy /= ql;
        qz /= ql;
        sides = Math.min(sides, 8);
        for (int i = 0; i < sides; i++) {
            float a0 = (float) (2.0 * Math.PI * i / sides), a1 = (float) (2.0 * Math.PI * (i + 1) / sides);
            float c0 = (float) Math.cos(a0), s0 = (float) Math.sin(a0), c1 = (float) Math.cos(a1), s1 = (float) Math.sin(a1);
            float r0x = rx * c0 + qx * s0, r0y = ry * c0 + qy * s0, r0z = rz * c0 + qz * s0;
            float r1x = rx * c1 + qx * s1, r1y = ry * c1 + qy * s1, r1z = rz * c1 + qz * s1;
            px[0] = x + r0x * radius - ux * halfHeight; py[0] = y + r0y * radius - uy * halfHeight; pz[0] = z + r0z * radius - uz * halfHeight;
            px[1] = x + r1x * radius - ux * halfHeight; py[1] = y + r1y * radius - uy * halfHeight; pz[1] = z + r1z * radius - uz * halfHeight;
            px[2] = x + r1x * radius + ux * halfHeight; py[2] = y + r1y * radius + uy * halfHeight; pz[2] = z + r1z * radius + uz * halfHeight;
            px[3] = x + r0x * radius + ux * halfHeight; py[3] = y + r0y * radius + uy * halfHeight; pz[3] = z + r0z * radius + uz * halfHeight;
            float mx = r0x + r1x, my = r0y + r1y, mz = r0z + r1z;
            addFace(px, py, pz, 4, mx, my, mz, color, false);
        }
        // top cap
        for (int i = 0; i < sides; i++) {
            float a0 = (float) (2.0 * Math.PI * i / sides);
            float c0 = (float) Math.cos(a0), s0 = (float) Math.sin(a0);
            px[i] = x + (rx * c0 + qx * s0) * radius + ux * halfHeight;
            py[i] = y + (ry * c0 + qy * s0) * radius + uy * halfHeight;
            pz[i] = z + (rz * c0 + qz * s0) * radius + uz * halfHeight;
        }
        addFace(px, py, pz, sides, ux, uy, uz, color, false);
    }

    private void face4(int i0, int i1, int i2, int i3, float nx, float ny, float nz, int color, boolean emissive) {
        px[0] = cx[i0]; py[0] = cy[i0]; pz[0] = cz[i0];
        px[1] = cx[i1]; py[1] = cy[i1]; pz[1] = cz[i1];
        px[2] = cx[i2]; py[2] = cy[i2]; pz[2] = cz[i2];
        px[3] = cx[i3]; py[3] = cy[i3]; pz[3] = cz[i3];
        addFace(px, py, pz, 4, nx, ny, nz, color, emissive);
    }

    private void addFace(float[] fx, float[] fy, float[] fz, int n, float nx, float ny, float nz, int base, boolean emissive) {
        if (faces >= faceOffset.length || verts + n > xs.length) return;
        float nl = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
        if (nl < 1e-6f) return;
        nx /= nl;
        ny /= nl;
        nz /= nl;
        if (!Projection.facesViewer(nx, ny, nz)) return;
        int argb;
        if (emissive) {
            argb = base;
        } else {
            float diffuse = (nx * LIGHT_X + ny * LIGHT_Y + nz * LIGHT_Z) / LIGHT_NORM;
            if (diffuse < 0f) diffuse = 0f;
            argb = SceneBuffer.shade(base, AMBIENT + (1.12f - AMBIENT) * diffuse);
        }
        if (whiten > 0f) argb = SceneBuffer.mixWhite(argb, whiten);
        if (alpha < 0.999f) argb = (((int) (((argb >>> 24) & 0xFF) * alpha)) << 24) | (argb & 0x00FFFFFF);
        float depth = 0f;
        faceOffset[faces] = verts;
        faceCount[faces] = n;
        for (int k = 0; k < n; k++) {
            xs[verts] = Projection.screenX(fx[k], fz[k]);
            ys[verts] = Projection.screenY(fy[k], fz[k]);
            depth += Projection.nearness(fx[k], fy[k], fz[k]);
            verts++;
        }
        faceDepth[faces] = depth / n;
        faceColor[faces] = argb;
        faces++;
    }

    /** Sorts the faces far to near and hands them to the sink. */
    public void flush(FaceSink sink) {
        for (int i = 0; i < faces; i++) {
            int j = i - 1;
            float d = faceDepth[i];
            while (j >= 0 && faceDepth[order[j]] > d) {
                order[j + 1] = order[j];
                j--;
            }
            order[j + 1] = i;
        }
        for (int i = 0; i < faces; i++) {
            int f = order[i];
            sink.polygon(xs, ys, faceOffset[f], faceCount[f], faceColor[f]);
        }
    }
}
