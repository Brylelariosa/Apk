package com.hazardyard.game.input;

import com.hazardyard.game.core.Items;
import com.hazardyard.game.core.LocalInput;
import com.hazardyard.game.survival.Inventory;
import com.hazardyard.game.survival.Recipes;
import com.hazardyard.game.survival.SurvivalSim;

/**
 * The survival screens' touch handling and layout: a hotbar of six slots with a bag button beside it, and the bag, a
 * modal panel with the pack on the left (tap an item to select it, drag it onto another slot to swap, or tap a second
 * slot) and, on the right, two tabs: the selected item's details with Use / Equip / Drop, and the crafting list with
 * what each recipe needs. Pure Java: the renderer reads the geometry from here, so what is drawn is what can be
 * touched. Everything it wants done is queued as commands for the host.
 *
 * <p>While the bag is open it is modal: every touch belongs to it (the close button, the tabs, the slots), and a touch
 * outside the panel closes it. Nothing reaches the pause button or the game controls underneath, which is what made the
 * old close button send the player to the pause menu.
 */
public final class SurvivalUi {
    public static final int TAB_ITEMS = 0, TAB_CRAFT = 1;
    /** What the primary button next to Drop does for the selected item. */
    public static final int ACT_NONE = 0, ACT_USE = 1, ACT_EQUIP = 2, ACT_HOLD = 3;
    public static final int COLS = 6;

    /** True in survival mode; when false this does nothing. */
    public volatile boolean active;
    public volatile boolean bagOpen;
    public int selSlot = -1;
    public int selRecipe = -1;
    public int tab = TAB_ITEMS;
    public float recipeScroll;

    // the world around the survivor, as far as crafting is concerned (set every frame by the game loop)
    private Inventory inv;
    private boolean nearBench, nearFire;

    // ---- geometry (pixels)
    public float density = 1f;
    public float slot, gap;
    public float hotX0, hotY;
    public float bagBtnX, bagBtnY, bagBtnS;
    public float panelX0, panelY0, panelX1, panelY1;
    public float headerH;
    public float tabX0, tabY, tabW, tabH, tabGap;
    public float closeX, closeY, closeS;
    public float gridX0, gridY0, cell, cellGap;
    public float detX0, detY0, detX1, detY1;
    public float actX0, actY, actW, actH, actGap;
    public float listX0, listY0, listX1, listY1, rowH;
    public float craftX, craftY, craftW, craftH;
    private int viewW, viewH;

    // ---- pointer
    private int owner = -1;
    private float downX, downY, lastX, lastY;
    private boolean dragged;
    private int downCell = -1;
    /** Dragging an item: which slot it comes from and where the finger is (drawn as a floating icon). */
    public boolean dragging;
    public int dragSlot = -1;
    public float dragX, dragY;

    private final int[] cmdQueueType = new int[16];
    private final int[] cmdQueueA = new int[16];
    private final int[] cmdQueueB = new int[16];
    private int queued;

    public synchronized void setContext(Inventory inv, boolean nearBench, boolean nearFire) {
        this.inv = inv;
        this.nearBench = nearBench;
        this.nearFire = nearFire;
    }

    /** The pack the screen is showing (null before the first frame). */
    public synchronized Inventory inventory() {
        return inv;
    }

    public boolean nearBench() {
        return nearBench;
    }

    public boolean nearFire() {
        return nearFire;
    }

    /** True when the recipe could be crafted right now (ingredients in the pack, station within reach). */
    public synchronized boolean craftable(int recipe) {
        if (inv == null || recipe < 0 || recipe >= Recipes.ALL.length) return false;
        Recipes.Recipe r = Recipes.ALL[recipe];
        if (r.station == Recipes.BENCH && !nearBench) return false;
        if (r.station == Recipes.FIRE && !nearFire) return false;
        return Recipes.canAfford(inv, r);
    }

    /** What the primary action button does for the item in a slot (see the ACT_ constants). */
    public static int actionFor(int item, int slotIndex) {
        if (item < 0) return ACT_NONE;
        if (Items.foodValue(item) > 0 || Items.healValue(item) > 0 || Items.isVest(item)) return ACT_USE;
        if (Items.isWeapon(item) || Items.category(item) == Items.CAT_TOOL || Items.category(item) == Items.CAT_BUILD) {
            return slotIndex < Inventory.HOTBAR ? ACT_HOLD : ACT_EQUIP;
        }
        return ACT_NONE;
    }

    public synchronized void layout(int w, int h, float dens, float insetL, float insetT, float insetR, float insetB) {
        viewW = w;
        viewH = h;
        density = dens;
        float d = dens;
        slot = 42f * d;
        gap = 4f * d;
        float total = Inventory.HOTBAR * slot + (Inventory.HOTBAR - 1) * gap + gap + slot;      // six slots, a gap, the bag button
        hotX0 = (w - total) * 0.5f;
        hotY = h - insetB - slot - 46f * d;           // above the health bar
        bagBtnS = slot;
        bagBtnX = hotX0 + Inventory.HOTBAR * (slot + gap) + gap;
        bagBtnY = hotY;

        panelX0 = Math.max(insetL, 0f) + 12f * d;
        panelX1 = w - Math.max(insetR, 0f) - 12f * d;
        panelY0 = insetT + 8f * d;
        panelY1 = h - insetB - 8f * d;
        headerH = 44f * d;
        closeS = 34f * d;
        closeX = panelX1 - closeS - 8f * d;
        closeY = panelY0 + (headerH - closeS) * 0.5f;
        tabW = 92f * d;
        tabH = 30f * d;
        tabGap = 6f * d;
        tabY = panelY0 + (headerH - tabH) * 0.5f;
        tabX0 = closeX - 12f * d - 2f * tabW - tabGap;

        float bodyY0 = panelY0 + headerH;
        float bodyH = panelY1 - bodyY0 - 12f * d;
        cell = Math.min(52f * d, Math.max(28f * d, (bodyH - 3f * 4f * d) / 4f));
        cellGap = 4f * d;
        gridX0 = panelX0 + 14f * d;
        gridY0 = bodyY0 + 4f * d;
        float gridW = COLS * cell + (COLS - 1) * cellGap;

        detX0 = gridX0 + gridW + 16f * d;
        detX1 = panelX1 - 14f * d;
        detY0 = bodyY0 + 4f * d;
        detY1 = panelY1 - 12f * d;
        actH = 38f * d;
        actGap = 8f * d;
        actY = detY1 - actH;
        actW = (detX1 - detX0 - actGap) * 0.5f;
        actX0 = detX0;

        listX0 = detX0;
        listX1 = detX1;
        listY0 = detY0;
        craftH = 38f * d;
        craftY = detY1 - craftH;
        craftX = detX0;
        craftW = detX1 - detX0;
        listY1 = craftY - 8f * d;
        rowH = 44f * d;
    }

    public float slotX(int i) {
        return hotX0 + i * (slot + gap);
    }

    public float cellX(int i) {
        return gridX0 + (i % COLS) * (cell + cellGap);
    }

    public float cellY(int i) {
        return gridY0 + (i / COLS) * (cell + cellGap);
    }

    public float tabX(int t) {
        return tabX0 + t * (tabW + tabGap);
    }

    public float actX(int i) {
        return actX0 + i * (actW + actGap);
    }

    public float rowY(int r) {
        return listY0 + r * rowH - recipeScroll;
    }

    public float maxScroll() {
        return Math.max(0f, Recipes.ALL.length * rowH - (listY1 - listY0));
    }

    private static boolean in(float x, float y, float x0, float y0, float w, float h) {
        return x >= x0 && x <= x0 + w && y >= y0 && y <= y0 + h;
    }

    private int cellAt(float x, float y) {
        for (int i = 0; i < Inventory.SLOTS; i++) if (in(x, y, cellX(i), cellY(i), cell, cell)) return i;
        return -1;
    }

    // ------------------------------------------------------------------ touches

    /** Returns true when the touch belongs to this layer (and must not reach the game controls). */
    public synchronized boolean onDown(int id, float x, float y) {
        if (!active) return false;
        if (bagOpen) {
            if (owner >= 0) return true;           // a second finger while the bag is open is swallowed too: it is modal
            owner = id;
            downX = x;
            downY = y;
            lastX = x;
            lastY = y;
            dragged = false;
            dragging = false;
            downCell = tab == TAB_ITEMS ? cellAt(x, y) : -1;
            if (downCell < 0 && tab == TAB_CRAFT) downCell = cellAt(x, y);
            return true;
        }
        for (int i = 0; i < Inventory.HOTBAR; i++) {
            if (in(x, y, slotX(i), hotY, slot, slot)) {
                push(SurvivalSim.CMD_SELECT, i, 0);
                return true;           // handled right away; nothing to track
            }
        }
        if (in(x, y, bagBtnX, bagBtnY, bagBtnS, bagBtnS)) {
            bagOpen = true;
            selSlot = -1;
            dragging = false;
            return true;
        }
        return false;
    }

    public synchronized boolean owns(int id) {
        return owner == id;
    }

    public synchronized void onMove(int id, float x, float y) {
        if (owner != id) return;
        float slop = 9f * density;
        if (!dragged && (Math.abs(x - downX) > slop || Math.abs(y - downY) > slop)) {
            dragged = true;
            // dragging an item out of a slot picks it up
            if (downCell >= 0 && inv != null && !inv.isEmpty(downCell)) {
                dragging = true;
                dragSlot = downCell;
                selSlot = downCell;
            }
        }
        if (dragging) {
            dragX = x;
            dragY = y;
        } else if (dragged && tab == TAB_CRAFT && downX >= listX0) {
            recipeScroll = Math.max(0f, Math.min(maxScroll(), recipeScroll - (y - lastY)));
        }
        lastX = x;
        lastY = y;
    }

    public synchronized void onUp(int id) {
        if (owner != id) return;
        owner = -1;
        float x = lastX, y = lastY;
        if (dragging) {
            dragging = false;
            int to = cellAt(x, y);
            if (to >= 0 && to != dragSlot) {
                push(SurvivalSim.CMD_SWAP, dragSlot, to);
                selSlot = to;
            }
            dragSlot = -1;
            return;
        }
        if (dragged) return;
        // the close button, or a tap outside the panel
        if (in(x, y, closeX, closeY, closeS, closeS) || x < panelX0 || x > panelX1 || y < panelY0 || y > panelY1) {
            closeBag();
            return;
        }
        for (int t = 0; t < 2; t++) {
            if (in(x, y, tabX(t), tabY, tabW, tabH)) {
                tab = t;
                return;
            }
        }
        int c = cellAt(x, y);
        if (c >= 0) {
            if (selSlot < 0) {
                if (inv != null && !inv.isEmpty(c)) selSlot = c;
            } else if (selSlot == c) {
                selSlot = -1;
            } else if (inv != null && inv.isEmpty(selSlot)) {
                selSlot = inv.isEmpty(c) ? -1 : c;
            } else {
                push(SurvivalSim.CMD_SWAP, selSlot, c);
                selSlot = -1;
            }
            tab = TAB_ITEMS;
            return;
        }
        if (tab == TAB_ITEMS) {
            if (selSlot >= 0 && inv != null && !inv.isEmpty(selSlot)) {
                int act = actionFor(inv.item[selSlot], selSlot);
                if (in(x, y, actX(0), actY, actW, actH) && act != ACT_NONE) {
                    doPrimary(act);
                    return;
                }
                if (in(x, y, actX(1), actY, actW, actH)) {
                    push(SurvivalSim.CMD_DROP, selSlot, 0);
                    selSlot = -1;
                }
            }
            return;
        }
        // the crafting tab
        if (x >= listX0 && x <= listX1 && y >= listY0 && y <= listY1) {
            int r = (int) Math.floor((y - listY0 + recipeScroll) / rowH);
            if (r >= 0 && r < Recipes.ALL.length) selRecipe = r;
            return;
        }
        if (selRecipe >= 0 && in(x, y, craftX, craftY, craftW, craftH)) {
            push(SurvivalSim.CMD_CRAFT, selRecipe, 0);
        }
    }

    private void doPrimary(int act) {
        if (act == ACT_USE) {
            push(SurvivalSim.CMD_USE, selSlot, 0);
        } else if (act == ACT_HOLD) {
            push(SurvivalSim.CMD_SELECT, selSlot, 0);
            closeBag();
        } else if (act == ACT_EQUIP && inv != null) {
            // put it in the hotbar slot that is in hand and take it out
            int to = Math.max(0, Math.min(Inventory.HOTBAR - 1, inv.selected));
            push(SurvivalSim.CMD_SWAP, selSlot, to);
            push(SurvivalSim.CMD_SELECT, to, 0);
            selSlot = to;
            closeBag();
        }
    }

    public synchronized void closeBag() {
        bagOpen = false;
        selSlot = -1;
        dragging = false;
        dragSlot = -1;
        owner = -1;
    }

    public synchronized void cancel() {
        owner = -1;
        dragged = false;
        dragging = false;
    }

    private void push(int type, int a, int b) {
        if (queued >= cmdQueueType.length) return;
        cmdQueueType[queued] = type;
        cmdQueueA[queued] = a;
        cmdQueueB[queued] = b;
        queued++;
    }

    /** Moves the queued commands into this frame's input. */
    public synchronized void drainCommands(LocalInput out) {
        for (int i = 0; i < queued; i++) out.pushCommand(cmdQueueType[i], cmdQueueA[i], cmdQueueB[i]);
        queued = 0;
    }

    /** A one-line description of an item (kept for the hotbar tip). */
    public static String describe(int item) {
        if (item < 0) return "";
        int food = Items.foodValue(item);
        if (food > 0) return Items.name(item) + "  \u2022  restores " + food + " hunger";
        int heal = Items.healValue(item);
        if (heal > 0) return Items.name(item) + "  \u2022  heals " + heal;
        if (Items.isVest(item)) return Items.name(item) + "  \u2022  " + Items.armorOf(item) + " armour";
        return Items.name(item);
    }
}
