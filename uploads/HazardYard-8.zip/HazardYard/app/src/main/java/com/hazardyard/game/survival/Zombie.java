package com.hazardyard.game.survival;

import com.hazardyard.game.core.Puppet;

/**
 * A zombie. The host moves it, decides its state and fights; clients only show what the snapshots and events say (smoothed
 * in {@link #rx}, {@link #ry}) and play the matching animation. What it looks like comes from its type and its id
 * ({@link ZombieLook}), the same on every device.
 */
public final class Zombie {
    public static final int WALKER = 0, RUNNER = 1, BRUTE = 2;
    public static final float RADIUS = 13f;

    // ---- what a blow did (events on the wire)
    public static final int EV_HIT = 0, EV_STUMBLE = 1, EV_KNOCKDOWN = 2, EV_DEATH = 3, EV_GROUND_HIT = 4;

    public int id;
    /** Client: the snapshot this entity was last in (older ones are gone). */
    public int seen;
    public boolean active;
    public int type;
    public float x, y, aim;
    public int hp;
    public boolean attacking;
    /** Smoothed position for drawing (clients) and a walk-cycle clock. */
    public float rx, ry, rAim, walk;
    /** Seconds the zombie has just been hit (draws it flashing). */
    public float hurt;

    // ---- animation (host and clients)
    /** One of {@code Puppet.A_*}: idle, walk, run, attack, hit, stumble, fall, down, get up. */
    public int state = Puppet.A_IDLE;
    /** Seconds spent in {@link #state}. */
    public float stateT;
    /** Where the last blow pushed this zombie (a unit vector in the world), how hard (0..1+) and how many seconds ago. */
    public float hitDirX = 1f, hitDirY, hitK, hitT = 9f;
    /** The direction (unit vector in the world) a knocked-down zombie fell in: its head points that way while it lies. */
    public float fallDirX = -1f, fallDirY;
    /** Client: the walk blend (0 standing, 1 walking, above 1 running), eased every frame. */
    public float gait;
    /** Client: where the zombie was drawn last frame, to work out how fast it is moving. */
    public float lastRx, lastRy;
    /** Client: seconds during which a state set by an event (fall, stumble) is not overwritten by an older snapshot. */
    public float stateLock;
    /** Client: set when a death event arrives; the body is shown by a ragdoll instead. */
    public boolean dying;

    // ---- host-side behaviour
    public int target = -1;
    public float attackCd, wanderT, wanderX, wanderY, groanT, stuckT, lastX, lastY, stunT, farT, alertT;
    public boolean hasWander;
    /** Knockback velocity in world units per second; it dies away with friction. */
    public float vx, vy;
    /** Seconds until a knocked-down zombie starts getting up (counts the fall too). */
    public float downT;
    /** Seconds of an attack wind-up left (the claw lands when it reaches zero). */
    public float windT;
    /** Time since the last hit event was sent, to keep a stream of bullets from flooding the network. */
    public float eventCd;
    /** Seconds the zombie has been moving / standing still, for a steady walk-idle switch. */
    public float movedT, stillT;

    public static int maxHp(int type) {
        return type == BRUTE ? 220 : (type == RUNNER ? 45 : 70);
    }

    public static float speed(int type) {
        return type == BRUTE ? 46f : (type == RUNNER ? 104f : 54f);
    }

    public static int damage(int type) {
        return type == BRUTE ? 28 : (type == RUNNER ? 9 : 14);
    }

    /** How much a blow moves it: a brute shrugs off what sends a runner flying. */
    public static float mass(int type) {
        return type == BRUTE ? 2.6f : (type == RUNNER ? 0.85f : 1f);
    }

    /** Seconds from the start of an attack to the claw landing. */
    public static float windup(int type) {
        return type == BRUTE ? 0.55f : (type == RUNNER ? 0.22f : 0.38f);
    }

    /** Seconds the whole attack animation lasts (the strike is at its half-way point). */
    public static float attackLength(int type) {
        return windup(type) * 2f;
    }

    public static String typeName(int type) {
        return type == BRUTE ? "Brute" : (type == RUNNER ? "Runner" : "Walker");
    }

    /** True while the zombie is on the ground or on its way there / back up. */
    public boolean isDownish() {
        return state == Puppet.A_FALL || state == Puppet.A_DOWN || state == Puppet.A_GETUP;
    }

    /** Sets the animation state and restarts its clock when it changes. */
    public void setState(int s) {
        if (s != state) {
            state = s;
            stateT = 0f;
        }
    }
}
