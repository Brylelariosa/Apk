package com.hazardyard.game.core;

import java.util.ArrayDeque;
import java.util.Arrays;

/**
 * The Battleground island: 192 x 192 tiles (6144 x 6144 world units) of coast, beaches, meadows, forests and rocky
 * highlands crossed by a river with bridges, with towns, a harbour, a factory, a farm and a fenced military base
 * joined by roads, and farmhouses, cabins and sheds scattered in between. Every building has walls and a door you can
 * walk through, rooms, furniture and loot inside; a roof hides the inside until you step in (see TileMap#houses).
 *
 * <p>The island is generated, not drawn by hand: noise decides where the land ends and what grows where, then the
 * water, the roads, the settlements and the loot are laid over it in a fixed order from a fixed seed, so every device
 * builds the very same map. Only integer hashing and exactly rounded arithmetic are used (no platform-dependent math
 * functions in the shaping of the land), which keeps that true across phones.
 */
final class BattlegroundMap {
    static final int W = 192;
    static final int H = 192;
    private static final int SEED = 0x5EED;
    private static final int[] DX = {1, -1, 0, 0};
    private static final int[] DY = {0, 0, 1, -1};

    // building kinds
    private static final int COTTAGE = 0, HOUSE = 1, VILLA = 2, SHED = 3, BARN = 4, WAREHOUSE = 5, CHURCH = 6, SHOP = 7,
            BUNKER = 8, HANGAR = 9;
    /** Width and height of each kind for a door on its north or south side (swapped for east / west). */
    private static final int[][] DIM = {{7, 6}, {9, 7}, {12, 8}, {5, 5}, {13, 9}, {16, 10}, {9, 13}, {10, 7}, {9, 7}, {20, 12}};
    private static final int[] PARTITIONS = {0, 1, 2, 0, 0, 1, 0, 1, 1, 0};
    private static final int[] LOOT_SPOTS = {2, 3, 4, 1, 3, 5, 3, 3, 4, 6};
    /** Floors: wood for homes, tiles for shops and the church, concrete for sheds, barns, warehouses and bunkers. */
    private static final byte[] FLOOR = {TileMap.G_WOOD, TileMap.G_WOOD, TileMap.G_WOOD, TileMap.G_CONCRETE, TileMap.G_DIRT,
            TileMap.G_CONCRETE, TileMap.G_TILES, TileMap.G_TILES, TileMap.G_CONCRETE, TileMap.G_CONCRETE};
    private static final int SIDE_N = 0, SIDE_E = 1, SIDE_S = 2, SIDE_W = 3;

    /** The item letters a loot roll can give, and how likely each is in three tiers of place. */
    private static final String ITEMS = "klcmepXQDMGRAHUNVKPabhijfg";
    private static final int[][] WEIGHTS = {
            //k  l  c  m  e  p   X  Q  D  M  G  R  A  H  U  N  V  K  P   a   b   h   i  j  f  g
            {4, 4, 3, 3, 3, 1,  7, 6, 6, 8, 8, 2, 1, 3, 0, 0, 2, 0, 0, 14,  1, 18,  8, 5, 1, 0},     // farms and cabins
            {2, 2, 2, 2, 1, 1,  5, 5, 5, 7, 7, 10, 7, 5, 3, 1, 3, 1, 0, 13,  4, 14,  9, 5, 3, 1},    // towns
            {0, 1, 1, 1, 1, 0,  2, 3, 2, 4, 4, 10, 10, 6, 8, 7, 6, 6, 3,  8, 18, 14, 10, 3, 5, 4}};  // base, warehouses, church

    private final char[][] g = new char[H][W];
    private final byte[] ground = new byte[W * H];
    private final float[] moist = new float[W * H];
    private final float[] height = new float[W * H];
    /** Roads, building footprints and their surroundings: nothing is scattered or built over them. */
    private final boolean[] used = new boolean[W * H];
    private int[] houses = new int[5 * 160];
    private int houseCount;
    private final XorShift rng = new XorShift(0xB477);

    static TileMap build(int id) {
        BattlegroundMap m = new BattlegroundMap();
        m.generate();
        String[] rows = new String[H];
        for (int y = 0; y < H; y++) rows[y] = new String(m.g[y]);
        return TileMap.parse(id, rows, m.ground, Arrays.copyOf(m.houses, m.houseCount * 5));
    }

    private void generate() {
        terrain();
        // landmarks that must stand on dry land
        forceLand(92, 112, 46, 30);
        forceLand(100, 60, 26, 20);
        forceLand(140, 84, 28, 20);
        forceLand(60, 46, 28, 20);
        forceLand(140, 44, 34, 24);
        forceLand(38, 96, 24, 22);
        forceLand(130, 146, 26, 18);
        forceLand(160, 110, 16, 14);
        forceLand(44, 122, 16, 14);
        water();
        roads();
        base();
        old();
        northHamlet();
        riverside();
        farm();
        factory();
        harbour();
        village();
        hamlet(160, 110);
        hamlet(44, 122);
        countryside();
        scatter();
        spawns();
        settle();
    }

    // ------------------------------------------------------------------ noise (integers and exact float arithmetic only)

    private static int hash(int x, int y, int seed) {
        int h = x * 374761393 + y * 668265263 + seed * 1442695041;
        h = (h ^ (h >>> 13)) * 1274126177;
        return h ^ (h >>> 16);
    }

    private static float rnd01(int x, int y, int seed) {
        return (hash(x, y, seed) & 0xFFFFFF) / 16777216f;
    }

    private static float smooth(float t) {
        return t * t * (3f - 2f * t);
    }

    private static float vnoise(float x, float y, int seed) {
        int xi = (int) Math.floor(x);
        int yi = (int) Math.floor(y);
        float fx = smooth(x - xi);
        float fy = smooth(y - yi);
        float a = rnd01(xi, yi, seed);
        float b = rnd01(xi + 1, yi, seed);
        float c = rnd01(xi, yi + 1, seed);
        float d = rnd01(xi + 1, yi + 1, seed);
        float top = a + (b - a) * fx;
        float bot = c + (d - c) * fx;
        return top + (bot - top) * fy;
    }

    private static float fbm(float x, float y, int seed) {
        return 0.55f * vnoise(x / 34f, y / 34f, seed) + 0.30f * vnoise(x / 15f, y / 15f, seed + 7)
                + 0.15f * vnoise(x / 6.5f, y / 6.5f, seed + 13);
    }

    // ------------------------------------------------------------------ the land

    private void terrain() {
        for (int y = 0; y < H; y++) {
            for (int x = 0; x < W; x++) {
                int i = y * W + x;
                float dx = (x + 0.5f - W / 2f) / (W / 2f);
                float dy = (y + 0.5f - H / 2f) / (H / 2f);
                float r = (float) Math.sqrt(dx * dx + dy * dy);
                float coast = r + (fbm(x, y, SEED + 1) - 0.5f) * 0.46f;
                moist[i] = fbm(x * 0.9f + 40f, y * 0.9f - 25f, SEED + 2);
                height[i] = fbm(x * 1.1f - 60f, y * 1.1f + 15f, SEED + 3);
                boolean edge = x < 4 || y < 4 || x >= W - 4 || y >= H - 4;
                if (edge || coast > 0.88f) {
                    g[y][x] = '~';
                    ground[i] = TileMap.G_SAND;
                    continue;
                }
                g[y][x] = '.';
                ground[i] = baseGround(i, coast);
            }
        }
    }

    private byte baseGround(int i, float coast) {
        if (coast > 0.80f) return TileMap.G_SAND;
        if (height[i] > 0.66f && coast > 0.25f) return TileMap.G_ROCKY;
        if (moist[i] > 0.53f) return TileMap.G_FOREST;
        if (moist[i] < 0.38f) return TileMap.G_MEADOW;
        return TileMap.G_GRASS;
    }

    private void forceLand(int cx, int cy, int rx, int ry) {
        for (int y = cy - ry; y <= cy + ry; y++) {
            for (int x = cx - rx; x <= cx + rx; x++) {
                if (x < 5 || y < 5 || x >= W - 5 || y >= H - 5) continue;
                float dx = (x - cx) / (float) rx;
                float dy = (y - cy) / (float) ry;
                if (dx * dx + dy * dy > 1f) continue;
                int i = y * W + x;
                if (g[y][x] == '~') {
                    g[y][x] = '.';
                    ground[i] = TileMap.G_GRASS;
                }
                if (ground[i] == TileMap.G_ROCKY && !(cx == 38 && cy == 96)) ground[i] = TileMap.G_GRASS;
            }
        }
    }

    // ------------------------------------------------------------------ water: a river, two lakes

    private void water() {
        lake(42, 54, 9, 7, 11);
        lake(66, 134, 9, 8, 12);
        int[][] river = {{44, 54}, {62, 66}, {84, 77}, {106, 82}, {126, 88}, {146, 99}, {168, 103}, {192, 108}};
        for (int s = 0; s + 1 < river.length; s++) {
            int x0 = river[s][0], y0 = river[s][1], x1 = river[s + 1][0], y1 = river[s + 1][1];
            int steps = Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0)) * 2;
            float len = (float) Math.sqrt((x1 - x0) * (x1 - x0) + (y1 - y0) * (y1 - y0));
            float nx = -(y1 - y0) / len;
            float ny = (x1 - x0) / len;
            for (int k = 0; k <= steps; k++) {
                float t = k / (float) steps;
                float wob = (float) StrictMath.sin((s + t) * 2.3f) * 4.2f + (vnoise(s * 9f + t * 9f, 3f, SEED + 21) - 0.5f) * 6f;
                float px = x0 + (x1 - x0) * t + nx * wob;
                float py = y0 + (y1 - y0) * t + ny * wob;
                float wide = 1.7f + 0.6f * vnoise(s * 5f + t * 5f, 8f, SEED + 22);
                carve(px, py, wide);
            }
        }
    }

    private void carve(float px, float py, float r) {
        int x0 = (int) Math.floor(px - r), x1 = (int) Math.ceil(px + r);
        int y0 = (int) Math.floor(py - r), y1 = (int) Math.ceil(py + r);
        for (int y = y0; y <= y1; y++) {
            for (int x = x0; x <= x1; x++) {
                if (x < 5 || y < 5 || x >= W - 5 || y >= H - 5) continue;
                float dx = x + 0.5f - px;
                float dy = y + 0.5f - py;
                if (dx * dx + dy * dy <= r * r) {
                    g[y][x] = '~';
                    ground[y * W + x] = TileMap.G_SAND;
                }
            }
        }
    }

    private void lake(int cx, int cy, int rx, int ry, int salt) {
        for (int y = cy - ry - 3; y <= cy + ry + 3; y++) {
            for (int x = cx - rx - 3; x <= cx + rx + 3; x++) {
                if (x < 5 || y < 5 || x >= W - 5 || y >= H - 5) continue;
                float dx = (x - cx) / (float) rx;
                float dy = (y - cy) / (float) ry;
                float d = dx * dx + dy * dy + (vnoise(x / 5f, y / 5f, SEED + salt) - 0.5f) * 0.7f;
                if (d < 1f) {
                    g[y][x] = '~';
                    ground[y * W + x] = TileMap.G_SAND;
                } else if (d < 1.28f && g[y][x] == '.') {
                    ground[y * W + x] = TileMap.G_SAND;
                }
            }
        }
    }

    // ------------------------------------------------------------------ roads

    private void roads() {
        road(92, 112, 100, 60);
        road(92, 112, 84, 158);
        road(92, 112, 130, 146);
        road(92, 112, 38, 96);
        road(92, 112, 140, 112);
        road(140, 112, 140, 84);
        road(140, 84, 140, 44);
        road(100, 60, 140, 60);
        road(100, 60, 60, 46);
        road(38, 96, 60, 46);
        road(130, 146, 160, 110);
        road(38, 96, 44, 122);
    }

    /** A Z-shaped road, three tiles wide, between two points; over water it becomes a bridge. */
    private void road(int x0, int y0, int x1, int y1) {
        int mx = x0 + (x1 - x0) / 2;
        hline(y0, x0, mx);
        vline(mx, y0, y1);
        hline(y1, mx, x1);
    }

    private void hline(int y, int xa, int xb) {
        for (int x = Math.min(xa, xb); x <= Math.max(xa, xb); x++) {
            for (int k = -1; k <= 1; k++) roadTile(x, y + k, k == 0 ? TileMap.G_ROAD_H : TileMap.G_ROAD);
        }
    }

    private void vline(int x, int ya, int yb) {
        for (int y = Math.min(ya, yb); y <= Math.max(ya, yb); y++) {
            for (int k = -1; k <= 1; k++) roadTile(x + k, y, k == 0 ? TileMap.G_ROAD_V : TileMap.G_ROAD);
        }
    }

    private void roadTile(int x, int y, byte kind) {
        if (x < 5 || y < 5 || x >= W - 5 || y >= H - 5) return;
        int i = y * W + x;
        if (g[y][x] == '~') {
            g[y][x] = '.';
            ground[i] = TileMap.G_BRIDGE;
        } else {
            g[y][x] = '.';
            if (ground[i] != TileMap.G_BRIDGE) ground[i] = kind;
        }
        used[i] = true;
    }

    // ------------------------------------------------------------------ settlements

    private void old() {
        build(CHURCH, 76, 118, SIDE_N, 3);
        build(WAREHOUSE, 56, 118, SIDE_N, 3);
        build(SHOP, 104, 98, SIDE_S, 2);
        plaza(92, 112, 5);
        street(92, 112, 40, 26, 2, new int[] {HOUSE, HOUSE, COTTAGE, SHOP, VILLA, COTTAGE});
    }

    private void northHamlet() {
        street(100, 60, 24, 14, 2, new int[] {COTTAGE, HOUSE, COTTAGE, SHED});
    }

    private void riverside() {
        street(140, 84, 24, 18, 2, new int[] {HOUSE, COTTAGE, VILLA, COTTAGE, SHOP});
    }

    private void village() {
        street(130, 146, 22, 14, 2, new int[] {COTTAGE, HOUSE, COTTAGE, COTTAGE, SHED});
    }

    private void hamlet(int cx, int cy) {
        street(cx, cy, 14, 10, 1, new int[] {COTTAGE, SHED, COTTAGE, HOUSE});
    }

    private void farm() {
        // three farmsteads around fenced fields, west of the north lake
        build(BARN, 46, 30, SIDE_S, 1);
        build(HOUSE, 66, 30, SIDE_S, 1);
        build(SHED, 84, 33, SIDE_S, 1);
        field(48, 48, 22, 12);
        field(76, 50, 18, 12);
        field(54, 66, 20, 10);
        build(BARN, 74, 66, SIDE_N, 1);
        build(COTTAGE, 36, 40, SIDE_E, 1);
    }

    private void field(int x0, int y0, int w, int h) {
        for (int y = y0; y < y0 + h; y++) {
            for (int x = x0; x < x0 + w; x++) {
                int i = y * W + x;
                if (x < 5 || y < 5 || x >= W - 5 || y >= H - 5 || g[y][x] != '.' || used[i]) continue;
                ground[i] = TileMap.G_FIELD;
                used[i] = true;
            }
        }
        fence(x0 - 1, y0 - 1, x0 + w, y0 + h, 3);
    }

    /** A fence round a rectangle with a gap in the middle of each side. */
    private void fence(int x0, int y0, int x1, int y1, int gap) {
        int mx = (x0 + x1) / 2;
        int my = (y0 + y1) / 2;
        for (int x = x0; x <= x1; x++) {
            if (Math.abs(x - mx) > gap / 2) {
                putFence(x, y0);
                putFence(x, y1);
            }
        }
        for (int y = y0; y <= y1; y++) {
            if (Math.abs(y - my) > gap / 2) {
                putFence(x0, y);
                putFence(x1, y);
            }
        }
    }

    private void putFence(int x, int y) {
        if (x < 5 || y < 5 || x >= W - 5 || y >= H - 5) return;
        int i = y * W + x;
        if (g[y][x] != '.' || used[i] || ground[i] == TileMap.G_ROAD || ground[i] == TileMap.G_ROAD_H || ground[i] == TileMap.G_ROAD_V) return;
        g[y][x] = '+';
        used[i] = true;
    }

    /** A military compound in the north-east: a wall with two gates, bunkers, a hangar, tanks and the best loot. */
    private void base() {
        int x0 = 118, y0 = 30, x1 = 164, y1 = 58;
        for (int y = y0; y <= y1; y++) {
            for (int x = x0; x <= x1; x++) {
                int i = y * W + x;
                g[y][x] = '.';
                if (ground[i] != TileMap.G_ROAD && ground[i] != TileMap.G_ROAD_H && ground[i] != TileMap.G_ROAD_V) ground[i] = TileMap.G_CONCRETE;
            }
        }
        for (int x = x0; x <= x1; x++) {
            wallTile(x, y0);
            wallTile(x, y1);
        }
        for (int y = y0; y <= y1; y++) {
            wallTile(x0, y);
            wallTile(x1, y);
        }
        // gates: south (to the road) and west
        for (int k = -2; k <= 2; k++) {
            openTile(141 + k, y1);
            openTile(x0, 44 + k);
        }
        for (int k = -2; k <= 2; k++) {
            for (int dy = 1; dy <= 3; dy++) openTile(141 + k, y1 + dy);
            for (int dx = 1; dx <= 3; dx++) openTile(x0 - dx, 44 + k);
        }
        build(WAREHOUSE, 122, 33, SIDE_S, 3);
        build(HANGAR, 142, 33, SIDE_S, 3);
        build(BUNKER, 122, 49, SIDE_N, 3);
        build(BUNKER, 148, 48, SIDE_W, 3);
        // tanks and crates in the yard
        tank(126, 44);
        tank(129, 44);
        tank(132, 44);
        crates(144, 47, 3, 1);
        crates(158, 50, 3, 2);
        crates(134, 52, 3, 2);
        // watch towers in the corners
        for (int[] t : new int[][] {{x0 + 2, y0 + 2}, {x1 - 2, y0 + 2}, {x0 + 2, y1 - 2}, {x1 - 2, y1 - 2}}) {
            if (g[t[1]][t[0]] == '.') g[t[1]][t[0]] = 'O';
        }
        for (int k = 0; k < 8; k++) yardLoot(x0 + 6, y0 + 6, x1 - 6, y1 - 6, 3);
        // the best things on the island always lie in the compound
        for (char best : new char[] {'P', 'K', 'N', 'N', 'U', 'b', 'b', 'b'}) yardSpecific(best, x0 + 6, y0 + 6, x1 - 6, y1 - 6);
        for (int y = y0; y <= y1; y++) for (int x = x0; x <= x1; x++) used[y * W + x] = true;
    }

    private void wallTile(int x, int y) {
        g[y][x] = '#';
        used[y * W + x] = true;
    }

    private void openTile(int x, int y) {
        if (x < 5 || y < 5 || x >= W - 5 || y >= H - 5) return;
        g[y][x] = '.';
        int i = y * W + x;
        used[i] = true;
        if (ground[i] != TileMap.G_ROAD && ground[i] != TileMap.G_ROAD_H && ground[i] != TileMap.G_ROAD_V) ground[i] = TileMap.G_CONCRETE;
    }

    private void tank(int x, int y) {
        for (int dy = 0; dy < 2; dy++) {
            for (int dx = 0; dx < 2; dx++) {
                if (g[y + dy][x + dx] != '.') return;
            }
        }
        for (int dy = 0; dy < 2; dy++) for (int dx = 0; dx < 2; dx++) g[y + dy][x + dx] = 'T';
    }

    private void crates(int x, int y, int w, int h) {
        for (int yy = y; yy < y + h; yy++) {
            for (int xx = x; xx < x + w; xx++) {
                if (g[yy][xx] == '.') g[yy][xx] = 'C';
            }
        }
    }

    private void yardLoot(int x0, int y0, int x1, int y1, int tier) {
        for (int tries = 0; tries < 30; tries++) {
            int x = x0 + rng.nextInt(x1 - x0);
            int y = y0 + rng.nextInt(y1 - y0);
            if (g[y][x] == '.' && freeAround(x, y)) {
                g[y][x] = loot(tier);
                return;
            }
        }
    }

    private void yardSpecific(char item, int x0, int y0, int x1, int y1) {
        for (int tries = 0; tries < 60; tries++) {
            int x = x0 + rng.nextInt(x1 - x0);
            int y = y0 + rng.nextInt(y1 - y0);
            if (g[y][x] == '.' && freeAround(x, y)) {
                g[y][x] = item;
                return;
            }
        }
    }

    private boolean freeAround(int x, int y) {
        for (int dy = -1; dy <= 1; dy++) {
            for (int dx = -1; dx <= 1; dx++) {
                char c = g[y + dy][x + dx];
                if (c != '.') return false;
            }
        }
        return true;
    }

    /** Factory in the west: warehouses, a tank farm and chimneys on rocky ground. */
    private void factory() {
        build(WAREHOUSE, 22, 82, SIDE_E, 3);
        build(WAREHOUSE, 22, 104, SIDE_E, 3);
        build(BARN, 46, 80, SIDE_W, 2);
        for (int k = 0; k < 4; k++) tank(48 + k * 3, 94);
        for (int k = 0; k < 3; k++) tank(48 + k * 3, 98);
        crates(52, 104, 4, 2);
        crates(44, 88, 2, 3);
        for (int[] t : new int[][] {{50, 90}, {58, 90}, {50, 102}}) if (g[t[1]][t[0]] == '.') g[t[1]][t[0]] = 'O';
    }

    /** Harbour on the south coast: a pier into the sea, container stacks and warehouses. */
    private void harbour() {
        forceLand(84, 160, 28, 14);
        build(WAREHOUSE, 66, 152, SIDE_S, 3);
        build(WAREHOUSE, 92, 152, SIDE_S, 3);
        build(COTTAGE, 100, 140, SIDE_S, 2);
        // concrete apron
        for (int y = 150; y <= 170; y++) {
            for (int x = 62; x <= 108; x++) {
                int i = y * W + x;
                if (g[y][x] != '.' || used[i]) continue;
                ground[i] = TileMap.G_CONCRETE;
                used[i] = true;
            }
        }
        // the pier: planks running south into the water
        for (int y = 160; y <= 178; y++) {
            for (int x = 82; x <= 87; x++) {
                int i = y * W + x;
                if (g[y][x] == '#' || g[y][x] == 'C') continue;
                g[y][x] = '.';
                ground[i] = y >= 168 ? TileMap.G_BRIDGE : ground[i];
                used[i] = true;
            }
        }
        for (int k = 0; k < 4; k++) crates(68 + k * 5, 165, 3, 2);
        for (int k = 0; k < 3; k++) crates(94 + k * 4, 165, 2, 2);
        crates(77, 172, 2, 2);
        crates(89, 172, 2, 2);
    }

    // ------------------------------------------------------------------ towns, streets, buildings

    private void plaza(int cx, int cy, int r) {
        for (int y = cy - r; y <= cy + r; y++) {
            for (int x = cx - r; x <= cx + r; x++) {
                int i = y * W + x;
                ground[i] = TileMap.G_PAVED;
                g[y][x] = '.';
                used[i] = true;
            }
        }
        g[cy][cx] = 'O';
    }

    /**
     * Rows of buildings facing the main street (a horizontal one through the centre) and a cross street (vertical).
     * The streets themselves are the roads laid before.
     */
    private void street(int cx, int cy, int halfW, int halfH, int tier, int[] kinds) {
        // along the horizontal road: a row on each side
        for (int side = 0; side < 2; side++) {
            int x = cx - halfW;
            while (x < cx + halfW) {
                int kind = kinds[rng.nextInt(kinds.length)];
                int w = DIM[kind][0];
                int h = DIM[kind][1];
                boolean north = side == 0;
                int y0 = north ? cy - 3 - h + 1 : cy + 3;
                if (build(kind, x, y0, north ? SIDE_S : SIDE_N, tier)) x += w + 1 + rng.nextInt(3);
                else x += 3;
            }
        }
        // along the vertical road
        for (int side = 0; side < 2; side++) {
            int y = cy - halfH;
            while (y < cy + halfH) {
                int kind = kinds[rng.nextInt(kinds.length)];
                int w = DIM[kind][1];      // turned: the door is on the east or west side
                int h = DIM[kind][0];
                boolean west = side == 0;
                int x0 = west ? cx - 3 - w + 1 : cx + 3;
                if (build(kind, x0, y, west ? SIDE_E : SIDE_W, tier)) y += h + 1 + rng.nextInt(3);
                else y += 3;
            }
        }
    }

    /**
     * A building with walls, a door on one side, rooms, furniture and loot. Returns false (and builds nothing) when it
     * does not fit on free dry land. {@code (x0, y0)} is the top-left corner; the size follows from the kind and the
     * side the door is on.
     */
    private boolean build(int kind, int x0, int y0, int doorSide, int tier) {
        boolean sideways = doorSide == SIDE_E || doorSide == SIDE_W;
        int w = sideways ? DIM[kind][1] : DIM[kind][0];
        int h = sideways ? DIM[kind][0] : DIM[kind][1];
        int x1 = x0 + w - 1;
        int y1 = y0 + h - 1;
        if (x0 < 8 || y0 < 8 || x1 >= W - 8 || y1 >= H - 8 || houseCount >= houses.length / 5) return false;
        for (int y = y0 - 2; y <= y1 + 2; y++) {
            for (int x = x0 - 2; x <= x1 + 2; x++) {
                if (x < 5 || y < 5 || x >= W - 5 || y >= H - 5) return false;
                int i = y * W + x;
                char c = g[y][x];
                boolean inside = x >= x0 && x <= x1 && y >= y0 && y <= y1;
                if (c == '~' || c == '#' || c == 'T' || c == 'O' || c == '+') return false;
                if (inside && used[i]) return false;
                if (!inside && used[i] && ground[i] != TileMap.G_PAVED) {
                    // roads may run right past the door but never through the building's rectangle
                    boolean ring = x >= x0 - 1 && x <= x1 + 1 && y >= y0 - 1 && y <= y1 + 1;
                    if (ring && ground[i] != TileMap.G_ROAD && ground[i] != TileMap.G_ROAD_H && ground[i] != TileMap.G_ROAD_V
                            && ground[i] != TileMap.G_CONCRETE) return false;
                }
            }
        }
        byte floor = FLOOR[kind];
        // sidewalk / yard ring
        for (int y = y0 - 1; y <= y1 + 1; y++) {
            for (int x = x0 - 1; x <= x1 + 1; x++) {
                int i = y * W + x;
                if (g[y][x] == 't' || g[y][x] == 'r') g[y][x] = '.';
                if (ground[i] != TileMap.G_ROAD && ground[i] != TileMap.G_ROAD_H && ground[i] != TileMap.G_ROAD_V
                        && ground[i] != TileMap.G_CONCRETE && ground[i] != TileMap.G_BRIDGE) {
                    ground[i] = kind == BARN || kind == SHED ? TileMap.G_DIRT : TileMap.G_PAVED;
                }
                used[i] = true;
            }
        }
        for (int y = y0; y <= y1; y++) {
            for (int x = x0; x <= x1; x++) {
                int i = y * W + x;
                boolean wall = x == x0 || x == x1 || y == y0 || y == y1;
                g[y][x] = wall ? '#' : '.';
                ground[i] = floor;
                used[i] = true;
            }
        }
        // the door, two tiles wide (three on big buildings), not at a corner
        int doorW = (kind == BARN || kind == WAREHOUSE || kind == HANGAR) ? 3 : 2;
        int dLo, dHi;     // door tiles along the wall
        if (sideways) {
            int span = h - 2 - doorW;
            dLo = y0 + 1 + (span > 0 ? rng.nextInt(span + 1) : 0);
        } else {
            int span = w - 2 - doorW;
            dLo = x0 + 1 + (span > 0 ? rng.nextInt(span + 1) : 0);
        }
        dHi = dLo + doorW - 1;
        for (int k = dLo; k <= dHi; k++) {
            switch (doorSide) {
                case SIDE_N: g[y0][k] = '.'; break;
                case SIDE_S: g[y1][k] = '.'; break;
                case SIDE_W: g[k][x0] = '.'; break;
                default: g[k][x1] = '.'; break;
            }
        }
        // a back door on the big halls
        if (kind == WAREHOUSE || kind == HANGAR || kind == BARN) {
            int mid = sideways ? (y0 + y1) / 2 : (x0 + x1) / 2;
            for (int k = mid - 1; k <= mid + 1; k++) {
                switch (doorSide) {
                    case SIDE_N: g[y1][k] = '.'; break;
                    case SIDE_S: g[y0][k] = '.'; break;
                    case SIDE_W: g[k][x1] = '.'; break;
                    default: g[k][x0] = '.'; break;
                }
            }
        }
        // partitions with a two-tile doorway each
        int parts = PARTITIONS[kind];
        for (int p = 1; p <= parts; p++) {
            if (sideways) {
                int py = y0 + (h * p) / (parts + 1);
                if (py <= y0 + 1 || py >= y1 - 1) continue;
                for (int x = x0 + 1; x < x1; x++) g[py][x] = '#';
                int gx = x0 + 2 + rng.nextInt(Math.max(1, w - 6));
                g[py][gx] = '.';
                g[py][gx + 1] = '.';
            } else {
                int px = x0 + (w * p) / (parts + 1);
                if (px <= x0 + 1 || px >= x1 - 1) continue;
                for (int y = y0 + 1; y < y1; y++) g[y][px] = '#';
                int gy = y0 + 2 + rng.nextInt(Math.max(1, h - 6));
                g[gy][px] = '.';
                g[gy + 1][px] = '.';
            }
        }
        if (kind == CHURCH) {
            for (int y = y0 + 3; y < y1 - 2; y += 3) {
                g[y][x0 + 2] = 'O';
                g[y][x1 - 2] = 'O';
            }
        }
        // furniture along the walls, loot on the floor
        for (int y = y0 + 1; y < y1; y++) {
            for (int x = x0 + 1; x < x1; x++) {
                if (g[y][x] != '.' || nearGap(x, y)) continue;
                if (!wallNeighbour(x, y)) continue;
                if (rnd01(x, y, SEED + 31) < (kind == WAREHOUSE || kind == HANGAR ? 0.20f : (kind == BARN ? 0.12f : 0.07f))) g[y][x] = 'C';
            }
        }
        int spots = LOOT_SPOTS[kind];
        for (int n = 0; n < spots; n++) {
            for (int tries = 0; tries < 40; tries++) {
                int x = x0 + 1 + rng.nextInt(w - 2);
                int y = y0 + 1 + rng.nextInt(h - 2);
                if (g[y][x] == '.' && !nearGap(x, y) && !adjacentToLoot(x, y)) {
                    g[y][x] = loot(tier);
                    break;
                }
            }
        }
        if (houseCount * 5 + 5 > houses.length) houses = Arrays.copyOf(houses, houses.length * 2);
        int style = (hash(x0, y0, SEED + 41) & 0x7FFF) % 6;
        houses[houseCount * 5] = x0;
        houses[houseCount * 5 + 1] = y0;
        houses[houseCount * 5 + 2] = x1;
        houses[houseCount * 5 + 3] = y1;
        houses[houseCount * 5 + 4] = style + (kind == WAREHOUSE || kind == HANGAR || kind == BARN || kind == BUNKER ? 8 : 0);
        houseCount++;
        return true;
    }

    private boolean wallNeighbour(int x, int y) {
        for (int d = 0; d < 4; d++) if (g[y + DY[d]][x + DX[d]] == '#') return true;
        return false;
    }

    /** True within two tiles of an opening in a wall (a door or a doorway), so furniture and loot never block the way. */
    private boolean nearGap(int x, int y) {
        for (int dy = -2; dy <= 2; dy++) {
            for (int dx = -2; dx <= 2; dx++) {
                int xx = x + dx, yy = y + dy;
                if (xx < 0 || yy < 0 || xx >= W || yy >= H || g[yy][xx] != '.') continue;
                // a floor tile with walls on two opposite sides is a doorway
                boolean ns = yy > 0 && yy < H - 1 && g[yy - 1][xx] == '#' && g[yy + 1][xx] == '#';
                boolean ew = xx > 0 && xx < W - 1 && g[yy][xx - 1] == '#' && g[yy][xx + 1] == '#';
                if (ns || ew) return true;
            }
        }
        return false;
    }

    private boolean adjacentToLoot(int x, int y) {
        for (int dy = -1; dy <= 1; dy++) {
            for (int dx = -1; dx <= 1; dx++) if (ITEMS.indexOf(g[y + dy][x + dx]) >= 0) return true;
        }
        return false;
    }

    private char loot(int tier) {
        int[] w = WEIGHTS[Math.max(0, Math.min(2, tier - 1))];
        int total = 0;
        for (int v : w) total += v;
        int roll = rng.nextInt(total);
        for (int i = 0; i < w.length; i++) {
            roll -= w[i];
            if (roll < 0) return ITEMS.charAt(i);
        }
        return 'h';
    }

    // ------------------------------------------------------------------ the countryside

    private void countryside() {
        int placed = 0;
        for (int tries = 0; tries < 900 && placed < 46; tries++) {
            int x = 14 + rng.nextInt(W - 28);
            int y = 14 + rng.nextInt(H - 28);
            int kind;
            int roll = rng.nextInt(10);
            if (roll < 4) kind = COTTAGE;
            else if (roll < 6) kind = SHED;
            else if (roll < 8) kind = HOUSE;
            else if (roll < 9) kind = BARN;
            else kind = VILLA;
            if (build(kind, x, y, rng.nextInt(4), 1)) placed++;
        }
        // a few supply caches in the open
        for (int n = 0; n < 14; n++) {
            for (int tries = 0; tries < 50; tries++) {
                int x = 12 + rng.nextInt(W - 24);
                int y = 12 + rng.nextInt(H - 24);
                if (g[y][x] == '.' && !used[y * W + x] && freeAround(x, y) && ground[y * W + x] != TileMap.G_SAND) {
                    g[y][x] = rng.nextInt(3) == 0 ? 'b' : (rng.nextInt(2) == 0 ? 'a' : 'h');
                    break;
                }
            }
        }
    }

    /** Trees, boulders: thick in the forest, a few on the meadows and the rocky ground. Never on roads or around buildings. */
    private void scatter() {
        for (int y = 6; y < H - 6; y++) {
            for (int x = 6; x < W - 6; x++) {
                int i = y * W + x;
                if (g[y][x] != '.' || used[i]) continue;
                float r = rnd01(x, y, SEED + 51);
                byte gr = ground[i];
                if (gr == TileMap.G_FOREST) {
                    float p = 0.20f + 0.20f * Math.min(1f, (moist[i] - 0.53f) / 0.2f);
                    if (r < p) g[y][x] = 't';
                } else if (gr == TileMap.G_GRASS) {
                    if (r < 0.030f) g[y][x] = 't';
                    else if (r > 0.992f) g[y][x] = 'r';
                } else if (gr == TileMap.G_MEADOW) {
                    if (r < 0.010f) g[y][x] = 't';
                } else if (gr == TileMap.G_ROCKY) {
                    if (r < 0.075f) g[y][x] = 'r';
                    else if (r > 0.985f) g[y][x] = 't';
                } else if (gr == TileMap.G_SAND) {
                    if (r > 0.994f) g[y][x] = 'r';
                }
            }
        }
    }

    /** Spawn points on open ground, one per cell of a coarse grid. */
    private void spawns() {
        int cell = 16;
        for (int cy = 0; cy < H / cell; cy++) {
            for (int cx = 0; cx < W / cell; cx++) {
                for (int tries = 0; tries < 60; tries++) {
                    int x = cx * cell + 2 + rng.nextInt(cell - 4);
                    int y = cy * cell + 2 + rng.nextInt(cell - 4);
                    if (x < 8 || y < 8 || x >= W - 8 || y >= H - 8) continue;
                    if (g[y][x] != '.' || ground[y * W + x] == TileMap.G_SAND || !wideOpen(x, y, 3)) continue;
                    g[y][x] = 'S';
                    break;
                }
            }
        }
    }

    private boolean wideOpen(int x, int y, int r) {
        for (int dy = -r; dy <= r; dy++) {
            for (int dx = -r; dx <= r; dx++) {
                char c = g[y + dy][x + dx];
                if (c != '.') return false;
                if (used[(y + dy) * W + x + dx] && houseTileSolid(x + dx, y + dy)) return false;
            }
        }
        return true;
    }

    private boolean houseTileSolid(int x, int y) {
        return g[y][x] != '.';
    }

    // ------------------------------------------------------------------ keep one connected playground

    private boolean floorAt(int x, int y) {
        if (x < 0 || y < 0 || x >= W || y >= H) return false;
        char c = g[y][x];
        return c == '.' || c == 'S' || ITEMS.indexOf(c) >= 0;
    }

    /**
     * Everything that cannot be reached from the biggest stretch of open ground is filled in (with trees outdoors, with
     * crates indoors) so nobody can be spawned or locked into a pocket the others cannot get to.
     */
    private void settle() {
        int[] label = new int[W * H];
        int best = 0, bestSize = 0, regions = 0;
        ArrayDeque<Integer> q = new ArrayDeque<>();
        for (int y = 0; y < H; y++) {
            for (int x = 0; x < W; x++) {
                if (!floorAt(x, y) || label[y * W + x] != 0) continue;
                regions++;
                int size = 0;
                label[y * W + x] = regions;
                q.add(y * W + x);
                while (!q.isEmpty()) {
                    int c = q.poll();
                    size++;
                    int cx = c % W, cy = c / W;
                    for (int d = 0; d < 4; d++) {
                        int nx = cx + DX[d], ny = cy + DY[d];
                        if (floorAt(nx, ny) && label[ny * W + nx] == 0) {
                            label[ny * W + nx] = regions;
                            q.add(ny * W + nx);
                        }
                    }
                }
                if (size > bestSize) {
                    bestSize = size;
                    best = regions;
                }
            }
        }
        for (int y = 0; y < H; y++) {
            for (int x = 0; x < W; x++) {
                if (floorAt(x, y) && label[y * W + x] != best) g[y][x] = isHouseTile(x, y) ? 'C' : 't';
            }
        }
    }

    private boolean isHouseTile(int x, int y) {
        for (int k = 0; k < houseCount; k++) {
            if (x >= houses[k * 5] && x <= houses[k * 5 + 2] && y >= houses[k * 5 + 1] && y <= houses[k * 5 + 3]) return true;
        }
        return false;
    }
}
