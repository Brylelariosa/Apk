package com.hazardyard.game.render.model;

import com.hazardyard.game.core.MeleeProfile;
import com.hazardyard.game.core.WeaponDef;

/**
 * The poses of a soldier fighting hand to hand. Every attack is a short run of key poses (wind-up, impact, follow-through)
 * between the guard the weapon is held in; the hand paths are arcs round the body (polar coordinates), so a swing sweeps
 * and a stab drives straight out. From the pose the rig works out where both hands are, bends both arms to reach them
 * (two-bone IK from the fixed shoulders), and tells the renderer how to tilt, turn and place the weapon so the grip sits in
 * the hand: the arms are not part of any mesh, they are drawn wherever the hands are.
 *
 * <p>Body frame: x forward, y to the right, z up, angles in radians (the tables are written in degrees). Pure maths, no
 * allocation after construction; one instance per renderer.
 */
public final class MeleeRig {
    // ---- outputs of the last pose()
    /** Hands (body frame, before the forward lunge), already pulled in to what the arms can reach. */
    public float rx, ry, rz, lx, ly, lz;
    /** Elbows. */
    public float erx, ery, erz, elx, ely, elz;
    /** The weapon turned about its grip: yaw (relative to the body), pitch (+ tips the tip down), roll. */
    public float yaw, pitch, roll;
    /** Body turn (radians), body shift forward (units) and the stance (+1: front foot forward). */
    public float twist, lunge, step;
    /** Where to put the weapon mesh (offsets of its group) so the grip lies in the right hand. */
    public float gunOffX, gunOffY, gunOffZ;
    /** The weapon-local grip the mesh is turned about. */
    public float pivX, pivY, pivZ;
    public boolean hasWeapon, twoHanded;

    // ---- arm geometry (a little longer than the bare upper arms so a stab can reach)
    private static final float UPPER = 5.6f, FORE = 9.8f;
    private static final float SX = SoldierModel.SHOULDER_X, SY = SoldierModel.SHOULDER_Y, SZ = SoldierModel.SHOULDER_Z;

    private static final float D2R = (float) Math.PI / 180f;
    private static final int N = 13;
    // key fields
    private static final int A = 0, R = 1, Z = 2, PSI = 3, TH = 4, PHI = 5, TW = 6, LG = 7, LA = 8, LR = 9, LZ = 10, STEP = 11, KICK = 12;

    private static final float TW_SPIN_END = 360f;

    /** What each melee weapon is like to hold. */
    private static final class Spec {
        float grip, leftGrip, tipX, tipY, midX, midY, bias, heavy;
        float[] guard;
    }

    private static final Spec[] SPECS = new Spec[WeaponDef.ALL.length];

    private static float[] k(float a, float r, float z, float psi, float th, float phi, float tw, float lg, float la, float lr,
                             float lz, float step, float kick) {
        return new float[] {a, r, z, psi, th, phi, tw, lg, la, lr, lz, step, kick};
    }

    private static Spec spec(float grip, float leftGrip, float tipX, float tipY, float midX, float midY, float bias, float heavy,
                             float[] guard) {
        Spec s = new Spec();
        s.grip = grip;
        s.leftGrip = leftGrip;
        s.tipX = tipX;
        s.tipY = tipY;
        s.midX = midX;
        s.midY = midY;
        s.bias = bias;
        s.heavy = heavy;
        s.guard = guard;
        return s;
    }

    static {
        //                         grip  left  tipX   tipY  midX  midY  bias heavy  guard: a   r     z    psi   th    phi   tw   lg   la    lr   lz  step kick
        SPECS[WeaponDef.KNIFE]   = spec(10.2f, -1f, 23.0f, 0.8f, 15.0f, 0.8f, 72f, 0.85f, k(16, 9.5f, 14.6f, 6, -10, 0, 8, 0, -38, 7.5f, 15.4f, 0, 0));
        SPECS[WeaponDef.MACHETE] = spec(10.5f, -1f, 32.5f, 0.8f, 20.0f, 0.8f, 76f, 0.95f, k(16, 9.6f, 15.0f, 8, -22, 0, 8, 0, -38, 7.5f, 15.4f, 0, 0));
        SPECS[WeaponDef.BAT]     = spec(10.0f, 15.5f, 35.4f, 0.8f, 22.0f, 0.8f, 0f, 1.0f, k(24, 7.0f, 19.0f, 8, -58, 0, 6, 0, 0, 0, 0, 0, 0));
        SPECS[WeaponDef.CROWBAR] = spec(11.0f, 17.0f, 36.0f, 3.2f, 24.0f, 0.8f, 0f, 1.0f, k(24, 7.0f, 18.0f, 8, -48, 0, 6, 0, 0, 0, 0, 0, 0));
        SPECS[WeaponDef.AXE]     = spec(10.0f, 16.0f, 32.5f, 6.4f, 29.0f, 0.8f, 0f, 1.15f, k(24, 7.0f, 18.6f, 8, -62, 0, 6, 0, 0, 0, 0, 0, 0));
        SPECS[WeaponDef.PICKAXE] = spec(10.0f, 16.0f, 30.3f, 8.2f, 26.0f, 0.8f, 0f, 1.0f, k(24, 7.0f, 18.6f, 8, -62, 0, 6, 0, 0, 0, 0, 0, 0));
        SPECS[WeaponDef.FISTS]   = spec(0f, -1f, 2.0f, 0f, 0f, 0f, 0f, 1.0f, k(16, 10.0f, 17.0f, 0, 0, 0, 4, 0, -14, 10.5f, 17.2f, 0, 0));
    }

    // key poses {wind-up, impact, follow-through} for each kind of attack, right-handed
    private static final float[][][] KEYS = new float[16][][];

    static {
        KEYS[MeleeProfile.THRUST] = new float[][] {
                k(28, 4.0f, 14.6f, 14, -4, 0, 24, -1.5f, -48, 5.0f, 15.5f, -0.3f, 0),
                k(-2, 14.2f, 15.2f, -2, 0, 0, -16, 4.5f, -56, 6.0f, 15.5f, 1, 0),
                k(0, 12.8f, 15.0f, 0, 2, 0, -10, 5.5f, -50, 6.5f, 15.5f, 1, 0)};
        KEYS[MeleeProfile.LUNGE] = new float[][] {
                k(34, 3.2f, 14.0f, 16, -6, 0, 38, -2.5f, -52, 4.5f, 15.0f, -0.6f, 0),
                k(-4, 15.0f, 15.6f, -4, -2, 0, -26, 9.0f, -62, 6.0f, 16.0f, 1, 0),
                k(-2, 13.6f, 15.2f, -2, 0, 0, -18, 10.0f, -56, 6.5f, 16.0f, 1, 0)};
        KEYS[MeleeProfile.SWING_LR] = new float[][] {
                k(-84, 10.5f, 16.0f, -90, -6, 0, -46, -1.0f, -70, 8.0f, 16.0f, -0.4f, 0),
                k(4, 13.4f, 15.6f, 6, 0, 0, 2, 2.5f, -64, 8.0f, 16.0f, 0.7f, 0),
                k(80, 10.0f, 15.0f, 88, 4, 0, 44, 1.0f, -44, 8.0f, 16.0f, 0.4f, 0)};
        KEYS[MeleeProfile.SWING_RL] = new float[][] {
                k(82, 10.0f, 15.5f, 90, -6, 0, 46, -1.0f, -20, 9.0f, 16.0f, -0.4f, 0),
                k(-4, 13.4f, 15.6f, -6, 0, 0, -2, 2.5f, -34, 9.0f, 16.0f, 0.7f, 0),
                k(-78, 10.0f, 15.0f, -86, 4, 0, -44, 1.0f, -50, 8.0f, 16.0f, 0.4f, 0)};
        KEYS[MeleeProfile.OVERHEAD] = new float[][] {
                k(10, 3.5f, 29.5f, 6, -108, 0, 14, -2.5f, -34, 6.0f, 24.0f, -0.5f, 0),
                k(0, 12.5f, 14.8f, 0, 28, 0, -10, 4.5f, -46, 7.0f, 16.0f, 1, 0),
                k(0, 13.5f, 11.4f, 0, 42, 0, -14, 5.5f, -46, 7.0f, 15.0f, 1, 0)};
        KEYS[MeleeProfile.DIAG_LR] = new float[][] {
                k(-72, 9.5f, 25.5f, -80, -22, -36, -38, -1.0f, -60, 8.0f, 18.0f, -0.4f, 0),
                k(8, 13.2f, 16.8f, 10, 6, 20, 4, 3.0f, -62, 8.0f, 16.0f, 0.7f, 0),
                k(74, 10.0f, 10.8f, 82, 18, 42, 38, 1.5f, -44, 8.0f, 15.0f, 0.5f, 0)};
        KEYS[MeleeProfile.DIAG_RL] = new float[][] {
                k(72, 9.5f, 25.5f, 80, -22, 36, 38, -1.0f, -22, 9.0f, 18.0f, -0.4f, 0),
                k(-8, 13.2f, 16.8f, -10, 6, -20, -4, 3.0f, -34, 9.0f, 16.0f, 0.7f, 0),
                k(-74, 10.0f, 10.8f, -82, 18, -42, -38, 1.5f, -48, 8.0f, 15.0f, 0.5f, 0)};
        KEYS[MeleeProfile.UPPER] = new float[][] {
                k(46, 8.5f, 9.5f, 52, 36, 20, 34, -2.0f, -40, 6.5f, 14.0f, -0.5f, 0),
                k(4, 13.0f, 16.8f, 4, -20, 0, -6, 4.0f, -50, 6.5f, 17.0f, 1, 0),
                k(-28, 8.5f, 27.5f, -30, -64, -26, -30, 2.5f, -54, 6.0f, 22.0f, 1, 0)};
        KEYS[MeleeProfile.STAB_DOWN] = new float[][] {
                k(8, 5.0f, 28.5f, 4, -98, 0, 12, -2.0f, -34, 6.0f, 24.0f, -0.5f, 0),
                k(0, 13.6f, 12.8f, 0, 62, 0, -10, 5.0f, -46, 7.0f, 15.0f, 1, 0),
                k(0, 14.2f, 11.2f, 0, 70, 0, -12, 5.5f, -46, 7.0f, 15.0f, 1, 0)};
        KEYS[MeleeProfile.JAB] = new float[][] {
                k(20, 6.5f, 17.0f, 0, 0, 0, 14, -1.0f, -22, 8.5f, 17.2f, -0.3f, 0),
                k(2, 15.8f, 17.6f, 0, 0, 0, -12, 3.5f, -26, 8.5f, 17.2f, 1, 0),
                k(3, 13.0f, 17.2f, 0, 0, 0, -8, 3.0f, -24, 8.5f, 17.2f, 1, 0)};
        KEYS[MeleeProfile.HOOK] = new float[][] {
                k(80, 11.0f, 17.6f, 0, 0, 0, 42, -1.5f, -18, 8.0f, 17.4f, -0.5f, 0),
                k(8, 13.8f, 17.6f, 0, 0, 0, -22, 3.0f, -22, 8.0f, 17.4f, 1, 0),
                k(-42, 10.6f, 17.2f, 0, 0, 0, -46, 2.0f, -22, 8.0f, 17.4f, 1, 0)};
        KEYS[MeleeProfile.SPIN] = new float[][] {
                k(76, 11.5f, 16.0f, 82, -2, 0, 26, -1.5f, -10, 9.0f, 16.0f, -0.5f, 0),
                k(76, 12.5f, 16.0f, 82, 0, 0, -140, 1.0f, -10, 9.0f, 16.0f, 0.3f, 0),
                k(76, 12.0f, 16.0f, 82, 2, 0, -300, 1.0f, -10, 9.0f, 16.0f, 0.3f, 0)};
    }

    // ---- scratch
    private final float[] gStart = new float[N], gEnd = new float[N], cur = new float[N], tmp = new float[N];
    private final float[] hand = new float[3], elbow = new float[3];

    /**
     * Works out the pose of a fighter holding {@code weaponId}: idle in the guard ({@code kind} below 0), or {@code u} (0..1)
     * of the way through attack {@code kind}. {@code uHit} is when, as a fraction of the swing, the blow lands: the impact
     * pose is timed to it. {@code index} is the attack's place in its combo (punches alternate hands), {@code time} drives
     * the idle breathing.
     */
    public void pose(int weaponId, int kind, int index, float u, float uHit, float time) {
        Spec sp = weaponId >= 0 && weaponId < SPECS.length ? SPECS[weaponId] : null;
        if (sp == null) sp = SPECS[WeaponDef.FISTS];
        hasWeapon = weaponId != WeaponDef.FISTS;
        twoHanded = sp.leftGrip > 0f;
        System.arraycopy(sp.guard, 0, gStart, 0, N);
        gStart[PHI] = sp.bias;
        System.arraycopy(gStart, 0, gEnd, 0, N);
        float breathe = (float) Math.sin(time * 2.3f) * 0.22f;

        boolean mirror = false;
        if (kind < 0 || kind >= KEYS.length || KEYS[kind] == null) {
            System.arraycopy(gStart, 0, cur, 0, N);
            cur[Z] += breathe;
            cur[LZ] += breathe;
            cur[R] += breathe * 0.5f;
        } else {
            float[][] keys = KEYS[kind];
            float biasMul = biasMul(kind);
            float[] w = keyOf(keys[0], sp, biasMul, 0), im = keyOf(keys[1], sp, biasMul, 1), f = keyOf(keys[2], sp, biasMul, 2);
            if (kind == MeleeProfile.SPIN) gEnd[TW] = TW_SPIN_END + gStart[TW];
            // keep the free hand where the attack puts it only for weapons that leave it free
            float wu = u < uHit ? 0.40f * u / Math.max(0.05f, uHit) : 0.40f + 0.60f * (u - uHit) / Math.max(0.05f, 1f - uHit);
            if (wu < 0.18f) blend(gStart, w, smooth(wu / 0.18f), cur);
            else if (wu < 0.40f) blend(w, im, easeIn((wu - 0.18f) / 0.22f), cur);
            else if (wu < 0.60f) blend(im, f, easeOut((wu - 0.40f) / 0.20f), cur);
            else blend(f, gEnd, smooth((wu - 0.60f) / 0.40f), cur);
            // heavy weapons put their body into it
            float amp = sp.heavy;
            cur[TW] = gStart[TW] + (cur[TW] - gStart[TW]) * (kind == MeleeProfile.SPIN ? 1f : amp);
            mirror = kind == MeleeProfile.JAB && weaponId == WeaponDef.FISTS && (index & 1) == 1;
        }

        // ---- the right hand and the free hand, in the body frame
        float a = cur[A] * D2R, r = cur[R], z = cur[Z];
        float hx = r * (float) Math.cos(a), hy = 3.0f + r * (float) Math.sin(a), hz = z;
        float la = cur[LA] * D2R, lr = cur[LR], lzz = cur[LZ];
        float fx = lr * (float) Math.cos(la), fy = -3.0f + lr * (float) Math.sin(la), fz = lzz;
        twist = cur[TW] * D2R;
        lunge = cur[LG];
        step = cur[STEP];
        yaw = cur[PSI] * D2R;
        pitch = cur[TH] * D2R;
        roll = cur[PHI] * D2R;

        if (mirror) {
            // the other fist throws the punch: each hand takes the place the other one had, flipped sideways
            float ox = hx, oy = hy, oz = hz;
            hx = fx;
            hy = -fy;
            hz = fz;
            fx = ox;
            fy = -oy;
            fz = oz;
            twist = -twist;
        }

        // ---- the weapon turned about its grip
        pivX = sp.grip;
        pivY = 0.8f;
        pivZ = 14.7f;

        // right arm
        solveArm(SX, SY, SZ, hx, hy, hz, 1f);
        rx = hand[0];
        ry = hand[1];
        rz = hand[2];
        erx = elbow[0];
        ery = elbow[1];
        erz = elbow[2];
        float cps = (float) Math.cos(yaw), sps = (float) Math.sin(yaw);
        float px = rx + lunge, py = ry;
        gunOffX = px * cps + py * sps - pivX;
        gunOffY = -px * sps + py * cps - pivY;
        gunOffZ = rz - pivZ;

        // left arm: on the weapon for two-handed ones, free otherwise
        if (twoHanded) {
            localToBody(sp.leftGrip, pivY, pivZ, false);
            fx = tipB[0];
            fy = tipB[1];
            fz = tipB[2];
        }
        solveArm(SX, -SY, SZ, fx, fy, fz, -1f);
        lx = hand[0];
        ly = hand[1];
        lz = hand[2];
        elx = elbow[0];
        ely = elbow[1];
        elz = elbow[2];
    }

    private final float[] tipB = new float[3];

    /**
     * A point of the weapon (weapon-local x, y) in the body frame of the last pose, including the lunge: the tip, or the
     * middle of the weapon.
     */
    public void weaponPoint(int weaponId, boolean tip, float[] out) {
        Spec sp = weaponId >= 0 && weaponId < SPECS.length && SPECS[weaponId] != null ? SPECS[weaponId] : SPECS[WeaponDef.FISTS];
        if (weaponId == WeaponDef.FISTS) {
            out[0] = rx + lunge + (tip ? 2.4f : 0f);
            out[1] = ry;
            out[2] = rz;
            return;
        }
        localToBody(tip ? sp.tipX : sp.midX, tip ? sp.tipY : sp.midY, pivZ, true);
        out[0] = tipB[0];
        out[1] = tipB[1];
        out[2] = tipB[2];
    }

    /** Local weapon point to the body frame: turn about the grip (roll, then pitch, then yaw), then put the grip in the hand. */
    private void localToBody(float lxp, float lyp, float lzp, boolean withLunge) {
        float dx = lxp - pivX, dy = lyp - pivY, dz = lzp - pivZ;
        float cr = (float) Math.cos(roll), sr = (float) Math.sin(roll);
        float y1 = dy * cr - dz * sr, z1 = dy * sr + dz * cr;
        float cp = (float) Math.cos(pitch), sp = (float) Math.sin(pitch);
        float x2 = dx * cp + z1 * sp, z2 = -dx * sp + z1 * cp;
        float cy = (float) Math.cos(yaw), sy = (float) Math.sin(yaw);
        tipB[0] = rx + (withLunge ? lunge : 0f) + x2 * cy - y1 * sy;
        tipB[1] = ry + x2 * sy + y1 * cy;
        tipB[2] = rz + z2;
    }

    // ------------------------------------------------------------------ helpers

    private float biasMul(int kind) {
        switch (kind) {
            case MeleeProfile.OVERHEAD:
            case MeleeProfile.STAB_DOWN:
                return 0f;
            case MeleeProfile.DIAG_LR:
            case MeleeProfile.DIAG_RL:
                return 0.6f;
            case MeleeProfile.UPPER:
                return 0.5f;
            default:
                return 1f;
        }
    }

    /** A key of the table with the weapon's own roll bias added; the free hand's numbers only matter for one-handed weapons. */
    private final float[][] keyBuf = new float[3][N];

    private float[] keyOf(float[] src, Spec sp, float biasMul, int slot) {
        float[] o = keyBuf[slot];
        System.arraycopy(src, 0, o, 0, N);
        o[PHI] = src[PHI] + sp.bias * biasMul;
        return o;
    }

    private static void blend(float[] p, float[] q, float t, float[] out) {
        for (int i = 0; i < N; i++) out[i] = p[i] + (q[i] - p[i]) * t;
    }

    private static float smooth(float t) {
        t = t < 0f ? 0f : (t > 1f ? 1f : t);
        return t * t * (3f - 2f * t);
    }

    private static float easeIn(float t) {
        t = t < 0f ? 0f : (t > 1f ? 1f : t);
        return t * t * (0.35f + 0.65f * t);
    }

    private static float easeOut(float t) {
        t = t < 0f ? 0f : (t > 1f ? 1f : t);
        float q = 1f - t;
        return 1f - q * q;
    }

    /**
     * Two-bone arm from the shoulder (sx, sy, sz) to a hand at (hx, hy, hz): the hand is pulled in if it is out of reach, the
     * elbow is bent out to the side and down ({@code side} is +1 for the right arm, -1 for the left).
     */
    private void solveArm(float sx, float sy, float sz, float hx, float hy, float hz, float side) {
        float dx = hx - sx, dy = hy - sy, dz = hz - sz;
        float dist = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        float max = UPPER + FORE - 0.15f, min = Math.abs(UPPER - FORE) + 0.4f;
        if (dist < 1e-3f) {
            dx = 1f;
            dy = 0f;
            dz = 0f;
            dist = 1f;
        }
        float nx = dx / dist, ny = dy / dist, nz = dz / dist;
        float d = dist > max ? max : (dist < min ? min : dist);
        hand[0] = sx + nx * d;
        hand[1] = sy + ny * d;
        hand[2] = sz + nz * d;
        float al = (UPPER * UPPER - FORE * FORE + d * d) / (2f * d);
        float h2 = UPPER * UPPER - al * al;
        float h = h2 > 0f ? (float) Math.sqrt(h2) : 0f;
        // the elbow points out to the side and a little down and back
        float pxv = -0.18f, pyv = side, pzv = -0.62f;
        float dot = pxv * nx + pyv * ny + pzv * nz;
        pxv -= dot * nx;
        pyv -= dot * ny;
        pzv -= dot * nz;
        float pl = (float) Math.sqrt(pxv * pxv + pyv * pyv + pzv * pzv);
        if (pl < 1e-4f) {
            pxv = 0f;
            pyv = side;
            pzv = 0f;
            pl = 1f;
        }
        elbow[0] = sx + nx * al + pxv / pl * h;
        elbow[1] = sy + ny * al + pyv / pl * h;
        elbow[2] = sz + nz * al + pzv / pl * h;
    }
}
