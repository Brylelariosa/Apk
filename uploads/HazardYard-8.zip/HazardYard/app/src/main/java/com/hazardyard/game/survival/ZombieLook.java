package com.hazardyard.game.survival;

import com.hazardyard.game.core.Puppet;
import com.hazardyard.game.core.PuppetStyle;

/**
 * Turns a zombie's type and its {@code look} number (a hash of its id, the same on every device) into a body: skin
 * tone, clothes, hair, wounds and build. Walkers wear ordinary clothes, runners are lean in sportswear, brutes are
 * big and wear a butcher's apron, a work vest or little at all, so a crowd never looks like copies of one model.
 */
public final class ZombieLook {
    private ZombieLook() {}

    private static final int[] SKIN = {0xFF9DB58A, 0xFF8FA39A, 0xFFB3AE8B, 0xFFA9A9A2, 0xFF8DB1A4, 0xFFA7B38E};
    private static final int[] SHIRT = {0xFF9C4B46, 0xFF4A6D95, 0xFF557A4E, 0xFF808890, 0xFFB09A45, 0xFF7A5A8C, 0xFF6B6F4C, 0xFFB86A3C};
    private static final int[] DARK_SHIRT = {0xFF3E4452, 0xFF5A3C3C, 0xFF2F4A46, 0xFF4B4B55, 0xFF6A3A2A, 0xFF34405A};
    private static final int[] PANTS = {0xFF3A4660, 0xFF4B4B50, 0xFF5A4A38, 0xFF2E3A33, 0xFF6A5E4A, 0xFF30344A};
    private static final int[] HAIR = {0xFF1E1B1A, 0xFF3A2A1E, 0xFF5C4128, 0xFFA89A72, 0xFF8A4A26, 0xFF777777};

    /** A deterministic scramble of a zombie id. */
    public static int lookOf(int id) {
        int h = id * 0x9E3779B1 + 0x7F4A7C15;
        h ^= h >>> 15;
        h *= 0x2C1B3C6D;
        h ^= h >>> 12;
        h *= 0x297A2D39;
        h ^= h >>> 15;
        return h;
    }

    private static int shade(int c, float k) {
        int r = (int) (((c >> 16) & 0xFF) * k), g = (int) (((c >> 8) & 0xFF) * k), b = (int) ((c & 0xFF) * k);
        return 0xFF000000 | (Math.min(255, r) << 16) | (Math.min(255, g) << 8) | Math.min(255, b);
    }

    private static int pick(int[] a, int look, int shift) {
        return a[((look >>> shift) & 0xFFFF) % a.length];
    }

    /** Fills {@code o} for a zombie of this type with this look number. */
    public static void fill(int type, int look, PuppetStyle o) {
        o.sleeve = 0;
        o.build = type == Zombie.RUNNER ? Puppet.B_RUNNER : (type == Zombie.BRUTE ? Puppet.B_BRUTE : Puppet.B_NORMAL);
        o.skin = pick(SKIN, look, 0);
        o.skinShade = shade(o.skin, 0.74f);
        o.eye = 0xFFEAE27A;
        o.outline = 0xFF1B1E22;
        o.blood = 0xFF7A1C1C;
        o.shoe = 0xFF25272B;
        o.sleeveLen = 2;
        o.longPants = true;
        o.trim = 0;
        o.accent = 0;
        float jitter = ((look >>> 8) & 0xFF) / 255f;
        int outfitRoll = (look >>> 16) & 0xFF;
        int wounds = 0;
        int woundBits = (look >>> 24) & 0xFF;
        if ((woundBits & 3) == 0) wounds |= PuppetStyle.W_CHEST;
        if ((woundBits & 12) == 0) wounds |= PuppetStyle.W_HEAD;
        if ((woundBits & 48) == 0) wounds |= PuppetStyle.W_ARM;
        if ((woundBits & 192) == 0) wounds |= PuppetStyle.W_LEG;
        if (((look >>> 5) & 15) == 0) wounds |= PuppetStyle.W_NECK;
        o.hairStyle = 1 + ((look >>> 13) & 7) % 3;                  // short, messy, long
        if (((look >>> 4) & 7) == 0) o.hairStyle = PuppetStyle.HAIR_BALD;
        o.hair = pick(HAIR, look, 3);

        switch (type) {
            case Zombie.RUNNER:
                o.scale = 0.96f + jitter * 0.06f;
                o.width = 0.92f;
                if (outfitRoll < 100) {                              // hoodie
                    o.outfit = PuppetStyle.OUTFIT_HOODIE;
                    o.shirt = pick(DARK_SHIRT, look, 6);
                    o.trim = shade(o.shirt, 1.25f);
                    o.pants = shade(pick(PANTS, look, 9), 0.9f);
                } else if (outfitRoll < 180) {                       // tank top and shorts
                    o.outfit = PuppetStyle.OUTFIT_TANK;
                    o.shirt = pick(SHIRT, look, 6);
                    o.sleeveLen = 0;
                    o.pants = pick(PANTS, look, 9);
                    o.longPants = false;
                } else {                                             // tee and jeans
                    o.outfit = PuppetStyle.OUTFIT_TEE;
                    o.shirt = pick(SHIRT, look, 6);
                    o.sleeveLen = 1;
                    o.pants = pick(PANTS, look, 9);
                }
                break;
            case Zombie.BRUTE:
                o.scale = 1.22f + jitter * 0.1f;
                o.width = 1.34f;
                o.hairStyle = (look & 3) == 0 ? PuppetStyle.HAIR_BALD : PuppetStyle.HAIR_SHORT;
                if (outfitRoll < 90) {                               // butcher's apron
                    o.outfit = PuppetStyle.OUTFIT_APRON;
                    o.shirt = 0xFFC9C3B0;
                    o.trim = 0xFF8A8576;
                    o.pants = shade(pick(PANTS, look, 9), 0.85f);
                    wounds |= PuppetStyle.W_CHEST;
                } else if (outfitRoll < 170) {                       // site worker in a vest
                    o.outfit = PuppetStyle.OUTFIT_VEST;
                    o.shirt = 0xFFD9802B;
                    o.trim = 0xFFD8D8C8;
                    o.sleeve = 0xFF6E7075;
                    o.sleeveLen = 1;
                    o.pants = 0xFF4A4C50;
                    if (((look >>> 20) & 3) == 0) o.hairStyle = PuppetStyle.HAIR_HARDHAT;
                } else {                                             // shirtless
                    o.outfit = PuppetStyle.OUTFIT_BARE;
                    o.shirt = o.skin;
                    o.sleeveLen = 0;
                    o.pants = shade(pick(PANTS, look, 9), 0.8f);
                    wounds |= PuppetStyle.W_CHEST | PuppetStyle.W_ARM;
                }
                break;
            default:
                o.scale = 0.97f + jitter * 0.08f;
                o.width = 0.97f + ((look >>> 10) & 7) * 0.012f;
                if (outfitRoll < 55) {
                    o.outfit = PuppetStyle.OUTFIT_TEE;
                    o.shirt = pick(SHIRT, look, 6);
                    o.sleeveLen = 1;
                    o.pants = pick(PANTS, look, 9);
                } else if (outfitRoll < 100) {
                    o.outfit = PuppetStyle.OUTFIT_HOODIE;
                    o.shirt = pick(DARK_SHIRT, look, 6);
                    o.trim = shade(o.shirt, 1.25f);
                    o.pants = pick(PANTS, look, 9);
                } else if (outfitRoll < 140) {
                    o.outfit = PuppetStyle.OUTFIT_OFFICE;
                    o.shirt = ((look >>> 7) & 1) == 0 ? 0xFFB9C0C6 : 0xFF8FB0C8;
                    o.trim = 0xFF7A2A2E;                               // the tie
                    o.pants = 0xFF2F3340;
                } else if (outfitRoll < 170) {
                    o.outfit = PuppetStyle.OUTFIT_COAT;
                    o.shirt = 0xFFD8DAD4;
                    o.trim = 0xFF4F8F94;                               // scrubs under the coat
                    o.pants = 0xFF4F8F94;
                    wounds |= PuppetStyle.W_CHEST;
                } else if (outfitRoll < 200) {
                    o.outfit = PuppetStyle.OUTFIT_POLICE;
                    o.shirt = 0xFF2F4565;
                    o.trim = 0xFFD8B84A;                               // the badge
                    o.pants = 0xFF222B3B;
                    if (((look >>> 18) & 3) < 2) o.hairStyle = PuppetStyle.HAIR_CAP;
                } else if (outfitRoll < 228) {
                    o.outfit = PuppetStyle.OUTFIT_VEST;
                    o.shirt = 0xFFE08A2E;
                    o.trim = 0xFFE2E2D2;
                    o.sleeve = 0xFF6E7075;
                    o.sleeveLen = 1;
                    o.pants = pick(PANTS, look, 9);
                    if (((look >>> 20) & 3) == 0) o.hairStyle = PuppetStyle.HAIR_HARDHAT;
                } else {
                    o.outfit = PuppetStyle.OUTFIT_GOWN;
                    o.shirt = 0xFFA9C6D8;
                    o.trim = 0xFF8AA8BC;
                    o.pants = o.shirt;
                    o.sleeveLen = 1;
                    o.longPants = false;
                    wounds |= PuppetStyle.W_LEG;
                }
                break;
        }
        if (o.sleeve == 0) o.sleeve = o.shirt;
        o.shirtShade = shade(o.shirt, 0.78f);
        o.pantsShade = shade(o.pants, 0.8f);
        o.wounds = wounds;
    }
}
