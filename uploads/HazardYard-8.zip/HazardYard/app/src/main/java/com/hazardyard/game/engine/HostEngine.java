package com.hazardyard.game.engine;

import com.hazardyard.game.bot.BotDifficulty;
import com.hazardyard.game.bot.BotSquad;
import com.hazardyard.game.core.GameConfig;
import com.hazardyard.game.core.GameMode;
import com.hazardyard.game.core.GameState;
import com.hazardyard.game.core.GameWorld;
import com.hazardyard.game.core.LocalInput;
import com.hazardyard.game.core.MapLibrary;
import com.hazardyard.game.core.MathUtil;
import com.hazardyard.game.core.Player;
import com.hazardyard.game.core.WeaponDef;
import com.hazardyard.game.core.WorldListener;
import com.hazardyard.game.net.HostManager;
import com.hazardyard.game.net.LobbyManager;
import com.hazardyard.game.net.NetworkManager;
import com.hazardyard.game.net.Packets;
import com.hazardyard.game.net.PacketReader;
import com.hazardyard.game.net.PacketWriter;
import com.hazardyard.game.net.Protocol;
import com.hazardyard.game.net.SnapshotCodec;
import com.hazardyard.game.net.SurvivalCodec;
import com.hazardyard.game.survival.Car;
import com.hazardyard.game.survival.Inventory;
import com.hazardyard.game.survival.SurvivalSim;
import com.hazardyard.game.survival.SurvivalState;
import com.hazardyard.game.survival.Zombie;

/**
 * Authoritative engine: applies client input, runs {@link GameWorld}, and publishes the result as
 * 20 Hz snapshots plus reliable fire/hit/kill events. The host's own player is slot 0.
 */
public final class HostEngine implements GameEngine, WorldListener {
    private final HostManager net;
    private final GameState st;
    private final GameWorld world;
    private final BotSquad squad;
    private final PacketWriter snapshotWriter = new PacketWriter(1024);
    private final PacketWriter eventWriter = new PacketWriter(64);
    private final PacketReader reader = new PacketReader();
    private final PacketWriter survivalWriter = new PacketWriter(1024);
    private final PacketWriter invWriter = new PacketWriter(128);

    /** Survival: what the rules engine reports goes to every client and is played here too. */
    private final SurvivalSim.Out survivalOut = new SurvivalSim.Out() {
        @Override
        public void sound(int sound, float x, float y, float volume, float pitch) {
            net.broadcast(SurvivalCodec.encodeSound(eventWriter, sound, x, y, volume, pitch));
            if (pitch > 0f) st.audio.playAt(sound, x, y, volume, pitch);
            else st.audio.playAt(sound, x, y, volume);
        }

        @Override
        public void edit(int tx, int ty, int layer, int value, int meta) {
            net.broadcast(SurvivalCodec.encodeEdit(eventWriter, tx, ty, layer, value, meta));
        }

        @Override
        public void zombieEvent(int id, int type, int kind, float x, float y, float angle, float strength, int damage) {
            net.broadcast(SurvivalCodec.encodeZombieEvent(eventWriter, id, type, kind, x, y, angle, strength, damage));
            Presentation.zombieEvent(st, id, type, kind, x, y, angle, strength, damage);
        }

        @Override
        public void toast(int playerId, int code) {
            net.broadcast(SurvivalCodec.encodeToast(eventWriter, playerId, code));
            if (playerId == net.localPlayerId() && st.survival != null) {
                st.survival.toast = code;
                st.survival.toastTimer = 2.4f;
            }
        }
    };
    private final Packets.Input inputPacket = new Packets.Input();
    private final Packets.Fire firePacket = new Packets.Fire();
    private final Packets.Hit hitPacket = new Packets.Hit();
    private final Packets.Kill killPacket = new Packets.Kill();
    private int tick;
    private volatile boolean finished;
    private volatile boolean paused;

    /**
     * Creates the match for everybody currently in the lobby and starts the countdown. A mode with a
     * roster (Battleground) is filled up with bots: they only take slots no real player holds, so a
     * human is never replaced, and the bots simply are fewer the more humans there are.
     */
    public HostEngine(HostManager net) {
        this.net = net;
        GameMode mode = GameMode.byId(net.lobby().getModeId());
        if (mode.survival) {
            SurvivalState sv = new SurvivalState(net.lobby().getSeed());
            st = new GameState(MapLibrary.get(mode.mapId), sv.terrain, net.localPlayerId(), mode);
            st.survival = sv;
        } else {
            st = new GameState(MapLibrary.get(net.lobby().getMapId()), net.localPlayerId(), mode);
        }
        world = new GameWorld(st, this);
        if (mode.survival) world.attachSurvival(survivalOut);
        LobbyManager.Entry[] roster = new LobbyManager.Entry[GameConfig.MAX_HUMANS];
        for (int i = 0; i < roster.length; i++) roster[i] = new LobbyManager.Entry();
        net.lobby().copyTo(roster);
        int humans = 0;
        for (int i = 0; i < roster.length; i++) {
            if (roster[i].used) {
                world.addPlayer(i, roster[i].name);
                humans++;
            }
        }
        squad = new BotSquad(st, world, BotDifficulty.NORMAL);
        int bots = Math.min(mode.botsFor(humans), net.lobby().getBotCap());
        int seed = (int) (System.nanoTime() & 0x3FFFFFFF);
        // Bots take the slots above the human range first, then any human slot nobody holds.
        for (int slot = GameConfig.MAX_HUMANS; slot < GameConfig.MAX_PLAYERS && bots > 0; slot++, bots--) {
            addBot(slot, seed);
        }
        for (int slot = 0; slot < GameConfig.MAX_HUMANS && bots > 0; slot++) {
            if (roster[slot].used) continue;
            addBot(slot, seed);
            bots--;
        }
        world.startMatch();
    }

    private void addBot(int slot, int seed) {
        world.addPlayer(slot, BotSquad.nameFor(slot), true);
        squad.add(slot, seed + slot);
    }

    @Override
    public GameState state() {
        return st;
    }

    @Override
    public void fixedUpdate(float dt, LocalInput in) {
        if (finished) return;
        tick++;
        NetworkManager.Inbound m;
        while ((m = net.poll()) != null) handle(m);
        if (net.isClosed()) {
            finished = true;
            return;
        }
        world.setInput(0, in.moveX, in.moveY, in.aim, in.firing, 0);
        if (in.reload) world.requestReload(0);
        if (in.switchWeapon) world.requestSwitch(0);
        if (in.dodge) world.requestDodge(0, 0f, 0f);
        if (in.pickup) world.requestPickup(0, -1);
        for (int k = 0; k < in.cmdCount; k++) world.survivalCommand(0, in.cmdType[k], in.cmdA[k], in.cmdB[k]);

        Interpolation.begin(st);
        boolean frozen = paused && net.clientCount() == 0;
        if (!frozen) {
            squad.think(dt);
            world.step(dt);
            if (tick % GameConfig.SNAPSHOT_EVERY_TICKS == 0) {
                net.broadcastDroppable(SnapshotCodec.encode(snapshotWriter, st, tick));
            }
            if (st.survival != null) publishSurvival();
        }
        Interpolation.end(st);
        st.effects.update(dt);
        st.ragdolls.update(dt, st.terrain);
        if (st.phase == GameState.PHASE_FINISHED) finished = true;
    }

    /** Survival: the zombies, cars and items every 2nd snapshot, and each survivor's pack whenever it changed. */
    private void publishSurvival() {
        if (tick % (GameConfig.SNAPSHOT_EVERY_TICKS * 2) == 0) {
            net.broadcastDroppable(SurvivalCodec.encodeState(survivalWriter, st));
        }
        for (int i = 0; i < st.players.length; i++) {
            Inventory inv = st.survival.inv[i];
            if (!inv.dirty) continue;
            if (i != net.localPlayerId() && st.players[i].connected) {
                net.sendTo(i, SurvivalCodec.encodeInventory(invWriter, inv));
            }
            inv.dirty = false;
        }
        Zombie[] zs = st.survival.zombies;
        for (Zombie z : zs) {
            if (!z.active) continue;
            z.rx = z.x;
            z.ry = z.y;
            z.rAim = z.aim;
        }
        for (Car c : st.survival.cars) {
            if (!c.active) continue;
            c.rx = c.x;
            c.ry = c.y;
            c.rHeading = c.heading;
        }
    }

    private void handle(NetworkManager.Inbound m) {
        try {
            reader.wrap(m.data, 0, m.data.length);
            int type = reader.u8();
            switch (type) {
                case Protocol.C_INPUT:
                    inputPacket.read(reader);
                    world.setInput(m.from, inputPacket.moveX / 127f, inputPacket.moveY / 127f,
                            MathUtil.u16ToAngle(inputPacket.aim16), inputPacket.firing, inputPacket.seq);
                    break;
                case Protocol.C_RELOAD:
                    world.requestReload(m.from);
                    break;
                case Protocol.C_SWITCH:
                    world.requestSwitch(m.from);
                    break;
                case Protocol.C_DODGE: {
                    float a = MathUtil.u16ToAngle(reader.u16());
                    world.requestDodge(m.from, (float) Math.cos(a), (float) Math.sin(a));
                    break;
                }
                case Protocol.C_PICKUP: {
                    int pad = reader.u16();
                    world.requestPickup(m.from, pad == 65535 ? -1 : pad);
                    break;
                }
                case Protocol.C_SURV: {
                    int cmd = reader.u8();
                    int a = (short) reader.u16();
                    int b = (short) reader.u16();
                    world.survivalCommand(m.from, cmd, a, b);
                    break;
                }
                case Protocol.I_PLAYER_LEFT:
                    world.removePlayer(m.from);
                    break;
                default:
                    break;
            }
        } catch (RuntimeException malformed) {
            // A broken packet from one client must never take the host down; it is simply ignored.
        }
    }

    @Override
    public void frameUpdate(float dt, float alpha) {
        Interpolation.apply(st, alpha);
    }

    @Override
    public boolean isFinished() {
        return finished;
    }

    @Override
    public String finishReason() {
        return net.isClosed() ? "The lobby was closed." : null;
    }

    @Override
    public int pingMs() {
        return 0;
    }

    @Override
    public void setPaused(boolean p) {
        paused = p;
    }

    @Override
    public void close() {
        finished = true;
    }

    // ------------------------------------------------------------------ WorldListener

    @Override
    public void onShot(Player shooter, WeaponDef def, float x, float y, float angle, int seed, int baseId) {
        firePacket.owner = shooter.id;
        firePacket.weaponId = def.id;
        firePacket.x = x;
        firePacket.y = y;
        firePacket.angle = angle;
        firePacket.seed = seed;
        firePacket.baseId = baseId;
        net.broadcast(firePacket.encode(eventWriter));
        Presentation.shot(st, shooter.id, def.id, x, y, angle, seed);
    }

    @Override
    public void onProjectileHit(int projectileId, int victimId, float x, float y, int damage, int weaponId) {
        hitPacket.projectileId = projectileId;
        hitPacket.victim = victimId;
        hitPacket.damage = damage;
        hitPacket.x = x;
        hitPacket.y = y;
        net.broadcast(hitPacket.encode(eventWriter));
        Presentation.hit(st, victimId, x, y, weaponId, damage);
    }

    @Override
    public void onPickup(Player p, int pickupIndex) {
        Presentation.pickup(st, pickupIndex, st.pickups[pickupIndex].item);
    }

    @Override
    public void onWallImpact(float x, float y, int weaponId) {
        Presentation.wallImpact(st, x, y, weaponId);
    }

    @Override
    public void onKill(int killerId, int victimId, int weaponId) {
        killPacket.killer = killerId;
        killPacket.victim = victimId;
        killPacket.weaponId = weaponId;
        net.broadcast(killPacket.encode(eventWriter));
        Presentation.kill(st, killerId, victimId, weaponId);
    }
}
