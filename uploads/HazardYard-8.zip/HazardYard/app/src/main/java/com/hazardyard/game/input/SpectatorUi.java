package com.hazardyard.game.input;

/**
 * The buttons shown to a fighter who has been eliminated from a Battleground match while the match goes on: Previous and
 * Next to look through the eyes of another survivor, and Leave to go back without watching the rest. Pure Java: the
 * HUD reads the geometry from here so what is drawn is what can be touched. Touches that start on a button belong to it.
 */
public final class SpectatorUi {
    public static final int BTN_NONE = -1, BTN_PREV = 0, BTN_NEXT = 1, BTN_LEAVE = 2;

    /** Set every frame by the game loop: true while the local fighter is out and the match is still running. */
    public volatile boolean active;

    public float prevX, prevY, nextX, nextY, btnR;
    public float leaveX, leaveY, leaveW, leaveH;
    public float barX0, barY, barX1, barH;

    private int owner = -1;
    private float lastX, lastY;
    private int downButton = BTN_NONE;
    private int pendingDir;
    private boolean leaveRequested;

    public synchronized void layout(int w, int h, float d, float insetB) {
        float cx = w * 0.5f;
        btnR = 24f * d;
        float spread = 118f * d;
        prevX = cx - spread;
        nextX = cx + spread;
        prevY = h - insetB - 66f * d;
        nextY = prevY;
        leaveW = 150f * d;
        leaveH = 38f * d;
        leaveX = cx - leaveW * 0.5f;
        leaveY = h - insetB - 34f * d - leaveH * 0.5f + 8f * d;
        barX0 = prevX + btnR + 8f * d;
        barX1 = nextX - btnR - 8f * d;
        barH = 46f * d;
        barY = prevY - barH * 0.5f;
    }

    /** Puts the Leave button somewhere else for a moment (the results panel uses it as its Continue button). */
    public synchronized void placeLeave(float x, float y, float w, float h) {
        leaveX = x;
        leaveY = y;
        leaveW = w;
        leaveH = h;
    }

    /** True when only the Leave button is on screen (the results panel). */
    public volatile boolean leaveOnly;

    private int buttonAt(float x, float y) {
        if (leaveOnly) {
            return x >= leaveX && x <= leaveX + leaveW && y >= leaveY && y <= leaveY + leaveH ? BTN_LEAVE : BTN_NONE;
        }
        if (dist2(x, y, prevX, prevY) <= btnR * btnR * 1.5f) return BTN_PREV;
        if (dist2(x, y, nextX, nextY) <= btnR * btnR * 1.5f) return BTN_NEXT;
        if (x >= leaveX && x <= leaveX + leaveW && y >= leaveY && y <= leaveY + leaveH) return BTN_LEAVE;
        return BTN_NONE;
    }

    private static float dist2(float ax, float ay, float bx, float by) {
        float dx = ax - bx, dy = ay - by;
        return dx * dx + dy * dy;
    }

    public synchronized boolean onDown(int id, float x, float y) {
        if (!active || owner >= 0) return false;
        int b = buttonAt(x, y);
        if (b == BTN_NONE) return false;
        owner = id;
        downButton = b;
        lastX = x;
        lastY = y;
        return true;
    }

    public synchronized void onMove(int id, float x, float y) {
        if (owner != id) return;
        lastX = x;
        lastY = y;
    }

    public synchronized boolean owns(int id) {
        return owner == id;
    }

    /** True while a finger rests on this button (drawn pressed). */
    public synchronized boolean isHeld(int button) {
        return owner >= 0 && downButton == button;
    }

    public synchronized void onUp(int id) {
        if (owner != id) return;
        owner = -1;
        int b = buttonAt(lastX, lastY);
        if (b != downButton) return;
        if (b == BTN_PREV) pendingDir = -1;
        else if (b == BTN_NEXT) pendingDir = 1;
        else if (b == BTN_LEAVE) leaveRequested = true;
    }

    public synchronized void cancel() {
        owner = -1;
    }

    /** -1, +1 or 0: which way the player asked to move the view since the last call. */
    public synchronized int takeDirection() {
        int d = pendingDir;
        pendingDir = 0;
        return d;
    }

    /** True once after Leave was tapped. */
    public synchronized boolean takeLeave() {
        boolean l = leaveRequested;
        leaveRequested = false;
        return l;
    }
}
