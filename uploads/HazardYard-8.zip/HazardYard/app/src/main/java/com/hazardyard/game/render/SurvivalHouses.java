package com.hazardyard.game.render;

import android.graphics.Canvas;
import android.graphics.Paint;

import com.hazardyard.game.core.GameConfig;
import com.hazardyard.game.survival.SurvivalGen;
import com.hazardyard.game.survival.SurvivalTerrain;

/**
 * The buildings of the survival world as you see them: a roof over each (it hides the inside and fades away when you step
 * through the door, like Battleground's houses), the porch step and doormat in front of every door, and the colour of
 * the walls. The buildings are found by asking the world generator for the ones near the view, so nothing is stored.
 */
final class SurvivalHouses {
    private static final float T = GameConfig.TILE;
    private static final int MAX = 40;
    /** Walls: lit top, south face, west face, trim, per colour scheme. */
    static final int[][] WALLS = {
            {0xFFEADFC4, 0xFFC9B795, 0xFF9E8E70, 0xFF8A7656},    // 0 cream
            {0xFFC9D2DC, 0xFFA2AEBC, 0xFF7D8A99, 0xFF5E6A78},    // 1 blue grey
            {0xFFCBDDBD, 0xFF9DB68A, 0xFF7A9268, 0xFF5E744F},    // 2 sage
            {0xFFD9A38C, 0xFFB5705A, 0xFF8F5442, 0xFF6C3B2E},    // 3 brick
            {0xFFEDD79A, 0xFFD2B462, 0xFFA8893F, 0xFF846A2A},    // 4 mustard
            {0xFFF1F3F4, 0xFFD5DADD, 0xFFAEB5BA, 0xFF8E969C},    // 5 white
            {0xFFC9A67C, 0xFFA07A50, 0xFF7A5A38, 0xFF5A4028},    // 6 timber
            {0xFFC8CCD0, 0xFF9AA0A6, 0xFF787E84, 0xFF595F66}};   // 7 concrete

    private final RoofRenderer roofs = new RoofRenderer();
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final int[] rec = new int[MAX * SurvivalGen.B_STRIDE];
    private int count;
    private final int[] order = new int[MAX];
    // roof fade: the alpha of each building by id, kept between frames
    private int[] ids = new int[MAX], ids2 = new int[MAX];
    private float[] alpha = new float[MAX], alpha2 = new float[MAX];
    private int idCount;
    private final float[] roofA = new float[MAX];
    private int roofPointer;
    private float lastTime = -1f;

    SurvivalHouses() {
        fill.setStyle(Paint.Style.FILL);
    }

    /** Finds the buildings near the view and works out how see-through each roof is (open when the viewer is inside). */
    void collect(SurvivalGen gen, int tx0, int ty0, int tx1, int ty1, float viewerX, float viewerY, float time) {
        float dt = lastTime < 0f ? 0f : Math.max(0f, Math.min(0.1f, time - lastTime));
        lastTime = time;
        count = gen.buildingsInRect(tx0 - 2, ty0 - 4, tx1 + 2, ty1 + 2, rec);
        int vtx = (int) Math.floor(viewerX / T), vty = (int) Math.floor(viewerY / T);
        int n2 = 0;
        for (int i = 0; i < count; i++) {
            int o = i * SurvivalGen.B_STRIDE;
            int id = rec[o + SurvivalGen.B_ID];
            float prev = 1f;
            for (int k = 0; k < idCount; k++) if (ids[k] == id) { prev = alpha[k]; break; }
            boolean inside = vtx >= rec[o + SurvivalGen.B_X] - 0 && vtx < rec[o + SurvivalGen.B_X] + rec[o + SurvivalGen.B_W]
                    && vty >= rec[o + SurvivalGen.B_Y] && vty < rec[o + SurvivalGen.B_Y] + rec[o + SurvivalGen.B_H];
            float target = inside ? 0f : 1f;
            float a = prev < target ? Math.min(target, prev + dt * 6f) : Math.max(target, prev - dt * 6f);
            roofA[i] = a;
            ids2[n2] = id;
            alpha2[n2++] = a;
        }
        int[] ti = ids; ids = ids2; ids2 = ti;
        float[] ta = alpha; alpha = alpha2; alpha2 = ta;
        idCount = n2;
        // sort by the south row, so a roof is drawn after the row of its own south wall
        for (int i = 0; i < count; i++) {
            int j = i - 1;
            int key = southRow(i);
            while (j >= 0 && southRow(order[j]) > key) {
                order[j + 1] = order[j];
                j--;
            }
            order[j + 1] = i;
        }
        roofPointer = 0;
    }

    private int southRow(int i) {
        int o = i * SurvivalGen.B_STRIDE;
        return rec[o + SurvivalGen.B_Y] + rec[o + SurvivalGen.B_H] - 1;
    }

    /** The porch step and the doormat in front of each door; drawn on the ground before the objects. */
    void drawPorches(Canvas c, SurvivalTerrain t) {
        for (int i = 0; i < count; i++) {
            int o = i * SurvivalGen.B_STRIDE;
            int x0 = rec[o + SurvivalGen.B_X], y0 = rec[o + SurvivalGen.B_Y], w = rec[o + SurvivalGen.B_W], h = rec[o + SurvivalGen.B_H];
            int side = rec[o + SurvivalGen.B_SIDE], along = rec[o + SurvivalGen.B_ALONG];
            int dx = x0, dy = y0, ox = 0, oy = 0;
            if (side == 2) { dx = x0 + along; dy = y0 + h - 1; oy = 1; }
            else if (side == 0) { dx = x0 + along; dy = y0; oy = -1; }
            else if (side == 3) { dx = x0; dy = y0 + along; ox = -1; }
            else { dx = x0 + w - 1; dy = y0 + along; ox = 1; }
            float px = (dx + ox) * T, py = (dy + oy) * T;
            // a slab of lighter paving: the step
            fill.setColor(0xFFD0D0CC);
            c.drawRect(px + 2f, py + 2f, px + T - 2f, py + T - 2f, fill);
            fill.setColor(0xFFB4B4B0);
            c.drawRect(px + 2f, py + T - 4f, px + T - 2f, py + T - 2f, fill);
            // the doormat
            fill.setColor(rec[o + SurvivalGen.B_STYLE] % 2 == 0 ? 0xFF8A3A3A : 0xFF3A5A7A);
            if (side == 2 || side == 0) c.drawRoundRect(px + 6f, py + 8f, px + T - 6f, py + T - 8f, 3f, 3f, fill);
            else c.drawRoundRect(px + 8f, py + 6f, px + T - 8f, py + T - 6f, 3f, 3f, fill);
            fill.setColor(0x33FFFFFF);
            if (side == 2 || side == 0) c.drawRect(px + 9f, py + 11f, px + T - 9f, py + 13f, fill);
        }
    }

    /** Draws the roofs of the buildings whose south wall is on this tile row (call after the row). */
    void drawRoofsOf(Canvas c, int row, boolean lite, float vx0, float vx1, float vy0, float vy1) {
        while (roofPointer < count && southRow(order[roofPointer]) <= row) {
            int i = order[roofPointer++];
            int o = i * SurvivalGen.B_STRIDE;
            int x0 = rec[o + SurvivalGen.B_X], y0 = rec[o + SurvivalGen.B_Y], w = rec[o + SurvivalGen.B_W], h = rec[o + SurvivalGen.B_H];
            if (!RoofRenderer.inView(x0, y0, x0 + w - 1, y0 + h - 1, vx0, vx1, vy0, vy1)) continue;
            int kind = rec[o + SurvivalGen.B_KIND];
            int style = rec[o + SurvivalGen.B_STYLE];
            int roofStyle;
            if (kind == SurvivalGen.HOUSE || kind == SurvivalGen.CABIN) roofStyle = (style * 5 + 1) % 6;      // a pitched tile roof
            else roofStyle = 8;                                                                                // a flat metal roof
            roofs.drawRect(c, x0, y0, x0 + w - 1, y0 + h - 1, roofStyle, roofA[i], lite);
        }
    }

    /** Draws any roofs not drawn yet (below the last row of the view). */
    void drawRemainingRoofs(Canvas c, boolean lite, float vx0, float vx1, float vy0, float vy1) {
        drawRoofsOf(c, Integer.MAX_VALUE, lite, vx0, vx1, vy0, vy1);
    }
}
