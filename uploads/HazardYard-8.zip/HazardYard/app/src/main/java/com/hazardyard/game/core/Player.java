package com.hazardyard.game.core;

/**
 * One player slot. The same class serves the host (authoritative state plus received input) and
 * clients (last received state plus interpolation data), which keeps the renderer identical for both.
 */
public final class Player {
    public final int id;
    public String name = "";
    /** Slot is in use (a human or a bot is in the match). */
    public boolean connected;
    /** Host side: this slot is played by the computer. Never sent over the network. */
    public boolean bot;

    // ---- gameplay state: authoritative on the host, mirrored from snapshots on clients ----
    public boolean alive;
    public float x, y;
    public float aim;
    public int health = GameConfig.PLAYER_MAX_HEALTH;
    /** Bulletproof vest points left (0 = none); see {@link GameConfig#ARMOR_ABSORB}. */
    public int armor;
    /**
     * Battleground: 0 while the fighter is still in the match, otherwise the place it finished in (the winner is 1,
     * the first one out is the roster size). Always 0 in classic matches, where fighters respawn.
     */
    public int placement;
    public float respawnTimer;
    public float spawnProtect;
    public int kills, deaths;
    public final Weapon weapon = new Weapon();

    // ---- dodge roll: authoritative on the host, predicted by a client for its own player, mirrored for the rest ----
    /** Seconds of roll left; 0 when not rolling. */
    public float rollTimer;
    public float rollDirX, rollDirY;
    /** Seconds until another roll may start. */
    public float dodgeCooldown;
    /** How far through the roll the player is as drawn (0..1, smoothed between simulation steps); only meaningful while rolling. */
    public float rollU;

    // ---- Battleground equipment: two primary weapons (each with its own ammunition) and a backpack ----
    public static final int SLOTS = 2;
    /** The weapon carried in each slot (a {@link WeaponDef} id, or -1 for an empty slot). */
    public final int[] slotWeapon = {WeaponDef.PISTOL, -1};
    /** Rounds in the gun of each slot. For the active slot the live value is {@code weapon.ammo}; this is what it holds while put away. */
    public final int[] slotAmmo = new int[SLOTS];
    /** Spare rounds carried for the gun in each slot: every weapon has its own supply. */
    public final int[] slotReserve = new int[SLOTS];
    /** The slot in hand. */
    public int activeSlot;
    /** 0 no backpack, 1..3 small, medium, large: it decides how many spare magazines can be carried. */
    public int backpack;
    /** The player pressed Switch Weapon; consumed by the next simulation step. */
    public boolean switchRequest;
    /** Seconds of the weapon swap still to go: the gun cannot fire while it runs. */
    public float switchTimer;

    // ---- host side: latest input received for this player ----
    public float moveX, moveY;
    public float aimTarget;
    public boolean hasAimInput;
    public boolean firing;
    /** Counts trigger pulls (rising edges of {@link #firing}); semi-automatic weapons use it. */
    public int pulls;
    public int handledPulls;
    public float pullBuffer;
    public boolean reloadRequest;
    /** Host side: seconds until the melee blow that was started lands (0 = no swing in progress), and with which weapon. */
    public float swingTimer;
    public int swingWeapon;
    /** Animation of a melee swing, 0 (start) .. 1 (over) and how long it lasts; set on every device when the swing is seen. */
    public float swingT = 1f;
    public float swingDur = 0.3f;
    /** Which attack of the weapon's combo the current (or last) swing is, see {@link MeleeProfile}; set on every device. */
    public int swingVariant;
    /** Host side: index of the last attack, and seconds since it began, so a run of swings carries the combo on. */
    public int comboIdx = -1;
    public float comboT = 9f;
    /** Host side: velocity of a shove (a zombie's blow); it dies away quickly. */
    public float shoveX, shoveY;
    /** Host side: fraction of a point of storm damage not yet taken off the health (damage comes in whole points). */
    public float stormAcc;
    /** {@link #pulls} at the moment the current reload began: only a trigger pull after it may cut the reload short. */
    public int reloadPullMark;
    /** The player pressed Pick Up; consumed by the next simulation step. */
    public boolean pickupRequest;
    /** Pad the player was looking at when they pressed Pick Up, or -1 for "the nearest one". */
    public int pickupRequestIndex = -1;
    /** A dodge roll was requested; consumed by the next simulation step. */
    public boolean dodgeRequest;
    /** Requested roll direction (a unit vector); (0, 0) lets the host choose from the player's input. */
    public float dodgeReqX, dodgeReqY;
    /** Sequence number of the newest input applied; echoed to the owner for prediction. */
    public int lastInputSeq;

    // ---- presentation: what the renderer draws ----
    public float rx, ry, rAim;
    public float hitFlash;
    public float muzzleFlash;

    // ---- client side: interpolation of remote players ----
    public float fromX, fromY, fromAim;
    public float toX, toY, toAim;
    public float interpT;
    public boolean interpValid;
    /** Decaying visual offset applied after a prediction correction (local player only). */
    public float visX, visY;

    public Player(int id) {
        this.id = id;
    }

    public boolean isProtected() {
        return spawnProtect > 0f;
    }

    public boolean isRolling() {
        return rollTimer > 0f;
    }

    /** Clears everything that should not survive from one match into the next. */
    public void resetForMatch() {
        alive = false;
        health = GameConfig.PLAYER_MAX_HEALTH;
        armor = 0;
        placement = 0;
        stormAcc = 0f;
        swingTimer = 0f;
        swingT = 1f;
        swingVariant = 0;
        comboIdx = -1;
        comboT = 9f;
        shoveX = 0f;
        shoveY = 0f;
        slotWeapon[0] = WeaponDef.PISTOL;
        slotWeapon[1] = -1;
        slotAmmo[0] = 0;
        slotAmmo[1] = 0;
        slotReserve[0] = 0;
        slotReserve[1] = 0;
        activeSlot = 0;
        backpack = 0;
        switchRequest = false;
        switchTimer = 0f;
        respawnTimer = 0f;
        spawnProtect = 0f;
        kills = 0;
        deaths = 0;
        moveX = 0f;
        moveY = 0f;
        firing = false;
        pulls = 0;
        handledPulls = 0;
        pullBuffer = 0f;
        reloadRequest = false;
        reloadPullMark = 0;
        pickupRequest = false;
        pickupRequestIndex = -1;
        dodgeRequest = false;
        rollTimer = 0f;
        dodgeCooldown = 0f;
        hitFlash = 0f;
        muzzleFlash = 0f;
        interpValid = false;
        visX = 0f;
        visY = 0f;
        weapon.equip(WeaponDef.ALL[WeaponDef.PISTOL]);
        // a fighter starts with the pistol, a full magazine and two spare ones
        slotAmmo[0] = weapon.ammo;
        slotReserve[0] = weapon.def.magSize * 2;
        weapon.reserve = slotReserve[0];
    }
}
