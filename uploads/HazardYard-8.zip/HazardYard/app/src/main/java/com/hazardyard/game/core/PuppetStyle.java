package com.hazardyard.game.core;

/**
 * What a {@link Puppet} looks like: skin, clothes, hair, wounds and build. Plain numbers so a style can be filled in
 * without allocating (see {@code ZombieLook}), and so a zombie looks the same on every device.
 */
public final class PuppetStyle {
    public static final int OUTFIT_TEE = 0, OUTFIT_HOODIE = 1, OUTFIT_OFFICE = 2, OUTFIT_COAT = 3, OUTFIT_POLICE = 4,
            OUTFIT_VEST = 5, OUTFIT_TANK = 6, OUTFIT_APRON = 7, OUTFIT_GOWN = 8, OUTFIT_BARE = 9, OUTFIT_SOLDIER = 10;
    public static final int HAIR_BALD = 0, HAIR_SHORT = 1, HAIR_MESSY = 2, HAIR_LONG = 3, HAIR_CAP = 4, HAIR_HARDHAT = 5, HAIR_HELMET = 6;
    public static final int W_CHEST = 1, W_HEAD = 2, W_ARM = 4, W_LEG = 8, W_NECK = 16, W_JAW = 32;

    public int build = Puppet.B_NORMAL;
    public int skin, skinShade, shirt, shirtShade, sleeve, trim, pants, pantsShade, shoe, hair, eye, outline, blood;
    public int outfit, hairStyle, wounds;
    /** 0 bare arms, 1 sleeves to the elbow, 2 long sleeves; and long trousers (the whole leg in the trouser colour). */
    public int sleeveLen = 2;
    public boolean longPants = true;
    public float scale = 1f, width = 1f;
    /** A soldier's helmet colour, the accent of its player. */
    public int accent;

    public void copyFrom(PuppetStyle o) {
        build = o.build; skin = o.skin; skinShade = o.skinShade; shirt = o.shirt; shirtShade = o.shirtShade; sleeve = o.sleeve; trim = o.trim;
        pants = o.pants; pantsShade = o.pantsShade; shoe = o.shoe; hair = o.hair; eye = o.eye; outline = o.outline; blood = o.blood;
        outfit = o.outfit; hairStyle = o.hairStyle; wounds = o.wounds; sleeveLen = o.sleeveLen; longPants = o.longPants;
        scale = o.scale; width = o.width; accent = o.accent;
    }
}
