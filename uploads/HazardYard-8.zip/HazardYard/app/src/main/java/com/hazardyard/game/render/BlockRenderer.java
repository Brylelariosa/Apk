package com.hazardyard.game.render;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;

import com.hazardyard.game.core.GameConfig;
import com.hazardyard.game.core.TileMap;
import com.hazardyard.game.render.model.Projection;
import com.hazardyard.game.render.model.SceneBuffer;

/**
 * Draws the solid things of the arena with real height, using the same oblique projection as the 3D
 * models: walls and crates as boxes (a lit top, a south face and a west face; faces that touch a
 * neighbouring wall are skipped, so a long wall reads as one solid), round pillars and tanks as shaded
 * cylinders, angled corner pieces as triangular prisms and fences as thin chain-link lines. Blocks
 * must be drawn in {@link TileMap#blocks} order (south edge first) so closer ones overlap farther ones.
 */
final class BlockRenderer {
    static final float WALL_H = 24f;
    static final float CRATE_H = 15f;
    static final float FENCE_H = 9f;
    static final float PILLAR_H = 24f;
    static final float TANK_H = 27f;
    static final float TREE_H = 36f;
    static final float ROCK_H = 14f;
    private static final float T = GameConfig.TILE;
    private static final float AMBIENT = 0.46f;
    private static final float SHADOW_X = 0.35f;
    private static final float SHADOW_Y = 0.28f;

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final float[] segs = new float[512];
    private final float[] tri = new float[6];

    BlockRenderer() {
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeCap(Paint.Cap.ROUND);
    }

    /** Kinds that are drawn as boxes here (pools are part of the floor). */
    static boolean isBox(int kind) {
        return kind != TileMap.WATER && kind != TileMap.FLOOR;
    }

    static float heightOf(int kind) {
        switch (kind) {
            case TileMap.WALL:
            case TileMap.WEDGE_NW:
            case TileMap.WEDGE_NE:
            case TileMap.WEDGE_SW:
            case TileMap.WEDGE_SE: return WALL_H;
            case TileMap.CRATE: return CRATE_H;
            case TileMap.PILLAR: return PILLAR_H;
            case TileMap.TANK: return TANK_H;
            case TileMap.TREE: return TREE_H;
            case TileMap.ROCK: return ROCK_H;
            default: return FENCE_H;
        }
    }

    /** True when the block at index {@code b} can touch the visible rectangle (with room for its height). */
    static boolean inView(TileMap map, int b, float vx0, float vx1, float vy0, float vy1) {
        int o = b * 5;
        float h = heightOf(map.blocks[o + 4]);
        float x0 = map.blocks[o] * T;
        float y0 = map.blocks[o + 1] * T;
        float x1 = x0 + map.blocks[o + 2] * T + Projection.LEAN * h + SHADOW_X * h;
        float y1 = y0 + map.blocks[o + 3] * T + SHADOW_Y * h;
        return !(x1 < vx0 || x0 > vx1 || y1 < vy0 || y0 - Projection.TILT * h > vy1);
    }

    // ------------------------------------------------------------------ shadows

    void drawShadows(Canvas c, TileMap map, float vx0, float vx1, float vy0, float vy1) {
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(0x44000000);
        for (int b = 0; b < map.blockCount; b++) {
            int o = b * 5;
            int kind = map.blocks[o + 4];
            if (kind == TileMap.FENCE || kind == TileMap.FENCE_JOINT || kind == TileMap.WATER) continue;      // water lies flat: no shadow
            if (!inView(map, b, vx0, vx1, vy0, vy1)) continue;
            float h = heightOf(kind);
            float dx = SHADOW_X * h;
            float dy = SHADOW_Y * h;
            float x0 = map.blocks[o] * T;
            float y0 = map.blocks[o + 1] * T;
            float x1 = x0 + map.blocks[o + 2] * T;
            float y1 = y0 + map.blocks[o + 3] * T;
            if (kind == TileMap.PILLAR || kind == TileMap.TANK) {
                columnShadow(c, (x0 + x1) * 0.5f, (y0 + y1) * 0.5f,
                        kind == TileMap.TANK ? TileMap.TANK_RADIUS : TileMap.PILLAR_RADIUS, dx, dy);
                continue;
            }
            if (kind == TileMap.TREE) {            // the crown's shadow lies on the ground, down and to the right of the trunk
                c.drawCircle((x0 + x1) * 0.5f + dx * 0.55f, (y0 + y1) * 0.5f + dy * 0.55f + 3f, treeShadowRadius((int) Math.floor(x0 / T), (int) Math.floor(y0 / T)), fill);
                continue;
            }
            if (kind == TileMap.ROCK) {
                c.drawCircle((x0 + x1) * 0.5f + dx * 0.9f, (y0 + y1) * 0.5f + dy * 0.9f, 12f, fill);
                continue;
            }
            if (TileMap.isWedge((byte) kind)) {
                wedgeShadow(c, (byte) kind, x0, y0, dx, dy);
                continue;
            }
            path.reset();
            path.moveTo(x0, y0);
            path.lineTo(x1, y0);
            path.lineTo(x1 + dx, y0 + dy);
            path.lineTo(x1 + dx, y1 + dy);
            path.lineTo(x0 + dx, y1 + dy);
            path.lineTo(x0, y1);
            path.close();
            c.drawPath(path, fill);
        }
    }

    // ------------------------------------------------------------------ boxes

    void draw(Canvas c, TileMap map, MapTheme th, int b) {
        int o = b * 5;
        int bx = map.blocks[o];
        int by = map.blocks[o + 1];
        int bw = map.blocks[o + 2];
        int bh = map.blocks[o + 3];
        int kind = map.blocks[o + 4];
        if (kind == TileMap.WALL) {
            // concrete buildings (warehouses, bunkers, the compound wall) have their own colours
            MapTheme wt = map.hasTerrain() && map.groundAt(bx, by) == TileMap.G_CONCRETE ? MapTheme.concreteVariant(th) : th;
            drawWall(c, map, wt, bx, by, bw, bh);
        }
        else if (kind == TileMap.CRATE) {
            for (int yy = 0; yy < bh; yy++) {
                for (int xx = 0; xx < bw; xx++) drawCrate(c, th, (bx + xx) * T, (by + yy) * T);
            }
        } else if (kind == TileMap.FENCE) drawFence(c, map, th, bx, by, bw, bh);
        else if (kind == TileMap.FENCE_JOINT) drawFenceJoint(c, map, th, bx, by);
        else if (kind == TileMap.TREE) drawTree(c, bx, by);
        else if (kind == TileMap.ROCK) drawRock(c, bx, by);
        else if (kind == TileMap.PILLAR) drawColumn(c, th, (bx + 0.5f) * T, (by + 0.5f) * T, TileMap.PILLAR_RADIUS, PILLAR_H, 11, false);
        else if (kind == TileMap.TANK) drawColumn(c, th, (bx + 1f) * T, (by + 1f) * T, TileMap.TANK_RADIUS, TANK_H, 16, true);
        else if (TileMap.isWedge((byte) kind)) drawWedge(c, map, th, (byte) kind, bx, by);
    }

    // ------------------------------------------------------------------ trees and boulders

    private static final int[] CROWN_DARK = {0xFF1F4F27, 0xFF2A5A25, 0xFF365F22, 0xFF1B4A34};
    private static final int[] CROWN_MID = {0xFF2E7A36, 0xFF3A8230, 0xFF4A8A2C, 0xFF2A7A4A};
    private static final int[] CROWN_LIGHT = {0xFF4FA24A, 0xFF5FAA3C, 0xFF72AE36, 0xFF4AA064};

    /** Where the camera's player stands: a crown right over them turns see-through so they are never lost in a forest. */
    private float focusX = -1e9f, focusY = -1e9f;

    void setFocus(float x, float y, float time) {
        windTime = time;
        focusX = x;
        focusY = y;
    }

    // ------------------------------------------------------------------ trees: four kinds, every one a different size

    static final int T_OAK = 0, T_PINE = 1, T_BIRCH = 2, T_BUSHY = 3;

    /** The kind of tree on a tile (the same on every device). */
    static int treeKind(int tx, int ty) {
        int h = FloorRenderer.hash(tx * 7 + 3, ty * 13 + 5);
        int k = (h >>> 8) & 15;
        if (k < 7) return T_OAK;
        if (k < 11) return T_PINE;
        if (k < 13) return T_BIRCH;
        return T_BUSHY;
    }

    /** How big this tree is compared with an average one (0.72 .. 1.3). */
    static float treeScale(int tx, int ty) {
        int h = FloorRenderer.hash(tx * 7 + 3, ty * 13 + 5);
        return 0.72f + ((h >>> 12) & 15) * 0.0386f;
    }

    /** Radius of the shadow a tree throws on the ground. */
    static float treeShadowRadius(int tx, int ty) {
        int kind = treeKind(tx, ty);
        float sc = treeScale(tx, ty);
        return (kind == T_PINE ? 14f : (kind == T_BIRCH ? 12f : 17f)) * sc;
    }

    /** Set by the renderers every frame: the clock for the leaves' sway. */
    float windTime;
    /** Whether the finer details (leaf speckle, rim shading) are drawn; off on the light graphics levels. */
    private boolean detail = true;

    void setDetail(boolean on) {
        detail = on;
    }

    /** Leaves and shading that give a crown some texture: a rim, light and dark specks, a darker underside. */
    private void crownTexture(Canvas c, float ccx, float ccy, float r, int h, boolean over, int litLeaf, int darkLeaf) {
        if (!detail || over) return;
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(1.3f);
        stroke.setColor(0x33102A12);
        c.drawCircle(ccx, ccy + r * 0.05f, r * 0.98f, stroke);
        fill.setStyle(Paint.Style.FILL);
        for (int k = 0; k < 7; k++) {
            int hk = FloorRenderer.hash(h + k * 29, k * 7 + 11);
            double ang = (hk & 0x3FF) / 1023.0 * Math.PI * 2.0;
            float rad = r * (0.15f + 0.78f * (((hk >> 10) & 0xFF) / 255f));
            float sx = ccx + (float) Math.cos(ang) * rad;
            float sy = ccy + (float) Math.sin(ang) * rad * 0.92f;
            boolean light = (k & 1) == 0 && sy < ccy + r * 0.1f;
            fill.setColor(light ? ((litLeaf & 0x00FFFFFF) | 0x80000000) : ((darkLeaf & 0x00FFFFFF) | 0x55000000));
            c.drawCircle(sx, sy, 1.2f + ((hk >> 18) & 3) * 0.45f, fill);
        }
    }

    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);

    private void blob(Canvas c, float x, float y, float r, int color, int alpha) {
        fill.setColor((color & 0x00FFFFFF) | (alpha << 24));
        c.drawCircle(x, y, r, fill);
    }

    void drawTree(Canvas c, int tx, int ty) {
        final float cx = (tx + 0.5f) * T;
        final float cy = (ty + 0.5f) * T;
        int h = FloorRenderer.hash(tx * 7 + 3, ty * 13 + 5);
        int kind = treeKind(tx, ty);
        float sc = treeScale(tx, ty);
        int shade = (h >> 4) & 3;
        float sway = (float) Math.sin(windTime * 1.35f + (h & 255) * 0.09f) * 1.15f * sc;
        fill.setStyle(Paint.Style.FILL);
        float crownR = (kind == T_PINE ? 13f : (kind == T_BIRCH ? 12.5f : (kind == T_BUSHY ? 14f : 17.5f))) * sc;
        float crownZ = (kind == T_PINE ? 24f : (kind == T_BIRCH ? 32f : (kind == T_BUSHY ? 19f : 30f))) * sc;
        float ccx = cx + Projection.LEAN * crownZ + sway;
        float ccy = cy - Projection.TILT * crownZ;
        float dx = focusX - ccx;
        float dy = (focusY - 8f) - ccy;
        boolean over = cy > focusY - 4f && dx * dx + dy * dy < (crownR + 10f) * (crownR + 10f);
        int alpha = over ? 105 : 255;
        // ---- trunk
        float trunk = (kind == T_BUSHY ? 11f : (kind == T_PINE ? 15f : 24f)) * sc;
        float wBase = (kind == T_BIRCH ? 2.4f : 3.6f) * sc, wTop = wBase * 0.7f;
        int bark = kind == T_BIRCH ? 0xFFD8D4C8 : 0xFF4A2F1A, barkLight = kind == T_BIRCH ? 0xFFF0EEE6 : 0xFF6B4527;
        fill.setColor(bark);
        quad(c, cx - wBase, cy + 2f, cx + wBase, cy + 2f, cx + wTop + Projection.LEAN * trunk, cy - Projection.TILT * trunk,
                cx - wTop + Projection.LEAN * trunk, cy - Projection.TILT * trunk, fill);
        fill.setColor(barkLight);
        quad(c, cx - wBase * 0.25f, cy + 2f, cx + wBase, cy + 2f, cx + wTop + Projection.LEAN * trunk, cy - Projection.TILT * trunk,
                cx + wTop * 0.15f + Projection.LEAN * trunk, cy - Projection.TILT * trunk, fill);
        if (kind == T_BIRCH) {
            fill.setColor(0xFF3A3A38);
            for (int i = 0; i < 4; i++) {
                float z = (5f + i * 5.5f) * sc;
                c.drawRect(cx - wBase * 0.7f + Projection.LEAN * z, cy - Projection.TILT * z, cx + wBase * 0.1f + Projection.LEAN * z, cy - Projection.TILT * z + 1.3f * sc, fill);
            }
        }
        // a root flare at the foot
        fill.setColor(bark);
        c.drawOval(cx - wBase * 1.5f, cy - 0.5f, cx + wBase * 1.5f, cy + 3.8f, fill);
        // ---- crown
        switch (kind) {
            case T_PINE: {
                // stacked tiers, each a little smaller and lighter than the one below
                int[] dark = {0xFF1A3F26, 0xFF1F4A2A, 0xFF1D4A38, 0xFF25502A};
                for (int i = 0; i < 4; i++) {
                    float tz = (9f + i * 7.2f) * sc;
                    float r = (14.5f - i * 3.2f) * sc;
                    float tcx = cx + Projection.LEAN * tz + sway * (0.4f + 0.2f * i), tcy = cy - Projection.TILT * tz;
                    blob(c, tcx, tcy + r * 0.12f, r, dark[shade], alpha);
                    blob(c, tcx - r * 0.06f, tcy - r * 0.08f, r * 0.86f, i == 0 ? 0xFF2A6034 : 0xFF2F6B3A, alpha);
                    if (!over) {
                        blob(c, tcx - r * 0.3f, tcy - r * 0.32f, r * 0.42f, 0xFF4C8A4A, 255);
                        fill.setColor(0x33000000);
                        c.drawCircle(tcx + r * 0.34f, tcy + r * 0.4f, r * 0.24f, fill);
                    }
                }
                float tz = 38f * sc;
                blob(c, cx + Projection.LEAN * tz + sway * 1.1f, cy - Projection.TILT * tz, 3.2f * sc, 0xFF3F7A44, alpha);
                break;
            }
            case T_BIRCH: {
                // a loose crown of several small clusters
                float[][] cl = {{0f, 0f, 1f}, {-0.7f, 0.5f, 0.75f}, {0.75f, 0.35f, 0.7f}, {-0.2f, -0.75f, 0.7f}, {0.5f, -0.55f, 0.6f}};
                for (int i = 0; i < cl.length; i++) {
                    float r = crownR * 0.62f * cl[i][2];
                    blob(c, ccx + cl[i][0] * crownR * 0.75f, ccy + cl[i][1] * crownR * 0.7f, r, 0xFF6E9A3A, alpha);
                }
                for (int i = 0; i < cl.length; i++) {
                    float r = crownR * 0.5f * cl[i][2];
                    blob(c, ccx + cl[i][0] * crownR * 0.75f - 1.2f, ccy + cl[i][1] * crownR * 0.7f - 1.4f, r, 0xFF93BC4C, alpha);
                }
                if (!over) blob(c, ccx - crownR * 0.35f, ccy - crownR * 0.4f, crownR * 0.22f, 0xFFC4DC78, 255);
                crownTexture(c, ccx, ccy, crownR * 1.02f, h, over, 0xFFD6EC88, 0xFF4A6E24);
                break;
            }
            case T_BUSHY: {
                blob(c, ccx, ccy + 1.5f, crownR, CROWN_DARK[shade], alpha);
                blob(c, ccx - crownR * 0.18f, ccy - crownR * 0.1f, crownR * 0.84f, CROWN_MID[shade], alpha);
                blob(c, ccx + crownR * 0.42f, ccy + crownR * 0.1f, crownR * 0.5f, CROWN_MID[shade], alpha);
                blob(c, ccx - crownR * 0.36f, ccy - crownR * 0.34f, crownR * 0.46f, CROWN_LIGHT[shade], alpha);
                crownTexture(c, ccx, ccy, crownR, h, over, 0xFF9CD060, 0xFF123A1C);
                break;
            }
            default: {
                // an oak: a big round crown made of overlapping clusters, dark below and sunlit above
                float[][] cl = {{-0.52f, 0.30f, 0.62f}, {0.55f, 0.28f, 0.6f}, {0f, 0.46f, 0.55f}, {-0.45f, -0.32f, 0.6f}, {0.46f, -0.34f, 0.58f}, {0f, -0.1f, 0.78f}};
                for (int i = 0; i < cl.length; i++) blob(c, ccx + cl[i][0] * crownR, ccy + cl[i][1] * crownR, crownR * cl[i][2] + 1.3f, CROWN_DARK[shade], alpha);
                for (int i = 0; i < cl.length; i++) blob(c, ccx + cl[i][0] * crownR - 0.8f, ccy + cl[i][1] * crownR - 1.2f, crownR * cl[i][2], CROWN_MID[shade], alpha);
                blob(c, ccx - crownR * 0.28f, ccy - crownR * 0.34f, crownR * 0.5f, CROWN_LIGHT[shade], alpha);
                blob(c, ccx + crownR * 0.22f, ccy - crownR * 0.46f, crownR * 0.3f, CROWN_LIGHT[shade], alpha);
                if (!over) {
                    fill.setColor(0x33FFFFFF);
                    c.drawCircle(ccx - crownR * 0.42f, ccy - crownR * 0.5f, crownR * 0.16f, fill);
                    fill.setColor(0x22000000);
                    c.drawCircle(ccx + crownR * 0.42f, ccy + crownR * 0.5f, crownR * 0.22f, fill);
                }
                crownTexture(c, ccx, ccy, crownR * 1.05f, h, over, 0xFF9CD060, 0xFF123A1C);
                break;
            }
        }
    }

    void drawRock(Canvas c, int tx, int ty) {
        final float cx = (tx + 0.5f) * T;
        final float cy = (ty + 0.5f) * T + 3f;
        int h = FloorRenderer.hash(tx * 11 + 1, ty * 3 + 9);
        float r = 12f + (h & 3);
        final int slices = 3;
        for (int s = 0; s <= slices; s++) {
            float k = s / (float) slices;
            float lift = ROCK_H * k;
            float sc = 1f - 0.18f * k;
            int col = s == slices ? 0xFFA0A4AC : mix(0xFF5E6168, 0xFF8B8F97, k);
            rockPoly(c, cx + Projection.LEAN * lift, cy - Projection.TILT * lift, r * sc, h, col);
        }
        // a lit facet and a moss patch
        fill.setColor(0x44FFFFFF);
        c.drawCircle(cx + Projection.LEAN * ROCK_H - r * 0.28f, cy - Projection.TILT * ROCK_H - r * 0.22f, r * 0.28f, fill);
        if ((h & 12) == 0) {
            fill.setColor(0x884F8A3A);
            c.drawCircle(cx + Projection.LEAN * ROCK_H + r * 0.30f, cy - Projection.TILT * ROCK_H + r * 0.16f, r * 0.24f, fill);
        }
    }

    private void rockPoly(Canvas c, float cx, float cy, float r, int h, int color) {
        path.reset();
        for (int k = 0; k < 8; k++) {
            double a = Math.PI / 4 * k + 0.2;
            float rad = r * (0.82f + 0.22f * (((h >> (k * 2)) & 3) / 3f));
            float x = cx + (float) Math.cos(a) * rad;
            float y = cy + (float) Math.sin(a) * rad * 0.82f;
            if (k == 0) path.moveTo(x, y);
            else path.lineTo(x, y);
        }
        path.close();
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(color);
        c.drawPath(path, fill);
    }

    // ------------------------------------------------------------------ round things

    /** The shadow of a cylinder: a capsule from its base towards the shadow direction. */
    private void columnShadow(Canvas c, float cx, float cy, float r, float dx, float dy) {
        float len = (float) Math.sqrt(dx * dx + dy * dy);
        float px = -dy / len * r;
        float py = dx / len * r;
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(0x44000000);
        path.reset();
        path.moveTo(cx + px, cy + py);
        path.lineTo(cx - px, cy - py);
        path.lineTo(cx - px + dx, cy - py + dy);
        path.lineTo(cx + px + dx, cy + py + dy);
        path.close();
        c.drawPath(path, fill);
        c.drawCircle(cx, cy, r, fill);
        c.drawCircle(cx + dx, cy + dy, r, fill);
    }

    /** The shadow of an angled piece: the triangle and its copies pushed along the shadow direction, filled as one shape. */
    private void wedgeShadow(Canvas c, byte kind, float left, float top, float dx, float dy) {
        TileMap.wedgeCorners(kind, left, top, tri);
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(0x44000000);
        path.reset();
        for (int k = 0; k <= 2; k++) {
            float f = k * 0.5f;
            path.moveTo(tri[0] + dx * f, tri[1] + dy * f);
            path.lineTo(tri[2] + dx * f, tri[3] + dy * f);
            path.lineTo(tri[4] + dx * f, tri[5] + dy * f);
            path.close();
        }
        // the three sides of the prism swept along the shadow direction
        for (int e = 0; e < 3; e++) {
            int a = e * 2;
            int b = ((e + 1) % 3) * 2;
            path.moveTo(tri[a], tri[a + 1]);
            path.lineTo(tri[b], tri[b + 1]);
            path.lineTo(tri[b] + dx, tri[b + 1] + dy);
            path.lineTo(tri[a] + dx, tri[a + 1] + dy);
            path.close();
        }
        c.drawPath(path, fill);
    }

    /**
     * A vertical cylinder in the oblique projection: the half of its side that turns towards the
     * viewer is drawn as lit strips (light comes from the north-west, like on the soldiers), then the
     * top disc. Tanks get a hazard band, bands and a hatch.
     */
    private void drawColumn(Canvas c, MapTheme th, float cx, float cy, float r, float h, int strips, boolean tank) {
        final float lean = Projection.LEAN * h;
        final float rise = Projection.TILT * h;
        // outward normals facing the viewer: angles from a0 to a0 + PI (see Projection.facesViewer)
        final float a0 = (float) Math.atan2(Projection.LEAN, Projection.TILT);
        fill.setStyle(Paint.Style.FILL);
        float prevX = cx + (float) Math.cos(a0) * r;
        float prevY = cy + (float) Math.sin(a0) * r;
        for (int k = 1; k <= strips; k++) {
            float ang = a0 + (float) Math.PI * k / strips;
            float x = cx + (float) Math.cos(ang) * r;
            float y = cy + (float) Math.sin(ang) * r;
            float mid = a0 + (float) Math.PI * (k - 0.5f) / strips;
            float nx = (float) Math.cos(mid);
            float ny = (float) Math.sin(mid);
            float diffuse = Math.max(0f, (nx * -0.46f + ny * -0.38f) / 0.99f);
            fill.setColor(SceneBuffer.shade(th.wallFront, AMBIENT + (1.1f - AMBIENT) * diffuse));
            quad(c, prevX, prevY, x, y, x + lean, y - rise, prevX + lean, prevY - rise, fill);
            if (tank) {
                // hazard band low on the tank, in the theme's accent colour
                fill.setColor(SceneBuffer.shade(th.accent, 0.55f + 0.5f * diffuse));
                float f0 = 0.10f;
                float f1 = 0.22f;
                quad(c, prevX + lean * f0, prevY - rise * f0, x + lean * f0, y - rise * f0,
                        x + lean * f1, y - rise * f1, prevX + lean * f1, prevY - rise * f1, fill);
            } else {
                fill.setColor(0x30000000);
                quad(c, prevX, prevY, x, y, x + lean * 0.14f, y - rise * 0.14f, prevX + lean * 0.14f, prevY - rise * 0.14f, fill);
            }
            prevX = x;
            prevY = y;
        }
        if (tank) {
            // two seams around the body
            line.setColor(0x44101820);
            line.setStrokeWidth(1f);
            for (int band = 0; band < 2; band++) {
                float f = band == 0 ? 0.52f : 0.80f;
                int n = 0;
                float px = cx + (float) Math.cos(a0) * r + lean * f;
                float py = cy + (float) Math.sin(a0) * r - rise * f;
                for (int k = 1; k <= strips && n + 4 <= segs.length; k++) {
                    float ang = a0 + (float) Math.PI * k / strips;
                    float x = cx + (float) Math.cos(ang) * r + lean * f;
                    float y = cy + (float) Math.sin(ang) * r - rise * f;
                    segs[n++] = px;
                    segs[n++] = py;
                    segs[n++] = x;
                    segs[n++] = y;
                    px = x;
                    py = y;
                }
                c.drawLines(segs, 0, n, line);
            }
        }
        // top disc
        float tx = cx + lean;
        float ty = cy - rise;
        fill.setColor(th.wallTop);
        c.drawCircle(tx, ty, r, fill);
        fill.setColor(0x26FFFFFF);
        c.drawCircle(tx - r * 0.12f, ty - r * 0.12f, r * 0.72f, fill);
        line.setColor(th.wallTrim);
        line.setStrokeWidth(0.9f);
        c.drawCircle(tx, ty, r - 1.2f, line);
        if (tank) {
            line.setColor(Palette.withAlpha(th.wallTrim, 200));
            c.drawCircle(tx, ty, r * 0.55f, line);
            fill.setColor(th.wallFront);
            c.drawCircle(tx + r * 0.1f, ty - r * 0.08f, r * 0.17f, fill);   // the hatch
        }
    }

    // ------------------------------------------------------------------ angled corner pieces

    /** A triangular prism: the diagonal face, the legs that are not hidden by a neighbour, and the lit top. */
    private void drawWedge(Canvas c, TileMap map, MapTheme th, byte kind, int tx, int ty) {
        final float h = WALL_H;
        final float lean = Projection.LEAN * h;
        final float rise = Projection.TILT * h;
        TileMap.wedgeCorners(kind, tx * T, ty * T, tri);
        fill.setStyle(Paint.Style.FILL);
        for (int e = 0; e < 3; e++) {
            int a = e * 2;
            int b = ((e + 1) % 3) * 2;
            int o = ((e + 2) % 3) * 2;
            float ax = tri[a], ay = tri[a + 1], bx = tri[b], by = tri[b + 1];
            float nx = by - ay;
            float ny = -(bx - ax);
            if (nx * (tri[o] - ax) + ny * (tri[o + 1] - ay) > 0f) {
                nx = -nx;
                ny = -ny;
            }
            float len = (float) Math.sqrt(nx * nx + ny * ny);
            nx /= len;
            ny /= len;
            if (!Projection.facesViewer(nx, ny, 0f)) continue;
            // a leg that sits against another solid tile is not visible
            if (Math.abs(nx) > 0.99f || Math.abs(ny) > 0.99f) {
                int ntx = tx + (int) Math.signum(nx);
                int nty = ty + (int) Math.signum(ny);
                byte nk = map.kindAt(ntx, nty);
                if (nk == TileMap.WALL || nk == TileMap.CRATE || TileMap.isWedge(nk)) continue;
            }
            float ws = Math.max(0f, -nx);
            float wf = Math.max(0f, ny);
            float sum = ws + wf;
            int base = sum > 1e-4f ? mix(th.wallFront, th.wallSide, ws / sum) : th.wallFront;
            fill.setColor(SceneBuffer.shade(base, 1f - 0.18f * Math.max(0f, nx)));
            quad(c, ax, ay, bx, by, bx + lean, by - rise, ax + lean, ay - rise, fill);
            fill.setColor(0x38000000);
            quad(c, ax, ay, bx, by, bx + lean * 0.16f, by - rise * 0.16f, ax + lean * 0.16f, ay - rise * 0.16f, fill);
        }
        path.reset();
        path.moveTo(tri[0] + lean, tri[1] - rise);
        path.lineTo(tri[2] + lean, tri[3] - rise);
        path.lineTo(tri[4] + lean, tri[5] - rise);
        path.close();
        fill.setColor(th.wallTop);
        c.drawPath(path, fill);
        line.setColor(th.wallTrim);
        line.setStrokeWidth(0.9f);
        c.drawPath(path, line);
        // bright lip along the diagonal
        line.setColor(0x55FFFFFF);
        line.setStrokeWidth(1.6f);
        c.drawLine(tri[2] + lean, tri[3] - rise, tri[4] + lean, tri[5] - rise, line);
    }

    private static int mix(int a, int b, float t) {
        int ar = (a >> 16) & 0xFF, ag = (a >> 8) & 0xFF, ab = a & 0xFF;
        int br = (b >> 16) & 0xFF, bg = (b >> 8) & 0xFF, bb = b & 0xFF;
        return 0xFF000000 | ((int) (ar + (br - ar) * t) << 16) | ((int) (ag + (bg - ag) * t) << 8) | (int) (ab + (bb - ab) * t);
    }

    private void drawWall(Canvas c, TileMap map, MapTheme th, int bx, int by, int bw, int bh) {
        final float h = WALL_H;
        final float lean = Projection.LEAN * h;
        final float rise = Projection.TILT * h;
        float x0 = bx * T;
        float y0 = by * T;
        float x1 = x0 + bw * T;
        float y1 = y0 + bh * T;
        fill.setStyle(Paint.Style.FILL);

        // West face, in runs of rows that are not hidden by a wall to the west.
        fill.setColor(th.wallSide);
        int r = 0;
        while (r < bh) {
            if (map.kindAt(bx - 1, by + r) == TileMap.WALL) {
                r++;
                continue;
            }
            int r0 = r;
            while (r < bh && map.kindAt(bx - 1, by + r) != TileMap.WALL) r++;
            float ya = y0 + r0 * T;
            float yb = y0 + r * T;
            quad(c, x0, ya, x0, yb, x0 + lean, yb - rise, x0 + lean, ya - rise, fill);
        }

        // South face, in runs of columns that are not hidden by a wall to the south.
        int col = 0;
        while (col < bw) {
            if (map.kindAt(bx + col, by + bh) == TileMap.WALL) {
                col++;
                continue;
            }
            int c0 = col;
            while (col < bw && map.kindAt(bx + col, by + bh) != TileMap.WALL) col++;
            float xa = x0 + c0 * T;
            float xb = x0 + col * T;
            fill.setColor(th.wallFront);
            quad(c, xa, y1, xb, y1, xb + lean, y1 - rise, xa + lean, y1 - rise, fill);
            // Darker foot and panel seams give the face some structure.
            fill.setColor(0x40000000);
            quad(c, xa, y1, xb, y1, xb + lean * 0.16f, y1 - rise * 0.16f, xa + lean * 0.16f, y1 - rise * 0.16f, fill);
            line.setColor(0x33101820);
            line.setStrokeWidth(1f);
            int n = 0;
            for (float x = xa + T; x < xb - 0.5f && n + 4 <= segs.length; x += T) {
                segs[n++] = x;
                segs[n++] = y1;
                segs[n++] = x + lean;
                segs[n++] = y1 - rise;
            }
            if (n > 0) c.drawLines(segs, 0, n, line);
        }

        // Top face: a lit slab with a bright lip along its exposed south edge.
        fill.setColor(th.wallTop);
        c.drawRect(x0 + lean, y0 - rise, x1 + lean + 0.4f, y1 - rise + 0.4f, fill);
        col = 0;
        while (col < bw) {
            if (map.kindAt(bx + col, by + bh) == TileMap.WALL) {
                col++;
                continue;
            }
            int c0 = col;
            while (col < bw && map.kindAt(bx + col, by + bh) != TileMap.WALL) col++;
            fill.setColor(0x40FFFFFF);
            c.drawRect(x0 + c0 * T + lean, y1 - rise - 2.4f, x0 + col * T + lean, y1 - rise, fill);
        }
        // A darker inset line marks the edge of the slab.
        line.setColor(th.wallTrim);
        line.setStrokeWidth(0.9f);
        c.drawRect(x0 + lean + 1.4f, y0 - rise + 1.4f, x1 + lean - 1.4f, y1 - rise - 1.4f, line);
    }

    private void drawCrate(Canvas c, MapTheme th, float tx, float ty) {
        final float h = CRATE_H;
        final float lean = Projection.LEAN * h;
        final float rise = Projection.TILT * h;
        final float g = 1.6f;
        float x0 = tx + g;
        float y0 = ty + g;
        float x1 = tx + T - g;
        float y1 = ty + T - g;
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(th.crateSide);
        quad(c, x0, y0, x0, y1, x0 + lean, y1 - rise, x0 + lean, y0 - rise, fill);
        fill.setColor(th.crateFront);
        quad(c, x0, y1, x1, y1, x1 + lean, y1 - rise, x0 + lean, y1 - rise, fill);
        fill.setColor(th.crateTop);
        c.drawRect(x0 + lean, y0 - rise, x1 + lean + 0.4f, y1 - rise + 0.4f, fill);

        // Frame, cross-bracing on top and planks on the front, all in one batched line call.
        float tx0 = x0 + lean, ty0 = y0 - rise, tx1 = x1 + lean, ty1 = y1 - rise;
        int n = 0;
        segs[n++] = tx0 + 3f; segs[n++] = ty0 + 3f; segs[n++] = tx1 - 3f; segs[n++] = ty1 - 3f;
        segs[n++] = tx1 - 3f; segs[n++] = ty0 + 3f; segs[n++] = tx0 + 3f; segs[n++] = ty1 - 3f;
        float fy = y1 - rise * 0.36f;
        segs[n++] = x0 + lean * 0.36f; segs[n++] = fy; segs[n++] = x1 + lean * 0.36f; segs[n++] = fy;
        fy = y1 - rise * 0.7f;
        segs[n++] = x0 + lean * 0.7f; segs[n++] = fy; segs[n++] = x1 + lean * 0.7f; segs[n++] = fy;
        line.setColor(Palette.withAlpha(th.crateDark, 190));
        line.setStrokeWidth(1.5f);
        c.drawLines(segs, 0, n, line);
        line.setColor(Palette.withAlpha(th.crateDark, 230));
        line.setStrokeWidth(1.1f);
        c.drawRect(tx0 + 1.2f, ty0 + 1.2f, tx1 - 1.2f, ty1 - 1.2f, line);
    }

    /**
     * Chain-link fence along the long side of the rectangle: translucent mesh between two rails and
     * posts, so players and bullets can be seen through it.
     */
    private void drawFence(Canvas c, TileMap map, MapTheme th, int bx, int by, int bw, int bh) {
        final float h = FENCE_H;
        final float lean = Projection.LEAN * h;
        final float rise = Projection.TILT * h;
        boolean horizontal = bw >= bh;
        int lines = horizontal ? bh : bw;
        for (int k = 0; k < lines; k++) {
            if (horizontal) {
                float y = (by + k + 0.5f) * T;
                float xa = bx * T + (joins(map, bx - 1, by + k) ? 0f : 2f);
                float xb = (bx + bw) * T - (joins(map, bx + bw, by + k) ? 0f : 2f);
                fenceRun(c, th, xa, y, xb, y, lean, rise);
            } else {
                float x = (bx + k + 0.5f) * T;
                float ya = by * T + (joins(map, bx + k, by - 1) ? 0f : 2f);
                float yb = (by + bh) * T - (joins(map, bx + k, by + bh) ? 0f : 2f);
                fenceRun(c, th, x, ya, x, yb, lean, rise);
            }
        }
    }

    /** True when a fence end touching this tile should reach all the way to it (another fence, or a solid wall). */
    private static boolean joins(TileMap map, int tx, int ty) {
        byte k = map.kindAt(tx, ty);
        return k == TileMap.FENCE || k == TileMap.WALL || k == TileMap.CRATE || k == TileMap.PILLAR || k == TileMap.TANK;
    }

    /** A tile where fence runs meet: one arm towards every neighbouring fence, and a post in the middle. */
    private void drawFenceJoint(Canvas c, TileMap map, MapTheme th, int tx, int ty) {
        final float h = FENCE_H;
        final float lean = Projection.LEAN * h;
        final float rise = Projection.TILT * h;
        int arms = map.fenceArms(tx, ty);
        float cx = (tx + 0.5f) * T;
        float cy = (ty + 0.5f) * T;
        if ((arms & TileMap.ARM_L) != 0) fenceRun(c, th, tx * T, cy, cx, cy, lean, rise);
        if ((arms & TileMap.ARM_R) != 0) fenceRun(c, th, cx, cy, (tx + 1) * T, cy, lean, rise);
        if ((arms & TileMap.ARM_U) != 0) fenceRun(c, th, cx, ty * T, cx, cy, lean, rise);
        if ((arms & TileMap.ARM_D) != 0) fenceRun(c, th, cx, cy, cx, (ty + 1) * T, lean, rise);
    }

    private void fenceRun(Canvas c, MapTheme th, float xa, float ya, float xb, float yb, float lean, float rise) {
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(Palette.withAlpha(th.fence, 46));
        quad(c, xa, ya, xb, yb, xb + lean, yb - rise, xa + lean, ya - rise, fill);
        // Mesh: diagonal wires across the panel.
        int n = 0;
        float len = (float) Math.hypot(xb - xa, yb - ya);
        int cells = Math.max(1, (int) (len / 6f));
        for (int i = 0; i < cells && n + 8 <= segs.length; i++) {
            float t0 = i / (float) cells;
            float t1 = (i + 1) / (float) cells;
            segs[n++] = xa + (xb - xa) * t0;
            segs[n++] = ya + (yb - ya) * t0;
            segs[n++] = xa + (xb - xa) * t1 + lean;
            segs[n++] = ya + (yb - ya) * t1 - rise;
            segs[n++] = xa + (xb - xa) * t0 + lean;
            segs[n++] = ya + (yb - ya) * t0 - rise;
            segs[n++] = xa + (xb - xa) * t1;
            segs[n++] = ya + (yb - ya) * t1;
        }
        line.setColor(Palette.withAlpha(th.fence, 110));
        line.setStrokeWidth(0.7f);
        c.drawLines(segs, 0, n, line);
        // Top rail and ground rail.
        line.setColor(Palette.withAlpha(th.fence, 235));
        line.setStrokeWidth(1.7f);
        c.drawLine(xa + lean, ya - rise, xb + lean, yb - rise, line);
        line.setStrokeWidth(1.2f);
        c.drawLine(xa, ya, xb, yb, line);
        // Posts at both ends and every three tiles.
        line.setStrokeWidth(2.4f);
        int posts = Math.max(1, Math.round(len / (T * 3f)));
        for (int i = 0; i <= posts; i++) {
            float t = i / (float) posts;
            float px = xa + (xb - xa) * t;
            float py = ya + (yb - ya) * t;
            c.drawLine(px, py, px + lean * 1.15f, py - rise * 1.15f, line);
        }
    }

    private void quad(Canvas c, float x0, float y0, float x1, float y1, float x2, float y2, float x3, float y3, Paint p) {
        path.reset();
        path.moveTo(x0, y0);
        path.lineTo(x1, y1);
        path.lineTo(x2, y2);
        path.lineTo(x3, y3);
        path.close();
        c.drawPath(path, p);
    }
}
