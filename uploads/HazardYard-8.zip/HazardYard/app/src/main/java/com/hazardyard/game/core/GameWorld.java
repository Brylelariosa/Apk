package com.hazardyard.game.core;

/**
 * The authoritative game rules, run only on the host: movement, shooting, projectiles, damage,
 * death, respawn, pickups and the match clock. It works on a {@link GameState} and reports what
 * happened through a {@link WorldListener}. Pure Java, no Android dependencies.
 */
public final class GameWorld {
    private final GameState st;
    private final WorldListener listener;
    private final CollisionSystem col;
    private final XorShift rng = new XorShift(0x5EED);
    private final float[] dir = new float[2];
    private int nextProjectileId = 1;
    /** Distance from every living opponent beyond which one spawn point is as good as another. */
    private static final float SPAWN_FAR_ENOUGH = 900f;

    public GameWorld(GameState st, WorldListener listener) {
        this.st = st;
        this.listener = listener;
        this.col = st.collision;
    }

    public GameState state() {
        return st;
    }

    // ------------------------------------------------------------------ roster

    public void addPlayer(int id, String name) {
        addPlayer(id, name, false);
    }

    /** Adds a human or, with {@code bot}, a computer-controlled player to slot {@code id}. */
    public void addPlayer(int id, String name, boolean bot) {
        Player p = st.players[id];
        p.connected = true;
        p.bot = bot;
        p.name = name;
        p.resetForMatch();
    }

    /** The survival rules, when this match is a survival match (see {@link #attachSurvival}). */
    private com.hazardyard.game.survival.SurvivalSim sim;

    /** Survival: creates the rules engine; must be called before the match starts. {@code out} receives what the others must hear and see. */
    public void attachSurvival(com.hazardyard.game.survival.SurvivalSim.Out out) {
        sim = new com.hazardyard.game.survival.SurvivalSim(st, st.survival, this, col, out);
        st.survival.sim = sim;
    }

    /** Survival: an inventory or crafting command from a survivor. */
    public void survivalCommand(int id, int cmd, int a, int b) {
        if (sim == null || id < 0 || id >= st.players.length || !st.players[id].connected) return;
        sim.command(st.players[id], cmd, a, b);
    }

    /** Survival: hurts a fighter without a bullet (a zombie's bite, hunger, a car). */
    public void hurt(int victimId, int amount, int attackerId, int causeId, float hx, float hy) {
        damage(victimId, attackerId, amount, causeId, 0xFF00 | (causeId & 0xFF), hx, hy);
    }

    public void removePlayer(int id) {
        Player p = st.players[id];
        if (!p.connected) return;
        if (sim != null) sim.playerLeft(p);
        if (st.mode.royale && st.phase == GameState.PHASE_PLAYING && p.alive) p.placement = Math.max(1, st.aliveCount());
        p.connected = false;
        p.bot = false;
        p.alive = false;
        p.weapon.cancelReload();
        p.moveX = 0f;
        p.moveY = 0f;
        p.firing = false;
        p.rollTimer = 0f;
        p.dodgeRequest = false;
        // A fighter who leaves a battle royale counts as eliminated: the match may have just become decided.
        if (st.mode.royale && st.phase == GameState.PHASE_PLAYING && st.aliveCount() <= 1) endMatch();
    }

    // ------------------------------------------------------------------ input (validated here)

    /**
     * Stores the latest controls of a player. Values are sanitised: a misbehaving client cannot
     * move faster than the speed limit or feed NaNs into the simulation.
     */
    public void setInput(int id, float moveX, float moveY, float aim, boolean firing, int seq) {
        if (id < 0 || id >= st.players.length) return;
        Player p = st.players[id];
        if (!p.connected) return;
        if (!MathUtil.isFinite(moveX) || !MathUtil.isFinite(moveY)) {
            moveX = 0f;
            moveY = 0f;
        }
        p.moveX = MathUtil.clamp(moveX, -1f, 1f);
        p.moveY = MathUtil.clamp(moveY, -1f, 1f);
        p.aimTarget = MathUtil.wrapAngle(aim);
        p.hasAimInput = true;
        if (firing && !p.firing) p.pulls++;
        p.firing = firing;
        p.lastInputSeq = seq & 0xFF;
    }

    public void requestReload(int id) {
        if (id < 0 || id >= st.players.length) return;
        Player p = st.players[id];
        if (p.connected) p.reloadRequest = true;
    }

    /**
     * Asks to take the weapon on pad {@code padIndex} (-1: the nearest one in reach). Nothing happens
     * unless the player really is close to an active pad; walking over a weapon never takes it.
     */
    public void requestPickup(int id, int padIndex) {
        if (id < 0 || id >= st.players.length) return;
        Player p = st.players[id];
        if (!p.connected) return;
        p.pickupRequest = true;
        p.pickupRequestIndex = padIndex;
    }

    /**
     * Asks for a dodge roll along the unit vector (dx, dy). A zero vector lets the host choose from
     * the player's latest input (moving: that way, standing still: the way they face). The request
     * is turned down in {@link #updatePlayer} when a roll is not allowed right now.
     */
    public void requestDodge(int id, float dx, float dy) {
        if (id < 0 || id >= st.players.length) return;
        Player p = st.players[id];
        if (!p.connected) return;
        if (!MathUtil.isFinite(dx) || !MathUtil.isFinite(dy)) {
            dx = 0f;
            dy = 0f;
        }
        p.dodgeRequest = true;
        p.dodgeReqX = dx;
        p.dodgeReqY = dy;
    }

    // ------------------------------------------------------------------ match flow

    public void startMatch() {
        st.projectiles.clear();
        st.effects.clear();
        for (int i = 0; i < st.pickups.length; i++) {
            Pickup pk = st.pickups[i];
            if (pk.dynamic) {
                pk.active = false;
                pk.item = -1;
            } else {
                pk.active = true;
            }
            pk.timer = 0f;
        }
        lootSeq = 0f;
        st.timeLeft = st.mode.matchSeconds;
        // Battleground begins with the choice of where to land: the countdown is the time the fighters have to pick
        st.countdown = st.mode.royale ? GameConfig.DROP_SELECT_SECONDS : GameConfig.COUNTDOWN_SECONDS;
        st.winnerId = -1;
        st.resultsTimer = 0f;
        if (st.mode.royale) {
            int fighters = 0;
            for (Player q : st.players) if (q.connected) fighters++;
            st.zone.reset(st.map, rng.nextInt(), fighters);
        }
        else st.zone.disable();
        for (int i = 0; i < st.players.length; i++) {
            Player p = st.players[i];
            if (!p.connected) continue;
            p.resetForMatch();
            placeAtSpawn(p);
            p.alive = true;
            if (sim != null) sim.onSpawned(p);
            if (st.mode.royale) {
                // a fighter who never picks lands where the spawn point put them; the bots pick for themselves
                p.dropX = p.x;
                p.dropY = p.y;
                p.dropSet = false;
                p.dropReady = p.bot;
            }
        }
        if (st.mode.royale) {
            for (int i = 0; i < st.players.length; i++) {
                Player p = st.players[i];
                if (p.connected && p.bot) chooseBotDrop(p);
            }
        }
        setPhase(GameState.PHASE_COUNTDOWN);
    }

    private void setPhase(int phase) {
        st.phase = phase;
        listener.onPhaseChanged(phase);
    }

    private void endMatch() {
        if (st.phase != GameState.PHASE_PLAYING) return;
        if (st.mode.royale) {
            endRoyale();
            return;
        }
        int best = -1;
        boolean tie = false;
        for (int i = 0; i < st.players.length; i++) {
            Player p = st.players[i];
            if (!p.connected) continue;
            if (best < 0) {
                best = i;
                tie = false;
                continue;
            }
            Player b = st.players[best];
            if (p.kills > b.kills || (p.kills == b.kills && p.deaths < b.deaths)) {
                best = i;
                tie = false;
            } else if (p.kills == b.kills && p.deaths == b.deaths) {
                tie = true;
            }
        }
        st.winnerId = tie ? -1 : best;
        st.resultsTimer = GameConfig.RESULTS_SECONDS;
        setPhase(GameState.PHASE_ENDED);
    }

    /**
     * Battle royale: the winner is the last fighter standing. If several are still alive when the clock runs out, the
     * one with the most health and armour left wins (then the most kills), and the rest are placed behind in that
     * order. When everybody went down together, whoever was the last to fall has place 1 already.
     */
    private void endRoyale() {
        int n = 0;
        int[] left = new int[st.players.length];
        for (int i = 0; i < st.players.length; i++) {
            Player p = st.players[i];
            if (p.connected && p.alive) left[n++] = i;
        }
        // Sort the survivors, best first (insertion sort: there are at most eight).
        for (int a = 1; a < n; a++) {
            int v = left[a];
            int b = a - 1;
            while (b >= 0 && royaleBetter(st.players[v], st.players[left[b]])) {
                left[b + 1] = left[b];
                b--;
            }
            left[b + 1] = v;
        }
        for (int r = 0; r < n; r++) st.players[left[r]].placement = r + 1;
        int winner = -1;
        for (int i = 0; i < st.players.length; i++) {
            Player p = st.players[i];
            if (p.connected && p.placement == 1) winner = i;
        }
        st.winnerId = winner;
        st.resultsTimer = GameConfig.RESULTS_SECONDS;
        setPhase(GameState.PHASE_ENDED);
    }

    private static boolean royaleBetter(Player a, Player b) {
        int ha = a.health + a.armor;
        int hb = b.health + b.armor;
        return ha > hb || (ha == hb && a.kills > b.kills);
    }

    // ------------------------------------------------------------------ simulation step

    public void step(float dt) {
        switch (st.phase) {
            case GameState.PHASE_COUNTDOWN:
                st.countdown -= dt;
                if (st.mode.royale && st.countdown > 0f && everyoneReadyToDrop()) st.countdown = 0f;
                if (st.countdown <= 0f) {
                    st.countdown = 0f;
                    if (st.mode.royale) beginDrop();
                    setPhase(GameState.PHASE_PLAYING);
                }
                break;
            case GameState.PHASE_PLAYING:
                if (!st.mode.survival) st.timeLeft -= dt;
                if (st.timeLeft <= 0f && !st.mode.survival) {
                    st.timeLeft = 0f;
                    endMatch();
                }
                break;
            case GameState.PHASE_ENDED:
                st.resultsTimer -= dt;
                if (st.resultsTimer <= 0f) {
                    st.resultsTimer = 0f;
                    setPhase(GameState.PHASE_FINISHED);
                }
                break;
            default:
                break;
        }
        boolean live = st.phase == GameState.PHASE_PLAYING;
        for (int i = 0; i < st.players.length; i++) {
            Player p = st.players[i];
            if (p.connected) updatePlayer(p, dt, live);
        }
        if (live) separatePlayers();
        updateProjectiles(dt);
        if (live) updatePickups(dt);
        if (live && sim != null) sim.step(dt);
        if (live && st.zone.enabled) {
            float fx = 0f, fy = 0f;
            int alive = 0;
            for (Player q : st.players) {
                if (!q.connected || !q.alive) continue;
                fx += q.x;
                fy += q.y;
                alive++;
            }
            if (alive > 0) st.zone.setFocus(fx / alive, fy / alive, alive);
            st.zone.step(dt);
            applyStorm(dt);
        }
    }

    /** Fighters outside the safe zone lose health in whole points, as fast as the current storm tier says. */
    private void applyStorm(float dt) {
        Zone z = st.zone;
        for (int i = 0; i < st.players.length; i++) {
            if (st.phase != GameState.PHASE_PLAYING) return;
            Player p = st.players[i];
            if (!p.connected || !p.alive || p.air > 0f || z.inside(p.x, p.y)) continue;
            p.stormAcc += z.dps * dt;
            if (p.stormAcc < 1f) continue;
            int points = (int) p.stormAcc;
            p.stormAcc -= points;
            p.health -= points;
            p.hitFlash = 0.12f;
            if (p.health <= 0) kill(p, -1, GameConfig.CAUSE_ZONE);
        }
    }

    private void updatePlayer(Player p, float dt, boolean live) {
        if (p.hitFlash > 0f) p.hitFlash -= dt;
        if (p.muzzleFlash > 0f) p.muzzleFlash -= dt;
        if (!p.alive) {
            p.dodgeRequest = false;
            p.pickupRequest = false;
            p.reloadRequest = false;
            if (live && !st.mode.royale) {
                p.respawnTimer -= dt;
                p.deadFor += dt;
                // a survivor always comes back: when the timer is up, or (whatever went wrong with it) shortly after it should have been
                if (p.respawnTimer <= 0f || p.deadFor > st.mode.respawnDelay + 2f) respawn(p);
            }
            return;
        }
        if (p.spawnProtect > 0f) p.spawnProtect -= dt;
        Weapon w = p.weapon;
        int ammoBefore = w.ammo;
        w.update(dt);
        if (w.ammo > ammoBefore) {
            if (sim != null) sim.onReloaded(p, w.ammo - ammoBefore);   // survival: the rounds come out of the pack
            else if (usesSlots(p)) p.slotReserve[p.activeSlot] = Math.max(0, p.slotReserve[p.activeSlot] - (w.ammo - ammoBefore));   // the gun's own supply
        }
        p.comboT += dt;
        if (p.switchTimer > 0f) p.switchTimer = Math.max(0f, p.switchTimer - dt);
        if (!live) {
            p.dodgeRequest = false;
            p.pickupRequest = false;
            return;
        }

        if (p.aimLock > 0f) p.aimLock -= dt;
        else if (p.hasAimInput) {
            p.aim = MathUtil.rotateToward(p.aim, p.aimTarget, GameConfig.PLAYER_TURN_RATE * dt);
        }
        if (p.air > 0f) {
            updateAirborne(p, dt);
            return;
        }
        Dodge.tickCooldown(p, dt);
        if (p.swingT < 1f) p.swingT = Math.min(1f, p.swingT + dt / Math.max(0.05f, p.swingDur));
        if (p.swingTimer > 0f) {
            p.swingTimer -= dt;
            if (p.swingTimer <= 0f) {
                p.swingTimer = 0f;
                resolveSwing(p);
                if (!p.alive) return;
            }
        }

        if (p.pickupRequest) {
            p.pickupRequest = false;
            if (!p.isRolling()) {
                if (sim != null) sim.interact(p);
                else takePickup(p);
            }
        }
        if (p.switchRequest) {
            p.switchRequest = false;
            if (usesSlots(p) && !p.isRolling()) swapWeapon(p);
        }
        if (sim != null && sim.isDriving(p)) {
            p.dodgeRequest = false;
            p.reloadRequest = false;
            return;                 // the car carries the survivor (see SurvivalSim)
        }
        // A reload asked for during a roll waits until the roll is over.
        if (p.reloadRequest && !p.isRolling() && p.switchTimer <= 0f) {
            p.reloadRequest = false;
            beginReload(p);
        }

        if (p.dodgeRequest) {
            p.dodgeRequest = false;
            if (Dodge.canStart(p, GameConfig.DODGE_GRACE)) {
                float dx = p.dodgeReqX;
                float dy = p.dodgeReqY;
                if (dx == 0f && dy == 0f) {
                    Dodge.pickDirection(p.moveX, p.moveY, p.aim, dir);
                    dx = dir[0];
                    dy = dir[1];
                }
                Dodge.start(p, dx, dy);
                p.swingTimer = 0f;     // a roll cuts a swing short too
                w.cancelReload();      // a roll interrupts a reload; nothing of it is kept
            }
        }
        if (p.isRolling()) {
            // A roll replaces walking and shooting; the trigger keeps its state and resumes afterwards.
            Dodge.step(p, col, dt);
            if (!p.isRolling() && w.ammo <= 0 && !w.reloading) beginReload(p);   // an empty gun is reloaded after the roll
            return;
        }

        if (p.shoveX != 0f || p.shoveY != 0f) {
            col.moveCircle(p.x, p.y, p.shoveX * dt, p.shoveY * dt, GameConfig.PLAYER_RADIUS);
            p.x = col.resX;
            p.y = col.resY;
            float decay = (float) Math.exp(-10f * dt);
            p.shoveX *= decay;
            p.shoveY *= decay;
            if (p.shoveX * p.shoveX + p.shoveY * p.shoveY < 16f) {
                p.shoveX = 0f;
                p.shoveY = 0f;
            }
        }
        float mx = p.moveX;
        float my = p.moveY;
        float len2 = mx * mx + my * my;
        if (len2 > 1f) {
            float inv = 1f / (float) Math.sqrt(len2);
            mx *= inv;
            my *= inv;
            len2 = 1f;
        }
        if (len2 > 0f) {
            float step = GameConfig.PLAYER_SPEED * dt;
            col.moveCircle(p.x, p.y, mx * step, my * step, GameConfig.PLAYER_RADIUS);
            p.x = col.resX;
            p.y = col.resY;
        }

        if (p.pulls != p.handledPulls) {
            p.handledPulls = p.pulls;
            p.pullBuffer = GameConfig.PULL_BUFFER;
        }
        boolean trigger = w.def.automatic ? p.firing : p.pullBuffer > 0f;
        if (p.pullBuffer > 0f) p.pullBuffer -= dt;
        // A fresh trigger pull cuts a reload short when the gun is usable (a round is in it). A trigger that
        // was already held when the reload began does not: otherwise holding fire would cancel every reload.
        if (w.reloading && p.pulls != p.reloadPullMark) {
            if (w.canInterruptReload()) w.cancelReload();
            p.reloadPullMark = p.pulls;
        }
        if (trigger && sim != null && sim.handlesTrigger(p)) {
            sim.useSelected(p);                 // survival: eat, build, plant, fish with the item in hand
        } else if (trigger) {
            if (w.canFire() && p.switchTimer <= 0f) {
                if (w.def.melee) startSwing(p);
                else fire(p);
                if (!w.def.automatic) p.pullBuffer = 0f;
            } else if (w.ammo <= 0 && !w.reloading && !w.def.melee) {
                beginReload(p);
            }
        }
    }

    // ------------------------------------------------------------------ Battleground gear

    /** Seconds a weapon swap takes: the new gun cannot fire (or reload) before it is up. */
    public static final float SWITCH_TIME = 0.42f;

    /** True for a player who carries two guns with separate ammunition (Battleground, not bots, not survival). */
    public boolean usesSlots(Player p) {
        return st.mode.royale && sim == null && !p.bot;
    }

    /** The Switch Weapon button: asks to take out the other weapon. */
    public void requestSwitch(int id) {
        if (id < 0 || id >= st.players.length) return;
        Player p = st.players[id];
        if (p.connected) p.switchRequest = true;
    }

    /** Writes the weapon in hand back into its slot (what is loaded in it). */
    private void stowActive(Player p) {
        p.slotWeapon[p.activeSlot] = p.weapon.def.id;
        p.slotAmmo[p.activeSlot] = p.weapon.ammo;
    }

    /** Takes the weapon of the active slot into the hand with the rounds it had in it and the supply it owns. */
    private void drawActive(Player p) {
        int id = p.slotWeapon[p.activeSlot];
        if (id < 0) id = WeaponDef.FISTS;
        p.weapon.equip(WeaponDef.byId(id));
        p.weapon.ammo = Math.min(p.weapon.def.magSize, p.slotAmmo[p.activeSlot]);
        p.weapon.reserve = p.slotReserve[p.activeSlot];
        p.reloadPullMark = p.pulls;
        p.pullBuffer = 0f;
        p.swingTimer = 0f;
        p.switchTimer = SWITCH_TIME;
    }

    /** Switches to the other primary weapon, if there is one: each keeps its own magazine and its own supply. */
    private void swapWeapon(Player p) {
        int other = 1 - p.activeSlot;
        if (p.slotWeapon[other] < 0 || p.switchTimer > SWITCH_TIME * 0.5f) return;
        stowActive(p);
        p.activeSlot = other;
        drawActive(p);
    }

    /**
     * A gun from the ground: it goes to the empty slot, or replaces the one in hand if both are taken (the replaced gun
     * is put down on the ground, still loaded, for anybody to pick up). Picking up a gun the player already carries only
     * refills its supply. A gun from a map pad comes with a full magazine and two spare ones; one that was dropped keeps
     * the rounds it had ({@code ammo} / {@code reserve} of -1 mean a fresh supply).
     */
    private void giveWeapon(Player p, int id) {
        giveWeapon(p, id, -1, -1);
    }

    private void giveWeapon(Player p, int id, int ammo, int reserve) {
        WeaponDef d = WeaponDef.byId(id);
        stowActive(p);
        for (int s = 0; s < Player.SLOTS; s++) {
            if (p.slotWeapon[s] != id) continue;
            if (!d.melee) {
                int extra = reserve >= 0 ? reserve + Math.max(0, ammo) : d.magSize * 2;
                p.slotReserve[s] = Math.min(Pickups.reserveCap(p, d), p.slotReserve[s] + extra);
                p.slotAmmo[s] = Math.max(p.slotAmmo[s], ammo >= 0 ? Math.min(d.magSize, ammo) : d.magSize);
            }
            if (s == p.activeSlot) {
                p.weapon.ammo = p.slotAmmo[s];
                p.weapon.reserve = p.slotReserve[s];
            }
            return;
        }
        int target = p.slotWeapon[1] < 0 ? 1 : (p.slotWeapon[0] < 0 ? 0 : p.activeSlot);
        int old = p.slotWeapon[target];
        if (old >= 0) dropWeapon(p, old, p.slotAmmo[target], p.slotReserve[target]);
        p.slotWeapon[target] = id;
        p.slotAmmo[target] = ammo >= 0 ? Math.min(d.magSize, ammo) : d.magSize;
        p.slotReserve[target] = d.melee ? 0 : (reserve >= 0 ? Math.min(Pickups.reserveCap(p, d), reserve)
                : Math.min(Pickups.reserveCap(p, d), d.magSize * 2));
        p.activeSlot = target;
        drawActive(p);
    }

    /** Adds {@code magazines} spare magazines to every gun the player carries (up to what the backpack holds). */
    private void refillSupplies(Player p, int magazines) {
        for (int s = 0; s < Player.SLOTS; s++) {
            int id = p.slotWeapon[s];
            if (id < 0) continue;
            WeaponDef d = WeaponDef.byId(id);
            if (d.melee) continue;
            p.slotReserve[s] = Math.min(Pickups.reserveCap(p, d), p.slotReserve[s] + d.magSize * magazines);
        }
        p.weapon.reserve = p.slotReserve[p.activeSlot];
    }

    /** Starts a reload and remembers which trigger pull was the last one before it (see {@link Player#reloadPullMark}). */
    private void beginReload(Player p) {
        if (sim != null) {
            if (p.weapon.def.melee) return;
            int have = sim.ammoFor(p);
            if (have <= 0) {
                sim.toast(p, com.hazardyard.game.survival.SurvivalSim.T_NO_AMMO);
                return;
            }
            p.weapon.reserve = have;       // survival: no more rounds than the pack holds
        } else if (usesSlots(p)) {
            if (p.weapon.def.melee) return;
            p.weapon.reserve = p.slotReserve[p.activeSlot];       // each gun has its own supply
            if (p.weapon.reserve <= 0) return;
        } else {
            p.weapon.reserve = Integer.MAX_VALUE;
        }
        if (p.weapon.startReload()) p.reloadPullMark = p.pulls;
    }

    /** The Pick Up button: takes the item on the pad in reach (a gun replaces the one in hand; a vest or kit is used at once). */
    private void takePickup(Player p) {
        if (st.phase != GameState.PHASE_PLAYING || !p.alive) return;
        float reach = GameConfig.PICKUP_REACH + GameConfig.PICKUP_REACH_SLACK;
        int idx = p.pickupRequestIndex;
        p.pickupRequestIndex = -1;
        if (idx >= 0 && idx < st.pickups.length) {
            Pickup c = st.pickups[idx];
            float dx = p.x - c.x;
            float dy = p.y - c.y;
            boolean ok = c.active && dx * dx + dy * dy <= reach * reach && Pickups.worthTaking(p, c)
                    && col.raycast(p.x, p.y, c.x, c.y) < 0f;
            if (!ok) idx = -1;
        } else {
            idx = -1;
        }
        if (idx < 0) idx = Pickups.nearest(st, p, reach);
        if (idx < 0) return;
        Pickup pk = st.pickups[idx];
        int item = pk.item;
        if (Items.isWeapon(item)) {
            if (usesSlots(p)) {
                giveWeapon(p, item, pk.ammo, pk.reserve);
            } else {
                if (st.mode.royale && p.weapon.def.id != item && p.weapon.def.id != WeaponDef.FISTS) {
                    dropWeapon(p, p.weapon.def.id, p.weapon.ammo, Math.min(p.weapon.def.magSize * 2, p.weapon.reserve));
                }
                p.weapon.equip(WeaponDef.byId(item));      // replaces the weapon in hand and cancels any reload
                if (pk.ammo >= 0) p.weapon.ammo = Math.min(p.weapon.def.magSize, pk.ammo);
                p.reloadPullMark = p.pulls;
                p.pullBuffer = 0f;
            }
        } else if (Items.isBackpack(item)) {
            p.backpack = Math.max(p.backpack, Items.backpackLevel(item));
        } else if (item == Items.AMMO_BOX) {
            refillSupplies(p, 2);
        } else if (Items.isVest(item)) {
            p.armor = Math.min(GameConfig.ARMOR_MAX, Math.max(p.armor, Items.armorOf(item)));
        } else if (Items.isMedkit(item)) {
            p.health = Math.min(GameConfig.PLAYER_MAX_HEALTH, p.health + Items.MEDKIT_HEAL);
        }
        pk.active = false;
        pk.timer = st.mode.pickupRespawn;
        listener.onPickup(p, idx);
        if (pk.dynamic) pk.item = -1;
    }

    private void fire(Player p) {
        WeaponDef d = p.weapon.def;
        int seed = rng.nextInt() & 0xFFFF;
        int baseId = nextProjectileId;
        nextProjectileId = (nextProjectileId + d.pellets) & 0xFFFF;
        d.spawn(st.projectiles, col, p.id, p.x, p.y, p.aim, seed, baseId);
        p.weapon.onFired();
        if (p.weapon.ammo <= 0) beginReload(p);
        p.muzzleFlash = 0.06f;
        listener.onShot(p, d, p.x, p.y, p.aim, seed, baseId);
        if (sim != null) sim.noise(p.x, p.y, d.range * 1.6f + 350f);
    }

    private void updateProjectiles(float dt) {
        ProjectilePool pool = st.projectiles;
        for (int i = pool.activeCount - 1; i >= 0; i--) {
            Projectile b = pool.items[pool.activeList[i]];
            int status = col.advance(b, dt);
            int victim = -1;
            float bestT = 2f;
            for (int j = 0; j < st.players.length; j++) {
                Player q = st.players[j];
                if (!q.connected || !q.alive || q.id == b.owner || Dodge.invulnerable(q)) continue;
                float t = CollisionSystem.segmentCircle(b.px, b.py, b.x, b.y, q.x, q.y,
                        GameConfig.PLAYER_RADIUS + b.radius);
                if (t >= 0f && t < bestT) {
                    bestT = t;
                    victim = j;
                }
            }
            if (victim < 0 && sim != null && sim.projectileHitsZombie(b)) {
                pool.release(b);
                continue;
            }
            if (victim >= 0) {
                float hx = b.px + (b.x - b.px) * bestT;
                float hy = b.py + (b.y - b.py) * bestT;
                hitPlayer(b, victim, hx, hy);
                pool.release(b);
            } else if (status == CollisionSystem.HIT_WALL) {
                listener.onWallImpact(b.x, b.y, b.weaponId);
                pool.release(b);
            } else if (status == CollisionSystem.EXPIRED) {
                pool.release(b);
            }
        }
    }

    private void hitPlayer(Projectile b, int victimId, float hx, float hy) {
        damage(victimId, b.owner, b.damage, b.weaponId, b.id, hx, hy);
    }

    /**
     * Hurts a fighter: a vest takes its share first, the rest comes off the health. {@code projectileId} is the id the
     * clients know the bullet by; a melee blow sends {@code 0xFF00 | weaponId} instead.
     */
    private void damage(int victimId, int attackerId, int amount, int weaponId, int projectileId, float hx, float hy) {
        Player v = st.players[victimId];
        int dmg = (v.spawnProtect > 0f || v.air > 0f || st.phase != GameState.PHASE_PLAYING) ? 0 : amount;
        listener.onProjectileHit(projectileId, victimId, hx, hy, dmg, weaponId);
        if (dmg <= 0) return;
        // A vest takes its share of the bullet first; the rest hurts. A spent vest is simply gone.
        int absorbed = 0;
        if (v.armor > 0) {
            absorbed = Math.min(v.armor, Math.round(dmg * GameConfig.ARMOR_ABSORB));
            v.armor -= absorbed;
        }
        v.health -= dmg - absorbed;
        v.hitFlash = 0.15f;
        if (v.health <= 0) kill(v, attackerId, weaponId);
    }

    // ------------------------------------------------------------------ melee

    /**
     * A melee swing begins. Which attack it is comes from the weapon's combo (see {@link MeleeProfile}): a run of swings
     * goes through the weapon's attacks in turn, and starts again after a pause. Each attack has its own speed, so the
     * time until the blow lands and until the next swing may begin depend on it.
     */
    private void startSwing(Player p) {
        WeaponDef d = p.weapon.def;
        MeleeProfile prof = d.profile;
        int variant = 0;
        float speed = 1f, delay = 1f;
        if (prof != null) {
            float since = p.comboT - (p.comboIdx >= 0 ? d.fireInterval * prof.attack(p.comboIdx).speed : 0f);
            variant = prof.nextAttack(p.comboIdx, since);
            MeleeProfile.Attack atk = prof.attack(variant);
            speed = atk.speed;
            delay = atk.delay;
        }
        p.comboIdx = variant;
        p.comboT = 0f;
        p.swingVariant = variant;
        if (prof != null) {
            MeleeProfile.Attack atk = prof.attack(variant);
            if (!p.bot) assistMeleeAim(p, d, atk);
            // a stab or a chop carries the fighter into the blow
            if (atk.lunge > 0f && !p.isRolling()) {
                p.shoveX += (float) Math.cos(p.aim) * atk.lunge;
                p.shoveY += (float) Math.sin(p.aim) * atk.lunge;
            }
        }
        p.weapon.cooldown += d.fireInterval * speed;
        p.swingTimer = d.hitDelay * delay;
        p.swingWeapon = d.id;
        p.swingT = 0f;
        p.swingDur = Math.max(0.22f, d.fireInterval * speed * 0.8f);
        listener.onShot(p, d, p.x, p.y, p.aim, variant, 0);
    }

    /**
     * Melee on a touch screen is hard to line up: when a swing starts and a foe is near the aim, the fighter turns
     * most of the way onto it (and keeps that aim until the blow lands).
     */
    private void assistMeleeAim(Player p, WeaponDef d, MeleeProfile.Attack atk) {
        float reach = d.reach * atk.reach + GameConfig.PLAYER_RADIUS + 10f;
        float cone = Math.max(0.6f, d.arc * atk.arc) * 1.7f;
        float best = Float.NaN;
        float bestScore = 1e9f;
        for (int j = 0; j < st.players.length; j++) {
            Player q = st.players[j];
            if (q == p || !q.connected || !q.alive) continue;
            float dx = q.x - p.x, dy = q.y - p.y;
            float dist = (float) Math.sqrt(dx * dx + dy * dy);
            if (dist > reach) continue;
            float ang = (float) Math.atan2(dy, dx);
            float diff = Math.abs(MathUtil.angleDiff(ang, p.aim));
            if (diff > cone) continue;
            float score = dist + diff * 45f;
            if (score < bestScore) {
                bestScore = score;
                best = ang;
            }
        }
        if (sim != null) {
            float[] r = sim.assistFoe(p, reach, cone);
            if (r != null && r[1] < bestScore) best = r[0];
        }
        if (Float.isNaN(best)) return;
        p.aim = MathUtil.wrapAngle(p.aim + MathUtil.angleDiff(p.aim, best) * 0.8f);
        p.aimLock = 0.22f;
    }

    /**
     * The blow lands: whoever the weapon actually reaches is hit, as far as this attack goes (it can be narrow or wide,
     * long or short). Fighters are thrown away from the blow a little; zombies are handled by {@link SurvivalSim#meleeSwing}.
     */
    private void resolveSwing(Player p) {
        WeaponDef d = WeaponDef.byId(p.swingWeapon);
        if (!d.melee || !p.alive) return;
        MeleeProfile prof = d.profile;
        MeleeProfile.Attack atk = prof != null ? prof.attack(p.swingVariant) : null;
        float reach = d.reach * (atk != null ? atk.reach : 1f);
        float arc = d.arc * (atk != null ? atk.arc : 1f);
        float dmg = d.damage * (atk != null ? atk.damage : 1f);
        int maxHits = prof != null ? Math.min(3, prof.maxTargets) : 3;
        int hits = 0;
        for (int j = 0; j < st.players.length && hits < maxHits; j++) {
            Player q = st.players[j];
            if (q == p || !q.connected || !q.alive || Dodge.invulnerable(q)) continue;
            float dx = q.x - p.x;
            float dy = q.y - p.y;
            float dist = (float) Math.sqrt(dx * dx + dy * dy);
            if (dist > reach + GameConfig.PLAYER_RADIUS) continue;
            if (atk != null && atk.line) {
                float cA = (float) Math.cos(p.aim), sA = (float) Math.sin(p.aim);
                float along = dx * cA + dy * sA;
                float across = Math.abs(-dx * sA + dy * cA);
                if (along < -2f || across > GameConfig.PLAYER_RADIUS * 1.05f) continue;
            } else if (!(atk != null && atk.round) && dist > GameConfig.PLAYER_RADIUS * 1.2f) {
                float diff = Math.abs(MathUtil.angleDiff((float) Math.atan2(dy, dx), p.aim));
                float slack = (float) Math.atan2(GameConfig.PLAYER_RADIUS, Math.max(1f, dist));
                if (diff > arc + slack) continue;
            }
            if (dist > 1f && col.raycast(p.x, p.y, q.x, q.y) >= 0f) continue;      // a wall in between
            hits++;
            float inv = dist > 1f ? 1f / dist : 0f;
            damage(j, p.id, Math.max(1, Math.round(dmg)), d.id, 0xFF00 | d.id, q.x - dx * inv * GameConfig.PLAYER_RADIUS, q.y - dy * inv * GameConfig.PLAYER_RADIUS);
            if (q.alive && atk != null) {
                // a blow shoves the fighter it hits, along the swing as well as away
                float push = prof.baseKnock * 0.5f;
                float cx = (float) Math.cos(p.aim), sx = (float) Math.sin(p.aim);
                q.shoveX += (dx * inv * atk.knock + -sx * atk.sideSign() * atk.side) * push;
                q.shoveY += (dy * inv * atk.knock + cx * atk.sideSign() * atk.side) * push;
            }
        }
        if (sim != null && atk != null) sim.meleeSwing(p, d, atk);
    }

    private void kill(Player v, int killerId, int weaponId) {
        int aliveBefore = st.aliveCount();      // v still counts: it is the Nth-to-last fighter to be out
        if (st.mode.royale && sim == null) dropLoot(v);      // before the armour and the guns are cleared
        v.health = 0;
        v.armor = 0;
        v.alive = false;
        v.rollTimer = 0f;
        v.swingTimer = 0f;
        if (sim != null) sim.playerDied(v);
        v.deaths++;
        v.weapon.cancelReload();
        v.respawnTimer = st.mode.royale ? 0f : st.mode.respawnDelay;
        v.deadFor = 0f;
        if (sim != null) {
            v.deathX = v.x;
            v.deathY = v.y;
            v.hasDeathSpot = true;
        }
        if (st.mode.royale) v.placement = Math.max(1, aliveBefore);
        Player k = (killerId >= 0 && killerId < st.players.length) ? st.players[killerId] : null;
        boolean credit = k != null && k != v && k.connected;
        if (credit) k.kills++;
        listener.onKill(killerId, v.id, weaponId);
        if (credit && st.mode.killLimit > 0 && k.kills >= st.mode.killLimit) endMatch();
        else if (st.mode.royale && st.aliveCount() <= 1) endMatch();
    }

    private void respawn(Player p) {
        placeAtSpawn(p);
        p.alive = true;
        p.deadFor = 0f;
        p.health = GameConfig.PLAYER_MAX_HEALTH;
        p.weapon.equip(WeaponDef.ALL[WeaponDef.PISTOL]);
        p.spawnProtect = GameConfig.SPAWN_PROTECTION;
        p.rollTimer = 0f;
        p.dodgeCooldown = 0f;
        p.handledPulls = p.pulls;
        p.reloadPullMark = p.pulls;
        p.pullBuffer = 0f;
        p.reloadRequest = false;
        p.pickupRequest = false;
        if (sim != null) sim.onSpawned(p);
        listener.onRespawn(p);
    }


    // ------------------------------------------------------------------ Battleground: dropped items

    private float lootSeq;
    private final int[] lootItem = new int[10];
    private final int[] lootAmmo = new int[10];
    private final int[] lootReserve = new int[10];

    /**
     * Puts an item on the ground in a free loot slot (the oldest one is recycled when all are taken) and tells everybody.
     * Returns the slot, or -1 when this match has none.
     */
    public int spawnLoot(int item, float x, float y, int ammo, int reserve) {
        if (!st.mode.royale || st.pickups.length <= st.mapPads || item < 0) return -1;
        int best = -1;
        float oldest = Float.MAX_VALUE;
        for (int i = st.mapPads; i < st.pickups.length; i++) {
            Pickup c = st.pickups[i];
            if (!c.active) {
                best = i;
                break;
            }
            if (c.born < oldest) {
                oldest = c.born;
                best = i;
            }
        }
        if (best < 0) return -1;
        Pickup c = st.pickups[best];
        c.x = x;
        c.y = y;
        c.item = item;
        c.ammo = ammo;
        c.reserve = reserve;
        c.active = true;
        c.timer = 0f;
        c.born = ++lootSeq;
        listener.onLoot(best);
        return best;
    }

    /** A place for the n-th of count items round (x, y): on a ring, and never through a wall. */
    private void lootSpot(float x, float y, int n, int count, float[] out) {
        out[0] = x;
        out[1] = y;
        if (count <= 1) return;
        float a = (float) (n * 2.0 * Math.PI / count) + rng.nextFloat() * 0.5f;
        float r = GameConfig.LOOT_SPREAD * (0.85f + rng.nextFloat() * 0.5f);
        float px = x + (float) Math.cos(a) * r, py = y + (float) Math.sin(a) * r;
        if (col.raycast(x, y, px, py) >= 0f) return;        // a wall: it stays where it fell
        out[0] = px;
        out[1] = py;
    }

    private final float[] spot = new float[2];

    /** A gun put down at the feet of {@code p}, in front of them, with the rounds it has. */
    private void dropWeapon(Player p, int weaponId, int ammo, int reserve) {
        if (weaponId < 0 || weaponId == WeaponDef.FISTS) return;
        float a = p.aim;
        float px = p.x + (float) Math.cos(a) * 24f, py = p.y + (float) Math.sin(a) * 24f;
        if (col.raycast(p.x, p.y, px, py) >= 0f) {
            px = p.x;
            py = p.y;
        }
        spawnLoot(weaponId, px, py, ammo, reserve);
    }

    /**
     * Whoever goes down leaves what they carried: every gun (with its rounds), the vest and backpack if they wore them,
     * and now and then a first-aid kit or a crate of rounds. The items lie in a ring round the body, to be picked up.
     */
    private void dropLoot(Player v) {
        int n = 0;
        if (usesSlots(v)) {
            for (int s = 0; s < Player.SLOTS && n < lootItem.length; s++) {
                int id = v.slotWeapon[s];
                if (id < 0 || id == WeaponDef.FISTS) continue;
                lootItem[n] = id;
                lootAmmo[n] = s == v.activeSlot ? v.weapon.ammo : v.slotAmmo[s];
                lootReserve[n] = v.slotReserve[s];
                n++;
            }
        } else {
            WeaponDef d = v.weapon.def;
            if (d.id != WeaponDef.FISTS) {
                lootItem[n] = d.id;
                lootAmmo[n] = v.weapon.ammo;
                lootReserve[n] = d.melee ? 0 : d.magSize * 2;
                n++;
            }
        }
        if (v.armor > 0 && n < lootItem.length) {
            lootItem[n] = v.armor > Items.LIGHT_VEST_ARMOR ? Items.VEST_HEAVY : Items.VEST_LIGHT;
            lootAmmo[n] = -1;
            lootReserve[n] = -1;
            n++;
        }
        if (v.backpack > 0 && n < lootItem.length) {
            lootItem[n] = Items.BACKPACK_1 + Math.min(2, v.backpack - 1);
            lootAmmo[n] = -1;
            lootReserve[n] = -1;
            n++;
        }
        if (n < lootItem.length && rng.nextInt(100) < 50) {
            lootItem[n] = Items.MEDKIT;
            lootAmmo[n] = -1;
            lootReserve[n] = -1;
            n++;
        }
        if (n < lootItem.length && rng.nextInt(100) < 40) {
            lootItem[n] = Items.AMMO_BOX;
            lootAmmo[n] = -1;
            lootReserve[n] = -1;
            n++;
        }
        for (int i = 0; i < n; i++) {
            lootSpot(v.x, v.y, i, n, spot);
            spawnLoot(lootItem[i], spot[0], spot[1], lootAmmo[i], lootReserve[i]);
        }
    }

    // ------------------------------------------------------------------ Battleground: the drop

    /**
     * A fighter taps the map to choose where to land (and/or says they are done choosing). Only counts while the choice
     * is open. The point is moved to the nearest dry ground when the drop begins.
     */
    public void requestDrop(int id, boolean choose, float x, float y, boolean confirm) {
        if (!st.mode.royale || st.phase != GameState.PHASE_COUNTDOWN || id < 0 || id >= st.players.length) return;
        Player p = st.players[id];
        if (!p.connected || p.bot) return;
        if (choose && MathUtil.isFinite(x) && MathUtil.isFinite(y)) {
            float margin = 3f * GameConfig.TILE;
            p.dropX = MathUtil.clamp(x, margin, st.map.worldW - margin);
            p.dropY = MathUtil.clamp(y, margin, st.map.worldH - margin);
            p.dropSet = true;
        }
        if (confirm) p.dropReady = true;
    }

    private boolean everyoneReadyToDrop() {
        boolean human = false;
        for (Player p : st.players) {
            if (!p.connected || p.bot) continue;
            human = true;
            if (!p.dropReady) return false;
        }
        return human;
    }

    /** The bots pick spread-out places to land: far from the others' choices, with a taste for the spawn points (the towns). */
    private void chooseBotDrop(Player p) {
        TileMap m = st.map;
        float bx = p.x, by = p.y, bestScore = -1f;
        for (int tries = 0; tries < 8; tries++) {
            float cx, cy;
            if (m.spawnX.length > 0 && rng.nextInt(3) != 0) {
                int k = rng.nextInt(m.spawnX.length);
                cx = m.spawnX[k] + rng.nextSigned() * 90f;
                cy = m.spawnY[k] + rng.nextSigned() * 90f;
            } else {
                cx = m.worldW * (0.15f + 0.7f * rng.nextFloat());
                cy = m.worldH * (0.15f + 0.7f * rng.nextFloat());
            }
            float minD = 1500f;
            for (Player q : st.players) {
                if (q == p || !q.connected) continue;
                float dx = q.dropX - cx, dy = q.dropY - cy;
                float d = (float) Math.sqrt(dx * dx + dy * dy);
                if (d < minD) minD = d;
            }
            float score = minD + rng.nextFloat() * 450f;
            if (score > bestScore) {
                bestScore = score;
                bx = cx;
                by = cy;
            }
        }
        p.dropX = bx;
        p.dropY = by;
        p.dropSet = true;
        p.dropReady = true;
    }

    private final float[] land = new float[2];

    /** The nearest ground a fighter can stand on (a floor tile with floor on its four sides) round (x, y); false when there is none close. */
    private boolean findLand(float x, float y, float[] out) {
        TileMap m = st.map;
        int cx = (int) (x / GameConfig.TILE), cy = (int) (y / GameConfig.TILE);
        for (int r = 0; r <= 16; r++) {
            float bestD = Float.MAX_VALUE;
            int bx = -1, by = -1;
            for (int dy = -r; dy <= r; dy++) {
                for (int dx = -r; dx <= r; dx++) {
                    if (Math.max(Math.abs(dx), Math.abs(dy)) != r) continue;
                    int tx = cx + dx, ty = cy + dy;
                    if (m.kindAt(tx, ty) != TileMap.FLOOR || m.kindAt(tx + 1, ty) != TileMap.FLOOR || m.kindAt(tx - 1, ty) != TileMap.FLOOR
                            || m.kindAt(tx, ty + 1) != TileMap.FLOOR || m.kindAt(tx, ty - 1) != TileMap.FLOOR) continue;
                    float ox = (tx + 0.5f) * GameConfig.TILE - x, oy = (ty + 0.5f) * GameConfig.TILE - y;
                    float d = ox * ox + oy * oy;
                    if (d < bestD) {
                        bestD = d;
                        bx = tx;
                        by = ty;
                    }
                }
            }
            if (bx >= 0) {
                out[0] = (bx + 0.5f) * GameConfig.TILE;
                out[1] = (by + 0.5f) * GameConfig.TILE;
                return true;
            }
        }
        return false;
    }

    /** The choice is over: everybody is up in the air over the place they picked, and comes down. */
    private void beginDrop() {
        for (int i = 0; i < st.players.length; i++) {
            Player p = st.players[i];
            if (!p.connected) continue;
            float tx = p.dropSet ? p.dropX : p.x, ty = p.dropSet ? p.dropY : p.y;
            if (findLand(tx, ty, land)) {
                tx = land[0];
                ty = land[1];
            }
            p.x = tx;
            p.y = ty;
            p.rx = tx;
            p.ry = ty;
            p.air = GameConfig.DROP_ALTITUDE;
            p.spawnProtect = 0f;
            p.aim = (float) Math.atan2(st.map.worldH * 0.5f - ty, st.map.worldW * 0.5f - tx);
            p.aimTarget = p.aim;
            p.rAim = p.aim;
            p.hasAimInput = false;
        }
    }

    /** Under the chute: the fighter drifts where they steer, nothing can touch them, and the ground comes up. */
    private void updateAirborne(Player p, float dt) {
        p.dodgeRequest = false;
        p.pickupRequest = false;
        p.reloadRequest = false;
        p.switchRequest = false;
        p.swingTimer = 0f;
        float mx = p.moveX, my = p.moveY;
        float len2 = mx * mx + my * my;
        if (len2 > 1f) {
            float inv = 1f / (float) Math.sqrt(len2);
            mx *= inv;
            my *= inv;
        }
        float margin = 2f * GameConfig.TILE;
        p.x = MathUtil.clamp(p.x + mx * GameConfig.DROP_STEER_SPEED * dt, margin, st.map.worldW - margin);
        p.y = MathUtil.clamp(p.y + my * GameConfig.DROP_STEER_SPEED * dt, margin, st.map.worldH - margin);
        p.air -= (p.air > GameConfig.DROP_CHUTE_ALT ? GameConfig.DROP_FALL_FAST : GameConfig.DROP_FALL_SLOW) * dt;
        if (p.air > 0f) return;
        p.air = 0f;
        // out of the way of walls and water: the nearest standing place
        if (findLand(p.x, p.y, land)) {
            p.x = land[0];
            p.y = land[1];
        }
        p.spawnProtect = 1.5f;
        p.weapon.cooldown = Math.max(p.weapon.cooldown, 0.3f);
        listener.onLanded(p);
    }

    /** Picks the spawn point farthest from every living opponent (with a little randomness). */
    private void placeAtSpawn(Player p) {
        if (sim != null) {
            sim.placeAtSpawn(p);
            return;
        }
        TileMap m = st.map;
        int best = 0;
        float bestScore = -1f;
        for (int i = 0; i < m.spawnX.length; i++) {
            float minD2 = Float.MAX_VALUE;
            for (int j = 0; j < st.players.length; j++) {
                Player q = st.players[j];
                if (q == p || !q.connected || !q.alive) continue;
                float dx = q.x - m.spawnX[i];
                float dy = q.y - m.spawnY[i];
                float d2 = dx * dx + dy * dy;
                if (d2 < minD2) minD2 = d2;
            }
            float dist = minD2 == Float.MAX_VALUE ? 1000f : (float) Math.sqrt(minD2);
            // On a huge map every spawn far enough from the fighting is as good as the farthest one.
            float cap = st.mode.royale ? 3600f : SPAWN_FAR_ENOUGH;
            if (dist > cap) dist = cap;
            float score = dist + rng.nextFloat() * (st.mode.royale ? 160f : 40f);
            if (score > bestScore) {
                bestScore = score;
                best = i;
            }
        }
        p.x = m.spawnX[best];
        p.y = m.spawnY[best];
        p.aim = (float) Math.atan2(m.worldH * 0.5f - p.y, m.worldW * 0.5f - p.x);
        p.aimTarget = p.aim;
        p.hasAimInput = false;
        p.rx = p.x;
        p.ry = p.y;
        p.rAim = p.aim;
    }

    /** Pushes overlapping players apart so they cannot walk through each other. */
    private void separatePlayers() {
        float minDist = 2f * GameConfig.PLAYER_RADIUS;
        for (int i = 0; i < st.players.length; i++) {
            Player a = st.players[i];
            if (!a.connected || !a.alive || a.air > 0f) continue;
            for (int j = i + 1; j < st.players.length; j++) {
                Player b = st.players[j];
                if (!b.connected || !b.alive || b.air > 0f) continue;
                float dx = b.x - a.x;
                float dy = b.y - a.y;
                float d2 = dx * dx + dy * dy;
                if (d2 >= minDist * minDist) continue;
                float d = (float) Math.sqrt(d2);
                float nx = 1f;
                float ny = 0f;
                if (d > 1e-4f) {
                    nx = dx / d;
                    ny = dy / d;
                }
                float push = (minDist - d) * 0.5f;
                a.x -= nx * push;
                a.y -= ny * push;
                b.x += nx * push;
                b.y += ny * push;
                col.pushOut(a.x, a.y, GameConfig.PLAYER_RADIUS);
                a.x = col.resX;
                a.y = col.resY;
                col.pushOut(b.x, b.y, GameConfig.PLAYER_RADIUS);
                b.x = col.resX;
                b.y = col.resY;
            }
        }
    }

    /** Items are only taken by {@link #takePickup}; here they just come back after their respawn time (never, on Battleground). */
    private void updatePickups(float dt) {
        if (st.mode.pickupRespawn < 0f) return;
        for (int i = 0; i < st.pickups.length; i++) {
            Pickup pk = st.pickups[i];
            if (pk.active || pk.dynamic) continue;
            pk.timer -= dt;
            if (pk.timer <= 0f) pk.active = true;
        }
    }
}
