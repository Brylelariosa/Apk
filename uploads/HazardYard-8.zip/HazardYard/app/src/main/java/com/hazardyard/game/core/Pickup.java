package com.hazardyard.game.core;

/**
 * An item pad on the map: a weapon crate, a vest or a first-aid kit (see {@link Items}). On the classic
 * arenas it comes back a while after somebody takes it; on Battleground it does not.
 *
 * <p>On Battleground the list also ends in {@link GameConfig#LOOT_SLOTS} slots that start empty: a gun put down by
 * somebody who picked up another, and what a fallen fighter leaves behind, lands in one of them. Those carry the rounds
 * that were in the gun ({@link #ammo}, {@link #reserve}); on a map pad they are -1, which means a fresh supply.
 */
public final class Pickup {
    public float x, y;
    /** What lies here: an {@link Items} id (-1 while an item slot is empty). */
    public int item;
    public boolean active = true;
    public float timer;
    /** Rounds in the magazine and spare rounds that come with a dropped gun; -1 = none recorded (a full supply). */
    public int ammo = -1, reserve = -1;
    /** True for the slots that fill up during the match. */
    public final boolean dynamic;
    /** When it was put down (match seconds), so the oldest is the one recycled when every slot is full. */
    public float born;

    public Pickup(float x, float y, int item) {
        this.x = x;
        this.y = y;
        this.item = item;
        this.dynamic = false;
    }

    /** An empty item slot. */
    public Pickup() {
        this.item = -1;
        this.active = false;
        this.dynamic = true;
    }

    public boolean isWeapon() {
        return item >= 0 && Items.isWeapon(item);
    }
}
