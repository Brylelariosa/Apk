package com.hazardyard.game.core;

/**
 * An item pad on the map: a weapon crate, a vest or a first-aid kit (see {@link Items}). On the classic
 * arenas it comes back a while after somebody takes it; on Battleground it does not. Battleground also has a few
 * extra {@link #dynamic} pads that start empty and are filled during the match with what fighters leave behind (the
 * loot of a fighter who went down, a gun that was swapped away).
 */
public final class Pickup {
    public float x, y;
    /** What lies here: an {@link Items} id. */
    public int item;
    public boolean active = true;
    /** A map pad: seconds until it comes back. An extra pad: seconds since its item was dropped. */
    public float timer;
    /** An extra pad for dropped items (Battleground only), see {@link GameWorld}. */
    public boolean dynamic;
    /** A dropped gun: the rounds in its magazine (-1: a fresh gun, with a full magazine and two spare ones, as on a map pad). */
    public int ammo = -1;
    /** A dropped gun: the spare rounds that lie with it. */
    public int reserve;

    public Pickup(float x, float y, int item) {
        this.x = x;
        this.y = y;
        this.item = item;
    }

    public boolean isWeapon() {
        return Items.isWeapon(item);
    }
}
