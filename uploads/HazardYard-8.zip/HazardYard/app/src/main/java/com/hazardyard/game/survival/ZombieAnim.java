package com.hazardyard.game.survival;

import com.hazardyard.game.core.MathUtil;
import com.hazardyard.game.core.Puppet;
import com.hazardyard.game.core.PuppetStyle;

/**
 * Fills a {@link Puppet} from what a zombie is doing (its state, how long it has been in it, how fast it walks, which
 * way it was last hit or fell) and computes the pose. The renderer calls it every frame; the ragdoll spawner calls it
 * once to start a corpse from the exact pose the zombie had when it died.
 */
public final class ZombieAnim {
    private ZombieAnim() {}

    /** The target walk blend for a state: 0 standing, 1 shambling, above 1 running. */
    public static float gaitFor(Zombie z) {
        switch (z.state) {
            case Puppet.A_WALK: return 1f;
            case Puppet.A_RUN: return z.type == Zombie.RUNNER ? 1.5f : 1.3f;
            default: return 0f;
        }
    }

    /** Sets the puppet's inputs from the zombie and computes {@link Puppet#j} (body frame). */
    public static void pose(Zombie z, PuppetStyle style, Puppet pu, float clock) {
        pu.anim = z.state;
        pu.t = z.stateT;
        pu.phase = z.walk * 1.5f + (z.id % 7) * 0.9f;
        pu.gait = z.gait;
        pu.clock = clock + (z.id % 13) * 0.37f;
        pu.seed = (z.id * 0.6180339f) % 1f;
        pu.attackP = z.state == Puppet.A_ATTACK ? MathUtil.clamp(z.stateT / Zombie.attackLength(z.type), 0f, 1f) : 0f;
        pu.scale = style.scale;
        pu.width = style.width;
        pu.build = style.build;
        float aim = z.rAim;
        pu.hitX = Puppet.localX(z.hitDirX, z.hitDirY, aim);
        pu.hitY = Puppet.localY(z.hitDirX, z.hitDirY, aim);
        pu.hitK = z.hitK;
        pu.hitT = z.hitT;
        float fx = Puppet.localX(z.fallDirX, z.fallDirY, aim), fy = Puppet.localY(z.fallDirX, z.fallDirY, aim);
        float fl = (float) Math.sqrt(fx * fx + fy * fy);
        if (fl < 1e-3f) {
            fx = -1f;
            fy = 0f;
            fl = 1f;
        }
        pu.fallX = fx / fl;
        pu.fallY = fy / fl;
        pu.reach = 1f;
        pu.compute();
    }
}
