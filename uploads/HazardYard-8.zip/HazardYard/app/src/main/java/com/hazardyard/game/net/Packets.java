package com.hazardyard.game.net;

import com.hazardyard.game.core.GameConfig;
import com.hazardyard.game.core.MathUtil;

/**
 * Encode/decode pairs for the small gameplay messages, kept side by side so the two directions
 * cannot drift apart. Positions travel as 1/4 unit fixed point, angles as 16-bit turns.
 */
public final class Packets {
    private Packets() {}

    static int quantizePos(float v) {
        return MathUtil.clamp(Math.round(v * GameConfig.POS_SCALE), -32768, 32767);
    }

    /** For numbers that are never negative (the safe zone): 0..65535 in the same units. */
    static int quantizeUnsigned(float v) {
        return MathUtil.clamp(Math.round(v * GameConfig.POS_SCALE), 0, 65535);
    }

    /** Client -> host controls. */
    public static final class Input {
        public int seq;
        public int moveX;      // -127..127
        public int moveY;
        public int aim16;
        public boolean firing;

        public byte[] encode(PacketWriter w) {
            return w.begin(Protocol.C_INPUT).u8(seq).i8(moveX).i8(moveY).u16(aim16).u8(firing ? 1 : 0).finishFrame();
        }

        public void read(PacketReader r) {
            seq = r.u8();
            moveX = r.i8();
            moveY = r.i8();
            aim16 = r.u16();
            firing = (r.u8() & 1) != 0;
        }
    }

    /** Host -> clients: a weapon fired. Clients recreate the bullets from these numbers. */
    public static final class Fire {
        public int owner, weaponId, seed, baseId;
        public float x, y, angle;

        public byte[] encode(PacketWriter w) {
            return w.begin(Protocol.S_FIRE).u8(owner).u8(weaponId)
                    .i16(quantizePos(x)).i16(quantizePos(y))
                    .u16(MathUtil.angleToU16(angle)).u16(seed).u16(baseId).finishFrame();
        }

        public void read(PacketReader r) {
            owner = r.u8();
            weaponId = r.u8();
            x = r.i16() / GameConfig.POS_SCALE;
            y = r.i16() / GameConfig.POS_SCALE;
            angle = MathUtil.u16ToAngle(r.u16());
            seed = r.u16();
            baseId = r.u16();
        }
    }

    /** Host -> clients: a bullet ended on a player (damage 0 = absorbed by spawn protection). */
    public static final class Hit {
        public int projectileId, victim, damage;
        public float x, y;

        public byte[] encode(PacketWriter w) {
            return w.begin(Protocol.S_HIT).u16(projectileId).u8(victim)
                    .i16(quantizePos(x)).i16(quantizePos(y)).u8(Math.min(damage, 255)).finishFrame();
        }

        public void read(PacketReader r) {
            projectileId = r.u16();
            victim = r.u8();
            x = r.i16() / GameConfig.POS_SCALE;
            y = r.i16() / GameConfig.POS_SCALE;
            damage = r.u8();
        }
    }

    /** Host -> clients: somebody died. */
    public static final class Kill {
        public int killer, victim, weaponId;

        public byte[] encode(PacketWriter w) {
            return w.begin(Protocol.S_KILL).u8(killer < 0 ? 255 : killer).u8(victim).u8(weaponId).finishFrame();
        }

        public void read(PacketReader r) {
            int k = r.u8();
            killer = k == 255 ? -1 : k;
            victim = r.u8();
            weaponId = r.u8();
        }
    }

    /** Host -> clients: an item slot of the ground was filled (a dropped gun, the belongings of a fallen fighter). */
    public static final class Loot {
        public int slot, item, ammo, reserve;
        public float x, y;

        public byte[] encode(PacketWriter w) {
            return w.begin(Protocol.S_LOOT).u8(slot).u8(item < 0 ? 255 : item)
                    .i16(quantizePos(x)).i16(quantizePos(y))
                    .u8(ammo < 0 ? 255 : Math.min(254, ammo)).u16(reserve < 0 ? 65535 : Math.min(65534, reserve)).finishFrame();
        }

        public void read(PacketReader r) {
            slot = r.u8();
            int it = r.u8();
            item = it == 255 ? -1 : it;
            x = r.i16() / GameConfig.POS_SCALE;
            y = r.i16() / GameConfig.POS_SCALE;
            int a = r.u8();
            ammo = a == 255 ? -1 : a;
            int rs = r.u16();
            reserve = rs == 65535 ? -1 : rs;
        }
    }

    /** Client -> host: where the player chose to land and/or that they are done choosing. */
    public static final class Drop {
        public boolean choose, confirm;
        public float x, y;

        public byte[] encode(PacketWriter w) {
            return w.begin(Protocol.C_DROP).u8((choose ? 1 : 0) | (confirm ? 2 : 0))
                    .u16(quantizeUnsigned(x)).u16(quantizeUnsigned(y)).finishFrame();
        }

        public void read(PacketReader r) {
            int f = r.u8();
            choose = (f & 1) != 0;
            confirm = (f & 2) != 0;
            x = r.u16() / GameConfig.POS_SCALE;
            y = r.u16() / GameConfig.POS_SCALE;
        }
    }
}
