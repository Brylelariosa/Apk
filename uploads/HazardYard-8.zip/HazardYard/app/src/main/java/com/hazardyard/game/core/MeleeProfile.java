package com.hazardyard.game.core;

/**
 * How one melee weapon fights: a short combo of different attacks (a bat swings left to right, then right to left, then
 * smashes down), and for each attack its speed, damage, reach, the arc it covers, how hard it shoves, how long it
 * staggers and how likely it is to knock a zombie off its feet. The numbers are multipliers on the weapon's base
 * values in {@link WeaponDef} (damage, interval, reach, arc), so every weapon keeps one honest set of base stats.
 *
 * <p>Pure data. The host reads it to resolve a blow ({@code SurvivalSim#meleeSwing}, {@code GameWorld}); every device
 * reads it to animate the swing the same way, because the attack's index travels in the fire event.
 */
public final class MeleeProfile {
    // ---- attack kinds: they decide how the soldier moves the weapon and which way the blow pushes
    /** Left to right across the body: pushes whatever it hits to the attacker's right. */
    public static final int SWING_LR = 0;
    /** Right to left: pushes to the attacker's left. */
    public static final int SWING_RL = 1;
    /** Straight down from above. */
    public static final int OVERHEAD = 2;
    /** Straight forward. */
    public static final int THRUST = 3;
    /** Diagonal slash from the upper right down to the lower left (pushes left). */
    public static final int DIAG_RL = 4;
    /** Diagonal slash from the upper left down to the lower right (pushes right). */
    public static final int DIAG_LR = 5;
    /** A punch (the hand alternates with the attack's index). */
    public static final int JAB = 6;
    /** A big round punch. */
    public static final int HOOK = 7;
    /** A pick or stab driven down from above, a little in front. */
    public static final int STAB_DOWN = 8;
    /** A rising slash from low on the right up across the front: lifts what it hits. */
    public static final int UPPER = 9;
    /** A long stab with a step into it: the longest reach there is. */
    public static final int LUNGE = 10;
    /** A full turn with the weapon held out: hits everything around the fighter. */
    public static final int SPIN = 11;

    /** What a blow feels and sounds like. */
    public static final int IMPACT_BLUNT = 0, IMPACT_SLASH = 1, IMPACT_PIERCE = 2, IMPACT_CHOP = 3;

    /** One attack of the combo. */
    public static final class Attack {
        public final int kind;
        /** Multiplies the weapon's interval: the time before the next attack may start (and how long the swing lasts). */
        public final float speed;
        /** Multiplies the hit delay: when, after the swing starts, the blow lands (slow attacks wind up longer). */
        public final float delay;
        public final float damage;
        public final float reach;
        public final float arc;
        /** Push straight away from the attacker. */
        public final float knock;
        /** Push sideways, along the swing (to the attacker's right for a left-to-right swing). */
        public final float side;
        public final float stagger;
        /** Added to the weapon's chance of knocking a target down. */
        public final float down;
        /** The blow is a thrust: it runs along a narrow line in front instead of sweeping an arc (and can pass through two). */
        public final boolean line;
        /** The blow hits all the way round (a spin). */
        public final boolean round;
        /** Speed (world units per second) the fighter steps forward with the blow: a stab or a chop carries the body in. */
        public final float lunge;

        Attack(int kind, float speed, float delay, float damage, float reach, float arc, float knock, float side, float stagger,
               float down) {
            this.kind = kind;
            this.speed = speed;
            this.delay = delay;
            this.damage = damage;
            this.reach = reach;
            this.arc = arc;
            this.knock = knock;
            this.side = side;
            this.stagger = stagger;
            this.down = down;
            this.line = kind == THRUST || kind == LUNGE || kind == STAB_DOWN;
            this.round = kind == SPIN;
            this.lunge = lungeOf(kind);
        }

        private static float lungeOf(int kind) {
            switch (kind) {
                case THRUST: return 46f;
                case LUNGE: return 100f;
                case OVERHEAD: return 34f;
                case UPPER: return 40f;
                case STAB_DOWN: return 34f;
                case JAB: return 30f;
                case HOOK: return 26f;
                case SWING_LR: case SWING_RL: return 16f;
                case DIAG_LR: case DIAG_RL: return 24f;
                default: return 0f;
            }
        }

        /** +1: the blow pushes to the attacker's right, -1: to the left, 0: straight ahead. */
        public float sideSign() {
            switch (kind) {
                case SWING_LR: case DIAG_LR: return 1f;
                case SWING_RL: case DIAG_RL: return -1f;
                case HOOK: return 0.6f;
                default: return 0f;
            }
        }
    }

    public final Attack[] attacks;
    /** Seconds after a swing within which the next one carries on the combo; later it starts again from the first attack. */
    public final float comboWindow;
    /** Speed (world units per second) a standing zombie of weight 1 is thrown by a blow with knock 1. */
    public final float baseKnock;
    /** Seconds a zombie of weight 1 is staggered by a blow with stagger 1. */
    public final float baseStagger;
    /** Chance (0..1) a blow knocks a normal zombie down, before the attack's own bonus. */
    public final float knockdown;
    /** Most targets one blow can hit. */
    public final int maxTargets;
    public final int impact;
    /** Damage multiplier on a zombie that is looking away from the attacker. */
    public final float backstab;
    /** Damage multiplier against walls and doors the player built. */
    public final float structure;
    /** The blow runs through a line of targets instead of an arc (pick, stab). */
    public final boolean pierce;

    private MeleeProfile(Attack[] attacks, float comboWindow, float baseKnock, float baseStagger, float knockdown, int maxTargets,
                         int impact, float backstab, float structure, boolean pierce) {
        this.attacks = attacks;
        this.comboWindow = comboWindow;
        this.baseKnock = baseKnock;
        this.baseStagger = baseStagger;
        this.knockdown = knockdown;
        this.maxTargets = maxTargets;
        this.impact = impact;
        this.backstab = backstab;
        this.structure = structure;
        this.pierce = pierce;
    }

    private static Attack a(int kind, float speed, float delay, float damage, float reach, float arc, float knock, float side,
                            float stagger, float down) {
        return new Attack(kind, speed, delay, damage, reach, arc, knock, side, stagger, down);
    }

    /** The profile of a melee weapon, or null for anything else. */
    public static MeleeProfile forWeapon(int id) {
        switch (id) {
            case WeaponDef.FISTS:
                return new MeleeProfile(new Attack[] {
                        a(JAB, 0.78f, 0.9f, 1.0f, 1.0f, 0.80f, 0.55f, 0f, 0.7f, 0f),
                        a(JAB, 0.78f, 0.9f, 1.05f, 1.0f, 0.80f, 0.55f, 0f, 0.7f, 0f),
                        a(HOOK, 1.10f, 1.2f, 1.45f, 0.95f, 1.15f, 0.95f, 0.8f, 1.3f, 0.12f),
                        a(UPPER, 1.2f, 1.2f, 1.55f, 1.0f, 0.9f, 1.5f, 0f, 1.5f, 0.34f)},
                        0.9f, 150f, 0.22f, 0.0f, 1, IMPACT_BLUNT, 1.2f, 0.2f, false);
            case WeaponDef.KNIFE:
                // quick: stab, slash, rising slash, and a lunging stab to finish
                return new MeleeProfile(new Attack[] {
                        a(THRUST, 0.78f, 0.85f, 1.0f, 1.10f, 0.80f, 0.35f, 0f, 0.8f, 0f),
                        a(SWING_LR, 0.92f, 1.0f, 0.9f, 0.98f, 1.30f, 0.30f, 0.6f, 0.7f, 0f),
                        a(UPPER, 1.0f, 1.1f, 1.1f, 0.98f, 1.0f, 0.45f, 0f, 1.0f, 0.20f),
                        a(LUNGE, 1.15f, 1.1f, 1.75f, 1.45f, 0.8f, 0.95f, 0f, 1.3f, 0.12f)},
                        0.75f, 160f, 0.16f, 0.0f, 2, IMPACT_SLASH, 1.9f, 0.5f, false);
            case WeaponDef.BAT:
                return new MeleeProfile(new Attack[] {
                        a(SWING_LR, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 0.85f, 1.0f, 1.0f, 0.0f),
                        a(SWING_RL, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 0.85f, 1.0f, 1.0f, 0.0f),
                        a(OVERHEAD, 1.35f, 1.35f, 1.5f, 0.95f, 0.8f, 1.35f, 0f, 1.6f, 0.38f),
                        a(SPIN, 1.55f, 1.35f, 1.3f, 1.0f, 3.4f, 1.1f, 0f, 1.5f, 0.30f)},
                        1.1f, 205f, 0.34f, 0.20f, 3, IMPACT_BLUNT, 1.0f, 1.0f, false);
            case WeaponDef.CROWBAR:
                return new MeleeProfile(new Attack[] {
                        a(DIAG_RL, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 0.8f, 0.8f, 1.0f, 0.0f),
                        a(DIAG_LR, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 0.8f, 0.8f, 1.0f, 0.0f),
                        a(THRUST, 0.9f, 0.9f, 0.9f, 1.12f, 0.8f, 0.7f, 0f, 1.0f, 0.0f),
                        a(OVERHEAD, 1.2f, 1.25f, 1.4f, 0.97f, 0.85f, 1.0f, 0f, 1.4f, 0.20f)},
                        1.2f, 240f, 0.38f, 0.22f, 2, IMPACT_BLUNT, 1.0f, 1.7f, false);
            case WeaponDef.MACHETE:
                return new MeleeProfile(new Attack[] {
                        a(DIAG_LR, 0.95f, 0.95f, 1.0f, 1.0f, 1.15f, 0.50f, 0.6f, 0.9f, 0.0f),
                        a(DIAG_RL, 0.95f, 0.95f, 1.0f, 1.0f, 1.15f, 0.50f, 0.6f, 0.9f, 0.0f),
                        a(THRUST, 1.0f, 1.0f, 1.15f, 1.20f, 0.8f, 0.95f, 0f, 1.1f, 0.0f),
                        a(SPIN, 1.5f, 1.3f, 1.25f, 1.0f, 3.4f, 0.9f, 0f, 1.2f, 0.12f)},
                        0.95f, 190f, 0.22f, 0.08f, 4, IMPACT_SLASH, 1.5f, 0.8f, false);
            case WeaponDef.AXE:
                return new MeleeProfile(new Attack[] {
                        a(OVERHEAD, 1.1f, 1.25f, 1.25f, 0.98f, 0.9f, 1.1f, 0f, 1.25f, 0.22f),
                        a(DIAG_LR, 1.0f, 1.05f, 1.0f, 1.0f, 1.0f, 0.9f, 0.7f, 1.0f, 0.05f),
                        a(SPIN, 1.6f, 1.4f, 1.35f, 1.0f, 3.4f, 1.1f, 0f, 1.4f, 0.28f)},
                        1.3f, 270f, 0.34f, 0.32f, 3, IMPACT_CHOP, 1.3f, 1.4f, false);
            case WeaponDef.PICKAXE:
                return new MeleeProfile(new Attack[] {
                        a(STAB_DOWN, 1.0f, 1.2f, 1.25f, 1.0f, 0.75f, 0.75f, 0f, 1.0f, 0.10f),
                        a(SWING_LR, 0.95f, 1.0f, 0.9f, 1.0f, 0.9f, 0.8f, 0.7f, 0.9f, 0.0f),
                        a(STAB_DOWN, 1.0f, 1.2f, 1.25f, 1.0f, 0.75f, 0.75f, 0f, 1.0f, 0.10f),
                        a(UPPER, 1.1f, 1.15f, 1.1f, 1.0f, 0.95f, 0.8f, 0f, 1.1f, 0.22f)},
                        1.2f, 210f, 0.34f, 0.18f, 2, IMPACT_PIERCE, 1.2f, 1.2f, false);
            default:
                return null;
        }
    }

    /** The index of the attack a fighter performs next, given the index of the previous one and how long ago it was. */
    public int nextAttack(int previous, float secondsSince) {
        if (previous < 0 || secondsSince > comboWindow) return 0;
        return (previous + 1) % attacks.length;
    }

    public Attack attack(int index) {
        return attacks[MathUtil.clamp(index, 0, attacks.length - 1)];
    }
}
