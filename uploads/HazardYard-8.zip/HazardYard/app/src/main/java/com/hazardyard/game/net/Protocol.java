package com.hazardyard.game.net;

import java.io.DataInputStream;
import java.io.IOException;

/**
 * Wire constants. A TCP frame is [u16 length][u8 type][payload]; length counts the type byte and the
 * payload. All numbers are big-endian. Discovery datagrams use the same primitives without the length.
 */
public final class Protocol {
    private Protocol() {}

    public static final int VERSION = 8;
    public static final int DISCOVERY_PORT = 47820;
    public static final int GAME_PORT = 47821;
    /** "HYD1" */
    public static final int DISCOVERY_MAGIC = 0x48594431;
    public static final int MAX_FRAME = 4096;
    public static final int MAX_NAME = 12;

    // client -> host
    public static final int C_HELLO = 1;
    public static final int C_READY = 2;
    public static final int C_INPUT = 3;
    public static final int C_RELOAD = 4;
    public static final int C_PING = 5;
    public static final int C_LEAVE = 6;
    /** Dodge roll request: u16 direction (a 16-bit turn). */
    public static final int C_DODGE = 7;
    /** Pick Up pressed: u16 pad index the player is looking at (65535 = the nearest one in reach). */
    public static final int C_PICKUP = 8;
    /** Survival: an inventory or crafting command: u8 command, i16 a, i16 b (see SurvivalSim.CMD_*). */
    public static final int C_SURV = 9;
    /** Battleground: take out the other primary weapon. */
    public static final int C_SWITCH = 10;

    // host -> client
    public static final int S_WELCOME = 20;
    public static final int S_REJECT = 21;
    public static final int S_LOBBY = 22;
    public static final int S_START = 23;
    public static final int S_SNAPSHOT = 24;
    public static final int S_FIRE = 25;
    public static final int S_HIT = 26;
    public static final int S_KILL = 27;
    public static final int S_TO_LOBBY = 28;
    public static final int S_PONG = 29;
    /** Survival: zombies, cars, dropped items, hunger, the clock (droppable, 10 Hz). */
    public static final int S_SURV = 30;
    /** Survival: a sound at a place or a message for one survivor (reliable). */
    public static final int S_SURV_EVENT = 31;
    /** Survival: a tile changed (reliable). */
    public static final int S_SURV_EDIT = 32;
    /** Survival: one survivor's whole inventory (reliable, to that survivor only). */
    public static final int S_SURV_INV = 33;

    /** Never sent on the wire: queued by the host when a client disconnects during a match. */
    public static final int I_PLAYER_LEFT = 100;

    // discovery datagrams
    public static final int D_PROBE = 1;
    public static final int D_REPLY = 2;

    // reject reasons
    public static final int REJECT_VERSION = 1;
    public static final int REJECT_IN_MATCH = 2;
    public static final int REJECT_FULL = 3;

    /** Reads one frame and returns type byte + payload. Blocks; throws on EOF, timeout or bad length. */
    public static byte[] readFrame(DataInputStream in) throws IOException {
        int len = in.readUnsignedShort();
        if (len < 1 || len > MAX_FRAME) throw new IOException("Bad frame length " + len);
        byte[] data = new byte[len];
        in.readFully(data);
        return data;
    }

    /** Trims, strips control characters and limits the length of a player name. */
    public static String sanitizeName(String raw) {
        if (raw == null) return "Player";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < raw.length() && sb.length() < MAX_NAME; i++) {
            char c = raw.charAt(i);
            if (c >= 32 && c != 127) sb.append(c);
        }
        String s = sb.toString().trim();
        return s.isEmpty() ? "Player" : s;
    }

    public static String rejectMessage(int reason) {
        switch (reason) {
            case REJECT_VERSION: return "This game version does not match the host.";
            case REJECT_IN_MATCH: return "A match is already in progress.";
            case REJECT_FULL: return "The lobby is full.";
            default: return "The host refused the connection.";
        }
    }
}
