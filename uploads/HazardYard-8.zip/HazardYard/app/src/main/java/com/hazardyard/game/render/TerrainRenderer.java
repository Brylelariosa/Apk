package com.hazardyard.game.render;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;

import com.hazardyard.game.core.GameConfig;
import com.hazardyard.game.core.TileMap;

/**
 * The ground of an outdoor map: grass, meadows with flowers, forest floor, dirt, sand, roads with their centre lines,
 * paved yards, ploughed fields, wooden bridges, rock, water, and the floors inside buildings.
 *
 * <p>The ground is drawn the way a painter would, not as a board of coloured squares: every ground type is one flat colour
 * (so a whole row of grass is a single rectangle, no seams), the variety comes from soft blotches of lighter and darker
 * tint that ignore the tile grid, natural grounds that meet are feathered into each other, and water has shallows along
 * its banks, drifting foam, glints, and rounded corners where the shore turns.
 */
final class TerrainRenderer {
    private static final float T = GameConfig.TILE;

    /** One flat colour for each ground type. */
    private static final int[] BASE = new int[TileMap.G_COUNT];

    static {
        BASE[TileMap.G_GRASS] = 0xFF5C9A3E;
        BASE[TileMap.G_MEADOW] = 0xFF86B552;
        BASE[TileMap.G_FOREST] = 0xFF447D32;
        BASE[TileMap.G_DIRT] = 0xFF9A7A4C;
        BASE[TileMap.G_SAND] = 0xFFD8C88C;
        BASE[TileMap.G_ROAD] = 0xFF4C525C;
        BASE[TileMap.G_ROAD_H] = BASE[TileMap.G_ROAD];
        BASE[TileMap.G_ROAD_V] = BASE[TileMap.G_ROAD];
        BASE[TileMap.G_PAVED] = 0xFF9EA4AC;
        BASE[TileMap.G_FIELD] = 0xFFA8863E;
        BASE[TileMap.G_BRIDGE] = 0xFF9A6A3A;
        BASE[TileMap.G_ROCKY] = 0xFF8A8C84;
        BASE[TileMap.G_WOOD] = 0xFFB88A58;
        BASE[TileMap.G_TILES] = 0xFFC8CCD2;
        BASE[TileMap.G_CONCRETE] = 0xFF7C828C;
        BASE[TileMap.G_WATER] = 0xFF2162A0;
        BASE[TileMap.G_TILLED] = 0xFF6B4A2C;
    }

    private static final int WATER_DEEP = 0xFF2162A0;
    private static final int WATER_SHALLOW = 0xFF5CC0D6;
    /** What a rounded land corner that pokes into the water is filled with: the water as it looks beside the bank. */
    private static final int WATER_NEAR = 0xFF3585B4;
    private static final float FILLET = 11f;

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    /** The big flat fills: no anti-aliasing, so neighbouring rectangles never leave a hairline between them. */
    private final Paint flat = new Paint();
    private final Paint band = new Paint();
    private final Path path = new Path();

    // the world the renderer is looking at: water that runs off its edge keeps going
    private int minTx = Integer.MIN_VALUE, maxTx = Integer.MAX_VALUE, minTy = Integer.MIN_VALUE, maxTy = Integer.MAX_VALUE;

    /** Batches of line segments drawn in one call each (shore bands, foam, glints, wet sand). */
    private static final class Segs {
        float[] a = new float[512];
        int n;

        void add(float x0, float y0, float x1, float y1) {
            if (n + 4 > a.length) a = java.util.Arrays.copyOf(a, a.length * 2);
            a[n++] = x0;
            a[n++] = y0;
            a[n++] = x1;
            a[n++] = y1;
        }
    }

    private final Segs wet = new Segs(), shore1 = new Segs(), shore2 = new Segs(), shore3 = new Segs(), foam = new Segs(),
            foam2 = new Segs(), glint = new Segs(), contact = new Segs();

    TerrainRenderer() {
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeCap(Paint.Cap.ROUND);
        flat.setStyle(Paint.Style.FILL);
        band.setStyle(Paint.Style.STROKE);
        band.setStrokeCap(Paint.Cap.BUTT);
    }

    /** The extent of the map in tiles (water keeps going past it); an endless world passes nothing. */
    void setBounds(int minTx, int maxTx, int minTy, int maxTy) {
        this.minTx = minTx;
        this.maxTx = maxTx;
        this.minTy = minTy;
        this.maxTy = maxTy;
    }

    // the ground and water of the visible window (and a margin round it), read from the map once per frame
    private static final int MARGIN = 3;
    private byte[] cacheGround = new byte[0];
    private boolean[] cacheWater = new boolean[0];
    private int cacheX0, cacheY0, cacheW, cacheH;

    private void fillCache(GroundSource map, int tx0, int tx1, int ty0, int ty1) {
        cacheX0 = tx0 - MARGIN;
        cacheY0 = ty0 - MARGIN;
        cacheW = tx1 - tx0 + 1 + 2 * MARGIN;
        cacheH = ty1 - ty0 + 1 + 2 * MARGIN;
        int n = cacheW * cacheH;
        if (cacheGround.length < n) {
            cacheGround = new byte[n];
            cacheWater = new boolean[n];
        }
        for (int y = 0; y < cacheH; y++) {
            int ty = clampY(cacheY0 + y);
            for (int x = 0; x < cacheW; x++) {
                int tx = clampX(cacheX0 + x);
                int i = y * cacheW + x;
                cacheGround[i] = map.ground(tx, ty);
                cacheWater[i] = map.water(tx, ty);
            }
        }
    }

    private boolean water(GroundSource map, int tx, int ty) {
        int x = tx - cacheX0, y = ty - cacheY0;
        if (x >= 0 && x < cacheW && y >= 0 && y < cacheH) return cacheWater[y * cacheW + x];
        return map.water(clampX(tx), clampY(ty));
    }

    private byte ground(GroundSource map, int tx, int ty) {
        int x = tx - cacheX0, y = ty - cacheY0;
        if (x >= 0 && x < cacheW && y >= 0 && y < cacheH) return cacheGround[y * cacheW + x];
        return map.ground(clampX(tx), clampY(ty));
    }

    private int clampX(int tx) {
        return tx < minTx ? minTx : (tx > maxTx ? maxTx : tx);
    }

    private int clampY(int ty) {
        return ty < minTy ? minTy : (ty > maxTy ? maxTy : ty);
    }

    private static boolean natural(byte g) {
        return g == TileMap.G_GRASS || g == TileMap.G_MEADOW || g == TileMap.G_FOREST || g == TileMap.G_DIRT || g == TileMap.G_SAND
                || g == TileMap.G_ROCKY || g == TileMap.G_FIELD || g == TileMap.G_TILLED;
    }

    private int baseColor(GroundSource map, int tx, int ty) {
        return water(map, tx, ty) ? WATER_DEEP : BASE[ground(map, tx, ty)];
    }

    void draw(Canvas c, GroundSource map, float time, int tx0, int tx1, int ty0, int ty1, boolean lite) {
        fillCache(map, tx0, tx1, ty0, ty1);
        // 1. one flat colour per ground type, merged along each row
        for (int ty = ty0; ty <= ty1; ty++) {
            int runStart = tx0;
            int runColor = 0;
            for (int tx = tx0; tx <= tx1 + 1; tx++) {
                int color = tx <= tx1 ? baseColor(map, tx, ty) : 0;
                if (tx > tx0 && color != runColor) {
                    flat.setColor(runColor);
                    c.drawRect(runStart * T - 0.5f, ty * T - 0.5f, tx * T + 0.5f, ty * T + T + 0.6f, flat);
                    runStart = tx;
                }
                runColor = color;
            }
        }
        if (!lite) {
            blotches(c, map, tx0, tx1, ty0, ty1);
            feather(c, map, tx0, tx1, ty0, ty1);
        }
        shores(c, map, time, tx0, tx1, ty0, ty1, lite);
        if (lite) return;
        for (int ty = ty0; ty <= ty1; ty++) {
            for (int tx = tx0; tx <= tx1; tx++) decorate(c, map, tx, ty, time);
        }
    }

    // ------------------------------------------------------------------ soft variety

    /**
     * Big soft patches of lighter and darker tint, placed by a hash of a coarse cell, not of the tile: they ignore the
     * tile grid completely. A patch is only drawn where one ground type fills its whole reach.
     */
    private void blotches(Canvas c, GroundSource map, int tx0, int tx1, int ty0, int ty1) {
        final int cell = 7;
        int cx0 = Math.floorDiv(tx0, cell) - 1, cx1 = Math.floorDiv(tx1, cell) + 1;
        int cy0 = Math.floorDiv(ty0, cell) - 1, cy1 = Math.floorDiv(ty1, cell) + 1;
        fill.setStyle(Paint.Style.FILL);
        for (int cy = cy0; cy <= cy1; cy++) {
            for (int cx = cx0; cx <= cx1; cx++) {
                int h = FloorRenderer.hash(cx * 7 + 131, cy * 13 + 22);
                float px = (cx * cell + ((h & 0xFF) / 255f) * cell) * T;
                float py = (cy * cell + (((h >> 8) & 0xFF) / 255f) * cell) * T;
                int tx = (int) Math.floor(px / T), ty = (int) Math.floor(py / T);
                boolean wat = water(map, tx, ty);
                byte g = ground(map, tx, ty);
                if (!wat && (!natural(g) || g == TileMap.G_SAND)) continue;
                // the same ground in the 5 x 5 tiles around the centre (a patch never spills over a border)
                boolean same = true;
                for (int dy = -2; dy <= 2 && same; dy++) {
                    for (int dx = -2; dx <= 2; dx++) {
                        if (water(map, tx + dx, ty + dy) != wat || (!wat && ground(map, tx + dx, ty + dy) != g)) {
                            same = false;
                            break;
                        }
                    }
                }
                if (!same) continue;
                boolean light = ((h >> 16) & 1) == 0;
                float r = 38f + ((h >> 17) & 15) * 2.2f;
                float asp = 1f + (((h >> 21) & 7) / 7f) * 0.6f;
                int col = wat ? (light ? 0xFF4A96C8 : 0xFF123F78) : scaleRgb(BASE[g], light ? 1.22f : 0.78f);
                int alpha = wat ? 0x0C : 0x0A;
                for (int k = 0; k < 2; k++) {
                    float f = 1f - k * 0.4f;
                    fill.setColor(Palette.withAlpha(col, alpha * 2));
                    c.drawOval(px - r * asp * f, py - r * f, px + r * asp * f, py + r * f, fill);
                }
            }
        }
    }

    /** The colour with its red, green and blue multiplied by {@code f}. */
    private static int scaleRgb(int argb, float f) {
        int r = Math.min(255, (int) (((argb >> 16) & 0xFF) * f));
        int g = Math.min(255, (int) (((argb >> 8) & 0xFF) * f));
        int b = Math.min(255, (int) ((argb & 0xFF) * f));
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    /** Where natural grounds meet (grass and sand, meadow and dirt, ...) the two colours are blended over a few units. */
    private void feather(Canvas c, GroundSource map, int tx0, int tx1, int ty0, int ty1) {
        fill.setStyle(Paint.Style.FILL);
        for (int ty = ty0; ty <= ty1; ty++) {
            for (int tx = tx0; tx <= tx1; tx++) {
                if (water(map, tx, ty)) continue;
                byte g = ground(map, tx, ty);
                if (!natural(g)) continue;
                if (!water(map, tx + 1, ty)) {
                    byte e = ground(map, tx + 1, ty);
                    if (e != g && natural(e)) featherEdge(c, (tx + 1) * T, ty * T, true, BASE[g], BASE[e]);
                }
                if (!water(map, tx, ty + 1)) {
                    byte s = ground(map, tx, ty + 1);
                    if (s != g && natural(s)) featherEdge(c, tx * T, (ty + 1) * T, false, BASE[g], BASE[s]);
                }
            }
        }
    }

    private static final float[] FEATHER_W = {16f, 11f, 6.5f, 3f};
    private static final int[] FEATHER_A = {0x0E, 0x18, 0x24, 0x30};

    /** Blends the two sides of an edge: vertical (the edge runs down from (x, y)) or horizontal (it runs right). */
    private void featherEdge(Canvas c, float x, float y, boolean vertical, int before, int after) {
        for (int k = 0; k < FEATHER_W.length; k++) {
            float w = FEATHER_W[k];
            if (vertical) {
                fill.setColor(Palette.withAlpha(after, FEATHER_A[k]));
                c.drawRect(x - w, y, x, y + T, fill);
                fill.setColor(Palette.withAlpha(before, FEATHER_A[k]));
                c.drawRect(x, y, x + w, y + T, fill);
            } else {
                fill.setColor(Palette.withAlpha(after, FEATHER_A[k]));
                c.drawRect(x, y - w, x + T, y, fill);
                fill.setColor(Palette.withAlpha(before, FEATHER_A[k]));
                c.drawRect(x, y, x + T, y + w, fill);
            }
        }
    }

    // ------------------------------------------------------------------ water

    /**
     * Banks: shallows along every shore, wet sand on the land side, foam that drifts, glints on the open water, and the
     * rounded corners where the shore turns. Everything that repeats along the bank is collected and drawn in a handful of
     * batched calls.
     */
    private void shores(Canvas c, GroundSource map, float time, int tx0, int tx1, int ty0, int ty1, boolean lite) {
        wet.n = shore1.n = shore2.n = shore3.n = foam.n = foam2.n = glint.n = contact.n = 0;
        boolean any = false;
        // the banks themselves: runs of shore along a row or column are merged, so the bands are continuous
        for (int side = 0; side < 4; side++) {
            boolean horizontal = (side & 1) == 0;
            int outer0 = horizontal ? ty0 : tx0, outer1 = horizontal ? ty1 : tx1;
            int inner0 = horizontal ? tx0 : ty0, inner1 = horizontal ? tx1 : ty1;
            for (int o = outer0; o <= outer1; o++) {
                int run = Integer.MIN_VALUE;
                boolean runBuilt = false;
                for (int i = inner0; i <= inner1 + 1; i++) {
                    int tx = horizontal ? i : o, ty = horizontal ? o : i;
                    int nx = tx + (side == 1 ? 1 : (side == 3 ? -1 : 0)), ny = ty + (side == 2 ? 1 : (side == 0 ? -1 : 0));
                    boolean shore = i <= inner1 && water(map, tx, ty) && !water(map, nx, ny);
                    boolean built = shore && !natural(ground(map, nx, ny));
                    if (run != Integer.MIN_VALUE && (!shore || built != runBuilt)) {
                        bankRun(map, side, o, run, i, runBuilt);
                        run = Integer.MIN_VALUE;
                    }
                    if (shore && run == Integer.MIN_VALUE) {
                        run = i;
                        runBuilt = built;
                    }
                }
            }
        }
        for (int ty = ty0; ty <= ty1; ty++) {
            for (int tx = tx0; tx <= tx1; tx++) {
                if (!water(map, tx, ty)) continue;
                any = true;
                float x0 = tx * T, y0 = ty * T;
                // 4 sides: 0 north, 1 east, 2 south, 3 west
                for (int side = 0; side < 4; side++) {
                    int nx = tx + (side == 1 ? 1 : (side == 3 ? -1 : 0));
                    int ny = ty + (side == 2 ? 1 : (side == 0 ? -1 : 0));
                    if (water(map, nx, ny)) continue;
                    bank(map, tx, ty, nx, ny, side, x0, y0, time, lite);
                }
                if (!lite) {
                    int h = FloorRenderer.hash(tx * 5 + 3, ty * 3 + 1);
                    if ((h & 7) == 0 && ((int) (time * 1.3f + (h >> 4 & 7)) & 1) == 0) {
                        float gx = x0 + 5f + ((h >> 3) & 15);
                        float gy = y0 + 7f + ((h >> 8) & 15);
                        glint.add(gx, gy, gx + 7f, gy);
                        glint.add(gx + 2f, gy + 4f, gx + 6f, gy + 4f);
                    }
                }
            }
        }
        if (!any) return;
        band.setStrokeCap(Paint.Cap.BUTT);
        band.setColor(Palette.withAlpha(0xFF3A2A10, 0x22));          // wet sand
        band.setStrokeWidth(7f);
        c.drawLines(wet.a, 0, wet.n, band);
        band.setColor(Palette.withAlpha(0xFF101820, 0x42));          // a shadow where the water meets something built
        band.setStrokeWidth(4f);
        c.drawLines(contact.a, 0, contact.n, band);
        band.setColor(Palette.withAlpha(WATER_SHALLOW, 0x1C));
        band.setStrokeWidth(22f);
        c.drawLines(shore3.a, 0, shore3.n, band);
        band.setColor(Palette.withAlpha(WATER_SHALLOW, 0x30));
        band.setStrokeWidth(13f);
        c.drawLines(shore2.a, 0, shore2.n, band);
        band.setColor(Palette.withAlpha(WATER_SHALLOW, 0x52));
        band.setStrokeWidth(6.5f);
        c.drawLines(shore1.a, 0, shore1.n, band);
        if (!lite) {
            band.setStrokeCap(Paint.Cap.ROUND);
            band.setColor(0x44FFFFFF);
            band.setStrokeWidth(1.1f);
            c.drawLines(foam2.a, 0, foam2.n, band);
            band.setColor(0x96FFFFFF);
            band.setStrokeWidth(1.5f);
            c.drawLines(foam.a, 0, foam.n, band);
            band.setColor(0x66FFFFFF);
            band.setStrokeWidth(1.3f);
            c.drawLines(glint.a, 0, glint.n, band);
            band.setStrokeCap(Paint.Cap.BUTT);
            fillets(c, map, tx0, tx1, ty0, ty1);
        }
    }

    private void bank(GroundSource map, int tx, int ty, int nx, int ny, int side, float x0, float y0, float time, boolean lite) {
        if (lite) return;
        // foam: a wavy line a little way out, and a fainter one behind it; some stretches of bank have none
        int fh = FloorRenderer.hash(tx * 11 + side * 3, ty * 7 + 9);
        if ((fh & 3) == 0) return;
        for (int k = 0; k < 2; k++) {
            float inset = k == 0 ? 3.3f : 8.5f;
            Segs dst = k == 0 ? foam : foam2;
            float phase = time * (k == 0 ? 1.7f : 1.2f) + (k == 0 ? 0f : 2.1f);
            float px = 0, py = 0;
            for (int s = 0; s <= 4; s++) {
                float along = s * (T / 4f);
                float worldAlong = (side == 0 || side == 2) ? x0 + along : y0 + along;
                float o = inset + (float) Math.sin(phase + worldAlong * 0.21f) * (k == 0 ? 1.4f : 1.9f);
                float qx, qy;
                switch (side) {
                    case 0: qx = x0 + along; qy = y0 + o; break;
                    case 2: qx = x0 + along; qy = y0 + T - o; break;
                    case 1: qx = x0 + T - o; qy = y0 + along; break;
                    default: qx = x0 + o; qy = y0 + along; break;
                }
                if (s > 0) dst.add(px, py, qx, qy);
                px = qx;
                py = qy;
            }
        }
    }


    /**
     * One continuous stretch of bank: tiles {@code from}..{@code to - 1} along row (north/south sides) or column (east/west
     * sides) number {@code line}. The shallows, the wet sand and the contact shadow are added as single long segments, and are
     * lengthened where the shore turns into the water so the bands join up round the bend.
     */
    private void bankRun(GroundSource map, int side, int line, int from, int to, boolean built) {
        boolean horizontal = (side & 1) == 0;
        float a0 = from * T, a1 = to * T;
        // is the water carrying on past either end of the run (a concave turn)?
        boolean extA = horizontal ? water(map, from - 1, line) : water(map, line, from - 1);
        boolean extB = horizontal ? water(map, to, line) : water(map, line, to);
        float edge = (side == 0 || side == 3) ? line * T : (line + 1) * T;
        float sign = (side == 0 || side == 3) ? 1f : -1f;          // which way "into the water" runs
        bandSeg(shore1, horizontal, a0, a1, edge + sign * 3.25f, extA ? 3.25f : 0f, extB ? 3.25f : 0f);
        bandSeg(shore2, horizontal, a0, a1, edge + sign * 6.5f, extA ? 6.5f : 0f, extB ? 6.5f : 0f);
        bandSeg(shore3, horizontal, a0, a1, edge + sign * 11f, extA ? 11f : 0f, extB ? 11f : 0f);
        bandSeg(built ? contact : wet, horizontal, a0, a1, edge - sign * (built ? 2f : 3.5f), 0f, 0f);
    }

    private static void bandSeg(Segs dst, boolean horizontal, float a0, float a1, float at, float extA, float extB) {
        if (horizontal) dst.add(a0 - extA, at, a1 + extB, at);
        else dst.add(at, a0 - extA, at, a1 + extB);
    }

    /** Rounds the corners where the shore turns: land eats into a water corner, water bites into a land corner. */
    private void fillets(Canvas c, GroundSource map, int tx0, int tx1, int ty0, int ty1) {
        fill.setStyle(Paint.Style.FILL);
        for (int ty = ty0 - 1; ty <= ty1 + 1; ty++) {
            for (int tx = tx0 - 1; tx <= tx1 + 1; tx++) {
                boolean wat = water(map, tx, ty);
                for (int corner = 0; corner < 4; corner++) {
                    int dx = (corner == 1 || corner == 2) ? 1 : -1;
                    int dy = (corner >= 2) ? 1 : -1;
                    boolean ox = water(map, tx + dx, ty) != wat;
                    boolean oy = water(map, tx, ty + dy) != wat;
                    if (!ox || !oy) continue;
                    if (water(map, tx + dx, ty + dy) == wat) continue;      // the diagonal belongs to this side: a notch, not a corner
                    if (wat) {
                        byte lg = ground(map, tx + dx, ty);
                        if (!natural(lg)) continue;
                        fillet(c, tx, ty, corner, BASE[lg]);
                    } else {
                        if (!natural(ground(map, tx, ty))) continue;
                        fillet(c, tx, ty, corner, WATER_NEAR);
                    }
                }
            }
        }
    }

    /** One rounded corner: the sliver between the sharp corner of the tile and a curve cut into it. */
    private void fillet(Canvas c, int tx, int ty, int corner, int color) {
        float cx = (corner == 1 || corner == 2) ? (tx + 1) * T : tx * T;
        float cy = (corner >= 2) ? (ty + 1) * T : ty * T;
        float ix = (corner == 1 || corner == 2) ? -1f : 1f;
        float iy = (corner >= 2) ? -1f : 1f;
        path.reset();
        path.moveTo(cx - ix * 0.4f, cy - iy * 0.4f);
        path.lineTo(cx + ix * FILLET, cy - iy * 0.4f);
        path.quadTo(cx - ix * 0.4f, cy - iy * 0.4f, cx - ix * 0.4f, cy + iy * FILLET);
        path.close();
        fill.setColor(color);
        c.drawPath(path, fill);
    }

    // ------------------------------------------------------------------ small things

    private void decorate(Canvas c, GroundSource map, int tx, int ty, float time) {
        byte g = ground(map, tx, ty);
        if (water(map, tx, ty)) return;
        int h = FloorRenderer.hash(tx * 3 + 1, ty * 5 + 2);
        float x = tx * T;
        float y = ty * T;
        switch (g) {
            case TileMap.G_GRASS:
            case TileMap.G_MEADOW:
            case TileMap.G_FOREST: {
                int m = h % 7;
                if (m < 3) {
                    // a tuft of grass: three little blades
                    float bx = x + 5f + ((h >> 4) & 15);
                    float by = y + 12f + ((h >> 9) & 11);
                    line.setColor(g == TileMap.G_FOREST ? 0xFF2F6428 : (g == TileMap.G_MEADOW ? 0xFF6F9F3F : 0xFF4A8532));
                    line.setStrokeWidth(1.4f);
                    c.drawLine(bx, by, bx - 2.2f, by - 5f, line);
                    c.drawLine(bx, by, bx + 0.4f, by - 6f, line);
                    c.drawLine(bx, by, bx + 2.6f, by - 4.6f, line);
                } else if (g == TileMap.G_MEADOW && m == 3) {
                    float fx = x + 6f + ((h >> 5) & 19);
                    float fy = y + 6f + ((h >> 10) & 19);
                    fill.setColor(((h >> 15) & 1) == 0 ? 0xFFF4F0E0 : (((h >> 16) & 1) == 0 ? 0xFFF2D24A : 0xFFE88AB0));
                    c.drawCircle(fx, fy, 1.9f, fill);
                    fill.setColor(0xFFF2C230);
                    c.drawCircle(fx, fy, 0.7f, fill);
                } else if (g == TileMap.G_FOREST && m == 4) {
                    fill.setColor(0x33203A18);
                    c.drawCircle(x + 8f + ((h >> 6) & 15), y + 8f + ((h >> 11) & 15), 4.5f, fill);
                }
                break;
            }
            case TileMap.G_SAND: {
                if (h % 5 == 0) {
                    fill.setColor(0x22000000);
                    c.drawCircle(x + 4f + ((h >> 5) & 23), y + 4f + ((h >> 10) & 23), 1.1f, fill);
                }
                break;
            }
            case TileMap.G_ROCKY: {
                if (h % 4 == 0) {
                    fill.setColor(0x26000000);
                    float bx = x + 4f + ((h >> 5) & 15);
                    float by = y + 4f + ((h >> 10) & 15);
                    c.drawRect(bx, by, bx + 5f + ((h >> 15) & 3), by + 3f, fill);
                }
                break;
            }
            case TileMap.G_ROAD_H: {
                // centre line: dashes along the road
                if (((tx & 1) == 0)) {
                    fill.setColor(0xFFE2C95A);
                    c.drawRect(x + 4f, y + T * 0.5f - 1.2f, x + T - 4f, y + T * 0.5f + 1.2f, fill);
                }
                edge(c, map, tx, ty, x, y);
                break;
            }
            case TileMap.G_ROAD_V: {
                if (((ty & 1) == 0)) {
                    fill.setColor(0xFFE2C95A);
                    c.drawRect(x + T * 0.5f - 1.2f, y + 4f, x + T * 0.5f + 1.2f, y + T - 4f, fill);
                }
                edge(c, map, tx, ty, x, y);
                break;
            }
            case TileMap.G_ROAD: edge(c, map, tx, ty, x, y); break;
            case TileMap.G_PAVED:
            case TileMap.G_CONCRETE: {
                // no tile-sized joints: now and then a hairline crack or a worn patch, never the same twice
                int m = h % 13;
                if (m == 0) {
                    fill.setColor(0x14000000);
                    c.drawCircle(x + 6f + ((h >> 5) & 19), y + 6f + ((h >> 10) & 19), 6f + ((h >> 15) & 5), fill);
                } else if (m == 1) {
                    line.setColor(0x26000000);
                    line.setStrokeWidth(1f);
                    float cx = x + 5f + ((h >> 5) & 15), cy = y + 3f + ((h >> 9) & 7);
                    c.drawLine(cx, cy, cx + ((h >> 13) & 7) - 3f, cy + 11f, line);
                    c.drawLine(cx + ((h >> 13) & 7) - 3f, cy + 11f, cx + 5f, cy + 21f, line);
                }
                break;
            }
            case TileMap.G_TILES: {
                // indoor tiles keep their joints, softly
                line.setColor(0x1E000000);
                line.setStrokeWidth(1f);
                c.drawLine(x, y, x + T, y, line);
                c.drawLine(x, y, x, y + T, line);
                break;
            }
            case TileMap.G_FIELD: {
                // furrows with young crops
                line.setStrokeWidth(2.2f);
                for (int k = 0; k < 4; k++) {
                    float fy = y + 4f + k * 8f;
                    line.setColor(0x33503810);
                    c.drawLine(x, fy, x + T, fy, line);
                    if (((tx + k) & 1) == 0) {
                        line.setColor(0xFF6E9A3A);
                        line.setStrokeWidth(2f);
                        c.drawLine(x + 6f, fy - 1.5f, x + 12f, fy - 1.5f, line);
                        c.drawLine(x + 20f, fy - 1.5f, x + 26f, fy - 1.5f, line);
                        line.setStrokeWidth(2.2f);
                    }
                }
                break;
            }
            case TileMap.G_BRIDGE: {
                // planks across, rails where the bridge borders water
                line.setColor(0x44201006);
                line.setStrokeWidth(1.2f);
                for (int k = 1; k < 4; k++) c.drawLine(x, y + k * 8f, x + T, y + k * 8f, line);
                if (water(map, tx, ty - 1)) rail(c, x, y, x + T, y);
                if (water(map, tx, ty + 1)) rail(c, x, y + T, x + T, y + T);
                if (water(map, tx - 1, ty)) rail(c, x, y, x, y + T);
                if (water(map, tx + 1, ty)) rail(c, x + T, y, x + T, y + T);
                break;
            }
            case TileMap.G_WOOD: {
                // floorboards
                line.setColor(0x30301800);
                line.setStrokeWidth(1f);
                for (int k = 1; k < 4; k++) c.drawLine(x, y + k * 8f, x + T, y + k * 8f, line);
                break;
            }
            default:
                break;
        }
    }

    /** Darker kerb where a road meets something that is not road. */
    private void edge(Canvas c, GroundSource map, int tx, int ty, float x, float y) {
        line.setColor(0x55101418);
        line.setStrokeWidth(2f);
        if (!isRoad(map.ground(tx, ty - 1))) c.drawLine(x, y + 1f, x + T, y + 1f, line);
        if (!isRoad(map.ground(tx, ty + 1))) c.drawLine(x, y + T - 1f, x + T, y + T - 1f, line);
        if (!isRoad(map.ground(tx - 1, ty))) c.drawLine(x + 1f, y, x + 1f, y + T, line);
        if (!isRoad(map.ground(tx + 1, ty))) c.drawLine(x + T - 1f, y, x + T - 1f, y + T, line);
    }

    private static boolean isRoad(byte g) {
        return g == TileMap.G_ROAD || g == TileMap.G_ROAD_H || g == TileMap.G_ROAD_V || g == TileMap.G_BRIDGE;
    }

    private void rail(Canvas c, float x0, float y0, float x1, float y1) {
        line.setColor(0xFF5A3A1C);
        line.setStrokeWidth(3.2f);
        c.drawLine(x0, y0, x1, y1, line);
    }
}
