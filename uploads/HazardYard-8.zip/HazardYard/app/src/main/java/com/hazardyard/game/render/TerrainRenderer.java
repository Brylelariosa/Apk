package com.hazardyard.game.render;

import android.graphics.Canvas;
import android.graphics.Paint;

import com.hazardyard.game.core.GameConfig;
import com.hazardyard.game.core.TileMap;

/**
 * The ground of an outdoor map: grass, meadows with flowers, forest floor, dirt, sand, roads with their centre lines,
 * paved yards, ploughed fields, wooden bridges, rock, and the floors inside buildings. Only the visible tiles are drawn;
 * each tile gets a slightly different shade from a hash of its position, so large areas do not look flat.
 */
final class TerrainRenderer {
    private static final float T = GameConfig.TILE;

    /** Four shades of each ground type (index = ground type, then shade 0..3). */
    private static final int[][] SHADES = new int[TileMap.G_COUNT][];

    static {
        SHADES[TileMap.G_GRASS] = new int[] {0xFF5C9A3E, 0xFF579437, 0xFF62A044, 0xFF5A983C};
        SHADES[TileMap.G_MEADOW] = new int[] {0xFF86B552, 0xFF7FAE4D, 0xFF8EBC58, 0xFF83B24F};
        SHADES[TileMap.G_FOREST] = new int[] {0xFF457F33, 0xFF40792F, 0xFF4A8638, 0xFF437C31};
        SHADES[TileMap.G_DIRT] = new int[] {0xFF9A7A4C, 0xFF927246, 0xFFA28254, 0xFF967650};
        SHADES[TileMap.G_SAND] = new int[] {0xFFD8C88C, 0xFFD2C286, 0xFFDECE94, 0xFFD5C589};
        SHADES[TileMap.G_ROAD] = new int[] {0xFF4C525C, 0xFF495058, 0xFF50565F, 0xFF4B515A};
        SHADES[TileMap.G_ROAD_H] = SHADES[TileMap.G_ROAD];
        SHADES[TileMap.G_ROAD_V] = SHADES[TileMap.G_ROAD];
        SHADES[TileMap.G_PAVED] = new int[] {0xFF9EA4AC, 0xFF979DA5, 0xFFA4AAB2, 0xFF9AA0A8};
        SHADES[TileMap.G_FIELD] = new int[] {0xFFA8863E, 0xFFA2813A, 0xFFAE8D44, 0xFFA5843C};
        SHADES[TileMap.G_BRIDGE] = new int[] {0xFF9A6A3A, 0xFF946536, 0xFFA0703F, 0xFF976838};
        SHADES[TileMap.G_ROCKY] = new int[] {0xFF8A8C84, 0xFF83857D, 0xFF90928A, 0xFF878981};
        SHADES[TileMap.G_WOOD] = new int[] {0xFFB88A58, 0xFFB08350, 0xFFBE9260, 0xFFB48756};
        SHADES[TileMap.G_TILES] = new int[] {0xFFC8CCD2, 0xFFBEC2C9, 0xFFD0D4DA, 0xFFC3C7CE};
        SHADES[TileMap.G_CONCRETE] = new int[] {0xFF7C828C, 0xFF767C86, 0xFF828892, 0xFF797F89};
        SHADES[TileMap.G_WATER] = new int[] {0xFF2A6CB0, 0xFF2766A8, 0xFF2E72B8, 0xFF2969AC};
        SHADES[TileMap.G_TILLED] = new int[] {0xFF6B4A2C, 0xFF654528, 0xFF71502F, 0xFF684829};
    }

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);

    TerrainRenderer() {
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeCap(Paint.Cap.ROUND);
    }

    void draw(Canvas c, GroundSource map, float time, int tx0, int tx1, int ty0, int ty1, boolean lite) {
        fill.setStyle(Paint.Style.FILL);
        // every tile gets its own shade, merged along the row when neighbours share it (far fewer draw calls)
        for (int ty = ty0; ty <= ty1; ty++) {
            int runStart = tx0;
            int runColor = 0;
            for (int tx = tx0; tx <= tx1 + 1; tx++) {
                int color = tx <= tx1 ? colorOf(map, tx, ty) : 0;
                if (tx > tx0 && color != runColor) {
                    fill.setColor(runColor);
                    c.drawRect(runStart * T, ty * T, tx * T + 0.5f, ty * T + T + 0.5f, fill);
                    runStart = tx;
                }
                runColor = color;
            }
        }
        if (lite) return;
        for (int ty = ty0; ty <= ty1; ty++) {
            for (int tx = tx0; tx <= tx1; tx++) decorate(c, map, tx, ty, time);
        }
    }

    /**
     * How many levels (per colour channel) the ground of each type may drift from its base colour. Natural ground mottles
     * gently, built surfaces hardly at all. The drift changes smoothly from tile to tile (see {@link #noise}), so the tile
     * grid does not show: two neighbours differ by a level or two at most.
     */
    private static final int[] DRIFT = new int[TileMap.G_COUNT];

    static {
        java.util.Arrays.fill(DRIFT, 2);
        DRIFT[TileMap.G_GRASS] = 6;
        DRIFT[TileMap.G_MEADOW] = 6;
        DRIFT[TileMap.G_FOREST] = 6;
        DRIFT[TileMap.G_DIRT] = 5;
        DRIFT[TileMap.G_SAND] = 3;
        DRIFT[TileMap.G_FIELD] = 4;
        DRIFT[TileMap.G_ROCKY] = 4;
        DRIFT[TileMap.G_TILLED] = 3;
        DRIFT[TileMap.G_WATER] = 4;
    }

    private static int colorOf(GroundSource map, int tx, int ty) {
        byte g = map.ground(tx, ty);
        int base = SHADES[g][0];
        int d = Math.round(noise(tx, ty) * DRIFT[g]);
        if (d == 0) return base;
        int r = clamp255(((base >> 16) & 0xFF) + d);
        int gr = clamp255(((base >> 8) & 0xFF) + d);
        int b = clamp255((base & 0xFF) + d);
        return 0xFF000000 | (r << 16) | (gr << 8) | b;
    }

    private static int clamp255(int v) {
        return v < 0 ? 0 : (v > 255 ? 255 : v);
    }

    /** Smooth value noise in -1..1: broad patches (about six tiles across) with a finer mottling (about two and a half) on top. */
    private static float noise(int tx, int ty) {
        return 0.65f * lattice(tx * (1f / 6f), ty * (1f / 6f), 11) + 0.35f * lattice(tx * 0.4f, ty * 0.4f, 53);
    }

    private static float lattice(float x, float y, int salt) {
        int ix = (int) Math.floor(x);
        int iy = (int) Math.floor(y);
        float fx = x - ix;
        float fy = y - iy;
        fx = fx * fx * (3f - 2f * fx);
        fy = fy * fy * (3f - 2f * fy);
        float a = corner(ix, iy, salt);
        float b = corner(ix + 1, iy, salt);
        float c = corner(ix, iy + 1, salt);
        float d = corner(ix + 1, iy + 1, salt);
        float top = a + (b - a) * fx;
        float bottom = c + (d - c) * fx;
        return top + (bottom - top) * fy;
    }

    private static float corner(int x, int y, int salt) {
        return (FloorRenderer.hash(x + salt * 131, y - salt * 71) & 0xFFFF) / 32767.5f - 1f;
    }

    /** The colour tile (tx, ty) is drawn in (the water drawing rounds the banks off with it). */
    int colorAt(GroundSource map, int tx, int ty) {
        return colorOf(map, tx, ty);
    }

    private void decorate(Canvas c, GroundSource map, int tx, int ty, float time) {
        byte g = map.ground(tx, ty);
        int h = FloorRenderer.hash(tx * 3 + 1, ty * 5 + 2);
        float x = tx * T;
        float y = ty * T;
        switch (g) {
            case TileMap.G_GRASS:
            case TileMap.G_MEADOW:
            case TileMap.G_FOREST: {
                int m = h % 7;
                if (m < 3) {
                    // a tuft of grass: three little blades
                    float bx = x + 5f + ((h >> 4) & 15);
                    float by = y + 12f + ((h >> 9) & 11);
                    line.setColor(g == TileMap.G_FOREST ? 0xFF2F6428 : (g == TileMap.G_MEADOW ? 0xFF6F9F3F : 0xFF4A8532));
                    line.setStrokeWidth(1.4f);
                    c.drawLine(bx, by, bx - 2.2f, by - 5f, line);
                    c.drawLine(bx, by, bx + 0.4f, by - 6f, line);
                    c.drawLine(bx, by, bx + 2.6f, by - 4.6f, line);
                } else if (g == TileMap.G_MEADOW && m == 3) {
                    float fx = x + 6f + ((h >> 5) & 19);
                    float fy = y + 6f + ((h >> 10) & 19);
                    fill.setColor(((h >> 15) & 1) == 0 ? 0xFFF4F0E0 : (((h >> 16) & 1) == 0 ? 0xFFF2D24A : 0xFFE88AB0));
                    c.drawCircle(fx, fy, 1.9f, fill);
                    fill.setColor(0xFFF2C230);
                    c.drawCircle(fx, fy, 0.7f, fill);
                } else if (g == TileMap.G_FOREST && m == 4) {
                    fill.setColor(0x33203A18);
                    c.drawCircle(x + 8f + ((h >> 6) & 15), y + 8f + ((h >> 11) & 15), 4.5f, fill);
                }
                break;
            }
            case TileMap.G_SAND: {
                if (h % 5 == 0) {
                    fill.setColor(0x22000000);
                    c.drawCircle(x + 4f + ((h >> 5) & 23), y + 4f + ((h >> 10) & 23), 1.1f, fill);
                }
                break;
            }
            case TileMap.G_ROCKY: {
                if (h % 4 == 0) {
                    fill.setColor(0x26000000);
                    float bx = x + 4f + ((h >> 5) & 15);
                    float by = y + 4f + ((h >> 10) & 15);
                    c.drawRect(bx, by, bx + 5f + ((h >> 15) & 3), by + 3f, fill);
                }
                break;
            }
            case TileMap.G_ROAD_H: {
                // centre line: dashes along the road
                if (((tx & 1) == 0)) {
                    fill.setColor(0xFFE2C95A);
                    c.drawRect(x + 4f, y + T * 0.5f - 1.2f, x + T - 4f, y + T * 0.5f + 1.2f, fill);
                }
                edge(c, map, tx, ty, x, y);
                break;
            }
            case TileMap.G_ROAD_V: {
                if (((ty & 1) == 0)) {
                    fill.setColor(0xFFE2C95A);
                    c.drawRect(x + T * 0.5f - 1.2f, y + 4f, x + T * 0.5f + 1.2f, y + T - 4f, fill);
                }
                edge(c, map, tx, ty, x, y);
                break;
            }
            case TileMap.G_ROAD: edge(c, map, tx, ty, x, y); break;
            case TileMap.G_PAVED:
            case TileMap.G_CONCRETE:
            case TileMap.G_TILES: {
                // joints between slabs
                line.setColor(g == TileMap.G_TILES ? 0x30000000 : 0x22000000);
                line.setStrokeWidth(1f);
                c.drawLine(x, y, x + T, y, line);
                c.drawLine(x, y, x, y + T, line);
                break;
            }
            case TileMap.G_FIELD: {
                // furrows with young crops
                line.setStrokeWidth(2.2f);
                for (int k = 0; k < 4; k++) {
                    float fy = y + 4f + k * 8f;
                    line.setColor(0x33503810);
                    c.drawLine(x, fy, x + T, fy, line);
                    if (((tx + k) & 1) == 0) {
                        line.setColor(0xFF6E9A3A);
                        line.setStrokeWidth(2f);
                        c.drawLine(x + 6f, fy - 1.5f, x + 12f, fy - 1.5f, line);
                        c.drawLine(x + 20f, fy - 1.5f, x + 26f, fy - 1.5f, line);
                        line.setStrokeWidth(2.2f);
                    }
                }
                break;
            }
            case TileMap.G_BRIDGE: {
                // planks across, rails where the bridge borders water
                line.setColor(0x44201006);
                line.setStrokeWidth(1.2f);
                for (int k = 1; k < 4; k++) c.drawLine(x, y + k * 8f, x + T, y + k * 8f, line);
                if (map.water(tx, ty - 1)) rail(c, x, y, x + T, y);
                if (map.water(tx, ty + 1)) rail(c, x, y + T, x + T, y + T);
                if (map.water(tx - 1, ty)) rail(c, x, y, x, y + T);
                if (map.water(tx + 1, ty)) rail(c, x + T, y, x + T, y + T);
                break;
            }
            case TileMap.G_WATER: {
                // ripples that drift, and a pale rim where water meets land
                float ph = time * 1.4f + (h & 63) * 0.3f;
                line.setStrokeWidth(1.3f);
                line.setColor(0x33FFFFFF);
                float rx = x + 6f + ((h >> 3) & 15);
                float ry = y + 8f + ((h >> 8) & 15) + (float) Math.sin(ph) * 1.5f;
                c.drawLine(rx, ry, rx + 8f, ry, line);
                if ((h & 3) == 0) c.drawLine(rx + 4f, ry + 7f, rx + 11f, ry + 7f, line);
                line.setColor(0x66E8F6FF);
                line.setStrokeWidth(2f);
                if (!map.water(tx, ty - 1)) c.drawLine(x, y + 1f, x + T, y + 1f, line);
                if (!map.water(tx, ty + 1)) c.drawLine(x, y + T - 1f, x + T, y + T - 1f, line);
                if (!map.water(tx - 1, ty)) c.drawLine(x + 1f, y, x + 1f, y + T, line);
                if (!map.water(tx + 1, ty)) c.drawLine(x + T - 1f, y, x + T - 1f, y + T, line);
                break;
            }
            case TileMap.G_WOOD: {
                // floorboards
                line.setColor(0x30301800);
                line.setStrokeWidth(1f);
                for (int k = 1; k < 4; k++) c.drawLine(x, y + k * 8f, x + T, y + k * 8f, line);
                break;
            }
            default:
                break;
        }
    }

    /** Darker kerb where a road meets something that is not road. */
    private void edge(Canvas c, GroundSource map, int tx, int ty, float x, float y) {
        line.setColor(0x55101418);
        line.setStrokeWidth(2f);
        if (!isRoad(map.ground(tx, ty - 1))) c.drawLine(x, y + 1f, x + T, y + 1f, line);
        if (!isRoad(map.ground(tx, ty + 1))) c.drawLine(x, y + T - 1f, x + T, y + T - 1f, line);
        if (!isRoad(map.ground(tx - 1, ty))) c.drawLine(x + 1f, y, x + 1f, y + T, line);
        if (!isRoad(map.ground(tx + 1, ty))) c.drawLine(x + T - 1f, y, x + T - 1f, y + T, line);
    }

    private static boolean isRoad(byte g) {
        return g == TileMap.G_ROAD || g == TileMap.G_ROAD_H || g == TileMap.G_ROAD_V || g == TileMap.G_BRIDGE;
    }

    private void rail(Canvas c, float x0, float y0, float x1, float y1) {
        line.setColor(0xFF5A3A1C);
        line.setStrokeWidth(3.2f);
        c.drawLine(x0, y0, x1, y1, line);
    }
}
