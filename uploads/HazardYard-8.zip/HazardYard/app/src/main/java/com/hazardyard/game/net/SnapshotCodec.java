package com.hazardyard.game.net;

import com.hazardyard.game.core.GameConfig;
import com.hazardyard.game.core.GameState;
import com.hazardyard.game.core.MathUtil;
import com.hazardyard.game.core.Pickup;
import com.hazardyard.game.core.Player;
import com.hazardyard.game.core.TileMap;
import com.hazardyard.game.core.Zone;

/**
 * Compact world snapshot (host -> clients, 20 Hz). Layout after the type byte:
 * tick u16, phase u8, timeLeft u16 (1/10 s), countdown u8 (1/10 s), winner u8, pad mask (one bit per item pad, low
 * bit first, {@code (pads + 7) / 8} bytes), presentMask u8; for a battle royale then the safe zone (18 bytes: shrinks
 * begun u8, flags u8, centre x/y and radius, target centre x/y and radius as u16 in 1/4 unit, seconds left and stage
 * length as u16 in 1/10 s) and the items dropped during the match (count u8, then 9 bytes for each: extra pad u8, x u16,
 * y u16 in 1/4 unit, item u8, rounds in the gun u8 (255: a fresh one), spare rounds u16); then 17 bytes for every present player:
 * x i16, y i16 (1/4 unit), aim u8, health u8, armor u8, flags u8, weapon u8, ammo u8, reload u8,
 * ackSeq u8, kills u8, deaths u8, placement u8, respawn u8 (1/10 s), dodge cooldown u8 (1/100 s).
 */
public final class SnapshotCodec {
    private SnapshotCodec() {}

    public static final int F_ALIVE = 1;
    public static final int F_RELOADING = 2;
    public static final int F_PROTECTED = 4;
    public static final int F_ROLLING = 8;

    public static final int Z_SHRINKING = 1;
    public static final int Z_COLLAPSED = 2;

    /** Reusable decode target. */
    public static final class Data {
        public int tick, phase, timeLeftDs, countdownDs, winner, presentMask;
        /** Whether each item pad is still there (only the first {@code pads} entries are meaningful). */
        public final boolean[] padActive = new boolean[TileMap.MAX_PICKUPS + GameConfig.DROP_PADS];
        public int zoneShrinks, zoneFlags;
        public float zoneCx, zoneCy, zoneR, zoneToCx, zoneToCy, zoneToR, zoneTimer, zoneStage;
        /** Battleground: the items lying on the extra pads. For each: the pad (counted among the extra ones), where, what, the rounds in a gun (-1: a fresh one) and its spare rounds. */
        public int dropCount;
        public final int[] dropSlot = new int[GameConfig.DROP_PADS];
        public final float[] dropX = new float[GameConfig.DROP_PADS];
        public final float[] dropY = new float[GameConfig.DROP_PADS];
        public final int[] dropItem = new int[GameConfig.DROP_PADS];
        public final int[] dropAmmo = new int[GameConfig.DROP_PADS];
        public final int[] dropReserve = new int[GameConfig.DROP_PADS];
        public final float[] x = new float[GameConfig.MAX_PLAYERS];
        public final float[] y = new float[GameConfig.MAX_PLAYERS];
        public final float[] aim = new float[GameConfig.MAX_PLAYERS];
        public final int[] health = new int[GameConfig.MAX_PLAYERS];
        public final int[] armor = new int[GameConfig.MAX_PLAYERS];
        public final int[] flags = new int[GameConfig.MAX_PLAYERS];
        public final int[] weapon = new int[GameConfig.MAX_PLAYERS];
        public final int[] ammo = new int[GameConfig.MAX_PLAYERS];
        public final int[] reload = new int[GameConfig.MAX_PLAYERS];
        public final int[] ack = new int[GameConfig.MAX_PLAYERS];
        public final int[] kills = new int[GameConfig.MAX_PLAYERS];
        public final int[] deaths = new int[GameConfig.MAX_PLAYERS];
        public final int[] placement = new int[GameConfig.MAX_PLAYERS];
        public final int[] respawnDs = new int[GameConfig.MAX_PLAYERS];
        public final int[] dodgeCdCs = new int[GameConfig.MAX_PLAYERS];
        /** Battleground gear: active slot (bit 0), backpack level (bits 1-2), weapon swap under way (bit 3). */
        public final int[] gear = new int[GameConfig.MAX_PLAYERS];
        /** The weapon id of each slot (255 = empty), the rounds in the gun that is put away, and each slot's spare rounds (65535 = unlimited). */
        public final int[] slot0 = new int[GameConfig.MAX_PLAYERS];
        public final int[] slot1 = new int[GameConfig.MAX_PLAYERS];
        public final int[] otherAmmo = new int[GameConfig.MAX_PLAYERS];
        public final int[] reserve0 = new int[GameConfig.MAX_PLAYERS];
        public final int[] reserve1 = new int[GameConfig.MAX_PLAYERS];
    }

    public static byte[] encode(PacketWriter w, GameState st, int tick) {
        w.begin(Protocol.S_SNAPSHOT);
        w.u16(tick & 0xFFFF);
        w.u8(st.phase);
        w.u16(MathUtil.clamp(Math.round(st.timeLeft * 10f), 0, 65535));
        w.u8(MathUtil.clamp(Math.round(st.countdown * 10f), 0, 255));
        w.u8(st.winnerId < 0 ? 255 : st.winnerId);
        int pads = st.pickups.length;
        for (int b = 0; b < (pads + 7) >> 3; b++) {
            int v = 0;
            for (int bit = 0; bit < 8; bit++) {
                int i = b * 8 + bit;
                if (i < pads && st.pickups[i].active) v |= 1 << bit;
            }
            w.u8(v);
        }
        int present = 0;
        for (int i = 0; i < st.players.length; i++) {
            if (st.players[i].connected) present |= 1 << i;
        }
        w.u8(present);
        if (st.mode.royale) {
            Zone z = st.zone;
            w.u8(z.phase);
            w.u8((z.shrinking ? Z_SHRINKING : 0) | (z.collapsed ? Z_COLLAPSED : 0));
            w.u16(Packets.quantizeUnsigned(z.cx));
            w.u16(Packets.quantizeUnsigned(z.cy));
            w.u16(Packets.quantizeUnsigned(z.radius));
            w.u16(Packets.quantizeUnsigned(z.toCx));
            w.u16(Packets.quantizeUnsigned(z.toCy));
            w.u16(Packets.quantizeUnsigned(z.toRadius));
            w.u16(MathUtil.clamp(Math.round(z.timer * 10f), 0, 65535));
            w.u16(MathUtil.clamp(Math.round(z.stageLength * 10f), 0, 65535));
            // the items dropped during the match: the extra pads that are in use
            int countAt = w.size();
            w.u8(0);
            int dropped = 0;
            for (int i = st.mapPads; i < st.pickups.length && dropped < 255; i++) {
                Pickup pk = st.pickups[i];
                if (!pk.active) continue;
                w.u8(i - st.mapPads);
                w.u16(Packets.quantizeUnsigned(pk.x));
                w.u16(Packets.quantizeUnsigned(pk.y));
                w.u8(pk.item);
                w.u8(pk.ammo < 0 ? 255 : Math.min(254, pk.ammo));
                w.u16(MathUtil.clamp(pk.reserve, 0, 65535));
                dropped++;
            }
            w.setU8(countAt, dropped);
        }
        for (int i = 0; i < st.players.length; i++) {
            Player p = st.players[i];
            if (!p.connected) continue;
            w.i16(Packets.quantizePos(p.x));
            w.i16(Packets.quantizePos(p.y));
            w.u8(MathUtil.angleToU8(p.aim));
            w.u8(MathUtil.clamp(p.health, 0, 255));
            w.u8(MathUtil.clamp(p.armor, 0, 255));
            int flags = 0;
            if (p.alive) flags |= F_ALIVE;
            if (p.weapon.reloading) flags |= F_RELOADING;
            if (p.spawnProtect > 0f) flags |= F_PROTECTED;
            if (p.isRolling()) flags |= F_ROLLING;
            w.u8(flags);
            w.u8(p.weapon.def.id);
            w.u8(MathUtil.clamp(p.weapon.ammo, 0, 255));
            w.u8(MathUtil.clamp(Math.round(p.weapon.reloadFraction * 255f), 0, 255));
            w.u8(p.lastInputSeq);
            w.u8(MathUtil.clamp(p.kills, 0, 255));
            w.u8(MathUtil.clamp(p.deaths, 0, 255));
            w.u8(MathUtil.clamp(p.placement, 0, 255));
            w.u8(MathUtil.clamp((int) Math.ceil(p.respawnTimer * 10f), 0, 255));
            w.u8(MathUtil.clamp((int) Math.ceil(p.dodgeCooldown * 100f), 0, 255));
            if (st.mode.royale) {
                boolean slots = !p.bot;
                w.u8((slots ? p.activeSlot & 1 : 0) | ((slots ? p.backpack & 3 : 0) << 1) | (p.switchTimer > 0f ? 8 : 0));
                w.u8(slots ? (p.slotWeapon[0] < 0 ? 255 : p.slotWeapon[0]) : p.weapon.def.id);
                w.u8(slots ? (p.slotWeapon[1] < 0 ? 255 : p.slotWeapon[1]) : 255);
                w.u8(slots ? MathUtil.clamp(p.slotAmmo[1 - p.activeSlot], 0, 255) : 0);
                w.u16(slots ? MathUtil.clamp(p.slotReserve[0], 0, 65534) : 65535);
                w.u16(slots ? MathUtil.clamp(p.slotReserve[1], 0, 65534) : 0);
            }
        }
        return w.finishFrame();
    }

    /**
     * @param pads    number of item pads on the map (the sender and the receiver know it from the map)
     * @param royale  the match is a battle royale, so the frame carries the safe zone
     */
    public static void decode(PacketReader r, Data d, int pads, boolean royale) {
        d.tick = r.u16();
        d.phase = r.u8();
        d.timeLeftDs = r.u16();
        d.countdownDs = r.u8();
        int win = r.u8();
        d.winner = win == 255 ? -1 : win;
        int usable = Math.min(pads, d.padActive.length);
        for (int b = 0; b < (pads + 7) >> 3; b++) {
            int v = r.u8();
            for (int bit = 0; bit < 8; bit++) {
                int i = b * 8 + bit;
                if (i < usable) d.padActive[i] = (v & (1 << bit)) != 0;
            }
        }
        d.presentMask = r.u8();
        if (royale) {
            d.zoneShrinks = r.u8();
            d.zoneFlags = r.u8();
            d.zoneCx = r.u16() / GameConfig.POS_SCALE;
            d.zoneCy = r.u16() / GameConfig.POS_SCALE;
            d.zoneR = r.u16() / GameConfig.POS_SCALE;
            d.zoneToCx = r.u16() / GameConfig.POS_SCALE;
            d.zoneToCy = r.u16() / GameConfig.POS_SCALE;
            d.zoneToR = r.u16() / GameConfig.POS_SCALE;
            d.zoneTimer = r.u16() / 10f;
            d.zoneStage = r.u16() / 10f;
            int drops = r.u8();
            d.dropCount = 0;
            for (int k = 0; k < drops; k++) {
                int slot = r.u8();
                float dropX = r.u16() / GameConfig.POS_SCALE;
                float dropY = r.u16() / GameConfig.POS_SCALE;
                int item = r.u8();
                int rounds = r.u8();
                int spare = r.u16();
                int j = d.dropCount;
                if (j >= d.dropSlot.length) continue;
                d.dropSlot[j] = slot;
                d.dropX[j] = dropX;
                d.dropY[j] = dropY;
                d.dropItem[j] = item;
                d.dropAmmo[j] = rounds == 255 ? -1 : rounds;
                d.dropReserve[j] = spare;
                d.dropCount = j + 1;
            }
        }
        for (int i = 0; i < GameConfig.MAX_PLAYERS; i++) {
            if ((d.presentMask & (1 << i)) == 0) continue;
            d.x[i] = r.i16() / GameConfig.POS_SCALE;
            d.y[i] = r.i16() / GameConfig.POS_SCALE;
            d.aim[i] = MathUtil.u8ToAngle(r.u8());
            d.health[i] = r.u8();
            d.armor[i] = r.u8();
            d.flags[i] = r.u8();
            d.weapon[i] = r.u8();
            d.ammo[i] = r.u8();
            d.reload[i] = r.u8();
            d.ack[i] = r.u8();
            d.kills[i] = r.u8();
            d.deaths[i] = r.u8();
            d.placement[i] = r.u8();
            d.respawnDs[i] = r.u8();
            d.dodgeCdCs[i] = r.u8();
            if (royale) {
                d.gear[i] = r.u8();
                d.slot0[i] = r.u8();
                d.slot1[i] = r.u8();
                d.otherAmmo[i] = r.u8();
                d.reserve0[i] = r.u16();
                d.reserve1[i] = r.u16();
            }
        }
    }
}
