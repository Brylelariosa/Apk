package com.hazardyard.game.engine;

import com.hazardyard.game.core.Effects;
import com.hazardyard.game.core.GameState;
import com.hazardyard.game.core.Items;
import com.hazardyard.game.core.MathUtil;
import com.hazardyard.game.core.MeleeProfile;
import com.hazardyard.game.core.PlayerColors;
import com.hazardyard.game.core.Player;
import com.hazardyard.game.core.Puppet;
import com.hazardyard.game.core.PuppetStyle;
import com.hazardyard.game.core.Sounds;
import com.hazardyard.game.core.WeaponDef;
import com.hazardyard.game.survival.Zombie;
import com.hazardyard.game.survival.ZombieAnim;
import com.hazardyard.game.survival.ZombieLook;

/**
 * The visual and audible side of gameplay events, shared by every engine (host, solo, client) so a
 * muzzle flash or a kill looks and sounds the same wherever the match is simulated.
 */
final class Presentation {
    private Presentation() {}

    /** A weapon fired from (x, y): flash at the barrel tip, the shot sound, and a heard-shot ping for everyone but the local player. */
    static void shot(GameState st, int ownerId, int weaponId, float x, float y, float angle) {
        shot(st, ownerId, weaponId, x, y, angle, 0);
    }

    /** As above; for a melee weapon {@code variant} is which attack of its combo this swing is (it decides how it is animated). */
    static void shot(GameState st, int ownerId, int weaponId, float x, float y, float angle, int variant) {
        WeaponDef d = WeaponDef.byId(weaponId);
        if (d.melee) {
            // A swing: no flash and no heard-shot ping; the weapon sweeps (see UnitRenderer) and whooshes.
            if (ownerId >= 0 && ownerId < st.players.length) {
                Player o = st.players[ownerId];
                MeleeProfile prof = d.profile;
                float speed = prof != null ? prof.attack(variant).speed : 1f;
                o.swingT = 0f;
                o.swingDur = Math.max(0.22f, d.fireInterval * speed * 0.8f);
                o.swingVariant = variant;
                o.swingWeapon = d.id;
            }
            st.audio.shot(d.id, x, y);
            return;
        }
        st.effects.muzzle(d.muzzleX(x, angle), d.muzzleY(y, angle), angle, d.color);
        st.audio.shot(d.id, x, y);
        if (ownerId != st.localId) st.effects.noise(ownerId, x, y);
    }

    private static void impactFx(GameState st, int weaponId, float x, float y) {
        WeaponDef d = WeaponDef.byId(weaponId);
        if (d.style == WeaponDef.STYLE_ENERGY) st.effects.zap(x, y, d.color);
        else st.effects.impact(x, y, d.color);
    }

    static void hit(GameState st, int victimId, float x, float y, int weaponId, int damage) {
        if (weaponId >= 250 || WeaponDef.byId(weaponId).melee) {       // a melee blow, a zombie's bite, a car
            st.effects.impact(x, y, 0xFFB03030);
            if (damage > 0) st.audio.meleeHit(victimId, x, y);
            return;
        }
        impactFx(st, weaponId, x, y);
        if (damage > 0) st.audio.projectileHit(victimId, x, y);
    }

    static void wallImpact(GameState st, float x, float y, int weaponId) {
        impactFx(st, weaponId, x, y);
        st.audio.wallImpact(x, y);
    }

    /** An item was taken from pad {@code padIndex}: the pad pops (the pickup sound follows from the change in the taker's gear). */
    static void pickup(GameState st, int padIndex, int item) {
        if (padIndex < 0 || padIndex >= st.pickups.length) return;
        com.hazardyard.game.core.Pickup pk = st.pickups[padIndex];
        st.effects.pickup(pk.x, pk.y, Items.color(item));
    }

    static void kill(GameState st, int killerId, int victimId, int weaponId) {
        Effects fx = st.effects;
        fx.addKill(killerId, victimId, weaponId);
        if (victimId < 0 || victimId >= st.players.length) return;
        Player v = st.players[victimId];
        fx.burst(v.rx, v.ry, PlayerColors.of(victimId));
        st.audio.kill(killerId, victimId, v.rx, v.ry);
        float fromX = v.rx - (float) Math.cos(v.aim), fromY = v.ry - (float) Math.sin(v.aim);
        if (killerId >= 0 && killerId < st.players.length && killerId != victimId) {
            Player k = st.players[killerId];
            fromX = k.rx;
            fromY = k.ry;
        }
        fx.blood(v.rx, v.ry, (float) Math.atan2(v.ry - fromY, v.rx - fromX), 1.0f, BLOOD);
        soldierRagdoll(st, v, fromX, fromY);
    }

    // ------------------------------------------------------------------ zombies

    private static final Puppet scratchPuppet = new Puppet();
    private static final PuppetStyle scratchStyle = new PuppetStyle();
    private static final int BLOOD = 0xFFA81616;

    /**
     * A blow landed on a zombie (everybody gets this event): it flinches, stumbles, falls or dies. The body is thrown along the
     * blow, blood sprays that way and stains the ground, and a dead zombie leaves a ragdoll made from the pose it had
     * when it was struck. Heavy blows near the local player shake the view.
     */
    static void zombieEvent(GameState st, int id, int type, int kind, float x, float y, float angle, float strength, int damage) {
        if (st.survival == null) return;
        Zombie z = st.survival.zombieById(id);
        float dx = (float) Math.cos(angle), dy = (float) Math.sin(angle);
        Effects fx = st.effects;
        float force = Math.min(1.5f, strength);
        if (z != null) {
            z.hitDirX = dx;
            z.hitDirY = dy;
            z.hitT = 0f;
            z.hitK = strength;
            z.hurt = 0.18f;
        }
        fx.blood(x, y, angle, force * (kind == Zombie.EV_DEATH ? 1.35f : 1f), BLOOD);
        switch (kind) {
            case Zombie.EV_DEATH: {
                fx.decal(x + dx * 7f, y + dy * 7f, 5f + 6f * force, angle, 0xB0701212, 22f);
                if (z != null) z.dying = true;
                spawnZombieRagdoll(st, z, id, type, x, y, dx, dy, strength);
                break;
            }
            case Zombie.EV_KNOCKDOWN: {
                fx.decal(x + dx * 5f, y + dy * 5f, 4f + 4f * force, angle, 0x90701212, 14f);
                st.audio.bodyThud(x + dx * 12f, y + dy * 12f, 0.5f + 0.3f * force);
                if (z != null) {
                    z.fallDirX = dx;
                    z.fallDirY = dy;
                    z.setState(Puppet.A_FALL);
                    z.stateLock = 0.25f;
                }
                break;
            }
            case Zombie.EV_STUMBLE:
                if (z != null && !z.isDownish()) {
                    z.setState(Puppet.A_STUMBLE);
                    z.stateLock = 0.25f;
                }
                break;
            case Zombie.EV_GROUND_HIT:
                st.audio.bodyThud(x, y, 0.35f);
                break;
            default:
                if (z != null && !z.isDownish() && z.state != Puppet.A_STUMBLE && z.state != Puppet.A_ATTACK) {
                    z.setState(Puppet.A_HIT);
                    z.stateLock = 0.2f;
                }
                break;
        }
        // the view shakes for heavy blows close to the fighter being watched
        Player view = st.view();
        if (view != null && view.connected && (kind >= Zombie.EV_KNOCKDOWN || strength > 0.8f)) {
            float ddx = view.rx - x, ddy = view.ry - y;
            if (ddx * ddx + ddy * ddy < 110f * 110f) st.shakeRequest = Math.max(st.shakeRequest, 1.1f + 1.8f * Math.min(1f, strength));
        }
    }

    /** Starts a corpse from the pose the zombie had when it died (or a plain standing one if the zombie is not known here). */
    private static void spawnZombieRagdoll(GameState st, Zombie z, int id, int type, float x, float y, float dx, float dy, float strength) {
        ZombieLook.fill(type, ZombieLook.lookOf(id), scratchStyle);
        float aim;
        if (z != null) {
            aim = z.rAim;
            z.rx = x;
            z.ry = y;
            ZombieAnim.pose(z, scratchStyle, scratchPuppet, st.survival.time);
        } else {
            aim = (float) Math.atan2(-dy, -dx);
            scratchPuppet.anim = Puppet.A_IDLE;
            scratchPuppet.gait = 0f;
            scratchPuppet.t = 0f;
            scratchPuppet.hitT = 9f;
            scratchPuppet.hitK = 0f;
            scratchPuppet.attackP = 0f;
            scratchPuppet.scale = scratchStyle.scale;
            scratchPuppet.width = scratchStyle.width;
            scratchPuppet.build = scratchStyle.build;
            scratchPuppet.seed = (id * 0.6180339f) % 1f;
            scratchPuppet.clock = 0f;
            scratchPuppet.reach = 1f;
            scratchPuppet.compute();
        }
        st.ragdolls.spawn(scratchPuppet, x, y, aim, scratchStyle, dx, dy, strength);
    }

    /** A fighter has been killed: a fallen soldier flops to the ground from where it stood, thrown from the killer. */
    static void soldierRagdoll(GameState st, Player v, float fromX, float fromY) {
        scratchStyle.build = Puppet.B_SOLDIER;
        scratchStyle.accent = PlayerColors.of(v.id);
        scratchStyle.skin = 0xFFD8AE8C;
        scratchStyle.skinShade = 0xFFB08A6C;
        scratchStyle.shirt = 0xFF6A7A91;
        scratchStyle.sleeve = 0xFF6A7A91;
        scratchStyle.shirtShade = 0xFF56657B;
        scratchStyle.pants = 0xFF4A5565;
        scratchStyle.pantsShade = 0xFF3A4350;
        scratchStyle.shoe = 0xFF262C35;
        scratchStyle.hair = 0xFF2A2420;
        scratchStyle.eye = 0xFFFFFFFF;
        scratchStyle.outline = 0xFF1B1E22;
        scratchStyle.blood = 0xFF7A1C1C;
        scratchStyle.outfit = PuppetStyle.OUTFIT_SOLDIER;
        scratchStyle.hairStyle = PuppetStyle.HAIR_HELMET;
        scratchStyle.wounds = 0;
        scratchStyle.sleeveLen = 2;
        scratchStyle.longPants = true;
        scratchStyle.scale = 1.02f;
        scratchStyle.width = 1.18f;
        scratchPuppet.anim = Puppet.A_IDLE;
        scratchPuppet.gait = 0f;
        scratchPuppet.t = 0f;
        scratchPuppet.hitT = 9f;
        scratchPuppet.hitK = 0f;
        scratchPuppet.attackP = 0f;
        scratchPuppet.scale = scratchStyle.scale;
        scratchPuppet.width = scratchStyle.width;
        scratchPuppet.build = Puppet.B_SOLDIER;
        scratchPuppet.seed = (v.id * 0.37f) % 1f;
        scratchPuppet.clock = 0f;
        scratchPuppet.reach = 1f;
        scratchPuppet.compute();
        float dx = v.rx - fromX, dy = v.ry - fromY;
        float len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len < 1f) {
            dx = (float) -Math.cos(v.aim);
            dy = (float) -Math.sin(v.aim);
        }
        st.ragdolls.spawn(scratchPuppet, v.rx, v.ry, v.aim, scratchStyle, dx, dy, 0.85f);
        st.effects.decal(v.rx, v.ry, 7f, v.aim, 0x90701212, 18f);
    }
}
