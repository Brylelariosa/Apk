package com.hazardyard.game.render;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;

import com.hazardyard.game.core.Camera;
import com.hazardyard.game.core.GameConfig;
import com.hazardyard.game.core.GameState;
import com.hazardyard.game.core.Player;
import com.hazardyard.game.core.Puppet;
import com.hazardyard.game.core.TileMap;
import com.hazardyard.game.render.model.Projection;
import com.hazardyard.game.survival.Car;
import com.hazardyard.game.survival.Drop;
import com.hazardyard.game.survival.Obj;
import com.hazardyard.game.survival.SurvivalState;
import com.hazardyard.game.survival.SurvivalTerrain;
import com.hazardyard.game.survival.Zombie;

/**
 * Draws the endless survival world: ground, trees, ruined houses with their furniture, crops, campfires, then zombies,
 * cars, survivors and dropped items sorted by depth, and at night a darkness with a circle of light round the survivor.
 */
final class SurvivalRenderer {
    /** Draws one survivor (the regular soldier renderer). */
    interface PlayerDrawer {
        void draw(Canvas c, int playerIndex);
    }

    private static final float T = GameConfig.TILE;
    private static final float LEAN = Projection.LEAN;
    private static final float TILT = Projection.TILT;
    private static final float WALL_H = 24f;

    private final TerrainRenderer terrain = new TerrainRenderer();
    private final BodyDrawer bodies = new BodyDrawer();
    private final SurvivalHouses houses = new SurvivalHouses();
    private int bodyDetail = 2;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint night = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final Path path2 = new Path();
    private SurvivalTerrain src;
    private GroundSource groundSrc;
    private final float[] gx = new float[8];
    private final float[] gy = new float[8];

    // depth-sorted things that move
    private static final int K_PLAYER = 0, K_ZOMBIE = 1, K_CAR = 2, K_DROP = 3, K_RAGDOLL = 4;
    private static final int MAX_DYN = 160;
    private final int[] dynKind = new int[MAX_DYN];
    private final int[] dynIndex = new int[MAX_DYN];
    private final float[] dynKey = new float[MAX_DYN];
    private int nDyn;
    private int visibleBodies;

    private int nightW, nightH;
    private float lastLight = -1f;

    SurvivalRenderer() {
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeCap(Paint.Cap.ROUND);
    }

    private GroundSource groundOf(final SurvivalTerrain t) {
        if (src != t) {
            src = t;
            groundSrc = new GroundSource() {
                @Override
                public byte ground(int tx, int ty) {
                    return t.groundAt(tx, ty);
                }

                @Override
                public boolean water(int tx, int ty) {
                    return t.groundAt(tx, ty) == TileMap.G_WATER;
                }
            };
        }
        return groundSrc;
    }

    // ------------------------------------------------------------------ the world

    void draw(Canvas c, GameState st, Camera cam, float time, boolean lite, PlayerDrawer players, BlockRenderer blocks,
              float vx0, float vx1, float vy0, float vy1) {
        SurvivalState sv = st.survival;
        SurvivalTerrain t = sv.terrain;
        int tx0 = (int) Math.floor(vx0 / T) - 1, tx1 = (int) Math.floor(vx1 / T) + 1;
        int ty0 = (int) Math.floor(vy0 / T) - 1, ty1 = (int) Math.floor(vy1 / T) + 2;
        terrain.draw(c, groundOf(t), time, tx0, tx1, ty0, ty1, lite);
        shadows(c, t, tx0, tx1, ty0, ty1);
        Player viewer = st.view();
        houses.collect(t.gen, tx0, ty0, tx1, ty1, viewer.rx, viewer.ry, time);
        houses.drawPorches(c, t);
        bodies.beginFrame(time);
        bodies.drawDecals(c, st.effects, vx0, vx1, vy0, vy1);
        collect(st, cam);
        bodyDetail = BodyDrawer.detailFor(visibleBodies, lite);
        int d = 0;
        for (int ty = ty0; ty <= ty1; ty++) {
            float south = (ty + 1) * T;
            while (d < nDyn && dynKey[d] < south) drawDyn(c, st, d++, time, players, lite);
            for (int tx = tx0; tx <= tx1; tx++) {
                byte o = t.objAt(tx, ty);
                if (o != Obj.NONE) drawObject(c, t, blocks, o, tx, ty, t.metaAt(tx, ty), time, lite);
            }
            houses.drawRoofsOf(c, ty, lite, vx0, vx1, vy0, vy1);
        }
        while (d < nDyn) drawDyn(c, st, d++, time, players, lite);
        houses.drawRemainingRoofs(c, lite, vx0, vx1, vy0, vy1);
        drawFishing(c, st, time);
    }

    private void shadows(Canvas c, SurvivalTerrain t, int tx0, int tx1, int ty0, int ty1) {
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(0x33000000);
        for (int ty = ty0; ty <= ty1; ty++) {
            for (int tx = tx0; tx <= tx1; tx++) {
                byte o = t.objAt(tx, ty);
                if (o == Obj.TREE) c.drawCircle((tx + 0.5f) * T + 9f, (ty + 0.5f) * T + 9f, BlockRenderer.treeShadowRadius(tx, ty), fill);
                else if (o == Obj.ROCK) c.drawCircle((tx + 0.5f) * T + 6f, (ty + 0.5f) * T + 6f, 12f, fill);
                else if (o == Obj.BUSH) c.drawCircle((tx + 0.5f) * T + 3f, (ty + 0.5f) * T + 5f, 10f, fill);
            }
        }
    }

    private void collect(GameState st, Camera cam) {
        nDyn = 0;
        SurvivalState sv = st.survival;
        for (int i = 0; i < st.players.length; i++) {
            Player p = st.players[i];
            if (!p.connected || !p.alive || sv.drivingCar[i] >= 0 || !cam.isVisible(p.rx, p.ry, 60f)) continue;
            add(K_PLAYER, i, p.ry);
        }
        visibleBodies = 0;
        for (int i = 0; i < sv.zombies.length; i++) {
            Zombie z = sv.zombies[i];
            if (z.active && !z.dying && cam.isVisible(z.rx, z.ry, 60f)) {
                add(K_ZOMBIE, i, z.ry);
                visibleBodies++;
            }
        }
        for (int i = 0; i < st.ragdolls.active.length; i++) {
            if (!st.ragdolls.active[i]) continue;
            float px = st.ragdolls.x[i][Puppet.J_HIP_L], py = st.ragdolls.y[i][Puppet.J_HIP_L];
            if (!cam.isVisible(px, py, 70f)) continue;
            add(K_RAGDOLL, i, py);
            visibleBodies++;
        }
        for (int i = 0; i < sv.cars.length; i++) {
            Car car = sv.cars[i];
            if (car.active && cam.isVisible(car.rx, car.ry, 80f)) add(K_CAR, i, car.ry);
        }
        for (int i = 0; i < sv.drops.length; i++) {
            Drop dr = sv.drops[i];
            if (dr.active && cam.isVisible(dr.x, dr.y, 40f)) add(K_DROP, i, dr.y);
        }
    }

    private void add(int kind, int index, float key) {
        if (nDyn >= MAX_DYN) return;
        int i = nDyn++;
        while (i > 0 && dynKey[i - 1] > key) {
            dynKind[i] = dynKind[i - 1];
            dynIndex[i] = dynIndex[i - 1];
            dynKey[i] = dynKey[i - 1];
            i--;
        }
        dynKind[i] = kind;
        dynIndex[i] = index;
        dynKey[i] = key;
    }

    private void drawDyn(Canvas c, GameState st, int slot, float time, PlayerDrawer players, boolean lite) {
        SurvivalState sv = st.survival;
        int i = dynIndex[slot];
        switch (dynKind[slot]) {
            case K_PLAYER: players.draw(c, i); break;
            case K_ZOMBIE: bodies.drawZombie(c, sv.zombies[i], time, bodyDetail); break;
            case K_RAGDOLL: bodies.drawRagdoll(c, st.ragdolls, i, bodyDetail); break;
            case K_CAR: drawCar(c, sv.cars[i], time, sv.isNight()); break;
            default: drawDrop(c, sv.drops[i], time); break;
        }
    }

    // ------------------------------------------------------------------ objects

    private void drawObject(Canvas c, SurvivalTerrain t, BlockRenderer blocks, byte o, int tx, int ty, int meta, float time, boolean lite) {
        float x = tx * T, y = ty * T;
        switch (o) {
            case Obj.TREE: blocks.drawTree(c, tx, ty); break;
            case Obj.ROCK: blocks.drawRock(c, tx, ty); break;
            case Obj.WALL: drawWall(c, t, tx, ty, meta); break;
            case Obj.DOOR: drawDoor(c, t, tx, ty, meta); break;
            case Obj.CUPBOARD: box(c, x, y, 5f, 14f, 0xFFC09060, 0xFF9A7048, 0xFF785632, true, meta); break;
            case Obj.FRIDGE: box(c, x, y, 5f, 21f, 0xFFF0F4F8, 0xFFC4CCD4, 0xFF9AA4AE, true, meta); break;
            case Obj.SHELF: box(c, x, y, 4f, 19f, 0xFFA88050, 0xFF856038, 0xFF664A28, true, meta); shelfItems(c, x, y, 19f, meta); break;
            case Obj.WARDROBE: box(c, x, y, 4f, 26f, 0xFF8A6844, 0xFF6A4E30, 0xFF503A22, true, meta); break;
            case Obj.TOOLBOX: box(c, x, y, 8f, 10f, 0xFFD04A3C, 0xFFA03228, 0xFF7C241C, true, meta); break;
            case Obj.GUNCASE: box(c, x, y, 6f, 11f, 0xFF4A505C, 0xFF343942, 0xFF262A32, true, meta); break;
            case Obj.CRATE: box(c, x, y, 5f, 15f, 0xFFB8843C, 0xFF94672A, 0xFF744F1E, true, meta); crateSlats(c, x, y, 15f); break;
            case Obj.TABLE: box(c, x, y, 3f, 11f, 0xFF9A7A50, 0xFF7A5E3C, 0xFF5E462C, false, 0); break;
            case Obj.BED: bed(c, x, y); break;
            case Obj.WORKBENCH: box(c, x, y, 3f, 15f, 0xFFA88050, 0xFF856038, 0xFF664A28, false, 0); vise(c, x, y); break;
            case Obj.CAMPFIRE: drawFire(c, x, y, time); break;
            case Obj.CROP: drawCrop(c, x, y, meta, time); break;
            case Obj.BUSH: drawBush(c, x, y); break;
            case Obj.STUMP: stump(c, x, y); break;
            case Obj.RUBBLE: rubble(c, x, y, tx, ty); break;
            default: break;
        }
    }

    private void drawWall(Canvas c, SurvivalTerrain t, int tx, int ty, int meta) {
        boolean building = Obj.isBuildingWall(meta);
        int[] pal = building ? SurvivalHouses.WALLS[Obj.wallStyle(meta)] : null;
        int top = building ? pal[0] : 0xFFC79B5D;
        int front = building ? pal[1] : 0xFF9E7640;
        int side = building ? pal[2] : 0xFF745423;
        float x0 = tx * T, y0 = ty * T, x1 = x0 + T, y1 = y0 + T;
        float lean = LEAN * WALL_H, rise = TILT * WALL_H;
        boolean southFace = t.objAt(tx, ty + 1) != Obj.WALL;
        boolean westFace = t.objAt(tx - 1, ty) != Obj.WALL;
        if (southFace) {
            fill.setColor(front);
            quad(c, x0, y1, x1, y1, x1 + lean, y1 - rise, x0 + lean, y1 - rise);
            if (building) {
                // a darker plinth along the foot and a trim band under the eaves
                fill.setColor(pal[3]);
                quad(c, x0, y1, x1, y1, x1 + LEAN * 4f, y1 - TILT * 4f, x0 + LEAN * 4f, y1 - TILT * 4f);
                fill.setColor(0x26FFFFFF);
                quad(c, x0 + LEAN * 20f, y1 - TILT * 20f, x1 + LEAN * 20f, y1 - TILT * 20f, x1 + lean, y1 - rise, x0 + lean, y1 - rise);
                if (Obj.wallHasWindow(meta)) windowSouth(c, x0, y1);
            } else if (meta < 60) {                    // a damaged wall shows cracks
                line.setColor(0x88200E04);
                line.setStrokeWidth(1.4f);
                c.drawLine(x0 + 8f, y1 - 2f, x0 + 14f + lean, y1 - rise + 4f, line);
                c.drawLine(x0 + 20f, y1 - 3f, x0 + 17f + lean, y1 - rise + 6f, line);
            }
        }
        if (westFace) {
            fill.setColor(side);
            quad(c, x0, y0, x0, y1, x0 + lean, y1 - rise, x0 + lean, y0 - rise);
            if (building && Obj.wallHasWindow(meta)) windowWest(c, x0, y0);
        }
        fill.setColor(top);
        quad(c, x0 + lean, y0 - rise, x1 + lean, y0 - rise, x1 + lean, y1 - rise, x0 + lean, y1 - rise);
    }

    /** A window on a south wall face: a white frame, glass with a glint, and a sill. */
    private void windowSouth(Canvas c, float x0, float y1) {
        float a = x0 + 8f, b = x0 + T - 8f, z0 = 8f, z1 = 19f;
        fill.setColor(0xFFF4F6F8);
        quad(c, a - 1.5f + LEAN * z0, y1 - TILT * z0 + 0f, b + 1.5f + LEAN * z0, y1 - TILT * z0, b + 1.5f + LEAN * (z1 + 1.5f), y1 - TILT * (z1 + 1.5f), a - 1.5f + LEAN * (z1 + 1.5f), y1 - TILT * (z1 + 1.5f));
        fill.setColor(0xFF6E9CC0);
        quad(c, a + LEAN * z0, y1 - TILT * z0, b + LEAN * z0, y1 - TILT * z0, b + LEAN * z1, y1 - TILT * z1, a + LEAN * z1, y1 - TILT * z1);
        fill.setColor(0x55FFFFFF);
        float zm = (z0 + z1) * 0.5f;
        quad(c, a + LEAN * zm, y1 - TILT * zm, a + (b - a) * 0.45f + LEAN * zm, y1 - TILT * zm, a + (b - a) * 0.45f + LEAN * z1, y1 - TILT * z1, a + LEAN * z1, y1 - TILT * z1);
        line.setColor(0xFFF4F6F8);
        line.setStrokeWidth(1.1f);
        c.drawLine((a + b) * 0.5f + LEAN * z0, y1 - TILT * z0, (a + b) * 0.5f + LEAN * z1, y1 - TILT * z1, line);
        fill.setColor(0xFFB8BEC4);
        quad(c, a - 3f + LEAN * 7f, y1 - TILT * 7f, b + 3f + LEAN * 7f, y1 - TILT * 7f, b + 3f + LEAN * z0, y1 - TILT * z0, a - 3f + LEAN * z0, y1 - TILT * z0);
    }

    /** A window on a west wall face (seen at a slant). */
    private void windowWest(Canvas c, float x0, float y0) {
        float ya = y0 + 8f, yb = y0 + T - 8f, z0 = 8f, z1 = 19f;
        fill.setColor(0xFFE4E8EC);
        quad(c, x0 + LEAN * z0, ya - 1.5f - TILT * z0, x0 + LEAN * z0, yb + 1.5f - TILT * z0, x0 + LEAN * (z1 + 1.5f), yb + 1.5f - TILT * (z1 + 1.5f), x0 + LEAN * (z1 + 1.5f), ya - 1.5f - TILT * (z1 + 1.5f));
        fill.setColor(0xFF5E88AA);
        quad(c, x0 + LEAN * z0, ya - TILT * z0, x0 + LEAN * z0, yb - TILT * z0, x0 + LEAN * z1, yb - TILT * z1, x0 + LEAN * z1, ya - TILT * z1);
    }

    /** True for the ground a building has indoors. */
    private static boolean indoors(byte g) {
        return g == TileMap.G_WOOD || g == TileMap.G_TILES || g == TileMap.G_CONCRETE;
    }

    /** An axis-aligned block between heights z0 and z1: its lit top, south face and west face. */
    private void solid(Canvas c, float x0, float y0, float x1, float y1, float z0, float z1, int top, int frontC, int sideC) {
        float l0 = LEAN * z0, r0 = TILT * z0, l1 = LEAN * z1, r1 = TILT * z1;
        fill.setColor(frontC);
        quad(c, x0 + l0, y1 - r0, x1 + l0, y1 - r0, x1 + l1, y1 - r1, x0 + l1, y1 - r1);
        fill.setColor(sideC);
        quad(c, x0 + l0, y0 - r0, x0 + l0, y1 - r0, x0 + l1, y1 - r1, x0 + l1, y0 - r1);
        fill.setColor(top);
        quad(c, x0 + l1, y0 - r1, x1 + l1, y0 - r1, x1 + l1, y1 - r1, x0 + l1, y1 - r1);
    }

    /**
     * A proper door: a frame (two posts and a lintel) in the wall, and a leaf that either fills the opening or, when the
     * door is open, stands swung back against the inside of the wall, hinged at one post. The leaf swings into the building.
     */
    private void drawDoor(Canvas c, SurvivalTerrain t, int tx, int ty, int meta) {
        boolean open = (meta & 1) != 0;
        float x = tx * T, y = ty * T;
        boolean eastWest = isWallish(t, tx - 1, ty) || isWallish(t, tx + 1, ty);
        int frame = 0xFF5E3D1E, frameFront = 0xFF7A5230, frameSide = 0xFF4A2F16;
        int leafTop = 0xFFC08A52, leafFront = 0xFF9A6A38, leafSide = 0xFF74502A;
        float h = 21f;
        if (eastWest) {
            boolean northInside = indoors(t.groundAt(tx, ty - 1));
            float yFace = northInside ? y + T : y;               // the wall face the door sits in: the outer one
            // the floor of the doorway (a wooden threshold)
            fill.setColor(0xFF7A5630);
            c.drawRect(x, y + 2f, x + T, y + T - 2f, fill);
            if (open) {
                // the swung leaf stands against the inside of the wall, hinged at the west post
                float ya = northInside ? y + T - 24f : y + 6f, yb = northInside ? y + T - 6f : y + 24f;
                solid(c, x + 3.5f, ya, x + 7f, yb, 0f, 18f, leafTop, leafFront, leafSide);
                // the dark of the room beyond
                fill.setColor(0xFF2E2016);
                float yo = northInside ? y + T : y;
                quad(c, x + 4f + LEAN * 1f, yo - TILT * 1f, x + T - 4f + LEAN * 1f, yo - TILT * 1f, x + T - 4f + LEAN * 18f, yo - TILT * 18f, x + 4f + LEAN * 18f, yo - TILT * 18f);
                solid(c, x + 3.5f, ya, x + 7f, yb, 0f, 18f, leafTop, leafFront, leafSide);
            }
            solid(c, x, y, x + 3.5f, y + T, 0f, h, frame, frameFront, frameSide);
            solid(c, x + T - 3.5f, y, x + T, y + T, 0f, h, frame, frameFront, frameSide);
            solid(c, x, y, x + T, y + T, 18f, h, frame, frameFront, frameSide);
            if (!open) {
                // the leaf is flush with the outer face of the wall: panels and a knob can be seen
                float y0 = northInside ? y + T - 5f : y + 1.5f, y1 = northInside ? y + T - 1.5f : y + 5f;
                solid(c, x + 3.5f, y0, x + T - 3.5f, y1, 0f, 18f, leafTop, leafFront, leafSide);
                float yf = y1;
                fill.setColor(0xFF84582C);
                quad(c, x + 8f + LEAN * 3f, yf - TILT * 3f, x + T - 8f + LEAN * 3f, yf - TILT * 3f, x + T - 8f + LEAN * 9f, yf - TILT * 9f, x + 8f + LEAN * 9f, yf - TILT * 9f);
                quad(c, x + 8f + LEAN * 11f, yf - TILT * 11f, x + T - 8f + LEAN * 11f, yf - TILT * 11f, x + T - 8f + LEAN * 16f, yf - TILT * 16f, x + 8f + LEAN * 16f, yf - TILT * 16f);
                fill.setColor(0xFFE8D090);
                c.drawCircle(x + T - 9f + LEAN * 9f, yf - TILT * 9f, 1.8f, fill);
            }
        } else {
            boolean westInside = indoors(t.groundAt(tx - 1, ty));
            fill.setColor(0xFF6A4A2C);
            c.drawRect(x + 2f, y, x + T - 2f, y + T, fill);
            if (open) {
                float xa = westInside ? x + T * 0.5f - 22f : x + T * 0.5f, xb = westInside ? x + T * 0.5f : x + T * 0.5f + 22f;
                solid(c, xa, y + 4f, xb, y + 7.5f, 0f, 18f, leafTop, leafFront, leafSide);
            }
            solid(c, x + 8f, y, x + T - 8f, y + 4.5f, 0f, h, frame, frameFront, frameSide);
            solid(c, x + 8f, y + T - 4.5f, x + T - 8f, y + T, 0f, h, frame, frameFront, frameSide);
            solid(c, x + 8f, y, x + T - 8f, y + T, 18f, h, frame, frameFront, frameSide);
            if (!open) {
                solid(c, x + T * 0.5f - 2f, y + 4.5f, x + T * 0.5f + 2f, y + T - 4.5f, 0f, 18f, leafTop, leafFront, leafSide);
            }
        }
    }

    private static boolean isWallish(SurvivalTerrain t, int tx, int ty) {
        byte o = t.objAt(tx, ty);
        return o == Obj.WALL || o == Obj.DOOR || o == Obj.RUBBLE;
    }

    /** A box standing on a tile, inset from the edges; drawn with a lit top, a south face and a west face. */
    private void box(Canvas c, float x, float y, float inset, float h, int top, int front, int side, boolean searchable, int meta) {
        float x0 = x + inset, y0 = y + inset, x1 = x + T - inset, y1 = y + T - inset;
        float lean = LEAN * h, rise = TILT * h;
        boolean done = searchable && (meta & Obj.SEARCHED) != 0;
        if (done) {
            top = dim(top);
            front = dim(front);
            side = dim(side);
        }
        fill.setColor(front);
        quad(c, x0, y1, x1, y1, x1 + lean, y1 - rise, x0 + lean, y1 - rise);
        fill.setColor(side);
        quad(c, x0, y0, x0, y1, x0 + lean, y1 - rise, x0 + lean, y0 - rise);
        fill.setColor(top);
        quad(c, x0 + lean, y0 - rise, x1 + lean, y0 - rise, x1 + lean, y1 - rise, x0 + lean, y1 - rise);
        if (searchable && !done) {
            // a little glint on furniture that has not been searched yet
            float a = 0.5f + 0.5f * (float) Math.sin(glint + x * 0.05f + y * 0.03f);
            fill.setColor(((int) (140 + 100 * a) << 24) | 0xFFE680);
            float sx = (x0 + x1) * 0.5f + lean, sy = y0 - rise + (y1 - y0) * 0.35f;
            c.drawCircle(sx, sy, 2.1f, fill);
            line.setColor(((int) (110 * a) << 24) | 0xFFE680);
            line.setStrokeWidth(1f);
            c.drawLine(sx - 4.5f, sy, sx + 4.5f, sy, line);
            c.drawLine(sx, sy - 4.5f, sx, sy + 4.5f, line);
        }
    }

    private float glint;

    private static int dim(int argb) {
        int r = ((argb >> 16) & 255) * 7 / 10, g = ((argb >> 8) & 255) * 7 / 10, b = (argb & 255) * 7 / 10;
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    private void shelfItems(Canvas c, float x, float y, float h, int meta) {
        float lean = LEAN * h, rise = TILT * h;
        int[] cols = {0xFFE05A4A, 0xFF58A6FF, 0xFFE8C84A, 0xFF6EE08A};
        for (int i = 0; i < 4; i++) {
            fill.setColor(cols[i]);
            c.drawRect(x + 7f + i * 5f + lean, y + 8f - rise, x + 10f + i * 5f + lean, y + 11f - rise, fill);
        }
    }

    private void crateSlats(Canvas c, float x, float y, float h) {
        float lean = LEAN * h, rise = TILT * h;
        line.setColor(0x55402010);
        line.setStrokeWidth(1.3f);
        c.drawLine(x + 5f + lean, y + 5f - rise, x + T - 5f + lean, y + T - 5f - rise, line);
        c.drawLine(x + T - 5f + lean, y + 5f - rise, x + 5f + lean, y + T - 5f - rise, line);
    }

    private void bed(Canvas c, float x, float y) {
        box(c, x, y, 3f, 9f, 0xFF6A8FC0, 0xFF4E6E98, 0xFF3C5878, false, 0);
        float lean = LEAN * 9f, rise = TILT * 9f;
        fill.setColor(0xFFF2F2F2);
        c.drawRoundRect(x + 5f + lean, y + 5f - rise, x + T - 5f + lean, y + 12f - rise, 3f, 3f, fill);
    }

    private void vise(Canvas c, float x, float y) {
        float lean = LEAN * 15f, rise = TILT * 15f;
        fill.setColor(0xFF6A727E);
        c.drawRect(x + 21f + lean, y + 9f - rise, x + 27f + lean, y + 17f - rise, fill);
        line.setColor(0xFFC8CED8);
        line.setStrokeWidth(1.6f);
        c.drawLine(x + 7f + lean, y + 12f - rise, x + 17f + lean, y + 22f - rise, line);
    }

    private void drawFire(Canvas c, float x, float y, float time) {
        float cx = x + T * 0.5f, cy = y + T * 0.62f;
        fill.setColor(0x33000000);
        c.drawOval(cx - 13f, cy - 2f, cx + 13f, cy + 7f, fill);
        line.setStrokeWidth(4.2f);
        line.setColor(0xFF4A2F1A);
        c.drawLine(cx - 11f, cy + 2f, cx + 10f, cy - 3f, line);
        c.drawLine(cx - 10f, cy - 3f, cx + 11f, cy + 3f, line);
        line.setColor(0xFF6A4424);
        line.setStrokeWidth(2f);
        c.drawLine(cx - 11f, cy + 1f, cx + 9f, cy - 4f, line);
        float f = (float) Math.sin(time * 11f + x) * 1.6f;
        path.reset();
        path.moveTo(cx - 6f, cy - 1f);
        path.lineTo(cx - 3f + f, cy - 12f);
        path.lineTo(cx + f * 0.5f, cy - 7f);
        path.lineTo(cx + 3f - f, cy - 15f - f);
        path.lineTo(cx + 6f, cy - 1f);
        path.close();
        fill.setColor(0xFFFF8A2A);
        c.drawPath(path, fill);
        path.reset();
        path.moveTo(cx - 3f, cy - 1f);
        path.lineTo(cx + f * 0.4f, cy - 8f);
        path.lineTo(cx + 3f, cy - 1f);
        path.close();
        fill.setColor(0xFFFFE070);
        c.drawPath(path, fill);
    }

    private void drawCrop(Canvas c, float x, float y, int meta, float time) {
        int stage = meta & 3;
        boolean potato = ((meta >> 2) & 3) == 1;
        float cx = x + T * 0.5f, cy = y + T * 0.6f;
        line.setStrokeWidth(2f);
        for (int k = -1; k <= 1; k++) {
            float px = cx + k * 9f, py = cy + 3f;
            float h = 3f + stage * 5f;
            line.setColor(potato ? 0xFF5E9A3A : 0xFF6FB04A);
            c.drawLine(px, py, px - 2f, py - h, line);
            c.drawLine(px, py, px + 2.4f, py - h * 0.8f, line);
            if (stage >= 2) c.drawLine(px, py, px + 0.4f, py - h * 1.1f, line);
            if (stage == 3) {
                fill.setColor(potato ? 0xFFF2E27A : 0xFFFF9534);
                c.drawCircle(px, py + 1f, 2.6f, fill);
            }
        }
    }

    private void drawBush(Canvas c, float x, float y) {
        float cx = x + T * 0.5f, cy = y + T * 0.55f;
        fill.setColor(0xFF2E7A36);
        c.drawCircle(cx - 5f, cy, 9f, fill);
        c.drawCircle(cx + 5f, cy + 1f, 9f, fill);
        fill.setColor(0xFF4A9A44);
        c.drawCircle(cx, cy - 5f, 9f, fill);
        fill.setColor(0xFFB04AC8);
        c.drawCircle(cx - 4f, cy - 4f, 1.9f, fill);
        c.drawCircle(cx + 5f, cy - 1f, 1.9f, fill);
        c.drawCircle(cx - 1f, cy + 3f, 1.9f, fill);
    }

    private void stump(Canvas c, float x, float y) {
        float cx = x + T * 0.5f, cy = y + T * 0.55f;
        fill.setColor(0xFF4A2F1A);
        c.drawOval(cx - 8f, cy - 3f, cx + 8f, cy + 6f, fill);
        fill.setColor(0xFFC8A06A);
        c.drawOval(cx - 8f, cy - 6f, cx + 8f, cy + 3f, fill);
        line.setColor(0xFF9A7448);
        line.setStrokeWidth(1f);
        c.drawOval(cx - 4f, cy - 4f, cx + 4f, cy + 1f, line);
    }

    private void rubble(Canvas c, float x, float y, int tx, int ty) {
        fill.setColor(0xFF7A6A58);
        int h = FloorRenderer.hash(tx, ty);
        for (int k = 0; k < 4; k++) {
            float rx = x + 5f + ((h >> (k * 4)) & 15) * 1.4f, ry = y + 6f + ((h >> (k * 3 + 2)) & 15) * 1.2f;
            c.drawRect(rx, ry, rx + 4f + (k & 1) * 2f, ry + 3f, fill);
        }
    }

    // ------------------------------------------------------------------ moving things

    private void drawDrop(Canvas c, Drop d, float time) {
        float bob = (float) Math.sin(time * 3f + d.id) * 1.4f;
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(0x44000000);
        c.drawOval(d.x - 8f, d.y - 2f, d.x + 8f, d.y + 4f, fill);
        int col = 0xFF000000 | (com.hazardyard.game.core.Items.color(d.item) & 0x00FFFFFF);
        fill.setColor((col & 0x00FFFFFF) | 0x33000000);
        c.drawCircle(d.x, d.y - 8f, 12f, fill);
        ItemGlyph.draw(c, fill, path2, d.x, d.y - 9f + bob, 7.5f, d.item, col);
    }

    private void drawCar(Canvas c, Car car, float time, boolean night) {
        float x = car.rx, y = car.ry, h = car.rHeading;
        float cs = (float) Math.cos(h), sn = (float) Math.sin(h);
        float px = -sn, py = cs;
        int[] bodies = {0xFFB8403A, 0xFF3A6AA8, 0xFFC8B84A, 0xFF4A8A5A, 0xFFD8D8DC, 0xFF3A3E46};
        int v = Math.abs(car.variant);
        int body = bodies[v % bodies.length];
        int shape = (v / bodies.length) % 3;                 // 0 saloon, 1 pickup, 2 van
        if (!car.engineOk || car.hp < 25) body = rust(body);
        int glass = 0xFF2E3C4C, glassLit = 0xFF8CBAD8;
        // shadow
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(0x44000000);
        poly4(x + 3f, y + 5f, cs, sn, px, py, shape == 2 ? 27f : 25f, 13f);
        c.drawPath(path, fill);
        // wheels, with dark arches round them
        float axle = shape == 2 ? 16f : 15f;
        for (int fx = -1; fx <= 1; fx += 2) {
            for (int sx = -1; sx <= 1; sx += 2) {
                float wx = x + cs * axle * fx + px * 12f * sx, wy = y + sn * axle * fx + py * 12f * sx;
                fill.setColor(0xFF15171B);
                c.drawCircle(wx, wy - 2f, 5.6f, fill);
                fill.setColor(car.tyresOk ? 0xFF2A2D33 : 0xFF50555E);
                c.drawCircle(wx, wy - 2f, 4.6f, fill);
            }
        }
        // the lower body, then the cabin
        extrude(c, x, y, cs, sn, px, py, shape == 2 ? 26f : 24f, 11.5f, 8f, body, shade(body, 0.78f), shade(body, 0.6f));
        // bonnet and boot are a shade apart; a bumper at each end
        fill.setColor(shade(body, 1.12f));
        pathRect(c, x, y, cs, sn, px, py, 17f, 23f, 9.5f, 8f);
        fill.setColor(shade(body, 0.9f));
        pathRect(c, x, y, cs, sn, px, py, -23f, -17f, 9.5f, 8f);
        if (shape == 0) {
            extrude(c, x - cs * 2f, y - sn * 2f, cs, sn, px, py, 12f, 9.5f, 15f, shade(body, 1.08f), shade(body, 0.72f), shade(body, 0.55f), 8f);
            glassPane(c, x, y, cs, sn, px, py, 9f, 13f, 7.5f, 11f, glassLit);
            glassPane(c, x, y, cs, sn, px, py, -13f, -10f, 7.5f, 11f, glass);
        } else if (shape == 1) {
            // a pickup: the cab at the front, an open bed behind it
            extrude(c, x + cs * 6f, y + sn * 6f, cs, sn, px, py, 8.5f, 9.5f, 15f, shade(body, 1.08f), shade(body, 0.72f), shade(body, 0.55f), 8f);
            glassPane(c, x, y, cs, sn, px, py, 12f, 16f, 7.5f, 11f, glassLit);
            fill.setColor(0xFF2B2E33);
            pathRect(c, x, y, cs, sn, px, py, -22f, -5f, 9f, 8.5f);
            fill.setColor(shade(body, 1.2f));
            pathRect(c, x, y, cs, sn, px, py, -22f, -5f, 9.5f, 8.3f);
            fill.setColor(0xFF2B2E33);
            pathRect(c, x, y, cs, sn, px, py, -21f, -6f, 8.2f, 9.5f);
        } else {
            // a van: one tall box
            extrude(c, x - cs * 1f, y - sn * 1f, cs, sn, px, py, 21f, 10.5f, 16f, shade(body, 1.1f), shade(body, 0.72f), shade(body, 0.55f), 8f);
            glassPane(c, x, y, cs, sn, px, py, 17f, 21f, 7.5f, 12f, glassLit);
        }
        // roof gleam
        // lights
        float lx = shape == 2 ? 27f : 25f;
        fill.setColor(car.running ? 0xFFFFF2B0 : (night ? 0x66FFF2B0 : 0xFFE8E8E0));
        c.drawCircle(x + cs * lx + px * 8f + LEAN * 5f, y + sn * lx + py * 8f - TILT * 5f, car.running ? 2.6f : 2.0f, fill);
        c.drawCircle(x + cs * lx - px * 8f + LEAN * 5f, y + sn * lx - py * 8f - TILT * 5f, car.running ? 2.6f : 2.0f, fill);
        fill.setColor(0xFFC8302A);
        c.drawCircle(x - cs * lx + px * 8f + LEAN * 5f, y - sn * lx + py * 8f - TILT * 5f, 1.8f, fill);
        c.drawCircle(x - cs * lx - px * 8f + LEAN * 5f, y - sn * lx - py * 8f - TILT * 5f, 1.8f, fill);
        if (car.running) {
            fill.setColor(0x22FFF2B0);
            c.drawCircle(x + cs * 38f + LEAN * 4f, y + sn * 38f - TILT * 4f, 14f, fill);
        }
        if (car.running && car.speed > 20f) {
            fill.setColor(0x33FFFFFF);
            c.drawCircle(x - cs * 30f + LEAN * 4f, y - sn * 30f - TILT * 4f, 3f + (float) Math.sin(time * 20f), fill);
        }
        if (!car.engineOk && !car.running) {
            fill.setColor(0x44505050);
            c.drawCircle(x + cs * 18f + LEAN * 12f + (float) Math.sin(time * 2f) * 2f, y + sn * 18f - TILT * 12f - 6f - (time * 6f % 8f), 4f, fill);
        }
    }

    /** A flat rectangle on the car's top (between the lengthwise offsets a and b, half-width w, height z): the paint of bonnet and boot. */
    private void pathRect(Canvas c, float x, float y, float cs, float sn, float px, float py, float a, float b, float w, float z) {
        float lx = LEAN * z, ly = -TILT * z;
        path.reset();
        path.moveTo(x + cs * a + px * w + lx, y + sn * a + py * w + ly);
        path.lineTo(x + cs * b + px * w + lx, y + sn * b + py * w + ly);
        path.lineTo(x + cs * b - px * w + lx, y + sn * b - py * w + ly);
        path.lineTo(x + cs * a - px * w + lx, y + sn * a - py * w + ly);
        path.close();
        c.drawPath(path, fill);
    }

    /** A window of the cabin seen from above, a little above the roof line. */
    private void glassPane(Canvas c, float x, float y, float cs, float sn, float px, float py, float a, float b, float w, float z, int color) {
        fill.setColor(color);
        pathRect(c, x, y, cs, sn, px, py, a, b, w, z);
    }

    private static int rust(int c) {
        int r = ((c >> 16) & 255) * 6 / 10 + 40, g = ((c >> 8) & 255) * 5 / 10 + 20, b = (c & 255) * 4 / 10 + 10;
        return 0xFF000000 | (Math.min(255, r) << 16) | (Math.min(255, g) << 8) | Math.min(255, b);
    }

    private static int shade(int c, float k) {
        int r = Math.min(255, (int) (((c >> 16) & 255) * k)), g = Math.min(255, (int) (((c >> 8) & 255) * k)), b = Math.min(255, (int) ((c & 255) * k));
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    private void poly4(float x, float y, float cs, float sn, float px, float py, float half, float wide) {
        path.reset();
        path.moveTo(x + cs * half + px * wide, y + sn * half + py * wide);
        path.lineTo(x + cs * half - px * wide, y + sn * half - py * wide);
        path.lineTo(x - cs * half - px * wide, y - sn * half - py * wide);
        path.lineTo(x - cs * half + px * wide, y - sn * half + py * wide);
        path.close();
    }

    private void extrude(Canvas c, float x, float y, float cs, float sn, float px, float py, float half, float wide, float h,
                         int top, int sideA, int sideB) {
        extrude(c, x, y, cs, sn, px, py, half, wide, h, top, sideA, sideB, 0f);
    }

    /** A box seen from the side: its visible walls, then its top, raised by {@code lift} (a cabin on a body). */
    private void extrude(Canvas c, float x, float y, float cs, float sn, float px, float py, float half, float wide, float h,
                         int top, int sideA, int sideB, float lift) {
        gx[0] = x + cs * half + px * wide;
        gy[0] = y + sn * half + py * wide;
        gx[1] = x + cs * half - px * wide;
        gy[1] = y + sn * half - py * wide;
        gx[2] = x - cs * half - px * wide;
        gy[2] = y - sn * half - py * wide;
        gx[3] = x - cs * half + px * wide;
        gy[3] = y - sn * half + py * wide;
        float vx = LEAN * h, vy = -TILT * h;
        float bx = LEAN * lift, by = -TILT * lift;
        for (int i = 0; i < 4; i++) {
            int j = (i + 1) & 3;
            float ex = gx[j] - gx[i], ey = gy[j] - gy[i];
            float nx = ey, ny = -ex;
            float mx = (gx[i] + gx[j]) * 0.5f - x, my = (gy[i] + gy[j]) * 0.5f - y;
            if (nx * mx + ny * my < 0f) {
                nx = -nx;
                ny = -ny;
            }
            if (nx * vx + ny * vy >= 0f) continue;         // this wall faces away from the viewer
            path.reset();
            path.moveTo(gx[i] + bx, gy[i] + by);
            path.lineTo(gx[j] + bx, gy[j] + by);
            path.lineTo(gx[j] + bx + vx, gy[j] + by + vy);
            path.lineTo(gx[i] + bx + vx, gy[i] + by + vy);
            path.close();
            fill.setColor(ny > 0.3f ? sideA : sideB);
            c.drawPath(path, fill);
        }
        path.reset();
        path.moveTo(gx[0] + bx + vx, gy[0] + by + vy);
        path.lineTo(gx[1] + bx + vx, gy[1] + by + vy);
        path.lineTo(gx[2] + bx + vx, gy[2] + by + vy);
        path.lineTo(gx[3] + bx + vx, gy[3] + by + vy);
        path.close();
        fill.setColor(top);
        c.drawPath(path, fill);
    }

    private void drawFishing(Canvas c, GameState st, float time) {
        SurvivalState sv = st.survival;
        for (int i = 0; i < st.players.length; i++) {
            if (sv.fishState[i] == 0) continue;
            Player p = st.players[i];
            if (!p.connected || !p.alive) continue;
            float fx = sv.fishX[i], fy = sv.fishY[i];
            boolean bite = sv.fishState[i] == 2;
            float dip = bite ? (float) Math.sin(time * 30f) * 1.5f + 2f : (float) Math.sin(time * 2.5f) * 0.8f;
            float hx = p.rx + (float) Math.cos(p.rAim) * 10f + LEAN * 12f, hy = p.ry + (float) Math.sin(p.rAim) * 10f - TILT * 12f;
            line.setColor(0xCCFFFFFF);
            line.setStrokeWidth(1.1f);
            c.drawLine(hx, hy, fx, fy + dip, line);
            line.setColor(0x66FFFFFF);
            line.setStrokeWidth(1.2f);
            float ring = (time * 14f) % 10f;
            c.drawCircle(fx, fy, 3f + ring, line);
            fill.setColor(0xFFE04A4A);
            c.drawCircle(fx, fy + dip, 3.6f, fill);
            fill.setColor(0xFFFFFFFF);
            c.drawCircle(fx, fy + dip - 1.6f, 1.8f, fill);
            if (bite) {
                fill.setColor(0xFFFFE066);
                c.drawCircle(fx, fy - 20f, 6f, fill);
                fill.setColor(0xFF402000);
                c.drawRect(fx - 1f, fy - 25f, fx + 1f, fy - 20f, fill);
                c.drawCircle(fx, fy - 16.5f, 1.1f, fill);
            }
        }
    }

    // ------------------------------------------------------------------ night

    /** Called after the world is drawn, in screen space: the dark, a circle of light round the survivor, warm light at fires. */
    void drawNight(Canvas c, GameState st, Camera cam, float time) {
        SurvivalState sv = st.survival;
        float light = sv.daylight();
        glint = time * 3f;
        if (light >= 0.97f) return;
        float dark = (1f - light);
        Player v = st.view();
        float sx = cam.screenX(v.rx), sy = cam.screenY(v.ry - 8f);
        float radius = Math.max(150f, 240f * cam.scale);
        int edgeA = (int) (dark * 215f);
        int midA = (int) (dark * 150f);
        night.setShader(new RadialGradient(sx, sy, radius,
                new int[] {0x00060A18, 0x00060A18, (midA << 24) | 0x060A18, (edgeA << 24) | 0x040612},
                new float[] {0f, 0.22f, 0.62f, 1f}, Shader.TileMode.CLAMP));
        // beyond the circle: the same darkness, flat
        night.setStyle(Paint.Style.FILL);
        c.drawRect(0f, 0f, cam.viewW, cam.viewH, night);
        night.setShader(null);
        // campfires and car headlights glow warm in the dark
        float hw = cam.halfViewWorldW() + 60f, hh = cam.halfViewWorldH() + 60f;
        int tx0 = (int) Math.floor((cam.x - hw) / T), tx1 = (int) Math.floor((cam.x + hw) / T);
        int ty0 = (int) Math.floor((cam.y - hh) / T), ty1 = (int) Math.floor((cam.y + hh) / T);
        for (int ty = ty0; ty <= ty1; ty++) {
            for (int tx = tx0; tx <= tx1; tx++) {
                if (sv.terrain.objAt(tx, ty) != Obj.CAMPFIRE) continue;
                float fx = cam.screenX((tx + 0.5f) * T), fy = cam.screenY((ty + 0.5f) * T);
                float r = 130f * cam.scale * (0.92f + 0.08f * (float) Math.sin(time * 9f + tx));
                glow.setShader(new RadialGradient(fx, fy, r, new int[] {(int) (dark * 150f) << 24 | 0xFFA040, 0x00FF8A2A},
                        new float[] {0f, 1f}, Shader.TileMode.CLAMP));
                c.drawCircle(fx, fy, r, glow);
                glow.setShader(null);
            }
        }
        for (Car car : sv.cars) {
            if (!car.active || !car.running) continue;
            float fx = cam.screenX(car.rx + (float) Math.cos(car.rHeading) * 60f), fy = cam.screenY(car.ry + (float) Math.sin(car.rHeading) * 60f);
            float r = 120f * cam.scale;
            glow.setShader(new RadialGradient(fx, fy, r, new int[] {(int) (dark * 110f) << 24 | 0xFFF0B0, 0x00FFF0B0},
                    new float[] {0f, 1f}, Shader.TileMode.CLAMP));
            c.drawCircle(fx, fy, r, glow);
            glow.setShader(null);
        }
    }

    private void quad(Canvas c, float ax, float ay, float bx, float by, float cx, float cy, float dx, float dy) {
        path.reset();
        path.moveTo(ax, ay);
        path.lineTo(bx, by);
        path.lineTo(cx, cy);
        path.lineTo(dx, dy);
        path.close();
        c.drawPath(path, fill);
    }
}
