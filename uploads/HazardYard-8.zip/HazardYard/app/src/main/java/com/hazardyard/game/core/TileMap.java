package com.hazardyard.game.core;

import java.util.Arrays;

/**
 * Tile grid of the arena. Walls, crates, round pillars, tanks and angled corner pieces block players
 * and bullets; fences and toxic pools block players only (bullets fly over them), which makes them
 * useful low cover and map dividers. Also holds spawn points, weapon pickup locations and a list of
 * merged solid blocks so the renderer draws a few dozen shapes instead of one per tile.
 *
 * <p>Not every solid tile fills its whole square: a fence is a thin line, a pillar and a tank are
 * circles, and an angled corner piece is a triangle. {@link CollisionSystem} uses the real shapes.
 */
public final class TileMap implements Terrain {
    public static final byte FLOOR = 0;
    public static final byte WALL = 1;
    public static final byte CRATE = 2;
    /** Chain-link fence: a thin line players cannot cross, bullets pass through. */
    public static final byte FENCE = 3;
    /** Toxic pool / canal: players cannot cross it, bullets pass over it. */
    public static final byte WATER = 4;
    /** Round column filling most of one tile. Stops players and bullets. */
    public static final byte PILLAR = 5;
    /** Big round tank covering a 2 x 2 block of tiles (all four tiles carry this kind). */
    public static final byte TANK = 6;
    /** Angled corner pieces: a triangle filling the named half of the tile. Stop players and bullets. */
    public static final byte WEDGE_NW = 7;
    public static final byte WEDGE_NE = 8;
    public static final byte WEDGE_SW = 9;
    public static final byte WEDGE_SE = 10;
    /** Only used in {@link #blocks}: one fence tile where runs meet (a corner, a T or a cross). */
    public static final byte FENCE_JOINT = 11;
    /** A tree: a round trunk that stops players and bullets; the crown above it is only drawn. */
    public static final byte TREE = 12;
    /** A boulder: a round block of stone that stops players and bullets. */
    public static final byte ROCK = 13;

    /**
     * Ground types of the outdoor map (a purely visual layer: they never change what blocks players or bullets).
     * Maps without terrain have none and are drawn as an indoor arena.
     */
    public static final byte G_GRASS = 0;
    public static final byte G_MEADOW = 1;
    public static final byte G_FOREST = 2;
    public static final byte G_DIRT = 3;
    public static final byte G_SAND = 4;
    public static final byte G_ROAD = 5;
    /** Road with the centre line running left-right / top-bottom. */
    public static final byte G_ROAD_H = 6;
    public static final byte G_ROAD_V = 7;
    public static final byte G_PAVED = 8;
    public static final byte G_FIELD = 9;
    public static final byte G_BRIDGE = 10;
    public static final byte G_ROCKY = 11;
    public static final byte G_WOOD = 12;
    public static final byte G_TILES = 13;
    public static final byte G_CONCRETE = 14;
    /** Survival world only: open water, and soil turned over with a hoe. */
    public static final byte G_WATER = 15;
    public static final byte G_TILLED = 16;
    public static final byte G_COUNT = 17;

    /** At most this many item pads on one map (the snapshot carries one bit for each). */
    public static final int MAX_PICKUPS = 400;

    public static final float TREE_RADIUS = 9f;
    public static final float ROCK_RADIUS = 13f;
    public static final float PILLAR_RADIUS = 13f;
    public static final float TANK_RADIUS = 30f;
    /** Half the thickness of a fence line for collision. */
    public static final float FENCE_HALF = 3f;

    /** Fence arms: which of the four directions from the tile centre carry fence. */
    public static final int ARM_L = 1;
    public static final int ARM_R = 2;
    public static final int ARM_U = 4;
    public static final int ARM_D = 8;

    /** Which {@link MapLibrary} entry this is (the renderer picks its theme from it). */
    public final int id;
    public final int width;
    public final int height;
    public final byte[] tiles;
    public final float worldW;
    public final float worldH;

    public final float[] spawnX;
    public final float[] spawnY;
    public final float[] pickupX;
    public final float[] pickupY;
    /** What lies on each pad: an {@link Items} id. */
    public final int[] pickupItem;

    /** Ground type of every tile, or null on a map without terrain (see {@code G_*}). */
    private final byte[] ground;
    /**
     * Buildings you can walk into, 5 ints each: first column, first row, last column, last row (the walls
     * included) and a style number the renderer picks the roof from. Sorted by their south edge.
     */
    public final int[] houses;
    public final int houseCount;
    private final short[] houseOf;

    // ---- doorways: the gaps in the outer walls of the houses (found on first use)
    private int[] doorways;
    private int doorwayCount;
    /** Fields of a doorway record ({@link #DOOR_STRIDE} ints each): the house, the wall (0 N, 1 E, 2 S, 3 W), the first tile along the wall and the width in tiles. */
    public static final int DOOR_STRIDE = 4, D_HOUSE = 0, D_SIDE = 1, D_START = 2, D_LEN = 3;

    /**
     * The doorways of every house: a run of walkable tiles in the ring of a house's outer wall (corners excluded), as long
     * as the tile outside it is walkable too. The renderer marks each with a frame, a step and a mat, and the map checks
     * guarantee each one leads somewhere.
     */
    public synchronized int[] doorways() {
        if (doorways != null) return doorways;
        int[] out = new int[Math.max(1, houseCount) * 3 * DOOR_STRIDE];
        int n = 0;
        for (int h = 0; h < houseCount; h++) {
            int x0 = houses[h * 5], y0 = houses[h * 5 + 1], x1 = houses[h * 5 + 2], y1 = houses[h * 5 + 3];
            for (int side = 0; side < 4; side++) {
                int from = (side == 0 || side == 2) ? x0 + 1 : y0 + 1;
                int to = (side == 0 || side == 2) ? x1 - 1 : y1 - 1;
                int runStart = -1;
                for (int a = from; a <= to + 1; a++) {
                    boolean gap = false;
                    if (a <= to) {
                        int tx = side == 1 ? x1 : (side == 3 ? x0 : a);
                        int ty = side == 0 ? y0 : (side == 2 ? y1 : a);
                        int ox = tx + (side == 1 ? 1 : (side == 3 ? -1 : 0)), oy = ty + (side == 2 ? 1 : (side == 0 ? -1 : 0));
                        gap = walkableTile(tx, ty) && walkableTile(ox, oy);
                    }
                    if (gap && runStart < 0) runStart = a;
                    if (!gap && runStart >= 0) {
                        if (n < out.length / DOOR_STRIDE) {
                            out[n * DOOR_STRIDE] = h;
                            out[n * DOOR_STRIDE + 1] = side;
                            out[n * DOOR_STRIDE + 2] = runStart;
                            out[n * DOOR_STRIDE + 3] = a - runStart;
                            n++;
                        }
                        runStart = -1;
                    }
                }
            }
        }
        doorwayCount = n;
        doorways = out;
        return out;
    }

    public int doorwayCount() {
        doorways();
        return doorwayCount;
    }

    private boolean walkableTile(int tx, int ty) {
        if (tx < 0 || ty < 0 || tx >= width || ty >= height) return false;
        byte k = tiles[ty * width + tx];
        return k == FLOOR;
    }

    /**
     * Merged non-floor blocks, 5 ints each: tileX, tileY, tilesW, tilesH, kind. Sorted by their
     * south edge (then by x), which is the order the renderer needs for correct overlap.
     */
    public final int[] blocks;
    public final int blockCount;

    /** Round obstacles, 3 floats each: centre x, centre y, radius. */
    public final float[] circles;
    public final int circleCount;
    private final short[] circleAt;
    private final byte[] fenceArms;

    private TileMap(int id, int width, int height, byte[] tiles, float[] sx, float[] sy,
                    float[] px, float[] py, int[] pw, int[] blocks, int blockCount,
                    float[] circles, int circleCount, short[] circleAt, byte[] fenceArms,
                    byte[] ground, int[] houses, short[] houseOf) {
        this.id = id;
        this.width = width;
        this.height = height;
        this.tiles = tiles;
        this.worldW = width * GameConfig.TILE;
        this.worldH = height * GameConfig.TILE;
        this.spawnX = sx;
        this.spawnY = sy;
        this.pickupX = px;
        this.pickupY = py;
        this.pickupItem = pw;
        this.ground = ground;
        this.houses = houses;
        this.houseCount = houses.length / 5;
        this.houseOf = houseOf;
        this.blocks = blocks;
        this.blockCount = blockCount;
        this.circles = circles;
        this.circleCount = circleCount;
        this.circleAt = circleAt;
        this.fenceArms = fenceArms;
    }

    /** Kinds with a shape smaller than the tile that is not a plain box: pillars, tanks, angled pieces, trees, boulders. */
    public static boolean isShapeKind(byte k) {
        return (k >= PILLAR && k <= WEDGE_SE) || k == TREE || k == ROCK;
    }

    /** True for the kinds that are a round obstacle with an entry in {@link #circles}. */
    public static boolean isRoundKind(byte k) {
        return k == PILLAR || k == TANK || k == TREE || k == ROCK;
    }

    /** True when the map has a ground layer (an outdoor map). */
    public boolean hasTerrain() {
        return ground != null;
    }

    /** Ground type of a tile ({@link #G_GRASS} on maps without terrain or outside the grid). */
    public byte groundAt(int tx, int ty) {
        if (ground == null || tx < 0 || ty < 0 || tx >= width || ty >= height) return G_GRASS;
        return ground[ty * width + tx];
    }

    /** Index into {@link #houses} of the building whose footprint covers this tile, or -1. */
    public int houseAt(int tx, int ty) {
        if (tx < 0 || ty < 0 || tx >= width || ty >= height) return -1;
        return houseOf[ty * width + tx];
    }

    public int houseAtPoint(float wx, float wy) {
        return houseAt((int) Math.floor(wx / GameConfig.TILE), (int) Math.floor(wy / GameConfig.TILE));
    }

    public static boolean isWedge(byte k) {
        return k >= WEDGE_NW && k <= WEDGE_SE;
    }

    /** Blocks player movement (to some degree). Anything outside the grid counts as solid, so nothing can leave the arena. */
    public boolean isSolid(int tx, int ty) {
        if (tx < 0 || ty < 0 || tx >= width || ty >= height) return true;
        return tiles[ty * width + tx] != FLOOR;
    }

    /** True when the point is over water (or outside the map): a circle of safe ground there is not much of a refuge. */
    public boolean isWaterAt(float wx, float wy) {
        int tx = (int) Math.floor(wx / GameConfig.TILE), ty = (int) Math.floor(wy / GameConfig.TILE);
        if (tx < 0 || ty < 0 || tx >= width || ty >= height) return true;
        return tiles[ty * width + tx] == WATER;
    }

    public boolean isSolidAt(float wx, float wy) {
        return isSolid((int) Math.floor(wx / GameConfig.TILE), (int) Math.floor(wy / GameConfig.TILE));
    }

    /** Walls and crates (and the outside of the grid) stop bullets over the whole tile. */
    public boolean blocksShotsFully(int tx, int ty) {
        if (tx < 0 || ty < 0 || tx >= width || ty >= height) return true;
        byte k = tiles[ty * width + tx];
        return k == WALL || k == CRATE;
    }

    /** Pillars, tanks and angled pieces stop bullets, but only where their shape is. */
    public boolean blocksShotsPartly(int tx, int ty) {
        if (tx < 0 || ty < 0 || tx >= width || ty >= height) return false;
        return isShapeKind(tiles[ty * width + tx]);
    }

    public byte kindAt(int tx, int ty) {
        if (tx < 0 || ty < 0 || tx >= width || ty >= height) return WALL;
        return tiles[ty * width + tx];
    }

    /** Index into {@link #circles} of the round obstacle covering this tile, or -1. */
    public int circleAt(int tx, int ty) {
        if (tx < 0 || ty < 0 || tx >= width || ty >= height) return -1;
        return circleAt[ty * width + tx];
    }

    @Override
    public boolean roundAt(int tx, int ty, float[] out) {
        int c = circleAt(tx, ty);
        if (c < 0) return false;
        out[0] = circles[c * 3];
        out[1] = circles[c * 3 + 1];
        out[2] = circles[c * 3 + 2];
        return true;
    }

    /** {@code ARM_*} bits of the fence at this tile (0 when it is not a fence). */
    public int fenceArms(int tx, int ty) {
        if (tx < 0 || ty < 0 || tx >= width || ty >= height) return 0;
        return fenceArms[ty * width + tx];
    }

    /**
     * Corners of an angled piece whose tile has its top-left corner at (left, top). Output is
     * {@code out[0..5]}: the right-angle corner first, then the two ends of the long (diagonal) edge.
     */
    public static void wedgeCorners(byte kind, float left, float top, float[] out) {
        float r = left + GameConfig.TILE;
        float b = top + GameConfig.TILE;
        switch (kind) {
            case WEDGE_NW: set6(out, left, top, r, top, left, b); break;
            case WEDGE_NE: set6(out, r, top, r, b, left, top); break;
            case WEDGE_SW: set6(out, left, b, left, top, r, b); break;
            default: set6(out, r, b, r, top, left, b); break;     // WEDGE_SE
        }
    }

    private static void set6(float[] o, float a, float b, float c, float d, float e, float f) {
        o[0] = a;
        o[1] = b;
        o[2] = c;
        o[3] = d;
        o[4] = e;
        o[5] = f;
    }

    /** The weapon a map letter stands for, or -1 when the letter is not a weapon pickup. */
    public static int weaponForLetter(char c) {
        switch (c) {
            case 'R': return WeaponDef.RIFLE;
            case 'G': return WeaponDef.SHOTGUN;
            case 'M': return WeaponDef.SMG;
            case 'N': return WeaponDef.SNIPER;
            case 'V': return WeaponDef.MAGNUM;
            case 'P': return WeaponDef.PLASMA;
            case 'K': return WeaponDef.LMG;
            case 'X': return WeaponDef.REVOLVER;
            case 'D': return WeaponDef.DOUBLE_BARREL;
            case 'H': return WeaponDef.HUNTING_RIFLE;
            case 'A': return WeaponDef.AK;
            case 'U': return WeaponDef.DMR;
            case 'Q': return WeaponDef.MACHINE_PISTOL;
            case 'k': return WeaponDef.KNIFE;
            case 'l': return WeaponDef.BAT;
            case 'c': return WeaponDef.CROWBAR;
            case 'm': return WeaponDef.MACHETE;
            case 'e': return WeaponDef.AXE;
            case 'p': return WeaponDef.PICKAXE;
            default: return -1;
        }
    }

    /**
     * The item a map letter stands for ({@link Items} id), or -1: the weapon letters plus {@code a} light vest,
     * {@code b} heavy vest and {@code h} first-aid kit.
     */
    public static int itemForLetter(char c) {
        int w = weaponForLetter(c);
        if (w >= 0) return w;
        switch (c) {
            case 'a': return Items.VEST_LIGHT;
            case 'b': return Items.VEST_HEAVY;
            case 'h': return Items.MEDKIT;
            case 'i': return Items.AMMO_BOX;
            case 'j': return Items.BACKPACK_1;
            case 'f': return Items.BACKPACK_2;
            case 'g': return Items.BACKPACK_3;
            default: return -1;
        }
    }

    private static byte kindForLetter(char c) {
        switch (c) {
            case 't': return TREE;
            case 'r': return ROCK;
            case '#': return WALL;
            case 'C': return CRATE;
            case '+': return FENCE;
            case '~': return WATER;
            case 'O': return PILLAR;
            case 'T': return TANK;
            case '7': return WEDGE_NW;
            case '9': return WEDGE_NE;
            case '1': return WEDGE_SW;
            case '3': return WEDGE_SE;
            default: return FLOOR;
        }
    }

    /**
     * Legend: {@code #} wall, {@code C} crate, {@code +} fence, {@code ~} toxic pool, {@code O} round
     * pillar, {@code T} tank (four of them in a 2 x 2 block make one big round tank), the numpad corners
     * {@code 7 9 1 3} for an angled piece filling the top-left, top-right, bottom-left or bottom-right
     * half of its tile, {@code .} floor, {@code S} spawn point, and one letter per weapon pickup
     * (R rifle, G shotgun, M SMG, N sniper, V magnum, P plasma, K light MG), {@code a} / {@code b} for a light /
     * heavy vest, {@code h} for a first-aid kit, {@code t} a tree and {@code r} a boulder. All rows must have the
     * same length; an unknown character is an error.
     */
    public static TileMap parse(int id, String[] rows) {
        return parse(id, rows, null, new int[0]);
    }

    /**
     * Parses a map with a ground layer and buildings.
     *
     * @param ground one {@code G_*} byte per tile (row after row), or null for none
     * @param houses 5 ints per building: first column, first row, last column, last row, style; buildings must
     *               not overlap
     */
    public static TileMap parse(int id, String[] rows, byte[] ground, int[] houses) {
        int h = rows.length;
        int w = rows[0].length();
        byte[] tiles = new byte[w * h];
        int spawns = 0;
        int pickups = 0;
        int solid = 0;
        for (int y = 0; y < h; y++) {
            if (rows[y].length() != w) throw new IllegalArgumentException("Map row " + y + " has wrong length");
            for (int x = 0; x < w; x++) {
                char c = rows[y].charAt(x);
                byte kind = kindForLetter(c);
                if (kind == FLOOR) {
                    if (c == 'S') spawns++;
                    else if (itemForLetter(c) >= 0) pickups++;
                    else if (c != '.') throw new IllegalArgumentException("Unknown map tile '" + c + "' at " + x + "," + y);
                }
                tiles[y * w + x] = kind;
                if (kind != FLOOR) solid++;
            }
        }
        if (pickups > MAX_PICKUPS) throw new IllegalArgumentException("Too many item pads: " + pickups);
        if (ground != null && ground.length != w * h) throw new IllegalArgumentException("Ground layer has the wrong size");
        float[] sx = new float[spawns];
        float[] sy = new float[spawns];
        float[] px = new float[pickups];
        float[] py = new float[pickups];
        int[] pw = new int[pickups];
        int si = 0;
        int pi = 0;
        float t = GameConfig.TILE;
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                char c = rows[y].charAt(x);
                float cx = (x + 0.5f) * t;
                float cy = (y + 0.5f) * t;
                if (c == 'S') {
                    sx[si] = cx;
                    sy[si] = cy;
                    si++;
                } else if (itemForLetter(c) >= 0) {
                    px[pi] = cx;
                    py[pi] = cy;
                    pw[pi] = itemForLetter(c);
                    pi++;
                }
            }
        }

        // Fence arms: a straight run keeps both arms along its line, a junction only the arms that have a neighbour.
        byte[] arms = new byte[w * h];
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                if (tiles[y * w + x] != FENCE) continue;
                boolean l = x > 0 && tiles[y * w + x - 1] == FENCE;
                boolean r = x < w - 1 && tiles[y * w + x + 1] == FENCE;
                boolean u = y > 0 && tiles[(y - 1) * w + x] == FENCE;
                boolean d = y < h - 1 && tiles[(y + 1) * w + x] == FENCE;
                int a;
                if (!(l || r) && !(u || d)) a = ARM_L | ARM_R;
                else if ((l || r) && !(u || d)) a = ARM_L | ARM_R;
                else if ((u || d) && !(l || r)) a = ARM_U | ARM_D;
                else a = (l ? ARM_L : 0) | (r ? ARM_R : 0) | (u ? ARM_U : 0) | (d ? ARM_D : 0);
                arms[y * w + x] = (byte) a;
            }
        }

        boolean[] used = new boolean[w * h];
        int[] raw = new int[5 * Math.max(1, solid)];
        int bc = 0;
        int maxCircles = 0;
        for (int i = 0; i < tiles.length; i++) {
            if (tiles[i] == PILLAR || tiles[i] == TREE || tiles[i] == ROCK) maxCircles++;
            else if (tiles[i] == TANK) maxCircles++;   // generous: a tank uses 1 of every 4 tiles
        }
        if (maxCircles > Short.MAX_VALUE) throw new IllegalArgumentException("Too many round obstacles: " + maxCircles);
        float[] circles = new float[3 * Math.max(1, maxCircles)];
        short[] circleAt = new short[w * h];
        Arrays.fill(circleAt, (short) -1);
        int cc = 0;

        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int i = y * w + x;
                byte kind = tiles[i];
                if (kind == FLOOR || used[i]) continue;

                if (kind == PILLAR || kind == TREE || kind == ROCK) {
                    used[i] = true;
                    circles[cc * 3] = (x + 0.5f) * t;
                    circles[cc * 3 + 1] = (y + 0.5f) * t;
                    circles[cc * 3 + 2] = kind == TREE ? TREE_RADIUS : (kind == ROCK ? ROCK_RADIUS : PILLAR_RADIUS);
                    circleAt[i] = (short) cc;
                    cc++;
                    bc = addBlock(raw, bc, x, y, 1, 1, kind);
                    continue;
                }
                if (kind == TANK) {
                    boolean ok = x + 1 < w && y + 1 < h && tiles[i + 1] == TANK && tiles[i + w] == TANK
                            && tiles[i + w + 1] == TANK && !used[i + 1] && !used[i + w] && !used[i + w + 1];
                    if (!ok) throw new IllegalArgumentException("Tank tiles 'T' must form 2x2 blocks (at " + x + "," + y + ")");
                    used[i] = used[i + 1] = used[i + w] = used[i + w + 1] = true;
                    circles[cc * 3] = (x + 1f) * t;
                    circles[cc * 3 + 1] = (y + 1f) * t;
                    circles[cc * 3 + 2] = TANK_RADIUS;
                    circleAt[i] = circleAt[i + 1] = circleAt[i + w] = circleAt[i + w + 1] = (short) cc;
                    cc++;
                    bc = addBlock(raw, bc, x, y, 2, 2, kind);
                    continue;
                }
                if (isWedge(kind)) {
                    used[i] = true;
                    bc = addBlock(raw, bc, x, y, 1, 1, kind);
                    continue;
                }
                if (kind == FENCE) {
                    int a = arms[i];
                    if (a == (ARM_L | ARM_R)) {
                        int len = 1;
                        while (x + len < w && tiles[i + len] == FENCE && arms[i + len] == a && !used[i + len]) len++;
                        for (int k = 0; k < len; k++) used[i + k] = true;
                        bc = addBlock(raw, bc, x, y, len, 1, FENCE);
                    } else if (a == (ARM_U | ARM_D)) {
                        int len = 1;
                        while (y + len < h && tiles[i + len * w] == FENCE && arms[i + len * w] == a && !used[i + len * w]) len++;
                        for (int k = 0; k < len; k++) used[i + k * w] = true;
                        bc = addBlock(raw, bc, x, y, 1, len, FENCE);
                    } else {
                        used[i] = true;
                        bc = addBlock(raw, bc, x, y, 1, 1, FENCE_JOINT);
                    }
                    continue;
                }

                // Walls, crates and pools: greedy rectangle merge of equal tiles.
                int bw = 1;
                while (x + bw < w && tiles[i + bw] == kind && !used[i + bw]) bw++;
                int bh = 1;
                boolean grow = true;
                while (grow && y + bh < h) {
                    for (int k = 0; k < bw; k++) {
                        int j = (y + bh) * w + x + k;
                        if (tiles[j] != kind || used[j]) {
                            grow = false;
                            break;
                        }
                    }
                    if (grow) bh++;
                }
                for (int yy = 0; yy < bh; yy++) {
                    for (int xx = 0; xx < bw; xx++) used[(y + yy) * w + x + xx] = true;
                }
                bc = addBlock(raw, bc, x, y, bw, bh, kind);
            }
        }

        // Order by south edge, then x, so drawing back-to-front is a single pass.
        long[] keys = new long[bc];
        for (int b = 0; b < bc; b++) {
            long south = raw[b * 5 + 1] + raw[b * 5 + 3];
            keys[b] = (south << 40) | ((long) raw[b * 5] << 20) | b;
        }
        Arrays.sort(keys);
        int[] blocks = new int[bc * 5];
        for (int n = 0; n < bc; n++) {
            int b = (int) (keys[n] & 0xFFFFF);
            System.arraycopy(raw, b * 5, blocks, n * 5, 5);
        }

        // Buildings: sorted by south edge (the renderer draws roofs in that order), and a lookup table per tile.
        int hc = houses.length / 5;
        long[] hkeys = new long[hc];
        for (int k = 0; k < hc; k++) {
            long south = houses[k * 5 + 3];
            hkeys[k] = (south << 40) | ((long) houses[k * 5] << 20) | k;
        }
        Arrays.sort(hkeys);
        int[] sortedHouses = new int[hc * 5];
        short[] houseOf = new short[w * h];
        Arrays.fill(houseOf, (short) -1);
        for (int n = 0; n < hc; n++) {
            int k = (int) (hkeys[n] & 0xFFFFF);
            System.arraycopy(houses, k * 5, sortedHouses, n * 5, 5);
            for (int yy = sortedHouses[n * 5 + 1]; yy <= sortedHouses[n * 5 + 3]; yy++) {
                for (int xx = sortedHouses[n * 5]; xx <= sortedHouses[n * 5 + 2]; xx++) {
                    if (xx < 0 || yy < 0 || xx >= w || yy >= h) throw new IllegalArgumentException("House outside the map");
                    if (houseOf[yy * w + xx] >= 0) throw new IllegalArgumentException("Overlapping houses at " + xx + "," + yy);
                    houseOf[yy * w + xx] = (short) n;
                }
            }
        }
        return new TileMap(id, w, h, tiles, sx, sy, px, py, pw, blocks, bc,
                Arrays.copyOf(circles, cc * 3), cc, circleAt, arms, ground, sortedHouses, houseOf);
    }

    private static int addBlock(int[] raw, int bc, int x, int y, int bw, int bh, int kind) {
        raw[bc * 5] = x;
        raw[bc * 5 + 1] = y;
        raw[bc * 5 + 2] = bw;
        raw[bc * 5 + 3] = bh;
        raw[bc * 5 + 4] = kind;
        return bc + 1;
    }
}
