package com.hazardyard.game.survival;

import com.hazardyard.game.core.TileMap;

/**
 * Generates the endless survival world, one chunk at a time, from nothing but a seed. Every tile is a pure function of its
 * position and the seed (integer hashing and exact float arithmetic, no trigonometry), so the host and every client
 * build exactly the same world without sending any of it.
 *
 * <p>The land has lakes and seas, beaches, meadows, forests and rocky highlands. Scattered over it are ruined towns
 * (streets laid out in a grid, a house, shop, garage, clinic or police station on most blocks, with furniture to search) and
 * lonely cabins. The area around the starting point is always dry land with a town close by.
 */
public final class SurvivalGen {
    public static final int TOWN_CELL = 96;
    public static final int BLOCK = 12;
    public static final int HOUSE = 0, SHOP = 1, GARAGE = 2, CLINIC = 3, POLICE = 4, CABIN = 5;

    private final int seed;

    public SurvivalGen(int seed) {
        this.seed = seed;
    }

    /** Scratch result of describing one tile. */
    private static final class Out {
        byte g;
        byte o;
        int meta;
    }

    // ------------------------------------------------------------------ noise

    static int hash(int x, int y, int s) {
        int h = x * 374761393 + y * 668265263 + s * 1442695041;
        h = (h ^ (h >>> 13)) * 1274126177;
        return h ^ (h >>> 16);
    }

    static float rnd01(int x, int y, int s) {
        return (hash(x, y, s) & 0xFFFFFF) / 16777216f;
    }

    private static float smooth(float t) {
        return t * t * (3f - 2f * t);
    }

    private static float vnoise(float x, float y, int s) {
        int xi = (int) Math.floor(x);
        int yi = (int) Math.floor(y);
        float fx = smooth(x - xi);
        float fy = smooth(y - yi);
        float a = rnd01(xi, yi, s);
        float b = rnd01(xi + 1, yi, s);
        float c = rnd01(xi, yi + 1, s);
        float d = rnd01(xi + 1, yi + 1, s);
        float top = a + (b - a) * fx;
        float bot = c + (d - c) * fx;
        return top + (bot - top) * fy;
    }

    float elevation(int wx, int wy) {
        float e = 0.60f * vnoise(wx / 70f, wy / 70f, seed + 1) + 0.28f * vnoise(wx / 28f, wy / 28f, seed + 2)
                + 0.12f * vnoise(wx / 11f, wy / 11f, seed + 3);
        float d = (float) Math.sqrt((double) wx * wx + (double) wy * wy);
        e += Math.max(0f, 1f - d / 90f) * 0.40f;       // dry land around the start
        return e;
    }

    float moisture(int wx, int wy) {
        return 0.60f * vnoise(wx / 60f - 17f, wy / 60f + 9f, seed + 4) + 0.40f * vnoise(wx / 21f, wy / 21f, seed + 5);
    }

    byte baseGround(float e, float m) {
        if (e < 0.30f) return TileMap.G_WATER;
        if (e < 0.34f) return TileMap.G_SAND;
        if (e > 0.80f) return TileMap.G_ROCKY;
        if (m > 0.60f) return TileMap.G_FOREST;
        if (m < 0.36f) return TileMap.G_MEADOW;
        return TileMap.G_GRASS;
    }

    // ------------------------------------------------------------------ towns

    private boolean townAt(int cellX, int cellY) {
        if (cellX == 0 && cellY == 0) return true;
        if ((hash(cellX, cellY, seed + 100) & 0xFF) >= 150) return false;
        return elevation(townCenterX(cellX, cellY), townCenterY(cellX, cellY)) > 0.40f;
    }

    private int townCenterX(int cellX, int cellY) {
        if (cellX == 0 && cellY == 0) return 30;
        return cellX * TOWN_CELL + 32 + (hash(cellX, cellY, seed + 101) & 31);
    }

    private int townCenterY(int cellX, int cellY) {
        if (cellX == 0 && cellY == 0) return 24;
        return cellY * TOWN_CELL + 32 + ((hash(cellX, cellY, seed + 101) >>> 8) & 31);
    }

    private int townRadius(int cellX, int cellY) {
        return cellX == 0 && cellY == 0 ? 20 : 15 + ((hash(cellX, cellY, seed + 102) >>> 4) & 7);
    }

    /** True when the tile lies inside the boundary of a town. */
    public boolean inTown(int wx, int wy) {
        int cellX = Math.floorDiv(wx, TOWN_CELL);
        int cellY = Math.floorDiv(wy, TOWN_CELL);
        if (!townAt(cellX, cellY)) return false;
        int r = townRadius(cellX, cellY);
        return Math.abs(wx - townCenterX(cellX, cellY)) <= r && Math.abs(wy - townCenterY(cellX, cellY)) <= r;
    }

    private static int pickKind(int roll) {
        if (roll < 130) return HOUSE;
        if (roll < 170) return SHOP;
        if (roll < 200) return GARAGE;
        if (roll < 225) return CLINIC;
        return POLICE;
    }

    /** Sets {@code out} for a tile of a town; returns false when the tile is not in the town. */
    private boolean townTile(int wx, int wy, int cellX, int cellY, Out out) {
        int r = townRadius(cellX, cellY);
        int x0 = townCenterX(cellX, cellY) - r;
        int y0 = townCenterY(cellX, cellY) - r;
        int lx = wx - x0;
        int ly = wy - y0;
        if (lx < 0 || ly < 0 || lx > 2 * r || ly > 2 * r) return false;
        int mx = lx % BLOCK;
        int my = ly % BLOCK;
        boolean vs = mx < 3;
        boolean hs = my < 3;
        if (vs || hs) {
            out.g = vs && hs ? TileMap.G_ROAD : (vs ? (mx == 1 ? TileMap.G_ROAD_V : TileMap.G_ROAD) : (my == 1 ? TileMap.G_ROAD_H : TileMap.G_ROAD));
            out.o = Obj.NONE;
            out.meta = 0;
            return true;
        }
        int bx = lx / BLOCK;
        int by = ly / BLOCK;
        int u = mx - 3;
        int v = my - 3;
        if (!blockBuilding(cellX, cellY, bx, by, r, tmpInts)) {      // no building fits here: a yard
            out.g = TileMap.G_GRASS;
            float rr = rnd01(wx, wy, seed + 110);
            out.o = rr < 0.08f ? Obj.TREE : (rr > 0.97f ? Obj.BUSH : Obj.NONE);
            out.meta = 0;
            return true;
        }
        int kind = tmpInts[0], w = tmpInts[1], hh = tmpInts[2], ox = tmpInts[3], oy = tmpInts[4], h2 = tmpInts[5];
        int bu = u - ox;
        int bv = v - oy;
        if (bu < -1 || bu > w || bv < -1 || bv > hh) {   // yard beyond the pavement
            out.g = TileMap.G_GRASS;
            float rr = rnd01(wx, wy, seed + 111);
            out.o = rr < 0.05f ? Obj.TREE : (rr > 0.985f ? Obj.BUSH : Obj.NONE);
            out.meta = 0;
            return true;
        }
        if (bu < 0 || bu >= w || bv < 0 || bv >= hh) {     // the pavement round the building
            out.g = TileMap.G_PAVED;
            out.o = Obj.NONE;
            out.meta = 0;
            return true;
        }
        buildingTile(wx, wy, kind, w, hh, bu, bv, h2, out);
        return true;
    }

    /**
     * The building a block holds: {kind, width, height, offset x, offset y, hash} in {@code b}, or false for a park. The
     * whole building and the pavement round it must fit inside the town, so no building is ever cut off by the edge.
     */
    private boolean blockBuilding(int cellX, int cellY, int bx, int by, int r, int[] b) {
        int salt = seed + cellX * 7919 + cellY * 104729;
        int h = hash(bx, by, salt + 103);
        if ((h & 0xFF) >= 190) return false;                // an empty lot: a park
        int kind = pickKind((h >>> 8) & 0xFF);
        int w = 6 + ((h >>> 16) & 3);
        int hh = 5 + ((h >>> 18) & 3);
        int ox = ((h >>> 20) & 15) % (9 - w + 1);
        int oy = ((h >>> 24) & 15) % (9 - hh + 1);
        if (bx * BLOCK + 3 + ox + w + 1 > 2 * r || by * BLOCK + 3 + oy + hh + 1 > 2 * r) return false;
        b[0] = kind;
        b[1] = w;
        b[2] = hh;
        b[3] = ox;
        b[4] = oy;
        b[5] = hash(bx, by, salt + 104);
        return true;
    }

    /** Scratch for {@link #townTile} (the generator runs on one thread). */
    private final int[] tmpInts = new int[8];

    /** Integers per building in the array {@link #buildingsInRect} fills. */
    public static final int B_STRIDE = 9;
    /** Fields of a building record: top-left tile, size in tiles, kind, colour scheme, door wall (0 N, 1 E, 2 S, 3 W) and its tile along that wall. */
    public static final int B_X = 0, B_Y = 1, B_W = 2, B_H = 3, B_KIND = 4, B_STYLE = 5, B_SIDE = 6, B_ALONG = 7, B_ID = 8;

    /**
     * The door wall of a building: always the south one (2). From above and slightly in front the south wall is the one you
     * see under the eaves, so the door and its porch are always in plain view; a door in another wall would hide under the roof.
     */
    static int doorSide(int h2) {
        return 2;
    }

    /** The tile along the door wall where the (single) door is: near the middle, never at a corner. */
    static int doorAlong(int h2, int len) {
        int dp = len / 2 + (((h2 >>> 8) & 3) - 1);
        return Math.max(1, Math.min(len - 2, dp));
    }

    /** The colour scheme of a building (walls and roof). */
    static int styleOf(int kind, int h2) {
        switch (kind) {
            case SHOP: return 3;
            case GARAGE: return 7;
            case CLINIC: return 5;
            case POLICE: return 1;
            case CABIN: return 6;
            default: return (h2 >>> 12) & 3 | (((h2 >>> 15) & 1) << 2);
        }
    }

    private void record(int[] out, int n, int x0, int y0, int w, int hh, int kind, int h2, int id) {
        int o = n * B_STRIDE;
        out[o + B_X] = x0;
        out[o + B_Y] = y0;
        out[o + B_W] = w;
        out[o + B_H] = hh;
        out[o + B_KIND] = kind;
        out[o + B_STYLE] = styleOf(kind, h2);
        int side = doorSide(h2);
        out[o + B_SIDE] = side;
        out[o + B_ALONG] = doorAlong(h2, side == 0 || side == 2 ? w : hh);
        out[o + B_ID] = id;
    }

    /**
     * Writes the buildings (towns and cabins) that touch the tile rectangle into {@code out} as records of
     * {@link #B_STRIDE} integers; returns how many fit. Used by the renderer to draw roofs, windows and porches; the
     * tiles themselves come from {@link #generate}, and both use the same footprints.
     */
    public int buildingsInRect(int tx0, int ty0, int tx1, int ty1, int[] out) {
        int n = 0, max = out.length / B_STRIDE;
        int[] b = new int[6];
        for (int cellY = Math.floorDiv(ty0, TOWN_CELL); cellY <= Math.floorDiv(ty1, TOWN_CELL); cellY++) {
            for (int cellX = Math.floorDiv(tx0, TOWN_CELL); cellX <= Math.floorDiv(tx1, TOWN_CELL); cellX++) {
                if (townAt(cellX, cellY)) {
                    int r = townRadius(cellX, cellY);
                    int x0 = townCenterX(cellX, cellY) - r, y0 = townCenterY(cellX, cellY) - r;
                    int blocks = (2 * r) / BLOCK + 1;
                    for (int by = 0; by < blocks; by++) {
                        for (int bx = 0; bx < blocks; bx++) {
                            if (!blockBuilding(cellX, cellY, bx, by, r, b)) continue;
                            int bx0 = x0 + bx * BLOCK + 3 + b[3], by0 = y0 + by * BLOCK + 3 + b[4];
                            if (bx0 > tx1 || by0 > ty1 || bx0 + b[1] <= tx0 || by0 + b[2] <= ty0) continue;
                            if (n < max) record(out, n++, bx0, by0, b[1], b[2], b[0], b[5], hash(bx0, by0, seed));
                        }
                    }
                }
            }
        }
        // cabins
        for (int cellY = Math.floorDiv(ty0, CABIN_CELL); cellY <= Math.floorDiv(ty1, CABIN_CELL); cellY++) {
            for (int cellX = Math.floorDiv(tx0, CABIN_CELL); cellX <= Math.floorDiv(tx1, CABIN_CELL); cellX++) {
                if (!cabinFootprint(cellX, cellY, b)) continue;
                int bx0 = b[3], by0 = b[4];
                if (bx0 > tx1 || by0 > ty1 || bx0 + b[1] <= tx0 || by0 + b[2] <= ty0) continue;
                if (n < max) record(out, n++, bx0, by0, b[1], b[2], CABIN, b[5], hash(bx0, by0, seed));
            }
        }
        return n;
    }

    /** One tile of a building of {@code w x hh} tiles: its walls, windows, door, doorways, floor and furniture. */
    private void buildingTile(int wx, int wy, int kind, int w, int hh, int bu, int bv, int h2, Out out) {
        byte floor = kind == HOUSE || kind == CABIN ? TileMap.G_WOOD : (kind == GARAGE ? TileMap.G_CONCRETE : TileMap.G_TILES);
        out.g = floor;
        out.meta = 0;
        int style = styleOf(kind, h2);
        boolean border = bu == 0 || bu == w - 1 || bv == 0 || bv == hh - 1;
        int side = doorSide(h2);                          // which wall the door is in: 1 E, 2 S, 3 W
        int len = side == 0 || side == 2 ? w : hh;
        int dp = doorAlong(h2, len);                      // the one door tile along that wall
        if (border) {
            boolean onDoorWall = (side == 0 && bv == 0) || (side == 2 && bv == hh - 1) || (side == 3 && bu == 0) || (side == 1 && bu == w - 1);
            int along = side == 0 || side == 2 ? bu : bv;
            if (onDoorWall && along == dp) {
                int state = (hash(wx, wy, seed + 112) >>> 3) & 15;
                if (state < 1) {
                    out.o = Obj.NONE;                    // the door is gone
                } else {
                    out.o = Obj.DOOR;
                    out.meta = (50 << 1) | (state < 7 ? 1 : 0);          // 400 hit points; about a third stand open
                }
                return;
            }
            boolean corner = (bu == 0 || bu == w - 1) && (bv == 0 || bv == hh - 1);
            boolean nearDoor = onDoorWall && Math.abs(along - dp) <= 1;
            // a window in the outer wall every third tile (not at a corner, not beside the door)
            int pos = (bu == 0 || bu == w - 1) ? bv : bu;
            boolean window = !corner && !nearDoor && pos % 3 == 1 && kind != GARAGE;
            if (!corner && !nearDoor && !window && rnd01(wx, wy, seed + 105) < 0.04f) {
                out.o = Obj.RUBBLE;                      // a hole in the wall
                return;
            }
            out.o = Obj.WALL;
            out.meta = Obj.buildingWall(style, window);
            return;
        }
        // partitions: a wall across big buildings with a doorway (one tile for homes, two for halls)
        int pw = -1;
        boolean vertical = false;
        if (w >= 8) {
            pw = w / 2;
            vertical = true;
        } else if (hh >= 7) {
            pw = hh / 2;
        }
        int gapW = kind == HOUSE || kind == CABIN ? 1 : 2;
        int gap = 1;
        if (pw >= 0) {
            int span = vertical ? hh : w;
            gap = 1 + ((h2 >>> 14) & 0xFF) % Math.max(1, span - 2 - gapW);
            int pos = vertical ? bu : bv;
            int alongP = vertical ? bv : bu;
            if (pos == pw) {
                if (alongP >= gap && alongP < gap + gapW) {
                    out.o = Obj.NONE;
                } else {
                    out.o = Obj.WALL;
                    out.meta = Obj.buildingWall(style, false);
                }
                return;
            }
            // keep the doorway free of furniture
            if (Math.abs(pos - pw) <= 1 && (alongP >= gap - 1 && alongP <= gap + gapW)) {
                out.o = Obj.NONE;
                return;
            }
        }
        // the entrance hall: the three tiles inside the door stay clear
        int dx0, dy0;       // the door tile in building coordinates
        if (side == 0) {
            dx0 = dp;
            dy0 = 0;
        } else if (side == 2) {
            dx0 = dp;
            dy0 = hh - 1;
        } else if (side == 3) {
            dx0 = 0;
            dy0 = dp;
        } else {
            dx0 = w - 1;
            dy0 = dp;
        }
        boolean hall = Math.abs(bu - dx0) <= 1 && Math.abs(bv - dy0) <= 1 || (Math.abs(bu - dx0) <= 2 && Math.abs(bv - dy0) <= 2 && (side == 2 || side == 0 ? bu == dx0 : bv == dy0));
        boolean nearWall = bu == 1 || bu == w - 2 || bv == 1 || bv == hh - 2 || (pw >= 0 && Math.abs((vertical ? bu : bv) - pw) == 1);
        if (nearWall && !hall && rnd01(wx, wy, seed + 106) < 0.22f) {
            out.o = furniture(kind, (hash(wx, wy, seed + 107) >>> 4) & 0xFF);
            if (Obj.container(out.o)) out.meta = kind;
        } else {
            out.o = Obj.NONE;
        }
    }

    private static byte furniture(int kind, int roll) {
        int r = roll * 100 / 256;
        switch (kind) {
            case SHOP:
                return r < 60 ? Obj.SHELF : (r < 85 ? Obj.CRATE : (r < 95 ? Obj.CUPBOARD : Obj.FRIDGE));
            case GARAGE:
                return r < 40 ? Obj.TOOLBOX : (r < 70 ? Obj.CRATE : (r < 90 ? Obj.SHELF : Obj.TABLE));
            case POLICE:
                return r < 35 ? Obj.GUNCASE : (r < 65 ? Obj.CUPBOARD : (r < 80 ? Obj.TABLE : (r < 90 ? Obj.SHELF : Obj.CRATE)));
            case CLINIC:
                return r < 40 ? Obj.CUPBOARD : (r < 65 ? Obj.BED : (r < 85 ? Obj.SHELF : Obj.FRIDGE));
            default:   // house, cabin
                return r < 25 ? Obj.CUPBOARD : (r < 37 ? Obj.FRIDGE : (r < 55 ? Obj.WARDROBE : (r < 75 ? Obj.TABLE : (r < 90 ? Obj.BED : (r < 95 ? Obj.SHELF : Obj.TOOLBOX)))));
        }
    }

    // ------------------------------------------------------------------ cabins

    private static final int CABIN_CELL = 32;

    /**
     * The cabin of a cabin cell, if it has one and it stands on dry land outside the towns: {kind, w, h, x, y, hash} (tile
     * coordinates of its top-left corner in b[3], b[4]).
     */
    private boolean cabinFootprint(int cellX, int cellY, int[] b) {
        int h = hash(cellX, cellY, seed + 120);
        if ((h & 0xFF) >= 30) return false;
        int w = 6 + ((h >>> 8) & 1);
        int hh = 5 + ((h >>> 9) & 1);
        int ox = 4 + ((h >>> 10) & 15) % (CABIN_CELL - 8 - w);
        int oy = 4 + ((h >>> 14) & 15) % (CABIN_CELL - 8 - hh);
        int cx = cellX * CABIN_CELL + ox + w / 2;
        int cy = cellY * CABIN_CELL + oy + hh / 2;
        byte gnd = baseGround(elevation(cx, cy), moisture(cx, cy));
        if (gnd == TileMap.G_WATER || gnd == TileMap.G_SAND || gnd == TileMap.G_ROCKY || inTown(cx, cy) || inTown(cx - w, cy - hh) || inTown(cx + w, cy + hh)) return false;
        b[0] = CABIN;
        b[1] = w;
        b[2] = hh;
        b[3] = cellX * CABIN_CELL + ox;
        b[4] = cellY * CABIN_CELL + oy;
        b[5] = hash(cellX, cellY, seed + 121);
        return true;
    }

    /** Describes a tile that belongs to a lonely cabin, or returns false. */
    private boolean cabinTile(int wx, int wy, Out out) {
        int cellX = Math.floorDiv(wx, CABIN_CELL);
        int cellY = Math.floorDiv(wy, CABIN_CELL);
        int[] b = tmpInts;
        if (!cabinFootprint(cellX, cellY, b)) return false;
        int w = b[1], hh = b[2];
        int bu = wx - b[3];
        int bv = wy - b[4];
        if (bu < -1 || bu > w || bv < -1 || bv > hh) return false;
        if (bu < 0 || bu >= w || bv < 0 || bv >= hh) {
            out.g = TileMap.G_DIRT;
            out.o = Obj.NONE;
            out.meta = 0;
            return true;
        }
        buildingTile(wx, wy, CABIN, w, hh, bu, bv, b[5], out);
        return true;
    }

    // ------------------------------------------------------------------ chunks

    /** Fills a chunk with ground and objects. */
    public void generate(Chunk c) {
        Out out = new Out();
        for (int ly = 0; ly < Chunk.SIZE; ly++) {
            for (int lx = 0; lx < Chunk.SIZE; lx++) {
                int wx = c.cx * Chunk.SIZE + lx;
                int wy = c.cy * Chunk.SIZE + ly;
                describe(wx, wy, out);
                int i = Chunk.index(lx, ly);
                c.ground[i] = out.g;
                c.obj[i] = out.o;
                c.meta[i] = (byte) out.meta;
            }
        }
    }

    private void describe(int wx, int wy, Out out) {
        float e = elevation(wx, wy);
        float m = moisture(wx, wy);
        byte g = baseGround(e, m);
        out.g = g;
        out.meta = 0;
        out.o = Obj.NONE;
        if (g != TileMap.G_WATER) {
            float r = rnd01(wx, wy, seed + 7);
            switch (g) {
                case TileMap.G_FOREST:
                    out.o = r < 0.26f ? Obj.TREE : (r > 0.985f ? Obj.BUSH : Obj.NONE);
                    break;
                case TileMap.G_GRASS:
                    out.o = r < 0.030f ? Obj.TREE : (r > 0.985f ? Obj.BUSH : (r > 0.978f ? Obj.ROCK : Obj.NONE));
                    break;
                case TileMap.G_MEADOW:
                    out.o = r < 0.012f ? Obj.TREE : (r > 0.980f ? Obj.BUSH : Obj.NONE);
                    break;
                case TileMap.G_ROCKY:
                    out.o = r < 0.090f ? Obj.ROCK : (r > 0.99f ? Obj.TREE : Obj.NONE);
                    break;
                default:
                    out.o = g == TileMap.G_SAND && r > 0.995f ? Obj.ROCK : Obj.NONE;
                    break;
            }
            // the starting area is kept open
            if (wx * wx + wy * wy < 49) out.o = Obj.NONE;
        }
        int cellX = Math.floorDiv(wx, TOWN_CELL);
        int cellY = Math.floorDiv(wy, TOWN_CELL);
        if (g != TileMap.G_WATER) {
            if (townAt(cellX, cellY)) {
                townTile(wx, wy, cellX, cellY, out);
            } else {
                cabinTile(wx, wy, out);
            }
        }
    }

    // ------------------------------------------------------------------ cars and zombies of a chunk

    /**
     * Wrecks parked in this chunk: on town streets and, rarely, out in the open. Output: x, y (world units), heading
     * (radians) per car, in {@code out}; returns how many.
     */
    public int carSlots(int cx, int cy, float[] out) {
        int n = 0;
        Out o = new Out();
        for (int ly = 0; ly < Chunk.SIZE && n * 3 + 3 <= out.length; ly++) {
            for (int lx = 0; lx < Chunk.SIZE && n * 3 + 3 <= out.length; lx++) {
                int wx = cx * Chunk.SIZE + lx;
                int wy = cy * Chunk.SIZE + ly;
                float r = rnd01(wx, wy, seed + 130);
                if (r > 0.012f) continue;
                describe(wx, wy, o);
                boolean horizontal;
                if (o.g == TileMap.G_ROAD && inTown(wx, wy)) {
                    horizontal = (hash(wx, wy, seed + 131) & 1) == 0;
                    // a lane tile, not an intersection: check the neighbours on the street's axis
                    describe(wx + 1, wy, o);
                    boolean eastRoad = o.g == TileMap.G_ROAD || o.g == TileMap.G_ROAD_H;
                    describe(wx - 1, wy, o);
                    boolean westRoad = o.g == TileMap.G_ROAD || o.g == TileMap.G_ROAD_H;
                    describe(wx, wy + 1, o);
                    boolean southRoad = o.g == TileMap.G_ROAD || o.g == TileMap.G_ROAD_V;
                    describe(wx, wy - 1, o);
                    boolean northRoad = o.g == TileMap.G_ROAD || o.g == TileMap.G_ROAD_V;
                    if (eastRoad && westRoad && !(southRoad && northRoad)) horizontal = true;
                    else if (southRoad && northRoad && !(eastRoad && westRoad)) horizontal = false;
                    else continue;
                } else if (r < 0.0008f && (o.g == TileMap.G_GRASS || o.g == TileMap.G_MEADOW || o.g == TileMap.G_DIRT) && o.o == Obj.NONE) {
                    horizontal = (hash(wx, wy, seed + 132) & 1) == 0;
                } else {
                    continue;
                }
                float flip = (hash(wx, wy, seed + 133) & 2) == 0 ? 0f : 3.14159265f;
                out[n * 3] = (wx + 0.5f) * 32f;
                out[n * 3 + 1] = (wy + 0.5f) * 32f;
                out[n * 3 + 2] = horizontal ? flip : flip + 1.5707963f;
                n++;
            }
        }
        return n;
    }

    /** How many zombies live in a chunk when it is first met: towns are full of them, the wilds nearly empty. */
    public int zombiesIn(int cx, int cy) {
        int wx = cx * Chunk.SIZE + 8;
        int wy = cy * Chunk.SIZE + 8;
        if (cx >= -1 && cx <= 1 && cy >= -1 && cy <= 1) return 0;       // the start is quiet
        int h = hash(cx, cy, seed + 140);
        if (inTown(wx, wy)) return h & 3;                                // 0..3
        return (h & 0xFF) < 40 ? 1 : 0;
    }

    /** The building kind a furniture piece stands in (stored in its meta). */
    public static int buildingOf(int meta) {
        return meta & 7;
    }
}
