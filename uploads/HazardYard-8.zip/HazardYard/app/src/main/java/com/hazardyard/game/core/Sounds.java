package com.hazardyard.game.core;

/**
 * Sound ids. The first {@link WeaponDef#ALL} ids are the weapon sounds, so a weapon id is its shot sound (for a melee
 * weapon: the swing). Every gun also owns three reload sounds (start, load, done) and, for guns with a mechanical
 * action (pump, bolt, hammer), one action sound: no two guns share a firing, reload or action sound.
 */
public final class Sounds {
    private Sounds() {}

    /** Number of weapon sounds (guns and melee weapons). */
    public static final int WEAPONS = 21;

    /** Shot sound of weapon {@code weaponId}: the gun's report, or the whoosh of a melee swing. */
    public static int shot(int weaponId) {
        return weaponId >= 0 && weaponId < WEAPONS ? weaponId : WeaponDef.PISTOL;
    }

    public static final int PICKUP = 21;
    public static final int HIT = 22;
    public static final int HURT = 23;
    public static final int KILL = 24;
    public static final int DEATH = 25;
    public static final int RESPAWN = 26;
    public static final int IMPACT = 27;
    public static final int COUNTDOWN = 28;
    public static final int GO = 29;
    public static final int WIN = 30;
    public static final int LOSE = 31;
    public static final int CONFIRM = 32;
    /** The dodge roll: one short, snappy cloth-and-footwork whoosh, unlike any gun or movement sound. */
    public static final int DODGE = 33;
    /** A melee blow landing on a body. */
    public static final int MELEE_HIT = 34;
    /** A bullet or blow stopped by a vest. */
    public static final int ARMOR_HIT = 35;
    public static final int ARMOR_EQUIP = 36;
    public static final int HEAL = 37;
    /** The safe zone starts closing. */
    public static final int ZONE_ALERT = 38;

    // ---- survival
    public static final int CHOP = 39;
    public static final int MINE = 40;
    /** Three different zombie groans. */
    public static final int ZOMBIE_GROAN = 41;
    public static final int ZOMBIE_GROANS = 3;
    public static final int ZOMBIE_ATTACK = 44;
    public static final int ZOMBIE_DEATH = 45;
    public static final int EAT = 46;
    public static final int CRAFT = 47;
    public static final int BUILD = 48;
    public static final int DOOR = 49;
    public static final int SEARCH = 50;
    public static final int FISH_CAST = 51;
    public static final int FISH_BITE = 52;
    public static final int FISH_CATCH = 53;
    public static final int DIG = 54;
    public static final int PLANT = 55;
    public static final int HARVEST = 56;
    public static final int ENGINE_START = 57;
    public static final int ENGINE_FAIL = 58;
    /** One short engine pulse, played over and over at a pitch that follows the speed. */
    public static final int ENGINE_LOOP = 59;
    public static final int CAR_HIT = 60;
    public static final int REPAIR = 61;
    public static final int SPLASH = 62;
    /** A built structure falling apart. */
    public static final int BREAK = 63;

    /** First of the 3 x {@link #GUNS} reload sounds. */
    public static final int RELOAD_BASE = 64;
    private static final int GUNS = WeaponDef.GUN_COUNT;
    /** First of the {@link #GUNS} mechanical action sounds (only some guns use theirs). */
    public static final int ACTION_BASE = RELOAD_BASE + 3 * GUNS;
    /** Sounds added after the per-gun tables: taking out the other weapon, a body hitting the ground, a blade into flesh. */
    public static final int EXTRA_BASE = ACTION_BASE + GUNS;
    public static final int WEAPON_SWITCH = EXTRA_BASE;
    public static final int BODY_THUD = EXTRA_BASE + 1;
    public static final int FLESH_SLASH = EXTRA_BASE + 2;
    public static final int COUNT = EXTRA_BASE + 3;

    private static int w(int weaponId) {
        return weaponId >= 0 && weaponId < GUNS ? weaponId : WeaponDef.PISTOL;
    }

    /** The reload begins: magazine release, ejector, bolt or lid. */
    public static int reloadStart(int weaponId) {
        return RELOAD_BASE + 3 * w(weaponId);
    }

    /** The moment the ammunition is restored: the new magazine seats, or a shell goes in. */
    public static int reloadLoad(int weaponId) {
        return RELOAD_BASE + 3 * w(weaponId) + 1;
    }

    /** The reload is over and the gun is ready: slide, bolt, pump or cylinder snapping shut. */
    public static int reloadDone(int weaponId) {
        return RELOAD_BASE + 3 * w(weaponId) + 2;
    }

    /** Mechanical action heard a moment after a shot (pump, bolt, hammer), or -1 for guns without one. */
    public static int action(int weaponId) {
        WeaponDef d = WeaponDef.byId(weaponId);
        return !d.melee && d.actionDelay > 0f ? ACTION_BASE + w(weaponId) : -1;
    }
}
