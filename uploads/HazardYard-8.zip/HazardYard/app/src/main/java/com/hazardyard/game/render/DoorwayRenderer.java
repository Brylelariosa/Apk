package com.hazardyard.game.render;

import android.graphics.Canvas;
import android.graphics.Paint;

import com.hazardyard.game.core.GameConfig;
import com.hazardyard.game.core.TileMap;

/**
 * Marks where you can walk into a house on a Battleground map. Every gap in a house's outer wall gets a threshold, two
 * door leaves swung open against the inside of the wall, and, outside, a paved step and a doormat in a colour of its
 * own. The mat and step lie flat on the ground, so they show from above whichever way the door faces, even where the
 * roof hides the door itself.
 */
final class DoorwayRenderer {
    private static final float T = GameConfig.TILE;
    private static final int[] MATS = {0xFFB43A3A, 0xFF3A6FB4, 0xFF3AA06A, 0xFFD8A030};
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);

    DoorwayRenderer() {
        fill.setStyle(Paint.Style.FILL);
    }

    void draw(Canvas c, TileMap map, float vx0, float vx1, float vy0, float vy1) {
        int[] d = map.doorways();
        int n = map.doorwayCount();
        for (int i = 0; i < n; i++) {
            int o = i * TileMap.DOOR_STRIDE;
            int h = d[o + TileMap.D_HOUSE], side = d[o + TileMap.D_SIDE], start = d[o + TileMap.D_START], len = d[o + TileMap.D_LEN];
            int hx0 = map.houses[h * 5], hy0 = map.houses[h * 5 + 1], hx1 = map.houses[h * 5 + 2], hy1 = map.houses[h * 5 + 3];
            boolean horizontal = side == 0 || side == 2;
            // the gap: tiles (gx0..gx1, gy0..gy1) in the wall ring
            int gx0 = horizontal ? start : (side == 1 ? hx1 : hx0), gy0 = horizontal ? (side == 0 ? hy0 : hy1) : start;
            float x0 = gx0 * T, y0 = gy0 * T;
            float w = horizontal ? len * T : T, hgt = horizontal ? T : len * T;
            if (x0 > vx1 + T || y0 > vy1 + T || x0 + w < vx0 - T || y0 + hgt < vy0 - 2f * T) continue;
            int outX = side == 1 ? 1 : (side == 3 ? -1 : 0), outY = side == 2 ? 1 : (side == 0 ? -1 : 0);
            // ---- outside: a paved step, then a doormat
            float sx0 = x0 + outX * T, sy0 = y0 + outY * T;
            fill.setColor(0xFFD2D2CC);
            c.drawRect(sx0 + (horizontal ? 3f : 4f), sy0 + (horizontal ? 4f : 3f), sx0 + w - (horizontal ? 3f : 4f), sy0 + hgt - (horizontal ? 4f : 3f), fill);
            fill.setColor(0xFFB2B2AC);
            if (side == 2) c.drawRect(sx0 + 3f, sy0 + T - 6f, sx0 + w - 3f, sy0 + T - 4f, fill);
            else if (side == 0) c.drawRect(sx0 + 3f, sy0 + 4f, sx0 + w - 3f, sy0 + 6f, fill);
            else if (side == 1) c.drawRect(sx0 + T - 6f, sy0 + 3f, sx0 + T - 4f, sy0 + hgt - 3f, fill);
            else c.drawRect(sx0 + 4f, sy0 + 3f, sx0 + 6f, sy0 + hgt - 3f, fill);
            fill.setColor(MATS[(h * 5 + start) & 3]);
            float mx = horizontal ? 10f : 9f, my = horizontal ? 9f : 10f;
            c.drawRoundRect(sx0 + mx, sy0 + my, sx0 + w - mx, sy0 + hgt - my, 3f, 3f, fill);
            fill.setColor(0x33FFFFFF);
            c.drawRect(sx0 + mx + 2f, sy0 + my + 2f, sx0 + w - mx - 2f, sy0 + my + 4f, fill);
            // ---- in the wall line: a wooden threshold and the open leaves
            fill.setColor(0xFFC89A60);
            c.drawRect(x0 + (horizontal ? 0f : 8f), y0 + (horizontal ? 8f : 0f), x0 + w - (horizontal ? 0f : 8f), y0 + hgt - (horizontal ? 8f : 0f), fill);
            fill.setColor(0xFF8A5E34);
            float leaf = 22f;
            if (horizontal) {
                // leaves hinged at both posts, swung into the house (away from the step)
                float ly0 = side == 2 ? y0 - leaf + 8f : y0 + 24f - 8f, ly1 = side == 2 ? y0 + 10f : y0 + 24f + leaf - 8f;
                c.drawRect(x0 + 2f, Math.min(ly0, ly1), x0 + 5.5f, Math.max(ly0, ly1), fill);
                c.drawRect(x0 + w - 5.5f, Math.min(ly0, ly1), x0 + w - 2f, Math.max(ly0, ly1), fill);
            } else {
                float lx0 = side == 1 ? x0 - leaf + 8f : x0 + 24f - 8f, lx1 = side == 1 ? x0 + 10f : x0 + 24f + leaf - 8f;
                c.drawRect(Math.min(lx0, lx1), y0 + 2f, Math.max(lx0, lx1), y0 + 5.5f, fill);
                c.drawRect(Math.min(lx0, lx1), y0 + hgt - 5.5f, Math.max(lx0, lx1), y0 + hgt - 2f, fill);
            }
            // frame posts
            fill.setColor(0xFF5A3A1E);
            if (horizontal) {
                c.drawRect(x0, y0 + 6f, x0 + 3f, y0 + T - 6f, fill);
                c.drawRect(x0 + w - 3f, y0 + 6f, x0 + w, y0 + T - 6f, fill);
            } else {
                c.drawRect(x0 + 6f, y0, x0 + T - 6f, y0 + 3f, fill);
                c.drawRect(x0 + 6f, y0 + hgt - 3f, x0 + T - 6f, y0 + hgt, fill);
            }
        }
    }
}
