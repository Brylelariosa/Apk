package com.hazardyard.game.render;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;

import com.hazardyard.game.core.GameConfig;
import com.hazardyard.game.core.GameState;
import com.hazardyard.game.core.Items;
import com.hazardyard.game.core.Player;
import com.hazardyard.game.core.WeaponDef;
import com.hazardyard.game.input.SurvivalUi;
import com.hazardyard.game.survival.Car;
import com.hazardyard.game.survival.Inventory;
import com.hazardyard.game.survival.Recipes;
import com.hazardyard.game.survival.SurvivalSim;
import com.hazardyard.game.survival.SurvivalState;

/**
 * The survival screens: the hotbar and the bag button, hunger, the clock, fishing and driving read-outs, short messages, and
 * the bag with the pack and the crafting list. Geometry comes from {@link SurvivalUi}.
 */
final class SurvivalHud {
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF rect = new RectF();
    private Player curPlayer;
    private final Typeface bold = Typeface.create(Typeface.DEFAULT, Typeface.BOLD);
    private final Typeface regular = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL);

    SurvivalHud() {
        stroke.setStyle(Paint.Style.STROKE);
    }

    private void label(Canvas c, String s, float x, float y, float sizePx, int color, Paint.Align align, boolean isBold) {
        text.setTypeface(isBold ? bold : regular);
        text.setTextSize(sizePx);
        text.setColor(color);
        text.setTextAlign(align);
        c.drawText(s, x, y, text);
    }

    private float measure(String s, float sizePx, boolean isBold) {
        text.setTypeface(isBold ? bold : regular);
        text.setTextSize(sizePx);
        return text.measureText(s);
    }

    private void round(Canvas c, float x, float y, float wd, float ht, float r, int color) {
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(color);
        rect.set(x, y, x + wd, y + ht);
        c.drawRoundRect(rect, r, r, fill);
    }

    private void outline(Canvas c, float x, float y, float wd, float ht, float r, int color, float width) {
        stroke.setColor(color);
        stroke.setStrokeWidth(width);
        rect.set(x, y, x + wd, y + ht);
        c.drawRoundRect(rect, r, r, stroke);
    }

    void draw(Canvas c, GameState st, SurvivalUi ui, int w, int h, float d, float time, float insetL, float insetT, float insetR, float insetB) {
        SurvivalState sv = st.survival;
        Player me = st.local();
        curPlayer = st.view();
        Inventory inv = sv.inv[st.localId];
        ui.layout(w, h, d, insetL, insetT, insetR, insetB);
        ui.setContext(inv, SurvivalSim.nearObject(sv, me.x, me.y, com.hazardyard.game.survival.Obj.WORKBENCH),
                SurvivalSim.nearObject(sv, me.x, me.y, com.hazardyard.game.survival.Obj.CAMPFIRE));
        drawClock(c, sv, w, d, insetT, time);
        if (me.alive) {
            drawHunger(c, sv, ui, st.localId, d);
            drawHotbar(c, inv, ui, me, d);
            drawFishing(c, sv, st.localId, w, h, d, time);
            drawDriving(c, sv, st.localId, w, d, insetT);
        }
        drawToast(c, sv, w, h, d);
        if (!me.alive && me.connected && st.phase == GameState.PHASE_PLAYING) drawDeath(c, me, w, h, d);
        if (ui.bagOpen && me.alive) drawBag(c, inv, ui, me, d);
    }

    /** The local survivor is down: say so and count down to the moment they get up again (close to where they fell). */
    private void drawDeath(Canvas c, Player me, int w, int h, float d) {
        float pw = 280f * d, ph = 92f * d;
        float x = (w - pw) * 0.5f, y = h * 0.28f;
        round(c, x, y, pw, ph, 14f * d, 0xCC101820);
        outline(c, x, y, pw, ph, 14f * d, 0x88FF5A4A, 1.6f * d);
        label(c, "YOU DIED", w * 0.5f, y + 33f * d, 24f * d, 0xFFFF5A4A, Paint.Align.CENTER, true);
        int secs = (int) Math.ceil(Math.max(0f, me.respawnTimer));
        label(c, secs > 0 ? "You get up again in " + secs + "..." : "Getting up...", w * 0.5f, y + 56f * d, 13f * d, 0xFFFFFFFF, Paint.Align.CENTER, true);
        label(c, "You come back close by. Your things lie where you fell.", w * 0.5f, y + 77f * d, 9.5f * d, 0xB0FFFFFF, Paint.Align.CENTER, false);
    }

    // ------------------------------------------------------------------ small read-outs

    private void drawClock(Canvas c, SurvivalState sv, int w, float d, float insetT, float time) {
        float f = sv.dayFraction();
        float hours = (6f + f * 24f) % 24f;
        int hh = (int) hours;
        int mm = (int) ((hours - hh) * 60f);
        String clock = (hh < 10 ? "0" : "") + hh + ":" + (mm < 10 ? "0" : "") + mm;
        float pw = 124f * d, ph = 26f * d;
        float x = (w - pw) * 0.5f, y = insetT + 6f * d;
        round(c, x, y, pw, ph, 9f * d, 0x99101820);
        boolean night = sv.isNight();
        fill.setColor(night ? 0xFFC8D4F0 : 0xFFFFD34A);
        float cx = x + 14f * d, cy = y + ph * 0.5f;
        c.drawCircle(cx, cy, 6f * d, fill);
        if (night) {
            fill.setColor(0xFF1A2230);
            c.drawCircle(cx + 3f * d, cy - 2f * d, 5f * d, fill);
        }
        label(c, "Day " + sv.dayNumber(), x + 28f * d, y + ph * 0.68f, 12f * d, 0xFFFFFFFF, Paint.Align.LEFT, true);
        label(c, clock, x + pw - 8f * d, y + ph * 0.68f, 12f * d, night ? 0xFF9FB4E8 : 0xFFE8E8E8, Paint.Align.RIGHT, false);
        // where the survivor is, in tiles from the start: the world is endless, so this is the only way to find the way home
        Player me = curPlayer;
        if (me != null) {
            String where = "x " + Math.round(me.rx / GameConfig.TILE) + "   y " + Math.round(me.ry / GameConfig.TILE);
            label(c, where, w * 0.5f, y + ph + 11f * d, 9.5f * d, 0xAAFFFFFF, Paint.Align.CENTER, false);
        }
    }

    private void drawHunger(Canvas c, SurvivalState sv, SurvivalUi ui, int id, float d) {
        float hunger = Math.max(0f, Math.min(100f, sv.hunger[id]));
        float total = ui.bagBtnX + ui.bagBtnS - ui.hotX0;
        float x = ui.hotX0, y = ui.hotY - 11f * d, ht = 6f * d;
        round(c, x, y, total, ht, ht * 0.5f, 0x55FFFFFF);
        int color = hunger > 50f ? 0xFFFFB347 : (hunger > 20f ? 0xFFFF8A3A : 0xFFFF4A3A);
        if (hunger > 0.5f) round(c, x, y, total * hunger / 100f, ht, ht * 0.5f, color);
        label(c, hunger <= 0.5f ? "Starving!" : "Hunger", x, y - 3f * d, 10f * d, hunger <= 20f ? 0xFFFF6A5A : 0xFFE0E0E0, Paint.Align.LEFT, hunger <= 20f);
    }

    private void drawHotbar(Canvas c, Inventory inv, SurvivalUi ui, Player me, float d) {
        // the name of what is in hand, above the bar
        int hand = inv.selectedItem();
        if (hand >= 0) {
            String nm = Items.name(hand);
            float tw = measure(nm, 11f * d, true) + 16f * d;
            float cx = ui.hotX0 + (ui.bagBtnX + ui.bagBtnS - ui.hotX0) * 0.5f;
            round(c, cx - tw * 0.5f, ui.hotY - 44f * d, tw, 18f * d, 9f * d, 0x99101820);
            label(c, nm, cx, ui.hotY - 31f * d, 11f * d, 0xFFFFFFFF, Paint.Align.CENTER, true);
        }
        for (int i = 0; i < Inventory.HOTBAR; i++) {
            float x = ui.slotX(i);
            boolean sel = i == inv.selected;
            float lift = sel ? 3f * d : 0f;
            slotFrame(c, x, ui.hotY - lift, ui.slot, d, sel, i == ui.selSlot && ui.bagOpen, true);
            drawStack(c, inv, i, x, ui.hotY - lift, ui.slot, d, me, true);
            label(c, Integer.toString(i + 1), x + 5f * d, ui.hotY - lift + 12f * d, 9f * d, sel ? 0xFFFFE9A0 : 0x99FFFFFF, Paint.Align.LEFT, true);
        }
        // the bag button: a backpack, lit while the bag is open
        boolean open = ui.bagOpen;
        round(c, ui.bagBtnX, ui.bagBtnY, ui.bagBtnS, ui.bagBtnS, 10f * d, open ? 0xDD3A4A66 : 0xAA101820);
        outline(c, ui.bagBtnX, ui.bagBtnY, ui.bagBtnS, ui.bagBtnS, 10f * d, open ? 0xFFFFD34A : 0xAAB8C4D8, 1.8f * d);
        ItemGlyph.drawBackpack(c, fill, path, ui.bagBtnX + ui.bagBtnS * 0.5f, ui.bagBtnY + ui.bagBtnS * 0.43f, ui.bagBtnS * 0.30f, 0xFFC8A06A);
        label(c, "BAG", ui.bagBtnX + ui.bagBtnS * 0.5f, ui.bagBtnY + ui.bagBtnS - 4f * d, 8.5f * d, 0xFFE8E8E8, Paint.Align.CENTER, true);
        int used = 0;
        for (int i = 0; i < Inventory.SLOTS; i++) if (!inv.isEmpty(i)) used++;
        if (used >= Inventory.SLOTS) {
            round(c, ui.bagBtnX + ui.bagBtnS - 16f * d, ui.bagBtnY - 6f * d, 22f * d, 14f * d, 7f * d, 0xFFD8442F);
            label(c, "FULL", ui.bagBtnX + ui.bagBtnS - 5f * d, ui.bagBtnY + 4.5f * d, 7.5f * d, 0xFFFFFFFF, Paint.Align.CENTER, true);
        }
    }

    /** A slot background: a soft dark tile with a light top edge; the selected one glows gold and the one being moved blue. */
    private void slotFrame(Canvas c, float x, float y, float size, float d, boolean selected, boolean picked, boolean hot) {
        int base = selected ? 0xDD2C3C58 : (hot ? 0xAA1D2736 : 0xAA171D27);
        round(c, x, y, size, size, 9f * d, base);
        // a light edge along the top gives the tile some depth
        round(c, x + 2f * d, y + 1.5f * d, size - 4f * d, 4f * d, 3f * d, 0x16FFFFFF);
        int edge = selected ? 0xFFFFD34A : (picked ? 0xFF6FB6FF : 0x44FFFFFF);
        outline(c, x, y, size, size, 9f * d, edge, selected || picked ? 2.4f * d : 1.1f * d);
        if (selected) {
            stroke.setColor(0x44FFD34A);
            stroke.setStrokeWidth(5f * d);
            rect.set(x - 1f * d, y - 1f * d, x + size + 1f * d, y + size + 1f * d);
            c.drawRoundRect(rect, 10f * d, 10f * d, stroke);
        }
    }

    /** The item in a slot: its icon, its count, and for a gun a bar of the rounds in the magazine. */
    private void drawStack(Canvas c, Inventory inv, int slot, float x, float y, float size, float d, Player me, boolean small) {
        if (inv.isEmpty(slot)) return;
        int item = inv.item[slot];
        int color = 0xFF000000 | (Items.color(item) & 0x00FFFFFF);
        ItemGlyph.draw(c, fill, path, x + size * 0.5f, y + size * 0.47f, size * 0.30f, item, color);
        if (inv.count[slot] > 1) label(c, "x" + inv.count[slot], x + size - 4f * d, y + size - 4f * d, 10f * d, 0xFFFFFFFF, Paint.Align.RIGHT, true);
        if (Items.isWeapon(item) && !WeaponDef.byId(item).melee) {
            WeaponDef wd = WeaponDef.byId(item);
            int rounds = slot == inv.selected && me != null && me.weapon.def.id == item ? me.weapon.ammo : inv.ammo[slot];
            float frac = Math.max(0f, Math.min(1f, rounds / (float) wd.magSize));
            float bw = size - 12f * d, bx = x + 6f * d, by = y + size - 7f * d;
            round(c, bx, by, bw, 3f * d, 1.5f * d, 0x66000000);
            if (frac > 0f) round(c, bx, by, bw * frac, 3f * d, 1.5f * d, frac > 0.25f ? 0xFFFFD34A : 0xFFFF5A3A);
            label(c, Integer.toString(rounds), x + size - 4f * d, y + 12f * d, 9.5f * d, 0xFFFFD34A, Paint.Align.RIGHT, true);
        }
    }

    private void drawFishing(Canvas c, SurvivalState sv, int id, int w, int h, float d, float time) {
        int state = sv.fishState[id];
        if (state == 0) return;
        if (state == 2) {
            float pulse = 0.5f + 0.5f * (float) Math.sin(time * 18f);
            round(c, w * 0.5f - 90f * d, h * 0.2f - 18f * d, 180f * d, 36f * d, 12f * d, 0xDD1A2A3A);
            outline(c, w * 0.5f - 90f * d, h * 0.2f - 18f * d, 180f * d, 36f * d, 12f * d, 0xFFFFE066, (2f + 2f * pulse) * d);
            label(c, "A fish! Tap to reel in", w * 0.5f, h * 0.2f + 5f * d, 15f * d, 0xFFFFE066, Paint.Align.CENTER, true);
        } else {
            label(c, "Waiting for a bite...", w * 0.5f, h * 0.2f, 12f * d, 0xCCFFFFFF, Paint.Align.CENTER, false);
        }
    }

    private void drawDriving(Canvas c, SurvivalState sv, int id, int w, float d, float insetT) {
        int carId = sv.drivingCar[id];
        if (carId < 0) return;
        Car car = sv.carById(carId);
        if (car == null) return;
        float pw = 150f * d, ph = 40f * d;
        float x = (w - pw) * 0.5f, y = insetT + 52f * d;
        round(c, x, y, pw, ph, 10f * d, 0xAA101820);
        int kmh = Math.round(Math.abs(car.speed) * 0.36f);
        label(c, kmh + " km/h", x + 10f * d, y + 16f * d, 14f * d, 0xFFFFFFFF, Paint.Align.LEFT, true);
        label(c, car.running ? "Engine on" : "Engine off", x + pw - 8f * d, y + 16f * d, 10f * d, car.running ? 0xFF6EE08A : 0xFFFF8A6A, Paint.Align.RIGHT, false);
        float bw = pw - 20f * d;
        round(c, x + 10f * d, y + 24f * d, bw, 5f * d, 2.5f * d, 0x44FFFFFF);
        round(c, x + 10f * d, y + 24f * d, bw * Math.max(0, car.fuel) / 100f, 5f * d, 2.5f * d, car.fuel < 15 ? 0xFFFF5A4A : 0xFFFFC04A);
        round(c, x + 10f * d, y + 32f * d, bw, 3f * d, 1.5f * d, 0x44FFFFFF);
        round(c, x + 10f * d, y + 32f * d, bw * Math.max(0, car.hp) / 100f, 3f * d, 1.5f * d, 0xFF6EE08A);
    }

    private void drawToast(Canvas c, SurvivalState sv, int w, int h, float d) {
        if (sv.toast < 0 || sv.toast >= SurvivalSim.TOASTS.length || sv.toastTimer <= 0f) return;
        String s = SurvivalSim.TOASTS[sv.toast];
        float a = Math.min(1f, sv.toastTimer / 0.5f);
        float tw = measure(s, 14f * d, true) + 28f * d;
        float x = (w - tw) * 0.5f, y = h * 0.30f;
        round(c, x, y, tw, 30f * d, 10f * d, ((int) (a * 200f) << 24) | 0x101820);
        label(c, s, w * 0.5f, y + 20f * d, 14f * d, ((int) (a * 255f) << 24) | 0xFFFFFF, Paint.Align.CENTER, true);
    }

    // ------------------------------------------------------------------ the bag

    private void drawBag(Canvas c, Inventory inv, SurvivalUi ui, Player me, float d) {
        // dim the world behind: the bag is modal
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(0x88050810);
        c.drawRect(0f, 0f, ui.panelX1 + ui.panelX0 + 20f * d, ui.panelY1 + ui.panelY0 + 40f * d, fill);
        float pw = ui.panelX1 - ui.panelX0, ph = ui.panelY1 - ui.panelY0;
        round(c, ui.panelX0, ui.panelY0, pw, ph, 16f * d, 0xF40E141C);
        outline(c, ui.panelX0, ui.panelY0, pw, ph, 16f * d, 0x55FFFFFF, 1.3f * d);
        // header: the title, how full the pack is, the tabs and the close button
        int used = 0;
        for (int i = 0; i < Inventory.SLOTS; i++) if (!inv.isEmpty(i)) used++;
        label(c, "Backpack", ui.gridX0, ui.panelY0 + ui.headerH * 0.64f, 17f * d, 0xFFFFFFFF, Paint.Align.LEFT, true);
        float tw = measure("Backpack", 17f * d, true);
        String cap = used + " / " + Inventory.SLOTS;
        float cw = measure(cap, 10.5f * d, true) + 14f * d;
        round(c, ui.gridX0 + tw + 10f * d, ui.panelY0 + ui.headerH * 0.5f - 9f * d, cw, 18f * d, 9f * d, used >= Inventory.SLOTS ? 0xFF8A3A2E : 0xFF26344A);
        label(c, cap, ui.gridX0 + tw + 10f * d + cw * 0.5f, ui.panelY0 + ui.headerH * 0.5f + 4f * d, 10.5f * d, 0xFFFFFFFF, Paint.Align.CENTER, true);
        for (int t = 0; t < 2; t++) {
            boolean on = ui.tab == t;
            round(c, ui.tabX(t), ui.tabY, ui.tabW, ui.tabH, ui.tabH * 0.5f, on ? 0xFF3A5A8C : 0xFF1C2634);
            if (on) outline(c, ui.tabX(t), ui.tabY, ui.tabW, ui.tabH, ui.tabH * 0.5f, 0xFF9CC4FF, 1.4f * d);
            label(c, t == 0 ? "Items" : "Craft", ui.tabX(t) + ui.tabW * 0.5f, ui.tabY + ui.tabH * 0.66f, 12.5f * d, on ? 0xFFFFFFFF : 0xFFA8B4C8, Paint.Align.CENTER, true);
        }
        round(c, ui.closeX, ui.closeY, ui.closeS, ui.closeS, ui.closeS * 0.5f, 0xFF4A2A30);
        outline(c, ui.closeX, ui.closeY, ui.closeS, ui.closeS, ui.closeS * 0.5f, 0x88FFFFFF, 1.2f * d);
        stroke.setColor(0xFFFFFFFF);
        stroke.setStrokeWidth(2.4f * d);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        float m = ui.closeS * 0.32f;
        c.drawLine(ui.closeX + m, ui.closeY + m, ui.closeX + ui.closeS - m, ui.closeY + ui.closeS - m, stroke);
        c.drawLine(ui.closeX + ui.closeS - m, ui.closeY + m, ui.closeX + m, ui.closeY + ui.closeS - m, stroke);
        stroke.setStrokeCap(Paint.Cap.BUTT);
        // the pack: the first row is the hotbar
        for (int i = 0; i < Inventory.SLOTS; i++) {
            float x = ui.cellX(i), y = ui.cellY(i);
            boolean hot = i < Inventory.HOTBAR;
            boolean dragged = ui.dragging && i == ui.dragSlot;
            slotFrame(c, x, y, ui.cell, d, hot && i == inv.selected, i == ui.selSlot, hot);
            if (!dragged) drawStack(c, inv, i, x, y, ui.cell, d, me, false);
            if (hot) label(c, Integer.toString(i + 1), x + 5f * d, y + 12f * d, 9f * d, 0x99FFFFFF, Paint.Align.LEFT, true);
        }
        label(c, "Hotbar", ui.gridX0, ui.cellY(0) - 3f * d, 8.5f * d, 0x77FFFFFF, Paint.Align.LEFT, false);
        float hintY = ui.cellY(Inventory.SLOTS - 1) + ui.cell + 15f * d;
        label(c, "Tap an item, then a slot to move it  \u2022  or drag it", ui.gridX0, Math.min(hintY, ui.panelY1 - 5f * d), 9f * d, 0x88FFFFFF, Paint.Align.LEFT, false);
        if (ui.tab == SurvivalUi.TAB_ITEMS) drawDetails(c, inv, ui, me, d);
        else drawCrafting(c, ui, d);
        // the item being dragged follows the finger
        if (ui.dragging && ui.dragSlot >= 0 && !inv.isEmpty(ui.dragSlot)) {
            int item = inv.item[ui.dragSlot];
            fill.setStyle(Paint.Style.FILL);
            fill.setColor(0x55000000);
            c.drawCircle(ui.dragX, ui.dragY + 6f * d, ui.cell * 0.42f, fill);
            ItemGlyph.draw(c, fill, path, ui.dragX, ui.dragY - 4f * d, ui.cell * 0.36f, item, 0xFF000000 | (Items.color(item) & 0x00FFFFFF));
        }
    }

    /** The right-hand panel of the Items tab: the selected item, what it is worth and the buttons for it. */
    private void drawDetails(Canvas c, Inventory inv, SurvivalUi ui, Player me, float d) {
        float x0 = ui.detX0, y0 = ui.detY0, x1 = ui.detX1;
        round(c, x0, y0, x1 - x0, ui.detY1 - y0, 12f * d, 0x66131B26);
        int sel = ui.selSlot >= 0 && !inv.isEmpty(ui.selSlot) ? inv.item[ui.selSlot] : -1;
        if (sel < 0) {
            ItemGlyph.drawBackpack(c, fill, path, (x0 + x1) * 0.5f, y0 + (ui.detY1 - y0) * 0.36f, 26f * d, 0x66C8A06A);
            label(c, "Select an item", (x0 + x1) * 0.5f, y0 + (ui.detY1 - y0) * 0.64f, 14f * d, 0xCCFFFFFF, Paint.Align.CENTER, true);
            label(c, "to see what it does", (x0 + x1) * 0.5f, y0 + (ui.detY1 - y0) * 0.64f + 17f * d, 10.5f * d, 0x88FFFFFF, Paint.Align.CENTER, false);
            return;
        }
        int color = 0xFF000000 | (Items.color(sel) & 0x00FFFFFF);
        // the big icon on a tinted tile
        float is = Math.min(66f * d, (ui.detY1 - y0) * 0.30f);
        round(c, x0 + 10f * d, y0 + 10f * d, is, is, 12f * d, (color & 0x00FFFFFF) | 0x33000000);
        outline(c, x0 + 10f * d, y0 + 10f * d, is, is, 12f * d, (color & 0x00FFFFFF) | 0x99000000, 1.6f * d);
        ItemGlyph.draw(c, fill, path, x0 + 10f * d + is * 0.5f, y0 + 10f * d + is * 0.5f, is * 0.30f, sel, color);
        float tx = x0 + 10f * d + is + 12f * d;
        label(c, Items.name(sel), tx, y0 + 28f * d, 15f * d, 0xFFFFFFFF, Paint.Align.LEFT, true);
        String cat = categoryName(Items.category(sel));
        float cw = measure(cat, 9.5f * d, true) + 14f * d;
        round(c, tx, y0 + 35f * d, cw, 16f * d, 8f * d, 0x55FFFFFF & 0x00FFFFFF | 0x44000000 | (color & 0x00FFFFFF) & 0x00FFFFFF);
        label(c, cat, tx + cw * 0.5f, y0 + 46.5f * d, 9.5f * d, 0xFFFFFFFF, Paint.Align.CENTER, true);
        if (inv.count[ui.selSlot] > 1) label(c, "x" + inv.count[ui.selSlot], x1 - 12f * d, y0 + 28f * d, 14f * d, 0xFFFFE08A, Paint.Align.RIGHT, true);
        // what it does
        float y = y0 + 10f * d + is + 18f * d;
        if (Items.isWeapon(sel)) {
            WeaponDef wd = WeaponDef.byId(sel);
            drawWeaponStats(c, wd, inv, ui.selSlot, me, x0 + 12f * d, y, x1 - 12f * d, d);
        } else {
            String line = Items.foodValue(sel) > 0 ? "Restores " + Items.foodValue(sel) + " hunger"
                    : (Items.healValue(sel) > 0 ? "Heals " + Items.healValue(sel) + " health"
                    : (Items.isVest(sel) ? "Wear it: +" + Items.armorOf(sel) + " armour" : itemBlurb(sel)));
            label(c, line, x0 + 12f * d, y + 12f * d, 12f * d, 0xFFD8E0EC, Paint.Align.LEFT, false);
        }
        // the buttons
        int act = SurvivalUi.actionFor(sel, ui.selSlot);
        String primary = act == SurvivalUi.ACT_USE ? "Use" : (act == SurvivalUi.ACT_HOLD ? "Hold" : (act == SurvivalUi.ACT_EQUIP ? "Equip" : "\u2014"));
        button(c, ui.actX(0), ui.actY, ui.actW, ui.actH, primary, act != SurvivalUi.ACT_NONE, act == SurvivalUi.ACT_USE ? 0xFF2E6A44 : 0xFF2C5A8C, d);
        button(c, ui.actX(1), ui.actY, ui.actW, ui.actH, "Drop", true, 0xFF6A3A2E, d);
    }

    private void drawWeaponStats(Canvas c, WeaponDef wd, Inventory inv, int slot, Player me, float x0, float y, float x1, float d) {
        float bw = x1 - x0 - 74f * d;
        float row = 17f * d;
        if (wd.melee) {
            statBar(c, "Damage", wd.damage / 70f, Integer.toString(Math.round(wd.damage)), x0, y, bw, d, 0xFFFF7A5A);
            statBar(c, "Speed", 1f - Math.min(1f, (wd.fireInterval - 0.28f) / 0.7f), String.format(java.util.Locale.US, "%.1f/s", 1f / Math.max(0.1f, wd.fireInterval)), x0, y + row, bw, d, 0xFFFFD34A);
            statBar(c, "Reach", wd.reach / 60f, Math.round(wd.reach) + "", x0, y + 2 * row, bw, d, 0xFF6FD6FF);
            if (wd.profile != null) {
                label(c, wd.profile.attacks.length + "-hit combo  \u2022  " + impactName(wd.profile.impact), x0, y + 3 * row + 8f * d, 10f * d, 0xFFA8B4C8, Paint.Align.LEFT, false);
            }
        } else {
            statBar(c, "Damage", wd.damage * Math.max(1, wd.pellets) / 80f, Integer.toString(Math.round(wd.damage)) + (wd.pellets > 1 ? "x" + wd.pellets : ""), x0, y, bw, d, 0xFFFF7A5A);
            statBar(c, "Fire rate", Math.min(1f, (1f / Math.max(0.05f, wd.fireInterval)) / 12f), String.format(java.util.Locale.US, "%.1f/s", 1f / Math.max(0.05f, wd.fireInterval)), x0, y + row, bw, d, 0xFFFFD34A);
            statBar(c, "Range", Math.min(1f, wd.range / 520f), Math.round(wd.range) + "", x0, y + 2 * row, bw, d, 0xFF6FD6FF);
            int rounds = slot == inv.selected && me != null && me.weapon.def.id == wd.id ? me.weapon.ammo : inv.ammo[slot];
            int spare = wd.ammoItem >= 0 ? inv.countOf(wd.ammoItem) : 0;
            label(c, "Loaded " + rounds + "/" + wd.magSize + "   \u2022   spare " + spare, x0, y + 3 * row + 8f * d, 10.5f * d, 0xFFFFE08A, Paint.Align.LEFT, true);
        }
    }

    private void statBar(Canvas c, String name, float frac, String value, float x, float y, float bw, float d, int color) {
        label(c, name, x, y + 10f * d, 10f * d, 0xFFB8C4D8, Paint.Align.LEFT, false);
        float bx = x + 56f * d;
        round(c, bx, y + 3f * d, bw - 56f * d + 4f * d, 7f * d, 3.5f * d, 0x55000000);
        round(c, bx, y + 3f * d, Math.max(6f * d, (bw - 52f * d) * Math.max(0.04f, Math.min(1f, frac))), 7f * d, 3.5f * d, color);
        label(c, value, x + bw + 70f * d, y + 10f * d, 10f * d, 0xFFFFFFFF, Paint.Align.RIGHT, true);
    }

    private static String impactName(int impact) {
        switch (impact) {
            case 1: return "slashes";
            case 2: return "pierces";
            case 3: return "chops";
            default: return "blunt";
        }
    }

    private static String categoryName(int cat) {
        switch (cat) {
            case Items.CAT_WEAPON: return "Weapon";
            case Items.CAT_ARMOR: return "Armour";
            case Items.CAT_HEAL: return "Medical";
            case Items.CAT_FOOD: return "Food";
            case Items.CAT_MATERIAL: return "Material";
            case Items.CAT_TOOL: return "Tool";
            case Items.CAT_SEED: return "Seed";
            case Items.CAT_PART: return "Car part";
            case Items.CAT_AMMO: return "Ammo";
            default: return "Building";
        }
    }

    private static String itemBlurb(int item) {
        switch (Items.category(item)) {
            case Items.CAT_MATERIAL: return "Crafting material";
            case Items.CAT_TOOL: return "A tool: hold it and use it";
            case Items.CAT_SEED: return "Plant it on tilled soil";
            case Items.CAT_PART: return "A car part for repairs";
            case Items.CAT_AMMO: return "Ammunition for guns";
            case Items.CAT_BUILD: return "Place it in the world";
            default: return "";
        }
    }

    /** The Craft tab: each recipe with an icon and chips for what it needs (green when the pack has enough). */
    private void drawCrafting(Canvas c, SurvivalUi ui, float d) {
        c.save();
        c.clipRect(ui.listX0, ui.listY0, ui.listX1, ui.listY1);
        SurvivalState none = null;
        Inventory inv = ui.inventory();
        for (int r = 0; r < Recipes.ALL.length; r++) {
            float y = ui.rowY(r);
            if (y + ui.rowH < ui.listY0 || y > ui.listY1) continue;
            Recipes.Recipe rc = Recipes.ALL[r];
            boolean can = ui.craftable(r);
            boolean selected = r == ui.selRecipe;
            round(c, ui.listX0, y + 2f * d, ui.listX1 - ui.listX0, ui.rowH - 4f * d, 9f * d, selected ? 0xDD2A3C58 : 0x99161D28);
            if (selected) outline(c, ui.listX0, y + 2f * d, ui.listX1 - ui.listX0, ui.rowH - 4f * d, 9f * d, 0xFFFFD34A, 1.8f * d);
            else if (can) outline(c, ui.listX0, y + 2f * d, ui.listX1 - ui.listX0, ui.rowH - 4f * d, 9f * d, 0x668FE8A0, 1.2f * d);
            int col = 0xFF000000 | (Items.color(rc.out) & 0x00FFFFFF);
            ItemGlyph.draw(c, fill, path, ui.listX0 + 24f * d, y + ui.rowH * 0.5f, 10.5f * d, rc.out, col);
            label(c, rc.name, ui.listX0 + 46f * d, y + 16f * d, 12f * d, can ? 0xFF9CF0AE : 0xFFE6EAF0, Paint.Align.LEFT, true);
            // one chip per ingredient: its icon and have/need
            float cx = ui.listX0 + 46f * d;
            for (int k = 0; k < rc.in.length; k += 2) {
                int item = rc.in[k], need = rc.in[k + 1];
                int have = inv != null ? inv.countOf(item) : 0;
                boolean ok = have >= need;
                String t = have + "/" + need;
                float chipW = 24f * d + measure(t, 9f * d, true);
                if (cx + chipW > ui.listX1 - 6f * d) break;
                round(c, cx, y + 21f * d, chipW, 16f * d, 8f * d, ok ? 0x663A8A52 : 0x66A04838);
                ItemGlyph.draw(c, fill, path, cx + 8f * d, y + 29f * d, 4.4f * d, item, 0xFF000000 | (Items.color(item) & 0x00FFFFFF));
                label(c, t, cx + 15f * d, y + 32.5f * d, 9f * d, ok ? 0xFFD8FFE0 : 0xFFFFC8BE, Paint.Align.LEFT, true);
                cx += chipW + 4f * d;
            }
            if (rc.station != Recipes.NONE) {
                String st = rc.station == Recipes.BENCH ? "Bench" : "Fire";
                boolean near = rc.station == Recipes.BENCH ? ui.nearBench() : ui.nearFire();
                float sw = measure(st, 9f * d, true) + 12f * d;
                round(c, ui.listX1 - sw - 6f * d, y + 6f * d, sw, 15f * d, 7.5f * d, near ? 0x663A8A52 : 0x66A04838);
                label(c, st, ui.listX1 - sw * 0.5f - 6f * d, y + 16.5f * d, 9f * d, 0xFFFFFFFF, Paint.Align.CENTER, true);
            }
        }
        c.restore();
        boolean can = ui.selRecipe >= 0 && ui.craftable(ui.selRecipe);
        button(c, ui.craftX, ui.craftY, ui.craftW, ui.craftH, ui.selRecipe >= 0 ? "Craft " + Recipes.ALL[ui.selRecipe].name : "Pick a recipe", can, 0xFF2E6A44, d);
        if (ui.selRecipe >= 0 && !can) {
            Recipes.Recipe rc = Recipes.ALL[ui.selRecipe];
            String why = rc.station == Recipes.BENCH && !ui.nearBench() ? "Stand next to a workbench" : (rc.station == Recipes.FIRE && !ui.nearFire() ? "Stand next to a campfire" : "Missing materials");
            label(c, why, ui.craftX + ui.craftW - 10f * d, ui.craftY - 4f * d, 10f * d, 0xFFFF9A8A, Paint.Align.RIGHT, false);
        }
    }

    private void button(Canvas c, float x, float y, float wd, float ht, String s, boolean enabled, int color, float d) {
        round(c, x, y, wd, ht, 10f * d, enabled ? color : 0xFF232830);
        round(c, x + 2f * d, y + 2f * d, wd - 4f * d, ht * 0.4f, 8f * d, enabled ? 0x22FFFFFF : 0x0AFFFFFF);
        outline(c, x, y, wd, ht, 10f * d, enabled ? 0xCCFFFFFF : 0x33FFFFFF, 1.4f * d);
        label(c, s, x + wd * 0.5f, y + ht * 0.64f, 13f * d, enabled ? 0xFFFFFFFF : 0x66FFFFFF, Paint.Align.CENTER, true);
    }
}
