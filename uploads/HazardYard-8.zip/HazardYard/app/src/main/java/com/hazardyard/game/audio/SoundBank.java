package com.hazardyard.game.audio;

import com.hazardyard.game.core.Sounds;
import com.hazardyard.game.core.WeaponDef;

/**
 * Builds every sound effect of the game from scratch with {@link Synth}: no audio files.
 *
 * <p>All firearms share one family resemblance, the one of the assault rifle: a bright noise crack, a quick
 * low "thump" that dives in pitch, a mid-range body, a faint supersonic snap, a touch of saturation and a short
 * echo from the room. Each gun then gets its own numbers (a pistol is smaller and higher, a shotgun is wide and long,
 * a sniper rifle has a thin crack and a long echo...), so they sound like one weapon cabinet and are still easy to
 * tell apart. The assault rifle itself is exactly the recipe it always was.
 *
 * <p>Reloads are told as small mechanical stories, three sounds per gun (it starts, the ammunition goes in, it is
 * ready), made from short metal and polymer impacts (a sharp transient, a quickly damped body note and a low knock),
 * sliding friction and ratchets; there are no bell-like rings. Guns with a pump, bolt or hammer also have an action
 * sound that follows a shot. The game plays each of them at the moment the gun really reaches that stage.
 */
public final class SoundBank {
    private SoundBank() {}

    /** How far each sound carries, as a multiple of the normal hearing distance. */
    private static final float[] CARRY = new float[Sounds.COUNT];
    /** Default loudness of each sound before distance and master volume. */
    private static final float[] LEVEL = new float[Sounds.COUNT];

    static {
        java.util.Arrays.fill(CARRY, 1f);
        java.util.Arrays.fill(LEVEL, 1f);
        CARRY[WeaponDef.PISTOL] = 1.0f;
        CARRY[WeaponDef.RIFLE] = 1.3f;
        CARRY[WeaponDef.SHOTGUN] = 1.6f;
        CARRY[WeaponDef.SMG] = 0.9f;
        CARRY[WeaponDef.SNIPER] = 3.2f;
        CARRY[WeaponDef.MAGNUM] = 1.7f;
        CARRY[WeaponDef.PLASMA] = 1.3f;
        CARRY[WeaponDef.LMG] = 1.5f;
        CARRY[WeaponDef.REVOLVER] = 1.4f;
        CARRY[WeaponDef.DOUBLE_BARREL] = 1.7f;
        CARRY[WeaponDef.HUNTING_RIFLE] = 3.0f;
        CARRY[WeaponDef.AK] = 1.4f;
        CARRY[WeaponDef.DMR] = 2.4f;
        CARRY[WeaponDef.MACHINE_PISTOL] = 0.9f;
        for (int w = WeaponDef.GUN_COUNT; w < Sounds.WEAPONS; w++) {
            CARRY[w] = 0.35f;
            LEVEL[w] = 0.75f;
        }
        LEVEL[WeaponDef.SMG] = 0.8f;
        LEVEL[WeaponDef.MACHINE_PISTOL] = 0.8f;
        LEVEL[WeaponDef.PLASMA] = 0.85f;
        LEVEL[WeaponDef.PISTOL] = 0.9f;
        CARRY[Sounds.KILL] = 1.4f;
        CARRY[Sounds.IMPACT] = 0.5f;
        CARRY[Sounds.PICKUP] = 0.7f;
        CARRY[Sounds.RESPAWN] = 0.7f;
        CARRY[Sounds.DODGE] = 0.6f;
        LEVEL[Sounds.IMPACT] = 0.5f;
        LEVEL[Sounds.HIT] = 0.85f;
        LEVEL[Sounds.DODGE] = 0.95f;
        LEVEL[Sounds.PICKUP] = 0.9f;
        LEVEL[Sounds.COUNTDOWN] = 0.7f;
        CARRY[Sounds.MELEE_HIT] = 0.6f;
        CARRY[Sounds.ARMOR_HIT] = 0.6f;
        CARRY[Sounds.ARMOR_EQUIP] = 0.4f;
        CARRY[Sounds.HEAL] = 0.4f;
        CARRY[Sounds.ZONE_ALERT] = 1f;
        // survival
        CARRY[Sounds.CHOP] = 1.0f;
        CARRY[Sounds.MINE] = 1.0f;
        for (int i = 0; i < Sounds.ZOMBIE_GROANS; i++) {
            CARRY[Sounds.ZOMBIE_GROAN + i] = 1.5f;
            LEVEL[Sounds.ZOMBIE_GROAN + i] = 0.8f;
        }
        CARRY[Sounds.ZOMBIE_ATTACK] = 0.8f;
        CARRY[Sounds.ZOMBIE_DEATH] = 1.0f;
        CARRY[Sounds.EAT] = 0.3f;
        CARRY[Sounds.CRAFT] = 0.6f;
        CARRY[Sounds.BUILD] = 0.8f;
        CARRY[Sounds.DOOR] = 0.8f;
        CARRY[Sounds.SEARCH] = 0.5f;
        CARRY[Sounds.FISH_CAST] = 0.6f;
        CARRY[Sounds.FISH_BITE] = 0.5f;
        CARRY[Sounds.FISH_CATCH] = 0.6f;
        CARRY[Sounds.DIG] = 0.5f;
        CARRY[Sounds.PLANT] = 0.4f;
        CARRY[Sounds.HARVEST] = 0.4f;
        CARRY[Sounds.ENGINE_START] = 2.0f;
        CARRY[Sounds.ENGINE_FAIL] = 1.2f;
        CARRY[Sounds.ENGINE_LOOP] = 2.0f;
        LEVEL[Sounds.ENGINE_LOOP] = 0.6f;
        CARRY[Sounds.CAR_HIT] = 1.5f;
        CARRY[Sounds.REPAIR] = 0.7f;
        CARRY[Sounds.SPLASH] = 0.6f;
        CARRY[Sounds.BREAK] = 1.0f;
        CARRY[Sounds.WEAPON_SWITCH] = 0.4f;
        LEVEL[Sounds.WEAPON_SWITCH] = 0.8f;
        CARRY[Sounds.BODY_THUD] = 0.7f;
        LEVEL[Sounds.BODY_THUD] = 0.9f;
        CARRY[Sounds.FLESH_SLASH] = 0.6f;
        // Reload and action sounds are small, close-by sounds: quiet and short-ranged.
        for (int w = 0; w < WeaponDef.GUN_COUNT; w++) {
            for (int stage = 0; stage < 3; stage++) {
                CARRY[Sounds.RELOAD_BASE + 3 * w + stage] = 0.5f;
                LEVEL[Sounds.RELOAD_BASE + 3 * w + stage] = 0.85f;
            }
            CARRY[Sounds.ACTION_BASE + w] = 0.7f;
            LEVEL[Sounds.ACTION_BASE + w] = 0.85f;
        }
    }

    public static float carry(int sound) {
        return CARRY[sound];
    }

    public static float level(int sound) {
        return LEVEL[sound];
    }

    /** Synthesises all sounds (a fraction of a second of work in total). Index = {@link Sounds} id. */
    public static short[][] build() {
        short[][] pcm = new short[Sounds.COUNT][];
        for (int id = 0; id < Sounds.COUNT; id++) pcm[id] = Synth.toPcm(make(id));
        return pcm;
    }

    /** Float version of one sound, used by {@link #build} and by the tests. */
    static float[] make(int id) {
        if (id >= Sounds.RELOAD_BASE && id < Sounds.ACTION_BASE) {
            int rel = id - Sounds.RELOAD_BASE;
            return reload(rel / 3, rel % 3);
        }
        if (id >= Sounds.ACTION_BASE && id < Sounds.EXTRA_BASE) return action(id - Sounds.ACTION_BASE);
        if (id >= Sounds.ZOMBIE_GROAN && id < Sounds.ZOMBIE_GROAN + Sounds.ZOMBIE_GROANS) return zombieGroan(id - Sounds.ZOMBIE_GROAN);
        if (id < WeaponDef.GUN_COUNT) return gun(id);
        if (id < Sounds.WEAPONS) return swing(id);
        switch (id) {
            case Sounds.PICKUP: return pickup();
            case Sounds.HIT: return hit();
            case Sounds.HURT: return hurt();
            case Sounds.KILL: return kill();
            case Sounds.DEATH: return death();
            case Sounds.RESPAWN: return respawn();
            case Sounds.IMPACT: return impact();
            case Sounds.COUNTDOWN: return beep(880f, 0.14f);
            case Sounds.GO: return go();
            case Sounds.WIN: return arpeggio(new float[] {523.25f, 659.25f, 783.99f, 1046.5f}, 0.11f, 0.5f, 0.1f);
            case Sounds.LOSE: return arpeggio(new float[] {392f, 349.23f, 293.66f, 233.08f}, 0.16f, 0.45f, 0.5f);
            case Sounds.CONFIRM: return confirm();
            case Sounds.DODGE: return dodge();
            case Sounds.MELEE_HIT: return meleeHit();
            case Sounds.ARMOR_HIT: return armorHit();
            case Sounds.ARMOR_EQUIP: return armorEquip();
            case Sounds.HEAL: return heal();
            case Sounds.ZONE_ALERT: return zoneAlert();
            case Sounds.CHOP: return chop();
            case Sounds.MINE: return mine();
            case Sounds.ZOMBIE_ATTACK: return zombieAttack();
            case Sounds.ZOMBIE_DEATH: return zombieDeath();
            case Sounds.EAT: return eat();
            case Sounds.CRAFT: return craft();
            case Sounds.BUILD: return build_();
            case Sounds.DOOR: return door();
            case Sounds.SEARCH: return search();
            case Sounds.FISH_CAST: return fishCast();
            case Sounds.FISH_BITE: return fishBite();
            case Sounds.FISH_CATCH: return fishCatch();
            case Sounds.DIG: return dig();
            case Sounds.PLANT: return plant();
            case Sounds.HARVEST: return harvest();
            case Sounds.ENGINE_START: return engineStart();
            case Sounds.ENGINE_FAIL: return engineFail();
            case Sounds.ENGINE_LOOP: return engineLoop();
            case Sounds.CAR_HIT: return carHit();
            case Sounds.REPAIR: return repair();
            case Sounds.SPLASH: return splash();
            case Sounds.BREAK: return breakDown();
            case Sounds.WEAPON_SWITCH: return weaponSwitch();
            case Sounds.BODY_THUD: return bodyThud();
            case Sounds.FLESH_SLASH: return fleshSlash();
            default: return new float[1];
        }
    }

    // ------------------------------------------------------------------ shared pieces

    /** A copy of {@code dry} through a dark room: low-passed and echoed, mixed back under the dry signal. */
    private static void room(float[] b, float cutoffHz, float delay, float gain, int taps, float wet) {
        float[] w = b.clone();
        Synth.lowPass(w, cutoffHz);
        Synth.echo(w, delay, gain, taps);
        for (int i = 0; i < b.length; i++) b[i] += w[i] * wet;
    }

    /** Biquad band-pass (constant 0 dB peak gain): the resonance of a mouth, a tube or a body of wood. */
    private static float[] resonate(float[] x, float freq, float q) {
        double w0 = 2.0 * Math.PI * freq / Synth.RATE;
        double alpha = Math.sin(w0) / (2.0 * q);
        double a0 = 1.0 + alpha;
        double b0 = alpha / a0, b2 = -alpha / a0;
        double a1 = -2.0 * Math.cos(w0) / a0, a2 = (1.0 - alpha) / a0;
        float[] y = new float[x.length];
        double x1 = 0, x2 = 0, y1 = 0, y2 = 0;
        for (int i = 0; i < x.length; i++) {
            double xi = x[i];
            double yi = b0 * xi + b2 * x2 - a1 * y1 - a2 * y2;
            x2 = x1;
            x1 = xi;
            y2 = y1;
            y1 = yi;
            y[i] = (float) yi;
        }
        return y;
    }

    /** A handful of quickly damped sine modes: the body note of a knocked piece of metal, wood or plastic. */
    private static void modes(float[] b, float t0, float amp, float[] freq, float[] tau, float[] gain) {
        int s0 = (int) (t0 * Synth.RATE);
        for (int k = 0; k < freq.length; k++) {
            int len = Math.min(b.length - s0, (int) (tau[k] * 7f * Synth.RATE));
            double w = 2.0 * Math.PI * freq[k] / Synth.RATE;
            for (int i = 0; i < len; i++) {
                float env = (float) Math.exp(-i / (tau[k] * Synth.RATE));
                b[s0 + i] += amp * gain[k] * env * (float) Math.sin(w * i);
            }
        }
    }

    /** A hard metal-on-metal tap: a sharp noise transient, a damped body note (no ringing) and a short low knock. */
    private static void clack(float[] b, Synth.Noise n, float t0, float amp, float bodyHz, float hardness) {
        Synth.addNoise(b, n, t0, 0.0018f + 0.0025f * (1f - hardness), amp, 1800f, 9500f);
        modes(b, t0, amp * 0.55f, new float[] {bodyHz, bodyHz * 2.31f, bodyHz * 3.87f},
                new float[] {0.011f, 0.007f, 0.004f}, new float[] {1f, 0.5f, 0.28f});
        Synth.addThunk(b, n, t0, amp * 0.33f, 170f, 0.012f);
    }

    /** A softer impact of heavy parts or polymer (a magazine seating, a stock settling): a dull knock with a short rattle. */
    private static void knock(float[] b, Synth.Noise n, float t0, float amp, float hz) {
        Synth.addNoise(b, n, t0, 0.006f, amp * 0.7f, 500f, 4500f);
        Synth.addThunk(b, n, t0, amp, hz, 0.030f);
        modes(b, t0, amp * 0.28f, new float[] {hz * 4.2f, hz * 7.1f}, new float[] {0.008f, 0.005f}, new float[] {1f, 0.6f});
    }

    /** A part sliding on another: a band of friction noise that moves from {@code f0} to {@code f1}. */
    private static void slide(float[] b, Synth.Noise n, float t0, float dur, float amp, float f0, float f1) {
        Synth.addScrape(b, n, t0, dur, amp, f0, f1);
    }

    private static float[] finish(float[] b, float peak) {
        Synth.normalize(b, peak);
        Synth.fadeOut(b, 0.006f);
        return b;
    }

    // ------------------------------------------------------------------ firearms: one family, one identity each

    /*
     * The recipe of the assault rifle, in numbers. Order: length, crack duration, crack level, crack low and high
     * band edge, thump duration, thump level, thump start and end pitch, thump dive rate, body delay, body duration,
     * body level, body band low and high, snap pitch, snap level, saturation drive, room cut-off, room delay,
     * room gain, room taps, room wet level, peak.
     */
    private static final float[] SPEC_RIFLE  = {0.34f, 0.020f, 1.00f, 800f, 7000f, 0.070f, 0.95f, 240f, 75f, 36f, 0.006f, 0.090f, 0.33f, 150f, 1500f, 1650f, 0.18f, 2.2f, 1800f, 0.110f, 0.32f, 2, 0.45f, 0.92f};
    private static final float[] SPEC_PISTOL = {0.20f, 0.011f, 1.00f, 1100f, 8000f, 0.040f, 0.90f, 330f, 105f, 28f, 0.004f, 0.050f, 0.34f, 220f, 2200f, 2100f, 0.18f, 2.0f, 2600f, 0.070f, 0.30f, 2, 0.38f, 0.90f};
    private static final float[] SPEC_SMG    = {0.11f, 0.008f, 1.00f, 1500f, 9000f, 0.030f, 0.85f, 260f, 95f, 26f, 0.003f, 0.040f, 0.30f, 220f, 2000f, 1900f, 0.16f, 2.1f, 2400f, 0.050f, 0.22f, 1, 0.25f, 0.85f};
    private static final float[] SPEC_SHOTGUN= {0.70f, 0.035f, 1.00f, 400f, 5500f, 0.160f, 1.00f, 150f, 42f, 18f, 0.004f, 0.220f, 0.55f, 90f, 1100f, 0f, 0f, 2.8f, 1500f, 0.090f, 0.42f, 3, 0.55f, 0.95f};
    private static final float[] SPEC_SNIPER = {1.25f, 0.012f, 1.10f, 1400f, 9000f, 0.130f, 1.00f, 185f, 50f, 20f, 0.003f, 0.110f, 0.35f, 120f, 1400f, 2400f, 0.22f, 2.0f, 2000f, 0.200f, 0.50f, 5, 0.75f, 0.95f};
    private static final float[] SPEC_MAGNUM = {0.85f, 0.016f, 1.00f, 700f, 6500f, 0.120f, 1.05f, 200f, 58f, 24f, 0.004f, 0.120f, 0.38f, 110f, 1300f, 1500f, 0.15f, 2.3f, 1900f, 0.130f, 0.40f, 3, 0.58f, 0.93f};
    private static final float[] SPEC_LMG    = {0.40f, 0.022f, 1.00f, 600f, 5500f, 0.090f, 1.00f, 160f, 58f, 26f, 0.006f, 0.110f, 0.36f, 110f, 1200f, 1500f, 0.12f, 2.4f, 1700f, 0.120f, 0.30f, 2, 0.40f, 0.90f};
    private static final float[] SPEC_REVOLVER = {0.55f, 0.014f, 1.00f, 800f, 7000f, 0.090f, 0.95f, 235f, 72f, 30f, 0.005f, 0.080f, 0.34f, 180f, 1700f, 1800f, 0.16f, 2.3f, 2000f, 0.120f, 0.34f, 3, 0.50f, 0.92f};
    private static final float[] SPEC_DOUBLE = {0.65f, 0.030f, 1.00f, 450f, 5800f, 0.140f, 1.00f, 165f, 48f, 20f, 0.004f, 0.200f, 0.52f, 100f, 1200f, 0f, 0f, 2.7f, 1600f, 0.085f, 0.40f, 3, 0.52f, 0.94f};
    private static final float[] SPEC_HUNTING = {1.00f, 0.013f, 1.10f, 1300f, 8500f, 0.110f, 1.00f, 195f, 56f, 22f, 0.003f, 0.100f, 0.34f, 130f, 1500f, 2200f, 0.20f, 2.0f, 2100f, 0.170f, 0.46f, 4, 0.70f, 0.94f};
    private static final float[] SPEC_AK     = {0.36f, 0.021f, 1.00f, 600f, 6300f, 0.075f, 0.98f, 215f, 66f, 32f, 0.006f, 0.100f, 0.36f, 130f, 1300f, 1450f, 0.20f, 2.5f, 1800f, 0.110f, 0.32f, 2, 0.45f, 0.92f};
    private static final float[] SPEC_DMR    = {0.60f, 0.016f, 1.00f, 1000f, 7500f, 0.090f, 1.00f, 210f, 68f, 26f, 0.004f, 0.090f, 0.34f, 140f, 1500f, 1900f, 0.20f, 2.2f, 1900f, 0.140f, 0.40f, 3, 0.60f, 0.93f};
    private static final float[] SPEC_MPISTOL= {0.10f, 0.007f, 1.00f, 1800f, 10000f, 0.026f, 0.80f, 300f, 110f, 22f, 0.002f, 0.030f, 0.30f, 250f, 2300f, 2300f, 0.15f, 2.0f, 2800f, 0.040f, 0.20f, 1, 0.22f, 0.82f};

    private static float[] shot(int seed, float[] k) {
        float[] b = Synth.buffer(k[0]);
        Synth.Noise n = new Synth.Noise(seed);
        Synth.addNoise(b, n, 0f, k[1], k[2], k[3], k[4]);                  // the crack
        Synth.addSweep(b, 0f, k[5], k[6], k[7], k[8], k[9]);               // the thump that dives
        Synth.addNoise(b, n, k[10], k[11], k[12], k[13], k[14]);           // the mid-range body
        if (k[16] > 0f) Synth.addTone(b, 0.001f, 0f, 0.028f, k[16], k[15], 0f);   // the faint supersonic snap
        Synth.saturate(b, k[17]);
        room(b, k[18], k[19], k[20], (int) k[21], k[22]);
        return finish(b, k[23]);
    }

    private static float[] gun(int id) {
        switch (id) {
            case WeaponDef.PISTOL: return shot(11, SPEC_PISTOL);
            case WeaponDef.RIFLE: return rifle();
            case WeaponDef.SHOTGUN: return shot(37, SPEC_SHOTGUN);
            case WeaponDef.SMG: return shot(41, SPEC_SMG);
            case WeaponDef.SNIPER: return shot(53, SPEC_SNIPER);
            case WeaponDef.MAGNUM: return shot(67, SPEC_MAGNUM);
            case WeaponDef.PLASMA: return plasma();
            case WeaponDef.LMG: return shot(97, SPEC_LMG);
            case WeaponDef.REVOLVER: return shot(151, SPEC_REVOLVER);
            case WeaponDef.DOUBLE_BARREL: return shot(157, SPEC_DOUBLE);
            case WeaponDef.HUNTING_RIFLE: return shot(163, SPEC_HUNTING);
            case WeaponDef.AK: return shot(167, SPEC_AK);
            case WeaponDef.DMR: return shot(173, SPEC_DMR);
            case WeaponDef.MACHINE_PISTOL: return shot(179, SPEC_MPISTOL);
            default: return shot(11, SPEC_PISTOL);
        }
    }

    /** Assault rifle: a punchy mid-range crack with a quick "thump", a supersonic snap and a short echo. Unchanged. */
    private static float[] rifle() {
        return shot(23, SPEC_RIFLE);
    }

    /**
     * Plasma rifle: the rifle's punch (crack, thump, body) with an electric zap on top, so it still sounds like an energy
     * weapon but hits as hard as the rest of the cabinet. Short, so it stays clean at eleven shots a second.
     */
    private static float[] plasma() {
        float[] b = Synth.buffer(0.30f);
        Synth.Noise n = new Synth.Noise(79);
        Synth.addNoise(b, n, 0f, 0.012f, 0.8f, 1200f, 8000f);
        Synth.addSweep(b, 0f, 0.060f, 0.85f, 260f, 80f, 38f);
        Synth.addNoise(b, n, 0.004f, 0.060f, 0.28f, 200f, 1600f);
        Synth.addZap(b, 0f, 0.075f, 0.70f, 3300f, 260f, 26f, 137f, 0.8f);
        Synth.addZap(b, 0.002f, 0.055f, 0.32f, 4700f, 640f, 30f, 211f, 0.7f);
        Synth.addCrackle(b, n, 0f, 0.20f, 0.010f, 0.060f, 0.55f, 2500f);
        Synth.addBuzz(b, 0.02f, 0.22f, 0.12f, 96f, 38f, 0.08f);
        Synth.saturate(b, 2.0f);
        room(b, 2200f, 0.07f, 0.28f, 2, 0.30f);
        return finish(b, 0.88f);
    }

    // ------------------------------------------------------------------ reloads: three little stories per gun

    /** Reload sound {@code stage} (0 it starts, 1 the ammunition goes in, 2 it is ready) of gun {@code gun}. */
    private static float[] reload(int gun, int stage) {
        Synth.Noise n = new Synth.Noise(300 + gun * 7 + stage);
        float[] b;
        switch (gun) {
            case WeaponDef.SHOTGUN:
            case WeaponDef.DOUBLE_BARREL:
                return shellReload(gun, stage, n);
            case WeaponDef.REVOLVER:
                return revolverReload(stage, n);
            case WeaponDef.PLASMA:
                return plasmaReload(stage, n);
            case WeaponDef.LMG:
                return lmgReload(stage, n);
            case WeaponDef.SNIPER:
            case WeaponDef.HUNTING_RIFLE:
                return boltReload(gun, stage, n);
            default:
                break;
        }
        // magazine guns: pitch and weight of the parts differ with the size of the gun
        float weight = 1f;       // 1 = rifle
        switch (gun) {
            case WeaponDef.PISTOL: weight = 0.70f; break;
            case WeaponDef.MACHINE_PISTOL: weight = 0.72f; break;
            case WeaponDef.SMG: weight = 0.82f; break;
            case WeaponDef.MAGNUM: weight = 0.90f; break;
            case WeaponDef.AK: weight = 1.12f; break;
            case WeaponDef.DMR: weight = 1.05f; break;
            default: break;
        }
        float hz = 2400f * (1.12f - 0.12f * weight);       // lighter guns click higher
        float body = 140f * weight;
        switch (stage) {
            case 0:     // magazine release and the magazine sliding out
                b = Synth.buffer(0.26f);
                clack(b, n, 0f, 0.55f, hz, 0.9f);
                slide(b, n, 0.035f, 0.075f * weight, 0.42f, 1700f, 800f);
                knock(b, n, 0.125f * weight + 0.02f, 0.16f, body * 1.1f);
                return finish(b, 0.72f);
            case 1:     // the fresh magazine slides in and seats
                b = Synth.buffer(0.22f);
                slide(b, n, 0f, 0.05f, 0.40f, 700f, 1900f);
                knock(b, n, 0.052f, 0.95f, body);
                clack(b, n, 0.056f, 0.45f, hz * 0.8f, 0.7f);
                return finish(b, 0.80f);
            default:    // charging handle or slide: back, then forward onto the round
                b = Synth.buffer(0.30f);
                slide(b, n, 0f, 0.07f, 0.45f, 1100f, 2600f);
                clack(b, n, 0.075f, 0.50f, hz * 0.7f, 0.8f);
                slide(b, n, 0.110f, 0.06f, 0.35f, 2400f, 1000f);
                clack(b, n, 0.172f, 0.95f, hz * 0.85f, 1f);
                knock(b, n, 0.174f, 0.35f, body * 1.3f);
                return finish(b, 0.82f);
        }
    }

    /** Pump or break-action shotguns: the action opens, a shell drops in, the action closes. */
    private static float[] shellReload(int gun, int stage, Synth.Noise n) {
        boolean pump = gun == WeaponDef.SHOTGUN;
        float[] b;
        switch (stage) {
            case 0:
                b = Synth.buffer(0.24f);
                if (pump) {
                    slide(b, n, 0f, 0.07f, 0.45f, 900f, 2000f);
                    clack(b, n, 0.075f, 0.65f, 1500f, 0.85f);
                } else {
                    clack(b, n, 0f, 0.80f, 1300f, 0.9f);               // the lever
                    slide(b, n, 0.03f, 0.08f, 0.40f, 1000f, 1800f);    // the barrels drop open
                    knock(b, n, 0.12f, 0.45f, 120f);
                }
                return finish(b, 0.75f);
            case 1:     // a shell goes in: plastic tick, brass tink-less "chk" and the push of the spring
                b = Synth.buffer(0.14f);
                Synth.addNoise(b, n, 0f, 0.004f, 0.6f, 2500f, 8000f);
                modes(b, 0f, 0.45f, new float[] {1900f, 3300f}, new float[] {0.006f, 0.004f}, new float[] {1f, 0.5f});
                knock(b, n, 0.012f, 0.55f, 210f);
                slide(b, n, 0.03f, 0.03f, 0.18f, 1300f, 900f);
                return finish(b, 0.68f);
            default:
                b = Synth.buffer(0.30f);
                if (pump) {
                    slide(b, n, 0f, 0.06f, 0.40f, 900f, 2200f);
                    clack(b, n, 0.064f, 0.70f, 1400f, 0.9f);
                    clack(b, n, 0.120f, 0.95f, 1750f, 1f);
                    knock(b, n, 0.122f, 0.40f, 150f);
                } else {
                    slide(b, n, 0f, 0.06f, 0.40f, 1800f, 900f);        // the barrels swing up
                    clack(b, n, 0.065f, 1.0f, 1500f, 1f);
                    knock(b, n, 0.067f, 0.45f, 130f);
                }
                return finish(b, 0.82f);
        }
    }

    private static float[] revolverReload(int stage, Synth.Noise n) {
        float[] b;
        switch (stage) {
            case 0:     // the cylinder swings out
                b = Synth.buffer(0.22f);
                clack(b, n, 0f, 0.55f, 2100f, 0.9f);
                slide(b, n, 0.02f, 0.06f, 0.35f, 1200f, 2400f);
                clack(b, n, 0.085f, 0.45f, 1500f, 0.7f);
                return finish(b, 0.70f);
            case 1:     // a round drops into a chamber
                b = Synth.buffer(0.12f);
                Synth.addNoise(b, n, 0f, 0.004f, 0.5f, 2200f, 7500f);
                modes(b, 0f, 0.40f, new float[] {2300f, 3500f}, new float[] {0.006f, 0.004f}, new float[] {1f, 0.45f});
                knock(b, n, 0.010f, 0.40f, 240f);
                return finish(b, 0.60f);
            default:    // the cylinder closes and spins a click or two
                b = Synth.buffer(0.26f);
                slide(b, n, 0f, 0.04f, 0.30f, 2200f, 1100f);
                clack(b, n, 0.045f, 0.95f, 1700f, 1f);
                Synth.addRatchet(b, n, 0.08f, 3, 0.022f, 1f, 0.28f, 2600f);
                return finish(b, 0.78f);
        }
    }

    private static float[] boltReload(int gun, int stage, Synth.Noise n) {
        float[] b;
        float hz = gun == WeaponDef.SNIPER ? 1500f : 1700f;
        switch (stage) {
            case 0:     // magazine out
                b = Synth.buffer(0.26f);
                clack(b, n, 0f, 0.55f, 2000f, 0.9f);
                slide(b, n, 0.035f, 0.08f, 0.40f, 1600f, 800f);
                knock(b, n, 0.13f, 0.18f, 150f);
                return finish(b, 0.72f);
            case 1:     // magazine in
                b = Synth.buffer(0.22f);
                slide(b, n, 0f, 0.05f, 0.40f, 700f, 1800f);
                knock(b, n, 0.052f, 1.0f, 130f);
                clack(b, n, 0.056f, 0.45f, hz * 0.8f, 0.7f);
                return finish(b, 0.80f);
            default:    // the bolt: lift, pull back, push forward, push down - four distinct moves
                b = Synth.buffer(0.46f);
                clack(b, n, 0f, 0.55f, hz, 0.8f);
                slide(b, n, 0.03f, 0.08f, 0.45f, 1200f, 2200f);
                clack(b, n, 0.115f, 0.60f, hz * 0.9f, 0.9f);
                slide(b, n, 0.19f, 0.07f, 0.40f, 2200f, 1100f);
                clack(b, n, 0.265f, 0.80f, hz * 0.95f, 1f);
                clack(b, n, 0.335f, 0.95f, hz * 0.8f, 1f);
                knock(b, n, 0.337f, 0.40f, 140f);
                return finish(b, 0.84f);
        }
    }

    /** Light machine gun: the feed cover opens, the belt drops on, the cover slams shut. */
    private static float[] lmgReload(int stage, Synth.Noise n) {
        float[] b;
        switch (stage) {
            case 0:
                b = Synth.buffer(0.30f);
                clack(b, n, 0f, 0.80f, 900f, 0.9f);
                knock(b, n, 0.004f, 0.55f, 105f);
                slide(b, n, 0.05f, 0.12f, 0.35f, 900f, 400f);
                return finish(b, 0.78f);
            case 1:     // the belt: a rattle of loose links and a heavy settle
                b = Synth.buffer(0.34f);
                slide(b, n, 0f, 0.07f, 0.35f, 800f, 1800f);
                Synth.addRatchet(b, n, 0.06f, 6, 0.016f, 0.94f, 0.30f, 2200f);
                knock(b, n, 0.17f, 1.0f, 100f);
                clack(b, n, 0.175f, 0.50f, 1100f, 0.7f);
                return finish(b, 0.82f);
            default:
                b = Synth.buffer(0.32f);
                slide(b, n, 0f, 0.06f, 0.35f, 1500f, 700f);
                clack(b, n, 0.065f, 1.0f, 950f, 1f);
                knock(b, n, 0.067f, 0.70f, 95f);
                clack(b, n, 0.12f, 0.50f, 1700f, 0.9f);     // the cocking handle
                return finish(b, 0.86f);
        }
    }

    /** Plasma rifle: the cell is ejected with a hiss, the new one clunks in and powers up, a short ready chirp. */
    private static float[] plasmaReload(int stage, Synth.Noise n) {
        float[] b;
        switch (stage) {
            case 0:
                b = Synth.buffer(0.28f);
                clack(b, n, 0f, 0.55f, 2200f, 0.9f);
                Synth.addHiss(b, n, 0.02f, 0.12f, 0.45f, 2500f);
                slide(b, n, 0.04f, 0.10f, 0.30f, 1800f, 900f);
                return finish(b, 0.72f);
            case 1:
                b = Synth.buffer(0.34f);
                slide(b, n, 0f, 0.05f, 0.35f, 700f, 1700f);
                knock(b, n, 0.052f, 0.95f, 130f);
                Synth.addSweep(b, 0.06f, 0.18f, 0.35f, 420f, 1900f, 6f);
                Synth.addNoise(b, n, 0.06f, 0.10f, 0.12f, 3000f, 9000f);
                return finish(b, 0.78f);
            default:
                b = Synth.buffer(0.26f);
                clack(b, n, 0f, 0.70f, 1700f, 0.9f);
                Synth.addTone(b, 0.05f, 0.004f, 0.06f, 0.45f, 1500f, 0.05f);
                Synth.addTone(b, 0.11f, 0.004f, 0.08f, 0.45f, 2250f, 0.05f);
                return finish(b, 0.74f);
        }
    }

    // ------------------------------------------------------------------ action sounds (pump, bolt, hammer)

    private static float[] action(int gun) {
        Synth.Noise n = new Synth.Noise(500 + gun);
        float[] b;
        switch (gun) {
            case WeaponDef.SHOTGUN:      // pump back and forward
                b = Synth.buffer(0.30f);
                slide(b, n, 0f, 0.06f, 0.42f, 900f, 2200f);
                clack(b, n, 0.064f, 0.75f, 1400f, 0.9f);
                slide(b, n, 0.10f, 0.05f, 0.35f, 2200f, 900f);
                clack(b, n, 0.15f, 1.0f, 1750f, 1f);
                knock(b, n, 0.152f, 0.40f, 150f);
                return finish(b, 0.80f);
            case WeaponDef.SNIPER:
            case WeaponDef.HUNTING_RIFLE:  // the bolt works the next round in
                b = Synth.buffer(0.46f);
                float hz = gun == WeaponDef.SNIPER ? 1500f : 1700f;
                clack(b, n, 0f, 0.55f, hz, 0.8f);
                slide(b, n, 0.03f, 0.08f, 0.45f, 1200f, 2200f);
                clack(b, n, 0.115f, 0.60f, hz * 0.9f, 0.9f);
                slide(b, n, 0.19f, 0.07f, 0.40f, 2200f, 1100f);
                clack(b, n, 0.265f, 0.80f, hz * 0.95f, 1f);
                clack(b, n, 0.335f, 0.95f, hz * 0.8f, 1f);
                return finish(b, 0.80f);
            case WeaponDef.MAGNUM:
            case WeaponDef.REVOLVER:       // hammer cocked, the cylinder clicks round
                b = Synth.buffer(0.22f);
                clack(b, n, 0f, 0.80f, 2000f, 1f);
                Synth.addRatchet(b, n, 0.006f, 3, 0.022f, 1f, 0.45f, 2600f);
                knock(b, n, 0.07f, 0.35f, 160f);
                return finish(b, 0.75f);
            case WeaponDef.DOUBLE_BARREL:  // the second barrel's hammer
                b = Synth.buffer(0.14f);
                clack(b, n, 0f, 0.85f, 1500f, 1f);
                knock(b, n, 0.004f, 0.30f, 140f);
                return finish(b, 0.70f);
            default:
                return new float[1];
        }
    }

    // ------------------------------------------------------------------ melee

    /** The whoosh of a melee swing; edged weapons have a thin metallic hiss in it. */
    private static float[] swing(int id) {
        Synth.Noise n = new Synth.Noise(700 + id);
        float dur, f0, f1, q, amp, thump, edge;
        switch (id) {
            case WeaponDef.KNIFE:   dur = 0.16f; f0 = 1800f; f1 = 5200f; q = 1.8f; amp = 0.80f; thump = 0f;    edge = 5200f; break;
            case WeaponDef.BAT:     dur = 0.30f; f0 = 380f;  f1 = 1700f; q = 1.2f; amp = 1.00f; thump = 0.30f; edge = 0f;    break;
            case WeaponDef.CROWBAR: dur = 0.26f; f0 = 600f;  f1 = 2400f; q = 1.4f; amp = 0.95f; thump = 0.25f; edge = 0f;    break;
            case WeaponDef.MACHETE: dur = 0.22f; f0 = 1200f; f1 = 4800f; q = 1.6f; amp = 0.90f; thump = 0.12f; edge = 4300f; break;
            case WeaponDef.AXE:     dur = 0.34f; f0 = 300f;  f1 = 1500f; q = 1.1f; amp = 1.00f; thump = 0.45f; edge = 3000f; break;
            case WeaponDef.FISTS:   dur = 0.14f; f0 = 500f;  f1 = 1600f; q = 1.0f; amp = 0.55f; thump = 0f;    edge = 0f;    break;
            default:                dur = 0.32f; f0 = 340f;  f1 = 1700f; q = 1.1f; amp = 1.00f; thump = 0.40f; edge = 0f;    break;
        }
        float[] b = Synth.buffer(dur + 0.06f);
        Synth.addWhoosh(b, n, 0f, dur, amp, f0, f1, q, dur * 0.35f);
        Synth.addWhoosh(b, n, dur * 0.25f, dur * 0.6f, amp * 0.35f, f1 * 1.4f, f0 * 1.2f, q * 1.4f, 0.02f);
        if (thump > 0f) Synth.addSweep(b, dur * 0.45f, 0.06f, thump, 140f, 70f, 30f);
        if (edge > 0f) modes(b, dur * 0.40f, 0.10f, new float[] {edge, edge * 1.51f}, new float[] {0.030f, 0.020f}, new float[] {1f, 0.5f});
        return finish(b, 0.80f);
    }

    /** A blow landing on a body: a dull, meaty thwack with a thump behind it. */
    private static float[] meleeHit() {
        float[] b = Synth.buffer(0.20f);
        Synth.Noise n = new Synth.Noise(811);
        Synth.addNoise(b, n, 0f, 0.020f, 1.0f, 250f, 2400f);
        Synth.addSweep(b, 0f, 0.060f, 0.95f, 170f, 55f, 34f);
        modes(b, 0f, 0.28f, new float[] {380f, 760f}, new float[] {0.018f, 0.010f}, new float[] {1f, 0.5f});
        Synth.addNoise(b, n, 0f, 0.004f, 0.55f, 2000f, 7000f);
        Synth.saturate(b, 1.8f);
        return finish(b, 0.88f);
    }

    /** Taking out the other gun: cloth against the vest, a strap, and a short metallic clack as it comes up. */
    private static float[] weaponSwitch() {
        float[] b = Synth.buffer(0.30f);
        Synth.Noise n = new Synth.Noise(1201);
        Synth.addNoise(b, n, 0f, 0.060f, 0.35f, 900f, 4200f);               // cloth and strap
        Synth.addClick(b, n, 0.115f, 0.9f, 2600f, 0.006f);                   // the catch
        Synth.addThunk(b, n, 0.125f, 0.6f, 190f, 0.030f);
        Synth.addRing(b, 0.130f, 0.28f, 1850f, 0.040f);
        Synth.addClick(b, n, 0.205f, 0.7f, 3200f, 0.005f);                   // the second click as it seats
        Synth.addThunk(b, n, 0.210f, 0.45f, 240f, 0.022f);
        return finish(b, 0.72f);
    }

    /** A body hitting the ground: a low, soft thump and the rustle of clothes. */
    private static float[] bodyThud() {
        float[] b = Synth.buffer(0.42f);
        Synth.Noise n = new Synth.Noise(1203);
        Synth.addSweep(b, 0f, 0.090f, 1.0f, 120f, 44f, 30f);
        Synth.addNoise(b, n, 0f, 0.030f, 0.75f, 80f, 900f);
        Synth.addNoise(b, n, 0.020f, 0.110f, 0.30f, 500f, 2600f);            // cloth
        Synth.addThunk(b, n, 0.060f, 0.35f, 90f, 0.050f);                    // the second settle
        Synth.saturate(b, 1.4f);
        return finish(b, 0.85f);
    }

    /** A blade cutting into flesh: a quick slice of noise and a wet little pop underneath. */
    private static float[] fleshSlash() {
        float[] b = Synth.buffer(0.22f);
        Synth.Noise n = new Synth.Noise(1205);
        Synth.addWhoosh(b, n, 0f, 0.060f, 0.55f, 5200f, 1800f, 1.2f, 0.01f);
        Synth.addNoise(b, n, 0.020f, 0.028f, 0.8f, 900f, 4200f);
        Synth.addSweep(b, 0.025f, 0.050f, 0.55f, 240f, 90f, 40f);
        Synth.addNoise(b, n, 0.045f, 0.020f, 0.4f, 200f, 1200f);
        Synth.saturate(b, 1.5f);
        return finish(b, 0.8f);
    }

    /** A bullet landing on a player: a short meaty "thwap", not a zap. */
    private static float[] hit() {
        float[] b = Synth.buffer(0.16f);
        Synth.Noise n = new Synth.Noise(107);
        Synth.addNoise(b, n, 0f, 0.012f, 0.9f, 400f, 3500f);
        Synth.addSweep(b, 0f, 0.040f, 0.80f, 210f, 70f, 40f);
        Synth.addNoise(b, n, 0f, 0.003f, 0.5f, 2500f, 8000f);
        modes(b, 0f, 0.20f, new float[] {520f}, new float[] {0.012f}, new float[] {1f});
        Synth.saturate(b, 1.7f);
        return finish(b, 0.82f);
    }

    /** The local player is hit: a heavy thump, a short grunt and a body of noise. */
    private static float[] hurt() {
        float[] b = Synth.buffer(0.36f);
        Synth.Noise n = new Synth.Noise(109);
        Synth.addSweep(b, 0f, 0.090f, 0.95f, 150f, 48f, 24f);
        Synth.addNoise(b, n, 0f, 0.030f, 0.8f, 200f, 2600f);
        float[] g = voice(113, 150f, 105f, 0.26f, 0.6f, 560f, 1050f, 2500f);
        for (int i = 0; i < g.length && i < b.length; i++) b[i] += g[i] * 0.75f;
        Synth.saturate(b, 1.9f);
        return finish(b, 0.9f);
    }

    private static float[] death() {
        float[] b = Synth.buffer(1.0f);
        Synth.Noise n = new Synth.Noise(151);
        float[] g = voice(151, 140f, 55f, 0.75f, 0.7f, 480f, 820f, 2300f);
        for (int i = 0; i < g.length && i < b.length; i++) b[i] += g[i] * 0.8f;
        Synth.addSweep(b, 0.42f, 0.14f, 0.85f, 110f, 38f, 20f);
        Synth.addNoise(b, n, 0.42f, 0.04f, 0.45f, 200f, 2200f);
        Synth.addScrape(b, n, 0.38f, 0.10f, 0.15f, 800f, 300f);
        Synth.saturate(b, 1.7f);
        return finish(b, 0.85f);
    }

    /** A vest stopping a bullet: a dull plate "tunk" and the rattle of the straps. */
    private static float[] armorHit() {
        float[] b = Synth.buffer(0.18f);
        Synth.Noise n = new Synth.Noise(821);
        Synth.addThunk(b, n, 0f, 0.95f, 125f, 0.030f);
        clack(b, n, 0.001f, 0.70f, 1100f, 0.7f);
        Synth.addNoise(b, n, 0.012f, 0.035f, 0.22f, 800f, 4000f);
        return finish(b, 0.82f);
    }

    /** Putting a vest on: velcro tearing open and closed, and a settling thump. */
    private static float[] armorEquip() {
        float[] b = Synth.buffer(0.42f);
        Synth.Noise n = new Synth.Noise(823);
        Synth.addRatchet(b, n, 0f, 9, 0.011f, 0.92f, 0.45f, 3200f);
        slide(b, n, 0.02f, 0.10f, 0.25f, 1500f, 4500f);
        knock(b, n, 0.18f, 0.80f, 95f);
        Synth.addRatchet(b, n, 0.23f, 6, 0.012f, 0.9f, 0.35f, 3000f);
        return finish(b, 0.76f);
    }

    /** Medicine: a soft tearing of tape and cloth and a gentle, warm two-note rise. */
    private static float[] heal() {
        float[] b = Synth.buffer(0.55f);
        Synth.Noise n = new Synth.Noise(827);
        slide(b, n, 0f, 0.12f, 0.30f, 2500f, 5500f);
        Synth.addTone(b, 0.10f, 0.02f, 0.14f, 0.40f, 523.25f, 0f);
        Synth.addTone(b, 0.19f, 0.02f, 0.22f, 0.45f, 783.99f, 0f);
        Synth.lowPass(b, 4200f);
        return finish(b, 0.70f);
    }

    /** The zone starts closing: a low two-tone warning, three times. */
    private static float[] zoneAlert() {
        float[] b = Synth.buffer(1.05f);
        for (int i = 0; i < 3; i++) {
            Synth.addTone(b, i * 0.34f, 0.01f, 0.13f, 0.75f, 466.16f, 0.45f);
            Synth.addTone(b, i * 0.34f + 0.15f, 0.01f, 0.15f, 0.75f, 349.23f, 0.45f);
        }
        Synth.lowPass(b, 2600f);
        return finish(b, 0.72f);
    }

    // ------------------------------------------------------------------ voices

    /**
     * A throaty voice: a pulse train that glides from {@code f0} to {@code f1} with a little vibrato, a breath of noise
     * and three formant resonances (the shape of the mouth), shaped by a swell and a fall.
     */
    private static float[] voice(int seed, float f0, float f1, float dur, float roughness, float form1, float form2, float form3) {
        float[] src = Synth.buffer(dur);
        Synth.Noise n = new Synth.Noise(seed);
        double phase = 0;
        for (int i = 0; i < src.length; i++) {
            float t = i / (float) Synth.RATE;
            float u = t / dur;
            float f = f0 + (f1 - f0) * u;
            f *= 1f + 0.03f * (float) Math.sin(2.0 * Math.PI * 5.3 * t) + 0.012f * n.next();
            phase += f / Synth.RATE;
            float saw = (float) (phase - Math.floor(phase)) * 2f - 1f;
            float am = 1f - roughness * 0.45f * (0.5f + 0.5f * (float) Math.sin(2.0 * Math.PI * 31.0 * t));
            float env = (float) Math.min(1.0, t / 0.05) * (float) Math.pow(Math.max(0.0, 1.0 - u), 0.6);
            src[i] = (saw * 0.8f + n.next() * (0.25f + 0.3f * roughness)) * am * env;
        }
        float[] a = resonate(src, form1, 5f);
        float[] c = resonate(src, form2, 7f);
        float[] d = resonate(src, form3, 8f);
        float[] low = src.clone();
        Synth.lowPass(low, 260f);
        float[] out = new float[src.length];
        for (int i = 0; i < out.length; i++) out[i] = a[i] * 1.1f + c[i] * 0.7f + d[i] * 0.3f + low[i] * 0.35f;
        Synth.saturate(out, 1.8f);
        return out;
    }

    /** One of three zombie groans: a long, low, rattling moan that sags in pitch. */
    private static float[] zombieGroan(int variant) {
        float[] g;
        switch (variant) {
            case 0:  g = voice(901, 104f, 68f, 1.15f, 0.55f, 470f, 880f, 2300f); break;
            case 1:  g = voice(907, 128f, 84f, 0.90f, 0.45f, 620f, 1150f, 2500f); break;
            default: g = voice(911, 92f, 58f, 1.40f, 0.80f, 420f, 760f, 2100f); break;
        }
        float[] b = Synth.buffer(g.length / (float) Synth.RATE + 0.05f);
        System.arraycopy(g, 0, b, 0, Math.min(g.length, b.length));
        Synth.lowPass(b, 3200f);
        return finish(b, 0.85f);
    }

    private static float[] zombieAttack() {
        float[] g = voice(921, 165f, 105f, 0.40f, 0.8f, 700f, 1300f, 2600f);
        float[] b = Synth.buffer(0.46f);
        Synth.Noise n = new Synth.Noise(922);
        for (int i = 0; i < g.length && i < b.length; i++) b[i] += g[i];
        Synth.addNoise(b, n, 0.16f, 0.030f, 0.6f, 300f, 3000f);
        Synth.addSweep(b, 0.16f, 0.05f, 0.5f, 160f, 60f, 35f);
        return finish(b, 0.88f);
    }

    private static float[] zombieDeath() {
        float[] g = voice(931, 118f, 42f, 0.85f, 0.7f, 460f, 800f, 2200f);
        float[] b = Synth.buffer(1.1f);
        Synth.Noise n = new Synth.Noise(932);
        for (int i = 0; i < g.length && i < b.length; i++) b[i] += g[i] * 0.9f;
        Synth.addSweep(b, 0.55f, 0.12f, 0.9f, 100f, 36f, 22f);
        Synth.addNoise(b, n, 0.55f, 0.04f, 0.5f, 200f, 2000f);
        return finish(b, 0.85f);
    }

    // ------------------------------------------------------------------ survival

    /** An axe biting into wood: a dull knock, a splintery crack and the hollow note of the trunk. */
    private static float[] chop() {
        float[] b = Synth.buffer(0.30f);
        Synth.Noise n = new Synth.Noise(941);
        Synth.addNoise(b, n, 0f, 0.008f, 0.9f, 1200f, 6500f);
        Synth.addSweep(b, 0f, 0.030f, 0.9f, 230f, 95f, 34f);
        modes(b, 0f, 0.50f, new float[] {310f, 640f, 1180f}, new float[] {0.045f, 0.028f, 0.015f}, new float[] {1f, 0.55f, 0.3f});
        Synth.addNoise(b, n, 0.012f, 0.040f, 0.25f, 400f, 2500f);
        Synth.saturate(b, 1.6f);
        return finish(b, 0.82f);
    }

    /** A pick striking stone: a sharp clink, a hard crack and a few flying chips. */
    private static float[] mine() {
        float[] b = Synth.buffer(0.34f);
        Synth.Noise n = new Synth.Noise(943);
        clack(b, n, 0f, 1.0f, 2600f, 1f);
        Synth.addNoise(b, n, 0f, 0.012f, 0.7f, 800f, 6000f);
        Synth.addThunk(b, n, 0f, 0.6f, 140f, 0.030f);
        modes(b, 0.002f, 0.18f, new float[] {3400f, 5200f}, new float[] {0.040f, 0.025f}, new float[] {1f, 0.5f});
        Synth.addClick(b, n, 0.08f, 0.30f, 3500f, 0.003f);
        Synth.addClick(b, n, 0.13f, 0.22f, 4200f, 0.003f);
        Synth.addClick(b, n, 0.19f, 0.15f, 3800f, 0.003f);
        return finish(b, 0.80f);
    }

    private static float[] eat() {
        float[] b = Synth.buffer(0.62f);
        Synth.Noise n = new Synth.Noise(947);
        float[] at = {0f, 0.11f, 0.19f, 0.32f, 0.41f};
        for (int i = 0; i < at.length; i++) {
            Synth.addNoise(b, n, at[i], 0.014f, 0.8f - 0.1f * i, 1200f, 5200f);
            Synth.addThunk(b, n, at[i], 0.25f, 190f, 0.020f);
        }
        return finish(b, 0.70f);
    }

    private static float[] craft() {
        float[] b = Synth.buffer(0.62f);
        Synth.Noise n = new Synth.Noise(949);
        float[] at = {0f, 0.17f, 0.34f};
        for (int i = 0; i < at.length; i++) {
            knock(b, n, at[i], 0.85f, 260f);
            clack(b, n, at[i] + 0.002f, 0.35f, 1900f + 150f * i, 0.8f);
        }
        slide(b, n, 0.48f, 0.08f, 0.2f, 1200f, 2600f);
        return finish(b, 0.78f);
    }

    /** Placing a wall, floor or door: a solid wooden thud and a short clack. */
    private static float[] build_() {
        float[] b = Synth.buffer(0.28f);
        Synth.Noise n = new Synth.Noise(951);
        knock(b, n, 0f, 1.0f, 150f);
        clack(b, n, 0.002f, 0.45f, 800f, 0.6f);
        Synth.addNoise(b, n, 0.01f, 0.05f, 0.25f, 300f, 2000f);
        return finish(b, 0.80f);
    }

    /** A door: the hinge creaks, the latch clacks. */
    private static float[] door() {
        float[] b = Synth.buffer(0.55f);
        Synth.Noise n = new Synth.Noise(953);
        float[] saw = Synth.buffer(0.40f);
        double ph = 0;
        for (int i = 0; i < saw.length; i++) {
            float t = i / (float) Synth.RATE;
            float f = 190f + 90f * (float) Math.sin(2.0 * Math.PI * 2.2 * t) + 40f * t / 0.4f;
            ph += f / Synth.RATE;
            float s = (float) (ph - Math.floor(ph)) * 2f - 1f;
            saw[i] = s * (float) Math.sin(Math.PI * Math.min(1f, t / 0.4f)) * (0.7f + 0.3f * n.next());
        }
        float[] cr = resonate(saw, 820f, 6f);
        for (int i = 0; i < cr.length && i < b.length; i++) b[i] += cr[i] * 0.8f;
        clack(b, n, 0.40f, 0.85f, 900f, 0.7f);
        knock(b, n, 0.402f, 0.5f, 120f);
        return finish(b, 0.76f);
    }

    /** Rummaging through a cupboard: scrapes, rattles and a couple of clinks. */
    private static float[] search() {
        float[] b = Synth.buffer(0.95f);
        Synth.Noise n = new Synth.Noise(955);
        slide(b, n, 0f, 0.14f, 0.40f, 700f, 2200f);
        knock(b, n, 0.16f, 0.45f, 180f);
        slide(b, n, 0.26f, 0.12f, 0.35f, 2000f, 800f);
        clack(b, n, 0.42f, 0.35f, 2100f, 0.7f);
        Synth.addRatchet(b, n, 0.48f, 5, 0.020f, 0.9f, 0.25f, 2600f);
        slide(b, n, 0.62f, 0.14f, 0.35f, 900f, 2400f);
        knock(b, n, 0.80f, 0.40f, 150f);
        return finish(b, 0.68f);
    }

    private static float[] fishCast() {
        float[] b = Synth.buffer(0.70f);
        Synth.Noise n = new Synth.Noise(957);
        Synth.addWhoosh(b, n, 0f, 0.16f, 0.7f, 600f, 3200f, 1.4f, 0.05f);
        splashAt(b, n, 0.30f, 0.9f);
        return finish(b, 0.76f);
    }

    private static void splashAt(float[] b, Synth.Noise n, float t0, float amp) {
        Synth.addNoise(b, n, t0, 0.060f, amp, 300f, 3500f);
        Synth.addSweep(b, t0, 0.050f, amp * 0.55f, 260f, 950f, 22f);
        Synth.addNoise(b, n, t0 + 0.02f, 0.030f, amp * 0.3f, 1500f, 6000f);
        Synth.addSweep(b, t0 + 0.07f, 0.035f, amp * 0.30f, 380f, 1200f, 28f);
    }

    private static float[] fishBite() {
        float[] b = Synth.buffer(0.34f);
        Synth.Noise n = new Synth.Noise(959);
        splashAt(b, n, 0f, 0.55f);
        splashAt(b, n, 0.13f, 0.40f);
        Synth.addTone(b, 0.20f, 0.004f, 0.08f, 0.35f, 1568f, 0f);
        return finish(b, 0.72f);
    }

    private static float[] fishCatch() {
        float[] b = Synth.buffer(0.80f);
        Synth.Noise n = new Synth.Noise(961);
        splashAt(b, n, 0f, 1.0f);
        Synth.addNoise(b, n, 0.12f, 0.060f, 0.35f, 600f, 3500f);
        Synth.addNoise(b, n, 0.22f, 0.050f, 0.30f, 600f, 3500f);
        Synth.addNoise(b, n, 0.33f, 0.040f, 0.22f, 600f, 3500f);
        Synth.addTone(b, 0.45f, 0.004f, 0.10f, 0.40f, 880f, 0f);
        Synth.addTone(b, 0.52f, 0.004f, 0.16f, 0.45f, 1318.5f, 0f);
        return finish(b, 0.76f);
    }

    private static float[] dig() {
        float[] b = Synth.buffer(0.32f);
        Synth.Noise n = new Synth.Noise(963);
        Synth.addThunk(b, n, 0f, 0.95f, 120f, 0.040f);
        Synth.addNoise(b, n, 0f, 0.050f, 0.6f, 200f, 1500f);
        slide(b, n, 0.07f, 0.12f, 0.25f, 600f, 1800f);
        Synth.addNoise(b, n, 0.18f, 0.030f, 0.2f, 500f, 3000f);
        return finish(b, 0.72f);
    }

    private static float[] plant() {
        float[] b = Synth.buffer(0.26f);
        Synth.Noise n = new Synth.Noise(965);
        Synth.addThunk(b, n, 0f, 0.6f, 150f, 0.030f);
        Synth.addNoise(b, n, 0f, 0.040f, 0.5f, 400f, 2500f);
        Synth.addNoise(b, n, 0.08f, 0.050f, 0.3f, 1500f, 6000f);
        return finish(b, 0.62f);
    }

    private static float[] harvest() {
        float[] b = Synth.buffer(0.34f);
        Synth.Noise n = new Synth.Noise(967);
        Synth.addNoise(b, n, 0f, 0.008f, 0.9f, 1000f, 6000f);
        Synth.addSweep(b, 0f, 0.020f, 0.4f, 700f, 350f, 40f);
        Synth.addHiss(b, n, 0.02f, 0.18f, 0.28f, 2500f);
        Synth.addThunk(b, n, 0.12f, 0.35f, 200f, 0.020f);
        return finish(b, 0.68f);
    }

    /** Cranking a car that starts: coughing pulses that speed up into a steady idle. */
    private static float[] engineStart() {
        float[] b = Synth.buffer(1.9f);
        Synth.Noise n = new Synth.Noise(971);
        float t = 0f;
        // starter motor whine under the cranking
        Synth.addSweep(b, 0f, 0.9f, 0.18f, 190f, 330f, 1.2f);
        while (t < 1.8f) {
            float rate = t < 0.85f ? 5f + 4f * t : (t < 1.15f ? 9f + (t - 0.85f) * 40f : 22f);
            float amp = t < 0.85f ? 0.55f : 0.8f;
            Synth.addThunk(b, n, t, amp, 78f + 30f * (t > 1.15f ? 1f : 0f), 0.035f);
            Synth.addNoise(b, n, t, 0.018f, amp * 0.5f, 120f, 900f);
            t += 1f / rate;
        }
        Synth.lowPass(b, 1800f);
        Synth.saturate(b, 1.8f);
        return finish(b, 0.88f);
    }

    /** Cranking a car that will not start: the starter grinds, then a few dead clicks. */
    private static float[] engineFail() {
        float[] b = Synth.buffer(1.1f);
        Synth.Noise n = new Synth.Noise(973);
        float t = 0f;
        Synth.addSweep(b, 0f, 0.55f, 0.14f, 180f, 240f, 1.5f);
        while (t < 0.55f) {
            Synth.addThunk(b, n, t, 0.5f, 85f, 0.030f);
            Synth.addNoise(b, n, t, 0.015f, 0.25f, 120f, 800f);
            t += 1f / (6f + 6f * t);
        }
        clack(b, n, 0.72f, 0.7f, 1500f, 0.9f);
        clack(b, n, 0.84f, 0.55f, 1400f, 0.9f);
        clack(b, n, 0.95f, 0.40f, 1300f, 0.9f);
        Synth.lowPass(b, 3000f);
        return finish(b, 0.80f);
    }

    /** One engine pulse train (6 firings): loop it faster for higher revs. */
    private static float[] engineLoop() {
        float period = 0.05f;
        float[] b = Synth.buffer(period * 6f);
        Synth.Noise n = new Synth.Noise(977);
        for (int i = 0; i < 6; i++) {
            float amp = i % 2 == 0 ? 1f : 0.82f;
            Synth.addThunk(b, n, i * period, amp, 82f, 0.020f);
            Synth.addNoise(b, n, i * period, 0.012f, amp * 0.35f, 150f, 800f);
        }
        Synth.lowPass(b, 1500f);
        Synth.saturate(b, 1.6f);
        Synth.normalize(b, 0.7f);
        return b;
    }

    private static float[] carHit() {
        float[] b = Synth.buffer(0.45f);
        Synth.Noise n = new Synth.Noise(979);
        Synth.addSweep(b, 0f, 0.100f, 1.0f, 150f, 45f, 26f);
        Synth.addNoise(b, n, 0f, 0.060f, 0.9f, 200f, 4500f);
        modes(b, 0f, 0.35f, new float[] {420f, 960f, 1700f}, new float[] {0.060f, 0.035f, 0.020f}, new float[] {1f, 0.6f, 0.35f});
        Synth.addRatchet(b, n, 0.06f, 4, 0.022f, 0.9f, 0.3f, 2600f);
        Synth.saturate(b, 2.0f);
        return finish(b, 0.9f);
    }

    /** Working with a wrench: ratchet clicks and a few taps of metal on metal. */
    private static float[] repair() {
        float[] b = Synth.buffer(0.85f);
        Synth.Noise n = new Synth.Noise(981);
        Synth.addRatchet(b, n, 0f, 7, 0.032f, 0.95f, 0.5f, 2400f);
        clack(b, n, 0.30f, 0.65f, 1900f, 0.9f);
        clack(b, n, 0.42f, 0.55f, 2100f, 0.9f);
        Synth.addRatchet(b, n, 0.52f, 6, 0.030f, 0.95f, 0.45f, 2500f);
        knock(b, n, 0.74f, 0.45f, 160f);
        return finish(b, 0.76f);
    }

    private static float[] splash() {
        float[] b = Synth.buffer(0.42f);
        Synth.Noise n = new Synth.Noise(983);
        splashAt(b, n, 0f, 1.0f);
        splashAt(b, n, 0.16f, 0.4f);
        return finish(b, 0.76f);
    }

    /** A wall or door falling apart: a loud wooden crack, planks clattering down. */
    private static float[] breakDown() {
        float[] b = Synth.buffer(0.70f);
        Synth.Noise n = new Synth.Noise(985);
        Synth.addNoise(b, n, 0f, 0.012f, 1.0f, 800f, 7000f);
        Synth.addSweep(b, 0f, 0.060f, 0.95f, 200f, 70f, 30f);
        modes(b, 0f, 0.45f, new float[] {290f, 610f, 1120f}, new float[] {0.050f, 0.030f, 0.018f}, new float[] {1f, 0.6f, 0.3f});
        float[] at = {0.10f, 0.19f, 0.27f, 0.38f, 0.47f};
        for (int i = 0; i < at.length; i++) knock(b, n, at[i], 0.55f - 0.07f * i, 190f - 12f * i);
        Synth.saturate(b, 1.8f);
        return finish(b, 0.88f);
    }

    /** Taking a weapon: the grab (click and a short slide), a thunk of the gun settling, and a bright two-note chirp. */
    private static float[] pickup() {
        float[] b = Synth.buffer(0.38f);
        Synth.Noise n = new Synth.Noise(139);
        Synth.addClick(b, n, 0f, 0.7f, 2000f, 0.005f);
        Synth.addThunk(b, n, 0.002f, 0.4f, 200f, 0.04f);
        Synth.addScrape(b, n, 0.01f, 0.06f, 0.25f, 900f, 2800f);
        Synth.addTone(b, 0.08f, 0.004f, 0.07f, 0.55f, 880f, 0.1f);
        Synth.addTone(b, 0.15f, 0.004f, 0.10f, 0.6f, 1318.5f, 0.1f);
        Synth.addTone(b, 0.15f, 0.004f, 0.06f, 0.2f, 2637f, 0f);
        Synth.addRing(b, 0.15f, 0.10f, 3100f, 0.06f);
        return finish(b, 0.85f);
    }

    private static float[] kill() {
        float[] b = Synth.buffer(0.55f);
        Synth.Noise n = new Synth.Noise(113);
        Synth.addSweep(b, 0f, 0.17f, 1.0f, 130f, 32f, 14f);
        Synth.addNoise(b, n, 0f, 0.11f, 0.7f, 0f, 2200f);
        Synth.addNoise(b, n, 0f, 0.015f, 0.5f, 1500f, 7000f);
        Synth.saturate(b, 2.0f);
        return finish(b, 0.9f);
    }

    private static float[] respawn() {
        float[] b = Synth.buffer(0.45f);
        float phase = 0f;
        Synth.Noise n = new Synth.Noise(127);
        for (int i = 0; i < b.length; i++) {
            float t = i / (float) Synth.RATE;
            float f = 220f * (float) Math.pow(4.0, t / 0.45f);
            phase += (float) (2.0 * Math.PI) * f / Synth.RATE;
            float env = (float) Math.sin(Math.PI * Math.min(1f, t / 0.45f));
            b[i] = (float) Math.sin(phase) * env * 0.8f + n.next() * env * 0.05f;
        }
        return finish(b, 0.75f);
    }

    private static float[] impact() {
        float[] b = Synth.buffer(0.10f);
        Synth.Noise n = new Synth.Noise(131);
        Synth.addNoise(b, n, 0f, 0.012f, 0.9f, 1500f, 7000f);
        Synth.addTone(b, 0f, 0f, 0.03f, 0.25f, 2400f, 0f);
        return finish(b, 0.6f);
    }

    private static float[] beep(float freq, float seconds) {
        float[] b = Synth.buffer(seconds + 0.03f);
        Synth.addTone(b, 0f, 0.003f, seconds * 0.5f, 0.9f, freq, 0.15f);
        return finish(b, 0.7f);
    }

    private static float[] go() {
        float[] b = Synth.buffer(0.55f);
        Synth.addTone(b, 0f, 0.003f, 0.14f, 0.8f, 1320f, 0.15f);
        Synth.addTone(b, 0f, 0.003f, 0.14f, 0.4f, 1980f, 0f);
        Synth.addTone(b, 0f, 0.003f, 0.14f, 0.3f, 660f, 0f);
        return finish(b, 0.8f);
    }

    private static float[] arpeggio(float[] notes, float step, float tail, float sawMix) {
        float total = step * (notes.length - 1) + tail;
        float[] b = Synth.buffer(total);
        for (int i = 0; i < notes.length; i++) {
            boolean last = i == notes.length - 1;
            Synth.addTone(b, i * step, 0.005f, last ? tail * 0.35f : step * 1.1f, last ? 0.9f : 0.7f, notes[i], sawMix);
        }
        Synth.lowPass(b, 5000f);
        return finish(b, 0.8f);
    }

    /**
     * The roll: short and snappy, and unlike anything else in the game. A cloth snap and a soft push-off at
     * the start, a bright whoosh that sweeps upwards, and a quick \"fwip\" that falls away at the end. It has no
     * boom and no bang, so it can never be mistaken for a gun, and it is over in a quarter of a second.
     */
    private static float[] dodge() {
        float[] b = Synth.buffer(0.27f);
        Synth.Noise n = new Synth.Noise(137);
        Synth.addNoise(b, n, 0f, 0.005f, 0.5f, 3000f, 9000f);
        Synth.addSweep(b, 0f, 0.03f, 0.35f, 150f, 70f, 60f);
        Synth.addWhoosh(b, n, 0f, 0.20f, 1.0f, 900f, 4600f, 1.6f, 0.012f);
        Synth.addWhoosh(b, n, 0.10f, 0.14f, 0.35f, 5200f, 2400f, 2.0f, 0.02f);
        return finish(b, 0.85f);
    }

    private static float[] confirm() {
        float[] b = Synth.buffer(0.35f);
        Synth.addTone(b, 0.00f, 0.002f, 0.05f, 0.7f, 1760f, 0f);
        Synth.addTone(b, 0.07f, 0.002f, 0.09f, 0.7f, 2637f, 0f);
        return finish(b, 0.75f);
    }

}
