package com.hazardyard.game.input;

import com.hazardyard.game.core.LocalInput;

/**
 * The Battleground drop-in screen: the island on a big map, where the player taps (or drags the marker) to choose where to
 * land, and a Drop button to say they are done. Pure Java: the HUD reads the geometry from here, so what is drawn is what can
 * be touched. While it is active it takes every touch (no sticks or buttons work during the choice).
 */
public final class DropUi {
    /** Set every frame by the game loop: true while the drop choice is open for the local fighter. */
    public volatile boolean active;

    // geometry in screen pixels (see layout)
    public volatile float mapX, mapY, mapW, mapH;
    public volatile float btnX, btnY, btnW, btnH;
    public volatile float worldW = 6144f, worldH = 6144f;

    /** Where the player chose to land (world units). */
    public volatile boolean hasChoice;
    public volatile float chosenX, chosenY;
    /** The player pressed Drop: the choice is final. */
    public volatile boolean confirmed;

    private int viewW, viewH, insetT, insetB, insetR;
    private float density = 1f;
    private int owner = -1;
    private boolean dragging, onButton;
    private float lastX, lastY;
    private boolean choosePending, confirmPending;

    /** Where the map and the button go, for a screen of the given size (all in pixels). */
    public synchronized void layout(int w, int h, float d, float insetTop, float insetBottom, float insetRight) {
        viewW = w;
        viewH = h;
        density = d;
        insetT = (int) insetTop;
        insetB = (int) insetBottom;
        insetR = (int) insetRight;
        relayout();
    }

    /** The map the choice is made on (its size fixes the proportions of the picture). */
    public synchronized void setWorld(float ww, float wh) {
        if (ww == worldW && wh == worldH) return;
        worldW = ww;
        worldH = wh;
        relayout();
    }

    private void relayout() {
        if (viewW <= 0 || viewH <= 0) return;
        float top = insetT + 50f * density;
        float bottom = viewH - insetB - 10f * density;
        float availH = Math.max(40f, bottom - top);
        float availW = viewW * 0.62f;
        float s = Math.min(availH / worldH, availW / worldW);
        mapW = worldW * s;
        mapH = worldH * s;
        mapX = (viewW - mapW) * 0.5f;
        mapY = top + (availH - mapH) * 0.5f;
        btnW = 138f * density;
        btnH = 48f * density;
        float right = viewW - insetR - 14f * density;
        btnX = Math.min(right - btnW, mapX + mapW + 22f * density);
        btnY = mapY + mapH * 0.5f - btnH * 0.5f + 30f * density;
    }

    private boolean inMap(float x, float y) {
        return x >= mapX && x <= mapX + mapW && y >= mapY && y <= mapY + mapH;
    }

    private boolean inButton(float x, float y) {
        return x >= btnX && x <= btnX + btnW && y >= btnY && y <= btnY + btnH;
    }

    /** True when the touch belongs to this screen (while it is open, every touch does). */
    public synchronized boolean onDown(int id, float x, float y) {
        if (!active) return false;
        if (owner >= 0) return true;
        lastX = x;
        lastY = y;
        if (inButton(x, y)) {
            owner = id;
            onButton = true;
            return true;
        }
        if (!confirmed && inMap(x, y)) {
            owner = id;
            dragging = true;
            choose(x, y);
        }
        return true;
    }

    public synchronized void onMove(int id, float x, float y) {
        if (id != owner) return;
        lastX = x;
        lastY = y;
        if (dragging && !confirmed) choose(x, y);
    }

    public synchronized void onUp(int id) {
        if (id != owner) return;
        if (onButton && inButton(lastX, lastY) && !confirmed) {
            confirmed = true;
            confirmPending = true;
        }
        owner = -1;
        dragging = false;
        onButton = false;
    }

    public synchronized boolean owns(int id) {
        return owner == id;
    }

    private void choose(float x, float y) {
        float cx = Math.max(mapX, Math.min(mapX + mapW, x));
        float cy = Math.max(mapY, Math.min(mapY + mapH, y));
        chosenX = (cx - mapX) / mapW * worldW;
        chosenY = (cy - mapY) / mapH * worldH;
        hasChoice = true;
        choosePending = true;
    }

    /** Screen position of the chosen place (valid when {@link #hasChoice}). */
    public float screenX() {
        return mapX + chosenX / worldW * mapW;
    }

    public float screenY() {
        return mapY + chosenY / worldH * mapH;
    }

    /** The game thread takes what the player did since the last sample (the choice and/or the Drop button), once. */
    public synchronized void take(LocalInput out) {
        out.dropChoose = choosePending && hasChoice;
        out.dropX = chosenX;
        out.dropY = chosenY;
        out.dropConfirm = confirmPending;
        choosePending = false;
        confirmPending = false;
    }

    /** Called with the state of the choice every frame: when it closes everything is forgotten for the next match. */
    public synchronized void setActive(boolean on) {
        if (!on && active) {
            hasChoice = false;
            confirmed = false;
            owner = -1;
            dragging = false;
            onButton = false;
            choosePending = false;
            confirmPending = false;
        }
        active = on;
    }

    public synchronized void cancel() {
        owner = -1;
        dragging = false;
        onButton = false;
    }
}
