package com.hazardyard.game.core;

/**
 * The safe zone of a Battleground match: a circle that closes in on the island in {@link #SHRINKS} steps.
 * Fighters outside it take storm damage every second, more with every step, and the last step shrinks the
 * circle to a point, so a match always ends.
 *
 * <p>The match starts calm: the circle covers the whole map. While the zone waits, the next (smaller) circle is
 * already known and shown to the players; when the wait is over the zone shrinks towards it at a steady speed
 * and then waits again. The host runs {@link #step}; clients receive the numbers with every snapshot and only
 * call {@link #advance} to keep the picture smooth in between. Pure Java, no Android types.
 */
public final class Zone {
    /** Shrinks per match; the last one closes the circle completely. */
    public static final int SHRINKS = 7;

    /** Seconds of calm before shrink {@code i + 1} begins (index 0 is the calm at the start of the match). */
    private static final float[] WAIT = {50f, 36f, 26f, 20f, 14f, 8f, 5f};
    /** Seconds shrink {@code i + 1} takes. */
    private static final float[] SHRINK_TIME = {55f, 44f, 36f, 30f, 24f, 18f, 14f};
    /** Radius of the circle after shrink {@code i + 1}, as a fraction of the smaller side of the map. */
    private static final float[] RADIUS_FRACTION = {0.40f, 0.25f, 0.14f, 0.075f, 0.034f, 0.012f, 0f};
    /** Storm damage per second outside the circle once shrink {@code i} has begun (index 0: before the first shrink). */
    private static final float[] DPS = {1f, 2f, 4f, 6f, 9f, 13f, 18f, 26f};

    public boolean enabled;
    /** Shrinks begun so far (0 before the first one). The circle being shown next is shrink {@code phase + 1}. */
    public int phase;
    public boolean shrinking;
    /** The last shrink is over: the circle is a point and the whole map is storm. */
    public boolean collapsed;
    /** The safe circle right now. */
    public float cx, cy, radius;
    /** The circle the zone is heading for (shown on the map while it waits and while it shrinks). */
    public float toCx, toCy, toRadius;
    /** The circle at the moment the current shrink began (host side). */
    private float fromCx, fromCy, fromRadius;
    /** Seconds left of the current wait or shrink, and how long that stage is in all. */
    public float timer, stageLength;
    /** Storm damage per second outside the circle. */
    public float dps;

    private TileMap map;
    private final XorShift rng = new XorShift(0x2B07);

    /** Starts a match: the circle covers the whole map and the first target is chosen. */
    public void reset(TileMap m, int seed, int fighters) {
        startAlive = Math.max(2, fighters);
        aliveNow = startAlive;
        // a small match gets a quicker zone: it starts sooner and closes faster, since there are fewer fighters to find
        timeScale = Math.max(0.45f, Math.min(1f, 0.30f + 0.70f * startAlive / 8f));
        focusX = Float.NaN;
        reset(m, seed);
    }

    public void reset(TileMap m, int seed) {
        map = m;
        enabled = true;
        rng.setSeed(seed);
        phase = 0;
        shrinking = false;
        collapsed = false;
        cx = m.worldW * 0.5f;
        cy = m.worldH * 0.5f;
        radius = 0.5f * (float) Math.sqrt(m.worldW * (double) m.worldW + m.worldH * (double) m.worldH) + 64f;
        dps = DPS[0];
        chooseTarget();
        timer = WAIT[0] * timeScale;
        stageLength = timer;
    }

    /** Clears the zone (classic matches have none). */
    public void disable() {
        enabled = false;
        map = null;
    }

    /** Where the fighters still alive are (their centre) and how many: the next circle is drawn round them and the pace follows. */
    private float focusX = Float.NaN, focusY;
    private int aliveNow = 8;
    /** Fighters at the start of the match. */
    private int startAlive = 8;
    /** Multiplies every wait and shrink time (see {@link #reset(TileMap, int, int)}). */
    private float timeScale = 1f;

    /** Host: tells the zone where the survivors are. Call before {@link #step} (it is cheap). */
    public void setFocus(float x, float y, int alive) {
        focusX = x;
        focusY = y;
        aliveNow = alive;
    }

    /**
     * How fast the zone's clock runs: normal while many fighters are left, quicker as the field thins out, so two
     * survivors are not left circling a huge map: the last circles are small and the final fights come to them.
     */
    private float pace() {
        float p = 1f;
        if (aliveNow <= 2) p = 2.2f;
        else if (aliveNow <= 3) p = 1.7f;
        else if (aliveNow <= 4) p = 1.35f;
        // Never let the circle lag behind the fight: with few fighters left it has to be small already.
        if (phase < requiredPhase()) p *= 4f;
        return p;
    }

    /** The smallest shrink the match should have reached with this many fighters left (a fraction of those it started with). */
    private int requiredPhase() {
        float f = aliveNow / (float) Math.max(2, startAlive);
        if (aliveNow <= 1) return SHRINKS;
        if (f <= 0.20f) return 5;
        if (f <= 0.30f) return 4;
        if (f <= 0.42f) return 3;
        if (f <= 0.56f) return 2;
        if (f <= 0.76f) return 1;
        return 0;
    }

    /** Host: advances the zone by {@code dt} seconds. */
    public void step(float dt) {
        if (!enabled || collapsed) return;
        dt *= pace();
        timer -= dt;
        if (shrinking) {
            float u = stageLength > 1e-3f ? 1f - Math.max(0f, timer) / stageLength : 1f;
            cx = fromCx + (toCx - fromCx) * u;
            cy = fromCy + (toCy - fromCy) * u;
            radius = fromRadius + (toRadius - fromRadius) * u;
            if (timer <= 0f) {
                cx = toCx;
                cy = toCy;
                radius = toRadius;
                shrinking = false;
                if (phase >= SHRINKS) {
                    collapsed = true;
                    timer = 0f;
                } else {
                    chooseTarget();
                    timer = WAIT[phase] * timeScale;
                    stageLength = timer;
                }
            }
        } else if (timer <= 0f) {
            phase++;
            shrinking = true;
            fromCx = cx;
            fromCy = cy;
            fromRadius = radius;
            timer = SHRINK_TIME[phase - 1] * timeScale;
            stageLength = timer;
            dps = DPS[phase];
        }
    }

    /** Client: smooths the numbers of the last snapshot over the time until the next one arrives. */
    public void advance(float dt) {
        if (!enabled || collapsed) return;
        if (shrinking && timer > 1e-3f) {
            float k = Math.min(1f, dt / timer);
            cx += (toCx - cx) * k;
            cy += (toCy - cy) * k;
            radius += (toRadius - radius) * k;
        }
        timer = Math.max(0f, timer - dt);
    }

    /** True when the point is inside the safe circle. */
    public boolean inside(float x, float y) {
        if (!enabled) return true;
        float dx = x - cx;
        float dy = y - cy;
        return dx * dx + dy * dy <= radius * radius;
    }

    /** Like {@link #inside} for the circle the zone is heading for, with a margin (world units) kept from its edge. */
    public boolean insideTarget(float x, float y, float margin) {
        if (!enabled) return true;
        float dx = x - toCx;
        float dy = y - toCy;
        float r = Math.max(0f, toRadius - margin);
        return dx * dx + dy * dy <= r * r;
    }

    /** How far outside the safe circle the point lies (0 when it is inside). */
    public float distanceOutside(float x, float y) {
        if (!enabled) return 0f;
        float dx = x - cx;
        float dy = y - cy;
        float d = (float) Math.sqrt(dx * dx + dy * dy) - radius;
        return d > 0f ? d : 0f;
    }

    /** Number of the shrink the HUD talks about: the one running, or the one that comes next. */
    public int displayedShrink() {
        return Math.min(SHRINKS, shrinking ? phase : phase + 1);
    }

    /** Copies what a snapshot carries (client side). */
    public void load(int phase, boolean shrinking, boolean collapsed, float cx, float cy, float r,
                     float toCx, float toCy, float toR, float timer, float stage) {
        this.enabled = true;
        this.phase = MathUtil.clamp(phase, 0, SHRINKS);
        this.shrinking = shrinking;
        this.collapsed = collapsed;
        this.cx = cx;
        this.cy = cy;
        this.radius = r;
        this.toCx = toCx;
        this.toCy = toCy;
        this.toRadius = toR;
        this.timer = timer;
        this.stageLength = stage;
        this.dps = DPS[this.phase];
    }

    /** Storm damage per second at a given phase (for the HUD and the tests). */
    public static float dpsOf(int phase) {
        return DPS[MathUtil.clamp(phase, 0, SHRINKS)];
    }

    /** Total seconds of waiting and shrinking in a whole match (the match ends by then at the latest). */
    public static float totalSeconds() {
        float t = 0f;
        for (int i = 0; i < SHRINKS; i++) t += WAIT[i] + SHRINK_TIME[i];
        return t;
    }

    // ------------------------------------------------------------------ choosing the next circle

    /** The share (0..1) of a circle that is over water, from a handful of sample points. */
    private float waterShare(float x, float y, float r) {
        int n = 0, wet = 0;
        for (int ring = 0; ring < 3; ring++) {
            float rr = r * (ring == 0 ? 0f : (ring == 1 ? 0.5f : 0.9f));
            int pts = ring == 0 ? 1 : (ring == 1 ? 6 : 10);
            for (int i = 0; i < pts; i++) {
                float a = i * MathUtil.TWO_PI / pts + ring * 0.4f;
                n++;
                if (map.isWaterAt(x + (float) Math.cos(a) * rr, y + (float) Math.sin(a) * rr)) wet++;
            }
        }
        return n == 0 ? 0f : wet / (float) n;
    }

    /** Picks the circle of shrink {@code phase + 1}: smaller than the current one and entirely inside it, centred on dry land. */
    private void chooseTarget() {
        int next = phase + 1;
        float base = Math.min(map.worldW, map.worldH);
        float r = base * RADIUS_FRACTION[next - 1];
        float slack = Math.max(0f, radius - r);
        float margin = base * 0.08f;
        float bx = cx;
        float by = cy;
        boolean found = false;
        // Later circles are drawn round the fighters that are left, so they are pushed together; the early ones are
        // chosen freely but must be mostly dry land (a circle half over the sea is no real shrink).
        boolean follow = !Float.isNaN(focusX) && next >= 3;
        float bestWater = 2f;
        float maxWater = next <= 2 ? 0.22f : 0.34f;
        for (int tries = 0; tries < 70; tries++) {
            float px, py;
            if (follow && tries < 45) {
                float ang = rng.nextFloat() * MathUtil.TWO_PI;
                float off = (float) Math.sqrt(rng.nextFloat()) * r * 0.45f;
                px = focusX + (float) Math.cos(ang) * off;
                py = focusY + (float) Math.sin(ang) * off;
                // keep the new circle inside the current one
                float ddx = px - cx, ddy = py - cy;
                float dd = (float) Math.sqrt(ddx * ddx + ddy * ddy);
                float lim = Math.max(0f, slack * 0.95f);
                if (dd > lim && dd > 1f) {
                    px = cx + ddx / dd * lim;
                    py = cy + ddy / dd * lim;
                }
            } else {
                float ang = rng.nextFloat() * MathUtil.TWO_PI;
                float dist = (float) Math.sqrt(rng.nextFloat()) * slack * 0.9f;
                px = cx + (float) Math.cos(ang) * dist;
                py = cy + (float) Math.sin(ang) * dist;
            }
            if (px < margin || py < margin || px > map.worldW - margin || py > map.worldH - margin) continue;
            if (map.isSolidAt(px, py)) continue;
            float water = waterShare(px, py, r);
            if (water < bestWater) {
                bestWater = water;
                bx = px;
                by = py;
                found = true;
            }
            if (water <= maxWater) break;
        }
        if (!found) {
            bx = MathUtil.clamp(cx, margin, map.worldW - margin);
            by = MathUtil.clamp(cy, margin, map.worldH - margin);
        }
        toCx = bx;
        toCy = by;
        toRadius = Math.min(r, radius);
    }
}
