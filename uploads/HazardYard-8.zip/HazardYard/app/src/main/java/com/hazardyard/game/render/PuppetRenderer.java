package com.hazardyard.game.render;

import android.graphics.Canvas;
import android.graphics.Paint;

import com.hazardyard.game.core.Puppet;
import com.hazardyard.game.core.PuppetStyle;
import com.hazardyard.game.render.model.PoseMesh;
import com.hazardyard.game.render.model.SceneBuffer;

/**
 * Draws a {@link Puppet} skeleton (thirteen joints in world coordinates) as a low-poly person in the same lit, faceted
 * style as the soldiers: boxy limbs, a block head with hair and a face, clothes by {@link PuppetStyle}. The same code
 * draws a walking zombie, one falling over, a ragdoll flopped on the ground and a fallen soldier, so they all belong
 * together. Every part is built each frame by {@link PoseMesh}, which lights it and sorts the faces back to front.
 * Nothing is allocated while drawing.
 *
 * <p>The detail level trades faces for speed: 0 draws the silhouette in about a dozen boxes (far away or crowded
 * screens), 1 adds the joints, hands, shoes and hair, 2 adds faces, clothing details and wounds.
 */
public final class PuppetRenderer {
    private final PoseMesh mesh = new PoseMesh(300, 1500);
    private final PolyDrawer poly;
    private final Paint shadow = new Paint(Paint.ANTI_ALIAS_FLAG);

    private float[] wx, wy, wz;
    private PuppetStyle st;
    // torso frame: front, right, up
    private float fx, fy, fz, rx, ry, rz, ux, uy, uz;
    private float pelX, pelY, pelZ, chX, chY, chZ, torsoLen, shHalf, hpHalf;
    private float k;
    private int detail;

    PuppetRenderer(PolyDrawer poly) {
        this.poly = poly;
        shadow.setStyle(Paint.Style.FILL);
    }

    // ------------------------------------------------------------------ entry point

    /**
     * @param jx world x of the thirteen joints (see {@link Puppet}), jy and jz likewise
     * @param flash 0..1 white flash after a hit
     * @param fade 1 fully visible .. 0 gone
     */
    void draw(Canvas c, float[] jx, float[] jy, float[] jz, PuppetStyle style, float flash, float fade, int detailLevel) {
        if (fade <= 0.01f) return;
        wx = jx;
        wy = jy;
        wz = jz;
        st = style;
        detail = detailLevel;
        k = st.scale;
        frame();
        drawShadow(c, fade);
        mesh.begin();
        mesh.whiten = flash * 0.7f;
        mesh.alpha = fade;
        legs();
        torso();
        arms();
        head();
        poly.begin(c);
        lastFaces = mesh.faceCount();
        mesh.flush(poly);
    }

    /** How many polygons the last body drew (for tests and tuning). */
    int lastFaces;

    // ------------------------------------------------------------------ geometry helpers

    private void frame() {
        int L = Puppet.J_SH_L, R = Puppet.J_SH_R, HL = Puppet.J_HIP_L, HR = Puppet.J_HIP_R;
        chX = (wx[L] + wx[R]) * 0.5f;
        chY = (wy[L] + wy[R]) * 0.5f;
        chZ = (wz[L] + wz[R]) * 0.5f;
        pelX = (wx[HL] + wx[HR]) * 0.5f;
        pelY = (wy[HL] + wy[HR]) * 0.5f;
        pelZ = (wz[HL] + wz[HR]) * 0.5f;
        ux = chX - pelX;
        uy = chY - pelY;
        uz = chZ - pelZ;
        torsoLen = (float) Math.sqrt(ux * ux + uy * uy + uz * uz);
        if (torsoLen < 1e-3f) {
            torsoLen = 1f;
            ux = 0f;
            uy = 0f;
            uz = 1f;
        } else {
            ux /= torsoLen;
            uy /= torsoLen;
            uz /= torsoLen;
        }
        float sx = wx[R] - wx[L], sy = wy[R] - wy[L], sz = wz[R] - wz[L];
        shHalf = (float) Math.sqrt(sx * sx + sy * sy + sz * sz) * 0.5f;
        float hx = wx[HR] - wx[HL], hy = wy[HR] - wy[HL], hz = wz[HR] - wz[HL];
        hpHalf = (float) Math.sqrt(hx * hx + hy * hy + hz * hz) * 0.5f;
        if (shHalf < 1e-3f) {
            sx = 0f;
            sy = 1f;
            sz = 0f;
            shHalf = 3f;
        }
        float rl = (float) Math.sqrt(sx * sx + sy * sy + sz * sz);
        if (rl < 1e-3f) rl = 1f;
        sx /= rl;
        sy /= rl;
        sz /= rl;
        // front = right x up, then right again = up x front, so the frame is orthonormal
        fx = sy * uz - sz * uy;
        fy = sz * ux - sx * uz;
        fz = sx * uy - sy * ux;
        float fl = (float) Math.sqrt(fx * fx + fy * fy + fz * fz);
        if (fl < 1e-3f) {
            fx = 1f;
            fy = 0f;
            fz = 0f;
            fl = 1f;
        }
        fx /= fl;
        fy /= fl;
        fz /= fl;
        rx = uy * fz - uz * fy;
        ry = uz * fx - ux * fz;
        rz = ux * fy - uy * fx;
    }

    /** A box in the torso frame: centre (x, y, z), half sizes along front, right and up. */
    private void fbox(float x, float y, float z, float hf, float hr, float hu, int color) {
        mesh.box(x, y, z, hf, hr, hu, fx, fy, fz, rx, ry, rz, color, false);
    }

    /** A point on the torso: t along the spine (0 pelvis .. 1 chest), f in front, r to the right. */
    private float px(float t, float f, float r) {
        return pelX + ux * torsoLen * t + fx * f + rx * r;
    }

    private float py(float t, float f, float r) {
        return pelY + uy * torsoLen * t + fy * f + ry * r;
    }

    private float pz(float t, float f, float r) {
        return pelZ + uz * torsoLen * t + fz * f + rz * r;
    }

    /** A box at a point of the torso (see {@link #px}). */
    private void tbox(float t, float f, float r, float hf, float hr, float hu, int color) {
        mesh.box(px(t, f, r), py(t, f, r), pz(t, f, r), hf, hr, hu, fx, fy, fz, rx, ry, rz, color, false);
    }

    private static int shadeC(int c, float s) {
        return SceneBuffer.shade(c, s);
    }

    private void drawShadow(Canvas c, float fade) {
        float hz = (wz[Puppet.J_HIP_L] + wz[Puppet.J_HIP_R]) * 0.5f;
        float sc = st.scale * st.width;
        shadow.setColor(((int) (0x44 * fade) << 24));
        if (Math.abs(uz) > 0.55f) {
            float s = Math.max(0.5f, 1f - hz / 40f);
            shadow.setStyle(Paint.Style.FILL);
            c.drawOval(pelX - 8f * sc * s, pelY - 3.6f * sc * s + 1f, pelX + 8f * sc * s, pelY + 3.6f * sc * s + 1f, shadow);
        } else {
            // lying: a body-length shadow from head to feet
            float x0 = wx[Puppet.J_HEAD], y0 = wy[Puppet.J_HEAD] + 1.5f;
            float x1 = (wx[Puppet.J_FOOT_L] + wx[Puppet.J_FOOT_R]) * 0.5f, y1 = (wy[Puppet.J_FOOT_L] + wy[Puppet.J_FOOT_R]) * 0.5f + 1.5f;
            shadow.setStyle(Paint.Style.STROKE);
            shadow.setStrokeCap(Paint.Cap.ROUND);
            shadow.setStrokeWidth(8.5f * sc);
            c.drawLine(x0, y0, x1, y1, shadow);
            shadow.setStyle(Paint.Style.FILL);
        }
    }

    // ------------------------------------------------------------------ legs

    private void legs() {
        boolean soldier = st.build == Puppet.B_SOLDIER;
        float body = 0.95f + 0.07f * st.width;
        for (int side = 0; side < 2; side++) {
            int hip = side == 0 ? Puppet.J_HIP_L : Puppet.J_HIP_R;
            int knee = side == 0 ? Puppet.J_KNEE_L : Puppet.J_KNEE_R;
            int foot = side == 0 ? Puppet.J_FOOT_L : Puppet.J_FOOT_R;
            int upper = st.pants;
            int lower = st.longPants ? shadeC(st.pants, 0.92f) : st.skinShade;
            if (st.outfit == PuppetStyle.OUTFIT_GOWN) upper = st.shirt;
            float wT = 3.7f * k * body, wS = 3.2f * k * body;
            if (detail == 0) {
                mesh.beam(wx[hip], wy[hip], wz[hip], wx[foot], wy[foot], wz[foot], wT, wT, 0.8f, upper);
                continue;
            }
            mesh.beam(wx[hip], wy[hip], wz[hip], wx[knee], wy[knee], wz[knee], wT, wT + 0.3f, 0.7f, upper);
            mesh.beam(wx[knee], wy[knee], wz[knee], wx[foot], wy[foot], wz[foot], wS, wS + 0.2f, 0.5f, lower);
            if (soldier) {
                mesh.beam(wx[knee] * 0.9f + wx[hip] * 0.1f, wy[knee] * 0.9f + wy[hip] * 0.1f, wz[knee] * 0.9f + wz[hip] * 0.1f,
                        wx[knee] * 0.9f + wx[foot] * 0.1f, wy[knee] * 0.9f + wy[foot] * 0.1f, wz[knee] * 0.9f + wz[foot] * 0.1f,
                        wT + 0.8f, wT + 0.9f, 0.5f, 0xFF3A4350);
            }
            // shoe: points where the toes point (horizontal front of the body, or away from the knee when lying)
            float dx = fx, dy = fy;
            float dl = (float) Math.sqrt(dx * dx + dy * dy);
            if (dl < 0.45f) {
                dx = wx[foot] - wx[knee];
                dy = wy[foot] - wy[knee];
                dl = (float) Math.sqrt(dx * dx + dy * dy);
            }
            if (dl < 1e-3f) {
                dx = 1f;
                dy = 0f;
                dl = 1f;
            }
            dx /= dl;
            dy /= dl;
            float len = 3.4f * k;
            mesh.beam(wx[foot], wy[foot], wz[foot] + 0.2f, wx[foot] + dx * len, wy[foot] + dy * len, Math.max(wz[foot] - 0.2f, 1.0f), 3.0f * k, 2.2f * k, 0.5f, st.shoe);
            if ((st.wounds & PuppetStyle.W_LEG) != 0 && detail >= 2 && side == 1 && !soldier) {
                mesh.beam(wx[hip] * 0.75f + wx[knee] * 0.25f, wy[hip] * 0.75f + wy[knee] * 0.25f, wz[hip] * 0.75f + wz[knee] * 0.25f,
                        wx[hip] * 0.25f + wx[knee] * 0.75f, wy[hip] * 0.25f + wy[knee] * 0.75f, wz[hip] * 0.25f + wz[knee] * 0.75f,
                        wT + 0.5f, wT + 0.6f, 0.1f, st.blood);
            }
        }
    }

    // ------------------------------------------------------------------ torso

    private void torso() {
        boolean soldier = st.build == Puppet.B_SOLDIER;
        float depth = (soldier ? 3.0f : 2.6f) * k * (0.92f + 0.12f * st.width);
        float upperHalf = shHalf * (soldier ? 1.0f : 0.98f) + 0.6f * k;
        float lowerHalf = hpHalf * 1.18f + 0.5f * k;
        int upperColor = st.shirt;
        int lowerColor = st.pants;
        switch (st.outfit) {
            case PuppetStyle.OUTFIT_HOODIE:
            case PuppetStyle.OUTFIT_GOWN:
            case PuppetStyle.OUTFIT_COAT:
                lowerColor = st.shirt;
                break;
            default:
                break;
        }
        if (soldier) {
            upperColor = 0xFF8393AA;
            lowerColor = 0xFF3A4350;
        }
        if (detail == 0) {
            tbox(0.5f, 0f, 0f, depth, upperHalf * 0.9f, torsoLen * 0.62f, upperColor);
            return;
        }
        float lowT = st.outfit == PuppetStyle.OUTFIT_COAT || st.outfit == PuppetStyle.OUTFIT_HOODIE || st.outfit == PuppetStyle.OUTFIT_GOWN ? 0.28f : 0.22f;
        tbox(lowT, 0f, 0f, depth * 0.92f, lowerHalf, torsoLen * (lowT + 0.12f) * 0.5f + 0.4f, lowerColor);
        tbox(0.58f, 0f, 0f, depth, upperHalf, torsoLen * 0.5f * (1.04f - 0.2f) + 0.2f, upperColor);
        // neck
        mesh.box(chX + ux * k, chY + uy * k, chZ + uz * k, 1.1f * k, 1.2f * k, 1.2f * k, fx, fy, fz, rx, ry, rz, st.skinShade, false);
        if (soldier) {
            soldierTorso(depth, upperHalf, lowerHalf);
        } else if (detail >= 2) {
            outfitDetails(depth, upperHalf, lowerHalf);
            wounds(depth);
        }
    }

    private void outfitDetails(float depth, float upperHalf, float lowerHalf) {
        float front = depth + 0.18f;
        switch (st.outfit) {
            case PuppetStyle.OUTFIT_OFFICE:
                tbox(0.66f, front, 0f, 0.2f, 0.75f * k, torsoLen * 0.26f, st.trim);
                break;
            case PuppetStyle.OUTFIT_POLICE:
                tbox(0.74f, front, -upperHalf * 0.45f, 0.2f, 0.75f * k, 0.8f * k, st.trim);
                tbox(0.26f, 0f, 0f, depth * 0.98f, lowerHalf + 0.1f, 0.55f * k, 0xFF1B1B1F);
                break;
            case PuppetStyle.OUTFIT_VEST:
                tbox(0.58f, front, -upperHalf * 0.5f, 0.2f, 0.85f * k, torsoLen * 0.36f, st.trim);
                tbox(0.58f, front, upperHalf * 0.5f, 0.2f, 0.85f * k, torsoLen * 0.36f, st.trim);
                break;
            case PuppetStyle.OUTFIT_COAT:
                tbox(0.52f, front, 0f, 0.2f, 0.7f * k, torsoLen * 0.42f, st.trim);
                break;
            case PuppetStyle.OUTFIT_APRON:
                tbox(0.42f, front, 0f, 0.22f, upperHalf * 0.78f, torsoLen * 0.46f, shadeC(st.shirt, 1.05f));
                tbox(0.38f, front + 0.2f, 1.2f * k, 0.12f, 1.8f * k, 1.5f * k, st.blood);
                break;
            case PuppetStyle.OUTFIT_HOODIE:
                tbox(0.32f, front, 0f, 0.2f, upperHalf * 0.6f, k, st.trim);
                break;
            case PuppetStyle.OUTFIT_BARE:
                tbox(0.66f, front, 0.6f * k, 0.12f, 2.2f * k, 0.35f * k, st.skinShade);
                tbox(0.58f, front, -0.4f * k, 0.12f, 1.8f * k, 0.35f * k, st.skinShade);
                break;
            default:
                break;
        }
    }

    private void wounds(float depth) {
        float front = depth + 0.2f;
        if ((st.wounds & PuppetStyle.W_CHEST) != 0) {
            tbox(0.56f, front + 0.05f, 1.3f * k, 0.1f, 1.5f * k, 1.7f * k, st.blood);
            tbox(0.34f, front + 0.05f, -k, 0.1f, k, 1.1f * k, st.blood);
        }
        if ((st.wounds & PuppetStyle.W_NECK) != 0) {
            tbox(1.03f, 0.3f, 1.2f * k, 1.2f * k, 0.6f * k, 0.8f * k, st.blood);
        }
    }

    private void soldierTorso(float depth, float upperHalf, float lowerHalf) {
        float front = depth + 0.2f;
        tbox(0.58f, front, 0f, 0.5f * k, upperHalf * 0.72f, torsoLen * 0.34f, st.accent);                       // chest plate
        tbox(0.26f, 0f, 0f, depth * 1.02f, lowerHalf + 0.15f, 0.9f * k, 0xFF3A4350);                              // belt
        tbox(0.46f, -depth - 2.2f * k, 0f, 2.4f * k, upperHalf * 0.8f, torsoLen * 0.38f, 0xFF485364);             // backpack
        for (int side = 0; side < 2; side++) {                                                                      // shoulder pads
            int sh = side == 0 ? Puppet.J_SH_L : Puppet.J_SH_R;
            mesh.box(wx[sh] + ux * 1.2f * k, wy[sh] + uy * 1.2f * k, wz[sh] + uz * 1.2f * k, 2.6f * k, 2.0f * k, 1.6f * k, fx, fy, fz, rx, ry, rz, st.accent, false);
        }
    }

    // ------------------------------------------------------------------ arms

    private void arms() {
        boolean soldier = st.build == Puppet.B_SOLDIER;
        float body = 0.92f + 0.12f * st.width;
        for (int side = 0; side < 2; side++) {
            int sh = side == 0 ? Puppet.J_SH_L : Puppet.J_SH_R;
            int el = side == 0 ? Puppet.J_ELB_L : Puppet.J_ELB_R;
            int hand = side == 0 ? Puppet.J_HAND_L : Puppet.J_HAND_R;
            int upper = st.sleeveLen >= 1 ? st.sleeve : st.skin;
            int lower = st.sleeveLen >= 2 ? shadeC(st.sleeve, 0.92f) : st.skin;
            if (soldier) {
                upper = 0xFF6A7A91;
                lower = 0xFF6A7A91;
            }
            float wU = 3.0f * k * body, wL = 2.6f * k * body;
            if (detail == 0) {
                mesh.beam(wx[sh], wy[sh], wz[sh], wx[hand], wy[hand], wz[hand], wU, wU, 0.6f, upper);
                continue;
            }
            mesh.beam(wx[sh], wy[sh], wz[sh], wx[el], wy[el], wz[el], wU, wU, 0.7f, upper);
            mesh.beam(wx[el], wy[el], wz[el], wx[hand], wy[hand], wz[hand], wL, wL, 0.4f, lower);
            mesh.box(wx[hand], wy[hand], wz[hand], 1.3f * k, 1.3f * k, 1.3f * k, fx, fy, fz, rx, ry, rz, soldier ? 0xFF2C333D : st.skin, false);
            if ((st.wounds & PuppetStyle.W_ARM) != 0 && detail >= 2 && side == 0 && !soldier) {
                mesh.beam(wx[el] * 0.8f + wx[hand] * 0.2f, wy[el] * 0.8f + wy[hand] * 0.2f, wz[el] * 0.8f + wz[hand] * 0.2f,
                        wx[el] * 0.3f + wx[hand] * 0.7f, wy[el] * 0.3f + wy[hand] * 0.7f, wz[el] * 0.3f + wz[hand] * 0.7f,
                        wL + 0.4f, wL + 0.4f, 0.1f, st.blood);
            }
        }
    }

    // ------------------------------------------------------------------ head

    private void hbox(float hx, float hy, float hz, float f, float r, float u, float hf, float hr, float hu, int color, boolean glow) {
        mesh.box(hx + fx * f + rx * r + ux * u, hy + fy * f + ry * r + uy * u, hz + fz * f + rz * r + uz * u, hf, hr, hu,
                fx, fy, fz, rx, ry, rz, color, glow);
    }

    private void head() {
        int h = Puppet.J_HEAD;
        float hx = wx[h], hy = wy[h], hz = wz[h];
        float hs = k * (0.97f + 0.05f * st.width);
        if (st.build == Puppet.B_SOLDIER) {
            soldierHead(hx, hy, hz, hs);
            return;
        }
        hbox(hx, hy, hz, 0f, 0f, 0f, 2.7f * hs, 2.55f * hs, 2.75f * hs, st.skin, false);
        if (detail == 0) return;
        float top = 2.55f * hs;
        switch (st.hairStyle) {
            case PuppetStyle.HAIR_SHORT:
                hbox(hx, hy, hz, 0f, 0f, top, 2.85f * hs, 2.7f * hs, 0.8f * hs, st.hair, false);
                hbox(hx, hy, hz, -2.55f * hs, 0f, 0.5f * hs, 0.6f * hs, 2.7f * hs, 2.3f * hs, st.hair, false);
                break;
            case PuppetStyle.HAIR_MESSY:
                hbox(hx, hy, hz, 0f, 0f, top, 2.95f * hs, 2.8f * hs, 0.95f * hs, st.hair, false);
                hbox(hx, hy, hz, -2.6f * hs, 0f, 0.4f * hs, 0.7f * hs, 2.8f * hs, 2.4f * hs, st.hair, false);
                if (detail >= 2) {
                    hbox(hx, hy, hz, 0f, 1.4f * hs, top + 1.1f * hs, 1.0f * hs, 0.8f * hs, 0.8f * hs, st.hair, false);
                    hbox(hx, hy, hz, -0.8f * hs, -1.3f * hs, top + 1.0f * hs, 0.8f * hs, 0.9f * hs, 0.9f * hs, st.hair, false);
                }
                break;
            case PuppetStyle.HAIR_LONG:
                hbox(hx, hy, hz, 0f, 0f, top, 2.85f * hs, 2.7f * hs, 0.8f * hs, st.hair, false);
                hbox(hx, hy, hz, -2.65f * hs, 0f, -1.3f * hs, 0.7f * hs, 2.8f * hs, 4.2f * hs, st.hair, false);
                break;
            case PuppetStyle.HAIR_CAP:
                hbox(hx, hy, hz, 0f, 0f, top + 0.1f * hs, 2.95f * hs, 2.8f * hs, 0.95f * hs, 0xFF1F2A3D, false);
                hbox(hx, hy, hz, 3.3f * hs, 0f, 2.0f * hs, 1.2f * hs, 2.3f * hs, 0.25f * hs, 0xFF141C2A, false);
                break;
            case PuppetStyle.HAIR_HARDHAT:
                hbox(hx, hy, hz, 0f, 0f, top + 0.2f * hs, 3.05f * hs, 2.95f * hs, 1.15f * hs, 0xFFE8C13A, false);
                hbox(hx, hy, hz, 3.1f * hs, 0f, 1.9f * hs, 1.0f * hs, 2.95f * hs, 0.25f * hs, 0xFFC9A22C, false);
                break;
            default:
                break;
        }
        if (st.outfit == PuppetStyle.OUTFIT_HOODIE) {
            mesh.box(chX + ux * 1.6f * k - fx * 2.5f * k, chY + uy * 1.6f * k - fy * 2.5f * k, chZ + uz * 1.6f * k - fz * 2.5f * k,
                    1.9f * k, 3.2f * k, 2.0f * k, fx, fy, fz, rx, ry, rz, st.shirtShade, false);
        }
        if (detail >= 2) {
            float ff = 2.74f * hs;
            hbox(hx, hy, hz, ff, 1.2f * hs, 0.5f * hs, 0.12f * hs, 0.85f * hs, 0.75f * hs, 0xFF1B1D20, false);
            hbox(hx, hy, hz, ff, -1.2f * hs, 0.5f * hs, 0.12f * hs, 0.85f * hs, 0.75f * hs, 0xFF1B1D20, false);
            float ef = ff + 0.1f * hs;
            hbox(hx, hy, hz, ef, 1.2f * hs, 0.5f * hs, 0.1f * hs, 0.5f * hs, 0.42f * hs, st.eye, true);
            hbox(hx, hy, hz, ef, -1.2f * hs, 0.5f * hs, 0.1f * hs, 0.5f * hs, 0.42f * hs, st.eye, true);
            hbox(hx, hy, hz, ff, 0f, -1.35f * hs, 0.12f * hs, 1.4f * hs, 0.35f * hs, (st.wounds & PuppetStyle.W_JAW) != 0 ? st.blood : 0xFF3A1E1E, false);
            if ((st.wounds & PuppetStyle.W_HEAD) != 0) {
                hbox(hx, hy, hz, 0f, 2.6f * hs, 0.8f * hs, 1.1f * hs, 0.12f * hs, 1.1f * hs, st.blood, false);
            }
        }
    }

    private void soldierHead(float hx, float hy, float hz, float hs) {
        mesh.prism(hx, hy, hz, ux, uy, uz, fx, fy, fz, 5.2f * hs, 2.5f * hs, 6, st.accent);
        hbox(hx, hy, hz, 4.4f * hs, 0f, -0.3f, 1.1f * hs, 3.4f * hs, 1.7f * hs, 0xFF111A24, false);
        hbox(hx, hy, hz, 5.5f * hs, 0f, -0.3f, 0.1f * hs, 2.7f * hs, 0.7f * hs, 0xFF8FE8FF, true);
    }
}
