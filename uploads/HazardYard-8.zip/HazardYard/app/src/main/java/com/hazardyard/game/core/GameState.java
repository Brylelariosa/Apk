package com.hazardyard.game.core;

/**
 * Everything the renderer needs, plus everything the host simulates. The host mutates it through
 * {@link GameWorld}; a client fills it from network snapshots. Only the game thread touches it.
 */
public final class GameState {
    /** How far (0..1) the game clock is towards the next simulation step; the renderer draws bullets between their last two positions with it. */
    public float renderAlpha;

    /** Waiting for the match to begin (never simulated). */
    public static final int PHASE_LOBBY = 0;
    public static final int PHASE_COUNTDOWN = 1;
    public static final int PHASE_PLAYING = 2;
    /** Time or kill limit reached; results are on screen. */
    public static final int PHASE_ENDED = 3;
    /** Results shown long enough; the session should return to the lobby. */
    public static final int PHASE_FINISHED = 4;

    public final TileMap map;
    /** Rules of this match (time and kill limit, respawn delays). Fixed for the life of the state. */
    public final GameMode mode;
    public final CollisionSystem collision;
    /** The ground the match is played on (a map or the endless survival world). */
    public final Terrain terrain;
    /** The endless survival world and everything in it; null in every other mode. */
    public com.hazardyard.game.survival.SurvivalState survival;
    public final Player[] players = new Player[GameConfig.MAX_PLAYERS];
    public final ProjectilePool projectiles = new ProjectilePool(GameConfig.MAX_PROJECTILES);
    public final Pickup[] pickups;
    /** How many of {@link #pickups} are fixed pads of the map; the rest are the slots that fill up during a Battleground match. */
    public final int mapPads;
    /** The shrinking safe zone of a Battleground match; {@link Zone#enabled} is false in every other mode. */
    public final Zone zone = new Zone();
    public final Effects effects = new Effects();
    /** Bodies of the fallen (zombies, soldiers) flopping about under physics; visual only. */
    public final Ragdolls ragdolls = new Ragdolls();
    /** Presentation asks for a camera shake of this size; the game loop takes it (and clears it) once per frame. */
    public float shakeRequest;
    /** Turns events into sound requests; the sink is attached by the screen that owns the audio output. */
    public final AudioDirector audio = new AudioDirector(this);

    public int phase = PHASE_LOBBY;
    public float timeLeft;
    public float countdown;
    public float resultsTimer;
    /** Slot of the match winner, or -1 for a draw / undecided. */
    public int winnerId = -1;
    public final int localId;
    /**
     * The fighter whose view is on screen: the local player, or after an elimination in a Battleground match the
     * fighter the camera has moved on to (the sounds are heard from there too).
     */
    public int viewId;

    public GameState(TileMap map, int localId) {
        this(map, localId, GameMode.ALL[GameMode.CLASSIC]);
    }

    public GameState(TileMap map, int localId, GameMode mode) {
        this(map, map, localId, mode);
    }

    /**
     * A match whose collisions run against {@code terrain}. For every fixed arena that is the map itself; the survival
     * world is endless, so there {@code map} is only a tiny stand-in and {@code terrain} is the real ground.
     */
    public GameState(TileMap map, Terrain terrain, int localId, GameMode mode) {
        this.map = map;
        this.mode = mode;
        this.timeLeft = mode.matchSeconds;
        this.localId = localId;
        this.viewId = localId;
        this.collision = new CollisionSystem(terrain);
        this.terrain = terrain;
        for (int i = 0; i < players.length; i++) players[i] = new Player(i);
        mapPads = map.pickupX.length;
        int loot = mode.royale ? GameConfig.LOOT_SLOTS : 0;
        pickups = new Pickup[mapPads + loot];
        for (int i = 0; i < mapPads; i++) {
            pickups[i] = new Pickup(map.pickupX[i], map.pickupY[i], map.pickupItem[i]);
        }
        for (int i = mapPads; i < pickups.length; i++) pickups[i] = new Pickup();
    }

    public Player local() {
        return players[localId];
    }

    /** The fighter the camera is on (see {@link #viewId}). */
    public Player view() {
        return players[viewId];
    }

    /** Fighters still in the match: connected and alive. */
    public int aliveCount() {
        int n = 0;
        for (int i = 0; i < players.length; i++) if (players[i].connected && players[i].alive) n++;
        return n;
    }

    public int connectedCount() {
        int n = 0;
        for (int i = 0; i < players.length; i++) if (players[i].connected) n++;
        return n;
    }
}
