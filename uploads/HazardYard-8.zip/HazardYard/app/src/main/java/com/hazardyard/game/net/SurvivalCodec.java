package com.hazardyard.game.net;

import com.hazardyard.game.core.GameConfig;
import com.hazardyard.game.core.GameState;
import com.hazardyard.game.core.MathUtil;
import com.hazardyard.game.core.Player;
import com.hazardyard.game.survival.Car;
import com.hazardyard.game.survival.Drop;
import com.hazardyard.game.survival.Inventory;
import com.hazardyard.game.survival.SurvivalState;
import com.hazardyard.game.survival.Zombie;

/**
 * Wire format of the survival extras. {@code S_SURV} (10 Hz, droppable): clock, hunger and fishing of every survivor, then the
 * zombies, cars and dropped items within sight of anybody. Positions are 1/4 unit in an int32, since the world is endless.
 * Events, tile edits and inventories are small separate reliable frames.
 */
public final class SurvivalCodec {
    private SurvivalCodec() {}

    /** Entities further than this from every survivor are not sent. */
    private static final float INTEREST = 1150f;
    private static final int MAX_Z = 44, MAX_C = 12, MAX_D = 40;

    private static int q(float v) {
        return Math.round(v * GameConfig.POS_SCALE);
    }

    private static float uq(int v) {
        return v / GameConfig.POS_SCALE;
    }

    private static boolean near(GameState st, float x, float y) {
        float lim = INTEREST * INTEREST;
        for (Player p : st.players) {
            if (!p.connected || !p.alive) continue;
            float dx = p.x - x, dy = p.y - y;
            if (dx * dx + dy * dy < lim) return true;
        }
        return false;
    }

    public static byte[] encodeState(PacketWriter w, GameState st) {
        SurvivalState sv = st.survival;
        w.begin(Protocol.S_SURV);
        w.i32((int) (sv.time * 10f));
        int present = 0;
        for (int i = 0; i < st.players.length; i++) if (st.players[i].connected) present |= 1 << i;
        w.u8(present);
        for (int i = 0; i < st.players.length; i++) {
            if ((present & (1 << i)) == 0) continue;
            w.u8(MathUtil.clamp(Math.round(sv.hunger[i]), 0, 100));
            w.u8(sv.fishState[i]);
            if (sv.fishState[i] != 0) {
                w.i32(q(sv.fishX[i]));
                w.i32(q(sv.fishY[i]));
            }
        }
        int n = 0;
        int lenPos = w.size();
        w.u8(0);
        for (Zombie z : sv.zombies) {
            if (!z.active || n >= MAX_Z || !near(st, z.x, z.y)) continue;
            w.u16(z.id);
            w.i32(q(z.x));
            w.i32(q(z.y));
            w.u8(MathUtil.angleToU8(z.aim));
            w.u8(MathUtil.clamp(z.hp, 0, 255));
            w.u8((z.type & 3) | ((z.state & 15) << 2) | (z.hurt > 0f ? 64 : 0));
            n++;
        }
        w.setU8(lenPos, n);
        n = 0;
        lenPos = w.size();
        w.u8(0);
        for (Car c : sv.cars) {
            if (!c.active || n >= MAX_C || !near(st, c.x, c.y)) continue;
            w.u16(c.id);
            w.i32(q(c.x));
            w.i32(q(c.y));
            w.u8(MathUtil.angleToU8(c.heading));
            w.i16(MathUtil.clamp(Math.round(c.speed * 4f), -32768, 32767));
            w.u8(c.driver < 0 ? 255 : c.driver);
            w.u8(c.flags());
            w.u8(MathUtil.clamp(c.fuel, 0, 100));
            w.u8(MathUtil.clamp(c.hp, 0, 100));
            w.u8(c.variant & 7);
            n++;
        }
        w.setU8(lenPos, n);
        n = 0;
        lenPos = w.size();
        w.u8(0);
        for (Drop d : sv.drops) {
            if (!d.active || n >= MAX_D || !near(st, d.x, d.y)) continue;
            w.u16(d.id);
            w.i32(q(d.x));
            w.i32(q(d.y));
            w.u8(d.item);
            w.u8(MathUtil.clamp(d.count, 0, 255));
            n++;
        }
        w.setU8(lenPos, n);
        return w.finishFrame();
    }

    private static int stamp;

    public static void decodeState(PacketReader r, GameState st) {
        SurvivalState sv = st.survival;
        stamp++;
        float t = r.i32() / 10f;
        // the clock runs on its own between messages; only correct it when it has drifted
        if (Math.abs(t - sv.time) > 1.5f) sv.time = t;
        int present = r.u8();
        for (int i = 0; i < st.players.length; i++) {
            if ((present & (1 << i)) == 0) continue;
            sv.hunger[i] = r.u8();
            sv.fishState[i] = r.u8();
            if (sv.fishState[i] != 0) {
                sv.fishX[i] = uq(r.i32());
                sv.fishY[i] = uq(r.i32());
            }
        }
        int n = r.u8();
        for (int k = 0; k < n; k++) {
            int id = r.u16();
            float x = uq(r.i32()), y = uq(r.i32());
            float aim = MathUtil.u8ToAngle(r.u8());
            int hp = r.u8();
            int fl = r.u8();
            Zombie z = sv.zombieById(id);
            if (z == null) {
                z = freeZombie(sv);
                if (z == null) continue;
                z.active = true;
                z.id = id;
                z.rx = x;
                z.ry = y;
                z.rAim = aim;
            }
            z.seen = stamp;
            z.x = x;
            z.y = y;
            z.aim = aim;
            z.hp = hp;
            z.type = fl & 3;
            int stt = (fl >> 2) & 15;
            z.attacking = stt == com.hazardyard.game.core.Puppet.A_ATTACK;
            if ((fl & 64) != 0) z.hurt = 0.18f;
            if (z.stateLock <= 0f) z.setState(stt);
        }
        for (Zombie z : sv.zombies) if (z.active && z.seen != stamp) z.active = false;
        n = r.u8();
        for (int k = 0; k < n; k++) {
            int id = r.u16();
            float x = uq(r.i32()), y = uq(r.i32());
            float hd = MathUtil.u8ToAngle(r.u8());
            float speed = r.i16() / 4f;
            int driver = r.u8();
            int flags = r.u8();
            int fuel = r.u8();
            int hp = r.u8();
            int variant = r.u8();
            Car c = sv.carById(id);
            if (c == null) {
                c = freeCar(sv);
                if (c == null) continue;
                c.active = true;
                c.id = id;
                c.rx = x;
                c.ry = y;
                c.rHeading = hd;
            }
            c.seen = stamp;
            c.x = x;
            c.y = y;
            c.heading = hd;
            c.speed = speed;
            c.driver = driver == 255 ? -1 : driver;
            c.setFlags(flags);
            c.fuel = fuel;
            c.hp = hp;
            c.variant = variant;
        }
        for (Car c : sv.cars) if (c.active && c.seen != stamp) c.active = false;
        n = r.u8();
        for (int k = 0; k < n; k++) {
            int id = r.u16();
            float x = uq(r.i32()), y = uq(r.i32());
            int item = r.u8();
            int count = r.u8();
            Drop d = sv.dropById(id);
            if (d == null) {
                d = freeDrop(sv);
                if (d == null) continue;
                d.active = true;
                d.id = id;
            }
            d.seen = stamp;
            d.x = x;
            d.y = y;
            d.item = item;
            d.count = count;
        }
        for (Drop d : sv.drops) if (d.active && d.seen != stamp) d.active = false;
        for (int i = 0; i < sv.drivingCar.length; i++) sv.drivingCar[i] = -1;
        for (Car c : sv.cars) if (c.active && c.driver >= 0 && c.driver < sv.drivingCar.length) sv.drivingCar[c.driver] = c.id;
    }

    private static Zombie freeZombie(SurvivalState sv) {
        for (Zombie z : sv.zombies) if (!z.active) return z;
        return null;
    }

    private static Car freeCar(SurvivalState sv) {
        for (Car c : sv.cars) if (!c.active) return c;
        return null;
    }

    private static Drop freeDrop(SurvivalState sv) {
        for (Drop d : sv.drops) if (!d.active) return d;
        return null;
    }

    // ------------------------------------------------------------------ reliable extras

    public static byte[] encodeSound(PacketWriter w, int sound, float x, float y, float volume, float pitch) {
        w.begin(Protocol.S_SURV_EVENT);
        w.u8(0);
        w.u8(sound);
        w.i32(q(x));
        w.i32(q(y));
        w.u8(MathUtil.clamp(Math.round(volume * 100f), 0, 255));
        w.u8(pitch <= 0f ? 0 : MathUtil.clamp(Math.round(pitch * 50f), 1, 255));
        return w.finishFrame();
    }

    /** A blow on a zombie: everybody shows the flinch, fall or ragdoll. */
    public static byte[] encodeZombieEvent(PacketWriter w, int id, int type, int kind, float x, float y, float angle, float strength, int damage) {
        w.begin(Protocol.S_SURV_EVENT);
        w.u8(2);
        w.u16(id);
        w.u8((kind & 15) | ((type & 3) << 4));
        w.i32(q(x));
        w.i32(q(y));
        w.u8(MathUtil.angleToU8(angle));
        w.u8(MathUtil.clamp(Math.round(strength * 100f), 0, 255));
        w.u8(MathUtil.clamp(damage, 0, 255));
        return w.finishFrame();
    }

    public static byte[] encodeToast(PacketWriter w, int player, int code) {
        w.begin(Protocol.S_SURV_EVENT);
        w.u8(1);
        w.u8(player);
        w.u8(code);
        return w.finishFrame();
    }

    public static byte[] encodeEdit(PacketWriter w, int tx, int ty, int layer, int value, int meta) {
        w.begin(Protocol.S_SURV_EDIT);
        w.u8(layer);
        w.i32(tx);
        w.i32(ty);
        w.u8(value);
        w.u8(meta);
        return w.finishFrame();
    }

    public static byte[] encodeInventory(PacketWriter w, Inventory inv) {
        w.begin(Protocol.S_SURV_INV);
        w.u8(inv.selected);
        for (int i = 0; i < Inventory.SLOTS; i++) {
            boolean empty = inv.isEmpty(i);
            w.u8(empty ? 255 : inv.item[i]);
            w.u8(empty ? 0 : MathUtil.clamp(inv.count[i], 0, 255));
            w.u8(empty ? 0 : MathUtil.clamp(inv.ammo[i], 0, 255));
        }
        return w.finishFrame();
    }

    public static void decodeInventory(PacketReader r, Inventory inv) {
        inv.selected = MathUtil.clamp(r.u8(), 0, Inventory.HOTBAR - 1);
        for (int i = 0; i < Inventory.SLOTS; i++) {
            int item = r.u8();
            int count = r.u8();
            int ammo = r.u8();
            if (item == 255 || count == 0) {
                inv.item[i] = -1;
                inv.count[i] = 0;
                inv.ammo[i] = 0;
            } else {
                inv.item[i] = item;
                inv.count[i] = count;
                inv.ammo[i] = ammo;
            }
        }
    }

    public static byte[] encodeCommand(PacketWriter w, int cmd, int a, int b) {
        w.begin(Protocol.C_SURV);
        w.u8(cmd);
        w.i16(a);
        w.i16(b);
        return w.finishFrame();
    }
}
