package com.hazardyard.game.render;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;

import com.hazardyard.game.core.GameConfig;
import com.hazardyard.game.core.TileMap;
import com.hazardyard.game.render.model.Projection;

/**
 * The roofs of the buildings you can walk into. A roof hides everything under it; when the player steps through the door
 * it fades away, and it comes back when they leave. Houses get a pitched roof in one of six colours, big halls and
 * bunkers a flat corrugated metal one.
 */
final class RoofRenderer {
    private static final float T = GameConfig.TILE;
    private static final float BASE_Z = 27f;
    private static final float RIDGE_Z = 38f;
    private static final float EAVE = 3.5f;
    private static final int[] TILE_COLORS = {0xFFB5523B, 0xFF5C6878, 0xFF7A5238, 0xFF4F7A4A, 0xFF4A6FA5, 0xFF9A6A3A};

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();

    RoofRenderer() {
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeCap(Paint.Cap.ROUND);
    }

    /** True when the roof of this house reaches into the rectangle. */
    static boolean inView(TileMap map, int h, float vx0, float vx1, float vy0, float vy1) {
        int o = h * 5;
        float x0 = map.houses[o] * T - EAVE;
        float y0 = map.houses[o + 1] * T - EAVE;
        float x1 = (map.houses[o + 2] + 1) * T + EAVE + Projection.LEAN * RIDGE_Z;
        float y1 = (map.houses[o + 3] + 1) * T + EAVE;
        return !(x1 < vx0 || x0 > vx1 || y1 < vy0 || y0 - Projection.TILT * RIDGE_Z > vy1);
    }

    /** The depth key of a roof: the south edge of the building (roofs are drawn after the walls that have the same one). */
    static float southKey(TileMap map, int h) {
        return (map.houses[h * 5 + 3] + 1) * T;
    }

    void draw(Canvas c, TileMap map, int h, float alpha, boolean lite) {
        int o = h * 5;
        drawRect(c, map.houses[o], map.houses[o + 1], map.houses[o + 2], map.houses[o + 3], map.houses[o + 4], alpha, lite);
    }

    /** True when a roof over the tiles tx0..tx1, ty0..ty1 (inclusive) reaches into the rectangle (world units). */
    static boolean inView(int tx0, int ty0, int tx1, int ty1, float vx0, float vx1, float vy0, float vy1) {
        float x0 = tx0 * T - EAVE;
        float y0 = ty0 * T - EAVE;
        float x1 = (tx1 + 1) * T + EAVE + Projection.LEAN * RIDGE_Z;
        float y1 = (ty1 + 1) * T + EAVE;
        return !(x1 < vx0 || x0 > vx1 || y1 < vy0 || y0 - Projection.TILT * RIDGE_Z > vy1);
    }

    /** A roof over the tiles tx0..tx1, ty0..ty1 (inclusive); {@code style}: bits 0-2 the tile colour, bit 3 a flat metal roof. */
    void drawRect(Canvas c, int tx0, int ty0, int tx1, int ty1, int style, float alpha, boolean lite) {
        if (alpha <= 0.02f) return;
        float x0 = tx0 * T - EAVE;
        float y0 = ty0 * T - EAVE;
        float x1 = (tx1 + 1) * T + EAVE;
        float y1 = (ty1 + 1) * T + EAVE;
        boolean flat = (style & 8) != 0;
        int base = TILE_COLORS[(style & 7) % TILE_COLORS.length];
        int a = (int) (Math.min(1f, alpha) * 255f);
        fill.setStyle(Paint.Style.FILL);
        float lean = Projection.LEAN;
        float tilt = Projection.TILT;
        if (flat) {
            // flat metal roof: one lit slab with a lip and corrugation
            float zl = BASE_Z + 2f;
            fill.setColor(withAlpha(0xFF6F7886, a));
            quad(c, x0, y1, x1, y1, x1 + lean * zl, y1 - tilt * zl, x0 + lean * zl, y1 - tilt * zl, fill);    // the south lip
            fill.setColor(withAlpha(0xFF9AA4B2, a));
            quad(c, x0 + lean * zl, y0 - tilt * zl, x1 + lean * zl, y0 - tilt * zl, x1 + lean * zl, y1 - tilt * zl, x0 + lean * zl, y1 - tilt * zl, fill);
            if (!lite) {
                line.setColor(withAlpha(0x33000000, a));
                line.setStrokeWidth(1.2f);
                float yy0 = y0 - tilt * zl;
                float yy1 = y1 - tilt * zl;
                float xa = x0 + lean * zl;
                float xb = x1 + lean * zl;
                for (float x = xa + 7f; x < xb; x += 9f) c.drawLine(x, yy0, x, yy1, line);
                line.setColor(withAlpha(0x44FFFFFF, a));
                c.drawLine(xa, yy0 + 1f, xb, yy0 + 1f, line);
            }
            return;
        }
        boolean horizontalRidge = (x1 - x0) >= (y1 - y0);
        int lit = withAlpha(lighten(base, 1.10f), a);
        int dark = withAlpha(lighten(base, 0.70f), a);
        int tileLine = withAlpha(0x38000000, a);
        float bz = BASE_Z;
        float rz = RIDGE_Z;
        if (horizontalRidge) {
            float ym = (y0 + y1) * 0.5f;
            fill.setColor(dark);                    // north slope (turned away)
            quad(c, x0 + lean * bz, y0 - tilt * bz, x1 + lean * bz, y0 - tilt * bz, x1 + lean * rz, ym - tilt * rz, x0 + lean * rz, ym - tilt * rz, fill);
            fill.setColor(lit);                     // south slope (faces the viewer)
            quad(c, x0 + lean * rz, ym - tilt * rz, x1 + lean * rz, ym - tilt * rz, x1 + lean * bz, y1 - tilt * bz, x0 + lean * bz, y1 - tilt * bz, fill);
            // eave shadow line and the ridge
            line.setColor(withAlpha(0x66000000, a));
            line.setStrokeWidth(2.2f);
            c.drawLine(x0 + lean * bz, y1 - tilt * bz, x1 + lean * bz, y1 - tilt * bz, line);
            line.setColor(withAlpha(0x66FFFFFF, a));
            line.setStrokeWidth(1.6f);
            c.drawLine(x0 + lean * rz, ym - tilt * rz, x1 + lean * rz, ym - tilt * rz, line);
            if (!lite) {
                line.setColor(tileLine);
                line.setStrokeWidth(1.1f);
                for (int k = 1; k < 4; k++) {
                    float f = k / 4f;
                    float yS = (ym - tilt * rz) + ((y1 - tilt * bz) - (ym - tilt * rz)) * f;
                    float xs = lean * (rz + (bz - rz) * f);
                    c.drawLine(x0 + xs, yS, x1 + xs, yS, line);
                    float yN = (ym - tilt * rz) + ((y0 - tilt * bz) - (ym - tilt * rz)) * f;
                    c.drawLine(x0 + xs, yN, x1 + xs, yN, line);
                }
            }
        } else {
            float xm = (x0 + x1) * 0.5f;
            fill.setColor(dark);                    // west slope
            quad(c, x0 + lean * bz, y0 - tilt * bz, xm + lean * rz, y0 - tilt * rz, xm + lean * rz, y1 - tilt * rz, x0 + lean * bz, y1 - tilt * bz, fill);
            fill.setColor(lit);                     // east slope
            quad(c, xm + lean * rz, y0 - tilt * rz, x1 + lean * bz, y0 - tilt * bz, x1 + lean * bz, y1 - tilt * bz, xm + lean * rz, y1 - tilt * rz, fill);
            line.setColor(withAlpha(0x66000000, a));
            line.setStrokeWidth(2.2f);
            c.drawLine(x0 + lean * bz, y1 - tilt * bz, xm + lean * rz, y1 - tilt * rz, line);
            c.drawLine(x1 + lean * bz, y1 - tilt * bz, xm + lean * rz, y1 - tilt * rz, line);
            line.setColor(withAlpha(0x66FFFFFF, a));
            line.setStrokeWidth(1.6f);
            c.drawLine(xm + lean * rz, y0 - tilt * rz, xm + lean * rz, y1 - tilt * rz, line);
            if (!lite) {
                line.setColor(tileLine);
                line.setStrokeWidth(1.1f);
                for (int k = 1; k < 4; k++) {
                    float f = k / 4f;
                    float zz = rz + (bz - rz) * f;
                    float xe = xm + (x1 - xm) * f + lean * zz;
                    float xw = xm + (x0 - xm) * f + lean * zz;
                    c.drawLine(xe, y0 - tilt * zz, xe, y1 - tilt * zz, line);
                    c.drawLine(xw, y0 - tilt * zz, xw, y1 - tilt * zz, line);
                }
            }
        }
    }

    private void quad(Canvas c, float ax, float ay, float bx, float by, float cx, float cy, float dx, float dy, Paint paint) {
        path.reset();
        path.moveTo(ax, ay);
        path.lineTo(bx, by);
        path.lineTo(cx, cy);
        path.lineTo(dx, dy);
        path.close();
        c.drawPath(path, paint);
    }

    private static int withAlpha(int argb, int alpha) {
        int a = ((argb >>> 24) * alpha) / 255;
        return (argb & 0x00FFFFFF) | (a << 24);
    }

    private static int lighten(int argb, float k) {
        int r = Math.min(255, (int) (((argb >> 16) & 255) * k));
        int g = Math.min(255, (int) (((argb >> 8) & 255) * k));
        int b = Math.min(255, (int) ((argb & 255) * k));
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }
}
