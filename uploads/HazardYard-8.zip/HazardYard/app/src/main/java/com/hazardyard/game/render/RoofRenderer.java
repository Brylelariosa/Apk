package com.hazardyard.game.render;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;

import com.hazardyard.game.core.GameConfig;
import com.hazardyard.game.core.TileMap;
import com.hazardyard.game.render.model.Projection;

/**
 * The roofs of the buildings you can walk into. A roof hides everything under it; when the player steps through the door
 * it fades away, and it comes back when they leave. Houses get a pitched roof in one of six colours, big halls and
 * bunkers a flat corrugated metal one.
 */
final class RoofRenderer {
    private static final float T = GameConfig.TILE;
    private static final float BASE_Z = 27f;
    private static final float RIDGE_Z = 38f;
    private static final float EAVE = 3.5f;
    private static final int[] TILE_COLORS = {0xFFB5523B, 0xFF5C6878, 0xFF7A5238, 0xFF4F7A4A, 0xFF4A6FA5, 0xFF9A6A3A};

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();

    RoofRenderer() {
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeCap(Paint.Cap.ROUND);
    }

    /** True when the roof of this house reaches into the rectangle. */
    static boolean inView(TileMap map, int h, float vx0, float vx1, float vy0, float vy1) {
        int o = h * 5;
        float x0 = map.houses[o] * T - EAVE;
        float y0 = map.houses[o + 1] * T - EAVE;
        float x1 = (map.houses[o + 2] + 1) * T + EAVE + Projection.LEAN * RIDGE_Z;
        float y1 = (map.houses[o + 3] + 1) * T + EAVE;
        return !(x1 < vx0 || x0 > vx1 || y1 < vy0 || y0 - Projection.TILT * RIDGE_Z > vy1);
    }

    /** The depth key of a roof: the south edge of the building (roofs are drawn after the walls that have the same one). */
    static float southKey(TileMap map, int h) {
        return (map.houses[h * 5 + 3] + 1) * T;
    }

    void draw(Canvas c, TileMap map, int h, float alpha, boolean lite) {
        int o = h * 5;
        drawRect(c, map.houses[o], map.houses[o + 1], map.houses[o + 2], map.houses[o + 3], map.houses[o + 4], alpha, lite);
    }

    /** True when a roof over the tiles tx0..tx1, ty0..ty1 (inclusive) reaches into the rectangle (world units). */
    static boolean inView(int tx0, int ty0, int tx1, int ty1, float vx0, float vx1, float vy0, float vy1) {
        float x0 = tx0 * T - EAVE;
        float y0 = ty0 * T - EAVE;
        float x1 = (tx1 + 1) * T + EAVE + Projection.LEAN * RIDGE_Z;
        float y1 = (ty1 + 1) * T + EAVE;
        return !(x1 < vx0 || x0 > vx1 || y1 < vy0 || y0 - Projection.TILT * RIDGE_Z > vy1);
    }

    private int curA = 255;
    private final float[] joints = new float[1024];

    /** A roof over the tiles tx0..tx1, ty0..ty1 (inclusive); {@code style}: bits 0-2 the tile colour, bit 3 a flat metal roof. */
    void drawRect(Canvas c, int tx0, int ty0, int tx1, int ty1, int style, float alpha, boolean lite) {
        if (alpha <= 0.02f) return;
        float x0 = tx0 * T - EAVE;
        float y0 = ty0 * T - EAVE;
        float x1 = (tx1 + 1) * T + EAVE;
        float y1 = (ty1 + 1) * T + EAVE;
        boolean flat = (style & 8) != 0;
        int base = TILE_COLORS[(style & 7) % TILE_COLORS.length];
        int a = (int) (Math.min(1f, alpha) * 255f);
        curA = a;
        int h = FloorRenderer.hash(tx0 * 3 + 7, ty0 * 5 + 1);
        fill.setStyle(Paint.Style.FILL);
        float lean = Projection.LEAN;
        float tilt = Projection.TILT;
        if (flat) {
            drawFlat(c, x0, y0, x1, y1, h, lite);
            return;
        }
        boolean horizontalRidge = (x1 - x0) >= (y1 - y0);
        int lit = lighten(base, 1.12f);
        int dark = lighten(base, 0.66f);
        float bz = BASE_Z;
        float rz = RIDGE_Z;
        // the two slopes
        float ax0, ay0, ax1, ay1;      // the far (turned away) slope runs from its eave to the ridge
        if (horizontalRidge) {
            float ym = (y0 + y1) * 0.5f;
            fill.setColor(withAlpha(dark, a));
            quad(c, x0 + lean * bz, y0 - tilt * bz, x1 + lean * bz, y0 - tilt * bz, x1 + lean * rz, ym - tilt * rz, x0 + lean * rz, ym - tilt * rz, fill);
            fill.setColor(withAlpha(lit, a));
            quad(c, x0 + lean * rz, ym - tilt * rz, x1 + lean * rz, ym - tilt * rz, x1 + lean * bz, y1 - tilt * bz, x0 + lean * bz, y1 - tilt * bz, fill);
            if (!lite) {
                // light falls off from the ridge to the eave
                slopeShade(c, x0 + lean * rz, ym - tilt * rz, x1 + lean * rz, ym - tilt * rz, x1 + lean * bz, y1 - tilt * bz, x0 + lean * bz, y1 - tilt * bz, true);
                slopeShade(c, x0 + lean * bz, y0 - tilt * bz, x1 + lean * bz, y0 - tilt * bz, x1 + lean * rz, ym - tilt * rz, x0 + lean * rz, ym - tilt * rz, false);
                // rows of shingles, each row's joints shifted half a shingle from the one above
                shingles(c, x0, x1, ym - tilt * rz, y1 - tilt * bz, lean * rz, lean * bz, base, h, 1f);
                shingles(c, x0, x1, ym - tilt * rz, y0 - tilt * bz, lean * rz, lean * bz, base, h + 7, 0.7f);
                skylightAndChimney(c, x0, x1, y0, y1, ym, h, true);
            }
            // the ridge cap, and the eave: a pale fascia board with a shadow under it
            line.setStrokeCap(Paint.Cap.ROUND);
            line.setColor(withAlpha(lighten(base, 0.55f), a));
            line.setStrokeWidth(3.6f);
            c.drawLine(x0 + lean * rz, ym - tilt * rz, x1 + lean * rz, ym - tilt * rz, line);
            line.setColor(withAlpha(0x88FFFFFF, a));
            line.setStrokeWidth(1.3f);
            c.drawLine(x0 + lean * rz, ym - tilt * rz - 1.1f, x1 + lean * rz, ym - tilt * rz - 1.1f, line);
            line.setColor(withAlpha(0x55000000, a));
            line.setStrokeWidth(3.2f);
            c.drawLine(x0 + lean * bz, y1 - tilt * bz + 2.4f, x1 + lean * bz, y1 - tilt * bz + 2.4f, line);
            line.setColor(withAlpha(lighten(base, 1.32f), a));
            line.setStrokeWidth(2.2f);
            c.drawLine(x0 + lean * bz, y1 - tilt * bz, x1 + lean * bz, y1 - tilt * bz, line);
            line.setColor(withAlpha(lighten(base, 0.5f), a));
            line.setStrokeWidth(1.6f);
            c.drawLine(x0 + lean * bz, y0 - tilt * bz, x1 + lean * bz, y0 - tilt * bz, line);
        } else {
            float xm = (x0 + x1) * 0.5f;
            fill.setColor(withAlpha(dark, a));
            quad(c, x0 + lean * bz, y0 - tilt * bz, xm + lean * rz, y0 - tilt * rz, xm + lean * rz, y1 - tilt * rz, x0 + lean * bz, y1 - tilt * bz, fill);
            fill.setColor(withAlpha(lit, a));
            quad(c, xm + lean * rz, y0 - tilt * rz, x1 + lean * bz, y0 - tilt * bz, x1 + lean * bz, y1 - tilt * bz, xm + lean * rz, y1 - tilt * rz, fill);
            if (!lite) {
                slopeShade(c, xm + lean * rz, y0 - tilt * rz, x1 + lean * bz, y0 - tilt * bz, x1 + lean * bz, y1 - tilt * bz, xm + lean * rz, y1 - tilt * rz, true);
                slopeShade(c, x0 + lean * bz, y0 - tilt * bz, xm + lean * rz, y0 - tilt * rz, xm + lean * rz, y1 - tilt * rz, x0 + lean * bz, y1 - tilt * bz, false);
                // shingle rows run up and down the slope here
                line.setStrokeWidth(1f);
                for (int side = 0; side < 2; side++) {
                    float edge = side == 0 ? x1 : x0;
                    int rows = Math.max(3, (int) (Math.abs(edge - xm) / 4.6f));
                    line.setColor(withAlpha(side == 0 ? 0x34000000 : 0x26000000, a));
                    for (int k = 1; k < rows; k++) {
                        float f = k / (float) rows;
                        float zz = rz + (bz - rz) * f;
                        float xx = xm + (edge - xm) * f + lean * zz;
                        c.drawLine(xx, y0 - tilt * zz, xx, y1 - tilt * zz, line);
                    }
                }
                skylightAndChimney(c, x0, x1, y0, y1, xm, h, false);
            }
            line.setStrokeCap(Paint.Cap.ROUND);
            line.setColor(withAlpha(lighten(base, 0.55f), a));
            line.setStrokeWidth(3.6f);
            c.drawLine(xm + lean * rz, y0 - tilt * rz, xm + lean * rz, y1 - tilt * rz, line);
            line.setColor(withAlpha(0x88FFFFFF, a));
            line.setStrokeWidth(1.3f);
            c.drawLine(xm + lean * rz - 1.1f, y0 - tilt * rz, xm + lean * rz - 1.1f, y1 - tilt * rz, line);
            line.setColor(withAlpha(0x55000000, a));
            line.setStrokeWidth(3.2f);
            c.drawLine(x0 + lean * bz, y1 - tilt * bz + 2.4f, xm + lean * rz, y1 - tilt * rz + 2.4f, line);
            c.drawLine(x1 + lean * bz, y1 - tilt * bz + 2.4f, xm + lean * rz, y1 - tilt * rz + 2.4f, line);
            line.setColor(withAlpha(lighten(base, 1.32f), a));
            line.setStrokeWidth(2.2f);
            c.drawLine(x0 + lean * bz, y1 - tilt * bz, xm + lean * rz, y1 - tilt * rz, line);
            c.drawLine(x1 + lean * bz, y1 - tilt * bz, xm + lean * rz, y1 - tilt * rz, line);
        }
    }

    /** Darkens the eave end of a slope and lightens the ridge end, in three overlapping soft steps. */
    private void slopeShade(Canvas c, float ax, float ay, float bx, float by, float cx, float cy, float dx, float dy, boolean lit) {
        // (a, b) is the ridge edge, (d, c) the eave edge of a slope whose edges are bilinear
        for (int k = 0; k < 3; k++) {
            float f0 = k / 3f, f1 = (k + 1) / 3f;
            float x0a = ax + (dx - ax) * f0, y0a = ay + (dy - ay) * f0, x0b = bx + (cx - bx) * f0, y0b = by + (cy - by) * f0;
            float x1a = ax + (dx - ax) * f1, y1a = ay + (dy - ay) * f1, x1b = bx + (cx - bx) * f1, y1b = by + (cy - by) * f1;
            int color = (lit ? (k == 0 ? 0x16FFFFFF : (k == 1 ? 0x00000000 : 0x1E000000)) : (k == 0 ? 0x10FFFFFF : (k == 1 ? 0x00000000 : 0x18000000)));
            if (color == 0) continue;
            fill.setColor(withAlpha(color, curA));
            quad(c, x0a, y0a, x0b, y0b, x1b, y1b, x1a, y1a, fill);
        }
    }

    /**
     * Rows of shingles on a slope that runs from the ridge line (at y = {@code yRidge}) to the eave ({@code yEave}):
     * a seam per row, and short upright joints that alternate half a shingle from row to row.
     */
    private void shingles(Canvas c, float x0, float x1, float yRidge, float yEave, float leanRidge, float leanEave, int base, int h, float strength) {
        float span = Math.abs(yEave - yRidge);
        int rows = Math.max(3, Math.min(9, (int) (span / 4.4f)));
        line.setStrokeCap(Paint.Cap.BUTT);
        line.setStrokeWidth(1f);
        int n = 0;
        for (int k = 1; k <= rows; k++) {
            float f = k / (float) rows;
            float yy = yRidge + (yEave - yRidge) * f;
            float xl = x0 + leanRidge + (leanEave - leanRidge) * f;
            float xr = x1 + leanRidge + (leanEave - leanRidge) * f;
            // each row a touch lighter or darker than the next: the tiles are never quite the same
            int tint = ((h >> (k & 15)) & 1) == 0 ? 0x0CFFFFFF : 0x0C000000;
            fill.setColor(withAlpha(tint, curA));
            float yPrev = yRidge + (yEave - yRidge) * ((k - 1) / (float) rows);
            c.drawRect(xl, Math.min(yPrev, yy), xr, Math.max(yPrev, yy), fill);
            line.setColor(withAlpha((int) (0x40 * strength) << 24, curA));
            c.drawLine(xl, yy, xr, yy, line);
            float stagger = (k & 1) == 0 ? 0f : 6f;
            float yTop = yPrev;
            for (float x = xl + 6f + stagger; x < xr - 2f && n + 4 <= joints.length; x += 12f) {
                joints[n++] = x;
                joints[n++] = yTop;
                joints[n++] = x;
                joints[n++] = yy;
            }
        }
        line.setColor(withAlpha((int) (0x26 * strength) << 24, curA));
        c.drawLines(joints, 0, n, line);
    }

    /** A roof window, and on some houses a brick chimney, standing on the slope that faces the viewer. */
    private void skylightAndChimney(Canvas c, float x0, float x1, float y0, float y1, float mid, int h, boolean horizontal) {
        float lean = Projection.LEAN, tilt = Projection.TILT;
        float bz = BASE_Z, rz = RIDGE_Z;
        if (horizontal) {
            float w = x1 - x0;
            if ((h & 3) != 0 && w > 70f) {
                // a skylight a third of the way down the south slope
                float f0 = 0.28f, f1 = 0.66f;
                float xa = x0 + w * (0.18f + 0.5f * ((h >> 4) & 7) / 7f), xb = xa + 20f;
                float za = rz + (bz - rz) * f0, zb = rz + (bz - rz) * f1;
                float ya = mid + (y1 - mid) * f0, yb = mid + (y1 - mid) * f1;
                fill.setColor(withAlpha(0xFF2B3C52, curA));
                quad(c, xa + lean * za - 1.5f, ya - tilt * za - 1.5f, xb + lean * za + 1.5f, ya - tilt * za - 1.5f, xb + lean * zb + 1.5f, yb - tilt * zb + 1.5f, xa + lean * zb - 1.5f, yb - tilt * zb + 1.5f, fill);
                fill.setColor(withAlpha(0xFF9ED2EA, curA));
                quad(c, xa + lean * za, ya - tilt * za, xb + lean * za, ya - tilt * za, xb + lean * zb, yb - tilt * zb, xa + lean * zb, yb - tilt * zb, fill);
                line.setColor(withAlpha(0xAAFFFFFF, curA));
                line.setStrokeWidth(1.4f);
                c.drawLine(xa + lean * za + 4f, ya - tilt * za + 1f, xa + lean * zb + 10f, yb - tilt * zb - 1f, line);
            }
            if ((h & 1) == 0) {
                float cxw = x0 + w * (0.62f + 0.25f * ((h >> 7) & 3) / 3f);
                float fyw = mid + (y1 - mid) * 0.18f;
                float zr = rz + (bz - rz) * 0.18f;
                chimney(c, cxw, fyw, zr);
            }
        } else {
            float hgt = y1 - y0;
            if ((h & 3) != 0 && hgt > 70f) {
                float f0 = 0.3f, f1 = 0.64f;
                float ya = y0 + hgt * (0.18f + 0.5f * ((h >> 4) & 7) / 7f), yb = ya + 20f;
                float za = rz + (bz - rz) * f0, zb = rz + (bz - rz) * f1;
                float xa = mid + (x1 - mid) * f0, xb = mid + (x1 - mid) * f1;
                fill.setColor(withAlpha(0xFF2B3C52, curA));
                quad(c, xa + lean * za - 1.5f, ya - tilt * za - 1.5f, xb + lean * zb + 1.5f, ya - tilt * zb - 1.5f, xb + lean * zb + 1.5f, yb - tilt * zb + 1.5f, xa + lean * za - 1.5f, yb - tilt * za + 1.5f, fill);
                fill.setColor(withAlpha(0xFF9ED2EA, curA));
                quad(c, xa + lean * za, ya - tilt * za, xb + lean * zb, ya - tilt * zb, xb + lean * zb, yb - tilt * zb, xa + lean * za, yb - tilt * za, fill);
            }
            if ((h & 1) == 0) {
                float cyw = y0 + hgt * (0.3f + 0.4f * ((h >> 7) & 3) / 3f);
                float fxw = mid + (x1 - mid) * 0.2f;
                float zr = rz + (bz - rz) * 0.2f;
                chimney(c, fxw, cyw, zr);
            }
        }
    }

    /** A small brick chimney on the roof at (x, y) with the roof surface at height z. */
    private void chimney(Canvas c, float x, float y, float z) {
        float lean = Projection.LEAN, tilt = Projection.TILT;
        float w = 6.5f, d = 6.5f, z1 = z + 10f;
        float xa = x - w * 0.5f, xb = x + w * 0.5f, ya = y - d * 0.5f, yb = y + d * 0.5f;
        fill.setColor(withAlpha(0xFF8A4A3A, curA));      // south face
        quad(c, xa + lean * z, yb - tilt * z, xb + lean * z, yb - tilt * z, xb + lean * z1, yb - tilt * z1, xa + lean * z1, yb - tilt * z1, fill);
        fill.setColor(withAlpha(0xFF6A362A, curA));      // east face
        quad(c, xb + lean * z, yb - tilt * z, xb + lean * z, ya - tilt * z, xb + lean * z1, ya - tilt * z1, xb + lean * z1, yb - tilt * z1, fill);
        fill.setColor(withAlpha(0xFF3A3A40, curA));      // the cap
        quad(c, xa + lean * z1 - 0.8f, yb - tilt * z1 + 0.8f, xb + lean * z1 + 0.8f, yb - tilt * z1 + 0.8f, xb + lean * z1 + 0.8f, ya - tilt * z1 - 0.8f, xa + lean * z1 - 0.8f, ya - tilt * z1 - 0.8f, fill);
        fill.setColor(withAlpha(0xFF15151A, curA));      // the flue
        quad(c, xa + lean * z1 + 1.6f, yb - tilt * z1 - 0.2f, xb + lean * z1 - 1.6f, yb - tilt * z1 - 0.2f, xb + lean * z1 - 1.6f, ya - tilt * z1 + 1f, xa + lean * z1 + 1.6f, ya - tilt * z1 + 1f, fill);
    }

    /** A flat roof of corrugated metal: the slab, its lip, the ribs, and the things that stand on a roof: vents, an air unit, a hatch. */
    private void drawFlat(Canvas c, float x0, float y0, float x1, float y1, int h, boolean lite) {
        float lean = Projection.LEAN, tilt = Projection.TILT;
        int a = curA;
        float zl = BASE_Z + 2f;
        fill.setColor(withAlpha(0xFF6F7886, a));
        quad(c, x0, y1, x1, y1, x1 + lean * zl, y1 - tilt * zl, x0 + lean * zl, y1 - tilt * zl, fill);      // the south lip
        fill.setColor(withAlpha(0xFF9AA4B2, a));
        quad(c, x0 + lean * zl, y0 - tilt * zl, x1 + lean * zl, y0 - tilt * zl, x1 + lean * zl, y1 - tilt * zl, x0 + lean * zl, y1 - tilt * zl, fill);
        float yy0 = y0 - tilt * zl, yy1 = y1 - tilt * zl, xa = x0 + lean * zl, xb = x1 + lean * zl;
        if (lite) return;
        line.setStrokeCap(Paint.Cap.BUTT);
        line.setColor(withAlpha(0x2E000000, a));
        line.setStrokeWidth(1.2f);
        int n = 0;
        for (float x = xa + 7f; x < xb && n + 4 <= joints.length; x += 9f) {
            joints[n++] = x;
            joints[n++] = yy0;
            joints[n++] = x;
            joints[n++] = yy1;
        }
        c.drawLines(joints, 0, n, line);
        // a darker rim along the far edges and a bright one near
        line.setColor(withAlpha(0x44FFFFFF, a));
        c.drawLine(xa, yy0 + 1f, xb, yy0 + 1f, line);
        line.setColor(withAlpha(0x38000000, a));
        line.setStrokeWidth(2f);
        c.drawLine(xa + 1f, yy0, xa + 1f, yy1, line);
        // roof furniture, placed by the hash of the building: never the same on two roofs
        float w = xb - xa, hh = yy1 - yy0;
        if (w < 40f || hh < 30f) return;
        int count = 1 + (h & 1) + ((h >> 1) & 1);
        for (int k = 0; k < count; k++) {
            int hk = FloorRenderer.hash(h + k * 17, k * 5 + 3);
            float px = xa + 12f + ((hk & 0xFF) / 255f) * (w - 40f);
            float py = yy0 + 10f + (((hk >> 8) & 0xFF) / 255f) * (hh - 32f);
            if ((hk >> 16 & 3) == 0) {
                // a hatch with a pale skylight
                fill.setColor(withAlpha(0xFF59636F, a));
                c.drawRect(px, py, px + 20f, py + 14f, fill);
                fill.setColor(withAlpha(0xFF9ED2EA, a));
                c.drawRect(px + 2f, py + 2f, px + 18f, py + 12f, fill);
                line.setColor(withAlpha(0xAAFFFFFF, a));
                line.setStrokeWidth(1.2f);
                c.drawLine(px + 4f, py + 10f, px + 9f, py + 4f, line);
            } else {
                // an air unit: a box with a fan
                fill.setColor(withAlpha(0xFF4C5560, a));
                c.drawRect(px + 3f, py + 6f, px + 25f, py + 17f, fill);
                fill.setColor(withAlpha(0xFF7E8896, a));
                c.drawRect(px, py, px + 22f, py + 12f, fill);
                fill.setColor(withAlpha(0xFF2A3038, a));
                c.drawCircle(px + 11f, py + 6f, 4.6f, fill);
                line.setColor(withAlpha(0xFFB8C2D0, a));
                line.setStrokeWidth(1.2f);
                float ang = ((hk >> 20) & 7) * 0.4f;
                c.drawLine(px + 11f - (float) Math.cos(ang) * 4f, py + 6f - (float) Math.sin(ang) * 4f, px + 11f + (float) Math.cos(ang) * 4f, py + 6f + (float) Math.sin(ang) * 4f, line);
            }
        }
    }

    private void quad(Canvas c, float ax, float ay, float bx, float by, float cx, float cy, float dx, float dy, Paint paint) {
        path.reset();
        path.moveTo(ax, ay);
        path.lineTo(bx, by);
        path.lineTo(cx, cy);
        path.lineTo(dx, dy);
        path.close();
        c.drawPath(path, paint);
    }

    private static int withAlpha(int argb, int alpha) {
        int a = ((argb >>> 24) * alpha) / 255;
        return (argb & 0x00FFFFFF) | (a << 24);
    }

    private static int lighten(int argb, float k) {
        int r = Math.min(255, (int) (((argb >> 16) & 255) * k));
        int g = Math.min(255, (int) (((argb >> 8) & 255) * k));
        int b = Math.min(255, (int) ((argb & 255) * k));
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }
}
