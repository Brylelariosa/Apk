package com.hazardyard.game.render;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;

import com.hazardyard.game.core.Items;

/**
 * Flat icons for every item: weapons (through {@link GunGlyph}), vests, medicine, materials, food, seeds, tools, car
 * parts, ammunition and things to build. Used on the Pick Up button, on the item pads in the light graphics mode, in
 * the survival inventory and on the minimap. Allocation-free: the caller passes the paint and path to use.
 */
final class ItemGlyph {
    private ItemGlyph() {}

    /** A paint that draws everything in one dark colour: used to lay a rim of that colour round an icon. */
    private static final class Rim extends Paint {
        Rim() {
            super(Paint.ANTI_ALIAS_FLAG);
        }

        @Override
        public void setColor(int c) {
            super.setColor(0xFF0E1218);
        }
    }

    private static final Rim RIM = new Rim();
    private static final float[] RIM_DX = {-1f, 1f, 0f, 0f, -0.7f, 0.7f, -0.7f, 0.7f};
    private static final float[] RIM_DY = {0f, 0f, -1f, 1f, -0.7f, -0.7f, 0.7f, 0.7f};

    /**
     * Draws an item's icon in one art style: a bold dark rim all round (so it stands out on any background and reads as a
     * silhouette), then flat colour with shading, whatever the item. Weapons go through {@link GunGlyph}.
     *
     * @param cx   centre of the icon
     * @param cy   centre of the icon
     * @param size half of the icon's width in pixels
     * @param color the item's colour (the main fill)
     */
    static void draw(Canvas c, Paint fill, Path path, float cx, float cy, float size, int item, int color) {
        if (size >= 5f) {
            float o = Math.max(0.8f, size * 0.075f);
            int n = size >= 14f ? 8 : 4;
            for (int k = 0; k < n; k++) body(c, RIM, path, cx + RIM_DX[k] * o, cy + RIM_DY[k] * o, size, item, color);
        }
        body(c, fill, path, cx, cy, size, item, color);
        fill.setStyle(Paint.Style.FILL);
    }

    /** The icon without the rim (what the rim pass repeats). */
    private static void body(Canvas c, Paint fill, Path path, float cx, float cy, float size, int item, int color) {
        if (Items.isWeapon(item)) {
            GunGlyph.draw(c, fill, path, cx, cy, size, item, color);
            return;
        }
        float u = size;
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(color);
        switch (Items.icon(item)) {
            case Items.I_VEST:
                path.reset();
                poly(path, cx, cy, u, -0.62f, -0.78f, -0.26f, -0.78f, 0f, -0.52f, 0.26f, -0.78f, 0.62f, -0.78f,
                        0.74f, 0.18f, 0.42f, 0.80f, -0.42f, 0.80f, -0.74f, 0.18f);
                c.drawPath(path, fill);
                fill.setColor(0x55000000);
                c.drawRect(cx - 0.05f * u, cy - 0.45f * u, cx + 0.05f * u, cy + 0.78f * u, fill);
                fill.setColor(0x44FFFFFF);
                c.drawRect(cx - 0.50f * u, cy + 0.05f * u, cx - 0.12f * u, cy + 0.32f * u, fill);
                c.drawRect(cx + 0.12f * u, cy + 0.05f * u, cx + 0.50f * u, cy + 0.32f * u, fill);
                break;
            case Items.I_CROSS:
                c.drawRoundRect(cx - 0.85f * u, cy - 0.62f * u, cx + 0.85f * u, cy + 0.62f * u, 0.14f * u, 0.14f * u, fill);
                fill.setColor(0xFFFFFFFF);
                c.drawRect(cx - 0.13f * u, cy - 0.42f * u, cx + 0.13f * u, cy + 0.42f * u, fill);
                c.drawRect(cx - 0.42f * u, cy - 0.13f * u, cx + 0.42f * u, cy + 0.13f * u, fill);
                break;
            case Items.I_BANDAGE:
                fill.setColor(0xFFF2F2F2);
                c.drawRoundRect(cx - 0.80f * u, cy - 0.34f * u, cx + 0.80f * u, cy + 0.34f * u, 0.30f * u, 0.30f * u, fill);
                fill.setColor(color);
                c.drawRect(cx - 0.80f * u, cy - 0.34f * u, cx - 0.40f * u, cy + 0.34f * u, fill);
                fill.setColor(0xFFE04A4A);
                c.drawRect(cx - 0.08f * u, cy - 0.22f * u, cx + 0.08f * u, cy + 0.22f * u, fill);
                c.drawRect(cx - 0.22f * u, cy - 0.08f * u, cx + 0.22f * u, cy + 0.08f * u, fill);
                break;
            case Items.I_LOGS:
                for (int i = 0; i < 3; i++) {
                    float lx = cx + (i == 0 ? -0.42f : (i == 1 ? 0.42f : 0f)) * u;
                    float ly = cy + (i == 2 ? -0.38f : 0.34f) * u;
                    fill.setColor(color);
                    c.drawCircle(lx, ly, 0.42f * u, fill);
                    fill.setColor(0xFFE8C48A);
                    c.drawCircle(lx, ly, 0.27f * u, fill);
                    fill.setColor(color);
                    c.drawCircle(lx, ly, 0.10f * u, fill);
                }
                break;
            case Items.I_ROCK:
                path.reset();
                poly(path, cx, cy, u, -0.82f, 0.45f, -0.60f, -0.25f, -0.10f, -0.70f, 0.50f, -0.50f, 0.85f, 0.10f, 0.62f, 0.62f, -0.30f, 0.70f);
                c.drawPath(path, fill);
                fill.setColor(0x44FFFFFF);
                path.reset();
                poly(path, cx, cy, u, -0.60f, -0.25f, -0.10f, -0.70f, 0.20f, -0.30f, -0.30f, 0.0f);
                c.drawPath(path, fill);
                break;
            case Items.I_FIBER:
                fill.setStyle(Paint.Style.STROKE);
                fill.setStrokeWidth(Math.max(1.5f, 0.16f * u));
                fill.setStrokeCap(Paint.Cap.ROUND);
                c.drawLine(cx - 0.55f * u, cy + 0.7f * u, cx - 0.30f * u, cy - 0.7f * u, fill);
                c.drawLine(cx, cy + 0.7f * u, cx + 0.05f * u, cy - 0.8f * u, fill);
                c.drawLine(cx + 0.55f * u, cy + 0.7f * u, cx + 0.35f * u, cy - 0.65f * u, fill);
                fill.setStyle(Paint.Style.FILL);
                break;
            case Items.I_SCRAP:
                path.reset();
                for (int i = 0; i < 6; i++) {
                    double a = Math.PI / 3 * i + Math.PI / 6;
                    float px = cx + (float) Math.cos(a) * 0.80f * u;
                    float py = cy + (float) Math.sin(a) * 0.80f * u;
                    if (i == 0) path.moveTo(px, py);
                    else path.lineTo(px, py);
                }
                path.close();
                c.drawPath(path, fill);
                fill.setColor(0xAA000000);
                c.drawCircle(cx, cy, 0.30f * u, fill);
                break;
            case Items.I_CLOTH:
                c.drawRoundRect(cx - 0.80f * u, cy - 0.60f * u, cx + 0.80f * u, cy + 0.60f * u, 0.10f * u, 0.10f * u, fill);
                fill.setColor(0x33000000);
                c.drawRect(cx - 0.80f * u, cy - 0.10f * u, cx + 0.80f * u, cy + 0.04f * u, fill);
                c.drawRect(cx - 0.80f * u, cy + 0.30f * u, cx + 0.80f * u, cy + 0.42f * u, fill);
                break;
            case Items.I_NAILS:
                for (int i = 0; i < 3; i++) {
                    float nx = cx + (i - 1) * 0.5f * u;
                    c.drawRect(nx - 0.05f * u, cy - 0.55f * u, nx + 0.05f * u, cy + 0.75f * u, fill);
                    c.drawRect(nx - 0.20f * u, cy - 0.65f * u, nx + 0.20f * u, cy - 0.50f * u, fill);
                }
                break;
            case Items.I_BERRIES:
                c.drawCircle(cx - 0.40f * u, cy + 0.25f * u, 0.38f * u, fill);
                c.drawCircle(cx + 0.38f * u, cy + 0.30f * u, 0.38f * u, fill);
                c.drawCircle(cx, cy - 0.28f * u, 0.38f * u, fill);
                fill.setColor(0xFF4FA24A);
                c.drawRect(cx - 0.05f * u, cy - 0.85f * u, cx + 0.30f * u, cy - 0.62f * u, fill);
                break;
            case Items.I_APPLE:
                c.drawCircle(cx - 0.20f * u, cy + 0.12f * u, 0.52f * u, fill);
                c.drawCircle(cx + 0.20f * u, cy + 0.12f * u, 0.52f * u, fill);
                fill.setColor(0xFF6B4A2A);
                c.drawRect(cx - 0.05f * u, cy - 0.75f * u, cx + 0.07f * u, cy - 0.35f * u, fill);
                fill.setColor(0xFF4FA24A);
                path.reset();
                poly(path, cx, cy, u, 0.07f, -0.60f, 0.55f, -0.80f, 0.40f, -0.40f);
                c.drawPath(path, fill);
                break;
            case Items.I_CARROT:
                path.reset();
                poly(path, cx, cy, u, -0.15f, -0.45f, 0.45f, -0.20f, -0.65f, 0.85f);
                c.drawPath(path, fill);
                fill.setColor(0xFF4FA24A);
                c.drawRect(cx - 0.35f * u, cy - 0.85f * u, cx - 0.20f * u, cy - 0.40f * u, fill);
                c.drawRect(cx - 0.12f * u, cy - 0.95f * u, cx + 0.03f * u, cy - 0.42f * u, fill);
                c.drawRect(cx + 0.10f * u, cy - 0.80f * u, cx + 0.25f * u, cy - 0.35f * u, fill);
                break;
            case Items.I_POTATO:
                c.drawRoundRect(cx - 0.72f * u, cy - 0.50f * u, cx + 0.72f * u, cy + 0.50f * u, 0.5f * u, 0.5f * u, fill);
                fill.setColor(0x55000000);
                c.drawCircle(cx - 0.25f * u, cy - 0.10f * u, 0.07f * u, fill);
                c.drawCircle(cx + 0.28f * u, cy + 0.15f * u, 0.07f * u, fill);
                c.drawCircle(cx + 0.05f * u, cy - 0.28f * u, 0.06f * u, fill);
                break;
            case Items.I_FISH:
                c.drawOval(cx - 0.80f * u, cy - 0.40f * u, cx + 0.45f * u, cy + 0.40f * u, fill);
                path.reset();
                poly(path, cx, cy, u, 0.30f, 0.0f, 0.90f, -0.42f, 0.90f, 0.42f);
                c.drawPath(path, fill);
                fill.setColor(0xFF111111);
                c.drawCircle(cx - 0.50f * u, cy - 0.10f * u, 0.07f * u, fill);
                break;
            case Items.I_CAN:
                
                fill.setColor(0xFFB8BCC4);
                c.drawRoundRect(cx - 0.50f * u, cy - 0.72f * u, cx + 0.50f * u, cy + 0.72f * u, 0.10f * u, 0.10f * u, fill);
                fill.setColor(color);
                c.drawRect(cx - 0.50f * u, cy - 0.30f * u, cx + 0.50f * u, cy + 0.34f * u, fill);
                break;
            case Items.I_BREAD:
                c.drawRoundRect(cx - 0.85f * u, cy - 0.45f * u, cx + 0.85f * u, cy + 0.45f * u, 0.45f * u, 0.45f * u, fill);
                fill.setColor(0x44000000);
                c.drawRect(cx - 0.45f * u, cy - 0.35f * u, cx - 0.35f * u, cy + 0.0f, fill);
                c.drawRect(cx - 0.05f * u, cy - 0.38f * u, cx + 0.05f * u, cy + 0.0f, fill);
                c.drawRect(cx + 0.35f * u, cy - 0.35f * u, cx + 0.45f * u, cy + 0.0f, fill);
                break;
            case Items.I_SEEDS:
                c.drawCircle(cx, cy + 0.25f * u, 0.62f * u, fill);
                c.drawRect(cx - 0.18f * u, cy - 0.55f * u, cx + 0.18f * u, cy - 0.15f * u, fill);
                fill.setColor(0xFF6B4A2A);
                c.drawRect(cx - 0.30f * u, cy - 0.38f * u, cx + 0.30f * u, cy - 0.28f * u, fill);
                fill.setColor(0xFF3A2A18);
                c.drawCircle(cx - 0.22f * u, cy + 0.30f * u, 0.07f * u, fill);
                c.drawCircle(cx + 0.10f * u, cy + 0.15f * u, 0.07f * u, fill);
                c.drawCircle(cx + 0.18f * u, cy + 0.45f * u, 0.07f * u, fill);
                break;
            case Items.I_HOE:
                fill.setStyle(Paint.Style.STROKE);
                fill.setStrokeWidth(Math.max(1.6f, 0.14f * u));
                fill.setStrokeCap(Paint.Cap.ROUND);
                c.drawLine(cx - 0.75f * u, cy + 0.75f * u, cx + 0.55f * u, cy - 0.65f * u, fill);
                fill.setStyle(Paint.Style.FILL);
                path.reset();
                poly(path, cx, cy, u, 0.30f, -0.80f, 0.85f, -0.30f, 0.65f, -0.15f, 0.25f, -0.55f);
                c.drawPath(path, fill);
                break;
            case Items.I_ROD:
                fill.setStyle(Paint.Style.STROKE);
                fill.setStrokeWidth(Math.max(1.5f, 0.12f * u));
                fill.setStrokeCap(Paint.Cap.ROUND);
                c.drawLine(cx - 0.85f * u, cy + 0.80f * u, cx + 0.70f * u, cy - 0.75f * u, fill);
                fill.setStrokeWidth(Math.max(1f, 0.05f * u));
                c.drawLine(cx + 0.70f * u, cy - 0.75f * u, cx + 0.85f * u, cy + 0.25f * u, fill);
                fill.setStyle(Paint.Style.FILL);
                fill.setColor(0xFFE04A4A);
                c.drawCircle(cx + 0.85f * u, cy + 0.35f * u, 0.16f * u, fill);
                break;
            case Items.I_WRENCH:
                fill.setStyle(Paint.Style.STROKE);
                fill.setStrokeWidth(Math.max(1.8f, 0.2f * u));
                fill.setStrokeCap(Paint.Cap.ROUND);
                c.drawLine(cx - 0.70f * u, cy + 0.70f * u, cx + 0.35f * u, cy - 0.35f * u, fill);
                fill.setStyle(Paint.Style.FILL);
                c.drawCircle(cx + 0.45f * u, cy - 0.45f * u, 0.38f * u, fill);
                fill.setColor(0xFF1A2028);
                path.reset();
                poly(path, cx, cy, u, 0.45f, -0.45f, 0.85f, -0.62f, 0.62f, -0.85f);
                c.drawPath(path, fill);
                break;
            case Items.I_TIRE:
                fill.setColor(0xFF2A2E36);
                c.drawCircle(cx, cy, 0.85f * u, fill);
                fill.setColor(color);
                c.drawCircle(cx, cy, 0.52f * u, fill);
                fill.setColor(0xFF9AA0A8);
                c.drawCircle(cx, cy, 0.28f * u, fill);
                break;
            case Items.I_BATTERY:
                c.drawRoundRect(cx - 0.85f * u, cy - 0.45f * u, cx + 0.85f * u, cy + 0.60f * u, 0.08f * u, 0.08f * u, fill);
                fill.setColor(0xFF3A3F48);
                c.drawRect(cx - 0.60f * u, cy - 0.70f * u, cx - 0.30f * u, cy - 0.45f * u, fill);
                c.drawRect(cx + 0.30f * u, cy - 0.70f * u, cx + 0.60f * u, cy - 0.45f * u, fill);
                fill.setColor(0xFF1A2028);
                c.drawRect(cx - 0.10f * u, cy - 0.05f * u, cx + 0.50f * u, cy + 0.07f * u, fill);
                c.drawRect(cx + 0.14f * u, cy - 0.30f * u, cx + 0.26f * u, cy + 0.32f * u, fill);
                break;
            case Items.I_ENGINE:
                for (int i = 0; i < 8; i++) {
                    double a = Math.PI / 4 * i;
                    float px = cx + (float) Math.cos(a) * 0.72f * u;
                    float py = cy + (float) Math.sin(a) * 0.72f * u;
                    c.drawRect(px - 0.16f * u, py - 0.16f * u, px + 0.16f * u, py + 0.16f * u, fill);
                }
                c.drawCircle(cx, cy, 0.62f * u, fill);
                fill.setColor(0xFF1A2028);
                c.drawCircle(cx, cy, 0.26f * u, fill);
                break;
            case Items.I_GAS:
                c.drawRoundRect(cx - 0.62f * u, cy - 0.60f * u, cx + 0.62f * u, cy + 0.80f * u, 0.12f * u, 0.12f * u, fill);
                fill.setColor(0xFF2A2E36);
                c.drawRect(cx - 0.30f * u, cy - 0.85f * u, cx - 0.02f * u, cy - 0.60f * u, fill);
                c.drawRect(cx + 0.10f * u, cy - 0.78f * u, cx + 0.46f * u, cy - 0.60f * u, fill);
                fill.setColor(0x55000000);
                c.drawRect(cx - 0.45f * u, cy - 0.10f * u, cx + 0.45f * u, cy + 0.0f, fill);
                c.drawRect(cx - 0.45f * u, cy + 0.30f * u, cx + 0.45f * u, cy + 0.40f * u, fill);
                break;
            case Items.I_BULLETS:
                for (int i = 0; i < 3; i++) {
                    float bx = cx + (i - 1) * 0.55f * u;
                    fill.setColor(0xFFC8A040);
                    c.drawRect(bx - 0.17f * u, cy - 0.05f * u, bx + 0.17f * u, cy + 0.80f * u, fill);
                    fill.setColor(color);
                    c.drawRoundRect(bx - 0.17f * u, cy - 0.78f * u, bx + 0.17f * u, cy + 0.0f, 0.17f * u, 0.17f * u, fill);
                }
                break;
            case Items.I_SHELLS:
                for (int i = 0; i < 2; i++) {
                    float bx = cx + (i == 0 ? -0.40f : 0.40f) * u;
                    fill.setColor(color);
                    c.drawRoundRect(bx - 0.26f * u, cy - 0.78f * u, bx + 0.26f * u, cy + 0.30f * u, 0.08f * u, 0.08f * u, fill);
                    fill.setColor(0xFFC8A040);
                    c.drawRect(bx - 0.26f * u, cy + 0.30f * u, bx + 0.26f * u, cy + 0.78f * u, fill);
                }
                break;
            case Items.I_WALL:
                c.drawRect(cx - 0.85f * u, cy - 0.70f * u, cx + 0.85f * u, cy + 0.70f * u, fill);
                fill.setColor(0x55000000);
                for (int r = 1; r < 4; r++) c.drawRect(cx - 0.85f * u, cy - 0.70f * u + r * 0.35f * u - 0.03f * u, cx + 0.85f * u, cy - 0.70f * u + r * 0.35f * u + 0.03f * u, fill);
                c.drawRect(cx - 0.03f * u, cy - 0.70f * u, cx + 0.03f * u, cy - 0.35f * u, fill);
                c.drawRect(cx - 0.45f * u, cy - 0.35f * u, cx - 0.39f * u, cy + 0.0f, fill);
                c.drawRect(cx + 0.40f * u, cy + 0.0f, cx + 0.46f * u, cy + 0.35f * u, fill);
                break;
            case Items.I_DOOR:
                c.drawRect(cx - 0.55f * u, cy - 0.85f * u, cx + 0.55f * u, cy + 0.85f * u, fill);
                fill.setColor(0x44000000);
                c.drawRect(cx - 0.38f * u, cy - 0.68f * u, cx + 0.38f * u, cy - 0.10f * u, fill);
                c.drawRect(cx - 0.38f * u, cy + 0.05f * u, cx + 0.38f * u, cy + 0.68f * u, fill);
                fill.setColor(0xFFE8D090);
                c.drawCircle(cx + 0.36f * u, cy, 0.09f * u, fill);
                break;
            case Items.I_FLOOR:
                c.drawRect(cx - 0.85f * u, cy - 0.70f * u, cx + 0.85f * u, cy + 0.70f * u, fill);
                fill.setColor(0x55000000);
                for (int r = 1; r < 4; r++) c.drawRect(cx - 0.85f * u, cy - 0.70f * u + r * 0.35f * u - 0.03f * u, cx + 0.85f * u, cy - 0.70f * u + r * 0.35f * u + 0.03f * u, fill);
                break;
            case Items.I_FIRE:
                fill.setColor(0xFF6B4A2A);
                c.drawRoundRect(cx - 0.80f * u, cy + 0.40f * u, cx + 0.80f * u, cy + 0.70f * u, 0.12f * u, 0.12f * u, fill);
                fill.setColor(color);
                path.reset();
                poly(path, cx, cy, u, 0f, -0.85f, 0.50f, 0.0f, 0.38f, 0.45f, -0.38f, 0.45f, -0.50f, 0.0f);
                c.drawPath(path, fill);
                fill.setColor(0xFFFFE070);
                path.reset();
                poly(path, cx, cy, u, 0f, -0.35f, 0.24f, 0.10f, 0.16f, 0.42f, -0.16f, 0.42f, -0.24f, 0.10f);
                c.drawPath(path, fill);
                break;
            case Items.I_BENCH:
                c.drawRect(cx - 0.90f * u, cy - 0.30f * u, cx + 0.90f * u, cy - 0.05f * u, fill);
                c.drawRect(cx - 0.75f * u, cy - 0.05f * u, cx - 0.55f * u, cy + 0.75f * u, fill);
                c.drawRect(cx + 0.55f * u, cy - 0.05f * u, cx + 0.75f * u, cy + 0.75f * u, fill);
                fill.setColor(0xFFB0B8C4);
                c.drawRect(cx - 0.30f * u, cy - 0.62f * u, cx + 0.10f * u, cy - 0.30f * u, fill);
                break;
            case Items.I_PACK:
                backpack(c, fill, cx, cy, u, color);
                break;
            case Items.I_CAR: {
                // a car seen from the side: body, cabin with a window, wheels, a headlight
                fill.setColor(shadeOf(color, 0.78f));
                c.drawRoundRect(cx - 1.0f * u, cy - 0.12f * u, cx + 1.0f * u, cy + 0.52f * u, 0.22f * u, 0.22f * u, fill);
                fill.setColor(color);
                c.drawRoundRect(cx - 1.0f * u, cy - 0.12f * u, cx + 1.0f * u, cy + 0.36f * u, 0.22f * u, 0.22f * u, fill);
                path.reset();
                path.moveTo(cx - 0.56f * u, cy - 0.10f * u);
                path.lineTo(cx - 0.34f * u, cy - 0.62f * u);
                path.lineTo(cx + 0.36f * u, cy - 0.62f * u);
                path.lineTo(cx + 0.66f * u, cy - 0.10f * u);
                path.close();
                fill.setColor(color);
                c.drawPath(path, fill);
                fill.setColor(0xFFB8E0F4);
                path.reset();
                path.moveTo(cx - 0.44f * u, cy - 0.14f * u);
                path.lineTo(cx - 0.28f * u, cy - 0.52f * u);
                path.lineTo(cx + 0.30f * u, cy - 0.52f * u);
                path.lineTo(cx + 0.52f * u, cy - 0.14f * u);
                path.close();
                c.drawPath(path, fill);
                fill.setColor(0xFF1E2126);
                c.drawCircle(cx - 0.56f * u, cy + 0.50f * u, 0.27f * u, fill);
                c.drawCircle(cx + 0.58f * u, cy + 0.50f * u, 0.27f * u, fill);
                fill.setColor(0xFFC8CCD2);
                c.drawCircle(cx - 0.56f * u, cy + 0.50f * u, 0.11f * u, fill);
                c.drawCircle(cx + 0.58f * u, cy + 0.50f * u, 0.11f * u, fill);
                fill.setColor(0xFFFFF2B0);
                c.drawRect(cx + 0.88f * u, cy - 0.02f * u, cx + 1.0f * u, cy + 0.14f * u, fill);
                break;
            }
            case Items.I_AMMOBOX:
                // a metal crate with the brass of a few rounds standing in it
                fill.setColor(0xFF4E5B3C);
                c.drawRoundRect(cx - 0.88f * u, cy - 0.10f * u, cx + 0.88f * u, cy + 0.72f * u, 0.12f * u, 0.12f * u, fill);
                fill.setColor(color);
                c.drawRect(cx - 0.88f * u, cy - 0.10f * u, cx + 0.88f * u, cy + 0.10f * u, fill);
                fill.setColor(0x55000000);
                c.drawRect(cx - 0.62f * u, cy + 0.22f * u, cx + 0.62f * u, cy + 0.28f * u, fill);
                for (int i = 0; i < 3; i++) {
                    float bx = cx + (i - 1) * 0.50f * u;
                    fill.setColor(0xFFD8B04A);
                    c.drawRect(bx - 0.14f * u, cy - 0.62f * u, bx + 0.14f * u, cy - 0.08f * u, fill);
                    fill.setColor(0xFFB8764A);
                    c.drawRoundRect(bx - 0.14f * u, cy - 0.86f * u, bx + 0.14f * u, cy - 0.52f * u, 0.14f * u, 0.14f * u, fill);
                }
                break;
            default:
                c.drawCircle(cx, cy, 0.6f * u, fill);
                break;
        }
        fill.setStyle(Paint.Style.FILL);
    }

    /** A backpack: the body with a flap, two pockets and the straps; used by the bag button and the Battleground gear. */
    static void drawBackpack(Canvas c, Paint fill, Path path, float cx, float cy, float size, int color) {
        if (size >= 5f) {
            float o = Math.max(0.8f, size * 0.075f);
            for (int k = 0; k < 8; k++) backpack(c, RIM, cx + RIM_DX[k] * o, cy + RIM_DY[k] * o, size, color);
        }
        backpack(c, fill, cx, cy, size, color);
        fill.setStyle(Paint.Style.FILL);
    }

    private static void backpack(Canvas c, Paint fill, float cx, float cy, float u, int color) {
        fill.setStyle(Paint.Style.FILL);
        // carry loop and body
        fill.setColor(shadeOf(color, 0.7f));
        c.drawRoundRect(cx - 0.20f * u, cy - 1.0f * u, cx + 0.20f * u, cy - 0.74f * u, 0.1f * u, 0.1f * u, fill);
        fill.setColor(color);
        c.drawRoundRect(cx - 0.72f * u, cy - 0.86f * u, cx + 0.72f * u, cy + 0.88f * u, 0.34f * u, 0.34f * u, fill);
        // the flap with a buckle
        fill.setColor(shadeOf(color, 0.82f));
        c.drawRoundRect(cx - 0.72f * u, cy - 0.86f * u, cx + 0.72f * u, cy - 0.12f * u, 0.34f * u, 0.34f * u, fill);
        fill.setColor(0xFFE8D090);
        c.drawRect(cx - 0.12f * u, cy - 0.22f * u, cx + 0.12f * u, cy + 0.02f * u, fill);
        // pocket
        fill.setColor(shadeOf(color, 0.68f));
        c.drawRoundRect(cx - 0.50f * u, cy + 0.16f * u, cx + 0.50f * u, cy + 0.74f * u, 0.16f * u, 0.16f * u, fill);
        fill.setColor(0x44FFFFFF);
        c.drawRect(cx - 0.44f * u, cy + 0.20f * u, cx + 0.44f * u, cy + 0.26f * u, fill);
    }

    private static int shadeOf(int c, float k) {
        int r = (int) (((c >> 16) & 0xFF) * k), g = (int) (((c >> 8) & 0xFF) * k), b = (int) ((c & 0xFF) * k);
        return (c & 0xFF000000) | (r << 16) | (g << 8) | b;
    }

    /** Appends a closed polygon given as x/y pairs in units of {@code u} around (cx, cy). */
    private static void poly(Path path, float cx, float cy, float u, float... xy) {
        for (int i = 0; i + 1 < xy.length; i += 2) {
            float x = cx + xy[i] * u;
            float y = cy + xy[i + 1] * u;
            if (i == 0) path.moveTo(x, y);
            else path.lineTo(x, y);
        }
        path.close();
    }
}
