package com.hazardyard.game.render.model;

/**
 * Turns meshes into drawable polygons for one object (a soldier, a pickup): it moves, rotates and
 * projects the faces, throws away the ones that turn away from the viewer, lights the rest and sorts
 * them back to front. Reusable and allocation-free after construction; one instance per thread.
 */
public final class SceneBuffer {
    /** Number of independently animated parts (body, two legs, gun). */
    public static final int GROUPS = 4;
    private static final int GUN_GROUP = 3;

    private static final float AMBIENT = 0.46f;
    private static final float LIGHT_X = -0.46f, LIGHT_Y = -0.38f, LIGHT_Z = 0.80f;
    private static final float LIGHT_NORM;

    static {
        LIGHT_NORM = (float) Math.sqrt(LIGHT_X * LIGHT_X + LIGHT_Y * LIGHT_Y + LIGHT_Z * LIGHT_Z);
    }

    private final float[] xs;
    private final float[] ys;
    private final int[] faceOffset;
    private final int[] faceCount;
    private final int[] faceColor;
    private final float[] faceDepth;
    private final int[] order;
    private int faces;
    private int verts;

    // per-group animation: yaw (radians), offset in model space
    public final float[] yaw = new float[GROUPS];
    public final float[] offX = new float[GROUPS];
    public final float[] offY = new float[GROUPS];
    public final float[] offZ = new float[GROUPS];

    /**
     * Forward tumble of the whole object, in radians: it rotates about its own side axis (the one
     * through the pivot, at height {@link #pitchPivotZ}) before the groups are turned by their yaw.
     * A full turn is a somersault. 0 leaves the object untouched.
     */
    public float pitch;
    public float pitchPivotZ = 13f;

    /**
     * Tilt of the weapon group only (melee: a blade turned flat, a chop coming down): rotation about the grip, first a roll
     * about the forward axis, then a pitch about the side axis (positive tips the forward end down). 0 leaves it alone.
     */
    public float gunPitch, gunRoll;
    public float gunPivX, gunPivY, gunPivZ;

    private final float[] cs = new float[GROUPS];
    private final float[] sn = new float[GROUPS];

    public SceneBuffer(int maxFaces, int maxVerts) {
        xs = new float[maxVerts];
        ys = new float[maxVerts];
        faceOffset = new int[maxFaces];
        faceCount = new int[maxFaces];
        faceColor = new int[maxFaces];
        faceDepth = new float[maxFaces];
        order = new int[maxFaces];
    }

    /** Clears the polygons and resets every group's animation to neutral. */
    public void begin() {
        faces = 0;
        verts = 0;
        for (int g = 0; g < GROUPS; g++) {
            yaw[g] = 0f;
            offX[g] = 0f;
            offY[g] = 0f;
            offZ[g] = 0f;
        }
        pitch = 0f;
        gunPitch = 0f;
        gunRoll = 0f;
    }

    public void setAllYaw(float a) {
        for (int g = 0; g < GROUPS; g++) yaw[g] = a;
    }

    public int faceCount() {
        return faces;
    }

    /**
     * Adds a mesh placed at world position (wx, wy) at height wz, uniformly scaled.
     *
     * @param accent colour used by accent faces (the player's colour)
     * @param whiten 0..1: blends the final colours towards white (hit flash)
     */
    public void addMesh(Mesh m, float wx, float wy, float wz, float scale, int accent, float whiten) {
        for (int g = 0; g < GROUPS; g++) {
            cs[g] = (float) Math.cos(yaw[g]);
            sn[g] = (float) Math.sin(yaw[g]);
        }
        final boolean tumbling = pitch != 0f;
        final float cp = tumbling ? (float) Math.cos(pitch) : 1f;
        final float sp = tumbling ? (float) Math.sin(pitch) : 0f;
        final float pz = pitchPivotZ;
        final boolean gunTilt = gunPitch != 0f || gunRoll != 0f;
        final float gcp = (float) Math.cos(gunPitch), gsp = (float) Math.sin(gunPitch);
        final float gcr = (float) Math.cos(gunRoll), gsr = (float) Math.sin(gunRoll);
        for (int f = 0; f < m.faceCount; f++) {
            if (faces >= faceOffset.length) return;
            int g = m.group[f];
            float c = cs[g], s = sn[g];
            float nx = m.normals[f * 3], ny = m.normals[f * 3 + 1], nz = m.normals[f * 3 + 2];
            final boolean tilted = gunTilt && g == GUN_GROUP;
            if (tilted) {
                float ry = ny * gcr - nz * gsr;
                float rz = ny * gsr + nz * gcr;
                ny = ry;
                nz = rz;
                float px2 = nx * gcp + nz * gsp;
                nz = -nx * gsp + nz * gcp;
                nx = px2;
            }
            if (tumbling) {
                float tx = nx * cp + nz * sp;
                nz = -nx * sp + nz * cp;
                nx = tx;
            }
            float rnx = nx * c - ny * s;
            float rny = nx * s + ny * c;
            if (!Projection.facesViewer(rnx, rny, nz)) continue;
            int v0 = m.faceStart[f];
            int n = m.faceStart[f + 1] - v0;
            if (verts + n > xs.length) return;

            int base = (m.flags[f] & Mesh.FLAG_ACCENT) != 0 ? accent : m.color[f];
            int argb;
            if ((m.flags[f] & Mesh.FLAG_EMISSIVE) != 0) {
                argb = base;
            } else {
                float diffuse = (rnx * LIGHT_X + rny * LIGHT_Y + nz * LIGHT_Z) / LIGHT_NORM;
                if (diffuse < 0f) diffuse = 0f;
                argb = shade(base, AMBIENT + (1.12f - AMBIENT) * diffuse);
            }
            if (whiten > 0f) argb = mixWhite(argb, whiten);

            float depth = 0f;
            faceOffset[faces] = verts;
            faceCount[faces] = n;
            for (int k = 0; k < n; k++) {
                int vi = (v0 + k) * 3;
                float x = m.verts[vi];
                float y = m.verts[vi + 1];
                float z = m.verts[vi + 2];
                if (tilted) {
                    float ty = y - gunPivY, tz = z - gunPivZ, tx = x - gunPivX;
                    float ry = ty * gcr - tz * gsr;
                    float rz = ty * gsr + tz * gcr;
                    float rx = tx * gcp + rz * gsp;
                    rz = -tx * gsp + rz * gcp;
                    x = rx + gunPivX;
                    y = ry + gunPivY;
                    z = rz + gunPivZ;
                }
                x += offX[g];
                y += offY[g];
                z += offZ[g];
                if (tumbling) {
                    float zr = z - pz;
                    float tx = x * cp + zr * sp;
                    z = -x * sp + zr * cp + pz;
                    x = tx;
                }
                float X = (x * c - y * s) * scale + wx;
                float Y = (x * s + y * c) * scale + wy;
                float Z = z * scale + wz;
                xs[verts] = Projection.screenX(X, Z);
                ys[verts] = Projection.screenY(Y, Z);
                depth += Projection.nearness(X, Y, Z);
                verts++;
            }
            faceDepth[faces] = depth / n;
            faceColor[faces] = argb;
            faces++;
        }
    }


    // ------------------------------------------------------------------ limbs built on the fly

    private final int[] qi = new int[4];
    private final float[] bp = new float[24];
    private final float[] fx = new float[8];
    private final float[] fy = new float[8];
    private final float[] fz = new float[8];

    /**
     * Adds a straight box from point a to point b ({@code w} wide, {@code h} tall) in the model space of {@code group}
     * (so it moves with that group's yaw and offset). Used for arms that reach wherever the weapon hand is.
     */
    public void addBeam(int g, float ax, float ay, float az, float bx, float by, float bz, float w, float h, int argb,
                        float wx, float wy, float wz, float scale, float whiten) {
        float dx = bx - ax, dy = by - ay, dz = bz - az;
        float len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1e-4f) return;
        dx /= len; dy /= len; dz /= len;
        float sx = -dy, sy = dx, sz = 0f;
        float sl = (float) Math.sqrt(sx * sx + sy * sy);
        if (sl < 1e-4f) { sx = 0f; sy = 1f; sl = 1f; }
        sx /= sl; sy /= sl;
        float ux = dy * sz - dz * sy, uy = dz * sx - dx * sz, uz = dx * sy - dy * sx;
        float ul = (float) Math.sqrt(ux * ux + uy * uy + uz * uz);
        ux /= ul; uy /= ul; uz /= ul;
        if (uz < 0f) { ux = -ux; uy = -uy; uz = -uz; sx = -sx; sy = -sy; sz = -sz; }
        float hw = w * 0.5f, hh = h * 0.5f;
        int n = 0;
        for (int e = 0; e < 2; e++) {
            float cx = e == 0 ? ax : bx, cy = e == 0 ? ay : by, cz = e == 0 ? az : bz;
            for (int i = 0; i < 4; i++) {
                float ws = (i == 0 || i == 3) ? -hw : hw;
                float hs = (i < 2) ? -hh : hh;
                bp[n++] = cx + sx * ws + ux * hs;
                bp[n++] = cy + sy * ws + uy * hs;
                bp[n++] = cz + sz * ws + uz * hs;
            }
        }
        float c = (float) Math.cos(yaw[g]), s = (float) Math.sin(yaw[g]);
        for (int i = 0; i < 8; i++) {
            float x = bp[i * 3] + offX[g], y = bp[i * 3 + 1] + offY[g], z = bp[i * 3 + 2] + offZ[g];
            fx[i] = (x * c - y * s) * scale + wx;
            fy[i] = (x * s + y * c) * scale + wy;
            fz[i] = z * scale + wz;
        }
        float rux = ux * c - uy * s, ruy = ux * s + uy * c;
        float rsx = sx * c - sy * s, rsy = sx * s + sy * c;
        float rdx = dx * c - dy * s, rdy = dx * s + dy * c;
        pushQuad(3, 2, 6, 7, rux, ruy, uz, argb, whiten);
        pushQuad(0, 1, 5, 4, -rux, -ruy, -uz, argb, whiten);
        pushQuad(1, 2, 6, 5, rsx, rsy, sz, argb, whiten);
        pushQuad(0, 3, 7, 4, -rsx, -rsy, -sz, argb, whiten);
        pushQuad(4, 5, 6, 7, rdx, rdy, dz, argb, whiten);
        pushQuad(0, 1, 2, 3, -rdx, -rdy, -dz, argb, whiten);
    }

    private void pushQuad(int i0, int i1, int i2, int i3, float nx, float ny, float nz, int base, float whiten) {
        if (faces >= faceOffset.length || verts + 4 > xs.length) return;
        if (!Projection.facesViewer(nx, ny, nz)) return;
        float diffuse = (nx * LIGHT_X + ny * LIGHT_Y + nz * LIGHT_Z) / LIGHT_NORM;
        if (diffuse < 0f) diffuse = 0f;
        int argb = shade(base, AMBIENT + (1.12f - AMBIENT) * diffuse);
        if (whiten > 0f) argb = mixWhite(argb, whiten);
        faceOffset[faces] = verts;
        faceCount[faces] = 4;
        float depth = 0f;
        qi[0] = i0;
        qi[1] = i1;
        qi[2] = i2;
        qi[3] = i3;
        for (int k = 0; k < 4; k++) {
            int i = qi[k];
            xs[verts] = Projection.screenX(fx[i], fz[i]);
            ys[verts] = Projection.screenY(fy[i], fz[i]);
            depth += Projection.nearness(fx[i], fy[i], fz[i]);
            verts++;
        }
        faceDepth[faces] = depth * 0.25f;
        faceColor[faces] = argb;
        faces++;
    }

    /** Sorts the polygons far to near and hands them to the sink. */
    public void flush(FaceSink sink) {
        for (int i = 0; i < faces; i++) {
            int j = i - 1;
            float d = faceDepth[i];
            while (j >= 0 && faceDepth[order[j]] > d) {
                order[j + 1] = order[j];
                j--;
            }
            order[j + 1] = i;
        }
        for (int i = 0; i < faces; i++) {
            int f = order[i];
            sink.polygon(xs, ys, faceOffset[f], faceCount[f], faceColor[f]);
        }
    }

    // ------------------------------------------------------------------ colour helpers

    /** Multiplies the colour by {@code k}; shadows get a slight cool tint, highlights a warm one. */
    public static int shade(int argb, float k) {
        int a = argb >>> 24;
        float r = ((argb >> 16) & 0xFF) * k;
        float g = ((argb >> 8) & 0xFF) * k;
        float b = (argb & 0xFF) * k;
        if (k < 1f) {
            float t = 1f - k;
            r -= r * 0.06f * t * 2f;
            b += (255f - b) * 0.05f * t * 2f;
        }
        return (a << 24) | (clamp255(r) << 16) | (clamp255(g) << 8) | clamp255(b);
    }

    public static int mixWhite(int argb, float t) {
        int a = argb >>> 24;
        int r = (argb >> 16) & 0xFF, g = (argb >> 8) & 0xFF, b = argb & 0xFF;
        r += (int) ((255 - r) * t);
        g += (int) ((255 - g) * t);
        b += (int) ((255 - b) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    private static int clamp255(float v) {
        return v < 0f ? 0 : (v > 255f ? 255 : (int) v);
    }
}
