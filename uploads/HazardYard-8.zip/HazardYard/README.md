# Hazard Yard

Top-down arena shooter for Android (pure framework code, no dependencies). Play solo against bots, or
2-4 players on the same Wi-Fi.

## What is new in 1.7
**Battleground**
- **You choose where to drop.** The match opens on a map of the island (`render/HudRenderer.drawDropSelect`, touch in
  `input/DropUi`): tap or drag to put the parachute marker where you want to land, the white circle shows where the first safe
  zone will be, a clock counts the 16 seconds (`GameConfig.DROP_SELECT_SECONDS`) and *Drop here* ends the choice early; the
  match starts as soon as every human is ready (a player who never picks lands at their spawn point). The bots choose too, spread
  out and with a taste for the towns (`GameWorld.chooseBotDrop`).
  ![Choosing the drop](docs/battleground-drop-select.png)
- **The fall.** Everybody starts 320 units up over their chosen place, in freefall (rushing air streaks) until 110 units, then a
  striped parachute opens and slows the fall; the whole drop takes about 4 seconds. You can steer with the move stick, nothing can
  hurt you in the air and you cannot shoot, the camera pulls back a little, and the soldier, the nameplate and a wide soft shadow
  follow the height. You land on the nearest standable ground (never in water or a wall) with 1.5 s of protection
  (`GameWorld.updateAirborne`, `UnitRenderer.drawParachute`).
  ![The fall](docs/battleground-fall.png)
- **Loot from the fallen.** Whoever goes down (player or bot) leaves everything they carried in a ring round the body: every gun with
  the rounds it had, the vest, the backpack, and now and then a first-aid kit or an ammo crate (`GameWorld.dropLoot`). They are
  ordinary pads: walk up and press Pick Up.
- **Guns stay on the ground.** Picking up a gun when both slots are taken puts the replaced gun down at your feet, still loaded
  (`GameWorld.giveWeapon` / `dropWeapon`); a bot that swaps its gun does the same. Take it again and it swaps back. The ground holds
  48 such items at a time (`GameConfig.LOOT_SLOTS`); when it is full the oldest is recycled. Map pads are unchanged.
- **Over the network**: dropped items travel as one reliable `S_LOOT` message each, the pad bits of the snapshot say whether they are
  still lying there, a snapshot player carries its height, and the choice of landing place is a `C_DROP` message. The protocol is
  now version 8 (an old build is turned away with the usual "wrong version" message).

**Melee**
- **Every attack is a different movement** (`render/model/MeleeRig`, `UnitRenderer.drawMelee3d`). The soldier's arms are no longer part
  of a mesh: both are bent to wherever the hands are (two-bone IK from the shoulders), the weapon is tilted and turned about its grip,
  the body twists and steps into the blow, and the feet plant. Each attack is a few key poses (wind-up, impact, follow-through) timed to
  the moment the blow lands. New attacks: **stab** (the arm drives straight out), **lunge** (a long stab with a step), **rising slash**,
  **overhead chop**, **diagonal slashes**, **spin** (a full turn with the weapon out), **jab, jab, hook, uppercut** for fists. A blow
  leaves a trail: a bright crescent for a slash, a thin smear for a stab.
  ![Knife](docs/melee-knife.png)
  ![Baseball bat](docs/melee-bat.png)
  ![Fists](docs/melee-fists.png)
- **Combos** (`core/MeleeProfile`): knife = stab, slash, rising slash, lunge; bat = swing, backhand, overhead, spin; crowbar = two diagonal
  slashes, poke, overhead; machete = two diagonals, stab, spin; axe = overhead, diagonal, spin; pickaxe = stab down, swing, stab down, rising
  pick; fists = jab, jab, hook, uppercut.
- **Hits follow the movement.** A stab or lunge hits along a narrow line in front (and can pass through two), a spin hits all round, a slash
  sweeps an arc. A stab or a chop carries the fighter forward a few units, and a swing turns most of the way onto a foe near the aim
  (the aim assist keeps that aim until the blow lands), so melee works on a touch screen. Every blow that lands shakes the view a little.
  (`MeleeStats`: fists against three walkers 2/12 -> 7/12 cleared, pickaxe against five 10/12 -> 12/12 with half the damage taken; the price is
  that stepping into a blow puts a knife, axe or pickaxe fighter a little more often in a brute's reach - see `docs/TEST_REPORT.md`.)

**The map**
- **No more grid.** The ground is one flat colour per type, so a whole row is a single rectangle with no seams; the variety comes from soft
  large patches that ignore the tile grid, and natural grounds that meet (grass and sand, meadow and dirt) are blended over a few units.
  Paved yards lose their tile joints (cracks and worn patches instead); roads keep their dashes and kerbs.
  ![Town](docs/map-town.png)
- **Water.** No more rectangles with a bevelled edge: banks have shallows that fade into the deep colour, wet sand, drifting foam, glints on
  the open water, and the corners where the shore turns are rounded. The same for lakes in the survival world.
  ![Shore](docs/map-shore.png) ![Survival lake](docs/survival-lake.png)
- **Houses.** Pitched roofs have rows of shingles with staggered joints, light that falls off from the ridge to the eave, a ridge cap, a
  fascia board with a shadow, skylights and brick chimneys; flat roofs have ribs, vents, air units and hatches.
- **Trees** get a rim and leaf speckle on the crown (not on the light graphics levels).

**Survival**
- **You always come back.** I could not make a survivor stay dead in the headless runs (150 world seeds, starvation and zombie deaths,
  also far from the start), so this is a belt-and-braces change: the death screen now says *You died / You will get back up in N* and
  where the pack is, a watchdog respawns anyone who is still dead two seconds after the timer should have run out, and the respawn happens
  **near where you fell** (130-750 units away, on the open ground farthest from zombies) instead of at the start of the world, with four
  seconds of protection (`SurvivalSim.placeNearDeath`).

**Network fixes found while testing**
- The host dropped every survival command from a client (`C_SURV`), and a client dropped every survival frame from the host
  (`S_SURV`, `S_SURV_EVENT`, `S_SURV_EDIT`, `S_SURV_INV`): hosted survival could not have worked. Both whitelists now let them through
  (`NetSurvTest`: the client sees the zombies, gets its hunger, and a hotbar command reaches the host).

## What is new in 1.6
**Zombies and melee**
- **New zombies.** Every zombie is a posed low-poly body in the same lit style as the soldiers (`render/PuppetRenderer`,
  `render/model/PoseMesh`): walkers, lean runners and big brutes, with outfits (tee, hoodie, office shirt and tie, doctor's coat,
  police uniform, site vest and hard hat, tank top, hospital gown, butcher's apron, shirtless), skin tones, hair, wounds and
  sizes picked from the zombie's id, so a crowd never looks like copies and every device shows the same zombie.
- **Animations**: idle sway, shambling walk, run, attack (wind-up, lunge, follow-through), flinch when hit, stumble, fall,
  lying on the ground and getting up. They are procedural (`core/Puppet`): every state eases in and out, nothing snaps.
- **Hits are physical.** Each blow throws the zombie along the way it was struck, staggers it, or knocks it down for a
  few seconds (`SurvivalSim.applyHit`); a brute shrugs off what sends a runner flying. A blow on a zombie on the ground is
  a hit where it lies. Zombies wind up before they claw (about 0.2-0.55 s), a roll through the claw dodges it, and a brute's blow
  shoves you back.
- **Ragdolls.** Dead zombies (and fallen soldiers, in Battleground too) flop under a small Verlet physics (`core/Ragdolls`):
  gravity, ground friction, a bounce, walls. A bat swing left to right sends the body spinning off to the right; a rifle round
  throws it back. Blood sprays along the blow and stains the ground (`Effects.blood` and `decal`); a heavy hit shakes the view.
- **Each melee weapon is its own** (`core/MeleeProfile`): a combo of 2-4 different attacks per weapon with its own speed,
  damage, reach, arc, push, stagger and knock-down chance. The bat sweeps left to right, then right to left, then smashes down;
  the knife stabs and slashes (and kills a zombie that is looking away faster); the crowbar hammers and breaks doors and walls
  quickest; the machete cleaves up to four; the axe chops; the pickaxe drives through a line; fists jab and hook. Hit detection
  uses the weapon's real reach and the arc of that attack, ignores anything behind a wall, and a left-to-right swing pushes
  the zombie to the player's right. The soldier animates every attack differently (`UnitRenderer.meleePose`).
- **The Fire button** is a bullet with a muzzle flash (a claw slash when a melee weapon is in hand); the aim stick has a
  crosshair on its knob and the move stick has arrows, so no button needs a label.

**Survival world**
- **Houses**: 6-9 x 5-8 tile buildings with one proper door in the south wall (never hidden under the roof), a porch step and a
  doormat, windows, siding in eight colour schemes, a clear entrance hall, one-tile doorways between rooms, and a pitched or
  flat roof that hides the inside and fades away when you step in (the same roofs as Battleground). Buildings are never cut
  off by the edge of a town any more.
- **Doors** are framed, one tile wide (the player is 24 units across, a tile is 32), with a leaf that fills the opening and shows panels
  and a knob, or swings back against the inside of the wall when open. **Walking into a closed door opens it**; Pick Up still
  opens and closes doors.
- **Trees**: oak, pine, birch and bushy trees in sizes from 0.7x to 1.3x, with a gentle sway.
- **Cars** come as saloon, pickup and van, with windows, lights and bumpers; the Use button for a car shows a car.
- **Item icons** all share one style: a bold dark rim, flat colours with shading.
- **Camera fix**: the survival camera is no longer held inside "0 .. world", which left the survivor off-centre near the start.

**Inventory and controls**
- **The bag was redesigned**: a modal panel with the pack on the left (hotbar row first), tabs *Items* / *Craft* on the right.
  *Items* shows the selected item with a stat card (damage, speed, reach and combo for melee; damage, fire rate, range, magazine
  and spare ammo for guns; hunger or healing) and *Use / Hold / Equip* and *Drop*. *Craft* lists the recipes with an icon for every
  ingredient and have/need counts in green or red, and says why one cannot be made. Tap to select, tap a second slot to swap,
  or drag an item onto another slot.
- **The X (close) bug is fixed.** The bag's close button sits where the pause button is, and the pause button used to get the
  touch first. While the bag is open every touch now belongs to it (a tap outside it closes it too), and the Back button
  closes the bag before it opens the pause menu.

**Battleground**
- **Two primary weapons, each with its own ammunition** (`Player.slotWeapon / slotAmmo / slotReserve`). A gun you pick up
  goes into the empty slot (or replaces the one in hand); each keeps its magazine and its own spare rounds, shown as
  `rounds / spare` for the weapon in hand and the other one. The new *Switch Weapon* button (movable in the HUD editor) takes the
  other weapon out in a short animation, during which neither fires nor reloads.
- **Backpacks and ammo crates** (small, medium, large) lie in the houses: three magazines of spare ammunition per gun,
  and two more for every backpack size. An ammo crate adds two magazines for both guns.
- **Armour** shows a separate blue bar over the green health bar (always there; empty until you wear a vest) with a shield and
  a heart icon. The gear panel shows the weapons, backpack size and vest at a glance.
- **Choose the number of AI opponents** (1-7) before a solo match; the host of a Wi-Fi game can cap the bots.
- **The zone** now keeps up with the fight: a small match gets a quicker zone, circles must be mostly on land, the late circles
  are drawn round the fighters that are left, it speeds up as fighters drop out and is never allowed to lag behind (with half the
  fighters gone it is already at the third circle), the last circles are tighter and hit harder.
- **Spectator mode**: when you are out, Previous / Next switch between the fighters who are still alive (with their health,
  armour, weapon and kills), and *Leave match* goes back at once. The results screen has a *Continue* button.
- **Houses show their doors**: every gap in a house wall is marked with a threshold, open leaves, a paved step and a coloured doormat;
  a test checks that all 93 doorways on the island lead somewhere.

![The bag](docs/survival-bag.png)
![Crafting](docs/survival-craft.png)
![Zombies in a fight, with blood and a knocked-down zombie](docs/survival-day.png)
![The new survival houses](docs/survival-houses.png)
![Cars](docs/survival-vehicles.png)
![Zombies, walking](docs/zombies-walk.png)
![A zombie falling over](docs/zombie-fall.png)
![Battleground: two weapons, armour, gear](docs/battleground-gameplay.png)
![Spectating](docs/battleground-spectator.png)
![Battleground doorways](docs/battleground-doors.png)

## What was new in 1.5
- **Battleground is a real battle royale now.** One life each, last fighter standing wins, and a safe zone that closes
  in seven steps (about 8 minutes in all; the last step shrinks it to a point). Outside the zone you take storm damage,
  more with every step; a warning, an arrow to the zone and the red edge of the screen tell you. After you are out the
  camera follows a fighter who is still alive, and the results show the places (#1 is the winner).
- **Armour and first-aid kits.** A light vest (50) and a heavy vest (100) absorb 60% of every bullet or blow until they are
  used up; a first-aid kit gives 50 health. They lie in the houses next to the guns, with an armour bar over the health bar.
- **A very big outdoor island** (192 x 192 tiles, 6144 x 6144 units, about four times the old Battleground): coast and
  beaches, meadows, forests with real trees, rocky ground with boulders, a river with bridges and two lakes, a harbour with a
  pier, a factory, farms with fenced fields, towns joined by roads, a military base with a fenced compound, and cabins,
  barns and sheds in between. **Every one of the 80+ buildings can be walked into**: walls, doors, rooms, furniture and loot
  inside, and a roof that hides the inside until you step through the door (it fades away while you are in). The island is
  generated from a fixed seed (`core/BattlegroundMap`), the same on every phone. Positions on the network now use 1/4-unit
  steps so maps up to 256 tiles across work (`GameConfig.POS_SCALE`).
- **Bots play the new rules**: they loot house to house, put on armour and use kits, run for the zone as it closes and fight
  harder as the circle shrinks.
- **Melee weapons**: knife, baseball bat, crowbar, machete, fire axe and pickaxe. A swing sweeps an arc in front of you
  (up to three targets) and lands a moment after it starts; the soldier really swings the weapon round his body. They lie around
  Battleground and are the weapons of survival.
- **Six more guns** (14 in all): revolver, double barrel, hunting rifle, AK rifle, marksman rifle, machine pistol.
- **Sound**: the assault rifle shot is exactly the one you liked (the file is byte for byte the old recipe); every other gun
  now has the same punchy character (a bright crack, a quick thump, a mid-range body, a short echo) with its own size and tail,
  so they sound like one set of guns. Reloads are new mechanical foley, no more bell-like rings: the magazine release and the
  magazine sliding out, the magazine seating, the slide or bolt; shotguns, the revolver, the LMG and the plasma rifle each have
  their own. Hits, hurt and death sounds are meatier. See `docs/gun-sounds.png`.
- **Survival mode (new)**: an endless, generated zombie-apocalypse world. See the section below.

## Survival mode
Pick *Survival* in the solo set-up, or in the host's lobby for up to four players on the same Wi-Fi (everybody gets the same
world from the host's seed). There are no bots and no time limit.
- **The world**: endless (about 30,000 tiles in every direction) and generated as you walk: lakes and seas, beaches, meadows,
  forests, rocky highlands, ruined towns (a grid of streets, houses, shops, garages, clinics and police stations with doors,
  rooms and furniture) and lonely cabins. Parked wrecks stand in the streets.
- **Zombies**: walkers, fast runners and tough brutes. They see you from 300-460 units, come to gunshots and engines, break
  walls and doors you build, and swarm at night (a full day is 8 minutes; the screen darkens, campfires and headlights glow).
- **Loot**: every cupboard, fridge, shelf, wardrobe, toolbox, crate and gun case can be searched once (the Pick Up button says
  what it will do); what is inside is random and depends on the furniture and the building: food, cloth, nails, scrap, tools,
  car parts, ammunition, bandages and first-aid kits, vests, and the 14 guns (police stations have the most).
- **Hunger and eating**: hunger drains slowly; starving hurts. Eat canned food, bread, apples, berries, crops and fish by
  selecting the item and pressing the aim stick (or *Use* in the bag). A fed survivor slowly heals.
- **Crafting**: the *BAG* button opens the pack (tap an item, then another slot to move it, *Use* / *Drop*) and the crafting
  list: walls, doors, floors, campfire, workbench, axe, pickaxe, hoe, fishing rod, knife, bat, bandages, cooked fish, seeds,
  nails, a vest, ammunition. Some recipes need a workbench or a campfire next to you.
- **Building**: select a wall, door, floor, campfire or workbench and aim at a free tile in front of you; zombies chew at walls
  and doors, you can break your own with a melee weapon (you get wood back), and doors open and close with Pick Up.
- **Chopping and mining**: hit trees with an axe (any melee weapon works, slowly) for wood and fibre; boulders need a pickaxe
  for stone and scrap.
- **Farming**: till grass with a hoe, plant seeds on the soil, wait (about 3.5 minutes) and harvest with Pick Up for food
  and new seeds. **Fishing**: with a rod, aim at water and press; when the float dips and the screen says *A fish!*, press
  again to reel it in.
- **Cars** (like Project Zomboid): most wrecks are missing a tyre, a battery, engine parts or fuel. Carry the part (the engine
  needs a wrench in the pack, fuel a gas can) and press Pick Up next to the car to fit it, then Pick Up again to get in. The
  left stick drives (it steers towards where you push it and pushes the gas), Pick Up gets you out. Cars run zombies over, burn
  fuel, can be wrecked, and the engine attracts zombies.
- **Death**: your pack drops where you fall and you come back after a few seconds with a knife, two bandages and a tin of food.
- The world is not saved when you leave (this is the first version of the mode).

![The new Battleground island](docs/battleground-map.png)
![Battleground in play: the zone timer, fighters left, armour and health, the minimap with the safe zone](docs/battleground-gameplay.png)
![Survival by day](docs/survival-day.png)
![Survival at night](docs/survival-night.png)
![The bag: the pack on the left, crafting on the right](docs/survival-bag.png)

## What was new in 1.4
- **Battleground**: a new game mode on a huge island map (120 x 80 tiles, about four times the area of the biggest
  classic arena): ruins and a watch tower, a walled hill, a factory with a tank farm, a village, an old town with a
  plaza, a depot of container lanes, a harbour with piers, a lake with an island, and farmland, joined by canals with
  bridges and open ends. Eight fighters per match; bots fill every slot the real players leave empty (1 human = 7
  bots, 2 humans = 6 bots, 4 humans = 4 bots) and never take a human's place. Pick the mode in the solo setup or in the
  host's lobby.
- **Guns sound and reload like themselves**: every gun has its own shot and its own three reload sounds (it starts, the
  ammunition goes in, it is ready), and pump, bolt and hammer guns have an action sound after each shot. Reload times
  differ per gun (pistol 1.0 s ... magnum 2.5 s ... light MG 3.3 s); the ammunition comes back at the moment the new
  magazine seats, and the shotgun loads shell by shell (3.5 s from empty). A fresh trigger pull cuts a reload short when
  a round is in the gun; dodging, picking up a weapon or dying cancels it; an empty gun reloads again after a roll.
  The soldier's arms work the gun differently for each reload.
- **Dodge sound**: one short cloth-and-footwork whoosh per roll, never doubled when the button is mashed.
- **Manual weapon pickup**: walking over a weapon does nothing. A round Pick Up button appears (with the gun's name and
  what it replaces) while a weapon is within reach; the pad glows and an arrow bounces over it. Pressing it swaps your
  gun for that one.
- **Smooth bots**: steering, aiming and targeting were rewritten (see `bot/BotBrain`); they no longer shake.
- **Customize HUD** now only moves and resizes things (sticks, buttons, minimap, timer and scores, ammo, health bar,
  kill feed) and can reset the layout; **Controls** is a separate page (Pause menu or Settings) for how input works.
- Graphics quality "Auto" no longer drops soldiers to flat circles after a short slow patch, and recovers by itself.

## Features
- **Solo mode**: Classic (1-3 computer opponents, Easy / Normal / Hard, on any of the eight arenas), Battleground (battle royale
  against 7 bots) or Survival (an endless zombie world, alone or with friends).
- **Arenas**: Hazard Yard (smallest), Dockside Warehouse, Toxic Foundry, Ruined Outpost, Bunker Complex, and the
  newer Rotunda Plaza (wide open), Silo Yard and Diamond Hall. Besides square walls and crates they use round
  pillars and tanks and angled corner pieces. The host picks the arena in the lobby. Fences are thin lines
  you can stand right next to; fences and toxic pools block movement but not bullets.
- **Fourteen guns and six melee weapons**: pistol, assault rifle, shotgun, SMG, sniper rifle, magnum, plasma rifle, light MG,
  revolver, double barrel, hunting rifle, AK rifle, marksman rifle, machine pistol; knife, bat, crowbar, machete, fire axe, pickaxe.
  Pushing the aim stick all the way out fires every gun at its own rate, reloads included; bullets leave from the barrel.
  Each gun has its own camera zoom (`WeaponDef.zoom`): the sniper rifle pulls the view back to show its long range, the
  shotgun moves in close, and the view eases from one to the other when you pick up a different gun.
  Every gun has its own sound, synthesised in code (`audio/SoundBank`), no audio files; the plasma rifle keeps an electric zap on top of the same punch.
- **Aim line**: while you aim, a dashed line in the gun's colour runs from the muzzle as far as the gun reaches and stops at
  the first wall; guns that scatter their shots also show the edges of their spread. Only your own line is drawn, so it
  tells nothing about the other players. Can be switched off in Settings.
- **Dodge roll**: a button next to the aim stick. A short invulnerable somersault in the move direction
  (or the way you face), about 1.3 s cooldown. Bots roll too.
- **Heard shots only**: other players are not tracked on the minimap or by edge arrows; one shows up only
  where and while its gun was just heard firing.
- **3D look**: lit low-poly soldiers and guns, extruded walls and crates (`render/model`). Can be switched
  off in Settings for slow phones; Graphics quality "Auto" (default) lowers effects by itself when a phone
  cannot hold a steady frame rate (`render/QualityGovernor`). Frames follow the display's vsync and are
  interpolated, so 60, 90 and 120 Hz screens all look smooth.
- **Fullscreen** into the camera cutout; the HUD and controls keep to the safe area.
- **Customize HUD** (Settings > Customize HUD, or Pause > Customize HUD): move and resize every control and HUD element,
  reset the layout. Elements are shown exactly as in a match; overlapping ones are outlined in red. Nothing about how
  the controls behave is on this screen.
- **Controls** (Settings > Controls, or Pause > Controls): fixed or floating sticks, fire mode (stick fires / button fires /
  both), the "Stick fires at" level, aim dead zone, aim line and control opacity. The aim stick aims once it is past its
  dead zone and only fires once it is pushed out to the "Stick fires at" level (default 100% = all the way out,
  adjustable down to 30%); with "Button fires" the stick never fires and the fire button does the shooting. Changes apply
  at once, also during a paused match.

## Layout of the code (`app/src/main/java/com/hazardyard/game`)
| Package    | What lives there |
|------------|------------------|
| `core`     | Match rules and modes (`GameMode`), players, weapons and their reload model (`WeaponDef`, `Weapon`), the item registry (`Items`), the safe zone (`Zone`), pickups (`Pickups`), tile maps (`MapLibrary`, `BattlegroundMap`), collision (`CollisionSystem` against a `Terrain`). No Android types. |
| `survival` | The endless world and its rules: `SurvivalGen` (world generation), `SurvivalTerrain` (chunks), `SurvivalSim` (host-side rules: hunger, zombies, loot, crafting, building, farming, fishing, cars), `Inventory`, `Recipes`, `LootTable`. No Android types. |
| `bot`      | Bot AI: `BotBrain` (intent, then smooth steering), `BotSquad` (all bots of a match; spreads route searches over ticks), time-sliced A* `PathFinder`, `NavGrid`, `BotDifficulty`. |
| `engine`   | `GameEngine` implementations: `HostEngine`, `ClientEngine`, `SoloEngine`; `Presentation` turns events into effects and sounds. |
| `net`      | LAN discovery, lobby and match protocol (bump `Protocol.VERSION` when the wire format changes); `SnapshotCodec` and `SurvivalCodec` are the wire formats of a match. |
| `input`    | `InputController` (touch routing), `ControlGeometry` (pixel layout), `VirtualJoystick`, `SurvivalUi` (hotbar, bag and crafting touches). No Android types. |
| `settings` | `ControlSettings` (HUD layout: `resetLayout`; control options: `resetOptions`) / `GameSettings` and their SharedPreferences store. |
| `render`   | Canvas renderers: terrain, floor, blocks, roofs, the zone, units, pickups, shots, HUD, controls, and for survival `SurvivalRenderer` and `SurvivalHud`. `render/model` is the pure-Java 3D mesh pipeline. |
| `audio`    | `Synth` + `SoundBank` (sound design), `Mixer` (software mixing), `SoundEngine` (AudioTrack output). |
| `ui`       | Screens, the HUD layout editor (`HudEditorView`), the Controls page (`ControlsPanel`) and the Android views. |

## Adding things
- **A map**: add its rows to `MapLibrary` (legend in the comment there), a theme in `render/MapTheme`, and bump `MapLibrary.COUNT`
  (and `CLASSIC_COUNT` if players should be able to choose it). Keep it to 32 weapon pickups at most (the snapshot carries a
  32-bit pickup mask) and positions below 4096 units (they are sent as 1/8-unit 16-bit numbers).
- **A game mode**: add a `GameMode` (limits, respawn times, fixed arena, bot roster); the lobby, the solo setup and the host
  engine pick it up from there.
- **A gun**: add a `WeaponDef` (with its reload style and timings), a model in `render/model/GunModels`, sound recipes in
  `audio/SoundBank` (the shot sound id equals the weapon id, plus three reload sounds and optionally an action sound, see
  `core/Sounds`), a reload pose in `UnitRenderer.reloadPose`, and a map letter in `TileMap.weaponForLetter` if it should
  lie on a map.
