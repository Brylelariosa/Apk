# FloatNote

A lightweight Kotlin notes app for Android. Notes can open full-screen, or pop
out as a floating window (drag, resize, minimize to a bubble) that stays on
top of any other app - similar to Messenger's chat heads, but for notes.
Multiple notes can float at once.

## Features
- Notes list: 2-column staggered grid, 8-color palette, pin, search, swipe-to-delete with undo
- "Floating mode" toggle (toolbar overflow menu) controls whether tapping a note opens it full-screen or floating
- Floating windows: drag the header to move, drag the corner to resize, tap the bubble to expand, tap minimize to collapse to a bubble that snaps to the nearest screen edge
- Auto-saves as you type (debounced ~600ms) and again on close, so nothing is lost
- Material 3, dark mode, edge-to-edge, splash screen

## Size optimizations applied
- No Room / Retrofit / Glide - a hand-rolled `SQLiteOpenHelper` keeps the dependency graph (and APK) minimal, and avoids KSP/annotation-processor overhead in CI
- `isMinifyEnabled` + `isShrinkResources` on **both** debug and release build types (R8, full mode) - your workflow builds `assembleDebug` whenever `KEYSTORE_BASE64` isn't set, so debug stays small too. If you'd rather keep debug builds unobfuscated for easier debugging, just delete the `debug { }` override block in `app/build.gradle.kts` (release stays optimized either way)
- Vector drawables only, zero raster/PNG assets - including the adaptive launcher icon (`ic_launcher_background`/`foreground`, no per-density PNGs)
- `resourceConfigurations += listOf("en")` strips translated strings AndroidX/Material otherwise ship for every locale
- `buildConfig = false`, unused `META-INF/*` license/notice files excluded from packaging
- Every dependency in `app/build.gradle.kts` is actually used in code (no ConstraintLayout or other unused libraries)
- Crash logs stay readable even though the app is minified: `-keepattributes SourceFile,LineNumberTable` in `proguard-rules.pro` keeps file/line info while still shrinking and renaming everything else

## Versions used
JDK 17, AGP 8.13.0, Gradle 8.13, Kotlin 1.9.24, compileSdk/targetSdk 36 (Android 16), minSdk 26 (Android 8.0+).

Your workflow's "Setup Gradle" step and "Fetch gradle-wrapper.jar" step are both
pinned to Gradle **8.6**, but this project's `gradle-wrapper.properties` points
at Gradle **8.13** (needed for compileSdk 36 support via AGP 8.13). This still
works out of the box - `gradlew` downloads whatever `distributionUrl` its own
properties file says regardless of what the setup-gradle action pre-cached,
and a gradle-wrapper.jar from 8.6 can bootstrap a newer distribution fine.
For a slightly faster first CI run (so the pre-cache actually gets used),
you can optionally bump the two `"8.6"` strings in your workflow to `"8.13"`.

If anything about that version jump ever gives you trouble, the safe fallback
is: AGP `8.4.1`, Gradle `8.6` (matches your workflow exactly), compileSdk/targetSdk `34`.

## Building
Drop `FloatNote.zip` in the `uploads/` folder of your CI repo (or push it with
your ZipApkBuilder app) - your existing Build APK workflow picks it up
automatically, no other changes needed.

## Notes
- The first time "Floating mode" is used, Android will prompt for the
  "display over other apps" permission (required for the overlay windows) and,
  on Android 13+, notification permission (for the small persistent "FloatNote
  is active" notification foreground services require).
