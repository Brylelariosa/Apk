# FloatNote proguard rules

# Keep file names and line numbers so crash logs stay readable even though the
# app is minified/obfuscated in both debug and release builds.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

# AndroidX / Material / lifecycle / coroutines ship their own consumer rules,
# so nothing extra is needed for them. Add rules here if you introduce a
# reflection-based library later (Gson, Room, Retrofit, etc).
