package com.jarry.floatnote.util

import com.jarry.floatnote.R

object NoteColors {
    val swatches = intArrayOf(
        R.color.note_default,
        R.color.note_coral,
        R.color.note_peach,
        R.color.note_sunshine,
        R.color.note_sage,
        R.color.note_fog,
        R.color.note_sky,
        R.color.note_lavender
    )
}
