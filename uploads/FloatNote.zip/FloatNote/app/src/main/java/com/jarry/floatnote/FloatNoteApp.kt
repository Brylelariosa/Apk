package com.jarry.floatnote

import android.app.Application

class FloatNoteApp : Application()
