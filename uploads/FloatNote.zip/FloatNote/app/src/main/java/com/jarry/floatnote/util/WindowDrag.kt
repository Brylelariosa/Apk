package com.jarry.floatnote.util

import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import kotlin.math.abs

private const val DRAG_THRESHOLD_PX = 8

/**
 * Wires an OnTouchListener that repositions [params] (x/y) as the user drags
 * [view], applying each move via [windowManager]. Shared by the floating
 * card's drag handle and the collapsed bubble.
 *
 * [onRelease], if given, is called on ACTION_UP with whether the touch moved
 * past a small threshold (a tap vs. an actual drag) - e.g. the bubble uses
 * this to tell "tap to expand" apart from "drag to reposition". When
 * omitted, ACTION_UP is left unhandled, matching a plain drag handle with no
 * separate tap behavior.
 */
fun setupWindowDrag(
    view: View,
    params: WindowManager.LayoutParams,
    windowManager: WindowManager,
    onRelease: ((moved: Boolean) -> Unit)? = null
) {
    var startX = 0
    var startY = 0
    var touchX = 0f
    var touchY = 0f
    var moved = false
    view.setOnTouchListener { _, event ->
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                startX = params.x
                startY = params.y
                touchX = event.rawX
                touchY = event.rawY
                moved = false
                true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.rawX - touchX
                val dy = event.rawY - touchY
                if (abs(dx) > DRAG_THRESHOLD_PX || abs(dy) > DRAG_THRESHOLD_PX) moved = true
                params.x = startX + dx.toInt()
                params.y = startY + dy.toInt()
                runCatching { windowManager.updateViewLayout(view, params) }
                true
            }
            MotionEvent.ACTION_UP -> if (onRelease != null) {
                onRelease(moved)
                true
            } else {
                false
            }
            else -> false
        }
    }
}
