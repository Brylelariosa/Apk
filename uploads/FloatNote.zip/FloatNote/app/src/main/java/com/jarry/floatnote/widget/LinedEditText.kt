package com.jarry.floatnote.widget

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatEditText
import androidx.core.content.ContextCompat
import com.jarry.floatnote.R

/**
 * An EditText that draws notebook-style horizontal rule lines, plus a red
 * margin line, behind the text - like real ruled paper.
 *
 * The rule spacing is read from the EditText's own lineHeight/font metrics
 * (not a fixed dp value), so lines always land exactly under each row of
 * typed text no matter the font size or line spacing used. Lines are drawn
 * all the way to the bottom of the view rather than stopping at the last
 * typed line, so it reads as a full page from the moment a note opens.
 */
class LinedEditText @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = android.R.attr.editTextStyle
) : AppCompatEditText(context, attrs, defStyleAttr) {

    private val density = resources.displayMetrics.density

    private val rulePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeWidth = density
        color = ContextCompat.getColor(context, R.color.paper_rule_line)
    }

    private val marginPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeWidth = density
        color = ContextCompat.getColor(context, R.color.paper_margin_line)
    }

    var showMarginLine: Boolean = true
        set(value) {
            field = value
            invalidate()
        }

    override fun onDraw(canvas: Canvas) {
        drawRules(canvas)
        drawMargin(canvas)
        super.onDraw(canvas)
    }

    private fun drawRules(canvas: Canvas) {
        val lineH = lineHeight.toFloat()
        if (lineH <= 0f) return
        val fm = paint.fontMetrics
        val left = paddingLeft.toFloat()
        val right = (width - paddingRight).toFloat()
        val bottom = (height - paddingBottom).toFloat()
        var baseline = paddingTop - fm.top
        while (baseline <= bottom) {
            canvas.drawLine(left, baseline, right, baseline, rulePaint)
            baseline += lineH
        }
    }

    private fun drawMargin(canvas: Canvas) {
        if (!showMarginLine) return
        val x = paddingLeft - (10f * density)
        if (x > 0f) {
            canvas.drawLine(x, 0f, x, height.toFloat(), marginPaint)
        }
    }
}
