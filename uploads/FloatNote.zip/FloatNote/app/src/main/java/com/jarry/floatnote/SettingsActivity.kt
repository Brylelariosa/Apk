package com.jarry.floatnote

import android.content.res.ColorStateList
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding
import com.jarry.floatnote.databinding.ActivitySettingsBinding
import com.jarry.floatnote.util.MinimizeMode
import com.jarry.floatnote.util.PaperStyles
import com.jarry.floatnote.util.PrefsManager

/**
 * One place for choices that used to live inline on the note editor: the
 * single app-wide note style, and how minimizing a floating note behaves.
 */
class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }
        applyInsets()

        buildStyleSwatches()
        setupMinimizeModeToggle()
    }

    private fun applyInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(binding.toolbar) { v, insets ->
            v.updatePadding(top = insets.getInsets(WindowInsetsCompat.Type.systemBars()).top)
            insets
        }
        ViewCompat.setOnApplyWindowInsetsListener(binding.settingsScroll) { v, insets ->
            v.updatePadding(bottom = insets.getInsets(WindowInsetsCompat.Type.systemBars()).bottom)
            insets
        }
    }

    private fun buildStyleSwatches() {
        binding.styleRow.removeAllViews()
        val current = PrefsManager.getGlobalStyleIndex(this)
        PaperStyles.all.forEachIndexed { index, style ->
            val swatch = layoutInflater.inflate(R.layout.item_style_swatch, binding.styleRow, false)
            val cover = swatch.findViewById<View>(R.id.styleCover)
            cover.backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(this, style.coverColor))
            val selected = index == current
            cover.alpha = if (selected) 1f else 0.5f
            cover.scaleX = if (selected) 1.1f else 1f
            cover.scaleY = if (selected) 1.1f else 1f
            swatch.contentDescription = style.label
            swatch.setOnClickListener {
                PrefsManager.setGlobalStyleIndex(this, index)
                buildStyleSwatches()
            }
            binding.styleRow.addView(swatch)
        }
    }

    private fun setupMinimizeModeToggle() {
        val checkedId = when (PrefsManager.getMinimizeMode(this)) {
            MinimizeMode.BUBBLE -> R.id.buttonModeBubble
            MinimizeMode.NOTIFICATION -> R.id.buttonModeNotification
        }
        binding.minimizeModeGroup.check(checkedId)
        binding.minimizeModeGroup.addOnButtonCheckedListener { _, checkedButtonId, isChecked ->
            if (!isChecked) return@addOnButtonCheckedListener
            val mode = if (checkedButtonId == R.id.buttonModeNotification) {
                MinimizeMode.NOTIFICATION
            } else {
                MinimizeMode.BUBBLE
            }
            PrefsManager.setMinimizeMode(this, mode)
        }
    }
}
