package com.jarry.floatnote

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding
import androidx.lifecycle.lifecycleScope
import com.jarry.floatnote.data.Note
import com.jarry.floatnote.data.NoteRepository
import com.jarry.floatnote.databinding.ActivityNoteEditorBinding
import com.jarry.floatnote.util.OverlayPermission
import com.jarry.floatnote.util.PaperStyles
import com.jarry.floatnote.util.PrefsManager
import com.jarry.floatnote.util.UndoRedoManager
import com.jarry.floatnote.util.expandNumberedListToken
import com.jarry.floatnote.util.simpleWatcher
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class NoteEditorActivity : AppCompatActivity() {

    private lateinit var binding: ActivityNoteEditorBinding
    private lateinit var repository: NoteRepository
    private lateinit var undoRedo: UndoRedoManager
    private var note = Note()
    private var saveJob: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNoteEditorBinding.inflate(layoutInflater)
        setContentView(binding.root)
        repository = NoteRepository.getInstance(this)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }
        applyInsets()

        applyGlobalStyle()

        undoRedo = UndoRedoManager(binding.editContent, lifecycleScope)
        undoRedo.onStateChanged = { refreshUndoRedoButtons() }
        refreshUndoRedoButtons()
        binding.buttonUndo.setOnClickListener { undoRedo.undo() }
        binding.buttonRedo.setOnClickListener { undoRedo.redo() }
        binding.buttonNumberedList.setOnClickListener {
            if (!expandNumberedListToken(binding.editContent)) {
                Toast.makeText(this, R.string.numbered_list_hint, Toast.LENGTH_SHORT).show()
            }
        }

        val watcher = simpleWatcher { scheduleAutoSave() }
        binding.editTitle.addTextChangedListener(watcher)
        binding.editContent.addTextChangedListener(watcher)

        val noteId = intent.getLongExtra(EXTRA_NOTE_ID, 0L)
        if (noteId != 0L) {
            lifecycleScope.launch {
                repository.getById(noteId)?.let {
                    note = it
                    binding.editTitle.setText(it.title)
                    binding.editContent.setText(it.content)
                    undoRedo.reset()
                }
            }
        }

        binding.buttonDelete.setOnClickListener {
            lifecycleScope.launch {
                saveJob?.cancel()
                if (note.id != 0L) repository.delete(note.id)
                finish()
            }
        }

        binding.buttonPopOut.setOnClickListener {
            if (!OverlayPermission.isGranted(this)) {
                OverlayPermission.request(this, binding.root)
                return@setOnClickListener
            }
            lifecycleScope.launch {
                saveJob?.cancel()
                persist()
                val serviceIntent = Intent(this@NoteEditorActivity, FloatingNoteService::class.java)
                    .setAction(FloatingNoteService.ACTION_SHOW_NOTE)
                    .putExtra(FloatingNoteService.EXTRA_NOTE_ID, note.id)
                ContextCompat.startForegroundService(this@NoteEditorActivity, serviceIntent)
                finish()
            }
        }
    }

    private fun applyInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(binding.toolbar) { v, insets ->
            v.updatePadding(top = insets.getInsets(WindowInsetsCompat.Type.systemBars()).top)
            insets
        }
        ViewCompat.setOnApplyWindowInsetsListener(binding.bottomBar) { v, insets ->
            v.updatePadding(bottom = insets.getInsets(WindowInsetsCompat.Type.systemBars()).bottom)
            insets
        }
    }

    /** Style is a single app-wide choice made in Settings now, not a per-note
     *  picker living on this screen - just reflect it here. */
    private fun applyGlobalStyle() {
        val style = PaperStyles.get(PrefsManager.getGlobalStyleIndex(this))
        binding.spineAccent.setBackgroundColor(ContextCompat.getColor(this, style.coverColor))
        binding.editContent.pattern = style.pattern
    }

    override fun onResume() {
        super.onResume()
        applyGlobalStyle()
    }

    private fun refreshUndoRedoButtons() {
        binding.buttonUndo.isEnabled = undoRedo.canUndo()
        binding.buttonUndo.alpha = if (undoRedo.canUndo()) 1f else 0.35f
        binding.buttonRedo.isEnabled = undoRedo.canRedo()
        binding.buttonRedo.alpha = if (undoRedo.canRedo()) 1f else 0.35f
    }

    private fun scheduleAutoSave() {
        saveJob?.cancel()
        saveJob = lifecycleScope.launch {
            delay(600)
            persist()
        }
    }

    override fun onPause() {
        super.onPause()
        saveJob?.cancel()
        lifecycleScope.launch { persist() }
    }

    private suspend fun persist() {
        val title = binding.editTitle.text.toString()
        val content = binding.editContent.text.toString()
        if (title.isBlank() && content.isBlank()) {
            if (note.id != 0L) repository.delete(note.id)
            return
        }
        note = note.copy(title = title, content = content)
        note = note.copy(id = repository.save(note))
    }

    companion object {
        const val EXTRA_NOTE_ID = "extra_note_id"
    }
}
