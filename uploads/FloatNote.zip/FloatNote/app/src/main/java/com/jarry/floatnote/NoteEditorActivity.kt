package com.jarry.floatnote

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.jarry.floatnote.data.Note
import com.jarry.floatnote.data.NoteRepository
import com.jarry.floatnote.databinding.ActivityNoteEditorBinding
import com.jarry.floatnote.util.Debouncer
import com.jarry.floatnote.util.OverlayPermission
import com.jarry.floatnote.util.PaperStyles
import com.jarry.floatnote.util.UndoRedoManager
import com.jarry.floatnote.util.applyBottomSystemBarPadding
import com.jarry.floatnote.util.applyContentTextSize
import com.jarry.floatnote.util.applyTopSystemBarPadding
import com.jarry.floatnote.util.bindCopyButton
import com.jarry.floatnote.util.bindNumberedListButton
import com.jarry.floatnote.util.bindPasteButton
import com.jarry.floatnote.util.bindToButtons
import com.jarry.floatnote.util.simpleWatcher
import kotlinx.coroutines.launch

class NoteEditorActivity : AppCompatActivity() {

    private lateinit var binding: ActivityNoteEditorBinding
    private lateinit var repository: NoteRepository
    private lateinit var undoRedo: UndoRedoManager
    private lateinit var saveDebouncer: Debouncer
    private var note = Note()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNoteEditorBinding.inflate(layoutInflater)
        setContentView(binding.root)
        repository = NoteRepository.getInstance(this)
        saveDebouncer = Debouncer(lifecycleScope)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }
        applyInsets()

        applyGlobalStyle()
        applyContentTextSize(binding.editContent, this)

        undoRedo = UndoRedoManager(binding.editContent, lifecycleScope)
        undoRedo.bindToButtons(binding.buttonUndo, binding.buttonRedo)
        bindNumberedListButton(binding.editContent, binding.buttonNumberedList, this)
        bindCopyButton(binding.editContent, binding.buttonCopy, this)
        bindPasteButton(binding.editContent, binding.buttonPaste, this)

        val watcher = simpleWatcher { scheduleAutoSave() }
        binding.editTitle.addTextChangedListener(watcher)
        binding.editContent.addTextChangedListener(watcher)

        val noteId = intent.getLongExtra(EXTRA_NOTE_ID, 0L)
        if (noteId != 0L) {
            lifecycleScope.launch {
                repository.getById(noteId)?.let {
                    note = it
                    binding.editTitle.setText(it.title)
                    binding.editContent.setText(it.content)
                    undoRedo.reset()
                }
            }
        }

        binding.buttonDelete.setOnClickListener {
            lifecycleScope.launch {
                saveDebouncer.cancel()
                if (note.id != 0L) repository.delete(note.id)
                finish()
            }
        }

        binding.buttonPopOut.setOnClickListener {
            if (!OverlayPermission.isGranted(this)) {
                OverlayPermission.request(this, binding.root)
                return@setOnClickListener
            }
            lifecycleScope.launch {
                saveDebouncer.cancel()
                persist()
                val serviceIntent = Intent(this@NoteEditorActivity, FloatingNoteService::class.java)
                    .setAction(FloatingNoteService.ACTION_SHOW_NOTE)
                    .putExtra(FloatingNoteService.EXTRA_NOTE_ID, note.id)
                ContextCompat.startForegroundService(this@NoteEditorActivity, serviceIntent)
                finish()
            }
        }
    }

    private fun applyInsets() {
        binding.toolbar.applyTopSystemBarPadding()
        binding.bottomBar.applyBottomSystemBarPadding()
    }

    /** Style is a single app-wide choice made in Settings now, not a per-note
     *  picker living on this screen - just reflect it here. */
    private fun applyGlobalStyle() {
        val style = PaperStyles.current(this)
        binding.spineAccent.setBackgroundColor(ContextCompat.getColor(this, style.coverColor))
        binding.editContent.pattern = style.pattern
    }

    override fun onResume() {
        super.onResume()
        applyGlobalStyle()
        applyContentTextSize(binding.editContent, this)
    }

    private fun scheduleAutoSave() {
        saveDebouncer.schedule { persist() }
    }

    override fun onPause() {
        super.onPause()
        saveDebouncer.cancel()
        lifecycleScope.launch { persist() }
    }

    private suspend fun persist() {
        val title = binding.editTitle.text.toString()
        val content = binding.editContent.text.toString()
        if (title.isBlank() && content.isBlank()) {
            if (note.id != 0L) repository.delete(note.id)
            return
        }
        note = note.copy(title = title, content = content)
        note = note.copy(id = repository.save(note))
    }

    companion object {
        const val EXTRA_NOTE_ID = "extra_note_id"
    }
}
