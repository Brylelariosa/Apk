package com.jarry.floatnote

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.jarry.floatnote.data.Note
import com.jarry.floatnote.data.NoteRepository
import com.jarry.floatnote.databinding.ActivityNoteEditorBinding
import com.jarry.floatnote.util.Debouncer
import com.jarry.floatnote.util.OverlayPermission
import com.jarry.floatnote.util.PaperStyles
import com.jarry.floatnote.util.UndoRedoManager
import com.jarry.floatnote.util.applyBottomSystemBarPadding
import com.jarry.floatnote.util.applyContentTextSize
import com.jarry.floatnote.util.applyTopSystemBarPadding
import com.jarry.floatnote.util.bindCopyButton
import com.jarry.floatnote.util.bindNumberedListButton
import com.jarry.floatnote.util.bindPasteButton
import com.jarry.floatnote.util.bindToButtons
import com.jarry.floatnote.util.simpleWatcher
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

class NoteEditorActivity : AppCompatActivity() {

    private lateinit var binding: ActivityNoteEditorBinding
    private lateinit var repository: NoteRepository
    private lateinit var undoRedo: UndoRedoManager
    private lateinit var saveDebouncer: Debouncer
    private var note = Note()

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        binding = ActivityNoteEditorBinding.inflate(layoutInflater)
        setContentView(binding.root)
        repository = NoteRepository.getInstance(this)
        saveDebouncer = Debouncer(lifecycleScope)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }
        applyInsets()

        applyGlobalStyle()
        applyContentTextSize(binding.editContent, this)

        undoRedo = UndoRedoManager(binding.editContent, lifecycleScope)
        undoRedo.bindToButtons(binding.buttonUndo, binding.buttonRedo)
        bindNumberedListButton(binding.editContent, binding.buttonNumberedList, this)
        bindCopyButton(binding.editContent, binding.buttonCopy, this)
        bindPasteButton(binding.editContent, binding.buttonPaste, this)

        val watcher = simpleWatcher { scheduleAutoSave() }
        binding.editTitle.addTextChangedListener(watcher)
        binding.editContent.addTextChangedListener(watcher)

        // A configuration change (rotation, dark mode toggle, multi-window
        // resize, etc.) recreates this Activity with the *original* Intent,
        // whose EXTRA_NOTE_ID is still 0 for a note that was brand new when
        // this screen first opened - even if it has since been assigned a
        // real id by an autosave. Without restoring that id from saved state,
        // the recreated instance would treat the note as new again and the
        // next autosave would INSERT a second, duplicate row instead of
        // updating the first. onPause (see below) guarantees the id is
        // up to date in the DB and in `note` before this state is saved.
        val restoredNoteId = savedInstanceState?.getLong(STATE_NOTE_ID, 0L) ?: 0L
        val noteId = if (restoredNoteId != 0L) restoredNoteId else intent.getLongExtra(EXTRA_NOTE_ID, 0L)
        if (noteId != 0L) {
            lifecycleScope.launch {
                repository.getById(noteId)?.let {
                    note = it
                    binding.editTitle.setText(it.title)
                    binding.editContent.setText(it.content)
                    undoRedo.reset()
                    restoreCursorSelection(savedInstanceState)
                }
            }
        }

        binding.buttonDelete.setOnClickListener {
            lifecycleScope.launch {
                saveDebouncer.cancel()
                if (note.id != 0L) repository.delete(note.id)
                finish()
            }
        }

        binding.buttonPopOut.setOnClickListener {
            if (!OverlayPermission.isGranted(this)) {
                OverlayPermission.request(this, binding.root)
                return@setOnClickListener
            }
            lifecycleScope.launch {
                saveDebouncer.cancel()
                persist()
                val serviceIntent = Intent(this@NoteEditorActivity, FloatingNoteService::class.java)
                    .setAction(FloatingNoteService.ACTION_SHOW_NOTE)
                    .putExtra(FloatingNoteService.EXTRA_NOTE_ID, note.id)
                ContextCompat.startForegroundService(this@NoteEditorActivity, serviceIntent)
                finish()
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putLong(STATE_NOTE_ID, note.id)
        outState.putInt(STATE_CURSOR_START, binding.editContent.selectionStart)
        outState.putInt(STATE_CURSOR_END, binding.editContent.selectionEnd)
    }

    private fun restoreCursorSelection(savedInstanceState: Bundle?) {
        if (savedInstanceState == null) return
        val start = savedInstanceState.getInt(STATE_CURSOR_START, -1)
        val end = savedInstanceState.getInt(STATE_CURSOR_END, -1)
        val length = binding.editContent.text?.length ?: 0
        if (start in 0..length && end in 0..length) {
            binding.editContent.setSelection(start, end)
        }
    }

    private fun applyInsets() {
        binding.toolbar.applyTopSystemBarPadding()
        binding.bottomBar.applyBottomSystemBarPadding()
    }

    /** Style is a single app-wide choice made in Settings now, not a per-note
     *  picker living on this screen - just reflect it here. */
    private fun applyGlobalStyle() {
        val style = PaperStyles.current(this)
        binding.spineAccent.setBackgroundColor(ContextCompat.getColor(this, style.coverColor))
        binding.editContent.pattern = style.pattern
    }

    override fun onResume() {
        super.onResume()
        applyGlobalStyle()
        applyContentTextSize(binding.editContent, this)
        // Guards the same two-editors-one-note conflict as MainActivity.openNote,
        // just from the other direction: if this note became a floating window
        // while this screen was backgrounded (e.g. a stale multi-window/recents
        // instance), defer to that window instead of resuming a second,
        // uncoordinated editor for it.
        if (FloatingNoteService.isNoteFloating(note.id)) {
            finish()
        }
    }

    private fun scheduleAutoSave() {
        saveDebouncer.schedule { persist() }
    }

    override fun onPause() {
        super.onPause()
        saveDebouncer.cancel()
        // Deliberately synchronous (not a fire-and-forget launch): this needs
        // to have fully completed - and `note.id` needs to be up to date -
        // before onSaveInstanceState/onStop/onDestroy run right after this
        // returns. A fire-and-forget coroutine here raced with those
        // callbacks (lifecycleScope is cancelled once the Activity reaches
        // DESTROYED) and could both lose the last few keystrokes and, for a
        // brand new note, leave the recreated instance thinking it still
        // needs to insert one, creating a duplicate row on the next
        // autosave. The write itself is a single small local SQLite
        // operation, so blocking briefly here is not noticeable.
        runBlocking { persist() }
    }

    private suspend fun persist() {
        val title = binding.editTitle.text.toString()
        val content = binding.editContent.text.toString()
        if (title.isBlank() && content.isBlank()) {
            if (note.id != 0L) {
                repository.delete(note.id)
                note = note.copy(id = 0L)
            }
            return
        }
        note = note.copy(title = title, content = content)
        note = note.copy(id = repository.save(note))
    }

    companion object {
        const val EXTRA_NOTE_ID = "extra_note_id"
        private const val STATE_NOTE_ID = "state_note_id"
        private const val STATE_CURSOR_START = "state_cursor_start"
        private const val STATE_CURSOR_END = "state_cursor_end"
    }
}
