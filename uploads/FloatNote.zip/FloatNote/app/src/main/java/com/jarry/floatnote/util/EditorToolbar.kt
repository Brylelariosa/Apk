package com.jarry.floatnote.util

import android.content.Context
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
import com.jarry.floatnote.R

/**
 * Wiring shared by every editor surface that hosts the same undo/redo +
 * numbered-list toolbar buttons next to a content field - the full-screen
 * editor and each floating card.
 */

/** Wires this manager's undo/redo state to a pair of toolbar buttons: click
 *  handlers, plus enabled/dimmed state that refreshes on every state change. */
fun UndoRedoManager.bindToButtons(buttonUndo: ImageButton, buttonRedo: ImageButton) {
    fun refresh() {
        buttonUndo.isEnabled = canUndo()
        buttonUndo.alpha = if (canUndo()) 1f else 0.35f
        buttonRedo.isEnabled = canRedo()
        buttonRedo.alpha = if (canRedo()) 1f else 0.35f
    }
    onStateChanged = { refresh() }
    refresh()
    buttonUndo.setOnClickListener { undo() }
    buttonRedo.setOnClickListener { redo() }
}

/** Wires [button] to expand a typed numbered-list token in [editText] (see
 *  [expandNumberedListToken]), showing a hint via [context] when the current
 *  line has nothing to expand. */
fun bindNumberedListButton(editText: EditText, button: ImageButton, context: Context) {
    button.setOnClickListener {
        if (!expandNumberedListToken(editText)) {
            Toast.makeText(context, R.string.numbered_list_hint, Toast.LENGTH_SHORT).show()
        }
    }
}

/** Wires [button] to copy the current selection in [editText] (see
 *  [copySelectionOrAll]), confirming via toast. */
fun bindCopyButton(editText: EditText, button: ImageButton, context: Context) {
    button.setOnClickListener {
        if (copySelectionOrAll(editText, context)) {
            Toast.makeText(context, R.string.copied_to_clipboard, Toast.LENGTH_SHORT).show()
        }
    }
}

/** Wires [button] to paste the clipboard into [editText] (see
 *  [pasteFromClipboard]), showing a hint when there's nothing to paste. */
fun bindPasteButton(editText: EditText, button: ImageButton, context: Context) {
    button.setOnClickListener {
        if (!pasteFromClipboard(editText, context)) {
            Toast.makeText(context, R.string.clipboard_empty_hint, Toast.LENGTH_SHORT).show()
        }
    }
}
