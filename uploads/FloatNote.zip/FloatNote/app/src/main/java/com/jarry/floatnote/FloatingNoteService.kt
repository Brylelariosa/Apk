package com.jarry.floatnote

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.Log
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.view.animation.OvershootInterpolator
import android.animation.ValueAnimator
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import android.content.res.ColorStateList
import com.jarry.floatnote.data.Note
import com.jarry.floatnote.data.NoteRepository
import com.jarry.floatnote.databinding.LayoutFloatingBubbleBinding
import com.jarry.floatnote.databinding.LayoutFloatingNoteBinding
import com.jarry.floatnote.util.MinimizeMode
import com.jarry.floatnote.util.PaperStyles
import com.jarry.floatnote.util.PrefsManager
import com.jarry.floatnote.util.UndoRedoManager
import com.jarry.floatnote.util.dpToPx
import com.jarry.floatnote.util.expandNumberedListToken
import com.jarry.floatnote.util.simpleWatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.abs

/**
 * Hosts every floating note as a WindowManager overlay. Each note is either a
 * small draggable bubble (collapsed) or a draggable/resizable card (expanded).
 * Multiple notes can float at once - each gets its own FloatingNoteWindow.
 */
class FloatingNoteService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var repository: NoteRepository
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val windows = mutableListOf<FloatingNoteWindow>()

    // A bare Service context doesn't reliably resolve Material3/AppCompat theme
    // attributes the way an Activity does, which previously crashed inflation
    // of the AppCompat-based views in the floating layouts. Wrapping it with
    // the app's own theme explicitly fixes that for good.
    private val themedInflater: LayoutInflater by lazy {
        LayoutInflater.from(ContextThemeWrapper(this, R.style.Theme_FloatNote))
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        repository = NoteRepository.getInstance(this)
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_SHOW_NOTE -> showNote(intent.getLongExtra(EXTRA_NOTE_ID, 0L))
            ACTION_CLOSE_ALL -> stopSelf()
            ACTION_EXPAND_NOTE -> {
                val key = intent.getIntExtra(EXTRA_WINDOW_KEY, -1)
                windows.find { it.notifKey == key }?.expand()
            }
            ACTION_DISMISS_NOTE -> {
                val key = intent.getIntExtra(EXTRA_WINDOW_KEY, -1)
                windows.find { it.notifKey == key }?.destroy(save = true)
            }
        }
        return START_NOT_STICKY
    }

    private fun showNote(noteId: Long) {
        // Safety net: WindowManager.addView(TYPE_APPLICATION_OVERLAY) throws without this
        // permission. Callers should already check OverlayPermission before starting this
        // service, but this guard means a missed check degrades to a message, not a crash.
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow \"display over other apps\" to use floating notes", Toast.LENGTH_LONG).show()
            if (windows.isEmpty()) stopSelf()
            return
        }
        windows.find { it.noteId == noteId && noteId != 0L }?.let {
            it.expand()
            return
        }
        serviceScope.launch {
            val note = if (noteId != 0L) repository.getById(noteId) ?: Note() else Note()
            val window = FloatingNoteWindow(note)
            windows.add(window)
            window.attach()
        }
    }

    private fun buildNotification(): android.app.Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Floating notes", NotificationManager.IMPORTANCE_MIN
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val closeIntent = PendingIntent.getService(
            this, 0,
            Intent(this, FloatingNoteService::class.java).setAction(ACTION_CLOSE_ALL),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_note)
            .setContentTitle("FloatNote is active")
            .setContentText("Tap to manage floating notes")
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .addAction(0, "Close all", closeIntent)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        windows.toList().forEach { it.destroy(save = true) }
        windows.clear()
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private inner class FloatingNoteWindow(private var note: Note) {
        val noteId: Long get() = note.id

        // Stable identity for this window's notification (when minimized to one),
        // independent of note.id since a brand new note may still be 0L.
        val notifKey: Int = nextNotifKey()

        private var bubbleBinding: LayoutFloatingBubbleBinding? = null
        private var cardBinding: LayoutFloatingNoteBinding? = null
        private var cardParams: WindowManager.LayoutParams? = null
        private var saveJob: Job? = null
        private var isMinimizedAsNotification = false

        // The card is fully torn down and re-inflated on every minimize/maximize,
        // so scroll position and caret selection have to be captured manually
        // before that happens or the note reopens at the top every time.
        private var savedScrollY = 0
        private var savedSelectionStart = -1
        private var savedSelectionEnd = -1

        private val overlayType = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

        fun attach() = showCard()

        fun expand() {
            cancelMinimizedNotification()
            if (cardBinding != null) return
            removeBubble()
            showCard()
        }

        private fun showCard() {
            try {
                val binding = LayoutFloatingNoteBinding.inflate(themedInflater)
                cardBinding = binding

                binding.editTitle.setText(note.title)
                binding.editContent.setText(note.content)
                if (savedSelectionStart >= 0) {
                    val len = binding.editContent.text?.length ?: 0
                    val end = savedSelectionEnd.coerceIn(0, len)
                    val start = savedSelectionStart.coerceIn(0, end)
                    binding.editContent.setSelection(start, end)
                }
                // Restore where the user was in the note instead of reopening at the
                // top - has to wait a frame since the EditText doesn't know its own
                // scroll range until it's actually been laid out at its new size.
                val scrollToRestore = savedScrollY
                binding.editContent.post { binding.editContent.scrollTo(0, scrollToRestore) }
                applyCardStyle(binding)

                val undoRedo = UndoRedoManager(binding.editContent, serviceScope)
                undoRedo.reset()
                undoRedo.onStateChanged = { refreshUndoRedoButtons(binding, undoRedo) }
                refreshUndoRedoButtons(binding, undoRedo)
                binding.buttonUndo.setOnClickListener { undoRedo.undo() }
                binding.buttonRedo.setOnClickListener { undoRedo.redo() }
                binding.buttonNumberedList.setOnClickListener {
                    if (!expandNumberedListToken(binding.editContent)) {
                        Toast.makeText(this@FloatingNoteService, R.string.numbered_list_hint, Toast.LENGTH_SHORT).show()
                    }
                }

                val params = WindowManager.LayoutParams(
                    cardParams?.width ?: dpToPx(300f), cardParams?.height ?: dpToPx(360f),
                    overlayType,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                    PixelFormat.TRANSLUCENT
                ).apply {
                    gravity = Gravity.TOP or Gravity.START
                    x = cardParams?.x ?: dpToPx(40f)
                    y = cardParams?.y ?: dpToPx(120f)
                }
                cardParams = params

                setupCardDrag(binding, params)
                setupCardResize(binding, params)

                binding.buttonMinimize.setOnClickListener { minimizeToPreferredMode() }
                binding.buttonClose.setOnClickListener { destroy(save = true) }

                // The card starts non-focusable, like the bubble, so touches on it
                // (drag, resize, buttons) still work but Back/Home/etc. go straight
                // to whatever app is underneath instead of being swallowed - the note
                // just floats on top without taking over navigation. It only grabs
                // focus for as long as you're actually typing, so the keyboard can
                // show, and gives it back up the moment you're done.
                val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                fun setEditingFocusable(focusable: Boolean) {
                    val newFlags = if (focusable) {
                        params.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
                    } else {
                        params.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    }
                    if (newFlags != params.flags) {
                        params.flags = newFlags
                        runCatching { windowManager.updateViewLayout(binding.root, params) }
                    }
                }

                // EditTexts are focusable by default, and Android assigns the first
                // focusable view "logical" focus as soon as it's attached - even
                // inside a non-focusable window. That was silently flipping the
                // window focusable the instant the card appeared, before any tap,
                // which is exactly what kept swallowing Back. Starting them
                // unfocusable and only arming them on an explicit touch means
                // nothing grabs focus until you actually mean to type.
                binding.editTitle.isFocusable = false
                binding.editTitle.isFocusableInTouchMode = false
                binding.editContent.isFocusable = false
                binding.editContent.isFocusableInTouchMode = false

                fun armForEditing(field: View) {
                    field.setOnTouchListener { view, event ->
                        if (event.action == MotionEvent.ACTION_DOWN) {
                            view.isFocusable = true
                            view.isFocusableInTouchMode = true
                            setEditingFocusable(true)
                        }
                        false
                    }
                }
                armForEditing(binding.editTitle)
                armForEditing(binding.editContent)

                val focusListener = View.OnFocusChangeListener { view, hasFocus ->
                    if (hasFocus) {
                        view.post { imm.showSoftInput(view, InputMethodManager.SHOW_IMPLICIT) }
                    } else {
                        imm.hideSoftInputFromWindow(view.windowToken, 0)
                        view.isFocusable = false
                        view.isFocusableInTouchMode = false
                        setEditingFocusable(false)
                    }
                }
                binding.editTitle.onFocusChangeListener = focusListener
                binding.editContent.onFocusChangeListener = focusListener

                // Only reachable while the card currently holds focus (mid-edit) -
                // once non-focusable it never sees key events at all. Clearing focus
                // here (rather than consuming the press to close the whole card)
                // triggers the listener above, which drops the window back to
                // non-focusable so the *next* Back reaches the app underneath.
                binding.root.isFocusableInTouchMode = true
                binding.root.setOnKeyListener { _, keyCode, event ->
                    if (keyCode == KeyEvent.KEYCODE_BACK && event.action == KeyEvent.ACTION_UP) {
                        binding.editTitle.clearFocus()
                        binding.editContent.clearFocus()
                        imm.hideSoftInputFromWindow(binding.root.windowToken, 0)
                        setEditingFocusable(false)
                        true
                    } else {
                        false
                    }
                }

                val watcher = simpleWatcher {
                    note = note.copy(
                        title = binding.editTitle.text.toString(),
                        content = binding.editContent.text.toString()
                    )
                    scheduleSave()
                }
                binding.editTitle.addTextChangedListener(watcher)
                binding.editContent.addTextChangedListener(watcher)

                windowManager.addView(binding.root, params)
            } catch (e: Exception) {
                Log.e("FloatingNoteService", "Failed to show floating note card", e)
                cardBinding = null
                Toast.makeText(
                    this@FloatingNoteService,
                    "Couldn't show the floating note - check the \"display over other apps\" permission",
                    Toast.LENGTH_LONG
                ).show()
                windows.remove(this)
                if (windows.isEmpty()) stopSelf()
            }
        }

        private fun minimizeToPreferredMode() {
            when (PrefsManager.getMinimizeMode(this@FloatingNoteService)) {
                MinimizeMode.BUBBLE -> collapseToBubble()
                MinimizeMode.NOTIFICATION -> collapseToNotification()
            }
        }

        private fun collapseToBubble() {
            cancelMinimizedNotification()
            captureEditorState()
            removeCard()
            try {
                val binding = LayoutFloatingBubbleBinding.inflate(themedInflater)
                bubbleBinding = binding

                val size = dpToPx(BUBBLE_SIZE_DP)
                val params = WindowManager.LayoutParams(
                    size, size,
                    overlayType,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                    PixelFormat.TRANSLUCENT
                ).apply {
                    gravity = Gravity.TOP or Gravity.START
                    x = cardParams?.x ?: dpToPx(16f)
                    y = cardParams?.y ?: dpToPx(120f)
                }

                setupBubbleDrag(binding, params)
                windowManager.addView(binding.root, params)
            } catch (e: Exception) {
                Log.e("FloatingNoteService", "Failed to show floating bubble", e)
                bubbleBinding = null
                windows.remove(this)
                if (windows.isEmpty()) stopSelf()
            }
        }

        /** Minimize by fully removing the overlay and showing a regular status-bar
         *  notification instead of a floating bubble. Tapping it re-expands the
         *  card; swiping it away closes the note (same as the bubble's close). */
        private fun collapseToNotification() {
            captureEditorState()
            removeCard()
            removeBubble()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    MINIMIZED_CHANNEL_ID, "Minimized notes", NotificationManager.IMPORTANCE_DEFAULT
                )
                getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
            }
            val expandIntent = PendingIntent.getService(
                this@FloatingNoteService, notifKey,
                Intent(this@FloatingNoteService, FloatingNoteService::class.java)
                    .setAction(ACTION_EXPAND_NOTE)
                    .putExtra(EXTRA_WINDOW_KEY, notifKey),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val dismissIntent = PendingIntent.getService(
                this@FloatingNoteService, notifKey + 1,
                Intent(this@FloatingNoteService, FloatingNoteService::class.java)
                    .setAction(ACTION_DISMISS_NOTE)
                    .putExtra(EXTRA_WINDOW_KEY, notifKey),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val notification = NotificationCompat.Builder(this@FloatingNoteService, MINIMIZED_CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_note)
                .setContentTitle(note.title.ifBlank { "Untitled note" })
                .setContentText(note.content.take(80).ifBlank { "Empty note" })
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setOngoing(false)
                .setAutoCancel(true)
                .setContentIntent(expandIntent)
                .setDeleteIntent(dismissIntent)
                .build()
            getSystemService(NotificationManager::class.java).notify(notifKey, notification)
            isMinimizedAsNotification = true
        }

        private fun cancelMinimizedNotification() {
            if (!isMinimizedAsNotification) return
            getSystemService(NotificationManager::class.java).cancel(notifKey)
            isMinimizedAsNotification = false
        }

        private fun setupCardDrag(binding: LayoutFloatingNoteBinding, params: WindowManager.LayoutParams) {
            var startX = 0
            var startY = 0
            var touchX = 0f
            var touchY = 0f
            binding.dragHandle.setOnTouchListener { _, event ->
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = params.x
                        startY = params.y
                        touchX = event.rawX
                        touchY = event.rawY
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = startX + (event.rawX - touchX).toInt()
                        params.y = startY + (event.rawY - touchY).toInt()
                        runCatching { windowManager.updateViewLayout(binding.root, params) }
                        true
                    }
                    else -> false
                }
            }
        }

        private fun setupCardResize(binding: LayoutFloatingNoteBinding, params: WindowManager.LayoutParams) {
            var startWidth = 0
            var startHeight = 0
            var touchX = 0f
            var touchY = 0f
            val minSize = dpToPx(220f)
            val maxSize = dpToPx(500f)
            binding.resizeHandle.setOnTouchListener { _, event ->
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startWidth = params.width
                        startHeight = params.height
                        touchX = event.rawX
                        touchY = event.rawY
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.width = (startWidth + (event.rawX - touchX).toInt()).coerceIn(minSize, maxSize)
                        params.height = (startHeight + (event.rawY - touchY).toInt()).coerceIn(minSize, maxSize)
                        runCatching { windowManager.updateViewLayout(binding.root, params) }
                        true
                    }
                    else -> false
                }
            }
        }

        private fun setupBubbleDrag(binding: LayoutFloatingBubbleBinding, params: WindowManager.LayoutParams) {
            var startX = 0
            var startY = 0
            var touchX = 0f
            var touchY = 0f
            var moved = false
            val screenWidth = resources.displayMetrics.widthPixels
            binding.root.setOnTouchListener { _, event ->
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = params.x
                        startY = params.y
                        touchX = event.rawX
                        touchY = event.rawY
                        moved = false
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = event.rawX - touchX
                        val dy = event.rawY - touchY
                        if (abs(dx) > 8 || abs(dy) > 8) moved = true
                        params.x = startX + dx.toInt()
                        params.y = startY + dy.toInt()
                        runCatching { windowManager.updateViewLayout(binding.root, params) }
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (moved) {
                            cardParams = params
                            snapToEdge(binding, params, screenWidth)
                        } else {
                            expand()
                        }
                        true
                    }
                    else -> false
                }
            }
        }

        private fun snapToEdge(binding: LayoutFloatingBubbleBinding, params: WindowManager.LayoutParams, screenWidth: Int) {
            val targetX = if (params.x + params.width / 2 < screenWidth / 2) 0 else screenWidth - params.width
            val animator = ValueAnimator.ofInt(params.x, targetX)
            animator.interpolator = OvershootInterpolator(0.9f)
            animator.duration = 250
            animator.addUpdateListener {
                params.x = it.animatedValue as Int
                runCatching { windowManager.updateViewLayout(binding.root, params) }
            }
            animator.start()
        }

        private fun applyCardStyle(binding: LayoutFloatingNoteBinding) {
            val style = PaperStyles.get(PrefsManager.getGlobalStyleIndex(this@FloatingNoteService))
            val color = ContextCompat.getColor(this@FloatingNoteService, style.coverColor)
            binding.dragHandle.setBackgroundColor(color)
            binding.colorDot.backgroundTintList = ColorStateList.valueOf(color)
            binding.editContent.pattern = style.pattern
        }

        private fun refreshUndoRedoButtons(binding: LayoutFloatingNoteBinding, undoRedo: UndoRedoManager) {
            binding.buttonUndo.isEnabled = undoRedo.canUndo()
            binding.buttonUndo.alpha = if (undoRedo.canUndo()) 1f else 0.35f
            binding.buttonRedo.isEnabled = undoRedo.canRedo()
            binding.buttonRedo.alpha = if (undoRedo.canRedo()) 1f else 0.35f
        }

        private fun scheduleSave() {
            saveJob?.cancel()
            saveJob = serviceScope.launch {
                delay(600)
                note = note.copy(id = repository.save(note))
            }
        }

        fun destroy(save: Boolean) {
            saveJob?.cancel()
            if (save && (note.title.isNotBlank() || note.content.isNotBlank())) {
                serviceScope.launch { repository.save(note) }
            }
            cancelMinimizedNotification()
            removeCard()
            removeBubble()
            windows.remove(this)
            if (windows.isEmpty()) stopSelf()
        }

        private fun captureEditorState() {
            cardBinding?.editContent?.let {
                savedScrollY = it.scrollY
                savedSelectionStart = it.selectionStart
                savedSelectionEnd = it.selectionEnd
            }
        }

        private fun removeCard() {
            cardBinding?.root?.let { runCatching { windowManager.removeView(it) } }
            cardBinding = null
        }

        private fun removeBubble() {
            bubbleBinding?.root?.let { runCatching { windowManager.removeView(it) } }
            bubbleBinding = null
        }
    }

    companion object {
        const val ACTION_SHOW_NOTE = "com.jarry.floatnote.action.SHOW_NOTE"
        const val ACTION_CLOSE_ALL = "com.jarry.floatnote.action.CLOSE_ALL"
        const val ACTION_EXPAND_NOTE = "com.jarry.floatnote.action.EXPAND_NOTE"
        const val ACTION_DISMISS_NOTE = "com.jarry.floatnote.action.DISMISS_NOTE"
        const val EXTRA_NOTE_ID = "extra_note_id"
        const val EXTRA_WINDOW_KEY = "extra_window_key"
        private const val CHANNEL_ID = "floating_notes_channel"
        private const val MINIMIZED_CHANNEL_ID = "minimized_notes_channel"
        private const val NOTIF_ID = 42
        private const val BUBBLE_SIZE_DP = 44f

        // Notification/PendingIntent request codes for minimized notes, kept well
        // clear of NOTIF_ID and independent of note.id (which can be 0 for an
        // unsaved note).
        private val notifKeySeq = AtomicInteger(1000)
        private fun nextNotifKey(): Int = notifKeySeq.getAndAdd(2)
    }
}
