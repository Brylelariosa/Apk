package com.jarry.floatnote.data

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/** Plain SQLiteOpenHelper - no Room/KSP, keeps the dependency graph (and APK) small. */
class NoteDbHelper(context: Context) :
    SQLiteOpenHelper(context.applicationContext, DB_NAME, null, DB_VERSION) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE $TABLE (
                $COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_TITLE TEXT NOT NULL DEFAULT '',
                $COL_CONTENT TEXT NOT NULL DEFAULT '',
                $COL_COLOR INTEGER NOT NULL DEFAULT 0,
                $COL_PINNED INTEGER NOT NULL DEFAULT 0,
                $COL_CREATED INTEGER NOT NULL,
                $COL_UPDATED INTEGER NOT NULL
            )
            """.trimIndent()
        )
        createIndexes(db)
    }

    // Each branch here only ever ADDS things (indexes, columns) and never
    // drops or recreates $TABLE, so existing notes always survive an
    // upgrade - this used to unconditionally DROP TABLE + recreate on any
    // version bump, which would have silently wiped every saved note the
    // moment DB_VERSION was next incremented. Add the next `if (oldVersion < N)`
    // branch here when the schema changes again.
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            createIndexes(db)
        }
    }

    private fun createIndexes(db: SQLiteDatabase) {
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_updated ON $TABLE($COL_UPDATED DESC)")
        // Every query in this app sorts by pinned-then-updated together (see
        // getAll below), so a composite index on both columns lets SQLite
        // satisfy that sort directly from the index instead of scanning the
        // table and sorting in memory.
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_pinned_updated ON $TABLE($COL_PINNED DESC, $COL_UPDATED DESC)")
    }

    fun insert(note: Note): Long = writableDatabase.insert(TABLE, null, toValues(note))

    fun update(note: Note): Int =
        writableDatabase.update(TABLE, toValues(note), "$COL_ID = ?", arrayOf(note.id.toString()))

    fun delete(id: Long) {
        writableDatabase.delete(TABLE, "$COL_ID = ?", arrayOf(id.toString()))
    }

    fun getById(id: Long): Note? {
        readableDatabase.query(
            TABLE, null, "$COL_ID = ?", arrayOf(id.toString()), null, null, null
        ).use { c ->
            return if (c.moveToFirst()) c.toNote() else null
        }
    }

    fun getAll(query: String = ""): List<Note> {
        val selection = if (query.isNotBlank()) {
            "$COL_TITLE LIKE ? ESCAPE '\\' OR $COL_CONTENT LIKE ? ESCAPE '\\'"
        } else {
            null
        }
        val args = if (query.isNotBlank()) {
            // Escape SQLite's own LIKE wildcards (% and _) and the escape
            // character itself so a search for e.g. "50% off" or
            // "file_name" matches those literal characters instead of being
            // interpreted as a wildcard pattern.
            val likeArg = "%${escapeLike(query)}%"
            arrayOf(likeArg, likeArg)
        } else {
            null
        }
        val order = "$COL_PINNED DESC, $COL_UPDATED DESC"
        val notes = mutableListOf<Note>()
        readableDatabase.query(TABLE, null, selection, args, null, null, order).use { c ->
            while (c.moveToNext()) notes.add(c.toNote())
        }
        return notes
    }

    private fun escapeLike(raw: String): String =
        raw.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")

    private fun toValues(note: Note) = ContentValues().apply {
        put(COL_TITLE, note.title)
        put(COL_CONTENT, note.content)
        put(COL_COLOR, note.styleIndex)
        put(COL_PINNED, if (note.isPinned) 1 else 0)
        put(COL_CREATED, note.createdAt)
        put(COL_UPDATED, note.updatedAt)
    }

    private fun Cursor.toNote() = Note(
        id = getLong(getColumnIndexOrThrow(COL_ID)),
        title = getString(getColumnIndexOrThrow(COL_TITLE)),
        content = getString(getColumnIndexOrThrow(COL_CONTENT)),
        styleIndex = getInt(getColumnIndexOrThrow(COL_COLOR)),
        isPinned = getInt(getColumnIndexOrThrow(COL_PINNED)) == 1,
        createdAt = getLong(getColumnIndexOrThrow(COL_CREATED)),
        updatedAt = getLong(getColumnIndexOrThrow(COL_UPDATED))
    )

    companion object {
        private const val DB_NAME = "floatnote.db"
        private const val DB_VERSION = 2
        private const val TABLE = "notes"
        private const val COL_ID = "_id"
        private const val COL_TITLE = "title"
        private const val COL_CONTENT = "content"
        private const val COL_COLOR = "color"
        private const val COL_PINNED = "pinned"
        private const val COL_CREATED = "created_at"
        private const val COL_UPDATED = "updated_at"
    }
}
