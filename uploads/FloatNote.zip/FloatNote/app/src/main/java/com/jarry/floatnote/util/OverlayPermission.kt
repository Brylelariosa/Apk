package com.jarry.floatnote.util

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.view.View
import com.google.android.material.snackbar.Snackbar

/**
 * Shared "display over other apps" permission check, used by every entry
 * point that can start FloatingNoteService. Centralizing this avoids the bug
 * where one entry point checks the permission and another forgets to -
 * calling WindowManager.addView(TYPE_APPLICATION_OVERLAY) without this
 * permission throws and crashes the app.
 */
object OverlayPermission {
    fun isGranted(context: Context): Boolean = Settings.canDrawOverlays(context)

    fun request(activity: Activity, anchor: View) {
        activity.startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${activity.packageName}"))
        )
        Snackbar.make(anchor, "Allow \"display over other apps\", then try again", Snackbar.LENGTH_LONG).show()
    }
}
