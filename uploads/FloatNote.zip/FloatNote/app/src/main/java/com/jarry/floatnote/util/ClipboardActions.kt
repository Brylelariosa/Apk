package com.jarry.floatnote.util

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.EditText
import com.jarry.floatnote.R

/**
 * Copies the current text selection in [editText] to the clipboard, or the
 * whole field when nothing is selected. Returns false if there was nothing
 * to copy (an empty field).
 *
 * A floating overlay window doesn't reliably show the system's own
 * copy/paste popup (it depends on window focus a non-modal overlay only has
 * while actively being typed in), so both this and [pasteFromClipboard] back
 * explicit toolbar buttons instead of relying on long-press selection alone.
 */
fun copySelectionOrAll(editText: EditText, context: Context): Boolean {
    val text = editText.text ?: return false
    val start = editText.selectionStart
    val end = editText.selectionEnd
    val toCopy = if (start in 0 until end) text.subSequence(start, end) else text
    if (toCopy.isEmpty()) return false
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    clipboard.setPrimaryClip(ClipData.newPlainText(context.getString(R.string.app_name), toCopy))
    return true
}

/**
 * Pastes the clipboard's text content into [editText] at the current
 * selection (replacing it) or cursor position, leaving the cursor right
 * after the pasted text. Returns false if the clipboard has no text to
 * paste.
 */
fun pasteFromClipboard(editText: EditText, context: Context): Boolean {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip = clipboard.primaryClip
    if (clip == null || clip.itemCount == 0) return false
    val pasted = clip.getItemAt(0).coerceToText(context)
    if (pasted.isEmpty()) return false
    val text = editText.text ?: return false
    val start = editText.selectionStart.coerceIn(0, text.length)
    val end = editText.selectionEnd.coerceIn(0, text.length)
    val from = minOf(start, end)
    text.replace(from, maxOf(start, end), pasted)
    editText.setSelection(from + pasted.length)
    return true
}
