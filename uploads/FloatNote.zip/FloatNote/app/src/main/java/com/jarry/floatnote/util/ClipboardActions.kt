package com.jarry.floatnote.util

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.EditText
import android.widget.Toast
import com.jarry.floatnote.R

/**
 * Copies the current text selection in [editText] to the clipboard, or the
 * whole field when nothing is selected. A floating overlay window doesn't
 * reliably show the system's own copy/paste popup (it depends on window
 * focus a non-modal overlay only has while actively being typed in), so the
 * floating card exposes this as an explicit button instead of relying on
 * long-press selection alone.
 */
fun copySelectionOrAll(editText: EditText, context: Context) {
    val text = editText.text ?: return
    val start = editText.selectionStart
    val end = editText.selectionEnd
    val toCopy = if (start in 0 until end) text.subSequence(start, end) else text
    if (toCopy.isEmpty()) return
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    clipboard.setPrimaryClip(ClipData.newPlainText(context.getString(R.string.app_name), toCopy))
    Toast.makeText(context, R.string.copied_to_clipboard, Toast.LENGTH_SHORT).show()
}
