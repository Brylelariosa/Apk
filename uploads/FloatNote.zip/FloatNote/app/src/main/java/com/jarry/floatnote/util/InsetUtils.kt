package com.jarry.floatnote.util

import android.view.View
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding

/** Applies the system bars' top inset as this view's top padding, keeping it
 *  clear of the status bar in edge-to-edge layouts. */
fun View.applyTopSystemBarPadding() {
    ViewCompat.setOnApplyWindowInsetsListener(this) { v, insets ->
        v.updatePadding(top = insets.getInsets(WindowInsetsCompat.Type.systemBars()).top)
        insets
    }
}

/** Applies the system bars' bottom inset as this view's bottom padding,
 *  keeping it clear of the nav bar / gesture area in edge-to-edge layouts. */
fun View.applyBottomSystemBarPadding() {
    ViewCompat.setOnApplyWindowInsetsListener(this) { v, insets ->
        v.updatePadding(bottom = insets.getInsets(WindowInsetsCompat.Type.systemBars()).bottom)
        insets
    }
}
