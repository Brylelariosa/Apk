package com.jarry.floatnote.widget

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatEditText
import androidx.core.content.ContextCompat
import com.jarry.floatnote.R
import com.jarry.floatnote.util.PaperPattern

/**
 * An EditText that draws a paper-style background pattern behind the text:
 * ruled lines (with a red margin line), a grid, a dot-grid, or nothing
 * (blank). Spacing is read from the EditText's own lineHeight/font metrics,
 * not a fixed dp value, so the pattern always lines up with the actual text
 * no matter the font size. Patterns are drawn all the way to the bottom of
 * the view, not just behind typed lines, so it reads as a full page from the
 * moment a note opens.
 */
class PatternedEditText @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = android.R.attr.editTextStyle
) : AppCompatEditText(context, attrs, defStyleAttr) {

    private val density = resources.displayMetrics.density

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeWidth = density
        color = ContextCompat.getColor(context, R.color.paper_rule_line)
    }

    private val marginPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeWidth = density
        color = ContextCompat.getColor(context, R.color.paper_margin_line)
    }

    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = ContextCompat.getColor(context, R.color.paper_rule_line)
    }

    var pattern: PaperPattern = PaperPattern.RULED
        set(value) {
            field = value
            invalidate()
        }

    var showMarginLine: Boolean = true
        set(value) {
            field = value
            invalidate()
        }

    override fun onDraw(canvas: Canvas) {
        when (pattern) {
            PaperPattern.RULED -> {
                drawRules(canvas)
                drawMargin(canvas)
            }
            PaperPattern.GRID -> drawGrid(canvas)
            PaperPattern.DOT -> drawDots(canvas)
            PaperPattern.BLANK -> Unit
        }
        super.onDraw(canvas)
    }

    private fun lineStep(): Float {
        val lineH = lineHeight.toFloat()
        return if (lineH > 0f) lineH else textSize * 1.3f
    }

    private fun drawRules(canvas: Canvas) {
        val lineH = lineStep()
        if (lineH <= 0f) return
        val fm = paint.fontMetrics
        val left = paddingLeft.toFloat()
        val right = (width - paddingRight).toFloat()
        val top = scrollY.toFloat()
        val bottom = scrollY + (height - paddingBottom).toFloat()
        // Draw each rule a little below its text baseline (capped so it never
        // creeps into the next line) instead of exactly on it, so descenders
        // and glyph edges sit clear of the line instead of touching/overlapping it.
        val ruleGap = (fm.descent * 0.6f).coerceIn(0f, lineH * 0.22f)

        // Fallback anchor for when there's no Layout yet (shouldn't happen in
        // practice inside onDraw, but keeps this safe).
        var lastBaseline = paddingTop - fm.top

        val textLayout = layout
        if (textLayout != null) {
            val lineCount = textLayout.lineCount
            if (lineCount > 0) {
                // Use the real per-line baselines from the EditText's own Layout
                // instead of repeatedly adding a fixed lineHeight step, so rules
                // stay locked to the glyphs above them (lineSpacingExtra, wrapped
                // long lines like URLs, etc. each round slightly differently and
                // drift out of sync with a fixed step over a long note).
                //
                // Only walk lines within the visible (scrolled) window - onDraw
                // runs on every scroll frame, so looping every line in the whole
                // note each time is what made scrolling feel slow. getLineForVertical
                // jumps straight to the right range instead of a full scan.
                val firstLine = textLayout.getLineForVertical((top - paddingTop).toInt().coerceAtLeast(0))
                    .coerceIn(0, lineCount - 1)
                val lastLine = textLayout.getLineForVertical((bottom - paddingTop).toInt())
                    .coerceIn(0, lineCount - 1)
                for (i in firstLine..lastLine) {
                    val baseline = paddingTop + textLayout.getLineBaseline(i).toFloat()
                    val ruleY = baseline + ruleGap
                    canvas.drawLine(left, ruleY, right, ruleY, linePaint)
                }
                lastBaseline = paddingTop + textLayout.getLineBaseline(lineCount - 1).toFloat()
            }
        }

        // Continue the ruled pattern below the last typed line so the page still
        // reads as fully lined from the moment the note opens. Drift doesn't matter
        // here since there's no text to stay in sync with yet.
        var baseline = lastBaseline + lineH
        while (baseline <= bottom) {
            val ruleY = baseline + ruleGap
            canvas.drawLine(left, ruleY, right, ruleY, linePaint)
            baseline += lineH
        }
    }

    private fun drawMargin(canvas: Canvas) {
        if (!showMarginLine) return
        val x = paddingLeft - (10f * density)
        if (x > 0f) {
            val top = scrollY.toFloat()
            val bottom = (scrollY + height).toFloat()
            canvas.drawLine(x, top, x, bottom, marginPaint)
        }
    }

    private fun drawGrid(canvas: Canvas) {
        val step = lineStep() * 0.72f
        if (step <= 0f) return
        val left = paddingLeft.toFloat()
        val right = (width - paddingRight).toFloat()
        val top = scrollY.toFloat()
        val bottom = scrollY + (height - paddingBottom).toFloat()
        val firstY = paddingTop.toFloat()
        val skipped = kotlin.math.floor((top - firstY) / step).toInt().coerceAtLeast(0)
        var y = firstY + skipped * step
        while (y <= bottom) {
            canvas.drawLine(left, y, right, y, linePaint)
            y += step
        }
        var x = left
        while (x <= right) {
            canvas.drawLine(x, top, x, bottom, linePaint)
            x += step
        }
    }

    private fun drawDots(canvas: Canvas) {
        val step = lineStep() * 0.72f
        if (step <= 0f) return
        val left = paddingLeft.toFloat()
        val right = (width - paddingRight).toFloat()
        val top = scrollY.toFloat()
        val bottom = scrollY + (height - paddingBottom).toFloat()
        val radius = density * 1.1f
        val firstY = paddingTop.toFloat()
        val skipped = kotlin.math.floor((top - firstY) / step).toInt().coerceAtLeast(0)
        var y = firstY + skipped * step
        while (y <= bottom) {
            var x = left
            while (x <= right) {
                canvas.drawCircle(x, y, radius, dotPaint)
                x += step
            }
            y += step
        }
    }
}
