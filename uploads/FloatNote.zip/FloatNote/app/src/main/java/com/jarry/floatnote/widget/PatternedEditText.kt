package com.jarry.floatnote.widget

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatEditText
import androidx.core.content.ContextCompat
import com.jarry.floatnote.R
import com.jarry.floatnote.util.PaperPattern

/**
 * An EditText that draws a paper-style background pattern behind the text:
 * ruled lines (with a red margin line), a grid, a dot-grid, or nothing
 * (blank). Spacing is read from the EditText's own lineHeight/font metrics,
 * not a fixed dp value, so the pattern always lines up with the actual text
 * no matter the font size. Patterns are drawn all the way to the bottom of
 * the view, not just behind typed lines, so it reads as a full page from the
 * moment a note opens.
 */
class PatternedEditText @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = android.R.attr.editTextStyle
) : AppCompatEditText(context, attrs, defStyleAttr) {

    private val density = resources.displayMetrics.density

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeWidth = density
        color = ContextCompat.getColor(context, R.color.paper_rule_line)
    }

    private val marginPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeWidth = density
        color = ContextCompat.getColor(context, R.color.paper_margin_line)
    }

    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = ContextCompat.getColor(context, R.color.paper_rule_line)
    }

    var pattern: PaperPattern = PaperPattern.RULED
        set(value) {
            field = value
            invalidate()
        }

    var showMarginLine: Boolean = true
        set(value) {
            field = value
            invalidate()
        }

    override fun onDraw(canvas: Canvas) {
        when (pattern) {
            PaperPattern.RULED -> {
                drawRules(canvas)
                drawMargin(canvas)
            }
            PaperPattern.GRID -> drawGrid(canvas)
            PaperPattern.DOT -> drawDots(canvas)
            PaperPattern.BLANK -> Unit
        }
        super.onDraw(canvas)
    }

    private fun lineStep(): Float {
        val lineH = lineHeight.toFloat()
        return if (lineH > 0f) lineH else textSize * 1.3f
    }

    private fun drawRules(canvas: Canvas) {
        val lineH = lineStep()
        if (lineH <= 0f) return
        val fm = paint.fontMetrics
        val left = paddingLeft.toFloat()
        val right = (width - paddingRight).toFloat()
        val bottom = (height - paddingBottom).toFloat()
        var baseline = paddingTop - fm.top
        while (baseline <= bottom) {
            canvas.drawLine(left, baseline, right, baseline, linePaint)
            baseline += lineH
        }
    }

    private fun drawMargin(canvas: Canvas) {
        if (!showMarginLine) return
        val x = paddingLeft - (10f * density)
        if (x > 0f) {
            canvas.drawLine(x, 0f, x, height.toFloat(), marginPaint)
        }
    }

    private fun drawGrid(canvas: Canvas) {
        val step = lineStep() * 0.72f
        if (step <= 0f) return
        val left = paddingLeft.toFloat()
        val top = paddingTop.toFloat()
        val right = (width - paddingRight).toFloat()
        val bottom = (height - paddingBottom).toFloat()
        var y = top
        while (y <= bottom) {
            canvas.drawLine(left, y, right, y, linePaint)
            y += step
        }
        var x = left
        while (x <= right) {
            canvas.drawLine(x, top, x, bottom, linePaint)
            x += step
        }
    }

    private fun drawDots(canvas: Canvas) {
        val step = lineStep() * 0.72f
        if (step <= 0f) return
        val left = paddingLeft.toFloat()
        val top = paddingTop.toFloat()
        val right = (width - paddingRight).toFloat()
        val bottom = (height - paddingBottom).toFloat()
        val radius = density * 1.1f
        var y = top
        while (y <= bottom) {
            var x = left
            while (x <= right) {
                canvas.drawCircle(x, y, radius, dotPaint)
                x += step
            }
            y += step
        }
    }
}
