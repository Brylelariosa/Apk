package com.jarry.floatnote.util

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Runs [action] after [delayMillis] of inactivity, restarting the wait on
 * every new call to [schedule] - used to auto-save while the user is still
 * typing without hammering the DB on every keystroke.
 */
class Debouncer(
    private val scope: CoroutineScope,
    private val delayMillis: Long = 600L
) {
    private var job: Job? = null

    fun schedule(action: suspend () -> Unit) {
        job?.cancel()
        job = scope.launch {
            delay(delayMillis)
            action()
        }
    }

    fun cancel() {
        job?.cancel()
    }
}
