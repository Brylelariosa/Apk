package com.jarry.floatnote.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class NoteRepository private constructor(context: Context) {
    private val dbHelper = NoteDbHelper(context)

    suspend fun getAll(query: String = ""): List<Note> = withContext(Dispatchers.IO) {
        dbHelper.getAll(query)
    }

    suspend fun getById(id: Long): Note? = withContext(Dispatchers.IO) {
        dbHelper.getById(id)
    }

    suspend fun save(note: Note): Long = withContext(Dispatchers.IO) {
        val stamped = note.copy(updatedAt = System.currentTimeMillis())
        if (stamped.id == 0L) {
            dbHelper.insert(stamped)
        } else {
            dbHelper.update(stamped)
            stamped.id
        }
    }

    suspend fun delete(id: Long) = withContext(Dispatchers.IO) {
        dbHelper.delete(id)
    }

    companion object {
        @Volatile private var instance: NoteRepository? = null
        fun getInstance(context: Context): NoteRepository =
            instance ?: synchronized(this) {
                instance ?: NoteRepository(context.applicationContext).also { instance = it }
            }
    }
}
