package com.jarry.floatnote.data

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Suspend wrapper around [NoteDbHelper] that also centralizes error
 * handling for the whole app: every DB operation can in principle throw
 * (disk full, corrupt database file, etc.), and callers shouldn't have to
 * guard against that individually. Failures are logged and degraded to a
 * safe fallback (an empty list, a null note, an unchanged id) rather than
 * propagating and crashing whatever screen or floating window triggered them.
 */
class NoteRepository private constructor(context: Context) {
    private val dbHelper = NoteDbHelper(context)

    suspend fun getAll(query: String = ""): List<Note> = withContext(Dispatchers.IO) {
        try {
            dbHelper.getAll(query)
        } catch (e: Exception) {
            Log.e(TAG, "getAll failed", e)
            emptyList()
        }
    }

    suspend fun getById(id: Long): Note? = withContext(Dispatchers.IO) {
        try {
            dbHelper.getById(id)
        } catch (e: Exception) {
            Log.e(TAG, "getById($id) failed", e)
            null
        }
    }

    suspend fun save(note: Note): Long = withContext(Dispatchers.IO) {
        val stamped = note.copy(updatedAt = System.currentTimeMillis())
        try {
            if (stamped.id == 0L) {
                dbHelper.insert(stamped)
            } else {
                dbHelper.update(stamped)
                stamped.id
            }
        } catch (e: Exception) {
            Log.e(TAG, "save(${note.id}) failed", e)
            // Fall back to whatever id the note already had so the caller's
            // in-memory state stays consistent (a new note stays "unsaved"
            // rather than being mistaken for a successful insert).
            note.id
        }
    }

    suspend fun delete(id: Long) = withContext(Dispatchers.IO) {
        try {
            dbHelper.delete(id)
        } catch (e: Exception) {
            Log.e(TAG, "delete($id) failed", e)
        }
    }

    companion object {
        private const val TAG = "NoteRepository"

        @Volatile private var instance: NoteRepository? = null
        fun getInstance(context: Context): NoteRepository =
            instance ?: synchronized(this) {
                instance ?: NoteRepository(context.applicationContext).also { instance = it }
            }
    }
}
