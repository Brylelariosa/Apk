package com.jarry.floatnote.util

import android.content.Context

/** How a floating note behaves when the user taps minimize. */
enum class MinimizeMode { BUBBLE, NOTIFICATION }

object PrefsManager {
    private const val PREFS = "floatnote_prefs"
    private const val KEY_FLOATING_MODE = "floating_mode"
    private const val KEY_GLOBAL_STYLE = "global_style_index"
    private const val KEY_MINIMIZE_MODE = "minimize_mode"
    private const val KEY_CONTENT_TEXT_SIZE = "content_text_size_sp"

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun isFloatingModeEnabled(context: Context): Boolean =
        prefs(context).getBoolean(KEY_FLOATING_MODE, false)

    fun setFloatingModeEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_FLOATING_MODE, enabled).apply()
    }

    /** One app-wide paper style (cover color + pattern) used by every note,
     *  chosen once in Settings instead of per-note. */
    fun getGlobalStyleIndex(context: Context): Int =
        prefs(context).getInt(KEY_GLOBAL_STYLE, 0)

    fun setGlobalStyleIndex(context: Context, index: Int) {
        prefs(context).edit().putInt(KEY_GLOBAL_STYLE, index).apply()
    }

    fun getMinimizeMode(context: Context): MinimizeMode {
        val stored = prefs(context).getString(KEY_MINIMIZE_MODE, null)
        return runCatching { MinimizeMode.valueOf(stored ?: "") }.getOrDefault(MinimizeMode.BUBBLE)
    }

    fun setMinimizeMode(context: Context, mode: MinimizeMode) {
        prefs(context).edit().putString(KEY_MINIMIZE_MODE, mode.name).apply()
    }

    /** One app-wide note content text size (sp), same idea as [getGlobalStyleIndex]. */
    fun getContentTextSizeSp(context: Context): Float =
        prefs(context).getFloat(KEY_CONTENT_TEXT_SIZE, DEFAULT_CONTENT_TEXT_SIZE_SP)

    fun setContentTextSizeSp(context: Context, sizeSp: Float) {
        prefs(context).edit().putFloat(KEY_CONTENT_TEXT_SIZE, sizeSp).apply()
    }
}
