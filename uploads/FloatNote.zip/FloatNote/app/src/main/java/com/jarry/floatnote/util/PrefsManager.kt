package com.jarry.floatnote.util

import android.content.Context

object PrefsManager {
    private const val PREFS = "floatnote_prefs"
    private const val KEY_FLOATING_MODE = "floating_mode"

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun isFloatingModeEnabled(context: Context): Boolean =
        prefs(context).getBoolean(KEY_FLOATING_MODE, false)

    fun setFloatingModeEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_FLOATING_MODE, enabled).apply()
    }
}
