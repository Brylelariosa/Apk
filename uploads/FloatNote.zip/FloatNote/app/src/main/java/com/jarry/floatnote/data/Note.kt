package com.jarry.floatnote.data

data class Note(
    val id: Long = 0L,
    val title: String = "",
    val content: String = "",
    val styleIndex: Int = 0,
    val isPinned: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
