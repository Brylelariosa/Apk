package com.jarry.floatnote.util

import android.text.Editable
import android.text.TextWatcher

fun simpleWatcher(onChanged: () -> Unit): TextWatcher = object : TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
        onChanged()
    }
    override fun afterTextChanged(s: Editable?) {}
}
