package com.zipapkbuilder.feature.filemanager

import android.net.Uri
import com.zipapkbuilder.MainActivity
import com.zipapkbuilder.core.UriUtils
import com.zipapkbuilder.net.GitHubApi
import com.zipapkbuilder.net.NetworkReliability

/**
 * Uploads a single local file (picked from the device, not a project ZIP —
 * see [com.zipapkbuilder.feature.build.BuildFlowController] for that) into the
 * repo via the Contents API. Split out of [FileManagerController] since it's
 * a self-contained, independently-triggerable feature (reached from the file
 * manager's "New → Upload File" entry, via [FileOperationController.showNewItemDialog])
 * with no dependency on browsing, editing, or the other file operations.
 *
 * Shares [com.zipapkbuilder.feature.upload.UploadCoordinator] — the same
 * retry/progress/cancellation machinery
 * [com.zipapkbuilder.feature.build.BuildUploadCoordinator]'s small-file path
 * uses for the build ZIP — rather than calling
 * [GitHubApi.uploadStreamingBase64] directly with retry/progress/cancellation
 * all hardwired off, which was the one upload path in the app that had none
 * of the three.
 */
class FileUploadController(private val activity: MainActivity) {

    /**
     * Streams [uri] from the device straight into a base64-encoded Contents
     * API PUT (see [GitHubApi.uploadStreamingBase64]) — the raw file, its
     * base64 form, and the JSON body are never all held in memory at once,
     * same as [com.zipapkbuilder.feature.build.BuildFlowController]'s ZIP
     * upload, which shares this envelope via [GitHubApi.contentsApiEnvelope].
     * Binary files (images, zips, APKs…) are handled the same way as text —
     * the GitHub Contents API accepts any base-64 payload regardless of MIME
     * type. Files > ~50 MB will be rejected by the API; we warn early.
     *
     * Runs the actual PUT through [com.zipapkbuilder.feature.upload.UploadCoordinator.withUploadRetry]
     * (exponential-backoff retry on transient/network failures, automatic
     * offline pause-and-resume) and reports progress via the same floating
     * upload bubble the build-ZIP upload uses, so a large file picked from
     * Manage Files behaves identically to one uploaded as part of a build —
     * cancellable from that bubble, retried automatically on a flaky
     * connection, instead of failing outright on the first hiccup.
     */
    fun uploadFileToRepo(
        token: String, owner: String, repo: String, branch: String,
        filePath: String, uri: Uri, refreshPath: String
    ) {
        val uploadCoordinator = activity.uploadCoordinator
        try {
            val rawLength = UriUtils.resolveFileSize(activity.contentResolver, uri)
            if (rawLength > 50 * 1024 * 1024) {
                activity.appendLog("✗ File too large for GitHub Contents API (> 50 MB)."); return
            }
            activity.appendLog("  Size: ${rawLength / 1024} KB")

            val existingSha = activity.buildFlowController.fetchFileSha(token, owner, repo, filePath)
            uploadCoordinator.uploadCancelled = false
            val handle = uploadCoordinator.beginUpload(filePath.substringAfterLast('/'), GitHubApi.base64EncodedLength(rawLength))
            var ok = false
            val (code, body) = try {
                uploadCoordinator.withUploadRetry(handle) {
                    uploadCoordinator.uploadFileViaContentsApi(
                        token, owner, repo, branch, filePath,
                        message = "upload: $filePath via ZipApkBuilder [skip ci]",
                        sourceUri = uri, rawLength = rawLength, existingSha = existingSha
                    ) { written, total -> handle.onProgress(written, total) }
                        .also { (c, b) ->
                            // Treat a retryable-but-returned (not thrown) HTTP code as a
                            // failure withUploadRetry can see and retry, same as the
                            // build-ZIP upload path does.
                            if (c in NetworkReliability.RETRYABLE_HTTP_CODES) throw Exception("Upload failed ($c): ${b.take(200)}")
                        }
                }.also { (c, _) -> ok = c in 200..201 }
            } finally {
                handle.finish(ok)
            }
            if (uploadCoordinator.uploadCancelled) { activity.appendLog("⚠ Upload cancelled: $filePath"); return }
            if (code in 200..201) {
                activity.appendLog("✓ Uploaded: $filePath")
            } else {
                activity.appendLog("✗ Upload failed ($code): ${body.take(200)}")
            }
        } catch (e: Exception) {
            activity.appendLog("✗ ${e.message}")
        }
    }
}
