# JNI: the Rust library looks these methods up by name.
-keep class com.storagemap3d.app.core.Native { *; }
-keepclasseswithmembernames class * { native <methods>; }
