package com.storagemap3d.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.storagemap3d.app.MainViewModel
import com.storagemap3d.app.core.AccessMode

@Composable
fun SettingsScreen(vm: MainViewModel, onGrantAll: () -> Unit, onPickFolder: () -> Unit) {
    var askClearHistory by remember { mutableStateOf(false) }
    var askClearScan by remember { mutableStateOf(false) }
    val ctx = LocalContext.current
    val version = remember {
        try {
            ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: ""
        } catch (e: Exception) {
            ""
        }
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 0.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item { ScreenHeader(title = "Settings", startPadding = 4.dp) }

        // ---- storage access -----------------------------------------------------------------
        item {
            Panel {
                SectionTitle("Storage access")
                Spacer(Modifier.height(6.dp))
                when (vm.access) {
                    AccessMode.Full -> {
                        Text(
                            "All files access is on. Android still keeps other apps' private folders (Android/data and Android/obb) out of reach, so they are shown as protected and never counted.",
                            style = Type.Body,
                            color = Pal.Dim,
                        )
                        Spacer(Modifier.height(12.dp))
                        AppButton("Open Android settings", onGrantAll, Modifier.fillMaxWidth(), kind = BtnKind.Secondary)
                    }
                    AccessMode.Saf -> {
                        Text(
                            "Limited mode. Only \u201c" + vm.backend.rootLabel() + "\u201d is measured, using Android's folder picker. Scanning is slower than with all files access.",
                            style = Type.Body,
                            color = Pal.Dim,
                        )
                        Spacer(Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            AppButton("Allow all files", onGrantAll, Modifier.weight(1f), kind = BtnKind.Secondary)
                            AppButton("Change folder", onPickFolder, Modifier.weight(1f), kind = BtnKind.Ghost)
                        }
                        Spacer(Modifier.height(10.dp))
                        AppButton("Forget this folder", { vm.forgetFolder() }, Modifier.fillMaxWidth(), kind = BtnKind.Ghost)
                    }
                    AccessMode.None -> {
                        Text(
                            "Not allowed yet. Grant \u201cAll files access\u201d, or pick one folder to use limited mode.",
                            style = Type.Body,
                            color = Pal.Dim,
                        )
                        Spacer(Modifier.height(12.dp))
                        AppButton("Allow all files access", onGrantAll, Modifier.fillMaxWidth())
                        Spacer(Modifier.height(10.dp))
                        AppButton("Choose one folder instead", onPickFolder, Modifier.fillMaxWidth(), kind = BtnKind.Secondary)
                    }
                }
            }
        }

        // ---- explorer -----------------------------------------------------------------------
        item {
            Panel {
                SectionTitle("Explorer")
                SwitchRow(
                    "Show hidden files",
                    "Files and folders whose names start with a dot.",
                    vm.showHidden,
                ) { vm.setShowHidden(it) }
            }
        }

        // ---- 3D map -------------------------------------------------------------------------
        item {
            Panel {
                SectionTitle("3D map")
                Spacer(Modifier.height(10.dp))
                Text("Detail", style = Type.Label, color = Pal.Dim)
                Spacer(Modifier.height(8.dp))
                Segmented(listOf("Low", "Balanced", "Detailed"), vm.quality, { vm.setQuality(it) }, Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                Text(
                    "How many blocks the map may draw. Lower settings are lighter on older phones; deeper levels are always one tap away.",
                    style = Type.Small,
                    color = Pal.Dim,
                )
                Spacer(Modifier.height(6.dp))
                SwitchRow(
                    "Reduce motion",
                    "Skip the growing animation and other transitions.",
                    vm.reduceMotion,
                ) { vm.setReduceMotion(it) }
            }
        }

        // ---- history ------------------------------------------------------------------------
        item {
            Panel {
                SectionTitle("History")
                SwitchRow(
                    "Daily snapshot",
                    "Saves free and used space once a day, even if you do not open the app. Reads no files and uses almost no battery.",
                    vm.dailySnapshot,
                ) { vm.setDailySnapshot(it) }
                Spacer(Modifier.height(6.dp))
                AppButton("Clear history", { askClearHistory = true }, Modifier.fillMaxWidth(), kind = BtnKind.Danger)
            }
        }

        // ---- data ---------------------------------------------------------------------------
        item {
            Panel {
                SectionTitle("Saved scan")
                Spacer(Modifier.height(6.dp))
                Text(
                    "The index of file names, sizes and dates is stored only in this app. Removing it never touches your files.",
                    style = Type.Body,
                    color = Pal.Dim,
                )
                Spacer(Modifier.height(12.dp))
                AppButton("Remove saved scan", { askClearScan = true }, Modifier.fillMaxWidth(), kind = BtnKind.Danger)
            }
        }

        // ---- about --------------------------------------------------------------------------
        item {
            Panel {
                SectionTitle("About")
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth()) {
                    Text("Version", Modifier.weight(1f), style = Type.Body, color = Pal.Dim)
                    Text(version, style = Type.Num, color = Pal.Text)
                }
                Spacer(Modifier.height(6.dp))
                Row(Modifier.fillMaxWidth()) {
                    Text("Native core", Modifier.weight(1f), style = Type.Body, color = Pal.Dim)
                    Text(vm.nativeVersion, style = Type.Num, color = Pal.Text)
                }
                Spacer(Modifier.height(12.dp))
                Text(
                    "Everything runs on this device. The app has no accounts and no network access, and it never deletes anything without your confirmation.",
                    style = Type.Small,
                    color = Pal.Dim,
                )
            }
        }
    }

    if (askClearHistory) {
        ConfirmDialog(
            title = "Clear storage history?",
            message = "All saved snapshots are removed. A new one is saved the next time you scan or open the app.",
            confirmText = "Clear",
            danger = true,
            onConfirm = {
                askClearHistory = false
                vm.clearHistory()
            },
            onDismiss = { askClearHistory = false },
        )
    }
    if (askClearScan) {
        ConfirmDialog(
            title = "Remove the saved scan?",
            message = "The 3D map and the analysis pages will need a new scan. Your files are not touched.",
            confirmText = "Remove",
            danger = true,
            onConfirm = {
                askClearScan = false
                vm.clearScanData()
            },
            onDismiss = { askClearScan = false },
        )
    }
}
