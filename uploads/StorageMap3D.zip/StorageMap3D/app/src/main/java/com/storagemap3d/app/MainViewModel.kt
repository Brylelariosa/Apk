package com.storagemap3d.app

import android.app.Application
import android.net.Uri
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.storagemap3d.app.core.AccessMode
import com.storagemap3d.app.core.Backend
import com.storagemap3d.app.core.CatStat
import com.storagemap3d.app.core.Db
import com.storagemap3d.app.core.DupEngine
import com.storagemap3d.app.core.DupGroup
import com.storagemap3d.app.core.FileRef
import com.storagemap3d.app.core.Fmt
import com.storagemap3d.app.core.HistoryPoint
import com.storagemap3d.app.core.Native
import com.storagemap3d.app.core.NodeRow
import com.storagemap3d.app.core.Prefs
import com.storagemap3d.app.core.ScanEngine
import com.storagemap3d.app.core.ScanInfo
import com.storagemap3d.app.core.SnapshotWorker
import com.storagemap3d.app.core.Volume
import com.storagemap3d.app.core.VolumeStats
import com.storagemap3d.app.gl.OrbitCamera
import com.storagemap3d.app.gl.SceneBuilder
import com.storagemap3d.app.gl.SceneData
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class AnalysisPage { Largest, Duplicates, Distribution, Old, Empty, History }

enum class SortMode { Name, Size, Date }

/** One step of the explorer path: [key] is a path (full access) or a document id (limited mode). */
data class Crumb(val key: String, val name: String)

data class MapCrumb(val id: Long, val name: String)

data class FolderRow(val ref: FileRef, val own: Long)

data class Summary(
    val info: ScanInfo?,
    val scannedBytes: Long,
    val cats: List<CatStat>,
    val topFiles: List<FileRef>,
    val topFolders: List<FolderRow>,
)

/** The box the user tapped in the 3D map. [nodeId] is -1 for grouped "smaller items". */
data class MapSel(val nodeId: Long, val kind: Int, val title: String, val node: NodeRow?, val ref: FileRef?)

data class DeleteRequest(val refs: List<FileRef>, val emptyOnly: Boolean, val title: String, val message: String)

class MainViewModel(private val app: Application) : AndroidViewModel(app) {
    val prefs = Prefs(app)
    val db: Db = Db.get(app)
    val backend = Backend(app, db, prefs)
    val camera = OrbitCamera()

    val nativeOk: Boolean = Native.loaded
    val nativeVersion: String = if (Native.loaded) {
        try {
            Native.version()
        } catch (t: Throwable) {
            "unknown"
        }
    } else {
        "not loaded"
    }

    // ---- navigation ---------------------------------------------------------------------------
    var tab by mutableStateOf(0)
    var analysisPage by mutableStateOf<AnalysisPage?>(null)

    // ---- access and volume --------------------------------------------------------------------
    var access by mutableStateOf(backend.mode())
        private set
    var volume by mutableStateOf(VolumeStats(0L, 0L))
        private set

    // ---- scanning -----------------------------------------------------------------------------
    val scanner = ScanEngine(app, db, backend, viewModelScope) { onScanFinished() }
    var summary by mutableStateOf(Summary(null, 0L, emptyList(), emptyList(), emptyList()))
        private set

    /** True when the stored index was made with the access mode (and folder) that is active now. */
    val indexUsable: Boolean
        get() {
            val i = summary.info ?: return false
            return when (access) {
                AccessMode.Full -> i.mode == "full"
                AccessMode.Saf -> i.mode == "saf" && i.root == prefs.safTree
                AccessMode.None -> false
            }
        }

    // ---- settings -----------------------------------------------------------------------------
    var quality by mutableStateOf(prefs.quality)
        private set
    var reduceMotion by mutableStateOf(prefs.reduceMotion)
        private set
    var dailySnapshot by mutableStateOf(prefs.dailySnapshot)
        private set
    var showHidden by mutableStateOf(prefs.showHidden)
        private set
    var oldMonths by mutableStateOf(prefs.oldMonths)
        private set
    var dupMinKb by mutableStateOf(prefs.dupMinKb)
        private set

    // ---- 3D map -------------------------------------------------------------------------------
    var scene by mutableStateOf<SceneData?>(null)
        private set
    var mapBusy by mutableStateOf(false)
        private set
    var mapCrumbs by mutableStateOf<List<MapCrumb>>(emptyList())
        private set
    var mapSel by mutableStateOf<MapSel?>(null)
        private set
    var selectedNodeId by mutableStateOf(-1L)
        private set
    var mapMessage by mutableStateOf<String?>(null)
        private set
    private var mapFocusId = -1L
    private var cameraReset = false

    // ---- explorer -----------------------------------------------------------------------------
    var exStack by mutableStateOf<List<Crumb>>(emptyList())
        private set
    var exEntries by mutableStateOf<List<FileRef>>(emptyList())
        private set
    var exLoading by mutableStateOf(false)
        private set
    var exError by mutableStateOf<String?>(null)
        private set
    var exTruncated by mutableStateOf(false)
        private set
    var exSort by mutableStateOf(SortMode.Name)
    var exAscending by mutableStateOf(true)
    var exFilter by mutableStateOf(-1)
        private set
    var exQuery by mutableStateOf("")
        private set
    var exResults by mutableStateOf<List<FileRef>?>(null)
        private set
    var exFocusKey by mutableStateOf<String?>(null)
        private set
    private var searchJob: Job? = null

    // ---- dialogs ------------------------------------------------------------------------------
    var actionTarget by mutableStateOf<FileRef?>(null)
    var propRef by mutableStateOf<FileRef?>(null)
        private set
    var propHash by mutableStateOf<String?>(null)
        private set
    var propHashBusy by mutableStateOf(false)
        private set
    var deleteRequest by mutableStateOf<DeleteRequest?>(null)
        private set

    // ---- analysis -----------------------------------------------------------------------------
    var largestMode by mutableStateOf(0)
    var largestFiles by mutableStateOf<List<FileRef>>(emptyList())
        private set
    var largestFolders by mutableStateOf<List<FolderRow>>(emptyList())
        private set
    var oldFiles by mutableStateOf<List<FileRef>>(emptyList())
        private set
    var oldCount by mutableStateOf(0L)
        private set
    var oldBytes by mutableStateOf(0L)
        private set
    var emptyFolders by mutableStateOf<List<FileRef>>(emptyList())
        private set
    var emptySelected by mutableStateOf<Set<Long>>(emptySet())
        private set
    var distCat by mutableStateOf(-1)
        private set
    var distFiles by mutableStateOf<List<FileRef>>(emptyList())
        private set
    var history by mutableStateOf<List<HistoryPoint>>(emptyList())
        private set

    val dups = DupEngine(db, backend, viewModelScope) { loadDupGroups() }
    var dupGroups by mutableStateOf<List<DupGroup>>(emptyList())
        private set
    var dupTotals by mutableStateOf(Pair(0, 0L))
        private set
    var dupExpanded by mutableStateOf(-1L)
        private set
    var dupMembers by mutableStateOf<Map<Long, List<FileRef>>>(emptyMap())
        private set
    var dupSelected by mutableStateOf<Set<Long>>(emptySet())
        private set

    init {
        SnapshotWorker.apply(app, prefs.dailySnapshot)
        onResume()
        refreshSummary()
    }

    // ==========================================================================================
    // Lifecycle and access
    // ==========================================================================================

    fun onResume() {
        access = backend.refresh()
        volume = Volume.read()
        val now = System.currentTimeMillis()
        if (volume.total > 0L && now - prefs.lastSnapshotMs > 6L * 3600L * 1000L) {
            prefs.lastSnapshotMs = now
            val v = volume
            viewModelScope.launch(Dispatchers.IO) {
                try {
                    db.addHistory(HistoryPoint(now, v.total, v.used, v.free, db.rootNode()?.size ?: 0L))
                } catch (e: Exception) {
                    // A missing history point is not worth bothering the user about.
                }
            }
        }
        if (access != AccessMode.None && exStack.isEmpty() && tab == 2) explorerInit()
    }

    fun onFolderPicked(uri: Uri?) {
        if (uri == null) return
        backend.adoptTree(uri)
        access = backend.mode()
        resetViews()
        say("Folder saved. Scan it to measure what is inside.")
    }

    fun forgetFolder() {
        backend.forgetTree()
        access = backend.mode()
        resetViews()
    }

    private fun resetViews() {
        exStack = emptyList()
        exEntries = emptyList()
        scene = null
        mapSel = null
        selectedNodeId = -1L
        mapFocusId = -1L
        refreshSummary()
    }

    fun say(message: String) {
        viewModelScope.launch(Dispatchers.Main) {
            Toast.makeText(app, message, Toast.LENGTH_LONG).show()
        }
    }

    // ==========================================================================================
    // Scanning and summary
    // ==========================================================================================

    fun startScan() {
        scanner.start()
    }

    fun cancelScan() {
        scanner.cancel()
    }

    private fun onScanFinished() {
        access = backend.mode()
        volume = Volume.read()
        scene = null
        mapSel = null
        selectedNodeId = -1L
        mapFocusId = -1L
        refreshSummary()
        reloadExplorer()
        reloadAnalysis()
    }

    fun refreshSummary() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val info = db.lastScan()
                val root = db.rootNode()
                val cats = db.catStats()
                val files = db.topFiles(3).map { backend.refOf(it) }
                val folders = db.topFolders(3).map { FolderRow(backend.refOf(it.row), it.own) }
                summary = Summary(info, root?.size ?: 0L, cats, files, folders)
            } catch (e: Exception) {
                summary = Summary(null, 0L, emptyList(), emptyList(), emptyList())
            }
        }
    }

    // ==========================================================================================
    // 3D map
    // ==========================================================================================

    /** Build the first scene when the map tab is shown. */
    fun ensureMap() {
        if (scene != null || mapBusy || !indexUsable) return
        openMapFocus(if (mapFocusId >= 0L) mapFocusId else 0L)
    }

    fun openMapFocus(requested: Long) {
        mapBusy = true
        viewModelScope.launch(Dispatchers.IO) {
            val id = if (requested == 0L) db.rootId() else requested
            val built = if (id >= 0L) SceneBuilder.build(db, id, quality) else null
            val trail = if (built != null) {
                db.trail(id).map { MapCrumb(it.id, if (it.parent < 0L) backend.rootLabel() else it.name) }
            } else {
                emptyList()
            }
            withContext(Dispatchers.Main) {
                if (built != null) {
                    scene = built
                    mapFocusId = id
                    mapCrumbs = trail
                    mapSel = null
                    selectedNodeId = -1L
                    cameraReset = true
                    mapMessage = if (built.shownItems == 0) "This folder has nothing to draw." else null
                } else {
                    mapMessage = "That folder is not in the index. Scan again."
                }
                mapBusy = false
            }
        }
    }

    fun mapUp() {
        val parent = mapCrumbs.getOrNull(mapCrumbs.size - 2)
        if (parent != null) openMapFocus(parent.id)
    }

    /** Rebuild the scene for the current folder (after settings or deletions), keeping the camera. */
    fun rebuildMap() {
        if (scene == null) return
        val id = mapFocusId
        viewModelScope.launch(Dispatchers.IO) {
            val built = SceneBuilder.build(db, id, quality)
            withContext(Dispatchers.Main) {
                if (built != null) {
                    scene = built
                    mapSel = null
                    selectedNodeId = -1L
                } else {
                    scene = null
                    mapFocusId = -1L
                }
            }
        }
    }

    /** True once after a new scene was shown, so the view re-frames the camera exactly once. */
    fun takeCameraReset(): Boolean {
        val r = cameraReset
        cameraReset = false
        return r
    }

    fun onMapPick(index: Int) {
        val s = scene ?: return
        if (index < 0 || index >= s.count) {
            clearMapSelection()
            return
        }
        val pick = s.picks[index]
        if (pick.nodeId < 0L) {
            selectedNodeId = -1L
            mapSel = MapSel(-1L, pick.kind, pick.label, null, null)
            return
        }
        selectedNodeId = pick.nodeId
        viewModelScope.launch(Dispatchers.IO) {
            val node = db.node(pick.nodeId)
            val ref = if (node != null) backend.refOf(node) else null
            if (selectedNodeId == pick.nodeId) {
                mapSel = MapSel(pick.nodeId, pick.kind, pick.label, node, ref)
            }
        }
    }

    fun clearMapSelection() {
        selectedNodeId = -1L
        mapSel = null
    }

    val mapFocusSize: Long
        get() = scene?.focusSize ?: 0L

    // ==========================================================================================
    // Explorer
    // ==========================================================================================

    fun explorerInit() {
        if (access == AccessMode.None || exStack.isNotEmpty()) return
        exStack = listOf(Crumb(backend.rootKey(), backend.rootLabel()))
        loadDir()
    }

    private fun loadDir() {
        val dir = exStack.lastOrNull()?.key ?: return
        exLoading = true
        viewModelScope.launch(Dispatchers.IO) {
            val listing = backend.list(dir)
            withContext(Dispatchers.Main) {
                if (exStack.lastOrNull()?.key == dir) {
                    exEntries = listing.entries
                    exError = listing.error
                    exTruncated = listing.truncated
                    exLoading = false
                }
            }
        }
    }

    fun reloadExplorer() {
        if (exStack.isNotEmpty()) loadDir()
        if (exQuery.isNotBlank()) runSearch(exQuery, immediate = true)
    }

    fun exOpen(ref: FileRef) {
        exStack = exStack + Crumb(ref.key, ref.name)
        exFocusKey = null
        clearSearch()
        loadDir()
    }

    fun exUp(): Boolean {
        if (exResults != null || exQuery.isNotEmpty()) {
            clearSearch()
            return true
        }
        if (exStack.size <= 1) return false
        exStack = exStack.dropLast(1)
        exFocusKey = null
        loadDir()
        return true
    }

    fun exJump(index: Int) {
        if (index < 0 || index >= exStack.size - 1) return
        exStack = exStack.take(index + 1)
        exFocusKey = null
        clearSearch()
        loadDir()
    }

    fun setExFilter(cat: Int) {
        exFilter = cat
        if (exQuery.isNotBlank()) runSearch(exQuery, immediate = true)
    }

    fun setExQuery(q: String) {
        exQuery = q
        if (q.isBlank()) {
            searchJob?.cancel()
            exResults = null
        } else {
            runSearch(q, immediate = false)
        }
    }

    private fun clearSearch() {
        searchJob?.cancel()
        exQuery = ""
        exResults = null
    }

    private fun runSearch(q: String, immediate: Boolean) {
        searchJob?.cancel()
        val cat = exFilter
        searchJob = viewModelScope.launch(Dispatchers.IO) {
            if (!immediate) delay(250L)
            val refs = db.search(q, cat, 300).map { backend.refOf(it) }
            withContext(Dispatchers.Main) {
                if (q == exQuery) exResults = refs
            }
        }
    }

    /** Switch to the explorer, showing the folder that contains [ref]. */
    fun showInExplorer(ref: FileRef) {
        viewModelScope.launch(Dispatchers.IO) {
            val id = backend.nodeIdFor(ref)
            var stack: List<Crumb> = emptyList()
            if (id >= 0L) {
                val trail = db.trail(id).dropLast(1)
                stack = trail.map { Crumb(backend.keyOf(it), if (it.parent < 0L) backend.rootLabel() else it.name) }
            }
            if (stack.isEmpty()) stack = listOf(Crumb(backend.rootKey(), backend.rootLabel()))
            withContext(Dispatchers.Main) {
                exStack = stack
                clearSearch()
                exFocusKey = ref.key
                tab = 2
                actionTarget = null
                loadDir()
            }
        }
    }

    // ==========================================================================================
    // File actions
    // ==========================================================================================

    fun openFile(ref: FileRef) {
        val error = backend.open(ref)
        if (error != null) say(error)
    }

    fun shareFile(ref: FileRef) {
        val error = backend.share(ref)
        if (error != null) say(error)
    }

    fun showProperties(ref: FileRef) {
        propRef = ref
        propHash = null
        propHashBusy = false
        actionTarget = null
    }

    fun closeProperties() {
        if (propHashBusy && Native.loaded) Native.hashCancel(true)
        propRef = null
        propHash = null
        propHashBusy = false
    }

    fun computeHash() {
        val ref = propRef ?: return
        if (propHashBusy || !Native.loaded) return
        propHashBusy = true
        viewModelScope.launch(Dispatchers.IO) {
            Native.hashCancel(false)
            val digest = backend.hash(ref, 1)
            withContext(Dispatchers.Main) {
                if (propRef?.key == ref.key) {
                    propHash = if (digest != null) Native.hex(digest) else "Couldn't read this file."
                    propHashBusy = false
                }
            }
        }
    }

    fun requestDelete(refs: List<FileRef>, emptyOnly: Boolean = false) {
        if (refs.isEmpty()) return
        actionTarget = null
        val title: String
        val message: String
        if (emptyOnly) {
            title = if (refs.size == 1) "Delete this empty folder?" else "Delete ${refs.size} empty folders?"
            message = "Only folders that still contain no files are removed. This can't be undone."
        } else if (refs.size == 1) {
            val r = refs[0]
            title = if (r.isDir) "Delete this folder?" else "Delete this file?"
            val sizeText = if (r.size >= 0L) " (" + Fmt.bytes(r.size) + ")" else ""
            val inside = if (r.isDir) " and everything inside it" else ""
            message = "\"" + r.name + "\"" + sizeText + inside + " will be deleted permanently. This can't be undone."
        } else {
            var total = 0L
            for (r in refs) if (r.size > 0L) total += r.size
            title = "Delete ${refs.size} items?"
            message = Fmt.bytes(total) + " will be deleted permanently. This can't be undone."
        }
        deleteRequest = DeleteRequest(refs, emptyOnly, title, message)
    }

    fun cancelDelete() {
        deleteRequest = null
    }

    fun confirmDelete() {
        val req = deleteRequest ?: return
        deleteRequest = null
        viewModelScope.launch(Dispatchers.IO) {
            var ok = 0
            var failed = 0
            var freed = 0L
            for (r in req.refs) {
                val done = try {
                    if (req.emptyOnly) backend.deleteEmptyFolder(r) else backend.delete(r)
                } catch (e: Exception) {
                    false
                }
                if (done) {
                    ok++
                    if (r.size > 0L) freed += r.size
                } else {
                    failed++
                }
            }
            withContext(Dispatchers.Main) {
                afterDeletion()
                val freedText = if (freed > 0L) ", freed " + Fmt.bytes(freed) else ""
                if (failed == 0) {
                    say((if (ok == 1) "Deleted 1 item" else "Deleted $ok items") + freedText)
                } else {
                    say("Deleted $ok, could not delete $failed. Android may be protecting them.")
                }
            }
        }
    }

    private fun afterDeletion() {
        volume = Volume.read()
        dupSelected = emptySet()
        emptySelected = emptySet()
        refreshSummary()
        reloadExplorer()
        rebuildMap()
        reloadAnalysis()
    }

    // ==========================================================================================
    // Analysis pages
    // ==========================================================================================

    fun openAnalysis(page: AnalysisPage?) {
        analysisPage = page
        if (page != null) loadAnalysis(page)
    }

    fun reloadAnalysis() {
        val page = analysisPage ?: return
        loadAnalysis(page)
    }

    private fun loadAnalysis(page: AnalysisPage) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                when (page) {
                    AnalysisPage.Largest -> {
                        val files = db.topFiles(200).map { backend.refOf(it) }
                        val folders = db.topFolders(100).map { FolderRow(backend.refOf(it.row), it.own) }
                        largestFiles = files
                        largestFolders = folders
                    }
                    AnalysisPage.Old -> loadOld()
                    AnalysisPage.Empty -> {
                        emptyFolders = db.emptyDirs(500).map { backend.refOf(it) }
                        emptySelected = emptySet()
                    }
                    AnalysisPage.Distribution -> {
                        summary = summary.copy(cats = db.catStats())
                        if (distCat >= 0) distFiles = db.topFiles(40, distCat).map { backend.refOf(it) }
                    }
                    AnalysisPage.History -> {
                        history = db.history(400)
                    }
                    AnalysisPage.Duplicates -> loadDupGroups()
                }
            } catch (e: Exception) {
                say("Couldn't load this page: " + (e.message ?: "unknown error"))
            }
        }
    }

    private fun loadOld() {
        val cutoff = System.currentTimeMillis() / 1000L - oldMonths.toLong() * 2_629_800L
        oldFiles = db.oldFiles(cutoff, 200).map { backend.refOf(it) }
        val totals = db.oldTotals(cutoff)
        oldCount = totals.first
        oldBytes = totals.second
    }

    fun setOldMonths(months: Int) {
        oldMonths = months
        prefs.oldMonths = months
        viewModelScope.launch(Dispatchers.IO) { loadOld() }
    }

    fun selectCategory(cat: Int) {
        if (distCat == cat) {
            distCat = -1
            distFiles = emptyList()
            return
        }
        distCat = cat
        viewModelScope.launch(Dispatchers.IO) {
            distFiles = db.topFiles(40, cat).map { backend.refOf(it) }
        }
    }

    // ---- empty folders ------------------------------------------------------------------------

    fun toggleEmpty(nodeId: Long) {
        emptySelected = if (emptySelected.contains(nodeId)) emptySelected - nodeId else emptySelected + nodeId
    }

    fun selectAllEmpty(all: Boolean) {
        emptySelected = if (all) emptyFolders.map { it.nodeId }.toSet() else emptySet()
    }

    fun deleteSelectedEmpty() {
        val refs = emptyFolders.filter { emptySelected.contains(it.nodeId) }
        requestDelete(refs, emptyOnly = true)
    }

    // ---- duplicates ---------------------------------------------------------------------------

    fun setDupMinKb(kb: Int) {
        dupMinKb = kb
        prefs.dupMinKb = kb
    }

    fun findDuplicates() {
        dupExpanded = -1L
        dupMembers = emptyMap()
        dupSelected = emptySet()
        dupGroups = emptyList()
        dups.start(dupMinKb.toLong() * 1000L)
    }

    fun cancelDuplicates() {
        dups.cancel()
    }

    fun loadDupGroups() {
        viewModelScope.launch(Dispatchers.IO) {
            val groups = db.dupGroups(200)
            val totals = db.dupTotals()
            withContext(Dispatchers.Main) {
                dupGroups = groups
                dupTotals = totals
            }
        }
    }

    fun toggleDupGroup(gid: Long) {
        if (dupExpanded == gid) {
            dupExpanded = -1L
            return
        }
        dupExpanded = gid
        if (dupMembers.containsKey(gid)) return
        viewModelScope.launch(Dispatchers.IO) {
            val members = db.dupMembers(gid).map { backend.refOf(it) }
            withContext(Dispatchers.Main) {
                dupMembers = dupMembers + (gid to members)
            }
        }
    }

    fun toggleDupSelect(nodeId: Long) {
        dupSelected = if (dupSelected.contains(nodeId)) dupSelected - nodeId else dupSelected + nodeId
    }

    /** Select every copy except the oldest one in the group. */
    fun dupKeepOldest(gid: Long) {
        val members = dupMembers[gid] ?: return
        var next = dupSelected
        for (i in members.indices) {
            next = if (i == 0) next - members[i].nodeId else next + members[i].nodeId
        }
        dupSelected = next
    }

    fun dupClearSelection() {
        dupSelected = emptySet()
    }

    fun deleteSelectedDuplicates() {
        // Never allow a group to lose every copy.
        for ((_, members) in dupMembers) {
            if (members.isNotEmpty() && members.all { dupSelected.contains(it.nodeId) }) {
                say("Keep at least one copy in every group.")
                return
            }
        }
        val refs = ArrayList<FileRef>()
        for ((_, members) in dupMembers) {
            for (m in members) if (dupSelected.contains(m.nodeId)) refs.add(m)
        }
        requestDelete(refs)
    }

    // ==========================================================================================
    // History and settings
    // ==========================================================================================

    fun saveSnapshotNow() {
        val v = Volume.read()
        volume = v
        viewModelScope.launch(Dispatchers.IO) {
            db.addHistory(HistoryPoint(System.currentTimeMillis(), v.total, v.used, v.free, db.rootNode()?.size ?: 0L))
            val list = db.history(400)
            withContext(Dispatchers.Main) { history = list }
        }
    }

    fun setQuality(q: Int) {
        quality = q
        prefs.quality = q
        rebuildMap()
    }

    fun setReduceMotion(on: Boolean) {
        reduceMotion = on
        prefs.reduceMotion = on
    }

    fun setDailySnapshot(on: Boolean) {
        dailySnapshot = on
        prefs.dailySnapshot = on
        SnapshotWorker.apply(app, on)
    }

    fun setShowHidden(on: Boolean) {
        showHidden = on
        prefs.showHidden = on
    }

    fun clearHistory() {
        viewModelScope.launch(Dispatchers.IO) {
            db.clearHistory()
            withContext(Dispatchers.Main) { history = emptyList() }
        }
    }

    fun clearScanData() {
        viewModelScope.launch(Dispatchers.IO) {
            db.clearScanData()
            withContext(Dispatchers.Main) {
                scene = null
                mapSel = null
                mapFocusId = -1L
                largestFiles = emptyList()
                largestFolders = emptyList()
                oldFiles = emptyList()
                emptyFolders = emptyList()
                dupGroups = emptyList()
                dupMembers = emptyMap()
                dupSelected = emptySet()
                distFiles = emptyList()
                refreshSummary()
                reloadExplorer()
            }
        }
    }

    /** Share of the folder shown in the 3D map that an item takes, for example "12%". */
    fun shareOfFocus(size: Long): String = Fmt.percent(size, mapFocusSize)

    override fun onCleared() {
        scanner.cancel()
        dups.cancel()
        super.onCleared()
    }
}
