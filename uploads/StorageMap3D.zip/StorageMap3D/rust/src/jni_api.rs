//! JNI entry points for the Kotlin object `com.storagemap3d.app.core.Native`.
//!
//! Everything crossing the boundary is a primitive, a String or a byte[] with a fixed little-endian
//! layout. There are no callbacks into the JVM: the scanner runs on its own native thread and the app
//! polls it, which keeps threading simple and cancellation immediate.
//!
//! Every entry point is wrapped in `catch_unwind` so a Rust panic can never unwind into the JVM.
#![allow(non_snake_case)]

use std::panic::{catch_unwind, AssertUnwindSafe};
use std::path::Path;
use std::sync::atomic::{AtomicU8, Ordering};
use std::sync::mpsc::{sync_channel, Receiver, RecvTimeoutError};
use std::sync::{Arc, Mutex};
use std::time::Duration;

use jni::objects::{JObject, JString};
use jni::sys::{jboolean, jbyteArray, jfloat, jint, jstring, JNI_FALSE, JNI_TRUE};
use jni::JNIEnv;

use crate::category;
use crate::hash;
use crate::listing;
use crate::scanner::{scan_tree, Progress, ScanEnd};
use crate::treemap;
use crate::VERSION;

const STATE_IDLE: u8 = 0;
const STATE_RUNNING: u8 = 1;
const STATE_COMPLETED: u8 = 2;
const STATE_CANCELLED: u8 = 3;
const STATE_FAILED: u8 = 4;

struct Session {
    prog: Arc<Progress>,
    rx: Mutex<Receiver<Vec<u8>>>,
    state: Arc<AtomicU8>,
}

static SESSION: Mutex<Option<Arc<Session>>> = Mutex::new(None);

fn current_session() -> Option<Arc<Session>> {
    match SESSION.lock() {
        Ok(guard) => (*guard).clone(),
        Err(poisoned) => (*poisoned.into_inner()).clone(),
    }
}

/// Start a scan on a background thread. Returns false if one is already running.
fn scan_start(root: String) -> bool {
    let mut guard = match SESSION.lock() {
        Ok(g) => g,
        Err(p) => p.into_inner(),
    };
    if let Some(existing) = guard.as_ref() {
        // A scan that was cancelled but is still winding down (for example blocked because nobody is
        // reading its queue any more) must not block a new one: replacing the session below drops the
        // old receiver, which makes the old thread's next send fail so it exits.
        if existing.state.load(Ordering::SeqCst) == STATE_RUNNING && !existing.prog.cancel.load(Ordering::Relaxed) {
            return false;
        }
    }

    let prog = Arc::new(Progress::new());
    let state = Arc::new(AtomicU8::new(STATE_RUNNING));
    // Small bound: when the app is slower than the scanner the scanner waits instead of buffering.
    let (tx, rx) = sync_channel::<Vec<u8>>(6);
    let session = Arc::new(Session { prog: prog.clone(), rx: Mutex::new(rx), state: state.clone() });

    let thread_prog = prog.clone();
    let thread_state = state.clone();
    let spawned = std::thread::Builder::new().name("storagemap-scan".to_string()).spawn(move || {
        let result = catch_unwind(AssertUnwindSafe(|| {
            scan_tree(Path::new(&root), &thread_prog, |data| tx.send(data).is_ok())
        }));
        let code = match result {
            Ok(ScanEnd::Completed) => STATE_COMPLETED,
            Ok(ScanEnd::Cancelled) => STATE_CANCELLED,
            _ => STATE_FAILED,
        };
        // The final state is published before the channel closes, so a poller that sees the end of
        // the stream always reads the final state.
        thread_state.store(code, Ordering::SeqCst);
        drop(tx);
    });
    if spawned.is_err() {
        return false;
    }
    *guard = Some(session);
    true
}

enum Poll {
    Data(Vec<u8>),
    Pending,
    Done,
}

/// Wait briefly for the next batch of records.
fn scan_poll() -> Poll {
    let session = match current_session() {
        Some(s) => s,
        None => return Poll::Done,
    };
    let rx = match session.rx.lock() {
        Ok(g) => g,
        Err(p) => p.into_inner(),
    };
    match rx.recv_timeout(Duration::from_millis(120)) {
        Ok(data) => Poll::Data(data),
        Err(RecvTimeoutError::Timeout) => Poll::Pending,
        Err(RecvTimeoutError::Disconnected) => Poll::Done,
    }
}

/// state, files, dirs, bytes, restricted folders, read errors
fn scan_stats() -> [i64; 6] {
    match current_session() {
        None => [STATE_IDLE as i64, 0, 0, 0, 0, 0],
        Some(s) => [
            s.state.load(Ordering::SeqCst) as i64,
            s.prog.files.load(Ordering::Relaxed) as i64,
            s.prog.dirs.load(Ordering::Relaxed) as i64,
            s.prog.bytes.load(Ordering::Relaxed) as i64,
            s.prog.restricted.load(Ordering::Relaxed) as i64,
            s.prog.errors.load(Ordering::Relaxed) as i64,
        ],
    }
}

fn scan_current() -> String {
    match current_session() {
        None => String::new(),
        Some(s) => match s.prog.current.lock() {
            Ok(g) => g.clone(),
            Err(_) => String::new(),
        },
    }
}

fn scan_cancel() {
    if let Some(s) = current_session() {
        s.prog.cancel.store(true, Ordering::Relaxed);
    }
}

fn hash_path(path: &str, mode: i32) -> Option<[u8; 32]> {
    let mut file = std::fs::File::open(path).ok()?;
    hash::hash_file(&mut file, mode == 1).ok()
}

#[cfg(unix)]
fn hash_descriptor(fd: i32, mode: i32) -> Option<[u8; 32]> {
    use std::os::unix::io::FromRawFd;
    if fd < 0 {
        return None;
    }
    // The caller detached the descriptor, so ownership moves here and it is closed when dropped.
    let mut file = unsafe { std::fs::File::from_raw_fd(fd) };
    hash::hash_file(&mut file, mode == 1).ok()
}

#[cfg(not(unix))]
fn hash_descriptor(_fd: i32, _mode: i32) -> Option<[u8; 32]> {
    None
}

/// `sizes` is a comma separated list of unsigned integers; the result is packed f32 little endian
/// (x, y, w, h per item, in input order).
fn squarify_str(sizes: &str, w: f32, h: f32) -> Vec<u8> {
    let mut values: Vec<u64> = Vec::new();
    for part in sizes.split(',') {
        let t = part.trim();
        if t.is_empty() {
            continue;
        }
        values.push(t.parse::<u64>().unwrap_or(0));
    }
    let rects = treemap::squarify(&values, 0.0, 0.0, w as f64, h as f64);
    let mut out: Vec<u8> = Vec::with_capacity(values.len() * 16);
    for r in rects.iter() {
        out.extend_from_slice(&(r.x as f32).to_le_bytes());
        out.extend_from_slice(&(r.y as f32).to_le_bytes());
        out.extend_from_slice(&(r.w as f32).to_le_bytes());
        out.extend_from_slice(&(r.h as f32).to_le_bytes());
    }
    out
}

fn get_string(env: &mut JNIEnv, value: &JString) -> Option<String> {
    match env.get_string(value) {
        Ok(java_str) => Some(String::from(java_str)),
        Err(_) => None,
    }
}

fn bytes_to_java(env: &mut JNIEnv, data: &[u8]) -> jbyteArray {
    match env.byte_array_from_slice(data) {
        Ok(array) => array.into_raw(),
        Err(_) => std::ptr::null_mut(),
    }
}

// ---------------------------------------------------------------------------------------------
// JNI exports
// ---------------------------------------------------------------------------------------------

#[no_mangle]
pub extern "system" fn Java_com_storagemap3d_app_core_Native_version<'local>(
    mut env: JNIEnv<'local>,
    _this: JObject<'local>,
) -> jstring {
    match env.new_string(VERSION) {
        Ok(s) => s.into_raw(),
        Err(_) => std::ptr::null_mut(),
    }
}

#[no_mangle]
pub extern "system" fn Java_com_storagemap3d_app_core_Native_scanStart<'local>(
    mut env: JNIEnv<'local>,
    _this: JObject<'local>,
    root: JString<'local>,
) -> jboolean {
    let root = match get_string(&mut env, &root) {
        Some(r) => r,
        None => return JNI_FALSE,
    };
    let started = catch_unwind(AssertUnwindSafe(|| scan_start(root))).unwrap_or(false);
    if started {
        JNI_TRUE
    } else {
        JNI_FALSE
    }
}

/// null = nothing yet, empty array = the stream has ended, otherwise one batch of packed records.
#[no_mangle]
pub extern "system" fn Java_com_storagemap3d_app_core_Native_scanPoll<'local>(
    mut env: JNIEnv<'local>,
    _this: JObject<'local>,
) -> jbyteArray {
    let polled = catch_unwind(AssertUnwindSafe(scan_poll)).unwrap_or(Poll::Done);
    match polled {
        Poll::Data(data) => bytes_to_java(&mut env, &data),
        Poll::Pending => std::ptr::null_mut(),
        Poll::Done => bytes_to_java(&mut env, &[]),
    }
}

/// Six packed i64 values: state (0 idle, 1 running, 2 completed, 3 cancelled, 4 failed), files,
/// folders, bytes, restricted folders, read errors.
#[no_mangle]
pub extern "system" fn Java_com_storagemap3d_app_core_Native_scanStats<'local>(
    mut env: JNIEnv<'local>,
    _this: JObject<'local>,
) -> jbyteArray {
    let stats = catch_unwind(AssertUnwindSafe(scan_stats)).unwrap_or([STATE_FAILED as i64, 0, 0, 0, 0, 0]);
    let mut out: Vec<u8> = Vec::with_capacity(48);
    for v in stats.iter() {
        out.extend_from_slice(&v.to_le_bytes());
    }
    bytes_to_java(&mut env, &out)
}

#[no_mangle]
pub extern "system" fn Java_com_storagemap3d_app_core_Native_scanCurrent<'local>(
    mut env: JNIEnv<'local>,
    _this: JObject<'local>,
) -> jstring {
    let current = catch_unwind(AssertUnwindSafe(scan_current)).unwrap_or_default();
    match env.new_string(current) {
        Ok(s) => s.into_raw(),
        Err(_) => std::ptr::null_mut(),
    }
}

#[no_mangle]
pub extern "system" fn Java_com_storagemap3d_app_core_Native_scanCancel<'local>(
    _env: JNIEnv<'local>,
    _this: JObject<'local>,
) {
    let _ = catch_unwind(AssertUnwindSafe(scan_cancel));
}

/// mode 0 = sampled digest (head/middle/tail), mode 1 = full digest. Returns 32 bytes or null.
#[no_mangle]
pub extern "system" fn Java_com_storagemap3d_app_core_Native_hashFile<'local>(
    mut env: JNIEnv<'local>,
    _this: JObject<'local>,
    path: JString<'local>,
    mode: jint,
) -> jbyteArray {
    let path = match get_string(&mut env, &path) {
        Some(p) => p,
        None => return std::ptr::null_mut(),
    };
    let digest = catch_unwind(AssertUnwindSafe(|| hash_path(&path, mode))).unwrap_or(None);
    match digest {
        Some(d) => bytes_to_java(&mut env, &d),
        None => std::ptr::null_mut(),
    }
}

/// Same as hashFile but for an open file descriptor the caller detached (Storage Access Framework).
/// Ownership of the descriptor passes to native code.
#[no_mangle]
pub extern "system" fn Java_com_storagemap3d_app_core_Native_hashFd<'local>(
    mut env: JNIEnv<'local>,
    _this: JObject<'local>,
    fd: jint,
    mode: jint,
) -> jbyteArray {
    let digest = catch_unwind(AssertUnwindSafe(|| hash_descriptor(fd, mode))).unwrap_or(None);
    match digest {
        Some(d) => bytes_to_java(&mut env, &d),
        None => std::ptr::null_mut(),
    }
}

#[no_mangle]
pub extern "system" fn Java_com_storagemap3d_app_core_Native_hashCancel<'local>(
    _env: JNIEnv<'local>,
    _this: JObject<'local>,
    flag: jboolean,
) {
    hash::set_cancel(flag != 0);
}

/// Packed directory entries (see listing.rs) or null when the folder cannot be read.
#[no_mangle]
pub extern "system" fn Java_com_storagemap3d_app_core_Native_listDir<'local>(
    mut env: JNIEnv<'local>,
    _this: JObject<'local>,
    path: JString<'local>,
) -> jbyteArray {
    let path = match get_string(&mut env, &path) {
        Some(p) => p,
        None => return std::ptr::null_mut(),
    };
    let listed = catch_unwind(AssertUnwindSafe(|| listing::list_dir(Path::new(&path)).ok())).unwrap_or(None);
    match listed {
        Some(data) => bytes_to_java(&mut env, &data),
        None => std::ptr::null_mut(),
    }
}

#[no_mangle]
pub extern "system" fn Java_com_storagemap3d_app_core_Native_squarify<'local>(
    mut env: JNIEnv<'local>,
    _this: JObject<'local>,
    sizes: JString<'local>,
    w: jfloat,
    h: jfloat,
) -> jbyteArray {
    let text = match get_string(&mut env, &sizes) {
        Some(t) => t,
        None => return std::ptr::null_mut(),
    };
    let out = catch_unwind(AssertUnwindSafe(|| squarify_str(&text, w, h))).unwrap_or_default();
    bytes_to_java(&mut env, &out)
}

#[no_mangle]
pub extern "system" fn Java_com_storagemap3d_app_core_Native_classify<'local>(
    mut env: JNIEnv<'local>,
    _this: JObject<'local>,
    name: JString<'local>,
) -> jint {
    let name = match get_string(&mut env, &name) {
        Some(n) => n,
        None => return category::OTHER as jint,
    };
    category::classify(&name) as jint
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn session_streams_batches_and_reports_completion() {
        let nanos = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map(|d| d.as_nanos())
            .unwrap_or(0);
        let root = std::env::temp_dir().join(format!("smap_session_{}_{}", std::process::id(), nanos));
        std::fs::create_dir_all(root.join("a")).unwrap();
        std::fs::write(root.join("x.txt"), vec![0u8; 10]).unwrap();
        std::fs::write(root.join("a").join("y.png"), vec![0u8; 20]).unwrap();
        std::fs::write(root.join("a").join("z.mp3"), vec![0u8; 30]).unwrap();

        assert!(scan_start(root.to_string_lossy().into_owned()));
        let mut received = 0usize;
        let mut spins = 0;
        loop {
            match scan_poll() {
                Poll::Data(d) => received += d.len(),
                Poll::Pending => {
                    spins += 1;
                    assert!(spins < 200, "scan did not finish");
                }
                Poll::Done => break,
            }
        }
        let stats = scan_stats();
        assert_eq!(stats[0], STATE_COMPLETED as i64);
        assert_eq!(stats[1], 3);
        assert_eq!(stats[3], 60);
        assert!(received > 0);
        assert!(scan_current().len() > 0);
        let _ = std::fs::remove_dir_all(&root);
    }

    #[test]
    fn squarify_str_packs_floats() {
        let out = squarify_str("75, 25", 10.0, 10.0);
        assert_eq!(out.len(), 32);
        let mut area = 0.0f32;
        for i in 0..2 {
            let w = f32::from_le_bytes([out[i * 16 + 8], out[i * 16 + 9], out[i * 16 + 10], out[i * 16 + 11]]);
            let h = f32::from_le_bytes([out[i * 16 + 12], out[i * 16 + 13], out[i * 16 + 14], out[i * 16 + 15]]);
            area += w * h;
        }
        assert!((area - 100.0).abs() < 0.01);
        assert!(squarify_str("", 10.0, 10.0).is_empty());
    }
}
