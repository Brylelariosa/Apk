# BeamShare

Local WiFi Direct file & app transfer for Android. No internet, no server, no account -
one phone finds the other (peer scan or QR code), and once paired either side can beam
files or installed apps to the other without re-pairing.

## How it works

1. **Send**: pick files and/or installed apps -> discover nearby devices (or scan the
   receiver's QR code to connect directly) -> transfer starts automatically once paired.
2. **Receive**: shows your own QR code and stays discoverable -> accept the incoming
   pairing request -> land on the same connected hub the sender sees.
3. **Connected hub**: once paired, both phones can send more files/apps from here at any
   time - the WiFi Direct link and the app-level session both stay open until you
   disconnect.

## Architecture

```
core/
  discovery/   WifiDirectManager      - wraps WifiP2pManager as StateFlow, no Android
                                         callback types leak past this layer
  transfer/    TransferProtocol       - wire format (frame header + raw bytes, no JSON dep)
               TransferSession        - one paired connection: handshake, offer/accept,
                                         streamed bidirectional transfer, throttled progress
               SessionManager         - orchestrates link -> socket -> handshake -> consent
                                         -> connected session; this is what the UI observes
  qr/          ConnectPayload / QrCodeGenerator - pairing payload codec + QR bitmap (ZXing
                                         core only, no scanning UI dependency)
  apps/        InstalledAppsRepository / ApkInstaller - "send an app" enumeration + receive-
                                         side install intent
  files/       FileRepository         - SAF-picked source resolution, MediaStore-backed
                                         incoming file sink (scoped storage compliant)
di/            ServiceLocator         - manual DI; the dependency graph is small enough
                                         that Hilt's annotation processing wouldn't pay for
                                         itself here
service/       BeamShareService       - thin foreground-service wrapper; owns no transfer
                                         logic itself, just mirrors SessionManager's state
                                         into a notification so the OS doesn't kill the link
ui/            MVVM per feature (home, send, receive, session), Compose + Material 3,
               vector iconography only, a small monospace numeral style reserved for byte/
               speed readouts
```

Everything above `ui/` is plain Kotlin + coroutines and doesn't touch Compose, so the
transfer engine is unit-testable independent of the UI.

## Building

This is a ready-to-build Gradle project (Kotlin DSL + version catalog at
`gradle/libs.versions.toml`). Two things to know before wiring it into CI:

- **Gradle wrapper jar**: `gradle/wrapper/gradle-wrapper.properties` is included (pinned to
  Gradle 8.9), but the binary `gradle-wrapper.jar` isn't checked in here. Run
  `gradle wrapper` once locally, or let your existing pipeline provision Gradle
  (e.g. `gradle/actions/setup-gradle` in GitHub Actions works without a committed wrapper
  jar).
- **SDK levels**: `compileSdk`/`targetSdk` are set to 35, `minSdk` to 26. Dependency
  versions in the catalog are current as of early 2026 training data - bump them via the
  catalog if your CI has newer SDK platforms installed.

## Permissions

| Permission | Why |
|---|---|
| `NEARBY_WIFI_DEVICES` (13+) / `ACCESS_FINE_LOCATION` (<13) | WiFi Direct peer discovery. Declared `neverForLocation` on 13+ since the app never derives physical location from it. |
| `CAMERA` | QR code scanning only, requested lazily when you tap "Scan QR". |
| `POST_NOTIFICATIONS`, `FOREGROUND_SERVICE_CONNECTED_DEVICE` | Keeps the transfer session alive if you background the app mid-transfer. |
| `REQUEST_INSTALL_PACKAGES` | Lets a received APK be handed to the system installer. |

No storage permission is requested - incoming files land in `Downloads/BeamShare` via
`MediaStore` on API 29+, or app-specific external storage (shared through `FileProvider`)
on 26-28.

## Known v1 scope boundaries

- Sending an app sends its **base APK only**, not split/config APKs from app-bundle
  installs. That's a working install for the large majority of apps; a few
  dynamically-delivered features on very large apps may need to redownload after install.
- Each device streams its own outgoing items **one at a time, in order**; simultaneous
  sends in both directions both work, but two files queued from the *same* device won't
  literally interleave their bytes.
- No transfer history persists across sessions by design - the connected hub shows the
  current session only.
