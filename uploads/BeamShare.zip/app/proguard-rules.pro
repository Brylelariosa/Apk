# BeamShare release shrinking rules.
# AGP's default R8 rules already cover AndroidX, Compose, and Kotlin metadata correctly;
# only app-specific reflection points need explicit keeps.

# Domain models are (de)serialized manually via TransferProtocol, but keep field names
# stable for easier debugging of release-build transfer logs.
-keepclassmembers class com.beamshare.app.core.model.** { *; }

# CameraX / ML Kit ship their own consumer ProGuard rules; no extra keep needed here.
