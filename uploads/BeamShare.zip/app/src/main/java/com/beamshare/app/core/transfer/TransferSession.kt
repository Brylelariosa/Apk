package com.beamshare.app.core.transfer

import com.beamshare.app.core.files.FileIo
import com.beamshare.app.core.model.TransferDirection
import com.beamshare.app.core.model.TransferItem
import com.beamshare.app.core.model.TransferProgress
import com.beamshare.app.core.model.TransferState
import kotlinx.coroutines.CancellableContinuation
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.IOException
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap
import kotlin.coroutines.resume

/**
 * One paired connection to a peer. Symmetric by design: once the handshake completes, both
 * ends can call [send] at any time and both ends auto-accept whatever the other offers, so a
 * pairing (WiFi Direct link + this handshake) never needs to be redone for later transfers.
 */
class TransferSession(
    private val socket: Socket,
    private val fileIo: FileIo,
    private val sessionScope: CoroutineScope
) {
    private val input = DataInputStream(socket.getInputStream().buffered(TransferProtocol.IO_BUFFER_SIZE))
    private val output = DataOutputStream(socket.getOutputStream().buffered(TransferProtocol.IO_BUFFER_SIZE))
    private val writeMutex = Mutex()

    private val _progress = MutableStateFlow<List<TransferProgress>>(emptyList())
    val progress: StateFlow<List<TransferProgress>> = _progress.asStateFlow()

    private val _peerName = MutableStateFlow<String?>(null)
    val peerName: StateFlow<String?> = _peerName.asStateFlow()

    private val _closed = MutableStateFlow(false)
    val closed: StateFlow<Boolean> = _closed.asStateFlow()

    private val pendingOffers = ConcurrentHashMap<String, TransferProtocol.OfferPayload>()
    private val pendingAcks = ConcurrentHashMap<String, CancellableContinuation<Boolean>>()
    private var readJob: Job? = null

    fun start(localDeviceName: String) {
        readJob = sessionScope.launch(Dispatchers.IO) {
            runCatching { sendFrame(TransferProtocol.TYPE_HELLO, localDeviceName.toByteArray(Charsets.UTF_8)) }
            readLoop()
        }
    }

    /** Offers [item], waits for the peer's (automatic) accept, then streams it. Throws on I/O failure. */
    suspend fun send(item: TransferItem) {
        upsertQueued(item.id) {
            TransferProgress(
                itemId = item.id, name = item.displayName, direction = TransferDirection.SEND,
                totalBytes = item.sizeBytes, state = TransferState.QUEUED, isApk = item.isApk
            )
        }
        try {
            val accepted = withTimeoutOrNull(ACK_TIMEOUT_MS) { offerAndAwait(item) } ?: false
            if (!accepted) {
                setState(item.id, TransferState.CANCELLED)
                return
            }
            setState(item.id, TransferState.IN_PROGRESS)
            streamFileOut(item)
            setState(item.id, TransferState.COMPLETED)
        } catch (io: IOException) {
            setState(item.id, TransferState.FAILED)
            throw io
        }
    }

    fun close() {
        if (_closed.value) return
        _closed.value = true
        pendingAcks.keys.toList().forEach { id -> resumeAck(id, false) }
        readJob?.cancel()
        runCatching { socket.close() }
    }

    // ---- outgoing ----

    private suspend fun offerAndAwait(item: TransferItem): Boolean = suspendCancellableCoroutine { cont ->
        pendingAcks[item.id] = cont
        cont.invokeOnCancellation { pendingAcks.remove(item.id) }
        sessionScope.launch(Dispatchers.IO) {
            val offer = TransferProtocol.OfferPayload(
                id = item.id, name = item.displayName, sizeBytes = item.sizeBytes,
                mimeType = item.mimeType, isApk = item.isApk
            )
            runCatching { sendFrame(TransferProtocol.TYPE_OFFER, TransferProtocol.encodeOffer(offer)) }
                .onFailure { resumeAck(item.id, false) }
        }
    }

    private suspend fun streamFileOut(item: TransferItem) = withContext(Dispatchers.IO) {
        writeMutex.withLock {
            // FILE_START, the raw bytes, and FILE_DONE must stay one atomic write - otherwise
            // another queued send's OFFER could slip in between the header and its payload.
            TransferProtocol.writeFrame(output, TransferProtocol.TYPE_FILE_START, item.id.toByteArray(Charsets.UTF_8))
            fileIo.openInputStream(item).use { src ->
                val buffer = ByteArray(TransferProtocol.IO_BUFFER_SIZE)
                var sent = 0L
                var lastEmit = 0L
                var lastEmitTime = System.nanoTime()
                while (true) {
                    val read = src.read(buffer)
                    if (read == -1) break
                    output.write(buffer, 0, read)
                    sent += read
                    if (sent - lastEmit >= PROGRESS_EMIT_THRESHOLD || sent == item.sizeBytes) {
                        val now = System.nanoTime()
                        updateBytes(item.id, sent, speedOf(sent - lastEmit, now - lastEmitTime))
                        lastEmit = sent
                        lastEmitTime = now
                    }
                }
            }
            output.flush()
            TransferProtocol.writeFrame(output, TransferProtocol.TYPE_FILE_DONE, item.id.toByteArray(Charsets.UTF_8))
        }
    }

    private suspend fun sendFrame(type: Int, payload: ByteArray) = writeMutex.withLock {
        withContext(Dispatchers.IO) { TransferProtocol.writeFrame(output, type, payload) }
    }

    // ---- incoming ----

    private suspend fun readLoop() {
        try {
            while (true) {
                val frame = TransferProtocol.readFrame(input)
                when (frame.type) {
                    TransferProtocol.TYPE_HELLO -> _peerName.value = String(frame.payload, Charsets.UTF_8)
                    TransferProtocol.TYPE_OFFER -> handleOffer(TransferProtocol.decodeOffer(frame.payload))
                    TransferProtocol.TYPE_ACCEPT -> resumeAck(String(frame.payload, Charsets.UTF_8), true)
                    TransferProtocol.TYPE_REJECT -> resumeAck(String(frame.payload, Charsets.UTF_8), false)
                    TransferProtocol.TYPE_FILE_START -> receiveFile(String(frame.payload, Charsets.UTF_8))
                    TransferProtocol.TYPE_FILE_DONE -> Unit // receiveFile already marks completion
                    TransferProtocol.TYPE_CANCEL -> setState(String(frame.payload, Charsets.UTF_8), TransferState.CANCELLED)
                    TransferProtocol.TYPE_BYE -> { close(); return }
                }
            }
        } catch (t: Exception) {
            close()
        }
    }

    private suspend fun handleOffer(offer: TransferProtocol.OfferPayload) {
        pendingOffers[offer.id] = offer
        upsertQueued(offer.id) {
            TransferProgress(
                itemId = offer.id, name = offer.name, direction = TransferDirection.RECEIVE,
                totalBytes = offer.sizeBytes, state = TransferState.QUEUED, isApk = offer.isApk
            )
        }
        // Trust was already established when the WiFi Direct pairing was accepted, so
        // individual offers within a session don't need a second per-file confirmation.
        sendFrame(TransferProtocol.TYPE_ACCEPT, offer.id.toByteArray(Charsets.UTF_8))
    }

    private suspend fun receiveFile(id: String) {
        val offer = pendingOffers.remove(id) ?: return
        setState(id, TransferState.IN_PROGRESS)
        val sink = withContext(Dispatchers.IO) { fileIo.createIncomingSink(offer.name, offer.mimeType) }
        withContext(Dispatchers.IO) {
            sink.outputStream.use { out ->
                val buffer = ByteArray(TransferProtocol.IO_BUFFER_SIZE)
                var received = 0L
                var lastEmit = 0L
                var lastEmitTime = System.nanoTime()
                while (received < offer.sizeBytes) {
                    val toRead = minOf(buffer.size.toLong(), offer.sizeBytes - received).toInt()
                    val read = input.read(buffer, 0, toRead)
                    if (read == -1) break
                    out.write(buffer, 0, read)
                    received += read
                    if (received - lastEmit >= PROGRESS_EMIT_THRESHOLD || received == offer.sizeBytes) {
                        val now = System.nanoTime()
                        updateBytes(id, received, speedOf(received - lastEmit, now - lastEmitTime))
                        lastEmit = received
                        lastEmitTime = now
                    }
                }
            }
            sink.finalize()
        }
        mutate(id) { it.copy(savedUri = sink.uri) }
        setState(id, TransferState.COMPLETED)
    }

    // ---- progress bookkeeping ----

    private fun resumeAck(id: String, accepted: Boolean) {
        pendingAcks.remove(id)?.let { cont -> if (cont.isActive) cont.resume(accepted) }
    }

    private fun upsertQueued(id: String, factory: () -> TransferProgress) {
        _progress.update { list -> if (list.any { it.itemId == id }) list else list + factory() }
    }

    private fun mutate(id: String, transform: (TransferProgress) -> TransferProgress) {
        _progress.update { list -> list.map { if (it.itemId == id) transform(it) else it } }
    }

    private fun updateBytes(id: String, bytes: Long, speedBps: Long) =
        mutate(id) { it.copy(transferredBytes = bytes, speedBytesPerSec = speedBps) }

    private fun speedOf(bytesInWindow: Long, elapsedNanos: Long): Long {
        if (elapsedNanos <= 0) return 0L
        return (bytesInWindow * 1_000_000_000L) / elapsedNanos
    }

    private fun setState(id: String, state: TransferState) = mutate(id) { it.copy(state = state) }

    companion object {
        private const val PROGRESS_EMIT_THRESHOLD = 96 * 1024L // throttle StateFlow emissions to ~every 96KB
        private const val ACK_TIMEOUT_MS = 20_000L
        private const val CONNECT_TIMEOUT_MS = 15_000

        /** Opens the socket for this end: server if we're the WiFi Direct group owner, client otherwise. */
        suspend fun open(isGroupOwner: Boolean, groupOwnerAddress: String): Socket = withContext(Dispatchers.IO) {
            if (isGroupOwner) {
                ServerSocket(TransferProtocol.PORT).use { it.accept() }
            } else {
                Socket().apply { connect(InetSocketAddress(groupOwnerAddress, TransferProtocol.PORT), CONNECT_TIMEOUT_MS) }
            }
        }
    }
}
