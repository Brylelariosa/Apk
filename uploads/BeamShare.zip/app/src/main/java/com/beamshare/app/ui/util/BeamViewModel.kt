package com.beamshare.app.ui.util

import androidx.compose.runtime.Composable
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory

/**
 * ViewModels here take constructor dependencies from [com.beamshare.app.di.ServiceLocator]
 * rather than zero-arg constructors, so the default reflection-based factory can't build them.
 * This wraps the small `viewModelFactory { initializer { ... } }` DSL so screens don't repeat it.
 */
@Composable
inline fun <reified VM : ViewModel> beamViewModel(crossinline create: () -> VM): VM =
    viewModel(factory = viewModelFactory { initializer { create() } })
