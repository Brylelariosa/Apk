package com.beamshare.app.ui.theme

import androidx.compose.ui.graphics.Color

// Brand
val BeamBlue = Color(0xFF5468FF)
val BeamBlueDark = Color(0xFF3548D6)
val BeamMint = Color(0xFF2DD4A7)
val BeamAmber = Color(0xFFF5A623)
val BeamRed = Color(0xFFFF5C5C)

// Dark surfaces (primary theme for a fast-transfer utility)
val DarkBackground = Color(0xFF0E1116)
val DarkSurface = Color(0xFF161B22)
val DarkSurfaceElevated = Color(0xFF1E2530)
val DarkOutline = Color(0xFF2E3644)
val DarkOnSurface = Color(0xFFECF0F6)
val DarkOnSurfaceMuted = Color(0xFF8B95A7)

// Light surfaces
val LightBackground = Color(0xFFF7F8FA)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceElevated = Color(0xFFEFF1F5)
val LightOutline = Color(0xFFD7DBE2)
val LightOnSurface = Color(0xFF171B22)
val LightOnSurfaceMuted = Color(0xFF5B6472)
