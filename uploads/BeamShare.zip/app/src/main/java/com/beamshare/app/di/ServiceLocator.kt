package com.beamshare.app.di

import android.content.Context
import com.beamshare.app.core.apps.InstalledAppsRepository
import com.beamshare.app.core.discovery.WifiDirectManager
import com.beamshare.app.core.files.FileRepository
import com.beamshare.app.core.transfer.SessionManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob

/**
 * Minimal, explicit service locator instead of a DI framework: this app's dependency graph is
 * small enough that Hilt/Dagger annotation processing would add build overhead for no real gain.
 * Everything here is Application-scoped, created once from [com.beamshare.app.BeamShareApp].
 */
object ServiceLocator {

    private lateinit var appScope: CoroutineScope

    lateinit var wifiDirectManager: WifiDirectManager
        private set
    lateinit var fileRepository: FileRepository
        private set
    lateinit var installedAppsRepository: InstalledAppsRepository
        private set
    lateinit var sessionManager: SessionManager
        private set

    val isInitialized: Boolean get() = ::appScope.isInitialized

    fun init(context: Context) {
        if (isInitialized) return
        val application = context.applicationContext
        appScope = CoroutineScope(SupervisorJob())
        wifiDirectManager = WifiDirectManager(application)
        fileRepository = FileRepository(application)
        installedAppsRepository = InstalledAppsRepository(application)
        sessionManager = SessionManager(wifiDirectManager, fileRepository, appScope)
    }
}
