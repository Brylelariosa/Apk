package com.beamshare.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.beamshare.app.ui.navigation.BeamNavHost
import com.beamshare.app.ui.theme.BeamShareTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            BeamShareTheme {
                BeamNavHost()
            }
        }
    }
}
