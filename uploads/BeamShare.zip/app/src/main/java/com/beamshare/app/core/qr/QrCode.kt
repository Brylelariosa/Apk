package com.beamshare.app.core.qr

import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import java.net.URLDecoder
import java.net.URLEncoder

/** What a BeamShare QR code encodes: enough to connect directly, skipping peer discovery entirely. */
data class ConnectPayload(val macAddress: String, val deviceName: String) {

    fun encode(): String = "$SCHEME://connect?mac=$macAddress&name=${URLEncoder.encode(deviceName, "UTF-8")}"

    companion object {
        private const val SCHEME = "beamshare"

        fun decode(raw: String): ConnectPayload? {
            val uri = runCatching { Uri.parse(raw) }.getOrNull() ?: return null
            if (uri.scheme != SCHEME || uri.host != "connect") return null
            val mac = uri.getQueryParameter("mac")?.takeIf { it.isNotBlank() } ?: return null
            val encodedName = uri.getQueryParameter("name")
            val name = encodedName?.let { runCatching { URLDecoder.decode(it, "UTF-8") }.getOrDefault(mac) } ?: mac
            return ConnectPayload(mac, name)
        }
    }
}

object QrCodeGenerator {
    /** Renders [text] as a QR bitmap. RGB_565 keeps memory use low since a QR code needs no alpha channel. */
    fun generate(text: String, sizePx: Int = 512): ImageBitmap {
        val hints = mapOf(
            EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.M,
            EncodeHintType.MARGIN to 2
        )
        val matrix = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, sizePx, sizePx, hints)
        val bitmap = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.RGB_565)
        for (x in 0 until sizePx) {
            for (y in 0 until sizePx) {
                bitmap.setPixel(x, y, if (matrix.get(x, y)) BLACK else WHITE)
            }
        }
        return bitmap.asImageBitmap()
    }

    private const val BLACK = 0xFF000000.toInt()
    private const val WHITE = 0xFFFFFFFF.toInt()
}
