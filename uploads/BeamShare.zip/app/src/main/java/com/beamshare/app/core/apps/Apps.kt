package com.beamshare.app.core.apps

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.net.Uri
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import com.beamshare.app.core.model.TransferItem
import java.io.File

data class InstalledApp(
    val packageName: String,
    val label: String,
    val icon: ImageBitmap,
    val apkPath: String,
    val apkSizeBytes: Long
)

/** Enumerates user-launchable apps for the "send an app" picker. */
class InstalledAppsRepository(private val context: Context) {

    fun launchableApps(): List<InstalledApp> {
        val pm = context.packageManager
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val selfPackage = context.packageName
        return pm.queryIntentActivities(launcherIntent, PackageManager.MATCH_DEFAULT_ONLY)
            .asSequence()
            .map { it.activityInfo.applicationInfo }
            .distinctBy { it.packageName }
            .filter { it.packageName != selfPackage }
            .mapNotNull { it.toInstalledApp(pm) }
            .sortedBy { it.label.lowercase() }
            .toList()
    }

    private fun ApplicationInfo.toInstalledApp(pm: PackageManager): InstalledApp? {
        val apkFile = sourceDir?.let(::File) ?: return null
        if (!apkFile.exists()) return null
        return InstalledApp(
            packageName = packageName,
            label = loadLabel(pm).toString(),
            icon = loadIcon(pm).toImageBitmap(),
            apkPath = apkFile.absolutePath,
            apkSizeBytes = apkFile.length()
        )
    }
}

/**
 * Sends the base APK only (not split/config APKs from app-bundle installs). That's enough for
 * a working install for the large majority of apps; a handful of dynamically-delivered features
 * on very large apps may need to redownload on first use after install.
 */
fun InstalledApp.toTransferItem(): TransferItem = TransferItem(
    displayName = "$label.apk",
    sizeBytes = apkSizeBytes,
    mimeType = "application/vnd.android.package-archive",
    sourceFilePath = apkPath,
    isApk = true,
    packageName = packageName
)

/** Launches the system installer for a received APK; the user still confirms the install. */
object ApkInstaller {
    fun installIntent(apkUri: Uri): Intent = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(apkUri, "application/vnd.android.package-archive")
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
}

private fun Drawable.toImageBitmap(): ImageBitmap {
    val width = intrinsicWidth.coerceAtLeast(1)
    val height = intrinsicHeight.coerceAtLeast(1)
    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    setBounds(0, 0, canvas.width, canvas.height)
    draw(canvas)
    return bitmap.asImageBitmap()
}
