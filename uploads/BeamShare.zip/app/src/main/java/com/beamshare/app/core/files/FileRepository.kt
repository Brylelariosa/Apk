package com.beamshare.app.core.files

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.core.content.FileProvider
import com.beamshare.app.core.model.TransferItem
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream

/** A writable destination for an incoming transfer, plus how to finalize it once fully written. */
data class IncomingSink(
    val outputStream: OutputStream,
    val uri: Uri,
    val finalize: () -> Unit = {}
)

/** Abstraction boundary so [com.beamshare.app.core.transfer.TransferSession] never touches Context/ContentResolver directly. */
interface FileIo {
    fun openInputStream(item: TransferItem): InputStream
    fun createIncomingSink(name: String, mimeType: String): IncomingSink
}

class FileRepository(private val context: Context) : FileIo {

    private val providerAuthority get() = "${context.packageName}.fileprovider"

    override fun openInputStream(item: TransferItem): InputStream {
        item.sourceUri?.let { uri ->
            return context.contentResolver.openInputStream(uri) ?: error("Could not open ${item.displayName}")
        }
        item.sourceFilePath?.let { path ->
            return FileInputStream(File(path))
        }
        error("TransferItem ${item.displayName} has no source")
    }

    override fun createIncomingSink(name: String, mimeType: String): IncomingSink {
        val safeName = sanitizeFileName(name)
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            createMediaStoreSink(safeName, mimeType)
        } else {
            createLegacySink(safeName)
        }
    }

    /** Resolves an SAF-picked document URI into a queueable [TransferItem]. */
    fun transferItemFromUri(uri: Uri, mimeTypeHint: String? = null): TransferItem {
        val (name, size) = queryDisplayNameAndSize(uri)
        return TransferItem(
            displayName = name,
            sizeBytes = size,
            mimeType = mimeTypeHint ?: context.contentResolver.getType(uri) ?: "application/octet-stream",
            sourceUri = uri
        )
    }

    private fun createMediaStoreSink(name: String, mimeType: String): IncomingSink {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.MIME_TYPE, mimeType)
            put(MediaStore.Downloads.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/BeamShare")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: error("Could not create destination for $name")
        val stream = resolver.openOutputStream(uri) ?: error("Could not open destination for $name")
        return IncomingSink(stream, uri) {
            resolver.update(uri, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null)
        }
    }

    private fun createLegacySink(name: String): IncomingSink {
        val dir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: context.filesDir
        if (!dir.exists()) dir.mkdirs()
        val file = uniqueFile(dir, name)
        val contentUri = FileProvider.getUriForFile(context, providerAuthority, file)
        return IncomingSink(FileOutputStream(file), contentUri)
    }

    private fun uniqueFile(dir: File, name: String): File {
        val dot = name.lastIndexOf('.')
        val base = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var candidate = File(dir, name)
        var index = 1
        while (candidate.exists()) {
            candidate = File(dir, "$base ($index)$ext")
            index++
        }
        return candidate
    }

    private fun sanitizeFileName(name: String): String =
        name.replace(Regex("[/\\\\:*?\"<>|]"), "_").ifBlank { "beamshare_file" }

    private fun queryDisplayNameAndSize(uri: Uri): Pair<String, Long> {
        var displayName = "file"
        var size = 0L
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor: Cursor ->
            val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
            if (cursor.moveToFirst()) {
                if (nameIndex >= 0) cursor.getString(nameIndex)?.let { displayName = it }
                if (sizeIndex >= 0) size = cursor.getLong(sizeIndex)
            }
        }
        return displayName to size
    }
}
