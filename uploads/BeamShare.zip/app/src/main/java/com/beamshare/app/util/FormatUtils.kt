package com.beamshare.app.util

import kotlin.math.ln
import kotlin.math.pow

object FormatUtils {
    private val UNITS = arrayOf("B", "KB", "MB", "GB")

    fun formatBytes(bytes: Long): String {
        if (bytes < 1024) return "$bytes B"
        val exponent = (ln(bytes.toDouble()) / ln(1024.0)).toInt().coerceIn(1, UNITS.size - 1)
        val value = bytes / 1024.0.pow(exponent)
        return String.format("%.1f %s", value, UNITS[exponent])
    }

    fun formatSpeed(bytesPerSec: Long): String = "${formatBytes(bytesPerSec)}/s"
}
