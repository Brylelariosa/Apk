package com.beamshare.app.ui.send

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.beamshare.app.core.apps.InstalledApp
import com.beamshare.app.core.apps.InstalledAppsRepository
import com.beamshare.app.core.apps.toTransferItem
import com.beamshare.app.core.files.FileRepository
import com.beamshare.app.core.model.TransferItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class SelectContentViewModel(
    private val installedAppsRepository: InstalledAppsRepository,
    private val fileRepository: FileRepository
) : ViewModel() {

    private val _apps = MutableStateFlow<List<InstalledApp>>(emptyList())
    private val _selectedPackages = MutableStateFlow<Set<String>>(emptySet())
    private val _selectedFiles = MutableStateFlow<List<TransferItem>>(emptyList())
    private val _searchQuery = MutableStateFlow("")
    private val _loadingApps = MutableStateFlow(false)

    val selectedFiles: StateFlow<List<TransferItem>> = _selectedFiles.asStateFlow()
    val selectedPackages: StateFlow<Set<String>> = _selectedPackages.asStateFlow()
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()
    val loadingApps: StateFlow<Boolean> = _loadingApps.asStateFlow()

    val filteredApps: StateFlow<List<InstalledApp>> = combine(_apps, _searchQuery) { apps, query ->
        if (query.isBlank()) apps else apps.filter { it.label.contains(query, ignoreCase = true) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val totalSelectedCount: StateFlow<Int> = combine(_selectedPackages, _selectedFiles) { apps, files ->
        apps.size + files.size
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)

    val totalSelectedBytes: StateFlow<Long> = combine(_selectedPackages, _selectedFiles) { packages, files ->
        val appBytes = _apps.value.filter { it.packageName in packages }.sumOf { it.apkSizeBytes }
        appBytes + files.sumOf { it.sizeBytes }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0L)

    fun loadAppsIfNeeded() {
        if (_apps.value.isNotEmpty() || _loadingApps.value) return
        _loadingApps.value = true
        viewModelScope.launch(Dispatchers.IO) {
            val apps = installedAppsRepository.launchableApps()
            _apps.value = apps
            _loadingApps.value = false
        }
    }

    fun onSearchQueryChange(query: String) {
        _searchQuery.value = query
    }

    fun toggleApp(packageName: String) {
        _selectedPackages.update { current -> if (packageName in current) current - packageName else current + packageName }
    }

    fun addFileUris(uris: List<Uri>) {
        viewModelScope.launch(Dispatchers.IO) {
            val items = uris.map { fileRepository.transferItemFromUri(it) }
            _selectedFiles.update { it + items }
        }
    }

    fun removeFile(id: String) {
        _selectedFiles.update { list -> list.filterNot { it.id == id } }
    }

    fun buildTransferItems(): List<TransferItem> {
        val appItems = _apps.value.filter { it.packageName in _selectedPackages.value }.map { it.toTransferItem() }
        return _selectedFiles.value + appItems
    }
}
