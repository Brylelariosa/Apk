package com.beamshare.app.ui.send

import androidx.lifecycle.ViewModel
import com.beamshare.app.core.discovery.WifiDirectManager
import com.beamshare.app.core.model.ConnectionState
import com.beamshare.app.core.model.PeerDevice
import com.beamshare.app.core.model.SessionState
import com.beamshare.app.core.qr.ConnectPayload
import com.beamshare.app.core.transfer.SessionManager
import com.beamshare.app.core.transfer.SessionRole
import kotlinx.coroutines.flow.StateFlow

class DiscoverViewModel(
    private val wifiDirectManager: WifiDirectManager,
    private val sessionManager: SessionManager
) : ViewModel() {

    val peers: StateFlow<List<PeerDevice>> = wifiDirectManager.peers
    val connectionState: StateFlow<ConnectionState> = wifiDirectManager.connectionState
    val sessionState: StateFlow<SessionState> = sessionManager.sessionState
    val isWifiDirectSupported: Boolean get() = wifiDirectManager.isSupported

    fun hasPermission(): Boolean = wifiDirectManager.hasNearbyPermission()

    fun startDiscovery() {
        wifiDirectManager.start()
        wifiDirectManager.startDiscovery()
        sessionManager.watchForLink(SessionRole.INITIATOR)
    }

    fun connectToDevice(device: PeerDevice) {
        wifiDirectManager.stopDiscovery()
        wifiDirectManager.connect(device)
    }

    fun connectToQrPayload(payload: ConnectPayload) {
        wifiDirectManager.stopDiscovery()
        wifiDirectManager.connectToAddress(payload.macAddress, payload.deviceName)
    }
}
