package com.beamshare.app

import android.app.Application
import android.os.Build
import com.beamshare.app.di.ServiceLocator

class BeamShareApp : Application() {
    override fun onCreate() {
        super.onCreate()
        ServiceLocator.init(this)
        ServiceLocator.sessionManager.localDeviceName = Build.MODEL ?: "BeamShare device"
    }
}
