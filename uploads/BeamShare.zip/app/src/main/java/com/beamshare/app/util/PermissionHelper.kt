package com.beamshare.app.util

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat

object PermissionHelper {

    /** The one runtime permission WiFi Direct discovery/connect needs on this OS version. */
    fun nearbyPermission(): String = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        Manifest.permission.NEARBY_WIFI_DEVICES
    } else {
        Manifest.permission.ACCESS_FINE_LOCATION
    }

    fun hasNearbyPermission(context: Context): Boolean = isGranted(context, nearbyPermission())

    fun hasCameraPermission(context: Context): Boolean = isGranted(context, Manifest.permission.CAMERA)

    /** Null on API levels where notification permission isn't a runtime prompt. */
    fun notificationPermissionOrNull(): String? =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) Manifest.permission.POST_NOTIFICATIONS else null

    private fun isGranted(context: Context, permission: String): Boolean =
        ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
}
