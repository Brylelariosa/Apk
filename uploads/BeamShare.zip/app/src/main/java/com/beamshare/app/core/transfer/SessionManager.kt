package com.beamshare.app.core.transfer

import com.beamshare.app.core.discovery.WifiDirectManager
import com.beamshare.app.core.files.FileIo
import com.beamshare.app.core.model.ConnectionState
import com.beamshare.app.core.model.SessionState
import com.beamshare.app.core.model.TransferItem
import com.beamshare.app.core.model.TransferProgress
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/** Which side of the pairing this device took - decides whether a handshake needs explicit consent. */
enum class SessionRole { INITIATOR, RECEIVER }

/**
 * Owns everything from "WiFi Direct link formed" through the app-level handshake to an active,
 * reusable [TransferSession]. UI layers observe [sessionState] / [progress] only - they never
 * touch sockets or WifiP2pManager directly, and never need to re-pair for a later send.
 */
class SessionManager(
    private val wifiDirectManager: WifiDirectManager,
    private val fileIo: FileIo,
    private val scope: CoroutineScope
) {
    private val _sessionState = MutableStateFlow<SessionState>(SessionState.None)
    val sessionState: StateFlow<SessionState> = _sessionState.asStateFlow()

    private val _progress = MutableStateFlow<List<TransferProgress>>(emptyList())
    val progress: StateFlow<List<TransferProgress>> = _progress.asStateFlow()

    var localDeviceName: String = "BeamShare device"

    private var session: TransferSession? = null
    private var linkWatchJob: Job? = null
    private var pendingPeerName: String? = null

    /** Starts watching for a WiFi Direct link to form. [role] decides consent behavior once it does. */
    fun watchForLink(role: SessionRole) {
        _sessionState.value = SessionState.None
        linkWatchJob?.cancel()
        linkWatchJob = scope.launch {
            wifiDirectManager.connectionState.collect { state ->
                if (state is ConnectionState.LinkEstablished && session == null) {
                    openSession(state.isGroupOwner, state.groupOwnerAddress, role)
                }
            }
        }
    }

    fun stopWatching() {
        linkWatchJob?.cancel()
        linkWatchJob = null
    }

    /** Queues [items] on the active session, one at a time, in order. No-op if nothing is connected. */
    suspend fun sendItems(items: List<TransferItem>) {
        val active = session ?: return
        items.forEach { item -> runCatching { active.send(item) } }
    }

    fun acceptIncoming() {
        val name = pendingPeerName ?: return
        _sessionState.value = SessionState.Connected(name)
    }

    fun declineIncoming() {
        session?.close()
        session = null
        wifiDirectManager.disconnect()
        _sessionState.value = SessionState.Disconnected
    }

    fun disconnect() {
        session?.close()
        session = null
        stopWatching()
        wifiDirectManager.disconnect()
        _progress.value = emptyList()
        _sessionState.value = SessionState.Disconnected
    }

    private suspend fun openSession(isGroupOwner: Boolean, groupOwnerAddress: String, role: SessionRole) {
        _sessionState.value = SessionState.AwaitingHandshake
        val socket = withTimeoutOrNull(SOCKET_TIMEOUT_MS) {
            runCatching { TransferSession.open(isGroupOwner, groupOwnerAddress) }.getOrNull()
        }
        if (socket == null) {
            _sessionState.value = SessionState.Disconnected
            return
        }

        val newSession = TransferSession(socket, fileIo, scope)
        session = newSession

        scope.launch { newSession.progress.collect { _progress.value = it } }
        scope.launch {
            newSession.peerName.collect { name ->
                if (name == null) return@collect
                pendingPeerName = name
                _sessionState.value = if (role == SessionRole.RECEIVER) {
                    SessionState.IncomingRequest(name)
                } else {
                    SessionState.Connected(name)
                }
            }
        }
        scope.launch {
            newSession.closed.collect { isClosed ->
                if (isClosed && session === newSession) {
                    session = null
                    _sessionState.value = SessionState.Disconnected
                }
            }
        }

        newSession.start(localDeviceName)
    }

    companion object {
        private const val SOCKET_TIMEOUT_MS = 30_000L
    }
}
