package com.beamshare.app.ui.session

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.beamshare.app.core.model.SessionState
import com.beamshare.app.core.model.TransferItem
import com.beamshare.app.core.model.TransferProgress
import com.beamshare.app.core.transfer.SessionManager
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class SessionViewModel(private val sessionManager: SessionManager) : ViewModel() {

    val sessionState: StateFlow<SessionState> = sessionManager.sessionState
    val progress: StateFlow<List<TransferProgress>> = sessionManager.progress

    private var pendingDispatched = false

    /** Dispatches items queued before the connection was established. Safe to call multiple times - only sends once. */
    fun sendPendingOnce(items: List<TransferItem>) {
        if (pendingDispatched || items.isEmpty()) return
        pendingDispatched = true
        sendItems(items)
    }

    fun sendItems(items: List<TransferItem>) {
        if (items.isEmpty()) return
        viewModelScope.launch { sessionManager.sendItems(items) }
    }

    fun disconnect() {
        sessionManager.disconnect()
    }
}
