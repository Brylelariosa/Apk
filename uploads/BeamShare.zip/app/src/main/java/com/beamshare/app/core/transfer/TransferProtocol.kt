package com.beamshare.app.core.transfer

import java.io.DataInputStream
import java.io.DataOutputStream

/**
 * Wire format for the control channel riding on the WiFi Direct TCP socket.
 * Every control message is `[1 byte type][4 byte big-endian length][payload]`.
 * Raw file bytes are streamed immediately after a FILE_START frame with no further
 * per-chunk framing overhead, since both sides already know the exact size from the
 * matching OFFER - this keeps throughput close to raw socket speed.
 */
object TransferProtocol {
    const val PORT = 58432
    const val IO_BUFFER_SIZE = 128 * 1024

    const val TYPE_HELLO = 0x01
    const val TYPE_OFFER = 0x02
    const val TYPE_ACCEPT = 0x03
    const val TYPE_REJECT = 0x04
    const val TYPE_FILE_START = 0x05
    const val TYPE_FILE_DONE = 0x06
    const val TYPE_CANCEL = 0x07
    const val TYPE_BYE = 0x08

    private const val FIELD_SEP = '\u001F'

    data class Frame(val type: Int, val payload: ByteArray)

    data class OfferPayload(
        val id: String,
        val name: String,
        val sizeBytes: Long,
        val mimeType: String,
        val isApk: Boolean
    )

    fun writeFrame(out: DataOutputStream, type: Int, payload: ByteArray = ByteArray(0)) {
        out.writeByte(type)
        out.writeInt(payload.size)
        if (payload.isNotEmpty()) out.write(payload)
        out.flush()
    }

    fun readFrame(input: DataInputStream): Frame {
        val type = input.readUnsignedByte()
        val length = input.readInt()
        val payload = if (length > 0) ByteArray(length).also { input.readFully(it) } else ByteArray(0)
        return Frame(type, payload)
    }

    fun encodeOffer(item: OfferPayload): ByteArray = listOf(
        item.id,
        item.name,
        item.sizeBytes.toString(),
        item.mimeType,
        if (item.isApk) "1" else "0"
    ).joinToString(FIELD_SEP.toString()).toByteArray(Charsets.UTF_8)

    fun decodeOffer(payload: ByteArray): OfferPayload {
        val parts = String(payload, Charsets.UTF_8).split(FIELD_SEP)
        return OfferPayload(
            id = parts.getOrElse(0) { "" },
            name = parts.getOrElse(1) { "file" },
            sizeBytes = parts.getOrElse(2) { "0" }.toLongOrNull() ?: 0L,
            mimeType = parts.getOrElse(3) { "application/octet-stream" },
            isApk = parts.getOrElse(4) { "0" } == "1"
        )
    }
}
