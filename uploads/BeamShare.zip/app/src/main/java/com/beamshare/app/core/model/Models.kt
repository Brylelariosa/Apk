package com.beamshare.app.core.model

import android.net.Uri
import java.util.UUID

/** A device discovered (or paired with) over WiFi Direct. */
data class PeerDevice(
    val macAddress: String,
    val name: String,
    val isGroupOwner: Boolean = false
)

/** Something the user picked to send: a file or an installed app's APK. */
data class TransferItem(
    val id: String = UUID.randomUUID().toString(),
    val displayName: String,
    val sizeBytes: Long,
    val mimeType: String,
    val sourceUri: Uri? = null,
    val sourceFilePath: String? = null,
    val isApk: Boolean = false,
    val packageName: String? = null
)

enum class TransferDirection { SEND, RECEIVE }

enum class TransferState { QUEUED, IN_PROGRESS, COMPLETED, FAILED, CANCELLED }

data class TransferProgress(
    val itemId: String,
    val name: String,
    val direction: TransferDirection,
    val totalBytes: Long,
    val transferredBytes: Long = 0L,
    val state: TransferState = TransferState.QUEUED,
    val isApk: Boolean = false,
    val savedUri: Uri? = null,
    val speedBytesPerSec: Long = 0L
) {
    val fraction: Float
        get() = if (totalBytes <= 0L) 0f else (transferredBytes.toFloat() / totalBytes.toFloat()).coerceIn(0f, 1f)
}

/** Lifecycle of the WiFi Direct link, independent of the app-level session on top of it. */
sealed interface ConnectionState {
    data object Idle : ConnectionState
    data object Discovering : ConnectionState
    data class Connecting(val target: PeerDevice) : ConnectionState
    data class LinkEstablished(val isGroupOwner: Boolean, val groupOwnerAddress: String) : ConnectionState
    data class Failed(val reason: String) : ConnectionState
}

/** App-level session state, layered on top of ConnectionState once a socket is up. */
sealed interface SessionState {
    data object None : SessionState
    data object AwaitingHandshake : SessionState
    data class IncomingRequest(val peerName: String) : SessionState
    data class Connected(val peerName: String) : SessionState
    data object Disconnected : SessionState
}
