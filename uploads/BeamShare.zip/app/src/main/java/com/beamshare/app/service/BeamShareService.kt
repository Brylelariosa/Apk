package com.beamshare.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import com.beamshare.app.MainActivity
import com.beamshare.app.R
import com.beamshare.app.core.model.SessionState
import com.beamshare.app.di.ServiceLocator
import kotlinx.coroutines.launch

/**
 * Thin lifecycle wrapper: starts the foreground notification and mirrors [ServiceLocator]'s
 * session state into it. It owns no transfer logic itself - that all lives in [SessionManager]
 * so it keeps working identically whether or not this service happens to be running.
 */
class BeamShareService : LifecycleService() {

    override fun onCreate() {
        super.onCreate()
        if (!ServiceLocator.isInitialized) ServiceLocator.init(applicationContext)
        createChannel()
        ServiceCompat.startForeground(
            this,
            NOTIFICATION_ID,
            buildNotification(getString(R.string.notification_session_active)),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE
        )
        observeSession()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        return START_NOT_STICKY
    }

    private fun observeSession() {
        lifecycleScope.launch {
            ServiceLocator.sessionManager.sessionState.collect { state ->
                when (state) {
                    is SessionState.Disconnected -> stopSelf()
                    is SessionState.Connected -> updateNotification(getString(R.string.session_connected_to, state.peerName))
                    else -> updateNotification(getString(R.string.notification_session_active))
                }
            }
        }
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java)?.notify(NOTIFICATION_ID, buildNotification(text))
    }

    private fun buildNotification(text: String): Notification {
        val openApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentIntent(openApp)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, getString(R.string.notification_channel_name), NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
        }
    }

    companion object {
        private const val CHANNEL_ID = "beamshare_session"
        private const val NOTIFICATION_ID = 1001

        fun start(context: Context) {
            context.startForegroundService(Intent(context, BeamShareService::class.java))
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, BeamShareService::class.java))
        }
    }
}
