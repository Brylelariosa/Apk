#!/usr/bin/env bash
# Optional RGSS engine (RPG Maker XP / VX / VX Ace) for Splice.
#
# Builds the open-source mkxp-z Android port (https://github.com/BookerRues9/mkxp-z-android-reworked)
# with the same recipe its own CI uses, then harvests the result into the Gradle library module
# ./rgss-engine and generates the activity that connects it to Splice's UI.
#
# Called from ./gradlew before Gradle starts. It NEVER fails the build: on any problem it records
# the reason (shown in Settings > Engines) and exits 0, so you still get an APK with MV/MZ support.
#
# Environment:
#   SPLICE_SKIP_ENGINE=1        skip the engine entirely (or create a file named engine.disabled)
#   SPLICE_ENGINE_REF=<sha>     engine commit to build (default pinned below)
#   SPLICE_ENGINE_REPO=<url>    engine repository
#
# Output is cached inside app/.cxx (which the CI workflow caches), so only the first run is slow.
set -uo pipefail

ROOT="${1:-$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)}"
TOOLS="$ROOT/tools/engine"
ENGINE_DIR="$ROOT/rgss-engine"
GEN_DIR="$ROOT/app/src/rgss"
ASSETS_DIR="$ROOT/app/src/main/assets"
PRO_FILE="$ROOT/app/proguard-engine.pro"
CACHE_DIR="$ROOT/app/.cxx/splice-engine"
WORK="${SPLICE_ENGINE_WORK:-$ROOT/build-engine-work}"
REPO="${SPLICE_ENGINE_REPO:-https://github.com/BookerRues9/mkxp-z-android-reworked.git}"
REF="${SPLICE_ENGINE_REF:-b668e08cb58edf661d56fd4d396036ac31cd8332}"
NDK_VER="${SPLICE_ENGINE_NDK:-23.2.8568313}"
SCHEMA="1"
KEY="$SCHEMA|$REPO|$REF|$NDK_VER"
STARTED=$(date +%s)

log() { echo "[splice-engine] $*"; }
set_status() { mkdir -p "$ASSETS_DIR"; printf '%s\n' "$1" > "$ASSETS_DIR/engine_status.txt"; }
clean_outputs() { rm -rf "$ENGINE_DIR/READY" "$ENGINE_DIR/engine.properties" "$ENGINE_DIR/src" "$GEN_DIR" "$PRO_FILE"; }
fail() { log "FAILED: $*"; clean_outputs; set_status "RGSS engine was not built: $*"; exit 0; }
skip() { log "skipped: $*"; clean_outputs; set_status "RGSS engine skipped: $*"; exit 0; }
elapsed() { echo $(( $(date +%s) - STARTED )); }

# ---- preconditions -----------------------------------------------------------------------------
[ "${SPLICE_SKIP_ENGINE:-0}" = "1" ] && skip "SPLICE_SKIP_ENGINE=1"
[ -f "$ROOT/engine.disabled" ] && skip "engine.disabled file present"
[ "$(uname -s)" = "Linux" ] && [ "$(uname -m)" = "x86_64" ] || skip "needs a Linux x86_64 build host"
SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
[ -n "$SDK" ] && [ -d "$SDK" ] || skip "Android SDK not found (ANDROID_HOME)"

# ---- cache -------------------------------------------------------------------------------------
PAYLOAD="$CACHE_DIR/payload.tar"
if [ -f "$PAYLOAD" ] && [ -f "$CACHE_DIR/KEY" ] && [ "$(cat "$CACHE_DIR/KEY")" = "$KEY" ]; then
    clean_outputs
    if tar -xf "$PAYLOAD" -C "$ROOT" 2>/dev/null && [ -f "$ENGINE_DIR/READY" ]; then
        log "restored the RGSS engine from cache ($(du -sh "$PAYLOAD" | cut -f1))"
        exit 0
    fi
    log "cache payload unusable, rebuilding"
    clean_outputs
fi
clean_outputs
set_status "RGSS engine build in progress"

mkdir -p "$WORK"
SUDO=""
if [ "$(id -u)" != "0" ] && command -v sudo >/dev/null 2>&1; then SUDO="sudo"; fi

# ---- host tools --------------------------------------------------------------------------------
if command -v apt-get >/dev/null 2>&1; then
    log "installing host build tools"
    $SUDO apt-get update -y >/dev/null 2>&1 || true
    $SUDO env DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \
        build-essential cmake curl gpg xxd ruby-full autoconf automake libtool pkg-config \
        python3 git unzip gperf gettext autopoint nasm >/dev/null 2>&1 || log "apt-get reported problems (continuing)"
fi
for t in git make python3 curl unzip xxd; do
    command -v "$t" >/dev/null 2>&1 || fail "missing host tool: $t"
done

# Ruby 3.1 is what the engine's CI uses as the build-time "baseruby"; try a prebuilt toolcache copy.
ensure_ruby31() {
    if ruby -e 'exit(RUBY_VERSION.start_with?("3.1") ? 0 : 1)' 2>/dev/null; then return 0; fi
    local osv tool v url dest
    osv=$( . /etc/os-release 2>/dev/null; echo "${VERSION_ID:-22.04}" )
    tool="${RUNNER_TOOL_CACHE:-/opt/hostedtoolcache}"
    for v in 3.1.7 3.1.6 3.1.4; do
        dest="$tool/Ruby/$v/x64"
        url="https://github.com/ruby/ruby-builder/releases/download/toolcache/ruby-$v-ubuntu-$osv.tar.gz"
        if curl -fsSL --retry 2 --connect-timeout 20 "$url" -o "$WORK/ruby31.tgz" 2>/dev/null; then
            mkdir -p "$dest" 2>/dev/null || $SUDO mkdir -p "$dest"
            if tar -xzf "$WORK/ruby31.tgz" -C "$dest" 2>/dev/null || $SUDO tar -xzf "$WORK/ruby31.tgz" -C "$dest"; then
                if [ -x "$dest/bin/ruby" ]; then
                    export PATH="$dest/bin:$PATH"
                    log "using $(ruby -v)"
                    return 0
                fi
            fi
        fi
    done
    log "Ruby 3.1 toolcache build not available; using system Ruby: $(ruby -v 2>/dev/null || echo none)"
    return 0
}
ensure_ruby31
command -v ruby >/dev/null 2>&1 || fail "no Ruby available on the build host"

# ---- NDK (the engine's recipe is pinned to r23) --------------------------------------------------
NDK="$SDK/ndk/$NDK_VER"
if [ ! -d "$NDK" ]; then
    SM="$(command -v sdkmanager || true)"
    [ -z "$SM" ] && SM="$SDK/cmdline-tools/latest/bin/sdkmanager"
    [ -x "$SM" ] || fail "sdkmanager not found, cannot install NDK $NDK_VER"
    log "installing NDK $NDK_VER"
    yes 2>/dev/null | "$SM" --licenses >/dev/null 2>&1 || true
    "$SM" --install "ndk;$NDK_VER" >/dev/null 2>&1 || "$SM" --install "ndk;$NDK_VER" || fail "could not install NDK $NDK_VER"
fi
[ -d "$NDK" ] || fail "NDK $NDK_VER missing after install"

# ---- fetch the engine --------------------------------------------------------------------------
ENG="$WORK/engine"
rm -rf "$ENG"
mkdir -p "$ENG"
log "fetching $REPO @ ${REF:0:10}"
(
    cd "$ENG" || exit 1
    git init -q . && git remote add origin "$REPO" || exit 1
    if ! git fetch -q --depth 1 origin "$REF" 2>/dev/null; then
        echo "[splice-engine] pinned revision not fetchable, using the default branch"
        git fetch -q --depth 1 origin HEAD || exit 1
    fi
    git checkout -q FETCH_HEAD || exit 1
    git submodule update --init --recursive --depth 1 -q || exit 1
) || fail "could not fetch the engine sources"
REV_ACTUAL=$(cd "$ENG" && git rev-parse HEAD 2>/dev/null || echo "$REF")

# ---- native dependencies (arm64-v8a, same as the engine's own CI) ------------------------------
export ANDROID_NDK_HOME="$NDK"
export ARCH=linux-x86_64
export PATH="$NDK/toolchains/llvm/prebuilt/$ARCH/bin:$PATH"
log "building native dependencies (this is the slow part, once)"
(
    cd "$ENG/app/jni" || exit 1
    chmod +x get_deps.sh && ./get_deps.sh || exit 11
    ( cd mkxp-z && chmod +x make_xxd.sh && ./make_xxd.sh ) || exit 12
    HOST=aarch64-linux-android TARGET=aarch64-linux-android ABI=arm64-v8a \
        LDFLAGS="-Wl,-z,max-page-size=16384" timeout 30m make -j"$(nproc)" || exit 13
    if [ -d build-arm64-v8a ] && [ ! -e build-arm64 ]; then ln -s build-arm64-v8a build-arm64; fi
) > "$WORK/deps.log" 2>&1
rc=$?
if [ $rc -ne 0 ]; then
    tail -n 40 "$WORK/deps.log"
    fail "native dependency build failed (step code $rc); see the CI log above"
fi
log "dependencies built after $(elapsed)s"

# ---- engine APK (gives us the linked native libraries) -----------------------------------------
log "building the engine package"
(
    cd "$ENG" || exit 1
    chmod +x gradlew
    timeout 25m ./gradlew assembleRelease -Pandroid.suppressUnsupportedCompileSdk=34 --no-daemon --stacktrace
) > "$WORK/gradle.log" 2>&1
rc=$?
if [ $rc -ne 0 ]; then
    tail -n 60 "$WORK/gradle.log"
    fail "engine Gradle build failed (code $rc); see the CI log above"
fi
log "engine package built after $(elapsed)s"

# ---- harvest -----------------------------------------------------------------------------------
python3 "$TOOLS/harvest.py" "$ENG" "$ROOT" "$REV_ACTUAL" || fail "could not harvest the engine build (harvest.py code $?)"
set_status "RGSS engine: mkxp-z Android port ${REV_ACTUAL:0:10}, arm64-v8a, built in $(elapsed)s"

# ---- cache -------------------------------------------------------------------------------------
mkdir -p "$CACHE_DIR"
if tar -cf "$PAYLOAD" -C "$ROOT" rgss-engine/src rgss-engine/engine.properties rgss-engine/READY \
        app/src/rgss app/proguard-engine.pro app/src/main/assets/engine_status.txt 2>/dev/null; then
    printf '%s' "$KEY" > "$CACHE_DIR/KEY"
    log "cached engine payload ($(du -sh "$PAYLOAD" | cut -f1))"
fi
rm -rf "$WORK"
log "RGSS engine ready (total $(elapsed)s)"
exit 0
