package dev.splice.player.data

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.Settings
import dev.splice.player.core.Paths
import java.io.File

object StorageAccess {
    const val REQ_LEGACY = 4101

    fun hasAllFiles(ctx: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= 30) {
            Environment.isExternalStorageManager()
        } else {
            ctx.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        }
    }

    /** True if [f] is outside the app's own folders and we lack the permission to read it. */
    fun needsPermission(ctx: Context, f: File): Boolean = !Paths.isInsideApp(ctx, f) && !hasAllFiles(ctx)

    fun request(act: Activity) {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                val i = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + act.packageName))
                act.startActivity(i)
            } catch (t: Throwable) {
                try {
                    act.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                } catch (_: Throwable) {
                }
            }
        } else {
            act.requestPermissions(
                arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE),
                REQ_LEGACY
            )
        }
    }

    /** Converts a document-tree URI on primary/SD storage to a real path, or null. */
    fun treeUriToPath(uri: Uri): File? {
        return try {
            val docId = DocumentsContract.getTreeDocumentId(uri)
            val idx = docId.indexOf(':')
            if (idx < 0) return null
            val vol = docId.substring(0, idx)
            val rel = docId.substring(idx + 1)
            val base = if (vol.equals("primary", ignoreCase = true)) Environment.getExternalStorageDirectory() else File("/storage/$vol")
            val f = if (rel.isEmpty()) base else File(base, rel)
            if (f.exists()) f else null
        } catch (t: Throwable) {
            null
        }
    }

    fun freeBytes(dir: File): Long = try {
        android.os.StatFs(dir.absolutePath).availableBytes
    } catch (t: Throwable) {
        -1L
    }
}
