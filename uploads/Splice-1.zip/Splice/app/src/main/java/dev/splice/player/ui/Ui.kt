package dev.splice.player.ui

import android.animation.ValueAnimator
import android.app.Dialog
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.text.InputType
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import dev.splice.player.R

/** Design tokens: ink-violet surfaces with a mint / peach "splice" duotone. */
object C {
    const val BG = 0xFF14121D.toInt()
    const val SURFACE = 0xFF1C1A29.toInt()
    const val SURFACE2 = 0xFF252236.toInt()
    const val SURFACE3 = 0xFF2F2B45.toInt()
    const val OUTLINE = 0xFF3B3756.toInt()
    const val TEXT = 0xFFEDEAF7.toInt()
    const val DIM = 0xFFA29DBC.toInt()
    const val FAINT = 0xFF6F6A8C.toInt()
    const val MINT = 0xFF5BE3C4.toInt()
    const val PEACH = 0xFFFFA98A.toInt()
    const val DANGER = 0xFFFF6B7A.toInt()
    const val WARN = 0xFFFFC857.toInt()
    const val ON_MINT = 0xFF08241F.toInt()
}

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

fun Context.dp(v: Float): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
fun Context.dp(v: Int): Int = dp(v.toFloat())
fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density
fun View.dp(v: Int): Int = context.dp(v)
fun View.dp(v: Float): Int = context.dp(v)

fun Context.toast(msg: String) {
    Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}

fun Context.shape(color: Int, radiusDp: Float = 0f, strokeColor: Int = 0, strokeDp: Float = 0f): GradientDrawable {
    val d = GradientDrawable()
    d.setColor(color)
    d.cornerRadius = dpf(radiusDp)
    if (strokeDp > 0f) d.setStroke(dp(strokeDp).coerceAtLeast(1), strokeColor)
    return d
}

fun Context.ripple(content: Drawable?, radiusDp: Float = 0f, rippleColor: Int = 0x33FFFFFF): Drawable {
    val mask = GradientDrawable()
    mask.setColor(Color.WHITE)
    mask.cornerRadius = dpf(radiusDp)
    return RippleDrawable(ColorStateList.valueOf(rippleColor), content, mask)
}

fun Context.text(s: CharSequence, sp: Float = 14f, color: Int = C.TEXT, weight: Int = 0, maxLines: Int = 0): TextView {
    val t = TextView(this)
    t.text = s
    t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
    t.setTextColor(color)
    t.typeface = Typeface.create(if (weight == 0) "sans-serif" else "sans-serif-medium", if (weight == 2) Typeface.BOLD else Typeface.NORMAL)
    t.includeFontPadding = false
    if (maxLines > 0) {
        t.maxLines = maxLines
        t.ellipsize = TextUtils.TruncateAt.END
    }
    return t
}

fun Context.icon(res: Int, tint: Int = C.TEXT, sizeDp: Int = 24): ImageView {
    val v = ImageView(this)
    v.setImageResource(res)
    v.setColorFilter(tint)
    v.layoutParams = ViewGroup.LayoutParams(dp(sizeDp), dp(sizeDp))
    return v
}

fun Context.vbox(): LinearLayout {
    val l = LinearLayout(this)
    l.orientation = LinearLayout.VERTICAL
    return l
}

fun Context.hbox(centerV: Boolean = true): LinearLayout {
    val l = LinearLayout(this)
    l.orientation = LinearLayout.HORIZONTAL
    if (centerV) l.gravity = Gravity.CENTER_VERTICAL
    return l
}

/** Adds [v] to a LinearLayout with dp margins. */
fun LinearLayout.add(
    v: View, w: Int = MATCH, h: Int = WRAP, weight: Float = 0f,
    l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0
): View {
    val p = LinearLayout.LayoutParams(w, h, weight)
    p.setMargins(dp(l), dp(t), dp(r), dp(b))
    addView(v, p)
    return v
}

fun View.pressable(scale: Float = 0.97f) {
    setOnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> v.animate().scaleX(scale).scaleY(scale).setDuration(90).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).setDuration(150).start()
        }
        false
    }
}

const val BTN_PRIMARY = 0
const val BTN_TONAL = 1
const val BTN_GHOST = 2
const val BTN_DANGER = 3

fun Context.button(label: String, iconRes: Int = 0, kind: Int = BTN_TONAL, onClick: () -> Unit): TextView {
    val bg: Int
    val fg: Int
    when (kind) {
        BTN_PRIMARY -> { bg = C.MINT; fg = C.ON_MINT }
        BTN_DANGER -> { bg = 0x33FF6B7A; fg = C.DANGER }
        BTN_GHOST -> { bg = 0x00000000; fg = C.TEXT }
        else -> { bg = C.SURFACE3; fg = C.TEXT }
    }
    val t = text(label, 14f, fg, 1)
    t.gravity = Gravity.CENTER
    t.setPadding(dp(18), dp(13), dp(18), dp(13))
    val base: Drawable = if (kind == BTN_GHOST) shape(0, 14f, C.OUTLINE, 1f) else shape(bg, 14f)
    t.background = ripple(base, 14f, if (kind == BTN_PRIMARY) 0x33000000 else 0x33FFFFFF)
    if (iconRes != 0) {
        val d = getDrawable(iconRes)?.mutate()
        if (d != null) {
            d.setTint(fg)
            d.setBounds(0, 0, dp(20), dp(20))
            t.setCompoundDrawablesRelative(d, null, null, null)
            t.compoundDrawablePadding = dp(8)
        }
    }
    t.isClickable = true
    t.setOnClickListener { onClick() }
    t.pressable(0.96f)
    return t
}

fun Context.iconButton(res: Int, tint: Int = C.TEXT, sizeDp: Int = 44, onClick: () -> Unit): FrameLayout {
    val f = FrameLayout(this)
    f.layoutParams = ViewGroup.LayoutParams(dp(sizeDp), dp(sizeDp))
    val i = icon(res, tint, 22)
    f.addView(i, FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER))
    f.background = ripple(null, sizeDp / 2f, 0x33FFFFFF)
    f.isClickable = true
    f.setOnClickListener { onClick() }
    return f
}

fun Context.chip(label: String, selected: Boolean, onClick: () -> Unit): TextView {
    val t = text(label, 13f, if (selected) C.MINT else C.DIM, 1)
    t.gravity = Gravity.CENTER
    t.setPadding(dp(14), dp(8), dp(14), dp(8))
    val base = if (selected) shape(0x265BE3C4, 100f, C.MINT, 1f) else shape(C.SURFACE2, 100f, C.OUTLINE, 1f)
    t.background = ripple(base, 100f)
    t.isClickable = true
    t.setOnClickListener { onClick() }
    return t
}

fun Context.badge(label: String, color: Int = C.MINT): TextView {
    val t = text(label, 10.5f, C.ON_MINT, 2)
    t.setPadding(dp(7), dp(3), dp(7), dp(3))
    t.background = shape(color, 6f)
    t.letterSpacing = 0.04f
    return t
}

fun Context.sectionTitle(s: String): TextView {
    val t = text(s.uppercase(), 11.5f, C.DIM, 1)
    t.letterSpacing = 0.12f
    return t
}

fun Context.input(hint: String, value: String = "", multiline: Boolean = false): EditText {
    val e = EditText(this)
    e.setText(value)
    e.hint = hint
    e.setTextColor(C.TEXT)
    e.setHintTextColor(C.FAINT)
    e.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
    e.background = shape(C.SURFACE2, 12f, C.OUTLINE, 1f)
    e.setPadding(dp(14), dp(12), dp(14), dp(12))
    if (multiline) {
        e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        e.minLines = 3
        e.gravity = Gravity.TOP
    } else {
        e.setSingleLine(true)
        e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
    }
    return e
}

fun Context.scroll(content: View): ScrollView {
    val s = ScrollView(this)
    s.isVerticalScrollBarEnabled = false
    s.overScrollMode = View.OVER_SCROLL_NEVER
    s.isFillViewport = false
    s.addView(content, FrameLayout.LayoutParams(MATCH, WRAP))
    return s
}

/** A page in the app (library, saves, ...). Pushed/popped by MainActivity. */
abstract class Screen(ctx: Context) : FrameLayout(ctx) {
    open fun onShow() {}
    open fun onHide() {}
    open fun onBack(): Boolean = false
    open fun onDestroyScreen() {}
}

/** Top bar used by pushed pages: back arrow, title and optional trailing action. */
fun Context.topBar(title: String, onBack: () -> Unit, trailing: View? = null): LinearLayout {
    val bar = hbox()
    bar.setPadding(dp(8), dp(8), dp(12), dp(8))
    bar.add(iconButton(R.drawable.ic_back, C.TEXT, 44) { onBack() }, dp(44), dp(44))
    bar.add(text(title, 18f, C.TEXT, 1, 1), 0, WRAP, 1f, 6, 0, 6, 0)
    if (trailing != null) bar.addView(trailing)
    return bar
}

/** Bottom sheet built on a Dialog (slides up, tap outside to dismiss). */
class Sheet(private val ctx: Context, title: String? = null, subtitle: String? = null) {
    val dialog = Dialog(ctx, R.style.Theme_Splice_Sheet)
    val content: LinearLayout = ctx.vbox()
    private val root: LinearLayout = ctx.vbox()

    init {
        val r = ctx.dpf(24f)
        val bg = GradientDrawable()
        bg.setColor(C.SURFACE)
        bg.cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
        root.background = bg
        root.setPadding(ctx.dp(20), ctx.dp(10), ctx.dp(20), ctx.dp(22))
        val grab = View(ctx)
        grab.background = ctx.shape(C.OUTLINE, 3f)
        root.add(grab, ctx.dp(38), ctx.dp(4), 0f, 0, 0, 0, 14)
        (grab.layoutParams as LinearLayout.LayoutParams).gravity = Gravity.CENTER_HORIZONTAL
        if (title != null) root.add(ctx.text(title, 18f, C.TEXT, 1), MATCH, WRAP, 0f, 0, 0, 0, if (subtitle == null) 12 else 4)
        if (subtitle != null) root.add(ctx.text(subtitle, 13f, C.DIM), MATCH, WRAP, 0f, 0, 0, 0, 12)
        root.addView(ctx.scroll(content), LinearLayout.LayoutParams(MATCH, WRAP))
        dialog.setContentView(root)
        dialog.window?.let { w ->
            w.setGravity(Gravity.BOTTOM)
            w.setLayout(MATCH, WRAP)
            w.setBackgroundDrawable(ColorDrawable(0))
        }
    }

    fun action(label: String, iconRes: Int, danger: Boolean = false, onClick: () -> Unit): Sheet {
        val row = ctx.hbox()
        row.setPadding(ctx.dp(8), ctx.dp(14), ctx.dp(8), ctx.dp(14))
        val tint = if (danger) C.DANGER else C.TEXT
        row.addView(ctx.icon(iconRes, if (danger) C.DANGER else C.DIM, 22))
        row.add(ctx.text(label, 15f, tint, 1), MATCH, WRAP, 1f, 16, 0, 0, 0)
        row.background = ctx.ripple(null, 12f)
        row.isClickable = true
        row.setOnClickListener {
            dismiss()
            onClick()
        }
        content.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
        return this
    }

    fun add(v: View, topDp: Int = 0): Sheet {
        content.add(v, MATCH, WRAP, 0f, 0, topDp, 0, 0)
        return this
    }

    fun show(): Sheet {
        dialog.show()
        return this
    }

    fun dismiss() {
        try {
            dialog.dismiss()
        } catch (_: Throwable) {
        }
    }
}

fun confirmSheet(ctx: Context, title: String, message: String, positive: String, danger: Boolean, onYes: () -> Unit) {
    val s = Sheet(ctx, title)
    s.add(ctx.text(message, 14f, C.DIM))
    val row = ctx.hbox()
    row.add(ctx.button("Cancel", 0, BTN_GHOST) { s.dismiss() }, 0, WRAP, 1f, 0, 0, 8, 0)
    row.add(ctx.button(positive, 0, if (danger) BTN_DANGER else BTN_PRIMARY) {
        s.dismiss()
        onYes()
    }, 0, WRAP, 1f, 8, 0, 0, 0)
    s.add(row, 20)
    s.show()
}

fun promptSheet(ctx: Context, title: String, hint: String, initial: String, multiline: Boolean, onOk: (String) -> Unit) {
    val s = Sheet(ctx, title)
    val et = ctx.input(hint, initial, multiline)
    s.add(et)
    val row = ctx.hbox()
    row.add(ctx.button("Cancel", 0, BTN_GHOST) { s.dismiss() }, 0, WRAP, 1f, 0, 0, 8, 0)
    row.add(ctx.button("Save", 0, BTN_PRIMARY) {
        s.dismiss()
        onOk(et.text.toString())
    }, 0, WRAP, 1f, 8, 0, 0, 0)
    s.add(row, 16)
    s.dialog.window?.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
    s.show()
}

/** A card of settings rows with consistent spacing. */
class SettingsCard(private val ctx: Context) {
    val view: LinearLayout = ctx.vbox()
    private var count = 0

    init {
        view.background = ctx.shape(C.SURFACE, 18f, C.OUTLINE, 1f)
    }

    private fun addRow(v: View) {
        if (count > 0) {
            val d = View(ctx)
            d.setBackgroundColor(0x1AFFFFFF)
            view.add(d, MATCH, 1, 0f, 16, 0, 16, 0)
        }
        view.addView(v, LinearLayout.LayoutParams(MATCH, WRAP))
        count++
    }

    private fun titleBlock(title: String, subtitle: String?): LinearLayout {
        val col = ctx.vbox()
        col.addView(ctx.text(title, 15f, C.TEXT, 1))
        if (!subtitle.isNullOrEmpty()) col.add(ctx.text(subtitle, 12.5f, C.DIM), MATCH, WRAP, 0f, 0, 3, 0, 0)
        return col
    }

    fun toggle(title: String, subtitle: String?, value: Boolean, onChange: (Boolean) -> Unit): SettingsCard {
        val row = ctx.hbox()
        row.setPadding(ctx.dp(16), ctx.dp(14), ctx.dp(16), ctx.dp(14))
        row.add(titleBlock(title, subtitle), 0, WRAP, 1f, 0, 0, 12, 0)
        val sw = Switch(ctx)
        sw.isChecked = value
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.thumbTintList = ColorStateList(states, intArrayOf(C.MINT, C.DIM))
        sw.trackTintList = ColorStateList(states, intArrayOf(0x665BE3C4, C.OUTLINE))
        sw.setOnCheckedChangeListener { _, checked -> onChange(checked) }
        row.addView(sw)
        row.setOnClickListener { sw.toggle() }
        row.background = ctx.ripple(null, 0f, 0x14FFFFFF)
        addRow(row)
        return this
    }

    fun choice(title: String, options: List<String>, selected: Int, subtitle: String? = null, onChange: (Int) -> Unit): SettingsCard {
        val col = ctx.vbox()
        col.setPadding(ctx.dp(16), ctx.dp(14), ctx.dp(16), ctx.dp(14))
        col.addView(titleBlock(title, subtitle))
        val hs = android.widget.HorizontalScrollView(ctx)
        hs.isHorizontalScrollBarEnabled = false
        val chips = ctx.hbox()
        hs.addView(chips, FrameLayout.LayoutParams(WRAP, WRAP))
        fun render(sel: Int) {
            chips.removeAllViews()
            options.forEachIndexed { i, label ->
                chips.add(ctx.chip(label, i == sel) {
                    render(i)
                    onChange(i)
                }, WRAP, WRAP, 0f, 0, 0, 8, 0)
            }
        }
        render(selected)
        col.add(hs, MATCH, WRAP, 0f, 0, 10, 0, 0)
        addRow(col)
        return this
    }

    fun slider(title: String, min: Int, max: Int, step: Int, value: Int, fmt: (Int) -> String, onChange: (Int) -> Unit): SettingsCard {
        val col = ctx.vbox()
        col.setPadding(ctx.dp(16), ctx.dp(14), ctx.dp(16), ctx.dp(8))
        val head = ctx.hbox()
        head.add(ctx.text(title, 15f, C.TEXT, 1), 0, WRAP, 1f)
        val valueText = ctx.text(fmt(value), 13.5f, C.MINT, 1)
        head.addView(valueText)
        col.addView(head)
        val sb = SeekBar(ctx)
        sb.max = ((max - min) / step).coerceAtLeast(1)
        sb.progress = ((value - min) / step).coerceIn(0, sb.max)
        sb.progressTintList = ColorStateList.valueOf(C.MINT)
        sb.thumbTintList = ColorStateList.valueOf(C.MINT)
        sb.progressBackgroundTintList = ColorStateList.valueOf(C.OUTLINE)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                valueText.text = fmt(min + p * step)
            }

            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {
                onChange(min + s.progress * step)
            }
        })
        col.add(sb, MATCH, WRAP, 0f, 0, 6, 0, 0)
        addRow(col)
        return this
    }

    fun action(title: String, subtitle: String?, iconRes: Int, danger: Boolean = false, onClick: () -> Unit): SettingsCard {
        val row = ctx.hbox()
        row.setPadding(ctx.dp(16), ctx.dp(14), ctx.dp(16), ctx.dp(14))
        if (iconRes != 0) row.add(ctx.icon(iconRes, if (danger) C.DANGER else C.MINT, 22), ctx.dp(22), ctx.dp(22), 0f, 0, 0, 14, 0)
        val tb = ctx.vbox()
        tb.addView(ctx.text(title, 15f, if (danger) C.DANGER else C.TEXT, 1))
        if (!subtitle.isNullOrEmpty()) tb.add(ctx.text(subtitle, 12.5f, C.DIM), MATCH, WRAP, 0f, 0, 3, 0, 0)
        row.add(tb, 0, WRAP, 1f)
        row.addView(ctx.icon(R.drawable.ic_chevron_right, C.FAINT, 20))
        row.background = ctx.ripple(null, 0f, 0x14FFFFFF)
        row.isClickable = true
        row.setOnClickListener { onClick() }
        addRow(row)
        return this
    }

    fun info(title: String, value: String, valueColor: Int = C.DIM): SettingsCard {
        val row = ctx.hbox()
        row.setPadding(ctx.dp(16), ctx.dp(13), ctx.dp(16), ctx.dp(13))
        row.add(ctx.text(title, 14f, C.TEXT, 1), WRAP, WRAP, 0f, 0, 0, 16, 0)
        val v = ctx.text(value, 13.5f, valueColor)
        v.gravity = Gravity.END
        row.add(v, 0, WRAP, 1f)
        addRow(row)
        return this
    }

    fun note(textValue: String, color: Int = C.DIM): SettingsCard {
        val t = ctx.text(textValue, 12.5f, color)
        t.setLineSpacing(0f, 1.15f)
        t.setPadding(ctx.dp(16), ctx.dp(13), ctx.dp(16), ctx.dp(13))
        addRow(t)
        return this
    }

    fun custom(v: View): SettingsCard {
        addRow(v)
        return this
    }
}

/** Mint-to-peach sweep: indeterminate (progress < 0) or determinate progress bar. */
class SweepBar(ctx: Context) : View(ctx) {
    var progress: Float = -1f
        set(v) {
            field = v
            invalidate()
        }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val track = Paint(Paint.ANTI_ALIAS_FLAG)
    private var phase = 0f
    private var anim: ValueAnimator? = null

    init {
        track.color = C.SURFACE3
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 1300
        a.repeatCount = ValueAnimator.INFINITE
        a.interpolator = DecelerateInterpolator(1.2f)
        a.addUpdateListener {
            phase = it.animatedValue as Float
            invalidate()
        }
        a.start()
        anim = a
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        anim = null
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = h / 2f
        c.drawRoundRect(RectF(0f, 0f, w, h), r, r, track)
        val len: Float
        val start: Float
        if (progress < 0f) {
            len = w * 0.35f
            start = -len + (w + len) * phase
        } else {
            len = w * progress.coerceIn(0f, 1f)
            start = 0f
        }
        paint.shader = LinearGradient(start, 0f, start + len.coerceAtLeast(1f), 0f, C.MINT, C.PEACH, Shader.TileMode.CLAMP)
        c.save()
        c.clipRect(0f, 0f, w, h)
        c.drawRoundRect(RectF(start, 0f, start + len, h), r, r, paint)
        c.restore()
    }
}
