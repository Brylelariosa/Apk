package dev.splice.player.data

import dev.splice.player.core.Files
import dev.splice.player.model.Format
import org.json.JSONObject
import java.io.File
import java.util.Locale

/** Recognises RPG Maker XP / VX / VX Ace (RGSS) and MV / MZ (web) game folders. */
object Detector {
    class Result(
        val format: Format,
        val root: File,
        val webRoot: File?,
        val title: String,
        val tags: Set<String>,
        val execName: String?
    )

    private val SKIP = setOf(
        "graphics", "audio", "data", "js", "img", "movies", "fonts", "node_modules", ".git", "save",
        "pbs", "plugins", "locales", "icon", "www", "lib", "tilesets", "backup", "backups"
    )

    fun child(dir: File, name: String): File? {
        val direct = File(dir, name)
        if (direct.exists()) return direct
        val list = dir.listFiles() ?: return null
        for (f in list) if (f.name.equals(name, ignoreCase = true)) return f
        return null
    }

    fun childPath(dir: File, vararg parts: String): File? {
        var cur: File = dir
        for (p in parts) cur = child(cur, p) ?: return null
        return cur
    }

    fun detect(dir: File): Result? {
        if (!dir.isDirectory) return null
        detectWeb(dir)?.let { return it }
        return detectRgss(dir)
    }

    /** Looks for games in [root] and up to [maxDepth] levels below it. */
    fun scan(root: File, maxDepth: Int = 3, limitDirs: Int = 3000): List<Result> {
        val found = ArrayList<Result>()
        val queue = ArrayDeque<Pair<File, Int>>()
        queue.add(Pair(root, 0))
        var visited = 0
        while (queue.isNotEmpty() && visited < limitDirs) {
            val (dir, depth) = queue.removeFirst()
            visited++
            val r = detect(dir)
            if (r != null) {
                found.add(r)
                continue
            }
            if (depth >= maxDepth) continue
            val kids = dir.listFiles() ?: continue
            for (k in kids.sortedBy { it.name.lowercase(Locale.ROOT) }) {
                if (!k.isDirectory || k.name.startsWith(".")) continue
                if (SKIP.contains(k.name.lowercase(Locale.ROOT))) continue
                queue.add(Pair(k, depth + 1))
            }
        }
        return found
    }

    private fun cleanName(n: String): String = n.replace('_', ' ').replace('-', ' ').trim()

    private fun detectWeb(dir: File): Result? {
        val candidates = ArrayList<File>()
        candidates.add(dir)
        child(dir, "www")?.takeIf { it.isDirectory }?.let { candidates.add(it) }
        for (cand in candidates) {
            val index = child(cand, "index.html") ?: continue
            val js = child(cand, "js") ?: continue
            val mz = child(js, "rmmz_core.js") != null || child(js, "rmmz_managers.js") != null
            val mv = child(js, "rpg_core.js") != null || child(js, "rpg_managers.js") != null
            if (!mz && !mv) continue
            var title: String? = null
            try {
                val sys = childPath(cand, "data", "System.json")
                if (sys != null) title = JSONObject(Files.readTextSmart(sys)).optString("gameTitle").trim()
            } catch (_: Throwable) {
            }
            if (title.isNullOrEmpty()) {
                try {
                    val pj = child(dir, "package.json") ?: child(cand, "package.json")
                    if (pj != null) {
                        val o = JSONObject(Files.readTextSmart(pj))
                        title = o.optJSONObject("window")?.optString("title")?.trim()
                        if (title.isNullOrEmpty()) title = o.optString("name").trim()
                    }
                } catch (_: Throwable) {
                }
            }
            if (title.isNullOrEmpty()) title = cleanName(dir.name)
            return Result(if (mz) Format.MZ else Format.MV, dir, cand, title, tagsFor(dir, title), null)
        }
        return null
    }

    private fun detectRgss(dir: File): Result? {
        val files = dir.listFiles() ?: return null
        var ini: File? = null
        var archive: File? = null
        for (f in files) {
            val n = f.name.lowercase(Locale.ROOT)
            if (n == "game.ini") ini = f
            else if (ini == null && n.endsWith(".ini") && f.isFile && n != "desktop.ini") ini = f
            if (n.endsWith(".rgssad") || n.endsWith(".rgss2a") || n.endsWith(".rgss3a")) archive = f
        }
        var title: String? = null
        var version = 0
        if (ini != null) {
            try {
                for (raw in Files.readTextSmart(ini).lines()) {
                    val idx = raw.indexOf('=')
                    if (idx <= 0) continue
                    val key = raw.substring(0, idx).trim().lowercase(Locale.ROOT)
                    val value = raw.substring(idx + 1).trim()
                    when (key) {
                        "title" -> if (title == null) title = value
                        "scripts" -> {
                            val v = value.lowercase(Locale.ROOT)
                            if (v.endsWith("rvdata2")) version = 3
                            else if (v.endsWith("rvdata")) version = 2
                            else if (v.endsWith("rxdata")) version = 1
                        }
                        "library" -> if (version == 0) {
                            val m = Regex("rgss(\\d)").find(value.lowercase(Locale.ROOT))
                            if (m != null) version = m.groupValues[1].toInt()
                        }
                    }
                }
            } catch (_: Throwable) {
            }
        }
        if (version == 0) {
            val data = child(dir, "Data")
            if (data != null) {
                version = when {
                    child(data, "Scripts.rvdata2") != null -> 3
                    child(data, "Scripts.rvdata") != null -> 2
                    child(data, "Scripts.rxdata") != null -> 1
                    else -> 0
                }
            }
        }
        if (version == 0 && archive != null) {
            val n = archive.name.lowercase(Locale.ROOT)
            version = if (n.endsWith(".rgss3a")) 3 else if (n.endsWith(".rgss2a")) 2 else 1
        }
        if (version !in 1..3) return null
        val fmt = when (version) {
            3 -> Format.ACE
            2 -> Format.VX
            else -> Format.XP
        }
        if (title.isNullOrEmpty()) title = cleanName(dir.name)
        val exec = archive?.nameWithoutExtension
        return Result(fmt, dir, null, title, tagsFor(dir, title), exec)
    }

    /** Heuristic "Pokémon Essentials" detection (PBS folder or compiled .dat data). */
    private fun tagsFor(dir: File, title: String): Set<String> {
        val tags = linkedSetOf<String>()
        try {
            val pbs = child(dir, "PBS")
            if (pbs != null) {
                for (n in listOf("pokemon.txt", "moves.txt", "items.txt", "types.txt", "pokemon_forms.txt", "pokemonforms.txt")) {
                    if (child(pbs, n) != null) {
                        tags.add("pokemon")
                        break
                    }
                }
            }
            if (!tags.contains("pokemon")) {
                val data = child(dir, "Data")
                if (data != null) {
                    for (n in listOf("species.dat", "moves.dat", "types.dat", "PkmnAnimations.rxdata", "tm.dat")) {
                        if (child(data, n) != null) {
                            tags.add("pokemon")
                            break
                        }
                    }
                }
            }
            val t = title.lowercase(Locale.ROOT)
            if (t.contains("pokémon") || t.contains("pokemon") || t.contains("pkmn")) tags.add("pokemon")
        } catch (_: Throwable) {
        }
        return tags
    }
}
