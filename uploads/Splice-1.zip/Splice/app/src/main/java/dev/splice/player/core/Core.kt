package dev.splice.player.core

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/** Tiny background/UI executor helpers. */
object Bg {
    val io: ExecutorService = Executors.newFixedThreadPool(3)
    private val main = Handler(Looper.getMainLooper())

    fun ui(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) block() else main.post { block() }
    }

    fun postDelayed(ms: Long, block: () -> Unit) {
        main.postDelayed({ block() }, ms)
    }
}

/** All on-disk locations used by the app. */
object Paths {
    lateinit var root: File
        private set
    lateinit var games: File
        private set
    lateinit var covers: File
        private set
    lateinit var logs: File
        private set
    lateinit var sessions: File
        private set
    lateinit var saves: File
        private set
    lateinit var backups: File
        private set
    lateinit var slots: File
        private set
    lateinit var rgss: File
        private set
    lateinit var profiles: File
        private set
    lateinit var tmp: File
        private set

    fun init(ctx: Context) {
        val base = File(ctx.filesDir, "splice")
        val ext: File? = try {
            ctx.getExternalFilesDir(null)
        } catch (t: Throwable) {
            null
        }
        root = base
        covers = File(base, "covers")
        logs = File(base, "logs")
        sessions = File(base, "logs/sessions")
        saves = File(base, "saves")
        backups = File(base, "backups")
        slots = File(base, "slots")
        rgss = File(base, "rgss")
        profiles = File(base, "profiles")
        tmp = File(base, "tmp")
        games = File(ext ?: ctx.filesDir, "games")
        for (d in listOf(base, games, covers, logs, sessions, saves, backups, slots, rgss, profiles, tmp)) {
            d.mkdirs()
        }
    }

    fun saveDir(gameId: String): File = File(saves, gameId).also { it.mkdirs() }
    fun backupDir(gameId: String): File = File(backups, gameId).also { it.mkdirs() }
    fun slotDir(gameId: String): File = File(slots, gameId).also { it.mkdirs() }
    fun sessionDir(gameId: String): File = File(sessions, gameId).also { it.mkdirs() }
    fun newSessionLog(gameId: String): File = File(sessionDir(gameId), Fmt.stamp() + ".log")
    fun isInsideApp(ctx: Context, f: File): Boolean {
        val p = f.absolutePath
        return p.startsWith(ctx.filesDir.absolutePath) ||
            (ctx.getExternalFilesDir(null)?.let { p.startsWith(it.absolutePath) } ?: false)
    }
}

/** Small rotating file logger shared by both app processes. */
object AppLog {
    private var file: File? = null
    private var proc = "main"
    private val sdf = SimpleDateFormat("MM-dd HH:mm:ss.SSS", Locale.US)

    fun init(dir: File, process: String) {
        proc = process
        dir.mkdirs()
        val f = File(dir, "app.log")
        if (process == "main" && f.exists() && f.length() > 768 * 1024) {
            File(dir, "app.log.1").delete()
            f.renameTo(File(dir, "app.log.1"))
        }
        file = f
    }

    fun d(tag: String, msg: String) = emit('D', tag, msg, null)
    fun i(tag: String, msg: String) = emit('I', tag, msg, null)
    fun w(tag: String, msg: String, t: Throwable? = null) = emit('W', tag, msg, t)
    fun e(tag: String, msg: String, t: Throwable? = null) = emit('E', tag, msg, t)

    @Synchronized
    private fun emit(level: Char, tag: String, msg: String, t: Throwable?) {
        val prio = when (level) {
            'D' -> Log.DEBUG
            'W' -> Log.WARN
            'E' -> Log.ERROR
            else -> Log.INFO
        }
        Log.println(prio, "Splice/$tag", msg)
        if (t != null) Log.println(prio, "Splice/$tag", Log.getStackTraceString(t))
        val f = file ?: return
        try {
            val sb = StringBuilder()
            sb.append(sdf.format(Date())).append(' ').append(level).append(' ')
                .append('[').append(proc).append("] ").append(tag).append(": ").append(msg).append('\n')
            if (t != null) sb.append(Log.getStackTraceString(t)).append('\n')
            FileOutputStream(f, true).use { it.write(sb.toString().toByteArray()) }
        } catch (_: Throwable) {
        }
    }

    fun tail(maxBytes: Int = 200_000): String {
        val f = file ?: return ""
        return try {
            Files.tail(f, maxBytes)
        } catch (t: Throwable) {
            ""
        }
    }
}

object Files {
    /** Reads at most [maxBytes] from the end of [f]; drops a possibly cut first line. */
    fun tail(f: File, maxBytes: Int): String {
        if (!f.exists()) return ""
        java.io.RandomAccessFile(f, "r").use { raf ->
            val len = raf.length()
            val start = if (len > maxBytes) len - maxBytes else 0L
            raf.seek(start)
            val buf = ByteArray((len - start).toInt())
            raf.readFully(buf)
            var s = String(buf, Charsets.UTF_8)
            if (start > 0) {
                val nl = s.indexOf('\n')
                if (nl >= 0) s = s.substring(nl + 1)
            }
            return s
        }
    }

    /** UTF-8 text if valid, otherwise Latin-1 (old Windows-made INI/JSON files). */
    fun readTextSmart(f: File): String {
        val b = f.readBytes()
        var start = 0
        if (b.size >= 3 && b[0] == 0xEF.toByte() && b[1] == 0xBB.toByte() && b[2] == 0xBF.toByte()) start = 3
        val s = String(b, start, b.size - start, Charsets.UTF_8)
        return if (s.indexOf('\uFFFD') >= 0) String(b, start, b.size - start, Charsets.ISO_8859_1) else s
    }

    fun dirSize(f: File, limitFiles: Int = 200_000): Long {
        var total = 0L
        var count = 0
        val stack = ArrayDeque<File>()
        stack.add(f)
        while (stack.isNotEmpty() && count < limitFiles) {
            val cur = stack.removeLast()
            val list = cur.listFiles() ?: continue
            for (c in list) {
                count++
                if (c.isDirectory) stack.add(c) else total += c.length()
            }
        }
        return total
    }

    fun deleteRecursive(f: File) {
        if (f.isDirectory) f.listFiles()?.forEach { deleteRecursive(it) }
        f.delete()
    }

    fun copyRecursive(src: File, dst: File) {
        if (src.isDirectory) {
            dst.mkdirs()
            src.listFiles()?.forEach { copyRecursive(it, File(dst, it.name)) }
        } else {
            dst.parentFile?.mkdirs()
            src.inputStream().use { i -> dst.outputStream().use { o -> i.copyTo(o, 64 * 1024) } }
            dst.setLastModified(src.lastModified())
        }
    }
}

/** JNI helpers: crash backtraces and stdout/stderr capture. Safe if the library is missing. */
object Native {
    @Volatile
    var loaded = false
        private set

    init {
        loaded = try {
            System.loadLibrary("fgcore")
            true
        } catch (t: Throwable) {
            false
        }
    }

    @JvmStatic
    fun abi(): String {
        if (loaded) {
            try {
                return nAbi()
            } catch (t: Throwable) {
            }
        }
        return Build.SUPPORTED_ABIS.firstOrNull() ?: "unknown"
    }

    @JvmStatic
    fun installCrashHandler(path: String): Boolean {
        if (!loaded) return false
        return try {
            nInstallCrashHandler(path)
        } catch (t: Throwable) {
            false
        }
    }

    @JvmStatic
    fun redirectStdio(path: String): Boolean {
        if (!loaded) return false
        return try {
            nRedirectStdio(path)
        } catch (t: Throwable) {
            false
        }
    }

    @JvmStatic
    private external fun nAbi(): String

    @JvmStatic
    private external fun nInstallCrashHandler(path: String): Boolean

    @JvmStatic
    private external fun nRedirectStdio(path: String): Boolean
}

object Prefs {
    private lateinit var sp: SharedPreferences

    fun init(ctx: Context) {
        sp = ctx.getSharedPreferences("splice", Context.MODE_PRIVATE)
    }

    var sort: Int
        get() = sp.getInt("sort", 0)
        set(v) {
            sp.edit().putInt("sort", v).apply()
        }

    var filter: String
        get() = sp.getString("filter", "all") ?: "all"
        set(v) {
            sp.edit().putString("filter", v).apply()
        }

    var autoBackup: Boolean
        get() = sp.getBoolean("autoBackup", true)
        set(v) {
            sp.edit().putBoolean("autoBackup", v).apply()
        }

    var backupKeep: Int
        get() = sp.getInt("backupKeep", 5)
        set(v) {
            sp.edit().putInt("backupKeep", v).apply()
        }

    var defaultProfile: String
        get() = sp.getString("defaultProfile", "") ?: ""
        set(v) {
            sp.edit().putString("defaultProfile", v).apply()
        }

    var seenCrash: Long
        get() = sp.getLong("seenCrash", 0L)
        set(v) {
            sp.edit().putLong("seenCrash", v).apply()
        }
}

object Fmt {
    fun size(b: Long): String {
        if (b < 1024) return "$b B"
        val units = arrayOf("KB", "MB", "GB", "TB")
        var v = b.toDouble()
        var i = -1
        while (v >= 1024 && i < units.size - 1) {
            v /= 1024
            i++
        }
        return if (v >= 100) String.format(Locale.US, "%.0f %s", v, units[i])
        else String.format(Locale.US, "%.1f %s", v, units[i])
    }

    fun ago(ts: Long): String {
        if (ts <= 0) return "Never"
        val d = System.currentTimeMillis() - ts
        val min = d / 60000
        return when {
            min < 1 -> "Just now"
            min < 60 -> "$min min ago"
            min < 60 * 24 -> "${min / 60} h ago"
            min < 60 * 24 * 30 -> "${min / (60 * 24)} d ago"
            else -> date(ts)
        }
    }

    fun duration(ms: Long): String {
        val m = ms / 60000
        if (m < 1) return "under 1 min"
        val h = m / 60
        return if (h > 0) "${h}h ${m % 60}m" else "${m}m"
    }

    fun stamp(ts: Long = System.currentTimeMillis()): String =
        SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date(ts))

    fun date(ts: Long): String = SimpleDateFormat("MMM d, yyyy HH:mm", Locale.getDefault()).format(Date(ts))
}
