package com.novaenhance.ai.workers

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.novaenhance.ai.MainActivity
import com.novaenhance.ai.R
import com.novaenhance.ai.database.entities.TrainingStatus
import com.novaenhance.ai.di.ServiceLocator
import com.novaenhance.ai.training.trainer.TrainingPhase
import com.novaenhance.ai.training.trainer.TrainingProgressState
import com.novaenhance.ai.training.trainer.overallFraction
import com.novaenhance.ai.utils.Constants
import com.novaenhance.ai.utils.NovaLog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.launch

private const val TAG = "TrainingForegroundService"

private const val ACTION_START = "com.novaenhance.ai.action.START_TRAINING"
private const val ACTION_PAUSE = "com.novaenhance.ai.action.PAUSE_TRAINING"
private const val ACTION_RESUME = "com.novaenhance.ai.action.RESUME_TRAINING"
private const val ACTION_CANCEL = "com.novaenhance.ai.action.CANCEL_TRAINING"
private const val EXTRA_MODEL_ID = "modelId"
private const val EXTRA_RESUME_SESSION_ID = "resumeSessionId"

/**
 * Runs one [com.novaenhance.ai.training.trainer.SelfImprovementOrchestrator]
 * cycle as a foreground service so a long training run survives the app
 * being backgrounded. There is deliberately only ever one training session
 * system-wide (mirrors [com.novaenhance.ai.ai.model.ModelRepository] only
 * ever holding one loaded engine) - [control] (via [ServiceLocator]) is a
 * single shared instance both this service and the Train AI screen's
 * ViewModel read/write.
 */
class TrainingForegroundService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var trainingJob: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val locator = ServiceLocator.get(applicationContext)
        when (intent?.action) {
            ACTION_PAUSE -> locator.trainingControlFlow.pause()
            ACTION_RESUME -> locator.trainingControlFlow.resume()
            ACTION_CANCEL -> {
                locator.trainingControlFlow.cancel()
                stopSelf()
            }
            ACTION_START, null -> {
                val modelId = intent?.getStringExtra(EXTRA_MODEL_ID)
                if (modelId == null) {
                    stopSelf()
                } else {
                    val resumeSessionId = intent.getLongExtra(EXTRA_RESUME_SESSION_ID, -1L).takeIf { it >= 0 }
                    startForeground(Constants.TRAINING_NOTIFICATION_ID, buildNotification(null))
                    startTraining(modelId, resumeSessionId)
                }
            }
        }
        return START_NOT_STICKY // crash recovery is handled explicitly via ModelTrainer.findRecoverableSession(), not sticky restart
    }

    private fun startTraining(modelId: String, resumeSessionId: Long?) {
        if (trainingJob?.isActive == true) return
        val locator = ServiceLocator.get(applicationContext)

        trainingJob = scope.launch {
            val progressJob = launch {
                locator.trainingProgressPublisher.progress.filterNotNull().collect { state -> updateNotification(state) }
            }
            var finalStatus: TrainingStatus? = null
            try {
                val session = locator.selfImprovementOrchestrator.runCycle(modelId, resumeSessionId, locator.trainingControlFlow)
                finalStatus = session.status
                NovaLog.i(TAG, "Training session ${session.id} ended with status ${session.status}")
            } catch (t: Throwable) {
                NovaLog.w(TAG, "Training session failed", t)
                locator.modelTrainer.reportStartupFailure(t.message ?: "Training couldn't start (${t::class.simpleName})")
            } finally {
                progressJob.cancel()
                // Only PAUSED should leave the card showing where it left
                // off (Resume continues from there); every other exit -
                // completed, cancelled, or an exception before a session
                // even started - means there's truly nothing left running,
                // so the stale card shouldn't keep showing its last percentage
                // forever (nothing previously cleared this, so it used to).
                if (finalStatus != TrainingStatus.PAUSED) {
                    locator.trainingProgressPublisher.clear()
                }
                stopSelf()
            }
        }
    }

    override fun onDestroy() {
        trainingJob?.cancel()
        super.onDestroy()
    }

    private fun buildNotification(state: TrainingProgressState?): Notification {
        ensureChannel()

        val openAppIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val pauseIntent = PendingIntent.getService(
            this, 1, Intent(this, TrainingForegroundService::class.java).setAction(ACTION_PAUSE),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val cancelIntent = PendingIntent.getService(
            this, 2, Intent(this, TrainingForegroundService::class.java).setAction(ACTION_CANCEL),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val contentText = when {
            state == null -> getString(R.string.training_notification_starting)
            state.phase == TrainingPhase.TRAINING -> getString(
                R.string.training_notification_progress,
                state.epoch + 1, state.totalEpochs, state.phaseStepIndex + 1, state.phaseStepTotal
            )
            state.phase == TrainingPhase.SAVING_CHECKPOINT -> getString(R.string.training_notification_saving)
            state.phase == TrainingPhase.VALIDATING -> getString(
                R.string.training_notification_validating, state.phaseStepIndex, state.phaseStepTotal
            )
            else -> getString(R.string.training_notification_rescoring, state.phaseStepIndex, state.phaseStepTotal)
        }

        return NotificationCompat.Builder(this, Constants.NOTIFICATION_CHANNEL_TRAINING)
            .setSmallIcon(R.drawable.ic_training_notification)
            .setContentTitle(getString(R.string.training_notification_title))
            .setContentText(contentText)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openAppIntent)
            .setProgress(100, ((state?.overallFraction ?: 0f) * 100).toInt(), state == null)
            .addAction(0, getString(R.string.training_notification_pause), pauseIntent)
            .addAction(0, getString(R.string.training_notification_cancel), cancelIntent)
            .build()
    }

    private fun updateNotification(state: TrainingProgressState) {
        val hasPermission = Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        if (hasPermission) {
            NotificationManagerCompat.from(this).notify(Constants.TRAINING_NOTIFICATION_ID, buildNotification(state))
        }
    }

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                Constants.NOTIFICATION_CHANNEL_TRAINING,
                getString(R.string.training_notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    companion object {
        fun start(context: Context, modelId: String, resumeSessionId: Long? = null) {
            val intent = Intent(context, TrainingForegroundService::class.java)
                .setAction(ACTION_START)
                .putExtra(EXTRA_MODEL_ID, modelId)
            resumeSessionId?.let { intent.putExtra(EXTRA_RESUME_SESSION_ID, it) }
            ContextCompat.startForegroundService(context, intent)
        }

        fun pause(context: Context) {
            context.startService(Intent(context, TrainingForegroundService::class.java).setAction(ACTION_PAUSE))
        }

        fun resume(context: Context) {
            context.startService(Intent(context, TrainingForegroundService::class.java).setAction(ACTION_RESUME))
        }

        fun cancel(context: Context) {
            context.startService(Intent(context, TrainingForegroundService::class.java).setAction(ACTION_CANCEL))
        }
    }
}
