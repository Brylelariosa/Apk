"""Reference port of the Auto-enhance colour maths, OLD (build 12) vs NEW (build 13), on synthetic scenes.

It mirrors rust/src/enhance/{plan,tone}.rs in numpy so the design could be checked without a Rust toolchain: it reports,
per scene, the mean hue shift / saturation change of the colourful pixels and which techniques Auto would switch on.
It checks the MATHS, not the Rust code. Run: python3 tools/validate_color.py   (needs numpy)"""
import numpy as np

rng = np.random.default_rng(7)

def luma(r, g, b):
    return 0.299 * r + 0.587 * g + 0.114 * b

def smoothstep(e0, e1, x):
    t = np.clip((x - e0) / (e1 - e0), 0, 1)
    return t * t * (3 - 2 * t)

# ------------------------------------------------------------------ scenes (float RGB 0..255, H x W x 3)
H, W = 120, 160
yy, xx = np.mgrid[0:H, 0:W]

def noise(s=2.0):
    return rng.normal(0, s, (H, W, 1))

def scene_sunset():
    t = (yy / H)[..., None]
    top = np.array([90, 60, 120.0]); mid = np.array([240, 120, 40.0]); bot = np.array([40, 25, 20.0])
    img = np.where(t < 0.6, top + (mid - top) * (t / 0.6), mid + (bot - mid) * ((t - 0.6) / 0.4))
    return np.clip(img + noise(), 0, 255)

def scene_forest():
    base = np.array([55, 120, 45.0])
    img = base + rng.normal(0, 18, (H, W, 1)) * np.array([1.0, 1.0, 0.6])
    img[:25] = np.array([150, 190, 235.0])
    return np.clip(img, 0, 255)

def scene_sea():
    img = np.zeros((H, W, 3)) + np.array([30, 110, 170.0])
    img[:45] = np.array([185, 205, 225.0])
    img += noise()
    return np.clip(img, 0, 255)

def scene_portrait():
    img = np.zeros((H, W, 3)) + np.array([110, 112, 118.0])
    cy, cx = H / 2, W / 2
    face = ((yy - cy) / 42) ** 2 + ((xx - cx) / 32) ** 2 < 1
    img[face] = np.array([214, 160, 130.0])
    return np.clip(img + noise(), 0, 255)

def scene_tungsten():
    # neutral scene (white wall, grey objects) lit by a warm bulb
    wall = np.array([150, 150, 150.0]); obj = np.array([90, 90, 90.0]); white = np.array([200, 200, 200.0])
    img = np.zeros((H, W, 3)) + wall
    img[:, :40] = white
    img[70:, 60:120] = obj
    cast = np.array([1.35, 1.0, 0.68])
    return np.clip(img * cast + noise(), 0, 255)

def scene_balanced():
    t = (xx / W)[..., None]
    img = np.zeros((H, W, 3)) + np.array([120, 125, 118.0]) + 50 * (t - 0.5)
    img[80:] = np.array([60, 140, 70.0])
    img[:20, :50] = np.array([200, 60, 50.0])
    return np.clip(img + noise(), 0, 255)

SCENES = {
    'sunset': scene_sunset, 'forest': scene_forest, 'sea': scene_sea,
    'portrait': scene_portrait, 'tungsten(true cast)': scene_tungsten, 'balanced': scene_balanced,
}

# ------------------------------------------------------------------ analysis
def stats(img):
    r, g, b = img[..., 0], img[..., 1], img[..., 2]
    y8 = ((77 * np.round(r) + 150 * np.round(g) + 29 * np.round(b) + 128) // 256).astype(int)
    hist = np.bincount(y8.ravel(), minlength=256).astype(float)
    total = hist.sum()
    idx = np.arange(256) / 255.0
    mean = (idx * hist).sum() / total
    std = np.sqrt((((idx - mean) ** 2) * hist).sum() / total)
    def pbin(f):
        c = np.cumsum(hist); target = np.ceil(f * total)
        return int(np.searchsorted(c, target))
    mxv = np.round(img.max(-1)).astype(int)
    mh = np.bincount(mxv.ravel(), minlength=256).astype(float)
    cm = np.cumsum(mh)
    p_hi_v = int(np.searchsorted(cm, np.ceil(0.996 * mh.sum()))) / 255
    return dict(img=img, hist=hist, mean=mean, std=std, p_lo=pbin(0.004) / 255, p_hi=p_hi_v,
                med=pbin(0.5) / 255, dark=hist[:40].sum() / total, bright=hist[236:].sum() / total)

def sat_mean(img):
    mx = img.max(-1); mn = img.min(-1)
    m = mx > 10
    return float(((mx - mn)[m] / mx[m]).mean())

def wb_old(img):
    r, g, b = img[..., 0], img[..., 1], img[..., 2]
    y = luma(r, g, b); mx = img.max(-1)
    m = (y > 20) & (mx < 245)
    mr, mg, mb = r[m].mean(), g[m].mean(), b[m].mean()
    gray = (mr + mg + mb) / 3
    g3 = np.clip([gray / mr, gray / mg, gray / mb], 0.7, 1.43)
    k = 0.299 * g3[0] + 0.587 * g3[1] + 0.114 * g3[2]
    return g3 / k, max(mr, mg, mb) / min(mr, mg, mb), 1.0

def wb_new(img):
    r, g, b = img[..., 0], img[..., 1], img[..., 2]
    y = luma(r, g, b); mx = img.max(-1); mn = img.min(-1)
    s = np.where(mx > 10, (mx - mn) / np.maximum(mx, 1e-6), 0)
    usable = (y > 25) & (mx < 242)
    blue_dom = (b >= g) & (b > r * 1.04)
    neutral = usable & (s < 0.30) & ~blue_dom
    gcnt = usable.sum(); ncnt = neutral.sum()
    use_n = ncnt >= 30 and ncnt >= 0.04 * gcnt
    sel = neutral if use_n else usable
    mr, mg, mb = r[sel].mean(), g[sel].mean(), b[sel].mean()
    gray = (mr + mg + mb) / 3
    g3 = np.clip([gray / mr, gray / mg, gray / mb], 0.7, 1.43)
    k = 0.299 * g3[0] + 0.587 * g3[1] + 0.114 * g3[2]
    nfrac = ncnt / max(gcnt, 1)
    conf = float(np.clip((nfrac - 0.04) / 0.12, 0, 1)) if use_n else 0.0
    return g3 / k, max(mr, mg, mb) / min(mr, mg, mb), conf

# ------------------------------------------------------------------ auto decisions (colour related only)
def auto_old(st, img):
    a = dict(wb=0, levels=0, exposure=0, contrast=0, vib=0)
    _, cast, _ = wb_old(img)
    if cast > 1.10:
        a['wb'] = np.clip((cast - 1.06) / 0.25, 0, 0.85)
    span = st['p_hi'] - st['p_lo']
    if span < 0.85:
        a['levels'] = np.clip((0.92 - span) / 0.5, 0.2, 0.9)
    m = st['mean']
    if not m < 0.30 and abs(m - 0.45) > 0.08:
        a['exposure'] = np.clip((0.45 - m) * 2.0, -0.6, 0.6)
    if st['std'] < 0.17:
        a['contrast'] = np.clip((0.20 - st['std']) * 4.0, 0, 0.5)
    a['vib'] = 0.3 if sat_mean(img) < 0.30 else 0.15
    return a

def levels_window(amount, p_lo, p_hi):
    lo = min(p_lo * amount, 0.35)
    hi = 1 - min((1 - p_hi) * amount, 0.35)
    if hi - lo < 0.5:
        hi = lo + 0.5
    return lo, hi

def auto_new(st, img):
    a = dict(wb=0, levels=0, exposure=0, contrast=0, vib=0)
    _, cast, conf = wb_new(img)
    if conf > 0:
        rise = np.clip((cast - 1.05) / 0.08, 0, 1)
        fall = 1.0 - 0.7 * np.clip((cast - 1.20) / 0.20, 0, 1)
        a['wb'] = 0.6 * rise * fall * conf
    span = st['p_hi'] - st['p_lo']
    if span < 0.85:
        a['levels'] = np.clip((0.92 - span) / 0.5, 0.2, 0.7)
    key = 0.6 * st['med'] + 0.4 * st['mean']
    lo, hi = levels_window(a['levels'], st['p_lo'], st['p_hi'])
    if key >= 0.30:
        mid = np.clip((key - lo) / (hi - lo), 0.05, 0.95)
        target = np.clip(key, 0.38, 0.52)
        if abs(mid - target) > 0.04:
            g = np.log(target) / np.log(mid)
            a['exposure'] = float(np.clip(-np.log2(g) / 0.9, -0.35, 0.6))
    std_after = st['std'] / (hi - lo)
    if std_after < 0.17:
        a['contrast'] = float(np.clip((0.20 - std_after) * 4.0, 0, 0.4))
    sm = sat_mean(img)
    a['vib'] = 0.25 if sm < 0.20 else (0.12 if sm < 0.45 else 0.0)
    return a

# ------------------------------------------------------------------ tone LUT
def build_lut(a, p_lo, p_hi, n=1024):
    if not (a['levels'] > 0 or a['exposure'] != 0 or a['contrast'] != 0):
        return None
    lo = min(p_lo * a['levels'], 0.35)
    hi = 1 - min((1 - p_hi) * a['levels'], 0.35)
    span = max(hi - lo, 0.5)
    gamma = 2.0 ** (-a['exposure'] * 0.9)
    k = np.clip(a['contrast'], -0.9, 0.9)
    x = np.arange(n) / (n - 1)
    x1 = np.clip((x - lo) / span, 0, 1)
    x2 = x1 ** gamma
    x3 = x2 - k * np.sin(2 * np.pi * x2) / (2 * np.pi)
    return np.clip(x3, 0, 1) * 255

def lut_eval(lut, v):
    return np.interp(np.clip(v, 0, 255), np.linspace(0, 255, len(lut)), lut)

def retarget_luma(r, g, b, y, y2):
    mx = np.maximum(np.maximum(r, g), b)
    s = np.minimum(np.minimum(y2 / np.maximum(y, 1e-6), 255.0 / np.maximum(mx, 1.0)), 4.0)
    rs, gs, bs, ys = r * s, g * s, b * s, y * s
    t = np.where(y2 > ys + 0.01, np.clip((y2 - ys) / np.maximum(255.0 - ys, 1e-6), 0, 1), 0.0)
    out = [c + (255.0 - c) * t for c in (rs, gs, bs)]
    dark = y < 1.0
    d = y2 - y
    out = [np.where(dark, c0 + d, c1) for c0, c1 in zip((r, g, b), out)]
    return out

def skin_weight(r, g, b):
    mx = np.maximum(np.maximum(r, g), b); mn = np.minimum(np.minimum(r, g), b)
    s = np.where(mx > 1, (mx - mn) / np.maximum(mx, 1), 0)
    ok = (r >= mx) & (g >= b) & ((mx - mn) >= 8)
    hue = (g - b) / np.maximum(mx - mn, 1e-6)
    hw = smoothstep(0.05, 0.2, hue) * (1 - smoothstep(0.55, 0.8, hue))
    sw = smoothstep(0.12, 0.25, s) * (1 - smoothstep(0.55, 0.75, s))
    return np.where(ok, hw * sw, 0.0)

# ------------------------------------------------------------------ pipelines
def run_old(img, sat=0.2):
    st = stats(img); a = auto_old(st, img)
    out = img.copy()
    if a['wb'] > 0:
        gains, cast, _ = wb_old(img)
        gg = gains ** a['wb']; gg /= (0.299 * gg[0] + 0.587 * gg[1] + 0.114 * gg[2])
        out = out * gg
    lut = build_lut(a, st['p_lo'], st['p_hi'])
    if lut is not None:
        out = lut_eval(lut, out)  # per channel
    y = luma(out[..., 0], out[..., 1], out[..., 2])
    mx = out.max(-1); mn = out.min(-1)
    s = np.where(mx > 1, np.clip((mx - mn) / np.maximum(mx, 1), 0, 1), 0)
    f = (1 + sat + a['vib'] * (1 - s) * 0.9)[..., None]
    out = y[..., None] + (out - y[..., None]) * f
    return np.clip(out, 0, 255), a

def run_new(img, sat=0.2):
    st = stats(img); a = auto_new(st, img)
    out = img.copy()
    if a['wb'] > 0:
        gains, cast, conf = wb_new(img)
        gg = gains ** a['wb']; gg /= (0.299 * gg[0] + 0.587 * gg[1] + 0.114 * gg[2])
        out = out * gg
    lut = build_lut(a, st['p_lo'], st['p_hi'])
    if lut is not None:
        out = np.clip(out, 0, 255)
        r, g, b = out[..., 0], out[..., 1], out[..., 2]
        y = luma(r, g, b); y2 = lut_eval(lut, y)
        out = np.stack(retarget_luma(r, g, b, y, y2), -1)
    r, g, b = out[..., 0], out[..., 1], out[..., 2]
    y = luma(r, g, b)
    mx = out.max(-1); mn = out.min(-1)
    s = np.where(mx > 1, np.clip((mx - mn) / np.maximum(mx, 1), 0, 1), 0)
    skin = skin_weight(r, g, b)
    f = 1 + sat * (1 - 0.5 * s) + a['vib'] * (1 - s) ** 2 * 0.9 * (1 - 0.6 * skin)
    lim = np.full_like(f, 1e9)
    for c in (r, g, b):
        d = c - y
        lim = np.where(d > 1e-3, np.minimum(lim, (255 - y) / np.maximum(d, 1e-3)), lim)
        lim = np.where(d < -1e-3, np.minimum(lim, y / np.maximum(-d, 1e-3)), lim)
    f = np.where(f > lim, np.maximum(lim, 1.0), f)
    out = y[..., None] + (out - y[..., None]) * f[..., None]
    return np.clip(out, 0, 255), a

# ------------------------------------------------------------------ metrics
def hsv(img):
    mx = img.max(-1); mn = img.min(-1); d = mx - mn
    r, g, b = img[..., 0], img[..., 1], img[..., 2]
    h = np.zeros_like(mx)
    m = d > 1e-6
    rm = m & (mx == r); gm = m & (mx == g) & ~rm; bm = m & ~rm & ~gm
    h[rm] = (60 * ((g - b)[rm] / d[rm])) % 360
    h[gm] = 60 * ((b - r)[gm] / d[gm]) + 120
    h[bm] = 60 * ((r - g)[bm] / d[bm]) + 240
    s = np.where(mx > 0, d / np.maximum(mx, 1e-6), 0)
    return h, s, mx

def report(name, img, out, a):
    h0, s0, v0 = hsv(img); h1, s1, v1 = hsv(out)
    m = (s0 > 0.25) & (v0 > 40)
    dh = np.abs((h1 - h0 + 180) % 360 - 180)[m]
    cr = (s1[m] / np.maximum(s0[m], 1e-6))
    mean_in = img.reshape(-1, 3).mean(0); mean_out = out.reshape(-1, 3).mean(0)
    clipped = (((out >= 254.5).any(-1)) & ~((img >= 254.5).any(-1))).mean() * 100
    dl = (luma(out[..., 0], out[..., 1], out[..., 2]) - luma(img[..., 0], img[..., 1], img[..., 2])).mean()
    wb = a['wb']
    print(f"  hue shift {dh.mean() if m.any() else 0:5.1f} deg | sat x{cr.mean() if m.any() else 1:4.2f} | "
          f"newly-at-255 {clipped:4.1f}% | dLuma {dl:+5.1f} | wb {wb:4.2f} lev {a['levels']:4.2f} exp {a['exposure']:+5.2f} con {a['contrast']:4.2f} vib {a['vib']:4.2f} | "
          f"mean RGB {mean_in.round(0)} -> {mean_out.round(0)}")

if __name__ == '__main__':
    for name, fn in SCENES.items():
        img = fn()
        print(name)
        o, a = run_old(img); print('  OLD', end=''); report(name, img, o, a)
        n, a = run_new(img); print('  NEW', end=''); report(name, img, n, a)
