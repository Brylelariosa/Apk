package com.novaenhance.ai.ai.engine

/**
 * Everything the Enhance Image screen can ask for. Values are 0f..1f (0 = off) except [upscaleFactor], which is a
 * discrete multiplier, and the signed controls [exposure], [contrast] and [vignette] (-1f..1f, 0 = unchanged).
 *
 * The first five are the original sliders. The rest are the photo-enhancement techniques of the Rust pipeline; all
 * of them default to OFF, so existing behaviour is unchanged until the user asks for more. With [autoEnhance] on,
 * the scene analysis switches on whichever techniques the photo needs - for every technique left at 0; anything
 * set explicitly always wins.
 */
data class EnhancementOptions(
    /** Blend between the original pixel (0) and the AI model's output (1) for this tile. */
    val strength: Float = 1.0f,
    /** Classical sharpening applied on top of the AI result: a halo-free edge push (made for line art) plus a mild edge-aware unsharp stage. */
    val sharpness: Float = 0.3f,
    /** Compression-artifact removal applied on top of the AI result: colour-blotch/blocking removal on chroma and de-ringing on luma, both edge-preserving. 0 = off. */
    val noiseReduction: Float = 0.3f,
    /** Saturation boost applied on top of the AI result (factor 1 + value). */
    val colorRestoration: Float = 0.2f,
    /** 1x (no resize), 2x, or 4x classical upscale applied after AI enhancement. */
    val upscaleFactor: Int = 1,

    // ---- Scene-aware automation ----
    /** Analyse the photo and switch on the techniques below that it needs (for every one left at 0). */
    val autoEnhance: Boolean = false,
    /** How strongly the automatic choices are applied: 1 = as analysed, below 1 = gentler, up to 1.5. Only used with [autoEnhance]. */
    val autoStrength: Float = 1.0f,

    // ---- Tone and colour ----
    /** Corrects a colour cast (white balance), 0..1 = how much of the full correction. */
    val whiteBalance: Float = 0f,
    /** Stretches the tonal range (percentile levels) so blacks are black and whites are white. */
    val autoLevels: Float = 0f,
    /** Brightness in photographic terms, -1 (darker) .. 1 (brighter). */
    val exposure: Float = 0f,
    /** S-curve contrast, -1 (flatter) .. 1 (punchier). */
    val contrast: Float = 0f,
    /** Lifts dark areas without flattening the rest (shadow recovery). */
    val shadows: Float = 0f,
    /** Pulls bright areas back (highlight recovery). */
    val highlights: Float = 0f,
    /** Contrast-limited adaptive histogram equalisation: local contrast per region (CLAHE). */
    val clahe: Float = 0f,
    /** Retinex-style low-light boost: brightens dark scenes by their illumination, eased off in the highlights. */
    val lowLight: Float = 0f,
    /** Haze / fog removal (dark-channel prior). */
    val dehaze: Float = 0f,
    /** Boosts muted colours more than vivid ones. */
    val vibrance: Float = 0f,
    /** Large-radius local contrast ("clarity") on mid-tones. */
    val clarity: Float = 0f,
    /** Fine-texture boost (guided-filter detail layer with a noise-aware threshold). */
    val detail: Float = 0f,
    /** Vignette correction, -1 (darken corners) .. 1 (brighten corners). */
    val vignette: Float = 0f,

    // ---- Cleaning and sharpness ----
    /** Non-local-means luma denoise plus edge-aware chroma smoothing. */
    val denoise: Float = 0f,
    /** Hot-pixel / salt-and-pepper removal. */
    val despike: Float = 0f,
    /** Removes banding / posterisation from gradients. */
    val deband: Float = 0f,
    /** Richardson-Lucy deconvolution: undoes real blur (focus, motion softness), unlike plain sharpening. */
    val deblur: Float = 0f
) {
    init {
        require(strength in 0f..1f) { "strength must be in 0f..1f" }
        require(sharpness in 0f..1f) { "sharpness must be in 0f..1f" }
        require(noiseReduction in 0f..1f) { "noiseReduction must be in 0f..1f" }
        require(colorRestoration in 0f..1f) { "colorRestoration must be in 0f..1f" }
        require(upscaleFactor in setOf(1, 2, 4)) { "upscaleFactor must be 1, 2, or 4" }
        require(autoStrength in 0f..1.5f) { "autoStrength must be in 0f..1.5f" }
        require(whiteBalance in 0f..1f) { "whiteBalance must be in 0f..1f" }
        require(autoLevels in 0f..1f) { "autoLevels must be in 0f..1f" }
        require(exposure in -1f..1f) { "exposure must be in -1f..1f" }
        require(contrast in -1f..1f) { "contrast must be in -1f..1f" }
        require(shadows in 0f..1f) { "shadows must be in 0f..1f" }
        require(highlights in 0f..1f) { "highlights must be in 0f..1f" }
        require(clahe in 0f..1f) { "clahe must be in 0f..1f" }
        require(lowLight in 0f..1f) { "lowLight must be in 0f..1f" }
        require(dehaze in 0f..1f) { "dehaze must be in 0f..1f" }
        require(vibrance in 0f..1f) { "vibrance must be in 0f..1f" }
        require(clarity in 0f..1f) { "clarity must be in 0f..1f" }
        require(detail in 0f..1f) { "detail must be in 0f..1f" }
        require(vignette in -1f..1f) { "vignette must be in -1f..1f" }
        require(denoise in 0f..1f) { "denoise must be in 0f..1f" }
        require(despike in 0f..1f) { "despike must be in 0f..1f" }
        require(deband in 0f..1f) { "deband must be in 0f..1f" }
        require(deblur in 0f..1f) { "deblur must be in 0f..1f" }
    }

    /** True when any of the new techniques (or auto mode) is switched on. */
    val usesAdvancedTechniques: Boolean
        get() = autoEnhance || whiteBalance > 0f || autoLevels > 0f || exposure != 0f || contrast != 0f ||
            shadows > 0f || highlights > 0f || clahe > 0f || lowLight > 0f || dehaze > 0f || vibrance > 0f ||
            clarity > 0f || detail > 0f || vignette != 0f || denoise > 0f || despike > 0f || deband > 0f ||
            deblur > 0f
}
