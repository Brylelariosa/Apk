package com.novaenhance.ai.workers

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.novaenhance.ai.MainActivity
import com.novaenhance.ai.R
import com.novaenhance.ai.database.entities.TrainingSessionEntity
import com.novaenhance.ai.database.entities.TrainingStatus
import com.novaenhance.ai.di.ServiceLocator
import com.novaenhance.ai.training.trainer.TrainingPhase
import com.novaenhance.ai.training.trainer.TrainingProgressState
import com.novaenhance.ai.training.trainer.overallFraction
import com.novaenhance.ai.utils.Constants
import com.novaenhance.ai.utils.NovaLog
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.launch

private const val TAG = "TrainingForegroundService"

private const val ACTION_START = "com.novaenhance.ai.action.START_TRAINING"
private const val ACTION_PAUSE = "com.novaenhance.ai.action.PAUSE_TRAINING"
private const val ACTION_CANCEL = "com.novaenhance.ai.action.CANCEL_TRAINING"
private const val EXTRA_MODEL_ID = "modelId"
private const val EXTRA_RESUME_SESSION_ID = "resumeSessionId"

/**
 * Runs one [com.novaenhance.ai.training.trainer.SelfImprovementOrchestrator]
 * cycle as a foreground service so a long training run survives the app
 * being backgrounded. There is deliberately only ever one training session
 * system-wide (mirrors [com.novaenhance.ai.ai.model.ModelRepository] only
 * ever holding one loaded engine) - [control] (via [ServiceLocator]) is a
 * single shared instance both this service and the Train AI screen's
 * ViewModel read/write.
 *
 * The notification is a promise that training is happening, so this class is strict about keeping it true:
 *  - it only ever shows the state the trainer really is in (setup stages and "waiting because ..." included),
 *  - it is removed - and can never be re-posted by a late progress update - the moment the session ends,
 *  - Cancel from the notification asks the running session to stop and lets IT record CANCELLED, instead of killing
 *    the job mid-batch (which used to leave the session marked RUNNING with nothing behind it),
 *  - how the session ended (improved / no gain / paused and why / failed) is posted as a normal notification.
 */
class TrainingForegroundService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var trainingJob: Job? = null

    // Once the service has let go of the ongoing notification nothing may post it again: a progress update that was
    // already in flight would otherwise resurrect a "training" notification for a session that has ended - an
    // ongoing one, so it cannot even be swiped away - with nothing running behind it.
    private val notificationLock = Any()
    private var notificationLive = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val locator = ServiceLocator.get(applicationContext)
        when (intent?.action) {
            ACTION_PAUSE -> {
                locator.trainingControlFlow.pause()
                // Nothing running behind this (stale) notification: just take it down.
                if (trainingJob?.isActive != true) shutDown()
            }
            ACTION_CANCEL -> {
                locator.trainingControlFlow.cancel()
                // The running session notices the command at its next safe point, records CANCELLED itself, and its
                // job then stops this service. Calling stopSelf() here instead tore the job down mid-batch.
                if (trainingJob?.isActive != true) shutDown()
            }
            ACTION_START, null -> {
                val modelId = intent?.getStringExtra(EXTRA_MODEL_ID)
                if (modelId == null) {
                    shutDown()
                } else {
                    val resumeSessionId = intent.getLongExtra(EXTRA_RESUME_SESSION_ID, -1L).takeIf { it >= 0 }
                    val alreadyRunning = trainingJob?.isActive == true
                    // A service started with startForegroundService() must call startForeground(), even when it
                    // is already running - but then show what it is really doing, not a fresh "Starting...".
                    postForeground(if (alreadyRunning) locator.trainingProgressPublisher.progress.value else null)
                    if (alreadyRunning) {
                        NovaLog.i(TAG, "Start requested while a session is still running; leaving it to finish")
                    } else {
                        startTraining(modelId, resumeSessionId)
                    }
                }
            }
        }
        return START_NOT_STICKY // crash recovery is handled explicitly via ModelTrainer.findRecoverableSession(), not sticky restart
    }

    private fun startTraining(modelId: String, resumeSessionId: Long?) {
        if (trainingJob?.isActive == true) return
        val locator = ServiceLocator.get(applicationContext)

        trainingJob = scope.launch {
            val progressJob = launch {
                locator.trainingProgressPublisher.progress.filterNotNull().collect { state -> updateNotification(state) }
            }
            var session: TrainingSessionEntity? = null
            var failure: Throwable? = null
            try {
                session = locator.selfImprovementOrchestrator.runCycle(modelId, resumeSessionId, locator.trainingControlFlow)
                NovaLog.i(TAG, "Training session ${session.id} ended with status ${session.status}")
            } catch (cancelled: CancellationException) {
                // The service itself is being torn down; ModelTrainer has already recorded where the session stands.
                throw cancelled
            } catch (t: Throwable) {
                NovaLog.w(TAG, "Training session failed", t)
                failure = t
                locator.modelTrainer.reportStartupFailure(t.message ?: "Training couldn't start (${t::class.simpleName})")
            } finally {
                progressJob.cancel()
                // Only PAUSED should leave the card showing where it left
                // off (Resume continues from there); every other exit -
                // completed, cancelled, or an exception before a session
                // even started - means there's truly nothing left running,
                // so the stale card shouldn't keep showing its last percentage
                // forever (nothing previously cleared this, so it used to).
                if (session?.status != TrainingStatus.PAUSED) {
                    locator.trainingProgressPublisher.clear()
                }
                // Take the "training" notification down FIRST, then say how it went.
                releaseNotification()
                postOutcomeNotification(session, failure, locator.trainingProgressPublisher.lastError.value)
                stopSelf()
            }
        }
    }

    override fun onDestroy() {
        releaseNotification()
        trainingJob?.cancel()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ the ongoing notification

    private fun postForeground(state: TrainingProgressState?) {
        synchronized(notificationLock) {
            notificationLive = true
            startForeground(Constants.TRAINING_NOTIFICATION_ID, buildNotification(state))
        }
    }

    private fun updateNotification(state: TrainingProgressState) {
        if (!canNotify()) return
        synchronized(notificationLock) {
            if (!notificationLive) return
            NotificationManagerCompat.from(this).notify(Constants.TRAINING_NOTIFICATION_ID, buildNotification(state))
        }
    }

    /** Removes the ongoing notification for good; later [updateNotification] calls become no-ops. */
    private fun releaseNotification() {
        synchronized(notificationLock) {
            notificationLive = false
            stopForeground(STOP_FOREGROUND_REMOVE)
            NotificationManagerCompat.from(this).cancel(Constants.TRAINING_NOTIFICATION_ID)
        }
    }

    private fun shutDown() {
        releaseNotification()
        stopSelf()
    }

    private fun buildNotification(state: TrainingProgressState?): Notification {
        ensureChannel()

        val openAppIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val pauseIntent = PendingIntent.getService(
            this, 1, Intent(this, TrainingForegroundService::class.java).setAction(ACTION_PAUSE),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val cancelIntent = PendingIntent.getService(
            this, 2, Intent(this, TrainingForegroundService::class.java).setAction(ACTION_CANCEL),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val contentText = when {
            state == null -> getString(R.string.training_notification_starting)
            // A note says what is happening right now ("Loading the model...", "Waiting because ...").
            state.note != null -> state.note
            state.phase == TrainingPhase.PREPARING -> getString(R.string.training_notification_starting)
            state.phase == TrainingPhase.TRAINING -> getString(
                R.string.training_notification_progress,
                state.epoch + 1, state.totalEpochs, state.phaseStepIndex + 1, state.phaseStepTotal
            )
            state.phase == TrainingPhase.SAVING_CHECKPOINT -> getString(R.string.training_notification_saving)
            state.phase == TrainingPhase.VALIDATING -> getString(
                R.string.training_notification_validating, state.phaseStepIndex, state.phaseStepTotal
            )
            else -> getString(R.string.training_notification_rescoring, state.phaseStepIndex, state.phaseStepTotal)
        }
        val indeterminate = state == null || state.phase == TrainingPhase.PREPARING

        return NotificationCompat.Builder(this, Constants.NOTIFICATION_CHANNEL_TRAINING)
            .setSmallIcon(R.drawable.ic_training_notification)
            .setContentTitle(getString(R.string.training_notification_title))
            .setContentText(contentText)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openAppIntent)
            .setProgress(100, ((state?.overallFraction ?: 0f) * 100).toInt(), indeterminate)
            .addAction(0, getString(R.string.training_notification_pause), pauseIntent)
            .addAction(0, getString(R.string.training_notification_cancel), cancelIntent)
            .build()
    }

    // ------------------------------------------------------------------ the "how did it go" notification

    /**
     * A normal, dismissible notification saying how the session ended - so "it said training but nothing seemed to
     * happen" always has an answer: it improved, it ran but wasn't better (and the current model was kept), it paused
     * and why, or it failed and why. A pause or cancel the user asked for needs no announcement.
     */
    private fun postOutcomeNotification(session: TrainingSessionEntity?, failure: Throwable?, lastError: String?) {
        if (!canNotify()) return
        val (title, text) = when {
            failure != null -> getString(R.string.training_result_title_failed) to (lastError ?: failure.message ?: failure::class.simpleName.orEmpty())
            session == null -> return
            session.status == TrainingStatus.COMPLETED && session.wasPromoted -> {
                val before = session.initialLoss
                val after = session.finalLoss
                val body = if (before != null && after != null) {
                    getString(R.string.training_result_improved, before, after)
                } else {
                    getString(R.string.training_result_improved_no_loss)
                }
                getString(R.string.training_result_title_finished) to body
            }
            session.status == TrainingStatus.COMPLETED ->
                getString(R.string.training_result_title_finished) to getString(R.string.training_result_no_gain)
            session.status == TrainingStatus.FAILED ->
                getString(R.string.training_result_title_failed) to (session.failureReason ?: lastError ?: getString(R.string.training_result_unknown_failure))
            session.status == TrainingStatus.PAUSED && lastError != null ->
                getString(R.string.training_result_title_paused) to lastError
            else -> return
        }

        ensureChannel()
        val openAppIntent = PendingIntent.getActivity(
            this, 3,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(this, Constants.NOTIFICATION_CHANNEL_TRAINING)
            .setSmallIcon(R.drawable.ic_training_notification)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setContentIntent(openAppIntent)
            .build()
        NotificationManagerCompat.from(this).notify(Constants.TRAINING_RESULT_NOTIFICATION_ID, notification)
    }

    private fun canNotify(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                Constants.NOTIFICATION_CHANNEL_TRAINING,
                getString(R.string.training_notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    companion object {
        /**
         * Starts a fresh session, or resumes a paused one when
         * [resumeSessionId] is supplied. There is deliberately no separate
         * `resume()` action: once [com.novaenhance.ai.training.trainer.ModelTrainer.runSession]
         * hits a PAUSE command it returns (see the batch loop), which ends this service's
         * [trainingJob] entirely - flipping [ServiceLocator.trainingControlFlow]
         * back to RUN on its own wouldn't restart anything, since nothing
         * would be left polling it. Resuming has to re-invoke [startTraining]
         * the same way starting fresh does, which is exactly what calling
         * this again with the paused session's id does; `runSession` resets
         * the control flow to RUN itself as the first thing it does.
         */
        fun start(context: Context, modelId: String, resumeSessionId: Long? = null) {
            val intent = Intent(context, TrainingForegroundService::class.java)
                .setAction(ACTION_START)
                .putExtra(EXTRA_MODEL_ID, modelId)
            resumeSessionId?.let { intent.putExtra(EXTRA_RESUME_SESSION_ID, it) }
            ContextCompat.startForegroundService(context, intent)
        }

        fun pause(context: Context) {
            context.startService(Intent(context, TrainingForegroundService::class.java).setAction(ACTION_PAUSE))
        }

        fun cancel(context: Context) {
            context.startService(Intent(context, TrainingForegroundService::class.java).setAction(ACTION_CANCEL))
        }
    }
}
