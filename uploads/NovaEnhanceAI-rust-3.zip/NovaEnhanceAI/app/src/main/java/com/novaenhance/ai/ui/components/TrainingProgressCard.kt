package com.novaenhance.ai.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.novaenhance.ai.training.trainer.TrainingPhase
import com.novaenhance.ai.training.trainer.TrainingProgressState
import com.novaenhance.ai.training.trainer.overallFraction
import kotlin.math.roundToInt

/**
 * Redesigned from a stacked monospace "Batch/Loss/Speed/ETA/Memory" dump
 * (which read like a debug console) into one clear headline number, a
 * progress bar that only ever moves forward, and three at-a-glance stats.
 *
 * The old bar was bound to `batchIndex/totalBatches`, which resets to 0 at
 * the start of every epoch - visually indistinguishable from progress
 * jumping backward. [overallFraction] is monotonic across the whole
 * pipeline (training, checkpoint save, validation, and a promoted
 * session's rescoring pass all report into it) and is shared with the
 * training notification, so both agree.
 */
@Composable
fun TrainingProgressCard(state: TrainingProgressState, modifier: Modifier = Modifier) {
    Card(modifier = modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Training your AI",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        // A note ("Loading the model…", "Waiting because …") says what is happening right now and
                        // wins over the generic phase line.
                        text = state.note ?: when (state.phase) {
                            TrainingPhase.PREPARING -> "Getting ready…"
                            TrainingPhase.TRAINING -> "Epoch ${state.epoch + 1} of ${state.totalEpochs}"
                            TrainingPhase.SAVING_CHECKPOINT -> "Saving checkpoint…"
                            TrainingPhase.VALIDATING -> "Validating new model (${state.phaseStepIndex}/${state.phaseStepTotal})"
                            TrainingPhase.RESCORING -> "Improving future results (${state.phaseStepIndex}/${state.phaseStepTotal})"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Text(
                    text = "${(state.overallFraction * 100).roundToInt()}%",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            if (state.phase == TrainingPhase.PREPARING) {
                // Nothing to count yet: an indeterminate bar shows the app is working, not stuck.
                LinearProgressIndicator(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp))
                )
            } else {
                LinearProgressIndicator(
                    progress = { state.overallFraction },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp))
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                TrainingStat(label = "Speed", value = "${"%.1f".format(state.imagesPerSecond)} img/s")
                TrainingStat(
                    label = "Time left",
                    value = if (state.estimatedSecondsRemaining >= 0) formatEta(state.estimatedSecondsRemaining) else "Calculating…"
                )
                TrainingStat(label = "Memory", value = "${state.memoryUsedMb} MB")
            }

            state.latestLoss?.let { loss ->
                Spacer(modifier = Modifier.height(14.dp))
                Text(
                    text = "Loss (lower is better): ${"%.4f".format(loss)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun TrainingStat(label: String, value: String) {
    Column {
        Text(text = value, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

private fun formatEta(seconds: Long): String {
    val m = seconds / 60
    val s = seconds % 60
    return if (m > 0) "${m}m ${s}s" else "${s}s"
}
