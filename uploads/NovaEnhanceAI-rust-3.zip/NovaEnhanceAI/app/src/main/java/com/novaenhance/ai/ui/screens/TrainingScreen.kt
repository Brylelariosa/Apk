package com.novaenhance.ai.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.ui.res.painterResource
import com.novaenhance.ai.R
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.novaenhance.ai.database.entities.TrainingSessionEntity
import com.novaenhance.ai.database.entities.TrainingStatus
import com.novaenhance.ai.training.trainer.TrainingPhase
import com.novaenhance.ai.ui.components.TrainingProgressCard
import com.novaenhance.ai.ui.viewmodel.NovaViewModelFactory
import com.novaenhance.ai.ui.viewmodel.TrainingViewModel

@Composable
fun TrainingScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val viewModel: TrainingViewModel = viewModel(factory = NovaViewModelFactory(context))
    val state by viewModel.uiState.collectAsState()
    val progress by viewModel.liveProgress.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Train AI") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(painterResource(R.drawable.ic_back_arrow), contentDescription = "Back") } }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("Model: ${state.activeModel?.displayName ?: "None"}", style = MaterialTheme.typography.titleMedium)
            Text("Training pairs available: ${state.datasetPairCount}", style = MaterialTheme.typography.bodyMedium)

            progress?.let { TrainingProgressCard(it, modifier = Modifier.fillMaxWidth()) }

            when (state.currentSession?.status) {
                TrainingStatus.RUNNING -> {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { viewModel.pauseTraining() }, modifier = Modifier.weight(1f)) { Text("Pause") }
                        OutlinedButton(onClick = { viewModel.cancelTraining() }, modifier = Modifier.weight(1f)) { Text("Cancel") }
                    }
                }
                TrainingStatus.PAUSED -> {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { viewModel.startOrResumeTraining() }, modifier = Modifier.weight(1f)) { Text("Resume") }
                        OutlinedButton(onClick = { viewModel.cancelTraining() }, modifier = Modifier.weight(1f)) { Text("Cancel") }
                    }
                }
                else -> {
                    // `progress` is still set while the previous run is finishing its follow-up pass (rescoring).
                    // Tapping Start then used to show a "training" notification for a run the service silently
                    // ignored, so the button waits until the pipeline is really idle.
                    val pipelineBusy = progress != null
                    Button(
                        onClick = { viewModel.startOrResumeTraining() },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = state.datasetPairCount > 0 && !state.isStarting && !pipelineBusy
                    ) {
                        if (pipelineBusy) {
                            Text(if (progress?.phase == TrainingPhase.PREPARING) "Starting…" else "Finishing the previous run…")
                        } else if (state.isStarting) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                strokeWidth = 2.dp,
                                color = MaterialTheme.colorScheme.onPrimary
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Starting…")
                        } else {
                            Text("Start Training")
                        }
                    }
                    if (state.datasetPairCount == 0) {
                        Text(
                            "Add training pairs in Dataset Manager first.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // What the last run actually did - so "it said training, but nothing changed" always has an answer.
            state.currentSession?.let { last ->
                describeFinishedSession(last)?.let {
                    Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            state.message?.let {
                Text(it, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.error)
            }
        }
    }

    if (state.showKeepOrDeleteDatasetPrompt) {
        AlertDialog(
            onDismissRequest = { viewModel.keepDataset() },
            title = { Text("Training completed") },
            text = { Text("Delete the training images you used? Your AI's learned knowledge is kept either way.") },
            confirmButton = { TextButton(onClick = { viewModel.deleteDataset() }) { Text("Delete Dataset") } },
            dismissButton = { TextButton(onClick = { viewModel.keepDataset() }) { Text("Keep Dataset") } }
        )
    }
}

/** One line about how a finished session went; null while it is running/paused (the progress card covers those). */
private fun describeFinishedSession(session: TrainingSessionEntity): String? {
    val loss = if (session.initialLoss != null && session.finalLoss != null) {
        " Loss ${"%.4f".format(session.initialLoss)} → ${"%.4f".format(session.finalLoss)}."
    } else {
        ""
    }
    return when (session.status) {
        TrainingStatus.COMPLETED ->
            if (session.wasPromoted) {
                "Last run: your model improved.$loss"
            } else {
                "Last run: trained ${session.epochsCompleted} epochs on ${session.datasetPairCount} pairs, but the new model " +
                    "wasn’t better than your current one, so it was not kept.$loss More (or more varied) pairs usually help."
            }
        TrainingStatus.FAILED -> "Last run failed: ${session.failureReason ?: "unknown error"}"
        TrainingStatus.CANCELLED -> "Last run was cancelled."
        else -> null
    }
}
