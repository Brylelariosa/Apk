//! The options of one enhancement run, passed from Kotlin as a plain `float[]` (the layout below is shared with
//! `EnhancementOptions.toNativeArray()` on the Kotlin side). Every field has a safe "off" value of 0, so a short or
//! older array simply leaves the newer techniques disabled.

use crate::filters::sharpen::SharpenParams;
use crate::img::clampf;

/// Number of floats in the options array.
pub const OPTIONS_LEN: usize = 32;

pub const STRENGTH: usize = 0;
pub const SHARPNESS: usize = 1; // informational: the resolved sharpen spec is passed in 24..31
pub const NOISE_REDUCTION: usize = 2;
pub const COLOR_RESTORATION: usize = 3;
pub const AUTO: usize = 4;
pub const WHITE_BALANCE: usize = 5;
pub const AUTO_LEVELS: usize = 6;
pub const EXPOSURE: usize = 7;
pub const CONTRAST: usize = 8;
pub const SHADOWS: usize = 9;
pub const HIGHLIGHTS: usize = 10;
pub const CLAHE: usize = 11;
pub const LOW_LIGHT: usize = 12;
pub const DEHAZE: usize = 13;
pub const VIBRANCE: usize = 14;
pub const CLARITY: usize = 15;
pub const DETAIL: usize = 16;
pub const DENOISE: usize = 17;
pub const DESPIKE: usize = 18;
pub const DEBAND: usize = 19;
pub const DEBLUR: usize = 20;
pub const VIGNETTE: usize = 21;
pub const UPSCALE_FACTOR: usize = 22;
pub const AUTO_STRENGTH: usize = 23; // 0 / missing = 1.0
pub const SHARP_AMOUNT: usize = 24;
pub const SHARP_SIGMA: usize = 25;
pub const SHARP_OVERSHOOT: usize = 26;
pub const SHARP_CLAMP_RADIUS: usize = 27;
pub const SHARP_GATE_LOW: usize = 28;
pub const SHARP_GATE_HIGH: usize = 29;
pub const SHARP_PUSH: usize = 30;
pub const SHARP_PUSH_RADIUS: usize = 31;

#[derive(Clone, Debug)]
pub struct Options {
    /// Blend between the original (0) and the CNN's output (1).
    pub strength: f32,
    /// Compression-artifact removal (joint bilateral), 0..1.
    pub noise_reduction: f32,
    /// Saturation boost, 0..1 (factor 1 + value).
    pub color_restoration: f32,
    /// Let the scene analysis switch techniques on for the ones left at 0.
    pub auto: bool,
    /// How strongly the automatic choices are applied: 1 = as analysed, below 1 = gentler, up to 1.5.
    pub auto_strength: f32,

    pub white_balance: f32,
    pub auto_levels: f32,
    pub exposure: f32,
    pub contrast: f32,
    pub shadows: f32,
    pub highlights: f32,
    pub clahe: f32,
    pub low_light: f32,
    pub dehaze: f32,
    pub vibrance: f32,
    pub clarity: f32,
    pub detail: f32,
    pub denoise: f32,
    pub despike: f32,
    pub deband: f32,
    pub deblur: f32,
    pub vignette: f32,

    /// 1, 2 or 4: when above 1 the final sharpening is left to the upscaler.
    pub upscale_factor: usize,
    /// Sharpening to apply at 1x (all zero when the picture will be upscaled afterwards).
    pub sharpen: SharpenParams,
}

fn get(a: &[f32], i: usize) -> f32 {
    match a.get(i) {
        Some(v) if v.is_finite() => *v,
        _ => 0.0,
    }
}

impl Options {
    /// Reads and sanitises the array (NaN/inf -> 0, every value clamped into its valid range).
    pub fn from_slice(a: &[f32]) -> Options {
        let unit = |i: usize| clampf(get(a, i), 0.0, 1.0);
        let signed = |i: usize| clampf(get(a, i), -1.0, 1.0);
        let factor = get(a, UPSCALE_FACTOR).round() as i64;
        let sharpen = SharpenParams {
            amount: get(a, SHARP_AMOUNT).max(0.0),
            sigma: if get(a, SHARP_SIGMA) > 0.0 { get(a, SHARP_SIGMA) } else { 1.0 },
            overshoot: get(a, SHARP_OVERSHOOT),
            clamp_radius: get(a, SHARP_CLAMP_RADIUS).round().max(1.0) as i32,
            gate_low: get(a, SHARP_GATE_LOW),
            gate_high: get(a, SHARP_GATE_HIGH),
            push: get(a, SHARP_PUSH).max(0.0),
            push_radius: get(a, SHARP_PUSH_RADIUS).round().max(1.0) as i32,
        }
        .sanitized();
        Options {
            strength: unit(STRENGTH),
            noise_reduction: unit(NOISE_REDUCTION),
            color_restoration: unit(COLOR_RESTORATION),
            auto: get(a, AUTO) > 0.5,
            auto_strength: {
                let v = get(a, AUTO_STRENGTH);
                if v > 0.0 {
                    clampf(v, 0.0, 1.5)
                } else {
                    1.0
                }
            },
            white_balance: unit(WHITE_BALANCE),
            auto_levels: unit(AUTO_LEVELS),
            exposure: signed(EXPOSURE),
            contrast: signed(CONTRAST),
            shadows: unit(SHADOWS),
            highlights: unit(HIGHLIGHTS),
            clahe: unit(CLAHE),
            low_light: unit(LOW_LIGHT),
            dehaze: unit(DEHAZE),
            vibrance: unit(VIBRANCE),
            clarity: unit(CLARITY),
            detail: unit(DETAIL),
            denoise: unit(DENOISE),
            despike: unit(DESPIKE),
            deband: unit(DEBAND),
            deblur: unit(DEBLUR),
            vignette: signed(VIGNETTE),
            upscale_factor: if factor < 1 { 1 } else if factor > 8 { 8 } else { factor as usize },
            sharpen,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn short_array_means_everything_off() {
        let o = Options::from_slice(&[1.0, 0.3, 0.3, 0.2]);
        assert_eq!(o.strength, 1.0);
        assert_eq!(o.dehaze, 0.0);
        assert!(!o.auto);
        assert_eq!(o.auto_strength, 1.0);
        assert_eq!(o.upscale_factor, 1);
        assert!(!o.sharpen.enabled());
    }

    #[test]
    fn auto_strength_is_read_and_limited() {
        let mut a = vec![0.0f32; OPTIONS_LEN];
        a[AUTO_STRENGTH] = 0.5;
        assert_eq!(Options::from_slice(&a).auto_strength, 0.5);
        a[AUTO_STRENGTH] = 9.0;
        assert_eq!(Options::from_slice(&a).auto_strength, 1.5);
    }

    #[test]
    fn nan_and_out_of_range_are_sanitised() {
        let mut a = vec![0.0f32; OPTIONS_LEN];
        a[STRENGTH] = f32::NAN;
        a[CLAHE] = 7.0;
        a[EXPOSURE] = -9.0;
        let o = Options::from_slice(&a);
        assert_eq!(o.strength, 0.0);
        assert_eq!(o.clahe, 1.0);
        assert_eq!(o.exposure, -1.0);
    }
}
