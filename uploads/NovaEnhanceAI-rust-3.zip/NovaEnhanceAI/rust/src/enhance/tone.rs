//! The tone and colour techniques that need NO neighbouring rows, fused into ONE pass over the band so every pixel
//! is touched once. Everything global (gains, curves, thumbnail-resolution maps) comes from the [`Plan`], sampled by
//! ABSOLUTE image coordinates - so the result is identical however the photo is split into bands.
//!
//! Order, per pixel (all values 0..255):
//!
//! 1. vignette correction        radial gain
//! 2. white balance              per-channel gains
//! 3. clarity                    local contrast against the edge-aware blurred luminance (mid-tones only)
//! 4. dehaze                     J = (I - A) / t + A (dark-channel-prior transmission)
//! 5. low-light                  gain = illumination^(gamma - 1), eased off in the highlights (Retinex-style)
//! 6. shadows / highlights       lift dark neighbourhoods, compress bright ones
//! 7. CLAHE                      contrast-limited adaptive histogram equalisation of luma (tile curves, bilinear)
//! 8. tone curve                 auto levels + exposure + S-curve contrast, applied to the LUMA (hue-preserving)
//! 9. vibrance + saturation      boost muted colours more than vivid ones, skin kept calm, never out of gamut
//!
//! Large-radius local adjustments (clarity, shadows/highlights, low-light, dehaze) read thumbnail-resolution maps,
//! so they cost a few bilinear lookups per pixel instead of a full-size blur.

use super::plan::{Plan, TONE_LUT_SIZE};
use crate::img::{clampf, lerp, luma, smoothstep};
use crate::par::{par_row_chunks_mut, rows_per_job};

#[inline(always)]
fn lut_eval(lut: &[f32], v: f32) -> f32 {
    let x = clampf(v, 0.0, 255.0) * ((TONE_LUT_SIZE - 1) as f32 / 255.0);
    let i = x as usize;
    let i1 = if i + 1 < TONE_LUT_SIZE { i + 1 } else { i };
    let f = x - i as f32;
    lut[i] + (lut[i1] - lut[i]) * f
}

#[inline(always)]
fn clahe_tile(lut: &[f32], tile: usize, i0: usize, i1: usize, f: f32) -> f32 {
    let base = tile * 256;
    lut[base + i0] + (lut[base + i1] - lut[base + i0]) * f
}

/// Moves a pixel to luma `y2` WITHOUT changing its hue. The colour is scaled while every channel still fits, and the
/// luma that is still missing is made up by blending toward white - so a highlight fades to white instead of one channel
/// clipping first (which is exactly what turns an orange sky yellow when a curve is applied per channel).
/// Expects `r, g, b` in 0..255 and `y` = their luma.
#[inline(always)]
fn retarget_luma(r: f32, g: f32, b: f32, y: f32, y2: f32) -> (f32, f32, f32) {
    if y < 1.0 {
        // Practically black: there is no colour to preserve, just move the level.
        let d = y2 - y;
        return (r + d, g + d, b + d);
    }
    let mx = r.max(g).max(b).max(1.0);
    let s = (y2 / y).min(255.0 / mx).min(4.0);
    let (rs, gs, bs) = (r * s, g * s, b * s);
    let ys = y * s;
    if y2 > ys + 0.01 && ys < 255.0 {
        let t = clampf((y2 - ys) / (255.0 - ys), 0.0, 1.0);
        (rs + (255.0 - rs) * t, gs + (255.0 - gs) * t, bs + (255.0 - bs) * t)
    } else {
        (rs, gs, bs)
    }
}

/// 0..1: how skin-like a colour is (a red-orange-yellow hue at moderate saturation). Keeps vibrance off faces.
#[inline(always)]
fn skin_weight(r: f32, g: f32, b: f32, mx: f32, mn: f32, s: f32) -> f32 {
    if r < mx || g < b || mx - mn < 8.0 {
        return 0.0;
    }
    let hue = (g - b) / (mx - mn); // 0 = red .. 1 = yellow
    let hue_w = smoothstep(0.05, 0.2, hue) * (1.0 - smoothstep(0.55, 0.8, hue));
    let sat_w = smoothstep(0.12, 0.25, s) * (1.0 - smoothstep(0.55, 0.75, s));
    hue_w * sat_w
}

/// Applies the plan's tone/colour techniques to `band` (`w * bh * 3` floats, 0..255) whose first row is image row
/// `r0`. Does nothing when no technique is active.
pub fn tone_pass(band: &mut [f32], w: usize, bh: usize, r0: usize, plan: &Plan, threads: usize) {
    let a = &plan.amounts;
    let need_base = !plan.base_map.is_empty()
        && (a.shadows > 0.0 || a.highlights > 0.0 || a.clarity > 0.0 || a.low_light > 0.0);
    let need_t = a.dehaze > 0.0 && !plan.haze_t.is_empty();
    let clahe_on = a.clahe > 0.0 && !plan.clahe_lut.is_empty();
    let tone_on = !plan.tone_lut.is_empty();
    let sat = plan.saturation;
    let vib = a.vibrance;
    let vig = a.vignette;
    let active = need_base || need_t || clahe_on || tone_on || plan.wb_active || sat > 0.0 || vib > 0.0 || vig != 0.0;
    if !active || w == 0 || bh == 0 {
        return;
    }

    let img_w = plan.img_w as f32;
    let img_h = plan.img_h as f32;
    let cx = img_w * 0.5;
    let cy = img_h * 0.5;
    let inv_r2 = 1.0 / (cx * cx + cy * cy).max(1.0);
    let ll_gamma = 1.0 - 0.65 * a.low_light;
    let tiles_x = plan.tiles_x;
    let tiles_y = plan.tiles_y;
    let tile_w = img_w / tiles_x as f32;
    let tile_h = img_h / tiles_y as f32;
    let rpj = rows_per_job(w);

    par_row_chunks_mut(&mut band[..w * bh * 3], w * 3, rpj, threads, |first_row, chunk| {
        let rows_n = chunk.len() / (w * 3);
        let mut base_row = vec![0.0f32; if need_base { w } else { 0 }];
        let mut t_row = vec![0.0f32; if need_t { w } else { 0 }];
        for ry in 0..rows_n {
            let y_abs = r0 + first_row + ry;
            if need_base {
                plan.sample_map_row(&plan.base_map, y_abs, &mut base_row);
            }
            if need_t {
                plan.sample_map_row(&plan.haze_t, y_abs, &mut t_row);
            }

            // CLAHE: the two tile rows this image row sits between, and the vertical weight.
            let fy = clampf((y_abs as f32 + 0.5) / tile_h - 0.5, 0.0, (tiles_y - 1) as f32);
            let ty0 = fy.floor() as usize;
            let ty1 = (ty0 + 1).min(tiles_y - 1);
            let wy = fy - ty0 as f32;

            let dy = y_abs as f32 + 0.5 - cy;
            let row = &mut chunk[ry * w * 3..(ry + 1) * w * 3];
            for x in 0..w {
                let o = x * 3;
                let (mut r, mut g, mut b) = (row[o], row[o + 1], row[o + 2]);

                // 1. vignette
                if vig != 0.0 {
                    let dx = x as f32 + 0.5 - cx;
                    let r2 = (dx * dx + dy * dy) * inv_r2;
                    let gain = 1.0 + vig * 0.8 * r2;
                    r *= gain;
                    g *= gain;
                    b *= gain;
                }

                // 2. white balance
                if plan.wb_active {
                    r *= plan.wb_gains[0];
                    g *= plan.wb_gains[1];
                    b *= plan.wb_gains[2];
                }

                // 3. clarity
                if a.clarity > 0.0 && need_base {
                    let y = luma(r, g, b);
                    let yn = clampf(y / 255.0, 0.0, 1.0);
                    let mid = 4.0 * yn * (1.0 - yn);
                    let d = y - base_row[x];
                    let delta = clampf(a.clarity * 0.9 * d * mid, -30.0, 30.0);
                    r += delta;
                    g += delta;
                    b += delta;
                }

                // 4. dehaze
                if need_t {
                    let t = t_row[x];
                    r = (r - plan.haze_a[0]) / t + plan.haze_a[0];
                    g = (g - plan.haze_a[1]) / t + plan.haze_a[1];
                    b = (b - plan.haze_a[2]) / t + plan.haze_a[2];
                }

                // 5. low-light
                if a.low_light > 0.0 && need_base {
                    let l = (base_row[x] / 255.0).max(0.03);
                    let gain = l.powf(ll_gamma - 1.0).min(4.0);
                    let yn = clampf(luma(r, g, b) / 255.0, 0.0, 1.0);
                    let knee = 1.0 - smoothstep(0.55, 1.0, yn);
                    let ge = 1.0 + (gain - 1.0) * knee;
                    r *= ge;
                    g *= ge;
                    b *= ge;
                }

                // 6. shadows / highlights
                if (a.shadows > 0.0 || a.highlights > 0.0) && need_base {
                    let yn = clampf(luma(r, g, b) / 255.0, 0.0, 1.0);
                    let bl = clampf(base_row[x] / 255.0, 0.0, 1.0);
                    let mut gsh = 1.0f32;
                    if a.shadows > 0.0 {
                        let ws = (1.0 - bl) * (1.0 - bl);
                        gsh += a.shadows * 1.4 * ws * (1.0 - yn);
                    }
                    if a.highlights > 0.0 {
                        let wh = smoothstep(0.45, 1.0, bl);
                        gsh -= a.highlights * 0.55 * wh * yn;
                    }
                    let gsh = clampf(gsh, 0.45, 3.0);
                    r *= gsh;
                    g *= gsh;
                    b *= gsh;
                }

                // 7. CLAHE
                if clahe_on {
                    let yv = clampf(luma(r, g, b), 0.0, 255.0);
                    let i0 = yv as usize;
                    let i1 = (i0 + 1).min(255);
                    let f = yv - i0 as f32;
                    let fx = clampf((x as f32 + 0.5) / tile_w - 0.5, 0.0, (tiles_x - 1) as f32);
                    let tx0 = fx.floor() as usize;
                    let tx1 = (tx0 + 1).min(tiles_x - 1);
                    let wx = fx - tx0 as f32;
                    let lut = &plan.clahe_lut;
                    let top = lerp(
                        clahe_tile(lut, ty0 * tiles_x + tx0, i0, i1, f),
                        clahe_tile(lut, ty0 * tiles_x + tx1, i0, i1, f),
                        wx,
                    );
                    let bottom = lerp(
                        clahe_tile(lut, ty1 * tiles_x + tx0, i0, i1, f),
                        clahe_tile(lut, ty1 * tiles_x + tx1, i0, i1, f),
                        wx,
                    );
                    let delta = (lerp(top, bottom, wy) - yv) * a.clahe;
                    r += delta;
                    g += delta;
                    b += delta;
                }

                // 8. tone curve, applied to the luma: a curve applied to R, G and B separately changes their ratios,
                //    i.e. the hue and saturation of every colour it touches
                if tone_on {
                    let rc = clampf(r, 0.0, 255.0);
                    let gc = clampf(g, 0.0, 255.0);
                    let bc = clampf(b, 0.0, 255.0);
                    let y = luma(rc, gc, bc);
                    let y2 = lut_eval(&plan.tone_lut, y);
                    let (nr, ng, nb) = retarget_luma(rc, gc, bc, y, y2);
                    r = nr;
                    g = ng;
                    b = nb;
                }

                // 9. vibrance + saturation. Muted colours gain most, vivid ones and skin little, and the boost is capped
                //    so that no channel leaves 0..255: a clipped channel is a hue shift, not extra saturation.
                if sat > 0.0 || vib > 0.0 {
                    let y = luma(r, g, b);
                    let mx = r.max(g).max(b);
                    let mn = r.min(g).min(b);
                    let s = if mx > 1.0 { clampf((mx - mn) / mx, 0.0, 1.0) } else { 0.0 };
                    let skin = skin_weight(r, g, b, mx, mn, s);
                    let muted = 1.0 - s;
                    let mut f = 1.0 + sat * (1.0 - 0.5 * s) + vib * muted * muted * 0.9 * (1.0 - 0.6 * skin);
                    let mut limit = 1.0e9f32;
                    for &c in [r, g, b].iter() {
                        let d = c - y;
                        if d > 1e-3 {
                            limit = limit.min((255.0 - y) / d);
                        } else if d < -1e-3 {
                            limit = limit.min(y / -d);
                        }
                    }
                    if f > limit {
                        f = limit.max(1.0);
                    }
                    r = y + (r - y) * f;
                    g = y + (g - y) * f;
                    b = y + (b - y) * f;
                }

                row[o] = clampf(r, 0.0, 255.0);
                row[o + 1] = clampf(g, 0.0, 255.0);
                row[o + 2] = clampf(b, 0.0, 255.0);
            }
        }
    });
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::enhance::analysis::{analyze, VecImage};
    use crate::enhance::options::{Options, CONTRAST, OPTIONS_LEN, SHADOWS};

    fn gradient(w: usize, h: usize) -> VecImage {
        let mut px = vec![255u8; w * h * 4];
        for y in 0..h {
            for x in 0..w {
                let v = (40 + (x * 150 / w)) as u8;
                for c in 0..3 {
                    px[(y * w + x) * 4 + c] = v;
                }
            }
        }
        VecImage { w, h, px }
    }

    #[test]
    fn no_techniques_means_no_change() {
        let img = gradient(64, 48);
        let an = analyze(&img, 1);
        let plan = Plan::build(&Options::from_slice(&vec![0.0f32; OPTIONS_LEN]), &an, 1);
        let mut band = vec![100.0f32; 64 * 48 * 3];
        let before = band.clone();
        tone_pass(&mut band, 64, 48, 0, &plan, 2);
        assert_eq!(band, before);
    }

    #[test]
    fn contrast_curve_separates_tones_and_stays_in_range() {
        let img = gradient(64, 48);
        let an = analyze(&img, 1);
        let mut a = vec![0.0f32; OPTIONS_LEN];
        a[CONTRAST] = 0.6;
        let plan = Plan::build(&Options::from_slice(&a), &an, 1);
        let mut band = vec![0.0f32; 64 * 48 * 3];
        for i in 0..64 * 48 {
            let v = if i % 2 == 0 { 70.0 } else { 190.0 };
            band[i * 3] = v;
            band[i * 3 + 1] = v;
            band[i * 3 + 2] = v;
        }
        tone_pass(&mut band, 64, 48, 0, &plan, 2);
        assert!(band[0] < 70.0, "dark tone gets darker: {}", band[0]);
        assert!(band[3] > 190.0, "bright tone gets brighter: {}", band[3]);
        for v in band {
            assert!(v >= 0.0 && v <= 255.0);
        }
    }

    fn hue_of(r: f32, g: f32, b: f32) -> f32 {
        let mx = r.max(g).max(b);
        let mn = r.min(g).min(b);
        let d = (mx - mn).max(1e-6);
        let h = if mx == r {
            ((g - b) / d).rem_euclid(6.0)
        } else if mx == g {
            (b - r) / d + 2.0
        } else {
            (r - g) / d + 4.0
        };
        h * 60.0
    }

    #[test]
    fn retargeting_luma_keeps_the_hue_and_never_leaves_the_gamut() {
        let colours = [[240.0f32, 120.0, 40.0], [30.0, 90.0, 200.0], [214.0, 160.0, 130.0], [90.0, 200.0, 60.0]];
        for c in colours.iter() {
            let y = luma(c[0], c[1], c[2]);
            // (a target of pure white has no hue left to compare, so stop just short of it)
            for &target in [0.5 * y, 0.9 * y, 1.2 * y, 1.6 * y].iter() {
                let target = target.min(240.0);
                let (r, g, b) = retarget_luma(c[0], c[1], c[2], y, target);
                assert!(r >= -0.01 && g >= -0.01 && b >= -0.01 && r <= 255.01 && g <= 255.01 && b <= 255.01);
                let mut dh = (hue_of(r, g, b) - hue_of(c[0], c[1], c[2])).abs();
                if dh > 180.0 {
                    dh = 360.0 - dh;
                }
                // blending toward white keeps the hue of the scaled colour; allow a little for float rounding
                assert!(dh < 2.5, "hue moved {} degrees for {:?} -> luma {}", dh, c, target);
            }
        }
    }

    #[test]
    fn saturation_boost_does_not_clip_vivid_colours() {
        // A vivid, already-bright orange: the old per-channel boost pushed red past 255 and shifted the hue.
        let (w, h) = (16usize, 8usize);
        let mut a = vec![0.0f32; OPTIONS_LEN];
        a[crate::enhance::options::COLOR_RESTORATION] = 0.6;
        a[crate::enhance::options::VIBRANCE] = 1.0;
        let img = gradient(w, h);
        let an = analyze(&img, 1);
        let plan = Plan::build(&Options::from_slice(&a), &an, 1);
        let mut band = vec![0.0f32; w * h * 3];
        for i in 0..w * h {
            band[i * 3] = 250.0;
            band[i * 3 + 1] = 120.0;
            band[i * 3 + 2] = 30.0;
        }
        let before_hue = hue_of(250.0, 120.0, 30.0);
        tone_pass(&mut band, w, h, 0, &plan, 1);
        let (r, g, b) = (band[0], band[1], band[2]);
        assert!(r <= 255.0 && g >= 0.0 && b >= 0.0);
        assert!((hue_of(r, g, b) - before_hue).abs() < 1.0, "hue {} -> {}", before_hue, hue_of(r, g, b));
    }

    #[test]
    fn shadow_lift_brightens_dark_areas_more_than_bright_ones() {
        let (w, h) = (80usize, 60usize);
        let mut px = vec![255u8; w * h * 4];
        for y in 0..h {
            for x in 0..w {
                let v = if x < w / 2 { 25u8 } else { 225u8 };
                for c in 0..3 {
                    px[(y * w + x) * 4 + c] = v;
                }
            }
        }
        let img = VecImage { w, h, px };
        let an = analyze(&img, 1);
        let mut a = vec![0.0f32; OPTIONS_LEN];
        a[SHADOWS] = 1.0;
        let plan = Plan::build(&Options::from_slice(&a), &an, 1);
        let mut band = vec![0.0f32; w * h * 3];
        for i in 0..w * h {
            let v = if i % w < w / 2 { 25.0 } else { 225.0 };
            band[i * 3] = v;
            band[i * 3 + 1] = v;
            band[i * 3 + 2] = v;
        }
        tone_pass(&mut band, w, h, 0, &plan, 2);
        let dark_gain = band[(30 * w + 10) * 3] - 25.0;
        let bright_gain = band[(30 * w + 70) * 3] - 225.0;
        assert!(dark_gain > 10.0, "dark side lifted: {}", dark_gain);
        assert!(dark_gain > bright_gain, "bright side lifted less");
    }
}
