//! Scene analysis: ONE streaming, read-only pass over the photo that gathers everything the global techniques need
//! (white balance, levels, exposure, CLAHE, dehaze, noise / blur / hot-pixel estimates, auto-enhance decisions).
//!
//! Memory is tiny and independent of the photo size: a ~320 px thumbnail (<= 1.2 MB), a 256-bin histogram, 64 CLAHE
//! tile histograms (64 KB) and a few small counters per worker. Nothing here keeps a reference to the pixels.

use crate::par::run_jobs;

/// Longest side of the thumbnail, in pixels.
pub const THUMB_MAX: usize = 320;
/// CLAHE tile grid (per axis).
pub const TILE_GRID: usize = 8;
const NOISE_BINS: usize = 2048;
const ROWS_PER_JOB: usize = 64;

/// Anything that can hand out RGBA rows (a locked bitmap, or a plain buffer in tests).
pub trait PixelSource: Sync {
    fn width(&self) -> usize;
    fn height(&self) -> usize;
    /// Row `y` as `width * 4` bytes (R, G, B, A).
    fn row(&self, y: usize) -> &[u8];
}

pub struct Analysis {
    pub w: usize,
    pub h: usize,
    /// Source pixels per thumbnail pixel (per axis).
    pub block: usize,
    pub tw: usize,
    pub th: usize,
    /// Box-averaged thumbnail, `tw * th * 3` floats, 0..255.
    pub thumb: Vec<f32>,
    pub luma_hist: Vec<u32>,
    /// 256-bin histogram of the BRIGHTEST CHANNEL of every pixel (HSV "value"). It tells where a colour channel really
    /// runs out of headroom, which luma cannot: a vivid orange never gets a high luma but is already at its limit.
    pub max_hist: Vec<u32>,
    pub pixels: u64,
    pub mean_rgb: [f32; 3],
    /// Estimated sensor/compression noise, standard deviation in levels (robust MAD-style estimate).
    pub noise_sigma: f32,
    /// 95th percentile of the gradient magnitude in levels per pixel: low means blurry.
    pub grad_p95: f32,
    /// Fraction of sampled pixels that are isolated outliers (hot pixels / salt-and-pepper).
    pub spike_rate: f32,
    pub tiles_x: usize,
    pub tiles_y: usize,
    /// `tiles_x * tiles_y * 256` luma histograms.
    pub tile_hist: Vec<u32>,
}

struct Partial {
    thumb_sum: Vec<f32>,
    luma_hist: Vec<u32>,
    max_hist: Vec<u32>,
    sum_rgb: [u64; 3],
    tile_hist: Vec<u32>,
    noise_hist: Vec<u32>,
    grad_hist: Vec<u32>,
    samples: u64,
    spikes: u64,
}

impl Partial {
    fn new(thumb_len: usize, tile_len: usize) -> Partial {
        Partial {
            thumb_sum: vec![0.0; thumb_len],
            luma_hist: vec![0; 256],
            max_hist: vec![0; 256],
            sum_rgb: [0; 3],
            tile_hist: vec![0; tile_len * 256],
            noise_hist: vec![0; NOISE_BINS],
            grad_hist: vec![0; 256],
            samples: 0,
            spikes: 0,
        }
    }
}

#[inline(always)]
fn luma8(r: u8, g: u8, b: u8) -> u8 {
    ((77 * r as u32 + 150 * g as u32 + 29 * b as u32 + 128) >> 8) as u8
}

struct Geometry {
    w: usize,
    h: usize,
    block: usize,
    tw: usize,
    tiles_x: usize,
    tiles_y: usize,
}

fn process_rows(src: &dyn PixelSource, geo: &Geometry, a: usize, b: usize, st: &mut Partial) {
    let (w, h) = (geo.w, geo.h);
    let lo = a.saturating_sub(1);
    let hi = (b + 1).min(h);

    // Luma of the rows [lo, hi): the 3x3 neighbourhoods below need one row of context on each side.
    let mut luma = vec![0u8; (hi - lo) * w];
    for y in lo..hi {
        let row = src.row(y);
        let l = &mut luma[(y - lo) * w..(y - lo + 1) * w];
        for x in 0..w {
            let p = x * 4;
            l[x] = luma8(row[p], row[p + 1], row[p + 2]);
        }
    }

    for y in a..b {
        let row = src.row(y);
        let l = &luma[(y - lo) * w..(y - lo + 1) * w];
        let ty = y * geo.tiles_y / h;
        let thumb_row = (y / geo.block) * geo.tw;
        for x in 0..w {
            let p = x * 4;
            let (r, g, bl) = (row[p], row[p + 1], row[p + 2]);
            let lv = l[x] as usize;
            st.luma_hist[lv] += 1;
            st.max_hist[r.max(g).max(bl) as usize] += 1;
            st.sum_rgb[0] += r as u64;
            st.sum_rgb[1] += g as u64;
            st.sum_rgb[2] += bl as u64;
            let tile = ty * geo.tiles_x + x * geo.tiles_x / w;
            st.tile_hist[tile * 256 + lv] += 1;
            let t = (thumb_row + x / geo.block) * 3;
            st.thumb_sum[t] += r as f32;
            st.thumb_sum[t + 1] += g as f32;
            st.thumb_sum[t + 2] += bl as f32;
        }

        // Noise / sharpness / hot-pixel statistics on every second pixel of every second row.
        if y >= 1 && y + 1 < h && y % 2 == 0 && w >= 3 {
            let up = &luma[(y - 1 - lo) * w..(y - lo) * w];
            let dn = &luma[(y + 1 - lo) * w..(y + 2 - lo) * w];
            let mut x = 1usize;
            while x + 1 < w {
                let (a00, a01, a02) = (up[x - 1] as i32, up[x] as i32, up[x + 1] as i32);
                let (b00, b01, b02) = (l[x - 1] as i32, l[x] as i32, l[x + 1] as i32);
                let (c00, c01, c02) = (dn[x - 1] as i32, dn[x] as i32, dn[x + 1] as i32);

                // Immerkaer's noise mask: zero for any locally linear patch, 6 sigma wide for white noise.
                let conv = a00 - 2 * a01 + a02 - 2 * b00 + 4 * b01 - 2 * b02 + c00 - 2 * c01 + c02;
                let bin = (conv.unsigned_abs() as usize).min(NOISE_BINS - 1);
                st.noise_hist[bin] += 1;

                let gx = (a02 + 2 * b02 + c02) - (a00 + 2 * b00 + c00);
                let gy = (c00 + 2 * c01 + c02) - (a00 + 2 * a01 + a02);
                let mag = (((gx * gx + gy * gy) as f32).sqrt() * 0.125) as usize;
                st.grad_hist[mag.min(255)] += 1;

                let mx = a00.max(a01).max(a02).max(b00).max(b02).max(c00).max(c01).max(c02);
                let mn = a00.min(a01).min(a02).min(b00).min(b02).min(c00).min(c01).min(c02);
                if b01 > mx + 30 || b01 + 30 < mn {
                    st.spikes += 1;
                }
                st.samples += 1;
                x += 2;
            }
        }
    }
}

/// Smallest bin index whose cumulative count reaches `fraction` of the total.
pub fn percentile_bin(hist: &[u32], fraction: f32) -> usize {
    let total: u64 = hist.iter().map(|v| *v as u64).sum();
    if total == 0 {
        return 0;
    }
    let target = (fraction.max(0.0).min(1.0) as f64 * total as f64).ceil() as u64;
    let mut acc = 0u64;
    for (i, v) in hist.iter().enumerate() {
        acc += *v as u64;
        if acc >= target {
            return i;
        }
    }
    hist.len() - 1
}

/// Runs the analysis pass over the whole picture.
pub fn analyze(src: &dyn PixelSource, threads: usize) -> Analysis {
    let w = src.width();
    let h = src.height();
    let max_dim = w.max(h).max(1);
    let block = ((max_dim + THUMB_MAX - 1) / THUMB_MAX).max(1);
    let tw = ((w + block - 1) / block).max(1);
    let th = ((h + block - 1) / block).max(1);
    let tiles_x = TILE_GRID.min(w.max(1));
    let tiles_y = TILE_GRID.min(h.max(1));
    let geo = Geometry { w, h, block, tw, tiles_x, tiles_y };

    let mut jobs: Vec<(usize, usize)> = Vec::new();
    let mut a = 0usize;
    while a < h {
        jobs.push((a, (a + ROWS_PER_JOB).min(h)));
        a += ROWS_PER_JOB;
    }
    let tile_count = tiles_x * tiles_y;
    let partials: Vec<Partial> = run_jobs(
        jobs,
        threads,
        || Partial::new(tw * th * 3, tile_count),
        |st: &mut Partial, (a, b): (usize, usize)| process_rows(src, &geo, a, b, st),
    );

    let mut total = Partial::new(tw * th * 3, tile_count);
    for p in partials.iter() {
        for i in 0..total.thumb_sum.len() {
            total.thumb_sum[i] += p.thumb_sum[i];
        }
        for i in 0..256 {
            total.luma_hist[i] += p.luma_hist[i];
            total.max_hist[i] += p.max_hist[i];
            total.grad_hist[i] += p.grad_hist[i];
        }
        for c in 0..3 {
            total.sum_rgb[c] += p.sum_rgb[c];
        }
        for i in 0..total.tile_hist.len() {
            total.tile_hist[i] += p.tile_hist[i];
        }
        for i in 0..NOISE_BINS {
            total.noise_hist[i] += p.noise_hist[i];
        }
        total.samples += p.samples;
        total.spikes += p.spikes;
    }

    // Thumbnail = block means (edge blocks are partial).
    let mut thumb = total.thumb_sum;
    for ty in 0..th {
        let bh = block.min(h - ty * block);
        for tx in 0..tw {
            let bw = block.min(w - tx * block);
            let inv = 1.0 / (bw * bh) as f32;
            let t = (ty * tw + tx) * 3;
            thumb[t] *= inv;
            thumb[t + 1] *= inv;
            thumb[t + 2] *= inv;
        }
    }

    let pixels = (w as u64) * (h as u64);
    let denom = pixels.max(1) as f64;
    let mean_rgb = [
        (total.sum_rgb[0] as f64 / denom) as f32,
        (total.sum_rgb[1] as f64 / denom) as f32,
        (total.sum_rgb[2] as f64 / denom) as f32,
    ];

    // sigma: the 35th percentile of |noise mask| is 0.4538 * (6 sigma) for pure Gaussian noise; textures and edges
    // only push the UPPER tail, so a low percentile is far less biased by them than the median would be.
    let noise_bin = percentile_bin(&total.noise_hist, 0.35);
    let noise_sigma = if noise_bin == 0 { 0.0 } else { (noise_bin as f32 + 0.5) / 2.723 };
    let grad_p95 = percentile_bin(&total.grad_hist, 0.95) as f32;
    let spike_rate = if total.samples > 0 { total.spikes as f32 / total.samples as f32 } else { 0.0 };

    Analysis {
        w,
        h,
        block,
        tw,
        th,
        thumb,
        luma_hist: total.luma_hist,
        max_hist: total.max_hist,
        pixels,
        mean_rgb,
        noise_sigma,
        grad_p95,
        spike_rate,
        tiles_x,
        tiles_y,
        tile_hist: total.tile_hist,
    }
}

/// A plain in-memory RGBA image (tests and host tools).
pub struct VecImage {
    pub w: usize,
    pub h: usize,
    pub px: Vec<u8>,
}

impl PixelSource for VecImage {
    fn width(&self) -> usize {
        self.w
    }
    fn height(&self) -> usize {
        self.h
    }
    fn row(&self, y: usize) -> &[u8] {
        &self.px[y * self.w * 4..(y + 1) * self.w * 4]
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::rng::Rng;

    fn noisy_image(w: usize, h: usize, sigma: f32, seed: u64) -> VecImage {
        let mut rng = Rng::new(seed);
        let mut px = vec![255u8; w * h * 4];
        for y in 0..h {
            for x in 0..w {
                let base = 90.0 + 40.0 * (x as f32 / w as f32);
                for c in 0..3 {
                    let v = base + sigma * rng.normal();
                    px[(y * w + x) * 4 + c] = v.max(0.0).min(255.0) as u8;
                }
            }
        }
        VecImage { w, h, px }
    }

    #[test]
    fn noise_estimate_tracks_the_true_sigma() {
        let clean = analyze(&noisy_image(160, 120, 0.0, 1), 2);
        let noisy = analyze(&noisy_image(160, 120, 6.0, 2), 2);
        assert!(clean.noise_sigma < 1.0, "clean {}", clean.noise_sigma);
        assert!(noisy.noise_sigma > 3.5 && noisy.noise_sigma < 9.0, "noisy {}", noisy.noise_sigma);
    }

    #[test]
    fn thumbnail_of_a_flat_image_is_flat() {
        let w = 700usize;
        let h = 400usize;
        let img = VecImage { w, h, px: [40u8, 80, 120, 255].iter().cycle().take(w * h * 4).cloned().collect() };
        let a = analyze(&img, 3);
        assert!(a.tw <= THUMB_MAX && a.th <= THUMB_MAX);
        for i in 0..a.tw * a.th {
            assert!((a.thumb[i * 3] - 40.0).abs() < 1e-3);
            assert!((a.thumb[i * 3 + 2] - 120.0).abs() < 1e-3);
        }
    }

    #[test]
    fn value_histogram_sees_the_brightest_channel() {
        // A vivid orange has a modest luma but its red channel is nearly at the top.
        let w = 64usize;
        let h = 48usize;
        let img = VecImage { w, h, px: [240u8, 120, 40, 255].iter().cycle().take(w * h * 4).cloned().collect() };
        let a = analyze(&img, 2);
        assert_eq!(a.max_hist[240] as usize, w * h);
        assert_eq!(a.max_hist.iter().map(|v| *v as usize).sum::<usize>(), w * h);
        let luma_bin = percentile_bin(&a.luma_hist, 0.5);
        assert!(luma_bin < 160, "orange luma stays modest: {}", luma_bin);
    }

    #[test]
    fn histogram_percentiles() {
        let mut hist = vec![0u32; 256];
        hist[10] = 50;
        hist[200] = 50;
        assert_eq!(percentile_bin(&hist, 0.25), 10);
        assert_eq!(percentile_bin(&hist, 0.75), 200);
    }
}
