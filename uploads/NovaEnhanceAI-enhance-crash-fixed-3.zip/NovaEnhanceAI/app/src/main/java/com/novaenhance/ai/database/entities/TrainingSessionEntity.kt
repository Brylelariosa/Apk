package com.novaenhance.ai.database.entities

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

enum class TrainingStatus {
    RUNNING, PAUSED, COMPLETED, CANCELLED, FAILED
}

/**
 * One row per training run. This is also the crash-recovery record: if the
 * process dies mid-session, [com.novaenhance.ai.training.trainer.ModelTrainer]
 * finds the most recent row with status == RUNNING on next app start
 * ([com.novaenhance.ai.NovaEnhanceApplication] reconciles it to PAUSED so
 * the existing Resume flow picks it up) and resumes from
 * [checkpointPath]/[checkpointEpoch]/[checkpointBatchesInEpoch] - the actual
 * last-saved in-progress checkpoint, restored weights/optimizer state and
 * all - rather than [epochsCompleted] alone, which only ever moves at epoch
 * boundaries and says nothing about which *file* to load.
 */
@Entity(
    tableName = "training_sessions",
    foreignKeys = [
        ForeignKey(
            entity = ModelEntity::class,
            parentColumns = ["id"],
            childColumns = ["modelId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("modelId")]
)
data class TrainingSessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val modelId: String,
    val startedAt: Long,
    val completedAt: Long? = null,
    val status: TrainingStatus,

    // Plan decided by the adaptive controller at session start (see
    // AdaptiveTrainingController) - recorded so training history shows *why*
    // a given session behaved the way it did, not just the outcome.
    val plannedEpochs: Int,
    val epochsCompleted: Int = 0,
    val batchSize: Int,
    val learningRate: Float,
    val replayFraction: Float,

    val datasetPairCount: Int,
    val initialLoss: Float? = null,
    val finalLoss: Float? = null,

    val deviceRamMbAtStart: Long,
    val wasThrottledByThermal: Boolean = false,

    val resultModelVersionId: Long? = null,
    val wasPromoted: Boolean = false, // true only if ModelValidator approved the result
    val failureReason: String? = null,

    // Recovery metadata for the latest in-progress checkpoint actually
    // committed to disk for this session (see ModelTrainer.saveInProgressCheckpoint) -
    // null until the first periodic/end-of-epoch save. checkpointAdamStep is
    // also embedded in the checkpoint file's own header (see NovaModelEngine),
    // kept here too so a resumability check doesn't require opening/parsing
    // the file first. checkpointPath is intentionally the same path a
    // promoted version will end up at (see AppStorage.weightsFile) - there is
    // no separate copy step on promotion, just a DB flag flip.
    val checkpointPath: String? = null,
    val checkpointEpoch: Int? = null,
    val checkpointBatchesInEpoch: Int? = null,
    // How many real (non-replay) pairs made up a batch when checkpointBatchesInEpoch
    // was recorded (see ModelTrainer.realPairsPerBatch) - AdaptiveTrainingController
    // re-plans batchSize/replayFraction from scratch on every runSession call,
    // including a resume, so this can legitimately differ from the resumed run's own
    // freshly-planned batching. Resuming still checks this first and skips nothing
    // (falls back to safely re-running the epoch in full) rather than skip the wrong
    // count of batches under a since-changed plan.
    val checkpointRealPairsPerBatch: Int? = null,
    val checkpointAdamStep: Int? = null,
    val checkpointSavedAt: Long? = null
)
