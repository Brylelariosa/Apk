package com.novaenhance.ai.training.checkpoint

import android.system.ErrnoException
import android.system.Os
import android.system.OsConstants
import com.novaenhance.ai.utils.NovaLog
import java.io.File
import java.io.FileDescriptor
import java.io.FileOutputStream
import java.io.IOException

private const val TAG = "AtomicCheckpointFile"

/**
 * Crash-safe replace-in-place for a single file, plus a one-generation-back
 * fallback - the primitive [com.novaenhance.ai.ai.engine.NovaModelEngine]'s
 * checkpoint save/restore is built on. Deliberately free of anything
 * checkpoint-specific (byte layout, validation rules) so it stays reusable
 * for any other file this app ever needs the same guarantee for.
 *
 * For a canonical path `P`, up to three sibling files can exist at once:
 *  - `P` itself: the last generation that completed a full write+rename.
 *    Never opened for writing directly - see [write].
 *  - `P.tmp`: a new generation currently being staged. Only ever created,
 *    fully written, and fsynced *before* anything about `P` or `P.previous`
 *    changes - so a crash at any point up to here leaves both untouched.
 *  - `P.previous`: the generation `P` replaced, kept as a fallback one
 *    step further back than `P` itself - see [recoverLatestValid]'s "latest
 *    checkpoint is invalid but a previous one is valid" case.
 *
 * [write] and [recoverLatestValid] are the only two operations; neither
 * needs to know *why* a generation is invalid, only whether the
 * caller-supplied check says so.
 */
object AtomicCheckpointFile {

    private fun tmpFile(target: File) = File(target.parentFile, target.name + ".tmp")
    private fun previousFile(target: File) = File(target.parentFile, target.name + ".previous")

    /**
     * Writes a brand-new generation of [target] crash-safely:
     * `target.tmp` (fully written + fsynced) -> rotate `target` ->
     * `target.previous` -> rename `target.tmp` -> `target`. If the process
     * dies at any point in this sequence, [recoverLatestValid] finds
     * whichever of the three files is the newest fully-committed one - see
     * its own doc comment for exactly how.
     *
     * [writer] receives an already-open, empty [FileOutputStream] for the
     * tmp file; throwing out of it aborts the whole write and leaves
     * `target`/`target.previous` completely untouched - nothing about
     * either changes until the tmp file is fully written and fsynced.
     */
    fun write(target: File, writer: (FileOutputStream) -> Unit) {
        target.parentFile?.mkdirs()
        val tmp = tmpFile(target)
        tmp.delete() // clear any stale tmp left by an earlier failed attempt before reusing the name

        try {
            FileOutputStream(tmp).use { out ->
                writer(out)
                out.flush()
                try {
                    out.fd.sync()
                } catch (e: IOException) {
                    // Best-effort: some Android filesystems/emulated volumes reject fsync
                    // outright. The rename below is still atomic either way - sync only
                    // adds protection against a hard *power loss* mid-write, a strictly
                    // worse scenario than the process-kill this class primarily defends
                    // against (a killed process can't half-apply the rename() syscall
                    // itself, sync or no sync).
                    NovaLog.w(TAG, "fsync failed for ${tmp.path} - continuing without it", e)
                }
            }
        } catch (t: Throwable) {
            tmp.delete()
            throw t
        }

        if (target.exists()) {
            val previous = previousFile(target)
            previous.delete()
            if (!target.renameTo(previous)) {
                NovaLog.w(TAG, "Could not rotate ${target.path} -> .previous; continuing without a one-generation fallback for this write")
            }
        }

        if (!tmp.renameTo(target)) {
            throw IOException("Atomic rename failed: ${tmp.path} -> ${target.path}")
        }
        syncParentDirectory(target)
    }

    /**
     * Finds the newest generation of [target] that [tryLoad] accepts,
     * trying, in order: a leftover `.tmp` (a write that finished staging
     * but crashed before its final rename - see [write]), `target` itself,
     * then `target.previous`. Whichever one first validates is (re)synced
     * back onto the canonical `target` path - self-healing, so every later
     * caller sees a clean `target` with no leftover `.tmp`/stale-primary
     * state to re-discover. Returns null - never throws - if nothing valid
     * was found among any of the three.
     *
     * [tryLoad] must both validate and parse in one pass, returning null
     * (not throwing) to mean "reject this generation, try the next one."
     * Suspend so callers (checkpoint parsing is suspend, for its own
     * dispatcher/mutex hygiene) don't need a `runBlocking` bridge.
     */
    suspend fun <T> recoverLatestValid(target: File, tryLoad: suspend (File) -> T?): T? {
        val tmp = tmpFile(target)
        val previous = previousFile(target)

        if (tmp.exists()) {
            val fromTmp = tryLoad(tmp)
            if (fromTmp != null) {
                NovaLog.i(TAG, "Completing an interrupted write: staged ${tmp.path} is valid, finishing its commit to ${target.path}")
                target.delete() // defensive - POSIX rename() already replaces an existing destination atomically
                if (!tmp.renameTo(target)) {
                    NovaLog.w(TAG, "Recovered ${tmp.path} but could not rename it into place - returning the loaded value anyway")
                }
                return fromTmp
            }
            NovaLog.w(TAG, "Discarding an interrupted, invalid write staged at ${tmp.path}")
            tmp.delete()
        }

        if (target.exists()) {
            val fromTarget = tryLoad(target)
            if (fromTarget != null) return fromTarget
            NovaLog.w(TAG, "${target.path} did not validate - checking the one-generation-back fallback")
        }

        if (previous.exists()) {
            val fromPrevious = tryLoad(previous)
            if (fromPrevious != null) {
                NovaLog.w(TAG, "Falling back to ${previous.path} (one generation behind) and repairing ${target.path} from it")
                repairFromPrevious(target, previous)
                return fromPrevious
            }
        }

        return null
    }

    /** Self-heal: [target] was missing or failed to validate, but [previous] did - copy it back into place via the same crash-safe path. */
    private fun repairFromPrevious(target: File, previous: File) {
        try {
            write(target) { out -> previous.inputStream().use { it.copyTo(out) } }
        } catch (t: Throwable) {
            NovaLog.w(TAG, "Could not repair ${target.path} from its .previous fallback - it will be retried on the next save", t)
        }
    }

    /** Removes every sibling generation of [target] (itself, `.tmp`, `.previous`) - e.g. after a rejected/discarded training candidate. */
    fun deleteAllGenerations(target: File) {
        target.delete()
        tmpFile(target).delete()
        previousFile(target).delete()
    }

    private fun syncParentDirectory(file: File) {
        // Best-effort extra beyond what process-kill crash-safety strictly
        // needs (the rename() above is already one atomic syscall - nothing
        // about a killed process can leave it half-applied). This additionally
        // makes the rename's directory-entry update durable across a hard
        // *power loss*, which needs the directory's own fd fsynced -
        // java.io.File refuses to open a directory at all (FileOutputStream/
        // FileInputStream both reject it), so this drops one level to the
        // same syscalls java.io itself sits on top of.
        val dir = file.parentFile ?: return
        var fd: FileDescriptor? = null
        try {
            fd = Os.open(dir.path, OsConstants.O_RDONLY, 0)
            Os.fsync(fd)
        } catch (e: ErrnoException) {
            NovaLog.w(TAG, "Directory fsync unavailable for ${dir.path} (errno ${e.errno}) - rename() above is still atomic without it")
        } catch (t: Throwable) {
            NovaLog.w(TAG, "Directory fsync failed for ${dir.path} - rename() above is still atomic without it", t)
        } finally {
            fd?.let { try { Os.close(it) } catch (_: Throwable) { /* already best-effort */ } }
        }
    }
}
