package com.novaenhance.ai.ai.engine

import com.novaenhance.ai.training.checkpoint.AtomicCheckpointFile
import com.novaenhance.ai.utils.NovaLog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.zip.CRC32

private const val TAG = "NovaModelEngine"

internal const val CHECKPOINT_MAGIC = 0x4E564149 // "NVAI" as int32

// Format 1 (original): magic(4) + formatVersion(4) + adamStep(4) = 12 bytes,
// no paramCount field, no checksum. Still readable, unmigrated - see the
// class doc below.
internal const val CHECKPOINT_FORMAT_V1 = 1
internal const val HEADER_SIZE_BYTES_V1 = 12

// Format 2 (current): magic(4) + formatVersion(4) + adamStep(4) +
// paramCount(4) + crc32Checksum(4) = 20 bytes. paramCount makes an
// architecture change self-describing instead of inferred from whole-file
// size; the checksum catches bit-level corruption that happens to land on
// an otherwise-correctly-sized file (which size/magic checks alone cannot).
internal const val CHECKPOINT_FORMAT_V2 = 2
internal const val HEADER_SIZE_BYTES_V2 = 20
internal const val PREFIX_SIZE_BYTES = 8 // magic(4) + formatVersion(4), read first to decide how to parse the rest

internal const val CHECKPOINT_FORMAT_VERSION = CHECKPOINT_FORMAT_V2 // format every NEW save is written as

/**
 * Thrown by [NovaModelEngine.restoreCheckpoint] when a checkpoint file's parameter count doesn't
 * match what the current [NativeNeuralEngine.TOTAL_PARAMS] expects - i.e. it was saved under a
 * different network architecture (see `network.h`'s dated widening notes for the kind of change
 * that causes this). There's no partial or resizable way to load it: a different channel count is
 * a different-shaped parameter array, not a truncated/padded version of the same one. Callers
 * should treat this the same as "no checkpoint exists yet" and fall back to
 * [NovaModelEngine.createFresh] rather than surface it as a raw crash - see
 * [com.novaenhance.ai.ai.model.ModelRepository.getEngine].
 *
 * Deliberately distinct from [CheckpointCorruptedException]: this means "the file is intact but
 * was written for a different-shaped network," not "the file itself is damaged." The two need
 * different fallbacks - a size mismatch safely resets to a fresh model of the *current* shape,
 * but a corrupted file should first try an older, still-valid generation of the *same* shape
 * before ever considering that (see [AtomicCheckpointFile]).
 */
class CheckpointSizeMismatchException(val expectedBytes: Long, val actualBytes: Long, path: String) : Exception(
    "Checkpoint at $path is sized for a different architecture " +
        "(expected $expectedBytes bytes for the current TOTAL_PARAMS=${NativeNeuralEngine.TOTAL_PARAMS}, " +
        "file is $actualBytes bytes) - likely saved before an architecture change."
)

/**
 * Thrown by [NovaModelEngine.restoreCheckpoint] when a checkpoint file is truncated, has a bad
 * magic header, fails its checksum, or contains a non-finite (NaN/Infinity) weight - i.e. the file
 * itself is damaged, most likely by a process death partway through writing it under the OLD
 * (pre-[AtomicCheckpointFile]) non-atomic save path, or by on-disk corruption. Recovery code should
 * catch this and fall back to an older checkpoint generation - see [NovaModelEngine.tryRecoverInProgress] -
 * rather than ever loading the bad weights into a live engine.
 */
class CheckpointCorruptedException(path: String, reason: String) : Exception(
    "Checkpoint at $path is corrupted or truncated ($reason) - it must be discarded, never loaded."
)

/**
 * Owns one model's live state: its [NativeNeuralEngine.TOTAL_PARAMS]
 * weights, plus the Adam optimizer's momentum/velocity accumulators and
 * step counter. This is the entire replacement for the old TFLite-based
 * `TFLiteEngine` - there's no interpreter, no signature runner, no
 * checkpoint-file-format complexity inherited from TensorFlow. A "model" is
 * just these arrays; see [NativeNeuralEngine] for where the actual forward/
 * backward/optimizer math happens (verified in `tools/nn_verification/`).
 *
 * Kept as a plain Kotlin class (no native handle, no `close()` to forget) -
 * all state lives in ordinary [FloatArray]s that Kotlin's GC manages
 * normally; [NativeNeuralEngine]'s JNI calls are stateless functions that
 * read/mutate whatever arrays are passed in.
 *
 * [engineMutex] serializes every operation that reads or mutates
 * [params]/[momentum]/[velocity] on THIS instance - [trainBatch] mutates
 * them via a native call, [inferTile]/[saveCheckpoint] read them,
 * [restoreCheckpoint] replaces them outright. Within one uninterrupted
 * training session these already happen strictly sequentially (one
 * suspend call awaited after another in [com.novaenhance.ai.training.trainer.ModelTrainer]'s
 * batch loop), so the mutex is uncontended there and costs nothing
 * meaningful. It matters for the case that loop doesn't cover: this same
 * engine instance is also what [com.novaenhance.ai.ai.model.ModelRepository]
 * hands out for the interactive Enhance screen, and a training batch and an
 * Enhance tap CAN genuinely land on the same instance at the same time.
 * Without this, a checkpoint write (or an inference read) could observe a
 * torn mix of pre- and post-update floats mid-training-step - not a crash
 * in Kotlin, but exactly the kind of "checkpoint doesn't represent a
 * consistent model/optimizer state" bug recovery depends on not existing.
 * Scoped to one engine instance, not a shared/global lock, so it can never
 * block an unrelated model or session.
 */
class NovaModelEngine private constructor(
    private var params: FloatArray,
    private var momentum: FloatArray,
    private var velocity: FloatArray,
    private var adamStep: Int
) {
    private var anchorParams: FloatArray? = null
    private val engineMutex = Mutex()

    val tileSize: Int get() = NativeNeuralEngine.TILE_SIZE

    /** Read-only visibility into the current Adam step, for callers persisting resume bookkeeping (see ModelTrainer). */
    val currentAdamStep: Int get() = adamStep

    suspend fun inferTile(pixels: IntArray): IntArray = engineMutex.withLock {
        withContext(Dispatchers.Default) {
            val input = TensorImageCodec.encodeSingle(pixels, tileSize)
            val output = NativeNeuralEngine.infer(input, params)
            TensorImageCodec.decodeSingle(output, tileSize)
        }
    }

    /**
     * Runs one training step over a batch of (low-quality, high-quality)
     * tile pairs and returns the loss. `l2SpLambda` is 0 to disable the
     * anti-forgetting penalty entirely (e.g. a model's very first training
     * session, with nothing yet to protect).
     */
    suspend fun trainBatch(
        lowQualityTiles: List<IntArray>,
        highQualityTiles: List<IntArray>,
        learningRate: Float,
        l2SpLambda: Float
    ): Float = engineMutex.withLock {
        withContext(Dispatchers.Default) {
            require(lowQualityTiles.size == highQualityTiles.size) {
                "Batch size mismatch: ${lowQualityTiles.size} low-quality vs ${highQualityTiles.size} high-quality tiles"
            }
            val inputBatch = TensorImageCodec.encodeBatch(lowQualityTiles, tileSize)
            val targetBatch = TensorImageCodec.encodeBatch(highQualityTiles, tileSize)
            adamStep += 1
            NativeNeuralEngine.trainStep(
                inputBatch, targetBatch, lowQualityTiles.size,
                params, momentum, velocity,
                anchorParams, adamStep, learningRate, l2SpLambda
            )
        }
    }

    /** Snapshots current weights as the anti-forgetting anchor. Call once per session, before any [trainBatch]. */
    suspend fun setAnchor() = engineMutex.withLock {
        withContext(Dispatchers.Default) {
            anchorParams = params.copyOf()
        }
    }

    /** Crash-safe save (tmp file + fsync + atomic rename, plus a one-generation-back fallback) - see [AtomicCheckpointFile]. */
    suspend fun saveCheckpoint(path: String): String = engineMutex.withLock {
        withContext(Dispatchers.IO) {
            val paramsBytes = floatArrayToBytes(params)
            val momentumBytes = floatArrayToBytes(momentum)
            val velocityBytes = floatArrayToBytes(velocity)
            val checksum = CRC32().apply {
                update(paramsBytes)
                update(momentumBytes)
                update(velocityBytes)
            }.value.toInt()

            AtomicCheckpointFile.write(File(path)) { out ->
                val header = ByteBuffer.allocate(HEADER_SIZE_BYTES_V2).order(ByteOrder.LITTLE_ENDIAN)
                header.putInt(CHECKPOINT_MAGIC)
                header.putInt(CHECKPOINT_FORMAT_VERSION)
                header.putInt(adamStep)
                header.putInt(NativeNeuralEngine.TOTAL_PARAMS)
                header.putInt(checksum)
                out.write(header.array())
                out.write(paramsBytes)
                out.write(momentumBytes)
                out.write(velocityBytes)
            }
            path
        }
    }

    /**
     * Loads and validates [path] directly, throwing [CheckpointCorruptedException] /
     * [CheckpointSizeMismatchException] on any problem. Use this when an invalid file at this
     * exact path IS the whole answer (nothing else to fall back to) - e.g. the promoted active
     * version. For scanning a checkpoint's crash-safety generations and treating "invalid" as
     * "try the next one" instead, use [tryRecoverInProgress].
     */
    suspend fun restoreCheckpoint(path: String) = engineMutex.withLock { restoreCheckpointLocked(path) }

    private suspend fun restoreCheckpointLocked(path: String) = withContext(Dispatchers.IO) {
        val file = File(path)
        file.inputStream().buffered().use { input ->
            val prefix = ByteArray(PREFIX_SIZE_BYTES)
            readFully(input, prefix, path)
            val prefixBuffer = ByteBuffer.wrap(prefix).order(ByteOrder.LITTLE_ENDIAN)
            val magic = prefixBuffer.int
            val formatVersion = prefixBuffer.int
            if (magic != CHECKPOINT_MAGIC) throw CheckpointCorruptedException(path, "bad magic header")

            var newAdamStep: Int
            var expectedChecksum: Int? = null

            when (formatVersion) {
                CHECKPOINT_FORMAT_V1 -> {
                    val rest = ByteArray(HEADER_SIZE_BYTES_V1 - PREFIX_SIZE_BYTES) // adamStep only
                    readFully(input, rest, path)
                    newAdamStep = ByteBuffer.wrap(rest).order(ByteOrder.LITTLE_ENDIAN).int
                    // No paramCount field in v1 - whole-file size is the only check available,
                    // exactly as this format always worked (kept working on purpose, not migrated).
                    val expectedBytes = HEADER_SIZE_BYTES_V1 + 3L * NativeNeuralEngine.TOTAL_PARAMS * 4L
                    if (file.length() != expectedBytes) {
                        throw CheckpointSizeMismatchException(expectedBytes, file.length(), path)
                    }
                }
                CHECKPOINT_FORMAT_V2 -> {
                    val rest = ByteArray(HEADER_SIZE_BYTES_V2 - PREFIX_SIZE_BYTES) // adamStep + paramCount + checksum
                    readFully(input, rest, path)
                    val restBuffer = ByteBuffer.wrap(rest).order(ByteOrder.LITTLE_ENDIAN)
                    newAdamStep = restBuffer.int
                    val paramCount = restBuffer.int
                    expectedChecksum = restBuffer.int
                    if (paramCount != NativeNeuralEngine.TOTAL_PARAMS) {
                        throw CheckpointSizeMismatchException(
                            expectedBytes = HEADER_SIZE_BYTES_V2 + 3L * NativeNeuralEngine.TOTAL_PARAMS * 4L,
                            actualBytes = file.length(),
                            path = path
                        )
                    }
                }
                else -> throw CheckpointCorruptedException(path, "unsupported format version $formatVersion")
            }

            val paramsBytes = ByteArray(NativeNeuralEngine.TOTAL_PARAMS * 4)
            val momentumBytes = ByteArray(NativeNeuralEngine.TOTAL_PARAMS * 4)
            val velocityBytes = ByteArray(NativeNeuralEngine.TOTAL_PARAMS * 4)
            readFully(input, paramsBytes, path)
            readFully(input, momentumBytes, path)
            readFully(input, velocityBytes, path)

            if (expectedChecksum != null) {
                val actualChecksum = CRC32().apply {
                    update(paramsBytes)
                    update(momentumBytes)
                    update(velocityBytes)
                }.value.toInt()
                if (actualChecksum != expectedChecksum) {
                    throw CheckpointCorruptedException(path, "checksum mismatch - file is bit-corrupted")
                }
            }

            val newParams = bytesToFloatArray(paramsBytes)
            val newMomentum = bytesToFloatArray(momentumBytes)
            val newVelocity = bytesToFloatArray(velocityBytes)
            requireAllFinite(newParams, path, "params")
            requireAllFinite(newMomentum, path, "momentum")
            requireAllFinite(newVelocity, path, "velocity")

            params = newParams
            momentum = newMomentum
            velocity = newVelocity
            adamStep = newAdamStep
        }
    }

    private fun floatArrayToBytes(array: FloatArray): ByteArray {
        val buffer = ByteBuffer.allocate(array.size * 4).order(ByteOrder.LITTLE_ENDIAN)
        buffer.asFloatBuffer().put(array)
        return buffer.array()
    }

    private fun bytesToFloatArray(bytes: ByteArray): FloatArray {
        val floatArray = FloatArray(bytes.size / 4)
        ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN).asFloatBuffer().get(floatArray)
        return floatArray
    }

    private fun requireAllFinite(values: FloatArray, path: String, label: String) {
        for (v in values) {
            if (v.isNaN() || v.isInfinite()) {
                throw CheckpointCorruptedException(path, "non-finite value found in $label")
            }
        }
    }

    private fun readFully(input: java.io.InputStream, dest: ByteArray, path: String) {
        var offset = 0
        while (offset < dest.size) {
            val read = input.read(dest, offset, dest.size - offset)
            if (read == -1) {
                throw CheckpointCorruptedException(path, "unexpected end of file (got $offset of ${dest.size} bytes)")
            }
            offset += read
        }
    }

    companion object {
        /** A brand-new model with freshly (randomly) initialized weights - no file, no asset, no external step needed. */
        fun createFresh(seed: Long = System.nanoTime()): NovaModelEngine {
            val params = FloatArray(NativeNeuralEngine.TOTAL_PARAMS)
            NativeNeuralEngine.initializeParams(params, seed)
            return NovaModelEngine(
                params = params,
                momentum = FloatArray(NativeNeuralEngine.TOTAL_PARAMS),
                velocity = FloatArray(NativeNeuralEngine.TOTAL_PARAMS),
                adamStep = 0
            )
        }

        /**
         * Zero-filled arrays with no native init call - unlike [createFresh], this is only ever
         * used as an about-to-be-fully-overwritten placeholder for [loadFromCheckpoint]/
         * [tryRecoverInProgress] (never returned to a caller without a restore having succeeded
         * first), so there's no reason to pay for real (seeded, native) weight initialization just
         * to immediately discard it.
         */
        private fun uninitializedForLoading(): NovaModelEngine = NovaModelEngine(
            params = FloatArray(NativeNeuralEngine.TOTAL_PARAMS),
            momentum = FloatArray(NativeNeuralEngine.TOTAL_PARAMS),
            velocity = FloatArray(NativeNeuralEngine.TOTAL_PARAMS),
            adamStep = 0
        )

        /** Loads [path] directly; throws on any problem (size mismatch OR corruption) rather than falling back. */
        suspend fun loadFromCheckpoint(path: String): NovaModelEngine = withContext(Dispatchers.IO) {
            val engine = uninitializedForLoading()
            // restoreCheckpointLocked (unlocked) rather than restoreCheckpoint: engine is a fresh,
            // not-yet-shared local, so there is nothing else that could possibly contend for
            // engineMutex on it yet.
            engine.restoreCheckpointLocked(path)
            engine
        }

        /**
         * Recovery-scan variant of [loadFromCheckpoint] for resuming interrupted training (see
         * [com.novaenhance.ai.training.trainer.ModelTrainer]): tries [path] and its crash-safety
         * generations (a leftover staged write, then the one-generation-back fallback - see
         * [AtomicCheckpointFile]) in order, returning the first one that validates. Returns null -
         * never throws - if none of them do, meaning the caller should fall back to the promoted
         * active model instead; every rejected candidate is still logged so the reason is visible.
         */
        suspend fun tryRecoverInProgress(path: String): NovaModelEngine? =
            AtomicCheckpointFile.recoverLatestValid(File(path)) { candidate ->
                try {
                    val engine = uninitializedForLoading()
                    engine.restoreCheckpointLocked(candidate.path)
                    engine
                } catch (t: Throwable) {
                    NovaLog.w(TAG, "Rejecting candidate in-progress checkpoint ${candidate.path}", t)
                    null
                }
            }
    }
}
