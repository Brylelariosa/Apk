package com.novaenhance.ai.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.res.painterResource
import com.novaenhance.ai.R
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

/**
 * The app's signature interaction: drag the teal divider to wipe between
 * the original (left) and AI-enhanced (right) image. This is the one place
 * the app takes a real visual/interaction risk - everywhere else in the UI
 * is calm and information-dense by comparison, which is deliberate (see
 * ui/theme's design note on the palette telling the enhancement story).
 */
@Composable
fun BeforeAfterSlider(
    original: Bitmap,
    enhanced: Bitmap,
    modifier: Modifier = Modifier,
    beforeLabel: String = "Before",
    afterLabel: String = "After",
    onOriginalDisplayChanged: (bitmap: Bitmap, displayed: Boolean) -> Unit = { _, _ -> },
    onEnhancedDisplayChanged: (bitmap: Bitmap, displayed: Boolean) -> Unit = { _, _ -> }
) {
    // Ownership handshake for whoever gave us these bitmaps (see
    // EnhanceViewModel's BitmapRetirement): report every time our own
    // ownership of a specific original/enhanced instance starts or ends, so
    // it's never recycled while originalImage/enhancedImage below - or a
    // draw closure that already captured one of them - could still use it.
    // Keyed on the bitmap itself (not e.g. Unit) so this fires exactly when
    // that instance's tenure here actually starts/ends: once when this
    // composable first receives it, again if a newer bitmap replaces it in
    // place, and again if this composable leaves composition entirely.
    DisposableEffect(original) {
        onOriginalDisplayChanged(original, true)
        onDispose { onOriginalDisplayChanged(original, false) }
    }
    DisposableEffect(enhanced) {
        onEnhancedDisplayChanged(enhanced, true)
        onDispose { onEnhancedDisplayChanged(enhanced, false) }
    }

    var dividerFraction by remember { mutableFloatStateOf(0.5f) }
    val originalImage = remember(original) { original.asImageBitmap() }
    val enhancedImage = remember(enhanced) { enhanced.asImageBitmap() }
    val handleColor = MaterialTheme.colorScheme.primary

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectDragGestures { change, _ ->
                    change.consume()
                    dividerFraction = (change.position.x / size.width).coerceIn(0f, 1f)
                }
            }
    ) {
        val widthPx = constraints.maxWidth.toFloat()
        val heightPx = constraints.maxHeight.toFloat()
        val containerSize = Size(widthPx, heightPx)

        // Both bitmaps are drawn here, in the same Canvas, each fitted with
        // identical ContentScale.Fit math - rather than the previous
        // approach of an auto-scaled Image() for "enhanced" underneath a
        // raw Canvas.drawImage() for "original". That second call defaults
        // to the bitmap's native pixel size at the top-left corner when no
        // dstSize is given, so whenever the two bitmaps weren't already the
        // exact same pixel dimensions - which is the common case: the
        // enhancer can change resolution, and dataset pairs are decoded
        // independently in decodeSampledBitmap - "original" rendered at a
        // different size and origin than "enhanced", showing through the
        // wipe as a second, misaligned copy instead of a clean comparison.
        // "After" fills the whole frame; "before" is clipped over the left
        // portion up to the divider, so dragging right reveals more of the
        // original and dragging left reveals more of the AI result.
        Canvas(modifier = Modifier.fillMaxSize()) {
            val enhancedRect = fitRect(enhancedImage, containerSize)
            drawImage(
                image = enhancedImage,
                dstOffset = enhancedRect.topLeftInt(),
                dstSize = enhancedRect.sizeInt()
            )

            val originalRect = fitRect(originalImage, containerSize)
            clipRect(right = widthPx * dividerFraction) {
                drawImage(
                    image = originalImage,
                    dstOffset = originalRect.topLeftInt(),
                    dstSize = originalRect.sizeInt()
                )
            }

            drawLine(
                color = handleColor,
                start = Offset(widthPx * dividerFraction, 0f),
                end = Offset(widthPx * dividerFraction, heightPx),
                strokeWidth = 3.dp.toPx()
            )
        }

        val handleDiameter = 40.dp
        val handleOffsetX = with(androidx.compose.ui.platform.LocalDensity.current) {
            (widthPx * dividerFraction).toDp() - (handleDiameter / 2)
        }

        CompareLabel(text = beforeLabel, modifier = Modifier.align(Alignment.TopStart).padding(12.dp))
        CompareLabel(text = afterLabel, modifier = Modifier.align(Alignment.TopEnd).padding(12.dp))

        Surface(
            modifier = Modifier
                .align(Alignment.CenterStart)
                .offset(x = handleOffsetX)
                .size(handleDiameter),
            shape = CircleShape,
            color = handleColor,
            shadowElevation = 6.dp
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    painter = painterResource(R.drawable.ic_swap_horizontal),
                    contentDescription = "Drag to compare before and after",
                    tint = Color.White,
                    modifier = Modifier.padding(8.dp)
                )
            }
        }
    }
}

/** A small pill badge for labeling which side of the slider is which. Stays fixed in its corner regardless of divider position - only the underlying image content is clipped by the drag. */
@Composable
private fun CompareLabel(text: String, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(50),
        color = Color.Black.copy(alpha = 0.6f)
    ) {
        Text(
            text = text.uppercase(),
            color = Color.White,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}

/**
 * The on-screen rectangle [image] would occupy inside [containerSize] under
 * [ContentScale.Fit] semantics (uniform scale-to-fit, centered) - i.e.
 * exactly what an `Image(contentScale = ContentScale.Fit)` composable would
 * render for that bitmap in a box of that size. Lets a manually-drawn
 * `DrawScope.drawImage` call match that layout instead of falling back to
 * its own default (the bitmap's native pixel size, top-left aligned) - see
 * the comment above where this is used in [BeforeAfterSlider].
 */
private fun fitRect(image: ImageBitmap, containerSize: Size): Rect {
    val imageSize = Size(image.width.toFloat(), image.height.toFloat())
    if (imageSize.width <= 0f || imageSize.height <= 0f ||
        containerSize.width <= 0f || containerSize.height <= 0f
    ) {
        return Rect(Offset.Zero, containerSize)
    }
    val scale = ContentScale.Fit.computeScaleFactor(imageSize, containerSize).scaleX
    val scaledSize = Size(imageSize.width * scale, imageSize.height * scale)
    val topLeft = Offset(
        x = (containerSize.width - scaledSize.width) / 2f,
        y = (containerSize.height - scaledSize.height) / 2f
    )
    return Rect(topLeft, scaledSize)
}

private fun Rect.topLeftInt(): IntOffset = IntOffset(left.roundToInt(), top.roundToInt())
private fun Rect.sizeInt(): IntSize = IntSize(width.roundToInt(), height.roundToInt())
