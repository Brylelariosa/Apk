package com.novaenhance.ai.ai.engine

import android.graphics.Bitmap
import com.novaenhance.ai.utils.Constants
import com.novaenhance.ai.utils.NovaLog
import com.novaenhance.ai.utils.ThermalGovernor
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlin.math.min

private const val TAG = "TileProcessor"

/**
 * Splits a full-resolution [Bitmap] into `tileSize x tileSize` tiles (with a
 * small overlap band), computes each with [processTile], and writes results
 * into a single output bitmap.
 *
 * Memory strategy (per the "4GB RAM device" / tile-based requirement): the
 * only large allocation is the one output bitmap plus the source bitmap
 * itself - there is no full-image float accumulation buffer. Seams are
 * feathered by blending each tile's overlap band against whatever is
 * *already written* in the output bitmap from its left/top neighbor (which,
 * in raster order, is always processed first), rather than accumulating
 * weights globally. This is a lighter-weight approximation of full
 * multi-tile blending, and is visually seamless at the overlap widths this
 * app uses (16px, see [Constants.TILE_OVERLAP_PX]).
 *
 * That left/top-neighbor dependency means *writing* a tile's result into
 * the output must stay strictly sequential in raster order - but
 * *computing* a tile's result does not, since it only reads the source
 * bitmap and its own buffers. [NovaModelEngine] and [NativeImageProcessor]
 * both document their JNI calls as stateless (read/mutate only the arrays
 * passed in), so this splits the two: tiles are computed several at a time
 * on [Dispatchers.Default], then written into the output one at a time, in
 * order, exactly as before.
 *
 * [thermalGovernor], when provided, is re-checked *between* chunks (not
 * just once up front) so a run over a large photo - or a validation/
 * rescoring pass working through many photos back to back - eases off
 * mid-run if the device heats up partway through, not only at the start.
 * Every caller shares this: a manual "Enhance" tap and the training
 * pipeline's automated validation/rescoring passes all go through this same
 * class, so this is the one place that needed to change for all of them to
 * back off consistently. A `null` governor (the default) preserves the
 * previous fixed-concurrency, no-pacing behavior exactly, for any caller
 * (e.g. a test) that doesn't want it.
 */
class TileProcessor(
    private val tileSize: Int = Constants.TILE_SIZE_PX,
    private val overlap: Int = Constants.TILE_OVERLAP_PX,
    private val thermalGovernor: ThermalGovernor? = null
) {

    companion object {
        // However many cores the device has, don't fan a single tile pass
        // out wider than this - each concurrent tile still makes its own
        // JNI call into the native engine/filters, and there's no evidence
        // more than a handful of those in flight at once keeps paying off
        // on typical phone SoCs. [thermalGovernor] can only narrow this
        // further (via its maxConcurrency), never widen past it.
        private const val MAX_TILE_CONCURRENCY = 8
    }

    data class TileProgress(val tilesDone: Int, val tilesTotal: Int)

    private class ComputedTile(val tx: Int, val ty: Int, val tileW: Int, val tileH: Int, val pixels: IntArray)

    suspend fun process(
        source: Bitmap,
        onProgress: ((TileProgress) -> Unit)? = null,
        // See EnhancementEngine.enhance's isStale doc - threaded straight
        // through here so a superseded request stops between tile chunks
        // rather than processing the whole (possibly large) image. Checked
        // only between chunks, not per-tile: a chunk is at most
        // MAX_TILE_CONCURRENCY tiles and each tile is small
        // (Constants.TILE_SIZE_PX), so this already bounds wasted work to a
        // small, predictable amount without depending on exactly how
        // cancellation propagates out of an in-flight async{} child.
        isStale: () -> Boolean = { false },
        processTile: suspend (pixels: IntArray, tileWidth: Int, tileHeight: Int) -> IntArray
    ): Bitmap = coroutineScope {
        val startMs = System.currentTimeMillis()
        val width = source.width
        val height = source.height
        val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)

        try {
            val xPositions = tilePositions(width)
            val yPositions = tilePositions(height)
            val allPositions = yPositions.flatMap { ty -> xPositions.map { tx -> tx to ty } }
            val totalTiles = allPositions.size
            var done = 0
            var pacedChunks = 0

            val blendScratch = IntArray(tileSize * tileSize)
            val baseConcurrency = Runtime.getRuntime().availableProcessors().coerceIn(1, MAX_TILE_CONCURRENCY)

            // Index cursor + subList (a view, not a copy) rather than repeated
            // take/drop on allPositions - drop() on a List copies every
            // remaining element, which would make this loop quadratic in tile
            // count for a large photo (thousands of tiles) instead of linear.
            var cursor = 0
            while (cursor < allPositions.size) {
                if (isStale()) throw CancellationException("Enhancement superseded - aborting before the next tile chunk")

                val concurrency = if (thermalGovernor != null) {
                    val decision = thermalGovernor.evaluate(concurrencyCeiling = baseConcurrency)
                    if (decision.action == ThermalGovernor.ThrottleAction.PAUSE) {
                        // No meaningful "pause" for one image mid-flight (see
                        // class doc comment) - back off as hard as the worst
                        // COOL_DOWN case instead of abandoning the result.
                        pacedChunks++
                        delay(Constants.THERMAL_COOLDOWN_SEVERE_UNPROTECTED_MS)
                    } else if (decision.action == ThermalGovernor.ThrottleAction.COOL_DOWN) {
                        pacedChunks++
                        delay(decision.cooldownMillis)
                    }
                    decision.maxConcurrency
                } else {
                    baseConcurrency
                }

                val chunkEnd = min(cursor + concurrency, allPositions.size)
                val chunk = allPositions.subList(cursor, chunkEnd)
                cursor = chunkEnd

                val computed = chunk.map { (tx, ty) ->
                    async(Dispatchers.Default) { computeTile(source, tx, ty, width, height, processTile) }
                }.awaitAll()

                for (tile in computed) {
                    blendIntoOutput(output, tile.pixels, tile.tx, tile.ty, tile.tileW, tile.tileH, blendScratch)
                    done++
                    onProgress?.invoke(TileProgress(done, totalTiles))
                }
            }

            val pacingNote = if (pacedChunks > 0) ", eased off for $pacedChunks chunk(s) on thermal state" else ""
            NovaLog.i(TAG, "Processed $totalTiles tiles (${width}x$height, base concurrency=$baseConcurrency$pacingNote) in ${System.currentTimeMillis() - startMs}ms")
            output
        } catch (t: Throwable) {
            // Covers the isStale() abort above as much as any other failure -
            // output is a full-resolution bitmap (see class doc comment on
            // memory strategy) that nothing else references yet, so leaving
            // it for GC to eventually notice - rather than recycling it the
            // moment it's known to be unusable - is exactly the kind of
            // native-memory pressure this whole mechanism exists to avoid.
            output.recycle()
            throw t
        }
    }

    /**
     * Extracts and computes one tile. Reads only from [source] (never
     * mutated anywhere in this class) and this call's own local buffers, so
     * it's safe to run concurrently across tiles - [process] does exactly
     * that, chunked to [MAX_TILE_CONCURRENCY]. `getPixels` is additionally
     * wrapped in `synchronized` purely as cheap insurance against Bitmap's
     * read-concurrency not being documented as safe; it's a small fraction
     * of this function's cost next to the inference/filter call below it,
     * so serializing just that part doesn't meaningfully limit parallelism.
     */
    private suspend fun computeTile(
        source: Bitmap,
        tx: Int,
        ty: Int,
        width: Int,
        height: Int,
        processTile: suspend (pixels: IntArray, tileWidth: Int, tileHeight: Int) -> IntArray
    ): ComputedTile {
        val tileW = min(tileSize, width - tx)
        val tileH = min(tileSize, height - ty)
        val srcTileBuffer = IntArray(tileSize * tileSize)
        synchronized(source) {
            source.getPixels(srcTileBuffer, 0, tileW, tx, ty, tileW, tileH)
        }

        val processed = if (tileW == tileSize && tileH == tileSize) {
            processTile(srcTileBuffer, tileW, tileH)
        } else {
            // Edge tile smaller than the model's fixed input size: pad by
            // edge-replication up to tileSize, process, then crop back down
            // - keeps the model's fixed-shape "infer" signature usable for
            // every tile, including ragged edges.
            val padded = PixelBufferOps.padByReplication(srcTileBuffer, tileW, tileH, tileSize)
            val paddedResult = processTile(padded, tileSize, tileSize)
            PixelBufferOps.cropTopLeft(paddedResult, tileSize, tileW, tileH)
        }
        return ComputedTile(tx, ty, tileW, tileH, processed)
    }

    /** Tile start offsets covering [0, extent), with the last tile clamped to the edge instead of overshooting. */
    private fun tilePositions(extent: Int): List<Int> {
        if (extent <= tileSize) return listOf(0)
        val stride = tileSize - overlap
        val positions = mutableListOf<Int>()
        var pos = 0
        while (pos + tileSize < extent) {
            positions.add(pos)
            pos += stride
        }
        positions.add(extent - tileSize) // final tile flush with the edge
        return positions.distinct()
    }

    /**
     * Writes [processedTile] into [output] at ([tx],[ty]), feathering the
     * left/top overlap bands against pixels already present in [output]
     * (i.e. the previously-written left/top neighbor tiles). Always called
     * sequentially, in raster order - see the class doc comment.
     */
    private fun blendIntoOutput(
        output: Bitmap,
        processedTile: IntArray,
        tx: Int,
        ty: Int,
        tileW: Int,
        tileH: Int,
        scratch: IntArray
    ) {
        val hasLeftNeighbor = tx > 0
        val hasTopNeighbor = ty > 0
        val blendW = if (hasLeftNeighbor) min(overlap, tileW) else 0
        val blendH = if (hasTopNeighbor) min(overlap, tileH) else 0

        if (blendW == 0 && blendH == 0) {
            output.setPixels(processedTile, 0, tileW, tx, ty, tileW, tileH)
            return
        }

        // Read the existing (already-written) output region so we can
        // feather against it, then overwrite with the blended result.
        output.getPixels(scratch, 0, tileW, tx, ty, tileW, tileH)

        for (y in 0 until tileH) {
            for (x in 0 until tileW) {
                val idx = y * tileW + x
                var alpha = 1.0f // weight given to the NEW tile's pixel

                if (hasLeftNeighbor && x < blendW) {
                    alpha = min(alpha, x.toFloat() / blendW)
                }
                if (hasTopNeighbor && y < blendH) {
                    alpha = min(alpha, y.toFloat() / blendH)
                }

                scratch[idx] = if (alpha >= 1.0f) {
                    processedTile[idx]
                } else {
                    blendPixel(scratch[idx], processedTile[idx], alpha)
                }
            }
        }

        output.setPixels(scratch, 0, tileW, tx, ty, tileW, tileH)
    }

    private fun blendPixel(oldPixel: Int, newPixel: Int, newWeight: Float): Int {
        val oldWeight = 1.0f - newWeight
        val r = ((oldPixel shr 16 and 0xFF) * oldWeight + (newPixel shr 16 and 0xFF) * newWeight).toInt()
        val g = ((oldPixel shr 8 and 0xFF) * oldWeight + (newPixel shr 8 and 0xFF) * newWeight).toInt()
        val b = ((oldPixel and 0xFF) * oldWeight + (newPixel and 0xFF) * newWeight).toInt()
        return (0xFF shl 24) or
            (r.coerceIn(0, 255) shl 16) or
            (g.coerceIn(0, 255) shl 8) or
            b.coerceIn(0, 255)
    }
}
