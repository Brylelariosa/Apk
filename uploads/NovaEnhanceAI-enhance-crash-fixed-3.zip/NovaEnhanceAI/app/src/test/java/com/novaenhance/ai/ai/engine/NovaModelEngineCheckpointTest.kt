package com.novaenhance.ai.ai.engine

import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Before
import org.junit.Test
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.file.Files
import java.util.zip.CRC32

/**
 * IMPORTANT: [NovaModelEngine.createFresh]/`trainBatch`/`inferTile` call into
 * [NativeNeuralEngine]'s real JNI methods, which need an actual compiled,
 * loaded `novaenhance_native` `.so` - not available in a plain JVM unit
 * test (this project has no Robolectric/instrumented-test setup for that).
 * Every test here deliberately stays on [NovaModelEngine.loadFromCheckpoint]/
 * `saveCheckpoint`/`restoreCheckpoint`/`tryRecoverInProgress` instead, none
 * of which touch native code - [NativeNeuralEngine.TOTAL_PARAMS] is a
 * `const val` (inlined at compile time), so referencing it doesn't trigger
 * `NativeNeuralEngine`'s `System.loadLibrary` either. Fixture files are
 * built independently below (not via NovaModelEngine's own private
 * byte-conversion helpers) so these tests check the format's actual byte
 * contract, not just "whatever the code under test happens to produce."
 */
class NovaModelEngineCheckpointTest {

    private lateinit var tempDir: File

    @Before
    fun setUp() {
        tempDir = Files.createTempDirectory("nova_model_engine_checkpoint_test").toFile()
    }

    private fun file(name: String) = File(tempDir, name)

    private fun floatArrayToBytes(array: FloatArray): ByteArray {
        val buffer = ByteBuffer.allocate(array.size * 4).order(ByteOrder.LITTLE_ENDIAN)
        buffer.asFloatBuffer().put(array)
        return buffer.array()
    }

    private fun sampleArray(seed: Float) = FloatArray(NativeNeuralEngine.TOTAL_PARAMS) { i -> seed + i * 0.0001f }

    /**
     * Hand-builds a checkpoint file byte-for-byte against the documented format
     * (see NovaModelEngine's CHECKPOINT_FORMAT_V1/V2 constants), independent of
     * NovaModelEngine's own (private) serialization code.
     */
    private fun writeRawCheckpoint(
        target: File,
        formatVersion: Int = CHECKPOINT_FORMAT_V2,
        magic: Int = CHECKPOINT_MAGIC,
        adamStep: Int = 7,
        paramCount: Int = NativeNeuralEngine.TOTAL_PARAMS,
        params: FloatArray = sampleArray(0f),
        momentum: FloatArray = sampleArray(100f),
        velocity: FloatArray = sampleArray(200f),
        corruptChecksumBy: Int = 0,
        truncateLastNBytes: Int = 0
    ) {
        val paramsBytes = floatArrayToBytes(params)
        val momentumBytes = floatArrayToBytes(momentum)
        val velocityBytes = floatArrayToBytes(velocity)
        val trueChecksum = CRC32().apply {
            update(paramsBytes); update(momentumBytes); update(velocityBytes)
        }.value.toInt()

        val header = when (formatVersion) {
            CHECKPOINT_FORMAT_V1 -> ByteBuffer.allocate(HEADER_SIZE_BYTES_V1).order(ByteOrder.LITTLE_ENDIAN).apply {
                putInt(magic); putInt(formatVersion); putInt(adamStep)
            }
            else -> ByteBuffer.allocate(HEADER_SIZE_BYTES_V2).order(ByteOrder.LITTLE_ENDIAN).apply {
                putInt(magic); putInt(formatVersion); putInt(adamStep); putInt(paramCount)
                putInt(trueChecksum + corruptChecksumBy)
            }
        }.array()

        val fullPayload = header + paramsBytes + momentumBytes + velocityBytes
        val truncated = if (truncateLastNBytes > 0) fullPayload.copyOf(fullPayload.size - truncateLastNBytes) else fullPayload
        target.writeBytes(truncated)
    }

    private fun readPayloadBytes(checkpointFile: File, headerSize: Int): ByteArray =
        checkpointFile.readBytes().copyOfRange(headerSize, checkpointFile.length().toInt())

    // --- Round trip (scenario 1/2/12: training starts, checkpoint saves, optimizer state survives) ---

    @Test
    fun `saveCheckpoint after loadFromCheckpoint losslessly round-trips params, momentum, velocity, and adamStep`() = runBlocking {
        val params = sampleArray(1f)
        val momentum = sampleArray(2f)
        val velocity = sampleArray(3f)
        val seed = file("seed.weights")
        writeRawCheckpoint(seed, adamStep = 42, params = params, momentum = momentum, velocity = velocity)

        val engine = NovaModelEngine.loadFromCheckpoint(seed.path)
        assertEquals(42, engine.currentAdamStep)

        val out = file("v7.weights")
        engine.saveCheckpoint(out.path)

        val expectedPayload = floatArrayToBytes(params) + floatArrayToBytes(momentum) + floatArrayToBytes(velocity)
        val actualPayload = readPayloadBytes(out, HEADER_SIZE_BYTES_V2)
        assertArrayEquals("params/momentum/velocity bytes must survive the round trip exactly", expectedPayload, actualPayload)

        // And reloading what was just saved must agree on the optimizer step too.
        val reloaded = NovaModelEngine.loadFromCheckpoint(out.path)
        assertEquals(42, reloaded.currentAdamStep)
    }

    // --- Scenario: format migration (task item 6) ---

    @Test
    fun `a legacy v1 file (no checksum, no paramCount) still loads correctly`() = runBlocking {
        val params = sampleArray(9f)
        val seed = file("legacy_v1.weights")
        writeRawCheckpoint(seed, formatVersion = CHECKPOINT_FORMAT_V1, adamStep = 5, params = params)

        val engine = NovaModelEngine.loadFromCheckpoint(seed.path)
        assertEquals(5, engine.currentAdamStep)

        // A v1 file always gets re-saved in the current (v2) format going forward -
        // migration is read-side only, never a silent rewrite of files at rest.
        val out = file("migrated.weights")
        engine.saveCheckpoint(out.path)
        val header = out.readBytes().copyOfRange(0, 8)
        val formatVersion = ByteBuffer.wrap(header, 4, 4).order(ByteOrder.LITTLE_ENDIAN).int
        assertEquals(CHECKPOINT_FORMAT_V2, formatVersion)
    }

    // --- Scenario 6/7: corrupted / truncated checkpoints are detected ---

    @Test
    fun `a bad magic header is rejected as corrupted`(): Unit = runBlocking {
        val bad = file("bad_magic.weights")
        writeRawCheckpoint(bad, magic = CHECKPOINT_MAGIC.inv()) // bitwise-complemented, guaranteed different and unambiguously a valid Int
        try {
            NovaModelEngine.loadFromCheckpoint(bad.path)
            fail("expected CheckpointCorruptedException")
        } catch (e: CheckpointCorruptedException) {
            assertTrue(e.message!!.contains("magic"))
        }
    }

    @Test
    fun `an unsupported future format version is rejected as corrupted`(): Unit = runBlocking {
        val future = file("future_format.weights")
        writeRawCheckpoint(future, formatVersion = 99)
        try {
            NovaModelEngine.loadFromCheckpoint(future.path)
            fail("expected CheckpointCorruptedException")
        } catch (e: CheckpointCorruptedException) {
            assertTrue(e.message!!.contains("format version"))
        }
    }

    @Test
    fun `a flipped byte fails its checksum and is rejected as corrupted, not silently loaded`(): Unit = runBlocking {
        val flipped = file("bitflip.weights")
        writeRawCheckpoint(flipped, corruptChecksumBy = 1) // header's checksum field itself off-by-one from the true value
        try {
            NovaModelEngine.loadFromCheckpoint(flipped.path)
            fail("expected CheckpointCorruptedException")
        } catch (e: CheckpointCorruptedException) {
            assertTrue(e.message!!.contains("checksum"))
        }
    }

    @Test
    fun `a truncated payload is rejected as corrupted rather than partially loaded`(): Unit = runBlocking {
        val truncated = file("truncated.weights")
        writeRawCheckpoint(truncated, truncateLastNBytes = 1000)
        try {
            NovaModelEngine.loadFromCheckpoint(truncated.path)
            fail("expected CheckpointCorruptedException")
        } catch (e: CheckpointCorruptedException) {
            assertTrue(e.message!!.contains("end of file"))
        }
    }

    // --- Scenario: never load NaN/Infinity, even with an otherwise-valid checksum ---

    @Test
    fun `a NaN weight is rejected even though its checksum is internally consistent`(): Unit = runBlocking {
        val withNaN = sampleArray(1f).also { it[100] = Float.NaN }
        val corrupted = file("nan_weight.weights")
        // corruptChecksumBy = 0: the checksum is computed over the ACTUAL bytes
        // written (NaN included), so it matches - this is deliberately not a
        // checksum failure, it's the separate finite-value check catching it.
        writeRawCheckpoint(corrupted, params = withNaN)
        try {
            NovaModelEngine.loadFromCheckpoint(corrupted.path)
            fail("expected CheckpointCorruptedException")
        } catch (e: CheckpointCorruptedException) {
            assertTrue(e.message!!.contains("non-finite"))
        }
    }

    @Test
    fun `an Infinity value in momentum is rejected too, not just params`(): Unit = runBlocking {
        val withInfinity = sampleArray(2f).also { it[0] = Float.POSITIVE_INFINITY }
        val corrupted = file("inf_momentum.weights")
        writeRawCheckpoint(corrupted, momentum = withInfinity)
        try {
            NovaModelEngine.loadFromCheckpoint(corrupted.path)
            fail("expected CheckpointCorruptedException")
        } catch (e: CheckpointCorruptedException) {
            assertTrue(e.message!!.contains("non-finite") && e.message!!.contains("momentum"))
        }
    }

    // --- Scenario: architecture mismatch is a DIFFERENT failure mode than corruption ---

    @Test
    fun `a mismatched paramCount is a size mismatch, distinct from corruption`() {
        val mismatched = file("wrong_arch.weights")
        writeRawCheckpoint(
            mismatched,
            paramCount = NativeNeuralEngine.TOTAL_PARAMS - 1,
            params = FloatArray(NativeNeuralEngine.TOTAL_PARAMS - 1),
            momentum = FloatArray(NativeNeuralEngine.TOTAL_PARAMS - 1),
            velocity = FloatArray(NativeNeuralEngine.TOTAL_PARAMS - 1)
        )
        try {
            runBlocking { NovaModelEngine.loadFromCheckpoint(mismatched.path) }
            fail("expected CheckpointSizeMismatchException")
        } catch (e: CheckpointSizeMismatchException) {
            // correct, distinct exception type - a recovery scan must be able to
            // tell "different architecture" (never useful to fall back further)
            // apart from "damaged file of the right shape" (fall back and retry)
        }
    }

    @Test
    fun `a v1 file with the wrong total size is also a size mismatch`() {
        val wrongSize = file("legacy_wrong_size.weights")
        writeRawCheckpoint(wrongSize, formatVersion = CHECKPOINT_FORMAT_V1, truncateLastNBytes = 4)
        try {
            runBlocking { NovaModelEngine.loadFromCheckpoint(wrongSize.path) }
            fail("expected CheckpointSizeMismatchException")
        } catch (e: CheckpointSizeMismatchException) {
            // expected
        }
    }

    // --- End-to-end recovery through the real save path (scenario 8, via the actual engine API) ---

    @Test
    fun `tryRecoverInProgress returns null when nothing has ever been saved at that path`() = runBlocking {
        val neverSaved = file("never_saved.weights")
        assertNull(NovaModelEngine.tryRecoverInProgress(neverSaved.path))
    }

    @Test
    fun `tryRecoverInProgress falls back one generation when the latest real save becomes corrupted`() = runBlocking {
        val seed = file("seed.weights")
        writeRawCheckpoint(seed, adamStep = 1, params = sampleArray(11f))
        val engine = NovaModelEngine.loadFromCheckpoint(seed.path)

        val checkpointPath = file("v9.weights").path
        engine.saveCheckpoint(checkpointPath) // generation A (adamStep still 1 - no trainBatch involved, see class doc)

        // Simulate a second real training checkpoint by restoring a different
        // known state into the SAME engine and saving again - this is exactly
        // what ModelTrainer's periodic save does across two calls, minus the
        // real training compute in between (which needs the native lib - see
        // class doc).
        val secondSeed = file("second_seed.weights")
        writeRawCheckpoint(secondSeed, adamStep = 2, params = sampleArray(22f))
        engine.restoreCheckpoint(secondSeed.path)
        engine.saveCheckpoint(checkpointPath) // generation B - rotates generation A into .previous

        // Now corrupt only the latest generation on disk, as if a bad sector (or
        // a future bug) damaged it after it was already fully, validly written.
        File(checkpointPath).writeBytes(ByteArray(50) { 0 })

        val recovered = NovaModelEngine.tryRecoverInProgress(checkpointPath)
        requireNotNull(recovered) { "should have fallen back to the one-generation-back copy" }
        assertEquals("recovered engine should be generation A's adamStep, not generation B's", 1, recovered.currentAdamStep)

        // And the canonical path should have self-healed back to a valid file.
        val healedEngine = NovaModelEngine.loadFromCheckpoint(checkpointPath)
        assertEquals(1, healedEngine.currentAdamStep)
    }
}
