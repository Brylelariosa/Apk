package com.novaenhance.ai.training.checkpoint

import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.io.File
import java.nio.file.Files

/**
 * Exercises [AtomicCheckpointFile] in isolation from [com.novaenhance.ai.ai.engine.NovaModelEngine]'s
 * actual checkpoint byte format - content here is just a plain string tagged "GEN:n", and "invalid"
 * means "doesn't parse as that," so these tests are about the crash-safety file mechanics themselves
 * (tmp/previous rotation, what survives an interrupted write, what recovery falls back to) rather
 * than neural-net-specific validation, which NovaModelEngineCheckpointTest covers separately.
 */
class AtomicCheckpointFileTest {

    private lateinit var tempDir: File
    private lateinit var target: File

    @Before
    fun setUp() {
        tempDir = Files.createTempDirectory("nova_atomic_checkpoint_test").toFile()
        target = File(tempDir, "v6.weights")
    }

    private fun writeGeneration(file: File, n: Int) {
        AtomicCheckpointFile.write(file) { out -> out.write("GEN:$n".toByteArray()) }
    }

    /** Simple stand-in for NovaModelEngine's real parse-and-validate: accepts an EXACT "GEN:<int>", rejects anything else (including valid-prefixed garbage, e.g. a truncated write). */
    private fun tryParseGeneration(file: File): Int? =
        Regex("""^GEN:(\d+)$""").matchEntire(file.readText())?.groupValues?.get(1)?.toIntOrNull()

    // --- Scenario 1/2: training starts normally, checkpoint saves successfully ---

    @Test
    fun `write creates the target file with the given content`() {
        writeGeneration(target, 1)
        assertTrue(target.exists())
        assertEquals("GEN:1", target.readText())
    }

    // --- Scenario 3/4: process dies after a valid checkpoint, app restarts and resumes from it ---

    @Test
    fun `recoverLatestValid returns what write just wrote`() = runBlocking {
        writeGeneration(target, 1)
        val recovered = AtomicCheckpointFile.recoverLatestValid(target) { f -> tryParseGeneration(f) }
        assertEquals(1, recovered)
    }

    @Test
    fun `recoverLatestValid returns null when nothing has ever been written`() = runBlocking {
        val recovered = AtomicCheckpointFile.recoverLatestValid(target) { f -> tryParseGeneration(f) }
        assertNull(recovered)
    }

    @Test
    fun `a second write rotates the first generation into previous`() {
        writeGeneration(target, 1)
        writeGeneration(target, 2)

        assertEquals("GEN:2", target.readText())
        val previous = File(tempDir, "v6.weights.previous")
        assertTrue(previous.exists())
        assertEquals("GEN:1", previous.readText())
    }

    @Test
    fun `the very first write has nothing to rotate and creates no previous file`() {
        writeGeneration(target, 1)
        assertFalse(File(tempDir, "v6.weights.previous").exists())
    }

    // --- Scenario 5: process dies during checkpoint writing ---

    @Test
    fun `a write that throws mid-writer leaves target and previous completely untouched`() {
        writeGeneration(target, 1) // establish a known-good baseline first

        try {
            AtomicCheckpointFile.write(target) { out ->
                out.write("GEN:2 but only par".toByteArray())
                throw RuntimeException("simulated crash mid-write")
            }
            org.junit.Assert.fail("expected the simulated crash to propagate")
        } catch (e: RuntimeException) {
            assertEquals("simulated crash mid-write", e.message)
        }

        // The previously-good target must be exactly as it was - never truncated,
        // never partially overwritten - and no stray tmp left lying around.
        assertEquals("GEN:1", target.readText())
        assertFalse(File(tempDir, "v6.weights.tmp").exists())
        assertFalse(File(tempDir, "v6.weights.previous").exists())
    }

    // --- Scenario 6/7: corrupted / truncated checkpoint is detected ---

    @Test
    fun `recoverLatestValid rejects a corrupted target with nothing else to fall back to`() = runBlocking {
        target.writeText("not a valid generation marker at all")
        val recovered = AtomicCheckpointFile.recoverLatestValid(target) { f -> tryParseGeneration(f) }
        assertNull(recovered)
    }

    @Test
    fun `recoverLatestValid discards an invalid leftover tmp and falls through to a still-good target`() = runBlocking {
        writeGeneration(target, 1)
        // Simulate a crash that happened WHILE staging generation 2 - the tmp file
        // exists but was never finished (this is exactly what AtomicCheckpointFile.write
        // itself would leave behind if the process died inside the writer callback,
        // before this class's own try/catch could clean it up).
        File(tempDir, "v6.weights.tmp").writeText("GEN:2 but truncat")

        val recovered = AtomicCheckpointFile.recoverLatestValid(target) { f -> tryParseGeneration(f) }

        assertEquals(1, recovered)
        assertFalse("the invalid tmp should be discarded, not left behind", File(tempDir, "v6.weights.tmp").exists())
        assertEquals("the still-good target must be untouched", "GEN:1", target.readText())
    }

    @Test
    fun `recoverLatestValid completes a fully-staged tmp left over from a crash right before the final rename`() = runBlocking {
        writeGeneration(target, 1)
        // This time the tmp IS complete and valid - the crash landed after fsync but
        // before (or during) the rename that would have made it the real target.
        File(tempDir, "v6.weights.tmp").writeText("GEN:2")

        val recovered = AtomicCheckpointFile.recoverLatestValid(target) { f -> tryParseGeneration(f) }

        assertEquals("a fully-staged, valid tmp counts as committed", 2, recovered)
        assertEquals("recovery should finish the interrupted rename", "GEN:2", target.readText())
        assertFalse(File(tempDir, "v6.weights.tmp").exists())
    }

    // --- Scenario 8: latest checkpoint is invalid but the previous checkpoint is valid ---

    @Test
    fun `recoverLatestValid falls back to previous when the latest target is corrupted, and self-heals target`() = runBlocking {
        writeGeneration(target, 1)
        writeGeneration(target, 2)
        // Corrupt only the latest generation - e.g. a bad sector, or a bug in some
        // future save path - leaving the one-generation-back fallback untouched.
        target.writeText("corrupted!!")

        val recovered = AtomicCheckpointFile.recoverLatestValid(target) { f -> tryParseGeneration(f) }

        assertEquals("should fall back one generation", 1, recovered)
        assertEquals("target should be repaired from .previous, not left corrupted", "GEN:1", target.readText())
    }

    @Test
    fun `recoverLatestValid returns null when target, tmp, and previous are all invalid`() = runBlocking {
        writeGeneration(target, 1)
        writeGeneration(target, 2)
        target.writeText("corrupted target")
        File(tempDir, "v6.weights.previous").writeText("corrupted previous too")

        val recovered = AtomicCheckpointFile.recoverLatestValid(target) { f -> tryParseGeneration(f) }
        assertNull(recovered)
    }

    // --- Cleanup after a rejected/discarded training candidate ---

    @Test
    fun `deleteAllGenerations removes target, tmp, and previous`() {
        writeGeneration(target, 1)
        writeGeneration(target, 2)
        File(tempDir, "v6.weights.tmp").writeText("stray leftover")

        AtomicCheckpointFile.deleteAllGenerations(target)

        assertFalse(target.exists())
        assertFalse(File(tempDir, "v6.weights.previous").exists())
        assertFalse(File(tempDir, "v6.weights.tmp").exists())
    }
}
