package com.gbaemu.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.gbaemu.app.ui.game.GameActivity
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                RomLibraryScreen()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RomLibraryScreen() {
    val context = LocalContext.current
    val romsDir = remember { File(context.filesDir, "roms").apply { mkdirs() } }
    var roms by remember { mutableStateOf(romsDir.listFiles()?.toList().orEmpty()) }
    val versionName = remember {
        try {
            context.packageManager.getPackageInfo(context.packageName, 0).versionName
        } catch (_: Exception) {
            null
        }
    }

    val pickerLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            importRom(context, uri, romsDir)
            roms = romsDir.listFiles()?.toList().orEmpty()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("GBA Emulator" + (versionName?.let { " v$it" } ?: "")) })
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { pickerLauncher.launch(arrayOf("*/*")) }) {
                Text("+")
            }
        },
    ) { padding ->
        if (roms.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text("No ROMs yet \u2014 tap + to add one.")
            }
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize().padding(padding)) {
                items(roms) { file ->
                    ListItem(
                        headlineContent = { Text(file.name) },
                        modifier = Modifier.clickable {
                            context.startActivity(
                                Intent(context, GameActivity::class.java)
                                    .putExtra(GameActivity.EXTRA_ROM_PATH, file.absolutePath),
                            )
                        },
                    )
                    HorizontalDivider()
                }
            }
        }
    }
}

private fun importRom(context: Context, uri: Uri, romsDir: File) {
    context.contentResolver.openInputStream(uri)?.use { input ->
        val name = queryDisplayName(context, uri) ?: "rom_${System.currentTimeMillis()}.gba"
        File(romsDir, name).outputStream().use { output -> input.copyTo(output) }
    }
}

private fun queryDisplayName(context: Context, uri: Uri): String? {
    context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
        val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (idx >= 0 && cursor.moveToFirst()) return cursor.getString(idx)
    }
    return null
}
