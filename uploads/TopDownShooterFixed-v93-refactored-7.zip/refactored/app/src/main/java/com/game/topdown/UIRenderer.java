package com.game.topdown;

/**
 * Stub UIRenderer — placeholder for future extraction of drawHUD/drawShop/drawSettings.
 * Methods are currently no-ops; logic still lives in GameView until a thin
 * GameState interface is defined (see REFACTORING.md).
 */
public class UIRenderer {
    public void handleRelFireTap(float x, float y) {}
    public void handleSettingsTap(float x, float y) {}
    public void handleShopTap(float x, float y) {}
}
