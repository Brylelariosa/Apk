package com.game.topdown;

import android.graphics.*;
import java.util.*;
import java.util.concurrent.*;
import org.json.*;
import static com.game.topdown.MapData.*;
import static com.game.topdown.PhysicsSystem.*;
import static com.game.topdown.GameConstants.*;

/** Draws world-space entities. Owns all pre-allocated Paint fields. */
public class WorldRenderer {

/** Injected by GameView so the renderer can draw and react to joystick position. */
Joystick moveStick, aimStick;

private void drawVoltChakrams(GameState state, Canvas c) {
    long now = System.currentTimeMillis();

    // Each disc gets its own per-disc phase so they pulse out of sync
    for (VoltChakram vc : state.voltChakrams) {
        float cx = vc.x, cy = vc.y;
        float phase = (float)(now / 140.0) + vc.orbitIdx * 2.094f; // 120° apart
        float pulse  = 0.55f + 0.45f * (float) Math.sin(phase);
        float pulse2 = 0.55f + 0.45f * (float) Math.sin(phase * 1.7f + 1.1f);

        boolean orbiting  = vc.state == VoltChakram.ORBITING;
        boolean launched  = vc.state == VoltChakram.LAUNCHED;
        boolean returning = vc.state == VoltChakram.RETURNING;

        // Colour scheme: orbiting = cool electric cyan, launched = hot white-yellow, returning = aqua-green
        int rC, gC, bC;       // core tint
        int rG, gG, bG;       // glow tint
        float discR;          // disc radius
        if (launched) {
            rC = 255; gC = 245; bC = 200;   // white-hot
            rG = 180; gG = 240; bG = 255;
            discR = 13f;
        } else if (returning) {
            rC =  60; gC = 255; bC = 200;   // aqua-green return
            rG =   0; gG = 220; bG = 180;
            discR = 11f;
        } else {
            rC = 160; gC = 230; bC = 255;   // cool cyan orbit
            rG =  80; gG = 180; bG = 255;
            discR = 11f;
        }

        // ── 1. Wide soft outer glow ──────────────────────────────────────
        float glowR1 = discR * 2.6f + pulse * 6f;
        vcOuterGlow.setColor(Color.argb((int)(35 * pulse), rG, gG, bG));
        c.drawCircle(cx, cy, glowR1, vcOuterGlow);

        // ── 2. Mid glow ring ─────────────────────────────────────────────
        float glowR2 = discR * 1.7f + pulse2 * 4f;
        vcMidGlow.setColor(Color.argb((int)(80 * pulse2), rG, gG, bG));
        c.drawCircle(cx, cy, glowR2, vcMidGlow);

        // ── 3. Motion trail (launched & returning) ───────────────────────
        if (!orbiting) {
            float speed = (float) Math.sqrt(vc.vx * vc.vx + vc.vy * vc.vy);
            if (speed > 15f) {
                float ux = -vc.vx / speed, uy = -vc.vy / speed;
                int segments = launched ? 10 : 6;
                float segLen = launched ? Math.min(60f, speed * 0.05f) / segments
                                        : Math.min(30f, speed * 0.03f) / segments;
                // Slight perpendicular jitter for a crackling lightning-bolt look
                float px = -uy, py = ux;  // perpendicular
                for (int t = 0; t < segments; t++) {
                    float tf   = (t + 1f) / segments;
                    float tx   = cx + ux * segLen * (t + 1) * segments;
                    float ty   = cy + uy * segLen * (t + 1) * segments;
                    float jitter = (float)Math.sin(now * 0.041f + t * 1.3f + vc.orbitIdx) * 3f * tf;
                    float rx2  = tx + px * jitter, ry2 = ty + py * jitter;
                    int alpha  = (int)(200 * (1f - tf));
                    float sr   = discR * (1f - tf * 0.7f);
                    vcTrailP.setColor(Color.argb(alpha, rC, gC, bC));
                    c.drawCircle(rx2, ry2, sr, vcTrailP);
                }
                // Extra bright core of trail right behind disc
                vcTrailCore.setColor(Color.argb(160, 255, 255, 255));
                c.drawCircle(cx + ux * discR, cy + uy * discR, discR * 0.45f, vcTrailCore);
            }
        }

        // ── 4. Chakram blade ring (rotating thin ring with notches) ──────
        //    Two overlapping rings at different spin speeds for a shuriken look
        vcRingP.setColor(Color.argb((int)(210 + 45 * pulse), rC, gC, bC));
        vcRingP.setStrokeWidth(launched ? 3.5f : 2.8f);
        c.drawCircle(cx, cy, discR, vcRingP);

        // Inner ring, counter-rotating
        vcRingP2.setColor(Color.argb((int)(120 * pulse2), rG, gG, bG));
        c.drawCircle(cx, cy, discR * 0.62f, vcRingP2);

        // Spinning blade spokes — 6 blades that rotate
        float spinA = vc.spinAngle;
        vcBladePath.reset();
        for (int i = 0; i < 6; i++) {
            float a    = spinA + (float)(i * Math.PI / 3);
            float aTip = spinA + (float)(i * Math.PI / 3) + 0.38f; // angled tip
            float innerR = discR * 0.28f, outerR2 = discR * 0.92f;
            float ix = cx + innerR * (float)Math.cos(a),        iy = cy + innerR * (float)Math.sin(a);
            float ox = cx + outerR2 * (float)Math.cos(aTip),    oy = cy + outerR2 * (float)Math.sin(aTip);
            vcBladePath.moveTo(ix, iy);
            vcBladePath.lineTo(ox, oy);
        }
        vcBladeP.setStrokeWidth(launched ? 2.2f : 1.8f);
        vcBladeP.setColor(Color.argb((int)(200 + 55 * pulse), rC, gC, bC));
        c.drawPath(vcBladePath, vcBladeP);

        // ── 5. Electric bolt sparks radiating from disc ──────────────────
        int zapCount = orbiting ? 4 : (launched ? 6 : 3);
        float zapSeed = (float)(now / 70.0) + vc.orbitIdx * 3.7f;
        for (int z = 0; z < zapCount; z++) {
            float za      = zapSeed + z * ((float)Math.PI * 2 / zapCount);
            float zapLen  = discR * (0.9f + 0.8f * (float)Math.abs(Math.sin(zapSeed + z * 1.6f)));
            float kinkT   = 0.55f; // where the bolt kinks
            float kinkAng = za + (float)Math.sin(zapSeed * 1.3f + z) * 0.5f;
            float kx = cx + (float)Math.cos(kinkAng) * zapLen * kinkT;
            float ky = cy + (float)Math.sin(kinkAng) * zapLen * kinkT;
            float ex2 = cx + (float)Math.cos(za) * zapLen;
            float ey2 = cy + (float)Math.sin(za) * zapLen;
            int zapAlpha = (int)(180 * pulse * (launched ? 1f : 0.75f));
            vcZapP.setStrokeWidth(launched ? 2f : 1.3f);
            vcZapP.setColor(Color.argb(zapAlpha, 200, 240, 255));
            c.drawLine(cx, cy, kx, ky, vcZapP);   // first segment
            vcZapP.setStrokeWidth(launched ? 1.4f : 1f);
            vcZapP.setColor(Color.argb(zapAlpha / 2, 200, 240, 255));
            c.drawLine(kx, ky, ex2, ey2, vcZapP); // second segment (brighter)
        }

        // ── 6. Hot white core ────────────────────────────────────────────
        float coreR = discR * 0.30f + pulse * 1.5f;
        // Soft white halo around core
        vcCoreHalo.setColor(Color.argb((int)(120 * pulse), rC, gC, bC));
        c.drawCircle(cx, cy, coreR * 2.2f, vcCoreHalo);
        // Solid bright centre
        vcCoreP.setColor(Color.argb(255, 240, 255, 255));
        c.drawCircle(cx, cy, coreR, vcCoreP);

        // ── 7. Orbit connection line back to player (orbiting only) ──────
        if (orbiting) {
            Player owner = (state.localPlayer != null && state.localPlayer.id == vc.ownerId)
                    ? state.localPlayer : state.remote.get(vc.ownerId);
            if (owner != null) {
                vcConnP.setColor(Color.argb((int)(55 * pulse), rG, gG, bG));
                vcConnP.setPathEffect(new android.graphics.DashPathEffect(
                        new float[]{6f, 8f}, (float)(now / 60.0)));
                c.drawLine(owner.x, owner.y, cx, cy, vcConnP);
                vcConnP.setPathEffect(null); // reset for next draw
            }
        }
    }
}

private void drawRope(Canvas c, float x1, float y1, float x2, float y2) {
    float dx = x2 - x1, dy = y2 - y1;
    float len = (float) Math.sqrt(dx*dx + dy*dy);
    if (len < 2f) return;
    // Mid-point sag: blend perpendicular + downward gravity
    float mx = (x1+x2)*0.5f, my = (y1+y2)*0.5f;
    float perpX = -dy/len, perpY = dx/len;  // unit perpendicular
    float sagAmt = Math.min(len * 0.14f, 45f);
    // Bias sag downward (+y in world) to simulate gravity
    float ctrlX = mx + perpX * sagAmt * 0.3f;
    float ctrlY = my + perpY * sagAmt * 0.3f + sagAmt * 0.8f;
    android.graphics.Path ropePath = new android.graphics.Path();
    ropePath.moveTo(x1, y1);
    ropePath.quadTo(ctrlX, ctrlY, x2, y2);
    // Outer dark shadow (ddRopeOuter pre-allocated)
    ddRopeOuter.setStrokeWidth(5f); ddRopeOuter.setColor(Color.argb(180, 70, 45, 15));
    ddRopeOuter.setStrokeCap(Paint.Cap.ROUND);
    c.drawPath(ropePath, ddRopeOuter);
    // Inner lighter rope strand
    ddRopeInner.setStrokeWidth(2.5f); ddRopeInner.setColor(Color.argb(230, 205, 165, 90));
    ddRopeInner.setStrokeCap(Paint.Cap.ROUND);
    c.drawPath(ropePath, ddRopeInner);
    // Thin highlight strand for woven look
    ddRopeHighlight.setStrokeWidth(1f); ddRopeHighlight.setColor(Color.argb(120, 255, 220, 140));
    c.drawPath(ropePath, ddRopeHighlight);
}

private void drawPullRopes(GameState state, Canvas c) {
    for (Player p : state.remote.values()) {
        if (!p.alive || !p.isBeingPulled()) continue;
        Player caster = (state.localPlayer != null && p.hookPullOwnerId == state.localPlayer.id)
                ? state.localPlayer : state.remote.get(p.hookPullOwnerId);
        float ox = (caster != null) ? caster.x : p.hookPullFromX;
        float oy = (caster != null) ? caster.y : p.hookPullFromY;
        drawMetalChain(c, ox, oy, p.x, p.y);
    }
    // Local player being pulled
    if (state.localPlayer != null && state.localPlayer.alive && state.localPlayer.isBeingPulled()) {
        Player caster = state.remote.get(state.localPlayer.hookPullOwnerId);
        float ox = (caster != null) ? caster.x : state.localPlayer.hookPullFromX;
        float oy = (caster != null) ? caster.y : state.localPlayer.hookPullFromY;
        drawMetalChain(c, ox, oy, state.localPlayer.x, state.localPlayer.y);
    }
}

private void drawHookChains(GameState state, Canvas c) {
    for (Bullet b : state.bullets) {
        if (!b.hookSpear) continue;
        Player owner = (state.localPlayer != null && state.localPlayer.id == b.ownerId)
                ? state.localPlayer : state.remote.get(b.ownerId);
        float ox = (owner != null) ? owner.x : b.spawnX;
        float oy = (owner != null) ? owner.y : b.spawnY;
        drawMetalChain(c, ox, oy, b.x, b.y);
    }
}

private void drawMetalChain(Canvas c, float x1, float y1, float x2, float y2) {
    float dx = x2 - x1, dy = y2 - y1;
    float len = (float) Math.sqrt(dx * dx + dy * dy);
    if (len < 6f) return;

    float nx = dx / len, ny = dy / len;   // direction along chain
    float px = -ny, py = nx;               // perpendicular

    // Faint glow along full length
    ddChainGlow.setStrokeWidth(10f);
    ddChainGlow.setColor(Color.argb(30, 160, 200, 255));
    c.drawLine(x1, y1, x2, y2, ddChainGlow);

    // Chain links
    float linkLen = 16f;
    float halfW   = 4.5f;      // half-width of a cross link
    int linkCount = Math.max(1, (int)(len / linkLen));
    float actualLinkLen = len / linkCount;
    float halfL = actualLinkLen * 0.42f;

    // ddChainDark pre-allocated

    // ddChainLight pre-allocated

    for (int i = 0; i < linkCount; i++) {
        float t = (i + 0.5f) / linkCount;
        float mx = x1 + nx * len * t;
        float my = y1 + ny * len * t;

        if (i % 2 == 0) {
            // Horizontal link (along chain axis)
            float lx0 = mx - nx * halfL, ly0 = my - ny * halfL;
            float lx1 = mx + nx * halfL, ly1 = my + ny * halfL;
            ddChainDark.setStrokeWidth(5.5f);
            ddChainDark.setColor(Color.argb(230, 90, 100, 115));
            c.drawLine(lx0, ly0, lx1, ly1, ddChainDark);
            ddChainLight.setStrokeWidth(2.5f);
            ddChainLight.setColor(Color.argb(200, 210, 220, 240));
            c.drawLine(lx0, ly0, lx1, ly1, ddChainLight);
        } else {
            // Cross link (perpendicular)
            float cx0 = mx - px * halfW, cy0 = my - py * halfW;
            float cx1 = mx + px * halfW, cy1 = my + py * halfW;
            ddChainDark.setStrokeWidth(5.5f);
            ddChainDark.setColor(Color.argb(230, 70, 80, 95));
            c.drawLine(cx0, cy0, cx1, cy1, ddChainDark);
            ddChainLight.setStrokeWidth(2.5f);
            ddChainLight.setColor(Color.argb(180, 190, 200, 220));
            c.drawLine(cx0, cy0, cx1, cy1, ddChainLight);
        }
    }
}

public void render(GameState state, Canvas c){
    if(c==null) return;
    doDraw(state, c);
}

private void doDraw(GameState state, Canvas c){
    c.drawRect(0,0,c.getWidth(),c.getHeight(),bgP);
    c.save();
    c.scale(state.currentZoom, state.currentZoom);   // per-weapon camera zoom
    c.translate(-state.camX,-state.camY);

    for(float x=0;x<=MAP_W;x+=120) c.drawLine(x,0,x,MAP_H,gridP);
    for(float y=0;y<=MAP_H;y+=120) c.drawLine(0,y,MAP_W,y,gridP);
    c.drawRect(0,0,MAP_W,MAP_H,bdrP);

    for(float[] w:WALLS) c.drawRect(w[0],w[1],w[2],w[3],wallP);

    // ── Effects drawn BEHIND players (explosions, hit flashes, dash ghost trails)
    state.effects.drawBehindPlayers(c);

    for(Player p:state.remote.values()) drawPlayer(c,p,false);
    Player lp=state.localPlayer;
    if(lp!=null) drawPlayer(c,lp,true);

    // ── Effects drawn IN FRONT of players (crescent appears on top of player body)
    state.effects.drawInFrontOfPlayers(c);

    // ── Status-effect particles (slow mist, poison fumes, stun arcs — on top of players)
    if (GunConfig.ShowStatusEffectVisuals) state.effects.drawStatusParticles(c);

    // ── Bullets (drawn on top of all players and state.effects)
    drawHookChains(c);    // chains connect hook spears to owner (flight phase)
    drawPullRopes(c);     // chains remain visible during pull phase
    state.effects.drawBullets(c, state.bullets);

    // Aim line (world-space dashed line) — hidden while a hook spear is in flight
    boolean hookInFlight = false;
    if (lp != null) { for (Bullet b : state.bullets) { if (b.hookSpear && b.ownerId == lp.id) { hookInFlight = true; break; } } }
    if(lp!=null && lp.alive && !hookInFlight && cachedAimLine){
        float lineLen = 350f;
        float ex = lp.x + (float)Math.cos(lp.angle) * lineLen;
        float ey = lp.y + (float)Math.sin(lp.angle) * lineLen;
        c.drawLine(lp.x,lp.y,ex,ey,ddAimLine); // pre-allocated, no new Paint
    }

    // Draw active bombs (world space)
    long nowDraw = System.currentTimeMillis();
    for (Bomb bomb : state.activeBombs) {
        // ── Spawn explosion FX once when bomb first detonates ─────────────
        if (bomb.explodedAt > 0 && state.spawnedBombFx.add(bomb.explodedAt)) {
            state.effects.spawnBombExplosion(bomb.x, bomb.y);
        }

        if (bomb.isFlashing()) {
            // explosion FX handled by EffectsManager; nothing extra needed here
        } else if (bomb.explodedAt < 0) {
            if (!bomb.hasLanded) {
                // ── Flying: draw a shadow + emoji to indicate arc ─────────
                // Shadow grows as bomb approaches max range (shows distance)
                float travel = (float)Math.sqrt(bomb.traveledSq()) / Bomb.THROW_RANGE;
                float shadowR = 8f + 22f * travel;
                ddBombShadow.setColor(Color.argb((int)(120 * (1f - travel * 0.5f)), 0, 0, 0));
                c.drawCircle(bomb.x, bomb.y, shadowR, ddBombShadow);
                // Emoji slightly offset upward to simulate height
                float bounce = -(float)Math.sin(travel * Math.PI) * 40f;
                c.drawText("\uD83D\uDCA3", bomb.x, bomb.y + bounce + 12f, ddBombFly);
            } else {
                // ── Landed: emoji + pulsing danger ring showing blast radius ─
                long fuseAge   = nowDraw - bomb.deployTime;
                float fuseFrac = Math.min(1f, fuseAge / (float) Bomb.FUSE_MS);
                // pulse rate doubles as fuse runs out
                float pulse = 0.45f + 0.55f * (float)Math.abs(Math.sin(fuseAge / (200f - fuseFrac * 120f)));
                int dangerA = (int)(100 + 80 * pulse);
                ddBombDangerFill.setColor(Color.argb((int)(dangerA * 0.35f), 255, 50, 0));
                c.drawCircle(bomb.x, bomb.y, Bomb.RADIUS, ddBombDangerFill);
                ddBombDangerRing.setStrokeWidth(3f + 2f * pulse);
                ddBombDangerRing.setColor(Color.argb(dangerA, 255, 80, 0));
                c.drawCircle(bomb.x, bomb.y, Bomb.RADIUS, ddBombDangerRing);
                c.drawText("\uD83D\uDCA3", bomb.x, bomb.y + 12f, ddBombEmoji);
            }
        }
    }

    // ── Air Strike ring + orb (joystick-mag maps to target distance) ─────
    if (lp != null && lp.alive && lp.currentGun().bulletAirStrike) {
        boolean aimActive = aimStick != null && aimStick.isActive();
        boolean hasAngle  = !Float.isNaN(state.asAimAngle);
        boolean reloading = lp.currentGun().reloading;
        if (reloading) {
            // Show greyed-out ring + RELOADING label to signal aim is locked
            c.drawCircle(lp.x, lp.y, AS_RING_R, ddAsReloadRing);
            c.drawText("RELOADING — CAN'T AIM", lp.x, lp.y - AS_RING_R - 20f, ddAsReloadLbl);
        } else if (aimActive && hasAngle) {
            float ringR = AS_RING_R; // fixed size, no pulse

            // Big ring around player
            c.drawCircle(lp.x, lp.y, ringR, ddAsAimRing);
            c.drawCircle(lp.x, lp.y, ringR, fill(Color.argb(18, 224, 64, 251)));

            // Small orb: distance = state.asAimMag * ring radius (joystick center = at player)
            float orbDist = state.asAimMag * ringR;
            float orbX = lp.x + (float)Math.cos(state.asAimAngle) * orbDist;
            float orbY = lp.y + (float)Math.sin(state.asAimAngle) * orbDist;
            float ORB_R = 26f;

            // Glow + body + dot
            c.drawCircle(orbX, orbY, ORB_R * 1.7f, fill(Color.argb(70, 224, 64, 251)));
            c.drawCircle(orbX, orbY, ORB_R,         fill(Color.argb(230, 224, 64, 251)));
            c.drawCircle(orbX, orbY, ORB_R * 0.38f, fill(Color.WHITE));

            // Dashed connector: player to orb
            c.drawLine(lp.x, lp.y, orbX, orbY, ddAsAimConn);

            // Strike zone preview: circle showing explosion radius
            float zoneR = AS_RADIUS * 0.75f; // smaller preview circle
            c.drawCircle(orbX, orbY, zoneR, ddAsAimPrev);
            c.drawCircle(orbX, orbY, zoneR, fill(Color.argb(25, 255, 200, 50)));
            // Center crosshair on orb
            c.drawLine(orbX - 16, orbY, orbX + 16, orbY, ddAsAimXh);
            c.drawLine(orbX, orbY - 16, orbX, orbY + 16, ddAsAimXh);
        }
    }

    // Draw Air Strike targets and explosions (world space)
    long asNow = System.currentTimeMillis();
    for (double[] as : state.airStrikes) {
        float sx = (float) as[0], sy = (float) as[1];
        long trigMs = (long) as[2];
        long flashUntil = (long) as[4];
        boolean exploding = flashUntil > 0L && asNow < flashUntil;
        boolean pending   = asNow < trigMs;

        if (exploding) {
            // Spawn the full bomb-style explosion FX once when detonation starts
            if (state.spawnedAirStrikeFx.add(flashUntil)) {
                state.effects.spawnBombExplosion(sx, sy);
            }
            // (drawing handled by EffectsManager.drawBombExplosions)
        } else if (pending) {
            // Incoming warning: fixed danger ring visible to all players
            float countdown = Math.max(0f, (trigMs - asNow) / (float) AS_WARNING_MS);
            int ra = (int)(220 * (1f - countdown * 0.4f));
            // Outer danger ring (fixed size)
            ddAsDangerRing.setColor(Color.argb(ra, 255, 50, 50));
            c.drawCircle(sx, sy, AS_RADIUS, ddAsDangerRing);
            // Danger fill (gets brighter as time runs out)
            c.drawCircle(sx, sy, AS_RADIUS, fill(Color.argb((int)(ra * 0.18f), 255, 50, 50)));
            // Warning text above
            ddAsWarn.setColor(Color.argb(ra, 255, 80, 80));
            c.drawText("⚠", sx, sy - AS_RADIUS - 8f, ddAsWarn);
            ddAsCross.setColor(Color.argb(ra, 255, 100, 100));
            c.drawLine(sx - 12, sy, sx + 12, sy, ddAsCross);
            c.drawLine(sx, sy - 12, sx, sy + 12, ddAsCross);
        }
    }
    // ── Throw preview arc (world space) ──────────────────────────────────
    if (state.throwingBomb && lp != null && lp.alive && aimStick != null) {
        float tax = aimStick.getX(), tay = aimStick.getY();
        float tmag = (float) Math.sqrt(tax * tax + tay * tay);
        if (tmag > 0.08f) {
            float landX = lp.x + tax * Bomb.THROW_RANGE;
            float landY = lp.y + tay * Bomb.THROW_RANGE;
            // Dashed trajectory line (pre-allocated paint, no alloc)
            c.drawLine(lp.x, lp.y, landX, landY, ddBombArc);
            // (blast radius preview circles removed)
            // Landing bullseye
            ddBombDot.setColor(Color.argb(230, 255, 220, 0));
            c.drawCircle(landX, landY, 10f, ddBombDot);
        }
    }

    // ── Volt Chakrams (drawn in world space, on top of everything) ───────
    drawVoltChakrams(c);

    c.restore();

    drawHUD(c);
}

private void drawPlayer(GameState state, Canvas c, Player p, boolean local){
    // Resolve render position — bots use a visual-only dash interpolation
    float rx = p.x, ry = p.y;
    if (!local) {
        float[] bv = state.botDashVisual.get(p.id);
        if (bv != null) {
            float bt = Math.min(1f, (float)((System.currentTimeMillis() - EffectsManager.FX_EPOCH) - (long)bv[4]) / EffectsManager.DASH_ANIM_MS);
            float ease = 1f - (1f - bt) * (1f - bt) * (1f - bt);
            rx = bv[0] + (bv[2] - bv[0]) * ease;
            ry = bv[1] + (bv[3] - bv[1]) * ease;
        }
    }
    if(!p.alive){
        // Reuse dpShadow as the death-X paint
        dpShadow.setColor(Color.argb(160,230,50,50));
        dpShadow.setStyle(Paint.Style.STROKE); dpShadow.setStrokeWidth(4f);
        c.drawLine(rx-13,ry-13,rx+13,ry+13,dpShadow);
        c.drawLine(rx+13,ry-13,rx-13,ry+13,dpShadow);
        dpShadow.setStyle(Paint.Style.FILL); // restore
        return;
    }
    // Stealth: state.remote players are invisible (skip draw); local is translucent
    if (!local && p.isStealthed()) return;
    int stealthAlpha = (local && p.isStealthed()) ? 100 : 255;
    float r=PR;
    dpShadow.setColor(Color.argb(stealthAlpha*65/255, 0, 0, 0));
    c.drawCircle(rx+4,ry+4,r,dpShadow);
    // Dummies: grey body, no gun line, different name style
    boolean isDummy = state.dummyIds.contains(p.id);
    if (isDummy) dpBody.setColor(Color.argb(stealthAlpha, 140, 140, 140));
    else if (local) { dpBody.setColor(locP.getColor()); dpBody.setAlpha(stealthAlpha); }
    else            { dpBody.setColor(remP.getColor()); dpBody.setAlpha(stealthAlpha); }
    c.drawCircle(rx,ry,r,dpBody);
    dpBody.setAlpha(255); // restore
    if (!isDummy) {
        float gl=r+20f;
        int barrelCol = p.currentGun().color;
        dpGun.setColor(barrelCol); dpGun.setAlpha(stealthAlpha);
        c.drawLine(rx,ry,rx+(float)Math.cos(p.angle)*gl,ry+(float)Math.sin(p.angle)*gl,dpGun);
        dpGun.setAlpha(255); // restore
    }
    float bw=50f,bh=6f,bx=rx-25f,by=ry-r-14f;
    c.drawRoundRect(bx,by,bx+bw,by+bh,3,3,hpBgP);
    float fr=Math.max(0,p.hp/100f);
    dpHpFill.setColor(fr>0.5f?Color.rgb(50,220,50):fr>0.25f?Color.rgb(240,175,0):Color.rgb(230,50,50));
    c.drawRoundRect(bx,by,bx+bw*fr,by+bh,3,3,dpHpFill);
    dpName2.set(nameP); dpName2.setAlpha(stealthAlpha);
    if (isDummy) {
        dpName2.setColor(Color.argb(180, 180, 180, 180));
        dpName2.setTypeface(Typeface.defaultFromStyle(Typeface.ITALIC));
    }
    c.drawText(p.name, rx, ry-r-17f, dpName2);
    // Volt Chakram charge arc — drawn around the player when charging
    if (local && isVoltChakram(p.currentGun()) && state.voltCharge > 0.02f) {
        float sweep = state.voltCharge * 360f;
        dpCharge.setStrokeWidth(4.5f);
        int chargeAlpha = (int)(180 + state.voltCharge * 75);
        dpCharge.setColor(Color.argb(chargeAlpha, 100, 220, 255));
        float arcR = r + 14f;
        RectF arcRect = new RectF(rx - arcR, ry - arcR, rx + arcR, ry + arcR);
        c.drawArc(arcRect, -90f, sweep, false, dpCharge);
        // Bright tip dot at the leading edge
        float tipAngle = (float) Math.toRadians(-90f + sweep);
        float tipX = rx + arcR * (float) Math.cos(tipAngle);
        float tipY = ry + arcR * (float) Math.sin(tipAngle);
        // dpTip pre-allocated
        dpTip.setColor(Color.argb(230, 180, 240, 255));
        c.drawCircle(tipX, tipY, 5f, dpTip);
    }
    // Shadow Blade charge arc — color shifts per tier; state.tick marks at T2/T3 thresholds
    if (local && isShadowBlade(p.currentGun()) && state.shadowBladeCharge > 0.02f) {
        float sweep   = state.shadowBladeCharge * 360f;
        long  nowSb   = System.currentTimeMillis();
        float sbArcR  = r + 14f;
        RectF sbRect  = new RectF(rx - sbArcR, ry - sbArcR, rx + sbArcR, ry + sbArcR);
        int   sbAlpha = (int)(170 + state.shadowBladeCharge * 85);

        // Arc color: red (T1) → orange (T2) → white-gold (T3)
        int arcR, arcG, arcB;
        if (state.shadowBladeCharge < 0.40f) {
            arcR = 255; arcG = 30;  arcB = 70;   // crimson
        } else if (state.shadowBladeCharge < 0.85f) {
            float t = (state.shadowBladeCharge - 0.40f) / 0.45f;
            arcR = 255; arcG = (int)(30 + t * 140); arcB = (int)(70 * (1f - t)); // red→orange
        } else {
            float t = (state.shadowBladeCharge - 0.85f) / 0.15f;
            arcR = 255; arcG = (int)(170 + t * 70); arcB = (int)(t * 120); // orange→gold
        }
        dpSbCharge.setStrokeWidth(4.5f);
        dpSbCharge.setColor(Color.argb(sbAlpha, arcR, arcG, arcB));
        c.drawArc(sbRect, -90f, sweep, false, dpSbCharge);

        // Tier state.tick marks at 40% and 85%
        float[] ticks = {0.40f, 0.85f};
        for (float t : ticks) {
            float tickAngle = (float) Math.toRadians(-90f + t * 360f);
            float tx = rx + sbArcR * (float) Math.cos(tickAngle);
            float ty = ry + sbArcR * (float) Math.sin(tickAngle);
            boolean past = state.shadowBladeCharge >= t;
            dpSbTick.setColor(past ? Color.argb(220, 255, 255, 255) : Color.argb(130, 180, 180, 180));
            c.drawCircle(tx, ty, past ? 4.5f : 3f, dpSbTick);
        }

        // Bright tip dot
        float sbTipAngle = (float) Math.toRadians(-90f + sweep);
        float sbTipX = rx + sbArcR * (float) Math.cos(sbTipAngle);
        float sbTipY = ry + sbArcR * (float) Math.sin(sbTipAngle);
        dpSbTip.setColor(Color.argb(235, 255, 230, 180));
        c.drawCircle(sbTipX, sbTipY, 5.5f, dpSbTip);

        // Tier name label below the player — updates in real time as charge builds
        String tierName;
        int    tierR, tierG, tierB;
        if (state.shadowBladeCharge < 0.40f) {
            tierName = "LIGHT SLASH";  tierR = 255; tierG = 80;  tierB = 100;
        } else if (state.shadowBladeCharge < 0.85f) {
            tierName = "HEAVY SLASH";  tierR = 255; tierG = 160; tierB = 30;
        } else {
            tierName = "PHANTOM DASH"; tierR = 255; tierG = 220; tierB = 80;
        }
        dpTier.setTextSize(18f);
        dpTier.setTypeface(Typeface.DEFAULT_BOLD);
        dpTier.setColor(Color.argb(200, tierR, tierG, tierB));
        c.drawText(tierName, rx, ry + r + sbArcR + 22f, dpTier);
    }
    // Spawn protection ring
    if (p.isProtected()) {
        long rem = p.spawnProtectionUntil - System.currentTimeMillis();
        float pulse = 0.7f+0.3f*(float)Math.abs(Math.sin(System.currentTimeMillis()/200.0));
        dpProtRing.setStrokeWidth(4f*pulse);
        dpProtRing.setColor(Color.argb(Math.min(255,(int)(200*rem/800f)),100,200,255));
        c.drawCircle(rx,ry,(r+10)*pulse,dpProtRing);
    }
    // Shield ring
    if (p.isShielded()) {
        float pulse2 = 0.8f+0.2f*(float)Math.abs(Math.sin(System.currentTimeMillis()/150.0));
        dpShRing.setColor(Color.argb(200,255,200,0));
        c.drawCircle(rx,ry,(r+14)*pulse2,dpShRing);
    }
    // ── Status-effect particle spawning (visuals only — state.effects always active) ──
    // Circles/rings removed; particles are drawn via state.effects.drawStatusParticles().
    if (GunConfig.ShowStatusEffectVisuals) {
        if (p.isSlowed())                         state.effects.spawnSlowParticles(rx, ry, r);
        if (p.isPoisoned())                       state.effects.spawnPoisonParticles(rx, ry, r);
        if (p.isStunned() || p.isBeingPulled())   state.effects.spawnStunParticles(rx, ry, r);
    }
}

private void drawHUD(GameState state, Canvas c){
    Player lp=state.localPlayer;
    // Show connecting screen while waiting for server response (client only)
    if(lp==null){
        if(!state.isHost){
            float w=screenW, h=screenH;
            c.drawRect(0,0,w,h,fill(Color.argb(180,0,0,0)));
            Paint tp=fill(Color.WHITE); tp.setTextSize(32f); tp.setTextAlign(Paint.Align.CENTER);
            tp.setTypeface(Typeface.DEFAULT_BOLD); tp.setShadowLayer(4f,0,2f,Color.BLACK);
            c.drawText("Connecting to host…", w/2, h/2-20, tp);
            Paint tp2=fill(Color.argb(200,180,210,255)); tp2.setTextSize(18f); tp2.setTextAlign(Paint.Align.CENTER);
            c.drawText("Make sure you're on the host's hotspot", w/2, h/2+24, tp2);
        }
        return;
    }
    float w=screenW, h=screenH;

    // ── HP ────────────────────────────────────────────────────────────────
    c.drawRoundRect(10,10,215,56,8,8,hudBgP);
    hudP.setColor(Color.rgb(255,75,75)); hudP.setTextSize(27f); hudP.setTextAlign(Paint.Align.LEFT);
    c.drawText("♥ "+(int)Math.ceil(lp.hp), 22, 46, hudP);

    // ── Coins ─────────────────────────────────────────────────────────────
    c.drawRoundRect(222,10,355,56,8,8,hudBgP);
    Paint coinP2=fill(Color.rgb(255,210,50)); coinP2.setTextSize(22f);
    coinP2.setTextAlign(Paint.Align.LEFT); coinP2.setTypeface(Typeface.DEFAULT_BOLD);
    c.drawText("\uD83D\uDCB0 "+lp.coins, 234, 44, coinP2);

    // ── Kill streak badge ──────────────────────────────────────────────────
    if (!state.singlePlayer && lp.killStreak >= 2) {
        int ksColor;
        if      (lp.killStreak >= 10) ksColor = Color.argb(240, 255, 50,  50);
        else if (lp.killStreak >= 5)  ksColor = Color.argb(240, 255, 140, 20);
        else                          ksColor = Color.argb(240, 255, 210, 30);
        c.drawRoundRect(362,10,490,56,8,8,fill(Color.argb(160,20,10,5)));
        Paint ksPaint = fill(ksColor); ksPaint.setTextSize(21f);
        ksPaint.setTextAlign(Paint.Align.LEFT); ksPaint.setTypeface(Typeface.DEFAULT_BOLD);
        ksPaint.setShadowLayer(3f, 0, 1f, Color.BLACK);
        String bonusPct = "+" + Math.round(lp.killStreak * 3) + "%";
        c.drawText("\uD83D\uDD25" + lp.killStreak + "  " + bonusPct, 374, 43, ksPaint);
    }

    // ── Difficulty / mode badge ────────────────────────────────────────────
    if (state.singlePlayer) {
        String dlbl;
        int    dcol;
        if (state.trainingMode) {
            dlbl = "TRAINING"; dcol = 0xFF22aa66;
        } else {
            String[] diffLabels = {"EASY", "NORMAL", "HARD"};
            int[]    diffColors = {0xFF2ecc71, 0xFFe94560, 0xFF8855ee};
            dlbl = diffLabels[Math.max(0, Math.min(2, difficulty))];
            dcol = diffColors[Math.max(0, Math.min(2, difficulty))];
        }
        Paint diffP = fill(dcol); diffP.setTextSize(17f);
        diffP.setTextAlign(Paint.Align.LEFT); diffP.setTypeface(Typeface.DEFAULT_BOLD);
        diffP.setShadowLayer(3f,1f,1f,Color.BLACK);
        float dlblW = diffP.measureText(dlbl);
        c.drawRoundRect(362, 14, 362 + dlblW + 18, 52, 8, 8, fill(Color.argb(140,0,0,0)));
        c.drawText(dlbl, 371, 43, diffP);
    }

    // ── Gun + ammo ────────────────────────────────────────────────────────
    if(lp.alive){
        Gun g=lp.currentGun();
        String ammoStr = g.reloading ? "RELOADING…" : (g.ammo+"/"+g.maxAmmo);
        // Background panel – taller to fit stat bars when shown
        boolean showGunStats = cachedGunStats;
        boolean isSbHud = lp.gunIndex == 21;
        c.drawRoundRect(w/2-195,6,w/2+195,showGunStats?106:(isSbHud?68:52),10,10,hudBgP);
        // Gun name + ammo
        gunTxtP.setColor(g.color);
        c.drawText(g.name+"   "+ammoStr, w/2, 36, gunTxtP);
        // Soul Surge: show tier and kill progress
        if (lp.gunIndex == 20) {
            int lv = g.soulLevel();
            int next = g.soulNextThreshold();
            String[] tierNames = {
                "☠ DORMANT", "☠ AWAKENED", "☠ PIERCING", "☠ BOUNCING",
                "☠ SEEKING", "☠ UNSTOPPABLE", "☠ ASCENDANT ★", "☠ AWAKENED ★★", "☠ UNLEASHED ★★★"
            };
            String soulLine = tierNames[Math.min(lv, tierNames.length - 1)]
                    + (next >= 0 ? "   (" + g.killCount + "/" + next + " souls)" : "  MAX POWER");
            dpSoul.setTextSize(15f); dpSoul.setTextAlign(Paint.Align.CENTER);
            int[] tierColors = {
                0xFF9E9E9E, 0xFFCE93D8, 0xFFBA68C8, 0xFFAB47BC,
                0xFF8E24AA, 0xFF6A0080, 0xFF4A0060, 0xFFD500F9, 0xFFFFD700
            };
            dpSoul.setColor(tierColors[Math.min(lv, tierColors.length - 1)]);
            c.drawText(soulLine, w/2f, 50f, dpSoul);
        }
        // Shadow Blade: show charge bar + tier name in HUD panel
        if (lp.gunIndex == 21) {
            float sbBarW = 320f, sbBarH = 9f;
            float sbBarX = w / 2f - sbBarW / 2f;
            float sbBarY = 48f;

            // Tier colors: crimson T1, orange T2, gold T3
            int sbR, sbG, sbB;
            String sbTierLabel;
            if (state.shadowBladeCharge < 0.40f) {
                sbR = 255; sbG = 30;  sbB = 70;
                sbTierLabel = "LIGHT SLASH";
            } else if (state.shadowBladeCharge < 0.85f) {
                float t = (state.shadowBladeCharge - 0.40f) / 0.45f;
                sbR = 255; sbG = (int)(30 + t * 140); sbB = (int)(70 * (1f - t));
                sbTierLabel = "HEAVY SLASH";
            } else {
                float t = (state.shadowBladeCharge - 0.85f) / 0.15f;
                sbR = 255; sbG = (int)(170 + t * 70); sbB = (int)(t * 120);
                sbTierLabel = "PHANTOM DASH";
            }

            // Bar background
            Paint sbBgP = fill(Color.argb(80, 255, 255, 255));
            c.drawRoundRect(sbBarX, sbBarY, sbBarX + sbBarW, sbBarY + sbBarH, 4, 4, sbBgP);

            // Bar fill (only if charging)
            if (state.shadowBladeCharge > 0.01f) {
                Paint sbFillP = fill(Color.argb(220, sbR, sbG, sbB));
                c.drawRoundRect(sbBarX, sbBarY, sbBarX + sbBarW * state.shadowBladeCharge, sbBarY + sbBarH, 4, 4, sbFillP);
            }

            // Tier threshold state.tick marks at 40% and 85%
            float[] sbTicks = {0.40f, 0.85f};
            for (float t : sbTicks) {
                float tx = sbBarX + sbBarW * t;
                Paint sbTickP = fill(state.shadowBladeCharge >= t
                        ? Color.argb(220, 255, 255, 255) : Color.argb(120, 160, 160, 160));
                c.drawRect(tx - 1f, sbBarY - 2f, tx + 1f, sbBarY + sbBarH + 2f, sbTickP);
            }

            // Tier label (right of bar, colored)
            // dpSbLbl pre-allocated
            dpSbLbl.setTextSize(13f);
            dpSbLbl.setTextAlign(Paint.Align.CENTER);
            sbLblP.setTypeface(Typeface.DEFAULT_BOLD);
            dpSbLbl.setColor(state.shadowBladeCharge > 0.01f
                    ? Color.argb(210, sbR, sbG, sbB) : Color.argb(120, 180, 180, 180));
            c.drawText(state.shadowBladeCharge > 0.01f ? sbTierLabel : "HOLD AIM TO CHARGE",
                    w / 2f, sbBarY + sbBarH + 14f, dpSbLbl);
        }
        // Stat bars: DMG | SPD | RANGE | RATE
        if(showGunStats){
        String[] statNames = {"DMG","SPD","RANGE","RATE"};
        float[]  statVals  = {g.statDamage(), g.statSpeed(), g.statRange(), g.statFireRate()};
        int[]    statColors= {0xFFFF5252, 0xFF64B5F6, 0xFF81C784, 0xFFFFD54F};
        float barW=68f, barH=9f, gap=10f;
        float totalW = statNames.length*(barW+gap)-gap;
        float barX = w/2 - totalW/2;
        float barY = 55f;
        for(int si=0;si<statNames.length;si++){
            float sx = barX + si*(barW+gap);
            c.drawRoundRect(sx,barY, sx+barW,barY+barH, 4,4, hudStatBgP);
            tmpRectF.set(sx,barY, sx+barW*statVals[si],barY+barH);
            Paint fp=fill(statColors[si]); // color varies per stat — keep fill() here
            c.drawRoundRect(tmpRectF, 4,4, fp);
            c.drawText(statNames[si], sx, barY+barH+14f, hudStatLblP);
        }
        }
    }

    // ── HOST: show IP so others can join ──────────────────────────────────
    if(state.isHost && !state.hostIpDisplay.isEmpty()){
        int count=state.remote.size()+1;
        String ipLine="Your IP: "+state.hostIpDisplay+"   Players: "+count;
        float bgW=ipPaint.measureText(ipLine)+24f;
        c.drawRoundRect(w/2-bgW/2,h-52,w/2+bgW/2,h-4,10,10,hudBgP);
        c.drawText(ipLine, w/2, h-14, ipPaint);
    }

    // ── Kill state.feed ─────────────────────────────────────────────────────────
    hudP.setColor(Color.rgb(255,210,70)); hudP.setTextSize(18f); hudP.setTextAlign(Paint.Align.LEFT);
    synchronized(state.feed){ for(int i=0;i<state.feed.size();i++) c.drawText(state.feed.get(i),12,72+i*24,hudP); }

    // ── Multiplayer scoreboard ─────────────────────────────────────────────
    if (!state.singlePlayer) {
        // Collect all players: local + state.remote (excluding bots/dummies)
        java.util.List<Player> sbPlayers = new java.util.ArrayList<>();
        sbPlayers.add(lp);
        for (Player rp : state.remote.values()) {
            if (!state.dummyIds.contains(rp.id)) sbPlayers.add(rp);
        }
        // Sort by kills desc, then deaths asc
        sbPlayers.sort((a2, b2) -> a2.kills != b2.kills ? b2.kills - a2.kills : a2.deaths - b2.deaths);

        float sbX = w - 260f, sbY = 14f;
        float rowH = 32f, colW = 260f;
        float headerH = 28f;
        float sbH = headerH + sbPlayers.size() * rowH + 10f;

        // Panel background
        c.drawRoundRect(sbX, sbY, sbX + colW, sbY + sbH, 10, 10,
                fill(Color.argb(170, 8, 12, 28)));

        // Header row
        hudSbHdrP.setTextAlign(Paint.Align.LEFT);
        c.drawText("PLAYER", sbX + 10f, sbY + 20f, hudSbHdrP);
        hudSbHdrP.setTextAlign(Paint.Align.CENTER);
        c.drawText("K", sbX + colW - 100f, sbY + 20f, hudSbHdrP);
        c.drawText("D", sbX + colW - 65f,  sbY + 20f, hudSbHdrP);
        c.drawText("STRK", sbX + colW - 20f, sbY + 20f, hudSbHdrP);

        // Separator
        Paint sepP = fill(Color.argb(80, 100, 140, 220));
        c.drawRect(sbX + 6f, sbY + headerH, sbX + colW - 6f, sbY + headerH + 1.5f, sepP);

        for (int si = 0; si < sbPlayers.size(); si++) {
            Player sp2 = sbPlayers.get(si);
            float ry = sbY + headerH + 6f + si * rowH;
            boolean isMe = (sp2 == lp);

            // Row highlight for local player
            if (isMe) {
                c.drawRoundRect(sbX + 4f, ry - 2f, sbX + colW - 4f, ry + rowH - 4f, 6, 6,
                        fill(Color.argb(60, 100, 160, 255)));
            }

            // Streak badge color
            int streakColor;
            if      (sp2.killStreak >= 10) streakColor = Color.argb(255, 255, 80,  80);
            else if (sp2.killStreak >= 5)  streakColor = Color.argb(255, 255, 160, 30);
            else if (sp2.killStreak >= 3)  streakColor = Color.argb(255, 255, 220, 50);
            else                           streakColor = Color.argb(180, 180, 180, 180);

            hudSbNameP.setColor(isMe ? Color.WHITE : Color.argb(210, 200, 210, 230));
            hudSbNameP.setTypeface(isMe ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
            // Truncate long names
            String dname = sp2.name.length() > 10 ? sp2.name.substring(0, 10) + "…" : sp2.name;
            c.drawText(dname, sbX + 10f, ry + 20f, hudSbNameP);

            // Kills (green tint)
            hudSbNumP.setColor(Color.argb(230, 100, 255, 120));
            c.drawText(String.valueOf(sp2.kills), sbX + colW - 100f, ry + 20f, hudSbNumP);
            // Deaths (red tint)
            hudSbNumP.setColor(Color.argb(200, 255, 110, 110));
            c.drawText(String.valueOf(sp2.deaths), sbX + colW - 65f, ry + 20f, hudSbNumP);
            // Streak (colored by level)
            hudSbNumP.setColor(streakColor);
            String streakTxt = sp2.killStreak > 0 ? "🔥" + sp2.killStreak : "-";
            c.drawText(streakTxt, sbX + colW - 20f, ry + 20f, hudSbNumP);
        }
    }

    // ── Disconnect overlay ─────────────────────────────────────────────────
    if(!state.singlePlayer && !state.isHost && net!=null && net.isDisconnected()){
        // Pulsing amber banner across the top
        long now2=System.currentTimeMillis();
        int pulse=(int)(180+75*Math.abs(Math.sin(now2/500.0)));
        Paint discBg=fill(Color.argb(Math.min(255,pulse),120,40,0));
        c.drawRoundRect(w*0.1f,14,w*0.9f,66,12,12,discBg);
        uiTxt.setColor(Color.WHITE); uiTxt.setTextSize(22f);
        uiTxt.setTextAlign(Paint.Align.CENTER);
        uiTxt.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        uiTxt.setShadowLayer(4f,0,1f,Color.BLACK);
        c.drawText("\u26A0 DISCONNECTED \u2014 Reconnecting\u2026",w/2,48,discTxt);
    }

    // ── Death overlay ─────────────────────────────────────────────────────
    if(!lp.alive){
        c.drawRect(0,0,w,h,deathBgP);
        c.drawText("YOU DIED",w/2,h/2-18,deathTxtP);
        long rem=RESPAWN_MS-(System.currentTimeMillis()-state.deathTime);
        if(rem>0){
            uiCopy.set(deathTxtP); uiCopy.setTextSize(28f); uiCopy.setColor(Color.WHITE);
            uiCopy.setTextAlign(Paint.Align.CENTER);
            c.drawText("Respawning in "+(rem/1000+1)+"s",w/2,h/2+38,uiCopy);
        }
    }

    // ── Buttons ───────────────────────────────────────────────────────────
    // Weapon wheel — gear icon circle
    { float _scx=switchRect.centerX(), _scy=switchRect.centerY(), _sr=switchRect.width()/2f;
      c.drawCircle(_scx, _scy, _sr, btnP);
      uiCopy.set(btnTxtP); uiCopy.setTextSize(_sr * 0.70f);
      c.drawText("⚙", _scx, _scy + _sr*0.25f, uiCopy); }

    // Reload button — icon only (no text), shows reload arc progress when reloading
    { boolean asLocked = lp != null && lp.currentGun().bulletAirStrike;
      float _rcx = reloadRect.centerX(), _rcy = reloadRect.centerY();
      float _rr = Math.min(reloadRect.width(), reloadRect.height()) / 2f;
      if (asLocked) {
          c.drawCircle(_rcx, _rcy, _rr, fill(Color.argb(70, 55, 55, 65)));
          uiP.setTextSize(_rr * 1.05f); uiP.setTextAlign(Paint.Align.CENTER);
          uiP.setColor(Color.argb(110, 190, 190, 190));
          c.drawText("\uD83D\uDD12", _rcx, _rcy + _rr * 0.38f, uiP);
      } else if (lp != null && lp.currentGun().reloading) {
          // Show cool progress arc while reloading
          long elapsed = System.currentTimeMillis() - (lp.currentGun().reloadStart);
          float effectiveReloadMs = lp.currentGun().reloadMs * lp.reloadMult();
          float progress = Math.min(1f, elapsed / effectiveReloadMs);
          c.drawCircle(_rcx, _rcy, _rr, fill(Color.argb(120, 40, 40, 60)));
          uiP.setStyle(Paint.Style.STROKE); uiP.setStrokeWidth(5f);
          uiP.setColor(Color.argb(80, 200, 200, 255)); uiP.setStrokeCap(Paint.Cap.ROUND);
          android.graphics.RectF arcRect = new android.graphics.RectF(_rcx-_rr+4, _rcy-_rr+4, _rcx+_rr-4, _rcy+_rr-4);
          c.drawArc(arcRect, -90f, 360f, false, uiP);
          uiCopy.set(uiP); uiCopy.setColor(Color.argb(230, 100, 200, 255));
          c.drawArc(arcRect, -90f, 360f * progress, false, uiCopy);
          uiTxt.setTextSize(_rr * 0.90f); uiTxt.setTextAlign(Paint.Align.CENTER);
          uiTxt.setColor(Color.argb(200, 100, 200, 255));
          c.drawText("↺", _rcx, _rcy + _rr * 0.35f, uiTxt);
      } else {
          c.drawCircle(_rcx, _rcy, _rr, btnP);
          uiTxt.setTextSize(_rr * 1.0f); uiTxt.setTextAlign(Paint.Align.CENTER);
          uiTxt.setColor(Color.WHITE); uiTxt.setTypeface(Typeface.DEFAULT_BOLD);
          uiTxt.setShadowLayer(3f, 0, 1f, Color.BLACK);
          c.drawText("↺", _rcx, _rcy + _rr * 0.38f, uiTxt);
      }
    }

    // Bomb button — circle with count badge
    if (bombRect != null && lp != null) {
        boolean hasBombs = lp.bombs > 0;
        float _bcx = bombRect.centerX(), _bcy = bombRect.centerY();
        float _br = Math.min(bombRect.width(), bombRect.height()) / 2f;
        Paint bombBtnP;
        if (state.throwingBomb) {
            bombBtnP = fill(Color.argb(230, 220, 160, 0));
        } else {
            bombBtnP = fill(hasBombs ? Color.argb(210, 200, 80, 0) : Color.argb(120, 60, 60, 60));
        }
        c.drawCircle(_bcx, _bcy, _br, bombBtnP);
        // Bomb emoji icon
        uiTxt.setTextSize(_br * 1.05f); uiTxt.setTextAlign(Paint.Align.CENTER); uiTxt.setColor(Color.WHITE);
        c.drawText(state.throwingBomb ? "✕" : "\uD83D\uDCA3", _bcx, _bcy + _br * 0.38f, uiTxt);
        // Count badge (top-right corner of circle)
        if (!state.throwingBomb && lp.bombs > 0) {
            float badgeX = _bcx + _br * 0.65f, badgeY = _bcy - _br * 0.65f;
            c.drawCircle(badgeX, badgeY, _br * 0.34f, fill(Color.argb(230, 50, 50, 50)));
            uiTxt.setTextSize(_br * 0.42f); uiTxt.setTextAlign(Paint.Align.CENTER);
            uiTxt.setColor(Color.WHITE); uiTxt.setTypeface(Typeface.DEFAULT_BOLD);
            c.drawText(String.valueOf(lp.bombs), badgeX, badgeY + _br * 0.14f, uiTxt);
        }
        // AIM hint
        if (state.throwingBomb) {
            Paint hintP = fill(Color.argb(200, 255, 230, 100));
            hintP.setTextSize(16f); hintP.setTextAlign(Paint.Align.CENTER);
            hintP.setShadowLayer(3f, 0, 1f, Color.BLACK);
            c.drawText("aim joystick \u2192 release", _bcx, bombRect.top - 8f, hintP);
        }
    }

    // Drop weapon button — trash icon
    if (dropRect != null && lp != null) {
        int unlockedCount = 0;
        for (boolean u : lp.unlockedGuns) if (u) unlockedCount++;
        boolean canDrop = unlockedCount > 1;
        float _dcx = dropRect.centerX(), _dcy = dropRect.centerY();
        float _dr = Math.min(dropRect.width(), dropRect.height()) / 2f;
        c.drawCircle(_dcx, _dcy, _dr, fill(canDrop ? Color.argb(200, 140, 40, 40) : Color.argb(80, 60, 60, 60)));
        uiTxt.setTextSize(_dr * 1.0f); uiTxt.setTextAlign(Paint.Align.CENTER);
        uiTxt.setColor(canDrop ? Color.WHITE : Color.argb(120, 180, 180, 180));
        uiTxt.setShadowLayer(2f, 0, 1f, Color.BLACK);
        c.drawText("\uD83D\uDDD1", _dcx, _dcy + _dr * 0.38f, uiTxt);
    }

    // Paint mode button — only visible when Paint Launcher is equipped
    if (paintModeRect != null && lp != null && lp.gunIndex == 15) {
        Gun pg = lp.currentGun();
        int pm = pg.paintMode; // 0=ALT, 1=SLOW, 2=POISON
        int[] pmColors = { Color.argb(220,0,188,212), Color.argb(220,30,100,220), Color.argb(220,30,180,70) };
        String[] pmEmoji  = { "🎨", "🐌", "☠" };
        String[] pmLabels = { "ALT", "SLOW", "POISON" };
        Paint pmBtnP = fill(pmColors[pm]);
        float _pmcx = paintModeRect.centerX(), _pmcy = paintModeRect.centerY();
        float _pmr = Math.min(paintModeRect.width(), paintModeRect.height()) / 2f;
        c.drawCircle(_pmcx, _pmcy, _pmr, pmBtnP);
        // Icon line
        uiTxt.setColor(Color.WHITE); uiTxt.setTextSize(20f);
        uiTxt.setTextAlign(Paint.Align.CENTER);
        uiTxt.setTypeface(Typeface.DEFAULT_BOLD);
        uiTxt.setShadowLayer(3f, 0, 1f, Color.BLACK);
        c.drawText(pmEmoji[pm], _pmcx, _pmcy - 5f, uiTxt);
        // Label line
        // uiCopy used for pmLblP
        pmLblP.setColor(Color.WHITE); pmLblP.setTextSize(13f);
        pmLblP.setTextAlign(Paint.Align.CENTER);
        pmLblP.setTypeface(Typeface.DEFAULT_BOLD);
        pmLblP.setShadowLayer(2f, 0, 1f, Color.BLACK);
        c.drawText(pmLabels[pm], _pmcx, _pmcy + _pmr - 8f, uiCopy);
    }

    // Active skill button
    if (skillRect != null && lp != null) {
        ui.drawSkillButton(c, lp);
    }

    // Spawn protection pulsing shield ring (screen-space around player circle)
    if (lp != null && lp.alive && lp.isProtected()) {
        long rem = lp.spawnProtectionUntil - System.currentTimeMillis();
        float pulse = 0.7f + 0.3f*(float)Math.abs(Math.sin(System.currentTimeMillis()/200.0));
        float alpha = Math.min(1f, rem/800f);
        // Draw in screen centre (player is always at centre of screen)
        float cx2 = screenW/2f, cy2 = screenH/2f;
        uiP.setStyle(Paint.Style.STROKE); uiP.setStrokeWidth(5f*pulse);
        uiP.setColor(Color.argb((int)(200*alpha),100,200,255));
        c.drawCircle(cx2, cy2, (PR*state.currentZoom+18)*pulse, uiP);
        // Timer text
        Paint protTxt = fill(Color.argb((int)(230*alpha),120,220,255));
        protTxt.setTextSize(16f); protTxt.setTextAlign(Paint.Align.CENTER);
        c.drawText("🛡 "+(rem/1000+1)+"s", cx2, cy2-(PR*state.currentZoom+32), protTxt);
    }

    // ── Gear button ───────────────────────────────────────────────────────
    if(gearRect!=null){
        Paint gearBg=fill(Color.argb(settingsOpen?210:140,40,50,80));
        c.drawRoundRect(gearRect,10,10,gearBg);
        uiTxt.setColor(Color.WHITE); uiTxt.setTextSize(26f);
        uiTxt.setTextAlign(Paint.Align.CENTER);
        c.drawText("⚙",gearRect.centerX(),gearRect.centerY()+10,uiTxt);
    }

    // ── Shop button ───────────────────────────────────────────────────────
    if(shopBtn!=null){
        Paint sbP=fill(Color.argb(shopOpen?210:150,160,120,10));
        c.drawRoundRect(shopBtn,10,10,sbP);
        uiTxt.setColor(Color.WHITE); uiTxt.setTextSize(22f); uiTxt.setTextAlign(Paint.Align.CENTER);
        c.drawText("\uD83D\uDED2",shopBtn.centerX(),shopBtn.centerY()+9,uiTxt);
    }

    // ── Joysticks ─────────────────────────────────────────────────────────
    if(moveStick!=null) moveStick.draw(c);
    if(aimStick!=null)  aimStick.draw(c);

    // ── Button-move mode overlay ───────────────────────────────────────────
    if(btnMoveMode){
        Paint dimP = fill(Color.argb(120,0,0,0));
        c.drawRect(0,0,w,h,dimP);
        // Redraw buttons with highlight — selected button glows differently
        Paint hlP    = fill(Color.argb(220,80,160,255));
        Paint hlSelP = fill(Color.argb(240,255,190,40)); // gold = currently selected for sizing
        boolean sizing = btnSizingId != -1;
        if(switchRect!=null){
            Paint p2 = (sizing && btnSizingId==0) ? hlSelP : hlP;
            float _scx=switchRect.centerX(),_scy=switchRect.centerY(),_sr=switchRect.width()/2f;
            c.drawCircle(_scx,_scy,_sr,p2);
            uiCopy.set(btnTxtP); uiCopy.setTextSize(_sr*0.70f);
            c.drawText("⚙",_scx,_scy+_sr*0.25f,uiCopy);
        }
        if(reloadRect!=null){
            Paint p2 = (sizing && btnSizingId==1) ? hlSelP : hlP;
            float _rcx=reloadRect.centerX(),_rcy=reloadRect.centerY(),_rr=Math.min(reloadRect.width(),reloadRect.height())/2f;
            c.drawCircle(_rcx,_rcy,_rr,p2);
            uiTxt.setTextSize(_rr*1.0f); uiTxt.setTextAlign(Paint.Align.CENTER); uiTxt.setColor(Color.WHITE);
            c.drawText("↺",_rcx,_rcy+_rr*0.38f,uiTxt);
        }
        if(dropRect!=null) {
            float _dcx=dropRect.centerX(),_dcy=dropRect.centerY(),_dr=Math.min(dropRect.width(),dropRect.height())/2f;
            c.drawCircle(_dcx,_dcy,_dr,hlP);
            uiTxt.setTextSize(_dr*1.0f); uiTxt.setTextAlign(Paint.Align.CENTER); uiTxt.setColor(Color.WHITE);
            c.drawText("\uD83D\uDDD1",_dcx,_dcy+_dr*0.38f,uiTxt);
        }
        if(bombRect!=null) {
            float _bcx=bombRect.centerX(),_bcy=bombRect.centerY(),_br=Math.min(bombRect.width(),bombRect.height())/2f;
            c.drawCircle(_bcx,_bcy,_br,hlP);
            uiTxt.setTextSize(_br*1.0f); uiTxt.setTextAlign(Paint.Align.CENTER); uiTxt.setColor(Color.WHITE);
            c.drawText("\uD83D\uDCA3",_bcx,_bcy+_br*0.38f,uiTxt);
        }
        if(paintModeRect!=null) {
            float _pmcx=paintModeRect.centerX(),_pmcy=paintModeRect.centerY(),_pmr=Math.min(paintModeRect.width(),paintModeRect.height())/2f;
            c.drawCircle(_pmcx,_pmcy,_pmr,fill(Color.argb(200,0,188,212))); c.drawText("🎨",_pmcx,_pmcy+8,btnTxtP);
        }
        if(skillRect!=null) {
            Paint p2 = (sizing && btnSizingId==5) ? hlSelP : hlP;
            float _scx=skillRect.centerX(),_scy=skillRect.centerY(),_sr=skillRect.width()/2f;
            c.drawCircle(_scx, _scy, _sr, p2);
            uiCopy.set(btnTxtP); uiCopy.setTextSize(_sr*0.38f);
            c.drawText("SKILL", _scx, _scy+8, uiCopy);
        }
        if(shopBtn!=null){
            c.drawRoundRect(shopBtn,10,10,hlP);
            uiTxt.setColor(Color.WHITE); uiTxt.setTextSize(22f); uiTxt.setTextAlign(Paint.Align.CENTER);
            c.drawText("\uD83D\uDED2",shopBtn.centerX(),shopBtn.centerY()+9,uiTxt);
        }
            // Instruction label
        Paint infoP = fill(Color.WHITE); infoP.setTextSize(20f); infoP.setTextAlign(Paint.Align.CENTER);
        infoP.setShadowLayer(3f,0,2f,Color.BLACK);
        c.drawText(sizing ? "Drag slider to resize  |  Drag button to move" : "Drag to move  |  Tap button to resize", w/2, h/2 - 20, infoP);

        // ── Training buttons (shown in move mode so they can be repositioned) ──
        if (state.trainingMode) {
            Paint thlP = fill(Color.argb(220, 100, 200, 130));
            String[] tLabels = {"+ Dummy", "- Dummy", "+200 Coins"};
            RectF[]  tRects  = {trainAddDummyBtn, trainRemDummyBtn, trainAddMoneyBtn};
            for (int i = 0; i < tRects.length; i++) {
                if (tRects[i] == null) continue;
                c.drawRoundRect(tRects[i], 10, 10, thlP);
                c.drawText(tLabels[i], tRects[i].centerX(), tRects[i].centerY()+8, btnTxtP);
            }
        }

        // ── Size slider (shown when a button is tapped) ───────────────────
        if(sizing && sizeSliderTrack != null) {
            // Derive current scale for label
            float curScale = 0.4f + sizeSliderVal * 1.8f;
            String btnName = btnSizingId==0 ? "⚙ WHEEL" : (btnSizingId==1 ? "RELOAD" : "SKILL");
            uiTxt.setColor(Color.argb(220,255,220,80)); uiTxt.setTextSize(19f);
            uiTxt.setTextAlign(Paint.Align.CENTER); uiTxt.setShadowLayer(3f,0,2f,Color.BLACK);
            c.drawText(btnName + "  SIZE: " + (int)(curScale*100) + "%",
                    sizeSliderTrack.centerX(), sizeSliderTrack.top - 14f, uiTxt);
            // Track background
            Paint trackBg = fill(Color.argb(180,30,40,80));
            c.drawRoundRect(sizeSliderTrack, 16f, 16f, trackBg);
            // Filled portion
            float knobX = sizeSliderTrack.left + sizeSliderVal * sizeSliderTrack.width();
            RectF filled = new RectF(sizeSliderTrack.left, sizeSliderTrack.top, knobX, sizeSliderTrack.bottom);
            Paint fillP = fill(Color.argb(220,80,180,255));
            c.drawRoundRect(filled, 16f, 16f, fillP);
            // Knob
            Paint knobP = fill(Color.argb(255,255,255,255));
            c.drawCircle(knobX, sizeSliderTrack.centerY(), sizeSliderTrack.height()*0.82f, knobP);
            // Min / Max labels
            uiCopy.setColor(Color.argb(180,200,200,200)); uiCopy.setTextSize(15f);
            uiCopy.setTextAlign(Paint.Align.LEFT);
            c.drawText("40%", sizeSliderTrack.left + 4, sizeSliderTrack.bottom + 18f, uiCopy);
            uiCopy.setTextAlign(Paint.Align.RIGHT);
            c.drawText("220%", sizeSliderTrack.right - 4, sizeSliderTrack.bottom + 18f, uiCopy);
        }

        // Confirm button
        if(confirmMoveRect!=null){
            Paint confP = fill(Color.argb(230,50,190,90));
            c.drawRoundRect(confirmMoveRect,12,12,confP);
            uiCopy.set(btnTxtP); uiCopy.setTextSize(24f);
            c.drawText("✓  DONE", confirmMoveRect.centerX(), confirmMoveRect.centerY()+9, uiCopy);
        }
    }

    // ── Weapon wheel overlay ──────────────────────────────────────────────
    if(wheelOpen) drawWeaponWheel(c);

    // ── Settings overlay ──────────────────────────────────────────────────
    if(settingsOpen) drawSettings(c);

    // ── Per-gun Release Fire overlay ──────────────────────────────────────
    if(relFireOpen) drawRelFirePanel(c);

    // ── Shop overlay ──────────────────────────────────────────────────────
    if(shopOpen) drawShop(c);

    // ── Training overlay ──────────────────────────────────────────────────
    if(state.trainingMode) drawTrainingHUD(c);
}

}
