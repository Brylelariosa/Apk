package com.game.topdown;

import android.graphics.*;
import java.util.*;
import java.util.concurrent.*;
import org.json.*;
import static com.game.topdown.MapData.*;
import static com.game.topdown.PhysicsSystem.*;
import static com.game.topdown.GameConstants.*;
import android.util.Log;

/** Broadcast, receive, input send, event drain. Only Android dep: NetworkManager. */
public class NetworkSync {

private void broadcast(GameState state){
    try{
        JSONObject root=new JSONObject();
        JSONArray pa=new JSONArray();
        Player lp=state.localPlayer; if(lp!=null) pa.put(pj(lp));
        for(Player p:state.remote.values()) pa.put(pj(p));
        root.put("p",pa);
        // Bullets — cap at 100 to keep UDP packet inside buffer limits
        JSONArray ba=new JSONArray();
        int bCount=0;
        for(Bullet b:state.bullets){
            if(bCount++>=100) break;
            JSONObject bj=new JSONObject();
            bj.put("x",(int)b.x); bj.put("y",(int)b.y);
            bj.put("u",(int)b.dx); bj.put("v",(int)b.dy);
            bj.put("o",b.ownerId); bj.put("d",(int)b.damage); bj.put("i",b.id);
            // FIX: sync visual type so clients render state.bullets with correct appearance
            // 0=normal, 1=homing, 2=explosive, 3=bouncy, 4=piercing, 5=ghost, 6=hookSpear
            int btype = 0;
            if      (b.homing)        btype = 1;
            else if (b.explosive)     btype = 2;
            else if (b.bouncesLeft>0) btype = 3;
            else if (b.piercing)      btype = 4;
            else if (b.ghost)         btype = 5;
            else if (b.hookSpear)     btype = 6;
            bj.put("t", btype);
            bj.put("pc", b.paintColor); // paint color: 0=none, 1=slow(blue), 2=poison(green)
            ba.put(bj);
        }
        root.put("b",ba);
        // Bombs — full physics state so clients render them correctly
        JSONArray bma=new JSONArray();
        for(Bomb b:state.activeBombs){
            JSONObject bj=new JSONObject();
            bj.put("x",b.x); bj.put("y",b.y); bj.put("o",b.ownerId);
            bj.put("vx",b.vx); bj.put("vy",b.vy);
            bj.put("rx",b.rollVx); bj.put("ry",b.rollVy);
            bj.put("mr",b.maxRange);
            bj.put("ln",b.hasLanded); bj.put("ea",b.explodedAt);
            bj.put("dt",b.deployTime);
            bma.put(bj);
        }
        root.put("bm",bma);
        // VoltChakrams — positions + state for all active discs
        JSONArray vca=new JSONArray();
        for(VoltChakram vc:state.voltChakrams){
            JSONObject vcj=new JSONObject();
            vcj.put("o",vc.ownerId); vcj.put("x",(int)vc.x); vcj.put("y",(int)vc.y);
            vcj.put("st",vc.state); vcj.put("oi",vc.orbitIdx);
            vcj.put("vx",(int)vc.vx); vcj.put("vy",(int)vc.vy);
            vcj.put("d",(int)vc.damage); vcj.put("dt",(int)vc.distTraveled); vcj.put("mr",(int)vc.maxRange);
            vcj.put("sa",(int)(vc.spinAngle*100)); // sync self-spin angle
            vca.put(vcj);
        }
        root.put("vc",vca);
        // FIX: Sync state.airStrikes to clients so they see warning circles and explosions.
        // Previously absent — clients saw no airstrike visuals at all.
        JSONArray asa = new JSONArray();
        for (double[] as : state.airStrikes) {
            JSONObject asj = new JSONObject();
            asj.put("ax",(int)as[0]); asj.put("ay",(int)as[1]);
            asj.put("at",(long)as[2]);  // trigger time (epoch ms)
            asj.put("ao",(int)as[3]);   // ownerId
            asj.put("af",(long)as[4]);  // flashUntil (0 = not yet exploded)
            asj.put("ar",(int)(as.length>5?as[5]:0)); // remaining extra explosions
            asa.put(asj);
        }
        root.put("as",asa);
        // ── Slash trail events — sync so clients see the Shadow Blade arc ──
        // Only send slot-0 entries (the main arc); client reconstructs all slots.
        JSONArray sla = new JSONArray();
        long slaNow = System.currentTimeMillis();
        for (float[] st : state.effects.slashTrails) {
            if ((int)st[5] == 0 && slaNow - (long)st[3] < 420L) { // only live main-arc slot
                JSONObject slj = new JSONObject();
                slj.put("slx", (int)st[0]); slj.put("sly", (int)st[1]);
                slj.put("slr", (int)st[2]); slj.put("slt", (long)st[3]);
                slj.put("sla", (double)st[4]); // launch angle
                sla.put(slj);
            }
        }
        root.put("sl", sla);
        broadcastSnapshot = root.toString(); // hand off to sender thread — never blocks game loop
    }catch(Exception e){ e.printStackTrace(); }
}

private JSONObject pj(Player p) throws Exception {
    JSONObject o=new JSONObject();
    o.put("i",p.id); o.put("n",p.name);
    o.put("x",(int)p.x); o.put("y",(int)p.y);
    o.put("a",(double)p.angle);
    o.put("h",(int)p.hp); o.put("g",p.gunIndex); o.put("v",p.alive);
    o.put("c",p.coins);
    o.put("kl",p.kills); o.put("de",p.deaths); o.put("ks",p.killStreak);
    o.put("sr",p.skillReload); o.put("sf",p.skillFireRate);
    o.put("sg",p.skillRange);  o.put("sm",p.skillMoveSpeed);
    o.put("sa",p.activeSkillType);
    o.put("ss",(int)p.shieldHp);
    long rem=Math.max(0,p.spawnProtectionUntil-System.currentTimeMillis());
    o.put("sp",(int)rem);
    long aRem=Math.max(0,p.skillActiveUntil-System.currentTimeMillis());
    o.put("se",(int)aRem);
    long hpRem=Math.max(0,p.hookPullUntil-System.currentTimeMillis());
    o.put("hpu",(int)hpRem);
    o.put("hpo",p.hookPullOwnerId);
    // FIX: sync status-effect durations so clients render slow/poison/stun rings
    // on state.remote players. Previously omitted — all rings were invisible on clients.
    o.put("slw",(int)Math.max(0,p.slowUntil  -System.currentTimeMillis()));
    o.put("slwm", p.slowSpeedMult);
    o.put("poi",(int)Math.max(0,p.poisonUntil-System.currentTimeMillis()));
    o.put("stu",(int)Math.max(0,p.stunUntil  -System.currentTimeMillis()));
    return o;
}

public void applyState(GameState state, String json){
    try{
        JSONObject root=new JSONObject(json);
        JSONArray pa=root.getJSONArray("p");
        for(int i=0;i<pa.length();i++){
            JSONObject o=pa.getJSONObject(i);
            int id=o.getInt("i"); boolean alive=o.getBoolean("v");
            float hx=o.getInt("x"), hy=o.getInt("y");
            Player lp=state.localPlayer;
            if(lp!=null&&id==lp.id){
                boolean was=lp.alive;
                lp.hp=o.getInt("h"); lp.alive=alive;
                lp.coins=o.optInt("c", lp.coins);
                lp.kills=o.optInt("kl", lp.kills);
                lp.deaths=o.optInt("de", lp.deaths);
                lp.killStreak=o.optInt("ks", lp.killStreak);
                int spMs=o.optInt("sp",0);
                if(spMs>0) lp.spawnProtectionUntil=System.currentTimeMillis()+spMs;
                int hpRem=o.optInt("hpu",0);
                if(hpRem>0){ lp.hookPullUntil=System.currentTimeMillis()+hpRem; lp.hookPullOwnerId=o.optInt("hpo",-1); }
                else { lp.hookPullUntil=0; }
                if(was&&!alive) deathTime=System.currentTimeMillis();
                // Always reconcile position from host — on LAN ~1ms lag, prevents drift
                float dx=lp.x-hx, dy=lp.y-hy;
                if(dx*dx+dy*dy > 40*40){
                    // Only snap if significantly off (>40px) to avoid fighting local prediction
                    lp.x=hx; lp.y=hy;
                }
                continue;
            }
            Player p=state.remote.get(id);
            if(p==null){p=new Player();p.id=id;p.guns=Gun.createAll();state.remote.put(id,p);}
            p.name=o.getString("n");
            // ── Dead-reckoning: estimate velocity from successive positions ──
            boolean _first = (p.netUpdateMs < 0);
            long _nowMs = System.currentTimeMillis();
            if (!_first) {
                long _dt = _nowMs - p.netUpdateMs;
                if (_dt > 5 && _dt < 150) {
                    p.netVX = (hx - p.netX) / (float)_dt;
                    p.netVY = (hy - p.netY) / (float)_dt;
                }
            } else { p.netVX = 0f; p.netVY = 0f; }
            p.netX = hx; p.netY = hy; p.netUpdateMs = _nowMs;
            p.x = hx; p.y = hy;
            // Smooth aim angle — lerp instead of snap to avoid jitter between packets
            float _ta = (float)o.getDouble("a");
            p.angle = _first ? _ta : lerpAngle(p.angle, _ta, 0.45f);
            p.hp=o.getInt("h");
            p.gunIndex=o.getInt("g"); p.alive=alive;
            p.skillReload   =o.optInt("sr",p.skillReload);
            p.skillFireRate =o.optInt("sf",p.skillFireRate);
            p.skillRange    =o.optInt("sg",p.skillRange);
            p.skillMoveSpeed=o.optInt("sm",p.skillMoveSpeed);
            p.activeSkillType=o.optInt("sa",p.activeSkillType);
            p.shieldHp      =(float)o.optInt("ss",0);
            p.coins         =o.optInt("c", p.coins);
            p.kills         =o.optInt("kl", p.kills);
            p.deaths        =o.optInt("de", p.deaths);
            p.killStreak    =o.optInt("ks", p.killStreak);
            int spMs=o.optInt("sp",0);
            if(spMs>0) p.spawnProtectionUntil=System.currentTimeMillis()+spMs;
            int aRem=o.optInt("se",0);
            if(aRem>0) p.skillActiveUntil=System.currentTimeMillis()+aRem;
            int hpRem=o.optInt("hpu",0);
            if(hpRem>0){ p.hookPullUntil=System.currentTimeMillis()+hpRem; p.hookPullOwnerId=o.optInt("hpo",-1); }
            else { p.hookPullUntil=0; }
            // FIX: restore status-effect timestamps so slow/poison/stun rings render on clients
            int slwRem=o.optInt("slw",0);   p.slowUntil   = slwRem>0 ? System.currentTimeMillis()+slwRem : 0;
            p.slowSpeedMult = (float)o.optDouble("slwm", StatusEffectConfig.SLOW_SPEED_MULT);
            int poiRem=o.optInt("poi",0);   p.poisonUntil = poiRem>0 ? System.currentTimeMillis()+poiRem : 0;
            int stuRem=o.optInt("stu",0);   p.stunUntil   = stuRem>0 ? System.currentTimeMillis()+stuRem : 0;
        }
        // ── Bullets ──────────────────────────────────────────────────────
        JSONArray ba=root.getJSONArray("b");
        state.bullets.clear();
        for(int i=0;i<ba.length();i++){
            JSONObject bj=ba.getJSONObject(i);
            Bullet nb=new Bullet(bj.getInt("x"),bj.getInt("y"),
                bj.getInt("u"),bj.getInt("v"),
                bj.getInt("o"),bj.getInt("d"),bj.getInt("i"),Float.MAX_VALUE);
            // FIX: restore visual type flags so clients render state.bullets correctly
            int btype = bj.optInt("t", 0);
            switch(btype){
                case 1: nb.homing     = true; break;
                case 2: nb.explosive  = true; break;
                case 3: nb.bouncesLeft= 1;    break;
                case 4: nb.piercing   = true; break;
                case 5: nb.ghost      = true; break;
                case 6: nb.hookSpear  = true; break;
            }
            nb.paintColor = bj.optInt("pc", 0);
            state.bullets.add(nb);
        }
        // ── Bombs ─────────────────────────────────────────────────────────
        JSONArray bma=root.optJSONArray("bm");
        if(bma!=null){
            state.activeBombs.clear();
            for(int i=0;i<bma.length();i++){
                JSONObject bj=bma.getJSONObject(i);
                Bomb b=new Bomb((float)bj.getDouble("x"),(float)bj.getDouble("y"),bj.getInt("o"));
                b.vx=(float)bj.getDouble("vx"); b.vy=(float)bj.getDouble("vy");
                b.rollVx=(float)bj.getDouble("rx"); b.rollVy=(float)bj.getDouble("ry");
                b.maxRange=(float)bj.getDouble("mr");
                b.hasLanded=bj.getBoolean("ln");
                b.explodedAt=bj.getLong("ea");
                b.deployTime=bj.getLong("dt");
                state.activeBombs.add(b);
            }
        }
        // ── VoltChakrams ──────────────────────────────────────────────────
        JSONArray vca=root.optJSONArray("vc");
        if(vca!=null){
            int lpId=state.localPlayer!=null?state.localPlayer.id:-1;
            state.voltChakrams.removeIf(vc->vc.ownerId!=lpId); // keep local discs, replace state.remote
            for(int i=0;i<vca.length();i++){
                JSONObject vcj=vca.getJSONObject(i);
                int oid=vcj.getInt("o");
                if(oid==lpId) continue; // local player manages own discs
                VoltChakram vc=new VoltChakram(oid,vcj.optInt("oi",-1));
                vc.x=vcj.getInt("x"); vc.y=vcj.getInt("y");
                vc.state=vcj.getInt("st");
                vc.vx=vcj.getInt("vx"); vc.vy=vcj.getInt("vy");
                vc.damage=vcj.getInt("d"); vc.distTraveled=vcj.getInt("dt"); vc.maxRange=vcj.getInt("mr");
                vc.spinAngle=vcj.optInt("sa",0)/100f; // restore synced spin angle
                state.voltChakrams.add(vc);
            }
        }
        // FIX: Receive host's authoritative state.airStrikes list so clients render
        // warning circles and explosion flashes for all players' air strikes.
        JSONArray asa = root.optJSONArray("as");
        if (asa != null) {
            state.airStrikes.clear();
            for (int i = 0; i < asa.length(); i++) {
                JSONObject asj = asa.getJSONObject(i);
                state.airStrikes.add(new double[]{
                    asj.getDouble("ax"), asj.getDouble("ay"),
                    asj.getLong("at"),   asj.getInt("ao"),
                    asj.getLong("af"),   asj.optInt("ar", 0)
                });
            }
        }
        // ── Slash trail events — rebuild on client from host's slot-0 entries ──
        // FIX: slash state.effects were invisible on clients because slashTrails is only
        // populated locally inside launchShadowBlade (which returns early for clients).
        JSONArray sla = root.optJSONArray("sl");
        if (sla != null) {
            java.util.Set<Long> existingTs = new java.util.HashSet<>();
            for (float[] st : state.effects.slashTrails) existingTs.add((long)st[3]);
            for (int i = 0; i < sla.length(); i++) {
                JSONObject slj = sla.getJSONObject(i);
                long spawnMs = slj.getLong("slt");
                if (existingTs.contains(spawnMs)) continue;
                float slx = slj.getInt("slx"), sly = slj.getInt("sly");
                float slr = slj.getInt("slr");
                float slAng = (float)slj.getDouble("sla");
                state.effects.slashTrails.add(new float[]{slx, sly, slr,        spawnMs, slAng, 0});
                state.effects.slashTrails.add(new float[]{slx, sly, slr*0.85f,  spawnMs, slAng, 1});
                state.effects.slashTrails.add(new float[]{slx, sly, slr*1.1f,   spawnMs, slAng, 2});
                state.effects.slashTrails.add(new float[]{slx, sly, slr*0.6f,   spawnMs, slAng, 3});
                state.effects.slashTrails.add(new float[]{slx, sly, slr*1.3f,   spawnMs, slAng, 4});
            }
        }
    }catch(Exception e){ e.printStackTrace(); }
}

private void sendInput(GameState state, Player lp){
    try{
        JSONObject o=new JSONObject();
        // Joystick (kept for host-side angle/aim logic)
        o.put("0",moveStick.getX()); o.put("1",moveStick.getY());
        o.put("2",aimStick.getX());  o.put("3",aimStick.getY());
        float _ax=aimStick.getX(), _ay=aimStick.getY();
        float _ft=getFireThresh();
        o.put("4", aimStick.isActive() && (_ax*_ax+_ay*_ay) > _ft*_ft);
        o.put("5",lp.gunIndex);
        o.put("6",lp.currentGun().reloading);
        // ── Authoritative client position (avoids dual-simulation drift) ──
        o.put("px", lp.x); o.put("py", lp.y);
        // Passive skill levels
        o.put("7",lp.skillReload);
        o.put("8",lp.skillFireRate);
        o.put("9",lp.skillRange);
        o.put("10",lp.skillMoveSpeed);
        // Active skill
        o.put("11",lp.activeSkillType);
        // FIX Bug6: send ms (not seconds) — previously /1000 caused up to 999ms
        // of early expiry for stealth/shield on the host and other clients.
        long msRem=Math.max(0,lp.skillActiveUntil-System.currentTimeMillis());
        o.put("12",msRem);
        o.put("13",lp.shieldHp);
        // FIX Bug5: Heal event flag — host applies hp+40 on its authoritative copy.
        // Heal is instant (no skillActiveUntil) so host had no way to learn about it,
        // and overwrote the healed hp within 33ms via state update.
        o.put("hlt", pendingHealEvent ? 1 : 0);
        pendingHealEvent = false;
        // Dash position override (already folded into px/py above; flag kept for compat)
        o.put("14", pendingPositionSync ? 1 : 0);
        pendingPositionSync = false;
        // ── Pending bomb throw ─────────────────────────────────────────────
        if (pendingBombSend != null) {
            o.put("bt", 1);
            o.put("bvx", pendingBombSend[0]);
            o.put("bvy", pendingBombSend[1]);
            o.put("bmr", pendingBombSend[2]);
            pendingBombSend = null;
        } else {
            o.put("bt", 0);
        }
        // ── Pending Volt Chakram launch ────────────────────────────────────
        if (state.pendingVoltLaunch != null) {
            o.put("vcl", 1);
            o.put("vcax", state.pendingVoltLaunch[0]);
            o.put("vcay", state.pendingVoltLaunch[1]);
            o.put("vcc",  state.pendingVoltLaunch[2]);
            state.pendingVoltLaunch = null;
        } else {
            o.put("vcl", 0);
        }
        // ── Pending Shadow Blade launch ────────────────────────────────────
        if (state.pendingShadowBlade != null) {
            o.put("sbl", 1);
            o.put("sbax", state.pendingShadowBlade[0]);
            o.put("sbay", state.pendingShadowBlade[1]);
            o.put("sbc",  state.pendingShadowBlade[2]);
            state.pendingShadowBlade = null;
        } else {
            o.put("sbl", 0);
        }
        // ── Pending Quick Slash ────────────────────────────────────────────
        if (state.pendingQuickSlash != null) {
            o.put("qsl", 1);
            o.put("qsax", state.pendingQuickSlash[0]);
            o.put("qsay", state.pendingQuickSlash[1]);
            state.pendingQuickSlash = null;
        } else {
            o.put("qsl", 0);
        }
        net.sendInput(o.toString());
    }catch(Exception e){ if(net!=null) e.printStackTrace(); }
}

private void addFeed(GameState state, String msg) {
    synchronized(state.feed){state.feed.add(0,msg);if(state.feed.size()>4)state.feed.remove(state.feed.size()-1);}
}

public void drainNetEvents(GameState state) {
    float[] be;
    while ((be = state.netBombQ.poll()) != null) {
        int bpid = (int) be[0];
        Player bp = state.remote.get(bpid);
        if (bp != null && bp.alive) {
            // Duplicate check is now safe — we are on the game thread
            boolean hasBomb = false;
            for (Bomb b : state.activeBombs)
                if (b.ownerId == bp.id && !b.isDone() && b.explodedAt < 0) { hasBomb = true; break; }
            if (!hasBomb) {
                Bomb bomb = new Bomb(be[1], be[2], bpid);
                bomb.vx = be[3]; bomb.vy = be[4]; bomb.maxRange = be[5];
                state.activeBombs.add(bomb);
            }
        }
    }
    float[] ve;
    while ((ve = state.netVcQ.poll()) != null) {
        int vpid = (int) ve[0];
        Player vp = state.remote.get(vpid);
        if (vp != null && vp.alive && isVoltChakram(vp.currentGun()))
            launchVoltChakrams(vp, ve[1], ve[2], ve[3]);
    }
    // FIX: drain Shadow Blade queue — temporarily set state.shadowBladeCharge to the
    // client's reported charge so launchShadowBlade picks the right dash/no-dash path.
    float[] sbe;
    while ((sbe = state.netSbQ.poll()) != null) {
        int sbpid = (int) sbe[0];
        Player sbp = state.remote.get(sbpid);
        if (sbp != null && sbp.alive && isShadowBlade(sbp.currentGun())) {
            float savedCharge = state.shadowBladeCharge;
            state.shadowBladeCharge = sbe[3]; // use client's charge for this call
            launchShadowBlade(sbp, sbe[1], sbe[2]);
            state.shadowBladeCharge = savedCharge;
        }
    }
    // Drain Quick Slash queue
    float[] qse;
    while ((qse = state.netQsQ.poll()) != null) {
        int qspid = (int) qse[0];
        Player qsp = state.remote.get(qspid);
        if (qsp != null && qsp.alive && isShadowBlade(qsp.currentGun())) {
            launchQuickSlash(qsp, qse[1], qse[2]);
        }
    }
}

}
