package com.game.topdown;

import java.util.*;
import java.util.concurrent.*;

/**
 * All mutable game-world data in one place.
 *
 * Pattern (matches reference project):
 *   - GameView owns one instance:  final GameState state = new GameState(...)
 *   - Systems receive it as a parameter:  weapons.spawnBullets(state, p)
 *   - No system holds a reference to GameView or to another system
 *
 * Fields intentionally package-private so every system in com.game.topdown
 * can read/write them without getters.
 */
public class GameState {

    // ── Players ───────────────────────────────────────────────────────────────
    volatile Player                  localPlayer;
    final Map<Integer, Player>       remote      = new ConcurrentHashMap<>();
    final Map<Integer, Long>         deadAtMs    = new ConcurrentHashMap<>();

    // ── Projectiles & entities ────────────────────────────────────────────────
    final List<Bullet>               bullets     = new ArrayList<>();
    final List<Bomb>                 activeBombs = new ArrayList<>();
    /** Each entry: [worldX, worldY, triggerMs, ownerId, flashUntilMs] */
    final List<double[]>             airStrikes  = new ArrayList<>();
    final List<VoltChakram>          voltChakrams = new ArrayList<>();

    // ── Volt Chakram sub-state ────────────────────────────────────────────────
    float    voltOrbitAngle   = 0f;
    float    voltCharge       = 0f;
    float[]  pendingVoltLaunch = null;   // [ax, ay, charge] queued to send to host

    // ── Shadow Blade sub-state ────────────────────────────────────────────────
    float    shadowBladeCharge = 0f;
    float[]  pendingShadowBlade = null;
    long     quickSlashCdEnd   = 0L;
    float[]  pendingQuickSlash  = null;

    // ── Effects ───────────────────────────────────────────────────────────────
    final EffectsManager effects = new EffectsManager();

    // ── Weapon meta ───────────────────────────────────────────────────────────
    int     bulletId           = 0;
    boolean cheatInfiniteAmmo  = false;
    boolean cheatNoSkillCd     = false;

    // ── Bombs ─────────────────────────────────────────────────────────────────
    volatile boolean throwingBomb  = false;
    final Set<Long>  spawnedBombFx       = new HashSet<>();
    final Set<Long>  spawnedAirStrikeFx  = new HashSet<>();

    // ── Air Strike aim state ──────────────────────────────────────────────────
    float asAimAngle = Float.NaN;   // NaN = ring hidden
    float asAimMag   = 0f;

    // ── Camera ────────────────────────────────────────────────────────────────
    float camX = 0f, camY = 0f;
    float currentZoom = 1f;
    float camPanX = 0f, camPanY = 0f;

    // ── Network / game meta ───────────────────────────────────────────────────
    boolean isHost;
    boolean singlePlayer;
    int     tick           = 0;
    long    lastBroadcast  = 0L;
    String  hostIpDisplay  = "";
    volatile String pendingState;
    final Map<Integer, float[]> inputs = new ConcurrentHashMap<>();

    // ── Network event queues (written by net thread, drained by game thread) ──
    final ConcurrentLinkedQueue<float[]> netBombQ = new ConcurrentLinkedQueue<>();
    final ConcurrentLinkedQueue<float[]> netVcQ   = new ConcurrentLinkedQueue<>();
    final ConcurrentLinkedQueue<float[]> netSbQ   = new ConcurrentLinkedQueue<>();
    final ConcurrentLinkedQueue<float[]> netQsQ   = new ConcurrentLinkedQueue<>();
    final ConcurrentLinkedQueue<float[]> netAsQ   = new ConcurrentLinkedQueue<>();

    // ── AI / bots ─────────────────────────────────────────────────────────────
    final Set<Integer>            botIds       = new HashSet<>();
    final Map<Integer, float[]>   botDashVisual = new HashMap<>();
    float[][] navWaypoints  = null;
    boolean   navBuildNeeded = true;

    // ── Training mode ─────────────────────────────────────────────────────────
    boolean trainingMode = false;
    final Set<Integer>          dummyIds  = new HashSet<>();
    final Map<Integer, float[]> dummyHome = new HashMap<>();

    // ── Kill feed & score ─────────────────────────────────────────────────────
    final List<String> feed        = new ArrayList<>();
    int localKills = 0, localDeaths = 0;
    final Map<Integer, int[]> scoreMap = new ConcurrentHashMap<>(); // pid → [kills, deaths]

    // ── Reusable scratch (physics) ────────────────────────────────────────────
    /** Pre-allocated list reused every frame by resolvePlayerCollisions. */
    final List<Player> collisionPlayers = new ArrayList<>();

    // ── Constructor ───────────────────────────────────────────────────────────
    public GameState(boolean isHost, boolean singlePlayer) {
        this.isHost       = isHost;
        this.singlePlayer = singlePlayer;
    }

    /** Convenience: add a message to the kill feed (max 4 entries). */
    void addFeed(String msg) {
        synchronized (feed) {
            feed.add(0, msg);
            if (feed.size() > 4) feed.remove(feed.size() - 1);
        }
    }
}
