package com.game.topdown;

import java.util.*;
import java.util.concurrent.*;

/**
 * All mutable game-world data in one place.
 *
 * Pattern (matches reference project):
 *   - GameView owns one instance:  final GameState state = new GameState(...)
 *   - Systems receive it as a parameter:  weapons.spawnBullets(state, p)
 *   - No system holds a reference to GameView or to another system
 *
 * Fields intentionally package-private so every system in com.game.topdown
 * can read/write them without getters.
 */
public class GameState {

    // ── Players ───────────────────────────────────────────────────────────────
    volatile Player                  localPlayer;
    final Map<Integer, Player>       remote      = new ConcurrentHashMap<>();
    final Map<Integer, Long>         deadAtMs    = new ConcurrentHashMap<>();

    // ── Projectiles & entities ────────────────────────────────────────────────
    final List<Bullet>               bullets     = new ArrayList<>();
    final List<Bomb>                 activeBombs = new ArrayList<>();
    /** Each entry: [worldX, worldY, triggerMs, ownerId, flashUntilMs] */
    final List<double[]>             airStrikes  = new ArrayList<>();
    final List<VoltChakram>          voltChakrams = new ArrayList<>();

    // ── Volt Chakram sub-state ────────────────────────────────────────────────
    float    voltOrbitAngle   = 0f;
    float    voltCharge       = 0f;
    float[]  pendingVoltLaunch = null;   // [ax, ay, charge] queued to send to host

    // ── Shadow Blade sub-state ────────────────────────────────────────────────
    float    shadowBladeCharge = 0f;
    float[]  pendingShadowBlade = null;
    long     quickSlashCdEnd   = 0L;
    float[]  pendingQuickSlash  = null;

    // ── Effects ───────────────────────────────────────────────────────────────
    final EffectsManager effects = new EffectsManager();

    // ── Weapon meta ───────────────────────────────────────────────────────────
    int     bulletId           = 0;
    boolean cheatInfiniteAmmo  = false;
    boolean cheatNoSkillCd     = false;

    // ── Bombs ─────────────────────────────────────────────────────────────────
    volatile boolean throwingBomb  = false;
    final Set<Long>  spawnedBombFx       = new HashSet<>();
    final Set<Long>  spawnedAirStrikeFx  = new HashSet<>();

    // ── Air Strike aim state ──────────────────────────────────────────────────
    float asAimAngle = Float.NaN;   // NaN = ring hidden
    float asAimMag   = 0f;

    // ── Camera ────────────────────────────────────────────────────────────────
    float camX = 0f, camY = 0f;
    float currentZoom = 1f;
    float camPanX = 0f, camPanY = 0f;

    // ── Network / game meta ───────────────────────────────────────────────────
    boolean isHost;
    boolean singlePlayer;
    int     tick           = 0;
    long    lastBroadcast  = 0L;
    String  hostIpDisplay  = "";
    volatile String pendingState;
    final Map<Integer, float[]> inputs = new ConcurrentHashMap<>();

    // ── Network event queues (written by net thread, drained by game thread) ──
    final ConcurrentLinkedQueue<float[]> netBombQ = new ConcurrentLinkedQueue<>();
    final ConcurrentLinkedQueue<float[]> netVcQ   = new ConcurrentLinkedQueue<>();
    final ConcurrentLinkedQueue<float[]> netSbQ   = new ConcurrentLinkedQueue<>();
    final ConcurrentLinkedQueue<float[]> netQsQ   = new ConcurrentLinkedQueue<>();
    final ConcurrentLinkedQueue<float[]> netAsQ   = new ConcurrentLinkedQueue<>();

    // ── AI / bots ─────────────────────────────────────────────────────────────
    final Set<Integer>            botIds       = new HashSet<>();
    final Map<Integer, float[]>   botDashVisual = new HashMap<>();
    float[][] navWaypoints  = null;
    boolean   navBuildNeeded = true;

    // ── Training mode ─────────────────────────────────────────────────────────
    boolean trainingMode = false;
    final Set<Integer>          dummyIds  = new HashSet<>();
    final Map<Integer, float[]> dummyHome = new HashMap<>();

    // ── Kill feed & score ─────────────────────────────────────────────────────
    final List<String> feed        = new ArrayList<>();
    int localKills = 0, localDeaths = 0;
    final Map<Integer, int[]> scoreMap = new ConcurrentHashMap<>(); // pid → [kills, deaths]

    // ── Reusable scratch (physics) ────────────────────────────────────────────
    /** Pre-allocated list reused every frame by resolvePlayerCollisions. */
    final List<Player> collisionPlayers = new ArrayList<>();

    // ── Constructor ───────────────────────────────────────────────────────────
    public GameState(boolean isHost, boolean singlePlayer) {
        this.isHost       = isHost;
        this.singlePlayer = singlePlayer;
    }

    /** Convenience: add a message to the kill feed (max 4 entries). */
    void addFeed(String msg) {
        synchronized (feed) {
            feed.add(0, msg);
            if (feed.size() > 4) feed.remove(feed.size() - 1);
        }
    }

    // ── Fields moved from GameView so system classes can access them ──────────
    /** Timestamp of local player's last death (ms). Used for respawn timer. */
    volatile long deathTime = 0L;

    /** Pending bomb throw to send to host: [vx, vy, maxRange], or null. */
    volatile float[] pendingBombSend = null;

    /** True when a Heal skill fired this frame — host needs to apply it. */
    volatile boolean pendingHealEvent = false;

    /** True when a dash just ended — forces a position sync packet. */
    volatile boolean pendingPositionSync = false;

    // ── Joystick snapshot written by GameView each frame, read by NetworkSync ─
    float moveJx = 0f, moveJy = 0f;
    float aimJx  = 0f, aimJy  = 0f;
    boolean aimJactive = false;
    float   fireThresh = 0f;

    /** Returns the display name for a player id, or "?" if not found. */
    String nameOf(int id) {
        if (localPlayer != null && localPlayer.id == id) return localPlayer.name;
        Player p = remote.get(id);
        return p != null ? p.name : "?";
    }

    /** Award kill, update streaks, and publish kill-feed messages. */
    void onKill(Player killer, Player victim) {
        if (killer == null || victim == null) return;
        int baseCoins = 25;
        float streakMult = 1f + 0.03f * killer.killStreak;
        int earned = Math.round(baseCoins * streakMult);
        int streakBreakBonus = victim.killStreak * 6;
        killer.coins += earned + streakBreakBonus;
        killer.kills++;
        killer.killStreak++;
        if (killer.killStreak == 3)
            addFeed("🔥 " + killer.name + " is on a 3-kill streak!");
        else if (killer.killStreak == 5)
            addFeed("🔥🔥 " + killer.name + " is on a 5-kill streak!");
        else if (killer.killStreak == 10)
            addFeed("💀 " + killer.name + " — UNSTOPPABLE! 10-kill streak!");
        if (victim.killStreak >= 3)
            addFeed("💥 " + killer.name + " ended " + victim.name +
                    "'s " + victim.killStreak + "-kill streak! +" + streakBreakBonus + " bonus");
        victim.killStreak = 0;
        victim.deaths++;
        Gun victimSoul = victim.guns[20];
        if (victimSoul != null && victimSoul.killCount > 0) {
            int prevLv = victimSoul.soulLevel();
            int[] thresholds = {0, 1, 3, 5, 8, 12, 18, 25, 35};
            int prevTierStart = thresholds[Math.max(0, prevLv - 1)];
            victimSoul.killCount = prevTierStart;
            victimSoul.lastSoulLevel = -1;
            victimSoul.applySoulLevel();
            int newLv = victimSoul.soulLevel();
            if (newLv < prevLv)
                addFeed("💀 " + victim.name + " Soul Surge DOWNGRADED → Tier " + newLv);
        }
    }
}
