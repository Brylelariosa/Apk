package com.game.topdown;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.*;
import android.view.*;
import org.json.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

// World constants live in MapData; physics helpers live in PhysicsSystem.
// Static imports keep every existing call site (MAP_W, walls(…), clamp(…),
// GUN_PRICES, AS_RADIUS, …) compiling without any changes.
import static com.game.topdown.MapData.*;
import static com.game.topdown.PhysicsSystem.*;
import static com.game.topdown.GameConstants.*;

public class GameView extends SurfaceView
        implements SurfaceHolder.Callback, Runnable, NetworkManager.Callback {

    // ═══ WORLD ════════════════════════════════════════════════════════════════
    // MAP_W, MAP_H, PR, RESPAWN_MS, WALLS, SPAWNS, DUMMY_* → see MapData.java
    // (imported via  import static com.game.topdown.MapData.*)

    // ═══ STATE ═══════════════════════════════════════════════════════════
    final GameState state;

    // ═══ SYSTEMS (stateless — receive state as parameter) ════════════════
    final BombSystem    bombs   = new BombSystem();
    final WeaponSystem  weapons = new WeaponSystem();
    final WorldRenderer world   = new WorldRenderer();
    final NetworkSync   sync    = new NetworkSync();
    final UIRenderer    ui      = new UIRenderer();
    // Wire cross-system reference: NetworkSync.drainNetEvents needs to call weapon methods
    { sync.weapons = weapons; }

    private final String savedName;


    // ═══ NETWORK ══════════════════════════════════════════════════════════════
    private final NetworkManager          net;
    // FIX: network thread writes these; game thread drains them — avoids
    // ConcurrentModificationException on state.activeBombs / state.voltChakrams (plain ArrayLists).
    // float[] bomb entry  : [pid, spawnX, spawnY, vx, vy, maxRange]
    // float[] vc entry    : [pid, ax, ay, charge]

    // ═══ INPUT ════════════════════════════════════════════════════════════════
    private Joystick moveStick, aimStick;
    private RectF    switchRect, reloadRect, bombRect, dropRect, paintModeRect;
    private RectF    trainAddDummyBtn, trainRemDummyBtn, trainAddMoneyBtn; // training mode buttons

    // ═══ BOMBS ════════════════════════════════════════════════════════════════

    // ═══ AIR STRIKE (Pharsa SS) ══════════════════════════════════════════════
    // Each entry: [worldX, worldY, triggerTimeMs, ownerId, flashUntilMs]
    // Phase: triggerTimeMs in future = pending drop, flashUntilMs>0 = exploding

    // ── Air Strike ring-aim state ─────────────────────────────────────────────
    // AS_RING_R → GameConstants (static import)

    // ═══ CONTROL SETTINGS ════════════════════════════════════════════════════
    private static final String PREFS = "shooter_ctrl";
    private volatile boolean settingsOpen = false;
    private RectF   gearRect, settingsPanel, closeSettingsRect;
    private final RectF[] jsSizeOpts  = new RectF[3];
    private final RectF[] swapOpts    = new RectF[2];
    private final RectF[] btnSizeOpts = new RectF[3];
    private final RectF[] opacityOpts   = new RectF[3];
    private final RectF[] aimSensOpts   = new RectF[3];
    private final RectF[] gunStatOpts   = new RectF[2]; // ON/OFF gun stat bars
    private final RectF[] aimLineOpts     = new RectF[2]; // ON/OFF aim line
    // ── Per-gun Release Fire panel ────────────────────────────────────────────
    private boolean relFireOpen    = false;
    private RectF   relFireOpenBtn = null;           // "RELEASE FIRE ▶" row in main settings
    private RectF   relFirePanel   = null;           // secondary overlay panel
    private RectF   relFireCloseBtn = null;
    private final RectF[] relFireToggleON  = new RectF[22];
    private final RectF[] relFireToggleOFF = new RectF[22];
    // GUN_NAMES → GameConstants (static import)
    // GUN_COLORS → GameConstants (static import)
    private RectF fireThreshEditBtn;   // tapping opens custom-value dialog
    private RectF fireThreshValRect;   // display of current value
    private RectF moveBtnsRect;        // "MOVE BUTTONS" button in settings
    private RectF mainMenuRect;        // "MAIN MENU" button in settings
    private RectF changeNameRect;      // "CHANGE NAME" button in settings

    // ═══ SHOP ════════════════════════════════════════════════════════════════
    private volatile boolean shopOpen = false;
    private RectF   shopBtn, shopCloseRect;
    private final RectF[] shopBuyRects = new RectF[22];
    // GUN_PRICES → GameConstants (static import)

    // ═══ SHOP SCROLL ═════════════════════════════════════════════════════════
    private float shopPanelH = 670f; // computed dynamically from screenH in initLayout
    // SHOP_ROW_H, SHOP_ROW_GAP → GameConstants (static import)
    private final float[] shopTabScrollY  = {0f, 0f}; // per-tab scroll offset
    private final float[] shopTabScrollMax= {0f, 0f}; // per-tab max scroll (set in draw)
    private float  shopDragStartY  = 0f;
    private float  shopDragLastY   = 0f;
    private boolean shopIsDragging = false;
    private float  shopScrollVelocity = 0f;  // fling momentum (px/ms)

    // ═══ SKILL SHOP ══════════════════════════════════════════════════════════
    private int   shopTab = 0;   // 0 = guns, 1 = skills
    private RectF shopTabGuns, shopTabSkills;
    private RectF skillRect;                         // active-skill use button
    private final RectF[] passiveBuyRects = new RectF[4];
    private final RectF[] activeBuyRects  = new RectF[4];
    // PASSIVE_SKILL_COSTS, ACTIVE_SKILL_COSTS → GameConstants (static import)

    // ═══ CACHED PREFS (refreshed on settings change, avoid 60Hz disk reads) ════
    private int   cachedAimSens    = 1;        // 0=slow 1=norm 2=fast
    private boolean cachedAimLine  = false;
    private boolean cachedGunStats = true;
    private float cachedFireThresh = 0.40f;
    // Per-gun release-fire cache: index = gunIndex
    private final boolean[] cachedRelFire = new boolean[22];

    private void refreshCachedPrefs() {
        SharedPreferences p = getContext().getSharedPreferences(PREFS, 0);
        cachedAimSens    = p.getInt    ("aim_sens",  1);
        cachedAimLine    = p.getBoolean("aim_line",  false);
        cachedGunStats   = p.getBoolean("gun_stats", true);
        cachedFireThresh = p.getFloat  ("fire_thresh_val", 0.40f);
        for (int i = 0; i < 22; i++) cachedRelFire[i] = p.getBoolean("rel_fire_" + i, false);
    }
    // "kjm" → infinite ammo (no reload ever)
    // "khm" → zero skill cooldown (skills fire instantly, back-to-back)
    private void detectCheats(String name) {
        if (name == null) return;
        String n = name.trim().toLowerCase();
        if (n.equals("kjm")) { state.cheatInfiniteAmmo = true; }
        if (n.equals("khm")) { state.cheatNoSkillCd    = true; }
    }

    // ═══ DASH ANIMATION ══════════════════════════════════════════════════════
    // (managed by EffectsManager — access via state.effects.dashAnim*)

    // ═══ DASH AFTEREFFECTS ═══════════════════════════════════════════════════
    // Bot dash visual-only animation: botId -> [renderX, renderY, destX, destY, beginTimeMs]
    // Logical bot.x/bot.y is already at destination; this only affects rendering.
    private long                lastGhostTimeMs = 0;

    // ═══ DIFFICULTY (0=Easy 1=Normal 2=Hard) ══════════════════════════════
    private int difficulty = 1;

    // ═══ AI VELOCITY TRACKING (predictive aiming) ═════════════════════════
    private float lpVelX = 0f, lpVelY = 0f;
    private float lpPrevX = -1f, lpPrevY = -1f;

    // ═══ BUTTON DRAG ══════════════════════════════════════════════════════════
    private boolean btnMoveMode  = false; // drag-to-reposition mode
    private int     draggingBtn  = -1;    // 0=switch, 1=reload, -1=none
    private float   dragOffX, dragOffY;
    private RectF   confirmMoveRect;      // ✓ button to exit move mode
    // Per-button size slider (shown in btnMoveMode after tapping a button)
    private int     btnSizingId    = -1;  // which btn is being resized: 0=wheel,1=reload,5=skill
    private float   sizeSliderVal  = 0f;  // 0..1 → scale 0.4x..2.2x
    private RectF   sizeSliderTrack;      // drawn at bottom of screen
    private float   tapStartX, tapStartY; // for tap vs drag detection
    private boolean tapMoved       = false;

    // ═══ WEAPON WHEEL ═════════════════════════════════════════════════════════
    private boolean wheelOpen     = false;
    private float   wheelCX, wheelCY, wheelRadius;
    private int     wheelPid      = -1;   // pointer that opened the wheel
    private int     wheelHovered  = -1;   // currently highlighted slot index
    /** Slot array: each entry is a gun index (0-16), or -1 = bomb slot.
     *  Rebuilt every time the wheel opens. */
    private int[]   wheelSlots;

    // ═══ CAMERA ZOOM ══════════════════════════════════════════════════════════
    private Paint settingsBgP, settingsLabelP, optBtnP, optBtnSelP, optTxtP, settingsTitleP, closeBtnP;

    // ═══ PRE-ALLOCATED PAINTS & PATHS (eliminate per-frame GC pressure) ═══════
    // drawVoltChakrams — 11+ Paints + 1 Path created per disc per frame without these
    private final Paint vcOuterGlow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint vcMidGlow   = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint vcTrailP    = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint vcTrailCore = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint vcRingP     = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint vcRingP2    = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint vcBladeP    = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint vcZapP      = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint vcCoreHalo  = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint vcCoreP     = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint vcConnP     = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path  vcBladePath = new Path();
    // drawPlayer — reusable Paints per player per frame
    private final Paint dpShadow   = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dpBody     = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dpGun      = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dpHpFill   = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dpName2    = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dpProtRing = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dpShRing   = new Paint(Paint.ANTI_ALIAS_FLAG);
    // doDraw — world-space state.effects drawn every frame
    private final Paint ddAimLine = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final android.graphics.DashPathEffect aimLineDash =
            new android.graphics.DashPathEffect(new float[]{18f, 10f}, 0f);
    private final Paint ddBombArc = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final android.graphics.DashPathEffect bombArcDash =
            new android.graphics.DashPathEffect(new float[]{16f, 10f}, 0f);
    // Weapon wheel — reuse Path/RectF per slice instead of allocating per slice
    private final Path                    wheelSlicePath = new Path();
    private final android.graphics.RectF  wheelOval      = new android.graphics.RectF();
    // Shop — cache gun list so Gun.createAll() isn't called every draw frame
    private Gun[] shopGunsCache = null;
    // HUD + scoreboard Paints — these draw every frame in multiplayer
    private final Paint hudStatLblP  = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint hudStatBgP   = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint hudSbHdrP    = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint hudSbNameP   = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint hudSbNumP    = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final android.graphics.RectF tmpRectF = new android.graphics.RectF(); // general scratch RectF

    // ── Pre-allocated Paints: bomb world-draw (doDraw runs at 60 Hz) ──────────
    private final Paint ddBombShadow     = new Paint(Paint.ANTI_ALIAS_FLAG); // flying shadow
    private final Paint ddBombFly        = new Paint(Paint.ANTI_ALIAS_FLAG); // flying emoji
    private final Paint ddBombDangerFill = new Paint(Paint.ANTI_ALIAS_FLAG); // landed fill
    private final Paint ddBombDangerRing = new Paint(Paint.ANTI_ALIAS_FLAG); // landed ring
    private final Paint ddBombEmoji      = new Paint(Paint.ANTI_ALIAS_FLAG); // landed emoji
    private final Paint ddBombDot        = new Paint(Paint.ANTI_ALIAS_FLAG); // throw-preview dot
    // ── Air-strike aim UI ──────────────────────────────────────────────────────
    private final Paint ddAsReloadRing   = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ddAsReloadLbl    = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ddAsAimRing      = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ddAsAimConn      = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ddAsAimPrev      = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ddAsAimXh        = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final android.graphics.DashPathEffect ddAsConnDash =
            new android.graphics.DashPathEffect(new float[]{10f, 6f}, 0f);
    // ── Air-strike pending-warning ─────────────────────────────────────────────
    private final Paint ddAsDangerRing   = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ddAsWarn         = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ddAsCross        = new Paint(Paint.ANTI_ALIAS_FLAG);
    // ── Rope / chain draw ─────────────────────────────────────────────────────
    private final Paint ddRopeOuter      = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ddRopeInner      = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ddRopeHighlight  = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ddChainGlow      = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ddChainDark      = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ddChainLight     = new Paint(Paint.ANTI_ALIAS_FLAG);
    // ── drawPlayer — charge/tier/soul indicators ──────────────────────────────
    private final Paint dpCharge        = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dpTip           = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dpSbCharge      = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dpSbTick        = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dpSbTip         = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dpTier          = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dpSoul          = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dpSbLbl         = new Paint(Paint.ANTI_ALIAS_FLAG);

    // ── Scratch Paints for UI-overlay draw methods (shop, settings, HUD btns) ─
    // Each is configured immediately before use; safe because drawing is single-threaded.
    // uiP: general fill/stroke; uiTxt: text; uiCopy: copy of an existing paint via set().
    private final Paint uiP    = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint uiTxt  = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint uiCopy = new Paint(Paint.ANTI_ALIAS_FLAG);

    // ═══ RENDER ═══════════════════════════════════════════════════════════════
    private volatile boolean  gameRunning;
    private Thread            gameThread;
    /** Latest serialized state string; the sender thread drains this so the game loop never blocks on UDP. */
    private volatile String   broadcastSnapshot = null;
    private          Thread   senderThread;
    private float             screenW, screenH;

    private Paint bgP,gridP,wallP,bdrP,remP,locP,shP,hpBgP,
                  nameP,hudP,hudBgP,btnP,btnTxtP,
                  deathBgP,deathTxtP,gunTxtP,ipPaint;


    // ═══ CTOR ═════════════════════════════════════════════════════════════════

    /** Single-player constructor — no networking, with bot enemies. */
    public GameView(Context ctx, String name, int botCount, int difficulty) {
        super(ctx);
        // state must be initialised before any field access
        { GameState s = new GameState(true, true); this.state = s; }
        savedName    = name;
        net          = null;
        this.difficulty = difficulty;
        detectCheats(name);
        getHolder().addCallback(this);
        setFocusable(true);
        initPaints();
        spawnLocal(0, name);
        // Spawn bots — IDs 10, 11, 12 … well away from real player IDs
        for (int i = 0; i < botCount; i++) {
            int botId = 10 + i;
            Player bot = new Player();
            bot.id = botId; bot.name = "Bot " + (i + 1); bot.guns = Gun.createAll();
            float[] sp = SPAWNS[botId % SPAWNS.length];
            bot.x = sp[0]; bot.y = sp[1]; bot.hp = 100; bot.alive = true;

            // Give each bot a DIFFERENT starting gun so they're varied
            // 0=Pistol 1=SMG 2=Shotgun 3=Assault 4=Sniper 5=Burst 6=Minigun
            int[] startGuns = {3, 1, 2, 5, 4, 0, 6}; // assault, smg, shotgun, burst, sniper, pistol, minigun
            int startGun = startGuns[i % startGuns.length];
            bot.gunIndex = startGun;
            bot.unlockedGuns[startGun] = true;

            // Give each bot a starting active skill — they'll never earn
            // enough coins fast enough otherwise, so they never use skills
            int[] startSkills = {Player.ACTIVE_HEAL, Player.ACTIVE_DASH,
                                 Player.ACTIVE_SHIELD, Player.ACTIVE_STEALTH};
            bot.activeSkillType = startSkills[i % startSkills.length];

            // Starting coins so Normal bots can buy upgrades after a few kills
            if (difficulty == 1) bot.coins = 40;
            if (difficulty == 2) bot.coins = 200;
            state.remote.put(botId, bot);
            state.botIds.add(botId);
        }
    }

    /** Training / practice constructor — no bots, no network. */
    public GameView(Context ctx, String name, boolean trainingModeFlag) {
        super(ctx);
        { GameState s = new GameState(true, true); this.state = s; }
        savedName = name;
        state.trainingMode = trainingModeFlag;
        net              = null;
        detectCheats(name);
        getHolder().addCallback(this);
        setFocusable(true);
        initPaints();
        spawnLocal(0, name);
        // In training mode, start near the dummy area (center of map)
        if (state.localPlayer != null) { state.localPlayer.x = 1800f; state.localPlayer.y = 2200f; }
        // Start with one dummy so the range feels populated
        spawnDummy();
    }

    /** Multiplayer constructor — host or client. */
    public GameView(Context ctx, String name, boolean host, String hostIp) {
        super(ctx);
        savedName    = name;
        state.isHost       = host;
        state.singlePlayer = false;
        net          = new NetworkManager(this);
        detectCheats(name);
        getHolder().addCallback(this);
        setFocusable(true);
        initPaints();

        if (host) state.hostIpDisplay = detectLocalIp();

        try {
            if (host) { net.startHost(name); spawnLocal(0, name); }
            else        net.joinGame(hostIp, name);
        } catch (Exception e) { e.printStackTrace(); }
    }

    // ═══ PAINTS ═══════════════════════════════════════════════════════════════
    private void initPaints() {
        bgP     = fill(Color.rgb(12,25,18));
        gridP   = new Paint(Paint.ANTI_ALIAS_FLAG); // one-time init
        gridP.setColor(Color.argb(22,255,255,255));
        gridP.setStyle(Paint.Style.STROKE); gridP.setStrokeWidth(1f);
        wallP   = fill(Color.rgb(68,72,112));
        bdrP    = new Paint(Paint.ANTI_ALIAS_FLAG); // one-time init
        bdrP.setColor(Color.rgb(100,108,170)); bdrP.setStyle(Paint.Style.STROKE); bdrP.setStrokeWidth(6f);
        remP    = fill(Color.rgb(240,88,88));
        locP    = fill(Color.rgb(80,190,255));
        shP     = fill(Color.argb(65,0,0,0));
        hpBgP   = fill(Color.rgb(38,38,38));
        nameP   = fill(Color.WHITE); nameP.setTextSize(21f); nameP.setTextAlign(Paint.Align.CENTER);
        nameP.setShadowLayer(3f,1f,1f,Color.BLACK);
        hudP    = fill(Color.WHITE); hudP.setTextSize(28f);
        hudBgP  = fill(Color.argb(145,0,0,0));
        btnP    = fill(Color.argb(205,195,55,85));
        btnTxtP = fill(Color.WHITE); btnTxtP.setTextSize(22f);
        btnTxtP.setTextAlign(Paint.Align.CENTER); btnTxtP.setTypeface(Typeface.DEFAULT_BOLD);
        deathBgP  = fill(Color.argb(165,0,0,0));
        deathTxtP = fill(Color.rgb(255,55,55)); deathTxtP.setTextSize(58f);
        deathTxtP.setTextAlign(Paint.Align.CENTER);
        gunTxtP = fill(Color.WHITE); gunTxtP.setTextSize(25f); gunTxtP.setTextAlign(Paint.Align.CENTER);
        // IP display paint – large, high contrast
        ipPaint = fill(Color.rgb(255,230,80)); ipPaint.setTextSize(28f);
        ipPaint.setTextAlign(Paint.Align.CENTER); ipPaint.setTypeface(Typeface.DEFAULT_BOLD);
        ipPaint.setShadowLayer(4f,0,2f,Color.BLACK);
        // Settings overlay paints
        settingsBgP   = fill(Color.argb(235,10,15,30));
        settingsTitleP= fill(Color.WHITE); settingsTitleP.setTextSize(26f);
        settingsTitleP.setTextAlign(Paint.Align.LEFT); settingsTitleP.setTypeface(Typeface.DEFAULT_BOLD);
        settingsLabelP= fill(Color.argb(210,200,210,230)); settingsLabelP.setTextSize(20f);
        settingsLabelP.setTextAlign(Paint.Align.LEFT);
        optBtnP   = fill(Color.argb(180,40,50,80));
        optBtnSelP= fill(Color.argb(230,80,130,220));
        optTxtP   = fill(Color.WHITE); optTxtP.setTextSize(17f);
        optTxtP.setTextAlign(Paint.Align.CENTER); optTxtP.setTypeface(Typeface.DEFAULT_BOLD);
        closeBtnP = fill(Color.argb(200,180,50,60));
        // Pre-allocated VC paints
        vcOuterGlow.setStyle(Paint.Style.FILL);
        vcMidGlow.setStyle(Paint.Style.FILL);
        vcTrailP.setStyle(Paint.Style.FILL);
        vcTrailCore.setStyle(Paint.Style.FILL);
        vcRingP.setStyle(Paint.Style.STROKE);
        vcRingP2.setStyle(Paint.Style.STROKE); vcRingP2.setStrokeWidth(1.5f);
        vcBladeP.setStyle(Paint.Style.STROKE); vcBladeP.setStrokeCap(Paint.Cap.ROUND);
        vcZapP.setStyle(Paint.Style.STROKE); vcZapP.setStrokeCap(Paint.Cap.ROUND);
        vcCoreHalo.setStyle(Paint.Style.FILL);
        vcCoreP.setStyle(Paint.Style.FILL);
        vcConnP.setStyle(Paint.Style.STROKE); vcConnP.setStrokeWidth(1f);
        // Pre-allocated drawPlayer paints
        dpShadow.setStyle(Paint.Style.FILL);
        dpBody.setStyle(Paint.Style.FILL);
        dpGun.setStyle(Paint.Style.STROKE); dpGun.setStrokeWidth(7f); dpGun.setStrokeCap(Paint.Cap.ROUND);
        dpHpFill.setStyle(Paint.Style.FILL);
        dpName2.set(nameP);
        dpProtRing.setStyle(Paint.Style.STROKE); dpProtRing.setStrokeWidth(4f);
        dpShRing.setStyle(Paint.Style.STROKE); dpShRing.setStrokeWidth(5f); dpShRing.setColor(Color.argb(200,255,200,0));
        // Pre-allocated doDraw paints
        ddAimLine.setColor(Color.argb(160,255,255,255));
        ddAimLine.setStyle(Paint.Style.STROKE); ddAimLine.setStrokeWidth(2.5f);
        ddAimLine.setPathEffect(aimLineDash);
        ddBombArc.setColor(Color.argb(210,255,210,0));
        ddBombArc.setStyle(Paint.Style.STROKE); ddBombArc.setStrokeWidth(3.5f);
        ddBombArc.setPathEffect(bombArcDash);
        // HUD / scoreboard paints
        hudStatLblP.setTextSize(13f); hudStatLblP.setTextAlign(Paint.Align.LEFT);
        hudStatLblP.setColor(Color.argb(180,200,220,255));
        hudStatBgP.setStyle(Paint.Style.FILL); hudStatBgP.setColor(Color.argb(80,255,255,255));
        hudSbHdrP.setTextSize(13f); hudSbHdrP.setTypeface(Typeface.DEFAULT_BOLD);
        hudSbHdrP.setColor(Color.argb(200,150,180,255));
        hudSbHdrP.setShadowLayer(2f, 0, 1f, Color.BLACK);
        hudSbNameP.setTextSize(15f); hudSbNameP.setTextAlign(Paint.Align.LEFT);
        hudSbNameP.setShadowLayer(2f, 0, 1f, Color.BLACK);
        hudSbNumP.setTextSize(15f); hudSbNumP.setTextAlign(Paint.Align.CENTER);
        hudSbNumP.setTypeface(Typeface.DEFAULT_BOLD);
        hudSbNumP.setShadowLayer(2f, 0, 1f, Color.BLACK);

        // ── Bomb world-draw ───────────────────────────────────────────────────
        ddBombShadow.setStyle(Paint.Style.FILL);
        ddBombFly.setTextSize(34f); ddBombFly.setTextAlign(Paint.Align.CENTER);
        ddBombDangerFill.setStyle(Paint.Style.FILL);
        ddBombDangerRing.setStyle(Paint.Style.STROKE);
        ddBombEmoji.setTextSize(32f); ddBombEmoji.setTextAlign(Paint.Align.CENTER);
        ddBombDot.setStyle(Paint.Style.FILL);

        // ── Air-strike aim UI ─────────────────────────────────────────────────
        ddAsReloadRing.setStyle(Paint.Style.STROKE); ddAsReloadRing.setStrokeWidth(3f);
        ddAsReloadRing.setColor(Color.argb(80, 180, 180, 180));
        ddAsReloadLbl.setColor(Color.argb(200, 220, 100, 100));
        ddAsReloadLbl.setTextSize(36f); ddAsReloadLbl.setTextAlign(Paint.Align.CENTER);
        ddAsAimRing.setStyle(Paint.Style.STROKE); ddAsAimRing.setStrokeWidth(3f);
        ddAsAimRing.setColor(Color.argb(180, 224, 64, 251));
        ddAsAimConn.setColor(Color.argb(110, 224, 64, 251));
        ddAsAimConn.setStrokeWidth(2f); ddAsAimConn.setPathEffect(ddAsConnDash);
        ddAsAimPrev.setStyle(Paint.Style.STROKE); ddAsAimPrev.setStrokeWidth(3f);
        ddAsAimPrev.setColor(Color.argb(160, 255, 200, 50));
        ddAsAimXh.setColor(Color.argb(200, 255, 200, 50)); ddAsAimXh.setStrokeWidth(2.5f);

        // ── Air-strike pending-warning ────────────────────────────────────────
        ddAsDangerRing.setStyle(Paint.Style.STROKE); ddAsDangerRing.setStrokeWidth(4f);
        ddAsWarn.setTextSize(22f); ddAsWarn.setTextAlign(Paint.Align.CENTER);
        ddAsCross.setStrokeWidth(2f);

        // ── Rope / chain draw ─────────────────────────────────────────────────
        ddRopeOuter.setStyle(Paint.Style.STROKE);
        ddRopeInner.setStyle(Paint.Style.STROKE);
        ddRopeHighlight.setStyle(Paint.Style.STROKE);
        ddChainGlow.setStyle(Paint.Style.STROKE); ddChainGlow.setStrokeCap(Paint.Cap.ROUND);
        ddChainDark.setStyle(Paint.Style.STROKE); ddChainDark.setStrokeCap(Paint.Cap.SQUARE);
        ddChainLight.setStyle(Paint.Style.STROKE); ddChainLight.setStrokeCap(Paint.Cap.SQUARE);

        // ── drawPlayer charge/soul/tier indicators ────────────────────────────
        dpCharge.setStyle(Paint.Style.STROKE); dpCharge.setStrokeCap(Paint.Cap.ROUND);
        dpTip.setStyle(Paint.Style.FILL);
        dpSbCharge.setStyle(Paint.Style.STROKE); dpSbCharge.setStrokeCap(Paint.Cap.ROUND);
        dpSbTick.setStyle(Paint.Style.STROKE); dpSbTick.setStrokeCap(Paint.Cap.ROUND);
        dpSbTip.setStyle(Paint.Style.FILL);
        dpTier.setStyle(Paint.Style.FILL); dpTier.setTextAlign(Paint.Align.CENTER);
        dpSoul.setStyle(Paint.Style.FILL);
        dpSbLbl.setStyle(Paint.Style.FILL); dpSbLbl.setTextAlign(Paint.Align.CENTER);
    }
    // Scratch paint reused by fill() — avoids per-call allocation in draw methods.
    // Safe: drawing is single-threaded and drawXxx() consumes the paint immediately.
    private final Paint _fillScratch = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Paint fill(int c) {
        _fillScratch.setColor(c);
        _fillScratch.setStyle(Paint.Style.FILL);
        return _fillScratch;
    }

    /** Finds this device's best local IP — works for regular WiFi AND hotspot AP mode. */
    private static String detectLocalIp() {
        String best = "???.???.???.???";
        try {
            Enumeration<NetworkInterface> ifaces = NetworkInterface.getNetworkInterfaces();
            if (ifaces == null) return best;
            while (ifaces.hasMoreElements()) {
                NetworkInterface ni = ifaces.nextElement();
                if (!ni.isUp() || ni.isLoopback()) continue;
                Enumeration<InetAddress> addrs = ni.getInetAddresses();
                while (addrs.hasMoreElements()) {
                    InetAddress addr = addrs.nextElement();
                    if (addr.isLoopbackAddress() || !(addr instanceof Inet4Address)) continue;
                    String ip = addr.getHostAddress();
                    if (ip == null || ip.isEmpty()) continue;
                    best = ip; // keep last found
                    // Hotspot default range — prefer this immediately
                    if (ip.startsWith("192.168.43.") || ip.startsWith("192.168.1.")
                            || ip.startsWith("10.")) return ip;
                }
            }
        } catch (Exception ignored) {}
        return best;
    }

    // ═══ SURFACE ══════════════════════════════════════════════════════════════
    @Override public void surfaceCreated(SurfaceHolder h)  { /* Wait for surfaceChanged which always provides real dimensions */ }
    @Override public void surfaceChanged(SurfaceHolder h,int f,int w,int hh) { screenW=w; screenH=hh; initControls(); resume(); }
    @Override public void surfaceDestroyed(SurfaceHolder h) { pause(); }

    private void initControls() {
        refreshCachedPrefs(); // keep cached values in sync whenever layout is rebuilt
        SharedPreferences prefs = getContext().getSharedPreferences(PREFS, 0);
        int  jsSize  = prefs.getInt    ("js_size",  1);   // 0=S 1=M 2=L
        boolean swap = prefs.getBoolean("swap",     false);
        int  btnSize = prefs.getInt    ("btn_size", 1);   // 0=S 1=M 2=L
        int  opacity = prefs.getInt    ("opacity",  1);   // 0=lo 1=med 2=hi

        // Joysticks – use saved base positions if available
        float[] muls = {0.10f, 0.145f, 0.19f};
        float r = Math.min(screenW, screenH) * muls[Math.max(0, Math.min(2, jsSize))];
        float m = r + 18f;
        float lx = swap ? screenW - m : m;
        float rx = swap ? m           : screenW - m;
        float defLy = screenH - m;
        moveStick = new Joystick(
            clamp(prefs.getFloat("js_lx", lx),  r, screenW - r),
            clamp(prefs.getFloat("js_ly", defLy), r, screenH - r), r);
        aimStick  = new Joystick(
            clamp(prefs.getFloat("js_rx", rx),  r, screenW - r),
            clamp(prefs.getFloat("js_ry", defLy), r, screenH - r), r);
        int[] alphas = {90, 160, 225};
        int alpha = alphas[Math.max(0, Math.min(2, opacity))];
        moveStick.setAlpha(alpha);
        aimStick .setAlpha(alpha);
        world.moveStick = moveStick;
        world.aimStick  = aimStick;

        // Action buttons with saved position + size
        float[] bws = {120f, 160f, 210f};
        float[] bhs = { 46f,  58f,  72f};
        float bw = bws[Math.max(0, Math.min(2, btnSize))];
        float bh = bhs[Math.max(0, Math.min(2, btnSize))];
        float defBx = screenW - bw - 14f;
        // Per-button scale (set via size slider in move mode). 0.4x..2.2x range.
        float switchScale = prefs.getFloat("scale_switch", 1.0f);
        float rldScale    = prefs.getFloat("scale_rld",    1.0f);
        float skillScale2 = prefs.getFloat("scale_skill",  1.0f);
        // Weapon wheel button — independently positioned, square for circle rendering
        float bx = prefs.getFloat("btn_x", defBx);
        float by = prefs.getFloat("btn_y", 14f);
        float swD = bh * switchScale;  // circle diameter scales per-button
        bx = Math.max(0, Math.min(screenW - swD, bx));
        by = Math.max(0, Math.min(screenH - swD, by));
        switchRect = new RectF(bx, by, bx+swD, by+swD);
        // Reload / bomb / drop group — independently positioned
        float rldW = bw * rldScale, rldH = bh * rldScale;
        float rldX = prefs.getFloat("rld_x", defBx);
        float rldY = prefs.getFloat("rld_y", by + swD + 8f);
        rldX = Math.max(0, Math.min(screenW - rldW, rldX));
        rldY = Math.max(0, Math.min(screenH - rldH, rldY));
        reloadRect = new RectF(rldX, rldY, rldX+rldW, rldY+rldH);
        // Bomb — independently positioned
        float bombX = prefs.getFloat("bomb_x", defBx);
        float bombY = prefs.getFloat("bomb_y", by + swD + rldH + 16f);
        bombX = Math.max(0, Math.min(screenW - rldW, bombX));
        bombY = Math.max(0, Math.min(screenH - rldH, bombY));
        bombRect = new RectF(bombX, bombY, bombX+rldW, bombY+rldH);
        // Drop — independently positioned
        float dropX = prefs.getFloat("drop_x", defBx);
        float dropY = prefs.getFloat("drop_y", by + swD + rldH*2 + 24f);
        dropX = Math.max(0, Math.min(screenW - rldW, dropX));
        dropY = Math.max(0, Math.min(screenH - rldH, dropY));
        dropRect = new RectF(dropX, dropY, dropX+rldW, dropY+rldH);

        // Paint mode toggle button — positioned left of reload group, only visible with Paint Launcher
        float pmW = rldW * 0.82f, pmH = rldH;
        float pmX = prefs.getFloat("pm_x", defBx - pmW - 10f);
        float pmY = prefs.getFloat("pm_y", rldY);
        pmX = Math.max(0, Math.min(screenW - pmW, pmX));
        pmY = Math.max(0, Math.min(screenH - pmH, pmY));
        paintModeRect = new RectF(pmX, pmY, pmX + pmW, pmY + pmH);

        // Skill button — circle, independently movable
        float skillDBase = bw * 0.88f;
        float skillD = skillDBase * skillScale2;
        float defSklX = prefs.getFloat("skill_x", bx + (swD - skillD) / 2f);
        float defSklY = prefs.getFloat("skill_y", by + swD * 4 + 32f);
        defSklX = Math.max(0, Math.min(screenW - skillD, defSklX));
        defSklY = Math.max(0, Math.min(screenH - skillD, defSklY));
        skillRect = new RectF(defSklX, defSklY, defSklX + skillD, defSklY + skillD);

        // Size slider track (shown when a button is tapped in move mode)
        float slW = Math.min(screenW * 0.65f, 420f);
        sizeSliderTrack = new RectF(screenW/2f - slW/2f, screenH - 210f, screenW/2f + slW/2f, screenH - 178f);

        // Gear button
        gearRect = new RectF(12, screenH-72, 72, screenH-12);
        wheelRadius = Math.min(screenW, screenH) * 0.20f;

        // Confirm-move button (shown only in btnMoveMode)
        confirmMoveRect = new RectF(screenW/2-70, screenH-90, screenW/2+70, screenH-30);

        // Settings panel — 8 option rows + MOVE BUTTONS + CHANGE NAME
        float pw = Math.min(520f, screenW - 48f);
        float ph = 790f;
        float px = (screenW - pw) / 2f;
        float py = (screenH - ph) / 2f;
        settingsPanel     = new RectF(px, py, px+pw, py+ph);
        closeSettingsRect = new RectF(px+pw-54, py+8, px+pw-8, py+52);

        float optX = px + pw * 0.47f;
        float obw=72f, obh=40f, og=7f;
        // 8 rows, 62px apart
        float[] rowY = {py+66f, py+128f, py+190f, py+252f, py+314f, py+376f, py+438f, py+500f};
        for(int i=0;i<3;i++) jsSizeOpts[i]  = new RectF(optX+i*(obw+og), rowY[0], optX+i*(obw+og)+obw, rowY[0]+obh);
        for(int i=0;i<2;i++) swapOpts[i]    = new RectF(optX+i*(obw+og), rowY[1], optX+i*(obw+og)+obw, rowY[1]+obh);
        for(int i=0;i<3;i++) btnSizeOpts[i] = new RectF(optX+i*(obw+og), rowY[2], optX+i*(obw+og)+obw, rowY[2]+obh);
        for(int i=0;i<3;i++) aimSensOpts[i] = new RectF(optX+i*(obw+og), rowY[3], optX+i*(obw+og)+obw, rowY[3]+obh);
        for(int i=0;i<3;i++) opacityOpts[i] = new RectF(optX+i*(obw+og), rowY[4], optX+i*(obw+og)+obw, rowY[4]+obh);
        for(int i=0;i<2;i++) gunStatOpts[i] = new RectF(optX+i*(obw+og), rowY[5], optX+i*(obw+og)+obw, rowY[5]+obh);
        for(int i=0;i<2;i++) aimLineOpts[i] = new RectF(optX+i*(obw+og), rowY[6], optX+i*(obw+og)+obw, rowY[6]+obh);
        // Row 7: "RELEASE FIRE ▶" button (opens per-gun overlay)
        relFireOpenBtn = new RectF(optX, rowY[7], optX + obw*2 + og, rowY[7] + obh);
        // Fire threshold: value display + EDIT button
        float ftY = py + 562f;
        float ftEditW = 80f;
        float ftValW  = 90f;
        fireThreshValRect  = new RectF(optX,            ftY, optX+ftValW,          ftY+obh);
        fireThreshEditBtn  = new RectF(optX+ftValW+8f,  ftY, optX+ftValW+8f+ftEditW, ftY+obh);
        float mbY = py + 622f;
        moveBtnsRect = new RectF(px+20, mbY, px+pw-20, mbY+42f);
        float mmY = mbY + 50f;
        mainMenuRect = new RectF(px+20, mmY, px+pw-20, mmY+42f);
        float cnY = mmY + 50f;
        changeNameRect = new RectF(px+20, cnY, px+pw-20, cnY+42f);

        // Per-gun Release Fire secondary panel (two-column grid, 10+10)
        float rfpW = Math.min(520f, screenW - 48f);
        float rfRowH = 38f, rfRowGap = 5f;
        int rfRows = 10;
        float rfpH = 62f + rfRows * (rfRowH + rfRowGap) + 12f;
        float rfpX = (screenW - rfpW) / 2f;
        float rfpY = (screenH - rfpH) / 2f;
        relFirePanel    = new RectF(rfpX, rfpY, rfpX + rfpW, rfpY + rfpH);
        relFireCloseBtn = new RectF(rfpX + rfpW - 54, rfpY + 8, rfpX + rfpW - 8, rfpY + 52);
        float rfColW = rfpW / 2f - 12f;
        float rfTogW = 46f, rfTogGap = 6f;
        float rfContentY = rfpY + 62f;
        for (int i = 0; i < GUN_NAMES.length; i++) {
            int col = i / rfRows, row = i % rfRows;
            float rfRx = rfpX + 10f + col * (rfColW + 12f);
            float rfRy = rfContentY + row * (rfRowH + rfRowGap);
            float tx = rfRx + rfColW - rfTogW*2 - rfTogGap;
            relFireToggleON[i]  = new RectF(tx,               rfRy + 3, tx + rfTogW,            rfRy + rfRowH - 3);
            relFireToggleOFF[i] = new RectF(tx + rfTogW + rfTogGap, rfRy + 3, tx + rfTogW*2 + rfTogGap, rfRy + rfRowH - 3);
        }
        float defSbx = 82f, defSby = screenH - 72f;
        float sbx = prefs.getFloat("shop_x", defSbx);
        float sby = prefs.getFloat("shop_y", defSby);
        sbx = Math.max(0, Math.min(screenW - 70f, sbx));
        sby = Math.max(0, Math.min(screenH - 60f, sby));
        shopBtn = new RectF(sbx, sby, sbx + 70f, sby + 60f);

        // Shop panel rects  ── shopPanelH field is shared with drawShop() ──
        float spw = Math.min(580f, screenW - 40f);
        shopPanelH = Math.min(screenH - 40f, screenH * 0.94f); // nearly full screen height
        float sph = shopPanelH;
        float spx = (screenW - spw) / 2f;
        float spy = (screenH - sph) / 2f;
        shopCloseRect = new RectF(spx+spw-54, spy+8, spx+spw-8, spy+52);

        // Shop tab buttons
        float tabW = (spw - 24f) / 2f;
        shopTabGuns   = new RectF(spx+12,       spy+58, spx+12+tabW,  spy+98);
        shopTabSkills = new RectF(spx+14+tabW,  spy+58, spx+spw-12,   spy+98);

        // Gun buy rects (2 columns: guns shown side-by-side)
        float colW = (spw - 24f) / 2f;
        float buyW = colW * 0.38f, buyH = 30f, firstRowY = spy + 110f;
        float colPad = 8f;
        for (int i = 0; i < 22; i++) {
            int row = i / 2, col = i % 2;
            float ry = firstRowY + row * (SHOP_ROW_H + SHOP_ROW_GAP);
            float cardX = spx + 8f + col * (colW + colPad);
            shopBuyRects[i] = new RectF(cardX + colW - buyW - 4f, ry + (SHOP_ROW_H - buyH) / 2f,
                                         cardX + colW - 4f,        ry + (SHOP_ROW_H + buyH) / 2f);
        }

        // Passive skill buy rects
        float skillBuyW = 86f, skillBuyH = 34f;
        float passiveRowY = spy + 132f, skillRowH = 54f, skillRowGap = 4f;
        for (int i = 0; i < 4; i++) {
            float ry = passiveRowY + i*(skillRowH + skillRowGap);
            passiveBuyRects[i] = new RectF(spx+spw-skillBuyW-16, ry+10, spx+spw-16, ry+10+skillBuyH);
        }
        // Active skill buy rects
        float activeRowY = spy + 392f;
        for (int i = 0; i < 4; i++) {
            float ry = activeRowY + i*(skillRowH + skillRowGap);
            activeBuyRects[i] = new RectF(spx+spw-skillBuyW-16, ry+10, spx+spw-16, ry+10+skillBuyH);
        }

        // Training mode panel — three buttons, each independently repositionable
        if (state.trainingMode) {
            float tbW = 140f, tbH = 46f, tbGap = 8f;
            float defTbX = screenW - tbW - 12f;
            float taDx = prefs.getFloat("train_add_x", defTbX);
            float taDy = prefs.getFloat("train_add_y", 70f);
            taDx = Math.max(0, Math.min(screenW - tbW, taDx));
            taDy = Math.max(0, Math.min(screenH - tbH, taDy));
            trainAddDummyBtn = new RectF(taDx, taDy, taDx+tbW, taDy+tbH);
            float trDx = prefs.getFloat("train_rem_x", defTbX);
            float trDy = prefs.getFloat("train_rem_y", 70f + tbH + tbGap);
            trDx = Math.max(0, Math.min(screenW - tbW, trDx));
            trDy = Math.max(0, Math.min(screenH - tbH, trDy));
            trainRemDummyBtn = new RectF(trDx, trDy, trDx+tbW, trDy+tbH);
            float tmDx = prefs.getFloat("train_money_x", defTbX);
            float tmDy = prefs.getFloat("train_money_y", 70f + 2*(tbH + tbGap));
            tmDx = Math.max(0, Math.min(screenW - tbW, tmDx));
            tmDy = Math.max(0, Math.min(screenH - tbH, tmDy));
            trainAddMoneyBtn = new RectF(tmDx, tmDy, tmDx+tbW, tmDy+tbH);
        }
    }

    // ═══ TOUCH ════════════════════════════════════════════════════════════════
    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int act=e.getActionMasked(), idx=e.getActionIndex(), pid=e.getPointerId(idx);
        float x=e.getX(idx), y=e.getY(idx);

        // Per-gun Release Fire panel — checked FIRST (settingsOpen is still true behind it)
        if (relFireOpen) {
            if (act == MotionEvent.ACTION_DOWN || act == MotionEvent.ACTION_POINTER_DOWN) {
                if (relFireCloseBtn != null && relFireCloseBtn.contains(x, y)) {
                    relFireOpen = false; return true;
                }
                ui.handleRelFireTap(x, y);
            }
            return true;
        }

        // Settings overlay absorbs all input when open
        if (settingsOpen) {
            if (act == MotionEvent.ACTION_DOWN || act == MotionEvent.ACTION_POINTER_DOWN) {
                if (closeSettingsRect != null && closeSettingsRect.contains(x, y)) {
                    settingsOpen = false; return true;
                }
                ui.handleSettingsTap(x, y);
            }
            return true;
        }

        // Shop overlay absorbs all input when open
        if (shopOpen) {
            switch (act) {
                case MotionEvent.ACTION_DOWN:
                case MotionEvent.ACTION_POINTER_DOWN:
                    shopDragStartY = y;
                    shopDragLastY  = y;
                    shopIsDragging = false;
                    shopScrollVelocity = 0f;
                    break;
                case MotionEvent.ACTION_MOVE: {
                    float scrollDelta = shopDragLastY - y;
                    shopDragLastY = y;
                    if (!shopIsDragging && Math.abs(y - shopDragStartY) > 12f) {
                        shopIsDragging = true;
                    }
                    if (shopIsDragging) {
                        shopTabScrollY[shopTab] = Math.max(0f,
                            Math.min(shopTabScrollMax[shopTab],
                                shopTabScrollY[shopTab] + scrollDelta));
                        shopScrollVelocity = shopScrollVelocity * 0.6f + scrollDelta * 0.4f; // track velocity in px/event
                    }
                    break;
                }
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_POINTER_UP:
                    if (!shopIsDragging) {
                        if (shopCloseRect != null && shopCloseRect.contains(x, y)) {
                            shopOpen = false;
                        } else {
                            ui.handleShopTap(x, y);
                        }
                    }
                    shopIsDragging = false;
                    break;
            }
            return true;
        }

        // Button-move mode: drag switch/reload buttons AND joysticks, tap ✓ to save
        if (btnMoveMode) {
            switch(act) {
                case MotionEvent.ACTION_DOWN:
                case MotionEvent.ACTION_POINTER_DOWN:
                    tapStartX = x; tapStartY = y; tapMoved = false;
                    // Size slider drag — only when a button is selected for sizing
                    if (btnSizingId != -1 && sizeSliderTrack != null) {
                        RectF sliderHit = new RectF(sizeSliderTrack.left - 20, sizeSliderTrack.top - 30,
                                sizeSliderTrack.right + 20, sizeSliderTrack.bottom + 30);
                        if (sliderHit.contains(x, y)) { draggingBtn = 99; break; }
                    }
                    if (confirmMoveRect != null && confirmMoveRect.contains(x, y)) {
                        // Save positions + per-button scales and exit move mode
                        SharedPreferences.Editor ed = getContext().getSharedPreferences(PREFS, 0).edit();
                        if (switchRect != null) {
                            ed.putFloat("btn_x", switchRect.left); ed.putFloat("btn_y", switchRect.top);
                            SharedPreferences pr2 = getContext().getSharedPreferences(PREFS, 0);
                            float baseH = new float[]{46f,58f,72f}[Math.max(0,Math.min(2,pr2.getInt("btn_size",1)))];
                            ed.putFloat("scale_switch", switchRect.width() / baseH);
                        }
                        if (reloadRect != null) {
                            ed.putFloat("rld_x", reloadRect.left); ed.putFloat("rld_y", reloadRect.top);
                            SharedPreferences pr2 = getContext().getSharedPreferences(PREFS, 0);
                            float[] bws2 = {120f,160f,210f};
                            float baseW = bws2[Math.max(0,Math.min(2,pr2.getInt("btn_size",1)))];
                            ed.putFloat("scale_rld", reloadRect.width() / baseW);
                        }
                        if (skillRect  != null) {
                            ed.putFloat("skill_x", skillRect.left); ed.putFloat("skill_y", skillRect.top);
                            SharedPreferences pr2 = getContext().getSharedPreferences(PREFS, 0);
                            float[] bws3 = {120f,160f,210f};
                            float baseW = bws3[Math.max(0,Math.min(2,pr2.getInt("btn_size",1)))];
                            float baseSkillD = baseW * 0.88f;
                            ed.putFloat("scale_skill", skillRect.width() / baseSkillD);
                        }
                        if (moveStick != null) { ed.putFloat("js_lx", moveStick.getBaseX()); ed.putFloat("js_ly", moveStick.getBaseY()); }
                        if (aimStick  != null) { ed.putFloat("js_rx", aimStick.getBaseX());  ed.putFloat("js_ry", aimStick.getBaseY());  }
                        if (shopBtn   != null) { ed.putFloat("shop_x", shopBtn.left);        ed.putFloat("shop_y", shopBtn.top);          }
                        if (bombRect  != null) { ed.putFloat("bomb_x", bombRect.left);       ed.putFloat("bomb_y", bombRect.top);         }
                        if (dropRect  != null) { ed.putFloat("drop_x", dropRect.left);       ed.putFloat("drop_y", dropRect.top);         }
                        if (paintModeRect != null) { ed.putFloat("pm_x", paintModeRect.left); ed.putFloat("pm_y", paintModeRect.top);     }
                        if (state.trainingMode) {
                            if (trainAddDummyBtn != null) { ed.putFloat("train_add_x",   trainAddDummyBtn.left); ed.putFloat("train_add_y",   trainAddDummyBtn.top); }
                            if (trainRemDummyBtn != null) { ed.putFloat("train_rem_x",   trainRemDummyBtn.left); ed.putFloat("train_rem_y",   trainRemDummyBtn.top); }
                            if (trainAddMoneyBtn != null) { ed.putFloat("train_money_x", trainAddMoneyBtn.left); ed.putFloat("train_money_y", trainAddMoneyBtn.top); }
                        }
                        ed.apply();
                        btnMoveMode = false; btnSizingId = -1; draggingBtn = -1; break;
                    }
                    if (switchRect != null && switchRect.contains(x, y)) {
                        draggingBtn=0; dragOffX=x-switchRect.left; dragOffY=y-switchRect.top;
                    } else if (reloadRect != null && reloadRect.contains(x, y)) {
                        draggingBtn=1; dragOffX=x-reloadRect.left; dragOffY=y-reloadRect.top;
                    } else if (bombRect != null && bombRect.contains(x, y)) {
                        draggingBtn=6; dragOffX=x-bombRect.left; dragOffY=y-bombRect.top;
                    } else if (dropRect != null && dropRect.contains(x, y)) {
                        draggingBtn=7; dragOffX=x-dropRect.left; dragOffY=y-dropRect.top;
                    } else if (moveStick != null) {
                        float dx=x-moveStick.getBaseX(), dy=y-moveStick.getBaseY();
                        float rr=moveStick.getRadius()*2f;
                        if(dx*dx+dy*dy<=rr*rr){ draggingBtn=2; dragOffX=dx; dragOffY=dy; }
                    }
                    if (draggingBtn==-1 && aimStick != null) {
                        float dx=x-aimStick.getBaseX(), dy=y-aimStick.getBaseY();
                        float rr=aimStick.getRadius()*2f;
                        if(dx*dx+dy*dy<=rr*rr){ draggingBtn=3; dragOffX=dx; dragOffY=dy; }
                    }
                    if (draggingBtn==-1 && shopBtn != null && shopBtn.contains(x, y)) {
                        draggingBtn=4; dragOffX=x-shopBtn.left; dragOffY=y-shopBtn.top;
                    }
                    if (draggingBtn==-1 && paintModeRect != null && paintModeRect.contains(x, y)) {
                        draggingBtn=8; dragOffX=x-paintModeRect.left; dragOffY=y-paintModeRect.top;
                    }
                    if (draggingBtn==-1 && skillRect != null) {
                        float _sdx=x-skillRect.centerX(), _sdy=y-skillRect.centerY();
                        float _sr=skillRect.width()/2f*1.4f;
                        if(_sdx*_sdx+_sdy*_sdy<=_sr*_sr){
                            draggingBtn=5; dragOffX=x-skillRect.left; dragOffY=y-skillRect.top;
                        }
                    }
                    if (draggingBtn==-1 && state.trainingMode) {
                        if (trainAddDummyBtn != null && trainAddDummyBtn.contains(x, y)) {
                            draggingBtn=10; dragOffX=x-trainAddDummyBtn.left; dragOffY=y-trainAddDummyBtn.top;
                        } else if (trainRemDummyBtn != null && trainRemDummyBtn.contains(x, y)) {
                            draggingBtn=11; dragOffX=x-trainRemDummyBtn.left; dragOffY=y-trainRemDummyBtn.top;
                        } else if (trainAddMoneyBtn != null && trainAddMoneyBtn.contains(x, y)) {
                            draggingBtn=12; dragOffX=x-trainAddMoneyBtn.left; dragOffY=y-trainAddMoneyBtn.top;
                        }
                    }
                    break;
                case MotionEvent.ACTION_MOVE:
                    float mdx = x - tapStartX, mdy = y - tapStartY;
                    if (mdx*mdx + mdy*mdy > 144f) tapMoved = true; // 12px threshold
                    if (draggingBtn == 99 && sizeSliderTrack != null) {
                        // Dragging the size slider knob
                        float knobX = Math.max(sizeSliderTrack.left, Math.min(sizeSliderTrack.right, x));
                        sizeSliderVal = (knobX - sizeSliderTrack.left) / sizeSliderTrack.width();
                        float scale = 0.4f + sizeSliderVal * 1.8f; // 0.4x .. 2.2x
                        applyBtnSizeScale(btnSizingId, scale);
                    } else if (draggingBtn == 0) {
                        if (switchRect != null) {
                            float bw2 = switchRect.width(), bh2 = switchRect.height();
                            float nx = Math.max(0, Math.min(screenW - bw2, x - dragOffX));
                            float ny = Math.max(0, Math.min(screenH - bh2, y - dragOffY));
                            switchRect.offsetTo(nx, ny);
                        }
                    } else if (draggingBtn == 1) {
                        if (reloadRect != null) {
                            float bw2 = reloadRect.width(), bh2 = reloadRect.height();
                            float nx = Math.max(0, Math.min(screenW - bw2,      x - dragOffX));
                            float ny = Math.max(0, Math.min(screenH - bh2, y - dragOffY));
                            reloadRect.offsetTo(nx, ny);
                        }
                    } else if (draggingBtn == 2 && moveStick != null) {
                        float r2=moveStick.getRadius();
                        moveStick.updateBase(clamp(x-dragOffX,r2,screenW-r2), clamp(y-dragOffY,r2,screenH-r2));
                    } else if (draggingBtn == 3 && aimStick != null) {
                        float r2=aimStick.getRadius();
                        aimStick.updateBase(clamp(x-dragOffX,r2,screenW-r2), clamp(y-dragOffY,r2,screenH-r2));
                    } else if (draggingBtn == 4 && shopBtn != null) {
                        float sw=shopBtn.width(), sh=shopBtn.height();
                        float nx=Math.max(0,Math.min(screenW-sw, x-dragOffX));
                        float ny=Math.max(0,Math.min(screenH-sh, y-dragOffY));
                        shopBtn.offsetTo(nx, ny);
                    } else if (draggingBtn == 5 && skillRect != null) {
                        float sd = skillRect.width();
                        float nx = Math.max(0, Math.min(screenW - sd, x - dragOffX));
                        float ny = Math.max(0, Math.min(screenH - sd, y - dragOffY));
                        skillRect.offsetTo(nx, ny);
                    } else if (draggingBtn == 6 && bombRect != null) {
                        float bw2=bombRect.width(), bh2=bombRect.height();
                        float nx=Math.max(0,Math.min(screenW-bw2, x-dragOffX));
                        float ny=Math.max(0,Math.min(screenH-bh2, y-dragOffY));
                        bombRect.offsetTo(nx, ny);
                    } else if (draggingBtn == 7 && dropRect != null) {
                        float bw2=dropRect.width(), bh2=dropRect.height();
                        float nx=Math.max(0,Math.min(screenW-bw2, x-dragOffX));
                        float ny=Math.max(0,Math.min(screenH-bh2, y-dragOffY));
                        dropRect.offsetTo(nx, ny);
                    } else if (draggingBtn == 8 && paintModeRect != null) {
                        float bw2=paintModeRect.width(), bh2=paintModeRect.height();
                        float nx=Math.max(0,Math.min(screenW-bw2, x-dragOffX));
                        float ny=Math.max(0,Math.min(screenH-bh2, y-dragOffY));
                        paintModeRect.offsetTo(nx, ny);
                    } else if (draggingBtn == 10 && trainAddDummyBtn != null) {
                        float bw2=trainAddDummyBtn.width(), bh2=trainAddDummyBtn.height();
                        float nx=Math.max(0,Math.min(screenW-bw2, x-dragOffX));
                        float ny=Math.max(0,Math.min(screenH-bh2, y-dragOffY));
                        trainAddDummyBtn.offsetTo(nx, ny);
                    } else if (draggingBtn == 11 && trainRemDummyBtn != null) {
                        float bw2=trainRemDummyBtn.width(), bh2=trainRemDummyBtn.height();
                        float nx=Math.max(0,Math.min(screenW-bw2, x-dragOffX));
                        float ny=Math.max(0,Math.min(screenH-bh2, y-dragOffY));
                        trainRemDummyBtn.offsetTo(nx, ny);
                    } else if (draggingBtn == 12 && trainAddMoneyBtn != null) {
                        float bw2=trainAddMoneyBtn.width(), bh2=trainAddMoneyBtn.height();
                        float nx=Math.max(0,Math.min(screenW-bw2, x-dragOffX));
                        float ny=Math.max(0,Math.min(screenH-bh2, y-dragOffY));
                        trainAddMoneyBtn.offsetTo(nx, ny);
                    }
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_POINTER_UP:
                    // Tap (no drag) on a button → enter per-button size slider mode
                    if (!tapMoved && draggingBtn >= 0 && draggingBtn != 99) {
                        int tappedId = draggingBtn; // 0=wheel, 1=reload, 5=skill
                        if (tappedId == 0 || tappedId == 1 || tappedId == 5) {
                            btnSizingId = tappedId;
                            // Init slider position from current button scale
                            float curScale = 1.0f;
                            SharedPreferences pr = getContext().getSharedPreferences(PREFS, 0);
                            if (tappedId == 0) curScale = pr.getFloat("scale_switch", 1.0f);
                            else if (tappedId == 1) curScale = pr.getFloat("scale_rld", 1.0f);
                            else curScale = pr.getFloat("scale_skill", 1.0f);
                            sizeSliderVal = Math.max(0f, Math.min(1f, (curScale - 0.4f) / 1.8f));
                        }
                    }
                    draggingBtn = -1; break;
            }
            return true;
        }

        switch(act){
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN:
                if(gearRect!=null&&gearRect.contains(x,y)){settingsOpen=true;break;}
                if(shopBtn!=null&&shopBtn.contains(x,y)){shopOpen=true;shopTabScrollY[0]=0f;shopTabScrollY[1]=0f;break;}
                // Training mode buttons
                if (state.trainingMode) {
                    if (trainAddDummyBtn != null && trainAddDummyBtn.contains(x, y)) { spawnDummy(); break; }
                    if (trainRemDummyBtn != null && trainRemDummyBtn.contains(x, y)) { removeLastDummy(); break; }
                    if (trainAddMoneyBtn != null && trainAddMoneyBtn.contains(x, y)) {
                        Player lp2 = state.localPlayer; if (lp2 != null) lp2.coins += 200; break;
                    }
                }
                if(switchRect!=null&&switchRect.contains(x,y)){openWeaponWheel(pid,x,y);break;}
                if(reloadRect!=null&&reloadRect.contains(x,y)){
                    // Air strike gun has no reload — tap is a no-op
                    if(state.localPlayer==null||!state.localPlayer.currentGun().bulletAirStrike) reload();
                    break;
                }
                if(bombRect!=null&&bombRect.contains(x,y)){bombs.startBombThrow(state);break;}
                if(dropRect!=null&&dropRect.contains(x,y)){dropWeapon();break;}
                if(paintModeRect!=null&&paintModeRect.contains(x,y)&&state.localPlayer!=null&&state.localPlayer.gunIndex==15){
                    Gun pg=state.localPlayer.currentGun();
                    pg.paintMode = (pg.paintMode + 1) % 3; // cycle ALT → SLOW → POISON → ALT
                    // Reset toggle so ALT always restarts from poison
                    if (pg.paintMode == 0) pg.paintShotToggle = 2;
                    break;
                }
                if(skillRect!=null){
                    float _sdx=x-skillRect.centerX(),_sdy=y-skillRect.centerY(),_sr=skillRect.width()/2f;
                    if(_sdx*_sdx+_sdy*_sdy<=_sr*_sr){useActiveSkill();break;}
                }
                if(!moveStick.onTouchDown(pid,x,y)) aimStick.onTouchDown(pid,x,y);
                // Air Strike: reset ring when aim stick pressed (blocked while reloading)
                { Player _lp=state.localPlayer; if(_lp!=null&&_lp.currentGun().bulletAirStrike&&!_lp.currentGun().reloading) { state.asAimAngle=_lp.angle; state.asAimMag=0f; } }
                break;
            case MotionEvent.ACTION_MOVE:
                for(int i=0;i<e.getPointerCount();i++){
                    int p2=e.getPointerId(i);
                    if(wheelOpen && p2==wheelPid){
                        updateWheelHover(e.getX(i), e.getY(i));
                    } else {
                        boolean msWasActive = moveStick.isActive();
                        moveStick.onTouchMove(p2,e.getX(i),e.getY(i));
                        aimStick.onTouchMove(p2,e.getX(i),e.getY(i));
                        // Air Strike: update ring aim from stick; hide ring if walking or reloading
                        Player _lp2=state.localPlayer;
                        if(_lp2!=null && _lp2.currentGun().bulletAirStrike) {
                            if(_lp2.currentGun().reloading) {
                                state.asAimAngle = Float.NaN; state.asAimMag = 0f; // clear ring while reloading
                            } else if(moveStick.isActive()) {
                                float _mx=moveStick.getX(), _my=moveStick.getY();
                                if(_mx*_mx+_my*_my > 0.15f*0.15f) {
                                    state.asAimAngle = Float.NaN; // walking → hide ring
                                }
                            } else if(aimStick.isActive()) {
                                float _ax=aimStick.getX(), _ay=aimStick.getY();
                                state.asAimMag=(float)Math.sqrt(_ax*_ax+_ay*_ay);
                                if(state.asAimMag>0.05f) state.asAimAngle=(float)Math.atan2(_ay,_ax);
                            }
                        }
                    }
                }
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP:
                if(wheelOpen && pid==wheelPid){ closeWeaponWheel(); break; }
                float savedAX = aimStick != null ? aimStick.getX() : 0f;
                float savedAY = aimStick != null ? aimStick.getY() : 0f;
                boolean aimWasActive = aimStick != null && aimStick.isActive();
                moveStick.onTouchUp(pid);
                aimStick.onTouchUp(pid);
                if (state.throwingBomb && aimWasActive && (aimStick == null || !aimStick.isActive())) {
                    bombs.executeThrow(state, savedAX, savedAY);
                }
                // Volt Chakram: release stick → launch all orbiting discs
                if (!state.throwingBomb && aimWasActive && !aimStick.isActive()) {
                    Player lp2 = state.localPlayer;
                    if (lp2 != null && lp2.alive && weapons.isVoltChakram(lp2.currentGun())) {
                        if (!state.isHost) state.pendingVoltLaunch = new float[]{savedAX, savedAY, state.voltCharge};
                        weapons.launchVoltChakrams(state, lp2, savedAX, savedAY);
                    } else if (lp2 != null && lp2.alive && weapons.isShadowBlade(lp2.currentGun())) {
                        // FIX: capture charge BEFORE launchShadowBlade resets it to 0
                        if (!state.isHost) state.pendingShadowBlade = new float[]{savedAX, savedAY, state.shadowBladeCharge};
                        weapons.launchShadowBlade(state, lp2, savedAX, savedAY);
                    } else if (lp2 != null && lp2.alive && lp2.currentGun().bulletAirStrike) {
                        // Air Strike: detonate at ring-aimed position on stick release
                        if (!Float.isNaN(state.asAimAngle)) {
                            Gun ag = lp2.currentGun();
                            if (ag.ammo > 0 && !ag.reloading) {
                                weapons.spawnBullets(state, lp2); ag.markFired();
                            }
                        }
                        state.asAimAngle = Float.NaN; state.asAimMag = 0f;
                    } else if (lp2 != null && lp2.alive) {
                        // Per-gun fire-on-release: fire on stick-up if this gun uses REL mode
                        boolean rel = cachedRelFire[lp2.gunIndex]; // FIX: was reading disk on every touch-up
                        if (rel) {
                            float ft = getFireThresh();
                            if (savedAX*savedAX + savedAY*savedAY > ft*ft) {
                                lp2.angle = (float)Math.atan2(savedAY, savedAX);
                                Gun g2 = lp2.currentGun();
                                if (g2.ammo > 0 && !g2.reloading) {
                                    weapons.spawnBullets(state, lp2); g2.markFired();
                                }
                            }
                        }
                    }
                }
                break;
        }
        return true;
    }

    /** Live-resize a button RectF during the size slider drag (keeps center fixed). */
    private void applyBtnSizeScale(int btnId, float scale) {
        scale = Math.max(0.4f, Math.min(2.2f, scale));
        if (btnId == 0 && switchRect != null) {
            // Wheel circle — keep top-left anchor, resize square
            float cx = switchRect.left, cy = switchRect.top;
            SharedPreferences pr = getContext().getSharedPreferences(PREFS, 0);
            float baseH = new float[]{46f,58f,72f}[Math.max(0,Math.min(2,pr.getInt("btn_size",1)))];
            float d = baseH * scale;
            switchRect.set(cx, cy, cx + d, cy + d);
        } else if (btnId == 1 && reloadRect != null) {
            // Keep each button's own top-left anchor, just resize width+height together
            SharedPreferences pr = getContext().getSharedPreferences(PREFS, 0);
            float[] bws2={120f,160f,210f}; float[] bhs2={46f,58f,72f};
            int sz=Math.max(0,Math.min(2,pr.getInt("btn_size",1)));
            float nw = bws2[sz] * scale, nh = bhs2[sz] * scale;
            reloadRect.set(reloadRect.left, reloadRect.top, reloadRect.left+nw, reloadRect.top+nh);
            if(bombRect!=null) bombRect.set(bombRect.left, bombRect.top, bombRect.left+nw, bombRect.top+nh);
            if(dropRect!=null) dropRect.set(dropRect.left, dropRect.top, dropRect.left+nw, dropRect.top+nh);
        } else if (btnId == 5 && skillRect != null) {
            // Skill circle — keep top-left anchor
            float sx = skillRect.left, sy = skillRect.top;
            SharedPreferences pr = getContext().getSharedPreferences(PREFS, 0);
            float[] bws3={120f,160f,210f};
            float baseSkillD = bws3[Math.max(0,Math.min(2,pr.getInt("btn_size",1)))] * 0.88f;
            float d = baseSkillD * scale;
            skillRect.set(sx, sy, sx + d, sy + d);
        }
    }

    private void switchGun(){
        if(state.localPlayer==null||!state.localPlayer.alive) return;
        Player p=state.localPlayer;
        int next=(p.gunIndex+1)%p.guns.length;
        for(int tries=0;tries<p.guns.length;tries++){
            if(p.unlockedGuns[next]){ p.gunIndex=next; return; }
            next=(next+1)%p.guns.length;
        }
    }

    // ── Weapon Wheel ──────────────────────────────────────────────────────────
    private void openWeaponWheel(int pid, float x, float y){
        Player lp=state.localPlayer; if(lp==null||!lp.alive) return;
        // Build slot list: all unlocked guns + bomb slot if player has bombs
        java.util.List<Integer> slots=new java.util.ArrayList<>();
        for(int i=0;i<lp.guns.length;i++) if(lp.unlockedGuns[i]) slots.add(i);
        // Bomb slot intentionally excluded from weapon wheel — use bomb button instead
        wheelSlots=new int[slots.size()];
        for(int i=0;i<slots.size();i++) wheelSlots[i]=slots.get(i);
        // Centre the wheel on the SWITCH button
        wheelCX=switchRect!=null?switchRect.centerX():x;
        wheelCY=switchRect!=null?switchRect.centerY():y;
        wheelHovered=-1; wheelPid=pid; wheelOpen=true;
    }

    private void updateWheelHover(float tx, float ty){
        if(!wheelOpen||wheelSlots==null||wheelSlots.length==0) return;
        float dx=tx-wheelCX, dy=ty-wheelCY;
        // Only register hover when finger has moved away from centre
        if(dx*dx+dy*dy < 18*18){ wheelHovered=-1; return; }
        float angle=(float)Math.atan2(dy,dx); // -π .. π
        // Map angle to slot index (start at top = -π/2, clockwise)
        float adjusted=angle+(float)(Math.PI/2);
        if(adjusted<0) adjusted+=(float)(Math.PI*2);
        float sliceAngle=(float)(Math.PI*2)/wheelSlots.length;
        wheelHovered=(int)(adjusted/sliceAngle)%wheelSlots.length;
    }

    private void closeWeaponWheel(){
        if(!wheelOpen) return;
        Player lp=state.localPlayer;
        if(lp!=null&&lp.alive&&wheelHovered>=0&&wheelSlots!=null&&wheelHovered<wheelSlots.length){
            int sel=wheelSlots[wheelHovered];
            lp.gunIndex=sel;
            state.asAimAngle = Float.NaN; state.asAimMag = 0f;
            state.shadowBladeCharge = 0f; // reset blade charge if switching away
        }
        wheelOpen=false; wheelPid=-1; wheelHovered=-1;
    }
    private void reload()   {if(state.localPlayer!=null&&state.localPlayer.alive) state.localPlayer.currentGun().startReload();}

    /**
     * Called (host-only) whenever a player is confirmed killed.
     * Awards coins to the killer with streak bonuses, updates all score counters,
     * and resets the victim's kill streak.
     */
    private void onKill(Player killer, Player victim) {
        state.onKill(killer, victim); // logic lives in GameState
    }

    private void dropWeapon() {
        Player lp = state.localPlayer;
        if (lp == null || !lp.alive) return;
        int unlockedCount = 0;
        for (boolean u : lp.unlockedGuns) if (u) unlockedCount++;
        if (unlockedCount <= 1) return;
        lp.unlockedGuns[lp.gunIndex] = false;
        int next = (lp.gunIndex + 1) % lp.guns.length;
        for (int tries = 0; tries < lp.guns.length; tries++) {
            if (lp.unlockedGuns[next]) { lp.gunIndex = next; return; }
            next = (next + 1) % lp.guns.length;
        }
    }

    private void useActiveSkill() {
        Player lp = state.localPlayer;
        if (lp == null || !lp.alive) return;

        // ── Shadow Blade: skill button = quick slash (no charge needed) ───────
        if (weapons.isShadowBlade(lp.currentGun())) {
            long now = System.currentTimeMillis();
            if (now < state.quickSlashCdEnd) return; // on cooldown
            Gun g = lp.currentGun();
            if (g.ammo <= 0 || g.reloading) return;
            float ax = aimStick != null ? aimStick.getX() : 0f;
            float ay = aimStick != null ? aimStick.getY() : 0f;
            float mag = (float) Math.sqrt(ax*ax + ay*ay);
            // Fall back to player facing angle if stick is neutral
            if (mag < 0.05f) { ax = (float)Math.cos(lp.angle); ay = (float)Math.sin(lp.angle); mag = 1f; }
            if (!state.isHost) state.pendingQuickSlash = new float[]{ax/mag, ay/mag};
            state.quickSlashCdEnd = now + 1000; // 1.0 s cooldown
            weapons.launchQuickSlash(state, lp, ax/mag, ay/mag);
            return;
        }

        if (lp.activeSkillType == Player.ACTIVE_NONE) return;
        if (lp.skillOnCooldown()) return;
        long now = System.currentTimeMillis();
        switch (lp.activeSkillType) {
            case Player.ACTIVE_DASH:
                // Dash in the MOVE joystick direction (where you're walking)
                float dashAngle = (moveStick!=null&&moveStick.isActive())
                    ? (float)Math.atan2(moveStick.getY(),moveStick.getX()) : lp.angle;
                float dashDist = 260f;
                // Step along the dash path and stop at the last wall-free position
                float[] dashEnd = dashWithWallStop(lp.x, lp.y, dashAngle, dashDist);
                float nx = dashEnd[0], ny = dashEnd[1];
                // Animate the dash smoothly instead of snapping
                state.effects.dashAnimStartX = lp.x; state.effects.dashAnimStartY = lp.y;
                state.effects.dashAnimEndX   = nx;   state.effects.dashAnimEndY   = ny;
                state.effects.dashAnimBegin  = now;  state.effects.dashAnimating  = true;
                lp.skillCooldownEnd = now + 6000;
                state.pendingPositionSync = true;
                break;
            case Player.ACTIVE_STEALTH:
                lp.skillActiveUntil = now + 4000;
                lp.skillCooldownEnd = now + 10000;
                break;
            case Player.ACTIVE_HEAL:
                lp.hp = Math.min(100, lp.hp + 40);
                lp.skillCooldownEnd = now + 12000;
                state.pendingHealEvent = true; // FIX: tell host to apply hp+40 on its authoritative copy
                break;
            case Player.ACTIVE_SHIELD:
                lp.shieldHp = 60f;
                lp.skillActiveUntil = now + 6000;
                lp.skillCooldownEnd = now + 14000;
                break;
        }
    }

    /** Enter throw-aiming mode — bomb is actually thrown when aim stick is released. */
    /** Called when the aim stick is released while state.throwingBomb is true. */
    // ═══ LOOP ═════════════════════════════════════════════════════════════════
    public synchronized void resume(){
        if(gameRunning) return;
        gameRunning=true;
        gameThread=new Thread(this,"GameLoop"); gameThread.start();
        // Dedicated UDP sender: the game loop writes broadcastSnapshot; this thread drains it.
        // Keeps the 16ms game-loop budget free of any socket-blocking time.
        senderThread = new Thread(() -> {
            while (gameRunning) {
                String snap = broadcastSnapshot;
                if (snap != null) { broadcastSnapshot = null; net.broadcastState(snap); }
                try { Thread.sleep(1); } catch (InterruptedException e) { break; }
            }
        }, "StateSender");
        senderThread.setDaemon(true);
        senderThread.start();
    }
    public synchronized void pause(){
        gameRunning=false;
        if(senderThread!=null){ senderThread.interrupt(); senderThread=null; }
        if(gameThread!=null) try{gameThread.join(700);}catch(InterruptedException ignored){}
        gameThread=null;
    }
    public void stopGame(){ pause(); if(net!=null) net.stop(); }

    @Override public void run(){
        long prev=System.nanoTime();
        while(gameRunning){
            long now=System.nanoTime();
            float dt=Math.min((now-prev)/1e9f,0.08f); prev=now;
            update(dt);
            Canvas _c=getHolder().lockCanvas();
            try{ world.render(state, _c); }finally{ if(_c!=null) getHolder().unlockCanvasAndPost(_c); }
            long sleep=16_666_000L-(System.nanoTime()-now);
            if(sleep>0) try{Thread.sleep(sleep/1_000_000,(int)(sleep%1_000_000));}catch(InterruptedException ig){}
        }
    }

    // ═══ UPDATE ═══════════════════════════════════════════════════════════════
    private void update(float dt){
        state.tick++;
        // Snapshot joystick state into GameState so NetworkSync.sendInput can read it
        if (moveStick != null) { state.moveJx = moveStick.getX(); state.moveJy = moveStick.getY(); }
        if (aimStick  != null) { state.aimJx  = aimStick.getX();  state.aimJy  = aimStick.getY(); state.aimJactive = aimStick.isActive(); }
        state.fireThresh = getFireThresh();
        if(!state.isHost && state.pendingState!=null){ sync.applyState(state, state.pendingState); state.pendingState=null; }

        // ── Shop fling momentum ────────────────────────────────────────────────
        if (shopOpen && Math.abs(shopScrollVelocity) > 0.5f) {
            shopTabScrollY[shopTab] = Math.max(0f,
                Math.min(shopTabScrollMax[shopTab],
                    shopTabScrollY[shopTab] + shopScrollVelocity * dt * 1000f));
            shopScrollVelocity *= 0.88f; // decelerate
            if (Math.abs(shopScrollVelocity) < 0.5f) shopScrollVelocity = 0f;
        }

        // ── Client-side dead-reckoning ─────────────────────────────────────────
        // Between host state packets (~33ms apart), extrapolate state.remote players
        // forward at their last known velocity so they never freeze or snap.
        if (!state.isHost) {
            long _drNow = System.currentTimeMillis();
            for (Player rp : state.remote.values()) {
                if (rp.alive && rp.netUpdateMs >= 0) {
                    long _age = _drNow - rp.netUpdateMs;
                    // Extrapolate up to 120ms; beyond that the player has stopped or packet is lost
                    if (_age > 0 && _age < 120) {
                        rp.x = clamp(rp.netX + rp.netVX * _age, PR, MAP_W - PR);
                        rp.y = clamp(rp.netY + rp.netVY * _age, PR, MAP_H - PR);
                    }
                }
            }
        }

        Player lp = state.localPlayer;  // snapshot reference — safe
        if(lp==null) return;

        if(lp.alive) {
            float rm = lp.reloadMult();
            for(Gun g:lp.guns) g.tick(rm);
        }

        if(state.isHost&&!lp.alive&&System.currentTimeMillis()-state.deathTime>=RESPAWN_MS)
            respawn(lp);

        if(lp.alive) moveAndAim(lp, dt);

        // Smooth dash animation — override position while active
        if (state.effects.dashAnimating) {
            long elapsed = System.currentTimeMillis() - state.effects.dashAnimBegin;
            float t = Math.min(1f, (float)elapsed / EffectsManager.DASH_ANIM_MS);
            // Ease-out cubic: fast start, gentle stop — feels like a real dash
            float ease = 1f - (1f - t) * (1f - t) * (1f - t);
            lp.x = state.effects.dashAnimStartX + (state.effects.dashAnimEndX - state.effects.dashAnimStartX) * ease;
            lp.y = state.effects.dashAnimStartY + (state.effects.dashAnimEndY - state.effects.dashAnimStartY) * ease;
            if (t >= 1f) { lp.x = state.effects.dashAnimEndX; lp.y = state.effects.dashAnimEndY; state.effects.dashAnimating = false; state.effects.isPhantomDashing = false; }

            // ── Emit aftereffect ghost at current position ─────────────────
            long nowGhost = System.currentTimeMillis();
            if (nowGhost - lastGhostTimeMs >= 16) {   // ~60fps cap
                if (state.effects.isPhantomDashing) {
                    state.effects.phantomDashGhosts.add(new float[]{lp.x, lp.y, (float)(nowGhost - EffectsManager.FX_EPOCH)});
                } else {
                    state.effects.dashGhosts.add(new float[]{lp.x, lp.y, (float)(nowGhost - EffectsManager.FX_EPOCH)});
                }
                lastGhostTimeMs = nowGhost;
            }
        }

        // ── Bot dash visual animation — expire finished entries ────────────────
        if (!state.botDashVisual.isEmpty()) {
            long nowAnim = System.currentTimeMillis() - EffectsManager.FX_EPOCH;
            state.botDashVisual.entrySet().removeIf(e -> nowAnim - (long)e.getValue()[4] >= EffectsManager.DASH_ANIM_MS);
        }


        // Track player velocity for AI predictive aiming (px / update)
        if (lpPrevX >= 0f) {
            lpVelX = lp.x - lpPrevX;
            lpVelY = lp.y - lpPrevY;
        }
        lpPrevX = lp.x;
        lpPrevY = lp.y;

        weapons.updateBullets(state, lp, dt);
        bombs.updateBombs(state, lp, dt);
        bombs.updateAirStrikes(state, lp);
        weapons.updateVoltChakrams(state, lp, dt);
        weapons.updateHookPulls(state, dt);
        // PhysicsSystem.resolvePlayerCollisions() is static — pass the reusable list.
        state.collisionPlayers.clear();
        if (state.localPlayer != null && state.localPlayer.alive) state.collisionPlayers.add(state.localPlayer);
        for (Player rp : state.remote.values()) if (rp.alive) state.collisionPlayers.add(rp);
        resolvePlayerCollisions(state.collisionPlayers);
        applyPoisonTicks(lp);

        if(state.isHost){
            applyClientInputs(dt);
            sync.drainNetEvents(state); // FIX: apply queued bomb/VC events from network thread on game thread
            if(!state.botIds.isEmpty()) updateBots(dt);
            // Update volt chakrams for state.remote players (hit detection runs on host)
            for (Player rp : state.remote.values()) {
                if (rp.alive && weapons.isVoltChakram(rp.currentGun())) weapons.updateVoltChakrams(state, rp, dt);
            }
            checkRemoteRespawns();
            if(!state.singlePlayer && System.currentTimeMillis()-state.lastBroadcast>33){ sync.broadcast(state); state.lastBroadcast=System.currentTimeMillis(); }
        } else {
            net.sync.sendInput(state, lp); // send every frame (60 Hz) for minimal input lag
        }

        // Smooth per-weapon zoom  (global 0.85 scale already baked into GunConfig)
        float targetZoom = (lp.alive) ? lp.currentGun().zoom : 0.85f;
        state.currentZoom += (targetZoom - state.currentZoom) * 0.07f;

        // Aim pan — shift camera toward aim stick so the player sees further ahead.
        // Vertical pan is stronger (PAN_Y > PAN_X) but we blend by direction so
        // diagonals feel smooth rather than snapping between the two extremes.
        final float PAN_X = 200f;
        final float PAN_Y = 340f;
        float aimPanTargetX = 0f, aimPanTargetY = 0f;
        if (!state.throwingBomb && aimStick != null && aimStick.isActive() && !weapons.isShadowBlade(lp.currentGun())) {
            float _sx = aimStick.getX(), _sy = aimStick.getY();
            float _mag = (float) Math.sqrt(_sx * _sx + _sy * _sy);
            if (_mag > 0.01f) {
                // vertFrac=0 → pure horizontal (use PAN_X), vertFrac=1 → pure vertical (use PAN_Y)
                float vertFrac = Math.abs(_sy) / _mag;
                float panR = PAN_X + (PAN_Y - PAN_X) * vertFrac;
                aimPanTargetX = _sx * panR;
                aimPanTargetY = _sy * panR;
            }
        }
        state.camPanX += (aimPanTargetX - state.camPanX) * 0.09f;
        state.camPanY += (aimPanTargetY - state.camPanY) * 0.09f;

        state.camX = lp.x + state.camPanX - screenW / (2f * state.currentZoom);
        state.camY = lp.y + state.camPanY - screenH / (2f * state.currentZoom);
    }

    private void moveAndAim(Player lp, float dt){
        if(moveStick==null||aimStick==null) return;
        // Hook Spear: pull overrides movement; stun freezes player entirely
        if (lp.isBeingPulled() || lp.isStunned()) return;
        float spd = 280f * lp.moveSpeedMult() * (lp.isSlowed() ? lp.slowSpeedMult : 1.0f) * (lp.isStealthed() ? 1.3f : 1.0f);
        float nx=lp.x+moveStick.getX()*spd*dt;
        float ny=lp.y+moveStick.getY()*spd*dt;
        nx=clamp(nx,PR,MAP_W-PR); ny=clamp(ny,PR,MAP_H-PR);
        float[] pos=walls(lp.x,lp.y,nx,ny);
        lp.x=pos[0]; lp.y=pos[1];

        float ax=aimStick.getX(), ay=aimStick.getY();
        if(ax*ax+ay*ay>0.01f){
            float targetAngle=(float)Math.atan2(ay,ax);
            // Aim sensitivity: 0=slow(0.10) 1=norm(0.35) 2=fast(1.0)
            float[] sensVals = {0.10f, 0.35f, 1.0f};
            float sens = sensVals[Math.max(0,Math.min(2,cachedAimSens))];
            lp.angle = lerpAngle(lp.angle, targetAngle, sens);
        }

        Gun g=lp.currentGun();
        // ── Cheat: infinite ammo — keep every gun topped up, never reload ────
        if (state.cheatInfiniteAmmo) {
            for (Gun cg : lp.guns) { cg.ammo = cg.maxAmmo; cg.reloading = false; }
        }
        // ── Cheat: no skill cooldown — reset CD every frame ──────────────────
        if (state.cheatNoSkillCd) { lp.skillCooldownEnd = 0; }
        // Auto-reload when clip is empty
        if(g.ammo<=0 && !g.reloading && !weapons.isVoltChakram(g)) g.startReload();

        // ── Volt Chakram: spin aim stick to charge; fire handled on stick-up ─
        if (weapons.isVoltChakram(g)) {
            // Passive idle orbit spin
            state.voltOrbitAngle += dt * 1.4f;
            // Hold aim stick to charge — orbit ring spins faster as power builds.
            // No joystick spinning needed; fully compatible with aim panning.
            if (aimStick.isActive() && ax*ax + ay*ay > 0.04f) {
                state.voltCharge = Math.min(1f, state.voltCharge + dt * 0.38f); // full charge in ~2.6s
            } else {
                state.voltCharge = Math.max(0f, state.voltCharge - dt * 0.25f); // slow decay when idle
            }
            // Orbit ring accelerates hard with charge: 1.5 rad/s idle → 18 rad/s full
            state.voltOrbitAngle += dt * (1.5f + state.voltCharge * state.voltCharge * 16.5f);
            return; // skip normal bullet fire
        }

        // ── Shadow Blade: hold aim stick to charge; release dashes and slashes ─
        if (weapons.isShadowBlade(g)) {
            if (aimStick.isActive() && ax*ax + ay*ay > 0.04f) {
                state.shadowBladeCharge = Math.min(1f, state.shadowBladeCharge + dt * 0.83f); // full in ~1.2s
            }
            // Charge is RETAINED when stick released — only resets on fire (launchShadowBlade sets it to 0)
            return; // fire happens on stick-up via launchShadowBlade
        }

        // Fire with passive fire-rate bonus applied
        float aimMag2 = ax*ax + ay*ay;
        float fireThreshVal = getFireThresh();
        // Per-gun release-fire: skip continuous firing; bullet spawned on stick-up instead
        boolean fireOnRelease = cachedRelFire[lp.gunIndex]; // FIX: was reading disk at 60fps
        boolean isAirStrike = g.bulletAirStrike;

        // Air Strike: track aim angle/mag from stick continuously (blocked while reloading)
        if (isAirStrike && aimStick.isActive()) {
            if (g.reloading) {
                state.asAimAngle = Float.NaN; state.asAimMag = 0f; // no aiming while reloading
            } else {
            float _ax = ax, _ay = ay;
            float _mag = (float) Math.sqrt(_ax*_ax + _ay*_ay);
            // Hide ring if walking
            float mvx = moveStick.getX(), mvy = moveStick.getY();
            if (mvx*mvx + mvy*mvy > 0.15f*0.15f) {
                state.asAimAngle = Float.NaN; state.asAimMag = 0f;
            } else if (_mag > 0.05f) {
                state.asAimAngle = (float)Math.atan2(_ay, _ax);
                state.asAimMag   = Math.min(1f, _mag);
            }
            }
        }

        if(!state.throwingBomb && aimStick.isActive() && aimMag2 > fireThreshVal*fireThreshVal
                && !fireOnRelease && !isAirStrike){
            float frMult = lp.fireRateMult();
            long fireCooldown = (long)(1000f / (g.fireRate * frMult));
            boolean canFire = g.ammo > 0 && !g.reloading
                    && System.currentTimeMillis() - g.lastFireTime >= fireCooldown;
            if(canFire){ weapons.spawnBullets(state, lp); g.markFired(); }
        }
    }


    /** Shortest-path angle lerp accounting for ±π wrap. */

    // ═══ AIR STRIKE ══════════════════════════════════════════════════════════

    // ═══ VOLT CHAKRAM ══════════════════════════════════════════════════════════

    /**
     * Quick Slash — instant short-range melee strike, no charge required.
     * Triggered by the SKILL button while Shadow Blade is equipped.
     * Lower damage than the full charged dash-slash; plays a tighter arc effect.
     */
    /** Shortest distance from point (px,py) to segment (ax,ay)→(bx,by). lenSq = |b-a|². */
    private float pointToSegDist(float px, float py,
                                  float ax, float ay, float bx, float by, float lenSq) {
        if (lenSq == 0f) return (float) Math.sqrt((px-ax)*(px-ax)+(py-ay)*(py-ay));
        float t = ((px-ax)*(bx-ax)+(py-ay)*(by-ay)) / lenSq;
        t = Math.max(0f, Math.min(1f, t));
        float cx = ax + t*(bx-ax), cy = ay + t*(by-ay);
        return (float) Math.sqrt((px-cx)*(px-cx)+(py-cy)*(py-cy));
    }

    /** Ensure exactly 3 chakrams (one per orbit slot) exist for lp; remove orbiters if gun switched away. */
    /** Called on aim-stick release when Volt Chakram is equipped. */
    /** Main per-frame update: orbit → launch → return cycle + hit detection. */
    /** Apply damage to any players overlapping this chakram (skips already-hit IDs). */
    /** Render all active chakram discs in world space. */
    /** Moves all players that are currently being pulled by a Hook Spear. */
    /** Draws a catenary-style bezier rope between two world-space points. */
    /** Draws pull-phase ropes for all players currently being yanked. Called in world space. */
    /** Draws chains connecting in-flight hook spear state.bullets back to their owners. */
    /**
     * Draws a metallic chain between two world-space points.
     * Links alternate between along-axis and cross-axis to mimic real chain links.
     */
    /** Pushes all alive players apart so they can't overlap each other. */

    // ── Electric Burst / Chain (Soul Surge T6+) ───────────────────────────────
    // EBURST_RADIUS, EBURST_DAMAGE, ECHAIN_MAX_HOPS → GameConstants (static import)

    /**
     * Called when a Soul Surge bullet kills a target at (cx, cy).
     * tier >= 6 → single burst; tier >= 8 → chain lightning up to ECHAIN_MAX_HOPS.
     * hopsLeft is decremented each jump; starts at ECHAIN_MAX_HOPS for T8, 0 for T6/T7.
     */
    private void applyPoisonTicks(Player lp){
        if(!state.isHost) return;
        long now=System.currentTimeMillis();
        // Local player
        if(lp.alive && lp.isPoisoned() && now-lp.poisonLastTick>=StatusEffectConfig.POISON_TICK_MS){
            lp.poisonLastTick=now;
            if(!lp.isProtected()){
                lp.hp=Math.max(0, lp.hp-lp.poisonTickDamage);
                if(lp.hp==0){
                    lp.alive=false; state.deathTime=now;
                    state.addFeed(state.nameOf(lp.poisonOwnerId)+" ☠ "+lp.name+" (poison)");
                    onKill(state.remote.get(lp.poisonOwnerId), lp);
                }
                if(lp.isStealthed()) lp.skillActiveUntil=0;
            }
        }
        // Remote players
        for(Player rp:state.remote.values()){
            if(!rp.alive||!rp.isPoisoned()) continue;
            if(now-rp.poisonLastTick>=StatusEffectConfig.POISON_TICK_MS){
                rp.poisonLastTick=now;
                if(!rp.isProtected()){
                    if(rp.isStealthed()) rp.skillActiveUntil=0;
                    rp.hp=Math.max(0, rp.hp-rp.poisonTickDamage);
                    if(rp.hp==0){
                        rp.alive=false; state.deadAtMs.put(rp.id,now);
                        state.addFeed(state.nameOf(rp.poisonOwnerId)+" ☠ "+rp.name+" (poison)");
                        if(rp.poisonOwnerId==lp.id) onKill(lp, rp);
                        else{ Player killer=state.remote.get(rp.poisonOwnerId); onKill(killer, rp); }
                    }
                }
            }
        }
    }

    private void applyClientInputs(float dt){
        for(Map.Entry<Integer,float[]> e:state.inputs.entrySet()){
            Player p=state.remote.get(e.getKey()); if(p==null||!p.alive) continue;
            float[] inp=e.getValue();
            // Sync skill levels from client input
            if(inp.length>13){
                p.skillReload    =Math.max(0,Math.min(3,(int)inp[7]));
                p.skillFireRate  =Math.max(0,Math.min(3,(int)inp[8]));
                p.skillRange     =Math.max(0,Math.min(3,(int)inp[9]));
                p.skillMoveSpeed =Math.max(0,Math.min(3,(int)inp[10]));
                p.activeSkillType=(int)inp[11];
                // FIX Bug6: field 12 is now ms remaining (was seconds — caused up to 999ms precision loss)
                long msRem2=(long)inp[12]; p.skillActiveUntil= msRem2>0?System.currentTimeMillis()+msRem2:0;
                p.shieldHp=inp[13];
                // FIX Bug5: apply heal on the host's authoritative copy so the hp change sticks
                if(inp.length>17 && inp[17]>0.5f && p.alive) p.hp=Math.min(100,p.hp+40);
            }
            // ── Use client's authoritative position if provided ─────────────────
            // inp[14]=px, inp[15]=py (−1 means not provided, fall back to delta)
            float clientX = inp.length>14 ? inp[14] : -1f;
            float clientY = inp.length>15 ? inp[15] : -1f;
            if (p.isBeingPulled() || p.isStunned()) {
                // Hook pull / stun: host position is authoritative — ignore client
            } else if(clientX >= 0 && clientY >= 0){
                // FIX: lerp toward client position to smooth network jitter.
                // Snap instantly if far away (respawn/teleport), otherwise ease in.
                float tX = clamp(clientX, PR, MAP_W-PR);
                float tY = clamp(clientY, PR, MAP_H-PR);
                float snapDist2 = 120f*120f;
                if ((tX-p.x)*(tX-p.x)+(tY-p.y)*(tY-p.y) > snapDist2) {
                    p.x = tX; p.y = tY; // far away: snap immediately
                } else {
                    p.x += (tX - p.x) * 0.3f; // close: smooth interpolation
                    p.y += (tY - p.y) * 0.3f;
                }
            } else {
                // Fallback: dead-reckon from joystick (should rarely happen)
                float nx=p.x+inp[0]*280f*p.moveSpeedMult()*dt, ny=p.y+inp[1]*280f*p.moveSpeedMult()*dt;
                nx=clamp(nx,PR,MAP_W-PR); ny=clamp(ny,PR,MAP_H-PR);
                float[] pos=walls(p.x,p.y,nx,ny); p.x=pos[0]; p.y=pos[1];
            }
            // Aim angle from joystick
            if(inp[2]*inp[2]+inp[3]*inp[3]>0.01f) p.angle=(float)Math.atan2(inp[3],inp[2]);
            p.gunIndex=Math.max(0,Math.min((int)inp[5], p.guns.length-1));
            if(inp[6]>0.5f) p.guns[p.gunIndex].startReload();
            float rm=p.reloadMult();
            for(Gun g:p.guns) g.tick(rm);
            { Gun g=p.currentGun(); if(g.ammo<=0&&!g.reloading) g.startReload(); }
            if(inp[4]>0.5f){
                Gun g=p.currentGun();
                float frMult=p.fireRateMult();
                long fireCd=(long)(1000f/(g.fireRate*frMult));
                if(g.ammo>0&&!g.reloading&&System.currentTimeMillis()-g.lastFireTime>=fireCd){
                    weapons.spawnBullets(state, p); g.markFired();
                }
            }
        }
    }

    private void checkRemoteRespawns(){
        long now=System.currentTimeMillis();
        for(Player p:state.remote.values()) {
            if (!p.alive && state.deadAtMs.containsKey(p.id)) {
                long delay = state.dummyIds.contains(p.id) ? 2000L : RESPAWN_MS;
                if (now - state.deadAtMs.get(p.id) >= delay) {
                    if (state.dummyIds.contains(p.id)) respawnDummy(p);
                    else respawn(p);
                    state.deadAtMs.remove(p.id);
                }
            }
        }
    }

    private void respawn(Player p){
        float[] sp=SPAWNS[p.id%SPAWNS.length]; p.x=sp[0]; p.y=sp[1];
        p.hp=100; p.alive=true; p.guns=Gun.createAll();
        p.bombs = 2;
        p.spawnProtectionUntil = System.currentTimeMillis() + 3000;
        p.shieldHp = 0; p.skillActiveUntil = 0; p.skillCooldownEnd = 0;
        p.slowUntil = 0; p.slowSpeedMult = StatusEffectConfig.SLOW_SPEED_MULT; p.poisonUntil = 0; p.poisonLastTick = 0; p.poisonOwnerId = -1;
        p.stunUntil = 0; p.hookPullUntil = 0; p.hookPullOwnerId = -1;  // clear status state.effects on respawn
        p.killStreak = 0; // streak resets on death; kills/deaths persist
        // Keep coins, skill levels, active skill type, and unlocked guns
        // FIX: only validate gunIndex for the LOCAL player. The host never receives
        // unlockedGuns data for state.remote players, so their copy is always {true,false,…}.
        // Without this guard, the host was resetting every state.remote player to pistol (index 0)
        // on every respawn, even when they had a different gun equipped.
        Player lp = state.localPlayer;
        if (p == lp && !p.unlockedGuns[p.gunIndex]) p.gunIndex = 0;
        // For state.remote players, applyClientInputs restores the correct gunIndex each frame.
    }
    private void spawnLocal(int id, String name){
        Player p=new Player(); p.id=id; p.name=name; p.guns=Gun.createAll();
        float[] sp=SPAWNS[id%SPAWNS.length]; p.x=sp[0]; p.y=sp[1];
        p.spawnProtectionUntil = System.currentTimeMillis() + 3000;
        state.localPlayer=p;
    }

    /** Spawn one more training dummy (up to MAX_DUMMIES). */
    private void spawnDummy() {
        if (state.dummyIds.size() >= MAX_DUMMIES) return;
        int slot = state.dummyIds.size();
        int id   = DUMMY_ID_BASE + slot;
        float[] home = DUMMY_SPAWNS[slot % DUMMY_SPAWNS.length];
        Player d = new Player();
        d.id = id; d.name = "Dummy"; d.guns = Gun.createAll();
        d.x = home[0]; d.y = home[1]; d.hp = 100; d.alive = true;
        d.spawnProtectionUntil = 0; // dummies have no protection
        state.remote.put(id, d);
        state.dummyIds.add(id);
        state.dummyHome.put(id, new float[]{home[0], home[1]});
    }

    /** Remove the most recently added training dummy. */
    private void removeLastDummy() {
        if (state.dummyIds.isEmpty()) return;
        int lastId = DUMMY_ID_BASE + state.dummyIds.size() - 1;
        state.remote.remove(lastId);
        state.dummyIds.remove(lastId);
        state.dummyHome.remove(lastId);
        state.deadAtMs.remove(lastId);
        state.voltChakrams.removeIf(vc -> vc.ownerId == lastId);
    }

    /** Respawn a dummy at its fixed home position. */
    private void respawnDummy(Player d) {
        float[] home = state.dummyHome.get(d.id);
        if (home == null) return;
        d.x = home[0]; d.y = home[1];
        d.hp = 100; d.alive = true; d.guns = Gun.createAll();
        d.spawnProtectionUntil = 0;
        d.shieldHp = 0; d.skillActiveUntil = 0; d.skillCooldownEnd = 0;
        d.slowUntil = 0; d.slowSpeedMult = StatusEffectConfig.SLOW_SPEED_MULT; d.poisonUntil = 0; d.poisonLastTick = 0; d.poisonOwnerId = -1;
        d.stunUntil = 0; d.hookPullUntil = 0; d.hookPullOwnerId = -1;
    }

    // ══ BOT AI ════════════════════════════════════════════════════════════════

    /** Tactical state-machine AI engine — fully separated from GameView. */
    private final BotAI botAI = new BotAI();

    /** Pre-built wall-corner waypoints used for around-wall routing. */

    /**
     * Builds waypoints at every wall corner (plus map corners) with a margin so
     * bots always stand outside the wall geometry.  Call once after WALLS is set.
     */
    private void buildNavWaypoints() {
        final float PAD = 52f;
        List<float[]> pts = new ArrayList<>();
        // Map corners
        pts.add(new float[]{PAD, PAD});
        pts.add(new float[]{MAP_W - PAD, PAD});
        pts.add(new float[]{PAD, MAP_H - PAD});
        pts.add(new float[]{MAP_W - PAD, MAP_H - PAD});
        // For every wall: 4 outer corners + 4 edge midpoints
        for (float[] w : WALLS) {
            float mx = (w[0] + w[2]) * 0.5f, my = (w[1] + w[3]) * 0.5f;
            pts.add(new float[]{w[0] - PAD, w[1] - PAD});
            pts.add(new float[]{w[2] + PAD, w[1] - PAD});
            pts.add(new float[]{w[0] - PAD, w[3] + PAD});
            pts.add(new float[]{w[2] + PAD, w[3] + PAD});
            pts.add(new float[]{mx,          w[1] - PAD});
            pts.add(new float[]{mx,          w[3] + PAD});
            pts.add(new float[]{w[0] - PAD,  my});
            pts.add(new float[]{w[2] + PAD,  my});
        }
        // Keep only points that are inside the map and not inside any wall
        List<float[]> valid = new ArrayList<>();
        for (float[] p : pts) {
            if (p[0] < PAD || p[0] > MAP_W - PAD || p[1] < PAD || p[1] > MAP_H - PAD) continue;
            boolean blocked = false;
            for (float[] w : WALLS) {
                if (p[0] > w[0] && p[0] < w[2] && p[1] > w[1] && p[1] < w[3]) { blocked = true; break; }
            }
            if (!blocked) valid.add(p);
        }
        state.navWaypoints = valid.toArray(new float[0][]);
    }

    /**
     * Finds the cheapest 1-hop waypoint such that: bot→wp has clear LOS AND
     * wp→target has clear LOS.  Returns null if no waypoint is needed / found.
     */
    private float[] findNavWaypoint(float bx, float by, float tx, float ty) {
        float bestCost = Float.MAX_VALUE;
        float[] best   = null;
        if (state.navWaypoints == null) return null;
        for (float[] wp : state.navWaypoints) {
            if (!hasLos(bx, by, wp[0], wp[1])) continue;
            if (!hasLos(wp[0], wp[1], tx, ty))  continue;
            float d1x = wp[0] - bx, d1y = wp[1] - by;
            float d2x = tx - wp[0], d2y = ty - wp[1];
            float cost = (float)(Math.sqrt(d1x*d1x + d1y*d1y) + Math.sqrt(d2x*d2x + d2y*d2y));
            if (cost < bestCost) { bestCost = cost; best = wp; }
        }
        return best;
    }

    /** Move bot by (moveX, moveY)*speed*dt with axis-separated wall sliding. */

    /**
     * Per-frame AI update. Delegates entirely to {@link BotAI} via a Context
     * adapter so all tactical logic lives in the separated BotAI class.
     */
    private void updateBots(float dt) {
        Player lp = state.localPlayer;
        if (lp == null) return;
        if (state.navWaypoints == null) buildNavWaypoints();

        // Build a Context adapter once per frame — captures local references.
        BotAI.Context ctx = new BotAI.Context() {
            @Override public java.util.List<Bullet> getBullets()           { return state.bullets; }
            @Override public Player getLocalPlayer()                       { return state.localPlayer; }
            @Override public Map<Integer, Player> getRemote()              { return state.remote; }
            @Override public int    getDifficulty()                        { return difficulty; }
            @Override public int    getTick()                              { return state.tick; }
            @Override public float  getPlayerVelX()                        { return lpVelX; }
            @Override public float  getPlayerVelY()                        { return lpVelY; }
            @Override public float[][] getWalls()                          { return WALLS; }
            @Override public float[][] getNavWaypoints()                   { return state.navWaypoints; }
            // hasLos / moveBotWithCollision are static in PhysicsSystem (static import)
            @Override public boolean hasLos(float x1, float y1, float x2, float y2) {
                return PhysicsSystem.hasLos(x1, y1, x2, y2);
            }
            @Override public void moveBotWithCollision(Player bot, float mx, float my, float spd, float dt2) {
                PhysicsSystem.moveBotWithCollision(bot, mx, my, spd, dt2);
            }
            @Override public void spawnBotBullets(Player bot)              { weapons.spawnBullets(state, bot); }
            @Override public void doBotShopping(Player bot) {
                BotController.doShopping(bot);
            }
            @Override public void doBotUseSkill(Player bot, Player lp2, float dist) {
                BotController.doUseSkill(bot, lp2, dist, state.effects, state.botDashVisual);
            }
            @Override public float[] findNavWaypoint(float bx, float by, float tx, float ty) {
                return GameView.this.findNavWaypoint(bx, by, tx, ty);
            }
        };

        for (Player bot : state.remote.values()) {
            if (!state.botIds.contains(bot.id) || !bot.alive) continue;
            botAI.update(bot, ctx, dt);
        }
    }



    // ═══ RENDER ═══════════════════════════════════════════════════════════════
    // ═══ TRAINING HUD ════════════════════════════════════════════════════════
    // ═══ SKILL BUTTON ════════════════════════════════════════════════════════
    private long skillCooldownTotal(int type) {
        switch(type){
            case Player.ACTIVE_DASH:    return 6000;
            case Player.ACTIVE_STEALTH: return 10000;
            case Player.ACTIVE_HEAL:    return 12000;
            case Player.ACTIVE_SHIELD:  return 14000;
            default: return 1;
        }
    }

    // ═══ SETTINGS OVERLAY ════════════════════════════════════════════════════
    // ═══ WEAPON WHEEL ════════════════════════════════════════════════════════
    /** Returns the fire-joystick magnitude threshold from cached settings (0.15–0.70). */
    private float getFireThresh() {
        return cachedFireThresh;
    }

    private void showFireThreshDialog() {
        android.app.Activity act = (android.app.Activity) getContext();
        act.runOnUiThread(() -> {
            android.widget.EditText input = new android.widget.EditText(getContext());
            input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER
                    | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
            float cur = getFireThresh();
            input.setText(String.format(java.util.Locale.US, "%.2f", cur));
            input.selectAll();
            input.setPadding(40, 24, 40, 24);

            new android.app.AlertDialog.Builder(getContext())
                .setTitle("Fire Threshold")
                .setMessage("How far to push aim stick before firing (0.05 – 0.99)")
                .setView(input)
                .setPositiveButton("Set", (dlg, which) -> {
                    try {
                        float val = Float.parseFloat(input.getText().toString().trim());
                        val = Math.max(0.05f, Math.min(0.99f, val));
                        getContext().getSharedPreferences(PREFS, 0).edit()
                            .putFloat("fire_thresh_val", val).apply();
                        refreshCachedPrefs();
                    } catch (NumberFormatException ignored) {}
                })
                .setNegativeButton("Cancel", null)
                .show();
        });
    }

    private void showChangeNameDialog() {
        android.app.Activity act = (android.app.Activity) getContext();
        act.runOnUiThread(() -> {
            android.widget.EditText input = new android.widget.EditText(getContext());
            input.setInputType(android.text.InputType.TYPE_CLASS_TEXT
                    | android.text.InputType.TYPE_TEXT_FLAG_CAP_WORDS);
            input.setFilters(new android.text.InputFilter[]{
                    new android.text.InputFilter.LengthFilter(16)
            });
            if (state.localPlayer != null) {
                input.setText(state.localPlayer.name);
                input.selectAll();
            }
            input.setPadding(40, 24, 40, 24);

            new android.app.AlertDialog.Builder(getContext())
                .setTitle("Change Name")
                .setMessage("Enter a new name (max 16 characters)")
                .setView(input)
                .setPositiveButton("Save", (dlg, which) -> {
                    String newName = input.getText().toString().trim();
                    if (newName.isEmpty()) return;
                    // Update live player name
                    if (state.localPlayer != null) state.localPlayer.name = newName;
                    // Persist so the main menu shows it next time
                    getContext().getSharedPreferences(PREFS, 0).edit()
                        .putString("player_name", newName).apply();
                })
                .setNegativeButton("Cancel", null)
                .show();
        });
    }

    // ═══ PER-GUN RELEASE FIRE PANEL ══════════════════════════════════════════
    // ═══ SHOP OVERLAY ════════════════════════════════════════════════════════
    // ═══ CALLBACKS ════════════════════════════════════════════════════════════
    @Override public void onHostDiscovered(String ip,String n){}
    @Override public void onJoined(int id){
        // Network thread — just assign (volatile reference, atomic)
        Player p=new Player(); p.id=id; p.name=savedName; p.guns=Gun.createAll();
        float[] sp=SPAWNS[id%SPAWNS.length]; p.x=sp[0]; p.y=sp[1];
        p.hp=100; p.alive=true;  // ← must be set or client stays "dead" forever
        state.localPlayer=p;
    }
    @Override public void onPlayerJoined(int id,String name){
        if(state.remote.containsKey(id)) return;
        Player p=new Player(); p.id=id; p.name=name; p.guns=Gun.createAll();
        float[] sp=SPAWNS[id%SPAWNS.length]; p.x=sp[0]; p.y=sp[1];
        p.hp=100; p.alive=true;
        state.remote.put(id,p); addFeed(name+" joined");
    }
    @Override public void onStateUpdate(String json){ state.pendingState=json; }
    @Override public void onDisconnected(){
        state.addFeed("⚠ Disconnected — reconnecting…");
    }
    @Override public void onInputReceived(int pid,String json){
        try{
            JSONObject o=new JSONObject(json);
            state.inputs.put(pid,new float[]{
                (float)o.getDouble("0"),(float)o.getDouble("1"),
                (float)o.getDouble("2"),(float)o.getDouble("3"),
                o.getBoolean("4")?1f:0f,(float)o.getInt("5"),o.getBoolean("6")?1f:0f,
                (float)o.optInt("7",0),(float)o.optInt("8",0),
                (float)o.optInt("9",0),(float)o.optInt("10",0),
                (float)o.optInt("11",0),(float)o.optLong("12",0),
                (float)o.optDouble("13",0),
                (float)o.optDouble("px",-1),   // [14] authoritative x (-1 = not provided)
                (float)o.optDouble("py",-1),   // [15] authoritative y
                (float)o.optInt("14",0),        // [16] dash flag (unused now, kept for compat)
                (float)o.optInt("hlt",0)        // [17] FIX Bug5: heal event flag
            });
            // FIX: Queue bomb/VC events instead of touching ArrayLists directly from the
            // network thread.  state.activeBombs and state.voltChakrams are plain ArrayLists; concurrent
            // modification from two threads causes ConcurrentModificationException crashes.
            // The game thread drains both queues inside drainNetEvents() each frame.
            if(o.optInt("bt",0)==1){
                Player p=state.remote.get(pid);
                if(p!=null&&p.alive&&p.bombs>0){
                    p.bombs--;
                    state.netBombQ.add(new float[]{pid, p.x, p.y,
                        (float)o.getDouble("bvx"),
                        (float)o.getDouble("bvy"),
                        (float)o.getDouble("bmr")});
                }
            }
            // ── Volt Chakram launch from client — queued for game thread ──────
            if(o.optInt("vcl",0)==1){
                Player p=state.remote.get(pid);
                if(p!=null&&p.alive&&weapons.isVoltChakram(p.currentGun())){
                    state.netVcQ.add(new float[]{pid,
                        (float)o.getDouble("vcax"),
                        (float)o.getDouble("vcay"),
                        (float)o.getDouble("vcc")});
                }
            }
            // ── Shadow Blade launch from client — queued for game thread ───────
            // FIX: clients send their aim direction + charge so the host can run
            // launchShadowBlade authoritatively (damage, dash, slash trail).
            if(o.optInt("sbl",0)==1){
                Player p=state.remote.get(pid);
                if(p!=null&&p.alive&&weapons.isShadowBlade(p.currentGun())){
                    state.netSbQ.add(new float[]{pid,
                        (float)o.getDouble("sbax"),
                        (float)o.getDouble("sbay"),
                        (float)o.optDouble("sbc",1.0)});
                }
            }
            // ── Quick Slash from client — queued for game thread ───────────────
            if(o.optInt("qsl",0)==1){
                Player p=state.remote.get(pid);
                if(p!=null&&p.alive&&weapons.isShadowBlade(p.currentGun())){
                    state.netQsQ.add(new float[]{pid,
                        (float)o.optDouble("qsax",0),
                        (float)o.optDouble("qsay",0)});
                }
            }
        }catch(Exception e){ e.printStackTrace(); }
    }

    // ═══ UTIL ═════════════════════════════════════════════════════════════════
    /**
     * FIX: Drains bomb and Volt-Chakram creation events that were queued by the
     * network thread into game-thread-owned ArrayLists (state.activeBombs, state.voltChakrams).
     * Must only be called from the game thread (inside update()).
     */
}
