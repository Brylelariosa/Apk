//! Where the far-terrain tiles are. Far terrain is a "clipmap": several levels of square tiles around the
//! player, each level with cells twice as big as the one before and tiles twice as large, so detail drops with
//! distance and the whole thing needs only a few hundred tiles to reach 80 kilometres.
//!
//! * level `k` has cells of `4 << k` blocks (4, 8, 16, 32 ...); a tile is `CELLS` x `CELLS` cells, so it is `128 << k` blocks wide;
//! * level `k` keeps a window of tiles around the player (see `Layout`): 9 x 9 tiles on the finest level, 7 x 7 on the next
//!   and 5 x 5 on the others, and more on the finest levels when the block world is big. The finest levels get the bigger
//!   windows because the strip just beyond the real blocks is where far terrain is looked at most closely, and what Distant
//!   Horizons does there is blocks of a few blocks' size, not of eight or sixteen;
//! * a tile of level `k` is made of four quarters, each of which is exactly one tile of level `k - 1`. Where the
//!   finer tile exists, the quarter of the coarser tile under it is left out (see `mesh::draw_runs`).

/// Levels of detail. Level 9 reaches 131 072 blocks, past the largest render distance (5000 chunks, 80 000
/// blocks); a render distance of 1000 chunks needs only the first seven.
pub const LEVELS: usize = 10;
/// Cells along one side of a tile.
pub const CELLS: usize = 32;
/// Vertices along one side of a tile.
pub const VERTS: usize = CELLS + 1;
/// Cell size, in blocks, of the finest level.
pub const BASE_CELL: i32 = 4;

/// How many tiles to each side of the player's tile each level wants when the block world is small (the windows never get
/// smaller than this). Each window must reach past the edge of the window inside it: `2 * radius(k + 1) >= radius(k) + 1`.
const BASE_WINDOWS: [i32; LEVELS] = [4, 3, 2, 2, 2, 2, 2, 2, 2, 2];
/// The finest level reaches at least this many blocks past the real blocks, wherever the player stands in his tile. With a
/// small block world the base window already does (4 tiles = 512 blocks); a big one (up to 512 blocks of real chunks, which
/// is all a phone can hold) would otherwise leave its edge to the 8-block cells of the second level, a coarser strip right
/// where the far terrain is looked at most closely.
const FINE_RING: f32 = 128.0;
/// The finest window never grows past this (tiles to each side): 5 is what the biggest block world a phone can hold (32
/// chunks) needs, and every extra ring costs a lot of triangles (about 100 000 for the ring of tiles at 5 tiles' distance).
const MAX_FINE_WINDOW: i32 = 6;

/// The windows of every level for one size of block world: how many tiles around the player's tile each level wants. A pure
/// value, so that what is wanted can be worked out (and tested) without a manager, threads or a GPU.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Layout {
    radius: [i32; LEVELS],
}

impl Layout {
    /// The windows for real blocks reaching `detail_blocks` from the player (0 or less for none).
    pub fn for_detail(detail_blocks: f32) -> Layout {
        let mut radius = BASE_WINDOWS;
        let wanted = ((detail_blocks.max(0.0) + FINE_RING) / tile_size(0) as f32).ceil() as i32;
        radius[0] = wanted.max(BASE_WINDOWS[0]).min(MAX_FINE_WINDOW);
        for level in 1..LEVELS {
            // the window inside this one reaches `radius + 1` of its tiles from the player at the most (he may stand at the
            // far edge of the middle tile), which is `(radius + 1) / 2` tiles of this level, rounded up
            let inner = radius[level - 1];
            radius[level] = BASE_WINDOWS[level].max((inner + 2) / 2);
        }
        Layout { radius }
    }

    /// A level wants the tiles up to this many tiles away from the one the player is in.
    pub fn window_radius(&self, level: usize) -> i32 {
        self.radius[level.min(LEVELS - 1)]
    }

    /// Tiles stay loaded until they are this far (in tiles) from the player's tile; a little more than the window
    /// so that walking back and forth over a tile edge does not rebuild tiles over and over.
    pub fn keep_radius(&self, level: usize) -> i32 {
        self.window_radius(level) + 1
    }

    /// Distance (blocks) from the player that the window of a level always covers, wherever in its tile the player is.
    pub fn guaranteed_reach(&self, level: usize) -> f32 {
        (self.window_radius(level) * tile_size(level)) as f32
    }

    /// How many levels are needed to see `view_blocks` far (0 when nothing is to be seen).
    pub fn levels_needed(&self, view_blocks: f32) -> usize {
        if view_blocks <= 0.0 {
            return 0;
        }
        for level in 0..LEVELS {
            if self.guaranteed_reach(level) >= view_blocks {
                return level + 1;
            }
        }
        LEVELS
    }

    /// How many tiles all the windows hold, before the view distance cuts the corners off (an upper bound on the work).
    pub fn tile_count(&self, levels: usize) -> usize {
        (0..levels.min(LEVELS)).map(|l| ((2 * self.window_radius(l) + 1) as usize).pow(2)).sum()
    }
}

impl Default for Layout {
    /// The windows of a small block world.
    fn default() -> Layout {
        Layout::for_detail(0.0)
    }
}

pub fn cell_size(level: usize) -> i32 {
    BASE_CELL << level
}

/// Width of a tile, in blocks.
pub fn tile_size(level: usize) -> i32 {
    (CELLS as i32 * BASE_CELL) << level
}

/// One tile: its level and its position on that level's grid (tile `tx` covers `tx * size .. (tx + 1) * size`).
#[derive(Clone, Copy, PartialEq, Eq, Hash, Debug, PartialOrd, Ord)]
pub struct TileKey {
    pub level: u8,
    pub tx: i32,
    pub tz: i32,
}

impl TileKey {
    pub fn new(level: usize, tx: i32, tz: i32) -> TileKey {
        TileKey { level: level as u8, tx, tz }
    }

    pub fn level(self) -> usize {
        self.level as usize
    }

    pub fn size(self) -> i32 {
        tile_size(self.level())
    }

    pub fn cell(self) -> i32 {
        cell_size(self.level())
    }

    /// World x of the tile's west edge.
    pub fn origin_x(self) -> i64 {
        self.tx as i64 * self.size() as i64
    }

    /// World z of the tile's north edge.
    pub fn origin_z(self) -> i64 {
        self.tz as i64 * self.size() as i64
    }

    /// The tile of the next finer level that fills quarter (`qx`, `qz`) of this one (each 0 or 1).
    pub fn child(self, qx: i32, qz: i32) -> TileKey {
        TileKey { level: self.level.saturating_sub(1), tx: self.tx * 2 + qx, tz: self.tz * 2 + qz }
    }

    /// Distance from the point (`x`, `z`) to the nearest edge of the tile (0 inside it).
    pub fn min_distance(self, x: f64, z: f64) -> f64 {
        let size = self.size() as f64;
        let x0 = self.origin_x() as f64;
        let z0 = self.origin_z() as f64;
        let dx = (x0 - x).max(x - (x0 + size)).max(0.0);
        let dz = (z0 - z).max(z - (z0 + size)).max(0.0);
        (dx * dx + dz * dz).sqrt()
    }
}

/// The tile of `level` that contains the point (`x`, `z`).
pub fn tile_containing(level: usize, x: f64, z: f64) -> (i32, i32) {
    let size = tile_size(level) as f64;
    ((x / size).floor() as i32, (z / size).floor() as i32)
}

/// Bit of quarter (`qx`, `qz`) in a hole mask.
pub fn quarter_bit(qx: i32, qz: i32) -> u8 {
    1u8 << (qx + 2 * qz)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn each_level_doubles_the_cell_and_the_tile() {
        assert_eq!(cell_size(0), 4);
        assert_eq!(tile_size(0), 128);
        for l in 1..LEVELS {
            assert_eq!(cell_size(l), cell_size(l - 1) * 2);
            assert_eq!(tile_size(l), tile_size(l - 1) * 2);
        }
        assert_eq!(tile_size(0) as usize, CELLS * cell_size(0) as usize);
    }

    #[test]
    fn ten_levels_reach_the_largest_render_distance() {
        let l = Layout::default();
        assert_eq!(l.levels_needed(0.0), 0);
        assert_eq!(l.levels_needed(100.0), 1);
        assert_eq!(l.levels_needed(512.0), 1);
        assert_eq!(l.levels_needed(513.0), 2);
        assert_eq!(l.levels_needed(768.0), 2);
        assert_eq!(l.levels_needed(1000.0 * 16.0), 7, "1000 chunks");
        assert_eq!(l.levels_needed(5000.0 * 16.0), LEVELS, "5000 chunks");
        assert!(l.guaranteed_reach(LEVELS - 1) >= 5000.0 * 16.0);
        assert!(l.guaranteed_reach(LEVELS - 2) < 5000.0 * 16.0);
        assert_eq!(l.levels_needed(1.0e9), LEVELS);
        // a bigger block world never needs more levels, and every size of it reaches the largest render distance
        for detail in (0..=1024).step_by(16) {
            let big = Layout::for_detail(detail as f32);
            assert!(big.levels_needed(5000.0 * 16.0) <= LEVELS);
            assert!(big.guaranteed_reach(big.levels_needed(5000.0 * 16.0) - 1) >= 5000.0 * 16.0, "detail {}", detail);
            assert!(big.levels_needed(1000.0) <= l.levels_needed(1000.0), "detail {}", detail);
        }
    }

    #[test]
    fn each_window_reaches_past_the_window_inside_it() {
        // for every size of block world: the finer window reaches this far at most (the player stands at the far edge of the
        // middle tile), and the next window must reach at least that far wherever he stands
        for detail in (0..=1100).step_by(8) {
            let l = Layout::for_detail(detail as f32);
            for k in 0..LEVELS - 1 {
                let finer_most = ((l.window_radius(k) + 1) * tile_size(k)) as f32;
                assert!(l.guaranteed_reach(k + 1) >= finer_most, "detail {}: level {} leaves a gap beyond level {}", detail, k + 1, k);
                assert!(l.keep_radius(k) > l.window_radius(k));
            }
        }
    }

    #[test]
    fn the_finest_level_has_four_block_cells_and_the_biggest_window() {
        assert_eq!(cell_size(0), 4);
        for detail in (0..=1100).step_by(8) {
            let l = Layout::for_detail(detail as f32);
            assert!(l.window_radius(0) > l.window_radius(1) && l.window_radius(1) >= l.window_radius(2), "detail {}", detail);
            // the windows only ever get smaller outwards
            for k in 1..LEVELS {
                assert!(l.window_radius(k) <= l.window_radius(k - 1), "detail {} level {}", detail, k);
            }
        }
        let l = Layout::default();
        assert!(l.window_radius(2) == l.window_radius(LEVELS - 1));
    }

    #[test]
    fn a_small_block_world_gets_the_usual_windows() {
        // 4 tiles (512 blocks) already reach 128 blocks past the real blocks out to 384 blocks (24 chunks)
        for detail in [0.0f32, 64.0, 112.0, 192.0, 320.0, 384.0] {
            let l = Layout::for_detail(detail);
            assert_eq!([l.window_radius(0), l.window_radius(1), l.window_radius(2), l.window_radius(9)], [4, 3, 2, 2], "detail {}", detail);
        }
        assert_eq!(Layout::default(), Layout::for_detail(0.0));
    }

    #[test]
    fn a_big_block_world_gets_a_finest_ring_beyond_it() {
        // every size of block world keeps 4-block cells for at least FINE_RING blocks past its real blocks
        for chunks in 4..=32 {
            let detail = chunks as f32 * 16.0;
            let l = Layout::for_detail(detail);
            assert!(l.guaranteed_reach(0) >= detail + FINE_RING, "{} chunks: the 4-block cells reach {}", chunks, l.guaranteed_reach(0));
            // and not much more than that (a tile of slack)
            assert!(l.guaranteed_reach(0) <= (detail + FINE_RING).max(512.0) + tile_size(0) as f32, "{} chunks", chunks);
        }
        assert_eq!(Layout::for_detail(32.0 * 16.0).window_radius(0), 5);
        assert_eq!(Layout::for_detail(25.0 * 16.0).window_radius(0), 5);
        assert_eq!(Layout::for_detail(24.0 * 16.0).window_radius(0), 4);
        assert_eq!(Layout::for_detail(1.0e6).window_radius(0), MAX_FINE_WINDOW, "capped");
    }

    #[test]
    fn the_number_of_tiles_stays_bounded_for_every_size_of_block_world() {
        let mut last = 0;
        for detail in (0..=1100).step_by(8) {
            let n = Layout::for_detail(detail as f32).tile_count(LEVELS);
            assert!(n >= last, "more block world, fewer tiles at {}", detail);
            last = n;
        }
        // the biggest block world a phone can hold (32 chunks), and the cap
        assert!(Layout::for_detail(512.0).tile_count(LEVELS) <= 380, "{}", Layout::for_detail(512.0).tile_count(LEVELS));
        assert!(Layout::for_detail(1.0e6).tile_count(LEVELS) <= 480);
        assert_eq!(Layout::for_detail(1.0e6).window_radius(0), MAX_FINE_WINDOW);
        assert_eq!(Layout::default().tile_count(LEVELS), 81 + 49 + 8 * 25);
    }

    #[test]
    fn a_tile_is_exactly_four_tiles_of_the_finer_level() {
        for l in 1..LEVELS {
            let t = TileKey::new(l, -3, 5);
            for qz in 0..2 {
                for qx in 0..2 {
                    let c = t.child(qx, qz);
                    assert_eq!(c.level(), l - 1);
                    assert_eq!(c.origin_x(), t.origin_x() + qx as i64 * c.size() as i64);
                    assert_eq!(c.origin_z(), t.origin_z() + qz as i64 * c.size() as i64);
                    assert_eq!(c.size() * 2, t.size());
                }
            }
        }
    }

    #[test]
    fn tiles_are_found_by_floor_division_so_negatives_work() {
        assert_eq!(tile_containing(0, 0.0, 0.0), (0, 0));
        assert_eq!(tile_containing(1, 255.9, 256.0), (0, 1));
        assert_eq!(tile_containing(1, -0.1, -256.1), (-1, -2));
        assert_eq!(tile_containing(3, -1.0, 2047.0), (-1, 1));
    }

    #[test]
    fn distance_to_a_tile_is_zero_inside_and_euclidean_outside() {
        let t = TileKey::new(1, 1, 0); // x 256..512, z 0..256
        assert_eq!(t.min_distance(300.0, 100.0), 0.0);
        assert_eq!(t.min_distance(256.0, 0.0), 0.0);
        assert!((t.min_distance(256.0 - 30.0, 100.0) - 30.0).abs() < 1e-9);
        assert!((t.min_distance(512.0 + 30.0, 256.0 + 40.0) - 50.0).abs() < 1e-9);
    }

    #[test]
    fn quarter_bits_are_distinct() {
        let mut seen = 0u8;
        for qz in 0..2 {
            for qx in 0..2 {
                let b = quarter_bit(qx, qz);
                assert_eq!(seen & b, 0);
                seen |= b;
            }
        }
        assert_eq!(seen, 0b1111);
    }
}
