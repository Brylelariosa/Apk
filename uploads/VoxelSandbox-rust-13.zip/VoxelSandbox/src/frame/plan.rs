//! How a frame's picture of the 3D world gets to the screen, decided without a GPU so that it can be tested.
//!
//! There are three ways:
//!
//! * **straight to the screen** (the normal case: resolution 100 %, game running);
//! * **through an off-screen picture** drawn at a smaller size and stretched over the screen (the resolution setting is
//!   below 100 %, which cuts the pixel work in proportion);
//! * **through an off-screen picture that is kept** while the game is paused: nothing in a paused world moves, so its picture
//!   is drawn once and put on the screen again in the frames after, instead of drawing the world over and over behind the
//!   menu (which heats the phone for nothing).
//!
//! The renderer asks the `Planner` at the start of every frame, does what it says and reports back what became of the
//! picture (it was drawn and kept; the GPU refused to make one). The planner remembers what the kept picture shows and which
//! sizes the driver refused. `RouteLog` turns a change of route into a line for the debug log, so that a glitch seen on a
//! phone can be matched against the way the frame was drawn.

/// How many refused sizes are remembered (so a size the GPU said no to is not retried every frame).
pub const REFUSED_SIZES_KEPT: usize = 16;

/// The size to render at for a screen of `width` x `height` pixels at `percent` of its native resolution.
/// Even numbers, never tiny, never bigger than the screen.
pub fn scaled_size(width: i32, height: i32, percent: i32) -> (i32, i32) {
    let p = percent.max(10).min(100) as i64;
    let w = ((width as i64 * p / 100) as i32).max(64) & !1;
    let h = ((height as i64 * p / 100) as i32).max(64) & !1;
    (w.min(width.max(2)), h.min(height.max(2)))
}

/// Everything that decides what the world looks like while the game is paused. When it is the same as for the picture already
/// kept, that picture is shown again instead of drawing the world once more.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct PictureKey {
    /// The screen's size in pixels.
    pub size: (i32, i32),
    /// Render distance, detail radius, resolution percent, clouds.
    pub settings: (i32, i32, i32, bool),
    /// How many block meshes and far tiles are on the GPU (a mesh finishing changes the picture).
    pub meshes: (usize, usize),
    /// The camera as bit patterns: x, y, z, yaw, pitch.
    pub camera: [u64; 5],
}

/// What the planner needs to know about the frame that is starting.
#[derive(Clone, Copy, Debug)]
pub struct FrameNeeds {
    /// The size of the screen in pixels.
    pub screen: (i32, i32),
    /// The 3D world is drawn behind the UI this frame (not on the main menu).
    pub world_on: bool,
    /// The game is paused: nothing in the world moves.
    pub frozen: bool,
    /// The resolution setting in effect (10 to 100).
    pub percent: i32,
    /// An off-screen picture can be put on the screen at all (the program that does it was built).
    pub offscreen_ok: bool,
}

/// What a frame does with the 3D world.
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum Route {
    /// No 3D world behind the UI (the menus): only the sky.
    Sky,
    /// The world is drawn straight onto the screen.
    Direct,
    /// The world goes through an off-screen picture of `size` pixels.
    Picture { size: (i32, i32), source: PictureSource },
}

/// Where the off-screen picture of a `Route::Picture` frame comes from.
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum PictureSource {
    /// Draw the world into the picture now; it is used for this frame only (the game is running).
    Fresh,
    /// Draw the world into the picture now and keep it: the game is paused. The renderer says `Planner::picture_kept` when
    /// the picture is drawn, and the frames after this one can show it again.
    FreshKeep(PictureKey),
    /// The picture kept earlier is still what the paused world looks like: put it on the screen again.
    Kept,
}

impl Route {
    /// The route in words, for the debug log. It changes when the way of drawing changes (not between frames that draw a
    /// fresh picture and frames that show a kept one).
    pub fn label(&self, screen: (i32, i32)) -> String {
        match *self {
            Route::Sky => "sky only (no world behind the menu)".to_string(),
            Route::Direct => format!("world drawn straight to the screen at {}x{}", screen.0, screen.1),
            Route::Picture { size, source } => {
                let paused = match source {
                    PictureSource::Fresh => "",
                    _ => ", paused: the picture is kept",
                };
                if size == screen {
                    format!("world drawn into an off-screen picture as big as the screen ({}x{}){}", size.0, size.1, paused)
                } else {
                    format!("world drawn into an off-screen picture of {}x{}, stretched over {}x{}{}", size.0, size.1, screen.0, screen.1, paused)
                }
            }
        }
    }
}

/// Decides the route of every frame and remembers what it needs between frames.
pub struct Planner {
    refused: Vec<(i32, i32)>,
    /// What the picture kept in the off-screen target shows (`None`: it holds nothing that can be reused).
    kept: Option<PictureKey>,
}

impl Planner {
    pub fn new() -> Planner {
        Planner { refused: Vec::new(), kept: None }
    }

    /// The route for the frame described by `needs`. `key` is what the paused world looks like right now; it is only looked
    /// at while the game is paused (the renderer need not work it out otherwise).
    pub fn plan(&mut self, needs: &FrameNeeds, key: Option<PictureKey>) -> Route {
        if !needs.frozen || !needs.world_on {
            self.kept = None;
        }
        if !needs.world_on {
            return Route::Sky;
        }
        let (width, height) = needs.screen;
        let scaled = scaled_size(width, height, needs.percent);
        let smaller = needs.percent < 100 && scaled != (width, height);
        // a kept picture at full resolution is exactly as big as the screen
        let size = if smaller { scaled } else { (width, height) };
        let wanted = smaller || needs.frozen;
        if !wanted || !needs.offscreen_ok || self.refused.contains(&size) {
            self.kept = None;
            return Route::Direct;
        }
        let key = if needs.frozen { key } else { None };
        let source = match key {
            Some(k) if self.kept == Some(k) => PictureSource::Kept,
            Some(k) => PictureSource::FreshKeep(k),
            None => PictureSource::Fresh,
        };
        Route::Picture { size, source }
    }

    /// The picture for `key` has been drawn into the off-screen target and stays there.
    pub fn picture_kept(&mut self, key: PictureKey) {
        self.kept = Some(key);
    }

    /// The off-screen target was dropped or made anew: whatever it held is gone.
    pub fn picture_lost(&mut self) {
        self.kept = None;
    }

    /// The GPU would not make (or use) an off-screen picture of this size: it is drawn straight to the screen from now on.
    pub fn refuse(&mut self, size: (i32, i32)) {
        if self.refused.len() >= REFUSED_SIZES_KEPT {
            self.refused.clear();
        }
        if !self.refused.contains(&size) {
            self.refused.push(size);
        }
        self.kept = None;
    }

    /// True if a picture of `size` was refused earlier.
    pub fn is_refused(&self, size: (i32, i32)) -> bool {
        self.refused.contains(&size)
    }
}

impl Default for Planner {
    fn default() -> Planner {
        Planner::new()
    }
}

/// Remembers how the last frame was drawn and says when that changes.
pub struct RouteLog {
    last: Option<String>,
}

impl RouteLog {
    pub fn new() -> RouteLog {
        RouteLog { last: None }
    }

    /// The line for the debug log if `route` is a different way of drawing than the frame before (and the first frame's).
    pub fn changed(&mut self, route: &Route, screen: (i32, i32)) -> Option<String> {
        let label = route.label(screen);
        if self.last.as_deref() == Some(label.as_str()) {
            return None;
        }
        let line = format!("frame route: {}", label);
        self.last = Some(label);
        Some(line)
    }
}

impl Default for RouteLog {
    fn default() -> RouteLog {
        RouteLog::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    const SCREEN: (i32, i32) = (1800, 810);

    fn needs(percent: i32, frozen: bool) -> FrameNeeds {
        FrameNeeds { screen: SCREEN, world_on: true, frozen, percent, offscreen_ok: true }
    }

    fn key(camera_x: u64) -> PictureKey {
        PictureKey { size: SCREEN, settings: (10, 4, 85, true), meshes: (100, 12), camera: [camera_x, 2, 3, 4, 5] }
    }

    #[test]
    fn scaled_sizes_are_even_and_never_bigger_than_the_screen() {
        assert_eq!(scaled_size(2400, 1080, 100), (2400, 1080));
        assert_eq!(scaled_size(2400, 1080, 50), (1200, 540));
        let (w, h) = scaled_size(2401, 1081, 75);
        assert!(w % 2 == 0 && h % 2 == 0 && w <= 2401 && h <= 1081);
        let (w, h) = scaled_size(100, 50, 40);
        assert!(w >= 2 && h >= 2 && w <= 100 && h <= 50, "{}x{}", w, h);
        let (w, h) = scaled_size(3000, 1500, 0);
        assert!(w >= 64 && h >= 64);
        assert_eq!(scaled_size(1800, 810, 85), (1530, 688));
    }

    #[test]
    fn the_menus_draw_only_the_sky() {
        let mut p = Planner::new();
        let n = FrameNeeds { world_on: false, ..needs(85, false) };
        assert_eq!(p.plan(&n, None), Route::Sky);
        // also when "frozen" (a world that is not shown is not drawn, whatever its state)
        let n = FrameNeeds { world_on: false, ..needs(100, true) };
        assert_eq!(p.plan(&n, Some(key(1))), Route::Sky);
    }

    #[test]
    fn a_running_game_at_full_resolution_draws_straight_to_the_screen() {
        let mut p = Planner::new();
        assert_eq!(p.plan(&needs(100, false), None), Route::Direct);
    }

    #[test]
    fn below_full_resolution_the_world_goes_through_a_smaller_picture() {
        let mut p = Planner::new();
        assert_eq!(p.plan(&needs(85, false), None), Route::Picture { size: (1530, 688), source: PictureSource::Fresh });
        assert_eq!(p.plan(&needs(70, false), None), Route::Picture { size: (1260, 566), source: PictureSource::Fresh });
        // a percentage that rounds to the screen's own size is not "smaller"
        let tiny = FrameNeeds { screen: (64, 64), ..needs(99, false) };
        assert_eq!(p.plan(&tiny, None), Route::Direct);
    }

    #[test]
    fn a_paused_game_keeps_its_picture_and_shows_it_again_until_something_changes() {
        let mut p = Planner::new();
        let n = needs(85, true);
        let first = p.plan(&n, Some(key(1)));
        assert_eq!(first, Route::Picture { size: (1530, 688), source: PictureSource::FreshKeep(key(1)) });
        // the renderer has drawn it
        p.picture_kept(key(1));
        for _ in 0..5 {
            assert_eq!(p.plan(&n, Some(key(1))), Route::Picture { size: (1530, 688), source: PictureSource::Kept });
        }
        // the camera moved (or a mesh arrived): drawn afresh
        assert_eq!(p.plan(&n, Some(key(2))), Route::Picture { size: (1530, 688), source: PictureSource::FreshKeep(key(2)) });
    }

    #[test]
    fn a_picture_that_was_never_reported_as_kept_is_drawn_again() {
        let mut p = Planner::new();
        let n = needs(85, true);
        for _ in 0..3 {
            assert!(matches!(p.plan(&n, Some(key(1))), Route::Picture { source: PictureSource::FreshKeep(_), .. }));
        }
    }

    #[test]
    fn paused_at_full_resolution_keeps_a_picture_as_big_as_the_screen() {
        let mut p = Planner::new();
        let n = needs(100, true);
        assert_eq!(p.plan(&n, Some(key(1))), Route::Picture { size: SCREEN, source: PictureSource::FreshKeep(key(1)) });
        p.picture_kept(key(1));
        assert_eq!(p.plan(&n, Some(key(1))), Route::Picture { size: SCREEN, source: PictureSource::Kept });
    }

    #[test]
    fn a_kept_picture_does_not_survive_the_game_running_again() {
        let mut p = Planner::new();
        p.plan(&needs(85, true), Some(key(1)));
        p.picture_kept(key(1));
        // resumed: the target is used for live frames, so the kept picture is gone
        assert!(matches!(p.plan(&needs(85, false), None), Route::Picture { source: PictureSource::Fresh, .. }));
        // paused again with exactly the same world: it must be drawn again, not shown from the old picture
        assert!(matches!(p.plan(&needs(85, true), Some(key(1))), Route::Picture { source: PictureSource::FreshKeep(_), .. }));
        // the same after a stretch at full resolution (no target at all)
        p.picture_kept(key(1));
        assert_eq!(p.plan(&needs(100, false), None), Route::Direct);
        assert!(matches!(p.plan(&needs(85, true), Some(key(1))), Route::Picture { source: PictureSource::FreshKeep(_), .. }));
    }

    #[test]
    fn a_lost_target_takes_the_kept_picture_with_it() {
        let mut p = Planner::new();
        p.plan(&needs(85, true), Some(key(1)));
        p.picture_kept(key(1));
        p.picture_lost();
        assert!(matches!(p.plan(&needs(85, true), Some(key(1))), Route::Picture { source: PictureSource::FreshKeep(_), .. }));
    }

    #[test]
    fn a_size_the_gpu_refused_is_drawn_straight_and_only_that_size() {
        let mut p = Planner::new();
        p.refuse((1530, 688));
        assert_eq!(p.plan(&needs(85, false), None), Route::Direct);
        assert!(p.is_refused((1530, 688)));
        // other sizes still get their picture
        assert_eq!(p.plan(&needs(70, false), None), Route::Picture { size: (1260, 566), source: PictureSource::Fresh });
        // and so does the screen-sized picture of a paused game
        assert!(matches!(p.plan(&needs(100, true), Some(key(1))), Route::Picture { size: SCREEN, .. }));
    }

    #[test]
    fn refusing_clears_what_was_kept() {
        let mut p = Planner::new();
        p.plan(&needs(100, true), Some(key(1)));
        p.picture_kept(key(1));
        p.refuse(SCREEN);
        assert_eq!(p.plan(&needs(100, true), Some(key(1))), Route::Direct);
    }

    #[test]
    fn the_list_of_refused_sizes_stays_small() {
        let mut p = Planner::new();
        for i in 0..100 {
            p.refuse((100 + i * 2, 100));
            assert!(p.refused.len() <= REFUSED_SIZES_KEPT);
        }
        // refusing the same size twice does not fill the list
        let mut q = Planner::new();
        for _ in 0..50 {
            q.refuse((640, 480));
        }
        assert_eq!(q.refused.len(), 1);
    }

    #[test]
    fn without_a_way_to_put_a_picture_on_the_screen_everything_is_drawn_straight() {
        let mut p = Planner::new();
        let off = |percent, frozen| FrameNeeds { offscreen_ok: false, ..needs(percent, frozen) };
        assert_eq!(p.plan(&off(85, false), None), Route::Direct);
        assert_eq!(p.plan(&off(100, true), Some(key(1))), Route::Direct);
        // the menus do not need it
        let menu = FrameNeeds { world_on: false, ..off(85, false) };
        assert_eq!(p.plan(&menu, None), Route::Sky);
    }

    #[test]
    fn the_route_log_speaks_only_when_the_way_of_drawing_changes() {
        let mut log = RouteLog::new();
        let direct = Route::Direct;
        let live = Route::Picture { size: (1530, 688), source: PictureSource::Fresh };
        let first_paused = Route::Picture { size: (1530, 688), source: PictureSource::FreshKeep(key(1)) };
        let shown_again = Route::Picture { size: (1530, 688), source: PictureSource::Kept };
        let first = log.changed(&direct, SCREEN).expect("the first frame is always said");
        assert!(first.contains("straight to the screen at 1800x810"), "{}", first);
        assert!(log.changed(&direct, SCREEN).is_none());
        let line = log.changed(&live, SCREEN).expect("a smaller picture");
        assert!(line.contains("1530x688") && line.contains("stretched over 1800x810") && !line.contains("paused"), "{}", line);
        assert!(log.changed(&live, SCREEN).is_none());
        let line = log.changed(&first_paused, SCREEN).expect("the pause");
        assert!(line.contains("paused"), "{}", line);
        // drawing the kept picture the first time and showing it again are one and the same way of drawing
        assert!(log.changed(&shown_again, SCREEN).is_none());
        assert!(log.changed(&live, SCREEN).is_some());
        let kept_full = Route::Picture { size: SCREEN, source: PictureSource::FreshKeep(key(1)) };
        let line = log.changed(&kept_full, SCREEN).expect("a kept picture at full size");
        assert!(line.contains("as big as the screen (1800x810)") && line.contains("paused"), "{}", line);
        assert!(log.changed(&live, SCREEN).is_some());
        // the same route on a screen of another size is another line (a rotation, a new window)
        assert!(log.changed(&live, (900, 405)).is_some());
        assert!(log.changed(&Route::Sky, SCREEN).unwrap().contains("sky"));
    }

    /// Goes through a long pseudo-random course of settings and states and checks what must hold in every frame. The state
    /// changes only now and then (as in a game: the same picture for many frames in a row), so that every route is met often.
    #[test]
    fn whatever_happens_the_route_obeys_its_rules() {
        let mut seed = 0x9E3779B97F4A7C15u64;
        let mut next = move |n: u64| {
            seed ^= seed << 13;
            seed ^= seed >> 7;
            seed ^= seed << 17;
            seed % n
        };
        let screens = [(1800, 810), (900, 405), (2400, 1080)];
        let percents = [100, 85, 70, 55, 40, 85];
        let (mut screen, mut percent, mut world_on, mut frozen, mut offscreen_ok) = (screens[0], 85, true, false, true);
        let (mut meshes, mut camera) = (0u64, 0u64);
        let mut p = Planner::new();
        let mut kept_by_renderer: Option<PictureKey> = None;
        let (mut shown_again, mut drawn_and_kept, mut fresh, mut direct, mut sky) = (0, 0, 0, 0, 0);
        for _ in 0..30_000 {
            if next(40) == 0 {
                screen = screens[next(3) as usize];
            }
            if next(25) == 0 {
                percent = percents[next(6) as usize];
            }
            // mostly in the world, now and then a visit to the main menu
            if if world_on { next(250) == 0 } else { next(12) == 0 } {
                world_on = !world_on;
            }
            if next(12) == 0 {
                frozen = !frozen;
            }
            if next(300) == 0 {
                offscreen_ok = !offscreen_ok;
            }
            if next(15) == 0 {
                meshes += 1;
            }
            if next(10) == 0 {
                camera += 1;
            }
            let n = FrameNeeds { screen, world_on, frozen: frozen && world_on, percent, offscreen_ok };
            let k = PictureKey { size: screen, settings: (10, 4, percent, true), meshes: (meshes as usize, 0), camera: [camera, 0, 0, 0, 0] };
            if next(200) == 0 {
                p.picture_lost();
                kept_by_renderer = None;
            }
            if next(400) == 0 {
                p.refuse(scaled_size(screen.0, screen.1, percent));
                kept_by_renderer = None;
            }
            let route = p.plan(&n, Some(k));
            match route {
                Route::Sky => {
                    assert!(!n.world_on);
                    kept_by_renderer = None;
                    sky += 1;
                }
                Route::Direct => {
                    assert!(n.world_on);
                    kept_by_renderer = None;
                    direct += 1;
                }
                Route::Picture { size, source } => {
                    assert!(n.world_on && n.offscreen_ok);
                    assert!(size.0 <= n.screen.0 && size.1 <= n.screen.1 && size.0 >= 2 && size.1 >= 2, "{:?} on {:?}", size, n.screen);
                    assert!(!p.is_refused(size), "a refused size was planned");
                    assert!(n.percent < 100 || n.frozen, "a picture was planned for a running game at full resolution");
                    match source {
                        PictureSource::Fresh => {
                            assert!(!n.frozen, "a paused game's picture must be kept");
                            fresh += 1;
                        }
                        PictureSource::FreshKeep(kk) => {
                            assert!(n.frozen);
                            assert_eq!(kk, k);
                            p.picture_kept(kk);
                            kept_by_renderer = Some(kk);
                            drawn_and_kept += 1;
                        }
                        PictureSource::Kept => {
                            // shown again only if the renderer really holds exactly this picture, and the game is paused
                            assert!(n.frozen);
                            assert_eq!(kept_by_renderer, Some(k), "a picture that was not kept was shown again");
                            shown_again += 1;
                        }
                    }
                }
            }
            if !n.frozen {
                kept_by_renderer = None;
            }
        }
        // the course must really have visited every branch often, or the rules above prove nothing
        assert!(shown_again > 500 && drawn_and_kept > 300 && fresh > 500 && direct > 500 && sky > 100, "{} {} {} {} {}", shown_again, drawn_and_kept, fresh, direct, sky);
    }
}
