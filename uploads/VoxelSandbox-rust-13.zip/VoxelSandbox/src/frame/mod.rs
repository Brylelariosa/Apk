//! Decisions about how a frame is put together that need no GPU, so they are tested on a normal computer: the
//! renderer (`render`, Android only) asks `plan::Planner` what to do and does it.

pub mod plan;

pub use plan::{scaled_size, FrameNeeds, PictureKey, PictureSource, Planner, Route, RouteLog};
