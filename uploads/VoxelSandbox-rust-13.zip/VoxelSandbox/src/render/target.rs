//! The off-screen picture the 3D world is drawn into when the "resolution" setting is below 100%, and while the game is
//! paused (`frame::plan` decides when).
//!
//! Drawing the world into a smaller picture and stretching it over the screen cuts the pixel work in proportion (60%
//! resolution = 36% of the pixels). The menus and the HUD are still drawn at the screen's real size on top, so text stays
//! sharp. While the game is paused nothing in the world moves, so its picture is drawn once and put on the screen again in
//! the frames after, instead of drawing the whole world again and again behind a menu (which heats the phone for nothing).
//!
//! # How a frame goes
//!
//! Every frame is made of whole passes, each starting with a clear of everything it draws into:
//!
//! 1. `SceneTarget::begin_pass`, then the world: the picture, a texture, with a depth buffer next to it;
//! 2. `begin_screen_pass`, then `composite::Composite::draw` (one triangle that samples the picture), then the UI.
//!
//! The screen is never touched before step 2, and nothing is copied between buffers: the picture is put on the screen the
//! way every post-processing step of every phone game does it. A paused game's picture is simply left in the texture and
//! drawn again.
//!
//! # What this file deliberately does not do
//!
//! Up to 0.8.2 the picture was a renderbuffer, copied to the screen with `glBlitFramebuffer`; `glInvalidateFramebuffer`
//! told the GPU it need not keep the picture's depth (and, for a running game, its colour) after the copy; and the screen was
//! cleared at the start of the frame *before* the picture was drawn, which splits the screen's own work in two around the
//! picture's. On the Infinix Hot 11 (Mali-G52) the screen then flashed whenever the resolution was below 100%: a frame in
//! which only that early clear had reached the screen (flat sky colour, black staircase of 16 pixel columns, no HUD at all)
//! alternated with good ones. At 100% (no picture) it did not happen. Nothing could reproduce it away from the phone, so the
//! cause is a best guess (the driver losing track of the screen's tiles around the blit and the invalidate), and everything
//! that guess depends on is left out now: no blit, no invalidate, no early clear. Do not bring them back to save bandwidth
//! without a phone to look at the result on.

use super::gl::*;
use super::programs::SCENE_UNIT;

/// A colour texture + depth renderbuffer the world can be drawn into.
pub struct SceneTarget {
    fbo: GLuint,
    /// The picture (a texture, so that `composite` can sample it).
    color: GLuint,
    depth: GLuint,
    width: i32,
    height: i32,
}

impl SceneTarget {
    /// Creates a target of the given size, or `None` if the driver does not accept it (the caller then draws
    /// straight to the screen).
    pub fn create(width: i32, height: i32) -> Option<SceneTarget> {
        if width < 2 || height < 2 {
            return None;
        }
        let mut fbo: GLuint = 0;
        let mut color: GLuint = 0;
        let mut depth: GLuint = 0;
        unsafe {
            // clear any error left over from earlier code so the check below is about this function only
            while glGetError() != 0 {}
            glGenTextures(1, &mut color as *mut GLuint);
            // the picture's own unit: no other texture binding is disturbed by making it
            glActiveTexture(GL_TEXTURE0 + SCENE_UNIT as GLenum);
            glBindTexture(GL_TEXTURE_2D, color);
            glTexStorage2D(GL_TEXTURE_2D, 1, GL_RGBA8_FORMAT, width, height);
            // one level only, so the minification filter must not be a mipmap one (the default is: the texture would
            // count as incomplete and be sampled as black)
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
            glBindTexture(GL_TEXTURE_2D, 0);
            glActiveTexture(GL_TEXTURE0);

            glGenRenderbuffers(1, &mut depth as *mut GLuint);
            glBindRenderbuffer(GL_RENDERBUFFER, depth);
            glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH_COMPONENT24, width, height);
            glBindRenderbuffer(GL_RENDERBUFFER, 0);

            glGenFramebuffers(1, &mut fbo as *mut GLuint);
            glBindFramebuffer(GL_FRAMEBUFFER, fbo);
            glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, color, 0);
            glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_RENDERBUFFER, depth);
            let status = glCheckFramebufferStatus(GL_FRAMEBUFFER);
            let error = glGetError();
            glBindFramebuffer(GL_FRAMEBUFFER, 0);
            if status != GL_FRAMEBUFFER_COMPLETE || error != 0 {
                crate::logw!("render target {}x{} refused (status 0x{:x}, error 0x{:x})", width, height, status, error);
                glDeleteFramebuffers(1, &fbo as *const GLuint);
                glDeleteTextures(1, &color as *const GLuint);
                glDeleteRenderbuffers(1, &depth as *const GLuint);
                return None;
            }
        }
        Some(SceneTarget { fbo, color, depth, width, height })
    }

    pub fn size(&self) -> (i32, i32) {
        (self.width, self.height)
    }

    /// The picture, for `composite` to sample.
    pub fn texture(&self) -> GLuint {
        self.color
    }

    /// Starts the pass that draws the world into this target: makes it the surface drawing goes to, covers it with the
    /// viewport and clears all of it (colour to `color`, depth to far), so that the pass never loads what an earlier frame left
    /// there.
    pub fn begin_pass(&self, color: [f32; 3]) {
        unsafe {
            glBindFramebuffer(GL_FRAMEBUFFER, self.fbo);
            glViewport(0, 0, self.width, self.height);
            clear_all(color);
        }
    }

    /// Frees the GPU objects (needs the context that made them).
    pub fn delete(self) {
        unsafe {
            glDeleteFramebuffers(1, &self.fbo as *const GLuint);
            glDeleteTextures(1, &self.color as *const GLuint);
            glDeleteRenderbuffers(1, &self.depth as *const GLuint);
        }
    }
}

/// Starts the screen's pass of a frame: makes the screen the surface drawing goes to, covers it with the viewport and clears
/// all of it. The screen is not touched before this, so the frame's work on it is one pass.
pub fn begin_screen_pass(width: i32, height: i32, color: [f32; 3]) {
    unsafe {
        glBindFramebuffer(GL_FRAMEBUFFER, 0);
        glViewport(0, 0, width, height);
        clear_all(color);
    }
}

/// Clears colour and depth of the surface that is being drawn to, with the state a clear needs (the scissor box and the
/// depth mask both limit a clear).
unsafe fn clear_all(color: [f32; 3]) {
    glDisable(GL_SCISSOR_TEST);
    glDepthMask(GL_TRUE);
    glDisable(GL_BLEND);
    glClearColor(color[0], color[1], color[2], 1.0);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
}
