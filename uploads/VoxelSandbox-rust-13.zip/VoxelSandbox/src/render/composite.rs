//! Puts the off-screen picture of the world on the screen (see `target`): one triangle that covers the screen and a program
//! that looks the picture up, bilinearly filtered, so a picture smaller than the screen is stretched over it.

use super::gl::*;
use super::programs::SCENE_UNIT;
use super::shader::Program;
use super::shaders::{COMPOSITE_FS, COMPOSITE_VS};

pub struct Composite {
    prog: Program,
    scene: GLint,
}

impl Composite {
    /// Builds the program. A driver that cannot only costs the lower-resolution drawing (the world is then drawn at full
    /// size), see `Renderer::new`.
    pub fn new() -> Result<Composite, String> {
        let p = Program::new(COMPOSITE_VS, COMPOSITE_FS).map_err(|e| format!("composite {}", e))?;
        Ok(Composite { scene: p.uniform("uScene"), prog: p })
    }

    /// Draws `texture` over the whole surface being drawn to (the caller has made the screen that surface, set its viewport
    /// and cleared it). `empty_vao` is any vertex array with no attributes: the corners come from the vertex number.
    pub fn draw(&self, texture: GLuint, empty_vao: GLuint) {
        unsafe {
            glDisable(GL_DEPTH_TEST);
            glDisable(GL_CULL_FACE);
            glDisable(GL_BLEND);
            self.prog.use_program();
            glActiveTexture(GL_TEXTURE0 + SCENE_UNIT as GLenum);
            glBindTexture(GL_TEXTURE_2D, texture);
            glUniform1i(self.scene, SCENE_UNIT);
            glBindVertexArray(empty_vao);
            glDrawArrays(GL_TRIANGLES, 0, 3);
            glBindVertexArray(0);
            // the picture is the colour buffer of the next frame's pass: no texture unit may still hold it by then
            glBindTexture(GL_TEXTURE_2D, 0);
            glActiveTexture(GL_TEXTURE0);
        }
    }
}
