//! The GLSL programs the world and the UI are drawn with, and the uniform locations they need.

use super::gl::*;
use super::shader::Program;
use super::shaders::*;

/// One build of the terrain shader and where its uniforms are. The solid blocks and the alpha-tested things
/// (leaves, plants) use different builds of the same shader text, see `shaders`.
pub struct TerrainVariant {
    pub prog: Program,
    pub view_proj: GLint,
    pub offset: GLint,
    pub tex: GLint,
    pub fog_color: GLint,
    pub fog: GLint,
}

impl TerrainVariant {
    fn new(defines: &[&str], what: &str) -> Result<TerrainVariant, String> {
        let p = Program::with_defines(TERRAIN_VS, TERRAIN_FS, defines).map_err(|e| format!("{} {}", what, e))?;
        Ok(TerrainVariant {
            view_proj: p.uniform("uViewProj"),
            offset: p.uniform("uOffset"),
            tex: p.uniform("uTex"),
            fog_color: p.uniform("uFogColor"),
            fog: p.uniform("uFog"),
            prog: p,
        })
    }
}

pub struct TerrainProg {
    /// Solid blocks: no `discard`, so hidden pixels can be rejected before they are shaded.
    pub opaque: TerrainVariant,
    /// Leaves and plants: pixels that are see-through in the texture are discarded.
    pub alpha: TerrainVariant,
}

pub struct WaterProg {
    pub prog: Program,
    pub view_proj: GLint,
    pub offset: GLint,
    pub tex: GLint,
    pub fog_color: GLint,
    pub fog: GLint,
    pub time: GLint,
}

pub struct SkyProg {
    pub prog: Program,
    pub forward: GLint,
    pub right: GLint,
    pub up: GLint,
    pub tan: GLint,
    pub horizon: GLint,
    pub zenith: GLint,
    pub sun: GLint,
}

pub struct CloudProg {
    pub prog: Program,
    pub view_proj: GLint,
    pub height: GLint,
    pub half: GLint,
    pub map: GLint,
    pub noise: GLint,
}

pub struct LineProg {
    pub prog: Program,
    pub view_proj: GLint,
    pub color: GLint,
}

pub struct UiProg {
    pub prog: Program,
    pub proj: GLint,
    pub tex: GLint,
    pub font: GLint,
}

/// The texture unit the map picture is bound to while it is drawn (unit 0 has the block textures, 1 the font, 2 the
/// cloud noise).
pub const MAP_UNIT: GLint = 3;

/// The texture unit the off-screen picture of the world is bound to while it is put on the screen (see `composite`). No
/// other program reads this unit, and it is left empty otherwise, so the picture is never bound to a unit while it is also
/// the colour buffer something is drawn into.
pub const SCENE_UNIT: GLint = 4;

/// The program that draws the world map picture (the texture on unit `MAP_UNIT`). Unlike the others it is built when the
/// map is first drawn, not when the renderer starts, so a driver that cannot build it only loses the map.
pub struct MapProg {
    pub prog: Program,
    pub proj: GLint,
    pub map: GLint,
}

impl MapProg {
    pub fn new() -> Result<MapProg, String> {
        let p = Program::new(UI_VS, MAP_FS).map_err(|e| format!("map {}", e))?;
        Ok(MapProg { proj: p.uniform("uProj"), map: p.uniform("uMap"), prog: p })
    }
}

pub struct WorldGl {
    pub terrain: TerrainProg,
    pub water: WaterProg,
    pub sky: SkyProg,
    pub cloud: CloudProg,
    pub line: LineProg,
}

impl WorldGl {
    pub fn new() -> Result<WorldGl, String> {
        let terrain = TerrainProg {
            opaque: TerrainVariant::new(&[], "terrain")?,
            alpha: TerrainVariant::new(&[DEFINE_ALPHA_TEST], "terrain (alpha test)")?,
        };
        let wp = Program::new(WATER_VS, WATER_FS).map_err(|e| format!("water {}", e))?;
        let water = WaterProg {
            view_proj: wp.uniform("uViewProj"),
            offset: wp.uniform("uOffset"),
            tex: wp.uniform("uTex"),
            fog_color: wp.uniform("uFogColor"),
            fog: wp.uniform("uFog"),
            time: wp.uniform("uTime"),
            prog: wp,
        };
        let sp = Program::new(SKY_VS, SKY_FS).map_err(|e| format!("sky {}", e))?;
        let sky = SkyProg {
            forward: sp.uniform("uForward"),
            right: sp.uniform("uRight"),
            up: sp.uniform("uUp"),
            tan: sp.uniform("uTan"),
            horizon: sp.uniform("uHorizon"),
            zenith: sp.uniform("uZenith"),
            sun: sp.uniform("uSunDir"),
            prog: sp,
        };
        let cp = Program::new(CLOUD_VS, CLOUD_FS).map_err(|e| format!("cloud {}", e))?;
        let cloud = CloudProg {
            view_proj: cp.uniform("uViewProj"),
            height: cp.uniform("uHeight"),
            half: cp.uniform("uHalf"),
            map: cp.uniform("uMap"),
            noise: cp.uniform("uNoise"),
            prog: cp,
        };
        let lp = Program::new(LINE_VS, LINE_FS).map_err(|e| format!("line {}", e))?;
        let line = LineProg { view_proj: lp.uniform("uViewProj"), color: lp.uniform("uColor"), prog: lp };
        Ok(WorldGl { terrain, water, sky, cloud, line })
    }
}
