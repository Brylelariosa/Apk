//! OpenGL ES drawing. Only built for Android (the GL library is not on a normal computer); what can be decided without a
//! GPU (which way a frame is drawn) lives in `frame`, which is tested everywhere.

pub mod chunks;
pub mod composite;
pub mod far;
pub mod fog;
pub mod gl;
pub mod gpu_timer;
pub mod map_gpu;
pub mod programs;
pub mod renderer;
pub mod shader;
pub mod shaders;
pub mod target;

pub use chunks::DrawTotals;
pub use renderer::{PassGauges, RenderGauges, Renderer};
