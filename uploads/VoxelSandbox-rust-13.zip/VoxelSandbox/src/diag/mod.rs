//! Diagnostics: a performance log written to a text file so that "the game lags" can be answered with data.
//!
//! * `probe` - near-free timers and counters that any code can use (a relaxed atomic add).
//! * `recorder` - the game thread's per-frame / per-second bookkeeping.
//! * `sink` - the background, lowest-priority writer thread (the game thread never waits for it).
//! * `report` - turns samples into the log text and decides whether the CPU (calculation / drawing work) or the
//!   GPU (waiting for the screen) is the bottleneck.
//! * `procfs` - what the OS reports about our own process.
//! * `flicker` - the bookkeeping of the menu blink probe (the renderer reads a few rows of the finished picture back).
//! * `gl_errors` - which GL errors are worth a line in the log.
//!
//! Everything except opening the destination file is plain Rust and unit-tested on a normal computer.

pub mod flicker;
pub mod gl_errors;
pub mod place;
pub mod probe;
pub mod procfs;
pub mod recorder;
pub mod report;
pub mod sample;
pub mod sink;
pub mod telemetry;

use std::sync::Mutex;
use std::time::Duration;

pub use probe::{count, scope, Counter, Stage};
pub use recorder::Recorder;
pub use sample::{Gauges, ScreenKind, PASS_NAMES};
pub use sink::{LogSender, Opened, Opener, SinkConfig};
pub use telemetry::{OpenerFactory, Telemetry};

static GLOBAL: Mutex<Option<LogSender>> = Mutex::new(None);

/// Remembers the running log so the panic hook can reach it.
pub fn install_global(sender: Option<LogSender>) {
    if let Ok(mut g) = GLOBAL.lock() {
        *g = sender;
    }
}

/// Writes `text` to the log right now and waits briefly for it to reach the file. Used by the panic hook, so it
/// must never hang: it gives up after a short time, and does nothing on the writer thread itself.
pub fn emergency_note(text: &str) {
    let on_writer = std::thread::current().name() == Some("vs-log");
    if on_writer {
        return;
    }
    let sender = match GLOBAL.try_lock() {
        Ok(g) => g.clone(),
        Err(_) => None,
    };
    if let Some(s) = sender {
        s.event(text.to_string());
        let _ = s.flush_blocking(Duration::from_millis(400));
    }
}

/// Puts `text` in the log as an event if one is running. Unlike `emergency_note` it never waits, so the drawing code can
/// use it.
pub fn note(text: &str) {
    let sender = match GLOBAL.try_lock() {
        Ok(g) => g.clone(),
        Err(_) => None,
    };
    if let Some(s) = sender {
        s.event(text.to_string());
    }
}

/// Facts about the device and the run that go at the top of the log (filled in by the platform shell).
#[derive(Clone, Debug, Default)]
pub struct SessionInfo {
    pub started: String,
    pub app_version: String,
    pub device: String,
    pub os: String,
    pub gpu: String,
    pub cpu_cores: usize,
    pub screen: String,
    pub settings: String,
    pub notes: Vec<String>,
}

/// The first lines of the log: who/what/where, and how to read the rest.
pub fn session_header(info: &SessionInfo) -> String {
    let mut o = String::with_capacity(2048);
    o.push_str("# VOXEL SANDBOX DEBUG LOG\n");
    o.push_str(&format!("# started:  {} (the phone's clock)\n", info.started));
    o.push_str(&format!("# app:      {}\n", info.app_version));
    o.push_str(&format!("# device:   {}\n", info.device));
    o.push_str(&format!("# system:   {}\n", info.os));
    o.push_str(&format!("# graphics: {}\n", info.gpu));
    o.push_str(&format!("# cpu:      {} cores\n", info.cpu_cores));
    o.push_str(&format!("# screen:   {}\n", info.screen));
    o.push_str(&format!("# settings: {}\n", info.settings));
    for n in info.notes.iter() {
        o.push_str(&format!("# note:     {}\n", n));
    }
    o.push_str(
        "#\n\
         # HOW TO READ THIS FILE\n\
         # - A line is written every second. The time at the start (for example 1:20:05pm) is the phone's clock.\n\
         # - fps = frames per second. frame = average milliseconds per frame (16.7 ms = 60 fps); p95 and max are the slow ones.\n\
         # - thread = what the game thread did during one frame, in milliseconds:\n\
         #     update    = calculation: game logic, physics, keeping the world loaded (streaming), building the menus\n\
         #     render    = drawing work done on the CPU: uploading meshes, working out what is visible, draw calls\n\
         #     swap-wait = time spent waiting for the screen / GPU. Big swap-wait with small update and render = the GPU is the limit.\n\
         # - cpu = how much of one CPU core the game thread / the whole app used. If it is far below 100% while lagging,\n\
         #   the game thread was waiting (GPU) or was not given CPU time (other apps, heat throttling).\n\
         # - workers = background threads that generate terrain, build meshes and build far terrain.\n\
         # - gpu upload / drawn = how much mesh data went to the GPU this second and how much was drawn per frame.\n\
         # - The end of each line (=> ...) says which part was the bottleneck that second.\n\
         # - HITCH lines are single frames that took over 50 ms, with the part responsible.\n\
         # - EVENT lines mark things that happened (world started, settings changed, app paused ...).\n\
         # - \"---- 1:20pm summary\" blocks sum up each minute.\n\
         #\n",
    );
    o
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn the_header_explains_itself() {
        let info = SessionInfo {
            started: "2026-11-07 6:37:12am".to_string(),
            app_version: "voxelsandbox 0.3.0".to_string(),
            device: "TestPhone".to_string(),
            cpu_cores: 8,
            ..SessionInfo::default()
        };
        let h = session_header(&info);
        assert!(h.starts_with("# VOXEL SANDBOX DEBUG LOG"));
        assert!(h.contains("TestPhone"));
        assert!(h.contains("HOW TO READ THIS FILE"));
        assert!(h.lines().all(|l| l.starts_with('#')), "every header line must be a comment");
    }

    /// The tests that put a log in the global slot must not run at the same time.
    static GLOBAL_SLOT: Mutex<()> = Mutex::new(());

    #[test]
    fn emergency_note_without_a_log_does_nothing() {
        let _slot = GLOBAL_SLOT.lock().unwrap_or_else(|e| e.into_inner());
        install_global(None);
        emergency_note("panic text");
    }

    #[test]
    fn emergency_note_reaches_the_file() {
        use sink::testing::{opener_for, SharedBuf};
        let _slot = GLOBAL_SLOT.lock().unwrap_or_else(|e| e.into_inner());
        let buf = SharedBuf::default();
        let log = sink::start(opener_for(&buf), String::new(), SinkConfig::default());
        install_global(Some(log.clone()));
        emergency_note("PANIC: something broke");
        assert!(buf.text().contains("PANIC: something broke"), "{}", buf.text());
        install_global(None);
        log.stop();
    }

    #[test]
    fn note_without_a_log_does_nothing() {
        let _slot = GLOBAL_SLOT.lock().unwrap_or_else(|e| e.into_inner());
        install_global(None);
        note("GL error");
    }

    #[test]
    fn note_reaches_the_file_without_the_caller_waiting() {
        use sink::testing::{opener_for, SharedBuf};
        let _slot = GLOBAL_SLOT.lock().unwrap_or_else(|e| e.into_inner());
        let buf = SharedBuf::default();
        let log = sink::start(opener_for(&buf), String::new(), SinkConfig::default());
        install_global(Some(log.clone()));
        note("GL error INVALID_OPERATION after drawing the UI");
        // `note` did not wait for the writer thread: ask it to write everything out before looking at the file
        assert!(log.flush_blocking(Duration::from_millis(2000)));
        assert!(buf.text().contains("GL error INVALID_OPERATION"), "{}", buf.text());
        install_global(None);
        log.stop();
    }
}
