#include "hills.h"

#include <algorithm>
#include <cmath>

#include "config.h"
#include "math3d.h"
#include "rng.h"

namespace sd {

HillProfile::Event HillProfile::eventOfBlock(int block) const {
    Event e;
    if (block < 0) return e;
    const uint32_t key = hash2(seed_ ^ 0x48494C4Cu, static_cast<uint32_t>(block));   // "HILL"
    auto h = [key](uint32_t i) { return hash01(hash2(key, i)); };

    const float roll = h(0);
    if (roll < cfg::kUphillChance) {
        e.kind = Kind::Climb;
        e.flat = lerpf(cfg::kUphillLenMin, cfg::kUphillLenMax, h(1));
        e.amount = lerpf(cfg::kUphillGradeMin, cfg::kUphillGradeMax, h(2));
    } else if (roll < cfg::kUphillChance + cfg::kSteepChance) {
        e.kind = Kind::Steep;
        e.flat = lerpf(cfg::kSteepLenMin, cfg::kSteepLenMax, h(1));
        e.amount = lerpf(cfg::kSteepExtraMin, cfg::kSteepExtraMax, h(2));
    } else {
        return e;
    }
    constexpr float kEdge = 10.0f;                                   // a hill never touches the edge of its block
    const float width = e.flat + 2.0f * cfg::kHillEase;              // everything it covers, eases included
    const float slack = std::max(0.0f, cfg::kHillBlock - 2.0f * kEdge - width);
    e.centre = cfg::kHillStart + static_cast<float>(block) * cfg::kHillBlock + kEdge + slack * h(3) + 0.5f * width;
    return e;
}

HillProfile::Event HillProfile::eventAt(float s) const {
    if (s < cfg::kHillStart) return Event();
    return eventOfBlock(static_cast<int>(std::floor((s - cfg::kHillStart) / cfg::kHillBlock)));
}

float HillProfile::reach(const Event& e) { return 0.5f * e.flat + cfg::kHillEase; }

float HillProfile::weight(const Event& e, float s) {
    if (e.kind == Kind::None) return 0.0f;
    const float d = std::fabs(s - e.centre) - 0.5f * e.flat;   // distance outside the steady part
    return 1.0f - smoothstep(0.0f, cfg::kHillEase, d);
}

float HillProfile::blend(const Event& e, float s, float pitch) {
    const float w = weight(e, s);
    if (w <= 0.0f) return pitch;
    if (e.kind == Kind::Climb) return lerpf(pitch, -e.amount * kDeg2Rad, w);   // the road settles onto the climb's grade
    return std::min(pitch + e.amount * kDeg2Rad * w, std::max(pitch, cfg::kMaxDescentDeg * kDeg2Rad));   // steeper, but never past the limit
}

}  // namespace sd
