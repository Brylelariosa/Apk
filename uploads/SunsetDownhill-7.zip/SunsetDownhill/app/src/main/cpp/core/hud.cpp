#include "hud.h"

#include <cmath>
#include <cstdio>

#include "ui_font.h"
#include "ui_widgets.h"

namespace sd {
namespace {

using namespace widgets;

void speedBlock(UiBatch& ui, const UiLayout& L, const HudModel& m) {
    const float u = L.u;
    char buf[32];
    std::snprintf(buf, sizeof(buf), "%d", static_cast<int>(m.speedKmh + 0.5f));
    const float size = 92.0f * u;
    const float w = text(ui, buf, L.margin, L.margin, size, kWhite);   // w is the exact width of the ink, so the unit never touches it
    const float unitSize = 30.0f * u;
    text(ui, "KM/H", L.margin + w + 14.0f * u, L.margin + textHeight(size) - textHeight(unitSize), unitSize, kAccent);   // shares the digits' baseline
    // speed bar
    const float bx = L.margin, by = L.margin + size + 24.0f * u, bw = 330.0f * u, bh = 16.0f * u;
    ui.roundRect(bx, by, bw, bh, bh * 0.5f, Rgba8{20, 10, 40, 150});
    const float f = saturate(m.speedKmh / 140.0f);
    if (f > 0.01f) {
        const Rgba8 cool = {255, 214, 120, 255}, hot = {255, 80, 60, 255};
        ui.roundRect(bx, by, std::max(bh, bw * f), bh, bh * 0.5f, mix(cool, hot, smoothstep(0.5f, 1.0f, f)));
    }
}

// When the road climbs and the board is dying, the PUSH button blinks and says why (until the rider starts kicking).
void pushHintCue(UiBatch& ui, const UiLayout& L, const HudModel& m, float op) {
    if (m.pushHint < 0.02f || m.pushDown) return;
    const float u = L.u;
    const Vec2 c = L.center(ButtonId::Push);
    const float r = L.radius(ButtonId::Push);
    const float pulse = 0.5f + 0.5f * std::sin(m.pulse * 8.0f);
    const float k = m.pushHint * op;
    ui.ring(c.x, c.y, r * (1.05f + 0.12f * pulse), r * (1.10f + 0.16f * pulse), alpha(kMint, (0.45f + 0.5f * pulse) * k), 56);
    const float size = 30.0f * u;
    text(ui, "UPHILL - KICK!", c.x, c.y - r * 1.12f - size - 10.0f * u, size, alpha(kGold, (0.75f + 0.25f * pulse) * k), TextAlign::Center);
}

void drawControls(UiBatch& ui, const UiLayout& L, const HudModel& m) {
    const float u = L.u;
    const float op = m.opacity;
    controlButton(ui, L, ButtonId::Tuck, m.tuckDown, op);
    controlButton(ui, L, ButtonId::Slide, m.slideDown, op);
    controlButton(ui, L, ButtonId::Push, m.pushDown, op);
    pushHintCue(ui, L, m, op);
    if (usesArrows(m.mode)) {
        controlButton(ui, L, ButtonId::Left, m.leftDown, op);
        controlButton(ui, L, ButtonId::Right, m.rightDown, op);
    }
    if (usesTilt(m.mode)) tiltGauge(ui, L, m.tilt, op, false);
    if (!usesStick(m.mode)) return;
    if (m.steerActive) {
        ui.ring(m.stickOrigin.x, m.stickOrigin.y, L.stickRange * 1.0f, L.stickRange * 1.04f, alpha(kWhite, 0.30f), 56);
        arrowHead(ui, m.stickOrigin.x - L.stickRange - 26.0f * u, m.stickOrigin.y, 15.0f * u, -1, alpha(kWhite, 0.45f));
        arrowHead(ui, m.stickOrigin.x + L.stickRange + 26.0f * u, m.stickOrigin.y, 15.0f * u, 1, alpha(kWhite, 0.45f));
        ui.circle(m.stickKnob.x, m.stickKnob.y, 52.0f * u, alpha(kWhite, 0.55f), 36);
        ui.ring(m.stickKnob.x, m.stickKnob.y, 46.0f * u, 52.0f * u, alpha(kWhite, 0.9f), 36);
    } else {
        const float cx = L.margin + 200.0f * u, cy = L.h - L.margin - 130.0f * u;
        arrowHead(ui, cx - 110.0f * u, cy, 34.0f * u, -1, alpha(kWhite, 0.30f * op));
        arrowHead(ui, cx + 110.0f * u, cy, 34.0f * u, 1, alpha(kWhite, 0.30f * op));
        drawText(ui, "STEER", cx, cy - 15.0f * u, 30.0f * u, alpha(kWhite, 0.40f * op), TextAlign::Center);
    }
}

void pauseButton(UiBatch& ui, const UiLayout& L) {
    const Vec2 c = L.pauseC;
    ui.circle(c.x, c.y, L.pauseR, Rgba8{30, 20, 60, 120});
    ui.ring(c.x, c.y, L.pauseR * 0.92f, L.pauseR, alpha(kWhite, 0.5f), 40);
    const float bw = L.pauseR * 0.20f, bh = L.pauseR * 0.7f;
    ui.rect(c.x - bw * 1.7f, c.y - bh * 0.5f, bw, bh, alpha(kWhite, 0.9f));
    ui.rect(c.x + bw * 0.7f, c.y - bh * 0.5f, bw, bh, alpha(kWhite, 0.9f));
}

void soundButton(UiBatch& ui, const UiLayout& L, bool on) {
    const Vec2 c = L.soundC;
    const float r = L.soundR;
    ui.circle(c.x, c.y, r, Rgba8{30, 20, 60, 120});
    ui.ring(c.x, c.y, r * 0.92f, r, alpha(kWhite, 0.5f), 40);
    const Rgba8 w = alpha(kWhite, 0.95f);
    ui.rect(c.x - r * 0.40f, c.y - r * 0.16f, r * 0.22f, r * 0.32f, w);
    ui.triangle({c.x - r * 0.18f, c.y - r * 0.16f}, {c.x + r * 0.10f, c.y - r * 0.40f}, {c.x + r * 0.10f, c.y + r * 0.40f}, w);
    ui.triangle({c.x - r * 0.18f, c.y - r * 0.16f}, {c.x + r * 0.10f, c.y + r * 0.40f}, {c.x - r * 0.18f, c.y + r * 0.16f}, w);
    if (on) {
        ui.ring(c.x + r * 0.08f, c.y, r * 0.26f, r * 0.33f, w, 20, -0.9f, 0.9f);
        ui.ring(c.x + r * 0.08f, c.y, r * 0.44f, r * 0.51f, w, 20, -0.9f, 0.9f);
    } else {
        ui.line({c.x + r * 0.22f, c.y - r * 0.26f}, {c.x + r * 0.58f, c.y + r * 0.26f}, r * 0.10f, alpha(kRed, 1.0f));
        ui.line({c.x + r * 0.58f, c.y - r * 0.26f}, {c.x + r * 0.22f, c.y + r * 0.26f}, r * 0.10f, alpha(kRed, 1.0f));
    }
}

void menuButton(UiBatch& ui, const UiLayout& L) {
    ui.roundRect(L.menuX, L.menuY, L.menuW, L.menuH, L.menuH * 0.4f, Rgba8{30, 20, 60, 170});
    drawText(ui, "MENU", L.menuX + L.menuW * 0.5f, L.menuY + L.menuH * 0.5f - 18.0f * L.u, 36.0f * L.u, kWhite, TextAlign::Center);
}

void dim(UiBatch& ui, const UiLayout& L, float alpha255) {
    ui.rect(0, 0, L.w, L.h, Rgba8{10, 4, 24, static_cast<uint8_t>(clampf(alpha255, 0.0f, 255.0f))});
}

const char* menuHint(SteerMode mode) {
    switch (mode) {
        case SteerMode::Arrows: return "USE THE ARROWS TO STEER   TUCK FOR SPEED   SLIDE + STEER FOR A COLEMAN SLIDE";
        case SteerMode::Tilt: return "TILT YOUR PHONE TO STEER   TUCK FOR SPEED   SLIDE + STEER FOR A COLEMAN SLIDE";
        case SteerMode::ArrowsTilt: return "TILT OR USE THE ARROWS TO STEER   TUCK FOR SPEED   SLIDE + STEER FOR A COLEMAN SLIDE";
        default: return "DRAG LEFT TO STEER   TUCK FOR SPEED   SLIDE + STEER FOR A COLEMAN SLIDE";
    }
}

void drawMenu(UiBatch& ui, const UiLayout& L, const HudModel& m) {
    if (m.mp.screen != MpModel::Screen::Off) {
        drawLobby(ui, L, m.mp, m.time);
        return;
    }
    const float u = L.u;
    ui.rectGradient(0, 0, L.w, L.h * 0.55f, Rgba8{12, 4, 30, 110}, Rgba8{12, 4, 30, 0});
    ui.rectGradient(0, L.h * 0.60f, L.w, L.h * 0.40f, Rgba8{12, 4, 30, 0}, Rgba8{12, 4, 30, 140});
    const float cx = L.w * 0.5f;
    const float s1 = 118.0f * u;
    text(ui, "SUNSET", cx, L.h * 0.12f, s1, kGold, TextAlign::Center);
    const float w2 = textWidth("DOWNHILL", s1 * 1.25f);
    text(ui, "DOWNHILL", cx, L.h * 0.12f + s1 * 1.28f, s1 * 1.25f, kWhite, TextAlign::Center);
    // accent bar
    const float bw = w2, by = L.h * 0.12f + s1 * 1.28f + s1 * 1.25f + 26.0f * u;
    for (int i = 0; i < 24; ++i) {
        const float t0 = static_cast<float>(i) / 24.0f;
        ui.rect(cx - bw * 0.5f + bw * t0, by, bw / 24.0f + 1.0f, 7.0f * u,
                mix(Rgba8{255, 190, 80, 255}, Rgba8{230, 80, 170, 255}, t0));
    }
    const float blink = 0.6f + 0.4f * std::sin(m.time * 3.2f);
    text(ui, "TAP TO START", cx, L.h * 0.72f, 54.0f * u, alpha(kWhite, blink), TextAlign::Center);
    char buf[48];
    std::snprintf(buf, sizeof(buf), "BEST %d", m.best);
    text(ui, buf, cx, L.h * 0.84f, 36.0f * u, kAccent, TextAlign::Center);
    const char* hint = menuHint(m.mode);
    text(ui, hint, cx, L.h * 0.93f, fitSize(hint, 21.0f * u, L.w - 2.0f * L.margin), alpha(kWhite, 0.75f), TextAlign::Center);
    soundButton(ui, L, m.soundOn);
    pill(ui, L.controlsMenu, "CONTROLS", 34.0f * u);
    pill(ui, L.multiMenu, "MULTIPLAYER", 34.0f * u);
}

void drawRunning(UiBatch& ui, const UiLayout& L, const HudModel& m) {
    const float u = L.u;
    speedBlock(ui, L, m);
    char buf[48];
    std::snprintf(buf, sizeof(buf), "%d", m.score);
    const float rx = L.pauseC.x - L.pauseR - 28.0f * u;
    text(ui, "SCORE", rx, L.margin - 2.0f * u, 26.0f * u, kAccent, TextAlign::Right);
    text(ui, buf, rx, L.margin + 40.0f * u, 64.0f * u, kWhite, TextAlign::Right);
    std::snprintf(buf, sizeof(buf), "%.2f KM", m.distanceM / 1000.0f);
    text(ui, buf, L.w * 0.5f, L.margin + 6.0f * u, 38.0f * u, alpha(kWhite, 0.92f), TextAlign::Center);
    if (m.goalM > 0.0f) {   // progress to the finish line
        const float bw = std::min(L.w * 0.34f, 640.0f * u), bh = 12.0f * u, bx = L.w * 0.5f - bw * 0.5f, by = L.margin + 62.0f * u;
        const float p = saturate(1.0f - m.toGoM / m.goalM);
        ui.roundRect(bx, by, bw, bh, bh * 0.5f, alpha(kWhite, 0.25f));
        if (p > 0.01f) ui.roundRect(bx, by, std::max(bh, bw * p), bh, bh * 0.5f, kAccent);
        std::snprintf(buf, sizeof(buf), m.finished ? "FINISHED" : "%d M TO GO", static_cast<int>(std::max(0.0f, m.toGoM)));
        text(ui, buf, L.w * 0.5f, by + 18.0f * u, 24.0f * u, alpha(kWhite, 0.9f), TextAlign::Center);
    }
    if (m.mp.racing) {
        drawStandings(ui, L, m.mp);
        drawNameTags(ui, L, m.mp);
    } else {
        pauseButton(ui, L);   // (a LAN race cannot be paused: the others keep riding)
    }
    drawControls(ui, L, m);
    if (m.finished) {
        const float pulse = 1.0f + 0.05f * std::sin(m.time * 9.0f);
        text(ui, "FINISH!", L.w * 0.5f, L.h * 0.15f, 150.0f * u * pulse, kGold, TextAlign::Center);
        char tm[24], line[48];
        const int minutes = static_cast<int>(m.finishTime / 60.0f);
        std::snprintf(tm, sizeof(tm), "%d:%04.1f", minutes, m.finishTime - 60.0f * static_cast<float>(minutes));
        if (m.finishRank > 0) std::snprintf(line, sizeof(line), "PLACE %d   %s", m.finishRank, tm);
        else std::snprintf(line, sizeof(line), "%s", tm);
        text(ui, line, L.w * 0.5f, L.h * 0.15f + 150.0f * u, 56.0f * u, kWhite, TextAlign::Center);
    }

    if (m.popupAlpha > 0.01f && m.popup[0]) {
        const float rise = std::min(1.0f, m.popupAge * 4.0f);
        text(ui, m.popup, L.w * 0.5f, L.h * 0.26f - 28.0f * u * rise, 58.0f * u, alpha(kGold, m.popupAlpha), TextAlign::Center);
    }
    if (m.phaseTime < 0.9f) {
        const float a = 1.0f - smoothstep(0.35f, 0.9f, m.phaseTime);
        const float s = 230.0f * u * (1.0f + 0.25f * m.phaseTime);
        text(ui, "GO!", L.w * 0.5f, L.h * 0.30f, s, alpha(kAccent, a), TextAlign::Center);
    }
}

void drawCountdown(UiBatch& ui, const UiLayout& L, const HudModel& m) {
    const float u = L.u;
    drawControls(ui, L, m);
    if (m.mp.racing) drawStandings(ui, L, m.mp);
    else pauseButton(ui, L);
    if (m.countdown >= 1) {
        char buf[16];
        std::snprintf(buf, sizeof(buf), "%d", m.countdown);
        const float p = m.countdownProgress;
        const float s = 260.0f * u * (1.0f + 0.35f * (1.0f - p));
        text(ui, buf, L.w * 0.5f, L.h * 0.28f, s, alpha(kWhite, 1.0f - 0.7f * p * p), TextAlign::Center);
    }
    text(ui, "GET READY", L.w * 0.5f, L.h * 0.14f, 40.0f * u, alpha(kGold, 0.9f), TextAlign::Center);
}

void drawCrashed(UiBatch& ui, const UiLayout& L, const HudModel& m) {
    const float u = L.u;
    if (m.mp.racing) {
        drawStandings(ui, L, m.mp);
        drawNameTags(ui, L, m.mp);
    }
    if (m.phaseTime > 0.25f) {
        const float a = smoothstep(0.25f, 0.6f, m.phaseTime);
        const float sh = std::sin(m.phaseTime * 60.0f) * 5.0f * u * (1.0f - a);
        text(ui, "WIPEOUT!", L.w * 0.5f + sh, L.h * 0.18f, 130.0f * u, alpha(kRed, a), TextAlign::Center);
    }
}

void drawGameOver(UiBatch& ui, const UiLayout& L, const HudModel& m) {
    const float u = L.u;
    const float a = smoothstep(0.0f, 0.35f, m.phaseTime);
    dim(ui, L, 120.0f * a);
    if (m.mp.racing) {   // a LAN race ends with the standings of everybody
        drawResults(ui, L, m.mp, a, m.time);
        menuButton(ui, L);
        return;
    }
    const float pw = 760.0f * u, ph = 560.0f * u;
    const float px = L.w * 0.5f - pw * 0.5f, py = L.h * 0.45f - ph * 0.5f;
    ui.roundRect(px, py, pw, ph, 36.0f * u, alpha(kPanel, a));
    ui.roundRect(px, py, pw, 10.0f * u, 5.0f * u, alpha(kAccent, a));
    const float cx = L.w * 0.5f;
    text(ui, "RUN OVER", cx, py + 36.0f * u, 70.0f * u, alpha(kWhite, a), TextAlign::Center);
    char buf[64];
    float y = py + 150.0f * u;
    auto row = [&](const char* label, const char* value, Rgba8 vc) {
        text(ui, label, px + 56.0f * u, y + 8.0f * u, 30.0f * u, alpha(kAccent, a));
        text(ui, value, px + pw - 56.0f * u, y, 44.0f * u, alpha(vc, a), TextAlign::Right);
        y += 62.0f * u;
    };
    std::snprintf(buf, sizeof(buf), "%.2f KM", m.distanceM / 1000.0f);
    row("DISTANCE", buf, kWhite);
    std::snprintf(buf, sizeof(buf), "%d KM/H", static_cast<int>(m.topSpeedKmh + 0.5f));
    row("TOP SPEED", buf, kWhite);
    std::snprintf(buf, sizeof(buf), "%d", m.nearMisses);
    row("CLOSE CALLS", buf, kWhite);
    std::snprintf(buf, sizeof(buf), "%d", m.score);
    row("SCORE", buf, kGold);
    std::snprintf(buf, sizeof(buf), "%d", m.best);
    row("BEST", buf, kWhite);
    if (m.newBest) {
        const float b = 0.65f + 0.35f * std::sin(m.time * 7.0f);
        text(ui, "NEW BEST!", cx, py + ph - 70.0f * u, 54.0f * u, alpha(kGold, a * b), TextAlign::Center);
    } else if (m.phaseTime > 0.7f) {
        const float b = 0.6f + 0.4f * std::sin(m.time * 3.2f);
        text(ui, "TAP TO RETRY", cx, py + ph - 66.0f * u, 46.0f * u, alpha(kWhite, a * b), TextAlign::Center);
    }
    menuButton(ui, L);
}

void drawPaused(UiBatch& ui, const UiLayout& L, const HudModel& m) {
    const float u = L.u;
    dim(ui, L, 150.0f);
    text(ui, "PAUSED", L.w * 0.5f, L.h * 0.26f, 140.0f * u, kWhite, TextAlign::Center);
    const float blink = 0.6f + 0.4f * std::sin(m.time * 3.2f);
    text(ui, "TAP TO RESUME", L.w * 0.5f, L.h * 0.56f, 50.0f * u, alpha(kGold, blink), TextAlign::Center);
    pill(ui, L.controlsPause, "CONTROLS", 36.0f * u);
    menuButton(ui, L);
}

}  // namespace

void drawHud(UiBatch& ui, const UiLayout& L, const HudModel& m) {
    ui.setScreen(L.w, L.h);
    switch (m.phase) {
        case Phase::Menu: drawMenu(ui, L, m); break;
        case Phase::Countdown: drawCountdown(ui, L, m); break;
        case Phase::Running: drawRunning(ui, L, m); break;
        case Phase::Crashed: drawCrashed(ui, L, m); break;
        case Phase::GameOver: drawGameOver(ui, L, m); break;
        case Phase::Paused: drawRunning(ui, L, m); drawPaused(ui, L, m); break;
    }
}

UiAction hudHandleTap(const UiLayout& L, const HudModel& m, float x, float y, int* index) {
    switch (m.phase) {
        case Phase::Menu:
            if (m.mp.screen != MpModel::Screen::Off) return lobbyTap(L, m.mp, x, y, index);
            if (UiLayout::inCircle(x, y, L.soundC, L.soundR * 1.4f)) return UiAction::ToggleSound;
            if (L.controlsMenu.contains(x, y)) return UiAction::OpenControls;
            if (L.multiMenu.contains(x, y)) return UiAction::OpenLobby;
            return UiAction::Start;
        case Phase::Countdown:
        case Phase::Running:
            if (!m.mp.racing && UiLayout::inCircle(x, y, L.pauseC, L.pauseR * 1.5f)) return UiAction::Pause;
            return UiAction::None;
        case Phase::Paused:
            if (L.inMenuButton(x, y)) return UiAction::Menu;
            if (L.controlsPause.contains(x, y)) return UiAction::OpenControls;
            return UiAction::Resume;
        case Phase::GameOver:
            if (L.inMenuButton(x, y)) return UiAction::Menu;
            return m.phaseTime > 0.7f ? UiAction::Retry : UiAction::None;
        case Phase::Crashed: break;
    }
    return UiAction::None;
}

}  // namespace sd
