// input.h - multi-touch handling: floating steering stick or arrow buttons, tuck / slide / push buttons, UI taps.
#pragma once

#include "controls_config.h"
#include "math3d.h"
#include "skater.h"
#include "ui_layout.h"

namespace sd {

enum TouchAction { kTouchDown = 0, kTouchMove = 1, kTouchUp = 2, kTouchCancel = 3 };

class TouchController {
public:
    void setLayout(const UiLayout& layout) { layout_ = layout; }
    // Which steering the touch screen offers: the floating stick (left half), the arrow buttons, or neither (tilt only).
    void setMode(SteerMode mode) { mode_ = mode; }
    // In gameplay, touches become steer / tuck / slide; otherwise every touch is a UI tap.
    void setGameplay(bool on) { gameplay_ = on; }
    void onTouch(int action, int id, float x, float y);
    void update(float dt);   // eases the arrow buttons in and out; call once per frame
    void releaseAll();
    void clearTaps() { tapCount_ = 0; }

    // Tuck, slide, push and the touch part of the steering (stick or arrows). Tilt is mixed in by Controls.
    SkaterInput input() const;
    // Taps (touch-down events that are not gameplay controls), oldest first.
    bool popTap(Vec2& out);

    bool steerActive() const { return steerPtr_ >= 0; }
    Vec2 stickOrigin() const { return stickOrigin_; }
    Vec2 stickKnob() const { return stickKnob_; }
    bool tuckDown() const { return held(Role::Tuck); }
    bool slideDown() const { return held(Role::Slide); }
    bool pushDown() const { return held(Role::Push); }
    bool leftDown() const { return held(Role::Left); }
    bool rightDown() const { return held(Role::Right); }

private:
    enum class Role : uint8_t { None, Steer, Tuck, Slide, Push, Left, Right, Tap };
    struct Pointer {
        bool active = false;
        int id = -1;
        Role role = Role::None;
    };
    static constexpr int kMaxPointers = 10;

    int find(int id) const;
    int allocate(int id);
    bool held(Role r) const;
    Role buttonAt(float x, float y) const;
    void updateSteer(float x);

    UiLayout layout_;
    SteerMode mode_ = SteerMode::Stick;
    bool gameplay_ = false;
    Pointer ptr_[kMaxPointers];
    int steerPtr_ = -1;
    Vec2 stickOrigin_, stickKnob_;
    float steer_ = 0.0f;   // stick
    float arrow_ = 0.0f;   // arrow buttons, eased
    Vec2 taps_[8];
    int tapCount_ = 0;
};

}  // namespace sd
