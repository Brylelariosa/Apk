// ui_layout.h - screen-size dependent placement of controls and buttons (landscape).
// Geometry only: where things are, never what they do. The control buttons follow the player's ControlsConfig.
#pragma once

#include "controls_config.h"
#include "math3d.h"

namespace sd {

struct Rect {
    float x = 0.0f, y = 0.0f, w = 0.0f, h = 0.0f;
    bool contains(float px, float py) const { return px >= x && px <= x + w && py >= y && py <= y + h; }
};

struct UiLayout {
    float w = 1920.0f, h = 1080.0f;
    float u = 1.0f;         // scale unit: screen height / 1080
    float margin = 44.0f;

    // Control buttons (indexed by ButtonId): centres, drawn radii and (slightly larger) touch radii.
    Vec2 btnC[kButtonCount];
    float btnR[kButtonCount] = {};
    float btnHit[kButtonCount] = {};
    float buttonTop = 0.0f;   // control buttons are kept below this line (the HUD and the editor panel live above it)

    Vec2 pauseC, soundC;
    float pauseR = 44.0f, soundR = 46.0f;
    float steerZoneRight = 0.0f;   // stick mode: touches left of this x start a steering gesture
    float stickRange = 130.0f;
    float menuX = 0.0f, menuY = 0.0f, menuW = 0.0f, menuH = 0.0f;   // "MENU" button on overlays
    Rect controlsMenu, controlsPause;                                // "CONTROLS" button on the main menu / pause overlay
    Rect multiMenu;                                                  // "MULTIPLAYER" button on the main menu

    static float baseRadius(ButtonId b, float u) {
        switch (b) {
            case ButtonId::Tuck: return 120.0f * u;
            case ButtonId::Slide: return 92.0f * u;
            case ButtonId::Push: return 86.0f * u;
            default: return 96.0f * u;   // arrows
        }
    }
    static float hitFactor(ButtonId b) { return b == ButtonId::Tuck ? 1.15f : 1.2f; }

    Vec2 center(ButtonId b) const { return btnC[toIndex(b)]; }
    float radius(ButtonId b) const { return btnR[toIndex(b)]; }

    // ButtonSpec::x <-> pixels (see ControlsConfig.h): x counts from the left edge when >= 0 and from the right edge
    // when negative, in units of a 16:9 screen's width, so a button keeps its distance to "its" side on any aspect ratio.
    float xToPx(float x) const { return x >= 0.0f ? x * 1920.0f * u : w + x * 1920.0f * u; }
    float pxToX(float px) const { return px < w * 0.5f ? px / (1920.0f * u) : (px - w) / (1920.0f * u); }
    Vec2 specToPx(const ButtonSpec& s) const { return {xToPx(s.x), s.y * h}; }

    // Keeps a button of radius r fully on screen, clear of the cut-out margins and below buttonTop.
    Vec2 clampCenter(float r, Vec2 c) const {
        const float inset = 0.55f * margin;
        return {clampf(c.x, inset + r, w - inset - r), clampf(c.y, buttonTop + r, h - inset - r)};
    }

    static UiLayout make(float w, float h, const ControlsConfig& cfg = ControlsConfig()) {
        UiLayout l;
        l.w = w;
        l.h = h;
        l.u = std::max(0.4f, h / 1080.0f);
        const float u = l.u;
        l.margin = std::max(36.0f * u, 0.05f * w);   // keeps the HUD clear of camera cut-outs and rounded corners
        l.buttonTop = 284.0f * u;
        for (int i = 0; i < kButtonCount; ++i) {
            const ButtonId b = static_cast<ButtonId>(i);
            l.btnR[i] = baseRadius(b, u) * cfg.button[i].scale;
            l.btnHit[i] = l.btnR[i] * hitFactor(b);
            l.btnC[i] = l.clampCenter(l.btnR[i], l.specToPx(cfg.button[i]));
        }
        l.pauseR = 44.0f * u;
        l.pauseC = Vec2(w - l.margin - l.pauseR, l.margin + l.pauseR);
        l.soundR = 46.0f * u;
        l.soundC = Vec2(w - l.margin - l.soundR, l.margin + l.soundR);
        l.steerZoneRight = w * 0.52f;
        l.stickRange = 170.0f * u;
        l.menuW = 320.0f * u;
        l.menuH = 80.0f * u;
        l.menuX = w * 0.5f - l.menuW * 0.5f;
        l.menuY = h - l.margin - l.menuH - 10.0f * u;
        l.controlsMenu = {l.margin, l.margin, 320.0f * u, 76.0f * u};
        l.multiMenu = {l.margin, l.margin + 76.0f * u + 14.0f * u, 320.0f * u, 76.0f * u};
        l.controlsPause = {w * 0.5f - 160.0f * u, l.menuY - 20.0f * u - 80.0f * u, 320.0f * u, 80.0f * u};
        return l;
    }

    static bool inCircle(float x, float y, const Vec2& c, float r) {
        const float dx = x - c.x, dy = y - c.y;
        return dx * dx + dy * dy <= r * r;
    }
    bool inMenuButton(float x, float y) const { return x >= menuX && x <= menuX + menuW && y >= menuY && y <= menuY + menuH; }
};

}  // namespace sd
