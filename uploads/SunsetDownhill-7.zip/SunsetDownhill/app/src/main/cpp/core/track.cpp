#include "track.h"

#include <algorithm>
#include <cmath>

namespace sd {

Track::Track(uint32_t seed) { reset(seed); }

void Track::reset(uint32_t seed) {
    seed_ = seed;
    rng_.reseed(seed * 2654435761U + 17U);
    samples_.clear();
    segments_.clear();
    zones_.clear();
    lastJumpBend_ = -1e6f;
    planHeading_ = 0.0f;
    lastDir_ = 1.0f;
    for (float& p : phase_) p = rng_.range(0.0f, kTwoPi);
    hills_.reseed(seed);

    TrackSample first;
    first.pitch = pitchAt(0.0f);
    buildFrame(first);
    samples_.push_back(first);

    segments_.push_back({0.0f, 120.0f, 0.0f});  // opening straight
    planEnd_ = 120.0f;
    lastWasStraight_ = true;
    ensureGenerated(64.0f);
}

void Track::ensureGenerated(float sMax) {
    while (generatedLength() < sMax) generateNext();
    planUntil(sMax + cfg::kPlanAhead);   // (the plan is a pure function of the seed, so looking further ahead changes nothing)
}

float Track::difficultyAt(float s) const { return saturate(s / cfg::kDifficultyDistance); }

float Track::basePitchAt(float s) const {
    const float d = difficultyAt(s);
    const float base = lerpf(5.2f, 7.4f, d) * kDeg2Rad;
    const float p = base + 2.4f * kDeg2Rad * std::sin(s / 210.0f + phase_[0]) + 1.5f * kDeg2Rad * std::sin(s / 77.0f + phase_[1]);
    return std::max(p, 2.2f * kDeg2Rad);
}

// The road rolls: climbs and steeper descents (hills.h) on top of the long descent, except around a gorge, where the detour keeps its
// own gentle slope (so every gorge is about as deep, and the jump over it is about as long).
float Track::pitchAt(float s) const {
    float p = hillPitchAt(s, basePitchAt(s));
    const float w = detourWeight(s);
    if (w > 0.0f) p = lerpf(p, cfg::kGorgePitchDeg * kDeg2Rad, w);
    return p * lerpf(0.6f, 1.0f, smoothstep(0.0f, 70.0f, s));  // already rolling at the start line
}

float Track::detourWeight(float s) const {
    if (zones_.empty()) return 0.0f;
    auto it = std::upper_bound(zones_.begin(), zones_.end(), s + 40.0f, [](float v, const ShortcutZone& z) { return v < z.sBend0; });
    if (it == zones_.begin()) return 0.0f;
    --it;
    return smoothstep(it->sBend0 - 40.0f, it->sBend0, s) * (1.0f - smoothstep(it->sBend1, it->sBend1 + 40.0f, s));
}

// A hill is all or nothing: one that would come within reach of a gorge detour (the rider needs speed for the kicker, and the detour has
// its own slope) is skipped whole, so the road never gets a stump of a climb. That needs every detour near the road being built to be
// planned already, which cfg::kPlanAhead guarantees; the plan is a pure function of the seed, so every phone sees the same hills.
bool Track::nearDetour(float from, float to) const {
    for (const ShortcutZone& z : zones_)
        if (from < z.sBend1 + cfg::kHillClearAfter && to > z.sBend0 - cfg::kHillClearBefore) return true;
    return false;
}

float Track::hillPitchAt(float s, float basePitch) const {
    const HillProfile::Event e = hills_.eventAt(s);
    if (HillProfile::weight(e, s) <= 0.0f) return basePitch;
    const float reach = HillProfile::reach(e);
    return nearDetour(e.centre - reach, e.centre + reach) ? basePitch : HillProfile::blend(e, s, basePitch);
}

float Track::hillBias(float s) const {
    return clampf(0.85f * std::sin(s / 380.0f + phase_[2]) + 0.35f * std::sin(s / 113.0f + phase_[3]), -1.0f, 1.0f);
}

float Track::curvatureAt(float s) const {
    if (segments_.empty()) return 0.0f;
    auto it = std::upper_bound(segments_.begin(), segments_.end(), s,
                               [](float v, const Segment& seg) { return v < seg.s0; });
    if (it == segments_.begin()) return 0.0f;
    --it;
    if (it->k == 0.0f) return 0.0f;
    const float u = (s - it->s0) / it->len;
    if (u < 0.0f || u > 1.0f) return 0.0f;
    const float r = it->ramp;  // clothoid-like ramps
    float e = 1.0f;
    if (u < r) e = smoothstep(0.0f, r, u);
    else if (u > 1.0f - r) e = smoothstep(1.0f, 1.0f - r, u);
    return it->k * e;
}

void Track::planUntil(float sTarget) {
    while (planEnd_ < sTarget) {
        const float diff = difficultyAt(planEnd_);
        if (!lastWasStraight_) {
            float len = lerpf(150.0f, 55.0f, diff) * rng_.range(0.55f, 1.4f);
            if (rng_.chance(0.25f)) len *= 0.35f;  // linked corners
            segments_.push_back({planEnd_, len, 0.0f});
            planEnd_ += len;
            lastWasStraight_ = true;
        } else {
            float radius = std::max(cfg::kMinCurveRadius, lerpf(125.0f, 58.0f, diff) * rng_.range(0.8f, 1.3f));
            float angle = rng_.range(24.0f, 68.0f) * kDeg2Rad * lerpf(0.9f, 1.15f, diff);
            float dir;
            if (std::fabs(planHeading_) > 45.0f * kDeg2Rad) dir = -sign1(planHeading_);
            else dir = rng_.chance(0.72f) ? -lastDir_ : lastDir_;
            // Now and then the road makes a U-shaped detour round a gorge instead (see ShortcutZone).
            if (planEnd_ > 420.0f && planEnd_ - lastJumpBend_ > 700.0f && planGorge()) continue;
            const float k = dir / radius;
            const float len = angle * radius / 0.75f;  // the smooth envelope averages 0.75
            segments_.push_back({planEnd_, len, k});
            planEnd_ += len;
            planHeading_ += dir * angle;
            lastDir_ = dir;
            lastWasStraight_ = false;
        }
    }
}

// A U-shaped detour round a gorge: sharp bend away from the straight, leg down the rim, hairpin round the head of the gorge, leg back up
// the other rim, sharp bend back onto the original line. The gorge side has to be the downhill side all along (that also decides which
// way the first bend turns), so the cliff beside the road is a natural one.
bool Track::planGorge() {
    const float step = cfg::kTrackStep;
    const float entry = 70.0f;                    // more straight, so the signs and the kicker are in view long before the bend
    const float rc = rng_.range(cfg::kGorgeBendRadiusMin, cfg::kGorgeBendRadiusMax);          // radius of the two sharp bends
    const float ru = rng_.range(cfg::kGorgeHairpinRadiusMin, cfg::kGorgeHairpinRadiusMax);    // radius of the hairpin round the head of the gorge
    const float leg = rng_.range(cfg::kGorgeLegMin, cfg::kGorgeLegMax);                       // the straight legs down and up the rims
    const float ramp = cfg::kGorgeCurveRamp;
    const float avg = 1.0f - ramp;                // the curvature envelope averages this over a bend
    const float len1 = 0.5f * kPi * rc / avg;
    const float lenU = kPi * ru / avg;
    const float s0 = planEnd_ + entry;
    const float s5 = s0 + 2.0f * len1 + lenU + 2.0f * leg;   // (where the detour ends)

    float dir = 0.0f;   // +1: the first bend turns right, so the gorge is on the left
    for (float sp = s0 - 24.0f; sp <= s5 + 24.0f; sp += 24.0f) {
        const float hb = hillBias(sp);
        if (std::fabs(hb) < 0.12f) return false;
        const float d = hb > 0.0f ? 1.0f : -1.0f;
        if (dir != 0.0f && d != dir) return false;
        dir = d;
    }
    if (!rng_.chance(0.9f)) return false;

    segments_.push_back({planEnd_, entry, 0.0f});
    float s = s0;
    segments_.push_back({s, len1, dir / rc, ramp});
    s += len1;
    segments_.push_back({s, leg, 0.0f});
    s += leg;
    segments_.push_back({s, lenU, -dir / ru, ramp});
    s += lenU;
    segments_.push_back({s, leg, 0.0f});
    s += leg;
    segments_.push_back({s, len1, dir / rc, ramp});
    s += len1;
    const float sEnd = s;
    segments_.push_back({s, cfg::kGorgeRunway, 0.0f});   // a straight runway: a fast jump flies on past the landing line and comes down on it
    s += cfg::kGorgeRunway;
    planEnd_ = s;
    lastDir_ = dir;
    lastWasStraight_ = false;
    lastJumpBend_ = s0;

    ShortcutZone z;
    z.side = -dir;
    z.sBend0 = s0;
    z.sBend1 = sEnd;
    z.sLip = s0 + 1.5f;   // the kicker sits at the very start of the first bend, at the outside edge
    z.sRamp0 = z.sLip - 7.0f;
    z.sLand = sEnd + 6.0f;
    z.sGorge0 = z.sLip - 16.0f;
    z.sGorge1 = z.sLand + 14.0f;
    zones_.push_back(z);

    // The descent of the detour (from the pitch) gives the heights the gorge floor is measured against: it lies well below the lowest road.
    ShortcutZone& zr = zones_.back();
    zr.baseIndex = static_cast<int>(std::floor(zr.sGorge0 / step));
    const int last = static_cast<int>(std::ceil(zr.sGorge1 / step)) + 1;
    zr.roadY.assign(static_cast<size_t>(last - zr.baseIndex + 1), 0.0f);
    for (int i = zr.baseIndex; i < last; ++i) {
        const size_t k = static_cast<size_t>(i - zr.baseIndex);
        zr.roadY[k + 1] = zr.roadY[k] - std::sin(pitchAt((static_cast<float>(i) + 0.5f) * step)) * step;
    }
    zr.floorY = zr.roadYAt(zr.sLand) - cfg::kGorgeDepth;
    return true;
}

void Track::buildFrame(TrackSample& t) {
    const float ch = std::cos(t.heading), sh = std::sin(t.heading);
    const float cp = std::cos(t.pitch), sp = std::sin(t.pitch);
    t.fwd = Vec3(sh * cp, -sp, -ch * cp);
    t.right0 = Vec3(ch, 0.0f, sh);
    t.up0 = cross(t.right0, t.fwd);
    const float cb = std::cos(t.bank), sb = std::sin(t.bank);
    t.up = t.up0 * cb + t.right0 * sb;
    t.right = t.right0 * cb - t.up0 * sb;
}

void Track::generateNext() {
    const TrackSample cur = samples_.back();
    const float step = cfg::kTrackStep;
    const float sNext = cur.s + step;
    planUntil(sNext + cfg::kPlanAhead);
    const float sMid = cur.s + step * 0.5f;
    const float kMid = curvatureAt(sMid);
    const float headingMid = cur.heading + kMid * step * 0.5f;
    const float pitchMid = pitchAt(sMid);

    TrackSample n;
    n.s = sNext;
    n.heading = cur.heading + kMid * step;
    n.pitch = pitchAt(sNext);
    n.curvature = curvatureAt(sNext);
    n.bank = clampf(n.curvature * 46.0f, -0.10f, 0.10f);
    const Vec3 dir(std::sin(headingMid) * std::cos(pitchMid), -std::sin(pitchMid),
                   -std::cos(headingMid) * std::cos(pitchMid));
    n.pos = cur.pos + dir * step;
    buildFrame(n);
    samples_.push_back(n);
}

TrackSample Track::at(float s) const {
    const int n = static_cast<int>(samples_.size());
    float u = s / cfg::kTrackStep;
    int i = static_cast<int>(std::floor(u));
    float f = u - static_cast<float>(i);
    if (i < 0) { i = 0; f = 0.0f; }
    if (i >= n - 1) { i = n - 2; f = 1.0f; }
    const TrackSample& a = samples_[static_cast<size_t>(i)];
    const TrackSample& b = samples_[static_cast<size_t>(i) + 1];
    TrackSample r;
    r.s = lerpf(a.s, b.s, f);
    r.pos = lerp(a.pos, b.pos, f);
    r.fwd = normalize(lerp(a.fwd, b.fwd, f));
    r.right0 = normalize(lerp(a.right0, b.right0, f));
    r.up0 = normalize(lerp(a.up0, b.up0, f));
    r.right = normalize(lerp(a.right, b.right, f));
    r.up = normalize(lerp(a.up, b.up, f));
    r.heading = lerpf(a.heading, b.heading, f);
    r.pitch = lerpf(a.pitch, b.pitch, f);
    r.curvature = lerpf(a.curvature, b.curvature, f);
    r.bank = lerpf(a.bank, b.bank, f);
    return r;
}

float Track::bankDrop(float lateral, float bank) {
    return -clampf(lateral, -cfg::kShoulderOuter, cfg::kShoulderOuter) * bank;
}

float Track::insideLimit(float curvature) {
    const float k = std::fabs(curvature);
    return k > 1e-4f ? 0.82f / k : 1e6f;
}

float Track::terrainHeight(float s, float d) const {
    const float ad = std::fabs(d);
    if (ad <= cfg::kShoulderOuter) {
        return ad > cfg::kRoadHalfWidth ? -0.04f * (ad - cfg::kRoadHalfWidth) : 0.0f;
    }
    const float away = ad - cfg::kShoulderOuter;
    const float hill = hillBias(s) * (d >= 0.0f ? 1.0f : -1.0f);  // +1: this side is the uphill side
    const float slope = lerpf(-0.52f, 0.62f, hill * 0.5f + 0.5f);
    const float limit = slope > 0.0f ? 34.0f : 30.0f;
    float h = limit * std::tanh(away * slope / limit);
    const float n = fbm2(s * 0.018f + 11.0f, ad * 0.021f, seed_, 3) - 0.5f;
    const float amp = 2.0f * smoothstep(2.0f, 14.0f, away) + 11.0f * smoothstep(18.0f, 70.0f, away);
    h += n * 2.0f * amp;
    return carve(s, d, h - 0.064f);
}

Vec3 Track::surfacePoint(const TrackSample& f, float lateral, float height) {
    return f.pos + f.right0 * lateral + f.up0 * (bankDrop(lateral, f.bank) + height);
}

Vec3 Track::ringVertex(int ring, int col) const {
    const TrackSample& f = samples_[static_cast<size_t>(ring)];
    const float dNom = cfg::kTerrainOffsets[col];
    float d = dNom;
    if ((d > 0.0f && f.curvature > 0.0f) || (d < 0.0f && f.curvature < 0.0f)) {
        const float lim = insideLimit(f.curvature);
        if (std::fabs(d) > lim) d = sign1(d) * lim;  // keep the inside of tight bends from folding over
    }
    const float h = terrainHeight(f.s, dNom);
    return f.pos + f.right0 * d + f.up0 * (bankDrop(d, f.bank) + h);
}

Vec3 Track::terrainPoint(float s, float d) const {
    const int n = static_cast<int>(samples_.size());
    const float u = s / cfg::kTrackStep;
    int i = static_cast<int>(std::floor(u));
    float fs = u - static_cast<float>(i);
    if (i < 0) { i = 0; fs = 0.0f; }
    if (i > n - 2) { i = n - 2; fs = 1.0f; }
    int j = 0;
    while (j < cfg::kTerrainCols - 2 && d > cfg::kTerrainOffsets[j + 1]) ++j;
    const float d0 = cfg::kTerrainOffsets[j], d1 = cfg::kTerrainOffsets[j + 1];
    const float fd = clampf((d - d0) / (d1 - d0), 0.0f, 1.0f);
    const Vec3 a = lerp(ringVertex(i, j), ringVertex(i, j + 1), fd);
    const Vec3 b = lerp(ringVertex(i + 1, j), ringVertex(i + 1, j + 1), fd);
    return lerp(a, b, fs);
}

// ---------------------------------------------------------------------------------------------------------------------------
// Gorge jumps
// ---------------------------------------------------------------------------------------------------------------------------

float ShortcutZone::roadYAt(float s) const {
    if (roadY.size() < 2) return 0.0f;
    const float u = clampf(s / cfg::kTrackStep - static_cast<float>(baseIndex), 0.0f, static_cast<float>(roadY.size() - 1));
    const size_t i = std::min(static_cast<size_t>(u), roadY.size() - 2);
    return lerpf(roadY[i], roadY[i + 1], u - static_cast<float>(i));
}

float ShortcutZone::rampHeight(float s, float xs) const {
    if (s < sRamp0 || s > sLip || xs < rampX0 || xs > rampX1) return -1e9f;
    const float u = (s - sRamp0) / (sLip - sRamp0);
    const float edge = smoothstep(0.0f, 0.45f, std::min(xs - rampX0, rampX1 - xs));   // the sides slope away: no step to ride into
    return lipHeight * std::pow(u, 1.6f) * edge;
}

int Track::zoneIndexAt(float s) const {
    if (zones_.empty()) return -1;
    auto it = std::upper_bound(zones_.begin(), zones_.end(), s + 14.0f, [](float v, const ShortcutZone& z) { return v < z.sRamp0; });
    if (it == zones_.begin()) return -1;
    --it;
    return (s >= it->sRamp0 - 14.0f && s <= it->sGorge1) ? static_cast<int>(it - zones_.begin()) : -1;
}

const ShortcutZone* Track::zoneAt(float s) const {
    const int i = zoneIndexAt(s);
    return i >= 0 ? &zones_[static_cast<size_t>(i)] : nullptr;
}

bool Track::foldsBack(float s, const Vec3& p, float limit) const {
    const float reach = foldReach();
    for (const ShortcutZone& z : zones_) {
        if (s < z.sBend0 - reach || s > z.sBend1 + reach) continue;
        const int i0 = std::max(0, static_cast<int>((z.sBend0 - reach) / cfg::kTrackStep));
        const int i1 = std::min(static_cast<int>(samples_.size()) - 1, static_cast<int>((z.sBend1 + reach) / cfg::kTrackStep) + 1);
        for (int i = i0; i <= i1; ++i) {
            const TrackSample& t = samples_[static_cast<size_t>(i)];
            if (std::fabs(t.s - s) < 45.0f) continue;
            const float dx = t.pos.x - p.x, dz = t.pos.z - p.z;
            if (dx * dx + dz * dz < limit * limit) return true;
        }
    }
    return false;
}

int Track::gorgeSide(float s) const {
    const ShortcutZone* z = zoneAt(s);
    return (z && s >= z->sGorge0 && s <= z->sGorge1) ? static_cast<int>(z->side) : 0;
}

float Track::supportHeight(float s, float x, int* kind) const {
    float best = -1e9f;
    int bk = kVoid;
    if (std::fabs(x) <= cfg::kRailOffset + 0.05f) { best = 0.0f; bk = kRoad; }
    if (const ShortcutZone* z = zoneAt(s)) {
        const float hr = z->rampHeight(s, x * z->side);
        if (hr > best) { best = hr; bk = kKicker; }
    }
    if (bk == kVoid) best = terrainHeight(s, x);   // nothing carries the rider: the ground far below
    if (kind) *kind = bk;
    return best;
}

bool Track::railGap(float s, float side) const {
    const ShortcutZone* z = zoneAt(s);
    if (!z || z->side != side) return false;
    return s >= z->sRamp0 - 3.0f && s <= z->sLip + 7.0f;
}

void Track::lateralWindow(float s, int /*kind*/, float* lo, float* hi) const {
    *lo = -cfg::kRailOffset;
    *hi = cfg::kRailOffset;
    const ShortcutZone* z = zoneAt(s);
    if (z && railGap(s, z->side)) {   // the kicker: nothing stops a rider who leaves the road here
        if (z->side > 0.0f) *hi = 1e6f;
        else *lo = -1e6f;
    }
}

bool Track::shortcutBlocks(float s, float d, float margin) const {
    const ShortcutZone* z = zoneAt(s);
    if (!z) return false;
    const float xs = d * z->side;
    if (xs < 1.8f || s < z->sRamp0 - 8.0f || s > z->sLip + 30.0f) return false;
    return xs <= 22.0f + margin;
}

Track::GapFrame Track::gapFrameOf(const ShortcutZone& z) const {
    const TrackSample a = at(z.sLip), b = at(z.sLand);
    GapFrame g;
    g.p0 = surfacePoint(a, z.side * z.xsFlight, z.lipHeight);
    g.p1 = surfacePoint(b, z.side * z.xsFlight, 0.0f);
    const float hx = g.p1.x - g.p0.x, hz = g.p1.z - g.p0.z;
    g.chordH = std::max(1.0f, std::sqrt(hx * hx + hz * hz));
    g.e0 = Vec3(hx / g.chordH, 0.0f, hz / g.chordH);
    g.r0 = Vec3(-g.e0.z, 0.0f, g.e0.x);
    g.heading = std::atan2(g.e0.x, -g.e0.z);
    return g;
}

void Track::gapFlightAt(const ShortcutZone& z, float u, float b, float rel, float h, float slope, Vec3* pos, Vec3* dir) const {
    const GapFrame g = gapFrameOf(z);
    const float x = u * g.chordH;
    if (pos) *pos = Vec3(g.p0.x + g.e0.x * x + g.r0.x * b, g.p0.y + h, g.p0.z + g.e0.z * x + g.r0.z * b);
    if (dir) {
        const Vec3 dh = g.e0 * std::cos(rel) + g.r0 * std::sin(rel);
        *dir = normalize(Vec3(dh.x, slope, dh.z));
    }
}

bool Track::groundNear(const ShortcutZone& z, const Vec3& p, float* sOut, float* dOut, float* groundY) const {
    const int n = static_cast<int>(samples_.size());
    if (n < 4) return false;
    const int i0 = std::max(0, static_cast<int>(std::floor((z.sBend0 - 30.0f) / cfg::kTrackStep)));
    const int i1 = std::min(n - 1, static_cast<int>(std::ceil((z.sLand + cfg::kGorgeRunway + 30.0f) / cfg::kTrackStep)));
    int best = -1;
    float bestD2 = 1e18f;
    for (int i = i0; i <= i1; ++i) {
        const Vec3& q = samples_[static_cast<size_t>(i)].pos;
        const float dx = p.x - q.x, dz = p.z - q.z;
        const float d2 = dx * dx + dz * dz;
        if (d2 < bestD2) { bestD2 = d2; best = i; }
    }
    if (best < 0) return false;
    const TrackSample& f = samples_[static_cast<size_t>(best)];
    const Vec3 fh = normalize(Vec3(f.fwd.x, 0.0f, f.fwd.z));
    const float along = (p.x - f.pos.x) * fh.x + (p.z - f.pos.z) * fh.z;
    const float s = clampf(f.s + along, f.s - cfg::kTrackStep, f.s + cfg::kTrackStep);
    const TrackSample fr = at(s);
    const float d = (p.x - fr.pos.x) * fr.right0.x + (p.z - fr.pos.z) * fr.right0.z;
    if (sOut) *sOut = s;
    if (dOut) *dOut = d;
    if (groundY) *groundY = terrainPoint(s, d).y;
    return true;
}

// The gorge itself: the ground beside the road is cut away down to a flat floor well below the lowest road of the detour, so the
// legs, the hairpin and the kicker all stand on the rim of a real drop (and neither leg is buried in the other's hillside).
float Track::carve(float s, float d, float h) const {
    const ShortcutZone* z = zoneAt(s);
    if (!z || s < z->sGorge0 || s > z->sGorge1) return h;
    const float xs = d * z->side;   // > 0 on the gorge side
    if (xs <= 0.0f) {   // the hill side of the detour is a cut slope, not a mountain (the sharp bends would otherwise wall the road in)
        const float cut = 3.0f + 0.25f * (std::fabs(d) - 5.0f);
        const float w = smoothstep(z->sGorge0, z->sBend0 + 5.0f, s) * (1.0f - smoothstep(z->sBend1 - 5.0f, z->sGorge1, s));
        return lerpf(h, std::min(h, cut), w * smoothstep(5.0f, 8.0f, std::fabs(d)));
    }
    const float along = smoothstep(z->sGorge0, z->sLip - 1.0f, s) * (1.0f - smoothstep(z->sLand + 2.0f, z->sGorge1, s));
    const float cliff = smoothstep(5.25f, 7.9f, xs);   // (the guard rail stands at 5.5: the cliff starts beyond it)
    const float floorRel = z->floorY - z->roadYAt(s);   // the floor relative to the road plane here (negative)
    return lerpf(h, std::min(h, floorRel), along * cliff);
}

}  // namespace sd
