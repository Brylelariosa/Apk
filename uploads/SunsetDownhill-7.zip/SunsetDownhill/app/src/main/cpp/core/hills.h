// hills.h - the rolling profile of the road: climbs and steeper descents placed along it.
//
// The road used to go down at one steady slope. Now it rolls: the road is cut into blocks (cfg::kHillBlock long) and each block holds
// at most one hill - a CLIMB (the road goes uphill for a while: the rider loses speed and has to kick-push) or a STEEP descent (more
// speed). Which blocks hold what, where, how long and how steep is a pure function of the seed, so every phone in a LAN race rides the
// same hills. A hill stays inside its block and eases in and out over cfg::kHillEase metres, so the pitch is always smooth.
#pragma once

#include <cstdint>

namespace sd {

class HillProfile {
public:
    enum class Kind : uint8_t { None = 0, Climb, Steep };
    struct Event {
        Kind kind = Kind::None;
        float centre = 0.0f;   // road position of the middle (m)
        float flat = 0.0f;     // length of the steady part (m); it eases in and out over cfg::kHillEase more on each side
        float amount = 0.0f;   // Climb: grade in degrees (uphill). Steep: extra descent in degrees.
    };

    void reseed(uint32_t seed) { seed_ = seed; }

    // The hill of block `block` (block 0 starts at cfg::kHillStart); kind None when the block has none.
    Event eventOfBlock(int block) const;
    // The hill of the block that holds s (None before cfg::kHillStart).
    Event eventAt(float s) const;

    // `pitch` (radians, + descends) of the road at s once hill `e` is applied to it (unchanged where e is not in effect).
    static float blend(const Event& e, float s, float pitch);
    // How much of hill `e` is in effect at s: 1 on its steady part, easing to 0 either side (0 for a None event).
    static float weight(const Event& e, float s);
    // Everything the hill covers, eases included: [centre - reach, centre + reach].
    static float reach(const Event& e);

    // The road's pitch at s with the hill of s's block applied, whatever lies around it (the Track skips hills near a gorge detour).
    float apply(float s, float basePitch) const { return blend(eventAt(s), s, basePitch); }

private:
    uint32_t seed_ = 1u;
};

}  // namespace sd
