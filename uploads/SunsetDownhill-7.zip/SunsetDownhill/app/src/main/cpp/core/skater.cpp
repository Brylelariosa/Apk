#include "skater.h"

#include <algorithm>
#include <cmath>

namespace sd {

void Skater::reset(float s0, float speed0) {
    *this = Skater();
    s = s0;
    speed = speed0;
}

void Skater::startPush() {
    pushTimer = cfg::kPushTime;
    pushPhase = 0.0f;
    pushAmount = 1.0f;   // the rider is already in the "ready to kick" pose from the countdown
    pushSteps = 1;       // the first kick plants straight away
    pushActive = true;
}

// Kick-push. A session is a run of kicks: foot planted and driving back for the first part of each stroke, then swinging forward again.
// It starts at the line (a few automatic kicks, cut short by TUCK / SLIDE after a couple) or whenever PUSH is held on the road. Kicks
// help less the faster the board already rolls (cfg::kPushFadeSpeed) and PUSH does nothing above cfg::kPushMaxSpeed. Letting go ends
// the session at the end of the stroke in progress, so the foot always comes back to the deck; TUCK or SLIDE end it at once.
float Skater::stepPush(const SkaterInput& in, float dt) {
    const bool brake = in.tuck || in.slide;
    if (pushTimer > 0.0f) {
        if (brake && pushPhase >= static_cast<float>(cfg::kPushCancelAfter)) pushTimer = 0.0f;
        else pushTimer = std::max(0.0f, pushTimer - dt);
    }
    const float limit = pushActive ? cfg::kPushMaxSpeed : cfg::kPushMaxSpeed - 1.0f;   // (a little hysteresis: no stuttering at the limit)
    const bool want = pushTimer > 0.0f || (in.push && !brake && speed < limit);
    if (!pushActive) {
        if (!want) return 0.0f;
        pushActive = true;
        pushPhase = 0.0f;
        ++pushSteps;   // the first kick plants straight away
    } else if (!want && brake) {
        pushActive = false;   // braking or tucking: the foot goes back onto the deck at once
        pushPhase = 0.0f;
        ++pushLands;
        return 0.0f;
    }

    float thrust = 0.0f;
    const float u = pushPhase - std::floor(pushPhase);
    if (u < cfg::kPushContact) {
        const float drive = std::sin(kPi * u / cfg::kPushContact);
        thrust = cfg::kPushAccel * drive * std::max(0.12f, 1.0f - speed / cfg::kPushFadeSpeed);
    }
    const float before = pushPhase;
    pushPhase += dt / cfg::kPushPeriod;
    if (std::floor(pushPhase) > std::floor(before)) {   // the stroke is done
        if (want) {
            ++pushSteps;   // the next kick plants
            if (pushPhase > 32.0f) pushPhase -= 16.0f;   // (keeps the number small on a long climb: only the fraction matters)
        } else {
            pushActive = false;
            pushPhase = 0.0f;
            ++pushLands;   // foot back onto the deck
        }
    }
    return thrust;
}

void Skater::crash(CrashCause cause) {
    if (crashed) return;
    crashed = true;
    gapFlight = false;
    crashCause = cause;
    crashTime = 0.0f;
    crashSpeed = speed;
    slide = 0.0f;
    tuck = 0.0f;
    yawVel = 0.0f;
    pushActive = false;
    pushTimer = 0.0f;
}

float Skater::coastAccel(float pitch, float speed, float tuck) {
    const float drag = cfg::kDragCoef * (1.0f - cfg::kTuckDragCut * tuck);
    return cfg::kGravity * std::sin(pitch) * cfg::kGravityScale - drag * speed * speed - cfg::kRolling;
}

float Skater::gripNow() const {
    return cfg::kGrip * (1.0f + cfg::kSlideGripBoost * slide) * (1.0f - cfg::kTuckGripCut * tuck) *
           (onShoulder ? 0.55f : 1.0f);
}

namespace {
float wrapPi(float a) {
    while (a > kPi) a -= 2.0f * kPi;
    while (a < -kPi) a += 2.0f * kPi;
    return a;
}

// One step of free flight in road space. The heading stays fixed in the world, so relative to the (bending) road it drifts.
void flightStep(const Track& track, float& s, float& x, float& alpha, float& yRel, float& vy, float speed, float dt) {
    const float curv = track.curvatureAt(s);
    const float denom = std::max(0.35f, 1.0f - curv * x);
    const float ds = speed * std::cos(alpha) / denom * dt;
    s += ds;
    x += speed * std::sin(alpha) * dt;
    alpha -= curv * ds;
    vy -= cfg::kAirGravity * dt;
    yRel += vy * dt;
}
}  // namespace

// At the lip of a kicker: the rider flies out over the gorge on an arc (see stepGap); creeping over the lip slower than
// cfg::kGapHopSpeed is only a hop, and the road (and its rail) takes the rider as usual.
bool Skater::beginGapFlight(const Track& track) {
    const int zi = track.zoneIndexAt(s);
    if (zi < 0 || speed < cfg::kGapHopSpeed) return false;
    const ShortcutZone& z = track.shortcuts()[static_cast<size_t>(zi)];
    if (s < z.sLip - 2.0f || s > z.sLip + 6.0f) return false;
    const Track::GapFrame g = track.gapFrameOf(z);
    gapFlight = true;
    gapZone = zi;
    gapTime = 0.0f;
    gapU = 0.0f;
    gapH = Track::surfacePoint(track.at(s), x, yRel).y - g.p0.y;   // (the rider's own height at the lip: the road may be banked there)
    gapVy = clampf(vy, 0.0f, cfg::kGapPopMax);   // what the kicker's slope gave the rider (speed x slope: the faster, the higher)
    gapG = 1.0f;
    gapB0 = x - z.side * z.xsFlight;   // where on the kicker the rider left the lip, relative to the line
    gapRel0 = clampf(wrapPi(track.at(s).heading + alpha - g.heading), -cfg::kGapMaxRel, cfg::kGapMaxRel);
    gapBs = gapRels = 0.0f;
    steer = 0.0f;   // (steering is the rider's again from here: what the board was doing on the ground does not carry on)
    gapB = gapB0;
    gapRel = gapRel0;
    gapFocus = z.sLip + 40.0f;
    return true;
}

SkaterEvent Skater::stepGap(const SkaterInput& in, const Track& track, float dt) {
    const ShortcutZone& z = track.shortcuts()[static_cast<size_t>(gapZone)];
    const Track::GapFrame g = track.gapFrameOf(z);

    // ---- controls: steering turns the board, TUCK dives the flight, SLIDE floats it
    steer += (clampf(in.steer, -1.0f, 1.0f) - steer) * smoothing(cfg::kSteerResponse, dt);
    const float tuckIn = in.tuck ? 1.0f : 0.0f, slideIn = in.slide ? 1.0f : 0.0f;
    tuck += ((0.55f + 0.45f * tuckIn - 0.35f * slideIn) - tuck) * smoothing(6.0f, dt);   // a crouch for the flight: deeper diving, stretched floating
    slide += (0.0f - slide) * smoothing(6.0f, dt);
    pushTimer = 0.0f;
    pushActive = false;
    pushAmount += (0.0f - pushAmount) * smoothing(8.0f, dt);
    stallTime = 0.0f;
    speed = std::max(0.0f, speed - cfg::kGapDrag * speed * speed * dt);   // air drag
    distance += speed * dt;
    topSpeed = std::max(topSpeed, speed);
    airTime += dt;
    yawVel += (cfg::kColeKick * (0.0f - yawVis) - cfg::kColeDamp * yawVel) * dt;
    yawVis += yawVel * dt;
    lean += (steer * 0.55f - lean) * smoothing(6.0f, dt);

    // ---- the flight: a real arc. The horizontal speed carries on, gravity pulls down (TUCK dives, SLIDE floats), and the rider steers sideways
    const float gTarget = 1.0f + cfg::kGapTuckGravity * tuckIn - cfg::kGapSlideGravity * slideIn;
    gapG += (gTarget - gapG) * smoothing(5.0f, dt);
    gapVy -= cfg::kGapGravity * gapG * dt;
    gapH += gapVy * dt;
    // the angle and the offset the rider had at the lip fade out (the board straightens up in the glide), so a rider who lets go comes
    // down on the line; what steering adds stays
    gapRel0 *= std::exp(-4.0f * dt);
    gapB0 *= std::exp(-1.1f * dt);
    gapRels += (cfg::kGapYawRate * steer - cfg::kGapCentering * gapRels) * dt;
    gapRels = clampf(gapRels, -cfg::kGapMaxRel, cfg::kGapMaxRel);
    gapTime += dt;
    gapU += speed * dt / g.chordH;
    gapBs += speed * std::tan(gapRels) * dt;
    gapRel = clampf(gapRel0 + gapRels, -cfg::kGapMaxRel - 0.1f, cfg::kGapMaxRel + 0.1f);
    gapB = gapB0 + gapBs;
    s = z.sLip + gapU * g.chordH;   // (the road-space numbers carry the flight for the network: s = metres from the lip, x / alpha as below)
    x = gapB;
    alpha = gapRel;
    yRel = 0.0f;
    vy = 0.0f;

    // ---- what is below: the flight ends where the arc meets the ground
    Vec3 P;
    track.gapFlightAt(z, gapU, gapB, gapRel, gapH, 0.0f, &P, nullptr);
    float gs = z.sLand, gd = 0.0f, gy = -1e9f;
    const bool have = track.groundNear(z, P, &gs, &gd, &gy);
    const bool landingArea = have && gs > z.sLand - 12.0f && std::fabs(gd) <= cfg::kRailOffset + 0.05f;
    const float relRoad = have ? wrapPi(g.heading + gapRel - track.at(gs).heading) : gapRel;

    if (have && P.y <= gy + 0.10f && landingArea && std::fabs(relRoad) <= cfg::kGapLandingTilt) {   // touchdown on the road beyond the gorge
        gapFlight = false;
        airborne = false;
        s = gs;
        x = gd;
        alpha = relRoad;
        lastLandVy = gapVy;
        lastLandKind = Track::kRoad;
        surface = Track::kRoad;
        onShoulder = false;
        speed *= 0.96f * (1.0f - 0.12f * std::fabs(relRoad));   // a crooked landing costs a little speed
        ++landings;
        ++gapJumps;
        return SkaterEvent::None;
    }
    if ((have && P.y <= gy + 0.10f) || gapTime > 12.0f) {
        // came down short of the road (in the gorge, or on the slope on the other side), beside it, or too crooked
        s = have ? gs : z.sLand;
        x = have ? gd : gapB;
        alpha = relRoad;
        yRel = P.y - Track::surfacePoint(track.at(s), x, 0.0f).y;
        const float ground = track.supportHeight(s, x);
        if (yRel <= ground) {
            yRel = ground;
            airborne = false;
            vy = 0.0f;
        } else {
            airborne = true;   // keeps falling (see step)
            vy = -2.0f;
        }
        surface = Track::kRoad;
        crash(CrashCause::Fall);
        return SkaterEvent::Crash;
    }
    return SkaterEvent::None;
}

SkaterEvent Skater::stepAir(const SkaterInput& in, const Track& track, float dt) {
    if (gapFlight) return stepGap(in, track, dt);
    // controls keep easing (so the pose is right on landing) but nothing steers the board in the air
    steer += (clampf(in.steer, -1.0f, 1.0f) - steer) * smoothing(cfg::kSteerResponse, dt);
    tuck += (1.0f - tuck) * smoothing(5.0f, dt);   // crouch for the flight
    slide += (0.0f - slide) * smoothing(6.0f, dt);
    pushTimer = 0.0f;
    pushActive = false;
    pushAmount += (0.0f - pushAmount) * smoothing(8.0f, dt);
    stallTime = 0.0f;
    speed *= std::exp(-0.015f * dt);   // a little air drag
    alpha = clampf(alpha + steer * cfg::kHopYawRate * dt, -1.15f, 1.15f);   // steering still turns the board a little in the air
    flightStep(track, s, x, alpha, yRel, vy, speed, dt);
    distance += speed * dt;
    topSpeed = std::max(topSpeed, speed);
    airTime += dt;
    airPeak = std::max(airPeak, yRel);
    yawVel += (cfg::kColeKick * (0.0f - yawVis) - cfg::kColeDamp * yawVel) * dt;
    yawVis += yawVel * dt;
    lean += (steer * 0.40f - lean) * smoothing(5.0f, dt);

    int kind = Track::kVoid;
    const float support = track.supportHeight(s, x, &kind);
    if (vy <= 0.0f && yRel <= support) {   // touchdown
        yRel = support;
        lastLandVy = vy;
        lastLandKind = kind;
        airborne = false;
        ++landings;
        vy = 0.0f;
        if (kind == Track::kVoid || -lastLandVy > cfg::kHardLanding) {   // the hillside below, or too far down
            surface = Track::kRoad;
            crash(CrashCause::Fall);
            return SkaterEvent::Crash;
        }
        surface = kind;
        speed *= 1.0f - std::min(0.12f, 0.006f * (-lastLandVy));
        alpha *= 0.4f;   // the board straightens up as the wheels bite
    }
    return SkaterEvent::None;
}

SkaterEvent Skater::step(const SkaterInput& in, const Track& track, float dt) {
    SkaterEvent ev = SkaterEvent::None;
    scrape = std::max(0.0f, scrape - dt * 4.0f);

    if (crashed) {
        crashTime += dt;
        speed *= std::exp(-1.1f * dt);
        s += speed * std::cos(alpha) * dt;
        x += speed * std::sin(alpha) * dt * 0.5f;
        if (airborne) {   // went over the edge: keep falling until the ground
            vy -= cfg::kAirGravity * dt;
            yRel += vy * dt;
            const float ground = track.supportHeight(s, x);
            if (yRel <= ground) {
                yRel = ground;
                vy = 0.0f;
                airborne = false;
            }
        } else if (yRel > -0.5f) {
            x = clampf(x, -cfg::kRailOffset, cfg::kRailOffset);
        }
        return ev;
    }
    if (airborne) return stepAir(in, track, dt);

    const float curv = track.curvatureAt(s);
    const float pitch = track.pitchAt(s);

    // ---- kick-push: the automatic kicks at the line, or PUSH held (this is how the rider keeps rolling uphill)
    const float thrust = stepPush(in, dt);
    const bool pushing = pushActive;

    // ---- controls
    steer += (clampf(in.steer, -1.0f, 1.0f) - steer) * smoothing(cfg::kSteerResponse, dt);
    const float tuckTarget = (in.tuck && !pushing) ? 1.0f : 0.0f;
    tuck += (tuckTarget - tuck) * smoothing(7.0f, dt);
    const bool slideWanted = in.slide && speed > 3.0f && !pushing;
    slide += ((slideWanted ? 1.0f : 0.0f) - slide) * smoothing(slideWanted ? 12.0f : 6.0f, dt);

    // ---- heading
    const float wMax = std::min(cfg::kYawRateMax * (1.0f + 0.4f * slide), gripNow() / std::max(speed, 3.0f));
    const float omega = steer * wMax;
    const float follow = curv * speed * (1.0f - cfg::kAutoFollow);
    alpha += (omega - follow - cfg::kStability * (1.0f - 0.6f * slide) * alpha) * dt;
    alpha = clampf(alpha, -1.15f, 1.15f);

    // ---- speed
    float a = coastAccel(pitch, speed, tuck) - std::fabs(omega) * speed * 0.02f;
    // The slide scrubs speed as the board comes round: a quick tap barely slows the rider, a committed slide at a big angle does.
    const float scrub = smoothstep(0.15f, 0.95f, std::fabs(yawVis));
    a -= slide * scrub * (cfg::kSlideDecelBase + cfg::kSlideDecelDrag * speed * speed);
    if (onShoulder) a -= cfg::kShoulderDrag * speed;
    a += thrust;
    speed = std::max(0.0f, speed + a * dt);

    // ---- bail out if the rider has come to a halt
    if (!pushing && speed < 1.0f) {
        stallTime += dt;
        if (stallTime > cfg::kStallTime) {
            crash(CrashCause::Stall);
            return SkaterEvent::Crash;
        }
    } else {
        stallTime = 0.0f;
    }

    // ---- kinematics
    const float denom = std::max(0.35f, 1.0f - curv * x);
    s += speed * std::cos(alpha) / denom * dt;
    x += speed * std::sin(alpha) * dt;
    distance += speed * dt;
    topSpeed = std::max(topSpeed, speed);

    // ---- road edges (the rails)
    float lo, hi;
    track.lateralWindow(s, surface, &lo, &hi);
    onShoulder = std::fabs(x) > cfg::kRoadHalfWidth;
    if (x > hi || x < lo) {
        const float side = x > hi ? 1.0f : -1.0f;
        const float outSpeed = speed * std::sin(alpha) * side;
        if (outSpeed > cfg::kCrashLateralSpeed) {
            crash(CrashCause::Rail);
            return SkaterEvent::Crash;
        }
        x = x > hi ? hi : lo;
        if (outSpeed > 0.0f) {
            alpha = -alpha * 0.35f;
            speed = std::max(0.0f, speed - outSpeed * 0.8f);
        }
        speed *= 1.0f - 1.5f * dt;
        scrape = 1.0f;
        railTime += dt;
        railClear = 0.0f;
        ev = SkaterEvent::Scrape;
        if (railTime > cfg::kRailGrindLimit) {  // grinding along the rail for too long
            crash(CrashCause::Rail);
            return SkaterEvent::Crash;
        }
    } else {
        railClear += dt;
        if (railClear > 0.5f) railTime = std::max(0.0f, railTime - dt * 0.8f);
    }

    // ---- what carries the board: the road or a kicker. If that falls away (the kicker's lip) the rider takes off.
    {
        int kind = Track::kRoad;
        const float support = track.supportHeight(s, x, &kind);
        if (kind == Track::kVoid || support < yRel - 0.05f) {
            airborne = true;
            airTime = 0.0f;
            airPeak = yRel;
            ++takeoffs;
            if (surface == Track::kKicker) beginGapFlight(track);
            return ev;
        }
        vy = clampf((support - yRel) / std::max(dt, 1e-4f), -30.0f, 30.0f);   // the slope's vertical speed: what a takeoff keeps
        yRel = support;
        surface = kind;
    }

    // ---- visuals
    // Coleman slide: SLIDE kicks the board out sideways. Pressing it while steering left / right throws the board out
    // to that side (and further out the harder you steer); once sliding, only a firm opposite steer switches sides.
    const float steerAbs = std::fabs(steer);
    if (slide < 0.15f) {
        if (steerAbs > 0.12f) slideDir = sign1(steer);
    } else if (steerAbs > 0.45f && sign1(steer) != slideDir) {
        slideDir = sign1(steer);
    }
    // (the harder the steering, the further out; and at speed the board holds a shallower angle)
    const float slip = lerpf(cfg::kColeSlipMin, cfg::kColeSlipMax, saturate(steerAbs)) *
                       lerpf(1.0f, 1.0f - cfg::kColeSpeedBlend, saturate((speed - 10.0f) / 22.0f));
    const float yawTarget = slide * slideDir * slip;
    // underdamped spring: the board snaps out with a small overshoot, like a real kick-out
    yawVel += (cfg::kColeKick * (yawTarget - yawVis) - cfg::kColeDamp * yawVel) * dt;
    yawVis += yawVel * dt;

    const float leanTarget = clampf(steer * 0.40f + curv * speed * 0.25f, -0.55f, 0.55f) * (1.0f - 0.6f * slide);
    lean += (leanTarget - lean) * smoothing(9.0f, dt);
    pushAmount += ((pushing ? 1.0f : 0.0f) - pushAmount) * smoothing(8.0f, dt);
    return ev;
}

}  // namespace sd
