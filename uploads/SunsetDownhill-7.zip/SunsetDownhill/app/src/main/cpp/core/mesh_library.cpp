#include "mesh_library.h"

#include "car_models.h"
#include "model_kit.h"
#include "rng.h"

namespace sd {
namespace {

const Mat4 kId = Mat4::identity();

Mat4 at(float x, float y, float z) { return Mat4::translation(Vec3(x, y, z)); }

// Rotation about the vertical axis, with the origin at (x, y, z).
Mat4 rotY(float a, float x, float y, float z) {
    const float c = std::cos(a), s = std::sin(a);
    return Mat4::fromBasis(Vec3(c, 0.0f, -s), Vec3(0.0f, 1.0f, 0.0f), Vec3(s, 0.0f, c), Vec3(x, y, z));
}

// A frustum that starts at `base` and grows along `dir` (boughs and limbs).
Mat4 along(const Vec3& base, const Vec3& dir) {
    const Vec3 y = normalize(dir);
    Vec3 x = cross(Vec3(0.0f, 0.0f, 1.0f), y);
    if (dot(x, x) < 1e-4f) x = Vec3(1.0f, 0.0f, 0.0f);
    x = normalize(x);
    return Mat4::fromBasis(x, y, cross(x, y), base);
}

Rgba8 mixc(const Rgba8& a, const Rgba8& b, float t) {
    return rgba(lerpf(a.r / 255.0f, b.r / 255.0f, t), lerpf(a.g / 255.0f, b.g / 255.0f, t), lerpf(a.b / 255.0f, b.b / 255.0f, t));
}

// Gloss lives in the vertex alpha (255 = matte), see the mesh fragment shader.
Rgba8 glossy(Rgba8 c, float g) {
    c.a = to8(1.0f - g);
    return c;
}

// One tier of a conifer: a jagged cone (long and short boughs alternate), a drooping skirt below its rim and a dark underside. The rim
// is lit at the tips and dark toward the trunk, so the tier reads as layers of needles instead of a smooth cone.
void addBoughTier(MeshData& m, float y, float r, float h, int segs, float rot, uint32_t seed, Rgba8 inner, Rgba8 tip, Rgba8 under, Material leaf) {
    std::vector<uint16_t> top(static_cast<size_t>(segs)), low(static_cast<size_t>(segs)), floorRing(static_cast<size_t>(segs));
    const uint16_t apex = m.addVertex(Vec3(0.0f, y + h, 0.0f), Vec3(0.0f, 1.0f, 0.0f), inner, leaf);
    const uint16_t hub = m.addVertex(Vec3(0.0f, y - 0.05f, 0.0f), Vec3(0.0f, -1.0f, 0.0f), under, leaf);
    for (int i = 0; i < segs; ++i) {
        const float a = rot + kTwoPi * static_cast<float>(i) / static_cast<float>(segs);
        const float ca = std::cos(a), sa = std::sin(a);
        const float j0 = hash01(hash2(seed, static_cast<uint32_t>(i))), j1 = hash01(hash2(seed + 77u, static_cast<uint32_t>(i)));
        const bool longBough = (i & 1) == 0;
        const float rr = r * (longBough ? 1.0f : 0.62f) * (0.90f + 0.20f * j0);
        const float dy = longBough ? -0.17f * h * (0.8f + 0.4f * j1) : -0.03f * h;
        const float drop = h * (0.26f + 0.16f * j1) * (longBough ? 1.0f : 0.55f);
        const Vec3 outward(ca, 0.0f, sa);
        const Vec3 pTop(ca * rr, y + dy, sa * rr);
        const Vec3 pLow(ca * rr * 1.05f, y + dy - drop, sa * rr * 1.05f);
        top[static_cast<size_t>(i)] = m.addVertex(pTop, normalize(outward * (h * 0.85f + 0.25f) + Vec3(0.0f, rr * 0.55f, 0.0f)), tip, leaf);
        low[static_cast<size_t>(i)] = m.addVertex(pLow, normalize(outward * 1.0f + Vec3(0.0f, -0.30f, 0.0f)), mixc(tip, under, 0.45f), leaf);
        floorRing[static_cast<size_t>(i)] = m.addVertex(pLow, Vec3(0.0f, -1.0f, 0.0f), under, leaf);
    }
    for (int i = 0; i < segs; ++i) {
        const size_t j = static_cast<size_t>((i + 1) % segs), k = static_cast<size_t>(i);
        m.addTriangle(apex, top[k], top[j]);
        m.addQuad(top[k], low[k], low[j], top[j]);
        m.addTriangle(hub, floorRing[j], floorRing[k]);
    }
}

// Conifer: nine tiers of jagged boughs, each turned against the one below it and ringed by a drooping skirt, so the silhouette is
// ragged and layered like a real spruce. Dark inside, lit at the tips, with a bare trunk below the first boughs and a thin leader on top.
MeshData buildPine() {
    MeshData m;
    const Material trunk{0, 0, 0, 40};
    m.addFrustum(kId, 0.40f, 0.17f, 3.6f, 8, rgba(0.24f, 0.15f, 0.09f), rgba(0.14f, 0.09f, 0.055f), trunk, 0.0f);
    const Material leaf{255, 0, 255, 255};
    const int tiers = 9;
    for (int i = 0; i < tiers; ++i) {
        const float t = static_cast<float>(i) / static_cast<float>(tiers - 1);
        const float y = 1.15f + 1.04f * static_cast<float>(i);
        const float r = lerpf(2.85f, 0.55f, std::pow(t, 0.88f));
        const float h = lerpf(2.55f, 1.55f, t);
        const Rgba8 inner = rgba(lerpf(0.020f, 0.050f, t), lerpf(0.070f, 0.150f, t), lerpf(0.045f, 0.060f, t));
        const Rgba8 tip = rgba(lerpf(0.11f, 0.20f, t), lerpf(0.30f, 0.46f, t), lerpf(0.11f, 0.15f, t));
        const Rgba8 under = rgba(0.014f, 0.040f, 0.026f);
        addBoughTier(m, y, r, h, 12, 0.71f * static_cast<float>(i) + 0.4f, 1000u + static_cast<uint32_t>(i) * 31u, inner, tip, under, leaf);
    }
    m.addFrustum(at(0.0f, 10.3f, 0.0f), 0.085f, 0.0f, 1.05f, 5, rgba(0.10f, 0.20f, 0.08f), rgba(0.18f, 0.34f, 0.12f), leaf, 0.2f);
    return m;
}

// Round autumn tree: a trunk that forks into three limbs and a crown of eight puffy lobes in different shades of gold, orange and red,
// dark red-brown underneath and bright on top.
MeshData buildAutumn() {
    MeshData m;
    const Material wood{0, 0, 0, 30};
    const Rgba8 b0 = rgba(0.27f, 0.17f, 0.10f), b1 = rgba(0.17f, 0.105f, 0.065f);
    m.addFrustum(kId, 0.40f, 0.20f, 3.3f, 8, b0, b1, wood, 0.0f);
    m.addFrustum(along(Vec3(0.0f, 3.0f, 0.0f), Vec3(0.60f, 1.0f, 0.15f)), 0.18f, 0.07f, 2.6f, 6, b1, b1, wood, 0.0f);
    m.addFrustum(along(Vec3(0.0f, 3.1f, 0.0f), Vec3(-0.55f, 1.0f, -0.25f)), 0.16f, 0.06f, 2.5f, 6, b1, b1, wood, 0.0f);
    m.addFrustum(along(Vec3(0.0f, 3.2f, 0.0f), Vec3(0.05f, 1.0f, 0.60f)), 0.14f, 0.06f, 2.3f, 6, b1, b1, wood, 0.0f);
    const Material leaf{255, 0, 255, 200};
    struct Lobe { float x, y, z, rx, ry, rz; uint32_t seed; float warm; };
    const Lobe lobes[8] = {{0.0f, 5.5f, 0.0f, 2.7f, 2.2f, 2.7f, 11u, 0.0f},   {1.7f, 6.1f, 0.8f, 1.8f, 1.5f, 1.8f, 23u, 0.6f},
                           {-1.6f, 6.4f, -0.7f, 1.8f, 1.5f, 1.8f, 37u, 0.3f}, {0.2f, 7.7f, 0.2f, 1.6f, 1.3f, 1.6f, 51u, 1.0f},
                           {-2.0f, 4.9f, 1.2f, 1.5f, 1.2f, 1.5f, 63u, 0.5f},  {2.0f, 4.7f, -1.3f, 1.5f, 1.2f, 1.5f, 77u, 0.2f},
                           {0.4f, 5.0f, 2.1f, 1.4f, 1.1f, 1.4f, 83u, 0.8f},   {-0.5f, 6.3f, -2.0f, 1.5f, 1.2f, 1.5f, 97u, 0.4f}};
    for (const Lobe& l : lobes) {
        const Rgba8 lo = mixc(rgba(0.42f, 0.11f, 0.035f), rgba(0.55f, 0.07f, 0.05f), l.warm);
        const Rgba8 hi = mixc(rgba(1.00f, 0.74f, 0.20f), rgba(1.00f, 0.44f, 0.11f), l.warm);
        m.addBlob(at(l.x, l.y, l.z), Vec3(l.rx, l.ry, l.rz), l.seed, 1, 0.10f, false, lo, hi, leaf);
    }
    return m;
}

// Birch: slim white trunk with dark bark bands, thin boughs and an airy, golden crown of five lobes.
MeshData buildBirch() {
    MeshData m;
    const Material wood{0, 0, 0, 30};
    const Rgba8 white = rgba(0.93f, 0.92f, 0.87f), bandC = rgba(0.10f, 0.09f, 0.08f);
    m.addFrustum(kId, 0.18f, 0.09f, 7.4f, 7, rgba(0.58f, 0.56f, 0.50f), white, wood, 0.0f);
    for (int i = 0; i < 6; ++i) {
        const float y = 0.7f + 1.12f * static_cast<float>(i);
        const float r = lerpf(0.18f, 0.09f, y / 7.4f) + 0.004f;
        m.addFrustum(at(0.0f, y, 0.0f), r, r * 0.985f, 0.10f + 0.03f * static_cast<float>(i % 3), 7, bandC, bandC, wood, 0.0f);
    }
    m.addFrustum(along(Vec3(0.0f, 4.7f, 0.0f), Vec3(0.60f, 1.0f, 0.10f)), 0.08f, 0.03f, 2.3f, 5, white, white, wood, 0.0f);
    m.addFrustum(along(Vec3(0.0f, 5.3f, 0.0f), Vec3(-0.55f, 1.0f, 0.30f)), 0.07f, 0.03f, 2.1f, 5, white, white, wood, 0.0f);
    const Material leaf{255, 0, 255, 220};
    const Rgba8 lo = rgba(0.70f, 0.38f, 0.04f), hi = rgba(1.00f, 0.90f, 0.32f);
    m.addBlob(at(0.0f, 7.9f, 0.0f), Vec3(1.55f, 2.0f, 1.55f), 101u, 1, 0.12f, false, lo, hi, leaf);
    m.addBlob(at(1.15f, 6.6f, 0.5f), Vec3(1.15f, 1.35f, 1.15f), 103u, 1, 0.12f, false, lo, hi, leaf);
    m.addBlob(at(-1.0f, 7.0f, -0.45f), Vec3(1.2f, 1.45f, 1.2f), 107u, 1, 0.12f, false, lo, hi, leaf);
    m.addBlob(at(0.15f, 9.3f, 0.1f), Vec3(0.95f, 1.15f, 0.95f), 109u, 1, 0.12f, false, lo, hi, leaf);
    m.addBlob(at(0.2f, 5.8f, -0.9f), Vec3(0.95f, 1.0f, 0.95f), 113u, 1, 0.12f, false, lo, hi, leaf);
    return m;
}

// Low undergrowth along the verge (four lumps); `autumn` gives it the colours of the autumn trees.
MeshData buildUndergrowth(bool autumn) {
    MeshData m;
    const Material leaf{255, 0, 255, 150};
    const Rgba8 lo = autumn ? rgba(0.50f, 0.17f, 0.04f) : rgba(0.035f, 0.12f, 0.05f);
    const Rgba8 hi = autumn ? rgba(0.92f, 0.56f, 0.13f) : rgba(0.17f, 0.32f, 0.11f);
    m.addBlob(at(0.0f, 0.42f, 0.0f), Vec3(1.0f, 0.62f, 1.0f), autumn ? 91u : 81u, 1, 0.14f, false, lo, hi, leaf, 0.3f);
    m.addBlob(at(0.72f, 0.33f, 0.42f), Vec3(0.70f, 0.48f, 0.70f), autumn ? 92u : 82u, 1, 0.14f, false, lo, hi, leaf, 0.3f);
    m.addBlob(at(-0.62f, 0.28f, -0.50f), Vec3(0.60f, 0.42f, 0.60f), autumn ? 93u : 83u, 1, 0.14f, false, lo, hi, leaf, 0.3f);
    m.addBlob(at(-0.20f, 0.30f, 0.75f), Vec3(0.55f, 0.38f, 0.55f), autumn ? 94u : 84u, 1, 0.14f, false, lo, hi, leaf, 0.3f);
    return m;
}

MeshData buildRock() {
    MeshData m;
    m.addBlob(kId, Vec3(1.0f, 0.74f, 1.0f), 5u, 1, 0.30f, true, rgba(0.26f, 0.23f, 0.22f), rgba(0.52f, 0.47f, 0.43f),
              Material{255, 0, 0, 0}, 0.25f);
    return m;
}

MeshData buildPost() {
    MeshData m;
    m.addBox(at(0.0f, 0.5f, 0.0f), Vec3(0.045f, 0.5f, 0.045f), rgba(0.86f, 0.86f, 0.84f), Material{});
    m.addBox(at(0.0f, 0.78f, 0.0f), Vec3(0.05f, 0.07f, 0.05f), rgba(1.0f, 0.35f, 0.12f), Material{0, 190, 0, 0});
    return m;
}

// Guard rail, one 4 m section (+Z along the road, +X away from the road): a galvanised steel W-beam with two corrugations, bolted
// to steel posts through offset blocks every 2 m, with an amber reflector on the beam.
MeshData buildRail() {
    MeshData m;
    const Rgba8 steel = glossy(rgba(0.74f, 0.76f, 0.79f), 0.50f), steelLo = glossy(rgba(0.50f, 0.52f, 0.56f), 0.45f);
    const Rgba8 postC = glossy(rgba(0.52f, 0.54f, 0.57f), 0.35f), postLo = glossy(rgba(0.36f, 0.38f, 0.41f), 0.30f);
    // W profile (height above the road, offset toward the road); the back of the sheet is 4 mm behind the front
    static const float py[] = {0.470f, 0.505f, 0.540f, 0.575f, 0.615f, 0.655f, 0.690f, 0.725f, 0.765f};
    static const float px[] = {0.000f, -0.030f, -0.040f, -0.030f, 0.000f, -0.030f, -0.040f, -0.030f, 0.000f};
    const int np = 9;
    auto ring = [&](float z) {
        kit::Ring r;
        for (int i = 0; i < np; ++i) r.push_back(Vec3(px[i], py[i], z));
        for (int i = np - 1; i >= 0; --i) r.push_back(Vec3(px[i] + 0.004f, py[i], z));
        return r;
    };
    const std::vector<kit::Ring> rings = {ring(-2.0f), ring(-1.0f), ring(0.0f), ring(1.0f), ring(2.0f)};
    kit::addLoft(m, kId, rings, [&](const Vec3& p, const Vec3& n, Material&) -> Rgba8 {
        const float k = saturate((p.y - 0.47f) / 0.295f);
        return mix(steelLo, steel, saturate(0.35f + 0.9f * (n.y * 0.5f + 0.5f)) * (0.75f + 0.25f * k));
    }, Material{});
    for (int k = 0; k < 2; ++k) {   // posts every 2 m: a steel C-section behind the beam and an offset block between them
        const float z = k == 0 ? -1.0f : 1.0f;
        m.addBox(at(0.085f, 0.40f, z), Vec3(0.022f, 0.40f, 0.045f), postLo, postC);
        m.addBox(at(0.040f, 0.620f, z), Vec3(0.030f, 0.060f, 0.040f), postLo, postLo);
        m.addBox(at(0.085f, 0.0f, z), Vec3(0.06f, 0.02f, 0.07f), postLo, postLo);   // soil plate: hides the foot on sloping ground
    }
    const Rgba8 amber = rgba(1.0f, 0.62f, 0.14f);
    m.addBox(at(-0.046f, 0.690f, 0.0f), Vec3(0.004f, 0.034f, 0.075f), amber, Material{0, 120, 0, 0});   // reflector
    return m;
}

MeshData buildCone() {
    MeshData m;
    const Material orange{255, 0, 0, 0};
    m.addBox(at(0.0f, 0.02f, 0.0f), Vec3(0.21f, 0.02f, 0.21f), rgba(0.95f, 0.30f, 0.05f), orange);
    m.addFrustum(at(0.0f, 0.04f, 0.0f), 0.17f, 0.135f, 0.20f, 10, rgba(1.0f, 0.36f, 0.06f), rgba(1.0f, 0.40f, 0.08f), orange, 0.1f);
    m.addFrustum(at(0.0f, 0.24f, 0.0f), 0.135f, 0.105f, 0.17f, 10, rgba(0.95f, 0.95f, 0.92f), rgba(0.95f, 0.95f, 0.92f), Material{}, 0.1f);
    m.addFrustum(at(0.0f, 0.41f, 0.0f), 0.105f, 0.035f, 0.29f, 10, rgba(1.0f, 0.36f, 0.06f), rgba(1.0f, 0.42f, 0.10f), orange, 0.1f);
    return m;
}

}  // namespace

float treeCrownRadius(Batch batch) {
    switch (batch) {
        case kBatchPine: return 2.85f;     // the lowest tier of boughs
        case kBatchAutumn: return 3.80f;   // the outermost puffy lobes
        case kBatchBirch: return 2.40f;
        default: return 0.0f;
    }
}

MeshData buildBatchMesh(Batch batch) {
    switch (batch) {
        case kBatchPine: return buildPine();
        case kBatchAutumn: return buildAutumn();
        case kBatchBirch: return buildBirch();
        case kBatchBush: return buildUndergrowth(false);
        case kBatchShrub: return buildUndergrowth(true);
        case kBatchRock: return buildRock();
        case kBatchPost: return buildPost();
        case kBatchRail: return buildRail();
        case kBatchCone: return buildCone();
        default: break;
    }
    if (batch >= kBatchCar && batch < kBatchCar + kCarBatchCount) return buildCarMesh(static_cast<int>(batch) - kBatchCar);
    return MeshData();
}

}  // namespace sd
