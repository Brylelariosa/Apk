#include "skater_model.h"

#include <algorithm>
#include <cmath>

#include "config.h"
#include "model_kit.h"

namespace sd {
namespace {

const RiderStyle kStyles[kRiderStyleCount] = {
    // 0: sunset - orange jacket, navy sleeves and pants, cream trim, white helmet with an orange stripe, butterscotch wheels
    {rgba(0.86f, 0.30f, 0.12f), rgba(1.00f, 0.56f, 0.20f), rgba(0.13f, 0.15f, 0.30f), rgba(0.99f, 0.92f, 0.76f), rgba(0.24f, 0.32f, 0.54f),
     rgba(0.97f, 0.96f, 0.94f), rgba(0.97f, 0.42f, 0.14f), rgba(1.00f, 0.76f, 0.22f), rgba(0.97f, 0.96f, 0.92f)},
    // 1: red racer - white wheels with red cores
    {rgba(0.74f, 0.09f, 0.12f), rgba(0.97f, 0.27f, 0.23f), rgba(0.14f, 0.14f, 0.19f), rgba(0.97f, 0.97f, 0.97f), rgba(0.30f, 0.30f, 0.37f),
     rgba(0.90f, 0.14f, 0.13f), rgba(0.90f, 0.14f, 0.14f), rgba(0.96f, 0.96f, 0.94f), rgba(0.84f, 0.14f, 0.13f)},
    // 2: teal - lime wheels
    {rgba(0.07f, 0.52f, 0.56f), rgba(0.20f, 0.80f, 0.78f), rgba(0.09f, 0.13f, 0.17f), rgba(1.00f, 0.86f, 0.22f), rgba(0.28f, 0.28f, 0.35f),
     rgba(0.94f, 0.97f, 0.97f), rgba(0.10f, 0.62f, 0.64f), rgba(0.84f, 0.95f, 0.30f), rgba(0.10f, 0.11f, 0.12f)},
    // 3: purple - pink wheels
    {rgba(0.38f, 0.17f, 0.64f), rgba(0.64f, 0.38f, 0.90f), rgba(0.12f, 0.10f, 0.22f), rgba(1.00f, 0.48f, 0.82f), rgba(0.22f, 0.26f, 0.50f),
     rgba(0.82f, 0.76f, 0.97f), rgba(0.55f, 0.25f, 0.80f), rgba(0.97f, 0.50f, 0.82f), rgba(0.96f, 0.94f, 0.96f)},
    // 4: lime - yellow wheels
    {rgba(0.40f, 0.60f, 0.11f), rgba(0.74f, 0.92f, 0.25f), rgba(0.12f, 0.14f, 0.10f), rgba(0.10f, 0.10f, 0.10f), rgba(0.32f, 0.29f, 0.20f),
     rgba(0.98f, 0.92f, 0.30f), rgba(0.62f, 0.85f, 0.18f), rgba(0.99f, 0.92f, 0.30f), rgba(0.12f, 0.12f, 0.10f)},
    // 5: pink and white - hot pink wheels
    {rgba(0.90f, 0.90f, 0.93f), rgba(1.00f, 1.00f, 1.00f), rgba(0.30f, 0.30f, 0.38f), rgba(1.00f, 0.28f, 0.60f), rgba(0.38f, 0.38f, 0.48f),
     rgba(1.00f, 0.62f, 0.78f), rgba(1.00f, 0.34f, 0.62f), rgba(1.00f, 0.40f, 0.68f), rgba(0.97f, 0.96f, 0.97f)},
};

// Gloss lives in the vertex alpha (255 = matte); the mesh shader turns it into a sun highlight and a hint of sky.
Rgba8 glossy(Rgba8 c, float g) {
    c.a = to8(1.0f - g);
    return c;
}

const Rgba8 kShoe = rgba(0.94f, 0.94f, 0.96f), kSole = rgba(0.86f, 0.80f, 0.66f), kLace = rgba(0.10f, 0.10f, 0.12f);
const Rgba8 kGlove = rgba(0.09f, 0.09f, 0.11f), kPad = rgba(0.10f, 0.10f, 0.12f), kVisorLo = rgba(0.03f, 0.05f, 0.09f), kVisorHi = rgba(0.16f, 0.22f, 0.32f);
const Rgba8 kReflective = rgba(0.82f, 0.84f, 0.88f), kGrip = rgba(0.105f, 0.105f, 0.115f), kTruck = glossy(rgba(0.78f, 0.80f, 0.84f), 0.80f);

Rgba8 shade(Rgba8 c, float k) {
    return {static_cast<uint8_t>(std::min(255.0f, c.r * k)), static_cast<uint8_t>(std::min(255.0f, c.g * k)), static_cast<uint8_t>(std::min(255.0f, c.b * k)), c.a};
}

struct Rig {
    const SkaterPose& p;
    MeshData& out;
    Vec3 o, r, u, f;
    const RiderStyle& st;
    bool low = false;   // remote rider: cheaper geometry

    Vec3 W(float x, float y, float z) const { return o + r * x + u * y + f * z; }

    void box(const Vec3& centre, const Vec3& axisX, const Vec3& axisY, const Vec3& axisZ, const Vec3& half, Rgba8 c0, Rgba8 c1,
             Material m = {}) const {
        out.addBox(Mat4::fromBasis(axisX, axisY, axisZ, centre), half, c0, c1, m);
    }
    // Round limb segment; the open ends are hidden by joint balls.
    void tube(const Vec3& a, const Vec3& b, float rA, float rB, Rgba8 cA, Rgba8 cB, const Vec3& hint) const {
        kit::addTube(out, a, b, rA, rB, low ? 8 : 12, cA, cB, Material{}, false, false, hint);
    }
    void ball(const Vec3& c, float radius, Rgba8 col) const {
        kit::addEllipsoid(out, Mat4::translation(c), Vec3(radius, radius, radius), low ? 1 : 2, col, col);
    }
    void blob(const Vec3& c, const Vec3& ax, const Vec3& ay, const Vec3& az, const Vec3& radii, Rgba8 lo, Rgba8 hi, int subdiv = 1) const {
        kit::addEllipsoid(out, Mat4::fromBasis(ax, ay, az, c), radii, low ? subdiv : subdiv + 1, lo, hi);
    }
};

Vec3 solveJoint(const Vec3& root, const Vec3& target, float l1, float l2, const Vec3& pole, Vec3& endOut) {
    const Vec3 d = target - root;
    float dist = length(d);
    const float maxD = (l1 + l2) * 0.998f, minD = std::fabs(l1 - l2) * 1.002f + 0.01f;
    dist = clampf(dist, minD, maxD);
    const Vec3 dir = dist > 1e-5f ? normalize(d) : Vec3(0.0f, -1.0f, 0.0f);
    endOut = root + dir * dist;
    const float a = (l1 * l1 - l2 * l2 + dist * dist) / (2.0f * dist);
    const float h = std::sqrt(std::max(0.0f, l1 * l1 - a * a));
    Vec3 pv = pole - dir * dot(pole, dir);
    if (dot(pv, pv) < 1e-6f) pv = Vec3(0.0f, 0.0f, 1.0f) - dir * dot(Vec3(0.0f, 0.0f, 1.0f), dir);
    return root + dir * a + normalize(pv) * h;
}

// ---- the longboard (a rigid mesh built once per style and re-posed with a matrix) --------------------------------------
constexpr float kDeckY = 0.116f;        // height of the deck's mid-plane above the road
constexpr float kDeckHalfT = 0.013f;    // half the deck thickness
constexpr float kWheelR = 0.058f;       // wheel radius = axle height
constexpr float kWheelHalfW = 0.029f;   // half the wheel width
constexpr float kWheelX = 0.156f;       // wheel centre across the board
constexpr float kTruckZ = 0.31f;        // truck position along the deck

float deckHalfWidth(float z) {
    static const float zs[] = {-0.56f, -0.52f, -0.44f, -0.34f, -0.18f, 0.0f, 0.18f, 0.34f, 0.44f, 0.52f, 0.56f};
    static const float ws[] = {0.040f, 0.075f, 0.112f, 0.128f, 0.133f, 0.134f, 0.133f, 0.128f, 0.112f, 0.075f, 0.040f};
    const float az = std::fabs(z);
    for (int i = 5; i < 10; ++i) {
        if (az <= zs[i + 1]) return lerpf(ws[i], ws[i + 1], (az - zs[i]) / (zs[i + 1] - zs[i]));
    }
    return ws[10];
}

float deckKick(float z) {
    const float k = saturate((std::fabs(z) - 0.30f) / 0.26f);
    return 0.064f * k * k;
}

// how far the rails rise above the middle of the deck (the concave), fading out toward the nose and tail
float deckConcave(float z) { return 0.011f * (1.0f - smoothstep(0.30f, 0.50f, std::fabs(z))); }

// top of the grip tape at (x, z) in board space
float deckTopY(float x, float z) {
    const float w = std::max(0.02f, deckHalfWidth(z));
    const float u = std::min(1.0f, std::fabs(x) / w);
    return kDeckY + deckKick(z) + kDeckHalfT + deckConcave(z) * u * u;
}

// Cross section of the deck at z: a rounded slab with extra points along the top and bottom so that the concave can bend it.
kit::Ring deckRing(float z, int inner) {
    const float w = std::max(0.03f, deckHalfWidth(z));
    const float yMid = kDeckY + deckKick(z);
    const kit::Ring base = kit::roundedSection(z, yMid - kDeckHalfT, yMid + kDeckHalfT, w, w, 0.011f, 0.011f, 2);   // 12 points
    const int kInner = inner;
    kit::Ring ring;
    for (size_t i = 0; i < base.size(); ++i) {
        ring.push_back(base[i]);
        if (i == 5 || i == 11) {   // end of the top arc / end of the bottom arc: fill the flat face
            const float xa = base[i].x, xb = base[(i + 1) % base.size()].x;
            for (int k = 1; k <= kInner; ++k) ring.push_back(Vec3(lerpf(xa, xb, static_cast<float>(k) / static_cast<float>(kInner + 1)), base[i].y, z));
        }
    }
    const float conc = deckConcave(z);
    for (Vec3& p : ring) {
        const float u = std::min(1.0f, std::fabs(p.x) / w);
        p.y += conc * u * u;
    }
    return ring;
}

// A thin coloured ribbon lying on the grip tape. A lateral position is frac * halfWidth(z) + off, so a ribbon can follow the outline
// (tip bands) or keep a fixed offset (stripes).
struct Lat { float frac, off; };
void addDeckRibbon(MeshData& m, Lat a, Lat b, float z0, float z1, int nz, int nx, Rgba8 c, Material mat) {
    std::vector<uint16_t> ids;
    for (int i = 0; i <= nz; ++i) {
        const float z = lerpf(z0, z1, static_cast<float>(i) / static_cast<float>(nz));
        const float w = deckHalfWidth(z);
        for (int j = 0; j <= nx; ++j) {
            const float x = lerpf(a.frac * w + a.off, b.frac * w + b.off, static_cast<float>(j) / static_cast<float>(nx));
            const float e = 0.004f;
            const float dydx = (deckTopY(x + e, z) - deckTopY(x - e, z)) / (2.0f * e);
            const float dydz = (deckTopY(x, z + e) - deckTopY(x, z - e)) / (2.0f * e);
            ids.push_back(m.addVertex(Vec3(x, deckTopY(x, z) + 0.0009f, z), normalize(Vec3(-dydx, 1.0f, -dydz)), c, mat));
        }
    }
    const size_t row = static_cast<size_t>(nx) + 1;
    for (int i = 0; i < nz; ++i)
        for (int j = 0; j < nx; ++j) {
            const size_t k = static_cast<size_t>(i) * row + static_cast<size_t>(j);
            m.addQuad(ids[k], ids[k + 1], ids[k + row + 1], ids[k + row]);
        }
}

// Urethane wheel: rounded shoulders, a slightly crowned tread, a dark bearing seat, a bright core with an axle recess and a steel nut.
// Plain urethane in the style's colour (satin, not glowing). `side` is +1 for the right wheel and -1 for the left one (the lathe's +Y
// axis points away from the board).
void addWheel(MeshData& m, const Vec3& centre, float side, const RiderStyle& st, bool low) {
    using P = kit::LathePoint;
    const float R = kWheelR, hw = kWheelHalfW, rs = 0.011f, c45 = 0.70710678f;
    const Rgba8 tire = glossy(st.wheel, 0.30f), shoulder = glossy(shade(st.wheel, 0.84f), 0.22f);
    const Rgba8 seat = rgba(0.06f, 0.06f, 0.07f);
    const Rgba8 core = glossy(st.hub, 0.45f), coreLo = glossy(shade(st.hub, 0.70f), 0.35f), hole = rgba(0.03f, 0.03f, 0.04f);
    const Rgba8 steel = glossy(rgba(0.80f, 0.82f, 0.86f), 0.85f);
    const Material none{};
    const std::vector<P> tireProfile = {
        {0.027f, -0.0225f, seat, none, false},
        {0.031f, -hw, seat, none, true},
        {R - rs, -hw, shoulder, none, false},
        {R - rs + rs * c45, -hw + rs - rs * c45, shoulder, none, false},
        {R, -hw + rs, tire, none, false},
        {R + 0.0006f, 0.0f, tire, none, false},
        {R, hw - rs, tire, none, false},
        {R - rs + rs * c45, hw - rs + rs * c45, shoulder, none, false},
        {R - rs, hw, shoulder, none, false},
        {0.031f, hw, seat, none, true},
        {0.027f, 0.0225f, seat, none, false},
    };
    const std::vector<P> hubFace = {   // outer face of the core, from the tyre in to the axle recess
        {0.0300f, 0.0225f, coreLo, none, false},
        {0.0285f, 0.0250f, core, none, true},
        {0.0125f, 0.0250f, core, none, true},
        {0.0112f, 0.0200f, hole, none, true},
        {0.0000f, 0.0200f, hole, none, false},
    };
    const std::vector<P> hubBack = {{0.0f, -0.0225f, shade(coreLo, 0.5f), none, false}, {0.030f, -0.0225f, shade(coreLo, 0.5f), none, false}};
    const std::vector<P> nut = {{0.0f, 0.0200f, steel, none, false}, {0.0090f, 0.0200f, steel, none, true}, {0.0090f, 0.0290f, steel, none, true}, {0.0f, 0.0290f, steel, none, false}};
    const Mat4 xf = Mat4::fromBasis(Vec3(0.0f, 0.0f, 1.0f), Vec3(side, 0.0f, 0.0f), Vec3(0.0f, 1.0f, 0.0f), centre);
    kit::addLathe(m, xf, tireProfile, low ? 12 : 20);
    kit::addLathe(m, xf, hubFace, low ? 10 : 16);
    kit::addLathe(m, xf, hubBack, low ? 10 : 16);
    kit::addLathe(m, xf, nut, 6);
}

// Reverse-kingpin truck: riser pad, black baseplate, polished hanger, two coloured bushings and the axle.
void addTruck(MeshData& m, float z, const RiderStyle& st, bool low) {
    using P = kit::LathePoint;
    const Rgba8 plate = glossy(rgba(0.13f, 0.13f, 0.15f), 0.55f), pad = rgba(0.05f, 0.05f, 0.06f), rubber = glossy(st.accent, 0.30f);
    m.addBox(Mat4::translation(Vec3(0.0f, 0.0975f, z)), Vec3(0.054f, 0.0055f, 0.072f), pad, pad);   // riser pad up to the deck
    {   // baseplate
        static const float zs[] = {-0.066f, -0.052f, 0.052f, 0.066f}, ws[] = {0.040f, 0.050f, 0.050f, 0.040f};
        std::vector<kit::Ring> rings;
        for (int i = 0; i < 4; ++i) rings.push_back(kit::roundedSection(zs[i], 0.0825f, 0.0920f, ws[i], ws[i], 0.004f, 0.004f, 2));
        kit::addLoft(m, Mat4::translation(Vec3(0.0f, 0.0f, z)), rings, [&](const Vec3&, const Vec3& n, Material&) -> Rgba8 {
            return mix(shade(plate, 0.8f), plate, saturate(n.y * 0.5f + 0.5f));
        }, Material{});
    }
    {   // hanger: a bar that is tall and wide in the middle and tapers to the axle ends (loft along the board's x axis)
        static const float xs[] = {-0.118f, -0.100f, -0.070f, -0.040f, 0.0f, 0.040f, 0.070f, 0.100f, 0.118f};
        static const float hh[] = {0.0085f, 0.0105f, 0.0150f, 0.0185f, 0.0200f, 0.0185f, 0.0150f, 0.0105f, 0.0085f};
        static const float hz[] = {0.0120f, 0.0160f, 0.0230f, 0.0290f, 0.0320f, 0.0290f, 0.0230f, 0.0160f, 0.0120f};
        static const float yc[] = {0.0520f, 0.0525f, 0.0560f, 0.0600f, 0.0620f, 0.0600f, 0.0560f, 0.0525f, 0.0520f};
        std::vector<kit::Ring> rings;
        for (int i = 0; i < 9; ++i) rings.push_back(kit::roundedSection(xs[i], yc[i] - hh[i], yc[i] + hh[i], hz[i] * 0.9f, hz[i], 0.006f, 0.008f, 2));
        const Mat4 xf = Mat4::fromBasis(Vec3(0.0f, 0.0f, 1.0f), Vec3(0.0f, 1.0f, 0.0f), Vec3(1.0f, 0.0f, 0.0f), Vec3(0.0f, 0.0f, z));
        kit::addLoft(m, xf, rings, [&](const Vec3&, const Vec3& n, Material&) -> Rgba8 {
            return mix(shade(kTruck, 0.60f), kTruck, saturate(n.y * 0.5f + 0.5f));
        }, Material{});
    }
    const std::vector<P> barrel = {   // bushing
        {0.0f, -0.0075f, rubber, {}, false}, {0.0125f, -0.0075f, rubber, {}, true}, {0.0185f, -0.0045f, rubber, {}, false}, {0.0200f, 0.0f, rubber, {}, false},
        {0.0185f, 0.0045f, rubber, {}, false}, {0.0125f, 0.0075f, rubber, {}, true}, {0.0f, 0.0075f, rubber, {}, false}};
    for (int k = -1; k <= 1; k += 2)
        kit::addLathe(m, Mat4::fromBasis(Vec3(1.0f, 0.0f, 0.0f), Vec3(0.0f, 0.0f, 1.0f), Vec3(0.0f, -1.0f, 0.0f), Vec3(0.0f, 0.0630f, z + 0.040f * static_cast<float>(k))), barrel, low ? 6 : 8);
    kit::addTube(m, Vec3(-0.176f, kWheelR, z), Vec3(0.176f, kWheelR, z), 0.0072f, 0.0072f, 8, shade(kTruck, 0.7f), shade(kTruck, 0.7f), Material{}, true, true);   // axle
}

MeshData makeBoard(const RiderStyle& st, bool low) {
    MeshData m;
    // lacquered maple edge, painted underside, black grip tape on top
    const Rgba8 maple = glossy(rgba(0.84f, 0.66f, 0.43f), 0.40f), mapleLo = glossy(rgba(0.58f, 0.41f, 0.25f), 0.35f);
    const Rgba8 under = glossy(st.deck, 0.45f), underLo = glossy(shade(st.deck, 0.70f), 0.45f);
    std::vector<kit::Ring> rings;
    const int n = low ? 21 : 33;
    for (int i = 0; i < n; ++i) rings.push_back(deckRing(-0.56f + 1.12f * static_cast<float>(i) / static_cast<float>(n - 1), low ? 1 : 3));
    kit::addLoft(m, Mat4::identity(), rings, [&](const Vec3& p, const Vec3& nrm, Material&) -> Rgba8 {
        if (nrm.y > 0.55f && std::fabs(p.x) < deckHalfWidth(p.z) - 0.0095f) return kGrip;     // grip tape, inset from the edge
        if (nrm.y < -0.5f) return mix(underLo, under, 0.5f);                                  // underside
        return mix(mapleLo, maple, saturate(nrm.y * 0.5f + 0.5f));                            // rails: lacquered wood
    }, Material{});
    for (int e = -1; e <= 1; e += 2)
        addDeckRibbon(m, {-1.0f, 0.014f}, {1.0f, -0.014f}, static_cast<float>(e) * 0.505f, static_cast<float>(e) * 0.540f, 3, 4, st.accent, Material{});   // tip bands
    for (int e = -1; e <= 1; e += 2)   // an accent pinstripe along each rail: the outline of the board reads against the road
        addDeckRibbon(m, {static_cast<float>(e), static_cast<float>(-e) * 0.024f}, {static_cast<float>(e), static_cast<float>(-e) * 0.013f}, -0.47f, 0.47f, 10, 1, st.accent, Material{});
    {   // three sunset stripes toward the nose and the tail: gold, orange, rose (what the camera sees most is the tail)
        const Rgba8 bars[3] = {rgba(1.00f, 0.80f, 0.26f), rgba(1.00f, 0.48f, 0.16f), rgba(0.90f, 0.26f, 0.40f)};
        for (int e = -1; e <= 1; e += 2)
            for (int i = 0; i < 3; ++i) {
                const float z0 = static_cast<float>(e) * (0.370f + 0.040f * static_cast<float>(i)), th = 0.024f;
                const float half = 0.84f - 0.07f * static_cast<float>(i);
                addDeckRibbon(m, {-half, 0.0f}, {half, 0.0f}, z0, z0 + static_cast<float>(e) * th, 1, 6, bars[i], Material{});
            }
    }
    const Rgba8 bolt = glossy(rgba(0.55f, 0.57f, 0.60f), 0.8f);
    for (int t = -1; t <= 1; t += 2)   // truck bolts through the grip tape
        for (int bx = -1; bx <= 1; bx += 2)
            for (int bz = -1; bz <= 1; bz += 2) {
                const float x = static_cast<float>(bx) * 0.030f, z = static_cast<float>(t) * kTruckZ + static_cast<float>(bz) * 0.044f;
                const float y = deckTopY(x, z);
                kit::addTube(m, Vec3(x, y, z), Vec3(x, y + 0.0035f, z), 0.0058f, 0.0050f, 6, bolt, bolt, Material{}, false, true);
            }

    for (int i = 0; i < 2; ++i) {
        const float z = i == 0 ? kTruckZ : -kTruckZ;
        addTruck(m, z, st, low);
        for (int side = -1; side <= 1; side += 2) addWheel(m, Vec3(static_cast<float>(side) * kWheelX, kWheelR, z), static_cast<float>(side), st, low);
    }
    return m;
}

const MeshData& boardMesh(const RiderStyle& st, bool low) {
    static const struct Boards {
        MeshData full[kRiderStyleCount], lite[kRiderStyleCount];
        Boards() {
            for (int i = 0; i < kRiderStyleCount; ++i) {
                full[i] = makeBoard(kStyles[i], false);
                lite[i] = makeBoard(kStyles[i], true);
            }
        }
    } boards;
    const long idx = &st - kStyles;
    if (idx >= 0 && idx < kRiderStyleCount) return low ? boards.lite[idx] : boards.full[idx];
    static thread_local MeshData custom;
    custom = makeBoard(st, low);
    return custom;
}

void buildBoard(const Rig& g, float spin, const Vec3& offset, float hop) {
    // Optionally detached board (crash): rotate its basis around the up vector by `spin`.
    const Vec3 o = g.o + offset + g.u * hop;
    const Vec3 f = rotateAround(g.f, g.u, spin), r = rotateAround(g.r, g.u, spin);
    g.out.append(boardMesh(g.st, g.low), Mat4::fromBasis(r, g.u, f, o));
}

// ---- body parts -------------------------------------------------------------------------------------------------------
void drawLeg(const Rig& g, const Vec3& hip, const Vec3& knee, const Vec3& ankle, const Vec3& pole) {
    const RiderStyle& st = g.st;
    const Rgba8 lo = shade(st.pants, 0.82f);
    g.tube(hip, knee, 0.094f, 0.074f, st.pants, st.pants, pole);
    g.tube(knee, ankle, 0.074f, 0.056f, st.pants, lo, pole);
    g.ball(hip, 0.094f, st.pants);
    g.ball(knee, 0.076f, st.pants);
    g.ball(ankle, 0.058f, lo);
    // knee pad on the front of the knee
    const Vec3 axis = normalize(ankle - hip);
    Vec3 kd = pole - axis * dot(pole, axis);
    kd = dot(kd, kd) > 1e-6f ? normalize(kd) : g.f;
    const Vec3 side = normalize(cross(kd, axis));
    const Rgba8 pad = mix(kPad, st.pants, 0.55f);   // (dark, but the colour of the trousers: not a black disc)
    g.blob(knee + kd * 0.050f, side, axis, kd, Vec3(0.062f, 0.072f, 0.032f), pad, shade(pad, 1.5f), 1);
    g.blob(knee + kd * 0.076f, side, axis, kd, Vec3(0.024f, 0.028f, 0.007f), st.accent, st.accent, 1);
}

// Skate shoe: toes along `dir`, `up` is the shoe's up axis. Full detail: lofted gum sole and upper with a toe bumper, laces and a heel tab.
void drawShoe(const Rig& g, const Vec3& ankle, const Vec3& dir, const Vec3& up) {
    const Vec3 side = cross(up, dir);
    if (g.low) {
        g.box(ankle - up * 0.030f + dir * 0.050f, side, up, dir, Vec3(0.060f, 0.017f, 0.150f), kSole, kSole);                     // gum sole
        g.blob(ankle + up * 0.018f + dir * 0.045f, side, up, dir, Vec3(0.056f, 0.046f, 0.135f), shade(kShoe, 0.85f), kShoe, 1);     // upper
        g.box(ankle + up * 0.060f + dir * 0.062f, side, up, dir, Vec3(0.030f, 0.006f, 0.052f), kLace, kLace);                      // laces
        return;
    }
    const Mat4 xf = Mat4::fromBasis(side, up, dir, ankle);   // x across the foot, y up, z toward the toes (heel -0.105, toe +0.205)
    static const float zs[] = {-0.105f, -0.088f, -0.050f, 0.0f, 0.050f, 0.100f, 0.150f, 0.190f, 0.205f};
    static const float ws[] = {0.040f, 0.046f, 0.050f, 0.052f, 0.058f, 0.060f, 0.056f, 0.046f, 0.034f};
    static const float yu[] = {0.036f, 0.046f, 0.050f, 0.050f, 0.038f, 0.028f, 0.016f, 0.004f, -0.004f};
    std::vector<kit::Ring> sole, upper;
    for (int i = 0; i < 9; ++i) {
        const float spring = 0.012f * smoothstep(0.12f, 0.205f, zs[i]);   // toe spring
        sole.push_back(kit::roundedSection(zs[i], -0.029f + spring, -0.011f + spring, ws[i], ws[i], 0.008f, 0.008f, 2));
        upper.push_back(kit::roundedSection(zs[i], -0.011f + spring, yu[i] + spring, ws[i] - 0.002f, (ws[i] - 0.002f) * 0.80f, 0.006f, 0.020f, 3));
    }
    kit::addLoft(g.out, xf, sole, [&](const Vec3&, const Vec3& n, Material&) -> Rgba8 { return mix(shade(kSole, 0.78f), kSole, saturate(n.y * 0.5f + 0.5f)); }, Material{});
    kit::addLoft(g.out, xf, upper, [&](const Vec3& p, const Vec3& n, Material&) -> Rgba8 {
        const Rgba8 base = mix(shade(kShoe, 0.80f), kShoe, saturate(n.y * 0.5f + 0.5f));
        return p.z > 0.158f ? mix(base, kSole, 0.55f) : base;   // toe bumper
    }, Material{});
    for (int i = 0; i < 3; ++i) {   // laces across the instep
        const float z = 0.012f + 0.033f * static_cast<float>(i);
        const float y = lerpf(0.0487f, 0.0320f, static_cast<float>(i) / 2.0f) + 0.002f;
        g.box(ankle + side * 0.0f + up * y + dir * z, side, up, dir, Vec3(0.026f, 0.0035f, 0.007f), kLace, kLace);
    }
    g.box(ankle + up * 0.040f - dir * 0.100f, side, up, dir, Vec3(0.014f, 0.012f, 0.004f), g.st.accent, g.st.accent);   // heel tab
}

// Jacket: a lofted torso from the hips to the collar, with an accent band and a reflective stripe that wrap around it, and a hood.
void drawTorso(const Rig& g, const Vec3& base, const Vec3& up, const Vec3& facing) {
    const RiderStyle& st = g.st;
    const Vec3 fw = normalize(facing - up * dot(facing, up));
    const Vec3 lat = normalize(cross(fw, up));
    const Mat4 xf = Mat4::fromBasis(lat, fw, up, base);   // loft space: x across the chest, y front/back, z up the spine
    struct Key { float z, w, d; };
    static const Key keys[] = {{0.00f, 0.165f, 0.105f}, {0.15f, 0.150f, 0.098f}, {0.31f, 0.190f, 0.112f}, {0.46f, 0.220f, 0.106f}, {0.545f, 0.100f, 0.078f}};
    auto profile = [&](float z, float& w, float& d) {
        for (int i = 0; i < 4; ++i) {
            if (z <= keys[i + 1].z) {
                const float t = (z - keys[i].z) / (keys[i + 1].z - keys[i].z);
                w = lerpf(keys[i].w, keys[i + 1].w, t);
                d = lerpf(keys[i].d, keys[i + 1].d, t);
                return;
            }
        }
        w = keys[4].w;
        d = keys[4].d;
    };
    // extra rings at the edges of the stripes keep their colour boundaries crisp
    static const float zs[] = {0.0f, 0.15f, 0.26f, 0.275f, 0.285f, 0.31f, 0.32f, 0.345f, 0.355f, 0.37f, 0.38f, 0.40f, 0.46f, 0.52f, 0.545f};
    std::vector<kit::Ring> rings;
    for (float z : zs) {
        float w, d;
        profile(z, w, d);
        const float r = std::min(w, d) * 0.85f;
        rings.push_back(kit::roundedSection(z, -d, d, w, w, r, r, g.low ? 2 : 3));
    }
    kit::addLoft(g.out, xf, rings, [&](const Vec3& p, const Vec3&, Material& mat) -> Rgba8 {
        if (p.z > 0.28f && p.z < 0.315f) return st.accent;
        if (p.z > 0.35f && p.z < 0.375f) { mat = Material{0, 70, 0, 0}; return kReflective; }
        if (p.z > 0.50f) return shade(st.jacket, 0.80f);   // collar
        if (p.z > 0.40f) return shade(mix(st.jacket, st.jacketHi, 0.8f), 0.88f);   // shoulder yoke
        return mix(st.jacket, st.jacketHi, saturate(p.z / 0.46f));
    }, Material{});
    g.blob(base + up * 0.50f - fw * 0.075f, lat, up, fw, Vec3(0.120f, 0.075f, 0.085f), st.jacket, st.jacketHi);   // hood bunched at the neck
    if (!g.low) {
        // sunset badge on the lower back: a glowing disc with three dark stripes across its lower half
        const float zc = 0.165f;
        float w, d;
        profile(zc, w, d);
        const Vec3 at = base + up * zc - fw * (d + 0.0015f);
        const Material glow{0, 30, 0, 0};
        using P = kit::LathePoint;
        const std::vector<P> disc = {{0.072f, 0.0f, st.accent, glow, false}, {0.072f, 0.006f, st.accent, glow, true}, {0.0f, 0.006f, st.accent, glow, false}};
        kit::addLathe(g.out, Mat4::fromBasis(lat, -fw, up, at), disc, 20);   // local +Y points out of the back
        const Rgba8 gap = mix(st.jacket, st.jacketHi, 0.35f);
        for (int i = 0; i < 3; ++i) {
            const float dz = -0.014f - 0.019f * static_cast<float>(i);
            const float half = std::sqrt(std::max(0.0f, 0.072f * 0.072f - dz * dz));
            g.box(at - fw * 0.0075f + up * dz, lat, -fw, up, Vec3(half, 0.0022f, 0.0042f), gap, gap);
        }
    }
}

struct ArmJoints { Vec3 sh, elbow, hand; };

// Moves `p` out of the capsule a-b (radius r) if it is inside it.
Vec3 pushOutOfSegment(const Vec3& p, const Vec3& a, const Vec3& b, float r) {
    const Vec3 ab = b - a;
    const float l2 = dot(ab, ab);
    const float t = l2 > 1e-8f ? saturate(dot(p - a, ab) / l2) : 0.0f;
    const Vec3 c = a + ab * t;
    Vec3 d = p - c;
    const float dl = length(d);
    if (dl >= r) return p;
    d = dl > 1e-5f ? d * (1.0f / dl) : Vec3(0.0f, 1.0f, 0.0f);
    return c + d * r;
}

// The tail of a neck gaiter: a flat ribbon with a little thickness that streams back along the airflow and flaps. It leaves the collar
// along the wind blended with the rider's own back (so it clears the shoulders when the body is twisted in a tuck), and every point of
// it is pushed out of the arms, the hands and the back, so the cloth never cuts through the rider whatever the pose.
void drawScarf(const Rig& g, const Vec3& neck, const Vec3& td, const Vec3& facing, const Vec3& hip, const ArmJoints arms[2], float time, float speed) {
    if (g.low) return;
    constexpr int kN = 8, kR = 6;
    const float wind = smoothstep(1.5f, 12.0f, speed);
    const Vec3 up = g.u;
    Vec3 fc = facing - up * dot(facing, up);
    fc = dot(fc, fc) > 1e-6f ? normalize(fc) : g.f;
    const Vec3 back = normalize(-(g.f * 0.55f + fc * 0.45f));
    const Vec3 lat = normalize(cross(back, up));
    const Vec3 root = neck - td * 0.035f - fc * 0.105f;
    const float len = lerpf(0.30f, 0.58f, wind);

    Vec3 pts[kN + 1];
    for (int i = 0; i <= kN; ++i) {
        const float k = static_cast<float>(i) / static_cast<float>(kN);
        const float wob = std::sin(time * 12.0f - k * 5.0f), wob2 = std::sin(time * 8.5f - k * 3.6f + 1.7f);
        const float amp = (0.010f + 0.040f * wind) * k;
        const float rise = 0.05f * std::sin(kPi * std::min(1.0f, k * 1.3f)) * wind;   // leaves the collar slightly upward
        const float hang = (1.0f - wind) * 0.30f * k * k + 0.03f * k * k;             // hangs down when there is no wind
        Vec3 p = root + back * (len * k) + up * (rise - hang + amp * wob) + lat * (amp * 0.8f * wob2);
        for (int a = 0; a < 2; ++a) {
            const Vec3 fd = normalize(arms[a].hand - arms[a].elbow);
            p = pushOutOfSegment(p, arms[a].sh, arms[a].elbow, 0.110f);
            p = pushOutOfSegment(p, arms[a].elbow, arms[a].hand + fd * 0.07f, 0.108f);
        }
        if (i >= 2) p = pushOutOfSegment(p, hip, neck - td * 0.06f, 0.125f);
        pts[i] = p;
    }

    const Rgba8 cloth = shade(g.st.accent, 0.96f), band = g.st.jacket;
    uint16_t ids[kN + 1][kR];
    for (int i = 0; i <= kN; ++i) {
        const float k = static_cast<float>(i) / static_cast<float>(kN);
        const Vec3 T = normalize(i < kN ? pts[i + 1] - pts[i] : pts[i] - pts[i - 1]);
        Vec3 B0 = cross(T, up);
        B0 = dot(B0, B0) > 1e-6f ? normalize(B0) : lat;
        const Vec3 B = rotateAround(B0, T, 0.9f * std::sin(time * 10.0f - k * 4.5f) * k * (0.35f + 0.65f * wind));   // twists as it flaps
        const Vec3 N = normalize(cross(B, T));
        const float w = 0.050f * (1.0f - 0.30f * k), h = 0.0075f;
        const Rgba8 c = k > 0.80f ? band : (k > 0.66f && k < 0.72f ? shade(cloth, 0.55f) : cloth);
        for (int j = 0; j < kR; ++j) {
            const float a = kTwoPi * static_cast<float>(j) / static_cast<float>(kR);
            const float ca = std::cos(a), sa = std::sin(a);
            const Vec3 nrm = normalize(B * (ca / w) + N * (sa / h));
            ids[i][j] = g.out.addVertex(pts[i] + B * (w * ca) + N * (h * sa), nrm, c, Material{});
        }
    }
    for (int i = 0; i < kN; ++i)
        for (int j = 0; j < kR; ++j) g.out.addQuad(ids[i][j], ids[i][(j + 1) % kR], ids[i + 1][(j + 1) % kR], ids[i + 1][j]);
    const Vec3 tipDir = normalize(pts[kN] - pts[kN - 1]);
    const uint16_t tip = g.out.addVertex(pts[kN], tipDir, band, Material{});
    for (int j = 0; j < kR; ++j) g.out.addTriangle(tip, ids[kN][j], ids[kN][(j + 1) % kR]);
}

// Full-face downhill helmet: a glossy egg-shaped shell with one racing stripe over the top, a chin bar in the shell's colour with a dark vent,
// a tinted shield that hugs the front of the shell at eye level, and a rear spoiler. (Small: the head is about a seventh of the rider.)
void drawHelmet(const Rig& g, const Vec3& c, const Vec3& hr, const Vec3& u, const Vec3& hf) {
    const RiderStyle& st = g.st;
    const Vec3 R(0.132f, 0.128f, 0.150f);   // shell radii: right, up, forward
    const Rgba8 shellLo = glossy(shade(st.helmet, 0.78f), 0.55f), shellHi = glossy(st.helmet, 0.55f);
    const Rgba8 stripe = glossy(st.jacketHi, 0.55f);
    const Rgba8 visLo = glossy(kVisorLo, 0.92f), visHi = glossy(kVisorHi, 0.92f);
    const Vec3 centre = c + u * 0.006f;
    g.blob(centre, hr, u, hf, R, shellLo, shellHi, 2);                                                                  // shell
    g.blob(centre + u * 0.002f, hr, u, hf, Vec3(0.019f, R.y + 0.004f, R.z + 0.004f), stripe, stripe, 1);                // racing stripe over the top
    g.blob(c - u * 0.076f + hf * 0.080f, hr, u, hf, Vec3(0.086f, 0.050f, 0.078f), shade(shellLo, 0.92f), shellHi, 1);    // chin bar
    g.box(c - u * 0.084f + hf * 0.154f, hr, u, hf, Vec3(0.028f, 0.007f, 0.006f), visLo, visLo);                          // vent
    if (!g.low) {   // the shield: a strip that follows the shell, three rows high
        constexpr int kA = 12;
        static const float rows[3] = {-0.008f, 0.026f, 0.060f};
        uint16_t ids[kA + 1][3];
        for (int i = 0; i <= kA; ++i) {
            const float th = lerpf(-1.08f, 1.08f, static_cast<float>(i) / static_cast<float>(kA));
            for (int j = 0; j < 3; ++j) {
                const float sp = clampf(rows[j] / R.y, -0.95f, 0.95f), cp = std::sqrt(1.0f - sp * sp);
                const Vec3 d(std::sin(th) * cp, sp, std::cos(th) * cp);
                const Vec3 pos = centre + hr * (R.x * d.x * 1.035f) + u * (R.y * d.y * 1.035f) + hf * (R.z * d.z * 1.035f);
                const Vec3 nrm = normalize(hr * (d.x / R.x) + u * (d.y / R.y) + hf * (d.z / R.z));
                ids[i][j] = g.out.addVertex(pos, nrm, j == 1 ? visHi : visLo, Material{});
            }
        }
        for (int i = 0; i < kA; ++i)
            for (int j = 0; j < 2; ++j) g.out.addQuad(ids[i][j], ids[i + 1][j], ids[i + 1][j + 1], ids[i][j + 1]);
    } else {
        g.blob(c + u * 0.028f + hf * 0.098f, hr, u, hf, Vec3(0.100f, 0.040f, 0.052f), visLo, visHi, 1);
    }
    g.box(c - hf * 0.140f + u * 0.050f, hr, u, hf, Vec3(0.038f, 0.009f, 0.026f), shade(st.helmet, 0.55f), shade(st.helmet, 0.45f));   // rear spoiler
}

// Sleeve, cuff and slide glove with a puck on the palm; `palmDir` is where the palm faces.
void drawArm(const Rig& g, const Vec3& sh, const Vec3& elbow, const Vec3& hand, const Vec3& palmDir, const Vec3& hint) {
    const RiderStyle& st = g.st;
    const Rgba8 upperLo = shade(st.jacket, 0.82f);
    g.tube(sh, elbow, 0.063f, 0.052f, st.jacket, upperLo, hint);
    g.tube(elbow, hand, 0.052f, 0.043f, st.sleeve, st.sleeve, hint);
    g.ball(sh, 0.067f, st.jacket);
    g.ball(elbow, 0.055f, mix(upperLo, st.sleeve, 0.5f));
    const Vec3 fd = normalize(hand - elbow);
    g.tube(hand - fd * 0.080f, hand - fd * 0.046f, 0.048f, 0.048f, st.accent, st.accent, hint);   // cuff
    Vec3 pd = palmDir - fd * dot(palmDir, fd);
    pd = dot(pd, pd) > 1e-6f ? normalize(pd) : -g.u;
    const Vec3 ax = normalize(cross(pd, fd));
    const Vec3 c = hand + fd * 0.038f;
    g.blob(c, ax, fd, pd, Vec3(0.046f, 0.058f, 0.033f), kGlove, shade(kGlove, 1.5f), 1);
    kit::addTube(g.out, c + pd * 0.028f, c + pd * 0.043f, 0.032f, 0.030f, 8, st.accent, st.accent, Material{}, true, true, fd);   // slide puck
}

// Rider on the board. Three poses are blended by weight:
//   riding stance (stand <-> tuck), kick-push (foot plants, drives back, swings forward) and Coleman slide
//   (board kicked out sideways, deep crouch, inside hand on the road, free arm out for balance).
void buildStanding(const Rig& g, const SkaterPose& p) {
    const float t = p.tuck;
    const float L = p.lean;
    const float sd = p.slideDir;
    const float pw = saturate(p.push);
    const float cw = saturate(p.slide) * (1.0f - pw);
    const Vec3 roadUp = normalize(p.roadUp);
    auto mixv = [](const Vec3& a, const Vec3& b, float k) { return a + (b - a) * k; };
    // point `pt` moved along the road normal so that it sits `h` above the road surface
    auto onRoad = [&](const Vec3& pt, float h) { return pt - roadUp * (dot(pt - g.o, roadUp) - h); };

    // axes aligned with the travel direction: the rider keeps looking where the road goes while the board kicks out
    const float cs = std::cos(p.slip), sn = std::sin(p.slip);
    const Vec3 fT = g.f * cs - g.r * sn;
    const Vec3 rT = g.r * cs + g.f * sn;

    // ---- riding stance
    Vec3 ankleL = g.W(0.0f, 0.158f, 0.20f);    // left leg = front foot
    Vec3 ankleR = g.W(0.0f, 0.158f, -0.20f);   // right leg = back (kicking) foot
    const float hipY = lerpf(0.69f, 0.48f, t);
    Vec3 hip = g.W(L * 0.10f, hipY, lerpf(0.0f, -0.03f, t));
    const float twist = lerpf(0.50f, 0.95f, t);
    Vec3 facing = normalize(g.r * std::cos(twist) + g.f * std::sin(twist));
    const float pitchT = lerpf(0.26f, 1.02f, t);
    Vec3 td = normalize(g.u * std::cos(pitchT) + facing * std::sin(pitchT) + g.r * (L * 0.30f));
    float toeL = 0.0f, toeR = 0.0f;           // shoe yaw: 0 = across the board, pi/2 = pointing at the nose
    Vec3 headFace = g.f;
    float armSwing = 0.0f;                    // kick-push arm swing, +1 = left arm forward

    // ---- kick-push
    if (pw > 0.001f) {
        const float N = static_cast<float>(cfg::kPushStrokes);
        const float cyc = std::min(p.pushPhase, N);
        const float u = cyc - std::floor(cyc);
        const float c = cfg::kPushContact;
        float fx, fy, fz, kp;   // kicking foot (board space x right / z forward, height above the road) and kick progress 0..1
        if (u < c) {            // drive: the foot is on the road and slides back past the board
            const float s = u / c;
            fz = lerpf(0.10f, -0.50f, s);
            fx = lerpf(0.34f, 0.25f, s);
            fy = lerpf(0.050f, 0.090f, s * s);   // heel comes up at the end of the drive
            kp = s;
        } else {                // recovery: lift the foot and swing it forward to the next plant
            const float s = (u - c) / (1.0f - c);
            const float e = s * s * (3.0f - 2.0f * s);
            fz = lerpf(-0.50f, 0.10f, e);
            fx = lerpf(0.25f, 0.34f, e) + 0.03f * std::sin(kPi * s);
            fy = lerpf(0.090f, 0.050f, s) + 0.17f * std::sin(kPi * s);
            kp = 1.0f - e;
        }
        Vec3 kick = onRoad(g.o + g.r * fx + g.f * fz, fy);
        // the last recovery brings the foot back onto the deck instead of planting again
        const float landing = smoothstep(N - 0.55f, N, cyc);
        kick = mixv(kick, g.W(0.0f, 0.158f, -0.20f), landing);
        const float lunge = kp * (1.0f - landing);

        const Vec3 hipP = g.W(0.08f, 0.60f - 0.03f * lunge, lerpf(-0.04f, 0.06f, lunge));
        const Vec3 facingP = normalize(g.r * std::cos(1.0f) + g.f * std::sin(1.0f));
        const float pitchP = 0.46f + 0.14f * lunge;
        const Vec3 tdP = normalize(g.u * std::cos(pitchP) + facingP * std::sin(pitchP));
        ankleR = mixv(ankleR, kick, pw);
        hip = mixv(hip, hipP, pw);
        facing = normalize(mixv(facing, facingP, pw));
        td = normalize(mixv(td, tdP, pw));
        toeL = lerpf(toeL, 0.95f, pw);
        toeR = lerpf(toeR, lerpf(1.30f, 0.0f, landing), pw);
        armSwing = (lunge * 2.0f - 1.0f) * (1.0f - landing) * pw;
    }

    // ---- Coleman slide
    if (cw > 0.001f) {
        const float mag = saturate((std::fabs(p.slip) - 0.80f) / 0.5f);
        const Vec3 hipC = g.o + g.u * 0.34f - g.f * 0.10f + rT * (sd * 0.04f);   // a deep squat
        const Vec3 facingC = normalize(fT * 0.85f + rT * (sd * 0.55f));
        const float phi = lerpf(0.95f, 1.20f, mag);   // leaning into the slide: harder the further the board is out
        const Vec3 leanDir = normalize(rT * (sd * 0.9f) + fT * 0.35f);
        const Vec3 tdC = normalize(g.u * std::cos(phi) + leanDir * std::sin(phi));
        // each foot stays on its own side of the board so the legs never cross
        const Vec3 aF = g.W(0.0f, 0.158f, 0.22f), aB = g.W(0.0f, 0.158f, -0.22f);
        const bool frontOnLeft = dot(aF - aB, rT) < 0.0f;
        ankleL = mixv(ankleL, frontOnLeft ? aF : aB, cw);
        ankleR = mixv(ankleR, frontOnLeft ? aB : aF, cw);
        hip = mixv(hip, hipC, cw);
        facing = normalize(mixv(facing, facingC, cw));
        td = normalize(mixv(td, tdC, cw));
        headFace = normalize(mixv(headFace, normalize(fT + rT * (sd * 0.40f)), cw));
    }

    const Vec3 left = normalize(cross(g.u, facing));     // rider's left
    const Vec3 neck = hip + td * 0.50f;

    // ---- legs
    const Vec3 hipL = hip + left * 0.085f, hipR = hip - left * 0.085f;
    Vec3 endL, endR;
    // knees point along the board when riding (unchanged), and along the chest direction while kicking / sliding
    Vec3 poleL = normalize(g.r * 1.0f + g.u * 0.15f + g.f * 0.1f);
    Vec3 poleR = normalize(g.r * 1.0f + g.u * 0.15f - g.f * 0.1f);
    const float wMode = std::max(pw, cw);
    if (wMode > 0.001f) {
        poleL = normalize(mixv(poleL, normalize(facing + g.u * 0.15f + left * 0.10f), wMode));
        poleR = normalize(mixv(poleR, normalize(facing + g.u * 0.15f - left * 0.10f), wMode));
    }
    const Vec3 kneeL = solveJoint(hipL, ankleL, 0.38f, 0.38f, poleL, endL);
    const Vec3 kneeR = solveJoint(hipR, ankleR, 0.38f, 0.38f, poleR, endR);
    drawLeg(g, hipL, kneeL, endL, poleL);
    drawLeg(g, hipR, kneeR, endR, poleR);
    // shoes: toes along `dir` (yaw measured from "across the board" toward the nose)
    for (int i = 0; i < 2; ++i) {
        const Vec3 a = i == 0 ? endL : endR;
        const float yaw = i == 0 ? toeL : toeR;
        const Vec3 dir = normalize(g.r * std::cos(yaw) + g.f * std::sin(yaw));
        drawShoe(g, a, dir, g.u);
    }

    // ---- pelvis + jacket
    const Basis pb = basisFromY(normalize(g.u * 1.0f + td * 0.25f), facing);
    g.blob(hip + g.u * 0.02f, pb.x, pb.y, pb.z, Vec3(0.178f, 0.105f, 0.112f), g.st.pants, g.st.jacket);
    drawTorso(g, hip, td, facing);

    // ---- head + helmet (looks along the board, or along the road while sliding)
    const Vec3 headUp = normalize(td + g.u * (1.2f * cw));
    const Vec3 headC = neck + headUp * 0.17f + g.u * 0.03f;
    const Vec3 hf = normalize(headFace - g.u * dot(headFace, g.u));
    const Vec3 hr = cross(hf, g.u);
    g.tube(neck - td * 0.02f, headC - g.u * 0.08f, 0.056f, 0.052f, shade(g.st.jacket, 0.8f), shade(g.st.jacket, 0.6f), hf);
    drawHelmet(g, headC, hr, g.u, hf);

    // ---- arms: relaxed -> hands behind the back (tuck) -> swinging (kick-push) -> inside hand on the road (Coleman)
    const Vec3 shL = neck + left * 0.235f - td * 0.04f, shR = neck - left * 0.235f - td * 0.04f;
    auto handFor = [&](int side) {
        const float sgn = side == 0 ? 1.0f : -1.0f;
        const Vec3 sh = side == 0 ? shL : shR;
        const float sway = std::sin(p.time * 2.3f + sgn) * 0.04f;
        Vec3 relaxed = sh + left * (sgn * 0.21f) - td * 0.36f + facing * 0.22f + g.r * (L * 0.2f) + g.u * sway;   // arms bent, out in front for balance
        // balance arms swing wide when carving
        relaxed += left * (sgn * 0.10f * std::fabs(L) * 2.0f);
        const Vec3 back = hip - facing * 0.17f + left * (sgn * 0.16f) + g.u * 0.06f;
        Vec3 h = relaxed + (back - relaxed) * t;
        if (pw > 0.001f) {
            const float swing = side == 0 ? armSwing : -armSwing;   // opposite arm to the kicking leg swings forward
            h += g.f * (swing * 0.34f) + g.u * (0.10f * pw);
        }
        if (cw > 0.001f) {
            const bool inside = dot(sh - neck, rT * sd) > 0.0f;    // the shoulder on the side we slide toward
            Vec3 target;
            if (inside) {
                // hand flat on the road under the shoulder, as far out as the arm reaches
                const float drop = dot(sh - g.o, roadUp) - 0.05f;
                const float reach = 0.56f;
                const float horiz = std::sqrt(std::max(0.0f, reach * reach - drop * drop));
                const Vec3 outDir = normalize(rT * (sd * 0.85f) - fT * 0.30f);
                target = onRoad(sh + outDir * horiz, 0.05f);
            } else {
                // free arm thrown out behind and up for balance
                target = sh + rT * (-sd * 0.44f) + g.u * 0.22f - fT * 0.26f;   // elbow bent: balance, not pointing
            }
            h += (target - h) * cw;
        }
        return h;
    };
    ArmJoints arm[2];
    Vec3 palm[2];
    for (int side = 0; side < 2; ++side) {
        const float sgn = side == 0 ? 1.0f : -1.0f;
        const Vec3 sh = side == 0 ? shL : shR;
        Vec3 end;
        const Vec3 hand = handFor(side);
        const Vec3 pole = normalize(-td * 0.4f - facing * 0.4f + left * (sgn * 0.5f) - g.u * 0.3f);
        const Vec3 elbow = solveJoint(sh, hand, 0.30f, 0.29f, pole, end);
        // palms face the body when relaxed and the road when a hand is down for the slide
        const Vec3 inward = normalize(hip + td * 0.28f - end);
        palm[side] = normalize(mixv(inward, -roadUp, cw));
        arm[side] = {sh, elbow, end};
    }
    drawScarf(g, neck, td, facing, hip, arm, p.time, p.speed);
    for (int side = 0; side < 2; ++side) drawArm(g, arm[side].sh, arm[side].elbow, arm[side].hand, palm[side], facing);
}

void buildCrashed(const Rig& g, const SkaterPose& p) {
    const float t = p.crashTime;
    const float u1 = saturate(t / 1.4f);
    const float ease = 1.0f - (1.0f - u1) * (1.0f - u1);
    const float phi = ease * (kPi * 0.5f + kTwoPi);            // somersault then land on the back
    const float hopT = saturate(t / 0.95f);
    const float hop = 1.0f * std::sin(hopT * kPi) * (1.0f - u1 * 0.6f);
    const float restY = 0.20f;

    // board flies ahead and spins
    const float ahead = p.crashSpeed * 0.55f * (1.0f - std::exp(-1.4f * t)) / 1.4f;
    buildBoard(g, 7.0f * (1.0f - std::exp(-1.4f * t)), g.f * ahead + g.r * (0.7f * (1.0f - std::exp(-2.0f * t))),
               0.35f * std::sin(saturate(t / 0.8f) * kPi));

    // limp rider rotating around the board-right axis
    const Vec3 axis = g.r;
    auto R = [&](const Vec3& v) { return rotateAround(v, axis, phi); };
    const Vec3 pivot = g.o + g.u * (restY + hop) - g.f * 0.1f;
    const float splay = 0.5f + 0.5f * saturate(t / 0.8f);
    const Vec3 up = R(g.u), fw = R(g.f), rt = g.r;
    auto P = [&](float x, float y, float z) { return pivot + rt * x + up * y + fw * z; };
    const RiderStyle& st = g.st;

    // pelvis, jacket, neck, helmet
    const Vec3 hip = P(0.0f, 0.02f, 0.0f);
    g.blob(hip, rt, up, fw, Vec3(0.178f, 0.105f, 0.112f), st.pants, st.jacket);
    drawTorso(g, hip, up, fw);
    g.tube(P(0.0f, 0.55f, 0.0f), P(0.0f, 0.66f, 0.01f), 0.056f, 0.052f, shade(st.jacket, 0.8f), shade(st.jacket, 0.6f), fw);
    drawHelmet(g, P(0.0f, 0.73f, 0.02f), rt, up, fw);
    // legs and arms (rigid, splayed)
    for (int s = -1; s <= 1; s += 2) {
        const float sg = static_cast<float>(s);
        const Vec3 knee = P(0.16f * sg * splay, -0.42f, 0.05f * sg), ankle = P(0.27f * sg * splay, -0.84f, 0.02f);
        drawLeg(g, P(0.09f * sg, 0.0f, 0.0f), knee, ankle, fw + rt * (0.2f * sg));
        drawShoe(g, ankle, normalize(fw + rt * (0.5f * sg)), up);
        drawArm(g, P(0.24f * sg, 0.50f, 0.0f), P(0.50f * sg * splay, 0.36f, -0.05f * sg), P(0.76f * sg * splay, 0.22f, -0.12f * sg), -up, fw);
    }
}

}  // namespace

const RiderStyle& riderStyle(int index) {
    const int n = kRiderStyleCount;
    return kStyles[((index % n) + n) % n];
}

void buildSkaterMesh(const SkaterPose& pose, MeshData& out, const RiderStyle& style) {
    // Build at natural size, then scale up around the board so the rider reads well on a phone screen.
    constexpr float kRiderScale = 1.2f;
    MeshData tmp;
    Rig g{pose, tmp, pose.origin, pose.right, pose.up, pose.fwd, style, pose.lowDetail};
    if (pose.crashed) {
        buildCrashed(g, pose);
    } else {
        buildBoard(g, 0.0f, Vec3(), 0.0f);
        buildStanding(g, pose);
    }
    const Mat4 xf = Mat4::translation(pose.origin) * Mat4::scaling(Vec3(kRiderScale, kRiderScale, kRiderScale)) *
                    Mat4::translation(-pose.origin);
    out.append(tmp, xf);
}

}  // namespace sd
