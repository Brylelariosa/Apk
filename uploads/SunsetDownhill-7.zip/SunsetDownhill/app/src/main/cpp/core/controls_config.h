// controls_config.h - the player's control scheme and button layout.
// Plain data plus a tiny text format, so the Kotlin shell can persist it without knowing anything about it.
#pragma once

#include <cstdint>
#include <string>

#include "math3d.h"

namespace sd {

// How the rider is steered. TUCK, SLIDE and PUSH are always on-screen buttons.
enum class SteerMode : uint8_t {
    Stick = 0,    // floating stick: drag on the left half of the screen (the original control)
    Arrows,       // two on-screen arrow buttons
    Tilt,         // tilt the phone like a steering wheel
    ArrowsTilt,   // arrows and tilt together
    Count
};

inline bool usesStick(SteerMode m) { return m == SteerMode::Stick; }
inline bool usesArrows(SteerMode m) { return m == SteerMode::Arrows || m == SteerMode::ArrowsTilt; }
inline bool usesTilt(SteerMode m) { return m == SteerMode::Tilt || m == SteerMode::ArrowsTilt; }
// Without a tilt sensor the tilt schemes fall back to the arrow buttons, so the game stays playable.
inline SteerMode effectiveMode(SteerMode m, bool tiltAvailable) { return (usesTilt(m) && !tiltAvailable) ? SteerMode::Arrows : m; }

// The on-screen buttons the player can move and resize.
enum class ButtonId : uint8_t { Tuck = 0, Slide, Push, Left, Right, Count };
constexpr int kButtonCount = static_cast<int>(ButtonId::Count);
inline int toIndex(ButtonId b) { return static_cast<int>(b); }
inline bool isArrowButton(ButtonId b) { return b == ButtonId::Left || b == ButtonId::Right; }

// Where a button sits and how big it is.
//   x: distance from the nearest side edge in units of a 16:9 screen's width, signed: >= 0 counts from the left edge,
//      < 0 counts from the right edge. Buttons therefore keep hugging "their" side on wider and narrower screens.
//   y: fraction of the screen height (0 = top).
struct ButtonSpec {
    float x = 0.5f, y = 0.5f;
    float scale = 1.0f;         // multiplies the button's default radius
};

struct ControlsConfig {
    static constexpr float kMinScale = 0.6f, kMaxScale = 1.6f, kScaleStep = 0.1f;
    static constexpr float kMinOpacity = 0.3f, kMaxOpacity = 1.0f, kOpacityStep = 0.1f;
    static constexpr float kMinTilt = 0.5f, kMaxTilt = 2.0f, kTiltStep = 0.1f;

    SteerMode mode = SteerMode::Stick;
    ButtonSpec button[kButtonCount];
    float opacity = 1.0f;           // 1 = buttons drawn as designed; lower = more see-through
    float tiltSensitivity = 1.0f;   // 1 = full steering at TiltSteer::kFullLockDeg of tilt; higher = twitchier

    ControlsConfig() { resetLayout(); }   // a default-constructed config is the factory layout

    void resetLayout();   // button positions, sizes and opacity (keeps the steering mode and tilt sensitivity)
    void sanitize();      // clamps everything into range (and replaces NaNs)

    // "v1 m=1 o=0.800 t=1.200 tuck=0.8820,0.8000,1.000 slide=... push=... left=... right=..."
    // Forgiving on the way back in: unknown keys are skipped, unreadable values keep their defaults,
    // and text with no version tag yields the factory layout.
    std::string serialize() const;
    static ControlsConfig parse(const std::string& text);

    bool operator==(const ControlsConfig& o) const;
    bool operator!=(const ControlsConfig& o) const { return !(*this == o); }
};

}  // namespace sd
