#include "controls_config.h"

#include <cmath>
#include <cstdio>
#include <cstdlib>

namespace sd {
namespace {

constexpr const char* kButtonKeys[kButtonCount] = {"tuck", "slide", "push", "left", "right"};

// The factory layout. TUCK and SLIDE sit exactly where they did before the buttons were movable. (A saved layout from before PUSH
// existed has no push= entry, so it keeps this spot for the new button.)
constexpr ButtonSpec kFactory[kButtonCount] = {
    {-0.1177f, 0.800f, 1.0f},   // Tuck   (bottom right corner)
    {-0.2437f, 0.807f, 1.0f},   // Slide  (left of Tuck)
    {-0.1850f, 0.545f, 1.0f},   // Push   (above and between the two: the thumb rolls up to it to kick)
    {0.1150f, 0.800f, 1.0f},    // Left   (bottom left corner)
    {0.2550f, 0.800f, 1.0f},    // Right  (next to Left)
};

float finite(float v, float fallback) { return std::isfinite(v) ? v : fallback; }

// Values are stored as integers in thousandths: no locale-dependent decimal separators to trip over.
int milli(float v) { return static_cast<int>(std::lround(v * 1000.0f)); }

// Reads `n` comma separated integers; false if the text is not exactly that.
bool readInts(const char* s, int* out, int n) {
    for (int i = 0; i < n; ++i) {
        char* end = nullptr;
        const long v = std::strtol(s, &end, 10);
        if (end == s) return false;
        out[i] = static_cast<int>(v);
        s = end;
        if (i + 1 < n) {
            if (*s != ',') return false;
            ++s;
        }
    }
    return *s == '\0';
}

}  // namespace

void ControlsConfig::resetLayout() {
    for (int i = 0; i < kButtonCount; ++i) button[i] = kFactory[i];
    opacity = 1.0f;
}

void ControlsConfig::sanitize() {
    if (static_cast<int>(mode) >= static_cast<int>(SteerMode::Count)) mode = SteerMode::Stick;
    for (int i = 0; i < kButtonCount; ++i) {
        ButtonSpec& b = button[i];
        b.x = clampf(finite(b.x, kFactory[i].x), -1.0f, 1.0f);
        b.y = clampf(finite(b.y, kFactory[i].y), 0.0f, 1.0f);
        b.scale = clampf(finite(b.scale, 1.0f), kMinScale, kMaxScale);
    }
    opacity = clampf(finite(opacity, 1.0f), kMinOpacity, kMaxOpacity);
    tiltSensitivity = clampf(finite(tiltSensitivity, 1.0f), kMinTilt, kMaxTilt);
}

std::string ControlsConfig::serialize() const {
    char buf[96];
    int n = std::snprintf(buf, sizeof(buf), "v1 m=%d o=%d t=%d", static_cast<int>(mode), milli(opacity), milli(tiltSensitivity));
    std::string s(buf, static_cast<size_t>(n > 0 ? n : 0));
    for (int i = 0; i < kButtonCount; ++i) {
        n = std::snprintf(buf, sizeof(buf), " %s=%d,%d,%d", kButtonKeys[i], milli(button[i].x), milli(button[i].y), milli(button[i].scale));
        if (n > 0) s.append(buf, static_cast<size_t>(n));
    }
    return s;
}

ControlsConfig ControlsConfig::parse(const std::string& text) {
    ControlsConfig c;
    bool versioned = false;
    size_t pos = 0;
    while (pos < text.size()) {
        size_t end = text.find(' ', pos);
        if (end == std::string::npos) end = text.size();
        const std::string token = text.substr(pos, end - pos);
        pos = end + 1;
        if (token.empty()) continue;
        if (token == "v1") {
            versioned = true;
            continue;
        }
        const size_t eq = token.find('=');
        if (eq == std::string::npos) continue;
        const std::string key = token.substr(0, eq);
        const char* value = token.c_str() + eq + 1;
        int v[3] = {0, 0, 0};
        if (key == "m") {
            if (readInts(value, v, 1) && v[0] >= 0 && v[0] < static_cast<int>(SteerMode::Count)) c.mode = static_cast<SteerMode>(v[0]);
        } else if (key == "o") {
            if (readInts(value, v, 1)) c.opacity = static_cast<float>(v[0]) * 0.001f;
        } else if (key == "t") {
            if (readInts(value, v, 1)) c.tiltSensitivity = static_cast<float>(v[0]) * 0.001f;
        } else {
            for (int i = 0; i < kButtonCount; ++i) {
                if (key != kButtonKeys[i]) continue;
                if (readInts(value, v, 3)) {
                    c.button[i].x = static_cast<float>(v[0]) * 0.001f;
                    c.button[i].y = static_cast<float>(v[1]) * 0.001f;
                    c.button[i].scale = static_cast<float>(v[2]) * 0.001f;
                }
                break;
            }
        }
    }
    if (!versioned) return ControlsConfig();   // empty, foreign or from the future: start from the factory layout
    c.sanitize();
    return c;
}

bool ControlsConfig::operator==(const ControlsConfig& o) const {
    return serialize() == o.serialize();   // compares at the precision that is actually stored
}

}  // namespace sd
