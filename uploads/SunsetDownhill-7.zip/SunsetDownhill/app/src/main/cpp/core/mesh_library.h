// mesh_library.h - procedural meshes for every instanced scenery batch.
#pragma once

#include "scene_types.h"

namespace sd {

// Builds the static mesh for a batch. +Y up, -Z is the object's forward direction.
MeshData buildBatchMesh(Batch batch);

// How far the boughs of a tree of this batch reach from its trunk at scale 1 (m): the world keeps trees apart by this, so crowns of
// different kinds never grow into each other. Must match the meshes (test_trees measures them); 0 for anything that is not a tree.
float treeCrownRadius(Batch batch);

}  // namespace sd
