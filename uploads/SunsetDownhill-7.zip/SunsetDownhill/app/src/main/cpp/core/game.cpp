#include "game.h"

#include <chrono>
#include <cmath>
#include <cstdio>

namespace sd {

Game::Game() : fxRng_(4242u) {
    baseSeed_ = static_cast<uint32_t>(std::chrono::steady_clock::now().time_since_epoch().count());
    resetDemo();
}

// --------------------------------------------------------------------------------------
// Commands
// --------------------------------------------------------------------------------------

void Game::resetDemo() {
    world_.reset(hash2(baseSeed_, 7777u + demoCounter_++));
    world_.setObstaclesEnabled(false);
    skater_.reset(30.0f, 12.0f);
    autopilot_ = AutoPilot();
    autopilot_.speedCap = 19.0f;
    world_.update(0.0f, playerRef());
    camera_.reset(world_.track(), skater_);
    fx_.clear();
    sunAz_ = world_.track().at(skater_.s + 260.0f).heading + 0.38f;
    atmo_ = makeAtmosphere(0.0f, sunAz_);
}

void Game::startRun() {
    if (phase_ != Phase::Menu && phase_ != Phase::GameOver) return;
    ++runCounter_;
    beginRun(hash2(baseSeed_, runCounter_ * 2654435761u));
}

void Game::startRunSeeded(uint32_t seed, float lagSeconds, float goalMeters) {
    if (phase_ != Phase::Menu && phase_ != Phase::GameOver) return;
    ++runCounter_;
    beginRun(hash2(seed, 0x4C414E31u));   // "LAN1": the same seed gives every phone the same road, cones and rocks
    goal_ = goalMeters > 0.0f ? goalMeters : 0.0f;
    goalS_ = skater_.s + goal_;
    // The host's countdown has been running for `lagSeconds` already: join it in progress so everybody's GO is the same moment.
    phaseTime_ = clampf(lagSeconds, 0.0f, 3.0f * cfg::kCountdownStep + 0.4f);
}

void Game::beginRun(uint32_t worldSeed) {
    world_.reset(worldSeed);
    world_.setObstaclesEnabled(true);
    skater_.reset(6.0f, 0.0f);
    world_.update(0.0f, playerRef());
    camera_.reset(world_.track(), skater_);
    fx_.clear();
    style_ = 0.0f;
    driftPoints_ = 0.0f;
    nearMisses_ = 0;
    crashKind_ = -1;
    newBest_ = false;
    popupAge_ = 99.0f;
    flash_ = 0.0f;
    lastTick_ = 99;
    lastPushSteps_ = lastPushLands_ = 0;
    goal_ = goalS_ = 0.0f;
    seenTakeoffs_ = seenLandings_ = seenGaps_ = 0;
    finished_ = false;
    finishTime_ = finishTimer_ = 0.0f;
    phase_ = Phase::Countdown;
    phaseTime_ = 0.0f;
    sunAz_ = world_.track().at(skater_.s + 260.0f).heading + 0.38f;
}

void Game::pause() {
    if (phase_ == Phase::Running || phase_ == Phase::Countdown) {
        pausedFrom_ = phase_;
        phase_ = Phase::Paused;
    }
}

void Game::resume() {
    if (phase_ == Phase::Paused) phase_ = pausedFrom_;
}

void Game::toMenu() {
    phase_ = Phase::Menu;
    phaseTime_ = 0.0f;
    resetDemo();
}

bool Game::handleBack() {
    switch (phase_) {
        case Phase::Running:
        case Phase::Countdown: pause(); return true;
        case Phase::Paused:
        case Phase::Crashed:
        case Phase::GameOver: toMenu(); return true;
        case Phase::Menu: break;
    }
    return false;
}

GameEvents Game::takeEvents() {
    GameEvents e = events_;
    events_ = GameEvents();
    return e;
}

int Game::countdownNumber() const {
    if (phase_ != Phase::Countdown && !(phase_ == Phase::Paused && pausedFrom_ == Phase::Countdown)) return 0;
    return std::max(0, 3 - static_cast<int>(phaseTime_ / cfg::kCountdownStep));
}

float Game::countdownProgress() const {
    const float t = std::fmod(phaseTime_, cfg::kCountdownStep) / cfg::kCountdownStep;
    return saturate(t);
}

float Game::popupAlpha() const {
    if (popupAge_ > 1.5f) return 0.0f;
    return popupAge_ < 1.0f ? 1.0f : 1.0f - (popupAge_ - 1.0f) / 0.5f;
}

void Game::showPopup(const char* text) {
    std::snprintf(popupText_, sizeof(popupText_), "%s", text);
    popupAge_ = 0.0f;
}

// --------------------------------------------------------------------------------------
// Simulation
// --------------------------------------------------------------------------------------

// The PUSH button blinks while the board would die: a climb, or a flat stretch at a low speed, with the rider not kicking yet.
void Game::updatePushHint(float dt) {
    bool want = false;
    const Skater& sk = skater_;
    if (phase_ == Phase::Running && !finished_ && !sk.crashed && !sk.airborne && !sk.gapFlight && !sk.pushActive) {
        const Track& tr = world_.track();
        const float pitch = std::min(tr.pitchAt(sk.s), tr.pitchAt(sk.s + 6.0f + sk.speed * 0.5f));
        want = Skater::coastAccel(pitch, sk.speed) < 0.5f && sk.speed < cfg::kPushMaxSpeed + 2.0f;
    }
    pushHint_ += ((want ? 1.0f : 0.0f) - pushHint_) * smoothing(want ? 5.0f : 9.0f, dt);
    pushPulse_ += dt;
}

void Game::update(float dt, const SkaterInput& input) {
    dt = clampf(dt, 0.0f, 0.05f);
    if (phase_ == Phase::Paused) return;
    time_ += dt;
    phaseTime_ += dt;
    popupAge_ += dt;
    flash_ = std::max(0.0f, flash_ - dt * 2.2f);

    const int steps = std::max(1, static_cast<int>(std::ceil(dt / cfg::kMaxPhysicsStep)));
    const float h = dt / static_cast<float>(steps);
    bool scraping = false;
    float intro = 0.0f;

    switch (phase_) {
        case Phase::Menu: {
            for (int i = 0; i < steps; ++i) {
                world_.update(h, playerRef());
                const SkaterInput in = autopilot_.compute(world_.track(), world_.obstacles(), skater_);
                skater_.step(in, world_.track(), h);
            }
            if (skater_.crashed || skater_.s > 3000.0f) resetDemo();
            break;
        }
        case Phase::Countdown: {
            world_.update(0.0f, playerRef());
            const int num = 3 - static_cast<int>(phaseTime_ / cfg::kCountdownStep);
            if (num != lastTick_) {
                lastTick_ = num;
                if (num >= 1) events_.tick = num;
            }
            intro = 1.0f - smoothstep(0.0f, 3.0f * cfg::kCountdownStep, phaseTime_);
            if (phaseTime_ >= 3.0f * cfg::kCountdownStep) {
                phase_ = Phase::Running;
                phaseTime_ = 0.0f;
                skater_.startPush();
                events_.go = true;
            }
            break;
        }
        case Phase::Running: {
            const SkaterInput noInput;   // past the finish line the rider just rolls out
            for (int i = 0; i < steps; ++i) {
                world_.update(h, playerRef());
                const SkaterEvent ev = skater_.step(finished_ ? noInput : input, world_.track(), h);
                if (ev == SkaterEvent::Scrape) scraping = true;
                if (finished_) skater_.speed *= std::exp(-0.75f * h);
                else if (!skater_.crashed) collide();
                if (skater_.crashed) break;
            }
            if (skater_.takeoffs != seenTakeoffs_) {
                seenTakeoffs_ = skater_.takeoffs;
                camera_.addShake(0.08f);
            }
            if (skater_.landings != seenLandings_) {   // touchdown: a thump, and points for a gorge jump
                seenLandings_ = skater_.landings;
                camera_.addShake(0.10f + 0.02f * std::min(12.0f, -skater_.lastLandVy));
                if (!skater_.crashed) {
                    Vec3 lp, lr, lu, lf;
                    skaterFrame(lp, lr, lu, lf);
                    burst(lp + lu * 0.1f, 14, 14, lf * (skater_.speed * 0.2f) + lu * 2.0f);
                    if (skater_.gapJumps != seenGaps_) {   // across the gorge: the whole detour skipped
                        seenGaps_ = skater_.gapJumps;
                        style_ += 500.0f;
                        showPopup("GORGE JUMP  +500");
                    } else if (skater_.airTime > 0.6f) {
                        style_ += 100.0f;
                        showPopup("AIR TIME  +100");
                    }
                }
            }
            if (goal_ > 0.0f && !finished_ && !skater_.crashed && skater_.s >= goalS_) crossFinishLine();
            if (finished_) {
                finishTimer_ += dt;
                if (finishTimer_ > 1.6f) finishRun();   // the standings come up
            }
            // kick-push sounds: foot plants on the road / foot lands back on the deck
            if (skater_.pushSteps != lastPushSteps_) {
                lastPushSteps_ = skater_.pushSteps;
                events_.push = true;
            }
            if (skater_.pushLands != lastPushLands_) {
                lastPushLands_ = skater_.pushLands;
                events_.footOn = true;
            }
            // scoring: Coleman slides (board kicked out, hand down) pay out per metre while they last
            if (!skater_.crashed) {
                if (skater_.slide > 0.5f && skater_.speed > 9.0f) {
                    const float pts = dt * skater_.speed * 0.5f;
                    style_ += pts;
                    driftPoints_ += pts;
                } else if (skater_.slide < 0.25f && driftPoints_ > 0.0f) {
                    if (driftPoints_ > 18.0f) {
                        char buf[40];
                        std::snprintf(buf, sizeof(buf), "COLEMAN SLIDE +%d", static_cast<int>(driftPoints_));
                        showPopup(buf);
                    }
                    driftPoints_ = 0.0f;
                }
            }
            if (skater_.crashed && phase_ == Phase::Running) {
                if (finished_) finishRun();   // hit something while rolling out: the finish already counts
                else onCrash();
            }
            break;
        }
        case Phase::Crashed: {
            for (int i = 0; i < steps; ++i) skater_.step(SkaterInput(), world_.track(), h);
            world_.update(dt, playerRef());
            if (phaseTime_ > cfg::kCrashDuration) finishRun();
            break;
        }
        case Phase::GameOver: {
            for (int i = 0; i < steps; ++i) {
                skater_.step(SkaterInput(), world_.track(), h);
                if (finished_) skater_.speed *= std::exp(-0.75f * h);
            }
            world_.update(dt, playerRef());
            break;
        }
        case Phase::Paused: break;
    }

    if (scraping) events_.scrape = true;
    updatePushHint(dt);

    emitFx(dt, scraping);
    fx_.update(dt);

    const float orbitTarget = phase_ == Phase::Menu ? 1.0f : 0.0f;
    orbit_ += (orbitTarget - orbit_) * smoothing(1.5f, dt);
    camera_.update(dt, world_.track(), skater_, intro, orbit_, time_);

    // atmosphere: golden hour -> dusk over the first few kilometres; sun stays roughly ahead
    const float sunTarget = world_.track().at(skater_.s + 260.0f).heading + 0.38f;
    sunAz_ += (sunTarget - sunAz_) * smoothing(0.35f, dt);
    atmo_ = makeAtmosphere(smoothstep(0.0f, 4500.0f, skater_.distance), sunAz_);
}

// The rider as the drivers see them (they keep clear of the rider and check for them before changing lane).
PlayerRef Game::playerRef() const {
    PlayerRef p;
    p.s = skater_.focusS();   // (while the rider flies over a gorge the world stays built around its mouth)
    p.x = skater_.x;
    p.speed = skater_.speed;
    p.active = phase_ != Phase::Menu;
    return p;
}

void Game::collide() {
    if (skater_.gapFlight) return;   // flying over the gorge: the traffic is far below
    for (Obstacle& o : world_.obstacles()) {
        if (o.hit) continue;
        const float ds = o.s - skater_.s;
        if (ds > 10.0f || ds < -10.0f) continue;
        const float dx = std::fabs(o.x - skater_.x);
        const float lim = o.hs + cfg::kSkaterHalfLength;
        if (std::fabs(ds) < lim) {
            const float gap = dx - (o.hx + cfg::kSkaterHalfWidth);
            if (gap < 0.0f) {
                if (o.kind == ObstacleKind::Cone) {
                    o.hit = true;
                    o.hitTime = 0.0f;
                    o.knockDir = (o.x - skater_.x) >= 0.0f ? 1.0f : -1.0f;
                    skater_.speed *= 0.88f;
                    events_.coneHit = true;
                    camera_.addShake(0.25f);
                    const TrackSample f = world_.track().at(o.s);
                    burst(Track::surfacePoint(f, o.x, 0.3f), 0, 8, f.up * 2.0f);
                } else {
                    crashKind_ = static_cast<int>(o.kind);
                    skater_.crash(CrashCause::Obstacle);
                    return;
                }
            } else {
                o.minGap = std::min(o.minGap, gap);
            }
        }
        if (!o.passed && ds < -(o.hs + 0.6f)) {
            o.passed = true;
            if (o.kind != ObstacleKind::Cone && o.minGap < 0.9f) {
                ++nearMisses_;
                style_ += 40.0f;
                events_.nearMiss = true;
                showPopup("CLOSE CALL +40");
            }
        }
    }
}

void Game::onCrash() {
    phase_ = Phase::Crashed;
    phaseTime_ = 0.0f;
    events_.crash = true;
    flash_ = 0.55f;
    camera_.addShake(1.0f);
    Vec3 pos, r, u, f;
    skaterFrame(pos, r, u, f);
    burst(pos + u * 0.5f, 22, 26, f * (skater_.speed * 0.3f) + u * 3.0f);
    driftPoints_ = 0.0f;
}

void Game::crossFinishLine() {
    finished_ = true;
    finishTimer_ = 0.0f;
    const float over = std::max(0.0f, skater_.s - goalS_);
    finishTime_ = std::max(0.0f, phaseTime_ - over / std::max(1.0f, skater_.speed));   // the exact moment inside this frame
    style_ += 500.0f;
    events_.newBest = true;   // fanfare
    camera_.addShake(0.3f);
    char buf[40];
    const int minutes = static_cast<int>(finishTime_ / 60.0f);
    std::snprintf(buf, sizeof(buf), "FINISH  %d:%04.1f  +500", minutes, finishTime_ - 60.0f * static_cast<float>(minutes));
    showPopup(buf);
}

void Game::finishRun() {
    phase_ = Phase::GameOver;
    phaseTime_ = 0.0f;
    if (score() > best_) {
        best_ = score();
        newBest_ = true;
        events_.newBest = true;
    }
}

// --------------------------------------------------------------------------------------
// Presentation helpers
// --------------------------------------------------------------------------------------

// Board frame of a rider flying over a gorge (Track::gapFlightAt): nose along the path, easing level with the road once the rider is
// over it and close to the ground (for the touchdown). `b` / `rel` / `h` / `slope`: how far to the right of the line the rider is, how
// far the board is turned from it, how high above the lip's launch point, and how steeply the path climbs.
static void gapFrame(const Track& track, const ShortcutZone& z, float u, float b, float rel, float h, float slope, float lean, Vec3& pos,
                     Vec3& right, Vec3& up, Vec3& fwd, Vec3* roadUp) {
    Vec3 p, d;
    track.gapFlightAt(z, u, b, rel, h, slope, &p, &d);
    float level = 0.0f, gs = z.sLand, gd = 0.0f, gy = 0.0f;
    if (track.groundNear(z, p, &gs, &gd, &gy) && gs > z.sLand - 12.0f && std::fabs(gd) <= cfg::kRailOffset + 0.05f) level = 1.0f - smoothstep(0.4f, 3.5f, p.y - gy);
    const TrackSample road = track.at(level > 0.0f ? gs : z.sLand);
    // the nose keeps the flight's heading; only the pitch eases level with the road for the touchdown
    const Vec3 dh = normalize(Vec3(d.x, 0.0f, d.z));
    const float pitch = lerpf(std::asin(clampf(d.y, -1.0f, 1.0f)), std::asin(clampf(road.fwd.y, -1.0f, 1.0f)), level);
    fwd = normalize(Vec3(dh.x * std::cos(pitch), std::sin(pitch), dh.z * std::cos(pitch)));
    const Vec3 upHint = normalize(lerp(Vec3(0.0f, 1.0f, 0.0f), road.up0, level));
    right = normalize(cross(fwd, upHint));
    up = cross(right, fwd);
    pos = p;
    if (roadUp) *roadUp = upHint;
    const float roll = lean * 0.35f;
    right = rotateAround(right, fwd, roll);
    up = rotateAround(up, fwd, roll);
}

// How steeply another phone's rider climbs or dives over the gorge, worked out from what it sends (metres from the lip, height, speed):
// the arc that left the kicker at its full slope and fits the height reached so far.
static float estimateGapSlope(const ShortcutZone& z, float metres, float h, float speed) {
    const float v = std::max(1.0f, speed);
    const float t = metres / v;
    const float vy0 = std::min(cfg::kGapPopMax, v * z.lipSlope());
    if (t < 0.12f) return vy0 / v;
    const float g = 2.0f * (vy0 * t - h) / (t * t);   // the gravity that bends the arc through this point
    return (vy0 - g * t) / v;
}

void riderFrame(const Track& track, float s, float x, float heading, float lean, Vec3& pos, Vec3& right, Vec3& up, Vec3& fwd, Vec3* roadUp, float yRel) {
    const TrackSample f = track.at(s);
    if (roadUp) *roadUp = f.up;
    pos = Track::surfacePoint(f, x, yRel);
    fwd = rotateAround(f.fwd, f.up, -heading);
    right = normalize(cross(fwd, f.up));
    up = cross(right, fwd);
    const float roll = lean * 0.35f;
    right = rotateAround(right, fwd, roll);
    up = rotateAround(up, fwd, roll);
}

void Game::skaterFrame(Vec3& pos, Vec3& right, Vec3& up, Vec3& fwd, Vec3* roadUp) const {
    if (skater_.gapFlight) {
        const ShortcutZone& z = world_.track().shortcuts()[static_cast<size_t>(skater_.gapZone)];
        gapFrame(world_.track(), z, skater_.gapU, skater_.gapB, skater_.gapRel, skater_.gapH, skater_.gapSlope(), skater_.lean, pos, right, up, fwd, roadUp);
        return;
    }
    riderFrame(world_.track(), skater_.s, skater_.x, skater_.alpha + skater_.yawVis, skater_.lean, pos, right, up, fwd, roadUp, skater_.yRel);
}

SkaterPose poseFromRiderNet(const Track& track, const RiderNet& r, const Vec3& origin, float time) {
    SkaterPose p;
    Vec3 pos;
    // (a rider flying over a gorge sends 100 + its height above the lip: see Game::riderNet)
    const ShortcutZone* gz = r.yRel > 40.0f ? track.zoneAt(r.s) : nullptr;
    if (gz) {
        const float metres = std::max(0.0f, r.s - gz->sLip), h = r.yRel - 100.0f;
        const float u = metres / track.gapFrameOf(*gz).chordH;
        gapFrame(track, *gz, u, r.x, r.alpha, h, estimateGapSlope(*gz, metres, h, r.speed), r.lean, pos, p.right, p.up, p.fwd, &p.roadUp);   // (x = metres off the line, alpha = how far the board is turned from it)
    } else {
        riderFrame(track, r.s, r.x, r.alpha + r.yawVis, r.lean, pos, p.right, p.up, p.fwd, &p.roadUp, r.yRel);
    }
    p.origin = pos - origin;
    p.tuck = r.tuck;
    p.lean = r.lean;
    p.slide = r.slide;
    p.slideDir = r.slideDir;
    p.slip = r.yawVis;
    p.push = r.pushAmount;
    p.pushPhase = r.pushPhase;
    p.time = time;
    p.speed = r.speed;
    p.crashed = r.crashed;
    p.crashTime = r.crashTime;
    p.crashSpeed = r.crashSpeed;
    return p;
}

RiderNet Game::riderNet() const {
    RiderNet r;
    r.s = skater_.s;
    r.x = skater_.x;
    r.alpha = skater_.alpha;
    r.yawVis = skater_.yawVis;
    r.speed = skater_.speed;
    r.lean = skater_.lean;
    r.tuck = skater_.tuck;
    r.slide = skater_.slide;
    r.slideDir = skater_.slideDir;
    r.pushAmount = skater_.pushAmount;
    r.pushPhase = skater_.pushPhase;
    if (phase_ == Phase::Countdown) {   // waiting with the kicking foot planted (same as the local pose)
        r.pushAmount = 1.0f;
        r.pushPhase = 0.0f;
    }
    r.crashTime = skater_.crashTime;
    r.crashSpeed = skater_.crashSpeed;
    r.distance = skater_.distance;
    r.score = score();
    r.crashed = skater_.crashed;
    r.finished = finished_;
    r.finishTime = finishTime_;
    r.yRel = skater_.gapFlight ? 100.0f + clampf(skater_.gapH, -45.0f, 45.0f) : skater_.yRel;   // (100 + height = flying over a gorge; s tells how far, x / alpha how the rider steered it)
    r.airborne = skater_.airborne;
    return r;
}

SkaterPose Game::skaterPose(const Vec3& origin) const {
    SkaterPose p;
    Vec3 pos;
    skaterFrame(pos, p.right, p.up, p.fwd, &p.roadUp);
    p.origin = pos - origin;
    p.tuck = skater_.tuck;
    p.lean = skater_.lean;
    p.slide = skater_.slide;
    p.slideDir = skater_.slideDir;
    p.slip = skater_.yawVis;
    p.push = skater_.pushAmount;
    p.pushPhase = skater_.pushPhase;
    p.speed = skater_.speed;
    // During the countdown the rider waits with the kicking foot planted on the road, ready for the first drive.
    if (phase_ == Phase::Countdown || (phase_ == Phase::Paused && pausedFrom_ == Phase::Countdown)) {
        p.push = 1.0f;
        p.pushPhase = 0.0f;
    }
    p.time = time_;
    p.crashed = skater_.crashed;
    p.crashTime = skater_.crashTime;
    p.crashSpeed = skater_.crashSpeed;
    return p;
}

void Game::burst(const Vec3& pos, int smoke, int sparks, const Vec3& dir) {
    for (int i = 0; i < smoke; ++i) {
        Particle p;
        p.pos = pos + Vec3(fxRng_.range(-0.3f, 0.3f), fxRng_.range(0.0f, 0.4f), fxRng_.range(-0.3f, 0.3f));
        p.vel = dir * 0.4f + Vec3(fxRng_.range(-2.5f, 2.5f), fxRng_.range(0.5f, 3.0f), fxRng_.range(-2.5f, 2.5f));
        p.life = fxRng_.range(0.8f, 1.6f);
        p.size0 = 0.5f;
        p.size1 = fxRng_.range(2.0f, 3.6f);
        p.color = rgba(0.82f, 0.72f, 0.64f, 0.55f);
        p.drag = 1.6f;
        fx_.emit(p);
    }
    for (int i = 0; i < sparks; ++i) {
        Particle p;
        p.pos = pos;
        p.vel = dir + Vec3(fxRng_.range(-5.0f, 5.0f), fxRng_.range(0.0f, 5.0f), fxRng_.range(-5.0f, 5.0f));
        p.life = fxRng_.range(0.3f, 0.7f);
        p.size0 = 0.05f;
        p.size1 = 0.03f;
        p.color = rgba(1.0f, 0.72f, 0.32f, 1.0f);
        p.gravity = 9.0f;
        p.additive = true;
        fx_.emit(p);
    }
}

void Game::emitFx(float dt, bool scraping) {
    if (phase_ == Phase::Paused) return;
    Vec3 pos, r, u, f;
    skaterFrame(pos, r, u, f);
    const TrackSample ts = world_.track().at(skater_.s);
    const Vec3 travel = ts.fwd;

    // tyre smoke + sparks while sliding
    if (!skater_.crashed && skater_.slide > 0.3f && skater_.speed > 6.0f) {
        smokeAcc_ += dt * 55.0f * skater_.slide;
        sparkAcc_ += dt * 30.0f * skater_.slide;
        while (smokeAcc_ >= 1.0f) {
            smokeAcc_ -= 1.0f;
            Particle p;
            p.pos = pos + f * fxRng_.range(-0.55f, 0.55f) + u * 0.08f;   // wheels skid along the whole board
            p.vel = -travel * (skater_.speed * 0.25f) + u * 0.8f + Vec3(fxRng_.range(-0.6f, 0.6f), fxRng_.range(0.0f, 0.8f), fxRng_.range(-0.6f, 0.6f));
            p.life = fxRng_.range(0.7f, 1.2f);
            p.size0 = 0.35f;
            p.size1 = fxRng_.range(1.6f, 2.4f);
            p.color = rgba(0.92f, 0.86f, 0.82f, 0.42f);
            p.drag = 1.4f;
            fx_.emit(p);
        }
        while (sparkAcc_ >= 1.0f) {
            sparkAcc_ -= 1.0f;
            Particle p;
            p.pos = pos + f * fxRng_.range(-0.5f, 0.5f) + u * 0.05f;
            p.vel = -travel * (skater_.speed * 0.2f) + u * fxRng_.range(0.5f, 2.5f) + r * fxRng_.range(-1.5f, 1.5f);
            p.life = fxRng_.range(0.2f, 0.45f);
            p.size0 = 0.05f;
            p.size1 = 0.03f;
            p.color = rgba(1.0f, 0.75f, 0.35f, 1.0f);
            p.gravity = 9.0f;
            p.additive = true;
            fx_.emit(p);
        }
    }

    // gravel dust on the shoulder
    if (!skater_.crashed && skater_.onShoulder && skater_.speed > 5.0f) {
        dustAcc_ += dt * 40.0f;
        while (dustAcc_ >= 1.0f) {
            dustAcc_ -= 1.0f;
            Particle p;
            p.pos = pos + u * 0.05f;
            p.vel = -travel * (skater_.speed * 0.2f) + Vec3(fxRng_.range(-1.0f, 1.0f), fxRng_.range(0.4f, 1.6f), fxRng_.range(-1.0f, 1.0f));
            p.life = fxRng_.range(0.8f, 1.4f);
            p.size0 = 0.3f;
            p.size1 = fxRng_.range(1.4f, 2.2f);
            p.color = rgba(0.62f, 0.5f, 0.36f, 0.42f);
            p.drag = 1.2f;
            fx_.emit(p);
        }
    }

    // sparks from rail contact
    if (scraping) {
        const Vec3 contact = Track::surfacePoint(ts, sign1(skater_.x) * cfg::kRailOffset, 0.35f);
        for (int i = 0; i < 5; ++i) {
            Particle p;
            p.pos = contact;
            p.vel = -travel * fxRng_.range(2.0f, 9.0f) + u * fxRng_.range(0.5f, 4.0f) - ts.right0 * (sign1(skater_.x) * fxRng_.range(0.0f, 3.0f));
            p.life = fxRng_.range(0.25f, 0.6f);
            p.size0 = 0.06f;
            p.size1 = 0.03f;
            p.color = rgba(1.0f, 0.8f, 0.4f, 1.0f);
            p.gravity = 9.0f;
            p.additive = true;
            fx_.emit(p);
        }
    }
}

}  // namespace sd
