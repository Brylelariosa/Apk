// hud.h - in-engine HUD, menus and overlays (drawn with UiBatch, no platform widgets).
#pragma once

#include "controls_config.h"
#include "game.h"
#include "hud_mp.h"
#include "ui_action.h"
#include "ui_batch.h"
#include "ui_layout.h"

namespace sd {

struct HudModel {
    Phase phase = Phase::Menu;
    float phaseTime = 0.0f;
    float time = 0.0f;
    float speedKmh = 0.0f;
    float distanceM = 0.0f;
    int score = 0;
    int best = 0;
    bool newBest = false;
    float topSpeedKmh = 0.0f;
    int nearMisses = 0;
    int countdown = 0;
    float countdownProgress = 0.0f;
    const char* popup = "";
    float popupAlpha = 0.0f;
    float popupAge = 0.0f;
    bool soundOn = true;
    SteerMode mode = SteerMode::Stick;   // the steering in use (controls the buttons and hints that are drawn)
    bool steerActive = false;
    Vec2 stickOrigin, stickKnob;
    bool tuckDown = false, slideDown = false, pushDown = false;
    float pushHint = 0.0f;   // 0..1: the road is climbing (or the board is dying) and kicking would help - the PUSH button calls for the thumb
    float pulse = 0.0f;      // seconds, for the blink of that call
    bool leftDown = false, rightDown = false;
    float tilt = 0.0f;       // what the phone tilt is steering right now (-1..1)
    float opacity = 1.0f;    // see-through-ness of the control buttons
    float goalM = 0.0f;      // finish line of a LAN race (0 = none)
    float toGoM = 0.0f;      // metres left to the finish line
    bool finished = false;   // crossed the finish line
    float finishTime = 0.0f;
    int finishRank = 0;
    MpModel mp;              // LAN multiplayer: lobby screens, standings, name tags
};

void drawHud(UiBatch& ui, const UiLayout& layout, const HudModel& model);
// `index` receives the row for UiAction::LobbyJoin.
UiAction hudHandleTap(const UiLayout& layout, const HudModel& model, float x, float y, int* index = nullptr);

}  // namespace sd
