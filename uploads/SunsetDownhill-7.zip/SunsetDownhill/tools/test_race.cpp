// Race rules and the gorge jump (no GPU needed):
//  - the rider meshes stay inside the 16-bit index budget of the dynamic mesh, six riders at once
//  - gorge zones: the U-shaped detour closes onto the original line, the ground is cut away beside it, support / rail rules are consistent
//  - the kicker flies the rider across the gorge onto the road beyond at any sensible speed, and the jump is a real shortcut
//  - the finish line ends a race, and a late START message fast-forwards the countdown so that GO is simultaneous
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <vector>

#include "autopilot.h"
#include "game.h"
#include "skater_model.h"
#include "track.h"

using namespace sd;

static int g_fails = 0, g_checks = 0;
#define CHECK(cond, ...)                                                            \
    do {                                                                            \
        ++g_checks;                                                                 \
        if (!(cond)) {                                                              \
            ++g_fails;                                                              \
            std::printf("  FAIL line %d: %s  ", __LINE__, #cond);                   \
            std::printf(__VA_ARGS__);                                               \
            std::printf("\n");                                                      \
        }                                                                           \
    } while (0)

static void testMeshBudget() {
    std::printf("rider mesh budget\n");
    size_t worst = 0, worstLow = 0;
    for (int style = 0; style < kRiderStyleCount; ++style) {
        for (int pose = 0; pose < 6; ++pose) {
            SkaterPose p;
            p.origin = Vec3(0, 0, 0); p.right = Vec3(1, 0, 0); p.up = Vec3(0, 1, 0); p.fwd = Vec3(0, 0, 1); p.time = 1.3f;
            if (pose == 1) p.tuck = 1.0f;
            if (pose == 2) { p.push = 1.0f; p.pushPhase = 0.4f; }
            if (pose == 3) { p.slide = 1.0f; p.slip = 1.1f; p.slideDir = -1.0f; }
            if (pose == 4) { p.crashed = true; p.crashTime = 0.7f; p.crashSpeed = 14.0f; }
            if (pose == 5) { p.lean = 0.5f; p.tuck = 0.5f; }
            MeshData full, low;
            p.lowDetail = false; buildSkaterMesh(p, full, riderStyle(style));
            p.lowDetail = true; buildSkaterMesh(p, low, riderStyle(style));
            worst = std::max(worst, full.vertices.size());
            worstLow = std::max(worstLow, low.vertices.size());
        }
    }
    std::printf("  full detail %zu vertices, low detail %zu\n", worst, worstLow);
    CHECK(worst <= kRiderVertexBudget, "full detail rider %zu > budget %zu", worst, kRiderVertexBudget);
    CHECK(worstLow <= kRemoteRiderVertexBudget, "low detail rider %zu > budget %zu", worstLow, kRemoteRiderVertexBudget);
    CHECK(worst + 5 * worstLow + 8000 <= kDynamicMeshVertexLimit, "the local rider + five remote riders + the world's own dynamic geometry must fit 16-bit indices");
}

static void testZones() {
    std::printf("gorge zones\n");
    int zones = 0;
    float minChord = 1e9f, maxChord = 0.0f, minDrop = 1e9f, maxDrop = 0.0f, minRadius = 1e9f, worstClosure = 0.0f, worstHeading = 0.0f, worstHeight = 0.0f;
    for (uint32_t seed = 1; seed <= 30; ++seed) {
        Track tr(seed * 7919u + 13u);
        tr.ensureGenerated(4600.0f);
        const auto& list = tr.shortcuts();
        for (size_t zi = 0; zi < list.size(); ++zi) {
            const ShortcutZone& z = list[zi];
            if (z.sGorge1 + 10.0f > tr.generatedLength()) continue;   // (the last one is only planned, not yet generated)
            ++zones;
            CHECK(z.sRamp0 < z.sLip && z.sBend0 < z.sLip && z.sLip < z.sBend1 && z.sBend1 < z.sLand && z.sLand < z.sGorge1 && z.sGorge0 < z.sRamp0 + 9.0f, "ordering seed %u", seed);
            CHECK(zi == 0 || list[zi - 1].sGorge1 + 300.0f < z.sRamp0, "zones are spaced");
            CHECK(z.side == 1.0f || z.side == -1.0f, "side");

            // the detour closes: the road is back on its original line, heading the same way, so the flight is a straight jump across the mouth
            const TrackSample a = tr.at(z.sLip - 8.0f), b = tr.at(z.sLand);
            const Vec3 d = b.pos - a.pos;
            const float along = d.x * a.fwd.x + d.z * a.fwd.z;
            const float across = std::fabs(d.x * a.right0.x + d.z * a.right0.z);
            float dh = std::fabs(b.heading - a.heading);
            worstClosure = std::max(worstClosure, across);
            worstHeading = std::max(worstHeading, dh);
            CHECK(across < 2.5f, "the exit is on the entry line, off by %.2f m (seed %u)", across, seed);
            CHECK(dh < 3.0f * kDeg2Rad, "the exit heads the way the entry did, off by %.1f deg", dh / kDeg2Rad);
            const float chord = tr.gapFrameOf(z).chordH;
            minChord = std::min(minChord, chord);
            maxChord = std::max(maxChord, chord);
            CHECK(along > 50.0f && along < 85.0f, "the jump is %.0f m across", along);
            CHECK(chord > 48.0f && chord < 85.0f, "the line from the lip to the road beyond is %.0f m", chord);
            // the road runs straight for a good way after the detour: that is where a fast jump comes down
            for (float s = z.sBend1; s <= z.sBend1 + cfg::kGorgeRunway; s += 2.0f) CHECK(std::fabs(tr.curvatureAt(s)) < 1e-5f, "the runway is straight at %.0f m after the detour (seed %u)", s - z.sBend1, seed);
            const float drop = z.roadYAt(z.sLip) - z.roadYAt(z.sLand);
            minDrop = std::min(minDrop, drop);
            maxDrop = std::max(maxDrop, drop);
            CHECK(drop > 2.5f && drop < 9.0f, "the road goes down %.1f m over the detour: the landing is a few metres below the lip, not a dive", drop);

            // the detour itself: sharp, but never absurdly so, and the gorge side is the downhill side all along
            float roadMin = 1e9f;
            bool downhill = true;
            for (float s = z.sBend0; s <= z.sBend1; s += 1.0f) {
                const float k = std::fabs(tr.curvatureAt(s));
                if (k > 1e-4f) roadMin = std::min(roadMin, 1.0f / k);
                if (tr.hillBias(s) * z.side > -0.06f) downhill = false;
            }
            minRadius = std::min(minRadius, roadMin);
            CHECK(roadMin > 10.5f && roadMin < 15.5f, "tightest radius %.1f m", roadMin);
            CHECK(downhill, "the gorge side is the downhill side (seed %u)", seed);

            // the ground: a flat floor well below the lowest road, on the gorge side only, and the flight stays well above it
            const float sMid = 0.5f * (z.sBend0 + z.sBend1);
            CHECK(tr.terrainHeight(z.sLip + 20.0f, z.side * 12.5f) < -4.0f, "gorge floor beside the first leg: %.1f", tr.terrainHeight(z.sLip + 20.0f, z.side * 12.5f));
            CHECK(tr.terrainHeight(sMid, z.side * 21.0f) < -3.5f, "gorge floor at the hairpin: %.1f", tr.terrainHeight(sMid, z.side * 21.0f));
            CHECK(tr.terrainHeight(z.sLip - 40.0f, z.side * 12.5f) > -12.0f, "no gorge before the kicker");
            CHECK(tr.terrainHeight(sMid, z.side * 5.0f) > -0.5f, "the shoulder is still there: %.2f", tr.terrainHeight(sMid, z.side * 5.0f));
            const Track::GapFrame fr = tr.gapFrameOf(z);
            const Vec3 land = Track::surfacePoint(tr.at(z.sLand), z.side * z.xsFlight, 0.0f);
            CHECK(length(fr.p1 - land) < 0.01f, "the line ends on the road beyond the detour");
            CHECK(fr.p0.y > fr.p1.y + 2.0f && fr.p0.y - fr.p1.y < 11.0f, "the lip is %.1f m above the far road", fr.p0.y - fr.p1.y);
            CHECK(z.floorY < z.roadYAt(z.sLand) - 2.0f, "the floor lies below the landing");
            CHECK(z.lipSlope() > 0.15f && z.lipSlope() < 0.40f, "the kicker's slope at the lip: %.2f", z.lipSlope());

            int kind = -1;
            const float sk = z.sRamp0 + 5.0f;
            CHECK(tr.supportHeight(sk, z.side * 3.4f, &kind) > 0.1f && kind == Track::kKicker, "kicker carries the rider");
            CHECK(tr.supportHeight(z.sLip + 3.0f, z.side * 3.4f, &kind) == 0.0f && kind == Track::kRoad, "road after the lip");
            tr.supportHeight(z.sLip + 3.0f, z.side * 12.0f, &kind);
            CHECK(kind == Track::kVoid, "nothing carries a rider off the road");
            CHECK(tr.railGap(z.sLip, z.side) && !tr.railGap(z.sLip, -z.side) && !tr.railGap(z.sRamp0 - 20.0f, z.side) && !tr.railGap(z.sLip + 12.0f, z.side), "rail gap at the kicker only");
            float lo, hi;
            tr.lateralWindow(z.sLip, Track::kKicker, &lo, &hi);
            CHECK((z.side > 0 ? hi : -lo) > 100.0f, "no rail beside the kicker");
            tr.lateralWindow(z.sLip + 20.0f, Track::kRoad, &lo, &hi);
            CHECK(hi - lo < 11.0f, "rails again after the kicker");
            CHECK(tr.gorgeSide(z.sLip + 20.0f) == static_cast<int>(z.side) && tr.gorgeSide(z.sRamp0 - 60.0f) == 0 && tr.gorgeSide(z.sGorge1 + 20.0f) == 0, "gorge side");
            CHECK(tr.shortcutBlocks(z.sLip - 3.0f, z.side * 6.0f, 4.0f) && !tr.shortcutBlocks(z.sLip - 3.0f, -z.side * 6.0f, 4.0f), "scenery keeps off the kicker, not the other side of the road");
        }
    }
    (void)worstHeight;
    std::printf("  %d zones over 30 seeds x 4.6 km; gap %.0f..%.0f m, descent %.1f..%.1f m, tightest radius %.1f m, worst closure %.2f m / %.2f deg\n",
                zones, minChord, maxChord, minDrop, maxDrop, minRadius, worstClosure, worstHeading / kDeg2Rad);
    CHECK(zones >= 30, "zones are common enough: %d", zones);
}

struct JumpResult { bool flew = false, crashed = false; float t = 0.0f, apex = 0.0f, above = 0.0f, flown = 0.0f, air = 0.0f; CrashCause cause = CrashCause::None; };

// Rides from 110 m before the kicker to 150 m past the landing line. With takeKicker the rider leaves the lip at exactly v0 (and lets go in the
// air); without it the rider rides the detour.
static JumpResult ride(const Track& tr, const ShortcutZone& z, float v0, bool takeKicker) {
    Skater sk;
    sk.reset(z.sRamp0 - 110.0f, v0);
    if (takeKicker) sk.x = 0.5f * (z.rampX0 + z.rampX1) * z.side;
    AutoPilot ap;
    std::vector<Obstacle> none;
    JumpResult r;
    const Track::GapFrame g = tr.gapFrameOf(z);
    const float dt = 1.0f / 120.0f;
    for (int i = 0; i < 120 * 90 && sk.s < z.sLand + 150.0f; ++i) {
        if (takeKicker && sk.s < z.sLip - 0.5f) { sk.speed = v0; ap.forcedX = 0.5f * (z.rampX0 + z.rampX1) * z.side; }   // the entry speed is the test's input
        else ap.forcedX = 1e9f;
        sk.step(ap.compute(tr, none, sk), tr, dt);
        r.t += dt;
        if (sk.gapFlight) {
            Vec3 p;
            tr.gapFlightAt(z, sk.gapU, sk.gapB, sk.gapRel, sk.gapH, 0.0f, &p, nullptr);
            float gs, gd, gy;
            if (tr.groundNear(z, p, &gs, &gd, &gy)) r.above = std::max(r.above, p.y - gy);
            r.apex = std::max(r.apex, sk.gapH);
            r.flown = std::max(r.flown, sk.gapU * g.chordH);
            r.air = sk.gapTime;
        }
        if (sk.gapJumps > 0) r.flew = true;
        if (sk.crashed) { r.crashed = true; r.cause = sk.crashCause; break; }
    }
    return r;
}

static void testJumps() {
    std::printf("gorge jumps\n");
    int total = 0, good = 0, compared = 0, hopsOk = 0, hops = 0, detoursOk = 0, detours = 0, shortOk = 0, shorts = 0;
    double saved = 0.0;
    // by entry speed: how high (apex above the lip), how far, how long, how high above the ground
    const float kSpeeds[] = {18.0f, 22.0f, 26.0f, 30.0f};
    double apex[4] = {0, 0, 0, 0}, flown[4] = {0, 0, 0, 0}, air[4] = {0, 0, 0, 0};
    float maxAbove = 0.0f, maxApex = 0.0f;
    int per[4] = {0, 0, 0, 0};
    for (uint32_t seed = 1; seed <= 12; ++seed) {
        Track tr(seed * 7919u + 13u);
        tr.ensureGenerated(4600.0f);
        for (const ShortcutZone& z : tr.shortcuts()) {
            if (z.sGorge1 + 10.0f > tr.generatedLength()) continue;   // (the last one is only planned, not yet generated)
            for (int k = 0; k < 4; ++k) {
                const float v = kSpeeds[k];
                const JumpResult a = ride(tr, z, v, true), b = ride(tr, z, v, false);
                ++total;
                if (a.flew && !a.crashed) {
                    ++good;
                    apex[k] += a.apex; flown[k] += a.flown; air[k] += a.air; ++per[k];
                    maxAbove = std::max(maxAbove, a.above);
                    maxApex = std::max(maxApex, a.apex);
                    if (!b.crashed) { saved += b.t - a.t; ++compared; }
                }
                ++detours;
                if (!b.crashed) ++detoursOk;
            }
            // too slow for the gorge: the rider falls short of the road beyond it (the gorge, or the slope on the far side)
            for (float v : {9.0f, 11.0f, 13.0f}) {
                ++shorts;
                const JumpResult h = ride(tr, z, v, true);
                if (!h.flew && h.crashed && h.cause == CrashCause::Fall) ++shortOk;
            }
            // creeping over the lip is only a hop: the rider stays on the road
            ++hops;
            const JumpResult h = ride(tr, z, 5.0f, true);
            if (!h.flew && !h.crashed) ++hopsOk;
        }
    }
    const double rate = total ? static_cast<double>(good) / total : 0.0;
    const double mean = compared ? saved / compared : 0.0;
    std::printf("  %d/%d jumps flew over the gorge and rode on; the jump saves %.1f s on average over the detour; %d/%d detour rides came through\n", good, total, mean, detoursOk, detours);
    std::printf("  slow riders: %d/%d fell short of the far road, %d/%d creeping riders only hopped\n", shortOk, shorts, hopsOk, hops);
    for (int k = 0; k < 4; ++k) {
        const double n = per[k] ? per[k] : 1;
        std::printf("  at %2.0f m/s (%3.0f km/h): apex %.1f m above the lip, flew %3.0f m in %.1f s\n", kSpeeds[k], kSpeeds[k] * 3.6f, apex[k] / n, flown[k] / n, air[k] / n);
    }
    std::printf("  highest: %.1f m above the lip, %.1f m above the ground\n", maxApex, maxAbove);
    CHECK(total >= 100, "enough jumps tested: %d", total);
    CHECK(rate >= 0.97, "jump rate %.3f", rate);
    CHECK(mean > 4.0, "the jump must be a real shortcut: %.2f s", mean);
    CHECK(detoursOk >= detours * 0.9, "the autopilot comes through the detour: %d/%d", detoursOk, detours);
    CHECK(shortOk == shorts, "slow riders fall short: %d/%d", shortOk, shorts);
    CHECK(hopsOk == hops, "creeping riders only hop: %d/%d", hopsOk, hops);
    // faster means higher and further
    CHECK(apex[2] / per[2] > apex[0] / per[0] + 1.5, "faster jumps higher: %.1f m at 26 m/s vs %.1f at 18", apex[2] / per[2], apex[0] / per[0]);
    CHECK(apex[1] / per[1] > apex[0] / per[0] + 0.5, "...steadily: %.1f m at 22 m/s", apex[1] / per[1]);
    CHECK(flown[3] / per[3] > flown[0] / per[0] + 40.0, "faster jumps further: %.0f m at 30 m/s vs %.0f at 18", flown[3] / per[3], flown[0] / per[0]);
    // ... but it stays a ramp jump
    CHECK(apex[0] / per[0] < 3.2, "a jump that just clears the gorge is a modest one: %.1f m", apex[0] / per[0]);
    CHECK(maxApex < 6.0f, "the highest jump rises %.1f m above the lip", maxApex);
    CHECK(maxAbove < 18.0f, "the highest the rider gets above the ground: %.1f m", maxAbove);
}

// ---- steering over the gorge: where the rider comes down is the rider's call
struct FlightResult { bool landed = false, crashed = false; float xLand = 0.0f, t = 0.0f; };

// Leaves the lip at v0 from the middle of the kicker and steers with steerFn(time in the air) / tuck / slide until the landing.
template <class F>
static FlightResult fly(const Track& tr, const ShortcutZone& z, float v0, F steerFn, bool tuck = false, bool slide = false) {
    Skater sk;
    sk.reset(z.sRamp0 - 110.0f, v0);
    sk.x = 0.5f * (z.rampX0 + z.rampX1) * z.side;
    AutoPilot ap;
    std::vector<Obstacle> none;
    FlightResult r;
    const float dt = 1.0f / 120.0f;
    for (int i = 0; i < 120 * 90 && sk.s < z.sLand + 150.0f; ++i) {
        SkaterInput in;
        if (sk.gapFlight) {
            in.steer = steerFn(sk.gapTime);
            in.tuck = tuck;
            in.slide = slide;
        } else {
            if (sk.s < z.sLip - 0.5f) { sk.speed = v0; ap.forcedX = 0.5f * (z.rampX0 + z.rampX1) * z.side; }
            else ap.forcedX = 1e9f;
            in = ap.compute(tr, none, sk);
        }
        const int jumps = sk.gapJumps;
        sk.step(in, tr, dt);
        if (sk.gapJumps > jumps) { r.landed = true; r.xLand = sk.x; r.t = sk.gapTime; }
        if (sk.crashed) { r.crashed = true; break; }
        if (r.landed) break;
    }
    return r;
}

static void testSteeredFlight() {
    std::printf("steering over the gorge\n");
    int n = 0, letGoLands = 0, centred = 0, rightMoves = 0, leftMoves = 0, nudgeLands = 0, hardMisses = 0, tuckFaster = 0;
    int shortN = 0, shortFalls = 0, slideSaves = 0, tuckFalls = 0;
    float worstCentre = 0.0f;
    for (uint32_t seed = 1; seed <= 8; ++seed) {
        Track tr(seed * 7919u + 13u);
        tr.ensureGenerated(4600.0f);
        for (const ShortcutZone& z : tr.shortcuts()) {
            if (z.sGorge1 + 10.0f > tr.generatedLength()) continue;
            for (float v : {22.0f, 26.0f, 30.0f}) {
                ++n;
                const FlightResult let = fly(tr, z, v, [](float) { return 0.0f; });
                if (let.landed && !let.crashed) {
                    ++letGoLands;
                    const float off = std::fabs(let.xLand - z.side * z.xsFlight);
                    worstCentre = std::max(worstCentre, off);
                    if (off < 1.6f) ++centred;
                }
                // a short nudge to the right / to the left: it lands that much further over (in road-right terms) and still lands
                const FlightResult r = fly(tr, z, v, [](float t) { return t < 0.4f ? 0.5f : 0.0f; });
                const FlightResult l = fly(tr, z, v, [](float t) { return t < 0.4f ? -0.5f : 0.0f; });
                if (r.landed && !r.crashed && let.landed && r.xLand > let.xLand + 1.0f) ++rightMoves;
                if (l.landed && !l.crashed && let.landed && l.xLand < let.xLand - 1.0f) ++leftMoves;
                if (r.landed && l.landed) ++nudgeLands;
                // full lock for the whole flight sails off the road: freedom has a price
                const FlightResult hard = fly(tr, z, v, [](float) { return 1.0f; });
                if (hard.crashed && !hard.landed) ++hardMisses;
                // TUCK dives the flight (it is over sooner), SLIDE floats it, and both still land at this speed
                const FlightResult tk = fly(tr, z, v, [](float) { return 0.0f; }, true, false), sl = fly(tr, z, v, [](float) { return 0.0f; }, false, true);
                if (tk.landed && sl.landed && tk.t < sl.t - 0.1f) ++tuckFaster;
            }
            // a jump that is a little short: letting go falls into the gorge, floating it (SLIDE) saves it; and a dive (TUCK) at a speed
            // that only just clears it falls short
            ++shortN;
            const FlightResult shortLet = fly(tr, z, 14.0f, [](float) { return 0.0f; }), shortSlide = fly(tr, z, 14.0f, [](float) { return 0.0f; }, false, true);
            if (!shortLet.landed && shortLet.crashed) ++shortFalls;
            if (shortSlide.landed && !shortSlide.crashed) ++slideSaves;
            const FlightResult dive = fly(tr, z, 18.0f, [](float) { return 0.0f; }, true, false);
            if (!dive.landed && dive.crashed) ++tuckFalls;
        }
    }
    std::printf("  %d flights: %d landed when the rider let go (worst %.2f m off the line); %d/%d nudges right and %d/%d left moved the landing; %d/%d full-lock flights missed; %d/%d tuck faster than slide\n",
                n, letGoLands, worstCentre, rightMoves, n, leftMoves, n, hardMisses, n, tuckFaster, n);
    std::printf("  a little short (50 km/h): %d/%d fell in when letting go, %d/%d made it floating with SLIDE; %d/%d dived short with TUCK at 65 km/h\n", shortFalls, shortN, slideSaves, shortN, tuckFalls, shortN);
    CHECK(n >= 60, "enough flights tested: %d", n);
    CHECK(letGoLands >= n * 0.97, "letting go lands: %d/%d", letGoLands, n);
    CHECK(centred >= letGoLands * 0.97, "letting go lands near the line: %d/%d", centred, letGoLands);
    CHECK(rightMoves >= n * 0.95 && leftMoves >= n * 0.95, "steering moves the landing: right %d left %d of %d", rightMoves, leftMoves, n);
    CHECK(nudgeLands >= n * 0.95, "small corrections still land: %d/%d", nudgeLands, n);
    CHECK(hardMisses >= n * 0.95, "holding full lock misses the road: %d/%d", hardMisses, n);
    CHECK(tuckFaster >= n * 0.95, "tuck flies the arc faster than slide: %d/%d", tuckFaster, n);
    CHECK(shortFalls >= shortN * 0.95, "a slow jump falls short when the rider lets go: %d/%d", shortFalls, shortN);
    CHECK(slideSaves >= shortN * 0.6, "floating (SLIDE) saves a jump that is a little short: %d/%d", slideSaves, shortN);
    CHECK(tuckFalls >= shortN * 0.8, "diving (TUCK) at a speed that only just clears the gorge falls short: %d/%d", tuckFalls, shortN);
}

// ---- what the other phones see of a jump: the flight travels as (metres from the lip, offset, heading, 100 + height) and is rebuilt from that
static void testFlightOverTheNetwork() {
    std::printf("a jump seen from another phone\n");
    int samples = 0, closeEnough = 0, slopeOk = 0, slopeChecked = 0;
    float worstPos = 0.0f, worstSlope = 0.0f;
    for (uint32_t seed = 1; seed <= 6; ++seed) {
        Track tr(seed * 7919u + 13u);
        tr.ensureGenerated(4600.0f);
        for (const ShortcutZone& z : tr.shortcuts()) {
            if (z.sGorge1 + 10.0f > tr.generatedLength()) continue;
            for (float v : {20.0f, 28.0f}) {
                Skater sk;
                sk.reset(z.sRamp0 - 110.0f, v);
                sk.x = 0.5f * (z.rampX0 + z.rampX1) * z.side;
                AutoPilot ap;
                std::vector<Obstacle> none;
                const float dt = 1.0f / 120.0f;
                int tick = 0;
                for (int i = 0; i < 120 * 60 && sk.s < z.sLand + 150.0f && !sk.crashed; ++i) {
                    SkaterInput in;
                    if (!sk.gapFlight) {
                        if (sk.s < z.sLip - 0.5f) { sk.speed = v; ap.forcedX = 0.5f * (z.rampX0 + z.rampX1) * z.side; } else ap.forcedX = 1e9f;
                        in = ap.compute(tr, none, sk);
                    }
                    sk.step(in, tr, dt);
                    if (!sk.gapFlight || ++tick % 30 != 0) continue;
                    RiderNet r;   // what Game::riderNet puts on the wire
                    r.s = sk.s; r.x = sk.x; r.alpha = sk.alpha; r.speed = sk.speed;
                    r.yRel = 100.0f + sk.gapH;
                    const SkaterPose pose = poseFromRiderNet(tr, r, Vec3(0, 0, 0), 0.0f);
                    Vec3 truth, dir;
                    tr.gapFlightAt(z, sk.gapU, sk.gapB, sk.gapRel, sk.gapH, sk.gapSlope(), &truth, &dir);
                    ++samples;
                    const float err = length(pose.origin - truth);
                    worstPos = std::max(worstPos, err);
                    if (err < 0.05f) ++closeEnough;
                    // the nose: the pitch is worked out from the height reached, so it follows the real arc (unless the board is levelling for the touchdown)
                    float gs, gd, gy;
                    if (tr.groundNear(z, truth, &gs, &gd, &gy) && truth.y - gy > 4.0f) {
                        ++slopeChecked;
                        const float want = std::asin(clampf(dir.y, -1.0f, 1.0f)), got = std::asin(clampf(pose.fwd.y, -1.0f, 1.0f));
                        worstSlope = std::max(worstSlope, std::fabs(want - got));
                        if (std::fabs(want - got) < 0.15f) ++slopeOk;
                    }
                }
            }
        }
    }
    std::printf("  %d snapshots of flights: %d rebuilt to within 5 cm (worst %.3f m); nose pitch within 0.15 rad for %d/%d (worst %.2f rad)\n", samples, closeEnough, worstPos, slopeOk, slopeChecked, worstSlope);
    CHECK(samples > 100, "enough snapshots: %d", samples);
    CHECK(closeEnough == samples, "the rider is drawn where it is: %d/%d (worst %.3f m)", closeEnough, samples, worstPos);
    CHECK(slopeOk >= slopeChecked * 0.95, "the nose follows the arc: %d/%d", slopeOk, slopeChecked);
}

static void testFinishLine() {
    std::printf("finish line and simultaneous start\n");
    int finished = 0;
    for (uint32_t seed = 1; seed <= 4; ++seed) {
        Game g;
        g.startRunSeeded(seed, 0.0f, 400.0f);
        g.autopilot() = AutoPilot();
        const float dt = 1.0f / 60.0f;
        float t = 0.0f;
        bool wasFinished = false;
        while (t < 120.0f && g.phase() != Phase::GameOver) {
            SkaterInput in;
            if (g.phase() == Phase::Running) in = g.autopilot().compute(g.world().track(), g.world().obstacles(), g.skater());
            g.update(dt, in);
            if (g.finished()) wasFinished = true;
            t += dt;
        }
        if (wasFinished) {
            ++finished;
            CHECK(g.goalMeters() == 400.0f && g.finishTime() > 12.0f && g.finishTime() < 90.0f, "finish time %.1f", g.finishTime());
            CHECK(g.riderNet().finished && std::fabs(g.riderNet().finishTime - g.finishTime()) < 1e-3f, "the finish travels with the rider's network state");
            CHECK(g.phase() == Phase::GameOver && !g.skater().crashed, "the standings come up after the finish");
        }
    }
    CHECK(finished >= 3, "%d of 4 autopilot runs reached a 400 m finish line", finished);

    // A START that arrives 1.2 s late: that phone's countdown is fast-forwarded and its GO is simultaneous with the host's
    Game host, late;
    host.startRunSeeded(5, 0.0f, 1000.0f);
    late.startRunSeeded(5, 1.2f, 1000.0f);
    const float dt = 1.0f / 60.0f;
    int goHost = -1, goLate = -1;
    for (int i = 0; i < 60 * 6; ++i) {
        host.update(dt, SkaterInput());
        late.update(dt, SkaterInput());
        if (goHost < 0 && host.phase() == Phase::Running) goHost = i;
        if (goLate < 0 && late.phase() == Phase::Running) goLate = i;
    }
    CHECK(goHost > 0 && goLate > 0, "both reach GO");
    CHECK(std::fabs(static_cast<float>(goHost - goLate) * dt - 1.2f) < 0.05f, "GO of the late phone is 1.2 s earlier than a phone that started on time: %d vs %d frames", goLate, goHost);
    Game absurd;
    absurd.startRunSeeded(5, 500.0f, 0.0f);   // a lag outside any sane range is clamped
    absurd.update(dt, SkaterInput());
    CHECK(absurd.phase() == Phase::Countdown || absurd.phase() == Phase::Running, "absurd lag is harmless");
}

int main() {
    testMeshBudget();
    testZones();
    testJumps();
    testSteeredFlight();
    testFlightOverTheNetwork();
    testFinishLine();
    std::printf("\n%d checks, %d failed\n", g_checks, g_fails);
    return g_fails == 0 ? 0 : 1;
}
