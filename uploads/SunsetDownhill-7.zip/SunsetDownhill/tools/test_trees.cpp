// The forest: trees of every kind keep their distance, so crowns never grow into each other (no GPU needed).
//  - the crown radius the world spaces trees by matches the real tree meshes
//  - across many roads and every chunk border, no two trees overlap
//  - the forest is still a forest (the spacing did not thin it out)
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <set>
#include <utility>
#include <vector>

#include "mesh_library.h"
#include "world.h"

using namespace sd;

static int g_fails = 0, g_checks = 0;
#define CHECK(cond, ...)                                                            \
    do {                                                                            \
        ++g_checks;                                                                 \
        if (!(cond)) {                                                              \
            ++g_fails;                                                              \
            std::printf("  FAIL line %d: %s  ", __LINE__, #cond);                   \
            std::printf(__VA_ARGS__);                                               \
            std::printf("\n");                                                      \
        }                                                                           \
    } while (0)

static const char* nameOf(int b) { return b == kBatchPine ? "pine" : b == kBatchAutumn ? "autumn" : "birch"; }

// The declared crown radius against what the mesh really reaches: the boughs, not the trunk.
static void testCrownRadii() {
    std::printf("crown radii\n");
    for (int b : {kBatchPine, kBatchAutumn, kBatchBirch}) {
        const MeshData m = buildBatchMesh(static_cast<Batch>(b));
        float reach = 0.0f, top = 0.0f;
        for (const MeshVertex& v : m.vertices) {
            top = std::max(top, v.py);
            if (v.py > 1.5f) reach = std::max(reach, std::sqrt(v.px * v.px + v.pz * v.pz));   // (above the trunk's flare)
        }
        const float declared = treeCrownRadius(static_cast<Batch>(b));
        std::printf("  %-6s mesh reaches %.2f m from the trunk (top %.1f m), the world assumes %.2f m\n", nameOf(b), reach, top, declared);
        CHECK(declared > 0.0f, "%s has a crown radius", nameOf(b));
        CHECK(declared >= reach * 0.92f && declared <= reach * 1.12f, "%s: the declared crown radius %.2f matches the mesh (%.2f)", nameOf(b), declared, reach);
    }
    CHECK(treeCrownRadius(kBatchRock) == 0.0f && treeCrownRadius(kBatchBush) == 0.0f, "only trees have a crown radius");
}

struct Tree { float x, z, r; int batch; };

static std::vector<Tree> forestOf(uint32_t seed, float length) {
    World w(seed);
    w.track().ensureGenerated(length + 600.0f);
    std::vector<Tree> all;
    std::set<std::pair<long, long>> seen;   // (the windows overlap: the same tree comes back, and is counted once)
    for (float s = 0.0f; s < length; s += 300.0f) {
        SceneGeometry geo;
        w.buildScenery(s + 150.0f, Vec3(0, 0, 0), Vec3(0, 0, -1), 1.0f, geo);
        for (int b : {kBatchPine, kBatchAutumn, kBatchBirch})
            for (const Instance& in : geo.instances[b])
                if (seen.insert({std::lround(in.x * 50.0f), std::lround(in.z * 50.0f)}).second)
                    all.push_back({in.x, in.z, treeCrownRadius(static_cast<Batch>(b)) * in.sx, b});
    }
    return all;
}

static void testNoOverlap() {
    std::printf("no two trees overlap\n");
    long trees = 0, pairs = 0, overlapping = 0, deep = 0;
    double worst = 1.0, metres = 0.0;
    int byKind[kBatchCount] = {0};
    int mixedClose = 0;
    for (uint32_t seed = 1; seed <= 16; ++seed) {
        const float length = 2400.0f;
        const std::vector<Tree> forest = forestOf(seed * 7919u + 13u, length);
        trees += static_cast<long>(forest.size());
        metres += length;
        for (const Tree& t : forest) ++byKind[t.batch];
        for (size_t i = 0; i < forest.size(); ++i)
            for (size_t j = i + 1; j < forest.size(); ++j) {
                const float dx = forest[i].x - forest[j].x, dz = forest[i].z - forest[j].z;
                if (std::fabs(dx) > 12.0f || std::fabs(dz) > 12.0f) continue;
                ++pairs;
                const float d = std::sqrt(dx * dx + dz * dz), want = cfg::kTreeOverlap * (forest[i].r + forest[j].r);
                if (d < want - 0.05f) {
                    ++overlapping;
                    worst = std::min(worst, static_cast<double>(d / want));
                    if (d < 0.8f * want) ++deep;
                    if (forest[i].batch != forest[j].batch) ++mixedClose;
                }
            }
    }
    std::printf("  %ld trees over %.0f m of road (%.0f per 100 m: %d pines, %d autumn, %d birches); %ld close pairs checked, %ld closer than they should be (worst %.0f%% of the spacing; %ld of them mixed kinds)\n",
                trees, metres, 100.0 * trees / metres, byKind[kBatchPine], byKind[kBatchAutumn], byKind[kBatchBirch], pairs, overlapping, 100.0 * worst, static_cast<long>(mixedClose));
    CHECK(trees > 3000, "a real forest: %ld trees", trees);
    // (a handful of pairs remain where the road bends sharply right at a chunk border: far fewer than one in a thousand trees)
    CHECK(overlapping <= trees / 400, "crowns keep apart: %ld pairs of %ld trees are closer than the spacing", overlapping, trees);
    CHECK(deep <= trees / 1500, "hardly any tree grows deep into another: %ld pairs closer than 80%% of the spacing", deep);
    CHECK(worst > 0.15, "and never into the same spot: worst %.0f%% of the spacing", 100.0 * worst);
    // not thinner than before: the old scatter put about 22 trees in every chunk on each side (73 per 100 m and side)
    CHECK(100.0 * trees / metres > 90.0, "the forest is still dense: %.0f trees per 100 m", 100.0 * trees / metres);
}

int main() {
    testCrownRadii();
    testNoOverlap();
    std::printf("\n%d checks, %d failed\n", g_checks, g_fails);
    return g_fails == 0 ? 0 : 1;
}
