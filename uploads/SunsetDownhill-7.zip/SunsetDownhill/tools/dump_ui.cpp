// dump_ui: renders the HUD, the control schemes and the CONTROLS screen to PPM images with a tiny software
// rasteriser, so the UI can be reviewed without a phone or a GPU. The background is just a sunset gradient.
//   ./dump_ui <out_dir>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <functional>
#include <string>
#include <vector>

#include "controls.h"
#include "hud.h"
#include "ui_batch.h"
#include "ui_font.h"
#include "ui_widgets.h"

using namespace sd;

namespace {

struct Image {
    int w, h;
    std::vector<float> rgb;   // 0..255
    Image(int w_, int h_) : w(w_), h(h_), rgb(static_cast<size_t>(w_) * h_ * 3) {
        for (int y = 0; y < h; ++y) {
            const float t = static_cast<float>(y) / static_cast<float>(h);
            float r, g, b;
            if (t < 0.55f) { const float k = t / 0.55f; r = 40 + 215 * k; g = 20 + 110 * k; b = 90 - 10 * k; }   // sky: purple -> orange
            else { const float k = (t - 0.55f) / 0.45f; r = 70 - 40 * k; g = 40 - 25 * k; b = 60 - 30 * k; }     // road
            for (int x = 0; x < w; ++x) { float* p = &rgb[(static_cast<size_t>(y) * w + x) * 3]; p[0] = r; p[1] = g; p[2] = b; }
        }
    }
};

// Bilinear sample of the UI atlas (clamp to edge, texel centres at (i + 0.5) / size) - what the GPU does for the UI shader.
float sampleAtlas(float u, float v) {
    static const std::vector<uint8_t>& px = fontAtlasPixels();
    const float fx = u * kAtlasSize - 0.5f, fy = v * kAtlasSize - 0.5f;
    const int x0 = static_cast<int>(std::floor(fx)), y0 = static_cast<int>(std::floor(fy));
    const float tx = fx - static_cast<float>(x0), ty = fy - static_cast<float>(y0);
    auto at = [&](int x, int y) {
        x = std::max(0, std::min(kAtlasSize - 1, x));
        y = std::max(0, std::min(kAtlasSize - 1, y));
        return static_cast<float>(px[static_cast<size_t>(y) * kAtlasSize + x]) / 255.0f;
    };
    const float top = at(x0, y0) * (1 - tx) + at(x0 + 1, y0) * tx;
    const float bot = at(x0, y0 + 1) * (1 - tx) + at(x0 + 1, y0 + 1) * tx;
    return top * (1 - ty) + bot * ty;
}

float smoothstepf(float e0, float e1, float x) {
    const float t = std::min(1.0f, std::max(0.0f, (x - e0) / (e1 - e0)));
    return t * t * (3.0f - 2.0f * t);
}

// Alpha-blended triangle fill with 2x2 supersampling. The fragment maths mirror the UI shader: plain shapes sample the solid block
// of the atlas, glyphs their signed-distance cell (fill + soft dark halo composited with "over").
void fillTriangle(Image& img, const UiVertex& a, const UiVertex& b, const UiVertex& c) {
    const float minX = std::floor(std::min({a.x, b.x, c.x})), maxX = std::ceil(std::max({a.x, b.x, c.x}));
    const float minY = std::floor(std::min({a.y, b.y, c.y})), maxY = std::ceil(std::max({a.y, b.y, c.y}));
    const float det = (b.y - c.y) * (a.x - c.x) + (c.x - b.x) * (a.y - c.y);
    if (std::fabs(det) < 1e-9f) return;
    // screen-space gradient of the texture coordinates (the GPU gets this from derivatives)
    const float l1x = (b.y - c.y) / det, l2x = (c.y - a.y) / det, l3x = -(l1x + l2x);
    const float l1y = (c.x - b.x) / det, l2y = (a.x - c.x) / det, l3y = -(l1y + l2y);
    const float dudx = a.u * l1x + b.u * l2x + c.u * l3x, dvdx = a.v * l1x + b.v * l2x + c.v * l3x;
    const float dudy = a.u * l1y + b.u * l2y + c.u * l3y, dvdy = a.v * l1y + b.v * l2y + c.v * l3y;
    for (int y = std::max(0, static_cast<int>(minY)); y < std::min(img.h, static_cast<int>(maxY) + 1); ++y) {
        for (int x = std::max(0, static_cast<int>(minX)); x < std::min(img.w, static_cast<int>(maxX) + 1); ++x) {
            float accA = 0, accR = 0, accG = 0, accB = 0;
            for (int sy = 0; sy < 2; ++sy) {
                for (int sx = 0; sx < 2; ++sx) {
                    const float px = x + 0.25f + 0.5f * sx, py = y + 0.25f + 0.5f * sy;
                    const float l1 = ((b.y - c.y) * (px - c.x) + (c.x - b.x) * (py - c.y)) / det;
                    const float l2 = ((c.y - a.y) * (px - c.x) + (a.x - c.x) * (py - c.y)) / det;
                    const float l3 = 1.0f - l1 - l2;
                    if (l1 < 0 || l2 <= 0 || l3 < 0) continue;   // (the shared diagonal of a quad belongs to exactly one of its triangles)
                    const float u = l1 * a.u + l2 * b.u + l3 * c.u, v = l1 * a.v + l2 * b.v + l3 * c.v;
                    const float d = sampleAtlas(u, v);
                    const float fw = std::fabs(sampleAtlas(u + dudx, v + dvdx) - d) + std::fabs(sampleAtlas(u + dudy, v + dvdy) - d);
                    const float w = std::max(fw * 0.75f, 0.0005f);
                    const float fill = smoothstepf(0.5f - w, 0.5f + w, d);
                    const float hv = (l1 * a.halo + l2 * b.halo + l3 * c.halo) / 255.0f;
                    const float halo = hv * 0.62f * smoothstepf(0.26f, 0.5f, d) * (1.0f - fill);
                    const float al = (l1 * a.a + l2 * b.a + l3 * c.a) / 255.0f;
                    const float aFill = al * fill, aHalo = al * halo;
                    const float A = aFill + aHalo * (1.0f - aFill);
                    const float k = 1.0f / std::max(A, 1e-4f);
                    const float cr = (l1 * a.r + l2 * b.r + l3 * c.r), cg = (l1 * a.g + l2 * b.g + l3 * c.g), cb = (l1 * a.b + l2 * b.b + l3 * c.b);
                    const float rr = (cr * aFill + 24.0f * aHalo * (1.0f - aFill)) * k;
                    const float gg = (cg * aFill + 8.0f * aHalo * (1.0f - aFill)) * k;
                    const float bb = (cb * aFill + 36.0f * aHalo * (1.0f - aFill)) * k;
                    accA += 0.25f * A;
                    accR += 0.25f * A * rr;
                    accG += 0.25f * A * gg;
                    accB += 0.25f * A * bb;
                }
            }
            if (accA <= 0) continue;
            float* p = &img.rgb[(static_cast<size_t>(y) * img.w + x) * 3];
            p[0] = p[0] * (1 - accA) + accR;
            p[1] = p[1] * (1 - accA) + accG;
            p[2] = p[2] * (1 - accA) + accB;
        }
    }
}

void savePPM(const Image& img, const std::string& path) {
    FILE* f = std::fopen(path.c_str(), "wb");
    if (!f) { std::perror(path.c_str()); std::exit(1); }
    std::fprintf(f, "P6\n%d %d\n255\n", img.w, img.h);
    for (float v : img.rgb) std::fputc(static_cast<int>(std::lround(std::min(255.0f, std::max(0.0f, v)))), f);
    std::fclose(f);
}

void render(const std::string& dir, const std::string& name, int w, int h, const std::function<void(UiBatch&, Controls&)>& draw,
            const std::function<void(Controls&)>& setup) {
    Controls c;
    c.setScreen(static_cast<float>(w), static_cast<float>(h));
    c.setTiltAvailable(true);
    setup(c);
    UiBatch ui;
    ui.setScreen(static_cast<float>(w), static_cast<float>(h));
    draw(ui, c);
    Image img(w, h);
    for (size_t i = 0; i + 2 < ui.vertexCount(); i += 3) fillTriangle(img, ui.data()[i], ui.data()[i + 1], ui.data()[i + 2]);
    savePPM(img, dir + "/" + name + ".ppm");
    std::printf("wrote %s (%dx%d, %zu vertices)\n", name.c_str(), w, h, ui.vertexCount());
}

HudModel model(const Controls& c, Phase phase) {
    HudModel m;
    m.phase = phase;
    m.phaseTime = 2.0f;
    m.time = 1.3f;
    m.speedKmh = 87;
    m.distanceM = 1840;
    m.score = 5320;
    m.best = 9800;
    m.topSpeedKmh = 96;
    m.nearMisses = 7;
    m.countdown = 2;
    m.countdownProgress = 0.4f;
    m.mode = c.mode();
    m.opacity = c.opacity();
    m.tilt = c.tiltSteer();
    return m;
}

ControlsConfig mode(SteerMode m) {
    ControlsConfig cfg;
    cfg.mode = m;
    return cfg;
}

void press(Controls& c, Vec2 p) { c.onTouch(kTouchDown, 1, p.x, p.y); c.onTouch(kTouchUp, 1, p.x, p.y); }
Vec2 widget(const Controls& c, ControlsEditor::Widget w) {
    Rect r;
    ControlsEditor::widgetRect(w, c.layout(), c.mode(), &r);
    return {r.x + r.w * 0.5f, r.y + r.h * 0.5f};
}

}  // namespace

int main(int argc, char** argv) {
    const std::string dir = argc > 1 ? argv[1] : ".";
    const int W = 1920, H = 1080;
    using W_ = ControlsEditor::Widget;

    // ---- in the game
    render(dir, "menu_stick", W, H, [](UiBatch& ui, Controls& c) { drawHud(ui, c.layout(), model(c, Phase::Menu)); }, [](Controls&) {});
    render(dir, "running_stick", W, H, [](UiBatch& ui, Controls& c) {
        HudModel m = model(c, Phase::Running);
        m.steerActive = true; m.stickOrigin = {330, 700}; m.stickKnob = {420, 700}; m.tuckDown = true;
        drawHud(ui, c.layout(), m);
    }, [](Controls&) {});
    // the road is climbing and the board is dying: PUSH blinks and says why (running_push_hint), then the thumb is on it (running_push_down)
    render(dir, "running_push_hint", W, H, [](UiBatch& ui, Controls& c) {
        HudModel m = model(c, Phase::Running);
        m.steerActive = true; m.stickOrigin = {330, 700}; m.stickKnob = {380, 700}; m.pushHint = 1.0f; m.pulse = 0.2f; m.speedKmh = 21.0f;
        drawHud(ui, c.layout(), m);
    }, [](Controls&) {});
    render(dir, "running_push_down", W, H, [](UiBatch& ui, Controls& c) {
        HudModel m = model(c, Phase::Running);
        m.pushDown = true; m.pushHint = 1.0f; m.speedKmh = 24.0f;
        drawHud(ui, c.layout(), m);
    }, [](Controls&) {});
    render(dir, "running_arrows", W, H, [](UiBatch& ui, Controls& c) {
        HudModel m = model(c, Phase::Running);
        m.rightDown = true;
        drawHud(ui, c.layout(), m);
    }, [](Controls& c) { c.setConfig(mode(SteerMode::Arrows)); });
    render(dir, "running_tilt", W, H, [](UiBatch& ui, Controls& c) {
        HudModel m = model(c, Phase::Running);
        m.tilt = 0.55f; m.slideDown = true;
        drawHud(ui, c.layout(), m);
    }, [](Controls& c) { c.setConfig(mode(SteerMode::Tilt)); });
    render(dir, "running_both_faded", W, H, [](UiBatch& ui, Controls& c) {
        HudModel m = model(c, Phase::Running);
        m.tilt = -0.35f; m.leftDown = true;
        drawHud(ui, c.layout(), m);
    }, [](Controls& c) { ControlsConfig cfg = mode(SteerMode::ArrowsTilt); cfg.opacity = 0.5f; c.setConfig(cfg); });
    render(dir, "paused", W, H, [](UiBatch& ui, Controls& c) { drawHud(ui, c.layout(), model(c, Phase::Paused)); }, [](Controls&) {});
    render(dir, "menu_tilt", W, H, [](UiBatch& ui, Controls& c) { drawHud(ui, c.layout(), model(c, Phase::Menu)); }, [](Controls& c) { c.setConfig(mode(SteerMode::ArrowsTilt)); });

    // ---- LAN multiplayer screens
    auto names = [](MpRow& r, const char* n, int style, int score = 0, float dist = 0) {
        std::snprintf(r.name, sizeof(r.name), "%s", n);
        r.style = style; r.score = score; r.distanceM = dist;
    };
    render(dir, "mp_choose", W, H, [](UiBatch& ui, Controls& c) {
        HudModel m = model(c, Phase::Menu);
        m.mp.screen = MpModel::Screen::Choose;
        std::snprintf(m.mp.address, sizeof(m.mp.address), "192.168.1.23");
        drawHud(ui, c.layout(), m);
    }, [](Controls&) {});
    render(dir, "mp_search", W, H, [&names](UiBatch& ui, Controls& c) {
        HudModel m = model(c, Phase::Menu);
        m.mp.screen = MpModel::Screen::Search;
        m.mp.rowCount = 2;
        names(m.mp.rows[0], "INFINIX HOT 11", 0); m.mp.rows[0].players = 2;
        names(m.mp.rows[1], "GALAXY A52", 0); m.mp.rows[1].players = 4; m.mp.rows[1].racing = true;
        drawHud(ui, c.layout(), m);
    }, [](Controls&) {});
    render(dir, "mp_room_host", W, H, [&names](UiBatch& ui, Controls& c) {
        HudModel m = model(c, Phase::Menu);
        m.mp.screen = MpModel::Screen::Room;
        m.mp.isHost = true; m.mp.canStart = true; m.mp.rowCount = kMpRows;
        names(m.mp.rows[0], "INFINIX HOT 11", 0); m.mp.rows[0].self = true; m.mp.rows[0].host = true;
        names(m.mp.rows[1], "PIXEL 7 PRO", 1);
        names(m.mp.rows[2], "GALAXY A52", 2);
        drawHud(ui, c.layout(), m);
    }, [](Controls&) {});
    render(dir, "mp_room_client", W, H, [&names](UiBatch& ui, Controls& c) {
        HudModel m = model(c, Phase::Menu);
        m.mp.screen = MpModel::Screen::Room;
        m.mp.rowCount = kMpRows;
        names(m.mp.rows[0], "INFINIX HOT 11", 0); m.mp.rows[0].host = true;
        names(m.mp.rows[1], "PIXEL 7 PRO", 1); m.mp.rows[1].self = true;
        std::snprintf(m.mp.status, sizeof(m.mp.status), "THE HOST LEFT");
        drawHud(ui, c.layout(), m);
    }, [](Controls&) {});
    render(dir, "mp_race", W, H, [&names](UiBatch& ui, Controls& c) {
        HudModel m = model(c, Phase::Running);
        m.mp.racing = true; m.mp.rowCount = 4; m.mp.rank = 2;
        names(m.mp.rows[0], "PIXEL 7 PRO", 1, 1204, 1204);
        names(m.mp.rows[1], "INFINIX HOT 11", 0, m.score, m.distanceM); m.mp.rows[1].self = true;
        names(m.mp.rows[2], "GALAXY A52", 2, 640, 640); m.mp.rows[2].crashed = true;
        names(m.mp.rows[3], "REDMI NOTE 9", 3, 331, 331);
        m.mp.tagCount = 2;
        m.mp.tags[0].pos = {980, 520}; std::snprintf(m.mp.tags[0].name, sizeof(m.mp.tags[0].name), "PIXEL 7 PRO"); m.mp.tags[0].style = 1; m.mp.tags[0].ahead = 38;
        m.mp.tags[1].pos = {700, 640}; std::snprintf(m.mp.tags[1].name, sizeof(m.mp.tags[1].name), "REDMI NOTE 9"); m.mp.tags[1].style = 3; m.mp.tags[1].ahead = -12;
        drawHud(ui, c.layout(), m);
    }, [](Controls&) {});
    render(dir, "mp_results", W, H, [&names](UiBatch& ui, Controls& c) {
        HudModel m = model(c, Phase::GameOver);
        m.phaseTime = 2.0f;
        m.mp.racing = true; m.mp.rowCount = 4; m.mp.rank = 2; m.mp.allDone = false;
        names(m.mp.rows[0], "PIXEL 7 PRO", 1, 1204, 1204); m.mp.rows[0].finished = true;
        names(m.mp.rows[1], "INFINIX HOT 11", 0, 904, 904); m.mp.rows[1].self = true; m.mp.rows[1].finished = true;
        names(m.mp.rows[2], "GALAXY A52", 2, 640, 640); m.mp.rows[2].crashed = true;
        names(m.mp.rows[3], "REDMI NOTE 9", 3, 331, 331);
        drawHud(ui, c.layout(), m);
    }, [](Controls&) {});

    // ---- the font: every glyph, opaque / translucent, with and without the halo
    render(dir, "font_sheet", W, H, [](UiBatch& ui, Controls&) {
        using namespace widgets;
        const char* rows[] = {"ABCDEFGHIJKLMNOPQRSTUVWXYZ", "0123456789 . : - / ! + ? % _ ( ) , ' # * < > =", "SUNSET DOWNHILL 104 KM/H 0.89 KM SCORE 904"};
        float y = 24;
        const float sizes[] = {64, 40, 22};
        for (int r = 0; r < 3; ++r) {
            text(ui, rows[r], 40, y, sizes[r], kWhite);
            y += textHeight(sizes[r]) + 16;
        }
        y += 10;
        for (int i = 0; i < 4; ++i) {   // fading text: the strokes must not show through each other
            const float a = 1.0f - 0.22f * i;
            text(ui, "ALPHA 100 WIPEOUT 8808", 40, y, 70, alpha(kGold, a));
            drawText(ui, "NO HALO 8808 EB", 1010, y, 70, alpha(kWhite, a));
            y += textHeight(70) + 12;
        }
        // the speed readout exactly as in the game, at a few values
        const int speeds[] = {30, 104, 188};
        for (int i = 0; i < 3; ++i) {
            char buf[16];
            std::snprintf(buf, sizeof(buf), "%d", speeds[i]);
            const float x = 40 + 560.0f * i;
            const float w = text(ui, buf, x, y, 92, kWhite);
            text(ui, "KM/H", x + w + 14, y + textHeight(92) - textHeight(30), 30, kAccent);
        }
    }, [](Controls&) {});

    // ---- the CONTROLS screen
    render(dir, "editor_stick", W, H, [](UiBatch&ui, Controls& c) { c.drawEditor(ui); }, [](Controls& c) { c.openEditor(); });
    render(dir, "editor_arrows", W, H, [](UiBatch& ui, Controls& c) { c.drawEditor(ui); }, [](Controls& c) {
        c.setConfig(mode(SteerMode::Arrows)); c.openEditor();
        press(c, c.layout().center(ButtonId::Left));                // select the left arrow ...
        press(c, widget(c, W_::SizeUp)); press(c, widget(c, W_::SizeUp));   // ... and make it a bit bigger
        press(c, widget(c, W_::OpacityDown));
    });
    render(dir, "editor_tilt", W, H, [](UiBatch& ui, Controls& c) { c.drawEditor(ui); }, [](Controls& c) {
        c.setConfig(mode(SteerMode::Tilt)); c.openEditor();
        c.setTiltGravity(-9.81f * std::sin(10 * kDeg2Rad), 9.81f * std::cos(10 * kDeg2Rad));
        for (int i = 0; i < 90; ++i) c.update(1.0f / 60.0f, false, false);
        press(c, c.layout().center(ButtonId::Slide));
    });
    render(dir, "editor_both_dragging", W, H, [](UiBatch& ui, Controls& c) { c.drawEditor(ui); }, [](Controls& c) {
        c.setConfig(mode(SteerMode::ArrowsTilt)); c.openEditor();
        const Vec2 t = c.layout().center(ButtonId::Tuck);
        c.onTouch(kTouchDown, 1, t.x, t.y);
        c.onTouch(kTouchMove, 1, 1500, 560);                       // mid-drag, finger still down
    });
    // narrow / wide / small screens
    render(dir, "editor_arrows_4x3", 1440, 1080, [](UiBatch& ui, Controls& c) { c.drawEditor(ui); }, [](Controls& c) { c.setConfig(mode(SteerMode::ArrowsTilt)); c.openEditor(); });
    render(dir, "editor_tilt_20x9", 2400, 1080, [](UiBatch& ui, Controls& c) { c.drawEditor(ui); }, [](Controls& c) { c.setConfig(mode(SteerMode::Tilt)); c.openEditor(); });
    render(dir, "running_arrows_4x3", 1440, 1080, [](UiBatch& ui, Controls& c) { drawHud(ui, c.layout(), model(c, Phase::Running)); }, [](Controls& c) { c.setConfig(mode(SteerMode::Arrows)); });
    return 0;
}
