// test_controls: checks the control schemes, button customisation and tilt steering without a phone or a GPU.
// Build: see tools/CMakeLists.txt (target test_controls), or
//   g++ -std=c++17 -O1 -I../app/src/main/cpp/core test_controls.cpp ../app/src/main/cpp/core/{controls_config,tilt,input,controls_editor,controls,hud,ui_widgets,ui_batch,ui_font}.cpp
#include <cmath>
#include <cstdio>
#include <string>

#include "controls.h"
#include "controls_config.h"
#include "controls_editor.h"
#include "hud.h"
#include "input.h"
#include "tilt.h"
#include "ui_batch.h"
#include "ui_layout.h"

using namespace sd;
using Widget = ControlsEditor::Widget;

static int g_checks = 0, g_failed = 0;
#define CHECK(cond)                                                                   \
    do {                                                                              \
        ++g_checks;                                                                   \
        if (!(cond)) {                                                                \
            ++g_failed;                                                               \
            std::printf("  FAIL %s:%d  %s\n", __FILE__, __LINE__, #cond);             \
        }                                                                             \
    } while (0)
#define CHECK_NEAR(a, b, tol)                                                                                         \
    do {                                                                                                              \
        ++g_checks;                                                                                                   \
        const double va_ = (a), vb_ = (b);                                                                            \
        if (!(std::fabs(va_ - vb_) <= (tol))) {                                                                       \
            ++g_failed;                                                                                               \
            std::printf("  FAIL %s:%d  %s = %.4f, expected %.4f (+-%.4f)\n", __FILE__, __LINE__, #a, va_, vb_, (double)(tol)); \
        }                                                                                                             \
    } while (0)

namespace {

constexpr float kDt = 1.0f / 60.0f;
struct Screen { float w, h; const char* name; };
const Screen kScreens[] = {{1920, 1080, "16:9"}, {2400, 1080, "20:9"}, {1440, 1080, "4:3"}, {1620, 1080, "3:2"}, {1280, 720, "720p"}, {2560, 1440, "1440p"}};

// ---- helpers --------------------------------------------------------------------------------------------------
void frames(Controls& c, int n, bool countdown = false, bool running = false) {
    for (int i = 0; i < n; ++i) c.update(kDt, countdown, running);
}
void down(Controls& c, int id, Vec2 p) { c.onTouch(kTouchDown, id, p.x, p.y); }
void move(Controls& c, int id, Vec2 p) { c.onTouch(kTouchMove, id, p.x, p.y); }
void up(Controls& c, int id, Vec2 p) { c.onTouch(kTouchUp, id, p.x, p.y); }
void press(Controls& c, Vec2 p) { down(c, 1, p); up(c, 1, p); }
Vec2 centerOf(const Rect& r) { return {r.x + r.w * 0.5f, r.y + r.h * 0.5f}; }

Vec2 widgetCenter(const Controls& c, Widget w) {
    Rect r;
    const bool ok = ControlsEditor::widgetRect(w, c.layout(), c.mode(), &r);
    CHECK(ok);
    return centerOf(r);
}
void tapWidget(Controls& c, Widget w) { press(c, widgetCenter(c, w)); }
float dist(Vec2 a, Vec2 b) { return std::sqrt((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y)); }

void setGravityRoll(TiltSteer& t, float deg, float g = 9.81f) {
    const float th = deg * kDeg2Rad;
    t.setGravity(-g * std::sin(th), g * std::cos(th));   // turning the phone clockwise makes x negative
}
void settleTilt(TiltSteer& t, float seconds, bool calibrating = false) {
    for (int i = 0; i < static_cast<int>(seconds * 60.0f); ++i) t.update(kDt, calibrating);
}

ControlsConfig withMode(SteerMode m) {
    ControlsConfig cfg;
    cfg.mode = m;
    return cfg;
}

// ---- config -----------------------------------------------------------------------------------------------------
void testConfig() {
    std::puts("config");
    const ControlsConfig d;
    CHECK(d.mode == SteerMode::Stick);
    CHECK(ControlsConfig::parse(d.serialize()) == d);

    ControlsConfig c;
    c.mode = SteerMode::ArrowsTilt;
    c.opacity = 0.6f;
    c.tiltSensitivity = 1.3f;
    c.button[0] = {-0.2f, 0.65f, 1.4f};
    c.button[1] = {-0.35f, 0.7f, 0.8f};
    c.button[2] = {0.05f, 0.9f, 1.1f};
    c.button[3] = {0.4f, 0.55f, 1.6f};
    CHECK(ControlsConfig::parse(c.serialize()) == c);
    CHECK(c != d);
    std::printf("  e.g. \"%s\"\n", c.serialize().c_str());

    CHECK(ControlsConfig::parse("") == d);
    CHECK(ControlsConfig::parse("hello world") == d);
    CHECK(ControlsConfig::parse("m=2 o=500") == d);   // no version tag: not ours

    const ControlsConfig u = ControlsConfig::parse("v1 m=2 zz=5 tuck=-500,400,1000 left=oops o=abc");
    CHECK(u.mode == SteerMode::Tilt);                  // unknown keys are skipped, bad values keep their defaults
    CHECK_NEAR(u.button[0].x, -0.5, 1e-3);
    CHECK_NEAR(u.button[toIndex(ButtonId::Left)].x, d.button[toIndex(ButtonId::Left)].x, 1e-4);

    // a layout saved before PUSH existed has no push= entry: the new button simply takes its factory spot
    const ControlsConfig old = ControlsConfig::parse("v1 m=1 o=800 t=1200 tuck=-100,700,1200 slide=-300,750,900 left=120,800,1000 right=260,800,1000");
    CHECK(old.mode == SteerMode::Arrows && old.button[0].scale > 1.19f);
    CHECK_NEAR(old.button[toIndex(ButtonId::Push)].x, d.button[toIndex(ButtonId::Push)].x, 1e-4);
    CHECK_NEAR(old.button[toIndex(ButtonId::Push)].y, d.button[toIndex(ButtonId::Push)].y, 1e-4);
    CHECK_NEAR(old.button[toIndex(ButtonId::Right)].x, 0.26, 1e-3);
    ControlsConfig moved = c;
    moved.button[toIndex(ButtonId::Push)] = {-0.4f, 0.4f, 1.3f};
    const ControlsConfig round = ControlsConfig::parse(moved.serialize());
    CHECK(round == moved && std::fabs(round.button[toIndex(ButtonId::Push)].scale - 1.3f) < 1e-3f);
    CHECK_NEAR(u.opacity, 1.0, 1e-4);

    const ControlsConfig r = ControlsConfig::parse("v1 m=9 o=99999 t=-5 tuck=5000,-300,9000");
    CHECK(r.mode == SteerMode::Stick);                 // out of range: ignored / clamped
    CHECK_NEAR(r.opacity, ControlsConfig::kMaxOpacity, 1e-4);
    CHECK_NEAR(r.tiltSensitivity, ControlsConfig::kMinTilt, 1e-4);
    CHECK_NEAR(r.button[0].x, 1.0, 1e-4);
    CHECK_NEAR(r.button[0].y, 0.0, 1e-4);
    CHECK_NEAR(r.button[0].scale, ControlsConfig::kMaxScale, 1e-4);

    ControlsConfig n;
    n.button[0].x = NAN;
    n.button[1].y = INFINITY;
    n.opacity = NAN;
    n.sanitize();
    CHECK(std::isfinite(n.button[0].x) && std::isfinite(n.button[1].y) && std::isfinite(n.opacity));

    ControlsConfig e = c;
    e.resetLayout();
    CHECK(e.mode == SteerMode::ArrowsTilt && e.tiltSensitivity == c.tiltSensitivity);   // reset keeps the scheme and tilt setting
    CHECK(e.opacity == 1.0f && e.button[0].scale == 1.0f);
}

// ---- layout -----------------------------------------------------------------------------------------------------
void testLayout() {
    std::puts("layout");
    // the factory TUCK / SLIDE sit where they sat before the buttons became movable
    const UiLayout L = UiLayout::make(1920, 1080);
    CHECK_NEAR(L.center(ButtonId::Tuck).x, 1694, 3);
    CHECK_NEAR(L.center(ButtonId::Tuck).y, 864, 3);
    CHECK_NEAR(L.radius(ButtonId::Tuck), 120, 0.01);
    CHECK_NEAR(L.center(ButtonId::Slide).x, 1452, 3);
    CHECK_NEAR(L.center(ButtonId::Slide).y, 872, 3);
    CHECK_NEAR(L.radius(ButtonId::Slide), 92, 0.01);
    CHECK_NEAR(L.btnHit[0], 138, 0.01);
    CHECK_NEAR(L.btnHit[1], 110.4, 0.01);

    for (const Screen& s : kScreens) {
        // factory layout: nothing overlaps, on any aspect ratio
        const UiLayout F = UiLayout::make(s.w, s.h);
        for (int a = 0; a < kButtonCount; ++a) {
            CHECK(dist(F.btnC[a], F.pauseC) > F.btnR[a] + F.pauseR * 1.5f);
            for (int b = a + 1; b < kButtonCount; ++b) {
                if (dist(F.btnC[a], F.btnC[b]) < F.btnR[a] + F.btnR[b]) std::printf("  overlap %s: %d-%d\n", s.name, a, b);
                CHECK(dist(F.btnC[a], F.btnC[b]) >= F.btnR[a] + F.btnR[b]);
            }
        }
        // factory TUCK / SLIDE hug the right edge by the same distance as on 16:9 (u-scaled)
        CHECK_NEAR((F.w - F.center(ButtonId::Tuck).x) / F.u, 226, 3);

        // whatever is saved, every button stays fully on screen and below the HUD band
        for (int variant = 0; variant < 5; ++variant) {
            ControlsConfig cfg;
            for (int i = 0; i < kButtonCount; ++i) {
                cfg.button[i].x = (variant & 1) ? (i % 2 ? 0.0f : -0.0f) : (i % 2 ? -1.0f : 1.0f);
                cfg.button[i].y = (variant & 2) ? 0.0f : 1.0f;
                cfg.button[i].scale = variant == 4 ? ControlsConfig::kMaxScale : ControlsConfig::kMinScale;
            }
            const UiLayout X = UiLayout::make(s.w, s.h, cfg);
            for (int i = 0; i < kButtonCount; ++i) {
                CHECK(X.btnC[i].x - X.btnR[i] >= -0.01f && X.btnC[i].x + X.btnR[i] <= X.w + 0.01f);
                CHECK(X.btnC[i].y - X.btnR[i] >= X.buttonTop - 0.01f && X.btnC[i].y + X.btnR[i] <= X.h + 0.01f);
            }
        }
    }
    // x <-> pixels round trip on both sides of a wide screen
    const UiLayout W = UiLayout::make(2400, 1080);
    for (float px : {120.0f, 700.0f, 1199.0f, 1201.0f, 1700.0f, 2280.0f}) CHECK_NEAR(W.xToPx(W.pxToX(px)), px, 0.01);
}

// ---- touch: stick, arrows, buttons ---------------------------------------------------------------------------------
void testTouchStick() {
    std::puts("touch: stick");
    Controls c;
    c.setScreen(1920, 1080);
    frames(c, 2, false, true);
    const UiLayout& L = c.layout();
    down(c, 1, {300, 700});
    CHECK(c.steerActive());
    CHECK_NEAR(c.skaterInput().steer, 0.0, 1e-4);
    move(c, 1, {300 + L.stickRange, 700});
    CHECK_NEAR(c.skaterInput().steer, 1.0, 1e-3);
    move(c, 1, {300 - L.stickRange, 700});
    CHECK(c.skaterInput().steer < -0.99f);
    up(c, 1, {300, 700});
    CHECK(!c.steerActive());
    CHECK_NEAR(c.skaterInput().steer, 0.0, 1e-4);

    down(c, 2, c.layout().center(ButtonId::Tuck));
    CHECK(c.tuckDown() && c.skaterInput().tuck && !c.skaterInput().slide);
    down(c, 3, c.layout().center(ButtonId::Slide));
    CHECK(c.slideDown() && c.skaterInput().slide);
    down(c, 7, c.layout().center(ButtonId::Push));
    CHECK(c.pushDown() && c.skaterInput().push && c.skaterInput().tuck && c.skaterInput().slide);   // (three thumbs would be needed: the buttons are independent)
    up(c, 7, {0, 0});
    CHECK(!c.pushDown() && !c.skaterInput().push);
    up(c, 2, {0, 0});
    up(c, 3, {0, 0});
    CHECK(!c.tuckDown() && !c.slideDown());

    // the arrow buttons do not exist in stick mode: a touch there is just the start of a steering drag
    down(c, 4, {L.center(ButtonId::Left).x, L.center(ButtonId::Left).y});
    CHECK(c.steerActive() && !c.leftDown());
    up(c, 4, {0, 0});

    // right of the steering zone, not on a button: a UI tap
    down(c, 5, {1000, 500});
    Vec2 tap;
    CHECK(!c.steerActive() && c.popTap(tap) && tap.x == 1000.0f);

    // outside gameplay every touch is a tap
    frames(c, 1, false, false);
    down(c, 6, c.layout().center(ButtonId::Tuck));
    CHECK(!c.tuckDown() && c.popTap(tap));
}

void testTouchArrows() {
    std::puts("touch: arrows");
    Controls c;
    c.setScreen(1920, 1080);
    c.setConfig(withMode(SteerMode::Arrows));
    frames(c, 2, false, true);
    const Vec2 left = c.layout().center(ButtonId::Left), right = c.layout().center(ButtonId::Right);

    down(c, 1, left);
    CHECK(c.leftDown() && !c.rightDown() && !c.steerActive());
    frames(c, 6, false, true);   // 0.1 s: a nudge
    CHECK_NEAR(c.skaterInput().steer, -(1.0 - std::exp(-6.0 * 0.1)), 0.02);
    frames(c, 24, false, true);  // 0.5 s: nearly full lock
    CHECK(c.skaterInput().steer < -0.9f && c.skaterInput().steer >= -1.0f);
    up(c, 1, left);
    frames(c, 18, false, true);  // eases off quickly
    CHECK(std::fabs(c.skaterInput().steer) < 0.1f);
    frames(c, 60, false, true);
    CHECK(c.skaterInput().steer == 0.0f);

    // switching straight from left to right reverses fast
    down(c, 1, left);
    frames(c, 30, false, true);
    up(c, 1, left);
    down(c, 2, right);
    frames(c, 9, false, true);   // 0.15 s
    CHECK(c.skaterInput().steer > 0.3f);
    up(c, 2, right);

    // rolling the thumb from one arrow onto the other switches direction; sliding off both keeps the last one
    frames(c, 60, false, true);
    down(c, 1, left);
    CHECK(c.leftDown() && !c.rightDown());
    move(c, 1, {(left.x + right.x) * 0.5f, left.y});   // in the gap between them
    CHECK(c.leftDown() && !c.rightDown());
    move(c, 1, right);
    CHECK(c.rightDown() && !c.leftDown());
    move(c, 1, {right.x + 400, right.y - 400});         // off in the weeds
    CHECK(c.rightDown() && !c.leftDown());
    up(c, 1, right);
    CHECK(!c.rightDown() && !c.leftDown());

    // both together cancel out
    frames(c, 60, false, true);
    down(c, 1, left);
    down(c, 2, right);
    frames(c, 90, false, true);
    CHECK(std::fabs(c.skaterInput().steer) < 0.01f);
    c.releaseAll();
    frames(c, 60, false, true);

    // no stick in arrow mode: a touch in the left half that is not on an arrow is a tap
    Vec2 tap;
    down(c, 3, {700, 500});
    CHECK(!c.steerActive() && c.popTap(tap));
    // tuck / slide still work
    down(c, 4, c.layout().center(ButtonId::Tuck));
    CHECK(c.tuckDown());
    c.releaseAll();

    // tilt only: the arrows are gone as well
    c.setConfig(withMode(SteerMode::Tilt));
    c.setTiltAvailable(true);
    frames(c, 2, false, true);
    down(c, 5, left);
    CHECK(!c.leftDown() && !c.steerActive() && c.popTap(tap));
}

// ---- tilt -------------------------------------------------------------------------------------------------------
void testTilt() {
    std::puts("tilt");
    TiltSteer t;
    t.setAvailable(true);
    setGravityRoll(t, 0);
    settleTilt(t, 1.0f);
    CHECK_NEAR(t.steer(1.0f), 0.0, 1e-3);

    setGravityRoll(t, 25);   // clockwise = right
    settleTilt(t, 1.0f);
    CHECK_NEAR(t.angleDeg(), 25.0, 0.2);
    CHECK_NEAR(t.steer(1.0f), 1.0, 1e-2);
    setGravityRoll(t, -25);
    settleTilt(t, 1.0f);
    CHECK_NEAR(t.steer(1.0f), -1.0, 1e-2);
    setGravityRoll(t, 12.5f);
    settleTilt(t, 1.0f);
    CHECK_NEAR(t.steer(1.0f), 0.402, 0.01);   // dead zone + a gentle curve: half tilt is a bit under half steering
    CHECK_NEAR(t.steer(2.0f), 1.0, 1e-2);      // twice the sensitivity: full lock at half the angle
    CHECK_NEAR(t.steer(0.5f), 0.0 + std::pow((12.5 / 50.0 - 0.06) / 0.94, 1.2), 0.01);
    setGravityRoll(t, 1.0f);
    settleTilt(t, 1.0f);
    CHECK_NEAR(t.steer(1.0f), 0.0, 1e-6);      // inside the dead zone
    setGravityRoll(t, 80);
    settleTilt(t, 1.0f);
    CHECK_NEAR(t.steer(1.0f), 1.0, 1e-4);      // saturates

    // the strength of gravity along the screen does not matter (phone tipped back), only its direction
    setGravityRoll(t, 12.5f, 5.0f);
    settleTilt(t, 1.0f);
    CHECK_NEAR(t.steer(1.0f), 0.402, 0.01);

    // lying flat: the roll is undefined, so it simply holds
    setGravityRoll(t, 20);
    settleTilt(t, 1.0f);
    t.setGravity(0.2f, 0.3f);
    settleTilt(t, 1.0f);
    CHECK_NEAR(t.angleDeg(), 20.0, 0.2);

    // it is smoothed, not instant, and settles within a fraction of a second
    TiltSteer s;
    s.setAvailable(true);
    setGravityRoll(s, 0);
    settleTilt(s, 0.5f);
    setGravityRoll(s, 25);
    settleTilt(s, 0.05f);
    const float early = s.steer(1.0f);
    CHECK(early > 0.15f && early < 0.8f);
    settleTilt(s, 0.3f);
    CHECK(s.steer(1.0f) > 0.97f);

    // calibration follows the grip, then tilting is relative to it
    TiltSteer k;
    k.setAvailable(true);
    setGravityRoll(k, 15);
    settleTilt(k, 1.5f, true);
    CHECK_NEAR(k.steer(1.0f), 0.0, 0.02);
    setGravityRoll(k, 25);
    settleTilt(k, 1.0f, false);
    CHECK_NEAR(k.angleDeg(), 10.0, 0.3);
    CHECK_NEAR(k.steer(1.0f), std::pow((10.0 / 25.0 - 0.06) / 0.94, 1.2), 0.02);
    setGravityRoll(k, 18);
    settleTilt(k, 1.0f);
    k.recenter();
    settleTilt(k, kDt);
    CHECK_NEAR(k.steer(1.0f), 0.0, 0.01);

    // no sensor: no steering
    TiltSteer none;
    setGravityRoll(none, 25);
    settleTilt(none, 1.0f);
    CHECK(none.steer(1.0f) == 0.0f);
}

// ---- the CONTROLS screen ------------------------------------------------------------------------------------------
void testEditor() {
    std::puts("editor");
    for (const Screen& s : kScreens) {
        Controls c;
        c.setScreen(s.w, s.h);
        c.setTiltAvailable(true);
        c.openEditor();
        CHECK(c.editorOpen());

        // pick a scheme (acts on press; persisted when the finger lifts)
        const Vec2 arrowsSeg = widgetCenter(c, Widget::ModeArrows);
        down(c, 1, arrowsSeg);
        CHECK(c.config().mode == SteerMode::Arrows);
        CHECK(!c.takeChanged());
        up(c, 1, arrowsSeg);
        CHECK(c.takeChanged());
        CHECK(!c.takeChanged());
        tapWidget(c, Widget::ModeStick);
        CHECK(c.config().mode == SteerMode::Stick);
        c.takeChanged();

        // PUSH sits above and between TUCK and SLIDE (clear of both, on every screen); it can be dragged anywhere free, like the others
        {
            const Vec2 p0 = c.layout().center(ButtonId::Push);
            const float pr = c.layout().radius(ButtonId::Push);
            for (ButtonId other : {ButtonId::Tuck, ButtonId::Slide}) {
                const Vec2 o = c.layout().center(other);
                CHECK(length(p0 - o) > pr + c.layout().radius(other) + 10.0f);   // PUSH starts clear of TUCK and SLIDE
            }
            const Vec2 grabP = {p0.x + 10, p0.y + 10}, toP = {s.w * 0.5f, s.h * 0.5f};
            down(c, 1, grabP);
            move(c, 1, toP);
            up(c, 1, toP);
            CHECK(c.takeChanged());
            CHECK_NEAR(c.layout().center(ButtonId::Push).x, toP.x - 10, 1.0);
            CHECK_NEAR(c.layout().center(ButtonId::Push).y, toP.y - 10, 1.0);
        }

        // drag TUCK: it follows the finger by the same amount (the grab point does not jump)
        const Vec2 t0 = c.layout().center(ButtonId::Tuck);
        const Vec2 grab = {t0.x + 30, t0.y + 20}, to = {grab.x - 100, grab.y - 300};
        down(c, 1, grab);
        move(c, 1, {grab.x - 50, grab.y - 150});
        move(c, 1, to);
        CHECK_NEAR(c.layout().center(ButtonId::Tuck).x, t0.x - 100, 1.0);
        CHECK_NEAR(c.layout().center(ButtonId::Tuck).y, t0.y - 300, 1.0);
        CHECK(!c.takeChanged());   // still dragging
        up(c, 1, to);
        CHECK(c.takeChanged());
        const Vec2 moved = c.layout().center(ButtonId::Tuck);

        // a plain tap on a button only selects it: nothing to save
        press(c, c.layout().center(ButtonId::Slide));
        CHECK(!c.takeChanged());
        CHECK_NEAR(c.layout().center(ButtonId::Tuck).x, moved.x, 1e-3);

        // buttons stay out of the HUD band at the top
        const float rt = c.layout().radius(ButtonId::Tuck);
        down(c, 1, moved);
        move(c, 1, {moved.x, 5});
        up(c, 1, {moved.x, 5});
        CHECK(c.layout().center(ButtonId::Tuck).y - rt >= c.layout().buttonTop - 0.5f);

        // ... and never on top of another button
        const Vec2 slideC = c.layout().center(ButtonId::Slide);
        down(c, 1, c.layout().center(ButtonId::Tuck));
        move(c, 1, slideC);
        up(c, 1, slideC);
        CHECK(dist(c.layout().center(ButtonId::Tuck), c.layout().center(ButtonId::Slide)) >= c.layout().radius(ButtonId::Tuck) + c.layout().radius(ButtonId::Slide));

        // ... or on the pause button
        const UiLayout& L = c.layout();
        down(c, 1, L.center(ButtonId::Tuck));
        move(c, 1, L.pauseC);
        up(c, 1, L.pauseC);
        CHECK(dist(c.layout().center(ButtonId::Tuck), c.layout().pauseC) >= c.layout().radius(ButtonId::Tuck) + c.layout().pauseR * 1.5f);
        c.takeChanged();

        // everything keeps within the screen
        for (int i = 0; i < kButtonCount; ++i) {
            CHECK(c.layout().btnC[i].x - c.layout().btnR[i] >= -0.01f && c.layout().btnC[i].x + c.layout().btnR[i] <= c.layout().w + 0.01f);
        }
    }

    // sizes: the stepper changes the selected button only, in steps, within limits
    {
        Controls c;
        c.setScreen(1920, 1080);
        c.openEditor();
        const float r0 = c.layout().radius(ButtonId::Tuck);
        tapWidget(c, Widget::SizeUp);
        CHECK_NEAR(c.config().button[0].scale, 1.1, 1e-3);
        CHECK_NEAR(c.layout().radius(ButtonId::Tuck), r0 * 1.1, 0.05);
        for (int i = 0; i < 20; ++i) tapWidget(c, Widget::SizeUp);
        CHECK_NEAR(c.config().button[0].scale, ControlsConfig::kMaxScale, 1e-3);
        press(c, c.layout().center(ButtonId::Slide));   // select SLIDE
        tapWidget(c, Widget::SizeDown);
        CHECK_NEAR(c.config().button[1].scale, 0.9, 1e-3);
        CHECK_NEAR(c.config().button[0].scale, ControlsConfig::kMaxScale, 1e-3);
        for (int i = 0; i < 20; ++i) tapWidget(c, Widget::SizeDown);
        CHECK_NEAR(c.config().button[1].scale, ControlsConfig::kMinScale, 1e-3);
        // a huge button still fits the screen
        const UiLayout& L = c.layout();
        CHECK(L.center(ButtonId::Tuck).x + L.radius(ButtonId::Tuck) <= L.w && L.center(ButtonId::Tuck).y + L.radius(ButtonId::Tuck) <= L.h);

        // ... and when every button is at its biggest, none of them ends up on top of another
        tapWidget(c, Widget::ModeArrows);
        for (int b = 0; b < kButtonCount; ++b) {
            press(c, c.layout().center(static_cast<ButtonId>(b)));   // select it
            for (int i = 0; i < 12; ++i) tapWidget(c, Widget::SizeUp);
        }
        for (int a = 0; a < kButtonCount; ++a) {
            CHECK_NEAR(c.config().button[a].scale, ControlsConfig::kMaxScale, 1e-3);
            CHECK(L.btnC[a].x - L.btnR[a] >= -0.01f && L.btnC[a].x + L.btnR[a] <= L.w + 0.01f && L.btnC[a].y + L.btnR[a] <= L.h + 0.01f);
            for (int b = a + 1; b < kButtonCount; ++b) {
                if (dist(L.btnC[a], L.btnC[b]) < L.btnR[a] + L.btnR[b] - 0.5f) std::printf("  maxed buttons %d and %d overlap by %.1f px\n", a, b, L.btnR[a] + L.btnR[b] - dist(L.btnC[a], L.btnC[b]));
                CHECK(dist(L.btnC[a], L.btnC[b]) >= L.btnR[a] + L.btnR[b] - 0.5f);
            }
        }
        c.setConfig(withMode(SteerMode::Stick));   // (the opacity part below does not care about the scheme)
        c.openEditor();

        // opacity
        for (int i = 0; i < 20; ++i) tapWidget(c, Widget::OpacityDown);
        CHECK_NEAR(c.config().opacity, ControlsConfig::kMinOpacity, 1e-3);
        tapWidget(c, Widget::OpacityUp);
        CHECK_NEAR(c.config().opacity, 0.4, 1e-3);

        // hold + : repeats
        c.setConfig(ControlsConfig());
        c.openEditor();
        const Vec2 plus = widgetCenter(c, Widget::SizeUp);
        down(c, 1, plus);
        CHECK_NEAR(c.config().button[0].scale, 1.1, 1e-3);   // the press itself
        frames(c, 12);                                        // 0.2 s: still within the initial delay
        CHECK_NEAR(c.config().button[0].scale, 1.1, 1e-3);
        frames(c, 60);                                        // ~1.2 s in total: repeating
        CHECK_NEAR(c.config().button[0].scale, ControlsConfig::kMaxScale, 1e-3);
        up(c, 1, plus);
        CHECK(c.takeChanged());

        // RESET restores the layout but keeps the scheme; DONE only fires when released on it
        c.setConfig(withMode(SteerMode::Arrows));
        c.openEditor();
        tapWidget(c, Widget::SizeUp);
        tapWidget(c, Widget::OpacityDown);
        CHECK(c.config() != withMode(SteerMode::Arrows));
        tapWidget(c, Widget::Reset);
        CHECK(c.config() == withMode(SteerMode::Arrows));
        const Vec2 doneC = widgetCenter(c, Widget::Done);
        down(c, 1, doneC);
        move(c, 1, {doneC.x, doneC.y + 400});   // slide off it
        up(c, 1, {doneC.x, doneC.y + 400});
        CHECK(c.editorOpen());
        press(c, doneC);
        CHECK(!c.editorOpen());
    }

    // one finger at a time
    {
        Controls c;
        c.setScreen(1920, 1080);
        c.openEditor();
        down(c, 1, c.layout().center(ButtonId::Tuck));
        down(c, 2, widgetCenter(c, Widget::ModeArrows));
        CHECK(c.config().mode == SteerMode::Stick);
        up(c, 2, {0, 0});
        up(c, 1, c.layout().center(ButtonId::Tuck));
    }

    // switching to arrows never leaves them under another button
    {
        Controls c;
        c.setScreen(1920, 1080);
        c.openEditor();
        const Vec2 leftHome = c.layout().center(ButtonId::Left);   // park TUCK on top of where the left arrow lives
        down(c, 1, c.layout().center(ButtonId::Tuck));
        move(c, 1, leftHome);
        up(c, 1, leftHome);
        tapWidget(c, Widget::ModeArrows);
        const UiLayout& L = c.layout();
        for (int a = 0; a < kButtonCount; ++a)
            for (int b = a + 1; b < kButtonCount; ++b) CHECK(dist(L.btnC[a], L.btnC[b]) >= L.btnR[a] + L.btnR[b] - 0.5f);
    }

    // tilt scheme: only offered with a sensor; the tilt widgets only show up when tilt is in use
    {
        Controls c;
        c.setScreen(1920, 1080);
        c.openEditor();
        Rect r;
        CHECK(!ControlsEditor::widgetRect(Widget::TiltUp, c.layout(), SteerMode::Stick, &r));
        tapWidget(c, Widget::ModeTilt);
        CHECK(c.config().mode == SteerMode::Stick);   // no sensor: refused
        c.setTiltAvailable(true);
        tapWidget(c, Widget::ModeTilt);
        CHECK(c.config().mode == SteerMode::Tilt);
        tapWidget(c, Widget::TiltUp);
        CHECK_NEAR(c.config().tiltSensitivity, 1.1, 1e-3);
        for (int i = 0; i < 30; ++i) tapWidget(c, Widget::TiltDown);
        CHECK_NEAR(c.config().tiltSensitivity, ControlsConfig::kMinTilt, 1e-3);
        // RECENTER takes the way the phone is held right now as straight ahead
        const float g = 9.81f, th = 25.0f * kDeg2Rad;
        c.setTiltGravity(-g * std::sin(th), g * std::cos(th));
        frames(c, 60);
        CHECK(c.tiltSteer() > 0.1f);   // (the sensitivity was just turned right down, so 25 degrees is only part of a lock)
        tapWidget(c, Widget::Recenter);
        frames(c, 2);
        CHECK_NEAR(c.tiltSteer(), 0.0, 0.01);
        c.setTiltGravity(0.0f, g);   // back to level: that is now 25 degrees anticlockwise of "straight"
        frames(c, 60);
        CHECK(c.tiltSteer() < -0.1f);
    }
}

// ---- the facade ---------------------------------------------------------------------------------------------------
void testControls() {
    std::puts("controls");
    Controls c;
    c.setScreen(1920, 1080);
    CHECK(!c.takeChanged());
    c.setConfig(withMode(SteerMode::Tilt));
    CHECK(!c.takeChanged());   // loading saved settings is not a change

    // no sensor: tilt schemes fall back to the arrows
    CHECK(c.mode() == SteerMode::Arrows);
    c.setTiltGravity(-4.0f, 9.0f);
    frames(c, 60, false, true);
    CHECK(c.skaterInput().steer == 0.0f);
    c.setConfig(withMode(SteerMode::ArrowsTilt));
    CHECK(c.mode() == SteerMode::Arrows);

    // with a sensor, tilt steers; arrows add to it; the sum is clamped
    c.setTiltAvailable(true);
    CHECK(c.mode() == SteerMode::ArrowsTilt);
    {
        const float g = 9.81f, th = 25.0f * kDeg2Rad;
        c.setTiltGravity(g * std::sin(th), g * std::cos(th));   // anticlockwise: left
        frames(c, 90, false, true);
        CHECK_NEAR(c.skaterInput().steer, -1.0, 0.02);
        c.onTouch(kTouchDown, 1, c.layout().center(ButtonId::Right).x, c.layout().center(ButtonId::Right).y);
        frames(c, 120, false, true);
        CHECK(std::fabs(c.skaterInput().steer) < 0.1f);   // full right arrow against full left tilt
        c.setTiltGravity(-g * std::sin(th), g * std::cos(th));
        frames(c, 90, false, true);
        CHECK_NEAR(c.skaterInput().steer, 1.0, 1e-4);      // clamped, not 2
        c.releaseAll();
    }

    // the countdown calibrates the neutral to however the phone is being held
    {
        Controls t;
        t.setScreen(1920, 1080);
        t.setTiltAvailable(true);
        t.setConfig(withMode(SteerMode::Tilt));
        const float g = 9.81f, th = 20.0f * kDeg2Rad;
        t.setTiltGravity(-g * std::sin(th), g * std::cos(th));
        frames(t, 1, true, false);
        frames(t, 150, true, false);   // 2.5 s of countdown
        frames(t, 5, false, true);
        CHECK_NEAR(t.skaterInput().steer, 0.0, 0.02);
        const float th2 = 32.0f * kDeg2Rad;
        t.setTiltGravity(-g * std::sin(th2), g * std::cos(th2));
        frames(t, 60, false, true);
        CHECK(t.skaterInput().steer > 0.3f && t.tiltSteer() > 0.3f);
    }

    // the CONTROLS screen takes over the touch screen
    {
        Controls e;
        e.setScreen(1920, 1080);
        e.openEditor();
        frames(e, 2, false, true);
        down(e, 1, e.layout().center(ButtonId::Slide));
        CHECK(!e.slideDown());
        up(e, 1, e.layout().center(ButtonId::Slide));
        e.closeEditor();
        frames(e, 2, false, true);
        down(e, 1, e.layout().center(ButtonId::Slide));
        CHECK(e.slideDown());
    }

    // closing mid-drag still saves
    {
        Controls e;
        e.setScreen(1920, 1080);
        e.openEditor();
        down(e, 1, e.layout().center(ButtonId::Tuck));
        move(e, 1, {1500, 600});
        e.closeEditor();
        CHECK(e.takeChanged());
    }
}

// ---- HUD ------------------------------------------------------------------------------------------------------------
bool onScreen(const UiBatch& ui, float w, float h, float slack) {
    for (size_t i = 0; i < ui.vertexCount(); ++i) {
        const UiVertex& v = ui.data()[i];
        if (!std::isfinite(v.x) || !std::isfinite(v.y)) return false;
        if (v.x < -slack || v.x > w + slack || v.y < -slack || v.y > h + slack) return false;
    }
    return true;
}

void testHud() {
    std::puts("hud");
    const Phase phases[] = {Phase::Menu, Phase::Countdown, Phase::Running, Phase::Crashed, Phase::GameOver, Phase::Paused};
    for (const Screen& s : kScreens) {
        for (int m = 0; m < static_cast<int>(SteerMode::Count); ++m) {
            for (bool pressed : {false, true}) {
                Controls c;
                c.setScreen(s.w, s.h);
                c.setTiltAvailable(true);
                ControlsConfig cfg = withMode(static_cast<SteerMode>(m));
                cfg.opacity = pressed ? 0.5f : 1.0f;
                c.setConfig(cfg);
                const UiLayout& L = c.layout();
                for (Phase p : phases) {
                    HudModel hm;
                    hm.phase = p;
                    hm.phaseTime = 1.0f;
                    hm.mode = c.mode();
                    hm.opacity = cfg.opacity;
                    hm.tilt = pressed ? 0.6f : -0.3f;
                    hm.tuckDown = hm.slideDown = hm.leftDown = pressed;
                    hm.steerActive = pressed;
                    hm.stickOrigin = {s.w * 0.16f, s.h * 0.62f};
                    hm.stickKnob = {s.w * 0.16f + 80.0f * L.u, s.h * 0.62f};
                    hm.score = 123456;
                    hm.best = 654321;
                    hm.popup = "COLEMAN SLIDE +123";
                    hm.popupAlpha = 1.0f;
                    UiBatch ui;
                    drawHud(ui, L, hm);
                    CHECK(ui.vertexCount() > 0);
                    if (!onScreen(ui, s.w, s.h, 4.0f)) std::printf("  off-screen HUD: %s mode %d phase %d\n", s.name, m, static_cast<int>(p));
                    CHECK(onScreen(ui, s.w, s.h, 4.0f * L.u + 60.0f));
                }
            }
            // the CONTROLS screen itself must fit on every screen, with or without a sensor
            for (bool sensor : {false, true}) {
                Controls c;
                c.setScreen(s.w, s.h);
                c.setTiltAvailable(sensor);
                c.setConfig(withMode(static_cast<SteerMode>(m)));
                c.openEditor();
                UiBatch ui;
                c.drawEditor(ui);
                CHECK(ui.vertexCount() > 0);
                if (!onScreen(ui, s.w, s.h, 2.0f)) std::printf("  off-screen editor: %s mode %d sensor %d\n", s.name, m, sensor);
                CHECK(onScreen(ui, s.w, s.h, 2.0f));
                // ... and its widgets must not overlap each other
                const Widget all[] = {Widget::Done, Widget::Reset, Widget::ModeStick, Widget::ModeArrows, Widget::ModeTilt, Widget::ModeBoth, Widget::SizeDown,
                                      Widget::SizeUp, Widget::OpacityDown, Widget::OpacityUp, Widget::TiltDown, Widget::TiltUp, Widget::Recenter};
                Rect rects[13];
                bool shown[13];
                for (int i = 0; i < 13; ++i) shown[i] = ControlsEditor::widgetRect(all[i], c.layout(), c.mode(), &rects[i]);
                for (int i = 0; i < 13; ++i) {
                    if (!shown[i]) continue;
                    CHECK(rects[i].x >= 0 && rects[i].x + rects[i].w <= s.w && rects[i].y + rects[i].h < c.layout().buttonTop);
                    for (int j = i + 1; j < 13; ++j) {
                        if (!shown[j]) continue;
                        const bool apart = rects[i].x + rects[i].w <= rects[j].x + 0.01f || rects[j].x + rects[j].w <= rects[i].x + 0.01f ||
                                           rects[i].y + rects[i].h <= rects[j].y + 0.01f || rects[j].y + rects[j].h <= rects[i].y + 0.01f;
                        if (!apart) std::printf("  widgets %d and %d overlap on %s\n", i, j, s.name);
                        CHECK(apart);
                    }
                }
            }
        }
    }

    // taps on the menu / pause overlays
    const UiLayout L = UiLayout::make(1920, 1080);
    HudModel menu;
    menu.phase = Phase::Menu;
    CHECK(hudHandleTap(L, menu, L.controlsMenu.x + 10, L.controlsMenu.y + 10) == UiAction::OpenControls);
    CHECK(hudHandleTap(L, menu, 960, 540) == UiAction::Start);
    CHECK(hudHandleTap(L, menu, L.soundC.x, L.soundC.y) == UiAction::ToggleSound);
    HudModel paused;
    paused.phase = Phase::Paused;
    CHECK(hudHandleTap(L, paused, L.controlsPause.x + 10, L.controlsPause.y + 10) == UiAction::OpenControls);
    CHECK(hudHandleTap(L, paused, L.menuX + 10, L.menuY + 10) == UiAction::Menu);
    CHECK(hudHandleTap(L, paused, 960, 400) == UiAction::Resume);
    // the two pause-screen buttons do not touch
    CHECK(L.controlsPause.y + L.controlsPause.h < L.menuY);
}

}  // namespace

int main() {
    testConfig();
    testLayout();
    testTouchStick();
    testTouchArrows();
    testTilt();
    testEditor();
    testControls();
    testHud();
    std::printf("\n%d checks, %d failed\n", g_checks, g_failed);
    return g_failed == 0 ? 0 : 1;
}
