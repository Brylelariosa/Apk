// The rolling road and what it asks of the rider (no GPU needed):
//  - hills: climbs and steeper descents are generated, smooth, bounded, deterministic (every phone builds the same road whatever the order
//    it asks for it in) and keep clear of the gorge detours
//  - climbing: without kicking the rider loses speed and stalls, with PUSH held the rider keeps going
//  - kick-push rules: from a standstill, speed limit, a session ends with the stroke (foot back on the deck), TUCK / SLIDE end it at once
//  - the Coleman slide scrubs speed as the board comes round, so a tap costs little and a committed slide costs a lot
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <vector>

#include "autopilot.h"
#include "skater.h"
#include "track.h"

using namespace sd;

static int g_fails = 0, g_checks = 0;
#define CHECK(cond, ...)                                                            \
    do {                                                                            \
        ++g_checks;                                                                 \
        if (!(cond)) {                                                              \
            ++g_fails;                                                              \
            std::printf("  FAIL line %d: %s  ", __LINE__, #cond);                   \
            std::printf(__VA_ARGS__);                                               \
            std::printf("\n");                                                      \
        }                                                                           \
    } while (0)

static constexpr float kDt = 1.0f / 120.0f;

static uint32_t seedOf(uint32_t i) { return i * 7919u + 13u; }

// ---- the road profile ---------------------------------------------------------------------------------------------------------------
static void testProfile() {
    std::printf("road profile\n");
    int climbs = 0, steeps = 0, firstHillTooEarly = 0;
    float shortest = 1e9f, steepest = 0.0f, maxStep = 0.0f, maxDescent = 0.0f;
    for (uint32_t i = 1; i <= 30; ++i) {
        Track tr(seedOf(i));
        tr.ensureGenerated(4600.0f);
        const float kStart = cfg::kHillStart;
        for (float s = 0.0f; s < kStart; s += 5.0f)
            CHECK(std::fabs(tr.pitchAt(s) - tr.basePitchAt(s) * lerpf(0.6f, 1.0f, smoothstep(0.0f, 70.0f, s))) < 1e-5f, "no hills before %.0f m (seed %u, s %.0f)", kStart, i, s);

        float prev = tr.pitchAt(0.0f), runStart = 0.0f, runMin = 0.0f;
        bool climbing = false;
        for (float s = 1.0f; s < 4500.0f; s += 1.0f) {
            const float p = tr.pitchAt(s);
            maxStep = std::max(maxStep, std::fabs(p - prev));
            prev = p;
            maxDescent = std::max(maxDescent, p / kDeg2Rad);
            if (p < 0.0f) {
                if (!climbing) { climbing = true; runStart = s; runMin = p; }
                runMin = std::min(runMin, p);
            } else if (climbing) {
                climbing = false;
                ++climbs;
                const float len = s - runStart;
                shortest = std::min(shortest, len);
                steepest = std::max(steepest, -runMin / kDeg2Rad);
                CHECK(len > 80.0f, "a climb is a real climb, not a stump: %.0f m at %.0f (seed %u)", len, runStart, i);
                CHECK(-runMin / kDeg2Rad >= cfg::kUphillGradeMin - 0.05f && -runMin / kDeg2Rad <= cfg::kUphillGradeMax + 0.05f, "climb grade %.2f deg", -runMin / kDeg2Rad);
                if (runStart < cfg::kHillStart) ++firstHillTooEarly;
            }
            const auto e = tr.hills().eventAt(s);
            if (e.kind == HillProfile::Kind::Steep && HillProfile::weight(e, s) > 0.99f) ++steeps;
        }

        // the road is the same whatever the order it is asked for in (the plan looks ahead, so the hills never depend on when a detour got planned)
        Track step(seedOf(i));
        for (float s = 60.0f; s <= 4600.0f; s += 37.0f) step.ensureGenerated(s);
        for (float s = 0.0f; s < 4400.0f; s += 3.7f) {
            CHECK(tr.pitchAt(s) == step.pitchAt(s), "pitch depends on the order the road was built in (seed %u, s %.1f)", i, s);
            const Vec3 a = tr.at(s).pos, b = step.at(s).pos;
            CHECK(length(a - b) < 1e-3f, "road geometry depends on the order the road was built in (seed %u, s %.1f)", i, s);
        }

        // hills keep clear of the gorge detours, and a detour keeps its own gentle slope
        for (const ShortcutZone& z : tr.shortcuts()) {
            if (z.sGorge1 > 4500.0f) continue;
            for (float s = z.sBend0 - cfg::kHillClearBefore; s < z.sBend1 + cfg::kHillClearAfter; s += 2.0f) {
                const float w = tr.detourWeight(s);
                const float expect = lerpf(tr.basePitchAt(s), cfg::kGorgePitchDeg * kDeg2Rad, w);
                CHECK(std::fabs(tr.pitchAt(s) - expect) < 1e-5f, "a hill reaches the detour at %.0f (seed %u)", s, i);
            }
        }
    }
    std::printf("  %d climbs (%.2f per km), shortest %.0f m, steepest %.2f deg; %d steep-descent samples; steepest descent %.1f deg, biggest pitch change per metre %.3f deg\n",
                climbs, climbs / (30 * 4.5f), shortest, steepest, steeps, maxDescent, maxStep / kDeg2Rad);
    CHECK(climbs >= 60, "climbs are common enough: %d", climbs);
    CHECK(steeps > 1000, "steeper descents exist: %d", steeps);
    CHECK(maxDescent <= cfg::kMaxDescentDeg + 0.05f, "descent limit: %.2f", maxDescent);
    CHECK(maxStep < 0.6f * kDeg2Rad, "the pitch changes smoothly: %.3f deg per metre", maxStep / kDeg2Rad);
    CHECK(firstHillTooEarly == 0, "no climb before cfg::kHillStart");
    // different seeds, different hills
    Track a(seedOf(1)), b(seedOf(2));
    int differ = 0;
    for (float s = 400.0f; s < 4000.0f; s += 20.0f) if (std::fabs(a.pitchAt(s) - b.pitchAt(s)) > 0.01f) ++differ;
    CHECK(differ > 60, "seeds give different hills: %d", differ);
}

// ---- riding a climb ---------------------------------------------------------------------------------------------------------------------
struct Climb { Track* tr; float start, end; };   // a straight-ish climb with no obstacles: [start, end] is where the road is uphill

// Finds a long, straight climb far from any detour (the first one found in the seeds).
static bool findClimb(Track& tr, float* sStart, float* sEnd) {
    for (float s0 = cfg::kHillStart; s0 < 3800.0f; s0 += 5.0f) {
        if (tr.pitchAt(s0) >= -0.5f * kDeg2Rad || tr.pitchAt(s0 - 5.0f) < -0.5f * kDeg2Rad) continue;
        float s1 = s0;
        while (tr.pitchAt(s1) < -0.5f * kDeg2Rad) s1 += 5.0f;
        float maxK = 0.0f;
        for (float s = s0 - 40.0f; s < s1 + 20.0f; s += 4.0f) maxK = std::max(maxK, std::fabs(tr.curvatureAt(s)));
        if (s1 - s0 > 90.0f && maxK < 0.008f) { *sStart = s0; *sEnd = s1; return true; }
    }
    return false;
}

struct RideResult { float speedAtEnd = 0.0f, minSpeed = 99.0f, time = 0.0f; bool crashed = false; CrashCause cause = CrashCause::None; int kicks = 0; float distance = 0.0f; };

// Rides from `from` to `to` with the autopilot's steering and the given policy for the pedals.
template <class Policy>
static RideResult ride(Track& tr, float from, float to, float speed0, Policy policy, float maxTime = 60.0f) {
    std::vector<Obstacle> none;
    AutoPilot ap;
    Skater sk;
    sk.reset(from, speed0);
    sk.x = cfg::kLaneCenter;
    RideResult r;
    float t = 0.0f;
    while (sk.s < to && t < maxTime && !sk.crashed) {
        tr.ensureGenerated(sk.s + 420.0f);
        SkaterInput in = ap.compute(tr, none, sk);
        in.slide = false;
        in.tuck = false;
        in.push = false;
        policy(sk, in);
        sk.step(in, tr, kDt);
        r.minSpeed = std::min(r.minSpeed, sk.speed);
        t += kDt;
    }
    r.speedAtEnd = sk.speed;
    r.time = t;
    r.crashed = sk.crashed;
    r.cause = sk.crashCause;
    r.kicks = sk.pushSteps;
    r.distance = sk.s - from;
    return r;
}

static void testClimb() {
    std::printf("climbing\n");
    int tested = 0, coastLoses = 0, coastStalls = 0, pushKeeps = 0, pushBeatsCoast = 0, tuckBetter = 0;
    float sumKeep = 0.0f;
    for (uint32_t i = 1; i <= 12; ++i) {
        Track tr(seedOf(i));
        tr.ensureGenerated(4600.0f);
        float c0, c1;
        if (!findClimb(tr, &c0, &c1)) continue;
        ++tested;
        const float from = c0 - 30.0f;

        // arriving at a good speed and rolling: the climb eats it
        const RideResult coast = ride(tr, from, c1, 20.0f, [](Skater&, SkaterInput&) {});
        const RideResult tuck = ride(tr, from, c1, 20.0f, [](Skater&, SkaterInput& in) { in.tuck = true; });
        if (coast.speedAtEnd < 20.0f - 7.0f || coast.crashed) ++coastLoses;
        if (tuck.distance > coast.distance + 5.0f) ++tuckBetter;   // (both usually stall: the one that tucked gets further)

        // arriving slowly: without kicking the board stops and the rider bails; with PUSH held the climb is made
        const RideResult slowCoast = ride(tr, from, c1, 7.0f, [](Skater&, SkaterInput&) {});
        const RideResult slowPush = ride(tr, from, c1, 7.0f, [](Skater&, SkaterInput& in) { in.push = true; });
        if (slowCoast.crashed && slowCoast.cause == CrashCause::Stall) ++coastStalls;
        if (!slowPush.crashed && slowPush.speedAtEnd > 3.5f && slowPush.minSpeed > 3.0f) { ++pushKeeps; sumKeep += slowPush.speedAtEnd; }
        if (!slowPush.crashed && slowPush.distance > slowCoast.distance + 10.0f) ++pushBeatsCoast;
    }
    std::printf("  %d climbs ridden: coasting at 20 m/s loses 7+ m/s %d, a slow rider coasting stalls %d, PUSH carries a slow rider over %d (arrives at %.1f m/s on average), PUSH goes further than coasting %d\n",
                tested, coastLoses, coastStalls, pushKeeps, pushKeeps ? sumKeep / pushKeeps : 0.0f, pushBeatsCoast);
    CHECK(tested >= 8, "enough straight climbs found: %d", tested);
    CHECK(coastLoses >= tested - 1, "a climb costs speed: %d/%d", coastLoses, tested);
    CHECK(tuckBetter >= tested - 1, "tucking gets further up a hill than sitting up: %d/%d", tuckBetter, tested);
    CHECK(coastStalls >= tested - 1, "without kicking a slow rider stalls on a climb: %d/%d", coastStalls, tested);
    CHECK(pushKeeps >= tested - 1, "PUSH keeps the rider going uphill: %d/%d", pushKeeps, tested);
    CHECK(pushBeatsCoast >= tested - 1, "PUSH gets further than coasting: %d/%d", pushBeatsCoast, tested);
}

// ---- the kick-push rules ----------------------------------------------------------------------------------------------------------------
static void testPushRules() {
    std::printf("kick-push rules\n");
    Track tr(seedOf(3));
    tr.ensureGenerated(1500.0f);
    auto fresh = [&](float s, float v) { Skater sk; sk.reset(s, v); sk.x = cfg::kLaneCenter; return sk; };
    auto run = [&](Skater& sk, SkaterInput in, float seconds) { for (float t = 0.0f; t < seconds && !sk.crashed; t += kDt) sk.step(in, tr, kDt); };

    {   // a standing start: PUSH gets the rider rolling
        Skater sk = fresh(100.0f, 0.0f);
        SkaterInput in; in.push = true;
        run(sk, in, 1.2f);
        CHECK(sk.pushActive && sk.pushAmount > 0.9f, "kicking: active %d, pose weight %.2f", sk.pushActive, sk.pushAmount);
        run(sk, in, 3.0f);
        CHECK(sk.speed > 4.0f && sk.pushSteps >= 3, "a standing start with PUSH: %.1f m/s after %d kicks", sk.speed, sk.pushSteps);
    }
    {   // too fast to kick: PUSH does nothing
        Skater sk = fresh(100.0f, 16.0f);
        SkaterInput in; in.push = true;
        run(sk, in, 1.0f);
        CHECK(!sk.pushActive && sk.pushSteps == 0 && sk.pushAmount < 0.01f, "PUSH above the speed limit: active %d, kicks %d", sk.pushActive, sk.pushSteps);
    }
    {   // letting go ends the session at the end of the stroke (the foot comes back to the deck), once
        Skater sk = fresh(100.0f, 3.0f);
        SkaterInput in; in.push = true;
        run(sk, in, 1.3f);
        const int lands0 = sk.pushLands;
        CHECK(sk.pushActive, "kicking before letting go");
        in.push = false;
        float t = 0.0f;
        while (sk.pushActive && t < 2.0f) { sk.step(in, tr, kDt); t += kDt; }
        CHECK(!sk.pushActive && t <= cfg::kPushPeriod + 0.02f, "the stroke is finished within one kick: %.2f s", t);
        CHECK(sk.pushLands == lands0 + 1, "the foot lands on the deck exactly once: %d -> %d", lands0, sk.pushLands);
        run(sk, in, 1.0f);
        CHECK(sk.pushLands == lands0 + 1 && sk.pushAmount < 0.05f, "and stays there: lands %d, pose weight %.2f", sk.pushLands, sk.pushAmount);
    }
    {   // TUCK or SLIDE end it at once
        for (int which = 0; which < 2; ++which) {
            Skater sk = fresh(100.0f, 4.0f);
            SkaterInput in; in.push = true;
            run(sk, in, 1.0f);
            const int lands0 = sk.pushLands;
            in.tuck = which == 0; in.slide = which == 1;
            sk.step(in, tr, kDt);
            CHECK(!sk.pushActive && sk.pushLands == lands0 + 1, "%s ends the kick-push at once", which == 0 ? "TUCK" : "SLIDE");
            CHECK(sk.pushActive == false && sk.pushPhase == 0.0f, "...and rewinds the stroke");
            run(sk, in, 0.3f);
            CHECK(which == 0 ? sk.tuck > 0.4f : sk.slide > 0.4f, "...so the rider can get on with it: tuck %.2f slide %.2f", sk.tuck, sk.slide);
        }
    }
    {   // the automatic kicks at the line: a few strokes, then the rider settles onto the board
        Skater sk = fresh(6.0f, 0.0f);
        sk.startPush();
        SkaterInput in;
        run(sk, in, 5.0f);
        CHECK(!sk.pushActive && sk.pushSteps == cfg::kPushStrokes && sk.pushLands == 1, "start: %d kicks, %d landings, active %d", sk.pushSteps, sk.pushLands, sk.pushActive);
        CHECK(sk.speed > 3.0f, "and the kicks got the board rolling: %.1f m/s", sk.speed);
    }
    {   // a long climb of kicks keeps the phase small (the network sends it as a bounded number)
        Skater sk = fresh(100.0f, 3.0f);
        SkaterInput in; in.push = true;
        float worst = 0.0f;
        for (float t = 0.0f; t < 60.0f && !sk.crashed; t += kDt) {
            sk.step(in, tr, kDt);
            worst = std::max(worst, sk.pushPhase);
            if (sk.speed > cfg::kPushMaxSpeed - 0.2f) sk.speed = 4.0f;   // (keep kicking for the whole minute)
        }
        CHECK(worst < 40.0f, "push phase stays bounded: %.1f", worst);
    }
}

// ---- the Coleman slide -----------------------------------------------------------------------------------------------------------------
static void testSlide() {
    std::printf("coleman slide\n");
    Track tr(seedOf(5));
    tr.ensureGenerated(1800.0f);
    // speed lost to a slide held for `hold` seconds, compared with riding on: both start at 20 m/s on the same stretch
    auto lost = [&](float hold, float steerAmt) {
        float v[2];
        for (int withSlide = 0; withSlide < 2; ++withSlide) {
            Skater sk; sk.reset(300.0f, 20.0f); sk.x = cfg::kLaneCenter;
            std::vector<Obstacle> none; AutoPilot ap;
            for (float t = 0.0f; t < 2.5f && !sk.crashed; t += kDt) {
                SkaterInput in = ap.compute(tr, none, sk);
                in.slide = withSlide && t < hold;
                in.tuck = in.push = false;
                if (in.slide && steerAmt != 0.0f) in.steer = steerAmt;
                sk.step(in, tr, kDt);
            }
            v[withSlide] = sk.crashed ? 0.0f : sk.speed;
        }
        return v[0] - v[1];
    };
    const float tap = lost(0.10f, 0.0f), hold = lost(1.2f, 0.0f), holdSteer = lost(1.2f, 0.9f);
    std::printf("  speed lost: a 0.1 s tap %.2f m/s, 1.2 s held %.1f m/s, 1.2 s held with steering %.1f m/s\n", tap, hold, holdSteer);
    CHECK(hold > 5.0f, "a committed slide scrubs plenty of speed: %.1f", hold);
    CHECK(tap < 0.3f * hold, "a quick tap costs much less than a held slide: %.2f vs %.1f", tap, hold);

    // the board comes round to a steeper angle with steering, and a shallower one at speed
    auto angleAt = [&](float speed, float steerAmt) {
        Skater sk; sk.reset(300.0f, speed); sk.x = cfg::kLaneCenter;
        float peak = 0.0f;
        for (float t = 0.0f; t < 1.0f && !sk.crashed; t += kDt) {
            SkaterInput in; in.slide = true; in.steer = steerAmt;
            sk.step(in, tr, kDt);
            if (t > 0.6f) peak = std::max(peak, std::fabs(sk.yawVis));
        }
        return peak;
    };
    const float slow = angleAt(12.0f, 1.0f), fast = angleAt(32.0f, 1.0f), gentle = angleAt(12.0f, 0.2f);
    std::printf("  board angle: %.2f rad at 12 m/s full steer, %.2f at 32 m/s, %.2f at 12 m/s with a light touch\n", slow, fast, gentle);
    CHECK(fast < slow - 0.05f, "faster means a shallower slide: %.2f vs %.2f", fast, slow);
    CHECK(gentle < slow - 0.05f, "a light touch means a smaller angle: %.2f vs %.2f", gentle, slow);
    CHECK(slow > 1.0f && slow < 1.45f, "full slide angle: %.2f rad", slow);
}

int main() {
    testProfile();
    testClimb();
    testPushRules();
    testSlide();
    std::printf("\n%d checks, %d failed\n", g_checks, g_fails);
    return g_fails == 0 ? 0 : 1;
}
