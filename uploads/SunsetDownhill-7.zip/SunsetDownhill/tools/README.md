# Desktop tools

These are optional developer tools for the platform independent engine in
`app/src/main/cpp/core`. They are **not** part of the Android build.

```bash
cmake -S tools -B build-tools && cmake --build build-tools -j
./build-tools/sim_physics        # speed / crash balance of the skater physics
./build-tools/sim_game           # autopilot plays full runs with obstacles and traffic
./build-tools/audio_dump         # synthesises a test session to /tmp/audio_test.wav
./build-tools/test_controls      # control schemes, button layout editor, tilt maths, HUD fit on every aspect ratio
./build-tools/test_audio         # no engine-like tone may follow the wheel speed (guards the "flapping / gear change" bug)
./build-tools/dump_ui /tmp/ui    # the HUD, the CONTROLS screen, the font sheet and the LAN screens as PPM images (no GPU needed)
./build-tools/test_traffic 240 6 # drivers vs. cones, rocks and each other on 6 seeds (add "weave" for a rider crossing both lanes)
./build-tools/test_net           # the LAN protocol on loopback: discovery, join, start, relay, spoofed / malformed packets
./build-tools/test_race          # gorge zones, the speed-dependent jump, steering over the gorge, a jump seen from another phone, finish line
./build-tools/test_hills         # the rolling road, climbing with and without PUSH, the kick-push rules, the Coleman slide
./build-tools/test_trees         # tree crowns keep apart (different kinds too) and the world's crown radii match the meshes
ctest --test-dir build-tools     # runs test_controls, test_audio, test_traffic, test_net, test_race, test_hills, test_trees (+ test_mp_engine with EGL)
# needs Mesa EGL/GLES (apt install libegl-dev libgles-dev libgl1-mesa-dri):
LIBGL_ALWAYS_SOFTWARE=1 ./build-tools/render_session 1600 720 /tmp/shots 3
LIBGL_ALWAYS_SOFTWARE=1 ./build-tools/render_models 1000 700 /tmp/models     # close-ups: rider poses and every car type
LIBGL_ALWAYS_SOFTWARE=1 ./build-tools/render_look models 900 560 /tmp/look    # rider poses, head and the tuck from behind / above (cloth vs hands)
LIBGL_ALWAYS_SOFTWARE=1 ./build-tools/render_look board  900 560 /tmp/look    # board, trucks and wheel close-ups
LIBGL_ALWAYS_SOFTWARE=1 ./build-tools/render_look scenery 900 520 /tmp/look   # spruce, autumn tree, birch, undergrowth, rock and guard rail
LIBGL_ALWAYS_SOFTWARE=1 ./build-tools/render_look game 1100 500 /tmp/look 777 9 22   # the chase view of a real run at 9 s and 22 s (seed 777)
LIBGL_ALWAYS_SOFTWARE=1 ./build-tools/render_look jump 960 440 /tmp/look 777 # a gorge flight with a steering nudge, five frames
LIBGL_ALWAYS_SOFTWARE=1 ./build-tools/render_traffic 1400 630 /tmp/traffic   # autopilot rides through traffic: cars, brake lights, signals
LIBGL_ALWAYS_SOFTWARE=1 ./build-tools/render_lan 1600 720 /tmp/lan           # two phones race over loopback; one is rendered
./build-tools/test_mp_engine     # three engines run a whole LAN race through the lobby screens (no GPU needed at run time)
```

`render_session` runs the real engine on a software GLES 3 context and writes PPM screenshots
(`python3 -c "from PIL import Image; Image.open('a_menu.ppm').save('a_menu.png')"` converts them).
All gameplay constants live in `core/config.h`.

`test_controls`, `test_audio` and `dump_ui` need neither a GPU nor a phone: the control code (`controls*.cpp`, `tilt.cpp`,
`input.cpp`, `hud.cpp`) is platform independent and free of OpenGL on purpose.

## test_race

`test_race` (GPU free) checks the rider mesh budget, that the gorge-jump zones are valid (the U-shaped detour closes back onto its
entry line, the ground is cut away beside it, rails and kicker rules agree, the road runs straight for the landing runway after it), and
the jump itself: that simulated kicker jumps over many seeds and detours land and ride on at 65 km/h and more and are a real shortcut over
the detour, that the jump is higher and further the faster the rider is yet stays a ramp jump (apex and height above the ground are
bounded), that a rider who is too slow falls short of the far road and one who creeps over the lip only hops, that steering moves the
landing and full lock misses, that SLIDE floats a jump that is a little short across and TUCK dives one that only just clears it, that
another phone rebuilds the rider's flight (position and nose pitch) from what is sent over the network, that a race with a goal ends at the
finish line, and that a late START fast-forwards the countdown so GO is simultaneous.

## test_hills

`test_hills` (GPU free) checks that the road really rolls: climbs and steeper descents are generated at a sensible rate, are smooth and
bounded, never stand within reach of a gorge detour, and that the road is identical whatever order it is built in (so every phone in a LAN
race rides the same hills). Then it rides the climbs: coasting up one at speed bleeds it, a slow rider coasting stalls, **PUSH** carries the
rider up it, tucking gets further than sitting up. It also checks the kick-push rules (a standing start, no kicks above the speed limit, a
session ends with the stroke so the foot lands on the deck exactly once, TUCK / SLIDE end it at once, the push phase stays bounded) and the
Coleman slide (a tap costs little speed, a committed slide costs a lot; the board comes out less far at speed and with a light touch).

## test_trees

`test_trees` (GPU free) measures the three tree meshes and checks that the crown radii `world.cpp` spaces trees by match them, then
generates the scenery of 16 roads and checks that no two crowns overlap (pines, autumn trees and birches against each other), also across
the borders of the independently generated chunks and round the gorge detours where the road folds back on itself, and that the forest is
still dense.
