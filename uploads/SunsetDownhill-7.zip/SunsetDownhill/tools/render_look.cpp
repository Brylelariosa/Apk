// render_look: close-ups of the rider / board / scenery and frames of a real run, for reviewing the artwork headlessly.
//   render_look models|board|scenery|game W H outDir [seconds...]
#include <EGL/egl.h>
#include <EGL/eglext.h>
#include <GLES3/gl3.h>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>
#include "atmosphere.h"
#include "autopilot.h"
#include "game.h"
#include "mesh_library.h"
#include "renderer.h"
#include "scene_builder.h"
#include "skater_model.h"
using namespace sd;

static void savePPM(const char* path, int w, int h) {
    std::vector<unsigned char> px(static_cast<size_t>(w) * h * 4), out(static_cast<size_t>(w) * h * 3);
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    glReadPixels(0, 0, w, h, GL_RGBA, GL_UNSIGNED_BYTE, px.data());
    for (int y = 0; y < h; ++y) for (int x = 0; x < w; ++x) { const unsigned char* s = &px[((h - 1 - y) * w + x) * 4]; unsigned char* d = &out[(y * w + x) * 3]; d[0]=s[0]; d[1]=s[1]; d[2]=s[2]; }
    FILE* f = std::fopen(path, "wb"); std::fprintf(f, "P6\n%d %d\n255\n", w, h); std::fwrite(out.data(), 1, out.size(), f); std::fclose(f);
}
struct Shot { const char* name; Vec3 target; float yawDeg, pitchDeg, dist, fov; };

static void renderShot(Renderer& r, int W, int H, const char* dir, const Shot& s, const SceneGeometry& geoWorld, const Atmosphere& atmo, float shadowDist = 0.0f) {
    const float yaw = s.yawDeg * kDeg2Rad, pitch = s.pitchDeg * kDeg2Rad;
    const Vec3 offset(-std::sin(yaw) * std::cos(pitch), std::sin(pitch), -std::cos(yaw) * std::cos(pitch));
    CameraView cam; cam.pos = s.target + offset * s.dist; cam.fwd = normalize(s.target - cam.pos);
    cam.right = normalize(cross(cam.fwd, Vec3(0, 1, 0))); cam.up = normalize(cross(cam.right, cam.fwd)); cam.fovY = s.fov;
    SceneGeometry geo; geo.clear();
    geo.dynamicMesh.append(geoWorld.dynamicMesh, Mat4::translation(-cam.pos));
    for (int b = 0; b < kBatchCount; ++b) for (Instance i : geoWorld.instances[b]) { i.x -= cam.pos.x; i.y -= cam.pos.y; i.z -= cam.pos.z; geo.instances[b].push_back(i); }
    FrameParams fp; fp.cam = cam; fp.atmo = atmo; fp.time = 1.0f; fp.speed01 = 0.0f; fp.shadowFocus = s.target;
    UiBatch ui; ui.setScreen((float)W, (float)H);
    r.render(fp, geo, ui);
    char path[256]; std::snprintf(path, sizeof(path), "%s/%s.ppm", dir, s.name);
    savePPM(path, W, H); std::fprintf(stderr, "wrote %s\n", s.name);
}
static SkaterPose basePose() { SkaterPose p; p.origin = Vec3(0,0,0); p.right = Vec3(1,0,0); p.up = Vec3(0,1,0); p.fwd = Vec3(0,0,1); p.roadUp = Vec3(0,1,0); p.time = 1.0f; p.speed = 15.0f; return p; }
static void ground(MeshData& m, float half = 30.0f) { const Rgba8 a = rgba(0.15f, 0.145f, 0.16f); m.addBox(Mat4::translation(Vec3(0, -0.06f, 0)), Vec3(half, 0.06f, half), a, a); }

int main(int argc, char** argv) {
    const std::string mode = argc > 1 ? argv[1] : "models";
    const int W = argc > 2 ? std::atoi(argv[2]) : 900, H = argc > 3 ? std::atoi(argv[3]) : 560;
    const char* dir = argc > 4 ? argv[4] : "/tmp/look";
    auto getPD = (PFNEGLGETPLATFORMDISPLAYEXTPROC)eglGetProcAddress("eglGetPlatformDisplayEXT");
    EGLDisplay dpy = getPD(EGL_PLATFORM_SURFACELESS_MESA, EGL_DEFAULT_DISPLAY, nullptr);
    EGLint maj, min; eglInitialize(dpy, &maj, &min); eglBindAPI(EGL_OPENGL_ES_API);
    const EGLint ca[] = {EGL_SURFACE_TYPE, EGL_PBUFFER_BIT, EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT, EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8, EGL_ALPHA_SIZE, 8, EGL_DEPTH_SIZE, 24, EGL_NONE};
    EGLConfig cfg; EGLint n; eglChooseConfig(dpy, ca, &cfg, 1, &n);
    const EGLint pa[] = {EGL_WIDTH, W, EGL_HEIGHT, H, EGL_NONE};
    EGLSurface surf = eglCreatePbufferSurface(dpy, cfg, pa);
    const EGLint xa[] = {EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE};
    EGLContext ctx = eglCreateContext(dpy, cfg, EGL_NO_CONTEXT, xa);
    eglMakeCurrent(dpy, surf, surf, ctx);
    Renderer r; r.setQualityTier(3); r.onContextCreated(); r.onResize(W, H);
    if (!r.ready()) { std::fprintf(stderr, "renderer not ready\n"); return 2; }
    const Atmosphere atmo = makeAtmosphere(0.05f, 3.4f);

    if (mode == "models" || mode == "board") {
        struct PoseDef { const char* name; SkaterPose p; };
        std::vector<PoseDef> poses;
        { SkaterPose p = basePose(); poses.push_back({"stand", p}); }
        { SkaterPose p = basePose(); p.tuck = 1.0f; poses.push_back({"tuck", p}); }
        { SkaterPose p = basePose(); p.lean = 0.35f; p.tuck = 0.3f; poses.push_back({"lean", p}); }
        { SkaterPose p = basePose(); p.slide = 1.0f; p.slideDir = 1.0f; p.slip = 1.1f; p.tuck = 0.6f; poses.push_back({"slide", p}); }
        { SkaterPose p = basePose(); p.push = 1.0f; p.pushPhase = 0.35f; poses.push_back({"push", p}); }
        for (int style = 0; style < (mode == "models" ? 1 : 0) + (argc > 5 ? 5 : 0); ++style) {}
        if (mode == "models") {
            const Shot shots[] = {{"back34", Vec3(0,0.95f,0), 35, 10, 4.2f, 0.62f}, {"side", Vec3(0,0.95f,0), 90, 6, 4.4f, 0.62f}, {"front34", Vec3(0,0.95f,0), 150, 12, 4.2f, 0.62f}, {"back", Vec3(0,0.95f,0), 0, 8, 4.2f, 0.62f}};
            for (const PoseDef& pd : poses) {
                SceneGeometry g; g.clear(); ground(g.dynamicMesh); buildSkaterMesh(pd.p, g.dynamicMesh);
                for (const Shot& base : shots) { Shot s = base; char nm[96]; std::snprintf(nm, sizeof(nm), "rider_%s_%s", pd.name, base.name); s.name = nm; renderShot(r, W, H, dir, s, g, atmo); }
            }
            // head and torso close-up
            SceneGeometry g; g.clear(); ground(g.dynamicMesh); buildSkaterMesh(poses[0].p, g.dynamicMesh);
            renderShot(r, W, H, dir, Shot{"head_front34", Vec3(0,1.55f,0.0f), 150, 8, 1.7f, 0.62f}, g, atmo);
            renderShot(r, W, H, dir, Shot{"head_side", Vec3(0,1.55f,0.0f), 90, 5, 1.7f, 0.62f}, g, atmo);
            // the tuck from behind and above: cloth vs hands
            SceneGeometry gt; gt.clear(); ground(gt.dynamicMesh); buildSkaterMesh(poses[1].p, gt.dynamicMesh);
            renderShot(r, W, H, dir, Shot{"tuck_back_close", Vec3(0,0.9f,-0.1f), 10, 28, 2.6f, 0.62f}, gt, atmo);
            renderShot(r, W, H, dir, Shot{"tuck_top", Vec3(0,0.9f,-0.1f), 0, 62, 2.8f, 0.62f}, gt, atmo);
            renderShot(r, W, H, dir, Shot{"tuck_side_close", Vec3(0,0.85f,0.0f), 90, 8, 2.6f, 0.62f}, gt, atmo);
        } else {
            SceneGeometry g; g.clear(); ground(g.dynamicMesh); buildSkaterMesh(poses[0].p, g.dynamicMesh);
            renderShot(r, W, H, dir, Shot{"board_back34", Vec3(0,0.16f,0), 30, 28, 1.9f, 0.62f}, g, atmo);
            renderShot(r, W, H, dir, Shot{"board_side", Vec3(0,0.12f,0), 90, 6, 1.9f, 0.62f}, g, atmo);
            renderShot(r, W, H, dir, Shot{"board_front34", Vec3(0,0.14f,0), 150, 20, 1.9f, 0.62f}, g, atmo);
            renderShot(r, W, H, dir, Shot{"board_top", Vec3(0,0.12f,0), 0, 75, 2.3f, 0.62f}, g, atmo);
            renderShot(r, W, H, dir, Shot{"wheel_close", Vec3(0.16f,0.07f,0.31f), 62, 12, 0.75f, 0.62f}, g, atmo);
        }
    } else if (mode == "scenery") {
        SceneGeometry g; g.clear(); ground(g.dynamicMesh, 80.0f);
        auto put = [&](Batch b, float x, float z, float sc, float yaw, Rgba8 tint) { Instance i{}; i.x = x; i.y = 0; i.z = z; i.yaw = yaw; i.sx = sc; i.sy = sc; i.phase = x; i.r = tint.r; i.g = tint.g; i.b = tint.b; i.a = 0; g.instances[b].push_back(i); };
        put(kBatchPine, -9, 6, 1.0f, 0.3f, {230, 235, 225, 255}); put(kBatchPine, -3, 6, 1.2f, 1.1f, {215, 225, 205, 255}); put(kBatchAutumn, 4, 6, 1.0f, 0.2f, {255, 200, 140, 255}); put(kBatchAutumn, 10, 6, 0.9f, 2.0f, {255, 150, 100, 255}); put(kBatchBirch, 16, 6, 1.0f, 0.5f, {250, 230, 160, 255});
        put(kBatchBush, -4, -1, 1.0f, 0.0f, {200, 220, 160, 255}); put(kBatchShrub, 0, -1, 1.0f, 0.5f, {255, 190, 130, 255}); put(kBatchRock, 4, -1, 1.2f, 0.4f, {220, 215, 210, 255});
        renderShot(r, W, H, dir, Shot{"trees_front", Vec3(3, 5, 6), 180, 8, 38.0f, 0.62f}, g, atmo);
        renderShot(r, W, H, dir, Shot{"trees_front34", Vec3(3, 5, 6), 140, 12, 38.0f, 0.62f}, g, atmo);
        renderShot(r, W, H, dir, Shot{"pine_close", Vec3(-9, 5, 6), 160, 6, 18.0f, 0.62f}, g, atmo);
        renderShot(r, W, H, dir, Shot{"autumn_close", Vec3(4, 4.5f, 6), 160, 6, 15.0f, 0.62f}, g, atmo);
        SceneGeometry gr; gr.clear(); ground(gr.dynamicMesh, 80.0f);
        for (int k = 0; k < 6; ++k) { Instance i{}; i.x = -12 + 4.0f * k; i.y = 0; i.z = 0; i.yaw = kPi * 0.5f; i.sx = 1; i.sy = 1; i.r = i.g = i.b = 255; gr.instances[kBatchRail].push_back(i); }
        for (int k = 0; k < 3; ++k) { Instance i{}; i.x = -6 + 12.0f * k; i.y = 0; i.z = 2.0f; i.sx = 1; i.sy = 1; i.r = i.g = i.b = 255; gr.instances[kBatchPost].push_back(i); }
        renderShot(r, W, H, dir, Shot{"rail_front34", Vec3(0, 0.6f, 0), 35, 12, 9.0f, 0.62f}, gr, atmo);
        renderShot(r, W, H, dir, Shot{"rail_back", Vec3(0, 0.6f, 0), 95, 8, 10.0f, 0.62f}, gr, atmo);
        renderShot(r, W, H, dir, Shot{"rail_close", Vec3(-2, 0.6f, 0), 60, 10, 4.0f, 0.62f}, gr, atmo);
    } else if (mode == "game") {
        Game game; game.setBaseSeed(argc > 5 ? std::atoi(argv[5]) : 777); game.startRun();
        const float dt = 1.0f / 60.0f; float t = 0.0f; size_t next = 6;
        std::vector<float> times; for (int i = 6; i < argc; ++i) times.push_back((float)std::atof(argv[i])); if (times.empty()) times = {8.0f, 16.0f};
        SceneGeometry geo; UiBatch ui; ui.setScreen((float)W, (float)H);
        for (size_t k = 0; k < times.size(); ++k) {
            while (t < times[k]) {
                SkaterInput in;
                if (game.phase() == Phase::Running) { in = game.autopilot().compute(game.world().track(), game.world().obstacles(), game.skater()); in.tuck = true; }
                game.update(dt, in); t += dt;
                if (game.phase() == Phase::Crashed || game.phase() == Phase::GameOver) { game.startRun(); }
            }
            const FrameParams fp = buildScene(game, 1.0f, geo);
            r.render(fp, geo, ui);
            char nm[64]; std::snprintf(nm, sizeof(nm), "game_%02d", (int)k);
            char path[256]; std::snprintf(path, sizeof(path), "%s/%s.ppm", dir, nm); savePPM(path, W, H);
            std::fprintf(stderr, "wrote %s t=%.1f phase=%d s=%.0f speed=%.1f km/h\n", nm, t, (int)game.phase(), game.skater().s, game.speedKmh());
        }
    }
    if (mode == "jump") {
        Game game; game.setBaseSeed(argc > 5 ? std::atoi(argv[5]) : 777); game.startRun();
        const float dt = 1.0f / 60.0f; float t = 0.0f;
        SceneGeometry geo; UiBatch ui; ui.setScreen((float)W, (float)H);
        const ShortcutZone* zone = nullptr; bool steerPhase = false; float air = 0.0f; int shot = 0;
        const float shotAt[] = {0.15f, 0.9f, 1.7f, 2.6f, 3.4f};
        for (int step = 0; step < 60 * 400 && shot < 5; ++step) {
            const Skater& sk = game.skater();
            SkaterInput in;
            if (game.phase() == Phase::Running) {
                zone = game.world().track().shortcuts().empty() ? nullptr : &game.world().track().shortcuts()[0];
                in = game.autopilot().compute(game.world().track(), game.world().obstacles(), sk);
                in.tuck = true;
                if (zone && sk.s > zone->sRamp0 - 110.0f && sk.s < zone->sLip) game.autopilot().forcedX = 0.5f * (zone->rampX0 + zone->rampX1) * zone->side; else game.autopilot().forcedX = 1e9f;
                if (zone && sk.s > zone->sRamp0 - 110.0f && sk.s < zone->sLip - 0.5f && sk.speed < 22.0f) const_cast<Skater&>(sk).speed = 22.0f;   // (the entry speed is the harness's input)
                if (sk.gapFlight) { air += dt; in.steer = (air > 1.0f && air < 1.5f) ? 0.5f : 0.0f; in.tuck = false; }
            }
            game.update(dt, in);
            if (sk.gapFlight && shot < 5 && air >= shotAt[shot]) {
                const FrameParams fp = buildScene(game, 1.0f, geo);
                r.render(fp, geo, ui);
                char nm[64]; std::snprintf(nm, sizeof(nm), "jump_%d", shot);
                char path[256]; std::snprintf(path, sizeof(path), "%s/%s.ppm", dir, nm); savePPM(path, W, H);
                std::fprintf(stderr, "wrote %s u=%.2f b=%.2f rel=%.2f\n", nm, sk.gapU, sk.gapB, sk.gapRel); ++shot;
            }
            if (game.phase() == Phase::Crashed) { std::fprintf(stderr, "crashed at s=%.0f x=%.2f speed=%.1f cause=%d zone=%s ramp0=%.0f lip=%.0f\n", sk.s, sk.x, sk.speed, (int)sk.crashCause, zone ? "y" : "n", zone ? zone->sRamp0 : 0.0f, zone ? zone->sLip : 0.0f); break; }
        }
    }
    return 0;
}
