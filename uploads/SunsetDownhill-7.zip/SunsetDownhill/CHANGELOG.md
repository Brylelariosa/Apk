# Changelog

## Update 7 (from SunsetDownhill-6): the road rolls (climbs + kick-push), a jump that depends on your speed, no overlapping trees, a better rider and Coleman slide

**The gorge jump is a real ramp jump now** (`config.h`, `track.*`, `skater.*`, `game.cpp`, `camera.cpp`)
- It was a 92 m glide, 25 m down, up to 35 m above the ground for 4 s: "like flying". The detour is smaller (bends 12.5-14 m radius, hairpin
  11.5-13.5 m, `kGorge*`), so the gap is about 60 m; it descends gently (1.3 degrees, `kGorgePitchDeg`) so the far road is only about 4 m
  below the lip, and the gorge floor is 2.8 m below that (`kGorgeDepth`). The kicker's lip is 1.1 m high.
- **Your speed decides the jump.** The flight is no longer a fixed arc: the kicker throws you up at (your speed x the slope of its lip, up to
  `kGapPopMax`), gravity (floaty, `kGapGravity`) pulls you down, your speed carries you on (a little air drag, `kGapDrag`) and the flight
  ends where the arc meets the ground (`Skater::stepGap`). Measured (`jump_curve`, 31 detours per speed): 29-54 km/h falls short and
  crashes into the gorge, 58 km/h makes it 11 times in 31, from 61 km/h every jump lands; 0.6 m above the lip at 29 km/h, 2.3 m at 61, 3.2 m
  at 72, 4.9 m at 90, 5.4 m at the top (the kicker gives no more); flights of 21 m .. 51 m .. 102 m .. 183 m.
- **TUCK dives** the flight (+40 % gravity: down sooner, a dive at a speed that only just clears the gorge falls short) and **SLIDE
  floats** it (-30 %: saves a jump that is a little short; with SLIDE 50 km/h is enough). Steering still drifts the flight and a landing
  beside the road or more crooked than 0.85 rad still crashes.
- Fast jumps come down further along the road, so every detour is followed by a **110 m straight runway** (`kGorgeRunway`).
- Slower than 7 m/s at the lip (`kGapHopSpeed`) the kicker is only a hop, as before.
- `Track::gapFlightAt(z, u, b, rel, h, slope, ...)` is the flight as a pure function (progress along the line from the lip, offset, heading,
  height above the launch point, slope); `Track::gapFlight` / `gapChord` and the `arc` argument are gone. LAN: a rider in the air sends
  `yRel = 100 + height` and `s` = metres from the lip (1:1 now), `x` and `alpha` as before; the other phones rebuild the position exactly and
  estimate the nose pitch from the height (`test_race`: 754 snapshots, 0.000 m off, pitch within 0.02 rad).

**The road rolls** (`hills.*`, `track.cpp`, `config.h`)
- New `HillProfile`: the road is cut into 320 m blocks and each holds at most one hill, a **climb** (1.3-3 degrees uphill for 90-160 m) or a
  **steeper descent** (+1.8-3.4 degrees); everything is a pure function of the seed, so a LAN race has the same hills everywhere. Hills ease
  in and out (smooth pitch), start no earlier than 340 m and are skipped whole near a gorge detour (the road plan now looks 560 m ahead,
  `kPlanAhead`, so the detours are always known first; the road is identical whatever order it is built in, `test_hills` checks it).
  About 0.8 climbs per km, 13 % of the road is uphill, the steepest descent is 11.5 degrees.
- On a climb the board bleeds speed (a rider at 72 km/h loses 7+ m/s over one; one who arrives slowly and coasts stalls and bails).
- `Skater::coastAccel` is the acceleration of a freely rolling rider at a pitch and speed; the physics, the autopilot and the HUD hint share it.

**PUSH: kick-push whenever you want** (`skater.*`, `controls_config.*`, `input.*`, `ui_*`, `hud.*`, `game.*`, `engine.cpp`)
- A third button, **PUSH**, sits above and between TUCK and SLIDE (movable and resizable in CONTROLS like the others; a layout saved before
  PUSH existed keeps working and gets the button at its factory spot). Hold it and the rider kick-pushes along the road: how you keep rolling
  uphill. Works below 40 km/h (`kPushMaxSpeed`; a kick helps less the faster the board already goes); a standing start from zero works too.
- `Skater::stepPush` is an explicit push session: it starts at the line (the four automatic kicks) or when PUSH is held, ends at the end of
  the stroke in progress once you let go (the foot always comes back to the deck, exactly once), and ends at once if you press TUCK or SLIDE.
  Thrust is a bit stronger (13 m/s^2 peak) and the cycle a touch slower (0.58 s). A continuous pusher settles at about 6-9 m/s (22-32 km/h) on a climb.
- The HUD makes the PUSH button blink with "UPHILL - KICK!" when the road climbs (or a flat stretch has slowed you) and you are not
  kicking yet. The stall bail-out is a second longer (3.5 s) so a rider can get going again. The autopilot kicks when the board would
  otherwise die. Other phones see the kicks (the same `pushAmount` / `pushPhase` fields; the phase is now an unbounded stroke count).

**Coleman slide** (`skater.cpp`, `skater_model.cpp`, `config.h`)
- The slide scrubs speed as the board comes round (`smoothstep` of the board angle): a quick tap barely slows you (0.05 m/s), a committed
  slide costs plenty (held for 1.2 s from 72 km/h: 5.5 m/s lost, 13 m/s with the stick thrown hard over; `kSlideDecelBase` 5.4); the board comes out a little less far at high speed
  (`kColeSpeedBlend`) and with a light touch on the stick.
- The pose is lower and leans harder into the slide (hip 0.34 m, lean 55-69 degrees) and the free arm is bent up and back for balance
  instead of pointing straight out.

**Trees** (`world.cpp`, `mesh_library.*`, `track.*`)
- Trees were scattered independently, so different kinds grew into each other. Now every tree claims its crown (`treeCrownRadius` per kind,
  which `test_trees` checks against the real meshes) and a spot is kept only if it clears the trees already placed; a trunk also keeps
  inside its chunk by its own crown radius, so independently generated chunks never meet; and round a gorge detour, where the road folds
  back on itself, a tree must be clearly nearer to its own part of the road than to a far part (`Track::foldsBack`), so the pocket inside
  the hairpin is bare. Pairs of overlapping crowns over 16 roads: 2915 before, 46 now (of 44468 trees; none inside each other).

**Rider and board** (`skater_model.cpp`)
- Smaller, sleeker helmet (it was a big white ball): egg-shaped shell, one racing stripe, a chin bar in the shell colour with a vent, a lower
  tinted shield. Fuller thighs, calves and sleeves; small flat knee pads in a dark trouser colour instead of black discs; thinner colour
  bands on the jacket and a darker shoulder yoke. A more athletic riding stance (knees bent, leaning in, arms bent out in front) and a lower,
  more forward kick-push pose.
- The board has an accent pinstripe along each rail so its outline reads against the dark road from behind.

**Tests** (`tools/`): new `test_hills` (91k checks: profile, climbing, kick-push rules, slide) and `test_trees` (crown radii, overlaps,
density); `test_race` reworked for the new jump (9.8k checks) and `test_controls` covers PUSH (layout, saved layouts from before PUSH, touch
mapping). The autopilot rides 240 s on all 8 seeds without a crash; the full-game sim finishes 4 of 12 runs (the previous build: 3 of 12).

## Update 6 (from SunsetDownhill-5): steerable gorge jump, new wheels / board / rider / cloth, real trees, W-beam guard rail, matte road

**You steer the gorge jump** (`skater.*`, `track.*`, `camera.cpp`, `game.cpp`, `autopilot.cpp`, `config.h`)
- Before, a rider who took the kicker was carried along a fixed path with no say in it. Now the flight is steerable
  (`Skater::stepGap`): the arc (height) is still fixed so every entry speed gets across, but sideways the rider is free. Steering turns
  the board (`kGapYawRate`) and the flight drifts with it; the board settles back toward the line to the landing when you let go
  (`kGapCentering`). **TUCK** dives the arc and flies it a little faster, **SLIDE** lifts it and flies it slower (`kGapArcLift`,
  `kGapRangeGain`). The angle and the offset you had at the lip fade out in the first second, so a rider who just lets go lands on the
  line (checked: 0.02 m off, 93 of 93 flights).
- There is something to lose: come down beside the road (the gorge on one side, the slope on the other), land more crooked than 0.85 rad
  to the road, or steer into the slope on the way, and the rider crashes (falling into the gorge if that is what is below). Holding full
  lock the whole flight always misses. A small correction still lands (`test_race`: 93 flights, every check passes).
- Ordinary kicker hops can be steered a little too (`kHopYawRate`).
- `Track::gapFlightAt` is the flight at an offset, a heading and an arc bend, a pure function of them; `Track::groundNear` finds the
  ground under a point over a detour. The LAN needs no new field: a rider in the air still sends `yRel = 100` and `s`, and now `x` (metres
  off the reference line) and `alpha` (how far the board is turned from it) say how they steered, so every phone draws the same flight.
- The autopilot lets go of the controls in the air; `Track::gapFlight` / `gapChord` (the reference line) are unchanged.

**Wheels** (`skater_model.cpp`)
- The wheels were glowing cyan (emissive urethane): that was the blue. They are now plain satin urethane in a natural colour per rider
  style (butterscotch for the sunset rider, white with red cores, lime, pink, yellow) with a bright core, a dark bearing seat and a steel nut.
  The neon underglow, the tail light and the nose light are gone, and so is everything on the road that looked like a reflection of them.

**Board** (`skater_model.cpp`)
- Natural lacquered maple edge, black grip tape, painted underside, three bold sunset stripes at nose and tail instead of four thin ones,
  truck bolts through the grip, black baseplates, polished hangers, coloured bushings, a steel axle nut.

**Road** (`shaders.cpp`)
- The asphalt looked like glass: a mirror-like reflection of the sky at grazing angles plus a sharp sun streak. Now it is dry asphalt with
  a faint broad sheen that only shows in the polished wheel tracks.
- Meshes got a general `gloss` (stored in the vertex alpha, 255 = matte): a sun highlight and a hint of sky, used on the helmet, visor,
  wheels, trucks, deck edge and guard rail.

**Rider** (`skater_model.cpp`, `skater_model.h`, `game.cpp`)
- Helmet: a proper full-face helmet - glossy dome, two racing stripes, a coloured chin bar, a tinted shield that follows the shell from ear
  to ear and a rear spoiler (the old one had black ear pads that read as eyes in a skull).
- Thicker legs, arms and sleeves in the jacket colour with a cream cuff, smaller shoulder / elbow joints and gloves, lighter denim-blue
  pants so the legs show against the dark road (every style's pants are lighter).
- **The cloth no longer goes through the rider.** The neck gaiter tail is now a flat ribbon with some thickness that streams along the
  airflow (`SkaterPose::speed`) blended with the direction the rider's back faces, so it clears the shoulders when the body is twisted in a
  tuck, and every point of it is pushed out of both arms, the hands and the back (`pushOutOfSegment`), whatever the pose.
- `RiderStyle::hub` is the wheel core colour; `SkaterPose::speed` is new.

**Trees** (`mesh_library.cpp`)
- Spruce: nine tiers of jagged boughs (long and short boughs alternate), each turned against the one below and ringed by a drooping skirt
  and a dark underside, dark inside and lit at the tips: a ragged, layered silhouette instead of smooth cones.
- Autumn tree: forked trunk and a crown of eight smooth puffy lobes in different golds, oranges and reds, dark red-brown below.
- Birch: airy golden crown of five lobes, dark bark bands. Undergrowth: four lumps per bush.

**Guard rail** (`mesh_library.cpp`)
- A galvanised steel **W-beam** with two corrugations, steel C-posts every 2 m (the old posts were 3.4 m and 0.6 m apart), offset blocks,
  soil plates and an amber reflector on the beam.

**Tools**
- `tools/render_look.cpp`: close-ups of the rider, board, trees and rail, frames of a real run, and a gorge flight with a steering input.
- `test_race` has `steering over the gorge` (let go lands on the line, nudges move the landing both ways, full lock misses, tuck is faster
  than slide) and only rides zones that are fully generated.

## Update 5 (from SunsetDownhill-4): gorge jump on the existing road, gentler sunset, predictable traffic, new board / rider / trees / road

**Shortcut: no more second road** (`track.*`, `skater.*`, `camera.*`, `game.cpp`, `world.cpp`)
- The shortcut deck on stilts is gone. Now there is only the one road. About once a kilometre it makes a **U-shaped detour round a
  gorge** (sharp bend, leg down the rim, hairpin, leg up the other rim, sharp bend back onto the original line; the road goes down at a
  steady slope all the way). A **kicker** at the cliff edge where the detour starts lets a rider with enough speed (14 m/s, about
  50 km/h) fly **straight across the mouth of the gorge and land on the road beyond it**: the whole detour (about 240 m of road, a good
  20 seconds) is skipped for +500 points. Slower than that it is only a hop.
- The detour is planned so it closes exactly (the exit lies on the line of the entry, heading the same way, checked by `test_race` on
  115 detours). The gorge side has to be the downhill side all along, which also decides which way it turns; the ground beside the road is
  cut away down to a flat floor well below the lowest road (`Track::carve`), the cliff always has its guard rail, the hill side is a cut slope.
- The flight is a fixed parabola from the lip to the landing (`Track::gapFlight`), a pure function of the zone, so the rider, the camera
  and the other phones in a LAN race all draw the same path (a remote rider in the air is recognised by `yRel = 100` and its `s`). The
  camera follows it in world space and blends back to the road camera on touchdown; the world stays built around the gorge mouth while you
  are in the air (`Skater::focusS`). Nothing can hit you up there.
- `aimJump`, the deck, its lateral windows and `kDeck` are removed.

**Sunset** (`atmosphere.cpp`, `shaders.cpp`)
- The sun, its glow, the glare and the sun-lit haze and clouds were too bright and washed the sky out. Sun disc smaller and dimmer, glow
  and glare roughly halved, haze / cloud / mountain colours a bit darker and less hot, less sheen on the asphalt.

**Cars no longer swerve for no reason** (`traffic.*`)
- Measured on the old code: 40% of all cars crossed the centre line, mostly (22 of 36) to dodge a plastic traffic cone - which the rider
  just drives through - and others to overtake slower cars or to dodge the rider. Now: cones are driven over and knocked flying, cars follow
  slower cars instead of overtaking them, they do not steer around the rider, they react to what is about 3 seconds ahead instead of 5-6,
  and the indicator comes a full second before a move. Left: boulders (the only reason to leave your half of the road). Only 11% of cars
  now cross the centre line, all for a boulder; `test_traffic` fails on anything else.

**Looks** (`skater_model.cpp`, `mesh_library.cpp`, `shaders.cpp`, `world.cpp`)
- Rider: sunset-orange jacket with navy sleeves / pants and cream trim (the old one was charcoal on dark asphalt and disappeared), helmet
  stripe in the jacket colour, glowing reflective tape, a neck gaiter tail that streams and flutters. All six rider colours are brighter.
- Board: bigger wheels, a taller deck and riser pads, a setting sun on the grip at nose and tail (gold to violet bars), a glowing tail
  light and nose light, neon underglow along both edges of the deck in the wheel colour.
- Trees: seven-tier spruces with drooping skirts and turned tiers, round autumn trees with a forked trunk and six lobes in gold / orange
  / red, new white birches with golden crowns, and green and autumn shrubs along the verge.
- Road: tar seams every 17 m, hairline cracks, patches of newer asphalt, patchy sheen, reflective road studs along the centre line,
  fallen-leaf litter and stratified rock on cliff faces.

**Tests**: `tools/test_race` (gorge zones, 255 simulated kicker jumps over different detours and speeds, slow riders only hop),
`tools/test_traffic` (new predictability checks, fail on the old traffic code), all other tests unchanged and green.

## Update 4 (from SunsetDownhill-3): sharper picture, new board / wheels / rider, race goal, cliff jumps, multiplayer sync

**Why the picture was soft (and what changed)**
- The 3D scene is drawn into an offscreen target and stretched to the screen. It used 55 / 70 / 85 / 100 % of the display
  resolution, started at 85 %, dropped a step whenever frames averaged slower than 24 ms, and a hard cap of 1920 px on the long side
  meant a typical 2400 px wide phone could never get above 80 %. Wheels and board are only a few pixels across at the chase camera,
  so a soft upscale and hard jagged edges (no multisampling, FXAA only on the middle tiers) hit them first.
- Presets are now 60 / 75 / 90 / 100 % and the cap is 2560 px. The top tier renders at the full display resolution with **4x MSAA**
  (`gl_util.*`, `renderer.*`: a multisampled twin of the scene target that is resolved into the texture the post pass reads; if the
  device can't do it the scene falls back to FXAA). The post pass has a small clamped **sharpen** that grows with the amount of upscaling.
  The governor is unchanged: it still steps down when frames get slow and back up when they are fast.

**Models** (`skater_model.cpp`, `model_kit.*`)
- New `kit::addLathe` (surface of revolution with smooth or creased normals).
- Wheels: rounded urethane tyre with shoulders and a slightly crowned tread (it was a 10-sided puck), dark groove, bright hub with an
  axle recess and a steel nut. Trucks: riser pad, rounded baseplate, tapered hanger, two coloured bushings, axle.
- Deck: concave, rounded rails, a real grip-tape top (the old one was never visible), centre and flank stripes, tip bands.
- Rider: smoother limbs and joints, lofted shoes (gum sole, toe bumper, laces, heel tab), smoother helmet, a glowing sunset badge on the
  back (the part you look at all run). Remote riders use a cheaper model (`SkaterPose::lowDetail`) and are skipped if the 16-bit index
  range of the dynamic mesh would overflow (`scene_builder.cpp`).

**Race goal (multiplayer)**
- The host picks the race length in the room (**GOAL 1 / 2 / 3 / 5 KM or ENDLESS**, default 2 km). First across the line wins; the
  standings show metres to go or the finish time; crossing the line gives FINISH banner, +500 and the results with times.
  Finish times are measured from GO on a shared clock. A rider who crashes is out (DNF) as before. Single-player stays endless.

**Cliff jumps** (`track.*`, `skater.*`, `world.*`)
- Some bends are now tight (about 55 m radius, 95-118 degrees) on stretches where the inside is the downhill side. There the road has a
  wooden **kicker** at the cliff edge (warning sign before it, no guard rail beside it). Hit it and you fly out over the cliff and land
  on a wide platform that continues as a **shortcut road on stilts** on the inside of the bend and merges back into the road.
  The inside lane covers the bend in less road: about 1 s saved on average in the tests. The board is aimed at the platform by the
  kicker (`Skater::aimJump` simulates the flight for the current speed and bend), landing on the deck gives +300, flights over 0.6 s
  give "AIR TIME", missing the deck or landing from a great height is a crash.
- Physics: height above the road (`yRel`, `vy`), flight with arcade gravity, lateral rail windows that follow the deck, terrain carved
  away under the deck so it really stands above a drop. Zones are a pure function of the seed (same on every phone) and show up about
  once a kilometre. The autopilot keeps off the kicker.

**Multiplayer: delay and sync** (`net.*`)
- Other riders used to be drawn by *arrival* time 120 ms in the past at 20 Hz, so Wi-Fi jitter and bursts of packets showed up
  directly as stutter and lag. Now every state carries the sender's race time; receivers play it back by that timestamp with a
  jitter-adaptive delay (about 60 ms on a quiet network, up to 220 ms on a bad one) and a short extrapolation. 30 updates per second.
- **Clock sync:** clients ping the host (round trip + host clock), keep the best of the last 8, and the START message carries the host's
  clock. A phone that gets START late fast-forwards its countdown by the difference, so **GO is the same moment everywhere**
  (before, each phone counted down from whenever its START packet arrived; lost packets made it worse).
- Android: a **Wi-Fi low-latency lock** (`LanSupport.kt`, `WAKE_LOCK` permission). Wi-Fi power saving batches packets and delivers
  them 100-200 ms late - a big part of "multiplayer is delayed".
- Protocol is now "SDH2" (an old build can't join a new one). New: pong, finish line distance in START, height / airborne / finish
  fields in the state. `tools/test_net` covers clock sync, goal sharing, finish reporting and playback of a burst of packets.

**Tests**: `tools/test_race` (mesh budget, cliff jump zones, 196 simulated kicker jumps, finish line, simultaneous start).

## Update 3 (from SunsetDownhill-2): HUD text, new models, drivers, LAN multiplayer

**HUD text (the "overlapping strokes / fading" problem)**
- The stroke font used to be built from many overlapping translucent quads per glyph, so any text that was not fully opaque (the
  drop shadow, the fading popups and countdown, the distance readout) showed the strokes through each other and looked patchy.
  Every glyph is now a single quad sampled from a signed-distance atlas (`ui_font.cpp`, `ui_atlas.h`): even opacity, crisp edges at
  any size, and a soft dark halo instead of the offset shadow.
- `textWidth` used to leave out the stroke thickness, so the "KM/H" label sat on top of the last digit. It now returns the exact ink
  width, and the label shares the baseline of the digits.
- `UiVertex` grew texture coordinates and a halo strength (24 bytes); the UI shader samples the atlas (`shaders.cpp`, `renderer.cpp`).

**Models**
- Rider: full-face helmet with visor, chin bar, stripe and spoiler; lofted jacket with accent band and reflective stripe; hood;
  round limbs with joint balls; knee pads; cuffs; slide gloves with pucks; skate shoes. Same rig and poses as before (`skater_model.cpp`).
  Six colour styles (one per LAN slot).
- Longboard: pintail outline with kicked nose and tail, grip tape with centre stripe, trucks (baseplate, hanger, axle, bushing) and
  glowing wheels with cores. Built once per style and re-posed with a matrix.
- Cars: five lofted body styles - sedan, hatchback, SUV, pickup, van - with wheels, rims, arches, lamps, mirrors, plates and door
  seams (`car_models.cpp`). New helpers in `model_kit.*` (loft, tube, ellipsoid); `addBlob` now caches the icosphere topology.

**Traffic**
- Cars used to drive straight through cones and rocks. `traffic.cpp` gives every car a driver: lane keeping, Intelligent Driver Model
  speed control, curve speed limit, brake lights, indicators, mirror checks, gap acceptance, steering around obstacles through free
  lanes, waiting for a gap with room to pull out, keeping clear of the rider. `tools/test_traffic`: zero overlaps with cones, rocks or
  other cars on many seeds, also with a rider weaving across both lanes.
- Cones and rocks are a pure function of the seed (cars no longer influence where they appear).

**LAN multiplayer** (see README): `net.*` (UDP protocol, polled from the game thread), `hud_mp.*` (lobby, standings, name tags,
results), engine integration, `LanSupport.kt` (multicast lock, Wi-Fi binding, device name), new permissions in the manifest.
`tools/test_net` (protocol, spoofing, garbage) and `tools/test_mp_engine` (three engines play a race through the lobby screens).

**Tools**: `test_traffic`, `test_net`, `test_mp_engine`, `render_models`, `render_traffic`, `render_lan`; `dump_ui` renders the font sheet
and the LAN screens.
