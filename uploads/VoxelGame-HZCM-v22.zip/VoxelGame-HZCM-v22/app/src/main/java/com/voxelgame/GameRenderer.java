package com.voxelgame;

import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.opengl.GLSurfaceView;
import android.util.Log;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;
import java.io.IOException;
import java.io.InputStream;

public class GameRenderer implements GLSurfaceView.Renderer {

    private static final String TAG = "VoxelAtlas";

    static {
        System.loadLibrary("voxelgame");
    }

    // ── Atlas tile names ───────────────────────────────────────────────────────
    // Index matches ATLAS_TILE[48] LUT in the vertex shader.
    // Files go in:  app/src/main/assets/textures/<name>
    // Missing files fall back to the procedural tile generated in TextureAtlas.h.
    private static final String[] TILE_NAMES = {
        null,             //  0  debug      (never override — keep magenta sentinel)
        "grass_top.png",  //  1  grass top
        "grass_side.png", //  2  grass side
        "dirt.png",       //  3  dirt
        "stone.png",      //  4  stone
        "sand.png",       //  5  sand
        "snow_top.png",   //  6  snow top
        "snow_side.png",  //  7  snow side
        "wood_side.png",  //  8  wood bark (side)
        "wood_top.png",   //  9  wood rings (top/bottom)
        "leaves.png",     // 10  leaves
        "water.png",      // 11  water
        "gravel.png",     // 12  gravel
        "red_sand.png",   // 13  red sand / terracotta
        "clay.png",       // 14  clay
        "ice.png",        // 15  ice
        "cactus_side.png",// 16  cactus side
        "cactus_top.png", // 17  cactus top
        "basalt.png",     // 18  basalt
        "cobble.png",     // 19  cobble
    };

    private final AssetManager assetManager;

    public GameRenderer(AssetManager assetManager) {
        this.assetManager = assetManager;
    }

    // ── GLSurfaceView.Renderer ─────────────────────────────────────────────────
    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        nativeInit();         // creates GL context, uploads procedural atlas
        loadAtlasTiles();     // replaces layers that have real PNG files
    }

    @Override
    public void onSurfaceChanged(GL10 gl, int width, int height) {
        nativeResize(width, height);
    }

    @Override
    public void onDrawFrame(GL10 gl) {
        nativeRender();
    }

    // ── PNG → atlas upload ─────────────────────────────────────────────────────
    // For each tile slot that has a filename, try to load the PNG from assets.
    // Decode → scale to 16×16 → convert ARGB→RGBA → upload via nativeSetAtlasTile.
    // Missing or malformed files are silently skipped (procedural tile is kept).
    private void loadAtlasTiles() {
        int loaded = 0;
        for (int i = 0; i < TILE_NAMES.length; i++) {
            if (TILE_NAMES[i] == null) continue;

            String path = "textures/" + TILE_NAMES[i];
            InputStream is = null;
            try {
                is = assetManager.open(path);
                Bitmap bmp = BitmapFactory.decodeStream(is);
                if (bmp == null) { Log.w(TAG, "Decode failed: " + path); continue; }

                // Scale to 16×16 if the source is larger (e.g. 32×32 assets)
                if (bmp.getWidth() != 16 || bmp.getHeight() != 16) {
                    Bitmap scaled = Bitmap.createScaledBitmap(bmp, 16, 16, false);
                    bmp.recycle();
                    bmp = scaled;
                }

                // Android stores pixels as ARGB_8888 — reorder to RGBA for OpenGL
                int[] argb = new int[256];
                bmp.getPixels(argb, 0, 16, 0, 0, 16, 16);
                bmp.recycle();

                byte[] rgba = new byte[256 * 4];
                for (int p = 0; p < 256; p++) {
                    int px = argb[p];
                    rgba[p * 4    ] = (byte)((px >> 16) & 0xFF); // R
                    rgba[p * 4 + 1] = (byte)((px >>  8) & 0xFF); // G
                    rgba[p * 4 + 2] = (byte)((px      ) & 0xFF); // B
                    rgba[p * 4 + 3] = (byte)((px >> 24) & 0xFF); // A
                }

                nativeSetAtlasTile(i, rgba);
                loaded++;
                Log.i(TAG, "Loaded tile " + i + " from " + path);

            } catch (IOException e) {
                // File not in assets yet — procedural fallback stays
            } finally {
                if (is != null) try { is.close(); } catch (IOException ignored) {}
            }
        }
        Log.i(TAG, "Atlas: " + loaded + "/" + (TILE_NAMES.length - 1) + " tiles loaded from assets");
    }

    // ── JNI declarations ──────────────────────────────────────────────────────
    public native void nativeInit();
    public native void nativeResize(int width, int height);
    public native void nativeRender();

    // Upload one 16×16 RGBA tile into the live GL_TEXTURE_2D_ARRAY atlas.
    // Must be called from the GL thread (inside onSurfaceCreated).
    public native void nativeSetAtlasTile(int tileIdx, byte[] rgbaBytes);
}
