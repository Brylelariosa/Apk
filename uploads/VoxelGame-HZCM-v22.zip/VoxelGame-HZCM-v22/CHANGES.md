# VoxelGame HZCM — Changelog

## v21  (texture atlas + biome overhaul)

### Texture Atlas (new feature)
- **Replaced** flat BLOCK_COL vec3 LUT with a real `GL_TEXTURE_2D_ARRAY` atlas.
- **20 layers × 16×16 RGBA8** pixel-art tiles generated procedurally at startup
  by the new `TextureAtlas.h` header (no external image files required).
- **Per-face tile assignment** via `ATLAS_TILE[blockType*3 + faceGroup]` LUT in
  the vertex shader — top / side / bottom faces get distinct tiles for every block.
- **Correct faces** for every block type:
  - Grass: green top, dirt-with-green-strip side, dirt bottom
  - Wood: bark-grain side, wood-ring top/bottom
  - Snow: bright-white top, cool-gray sides
  - Cactus: ribbed green side, cross-pattern top
  - Cobble: grout-line stone pattern
  - Stone, sand, gravel, red sand, clay, ice, basalt, water, leaves — all distinct
- **Greedy-mesh tiling**: `vRawUV = (cs, ct)` passed as unnormalized block-space
  coordinates (0..span0, 0..span1).  `GL_REPEAT` on the sampler tiles the 16×16
  tile once per block across any greedy-merged span with zero extra work.
- **Nearest-neighbour filtering** (`GL_NEAREST`) for crisp pixel-art look.
- **No texture bleeding** — each layer in the array is independent; GL_REPEAT
  wraps within that layer only, so atlas tiles can never bleed into each other.
- **AO and fog preserved** unchanged — vLight carries the combined factor.

### Biome Quality Improvements
- **Smooth biome gradients**: temperature and humidity now use 2-octave fbm at
  lower spatial frequency (0.0022 / 0.0028) instead of single noise2D calls.
  Biome regions are now large and smoothly varying instead of noisy patches.
- **Wider transition bands**: dithering increased from ±0.04 to ±0.06 combined
  with lower-frequency fbm creates 5-8 block wide blending zones vs old 3-4.
- **Tundra biome** (new): intermediate cold-grass zone (tN ∈ [0.24, 0.40]) with
  very sparse tree coverage — transitions snow ↔ temperate more naturally.
- **Shoreline smoothing**: height within ±4 blocks of sea level is pulled toward
  sea level by a quartic blend, eliminating abrupt beach cliffs and producing
  gentle sloping shores.
- **Valley floor materialisation**: high-erosion flat areas near sea level now
  place gravel in the sub-surface layer instead of stone, matching riverbeds.
- **Badlands** logic unchanged but better-looking due to smoother climate maps.

### Renderer Changes
- `TextureAtlas.h` added — procedural pixel-art generator, included by Renderer.cpp.
- `Renderer.h`: added `m_atlasTexture`, `m_uAtlas`, `initAtlas()`.
- `Renderer::init()`: calls `initAtlas()` after megabuffer init; sets `uAtlas=0`.
- `Renderer::render()`: binds atlas to `GL_TEXTURE0` before cluster draw pass.
- `Renderer::~Renderer()`: deletes atlas texture on teardown.
- Vertex shader: BLOCK_COL LUT removed; ATLAS_TILE LUT + vTexLayer + vRawUV added.
- Fragment shader: samples `sampler2DArray uAtlas`; applies lighting × fog.

### No Breaking Changes
- PackedFace format unchanged (geom + mat, 8 bytes).
- MegaBuffer, DrawBatcher, ClusterMesher all unchanged.
- Chunk loading, streaming, upload pipeline, render-distance system unchanged.
- Block types, Block.h unchanged.
- All v20 stability fixes (watchdog, retry queue, graveyard, thermal) intact.

---

## v20  (terrain + block-type expansion)
(see previous CHANGES.md)
