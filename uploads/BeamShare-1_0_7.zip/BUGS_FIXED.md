# BUGS_FIXED

**No compiler or device is available in this sandbox, for any pass.** Every fix
below was verified by hand-tracing the exact code path against Android's
documented API behavior, and by static checks (brace/paren balance, grep for
orphaned references, XML validation) - not by an actual build or a real WiFi
Direct exchange. Said plainly per fix, not just here, since fixes across
passes carry different levels of confidence.

---

## 1.0.6

No bug was reported for this pass: the request was to make the app work and
improve the UI. Everything below was found by reading the pairing and transfer path
end to end, so each item states how sure it is. Several are certain from the code
alone (marked **certain**); the WiFi Direct framework behaviours are from knowledge
of AOSP and are marked **likely** where no device was available to confirm.

### 1. "Send an app" listed almost no apps

**Category:** Bug fix (root cause) - **certain**
**Files modified:** `Apps.kt`
**Problem:** `queryIntentActivities(launcherIntent, MATCH_DEFAULT_ONLY)` only returns
activities whose intent filter also declares `CATEGORY_DEFAULT`. Launcher activities
almost never do, so the Apps tab was empty or nearly so.
**Fix:** flags `0` (the `ResolveInfoFlags` overload on API 33+). Icons are now drawn at
96px instead of the launcher's full 108dp canvas, which matters with 150+ apps.

### 2. First connection attempt could fail purely on timing

**Category:** Bug fix (root cause) - **likely**
**Files modified:** `GroupSocket.kt` (new), `SessionManager.kt`
**Problem:** the client end made exactly one `connect()` the moment the link formed,
with no retry. The group owner only starts listening once *its* link callback fires,
and the client usually has no IP address yet for a moment, so "connection refused" or
"network unreachable" on the first try is a normal outcome, not an edge case. Separately,
the owner's `ServerSocket.accept()` had no timeout and ran inside `withContext`, which
cannot interrupt a blocking call: a timeout or cancellation left the port bound and a
dead listener waiting for the next connection.
**Fix:** the client retries every 400ms until a deadline; the owner polls `accept()` in
one-second slices so cancellation is honoured and the socket is always closed.

### 3. QR pairing connected to an address Android doesn't give out

**Category:** Bug fix (root cause) - **likely**
**Files modified:** `QrCode.kt`, `DiscoverViewModel.kt`, `WifiDirectManager.kt`
**Problem:** the code encoded the receiver's own `WifiP2pDevice.deviceAddress`. From
Android 10 the framework reports a placeholder (`02:00:00:00:00:00`) for a device's own
address to apps without a system permission, and `connect()` can only reach a peer the
framework has already discovered. Scanning therefore asked the framework to connect to
something it had never seen, which fails silently - the app then waited on "Connecting".
**Fix:** the code now carries the device name (and the MAC only if it is real). Scanning
keeps discovery running, waits until a discovered peer matches, and connects with the
address the *scanner* discovered. If nothing matches within 25 seconds it says so.

### 4. Discovery needs Location switched on for Android 12 and older

**Category:** Bug fix - **likely**
**Files modified:** `PermissionHelper.kt`, `ReadinessGate.kt` (new), `Discover`/`Receive` screens
**Problem:** before Android 13 the framework only answers WiFi Direct discovery while
the Location switch is on, even with the permission granted. The old code checked only
the permission, so the symptom was an empty device list or a vague "error 0". This is
the likeliest cause of "it just doesn't find the other phone" on an Android 11 device.
**Fix:** a readiness gate checks permission, WiFi and (below Android 13) Location,
lists whatever is missing with a button for each, and re-checks when the user returns.

### 5. Consent was one-sided and cosmetic

**Category:** Bug fix (design) - **certain**
**Files modified:** `TransferProtocol.kt`, `TransferSession.kt`, `SessionManager.kt`
**Problem:** the sender moved to "Connected" as soon as the peer's greeting arrived, and
the receiver's session accepted every offer immediately, regardless of whether its user
had tapped Accept yet. Files could be saved before the prompt was answered.
**Fix:** protocol v2 adds READY. The receiver refuses offers until its user accepts,
then sends READY; the sender shows "Waiting for approval" until it arrives. A peer on
protocol v1 gets an explicit "update both phones" message instead of a hang.

### 6. "Connecting..." could spin forever

**Category:** Bug fix - **certain** for the missing timeout, **likely** for decline detection
**Files modified:** `WifiDirectManager.kt`, `DiscoverDevicesScreen.kt`
**Problem:** there was no timeout and no cancel, and the framework gives no "declined"
callback.
**Fix:** 60-second timeout; a peer that shows INVITED and then drops back to AVAILABLE or
FAILED is treated as declined; every connecting state has a Cancel button.

### 7. Transfer integrity

**Category:** Bug fix - **certain**
**Files modified:** `TransferSession.kt`, `FileRepository.kt`
**Problem:** (a) an item whose size the provider didn't report was offered as 0 bytes
while its real bytes were still sent, corrupting everything after it on the stream;
(b) a connection dropping mid-file ended the read loop and the file was still marked
completed; (c) partial files stayed in Downloads; (d) a failure while *creating* the
destination killed the whole session instead of just that file.
**Fix:** size comes from the descriptor, or the file is staged to cache to measure it;
both ends move exactly the offered number of bytes; a short read fails the file and
deletes the partial; if a destination can't be created the incoming bytes are drained
so the rest of the session continues.

### 8. WiFi Direct command handling

**Category:** Bug fix (hardening) - **likely**
**Files modified:** `WifiDirectManager.kt`
**Problem:** the framework answers BUSY not only to overlapping calls but while it is
mid-negotiation from an earlier connect; one stuck command blocked all later ones;
discovery stopped on its own and was never restarted; a group left by a previous run
could confuse the next connect; the P2P channel being lost was unhandled.
**Fix:** one FIFO queue with a per-command watchdog; BUSY on connect clears our own
half-finished attempt and retries, BUSY on discovery just waits (cancelling there could
kill an incoming connection); discovery is re-armed while wanted and not negotiating;
stale groups are removed at start; a lost channel is reported.

### 9. Session lifecycle

**Category:** Bug fix - **certain**
**Files modified:** `SessionManager.kt`, `ConnectedSessionScreen.kt`, `BeamNavHost.kt`
**Problem:** Back from a live session popped to Home with the session still running and
no way back to it; the session didn't notice the link dropping until a socket error;
sending depended on a composable's coroutine scope.
**Fix:** Back asks to disconnect; losing the link ends the session with a message;
sending runs in the app scope; leaving a pairing screen (ViewModel cleared) releases
WiFi Direct and lets the foreground service stop.

### 10. QR scanner

**Category:** Bug fix - **certain**
**Files modified:** `QrScannerScreen.kt`
**Problem:** the first QR code seen ended scanning even if it wasn't BeamShare's, so one
stray code left the screen dead; the camera-denied message was white text on a possibly
light background; the ML Kit scanner and executor were never released.
**Fix:** only a valid BeamShare code ends scanning (anything else shows a hint); the
screen is always dark; resources are released on dispose; torch toggle added.

### Not verified

No compiler, SDK or device was available. In addition to the usual hand-tracing, this
pass ran a script over every Kotlin file for brace balance, unresolved `R.*` references,
unresolved project imports and `stringResource` argument counts, validated all XML, and
rendered every vector icon and the launcher icon to check their shapes. None of that
replaces a build. See KNOWN_LIMITATIONS.md.

---

## 1.0.5

Two bugs reported directly, both regressions on top of behavior 1.0.4 had
already touched: "WiFi Direct is busy" still appearing specifically after a
QR scan (1.0.4 addressed BUSY generically but not this exact trigger), and
the "session active" notification outliving the app being closed.

### 1. "WiFi Direct is busy" still appears after scanning a QR code

**Category:** Bug fix (root cause)
**Files modified:** `DiscoverDevicesScreen.kt`, `WifiDirectManager.kt`
**Problem:** The 1.0.4 pass added BUSY retry handling and a same-call
redundant-discovery guard, but this report's actual trigger was different and
more specific. Returning from the QR scanner (`navController.popBackStack()`)
recreates `DiscoverDevicesScreen`'s composition from scratch, since plain
`remember` state doesn't survive a composable leaving and re-entering
composition. That means `hasPermission` re-initializes to `true` (permission
was already granted) and `qrPayloadToConnect` is simultaneously non-null - so
`LaunchedEffect(hasPermission)` (calls `startDiscovery()`) and
`LaunchedEffect(qrPayloadToConnect)` (calls `connectToQrPayload()`, itself
`stopDiscovery()` + `connectToAddress()`) both fire in the same recomposition.
Three P2P commands (`discoverPeers`, `stopPeerDiscovery`, `connect`) landed on
`WifiP2pManager` back-to-back, before the first one's callback could return -
which is exactly what BUSY means ("still processing your last command").
Worse, `startDiscovery()` and `connectToAddress()` both retry on BUSY using
the *same* 1.2s delay, started at the *same* instant, so their retries kept
landing in the same window and re-colliding - explaining why it kept
happening instead of resolving after one retry.
**Solution:** One change per layer. `DiscoverDevicesScreen` now skips
re-arming discovery in that effect when a QR payload is already queued to
connect to - no reason to start general discovery right as a specific connect
is about to happen. As defense in depth for any other call path,
`WifiDirectManager` now funnels every `discoverPeers`/`stopPeerDiscovery`/
`connect`/`removeGroup` call through a single in-flight gate, so a second
command issued while one is still awaiting its callback is queued instead of
dispatched concurrently.
**Reason:** Direct report ("i scan qr code but still say wifi direct is
busy") - the same user-facing message 1.0.4 addressed, from a different,
previously-untraced trigger.
**Expected improvement:** Connecting via QR should no longer produce BUSY
under normal conditions - the redundant discovery call this path used to
issue is gone, and even a future path that races two commands now queues
instead of colliding.
**Side effects:** None to the happy path. A command issued while another is
still in flight now waits for that command's callback (typically well under
a second) instead of firing immediately.
**Verification:** No compiler/device. Traced end to end from
`QrScannerScreen`'s result callback through `BeamNavHost` to
`DiscoverDevicesScreen`'s effects to `DiscoverViewModel` to
`WifiDirectManager` - two effects racing on screen re-entry is a genuine,
reproducible-on-paper gap. Stronger confidence than 1.0.4's fix for this same
message, since it identifies the actual colliding commands rather than
defending against BUSY generically - but per this project's standing caveat,
"reasoned through by reading every line" and "watched it happen on two real
phones" remain different confidence levels.

### 2. "BeamShare session active" notification stays after closing the app

**Category:** Bug fix (root cause)
**Files modified:** `BeamShareService.kt`, `DiscoverDevicesScreen.kt`,
`ReceiveScreen.kt`
**Problem:** `BeamShareService.start()` fires as soon as the Discover or
Receive screen opens, to prepare for a session before one exists. The service
only ever stops itself in response to `SessionState.Disconnected` - but
`Disconnected` is a "was connected, now isn't" state; a session that never
connected in the first place stays at `SessionState.None` forever, which
`observeSession()` doesn't treat as a stop signal. Nothing else in the app
called `BeamShareService.stop()`, and there was no `onTaskRemoved()`
override. So: open Discover or Receive, don't connect, close the app - the
foreground service (and its notification) has no path to ever stop.
**Solution:** Two changes. `BeamShareService` now overrides `onTaskRemoved()`
to call `SessionManager.disconnect()` when the app is removed from Recents -
`disconnect()` already flips `sessionState` to `Disconnected` unconditionally
(safe to call from `None`; it no-ops cleanly on a session that never formed),
and the existing `observeSession()` already stops the service on that
transition, so this reuses that path instead of duplicating it. Separately,
`DiscoverDevicesScreen` and `ReceiveScreen` now stop the service directly
when they leave composition (back button, not full app close) unless a
session actually reached `Connected` - covering backing out to Home without
closing the app, at any point before or during connecting.
**Reason:** Direct report ("even if the app already close it still appear on
my notifications beamshare session active").
**Expected improvement:** The notification should now clear both when
backing out of Discover/Receive without connecting, and when removing the
app from Recents at any point before a session forms.
**Side effects:** None to an active session - `onTaskRemoved()` deliberately
does end an in-progress session too (a WiFi Direct transfer has no good
reason to keep running once the app is fully closed on this end), but a
session already `Connected` and showing in `ConnectedSessionScreen` is
unaffected, since forward navigation into that screen only happens once
`sessionState` has already reached `Connected` - the one case the two
screens' dispose-time check deliberately excludes.
**Verification:** No compiler/device. `stopWithTask` isn't set on the
service's manifest entry, and a started service isn't stopped on task removal
by default without it or an `onTaskRemoved()` override - the latter is the
standard, documented mechanism for exactly this. Confirmed by grepping every
call site of `BeamShareService.start`/`stop` (two starts, zero stops, before
this fix) and every `SessionState` transition in `SessionManager.kt` to
confirm `None` truly has no path to `Disconnected` on its own.

---

## 1.0.4

Three bugs reported directly: QR scanner opening to a black screen, the
Receive screen never showing a QR code to scan, and WiFi Direct
reporting "busy." All three were real, all three were in the WiFi
Direct/camera plumbing rather than anything cosmetic, and none needed a
build log this time - these are runtime/logic bugs a compiler can't
catch, found by reading the actual code paths end to end.

### 1. QR scanner opens to a black screen

**Category:** Bug fix (root cause)
**Files modified:** `QrScannerScreen.kt`
**Problem:** Nothing in the app ever requested `CAMERA` permission.
`QrScannerScreen`'s own doc comment even said "assumes camera permission
is already granted by the caller" - but no caller ever actually granted
it; `DiscoverDevicesScreen`'s "Scan QR code" button navigated straight
here with zero permission handling. Without it, `bindToLifecycle()`
throws, and that throw was going into a bare `runCatching {}` with no
`onFailure` handler at all - silently swallowed, leaving `PreviewView`
with no camera feed and nothing on screen to explain why.
**Solution:** Two changes. `QrScannerScreen` now owns its own permission
check and request flow (rather than trusting a caller that never
actually gated it) - it requests `CAMERA` on first composition, shows a
rationale/retry state if denied, and an "Open settings" fallback if
denied permanently (the system won't show the permission dialog again
after that). Separately, `CameraPreviewWithAnalysis`'s `runCatching`
around the bind call now has an `onFailure` that surfaces a real
"camera couldn't start" message instead of a silent no-op - so even a
*different* bind failure (no back camera, camera already claimed by
another app) is visible instead of another black screen with no
explanation.
**Reason:** Direct report ("the scan is black i think camera doesn't
work on app").
**Expected improvement:** The scanner should now either show a live
camera preview, or a clear reason why it can't - never a silent black
screen either way.
**Side effects:** None to the happy path - once permission is granted,
behavior is unchanged. Denying permission now shows UI instead of
nothing, which is strictly more informative, not a regression.
**Verification:** No compiler/device. Confirmed `PermissionHelper` didn't
already have camera-permission-request wiring anywhere upstream of this
screen (grepped every call site of `Manifest.permission.CAMERA` and
`hasCameraPermission` before this fix - `hasCameraPermission()` existed
in `PermissionHelper` but was never actually called from anywhere, a
half-built check with no request flow attached to it). This is about as
confident as a fix gets without a device: a missing permission request is
a definite gap, not a guess, and `ActivityResultContracts.RequestPermission()`
is the same standard pattern already used for the nearby-devices
permission elsewhere in this app.

---

### 2. Receive screen never shows its own QR code

**Category:** Bug fix (root cause)
**Files modified:** `WifiDirectManager.kt`
**Problem:** `thisDevice` (what the QR code encodes) was populated
*only* by `WIFI_P2P_THIS_DEVICE_CHANGED_ACTION` - a broadcast that fires
on a **change**, not as an on-demand "here's the current state" query.
If WiFi Direct was already active before this app's receiver registered
(WiFi already on, or another app had already initialized P2P earlier),
there may be no subsequent "change" event to fire it at all - leaving
`thisDevice` at its initial `null` forever, and the Receive screen
showing its loading spinner indefinitely instead of a QR code.
**Solution:** Added an active query. `requestDeviceInfo()` (API 29+) is
now called directly after the channel initializes, and again whenever
`WIFI_P2P_STATE_CHANGED_ACTION` confirms P2P just turned on - two real
chances to populate `thisDevice` instead of depending entirely on a
broadcast that may never come. Pre-API 29 has no equivalent direct-query
API and still depends on the broadcast alone; see KNOWN_LIMITATIONS.md.
**Reason:** Direct report ("no qr to scan on receiver").
**Expected improvement:** The QR code should now appear promptly on
devices running API 29+ (Android 10, the large majority of real
devices) regardless of whether WiFi Direct was already active before
the app opened.
**Side effects:** None - this only adds an additional way `thisDevice`
gets populated; the existing broadcast-based path is untouched and
still runs alongside it.
**Verification:** No compiler/device. `requestDeviceInfo()`'s existence
and signature (added API 29, takes a `Channel` and a
`DeviceInfoListener`) checked against the same `WifiP2pManager` API
family the rest of this file already uses correctly (`requestPeers`,
`requestConnectionInfo` - both same shape, both already working code in
this file). The "broadcast fires on change, not on query" distinction is
standard, well-documented Android broadcast-receiver behavior, not
specific to this API - the same reasoning applies to why apps generally
need a "request current state" call *and* a change listener, not one or
the other, for any sticky-feeling state.

---

### 3. "WiFi Direct is busy"

**Category:** Bug fix (robustness / retry handling)
**Files modified:** `WifiDirectManager.kt`
**Problem:** Two contributing gaps. First, nothing prevented
`startDiscovery()` from being called again while a previous call was
still being processed by the framework - a real path to this exists:
last pass's Receive-screen fix re-arms waiting
(`viewModel.startWaiting()`) on `SessionState.Disconnected`, and if that
fires while an earlier `discoverPeers()` call hasn't been acknowledged
yet, the second call can get rejected as `BUSY`. Second, and separately,
`BUSY` was always treated as a terminal error requiring the user to
manually retry - but per Android's own documented behavior, `BUSY`
specifically means "the framework is still finishing your last command,"
which is often true for a very short window and resolves itself, not a
real failure needing user intervention.
**Solution:** `startDiscovery()` now no-ops if a discovery request is
already in flight (`isDiscovering` guard), closing the redundant-call
path directly. Separately, both `startDiscovery()` and
`connectToAddress()` now auto-retry once (up to 3 times, ~1.2s apart)
specifically on `BUSY` before surfacing it as a user-facing error -
transient busy states resolve without ever bothering the user; a
genuinely stuck state still surfaces the existing error/retry UI after
the retry budget is spent.
**Reason:** Direct report ("it say wifi direct is busy").
**Expected improvement:** The busy message should now be rare -
appearing only if the framework is still busy after ~3.6 seconds of
retrying, rather than on the first transient collision.
**Side effects:** A `BUSY` failure now takes up to ~3.6s longer to
surface as a visible error than before (the retry window) - deliberate;
that's strictly better than showing an error for something that would
have resolved on its own a moment later.
**Verification:** No compiler/device. This is the fix I'm least certain
pins the *exact* trigger the report describes, since there's no
attached log for this one (unlike the two build-log-driven passes
before it) - the redundant-discovery-call path is a real, traceable gap
this codebase had (confirmed by reading `ReceiveScreen`'s own
re-arm-on-disconnect logic added last pass), and the BUSY-specific
retry is correct, defensive handling regardless of whether that's the
exact path that produced this specific report. See
KNOWN_LIMITATIONS.md.
