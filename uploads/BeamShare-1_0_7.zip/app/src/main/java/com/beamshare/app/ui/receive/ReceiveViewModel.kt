package com.beamshare.app.ui.receive

import androidx.lifecycle.ViewModel
import com.beamshare.app.core.discovery.WifiDirectManager
import com.beamshare.app.core.model.PeerDevice
import com.beamshare.app.core.model.SessionState
import com.beamshare.app.core.transfer.SessionManager
import com.beamshare.app.core.transfer.SessionRole
import kotlinx.coroutines.flow.StateFlow

class ReceiveViewModel(
    private val wifiDirectManager: WifiDirectManager,
    private val sessionManager: SessionManager
) : ViewModel() {

    val thisDevice: StateFlow<PeerDevice?> = wifiDirectManager.thisDevice
    val sessionState: StateFlow<SessionState> = sessionManager.sessionState

    /** Makes this phone discoverable and starts listening for a link. Safe to call repeatedly. */
    fun startWaiting() {
        wifiDirectManager.start()
        sessionManager.watchForLink(SessionRole.RECEIVER)
        wifiDirectManager.startDiscovery() // keeps this device in an actively-discoverable P2P state
        wifiDirectManager.requestThisDeviceInfo()
    }

    fun accept() = sessionManager.acceptIncoming()

    fun decline() = sessionManager.declineIncoming()

    override fun onCleared() {
        // Leaving the screen without a live session: release WiFi Direct and let the service stop.
        sessionManager.cancelPairing()
    }
}
