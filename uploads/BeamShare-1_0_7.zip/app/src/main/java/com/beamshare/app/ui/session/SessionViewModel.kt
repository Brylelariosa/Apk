package com.beamshare.app.ui.session

import androidx.lifecycle.ViewModel
import com.beamshare.app.core.model.SessionState
import com.beamshare.app.core.model.TransferItem
import com.beamshare.app.core.model.TransferProgress
import com.beamshare.app.core.transfer.SessionManager
import kotlinx.coroutines.flow.StateFlow

class SessionViewModel(private val sessionManager: SessionManager) : ViewModel() {

    val sessionState: StateFlow<SessionState> = sessionManager.sessionState
    val progress: StateFlow<List<TransferProgress>> = sessionManager.progress

    /** Queues [items] for sending. The manager runs the transfer in the app scope, so it outlives this screen. */
    fun sendItems(items: List<TransferItem>) = sessionManager.sendItems(items)

    fun disconnect() = sessionManager.disconnect()
}
