package com.beamshare.app.core.apps

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import com.beamshare.app.core.model.TransferItem
import java.io.File

data class InstalledApp(
    val packageName: String,
    val label: String,
    val icon: ImageBitmap,
    val apkPath: String,
    val apkSizeBytes: Long,
    /** App-bundle installs ship extra split APKs that this app doesn't send, so the base APK alone may not install. */
    val isSplit: Boolean = false
)

/** Enumerates user-launchable apps for the "send an app" picker. */
class InstalledAppsRepository(private val context: Context) {

    fun launchableApps(): List<InstalledApp> {
        val pm = context.packageManager
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val selfPackage = context.packageName
        // Flags are deliberately 0. MATCH_DEFAULT_ONLY would drop every launcher activity that
        // doesn't also declare CATEGORY_DEFAULT - which is nearly all of them - leaving the list empty.
        val resolved = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.queryIntentActivities(launcherIntent, PackageManager.ResolveInfoFlags.of(0L))
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(launcherIntent, 0)
        }
        return resolved
            .asSequence()
            .map { it.activityInfo.applicationInfo }
            .distinctBy { it.packageName }
            .filter { it.packageName != selfPackage }
            .mapNotNull { it.toInstalledApp(pm) }
            .sortedBy { it.label.lowercase() }
            .toList()
    }

    private fun ApplicationInfo.toInstalledApp(pm: PackageManager): InstalledApp? {
        val apkFile = sourceDir?.let(::File) ?: return null
        if (!apkFile.exists()) return null
        return InstalledApp(
            packageName = packageName,
            label = loadLabel(pm).toString(),
            icon = loadIcon(pm).toImageBitmap(),
            apkPath = apkFile.absolutePath,
            apkSizeBytes = apkFile.length(),
            isSplit = !splitSourceDirs.isNullOrEmpty()
        )
    }
}

/**
 * Sends the base APK only (not split/config APKs from app-bundle installs). That installs fine for
 * single-APK apps - including debug and side-loaded builds - but not for most Play Store apps,
 * which is why the picker flags split apps.
 */
fun InstalledApp.toTransferItem(): TransferItem = TransferItem(
    displayName = "$label.apk",
    sizeBytes = apkSizeBytes,
    mimeType = "application/vnd.android.package-archive",
    sourceFilePath = apkPath,
    isApk = true,
    packageName = packageName
)

/** Launches the system installer for a received APK; the user still confirms the install. */
object ApkInstaller {
    fun installIntent(apkUri: Uri): Intent = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(apkUri, "application/vnd.android.package-archive")
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
}

/** Icons are drawn at list size, not at the launcher's full 108dp canvas - 150 of those add up fast on a 4GB phone. */
private const val ICON_SIZE_PX = 96

private fun Drawable.toImageBitmap(): ImageBitmap {
    val bitmap = Bitmap.createBitmap(ICON_SIZE_PX, ICON_SIZE_PX, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    setBounds(0, 0, ICON_SIZE_PX, ICON_SIZE_PX)
    draw(canvas)
    return bitmap.asImageBitmap()
}
