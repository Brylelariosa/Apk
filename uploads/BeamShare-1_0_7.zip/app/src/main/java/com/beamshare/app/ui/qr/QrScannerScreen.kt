package com.beamshare.app.ui.qr

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.util.Size
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.beamshare.app.R
import com.beamshare.app.core.qr.ConnectPayload
import com.beamshare.app.ui.components.BeamPrimaryButton
import com.beamshare.app.ui.theme.BeamBlueLight
import com.beamshare.app.ui.util.OnResumeEffect
import com.beamshare.app.util.PermissionHelper
import com.google.mlkit.vision.barcode.BarcodeScanner
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import kotlinx.coroutines.delay
import java.util.concurrent.Executors

@Composable
fun QrScannerScreen(
    onResult: (ConnectPayload) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    var hasResult by remember { mutableStateOf(false) }
    var invalidCode by remember { mutableStateOf(false) }
    val currentOnResult by rememberUpdatedState(onResult)
    val context = LocalContext.current

    var hasCameraPermission by remember { mutableStateOf(PermissionHelper.hasCameraPermission(context)) }
    var permissionWasRequested by remember { mutableStateOf(false) }
    var bindFailed by remember { mutableStateOf(false) }
    var camera by remember { mutableStateOf<Camera?>(null) }
    var torchOn by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        hasCameraPermission = granted
        permissionWasRequested = true
    }

    LaunchedEffect(Unit) {
        if (!hasCameraPermission) permissionLauncher.launch(Manifest.permission.CAMERA)
    }
    LaunchedEffect(invalidCode) {
        if (invalidCode) {
            delay(2_500)
            invalidCode = false
        }
    }
    // Coming back from Settings after enabling the permission there.
    OnResumeEffect { hasCameraPermission = PermissionHelper.hasCameraPermission(context) }

    // The camera screen is always dark, so its text and controls are always light.
    Box(modifier.fillMaxSize().background(Color.Black)) {
        when {
            hasCameraPermission && !bindFailed -> {
                CameraPreviewWithAnalysis(
                    modifier = Modifier.fillMaxSize(),
                    onBarcodeDetected = { value ->
                        if (!hasResult) {
                            // Only a BeamShare code ends the scan; anything else (a URL, a ticket...)
                            // just shows a hint, so one stray code can't leave the scanner dead.
                            val payload = ConnectPayload.decode(value)
                            if (payload != null) {
                                hasResult = true
                                currentOnResult(payload)
                            } else {
                                invalidCode = true
                            }
                        }
                    },
                    onCameraReady = { camera = it },
                    onBindFailed = { bindFailed = true }
                )
                ScannerOverlay(modifier = Modifier.fillMaxSize())
                HintPill(
                    text = stringResource(if (invalidCode) R.string.qr_invalid_code else R.string.qr_scan_hint),
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .navigationBarsPadding()
                        .padding(32.dp)
                )
            }
            else -> CameraUnavailableNotice(
                deniedPermanently = permissionWasRequested && !hasCameraPermission,
                bindFailed = bindFailed,
                onRequestAgain = { permissionLauncher.launch(Manifest.permission.CAMERA) },
                onOpenSettings = {
                    runCatching {
                        context.startActivity(
                            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                                .setData(Uri.fromParts("package", context.packageName, null))
                        )
                    }
                },
                modifier = Modifier.align(Alignment.Center).fillMaxWidth().padding(32.dp)
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth().statusBarsPadding().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            ScannerIconButton(
                icon = ImageVector.vectorResource(R.drawable.ic_arrow_back),
                contentDescription = stringResource(R.string.action_back),
                onClick = onClose
            )
            if (camera?.cameraInfo?.hasFlashUnit() == true) {
                ScannerIconButton(
                    icon = ImageVector.vectorResource(R.drawable.ic_flash),
                    contentDescription = stringResource(R.string.qr_torch),
                    highlighted = torchOn,
                    onClick = {
                        torchOn = !torchOn
                        camera?.cameraControl?.enableTorch(torchOn)
                    }
                )
            }
        }
    }
}

@Composable
private fun ScannerIconButton(
    icon: ImageVector,
    contentDescription: String,
    onClick: () -> Unit,
    highlighted: Boolean = false
) {
    FilledIconButton(
        onClick = onClick,
        colors = IconButtonDefaults.filledIconButtonColors(
            containerColor = if (highlighted) BeamBlueLight else Color.Black.copy(alpha = 0.45f),
            contentColor = Color.White
        )
    ) {
        Icon(icon, contentDescription = contentDescription)
    }
}

@Composable
private fun HintPill(text: String, modifier: Modifier = Modifier) {
    Text(
        text = text,
        color = Color.White,
        style = MaterialTheme.typography.bodyMedium,
        textAlign = TextAlign.Center,
        modifier = modifier
            .background(Color.Black.copy(alpha = 0.55f), CircleShape)
            .padding(horizontal = 18.dp, vertical = 10.dp)
    )
}

@Composable
private fun CameraUnavailableNotice(
    deniedPermanently: Boolean,
    bindFailed: Boolean,
    onRequestAgain: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            stringResource(
                when {
                    bindFailed -> R.string.qr_camera_unavailable
                    deniedPermanently -> R.string.qr_camera_permission_denied
                    else -> R.string.qr_camera_permission_body
                }
            ),
            color = Color.White,
            textAlign = TextAlign.Center,
            style = MaterialTheme.typography.bodyMedium
        )
        Spacer(Modifier.height(20.dp))
        if (bindFailed) return@Column
        BeamPrimaryButton(
            text = stringResource(if (deniedPermanently) R.string.qr_open_settings else R.string.qr_allow_camera),
            onClick = if (deniedPermanently) onOpenSettings else onRequestAgain
        )
    }
}

@Composable
private fun CameraPreviewWithAnalysis(
    onBarcodeDetected: (String) -> Unit,
    onCameraReady: (Camera) -> Unit,
    onBindFailed: () -> Unit,
    modifier: Modifier = Modifier
) {
    val lifecycleOwner = LocalLifecycleOwner.current
    val currentOnDetected by rememberUpdatedState(onBarcodeDetected)
    val currentOnCameraReady by rememberUpdatedState(onCameraReady)
    val currentOnBindFailed by rememberUpdatedState(onBindFailed)
    val executor = remember { Executors.newSingleThreadExecutor() }
    val scanner: BarcodeScanner = remember {
        BarcodeScanning.getClient(BarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build())
    }

    DisposableEffect(Unit) {
        onDispose {
            executor.shutdown()
            scanner.close()
        }
    }

    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            val previewView = PreviewView(ctx)
            val providerFuture = ProcessCameraProvider.getInstance(ctx)
            providerFuture.addListener({
                val provider = providerFuture.get()
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                val resolutionSelector = ResolutionSelector.Builder()
                    .setResolutionStrategy(
                        ResolutionStrategy(Size(1280, 720), ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER)
                    )
                    .build()
                val analysis = ImageAnalysis.Builder()
                    .setResolutionSelector(resolutionSelector)
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                    .also { useCase ->
                        useCase.setAnalyzer(executor) { imageProxy ->
                            val mediaImage = imageProxy.image
                            if (mediaImage == null) {
                                imageProxy.close()
                                return@setAnalyzer
                            }
                            val image = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)
                            scanner.process(image)
                                .addOnSuccessListener { barcodes ->
                                    barcodes.firstOrNull()?.rawValue?.let(currentOnDetected)
                                }
                                .addOnCompleteListener { imageProxy.close() }
                        }
                    }
                runCatching {
                    provider.unbindAll()
                    provider.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
                }.onSuccess { boundCamera ->
                    currentOnCameraReady(boundCamera)
                }.onFailure {
                    // Missing permission, no back camera, camera already claimed by another
                    // process, etc. Whatever the cause, surface it instead of leaving a dead
                    // black preview with no feedback.
                    currentOnBindFailed()
                }
            }, ContextCompat.getMainExecutor(ctx))
            previewView
        }
    )
}

/** Dimmed surround with a rounded cut-out, corner brackets, and a sweeping scan line. */
@Composable
private fun ScannerOverlay(modifier: Modifier = Modifier) {
    val accent = BeamBlueLight
    val dim = Color.Black.copy(alpha = 0.6f)
    val sweep = rememberInfiniteTransition(label = "scan").animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scanSweep"
    )
    Canvas(modifier = modifier) {
        val frame = size.minDimension * 0.66f
        val left = (size.width - frame) / 2f
        val top = (size.height - frame) / 2f - size.height * 0.04f
        val right = left + frame
        val bottom = top + frame
        val corner = 40f

        // Everything outside the frame is dimmed; even-odd fill leaves the frame itself clear.
        val surround = Path().apply {
            fillType = PathFillType.EvenOdd
            addRect(Rect(0f, 0f, size.width, size.height))
            addRoundRect(RoundRect(left, top, right, bottom, CornerRadius(corner, corner)))
        }
        drawPath(surround, dim)

        val arm = 64f
        val brackets = Path().apply {
            // top-left
            moveTo(left, top + arm)
            lineTo(left, top + corner)
            arcTo(Rect(left, top, left + 2 * corner, top + 2 * corner), 180f, 90f, false)
            lineTo(left + arm, top)
            // top-right
            moveTo(right - arm, top)
            lineTo(right - corner, top)
            arcTo(Rect(right - 2 * corner, top, right, top + 2 * corner), 270f, 90f, false)
            lineTo(right, top + arm)
            // bottom-right
            moveTo(right, bottom - arm)
            lineTo(right, bottom - corner)
            arcTo(Rect(right - 2 * corner, bottom - 2 * corner, right, bottom), 0f, 90f, false)
            lineTo(right - arm, bottom)
            // bottom-left
            moveTo(left + arm, bottom)
            lineTo(left + corner, bottom)
            arcTo(Rect(left, bottom - 2 * corner, left + 2 * corner, bottom), 90f, 90f, false)
            lineTo(left, bottom - arm)
        }
        drawPath(brackets, accent, style = Stroke(width = 9f, cap = StrokeCap.Round, join = StrokeJoin.Round))

        val lineY = top + 28f + (frame - 56f) * sweep.value
        drawLine(
            color = accent.copy(alpha = 0.9f),
            start = Offset(left + 32f, lineY),
            end = Offset(right - 32f, lineY),
            strokeWidth = 5f,
            cap = StrokeCap.Round
        )
    }
}
