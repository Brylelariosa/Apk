package com.beamshare.app.ui.session

import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.res.vectorResource
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.ui.unit.dp
import com.beamshare.app.R
import com.beamshare.app.core.apps.ApkInstaller
import com.beamshare.app.core.model.SessionState
import com.beamshare.app.core.model.TransferDirection
import com.beamshare.app.core.model.TransferProgress
import com.beamshare.app.core.model.TransferState
import com.beamshare.app.di.ServiceLocator
import com.beamshare.app.ui.components.BeamCard
import com.beamshare.app.ui.components.BeamTopBar
import com.beamshare.app.ui.components.EmptyState
import com.beamshare.app.ui.components.IconBadge
import com.beamshare.app.ui.components.StatusPill
import com.beamshare.app.ui.components.TransferProgressRow
import com.beamshare.app.ui.theme.BeamBrandBrush
import com.beamshare.app.ui.theme.BeamMint
import com.beamshare.app.ui.util.beamViewModel
import com.beamshare.app.util.FormatUtils

@Composable
fun ConnectedSessionScreen(
    onSendMore: () -> Unit,
    onDisconnected: () -> Unit,
    modifier: Modifier = Modifier
) {
    val viewModel: SessionViewModel = beamViewModel { SessionViewModel(ServiceLocator.sessionManager) }
    val context = LocalContext.current
    val sessionState by viewModel.sessionState.collectAsStateWithLifecycle()
    val progress by viewModel.progress.collectAsStateWithLifecycle()
    var showDisconnectConfirm by remember { mutableStateOf(false) }

    // The state flips to Disconnected before the screen leaves; remember the name for the dialog.
    var lastPeerName by remember { mutableStateOf("") }
    LaunchedEffect(sessionState) {
        val state = sessionState
        if (state is SessionState.Connected) lastPeerName = state.peerName
        if (state is SessionState.Disconnected) onDisconnected()
    }
    val peerName = (sessionState as? SessionState.Connected)?.peerName ?: lastPeerName

    // Going "back" from a live session is a disconnect, so ask first instead of silently orphaning it.
    BackHandler { showDisconnectConfirm = true }

    Scaffold(
        modifier = modifier,
        containerColor = Color.Transparent,
        topBar = {
            BeamTopBar(
                title = stringResource(R.string.session_title),
                actions = {
                    IconButton(onClick = { showDisconnectConfirm = true }) {
                        Icon(
                            ImageVector.vectorResource(R.drawable.ic_link_off),
                            contentDescription = stringResource(R.string.session_disconnect)
                        )
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onSendMore,
                icon = { Icon(ImageVector.vectorResource(R.drawable.ic_add), contentDescription = null) },
                text = { Text(stringResource(R.string.session_send_more)) },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = Color.White
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 4.dp, bottom = 104.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item { ConnectionHeader(peerName = peerName, progress = progress) }
            if (progress.isEmpty()) {
                item {
                    EmptyState(
                        icon = ImageVector.vectorResource(R.drawable.ic_insert_drive_file),
                        title = stringResource(R.string.session_empty_title),
                        subtitle = stringResource(R.string.session_empty_state),
                        modifier = Modifier.padding(top = 24.dp)
                    )
                }
            } else {
                items(progress, key = { it.itemId }) { item ->
                    TransferProgressRow(
                        progress = item,
                        onOpen = { openReceivedItem(context, item) }
                    )
                }
            }
        }
    }

    if (showDisconnectConfirm) {
        AlertDialog(
            onDismissRequest = { showDisconnectConfirm = false },
            title = { Text(stringResource(R.string.session_disconnect_confirm_title)) },
            text = { Text(stringResource(R.string.session_disconnect_confirm_body, peerName)) },
            confirmButton = {
                TextButton(onClick = {
                    showDisconnectConfirm = false
                    viewModel.disconnect()
                }) {
                    Text(stringResource(R.string.session_disconnect), color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDisconnectConfirm = false }) { Text(stringResource(R.string.action_cancel)) }
            },
            shape = RoundedCornerShape(28.dp),
            containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
        )
    }
}

/** Who we're connected to, plus running totals for the session. */
@Composable
private fun ConnectionHeader(peerName: String, progress: List<TransferProgress>) {
    val totals = remember(progress) { SessionTotals.from(progress) }
    BeamCard(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                IconBadge(ImageVector.vectorResource(R.drawable.ic_phone_android), size = 52.dp, gradient = BeamBrandBrush)
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        peerName.ifBlank { stringResource(R.string.session_unknown_device) },
                        style = MaterialTheme.typography.titleMedium
                    )
                    StatusPill(text = stringResource(R.string.session_status_connected), color = BeamMint, pulsing = true)
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatBlock(
                    label = stringResource(R.string.session_stat_sent),
                    value = "${totals.sentCount} · ${FormatUtils.formatBytes(totals.sentBytes)}",
                    modifier = Modifier.weight(1f)
                )
                StatBlock(
                    label = stringResource(R.string.session_stat_received),
                    value = "${totals.receivedCount} · ${FormatUtils.formatBytes(totals.receivedBytes)}",
                    modifier = Modifier.weight(1f)
                )
                StatBlock(
                    label = stringResource(R.string.session_stat_speed),
                    value = if (totals.speedBytesPerSec > 0L) FormatUtils.formatSpeed(totals.speedBytesPerSec) else "—",
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun StatBlock(label: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.padding(vertical = 2.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.titleSmall, maxLines = 1)
    }
}

private data class SessionTotals(
    val sentCount: Int,
    val sentBytes: Long,
    val receivedCount: Int,
    val receivedBytes: Long,
    val speedBytesPerSec: Long
) {
    companion object {
        fun from(items: List<TransferProgress>): SessionTotals {
            val sent = items.filter { it.direction == TransferDirection.SEND && it.state == TransferState.COMPLETED }
            val received = items.filter { it.direction == TransferDirection.RECEIVE && it.state == TransferState.COMPLETED }
            return SessionTotals(
                sentCount = sent.size,
                sentBytes = sent.sumOf { it.totalBytes },
                receivedCount = received.size,
                receivedBytes = received.sumOf { it.totalBytes },
                speedBytesPerSec = items.filter { it.state == TransferState.IN_PROGRESS }.sumOf { it.speedBytesPerSec }
            )
        }
    }
}

private fun openReceivedItem(context: Context, item: TransferProgress) {
    val uri = item.savedUri ?: return
    val intent = if (item.isApk) {
        ApkInstaller.installIntent(uri)
    } else {
        // The system knows the real type of what we just saved; "*/*" matches almost no viewer.
        val mimeType = context.contentResolver.getType(uri) ?: item.mimeType.ifBlank { "*/*" }
        Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mimeType)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }
    val opened = runCatching { context.startActivity(intent) }.isSuccess
    if (!opened) Toast.makeText(context, R.string.transfer_open_failed, Toast.LENGTH_SHORT).show()
}
