package com.beamshare.app.ui.navigation

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.beamshare.app.core.model.TransferItem
import com.beamshare.app.core.qr.ConnectPayload
import com.beamshare.app.di.ServiceLocator
import com.beamshare.app.service.BeamShareService
import com.beamshare.app.ui.home.HomeScreen
import com.beamshare.app.ui.qr.QrScannerScreen
import com.beamshare.app.ui.receive.ReceiveScreen
import com.beamshare.app.ui.send.DiscoverDevicesScreen
import com.beamshare.app.ui.send.SelectContentScreen
import com.beamshare.app.ui.session.ConnectedSessionScreen

private object Routes {
    const val HOME = "home"
    const val SELECT_CONTENT = "select_content/{fromSession}"
    const val DISCOVER = "discover"
    const val QR_SCANNER = "qr_scanner"
    const val RECEIVE = "receive"
    const val SESSION = "session"

    fun selectContent(fromSession: Boolean) = "select_content/$fromSession"
}

@Composable
fun BeamNavHost(modifier: Modifier = Modifier) {
    val navController = rememberNavController()
    val context = LocalContext.current

    // Forward-only, screen-lifetime data: what to send once connected, and a QR result
    // bounced back from the scanner screen to the discover screen that launched it.
    var pendingSendItems by remember { mutableStateOf<List<TransferItem>>(emptyList()) }
    var pendingQrPayload by remember { mutableStateOf<ConnectPayload?>(null) }

    Surface(modifier = modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        NavHost(navController = navController, startDestination = Routes.HOME) {
            composable(Routes.HOME) {
                HomeScreen(
                    onSendClick = { navController.navigate(Routes.selectContent(fromSession = false)) },
                    onReceiveClick = { navController.navigate(Routes.RECEIVE) }
                )
            }

            composable(
                route = Routes.SELECT_CONTENT,
                arguments = listOf(navArgument("fromSession") { type = NavType.BoolType })
            ) { backStackEntry ->
                val fromSession = backStackEntry.arguments?.getBoolean("fromSession") ?: false
                SelectContentScreen(
                    onContinue = { items ->
                        if (fromSession) {
                            // The session manager runs the transfer in the app scope, so it
                            // carries on after this screen is gone.
                            ServiceLocator.sessionManager.sendItems(items)
                            navController.popBackStack()
                        } else {
                            pendingSendItems = items
                            navController.navigate(Routes.DISCOVER)
                        }
                    },
                    onBack = { navController.popBackStack() }
                )
            }

            composable(Routes.DISCOVER) {
                DiscoverDevicesScreen(
                    qrPayloadToConnect = pendingQrPayload,
                    onQrPayloadConsumed = { pendingQrPayload = null },
                    onConnected = {
                        // The peer approved: hand over what the user picked and move on.
                        ServiceLocator.sessionManager.sendItems(pendingSendItems)
                        pendingSendItems = emptyList()
                        BeamShareService.start(context)
                        navController.navigate(Routes.SESSION) { popUpTo(Routes.HOME) }
                    },
                    onScanQr = { navController.navigate(Routes.QR_SCANNER) },
                    onBack = { navController.popBackStack() }
                )
            }

            composable(Routes.QR_SCANNER) {
                QrScannerScreen(
                    onResult = { payload ->
                        pendingQrPayload = payload
                        navController.popBackStack()
                    },
                    onClose = { navController.popBackStack() }
                )
            }

            composable(Routes.RECEIVE) {
                ReceiveScreen(
                    onConnected = {
                        BeamShareService.start(context)
                        navController.navigate(Routes.SESSION) { popUpTo(Routes.HOME) }
                    },
                    onBack = { navController.popBackStack() }
                )
            }

            composable(Routes.SESSION) {
                ConnectedSessionScreen(
                    onSendMore = { navController.navigate(Routes.selectContent(fromSession = true)) },
                    onDisconnected = {
                        navController.navigate(Routes.HOME) { popUpTo(Routes.HOME) { inclusive = true } }
                    }
                )
            }
        }
    }
}
