package com.beamshare.app.ui.send

import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.beamshare.app.R
import com.beamshare.app.core.model.ConnectionState
import com.beamshare.app.core.model.PeerDevice
import com.beamshare.app.core.model.SessionState
import com.beamshare.app.core.qr.ConnectPayload
import com.beamshare.app.di.ServiceLocator
import com.beamshare.app.service.BeamShareService
import com.beamshare.app.ui.components.BeamPrimaryButton
import com.beamshare.app.ui.components.BeamSecondaryButton
import com.beamshare.app.ui.components.BeamTopBar
import com.beamshare.app.ui.components.ConnectingPane
import com.beamshare.app.ui.components.DeviceListItem
import com.beamshare.app.ui.components.IconBadge
import com.beamshare.app.ui.components.InfoBanner
import com.beamshare.app.ui.components.RadarAnimation
import com.beamshare.app.ui.components.ReadinessGate
import com.beamshare.app.ui.components.SectionHeader
import com.beamshare.app.ui.util.beamViewModel

/** What the discover screen is currently showing - derived from link, session and lookup state. */
private sealed interface DiscoverUi {
    data object Scanning : DiscoverUi
    data class Looking(val name: String) : DiscoverUi
    data class Connecting(val name: String) : DiscoverUi
    data object Linking : DiscoverUi
    data class Approval(val name: String) : DiscoverUi
    data class Failed(val message: String?) : DiscoverUi
}

@Composable
fun DiscoverDevicesScreen(
    qrPayloadToConnect: ConnectPayload?,
    onQrPayloadConsumed: () -> Unit,
    onConnected: () -> Unit,
    onScanQr: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val viewModel: DiscoverViewModel = beamViewModel {
        DiscoverViewModel(ServiceLocator.wifiDirectManager, ServiceLocator.sessionManager)
    }
    val peers by viewModel.peers.collectAsStateWithLifecycle()
    val connectionState by viewModel.connectionState.collectAsStateWithLifecycle()
    val sessionState by viewModel.sessionState.collectAsStateWithLifecycle()
    val lookingFor by viewModel.lookingFor.collectAsStateWithLifecycle()
    val lookupFailure by viewModel.failure.collectAsStateWithLifecycle()
    val endReason by viewModel.endReason.collectAsStateWithLifecycle()

    // Session state outlives screens, so until this screen has reset it, an old "Disconnected"
    // must not flash up as a fresh failure.
    var started by remember { mutableStateOf(false) }

    LaunchedEffect(sessionState) {
        if (sessionState is SessionState.Connected) onConnected()
    }

    Scaffold(
        modifier = modifier,
        containerColor = Color.Transparent,
        topBar = { BeamTopBar(title = stringResource(R.string.discover_title), onBack = onBack) }
    ) { padding ->
        ReadinessGate(Modifier.padding(padding)) {
            LaunchedEffect(Unit) {
                viewModel.startDiscovery()
                BeamShareService.start(context)
                started = true
            }
            LaunchedEffect(qrPayloadToConnect) {
                if (qrPayloadToConnect != null) {
                    viewModel.connectToQrPayload(qrPayloadToConnect)
                    onQrPayloadConsumed()
                }
            }

            // Snapshot delegated state once so the checks below can smart-cast.
            val link = connectionState
            val session = sessionState
            val looking = lookingFor
            val failure = lookupFailure
            val ui: DiscoverUi = when {
                !started -> DiscoverUi.Scanning
                failure != null -> DiscoverUi.Failed(failure)
                link is ConnectionState.Failed -> DiscoverUi.Failed(link.reason)
                session is SessionState.Disconnected -> DiscoverUi.Failed(endReason)
                session is SessionState.AwaitingApproval -> DiscoverUi.Approval(session.peerName)
                link is ConnectionState.LinkEstablished || session is SessionState.AwaitingHandshake -> DiscoverUi.Linking
                link is ConnectionState.Connecting -> DiscoverUi.Connecting(link.target.name)
                looking != null -> DiscoverUi.Looking(looking)
                else -> DiscoverUi.Scanning
            }

            val stepLabels = listOf(
                stringResource(R.string.discover_step_connect),
                stringResource(R.string.discover_step_link),
                stringResource(R.string.discover_step_approve)
            )
            val cancelLabel = stringResource(R.string.action_cancel)

            Crossfade(targetState = ui, label = "discoverState") { state ->
                when (state) {
                    is DiscoverUi.Scanning -> ScanningPane(
                        peers = peers,
                        onDeviceClick = viewModel::connectToDevice,
                        onScanQr = onScanQr
                    )
                    is DiscoverUi.Looking -> ConnectingPane(
                        title = stringResource(R.string.discover_looking_for, state.name),
                        subtitle = stringResource(R.string.discover_looking_hint),
                        step = 0,
                        stepLabels = stepLabels,
                        cancelLabel = cancelLabel,
                        onCancel = viewModel::restart
                    )
                    is DiscoverUi.Connecting -> ConnectingPane(
                        title = stringResource(R.string.discover_connecting, state.name),
                        subtitle = stringResource(R.string.discover_connecting_hint, state.name),
                        step = 0,
                        stepLabels = stepLabels,
                        cancelLabel = cancelLabel,
                        onCancel = viewModel::restart
                    )
                    is DiscoverUi.Linking -> ConnectingPane(
                        title = stringResource(R.string.discover_securing),
                        subtitle = stringResource(R.string.discover_securing_hint),
                        step = 1,
                        stepLabels = stepLabels,
                        cancelLabel = cancelLabel,
                        onCancel = viewModel::restart
                    )
                    is DiscoverUi.Approval -> ConnectingPane(
                        title = stringResource(R.string.discover_waiting_approval, state.name),
                        subtitle = stringResource(R.string.discover_waiting_approval_hint),
                        step = 2,
                        stepLabels = stepLabels,
                        cancelLabel = cancelLabel,
                        onCancel = viewModel::restart
                    )
                    is DiscoverUi.Failed -> FailedPane(message = state.message, onRetry = viewModel::restart)
                }
            }
        }
    }
}

@Composable
private fun ScanningPane(
    peers: List<PeerDevice>,
    onDeviceClick: (PeerDevice) -> Unit,
    onScanQr: () -> Unit
) {
    val sorted = remember(peers) {
        peers.sortedWith(compareBy<PeerDevice>({ it.status != PeerDevice.STATUS_AVAILABLE }, { it.name.lowercase() }))
    }
    Column(Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item { ScanningHeader(count = sorted.size) }
            if (sorted.isEmpty()) {
                item { InfoBanner(text = stringResource(R.string.discover_scanning_hint)) }
            } else {
                item { SectionHeader(stringResource(R.string.discover_nearby)) }
                items(sorted, key = { device -> device.macAddress.ifBlank { device.name } }) { device ->
                    DeviceListItem(device = device, onClick = { onDeviceClick(device) })
                }
            }
        }
        Box(
            Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            BeamSecondaryButton(
                text = stringResource(R.string.discover_scan_qr),
                onClick = onScanQr,
                icon = ImageVector.vectorResource(R.drawable.ic_qr_code_scanner),
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun ScanningHeader(count: Int) {
    Column(
        modifier = Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        RadarAnimation()
        Spacer(Modifier.height(8.dp))
        Text(
            text = if (count == 0) {
                stringResource(R.string.discover_scanning)
            } else {
                stringResource(R.string.discover_found_count, count)
            },
            style = MaterialTheme.typography.titleMedium,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun FailedPane(message: String?, onRetry: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        IconBadge(
            icon = ImageVector.vectorResource(R.drawable.ic_error_outline),
            size = 84.dp,
            tint = MaterialTheme.colorScheme.error
        )
        Spacer(Modifier.height(24.dp))
        Text(
            stringResource(R.string.discover_failed_title),
            style = MaterialTheme.typography.headlineSmall,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(8.dp))
        Text(
            message ?: stringResource(R.string.discover_failed_generic),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(28.dp))
        BeamPrimaryButton(text = stringResource(R.string.action_retry), onClick = onRetry)
    }
}
