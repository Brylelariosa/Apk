package com.beamshare.app.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.beamshare.app.R
import com.beamshare.app.core.model.PeerDevice
import com.beamshare.app.ui.theme.BeamBrandBrush
import kotlin.math.abs

private const val RADAR_RINGS = 3
private const val LINK_DOTS = 5

/** Expanding rings around a WiFi glyph: "searching nearby". Drawn on the canvas, so it costs no recomposition. */
@Composable
fun RadarAnimation(modifier: Modifier = Modifier, diameter: Dp = 220.dp) {
    val ringColor = MaterialTheme.colorScheme.primary
    val transition = rememberInfiniteTransition(label = "radar")
    val phase = transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(animation = tween(durationMillis = 2800, easing = LinearEasing), repeatMode = RepeatMode.Restart),
        label = "radarPhase"
    )
    Box(modifier = modifier.size(diameter), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val maxRadius = size.minDimension / 2f
            val strokeWidth = 2.dp.toPx()
            for (ring in 0 until RADAR_RINGS) {
                val progress = (phase.value + ring.toFloat() / RADAR_RINGS) % 1f
                drawCircle(
                    color = ringColor,
                    radius = maxRadius * (0.3f + 0.7f * progress),
                    alpha = (1f - progress) * 0.5f,
                    style = Stroke(width = strokeWidth)
                )
            }
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(ringColor.copy(alpha = 0.30f), Color.Transparent),
                    center = center,
                    radius = maxRadius * 0.55f
                ),
                radius = maxRadius * 0.55f
            )
        }
        IconBadge(
            icon = ImageVector.vectorResource(R.drawable.ic_wifi),
            size = diameter * 0.28f,
            gradient = BeamBrandBrush
        )
    }
}

/** Two phones with a trail of dots running between them. */
@Composable
fun BeamLinkAnimation(modifier: Modifier = Modifier) {
    val dotColor = MaterialTheme.colorScheme.primary
    val transition = rememberInfiniteTransition(label = "link")
    val phase = transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(animation = tween(durationMillis = 1400, easing = LinearEasing), repeatMode = RepeatMode.Restart),
        label = "linkPhase"
    )
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        IconBadge(ImageVector.vectorResource(R.drawable.ic_phone_android), size = 68.dp, gradient = BeamBrandBrush)
        repeat(LINK_DOTS) { index ->
            Box(
                Modifier
                    .size(9.dp)
                    .graphicsLayer { alpha = dotAlpha(phase.value, index) }
                    .background(dotColor, CircleShape)
            )
        }
        IconBadge(ImageVector.vectorResource(R.drawable.ic_phone_android), size = 68.dp, tint = dotColor)
    }
}

/** The dot nearest the travelling "pulse" is brightest; the rest fade toward a faint resting glow. */
private fun dotAlpha(phase: Float, index: Int): Float {
    val position = phase * LINK_DOTS
    val distance = abs(position - index)
    return (1f - distance / 2.2f).coerceIn(0.18f, 1f)
}

@Composable
fun DeviceListItem(device: PeerDevice, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val subtitle = when (device.status) {
        PeerDevice.STATUS_AVAILABLE -> stringResource(R.string.discover_tap_to_connect)
        PeerDevice.STATUS_INVITED -> stringResource(R.string.discover_device_invited)
        PeerDevice.STATUS_CONNECTED -> stringResource(R.string.discover_device_connected)
        else -> stringResource(R.string.discover_device_unavailable)
    }
    val enabled = device.status != PeerDevice.STATUS_UNAVAILABLE
    BeamCard(
        modifier = modifier.fillMaxWidth(),
        onClick = if (enabled) onClick else null
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            IconBadge(ImageVector.vectorResource(R.drawable.ic_phone_android), size = 48.dp, gradient = BeamBrandBrush)
            Column(Modifier.weight(1f)) {
                Text(
                    device.name,
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (enabled) {
                Icon(
                    ImageVector.vectorResource(R.drawable.ic_chevron_right),
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

/**
 * Full-pane progress while a connection is being set up: the link animation, what's happening,
 * a three-step tracker, and a way out.
 */
@Composable
fun ConnectingPane(
    title: String,
    subtitle: String,
    step: Int,
    stepLabels: List<String>,
    cancelLabel: String,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxSize().padding(horizontal = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        BeamLinkAnimation()
        Spacer(Modifier.height(32.dp))
        Text(title, style = MaterialTheme.typography.headlineSmall, textAlign = TextAlign.Center)
        Spacer(Modifier.height(8.dp))
        Text(
            subtitle,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(28.dp))
        StepTracker(step = step, labels = stepLabels)
        Spacer(Modifier.height(32.dp))
        BeamSecondaryButton(text = cancelLabel, onClick = onCancel)
    }
}

@Composable
private fun StepTracker(step: Int, labels: List<String>, modifier: Modifier = Modifier) {
    Row(modifier = modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        labels.forEachIndexed { index, label ->
            val reached = index <= step
            Column(Modifier.weight(1f)) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(4.dp)
                        .clip(CircleShape)
                        .background(if (reached) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant)
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    label,
                    style = MaterialTheme.typography.labelSmall,
                    color = if (reached) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}
