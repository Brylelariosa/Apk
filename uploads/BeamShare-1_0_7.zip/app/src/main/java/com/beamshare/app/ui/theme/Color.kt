package com.beamshare.app.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Brand
val BeamBlue = Color(0xFF5468FF)
val BeamBlueDark = Color(0xFF3F52E0)
val BeamBlueLight = Color(0xFF6A7BFF)
val BeamViolet = Color(0xFF7C4DFF)
val BeamCyan = Color(0xFF22D3EE)

// Status
val BeamMint = Color(0xFF2DD4A7)
val BeamAmber = Color(0xFFF5A623)
val BeamRed = Color(0xFFFF5C6C)

// File-type accents (used for the small badges next to files)
val KindImage = Color(0xFFFF6FA5)
val KindVideo = Color(0xFFA77BFF)
val KindAudio = Color(0xFFF5A623)
val KindDocument = Color(0xFF6A7BFF)
val KindArchive = Color(0xFFFF8A4C)
val KindOther = Color(0xFF8C96AD)

// Dark theme surfaces: a near-black navy with slightly lifted layers
val DarkBackground = Color(0xFF0B0E14)
val DarkSurfaceLow = Color(0xFF11151D)
val DarkSurface = Color(0xFF151A25)
val DarkSurfaceHigh = Color(0xFF1B2130)
val DarkSurfaceHighest = Color(0xFF232A3B)
val DarkOutline = Color(0xFF3A445C)
val DarkOutlineVariant = Color(0xFF2B3347)
val DarkOnSurface = Color(0xFFE8EBF3)
val DarkOnSurfaceMuted = Color(0xFF9AA3B8)

// Light theme surfaces: cool off-white with white cards
val LightBackground = Color(0xFFF5F7FB)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceHigh = Color(0xFFEDF0F7)
val LightSurfaceHighest = Color(0xFFE6EAF3)
val LightOutline = Color(0xFF8C96AD)
val LightOutlineVariant = Color(0xFFDDE2EE)
val LightOnSurface = Color(0xFF121826)
val LightOnSurfaceMuted = Color(0xFF566077)

/** The brand gradient: primary actions, avatars, progress fills. */
val BeamBrandBrush: Brush = Brush.linearGradient(listOf(BeamBlueLight, BeamViolet))
