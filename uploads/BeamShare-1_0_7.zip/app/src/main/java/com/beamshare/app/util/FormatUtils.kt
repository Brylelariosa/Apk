package com.beamshare.app.util

import java.util.Locale
import kotlin.math.ln
import kotlin.math.pow

object FormatUtils {
    private val UNITS = arrayOf("B", "KB", "MB", "GB")

    fun formatBytes(bytes: Long): String {
        if (bytes < 1024) return "$bytes B"
        val exponent = (ln(bytes.toDouble()) / ln(1024.0)).toInt().coerceIn(1, UNITS.size - 1)
        val value = bytes / 1024.0.pow(exponent)
        return String.format(Locale.getDefault(), "%.1f %s", value, UNITS[exponent])
    }

    fun formatSpeed(bytesPerSec: Long): String = "${formatBytes(bytesPerSec)}/s"

    /** Compact remaining-time text: "12s", "3m 05s", "1h 02m". */
    fun formatDuration(totalSeconds: Long): String {
        val seconds = totalSeconds.coerceAtLeast(0L)
        return when {
            seconds < 60L -> "${seconds}s"
            seconds < 3600L -> "${seconds / 60L}m ${(seconds % 60L).toString().padStart(2, '0')}s"
            else -> "${seconds / 3600L}h ${((seconds % 3600L) / 60L).toString().padStart(2, '0')}m"
        }
    }
}
