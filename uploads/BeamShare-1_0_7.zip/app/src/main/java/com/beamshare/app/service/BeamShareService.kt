package com.beamshare.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import com.beamshare.app.MainActivity
import com.beamshare.app.R
import com.beamshare.app.core.model.SessionState
import com.beamshare.app.core.model.TransferProgress
import com.beamshare.app.core.model.TransferState
import com.beamshare.app.di.ServiceLocator
import com.beamshare.app.util.FormatUtils
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

/**
 * Thin lifecycle wrapper: starts the foreground notification and mirrors [ServiceLocator]'s
 * session state into it. It owns no transfer logic itself - that all lives in [SessionManager]
 * so it keeps working identically whether or not this service happens to be running.
 */
class BeamShareService : LifecycleService() {

    private var lastNotificationKey: String? = null
    private var lastNotificationAt = 0L

    override fun onCreate() {
        super.onCreate()
        if (!ServiceLocator.isInitialized) ServiceLocator.init(applicationContext)
        createChannel()
        ServiceCompat.startForeground(
            this,
            NOTIFICATION_ID,
            buildNotification(getString(R.string.notification_session_active), null),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE
        )
        observeSession()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        return START_NOT_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // The user removed BeamShare from Recents. A WiFi Direct session only makes sense with the
        // app open on both ends, so tear down the same way an explicit disconnect does:
        // disconnect() flips sessionState to Disconnected, and observeSession() below already
        // stops this service on that transition. Safe to call when nothing was ever connected.
        ServiceLocator.sessionManager.disconnect()
        super.onTaskRemoved(rootIntent)
    }

    private fun observeSession() {
        lifecycleScope.launch {
            val sessions = ServiceLocator.sessionManager
            combine(sessions.sessionState, sessions.progress) { state, items -> state to items }
                .collect { (state, items) -> render(state, items) }
        }
    }

    private fun render(state: SessionState, items: List<TransferProgress>) {
        when (state) {
            is SessionState.Disconnected -> stopSelf()
            is SessionState.Connected -> {
                val active = items.filter { it.state == TransferState.IN_PROGRESS }
                if (active.isEmpty()) {
                    updateNotification(getString(R.string.session_connected_to, state.peerName), null)
                } else {
                    val total = active.sumOf { it.totalBytes }
                    val done = active.sumOf { it.transferredBytes }
                    val percent = if (total > 0L) ((done * 100L) / total).toInt().coerceIn(0, 100) else 0
                    val speed = active.sumOf { it.speedBytesPerSec }
                    updateNotification(getString(R.string.notification_transferring, FormatUtils.formatSpeed(speed)), percent)
                }
            }
            else -> updateNotification(getString(R.string.notification_session_active), null)
        }
    }

    /** Skips no-op updates and throttles progress ticks - the system drops notifications posted too fast. */
    private fun updateNotification(text: String, percent: Int?) {
        val key = "$text|$percent"
        val now = SystemClock.elapsedRealtime()
        if (key == lastNotificationKey) return
        if (percent != null && now - lastNotificationAt < NOTIFY_MIN_INTERVAL_MS) return
        lastNotificationKey = key
        lastNotificationAt = now
        getSystemService(NotificationManager::class.java)?.notify(NOTIFICATION_ID, buildNotification(text, percent))
    }

    private fun buildNotification(text: String, percent: Int?): Notification {
        val openApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_stat_beam)
            .setContentIntent(openApp)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
        if (percent != null) builder.setProgress(100, percent, false)
        return builder.build()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, getString(R.string.notification_channel_name), NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
        }
    }

    companion object {
        private const val CHANNEL_ID = "beamshare_session"
        private const val NOTIFICATION_ID = 1001
        private const val NOTIFY_MIN_INTERVAL_MS = 700L

        fun start(context: Context) {
            // Can only fail if the app is no longer in the foreground; the transfer itself doesn't depend on it.
            runCatching { context.startForegroundService(Intent(context, BeamShareService::class.java)) }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, BeamShareService::class.java))
        }
    }
}
