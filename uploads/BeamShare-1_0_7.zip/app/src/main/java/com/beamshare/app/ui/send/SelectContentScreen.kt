package com.beamshare.app.ui.send

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.beamshare.app.R
import com.beamshare.app.core.apps.InstalledApp
import com.beamshare.app.core.model.TransferItem
import com.beamshare.app.di.ServiceLocator
import com.beamshare.app.ui.components.BeamPrimaryButton
import com.beamshare.app.ui.components.BeamSecondaryButton
import com.beamshare.app.ui.components.BeamTopBar
import com.beamshare.app.ui.components.EmptyState
import com.beamshare.app.ui.components.InfoBanner
import com.beamshare.app.ui.components.KindBadge
import com.beamshare.app.ui.components.fileKindOf
import com.beamshare.app.ui.components.openAppSettings
import com.beamshare.app.ui.theme.BeamAmber
import com.beamshare.app.ui.util.beamViewModel
import com.beamshare.app.util.FormatUtils
import com.beamshare.app.util.PermissionHelper

// Declaration order is the order of the tabs on screen.
private enum class ContentTab { FILES, IMAGES, APPS }

@Composable
fun SelectContentScreen(
    onContinue: (List<TransferItem>) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val viewModel: SelectContentViewModel = beamViewModel {
        SelectContentViewModel(
            ServiceLocator.installedAppsRepository,
            ServiceLocator.fileRepository,
            ServiceLocator.imageRepository
        )
    }
    val selectedFiles by viewModel.selectedFiles.collectAsStateWithLifecycle()
    val selectedPackages by viewModel.selectedPackages.collectAsStateWithLifecycle()
    val filteredApps by viewModel.filteredApps.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val loadingApps by viewModel.loadingApps.collectAsStateWithLifecycle()
    val images by viewModel.images.collectAsStateWithLifecycle()
    val selectedImageIds by viewModel.selectedImageIds.collectAsStateWithLifecycle()
    val loadingImages by viewModel.loadingImages.collectAsStateWithLifecycle()
    val totalCount by viewModel.totalSelectedCount.collectAsStateWithLifecycle()
    val totalBytes by viewModel.totalSelectedBytes.collectAsStateWithLifecycle()

    var tab by rememberSaveable { mutableStateOf(ContentTab.FILES) }

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) viewModel.addFileUris(uris)
    }

    val imageAccess = rememberImageAccessState()
    var imagePermissionDenied by rememberSaveable { mutableStateOf(false) }
    var imagePermissionAsked by rememberSaveable { mutableStateOf(false) }
    // Hoisted so the grid keeps its scroll position while the user looks at the other tabs.
    val imageGridState = rememberLazyGridState()
    val imagePermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        imageAccess.refresh()
        imagePermissionDenied = !imageAccess.hasAccess
        // Also covers "choose more" on Android 14+, where access was already there but the set of pictures changed.
        if (imageAccess.hasAccess) viewModel.loadImages()
    }

    LaunchedEffect(tab) {
        if (tab == ContentTab.APPS) viewModel.loadAppsIfNeeded()
    }

    LaunchedEffect(tab, imageAccess.hasAccess, imageAccess.isPartial) {
        if (tab != ContentTab.IMAGES) return@LaunchedEffect
        if (imageAccess.hasAccess) {
            viewModel.loadImages()
        } else if (!imagePermissionAsked) {
            // Opening the tab is a clear enough signal to ask right away, once. The prompt stays on screen after that.
            imagePermissionAsked = true
            imagePermissionLauncher.launch(PermissionHelper.imagePermissions())
        }
    }

    Scaffold(
        modifier = modifier,
        containerColor = Color.Transparent,
        topBar = { BeamTopBar(title = stringResource(R.string.select_title), onBack = onBack) },
        bottomBar = {
            AnimatedVisibility(
                visible = totalCount > 0,
                enter = slideInVertically { it } + fadeIn(),
                exit = slideOutVertically { it } + fadeOut()
            ) {
                SelectionBar(
                    count = totalCount,
                    bytes = totalBytes,
                    onContinue = { onContinue(viewModel.buildTransferItems()) }
                )
            }
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            TabSwitcher(
                selected = tab,
                fileCount = selectedFiles.size,
                imageCount = selectedImageIds.size,
                appCount = selectedPackages.size,
                onSelect = { tab = it },
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)
            )
            Spacer(Modifier.height(8.dp))
            when (tab) {
                ContentTab.FILES -> FilesTab(
                    files = selectedFiles,
                    onPick = { filePicker.launch(arrayOf("*/*")) },
                    onRemove = viewModel::removeFile
                )
                ContentTab.IMAGES -> ImagesTab(
                    hasAccess = imageAccess.hasAccess,
                    isPartialAccess = imageAccess.isPartial,
                    permissionDenied = imagePermissionDenied,
                    images = images,
                    selectedIds = selectedImageIds,
                    loading = loadingImages,
                    gridState = imageGridState,
                    cachedThumbnail = viewModel::cachedThumbnail,
                    loadThumbnail = { image -> viewModel.loadThumbnail(image) },
                    onRequestAccess = { imagePermissionLauncher.launch(PermissionHelper.imagePermissions()) },
                    onOpenSettings = { openAppSettings(context) },
                    onToggle = viewModel::toggleImage
                )
                ContentTab.APPS -> AppsTab(
                    apps = filteredApps,
                    selected = selectedPackages,
                    query = searchQuery,
                    loading = loadingApps,
                    onQueryChange = viewModel::onSearchQueryChange,
                    onToggle = viewModel::toggleApp
                )
            }
        }
    }
}

// --------------------------------------------------------------------------------------------
// Tabs
// --------------------------------------------------------------------------------------------

@Composable
private fun TabSwitcher(
    selected: ContentTab,
    fileCount: Int,
    imageCount: Int,
    appCount: Int,
    onSelect: (ContentTab) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(MaterialTheme.colorScheme.surfaceContainerHigh)
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        TabPill(
            label = stringResource(R.string.select_files_tab),
            count = fileCount,
            selected = selected == ContentTab.FILES,
            onClick = { onSelect(ContentTab.FILES) },
            modifier = Modifier.weight(1f)
        )
        TabPill(
            label = stringResource(R.string.select_images_tab),
            count = imageCount,
            selected = selected == ContentTab.IMAGES,
            onClick = { onSelect(ContentTab.IMAGES) },
            modifier = Modifier.weight(1f)
        )
        TabPill(
            label = stringResource(R.string.select_apps_tab),
            count = appCount,
            selected = selected == ContentTab.APPS,
            onClick = { onSelect(ContentTab.APPS) },
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun TabPill(label: String, count: Int, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Surface(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        color = if (selected) MaterialTheme.colorScheme.surfaceContainerLowest else Color.Transparent,
        shadowElevation = if (selected) 1.dp else 0.dp
    ) {
        Row(
            modifier = Modifier.padding(vertical = 11.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                label,
                modifier = Modifier.weight(1f, fill = false),
                style = MaterialTheme.typography.labelLarge,
                color = if (selected) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (count > 0) {
                Spacer(Modifier.size(8.dp))
                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary)
                        .widthIn(min = 20.dp)
                        .padding(horizontal = 6.dp, vertical = 1.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(count.toString(), style = MaterialTheme.typography.labelSmall, color = Color.White)
                }
            }
        }
    }
}

@Composable
private fun FilesTab(files: List<TransferItem>, onPick: () -> Unit, onRemove: (String) -> Unit) {
    if (files.isEmpty()) {
        Column(
            modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            EmptyState(
                icon = ImageVector.vectorResource(R.drawable.ic_folder_open),
                title = stringResource(R.string.select_no_files_title),
                subtitle = stringResource(R.string.select_no_files_subtitle)
            )
            BeamPrimaryButton(
                text = stringResource(R.string.select_choose_files),
                onClick = onPick,
                icon = ImageVector.vectorResource(R.drawable.ic_add)
            )
            Spacer(Modifier.height(48.dp))
        }
    } else {
        LazyColumn(
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 4.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                BeamSecondaryButton(
                    text = stringResource(R.string.select_add_more),
                    onClick = onPick,
                    icon = ImageVector.vectorResource(R.drawable.ic_add),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(4.dp))
            }
            items(files, key = { it.id }) { file ->
                FileRow(file = file, onRemove = { onRemove(file.id) })
            }
        }
    }
}

@Composable
private fun FileRow(file: TransferItem, onRemove: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surfaceContainer,
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Row(
            modifier = Modifier.padding(start = 12.dp, top = 10.dp, bottom = 10.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            KindBadge(fileKindOf(file.mimeType, file.displayName, file.isApk))
            Column(Modifier.weight(1f)) {
                Text(
                    file.displayName,
                    style = MaterialTheme.typography.titleSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    FormatUtils.formatBytes(file.sizeBytes),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            IconButton(onClick = onRemove) {
                Icon(
                    ImageVector.vectorResource(R.drawable.ic_close),
                    contentDescription = stringResource(R.string.select_remove),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun AppsTab(
    apps: List<InstalledApp>,
    selected: Set<String>,
    query: String,
    loading: Boolean,
    onQueryChange: (String) -> Unit,
    onToggle: (String) -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = query,
            onValueChange = onQueryChange,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
            placeholder = { Text(stringResource(R.string.select_search_apps)) },
            leadingIcon = { Icon(ImageVector.vectorResource(R.drawable.ic_search), contentDescription = null) },
            trailingIcon = {
                if (query.isNotEmpty()) {
                    IconButton(onClick = { onQueryChange("") }) {
                        Icon(
                            ImageVector.vectorResource(R.drawable.ic_close),
                            contentDescription = stringResource(R.string.select_clear_search)
                        )
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(18.dp)
        )
        Spacer(Modifier.height(8.dp))
        when {
            loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            apps.isEmpty() -> EmptyState(
                icon = ImageVector.vectorResource(R.drawable.ic_apps),
                title = stringResource(R.string.select_no_apps_found),
                subtitle = stringResource(R.string.select_no_apps_subtitle),
                modifier = Modifier.padding(top = 32.dp)
            )
            else -> LazyColumn(
                contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 4.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item { InfoBanner(text = stringResource(R.string.select_apps_note)) }
                items(apps, key = { it.packageName }) { app ->
                    AppRow(app = app, checked = app.packageName in selected, onToggle = { onToggle(app.packageName) })
                }
            }
        }
    }
}

@Composable
private fun AppRow(app: InstalledApp, checked: Boolean, onToggle: () -> Unit) {
    Surface(
        onClick = onToggle,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        color = if (checked) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f) else MaterialTheme.colorScheme.surfaceContainer,
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (checked) MaterialTheme.colorScheme.primary.copy(alpha = 0.6f) else MaterialTheme.colorScheme.outlineVariant
        )
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Image(
                bitmap = app.icon,
                contentDescription = null,
                modifier = Modifier.size(44.dp).clip(RoundedCornerShape(12.dp))
            )
            Column(Modifier.weight(1f)) {
                Text(
                    app.label,
                    style = MaterialTheme.typography.titleSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        FormatUtils.formatBytes(app.apkSizeBytes),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (app.isSplit) {
                        Text(
                            stringResource(R.string.select_split_app),
                            style = MaterialTheme.typography.labelSmall,
                            color = BeamAmber
                        )
                    }
                }
            }
            SelectionIndicator(checked)
        }
    }
}

@Composable
private fun SelectionIndicator(selected: Boolean) {
    val primary = MaterialTheme.colorScheme.primary
    Box(
        modifier = Modifier
            .size(24.dp)
            .clip(CircleShape)
            .background(if (selected) primary else Color.Transparent)
            .border(2.dp, if (selected) primary else MaterialTheme.colorScheme.outline, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        if (selected) {
            Icon(
                ImageVector.vectorResource(R.drawable.ic_check),
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(14.dp)
            )
        }
    }
}

// --------------------------------------------------------------------------------------------
// Bottom bar
// --------------------------------------------------------------------------------------------

@Composable
private fun SelectionBar(count: Int, bytes: Long, onContinue: () -> Unit) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
        shape = RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp),
        shadowElevation = 8.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    stringResource(R.string.select_items_selected, count),
                    style = MaterialTheme.typography.titleMedium
                )
                Text(
                    FormatUtils.formatBytes(bytes),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            BeamPrimaryButton(
                text = stringResource(R.string.select_continue),
                onClick = onContinue,
                icon = ImageVector.vectorResource(R.drawable.ic_chevron_right)
            )
        }
    }
}
