package com.beamshare.app.ui.receive

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.beamshare.app.R
import com.beamshare.app.core.model.PeerDevice
import com.beamshare.app.core.model.SessionState
import com.beamshare.app.core.qr.ConnectPayload
import com.beamshare.app.core.qr.QrCodeGenerator
import com.beamshare.app.di.ServiceLocator
import com.beamshare.app.service.BeamShareService
import com.beamshare.app.ui.components.BeamCard
import com.beamshare.app.ui.components.BeamTopBar
import com.beamshare.app.ui.components.IconBadge
import com.beamshare.app.ui.components.InfoBanner
import com.beamshare.app.ui.components.ReadinessGate
import com.beamshare.app.ui.components.StatusPill
import com.beamshare.app.ui.theme.BeamBrandBrush
import com.beamshare.app.ui.util.beamViewModel

@Composable
fun ReceiveScreen(
    onConnected: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val viewModel: ReceiveViewModel = beamViewModel {
        ReceiveViewModel(ServiceLocator.wifiDirectManager, ServiceLocator.sessionManager)
    }
    val thisDevice by viewModel.thisDevice.collectAsStateWithLifecycle()
    val sessionState by viewModel.sessionState.collectAsStateWithLifecycle()

    Scaffold(
        modifier = modifier,
        containerColor = Color.Transparent,
        topBar = { BeamTopBar(title = stringResource(R.string.receive_title), onBack = onBack) }
    ) { padding ->
        ReadinessGate(Modifier.padding(padding)) {
            LaunchedEffect(Unit) {
                viewModel.startWaiting()
                BeamShareService.start(context)
            }
            LaunchedEffect(sessionState) {
                val state = sessionState
                if (state is SessionState.Connected) {
                    onConnected()
                } else if (state is SessionState.Disconnected) {
                    // A request was declined or a session ended: become discoverable again.
                    viewModel.startWaiting()
                    BeamShareService.start(context)
                }
            }

            val device = thisDevice
            val qr = remember(device) {
                device?.let { QrCodeGenerator.generate(ConnectPayload.forThisDevice(it).encode()) }
            }
            WaitingContent(device = device, qr = qr)

            val state = sessionState
            if (state is SessionState.IncomingRequest) {
                IncomingRequestDialog(
                    peerName = state.peerName,
                    onAccept = viewModel::accept,
                    onDecline = viewModel::decline
                )
            }
        }
    }
}

@Composable
private fun WaitingContent(device: PeerDevice?, qr: ImageBitmap?) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        StatusPill(
            text = stringResource(R.string.receive_waiting),
            color = MaterialTheme.colorScheme.primary,
            pulsing = true
        )
        Spacer(Modifier.height(18.dp))
        QrCard(device = device, qr = qr)
        Spacer(Modifier.height(24.dp))

        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text(stringResource(R.string.receive_how_title), style = MaterialTheme.typography.titleMedium)
            StepRow(1, stringResource(R.string.receive_step_1))
            StepRow(2, stringResource(R.string.receive_step_2))
            StepRow(3, stringResource(R.string.receive_step_3))
            InfoBanner(text = stringResource(R.string.receive_saved_to))
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun QrCard(device: PeerDevice?, qr: ImageBitmap?) {
    BeamCard(shape = RoundedCornerShape(28.dp)) {
        Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(236.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.White)
                    .padding(14.dp),
                contentAlignment = Alignment.Center
            ) {
                if (qr != null) {
                    Image(
                        bitmap = qr,
                        contentDescription = stringResource(R.string.receive_qr_description),
                        modifier = Modifier.fillMaxSize(),
                        filterQuality = FilterQuality.None
                    )
                } else {
                    CircularProgressIndicator()
                }
            }
            Spacer(Modifier.height(16.dp))
            Text(
                text = device?.name ?: stringResource(R.string.receive_getting_ready),
                style = MaterialTheme.typography.titleMedium,
                textAlign = TextAlign.Center
            )
            Text(
                text = stringResource(R.string.receive_this_phone),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun StepRow(number: Int, text: String) {
    Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        Box(
            modifier = Modifier.size(26.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                number.toString(),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold
            )
        }
        Text(
            text,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.weight(1f).padding(top = 3.dp)
        )
    }
}

@Composable
private fun IncomingRequestDialog(peerName: String, onAccept: () -> Unit, onDecline: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDecline,
        icon = {
            IconBadge(ImageVector.vectorResource(R.drawable.ic_phone_android), size = 60.dp, gradient = BeamBrandBrush)
        },
        title = {
            Text(
                stringResource(R.string.receive_incoming_title, peerName),
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        },
        text = {
            Text(
                stringResource(R.string.receive_incoming_body),
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            TextButton(onClick = onAccept) {
                Text(stringResource(R.string.receive_accept), fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDecline) { Text(stringResource(R.string.receive_decline)) }
        },
        shape = RoundedCornerShape(28.dp),
        containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
    )
}
