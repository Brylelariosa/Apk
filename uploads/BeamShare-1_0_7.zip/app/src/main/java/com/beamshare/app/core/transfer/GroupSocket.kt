package com.beamshare.app.core.transfer

import android.os.SystemClock
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.IOException
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketTimeoutException

/**
 * Opens the TCP socket for one end of a WiFi Direct link.
 *
 * The group owner listens and the client dials the owner's address. The two phones learn
 * about the link at slightly different moments, and the client usually has no IP address for
 * its first second or so - so the client keeps retrying instead of failing on the first
 * "connection refused", and the owner polls `accept()` in short slices so cancelling the
 * coroutine actually releases the port instead of leaving a dead listener behind.
 */
object GroupSocket {
    private const val ACCEPT_POLL_MS = 1_000
    private const val CONNECT_ATTEMPT_TIMEOUT_MS = 3_000
    private const val CONNECT_RETRY_DELAY_MS = 400L

    /** The address a WiFi Direct group owner always uses unless the framework says otherwise. */
    private const val DEFAULT_OWNER_ADDRESS = "192.168.49.1"

    /** Returns a connected socket, or null if nothing connected before [timeoutMs] elapsed. */
    suspend fun open(isGroupOwner: Boolean, groupOwnerAddress: String, timeoutMs: Long): Socket? =
        withContext(Dispatchers.IO) {
            if (isGroupOwner) accept(timeoutMs) else dial(groupOwnerAddress.ifBlank { DEFAULT_OWNER_ADDRESS }, timeoutMs)
        }

    private suspend fun accept(timeoutMs: Long): Socket? {
        val server = ServerSocket()
        try {
            server.reuseAddress = true
            server.soTimeout = ACCEPT_POLL_MS
            server.bind(InetSocketAddress(TransferProtocol.PORT))
            val deadline = SystemClock.elapsedRealtime() + timeoutMs
            while (SystemClock.elapsedRealtime() < deadline) {
                currentCoroutineContext().ensureActive()
                try {
                    return server.accept().also { configure(it) }
                } catch (ignored: SocketTimeoutException) {
                    // nobody yet - poll again so cancellation and the deadline are re-checked
                }
            }
            return null
        } finally {
            runCatching { server.close() }
        }
    }

    private suspend fun dial(host: String, timeoutMs: Long): Socket? {
        val deadline = SystemClock.elapsedRealtime() + timeoutMs
        while (SystemClock.elapsedRealtime() < deadline) {
            currentCoroutineContext().ensureActive()
            val socket = Socket()
            try {
                socket.connect(InetSocketAddress(host, TransferProtocol.PORT), CONNECT_ATTEMPT_TIMEOUT_MS)
                configure(socket)
                return socket
            } catch (e: IOException) {
                runCatching { socket.close() }
                delay(CONNECT_RETRY_DELAY_MS)
            }
        }
        return null
    }

    private fun configure(socket: Socket) {
        runCatching {
            socket.tcpNoDelay = true
            socket.keepAlive = true
        }
    }
}
