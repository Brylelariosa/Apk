package com.beamshare.app.ui.components

import androidx.compose.ui.graphics.Color
import com.beamshare.app.R
import com.beamshare.app.ui.theme.BeamMint
import com.beamshare.app.ui.theme.KindArchive
import com.beamshare.app.ui.theme.KindAudio
import com.beamshare.app.ui.theme.KindDocument
import com.beamshare.app.ui.theme.KindImage
import com.beamshare.app.ui.theme.KindOther
import com.beamshare.app.ui.theme.KindVideo

/** A coarse category used to pick the icon and accent colour shown next to a file. */
enum class FileKind(val iconRes: Int, val tint: Color) {
    APP(R.drawable.ic_apps, BeamMint),
    IMAGE(R.drawable.ic_image, KindImage),
    VIDEO(R.drawable.ic_movie, KindVideo),
    AUDIO(R.drawable.ic_music_note, KindAudio),
    DOCUMENT(R.drawable.ic_description, KindDocument),
    ARCHIVE(R.drawable.ic_archive, KindArchive),
    OTHER(R.drawable.ic_insert_drive_file, KindOther)
}

private val DOCUMENT_EXTENSIONS = setOf(
    "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "md", "rtf", "odt", "ods", "odp", "csv", "epub"
)
private val ARCHIVE_EXTENSIONS = setOf("zip", "rar", "7z", "tar", "gz", "bz2", "xz", "apks", "xapk", "obb")

fun fileKindOf(mimeType: String, fileName: String, isApk: Boolean = false): FileKind {
    val mime = mimeType.lowercase()
    val extension = fileName.substringAfterLast('.', "").lowercase()
    return when {
        isApk || mime == "application/vnd.android.package-archive" || extension == "apk" -> FileKind.APP
        mime.startsWith("image/") -> FileKind.IMAGE
        mime.startsWith("video/") -> FileKind.VIDEO
        mime.startsWith("audio/") -> FileKind.AUDIO
        extension in ARCHIVE_EXTENSIONS || mime.contains("zip") || mime.contains("compressed") ||
            mime.contains("tar") || mime.contains("rar") || mime.contains("7z") -> FileKind.ARCHIVE
        extension in DOCUMENT_EXTENSIONS || mime == "application/pdf" || mime.startsWith("text/") ||
            mime.contains("document") || mime.contains("sheet") || mime.contains("presentation") ||
            mime.contains("msword") -> FileKind.DOCUMENT
        else -> FileKind.OTHER
    }
}
