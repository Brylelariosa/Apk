package com.beamshare.app.core.transfer

import com.beamshare.app.core.discovery.WifiDirectManager
import com.beamshare.app.core.files.FileIo
import com.beamshare.app.core.model.ConnectionState
import com.beamshare.app.core.model.SessionState
import com.beamshare.app.core.model.TransferItem
import com.beamshare.app.core.model.TransferProgress
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/** Which end of the pairing this device is on: the one that picked a peer, or the one that was picked. */
enum class SessionRole { INITIATOR, RECEIVER }

/**
 * Turns a raw WiFi Direct link into a user-approved transfer session.
 *
 * Intended to run on the main dispatcher: all state below is only touched from there, while the
 * blocking socket work lives behind suspend functions that switch to IO themselves.
 *
 * Pairing flow:
 *  1. [watchForLink] waits for the link, then opens the TCP socket ([GroupSocket]).
 *  2. Both ends greet each other. The receiver surfaces [SessionState.IncomingRequest] and the
 *     initiator shows [SessionState.AwaitingApproval].
 *  3. When the receiver's user accepts, it sends READY and both ends become [SessionState.Connected].
 *     Until then the receiver refuses offers, so nothing lands on the device unapproved.
 */
class SessionManager(
    private val wifiDirectManager: WifiDirectManager,
    private val fileIo: FileIo,
    private val scope: CoroutineScope
) {
    private val _sessionState = MutableStateFlow<SessionState>(SessionState.None)
    val sessionState: StateFlow<SessionState> = _sessionState.asStateFlow()

    private val _progress = MutableStateFlow<List<TransferProgress>>(emptyList())
    val progress: StateFlow<List<TransferProgress>> = _progress.asStateFlow()

    private val _endReason = MutableStateFlow<String?>(null)
    /** Why the last pairing attempt or session ended, when there is something worth telling the user. */
    val endReason: StateFlow<String?> = _endReason.asStateFlow()

    var localDeviceName: String = "BeamShare device"

    private var role = SessionRole.INITIATOR
    private var session: TransferSession? = null
    private var peerName: String? = null
    private var linkWatchJob: Job? = null
    private var openJob: Job? = null
    private val sessionJobs = mutableListOf<Job>()
    private val sendMutex = Mutex()

    /**
     * Starts (or restarts) waiting for a WiFi Direct link in the given [role]. A session that is
     * already live is left untouched.
     */
    fun watchForLink(role: SessionRole) {
        this.role = role
        linkWatchJob?.cancel()
        if (session == null) {
            openJob?.cancel()
            openJob = null
            _endReason.value = null
            _sessionState.value = SessionState.None
        }
        linkWatchJob = scope.launch {
            wifiDirectManager.connectionState.collect { state -> onLinkState(state) }
        }
    }

    private fun onLinkState(state: ConnectionState) {
        when (state) {
            is ConnectionState.LinkEstablished -> {
                if (session == null && openJob?.isActive != true) openSession(state)
            }
            is ConnectionState.Idle, is ConnectionState.Failed -> {
                // The link went away underneath a session (or the attempt to open one).
                if (session != null || openJob?.isActive == true) {
                    endSession("The WiFi Direct connection was lost.")
                }
            }
            else -> Unit
        }
    }

    private fun openSession(link: ConnectionState.LinkEstablished) {
        val myRole = role
        _sessionState.value = SessionState.AwaitingHandshake
        openJob = scope.launch {
            val socket = try {
                GroupSocket.open(link.isGroupOwner, link.groupOwnerAddress, SOCKET_TIMEOUT_MS)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                null
            }
            if (socket == null) {
                endSession("Couldn't open a connection to the other phone. Try again.")
                return@launch
            }
            val newSession = TransferSession(
                socket = socket,
                fileIo = fileIo,
                sessionScope = scope,
                approveIncomingImmediately = myRole == SessionRole.INITIATOR
            )
            session = newSession
            bind(newSession, myRole)
            val myName = wifiDirectManager.thisDevice.value?.name?.takeIf { it.isNotBlank() } ?: localDeviceName
            newSession.start(myName)
        }
    }

    private fun bind(newSession: TransferSession, myRole: SessionRole) {
        sessionJobs.add(scope.launch { newSession.progress.collect { _progress.value = it } })

        sessionJobs.add(
            scope.launch {
                newSession.peerHello.collect { hello ->
                    if (hello == null) return@collect
                    if (hello.version < TransferProtocol.PROTOCOL_VERSION) {
                        endSession("The other phone has an older version of BeamShare. Update both phones to the same version.")
                        return@collect
                    }
                    peerName = hello.name
                    // READY can only follow HELLO on the wire, but these are separate collectors:
                    // never let a late greeting knock an already-connected session back a step.
                    _sessionState.value = when {
                        _sessionState.value is SessionState.Connected -> SessionState.Connected(hello.name)
                        myRole == SessionRole.RECEIVER -> SessionState.IncomingRequest(hello.name)
                        else -> SessionState.AwaitingApproval(hello.name)
                    }
                }
            }
        )

        sessionJobs.add(
            scope.launch {
                newSession.peerReady.collect { ready ->
                    if (ready && myRole == SessionRole.INITIATOR && session === newSession) {
                        _sessionState.value = SessionState.Connected(peerName ?: "Device")
                    }
                }
            }
        )

        sessionJobs.add(
            scope.launch {
                newSession.closed.collect { isClosed ->
                    if (isClosed && session === newSession) {
                        endSession(
                            when (_sessionState.value) {
                                is SessionState.AwaitingApproval -> "The other phone didn't accept the connection."
                                is SessionState.Connected -> "The other phone disconnected."
                                else -> "The connection was closed."
                            }
                        )
                    }
                }
            }
        )
    }

    /** Receiver side: the user accepted the incoming request. */
    fun acceptIncoming() {
        val active = session ?: return
        val name = peerName ?: return
        active.approveIncoming()
        _sessionState.value = SessionState.Connected(name)
    }

    /** Receiver side: the user declined. The peer is told, then the link is torn down. */
    fun declineIncoming() {
        val active = session
        detachSession()
        _sessionState.value = SessionState.None
        scope.launch {
            active?.goodbye()
            wifiDirectManager.disconnect()
            _endReason.value = null
            _sessionState.value = SessionState.Disconnected
        }
    }

    /** User-initiated disconnect from a live session. */
    fun disconnect() {
        val active = session
        detachSession()
        linkWatchJob?.cancel()
        scope.launch {
            active?.goodbye()
            wifiDirectManager.disconnect()
            _progress.value = emptyList()
            _endReason.value = null
            _sessionState.value = SessionState.Disconnected
        }
    }

    /** Gives up on a pairing attempt that isn't connected yet, staying on the same screen. */
    fun abortPairing() {
        if (_sessionState.value is SessionState.Connected) return
        val active = session
        detachSession()
        active?.close()
        wifiDirectManager.disconnect()
        _endReason.value = null
        _sessionState.value = SessionState.None
    }

    /**
     * Called when the screen that was pairing goes away. Does nothing for a live session; otherwise
     * releases WiFi Direct and publishes Disconnected so the foreground service can stop itself.
     */
    fun cancelPairing() {
        if (_sessionState.value is SessionState.Connected) return
        linkWatchJob?.cancel()
        val active = session
        detachSession()
        active?.close()
        wifiDirectManager.release()
        _endReason.value = null
        _sessionState.value = SessionState.Disconnected
    }

    /**
     * Queues [items] to send to the connected peer, one after another. Runs in the app scope so a
     * transfer keeps going while the user moves between screens.
     */
    fun sendItems(items: List<TransferItem>) {
        if (items.isEmpty()) return
        val active = session ?: return
        active.enqueue(items)
        scope.launch {
            sendMutex.withLock {
                for (item in items) {
                    if (session !== active) break
                    try {
                        active.send(item)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        // The item is already marked FAILED. If the connection itself broke the
                        // session reports closed and the remaining items fail fast below.
                        if (session !== active) break
                    }
                }
            }
        }
    }

    private fun endSession(reason: String?) {
        val active = session
        detachSession()
        active?.close()
        wifiDirectManager.disconnect()
        _endReason.value = reason
        _sessionState.value = SessionState.Disconnected
    }

    /** Forgets the current session and everything observing it, without touching the link. */
    private fun detachSession() {
        session = null
        peerName = null
        openJob?.cancel()
        openJob = null
        sessionJobs.forEach { it.cancel() }
        sessionJobs.clear()
    }

    private companion object {
        const val SOCKET_TIMEOUT_MS = 30_000L
    }
}
