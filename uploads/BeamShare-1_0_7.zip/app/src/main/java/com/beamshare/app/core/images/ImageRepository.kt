package com.beamshare.app.core.images

import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import android.webkit.MimeTypeMap
import com.beamshare.app.core.model.TransferItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext

/** One picture from the phone's gallery, as listed in the Images tab. */
data class DeviceImage(
    val id: Long,
    val displayName: String,
    val sizeBytes: Long,
    val mimeType: String,
    /** Degrees the stored pixels must be turned to appear upright. Only read on Android 9 and older. */
    val orientation: Int = 0
) {
    /** Content URI of this picture in the shared media collection. */
    val uri: Uri get() = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id)
}

/** The same picture as something the transfer layer can send. */
fun DeviceImage.toTransferItem(): TransferItem = TransferItem(
    displayName = displayName,
    sizeBytes = sizeBytes,
    mimeType = mimeType,
    sourceUri = uri
)

/**
 * Lists the pictures on the phone and hands out small previews of them.
 *
 * Previews are decoded by the system (or sampled down on old Android versions) rather than by an
 * image-loading library, which keeps the APK from growing for what is a single grid of squares.
 */
class ImageRepository(private val context: Context) {

    private val resolver: ContentResolver get() = context.contentResolver

    // Measured in bytes rather than entries so a handful of large previews can't crowd out the rest.
    private val thumbnails = object : LruCache<Long, Bitmap>(thumbnailCacheBytes()) {
        override fun sizeOf(key: Long, value: Bitmap): Int = value.width * value.height * BYTES_PER_PIXEL
    }

    // A fast fling would otherwise ask the media provider for dozens of previews at once.
    private val thumbnailGate = Semaphore(permits = MAX_PARALLEL_THUMBNAILS)

    /** Newest pictures first. Blocking: call from a background thread. */
    fun queryImages(): List<DeviceImage> {
        val needsRotation = Build.VERSION.SDK_INT < Build.VERSION_CODES.Q
        val projection = buildList<String> {
            add(MediaStore.Images.Media._ID)
            add(MediaStore.Images.Media.DISPLAY_NAME)
            add(MediaStore.Images.Media.SIZE)
            add(MediaStore.Images.Media.MIME_TYPE)
            if (needsRotation) add(COLUMN_ORIENTATION)
        }.toTypedArray()
        val sortOrder = "${MediaStore.Images.Media.DATE_ADDED} DESC, ${MediaStore.Images.Media._ID} DESC"

        val images = ArrayList<DeviceImage>()
        resolver.query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection, null, null, sortOrder)?.use { cursor ->
            val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
            val nameColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
            val sizeColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE)
            val mimeColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.MIME_TYPE)
            val rotationColumn = if (needsRotation) cursor.getColumnIndexOrThrow(COLUMN_ORIENTATION) else -1
            while (cursor.moveToNext()) {
                val size = cursor.getLong(sizeColumn)
                // The receiver is told the exact byte count up front, so a picture of unknown size can't be sent.
                if (size <= 0L) continue
                val id = cursor.getLong(idColumn)
                val name = cursor.getString(nameColumn)?.takeIf { it.isNotBlank() } ?: "image_$id"
                images += DeviceImage(
                    id = id,
                    displayName = name,
                    sizeBytes = size,
                    mimeType = cursor.getString(mimeColumn)?.takeIf { it.isNotBlank() } ?: guessMimeType(name),
                    orientation = if (rotationColumn >= 0) cursor.getInt(rotationColumn) else 0
                )
            }
        }
        return images
    }

    /** The preview if it is already in memory, so a cell can draw it on its very first frame. */
    fun cachedThumbnail(image: DeviceImage): Bitmap? = thumbnails.get(image.id)

    /** Loads a small preview, or null if the system can't produce one for this picture. */
    suspend fun loadThumbnail(image: DeviceImage): Bitmap? {
        thumbnails.get(image.id)?.let { return it }
        // Waiting for a permit is cancellable, so previews that scrolled away before their turn never load.
        return thumbnailGate.withPermit {
            // The same picture may have finished loading while this request was queued.
            thumbnails.get(image.id) ?: withContext(Dispatchers.IO) { decodeThumbnail(image) }?.also {
                thumbnails.put(image.id, it)
            }
        }
    }

    fun clearThumbnailCache() {
        thumbnails.evictAll()
    }

    private fun decodeThumbnail(image: DeviceImage): Bitmap? = runCatching {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            resolver.loadThumbnail(image.uri, Size(THUMBNAIL_SIZE_PX, THUMBNAIL_SIZE_PX), null)
        } else {
            decodeSampled(image)
        }
    }.getOrNull()

    /** Android 9 and older: read the file at a fraction of its size, then stand it upright. */
    private fun decodeSampled(image: DeviceImage): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(image.uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

        var sampleSize = 1
        while (bounds.outWidth / (sampleSize * 2) >= THUMBNAIL_SIZE_PX && bounds.outHeight / (sampleSize * 2) >= THUMBNAIL_SIZE_PX) {
            sampleSize *= 2
        }
        val options = BitmapFactory.Options().apply { inSampleSize = sampleSize }
        val decoded = resolver.openInputStream(image.uri)?.use { BitmapFactory.decodeStream(it, null, options) } ?: return null
        if (image.orientation == 0) return decoded

        val matrix = Matrix().apply { postRotate(image.orientation.toFloat()) }
        return Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, matrix, true)
    }

    private fun guessMimeType(name: String): String {
        val extension = name.substringAfterLast('.', "").lowercase()
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension) ?: "image/jpeg"
    }

    private companion object {
        /** The MediaStore constant for this is deprecated on newer SDKs; the column itself is unchanged. */
        const val COLUMN_ORIENTATION = "orientation"

        /** About one grid cell at typical phone density, so previews stay sharp without being oversized. */
        const val THUMBNAIL_SIZE_PX = 320
        const val BYTES_PER_PIXEL = 4
        const val MAX_PARALLEL_THUMBNAILS = 4
        const val MIN_CACHE_BYTES = 8 * 1024 * 1024
        const val MAX_CACHE_BYTES = 32 * 1024 * 1024

        fun thumbnailCacheBytes(): Int =
            (Runtime.getRuntime().maxMemory() / 16).toInt().coerceIn(MIN_CACHE_BYTES, MAX_CACHE_BYTES)
    }
}
