package com.beamshare.app.core.model

import android.net.Uri
import java.util.UUID

/**
 * A device discovered (or paired with) over WiFi Direct. [status] mirrors
 * `WifiP2pDevice.status` so the connect flow can tell "invited" from "declined".
 */
data class PeerDevice(
    val macAddress: String,
    val name: String,
    val isGroupOwner: Boolean = false,
    val status: Int = STATUS_AVAILABLE
) {
    companion object {
        const val STATUS_CONNECTED = 0
        const val STATUS_INVITED = 1
        const val STATUS_FAILED = 2
        const val STATUS_AVAILABLE = 3
        const val STATUS_UNAVAILABLE = 4

        /** Address the framework reports in place of a real one when it hides this device's MAC. */
        const val ANONYMIZED_ADDRESS = "02:00:00:00:00:00"
    }
}

/** Something the user picked to send: a file or an installed app's APK. */
data class TransferItem(
    val id: String = UUID.randomUUID().toString(),
    val displayName: String,
    val sizeBytes: Long,
    val mimeType: String,
    val sourceUri: Uri? = null,
    val sourceFilePath: String? = null,
    val isApk: Boolean = false,
    val packageName: String? = null
)

enum class TransferDirection { SEND, RECEIVE }

enum class TransferState { QUEUED, IN_PROGRESS, COMPLETED, FAILED, CANCELLED }

data class TransferProgress(
    val itemId: String,
    val name: String,
    val direction: TransferDirection,
    val totalBytes: Long,
    val transferredBytes: Long = 0L,
    val state: TransferState = TransferState.QUEUED,
    val isApk: Boolean = false,
    val savedUri: Uri? = null,
    val speedBytesPerSec: Long = 0L,
    val mimeType: String = ""
) {
    val fraction: Float
        get() = if (totalBytes <= 0L) 0f else (transferredBytes.toFloat() / totalBytes.toFloat()).coerceIn(0f, 1f)

    /** Seconds left at the current speed, or null while that can't be estimated. */
    val remainingSeconds: Long?
        get() = if (speedBytesPerSec > 0L && totalBytes > transferredBytes) {
            (totalBytes - transferredBytes) / speedBytesPerSec
        } else {
            null
        }
}

/** Lifecycle of the WiFi Direct link, independent of the app-level session on top of it. */
sealed interface ConnectionState {
    data object Idle : ConnectionState
    data object Discovering : ConnectionState
    data class Connecting(val target: PeerDevice) : ConnectionState
    data class LinkEstablished(val isGroupOwner: Boolean, val groupOwnerAddress: String) : ConnectionState
    data class Failed(val reason: String) : ConnectionState
}

/** App-level session state, layered on top of ConnectionState once a socket is up. */
sealed interface SessionState {
    data object None : SessionState
    data object AwaitingHandshake : SessionState

    /** Initiator side: the socket is up and the peer is deciding whether to accept us. */
    data class AwaitingApproval(val peerName: String) : SessionState

    /** Receiver side: a peer wants to connect and is waiting for the user's decision. */
    data class IncomingRequest(val peerName: String) : SessionState
    data class Connected(val peerName: String) : SessionState
    data object Disconnected : SessionState
}
