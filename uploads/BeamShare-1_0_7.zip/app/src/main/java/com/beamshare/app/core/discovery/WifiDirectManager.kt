package com.beamshare.app.core.discovery

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.wifi.WpsInfo
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pDevice
import android.net.wifi.p2p.WifiP2pManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.Parcelable
import androidx.core.content.ContextCompat
import com.beamshare.app.core.model.ConnectionState
import com.beamshare.app.core.model.PeerDevice
import com.beamshare.app.util.PermissionHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Thin, lifecycle-aware wrapper around [WifiP2pManager]. Owns the broadcast receiver and
 * channel, and exposes everything else as [StateFlow]s so the UI layer never touches the
 * framework callback API directly.
 *
 * Everything here runs on the main thread (the channel is bound to the main looper); public
 * entry points hop there if called from elsewhere.
 *
 * Three framework behaviours shape the design:
 *  - The framework handles one command at a time and answers BUSY to a second one, also when it
 *    is simply mid-negotiation from an earlier connect. Every command therefore goes through one
 *    FIFO queue with a watchdog, and BUSY is retried (after cancelling a half-finished connect we
 *    started ourselves) instead of surfaced.
 *  - Discovery switches itself off after a while and whenever a connection starts. While a screen
 *    wants it, it is restarted - except while a negotiation is under way, which it would break.
 *  - `connect()` only works for a peer the framework has already discovered, and a device's own
 *    P2P address is hidden from apps on newer Android versions - so callers connect to peers taken
 *    from [peers], never to an address read from somewhere else.
 */
class WifiDirectManager(private val context: Context) {

    private val manager: WifiP2pManager? =
        context.getSystemService(Context.WIFI_P2P_SERVICE) as? WifiP2pManager
    private val handler = Handler(Looper.getMainLooper())

    private var channel: WifiP2pManager.Channel? = null
    private var receiver: BroadcastReceiver? = null

    private val _peers = MutableStateFlow<List<PeerDevice>>(emptyList())
    val peers: StateFlow<List<PeerDevice>> = _peers.asStateFlow()

    private val _connectionState = MutableStateFlow<ConnectionState>(ConnectionState.Idle)
    val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()

    private val _thisDevice = MutableStateFlow<PeerDevice?>(null)
    val thisDevice: StateFlow<PeerDevice?> = _thisDevice.asStateFlow()

    val isSupported: Boolean get() = manager != null

    // --- discovery / connect bookkeeping (main thread only) ---
    private var wantDiscovery = false
    private var discoveryRunning = false
    private var discoveryBusyRetries = 0
    private var connectBusyRetries = 0
    private var sawInvited = false

    // --- command queue ---
    private enum class Kind { DISCOVER, STOP_DISCOVERY, CONNECT, CANCEL_CONNECT, REMOVE_GROUP }

    private class Command(val kind: Kind, val block: (done: () -> Unit) -> Unit)

    private val queue = ArrayDeque<Command>()
    private var inFlight: Command? = null

    private val watchdog = Runnable { inFlight?.let { finish(it) } }
    private val restartDiscovery = Runnable {
        if (canRestartDiscovery()) issueDiscovery()
    }
    private val connectTimeout = Runnable {
        if (_connectionState.value is ConnectionState.Connecting) {
            failConnect("Couldn't connect. Make sure the other phone accepted the request, then try again.")
        }
    }

    // ------------------------------------------------------------------------------------------
    // Public API
    // ------------------------------------------------------------------------------------------

    fun start() = onMain {
        val mgr = manager ?: return@onMain
        if (channel == null) {
            channel = mgr.initialize(context, Looper.getMainLooper()) { onChannelLost() }
            clearStaleGroup()
        }
        if (receiver == null) registerReceiver()
        requestThisDeviceInfo()
    }

    /**
     * Actively queries this device's P2P info instead of relying only on
     * WIFI_P2P_THIS_DEVICE_CHANGED_ACTION, which fires on a *change* - if WiFi Direct was
     * already active before the receiver registered, that broadcast may never fire.
     */
    @SuppressLint("MissingPermission")
    fun requestThisDeviceInfo() = onMain {
        val mgr = manager ?: return@onMain
        val ch = channel ?: return@onMain
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && hasNearbyPermission()) {
            runCatching {
                mgr.requestDeviceInfo(ch) { device -> device?.let { _thisDevice.value = it.toPeerDevice() } }
            }
        }
    }

    fun startDiscovery() = onMain {
        if (manager == null || channel == null || !hasNearbyPermission()) return@onMain
        wantDiscovery = true
        discoveryBusyRetries = 0
        val state = _connectionState.value
        if (state !is ConnectionState.Connecting && state !is ConnectionState.LinkEstablished) {
            _connectionState.value = ConnectionState.Discovering
        }
        issueDiscovery()
    }

    fun stopDiscovery() = onMain {
        wantDiscovery = false
        handler.removeCallbacks(restartDiscovery)
        queue.removeAll { it.kind == Kind.DISCOVER }
        val mgr = manager ?: return@onMain
        val ch = channel ?: return@onMain
        if (!hasNearbyPermission()) return@onMain
        submit(Kind.STOP_DISCOVERY) { done -> mgr.stopPeerDiscovery(ch, listener(done)) }
    }

    /** Connects to a peer taken from [peers]. */
    fun connect(device: PeerDevice) = onMain {
        if (manager == null || channel == null || !hasNearbyPermission()) return@onMain
        wantDiscovery = false
        handler.removeCallbacks(restartDiscovery)
        handler.removeCallbacks(connectTimeout)
        sawInvited = false
        connectBusyRetries = 0
        _connectionState.value = ConnectionState.Connecting(device)
        handler.postDelayed(connectTimeout, CONNECT_TIMEOUT_MS)
        issueConnect(device)
    }

    /** Abandons any connection attempt and removes the group; leaves the link idle. */
    fun disconnect() = onMain { teardownLink() }

    /** Stops everything this manager started - used when no screen needs WiFi Direct any more. */
    fun release() = onMain {
        teardownLink()
        val mgr = manager
        val ch = channel
        if (mgr != null && ch != null && hasNearbyPermission()) {
            submit(Kind.STOP_DISCOVERY) { done -> mgr.stopPeerDiscovery(ch, listener(done)) }
        }
        _peers.value = emptyList()
    }

    fun hasNearbyPermission(): Boolean = PermissionHelper.hasNearbyPermission(context)

    // ------------------------------------------------------------------------------------------
    // Command queue
    // ------------------------------------------------------------------------------------------

    /** Queues [block]; a still-waiting command of the same kind is replaced, only the latest intent matters. */
    private fun submit(kind: Kind, block: (done: () -> Unit) -> Unit) {
        queue.removeAll { it.kind == kind }
        queue.addLast(Command(kind, block))
        pump()
    }

    private fun pump() {
        if (inFlight != null) return
        val command = queue.removeFirstOrNull() ?: return
        inFlight = command
        handler.postDelayed(watchdog, COMMAND_WATCHDOG_MS)
        try {
            command.block { finish(command) }
        } catch (e: Exception) {
            // e.g. a SecurityException if permission was revoked mid-flight
            finish(command)
        }
    }

    private fun finish(command: Command) {
        if (inFlight !== command) return
        handler.removeCallbacks(watchdog)
        inFlight = null
        pump()
    }

    private fun listener(done: () -> Unit): WifiP2pManager.ActionListener = object : WifiP2pManager.ActionListener {
        override fun onSuccess() = done()
        override fun onFailure(reason: Int) = done()
    }

    // ------------------------------------------------------------------------------------------
    // Discovery
    // ------------------------------------------------------------------------------------------

    @SuppressLint("MissingPermission") // presence enforced by hasNearbyPermission() before every entry
    private fun issueDiscovery() {
        val mgr = manager ?: return
        val ch = channel ?: return
        submit(Kind.DISCOVER) { done ->
            mgr.discoverPeers(ch, object : WifiP2pManager.ActionListener {
                override fun onSuccess() {
                    discoveryBusyRetries = 0
                    done()
                    refreshPeers()
                }

                override fun onFailure(reason: Int) {
                    done()
                    if (!wantDiscovery) return
                    if (reason == WifiP2pManager.BUSY && discoveryBusyRetries < MAX_BUSY_RETRIES) {
                        // The framework is mid-negotiation or finishing the previous command.
                        // Waiting is right; cancelling here could kill an incoming connection.
                        discoveryBusyRetries++
                        handler.postDelayed({ if (wantDiscovery) issueDiscovery() }, BUSY_RETRY_DELAY_MS)
                    } else {
                        wantDiscovery = false
                        val state = _connectionState.value
                        if (state !is ConnectionState.Connecting && state !is ConnectionState.LinkEstablished) {
                            _connectionState.value = ConnectionState.Failed(reasonToMessage(reason))
                        }
                    }
                }
            })
        }
    }

    /** Re-arms discovery after the framework stopped it, unless a connection is forming. */
    private fun maybeRestartDiscovery() {
        if (!canRestartDiscovery()) return
        handler.removeCallbacks(restartDiscovery)
        handler.postDelayed(restartDiscovery, DISCOVERY_RESTART_DELAY_MS)
    }

    /** Checked again when the delayed restart fires, since a negotiation may have begun meanwhile. */
    private fun canRestartDiscovery(): Boolean {
        if (!wantDiscovery || discoveryRunning) return false
        val state = _connectionState.value
        if (state is ConnectionState.Connecting || state is ConnectionState.LinkEstablished) return false
        return _peers.value.none {
            it.status == PeerDevice.STATUS_INVITED || it.status == PeerDevice.STATUS_CONNECTED
        }
    }

    @SuppressLint("MissingPermission")
    private fun refreshPeers() {
        val mgr = manager ?: return
        val ch = channel ?: return
        if (!hasNearbyPermission()) return
        runCatching {
            mgr.requestPeers(ch) { list ->
                val updated = list.deviceList.map { it.toPeerDevice() }
                _peers.value = updated
                checkConnectionProgress(updated)
                maybeRestartDiscovery()
            }
        }
    }

    // ------------------------------------------------------------------------------------------
    // Connecting
    // ------------------------------------------------------------------------------------------

    @SuppressLint("MissingPermission")
    private fun issueConnect(device: PeerDevice) {
        val mgr = manager ?: return
        val ch = channel ?: return
        val config = WifiP2pConfig().apply {
            deviceAddress = device.macAddress
            wps.setup = WpsInfo.PBC
        }
        submit(Kind.CONNECT) { done ->
            mgr.connect(ch, config, object : WifiP2pManager.ActionListener {
                override fun onSuccess() {
                    connectBusyRetries = 0
                    done()
                }

                override fun onFailure(reason: Int) {
                    done()
                    if (_connectionState.value !is ConnectionState.Connecting) return
                    if (reason == WifiP2pManager.BUSY && connectBusyRetries < MAX_BUSY_RETRIES) {
                        // Probably a stale negotiation of ours: clear it, give the framework a
                        // moment, then try again.
                        connectBusyRetries++
                        cancelPendingConnect()
                        handler.postDelayed({
                            if (_connectionState.value is ConnectionState.Connecting) issueConnect(device)
                        }, BUSY_RETRY_DELAY_MS)
                    } else {
                        failConnect(reasonToMessage(reason))
                    }
                }
            })
        }
    }

    @SuppressLint("MissingPermission")
    private fun cancelPendingConnect() {
        val mgr = manager ?: return
        val ch = channel ?: return
        submit(Kind.CANCEL_CONNECT) { done -> mgr.cancelConnect(ch, listener(done)) }
    }

    private fun failConnect(reason: String) {
        handler.removeCallbacks(connectTimeout)
        sawInvited = false
        cancelPendingConnect()
        _connectionState.value = ConnectionState.Failed(reason)
    }

    /**
     * The framework gives no direct "declined" callback. A peer we invited shows up as INVITED in
     * the peer list; if it later drops back to AVAILABLE (or FAILED) the other user said no or the
     * invitation timed out.
     */
    private fun checkConnectionProgress(peers: List<PeerDevice>) {
        val connecting = _connectionState.value as? ConnectionState.Connecting ?: return
        val target = peers.firstOrNull { it.macAddress.equals(connecting.target.macAddress, ignoreCase = true) } ?: return
        when (target.status) {
            PeerDevice.STATUS_INVITED -> sawInvited = true
            PeerDevice.STATUS_FAILED -> failConnect("Couldn't connect to ${target.name}.")
            PeerDevice.STATUS_AVAILABLE -> if (sawInvited) failConnect("${target.name} didn't accept the connection.")
        }
    }

    @SuppressLint("MissingPermission")
    private fun teardownLink() {
        handler.removeCallbacks(connectTimeout)
        handler.removeCallbacks(restartDiscovery)
        wantDiscovery = false
        sawInvited = false
        val mgr = manager
        val ch = channel
        if (mgr != null && ch != null) {
            queue.removeAll { it.kind == Kind.DISCOVER || it.kind == Kind.CONNECT }
            cancelPendingConnect()
            submit(Kind.REMOVE_GROUP) { done -> mgr.removeGroup(ch, listener(done)) }
        }
        _connectionState.value = ConnectionState.Idle
    }

    /** A group left over from a previous run of the app would make the next connect misbehave. */
    @SuppressLint("MissingPermission")
    private fun clearStaleGroup() {
        val mgr = manager ?: return
        val ch = channel ?: return
        if (!hasNearbyPermission()) return
        runCatching {
            mgr.requestGroupInfo(ch) { group ->
                if (group != null) submit(Kind.REMOVE_GROUP) { done -> mgr.removeGroup(ch, listener(done)) }
            }
        }
    }

    // ------------------------------------------------------------------------------------------
    // Broadcasts
    // ------------------------------------------------------------------------------------------

    private fun registerReceiver() {
        val filter = IntentFilter().apply {
            addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_DISCOVERY_CHANGED_ACTION)
        }
        val r = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context, intent: Intent) {
                handleBroadcast(intent)
            }
        }
        receiver = r
        ContextCompat.registerReceiver(context, r, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
    }

    private fun handleBroadcast(intent: Intent) {
        val mgr = manager ?: return
        val ch = channel ?: return
        when (intent.action) {
            WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION -> refreshPeers()

            WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION -> {
                // Ask for the connection info on every change instead of trusting the (deprecated)
                // NetworkInfo extra: groupFormed is the authoritative answer either way.
                mgr.requestConnectionInfo(ch) { info ->
                    val owner = info?.groupOwnerAddress
                    if (info != null && info.groupFormed && owner != null) {
                        handler.removeCallbacks(connectTimeout)
                        _connectionState.value = ConnectionState.LinkEstablished(
                            isGroupOwner = info.isGroupOwner,
                            groupOwnerAddress = owner.hostAddress.orEmpty()
                        )
                    } else if (_connectionState.value is ConnectionState.LinkEstablished) {
                        _connectionState.value = ConnectionState.Idle
                    }
                }
            }

            WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION -> {
                intent.getParcelableExtraCompat<WifiP2pDevice>(WifiP2pManager.EXTRA_WIFI_P2P_DEVICE)?.let {
                    _thisDevice.value = it.toPeerDevice()
                }
            }

            WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION -> {
                val enabled = intent.getIntExtra(WifiP2pManager.EXTRA_WIFI_STATE, -1) ==
                    WifiP2pManager.WIFI_P2P_STATE_ENABLED
                if (enabled) {
                    requestThisDeviceInfo()
                    if (_connectionState.value is ConnectionState.Failed) _connectionState.value = ConnectionState.Idle
                } else {
                    _connectionState.value = ConnectionState.Failed("WiFi was turned off. Turn it back on to continue.")
                }
            }

            WifiP2pManager.WIFI_P2P_DISCOVERY_CHANGED_ACTION -> {
                val state = intent.getIntExtra(
                    WifiP2pManager.EXTRA_DISCOVERY_STATE,
                    WifiP2pManager.WIFI_P2P_DISCOVERY_STOPPED
                )
                discoveryRunning = state == WifiP2pManager.WIFI_P2P_DISCOVERY_STARTED
                maybeRestartDiscovery()
            }
        }
    }

    private fun onChannelLost() {
        channel = null
        queue.clear()
        inFlight = null
        handler.removeCallbacks(watchdog)
        handler.removeCallbacks(restartDiscovery)
        wantDiscovery = false
        discoveryRunning = false
        _connectionState.value = ConnectionState.Failed("WiFi Direct was interrupted by the system. Try again.")
    }

    // ------------------------------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------------------------------

    private fun onMain(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) block() else handler.post { block() }
    }

    private fun WifiP2pDevice.toPeerDevice() = PeerDevice(
        macAddress = deviceAddress.orEmpty(),
        name = deviceName.orEmpty().ifBlank { deviceAddress.orEmpty() },
        isGroupOwner = isGroupOwner,
        status = status
    )

    private fun reasonToMessage(reason: Int): String = when (reason) {
        WifiP2pManager.P2P_UNSUPPORTED -> "WiFi Direct isn't supported on this device."
        WifiP2pManager.BUSY -> "WiFi Direct is busy. Wait a few seconds and try again."
        WifiP2pManager.ERROR -> if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            "WiFi Direct couldn't start. Make sure WiFi and Location are both turned on."
        } else {
            "WiFi Direct couldn't start. Make sure WiFi is turned on."
        }
        else -> "WiFi Direct error ($reason)."
    }

    private companion object {
        const val BUSY_RETRY_DELAY_MS = 1_500L
        const val MAX_BUSY_RETRIES = 4
        const val COMMAND_WATCHDOG_MS = 10_000L
        const val DISCOVERY_RESTART_DELAY_MS = 1_000L
        const val CONNECT_TIMEOUT_MS = 60_000L
    }
}

private inline fun <reified T : Parcelable> Intent.getParcelableExtraCompat(key: String): T? =
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        getParcelableExtra(key, T::class.java)
    } else {
        @Suppress("DEPRECATION")
        getParcelableExtra(key)
    }
