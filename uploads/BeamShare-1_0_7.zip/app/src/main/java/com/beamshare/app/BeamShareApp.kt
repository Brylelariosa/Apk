package com.beamshare.app

import android.app.Application
import android.os.Build
import android.provider.Settings
import com.beamshare.app.di.ServiceLocator

class BeamShareApp : Application() {
    override fun onCreate() {
        super.onCreate()
        ServiceLocator.init(this)
        ServiceLocator.sessionManager.localDeviceName = deviceDisplayName()
    }

    /** The name the user gave their phone in Settings, falling back to the hardware model. */
    private fun deviceDisplayName(): String {
        val configured = runCatching { Settings.Global.getString(contentResolver, Settings.Global.DEVICE_NAME) }.getOrNull()
        return configured?.takeIf { it.isNotBlank() } ?: Build.MODEL.orEmpty().ifBlank { "BeamShare device" }
    }
}
