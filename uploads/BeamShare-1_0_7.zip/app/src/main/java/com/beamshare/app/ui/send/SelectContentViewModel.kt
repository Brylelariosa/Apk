package com.beamshare.app.ui.send

import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.beamshare.app.core.apps.InstalledApp
import com.beamshare.app.core.apps.InstalledAppsRepository
import com.beamshare.app.core.apps.toTransferItem
import com.beamshare.app.core.files.FileRepository
import com.beamshare.app.core.images.DeviceImage
import com.beamshare.app.core.images.ImageRepository
import com.beamshare.app.core.images.toTransferItem
import com.beamshare.app.core.model.TransferItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class SelectContentViewModel(
    private val installedAppsRepository: InstalledAppsRepository,
    private val fileRepository: FileRepository,
    private val imageRepository: ImageRepository
) : ViewModel() {

    private val _apps = MutableStateFlow<List<InstalledApp>>(emptyList())
    private val _selectedPackages = MutableStateFlow<Set<String>>(emptySet())
    private val _selectedFiles = MutableStateFlow<List<TransferItem>>(emptyList())
    private val _searchQuery = MutableStateFlow("")
    private val _loadingApps = MutableStateFlow(false)
    private val _images = MutableStateFlow<List<DeviceImage>>(emptyList())
    // A LinkedHashSet underneath, so pictures are sent in the order they were tapped.
    private val _selectedImageIds = MutableStateFlow<Set<Long>>(emptySet())
    private val _loadingImages = MutableStateFlow(false)

    val selectedFiles: StateFlow<List<TransferItem>> = _selectedFiles.asStateFlow()
    val selectedPackages: StateFlow<Set<String>> = _selectedPackages.asStateFlow()
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()
    val loadingApps: StateFlow<Boolean> = _loadingApps.asStateFlow()
    val images: StateFlow<List<DeviceImage>> = _images.asStateFlow()
    val selectedImageIds: StateFlow<Set<Long>> = _selectedImageIds.asStateFlow()
    val loadingImages: StateFlow<Boolean> = _loadingImages.asStateFlow()

    val filteredApps: StateFlow<List<InstalledApp>> = combine(_apps, _searchQuery) { apps, query ->
        if (query.isBlank()) apps else apps.filter { it.label.contains(query.trim(), ignoreCase = true) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val totalSelectedCount: StateFlow<Int> = combine(_selectedPackages, _selectedFiles, _selectedImageIds) { apps, files, imageIds ->
        apps.size + files.size + imageIds.size
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)

    val totalSelectedBytes: StateFlow<Long> = combine(
        _selectedPackages, _selectedFiles, _apps, _selectedImageIds, _images
    ) { packages, files, apps, imageIds, images ->
        val appBytes = apps.filter { it.packageName in packages }.sumOf { it.apkSizeBytes }
        val imageBytes = images.filter { it.id in imageIds }.sumOf { it.sizeBytes }
        appBytes + imageBytes + files.sumOf { it.sizeBytes }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0L)

    fun loadAppsIfNeeded() {
        if (_apps.value.isNotEmpty() || _loadingApps.value) return
        _loadingApps.value = true
        viewModelScope.launch(Dispatchers.IO) {
            val apps = runCatching { installedAppsRepository.launchableApps() }.getOrDefault(emptyList())
            _apps.value = apps
            _loadingApps.value = false
        }
    }

    /**
     * Reads the gallery. Safe to call whenever the Images tab is shown: a refresh that finds the same
     * pictures changes nothing on screen, and the list keeps showing while it runs.
     */
    fun loadImages() {
        if (_loadingImages.value) return
        _loadingImages.value = true
        viewModelScope.launch(Dispatchers.IO) {
            val images = runCatching { imageRepository.queryImages() }.getOrDefault(emptyList())
            val available = images.mapTo(HashSet<Long>()) { it.id }
            _images.value = images
            // A picture that disappeared (deleted, or no longer shared with the app) can't be sent.
            _selectedImageIds.update { ids -> ids.filterTo(LinkedHashSet<Long>()) { it in available } }
            _loadingImages.value = false
        }
    }

    fun toggleImage(id: Long) {
        _selectedImageIds.update { current -> if (id in current) current - id else current + id }
    }

    /** A preview that is already in memory, so a cell never flashes empty when it scrolls back. */
    fun cachedThumbnail(image: DeviceImage): Bitmap? = imageRepository.cachedThumbnail(image)

    suspend fun loadThumbnail(image: DeviceImage): Bitmap? = imageRepository.loadThumbnail(image)

    fun onSearchQueryChange(query: String) {
        _searchQuery.value = query
    }

    fun toggleApp(packageName: String) {
        _selectedPackages.update { current -> if (packageName in current) current - packageName else current + packageName }
    }

    fun addFileUris(uris: List<Uri>) {
        viewModelScope.launch(Dispatchers.IO) {
            val alreadyAdded = _selectedFiles.value.mapNotNull { it.sourceUri }.toSet()
            // One unreadable document shouldn't discard the rest of the selection.
            val items = uris
                .filter { it !in alreadyAdded }
                .mapNotNull { uri -> runCatching { fileRepository.transferItemFromUri(uri) }.getOrNull() }
            if (items.isNotEmpty()) _selectedFiles.update { it + items }
        }
    }

    fun removeFile(id: String) {
        _selectedFiles.update { list -> list.filterNot { it.id == id } }
    }

    fun buildTransferItems(): List<TransferItem> {
        val imagesById = _images.value.associateBy { it.id }
        val imageItems = _selectedImageIds.value.mapNotNull { imagesById[it]?.toTransferItem() }
        val appItems = _apps.value.filter { it.packageName in _selectedPackages.value }.map { it.toTransferItem() }
        return _selectedFiles.value + imageItems + appItems
    }

    override fun onCleared() {
        // The previews are only useful while this screen is; don't keep a few megabytes of pixels around.
        imageRepository.clearThumbnailCache()
    }
}
