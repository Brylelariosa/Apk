package com.beamshare.app.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.beamshare.app.R
import com.beamshare.app.core.model.TransferDirection
import com.beamshare.app.core.model.TransferProgress
import com.beamshare.app.core.model.TransferState
import com.beamshare.app.ui.theme.BeamBlueLight
import com.beamshare.app.ui.theme.BeamBrandBrush
import com.beamshare.app.ui.theme.BeamMint
import com.beamshare.app.ui.theme.NumericReadoutStyle
import com.beamshare.app.util.FormatUtils

/** A rounded progress bar with a smooth brand-gradient fill. */
@Composable
fun BeamProgressBar(fraction: Float, modifier: Modifier = Modifier, height: Dp = 6.dp) {
    val animated by animateFloatAsState(
        targetValue = fraction.coerceIn(0f, 1f),
        animationSpec = tween(durationMillis = 250),
        label = "progressFill"
    )
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(height)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.surfaceContainerHighest)
    ) {
        Box(
            Modifier
                .fillMaxWidth(animated)
                .fillMaxHeight()
                .background(BeamBrandBrush, CircleShape)
        )
    }
}

/** One file moving in either direction: type badge, name, live status, progress, and a result action. */
@Composable
fun TransferProgressRow(
    progress: TransferProgress,
    modifier: Modifier = Modifier,
    onOpen: (() -> Unit)? = null
) {
    val kind = fileKindOf(progress.mimeType, progress.name, progress.isApk)
    val active = progress.state == TransferState.IN_PROGRESS || progress.state == TransferState.QUEUED
    BeamCard(modifier = modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box {
                    KindBadge(kind)
                    DirectionDot(progress.direction, Modifier.align(Alignment.BottomEnd).offset(x = 4.dp, y = 4.dp))
                }
                Column(Modifier.weight(1f)) {
                    Text(
                        progress.name,
                        style = MaterialTheme.typography.titleSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        statusLabel(progress),
                        style = NumericReadoutStyle,
                        color = statusColor(progress),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                TrailingAction(progress, onOpen)
            }
            if (active) {
                Spacer(Modifier.height(12.dp))
                BeamProgressBar(fraction = if (progress.state == TransferState.QUEUED) 0f else progress.fraction)
            }
        }
    }
}

/** A small up/down arrow stuck to the corner of a file badge. */
@Composable
private fun DirectionDot(direction: TransferDirection, modifier: Modifier = Modifier) {
    val sending = direction == TransferDirection.SEND
    Box(
        modifier = modifier
            .size(18.dp)
            .background(if (sending) BeamBlueLight else BeamMint, CircleShape)
            .border(2.dp, MaterialTheme.colorScheme.surfaceContainer, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            ImageVector.vectorResource(if (sending) R.drawable.ic_arrow_upward else R.drawable.ic_arrow_downward),
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(10.dp)
        )
    }
}

@Composable
private fun TrailingAction(progress: TransferProgress, onOpen: (() -> Unit)?) {
    when (progress.state) {
        TransferState.COMPLETED -> {
            if (onOpen != null && progress.direction == TransferDirection.RECEIVE && progress.savedUri != null) {
                TextButton(onClick = onOpen) {
                    Text(stringResource(if (progress.isApk) R.string.transfer_install else R.string.transfer_open))
                }
            } else {
                Icon(
                    ImageVector.vectorResource(R.drawable.ic_check_circle),
                    contentDescription = null,
                    tint = BeamMint
                )
            }
        }
        TransferState.FAILED -> Icon(
            ImageVector.vectorResource(R.drawable.ic_error_outline),
            contentDescription = null,
            tint = MaterialTheme.colorScheme.error
        )
        TransferState.CANCELLED -> Icon(
            ImageVector.vectorResource(R.drawable.ic_close),
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant
        )
        TransferState.IN_PROGRESS -> Text(
            "${(progress.fraction * 100).toInt()}%",
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.primary
        )
        TransferState.QUEUED -> Unit
    }
}

@Composable
private fun statusColor(p: TransferProgress): Color = when (p.state) {
    TransferState.COMPLETED -> MaterialTheme.colorScheme.tertiary
    TransferState.FAILED -> MaterialTheme.colorScheme.error
    else -> MaterialTheme.colorScheme.onSurfaceVariant
}

@Composable
private fun statusLabel(p: TransferProgress): String = when (p.state) {
    TransferState.QUEUED -> stringResource(R.string.transfer_queued)
    TransferState.IN_PROGRESS -> {
        val base = stringResource(
            R.string.transfer_in_progress,
            FormatUtils.formatBytes(p.transferredBytes),
            FormatUtils.formatBytes(p.totalBytes),
            FormatUtils.formatSpeed(p.speedBytesPerSec)
        )
        val remaining = p.remainingSeconds
        if (remaining != null) base + " · " + stringResource(R.string.transfer_eta, FormatUtils.formatDuration(remaining)) else base
    }
    TransferState.COMPLETED -> stringResource(
        if (p.direction == TransferDirection.SEND) R.string.transfer_sent else R.string.transfer_received,
        FormatUtils.formatBytes(p.totalBytes)
    )
    TransferState.FAILED -> stringResource(R.string.transfer_failed)
    TransferState.CANCELLED -> stringResource(
        if (p.direction == TransferDirection.SEND) R.string.transfer_declined else R.string.transfer_cancelled
    )
}
