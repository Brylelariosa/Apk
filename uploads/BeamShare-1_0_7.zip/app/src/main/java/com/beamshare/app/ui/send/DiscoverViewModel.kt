package com.beamshare.app.ui.send

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.beamshare.app.core.discovery.WifiDirectManager
import com.beamshare.app.core.model.ConnectionState
import com.beamshare.app.core.model.PeerDevice
import com.beamshare.app.core.model.SessionState
import com.beamshare.app.core.qr.ConnectPayload
import com.beamshare.app.core.transfer.SessionManager
import com.beamshare.app.core.transfer.SessionRole
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.mapNotNull
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

class DiscoverViewModel(
    private val wifiDirectManager: WifiDirectManager,
    private val sessionManager: SessionManager
) : ViewModel() {

    val peers: StateFlow<List<PeerDevice>> = wifiDirectManager.peers
    val connectionState: StateFlow<ConnectionState> = wifiDirectManager.connectionState
    val sessionState: StateFlow<SessionState> = sessionManager.sessionState
    val endReason: StateFlow<String?> = sessionManager.endReason

    private val _lookingFor = MutableStateFlow<String?>(null)
    /** Name of the device a scanned QR code points at, while we wait for it to show up in discovery. */
    val lookingFor: StateFlow<String?> = _lookingFor.asStateFlow()

    private val _failure = MutableStateFlow<String?>(null)
    /** A failure that happened in this screen's own flow (as opposed to the link or session failing). */
    val failure: StateFlow<String?> = _failure.asStateFlow()

    private var lookupJob: Job? = null

    fun startDiscovery() {
        _failure.value = null
        wifiDirectManager.start()
        sessionManager.watchForLink(SessionRole.INITIATOR)
        wifiDirectManager.startDiscovery()
    }

    fun connectToDevice(device: PeerDevice) {
        cancelLookup()
        _failure.value = null
        wifiDirectManager.connect(device)
    }

    /**
     * A QR code only says *who* to connect to. The actual connection must use the address this
     * phone discovered for that device, so wait until discovery has seen it, then connect.
     */
    fun connectToQrPayload(payload: ConnectPayload) {
        lookupJob?.cancel()
        _lookingFor.value = payload.deviceName
        wifiDirectManager.startDiscovery()
        lookupJob = viewModelScope.launch {
            val match = withTimeoutOrNull(QR_LOOKUP_TIMEOUT_MS) {
                wifiDirectManager.peers
                    .mapNotNull { list -> list.firstOrNull { payload.matches(it) } }
                    .first()
            }
            _lookingFor.value = null
            if (match != null) {
                wifiDirectManager.connect(match)
            } else {
                _failure.value = "Couldn't find ${payload.deviceName}. Make sure its Receive screen is open, then try again."
            }
        }
    }

    fun cancelLookup() {
        lookupJob?.cancel()
        lookupJob = null
        _lookingFor.value = null
    }

    /** Back to a clean discovery after a failure or a cancelled attempt. */
    fun restart() {
        cancelLookup()
        _failure.value = null
        sessionManager.abortPairing()
        startDiscovery()
    }

    override fun onCleared() {
        lookupJob?.cancel()
        // Leaving the screen without a live session: release WiFi Direct and let the service stop.
        sessionManager.cancelPairing()
    }

    private companion object {
        const val QR_LOOKUP_TIMEOUT_MS = 25_000L
    }
}
