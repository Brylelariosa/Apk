package com.beamshare.app.core.qr

import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import com.beamshare.app.core.model.PeerDevice
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import java.net.URLEncoder

/**
 * What a BeamShare QR code encodes: which device to connect to.
 *
 * The name is what the scanning phone matches against its own discovery results. The MAC is only
 * included when the OS actually exposes a real one - newer Android versions replace a device's own
 * P2P address with a placeholder, and even a real one is only a hint, because the connection itself
 * always uses the address the scanning phone discovered for that device.
 */
data class ConnectPayload(val macAddress: String?, val deviceName: String) {

    fun encode(): String {
        val builder = StringBuilder("$SCHEME://$HOST?name=").append(URLEncoder.encode(deviceName, "UTF-8"))
        if (!macAddress.isNullOrBlank()) builder.append("&mac=").append(URLEncoder.encode(macAddress, "UTF-8"))
        return builder.toString()
    }

    /** True if [peer], as seen in a discovery list, is the device this code was generated for. */
    fun matches(peer: PeerDevice): Boolean {
        if (!macAddress.isNullOrBlank() && macAddress.equals(peer.macAddress, ignoreCase = true)) return true
        return peer.name.trim().equals(deviceName.trim(), ignoreCase = true)
    }

    companion object {
        private const val SCHEME = "beamshare"
        private const val HOST = "connect"
        private val MAC_REGEX = Regex("^([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$")

        /** The payload this device shows on its Receive screen. */
        fun forThisDevice(device: PeerDevice): ConnectPayload {
            val usableMac = device.macAddress.takeIf {
                it.matches(MAC_REGEX) && !it.equals(PeerDevice.ANONYMIZED_ADDRESS, ignoreCase = true)
            }
            return ConnectPayload(usableMac, device.name)
        }

        fun decode(raw: String): ConnectPayload? {
            val uri = runCatching { Uri.parse(raw.trim()) }.getOrNull() ?: return null
            if (uri.scheme != SCHEME || uri.host != HOST) return null
            val mac = uri.getQueryParameter("mac")?.takeIf { it.matches(MAC_REGEX) }
            val name = uri.getQueryParameter("name")?.takeIf { it.isNotBlank() } ?: mac ?: return null
            return ConnectPayload(mac, name)
        }
    }
}

object QrCodeGenerator {
    private const val DARK = 0xFF000000.toInt()
    private const val LIGHT = 0xFFFFFFFF.toInt()

    /**
     * Renders [text] as a QR bitmap with crisp, integer-scaled modules at least [minSizePx] wide.
     * Pixels are written in one batch - per-pixel setPixel() calls were noticeably slow on
     * low-end phones.
     */
    fun generate(text: String, minSizePx: Int = 480): ImageBitmap {
        val hints = mapOf(
            EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.M,
            EncodeHintType.MARGIN to 1
        )
        val matrix = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, 0, 0, hints)
        val modules = matrix.width
        val scale = (minSizePx / modules).coerceAtLeast(1)
        val size = modules * scale
        val pixels = IntArray(size * size)
        for (y in 0 until size) {
            val moduleY = y / scale
            for (x in 0 until size) {
                pixels[y * size + x] = if (matrix.get(x / scale, moduleY)) DARK else LIGHT
            }
        }
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        bitmap.setPixels(pixels, 0, size, 0, 0, size, size)
        return bitmap.asImageBitmap()
    }
}
