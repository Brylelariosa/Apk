package com.beamshare.app.ui.send

import android.content.Context
import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.beamshare.app.R
import com.beamshare.app.core.images.DeviceImage
import com.beamshare.app.ui.components.BeamPrimaryButton
import com.beamshare.app.ui.components.BeamSecondaryButton
import com.beamshare.app.ui.components.EmptyState
import com.beamshare.app.ui.components.InfoBanner
import com.beamshare.app.ui.util.OnResumeEffect
import com.beamshare.app.util.PermissionHelper

/**
 * Whether the gallery can be read right now. It re-checks every time the screen resumes, so it
 * stays correct after the system permission dialog or a trip to the app's settings page.
 */
@Stable
internal class ImageAccessState(private val context: Context) {
    var hasAccess by mutableStateOf(PermissionHelper.hasImageAccess(context))
        private set

    /** Android 14+: access exists, but only to the pictures the user chose to share. */
    var isPartial by mutableStateOf(PermissionHelper.hasOnlyPartialImageAccess(context))
        private set

    fun refresh() {
        hasAccess = PermissionHelper.hasImageAccess(context)
        isPartial = PermissionHelper.hasOnlyPartialImageAccess(context)
    }
}

@Composable
internal fun rememberImageAccessState(): ImageAccessState {
    val context = LocalContext.current
    val state = remember(context) { ImageAccessState(context) }
    OnResumeEffect { state.refresh() }
    return state
}

/**
 * The Images tab: small square previews of the phone's pictures. Tapping a preview selects it,
 * so several can be picked and sent together through the same "Next" bar as files and apps.
 */
@Composable
internal fun ImagesTab(
    hasAccess: Boolean,
    isPartialAccess: Boolean,
    permissionDenied: Boolean,
    images: List<DeviceImage>,
    selectedIds: Set<Long>,
    loading: Boolean,
    gridState: LazyGridState,
    cachedThumbnail: (DeviceImage) -> Bitmap?,
    loadThumbnail: suspend (DeviceImage) -> Bitmap?,
    onRequestAccess: () -> Unit,
    onOpenSettings: () -> Unit,
    onToggle: (Long) -> Unit
) {
    if (!hasAccess) {
        ImagesPermissionPrompt(denied = permissionDenied, onAllow = onRequestAccess, onOpenSettings = onOpenSettings)
        return
    }
    Column(Modifier.fillMaxSize()) {
        if (isPartialAccess) {
            PartialAccessNote(onChooseMore = onRequestAccess, modifier = Modifier.padding(horizontal = 20.dp))
        }
        when {
            images.isEmpty() && loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            images.isEmpty() -> EmptyState(
                icon = ImageVector.vectorResource(R.drawable.ic_image),
                title = stringResource(R.string.select_no_images_title),
                subtitle = stringResource(R.string.select_no_images_subtitle),
                modifier = Modifier.padding(top = 32.dp)
            )
            else -> LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 90.dp),
                modifier = Modifier.fillMaxSize(),
                state = gridState,
                contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 4.dp, bottom = 24.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(images, key = { it.id }) { image ->
                    ImageCell(
                        image = image,
                        selected = image.id in selectedIds,
                        cachedThumbnail = cachedThumbnail,
                        loadThumbnail = loadThumbnail,
                        onToggle = { onToggle(image.id) }
                    )
                }
            }
        }
    }
}

@Composable
private fun ImageCell(
    image: DeviceImage,
    selected: Boolean,
    cachedThumbnail: (DeviceImage) -> Bitmap?,
    loadThumbnail: suspend (DeviceImage) -> Bitmap?,
    onToggle: () -> Unit
) {
    // Starts from the in-memory preview when there is one, so scrolling back never flashes an empty tile.
    val thumbnail by produceState(initialValue = cachedThumbnail(image), key1 = image.id) {
        if (value == null) value = loadThumbnail(image)
    }
    val preview = remember(thumbnail) { thumbnail?.asImageBitmap() }
    val shape = RoundedCornerShape(12.dp)

    Box(
        modifier = Modifier
            .aspectRatio(1f)
            .clip(shape)
            .background(MaterialTheme.colorScheme.surfaceContainerHigh)
            .semantics { contentDescription = image.displayName }
            .toggleable(value = selected, role = Role.Checkbox, onValueChange = { onToggle() })
    ) {
        if (preview != null) {
            Image(
                bitmap = preview,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Icon(
                ImageVector.vectorResource(R.drawable.ic_image),
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.45f),
                modifier = Modifier.align(Alignment.Center).size(26.dp)
            )
        }
        if (selected) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.22f))
                    .border(3.dp, MaterialTheme.colorScheme.primary, shape)
            )
        }
        SelectionBadge(selected = selected, modifier = Modifier.align(Alignment.TopEnd).padding(6.dp))
    }
}

/** Readable on top of any photo: a white ring over a dim disc, filled with the accent colour once picked. */
@Composable
private fun SelectionBadge(selected: Boolean, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(22.dp)
            .clip(CircleShape)
            .background(if (selected) MaterialTheme.colorScheme.primary else Color.Black.copy(alpha = 0.28f))
            .border(1.5.dp, Color.White, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        if (selected) {
            Icon(
                ImageVector.vectorResource(R.drawable.ic_check),
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(13.dp)
            )
        }
    }
}

@Composable
private fun PartialAccessNote(onChooseMore: () -> Unit, modifier: Modifier = Modifier) {
    Column(modifier) {
        InfoBanner(text = stringResource(R.string.select_images_partial_note))
        TextButton(onClick = onChooseMore, modifier = Modifier.align(Alignment.End)) {
            Text(stringResource(R.string.select_images_partial_action))
        }
    }
}

@Composable
private fun ImagesPermissionPrompt(denied: Boolean, onAllow: () -> Unit, onOpenSettings: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        EmptyState(
            icon = ImageVector.vectorResource(R.drawable.ic_image),
            title = stringResource(R.string.select_images_permission_title),
            subtitle = stringResource(R.string.select_images_permission_subtitle)
        )
        BeamPrimaryButton(text = stringResource(R.string.select_images_allow), onClick = onAllow)
        if (denied) {
            // After two refusals Android stops showing the dialog, so the settings page is the way back.
            Spacer(Modifier.height(8.dp))
            BeamSecondaryButton(text = stringResource(R.string.ready_permission_settings), onClick = onOpenSettings)
        }
        Spacer(Modifier.height(48.dp))
    }
}
