package com.beamshare.app.core.transfer

import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.IOException

/**
 * Wire format for the control channel riding on the WiFi Direct TCP socket.
 * Every control message is `[1 byte type][4 byte big-endian length][payload]`.
 * Raw file bytes are streamed immediately after a FILE_START frame with no further
 * per-chunk framing overhead, since both sides already know the exact size from the
 * matching OFFER - this keeps throughput close to raw socket speed.
 *
 * Session handshake (protocol v2):
 *  1. both ends send HELLO (protocol version + display name)
 *  2. the end that was *connected to* shows the user a prompt; once accepted it sends READY
 *  3. only then does the connecting end treat the session as live and start offering files
 */
object TransferProtocol {
    const val PORT = 58432
    const val IO_BUFFER_SIZE = 128 * 1024
    const val PROTOCOL_VERSION = 2

    /** Largest control payload we will ever allocate for - guards against a corrupt length field. */
    private const val MAX_CONTROL_PAYLOAD = 64 * 1024

    const val TYPE_HELLO = 0x01
    const val TYPE_OFFER = 0x02
    const val TYPE_ACCEPT = 0x03
    const val TYPE_REJECT = 0x04
    const val TYPE_FILE_START = 0x05
    const val TYPE_FILE_DONE = 0x06
    const val TYPE_CANCEL = 0x07
    const val TYPE_BYE = 0x08
    const val TYPE_READY = 0x09

    private const val FIELD_SEP = '\u001F'
    private const val VERSION_PREFIX = "v"

    data class Frame(val type: Int, val payload: ByteArray)

    data class Hello(val version: Int, val name: String)

    data class OfferPayload(
        val id: String,
        val name: String,
        val sizeBytes: Long,
        val mimeType: String,
        val isApk: Boolean
    )

    fun writeFrame(out: DataOutputStream, type: Int, payload: ByteArray = ByteArray(0)) {
        out.writeByte(type)
        out.writeInt(payload.size)
        if (payload.isNotEmpty()) out.write(payload)
        out.flush()
    }

    fun readFrame(input: DataInputStream): Frame {
        val type = input.readUnsignedByte()
        val length = input.readInt()
        if (length < 0 || length > MAX_CONTROL_PAYLOAD) throw IOException("Bad frame length $length")
        val payload = if (length > 0) ByteArray(length).also { input.readFully(it) } else ByteArray(0)
        return Frame(type, payload)
    }

    fun encodeHello(name: String): ByteArray =
        "$VERSION_PREFIX$PROTOCOL_VERSION$FIELD_SEP$name".toByteArray(Charsets.UTF_8)

    /** Version 1 peers sent the bare name with no prefix; they decode as version 1. */
    fun decodeHello(payload: ByteArray): Hello {
        val text = String(payload, Charsets.UTF_8)
        val sep = text.indexOf(FIELD_SEP)
        if (sep > 1 && text.startsWith(VERSION_PREFIX)) {
            val version = text.substring(VERSION_PREFIX.length, sep).toIntOrNull()
            if (version != null) return Hello(version, text.substring(sep + 1).ifBlank { "Device" })
        }
        return Hello(1, text.ifBlank { "Device" })
    }

    fun encodeOffer(item: OfferPayload): ByteArray = listOf(
        item.id,
        item.name,
        item.sizeBytes.toString(),
        item.mimeType,
        if (item.isApk) "1" else "0"
    ).joinToString(FIELD_SEP.toString()).toByteArray(Charsets.UTF_8)

    fun decodeOffer(payload: ByteArray): OfferPayload {
        val parts = String(payload, Charsets.UTF_8).split(FIELD_SEP)
        return OfferPayload(
            id = parts.getOrElse(0) { "" },
            name = parts.getOrElse(1) { "file" },
            sizeBytes = parts.getOrElse(2) { "0" }.toLongOrNull() ?: 0L,
            mimeType = parts.getOrElse(3) { "application/octet-stream" },
            isApk = parts.getOrElse(4) { "0" } == "1"
        )
    }
}
