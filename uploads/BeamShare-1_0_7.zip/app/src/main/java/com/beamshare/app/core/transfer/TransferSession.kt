package com.beamshare.app.core.transfer

import com.beamshare.app.core.files.FileIo
import com.beamshare.app.core.files.IncomingSink
import com.beamshare.app.core.model.TransferDirection
import com.beamshare.app.core.model.TransferItem
import com.beamshare.app.core.model.TransferProgress
import com.beamshare.app.core.model.TransferState
import kotlinx.coroutines.CancellableContinuation
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.IOException
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap
import kotlin.coroutines.resume

/**
 * One live connection to a peer: handshake, offers, and file streaming in both directions.
 *
 * All blocking socket work runs on [Dispatchers.IO]. Writes are serialised by [writeMutex] so a
 * file stream is never interleaved with control frames, and exactly one coroutine ([readLoop])
 * ever reads from the socket.
 *
 * @param approveIncomingImmediately the end that dialled out has implicitly agreed to the
 *  session; the end that was dialled holds incoming offers back until [approveIncoming] is called.
 */
class TransferSession(
    private val socket: Socket,
    private val fileIo: FileIo,
    private val sessionScope: CoroutineScope,
    approveIncomingImmediately: Boolean
) {
    private val input = DataInputStream(socket.getInputStream().buffered(TransferProtocol.IO_BUFFER_SIZE))
    private val output = DataOutputStream(socket.getOutputStream().buffered(TransferProtocol.IO_BUFFER_SIZE))
    private val writeMutex = Mutex()

    @Volatile
    private var incomingApproved = approveIncomingImmediately

    private val pendingAcks = ConcurrentHashMap<String, CancellableContinuation<Boolean>>()
    private val pendingOffers = ConcurrentHashMap<String, TransferProtocol.OfferPayload>()

    private val _progress = MutableStateFlow<List<TransferProgress>>(emptyList())
    val progress: StateFlow<List<TransferProgress>> = _progress.asStateFlow()

    private val _peerHello = MutableStateFlow<TransferProtocol.Hello?>(null)
    /** The peer's greeting, once received. */
    val peerHello: StateFlow<TransferProtocol.Hello?> = _peerHello.asStateFlow()

    private val _peerReady = MutableStateFlow(false)
    /** True once the peer's user accepted this session (only meaningful for the end that dialled out). */
    val peerReady: StateFlow<Boolean> = _peerReady.asStateFlow()

    private val _closed = MutableStateFlow(false)
    val closed: StateFlow<Boolean> = _closed.asStateFlow()

    private var readJob: Job? = null

    /** Sends our greeting and starts reading. Call once. */
    fun start(localDeviceName: String) {
        readJob = sessionScope.launch(Dispatchers.IO) {
            try {
                sendFrame(TransferProtocol.TYPE_HELLO, TransferProtocol.encodeHello(localDeviceName))
                readLoop()
            } catch (e: Exception) {
                close()
            }
        }
    }

    /** Lets the peer send us files, and tells the dialling end the session is live. */
    fun approveIncoming() {
        incomingApproved = true
        sessionScope.launch(Dispatchers.IO) {
            try {
                sendFrame(TransferProtocol.TYPE_READY)
            } catch (e: Exception) {
                close()
            }
        }
    }

    /** Puts [items] in the progress list as QUEUED so the user sees everything that's coming. */
    fun enqueue(items: List<TransferItem>) {
        _progress.update { current ->
            current + items.filter { item -> current.none { it.itemId == item.id } }.map { item ->
                TransferProgress(
                    itemId = item.id,
                    name = item.displayName,
                    direction = TransferDirection.SEND,
                    totalBytes = item.sizeBytes,
                    state = TransferState.QUEUED,
                    isApk = item.isApk,
                    mimeType = item.mimeType
                )
            }
        }
    }

    /**
     * Offers [item], waits for the peer to accept, then streams it.
     * Returns normally for an accepted-and-finished or declined item; throws if the transfer broke.
     */
    suspend fun send(item: TransferItem) {
        enqueue(listOf(item))
        try {
            val accepted = withTimeoutOrNull(ACK_TIMEOUT_MS) { offerAndAwait(item) } ?: false
            if (!accepted) {
                setState(item.id, TransferState.CANCELLED)
                return
            }
            setState(item.id, TransferState.IN_PROGRESS)
            streamFileOut(item)
            setState(item.id, TransferState.COMPLETED)
        } catch (e: Exception) {
            setState(item.id, TransferState.FAILED)
            throw e
        }
    }

    private suspend fun offerAndAwait(item: TransferItem): Boolean = suspendCancellableCoroutine { cont ->
        pendingAcks[item.id] = cont
        cont.invokeOnCancellation { pendingAcks.remove(item.id) }
        sessionScope.launch(Dispatchers.IO) {
            try {
                val offer = TransferProtocol.OfferPayload(item.id, item.displayName, item.sizeBytes, item.mimeType, item.isApk)
                sendFrame(TransferProtocol.TYPE_OFFER, TransferProtocol.encodeOffer(offer))
            } catch (e: Exception) {
                pendingAcks.remove(item.id)?.resume(false)
                close()
            }
        }
    }

    private suspend fun sendFrame(type: Int, payload: ByteArray = ByteArray(0)) {
        writeMutex.withLock {
            withContext(Dispatchers.IO) { TransferProtocol.writeFrame(output, type, payload) }
        }
    }

    /**
     * Streams exactly [TransferItem.sizeBytes] raw bytes. The receiver reads that same count, so if
     * anything goes wrong once FILE_START is on the wire the stream can't be resynchronised and the
     * session is closed rather than left in an undefined state.
     */
    private suspend fun streamFileOut(item: TransferItem) = withContext(Dispatchers.IO) {
        // Open the source first: failing here leaves the wire untouched and the session usable.
        val source = fileIo.openInputStream(item)
        try {
            writeMutex.withLock {
                TransferProtocol.writeFrame(output, TransferProtocol.TYPE_FILE_START, item.id.toByteArray(Charsets.UTF_8))
                val buffer = ByteArray(TransferProtocol.IO_BUFFER_SIZE)
                val meter = SpeedMeter()
                var sent = 0L
                var lastEmitted = 0L
                while (sent < item.sizeBytes) {
                    val toRead = minOf(buffer.size.toLong(), item.sizeBytes - sent).toInt()
                    val read = source.read(buffer, 0, toRead)
                    if (read < 0) throw IOException("${item.displayName} ended before its expected size")
                    output.write(buffer, 0, read)
                    sent += read
                    if (sent - lastEmitted >= PROGRESS_EMIT_THRESHOLD || sent == item.sizeBytes) {
                        val sentSoFar = sent
                        val speed = meter.update(sentSoFar)
                        lastEmitted = sentSoFar
                        mutate(item.id) { it.copy(transferredBytes = sentSoFar, speedBytesPerSec = speed) }
                    }
                }
                output.flush()
                TransferProtocol.writeFrame(output, TransferProtocol.TYPE_FILE_DONE, item.id.toByteArray(Charsets.UTF_8))
            }
        } catch (e: Exception) {
            close()
            throw e
        } finally {
            runCatching { source.close() }
        }
        mutate(item.id) { it.copy(transferredBytes = item.sizeBytes, speedBytesPerSec = 0L) }
    }

    private suspend fun readLoop() {
        try {
            while (true) {
                val frame = TransferProtocol.readFrame(input)
                when (frame.type) {
                    TransferProtocol.TYPE_HELLO -> _peerHello.value = TransferProtocol.decodeHello(frame.payload)
                    TransferProtocol.TYPE_READY -> _peerReady.value = true
                    TransferProtocol.TYPE_OFFER -> handleOffer(TransferProtocol.decodeOffer(frame.payload))
                    TransferProtocol.TYPE_ACCEPT -> pendingAcks.remove(idOf(frame))?.resume(true)
                    TransferProtocol.TYPE_REJECT -> pendingAcks.remove(idOf(frame))?.resume(false)
                    TransferProtocol.TYPE_FILE_START -> receiveFile(idOf(frame))
                    TransferProtocol.TYPE_FILE_DONE -> Unit
                    TransferProtocol.TYPE_CANCEL -> Unit
                    TransferProtocol.TYPE_BYE -> {
                        close()
                        return
                    }
                }
            }
        } catch (e: Exception) {
            close()
        }
    }

    private fun idOf(frame: TransferProtocol.Frame): String = String(frame.payload, Charsets.UTF_8)

    private suspend fun handleOffer(offer: TransferProtocol.OfferPayload) {
        if (!incomingApproved) {
            sendFrame(TransferProtocol.TYPE_REJECT, offer.id.toByteArray(Charsets.UTF_8))
            return
        }
        pendingOffers[offer.id] = offer
        _progress.update { current ->
            current + TransferProgress(
                itemId = offer.id,
                name = offer.name,
                direction = TransferDirection.RECEIVE,
                totalBytes = offer.sizeBytes,
                state = TransferState.QUEUED,
                isApk = offer.isApk,
                mimeType = offer.mimeType
            )
        }
        sendFrame(TransferProtocol.TYPE_ACCEPT, offer.id.toByteArray(Charsets.UTF_8))
    }

    /**
     * Runs on the read loop, so nothing else touches [input] while the file's bytes are consumed.
     * Reading exactly the offered size keeps the control stream in sync; a short read means the
     * connection died, which the caller handles by closing the session.
     */
    private suspend fun receiveFile(id: String) {
        val offer = pendingOffers.remove(id) ?: throw IOException("File data arrived for an unknown offer")
        setState(id, TransferState.IN_PROGRESS)

        val sink: IncomingSink? = withContext(Dispatchers.IO) {
            try {
                fileIo.createIncomingSink(offer.name, offer.mimeType)
            } catch (e: Exception) {
                null
            }
        }
        if (sink == null) {
            // Nowhere to put it (storage full, no permission...). The bytes are still coming, so
            // consume them to stay in sync, then report just this file as failed.
            withContext(Dispatchers.IO) { discardBytes(offer.sizeBytes) }
            setState(id, TransferState.FAILED)
            return
        }

        try {
            withContext(Dispatchers.IO) {
                sink.outputStream.use { out ->
                    val buffer = ByteArray(TransferProtocol.IO_BUFFER_SIZE)
                    val meter = SpeedMeter()
                    var received = 0L
                    var lastEmitted = 0L
                    while (received < offer.sizeBytes) {
                        val toRead = minOf(buffer.size.toLong(), offer.sizeBytes - received).toInt()
                        val read = input.read(buffer, 0, toRead)
                        if (read < 0) throw IOException("Connection lost while receiving ${offer.name}")
                        out.write(buffer, 0, read)
                        received += read
                        if (received - lastEmitted >= PROGRESS_EMIT_THRESHOLD || received == offer.sizeBytes) {
                            val receivedSoFar = received
                            val speed = meter.update(receivedSoFar)
                            lastEmitted = receivedSoFar
                            mutate(id) { it.copy(transferredBytes = receivedSoFar, speedBytesPerSec = speed) }
                        }
                    }
                }
                sink.finalize()
            }
            mutate(id) {
                it.copy(
                    transferredBytes = it.totalBytes,
                    speedBytesPerSec = 0L,
                    savedUri = sink.uri,
                    state = TransferState.COMPLETED
                )
            }
        } catch (e: Exception) {
            setState(id, TransferState.FAILED)
            runCatching { sink.discard() }
            throw e
        }
    }

    private fun discardBytes(count: Long) {
        val scratch = ByteArray(TransferProtocol.IO_BUFFER_SIZE)
        var remaining = count
        while (remaining > 0) {
            val read = input.read(scratch, 0, minOf(scratch.size.toLong(), remaining).toInt())
            if (read < 0) throw IOException("Connection lost")
            remaining -= read
        }
    }

    /** Tells the peer we're leaving (best effort, briefly) and then closes. */
    suspend fun goodbye() {
        withTimeoutOrNull(GOODBYE_TIMEOUT_MS) {
            try {
                sendFrame(TransferProtocol.TYPE_BYE)
            } catch (e: IOException) {
                // already broken - closing below is all that's left to do
            }
        }
        close()
    }

    fun close() {
        if (!_closed.compareAndSet(false, true)) return
        runCatching { socket.close() }
        readJob?.cancel()
        pendingAcks.values.forEach { runCatching { it.resume(false) } }
        pendingAcks.clear()
        _progress.update { list ->
            list.map {
                if (it.state == TransferState.IN_PROGRESS || it.state == TransferState.QUEUED) {
                    it.copy(state = TransferState.FAILED, speedBytesPerSec = 0L)
                } else {
                    it
                }
            }
        }
    }

    private fun setState(id: String, state: TransferState) {
        mutate(id) { it.copy(state = state, speedBytesPerSec = if (state == TransferState.IN_PROGRESS) it.speedBytesPerSec else 0L) }
    }

    private fun mutate(id: String, transform: (TransferProgress) -> TransferProgress) {
        _progress.update { list -> list.map { if (it.itemId == id) transform(it) else it } }
    }

    /** Smoothed transfer speed so the number shown to the user doesn't jitter with every chunk. */
    private class SpeedMeter {
        private var lastBytes = 0L
        private var lastNanos = System.nanoTime()
        private var smoothed = 0L

        fun update(totalBytes: Long): Long {
            val now = System.nanoTime()
            val elapsed = now - lastNanos
            if (elapsed > 0L) {
                val instant = (totalBytes - lastBytes) * 1_000_000_000L / elapsed
                smoothed = if (smoothed == 0L) instant else (smoothed * 6L + instant * 4L) / 10L
                lastBytes = totalBytes
                lastNanos = now
            }
            return smoothed
        }
    }

    private companion object {
        const val ACK_TIMEOUT_MS = 120_000L
        const val GOODBYE_TIMEOUT_MS = 800L
        const val PROGRESS_EMIT_THRESHOLD = 96L * 1024L
    }
}
