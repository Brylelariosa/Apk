// bench_frame.cpp - CPU cost of one frame (simulation step + scene geometry) on a long autopilot run, with and without other riders.
// Not a pass/fail test: it prints where the milliseconds go, to compare before / after an optimisation. (A phone is 4-10x slower than a PC.)
#include <chrono>
#include <cstdio>
#include <vector>

#include "game.h"
#include "scene_builder.h"

using namespace sd;
using Clock = std::chrono::steady_clock;

static double ms(Clock::time_point a, Clock::time_point b) { return std::chrono::duration<double, std::milli>(b - a).count(); }

int main(int argc, char** argv) {
    const int remotesN = argc > 1 ? std::atoi(argv[1]) : 5;
    Game g;
    g.setBaseSeed(11u);
    g.startRun();
    SceneGeometry geo;
    std::vector<RemoteRider> remotes;
    for (int i = 0; i < remotesN; ++i) {
        RemoteRider rr;
        rr.style = i % 6;
        rr.net.s = 40.0f + 14.0f * i;
        rr.net.x = (i % 3 - 1) * 1.6f;
        rr.net.speed = 18.0f;
        remotes.push_back(rr);
    }
    double tUpd = 0, tScene = 0, tUpdMax = 0, tSceneMax = 0;
    long verts = 0, inst = 0, terr = 0;
    int frames = 0;
    const float dt = 1.0f / 60.0f;
    for (int i = 0; i < 60 * 70; ++i) {
        SkaterInput in = g.autopilot().compute(g.world().track(), g.world().obstacles(), g.skater());
        if (g.phase() == Phase::Crashed || g.phase() == Phase::GameOver) g.startRun();
        const auto t0 = Clock::now();
        g.update(dt, in);
        const auto t1 = Clock::now();
        for (int k = 0; k < remotesN; ++k) {   // the others ride along
            remotes[k].net.s = g.skater().s + (k - 2) * 11.0f;
            remotes[k].net.speed = g.skater().speed;
        }
        buildScene(g, 1.0f, geo, remotesN > 0 ? &remotes : nullptr);
        const auto t2 = Clock::now();
        if (i < 60 * 8) continue;   // warm up (countdown, first chunks)
        const double a = ms(t0, t1), b = ms(t1, t2);
        tUpd += a; tScene += b;
        tUpdMax = std::max(tUpdMax, a); tSceneMax = std::max(tSceneMax, b);
        verts += static_cast<long>(geo.dynamicMesh.vertices.size());
        terr += static_cast<long>(geo.terrain.size());
        for (auto& v : geo.instances) inst += static_cast<long>(v.size());
        ++frames;
    }
    std::printf("%d other riders, %d frames: update %.3f ms avg (max %.2f)   scene %.3f ms avg (max %.2f)\n", remotesN, frames, tUpd / frames, tUpdMax,
                tScene / frames, tSceneMax);
    std::printf("per frame: terrain vertices %ld, instances %ld, dynamic mesh vertices %ld\n", terr / frames, inst / frames, verts / frames);
    return 0;
}
