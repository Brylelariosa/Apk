// test_respawn.cpp - checkpoints and respawns of LAN races (no GPU, no sockets):
//   * the checkpoint gates of a road: spacing, none near a gorge detour, the same list whatever order the road was generated in
//   * a wipe-out puts the rider back at the last gate passed (rolling, with a grace period), the cones and rocks come back from the seed,
//     the race clock keeps counting, a race with a finish line allows any number of wipe-outs and an endless run allows kEndlessLives
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <tuple>
#include <vector>

#include "config.h"
#include "game.h"
#include "track.h"

using namespace sd;

namespace {
int failures = 0, checks = 0;
#define CHECK(cond, ...)                                          \
    do {                                                          \
        ++checks;                                                 \
        if (!(cond)) {                                            \
            ++failures;                                           \
            std::printf("  FAIL line %d: %s  ", __LINE__, #cond); \
            std::printf(__VA_ARGS__);                             \
            std::printf("\n");                                    \
        }                                                         \
    } while (0)

using Statics = std::vector<std::tuple<int, float, float>>;
Statics staticsBetween(const World& w, float s0, float s1) {
    Statics v;
    for (const Obstacle& o : w.obstacles())
        if (o.kind != ObstacleKind::Car && o.s >= s0 && o.s < s1) v.emplace_back(static_cast<int>(o.kind), o.s, o.x);
    std::sort(v.begin(), v.end());
    return v;
}

void testGates() {
    std::puts("checkpoint gates");
    for (uint32_t seed = 1; seed <= 40; ++seed) {
        Track a(seed), b(seed);
        a.ensureGenerated(12000.0f);
        for (float s = 300.0f; s <= 12000.0f; s += 250.0f) b.ensureGenerated(s);   // the same road, generated bit by bit
        const int n = std::min(a.checkpointCount(), b.checkpointCount());
        CHECK(n >= 50, "seed %u: %d gates in 12 km", seed, n);
        bool same = true, spaced = true, clear = true, ordered = true;
        float last = 0.0f;
        for (int i = 1; i <= n; ++i) {
            const float s = a.checkpointS(i);
            same = same && a.checkpointS(i) == b.checkpointS(i);
            ordered = ordered && s > last;
            spaced = spaced && (i == 1 || s - last >= 60.0f) && (i == 1 || s - last <= 2.6f * cfg::kCheckpointSpacing + 400.0f);
            last = s;
            for (const ShortcutZone& z : a.shortcuts()) {
                const float z0 = std::min(std::min(z.sRamp0, z.sBend0), z.sGorge0), z1 = std::max(std::max(z.sGorge1, z.sBend1), z.sLand);
                if (s > z0 - cfg::kCheckpointKeepClear + 1.0f && s < z1 + cfg::kCheckpointKeepClear - 1.0f) clear = false;
            }
        }
        CHECK(same, "seed %u: the gates do not depend on how the road was generated", seed);
        CHECK(ordered && spaced, "seed %u: gates ordered and spaced", seed);
        CHECK(clear, "seed %u: no gate within the keep-clear distance of a detour", seed);
        CHECK(a.checkpointIndexAt(a.checkpointS(3) - 0.01f) == 2 && a.checkpointIndexAt(a.checkpointS(3)) == 3 && a.checkpointIndexAt(0.0f) == 0, "index lookup");
        CHECK(a.nearCheckpoint(a.checkpointS(4) + 5.0f, 6.0f) && !a.nearCheckpoint(a.checkpointS(4) + 40.0f, 6.0f) || a.checkpointS(5) - a.checkpointS(4) < 50.0f, "near lookup");
    }
}

// wipe the rider out on purpose: hold the stick hard to one side until the road bites
void crashOnPurpose(Game& g, float dt, int maxFrames) {
    SkaterInput in;
    in.steer = 1.0f;
    for (int i = 0; i < maxFrames && g.phase() == Phase::Running; ++i) g.update(dt, in);
}

void ride(Game& g, float dt, float seconds) {
    for (float t = 0.0f; t < seconds; t += dt) {
        const SkaterInput in = g.autopilot().compute(g.world().track(), g.world().obstacles(), g.skater());
        g.update(dt, in);
        if (g.phase() != Phase::Running) break;
    }
}

void startRace(Game& g, uint32_t seed, float goal) {
    g.startRunSeeded(seed, 0.0f, goal, true);
    for (int i = 0; i < 60 * 4 && g.phase() != Phase::Running; ++i) g.update(1.0f / 60.0f, SkaterInput());
}

void testRespawn() {
    std::puts("respawn after a wipe-out");
    const float dt = 1.0f / 60.0f;
    Game g;
    startRace(g, 4242u, 0.0f);   // endless
    CHECK(g.phase() == Phase::Running && g.respawnMode() && g.livesLeft() == cfg::kEndlessLives, "an endless LAN run starts with %d lives", g.livesLeft());

    // ride to past the second gate, then crash
    for (int i = 0; i < 60 * 120 && g.checkpointsPassed() < 2; ++i) {
        const SkaterInput in = g.autopilot().compute(g.world().track(), g.world().obstacles(), g.skater());
        g.update(dt, in);
        if (g.phase() != Phase::Running) break;
    }
    CHECK(g.phase() == Phase::Running && g.checkpointsPassed() >= 2, "the autopilot passes two gates (passed %d)", g.checkpointsPassed());
    const int gate = g.checkpointsPassed();
    const float gateS = g.world().track().checkpointS(gate);
    const float clockBefore = g.raceClock();
    const GameEvents ev0 = g.takeEvents();
    CHECK(ev0.checkpoint, "passing a gate is announced");

    crashOnPurpose(g, dt, 60 * 60);
    CHECK(g.phase() == Phase::Crashed && g.respawning(), "wiped out and about to be put back");
    const float crashS = g.skater().s;
    for (int i = 0; i < 60 * 3 && g.phase() == Phase::Crashed; ++i) g.update(dt, SkaterInput());
    CHECK(g.phase() == Phase::Running, "put back on the road after the wipe-out (phase %d)", static_cast<int>(g.phase()));
    const Skater& sk = g.skater();
    CHECK(!sk.crashed && sk.respawns == 1, "a fresh rider (respawns %d)", sk.respawns);
    CHECK(sk.s <= crashS - 5.0f || crashS < gateS + 8.0f, "back behind the crash: %.0f -> %.0f m", crashS, sk.s);
    CHECK(sk.s >= gateS && sk.s <= gateS + 3.0f + 3.0f * cfg::kRespawnSpeed * dt + 12.0f, "at the last gate: gate %.1f m, rider %.1f m", gateS, sk.s);
    CHECK(sk.speed > 0.6f * cfg::kRespawnSpeed && sk.speed < 2.0f * cfg::kRespawnSpeed, "rolling away: %.1f m/s", sk.speed);
    CHECK(std::fabs(sk.x) < 1.0f, "on the road: x = %.2f", sk.x);
    CHECK(sk.grace > 0.0f && sk.grace <= cfg::kRespawnGrace, "grace period %.2f s", sk.grace);
    CHECK(g.livesLeft() == cfg::kEndlessLives - 1, "one life used: %d left", g.livesLeft());
    CHECK(g.raceClock() >= clockBefore + cfg::kRespawnDelay - 0.2f, "the race clock kept counting through the wipe-out (%.1f -> %.1f)", clockBefore, g.raceClock());
    const GameEvents ev1 = g.takeEvents();
    CHECK(ev1.respawn, "the respawn is announced");
    const RiderNet net = g.riderNet();
    CHECK(net.respawnSeq == 1 && net.ghost && !net.crashed, "what the others are told: seq %d ghost %d", net.respawnSeq, net.ghost);

    // the cones and rocks are the seed's again, wherever the rider was put
    {
        const float s0 = sk.s;
        const Statics now = staticsBetween(g.world(), s0 - 60.0f, s0 + 420.0f);
        World ref(g.world().track().seed());
        ref.setObstaclesEnabled(true);
        ref.update(0.0f, s0);
        const Statics fresh = staticsBetween(ref, s0 - 60.0f, s0 + 420.0f);
        CHECK(!now.empty() && now == fresh, "the cones and rocks after the respawn are the seed's (%zu / %zu)", now.size(), fresh.size());
    }

    // grace: ride straight through a rock without harm; afterwards the rider is hurt again
    for (int i = 0; i < 60 * 3; ++i) g.update(dt, g.autopilot().compute(g.world().track(), g.world().obstacles(), g.skater()));
    CHECK(g.skater().grace == 0.0f, "grace is over");

    // the other lives: wipe out until the run is over
    int outs = 1;
    while (g.phase() != Phase::GameOver && outs < 12) {
        if (g.phase() == Phase::Running) crashOnPurpose(g, dt, 60 * 60);
        for (int i = 0; i < 60 * 3 && g.phase() == Phase::Crashed; ++i) g.update(dt, SkaterInput());
        if (g.phase() == Phase::Running || g.phase() == Phase::GameOver) ++outs;
        if (g.phase() == Phase::Running) {
            // skip the grace period by riding on
            for (int i = 0; i < 60 * 3; ++i) g.update(dt, SkaterInput());
        }
    }
    CHECK(g.phase() == Phase::GameOver, "the run is over after the last life (phase %d)", static_cast<int>(g.phase()));
    CHECK(g.respawnCount() == cfg::kEndlessLives - 1, "%d respawns, the last wipe-out ended the run", g.respawnCount());
}

void testRace() {
    std::puts("a race to a finish line: any number of wipe-outs, the clock counts them");
    const float dt = 1.0f / 60.0f;
    Game g;
    startRace(g, 777u, 1000.0f);
    CHECK(g.livesLeft() == -1, "unlimited respawns in a race with a goal");
    int respawns = 0;
    for (int round = 0; round < 7; ++round) {   // seven wipe-outs in a row
        crashOnPurpose(g, dt, 60 * 60);
        for (int i = 0; i < 60 * 3 && g.phase() == Phase::Crashed; ++i) g.update(dt, SkaterInput());
        CHECK(g.phase() == Phase::Running, "round %d: back on the road", round);
        if (g.phase() != Phase::Running) return;
        respawns = g.respawnCount();
        for (int i = 0; i < 60 * 3; ++i) g.update(dt, g.autopilot().compute(g.world().track(), g.world().obstacles(), g.skater()));
        if (g.phase() != Phase::Running) { std::puts("  (the autopilot crashed: fine, it is respawned below)"); break; }
    }
    CHECK(respawns >= 6, "%d respawns so far", respawns);
    // now ride to the line
    float clockAtStart = g.raceClock();
    for (int i = 0; i < 60 * 600 && !g.finished(); ++i) {
        const SkaterInput in = g.autopilot().compute(g.world().track(), g.world().obstacles(), g.skater());
        g.update(dt, in);
        if (g.phase() == Phase::Crashed) for (int k = 0; k < 60 * 3 && g.phase() == Phase::Crashed; ++k) g.update(dt, SkaterInput());
    }
    CHECK(g.finished(), "the rider crosses the finish line after all those wipe-outs");
    CHECK(g.finishTime() >= clockAtStart && g.finishTime() <= g.raceClock() + 0.1f, "finish time %.1f s counts the whole race (clock %.1f)", g.finishTime(), g.raceClock());
    CHECK(g.finishTime() > 7.0f * cfg::kRespawnDelay, "the seven wipe-outs are in the time: %.1f s", g.finishTime());
}

void testSoloUnchanged() {
    std::puts("a solo run still ends at the first wipe-out");
    const float dt = 1.0f / 60.0f;
    Game g;
    g.setBaseSeed(5u);
    g.startRun();
    for (int i = 0; i < 60 * 4 && g.phase() != Phase::Running; ++i) g.update(dt, SkaterInput());
    CHECK(!g.respawnMode() && g.livesLeft() == -1, "no respawns in a solo run");
    crashOnPurpose(g, dt, 60 * 90);
    for (int i = 0; i < 60 * 4 && g.phase() == Phase::Crashed; ++i) g.update(dt, SkaterInput());
    CHECK(g.phase() == Phase::GameOver, "run over after the first wipe-out (phase %d)", static_cast<int>(g.phase()));
}

}  // namespace

int main() {
    testGates();
    testRespawn();
    testRace();
    testSoloUnchanged();
    std::printf("\n%d checks, %d failed\n", checks, failures);
    return failures ? 1 : 0;
}
