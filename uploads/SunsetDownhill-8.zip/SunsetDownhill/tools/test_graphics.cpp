// test_graphics.cpp - the graphics options: the saved text, the GRAPHICS screen (geometry on phones and tablets, the slider, the presets, DONE)
#include <cmath>
#include <cstdio>
#include <string>

#include "controls_config.h"
#include "graphics_panel.h"
#include "graphics_settings.h"
#include "input.h"
#include "ui_layout.h"

using namespace sd;

namespace {
int failures = 0, checks = 0;
#define CHECK(cond, ...)                                          \
    do {                                                          \
        ++checks;                                                 \
        if (!(cond)) {                                            \
            ++failures;                                           \
            std::printf("  FAIL line %d: %s  ", __LINE__, #cond); \
            std::printf(__VA_ARGS__);                             \
            std::printf("\n");                                    \
        }                                                         \
    } while (0)

bool overlap(const Rect& a, const Rect& b) { return a.x < b.x + b.w && b.x < a.x + a.w && a.y < b.y + b.h && b.y < a.y + a.h; }
bool inside(const Rect& r, const Rect& outer) { return r.x >= outer.x - 0.5f && r.y >= outer.y - 0.5f && r.x + r.w <= outer.x + outer.w + 0.5f && r.y + r.h <= outer.y + outer.h + 0.5f; }

void testSettings() {
    std::puts("settings text");
    GraphicsSettings g;
    CHECK(g.motionBlur == GraphicsSettings::kDefaultMotionBlur && g.serialize() == "mb=50", "default %s", g.serialize().c_str());
    g.motionBlur = 90;
    CHECK(GraphicsSettings::parse(g.serialize()).motionBlur == 90, "round trip");
    CHECK(GraphicsSettings::parse("v1 m=0 o=1000 mb=0").motionBlur == 0, "off survives");
    CHECK(GraphicsSettings::parse("v1 m=0 o=1000 t=1000 mb=100 left=1,2,3").motionBlur == 100, "found among other tokens");
    CHECK(GraphicsSettings::parse("").motionBlur == 50 && GraphicsSettings::parse("v1 m=0").motionBlur == 50, "no token: the default");
    CHECK(GraphicsSettings::parse("mb=250").motionBlur == 100 && GraphicsSettings::parse("mb=-7").motionBlur == 0, "clamped");
    CHECK(GraphicsSettings::parse("mb=abc").motionBlur == 50 && GraphicsSettings::parse("mb=").motionBlur == 50 && GraphicsSettings::parse("mb=5x").motionBlur == 50, "junk ignored");
    // the controls parser must not trip over the extra token (the two share one saved text)
    const ControlsConfig c = ControlsConfig::parse(ControlsConfig().serialize() + " mb=33");
    CHECK(c.serialize() == ControlsConfig().serialize(), "the controls layout ignores the graphics token");
}

void testGeometry() {
    std::puts("panel geometry");
    const float sizes[][2] = {{1920, 1080}, {2400, 1080}, {1612, 720}, {1280, 720}, {800, 480}, {2560, 1600}, {1024, 768}};
    for (const auto& sz : sizes) {
        const UiLayout L = UiLayout::make(sz[0], sz[1]);
        const GraphicsPanel::Geometry g = GraphicsPanel::geometry(L);
        const Rect screen{0, 0, L.w, L.h};
        CHECK(inside(g.panel, screen), "%gx%g: the panel is on screen", sz[0], sz[1]);
        CHECK(inside(g.done, g.panel) && inside(g.minus, g.panel) && inside(g.plus, g.panel) && inside(g.sliderHit, screen), "%gx%g: parts inside the panel", sz[0], sz[1]);
        for (int i = 0; i < GraphicsPanel::kPresetCount; ++i) {
            CHECK(inside(g.chip[i], g.panel), "%gx%g: chip %d inside", sz[0], sz[1], i);
            CHECK(!overlap(g.chip[i], g.done) && !overlap(g.chip[i], g.sliderHit), "%gx%g: chip %d clear of the slider and DONE", sz[0], sz[1], i);
            for (int k = i + 1; k < GraphicsPanel::kPresetCount; ++k) CHECK(!overlap(g.chip[i], g.chip[k]), "chips do not overlap");
        }
        CHECK(g.trackX1 - g.trackX0 > 300.0f * L.u, "%gx%g: a usable slider (%g px)", sz[0], sz[1], g.trackX1 - g.trackX0);
        // the menu / pause buttons do not collide with each other
        CHECK(!overlap(L.graphicsMenu, L.controlsMenu) && !overlap(L.graphicsMenu, L.multiMenu), "%gx%g: menu buttons clear", sz[0], sz[1]);
        CHECK(!overlap(L.graphicsPause, L.controlsPause) && !overlap(L.graphicsPause, Rect{L.menuX, L.menuY, L.menuW, L.menuH}), "%gx%g: pause buttons clear", sz[0], sz[1]);
        CHECK(inside(L.graphicsMenu, screen) && inside(L.graphicsPause, screen), "%gx%g: buttons on screen", sz[0], sz[1]);
    }
}

void testTouch() {
    std::puts("slider, presets and steppers");
    const UiLayout L = UiLayout::make(1920, 1080);
    const GraphicsPanel::Geometry g = GraphicsPanel::geometry(L);
    GraphicsSettings gfx;
    GraphicsPanel p;
    CHECK(!p.onTouch(kTouchDown, 1, 10, 10, L, gfx), "a closed panel takes no touches");
    p.open();
    auto cx = [](const Rect& r) { return r.x + r.w * 0.5f; };
    auto cy = [](const Rect& r) { return r.y + r.h * 0.5f; };
    CHECK(GraphicsPanel::valueAt(g, g.trackX0) == 0 && GraphicsPanel::valueAt(g, g.trackX1) == 100, "the ends of the track");
    CHECK(GraphicsPanel::valueAt(g, g.trackX0 - 400.0f) == 0 && GraphicsPanel::valueAt(g, g.trackX1 + 400.0f) == 100, "beyond the ends is clamped");
    const float xAt[] = {0.0f, 0.25f, 0.5f, 0.75f, 0.9f, 1.0f};
    for (float t : xAt) {
        const int v = GraphicsPanel::valueAt(g, g.trackX0 + (g.trackX1 - g.trackX0) * t);
        CHECK(v == static_cast<int>(std::lround(t * 100.0f)), "the magnet at %g%%: %d", t * 100.0f, v);
    }
    int last = -1;
    bool monotonic = true;
    for (float x = g.trackX0; x <= g.trackX1; x += 1.0f) {
        const int v = GraphicsPanel::valueAt(g, x);
        monotonic = monotonic && v >= last;
        last = v;
    }
    CHECK(monotonic, "dragging right never lowers the value");

    // drag
    CHECK(p.onTouch(kTouchDown, 7, g.trackX0 + (g.trackX1 - g.trackX0) * 0.8f, g.trackY, L, gfx) && gfx.motionBlur == 80, "tap on the slider: %d", gfx.motionBlur);
    CHECK(p.onTouch(kTouchMove, 7, g.trackX0 + (g.trackX1 - g.trackX0) * 0.3f, g.trackY + 200.0f, L, gfx) && gfx.motionBlur == 30, "dragging follows the finger even off the track: %d", gfx.motionBlur);
    CHECK(!p.onTouch(kTouchMove, 9, g.trackX1, g.trackY, L, gfx) && gfx.motionBlur == 30, "another finger does not move it");
    p.onTouch(kTouchUp, 7, 0, 0, L, gfx);
    CHECK(!p.onTouch(kTouchMove, 7, g.trackX1, g.trackY, L, gfx) && gfx.motionBlur == 30, "after lifting the finger it stays");
    // presets
    for (int i = 0; i < GraphicsPanel::kPresetCount; ++i) {
        p.onTouch(kTouchDown, 3, cx(g.chip[i]), cy(g.chip[i]), L, gfx);
        p.onTouch(kTouchUp, 3, cx(g.chip[i]), cy(g.chip[i]), L, gfx);
        CHECK(gfx.motionBlur == GraphicsPanel::kPresets[i], "preset %d -> %d", i, gfx.motionBlur);
    }
    CHECK(GraphicsPanel::kPresets[0] == 0 && GraphicsPanel::kPresets[2] == 50 && GraphicsPanel::kPresets[3] == 90 && GraphicsPanel::kPresets[4] == 100, "presets include OFF, 50, 90 and 100");
    // steppers
    gfx.motionBlur = 50;
    p.onTouch(kTouchDown, 4, cx(g.plus), cy(g.plus), L, gfx);
    CHECK(gfx.motionBlur == 55, "+ is 5%%: %d", gfx.motionBlur);
    p.onTouch(kTouchDown, 4, cx(g.minus), cy(g.minus), L, gfx);
    p.onTouch(kTouchDown, 4, cx(g.minus), cy(g.minus), L, gfx);
    CHECK(gfx.motionBlur == 45, "- is 5%%: %d", gfx.motionBlur);
    gfx.motionBlur = 2;
    p.onTouch(kTouchDown, 4, cx(g.minus), cy(g.minus), L, gfx);
    CHECK(gfx.motionBlur == 0, "- stops at 0: %d", gfx.motionBlur);
    p.onTouch(kTouchDown, 4, cx(g.minus), cy(g.minus), L, gfx);
    CHECK(gfx.motionBlur == 0, "... and stays");
    gfx.motionBlur = 98;
    p.onTouch(kTouchDown, 4, cx(g.plus), cy(g.plus), L, gfx);
    p.onTouch(kTouchDown, 4, cx(g.plus), cy(g.plus), L, gfx);
    CHECK(gfx.motionBlur == 100, "+ stops at 100: %d", gfx.motionBlur);
    // DONE closes, and the touch outside everything does nothing
    p.onTouch(kTouchDown, 5, 3.0f, 3.0f, L, gfx);
    CHECK(p.isOpen() && gfx.motionBlur == 100, "a touch outside does nothing");
    p.onTouch(kTouchDown, 5, cx(g.done), cy(g.done), L, gfx);
    CHECK(!p.isOpen(), "DONE closes the screen");
}

}  // namespace

int main() {
    testSettings();
    testGeometry();
    testTouch();
    std::printf("\n%d checks, %d failed\n", checks, failures);
    return failures ? 1 : 0;
}
