// test_chute.cpp - the off-road shortcuts ("chutes"): the road round them, their ground and corridor, riding into one and out again, the
// obstacles in them and the camera / pose / network side of it. Grows with the feature; every part is a pure function of the seed.
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <vector>

#include "config.h"
#include "game.h"
#include "world.h"
#include "skater.h"
#include "track.h"

using namespace sd;

namespace {
int failures = 0, checks = 0;
#define CHECK(cond, ...)                                          \
    do {                                                          \
        ++checks;                                                 \
        if (!(cond)) {                                            \
            ++failures;                                           \
            std::printf("  FAIL line %d: %s  ", __LINE__, #cond); \
            std::printf(__VA_ARGS__);                             \
            std::printf("\n");                                    \
        }                                                         \
    } while (0)

std::vector<const ShortcutZone*> chutesOf(const Track& tr) {
    std::vector<const ShortcutZone*> v;
    for (const ShortcutZone& z : tr.shortcuts())
        if (z.isChute()) v.push_back(&z);
    return v;
}

void testGeometry() {
    std::puts("the road, the ground and the corridor of a chute");
    int total = 0, gorges = 0;
    float minChord = 1e9f, maxChord = 0.0f, minMid = 1e9f, maxMid = -1e9f;
    float worstRoadGap = 0.0f, worstEnd = 0.0f;
    for (uint32_t seed = 1; seed <= 60; ++seed) {
        Track tr(seed);
        tr.ensureGenerated(14000.0f);
        for (const ShortcutZone& zz : tr.shortcuts()) if (!zz.isChute()) ++gorges;
        const auto list = chutesOf(tr);
        for (const ShortcutZone* zp : list) {
            const ShortcutZone& z = *zp;
            if (z.sBend0 > 13500.0f) continue;   // (planned ahead, not generated yet)
            ++total;
            CHECK(z.chuteReady, "seed %u: a chute at %.0f m has its ground", seed, z.sBend0);
            if (!z.chuteReady) continue;
            minChord = std::min(minChord, z.chord);
            maxChord = std::max(maxChord, z.chord);
            CHECK(z.chord > 70.0f && z.chord < 140.0f, "seed %u: chord %.1f m", seed, z.chord);
            // the road is back on the line the chord runs along
            const TrackSample a = tr.at(z.sBend0), b = tr.at(z.sBend1);
            float u1, b1;
            Track::toChute(z, b.pos, &u1, &b1);
            CHECK(std::fabs(b1) < 0.6f && std::fabs(u1 - z.chord) < 0.6f, "seed %u: the road at the end of the detour is on the chord (b %.2f, du %.2f)", seed, b1, u1 - z.chord);
            float dh = std::fabs(a.heading - b.heading);
            CHECK(dh < 0.04f || std::fabs(dh - kTwoPi) < 0.04f, "seed %u: same heading at both ends (%.3f rad apart)", seed, dh);
            worstEnd = std::max(worstEnd, std::max(std::fabs(b1), std::fabs(u1 - z.chord)));
            // the ground: starts at the road, ends at the road, steeper than the detour road, never uphill, no kinks
            CHECK(std::fabs(z.groundY(0.0f) - a.pos.y) < 0.01f && std::fabs(z.groundY(z.chord) - b.pos.y) < 0.01f, "seed %u: the ground meets the road at both ends", seed);
            const float avg = (z.groundY(0.0f) - z.groundY(z.chord)) / z.chord;
            minMid = std::min(minMid, z.midSlope);
            maxMid = std::max(maxMid, z.midSlope);
            CHECK(z.midSlope < -0.06f && z.midSlope > -0.22f, "seed %u: steady slope %.3f (average %.3f)", seed, z.midSlope, avg);
            float prev = z.groundY(-10.0f);
            bool downhill = true;
            float maxKink = 0.0f;
            for (float u = -9.0f; u <= z.chord + 10.0f; u += 1.0f) {
                const float y = z.groundY(u);
                downhill = downhill && y <= prev + 1e-4f;
                maxKink = std::max(maxKink, std::fabs(z.slopeAt(u) - z.slopeAt(u - 1.0f)));
                CHECK(std::fabs((z.groundY(u + 0.5f) - z.groundY(u - 0.5f)) - z.slopeAt(u)) < 6e-3f, "seed %u u %.0f: slopeAt is the derivative", seed, u);
                prev = y;
            }
            CHECK(downhill, "seed %u: the chute only goes down", seed);
            CHECK(maxKink < 0.02f, "seed %u: the slope changes gently (%.4f per metre)", seed, maxKink);
            // the detour road lies close to the chute's ground where they are above one another (cuts and fills of a metre or two, not cliffs)
            for (float s = z.sBend0; s <= z.sBend1; s += 3.0f) {
                const TrackSample f = tr.at(s);
                float u, b2;
                Track::toChute(z, f.pos, &u, &b2);
                if (u < 0.0f || u > z.chord) continue;
                const float gap = z.groundY(u) - f.pos.y;
                worstRoadGap = std::max(worstRoadGap, std::fabs(gap));
            }
            // the corridor: a few metres wide, always on the free side of the road's rail, narrowing to the road at the end
            float lo, hi;
            for (float u = -cfg::kChuteBack; u <= z.chord + 6.0f; u += 2.0f) {
                z.window(u, &lo, &hi);
                CHECK(hi - lo > 3.0f, "seed %u u %.0f: corridor %.1f..%.1f", seed, u, lo, hi);
                CHECK(lo >= -cfg::kChuteHalfWidth - 0.01f && hi <= cfg::kChuteHalfWidth + 0.01f, "seed %u u %.0f: within the half width", seed, u);
            }
            z.window(z.chord - 2.0f, &lo, &hi);
            CHECK(hi - lo < 15.0f, "seed %u: the corridor narrows toward the end (%.1f m)", seed, hi - lo);
            // the way in: the corridor does not reach back onto the road (the rail line bounds it on the road side)
            z.window(5.0f, &lo, &hi);
            const float roadSideEdge = z.roadSign > 0.0f ? hi : -lo;   // reach toward the road side at 5 m
            const TrackSample f5 = tr.at(z.sBend0 + 5.0f);
            float u5, b5;
            Track::toChute(z, f5.pos, &u5, &b5);
            CHECK(roadSideEdge < z.roadSign * b5 + 0.2f, "seed %u: at 5 m the corridor stops short of the road's centre (%.1f vs road at %.1f)", seed, roadSideEdge, z.roadSign * b5);
        }
    }
    std::printf("   %d chutes and %d gorges in 60 roads of 14 km; chord %.0f..%.0f m, steady slope %.3f..%.3f, worst chute-vs-road gap %.2f m, worst end offset %.2f m\n",
                total, gorges, minChord, maxChord, minMid, maxMid, worstRoadGap, worstEnd);
    CHECK(total >= 60 * 4, "chutes are common enough (%d)", total);
    CHECK(worstRoadGap < 3.6f, "the chute's ground stays within %.2f m of the detour road where they overlap", worstRoadGap);
}

// The terrain mesh agrees with the chute's ground: wherever a mesh vertex lies in the middle of the corridor it is on the plane.
void testMesh() {
    std::puts("the terrain mesh in a chute's corridor");
    int vertsChecked = 0, bad = 0;
    float worst = 0.0f;
    for (uint32_t seed = 1; seed <= 20; ++seed) {
        Track tr(seed);
        tr.ensureGenerated(9000.0f);
        for (const ShortcutZone* zp : chutesOf(tr)) {
            const ShortcutZone& z = *zp;
            if (!z.chuteReady) continue;
            const int i0 = static_cast<int>(z.sBend0 / cfg::kTrackStep) - 30, i1 = static_cast<int>(z.sBend1 / cfg::kTrackStep) + 30;
            for (int i = std::max(1, i0); i < i1 && i < tr.sampleCount() - 2; ++i)
                for (int col = 0; col < cfg::kTerrainCols; ++col) {
                    const Vec3 v = tr.ringVertex(i, col);
                    float u, b;
                    Track::toChute(z, v, &u, &b);
                    float wLo, wHi;
                    z.window(u, &wLo, &wHi);
                    if (u < 22.0f || u > z.chord - 30.0f || b < wLo + 0.5f || b > wHi - 0.5f) continue;   // (only what is in the corridor, not the road itself where the chute meets it)
                    ++vertsChecked;
                    const float err = std::fabs(v.y - z.groundY(u));
                    worst = std::max(worst, err);
                    if (err > 0.06f) ++bad;
                }
            // and the interpolated point between vertices (what the mesh really is) along the middle of the corridor
            for (float u = 26.0f; u < z.chord - 26.0f; u += 7.0f) {
                float s, x;
                const Vec3 p = tr.chutePoint(z, u, 0.0f);
                // find a road strip that reaches this point: the nearest sample of the detour on the chute side
                float bestD = 1e9f; int bi = -1;
                for (int i = std::max(1, i0); i < i1 && i < tr.sampleCount() - 2; ++i) {
                    const Vec3 q = tr.sampleAt(i).pos;
                    const float d2 = (q.x - p.x) * (q.x - p.x) + (q.z - p.z) * (q.z - p.z);
                    if (d2 < bestD) { bestD = d2; bi = i; }
                }
                if (bi < 0) continue;
                const TrackSample f = tr.sampleAt(bi);
                s = f.s;
                x = (p.x - f.pos.x) * f.right0.x + (p.z - f.pos.z) * f.right0.z;
                if (std::fabs(x) < 62.0f && std::fabs(x) > 12.0f) {
                    const Vec3 t = tr.terrainPoint(s, x);
                    float tu, tb;
                    Track::toChute(z, t, &tu, &tb);
                    float wLo2, wHi2;
                    z.window(tu, &wLo2, &wHi2);
                    if (tu > 24.0f && tu < z.chord - 32.0f && tb > wLo2 + 0.5f && tb < wHi2 - 0.5f) {
                        ++vertsChecked;
                        worst = std::max(worst, std::fabs(t.y - z.groundY(tu)));
                        if (std::fabs(t.y - z.groundY(tu)) > 0.08f) ++bad;
                    }
                }
            }
        }
    }
    std::printf("   %d mesh points in the middle of corridors, worst height error %.3f m\n", vertsChecked, worst);
    CHECK(vertsChecked > 500, "enough mesh points to judge (%d)", vertsChecked);
    CHECK(bad == 0, "%d mesh points off the chute's ground", bad);
}

// ---- riding ----------------------------------------------------------------------------------------------------------------------

struct Run {
    bool entered = false, exited = false, crashed = false;
    float sEnter = 0, sExit = 0, speedIn = 0, speedOut = 0;
    float worldJumpIn = 0, worldJumpOut = 0, headingJumpIn = 0, headingJumpOut = 0;
    float yJumpOut = 0;
    float maxScrape = 0;
    int steps = 0;
    CrashCause cause = CrashCause::None;
};

Vec3 worldPos(const Track& tr, const Skater& sk) {
    if (sk.inChute()) return tr.chutePoint(tr.shortcuts()[static_cast<size_t>(sk.chuteZone)], sk.s - tr.shortcuts()[static_cast<size_t>(sk.chuteZone)].sBend0, sk.x);
    const TrackSample f = tr.at(sk.s);
    return f.pos + f.right0 * sk.x;
}
float worldHeading(const Track& tr, const Skater& sk) {
    if (sk.inChute()) return tr.shortcuts()[static_cast<size_t>(sk.chuteZone)].cHeading + sk.alpha;
    return tr.at(sk.s).heading + sk.alpha;
}

// A rider who means to take the chute: moves to the chute side before the mouth, and in the chute keeps to the middle of the corridor and
// finally steers onto the road. `take` false: a rider who stays on the road, in the lane, whatever the detour does.
Run ride(const Track& tr, const ShortcutZone& z, float speed0, bool take, float lateralSkill = 1.0f, bool slideInChute = false) {
    Run r;
    Skater sk;
    sk.reset(z.sBend0 - 60.0f, speed0);
    const float dt = 1.0f / 120.0f;
    for (int i = 0; i < 120 * 60 && sk.s < z.sBend1 + 120.0f; ++i) {
        SkaterInput in;
        const bool wasIn = sk.inChute();
        const Vec3 p0 = worldPos(tr, sk);
        const float h0 = worldHeading(tr, sk);
        if (!sk.inChute()) {
            // on the road: follow the lane; a rider who takes the chute moves toward the chute side from 12 m before the mouth
            float target = 0.0f;
            if (take && !r.exited && sk.s > z.sBend0 - 44.0f) target = z.side * 4.4f;    // (up on the shoulder, behind the rail)
            if (take && !r.exited && sk.s > z.sBend0 - 13.0f) target = z.side * 8.0f;    // ... and out through the opening
            const TrackSample f = tr.at(sk.s);
            const float follow = f.curvature * sk.speed * (1.0f - cfg::kAutoFollow);
            const float wMax = std::max(0.2f, std::min(cfg::kYawRateMax, sk.gripNow() / std::max(sk.speed, 3.0f)));
            const float aDes = clampf(-0.25f * (sk.x - target), -0.35f, 0.35f);
            in.steer = clampf(follow / wMax + 3.0f * (aDes - sk.alpha), -1.0f, 1.0f);
            in.slide = sk.speed > 17.0f && std::fabs(f.curvature) > 1.0f / 40.0f && !take;
        } else {
            const ShortcutZone& zz = tr.shortcuts()[static_cast<size_t>(sk.chuteZone)];
            const float u = sk.s - zz.sBend0;
            float lo, hi;
            zz.window(u, &lo, &hi);
            float target = 0.5f * (lo + hi) * lateralSkill;
            if (u > zz.chord - 20.0f) target = 0.0f;
            const float aDes = clampf(-0.25f * (sk.x - target), -0.30f, 0.30f);
            in.steer = clampf(3.0f * (aDes - sk.alpha), -1.0f, 1.0f);
            in.slide = slideInChute && sk.speed > 20.0f;
        }
        in.push = sk.speed < 6.0f;
        const SkaterEvent ev = sk.step(in, tr, dt);
        r.maxScrape = std::max(r.maxScrape, sk.scrape);
        ++r.steps;
        if (ev == SkaterEvent::ChuteIn && !wasIn) {
            r.entered = true;
            r.sEnter = sk.s;
            r.speedIn = sk.speed;
            r.worldJumpIn = length(Vec3(worldPos(tr, sk).x - p0.x, 0, worldPos(tr, sk).z - p0.z));
            float dh = worldHeading(tr, sk) - h0;
            while (dh > kPi) dh -= kTwoPi;
            while (dh < -kPi) dh += kTwoPi;
            r.headingJumpIn = std::fabs(dh);
        }
        if (ev == SkaterEvent::ChuteOut) {
            r.exited = true;
            r.sExit = sk.s;
            r.speedOut = sk.speed;
            const Vec3 q = worldPos(tr, sk);
            r.worldJumpOut = length(Vec3(q.x - p0.x, 0, q.z - p0.z));
            float dh = worldHeading(tr, sk) - h0;
            while (dh > kPi) dh -= kTwoPi;
            while (dh < -kPi) dh += kTwoPi;
            r.headingJumpOut = std::fabs(dh);
            r.yJumpOut = std::fabs(q.y - p0.y);
        }
        if (sk.crashed) { r.crashed = true; r.cause = sk.crashCause; break; }
    }
    return r;
}

void testRiding() {
    std::puts("riding into a chute, through it and out of it");
    int zonesTested = 0, entered = 0, exited = 0, crashedTake = 0, stayedOut = 0, crashedStay = 0, slideOk = 0;
    float worstIn = 0, worstOut = 0, worstHIn = 0, worstHOut = 0, worstYOut = 0, minGain = 1e9f, maxGain = 0, sumGain = 0, sumSpeedIn = 0, sumSpeedOut = 0;
    for (uint32_t seed = 1; seed <= 40; ++seed) {
        Track tr(seed);
        tr.ensureGenerated(9000.0f);
        for (const ShortcutZone* zp : chutesOf(tr)) {
            const ShortcutZone& z = *zp;
            if (!z.chuteReady || z.sBend1 + 200.0f > tr.generatedLength()) continue;
            ++zonesTested;
            for (float v : {12.0f, 18.0f, 24.0f}) {
                const Run t = ride(tr, z, v, true);
                if (t.entered) ++entered;
                if (t.exited) ++exited;
                if (t.crashed) ++crashedTake;
                if (t.entered) { worstIn = std::max(worstIn, t.worldJumpIn); worstHIn = std::max(worstHIn, t.headingJumpIn); sumSpeedIn += t.speedIn; }
                if (t.exited) {
                    worstOut = std::max(worstOut, t.worldJumpOut);
                    worstHOut = std::max(worstHOut, t.headingJumpOut);
                    worstYOut = std::max(worstYOut, t.yJumpOut);
                    const float gain = (t.sExit - t.sEnter);
                    minGain = std::min(minGain, gain);
                    maxGain = std::max(maxGain, gain);
                    sumGain += gain;
                    sumSpeedOut += t.speedOut;
                }
                if (!t.crashed && v == 18.0f) {   // the same rider and a Coleman slide in the chute
                    const Run sl = ride(tr, z, v, true, 1.0f, true);
                    if (sl.entered && sl.exited && !sl.crashed) ++slideOk;
                }
            }
            const Run st = ride(tr, z, 18.0f, false);   // stays on the road
            if (!st.entered) ++stayedOut;
            if (st.crashed) ++crashedStay;
        }
    }
    const int rides = zonesTested * 3;
    std::printf("   %d chutes ridden at three speeds: entered %d, rejoined the road %d, crashed %d; staying on the road: %d/%d never entered, %d crashed\n", zonesTested, entered, exited, crashedTake, stayedOut, zonesTested, crashedStay);
    std::printf("   position jump on entering %.3f m, on leaving %.3f m (height %.2f m); heading jump %.4f / %.4f rad; the chute skips %.0f..%.0f m of road (mean %.0f); speed in %.1f, out %.1f m/s\n",
                worstIn, worstOut, worstYOut, worstHIn, worstHOut, minGain, maxGain, exited ? sumGain / exited : 0.0f, entered ? sumSpeedIn / entered : 0.0f, exited ? sumSpeedOut / exited : 0.0f);
    CHECK(zonesTested >= 100, "enough chutes ridden (%d)", zonesTested);
    CHECK(entered == rides, "a rider who moves to the chute side at the mouth is in the chute (%d/%d)", entered, rides);
    CHECK(exited >= rides * 0.97f, "... and comes out the other end onto the road (%d/%d)", exited, rides);
    CHECK(crashedTake <= rides * 0.03f, "an empty chute is safe to ride (%d crashes in %d)", crashedTake, rides);
    CHECK(stayedOut == zonesTested, "a rider who stays on the road is never pulled into a chute (%d/%d)", stayedOut, zonesTested);
    CHECK(crashedStay == 0, "... and rides the detour without trouble (%d crashes)", crashedStay);
    CHECK(worstIn < 0.45f && worstHIn < 0.02f, "entering: one step of motion and nothing more: %.3f m, %.4f rad", worstIn, worstHIn);
    CHECK(worstOut < 0.6f && worstHOut < 0.03f, "rejoining the road: %.3f m, %.4f rad", worstOut, worstHOut);
    CHECK(worstYOut < 0.6f, "... and the ground it was on is within %.2f m of the road", worstYOut);
    CHECK(minGain > 150.0f, "a chute skips at least 150 m of the detour road (%.0f)", minGain);
    CHECK(slideOk >= zonesTested * 0.95f, "a Coleman slide inside a chute works (%d/%d)", slideOk, zonesTested);
}

// Changing frames moves nothing: put a rider where the change happens and take a step of no time.
void testFrameChange() {
    std::puts("changing frames (a step of no time)");
    int n = 0, badIn = 0, badOut = 0;
    float worstIn = 0, worstHIn = 0, worstOut = 0, worstHOut = 0, worstYOut = 0;
    for (uint32_t seed = 1; seed <= 40; ++seed) {
        Track tr(seed);
        tr.ensureGenerated(8000.0f);
        for (const ShortcutZone* zp : chutesOf(tr)) {
            const ShortcutZone& z = *zp;
            if (!z.chuteReady || z.sBend1 + 100.0f > tr.generatedLength()) continue;
            for (float ds : {-10.0f, -4.0f, 2.0f, 6.0f})
                for (float alpha : {-0.2f, 0.0f, 0.3f}) {
                    Skater sk;
                    sk.reset(z.sBend0 + ds, 18.0f);
                    sk.x = z.side * 5.3f;
                    sk.alpha = alpha;
                    const Vec3 p = worldPos(tr, sk);
                    const float h = worldHeading(tr, sk);
                    const SkaterEvent ev = sk.step(SkaterInput(), tr, 0.0f);
                    ++n;
                    if (ev != SkaterEvent::ChuteIn || !sk.inChute()) { ++badIn; continue; }
                    const Vec3 q = worldPos(tr, sk);
                    float dh = worldHeading(tr, sk) - h;
                    while (dh > kPi) dh -= kTwoPi;
                    while (dh < -kPi) dh += kTwoPi;
                    worstIn = std::max(worstIn, length(Vec3(q.x - p.x, 0, q.z - p.z)));
                    worstHIn = std::max(worstHIn, std::fabs(dh));
                    float lo, hi;
                    z.window(sk.s - z.sBend0, &lo, &hi);
                    if (sk.x < lo - 1e-3f || sk.x > hi + 1e-3f) ++badIn;
                }
            // leaving: on the road beside the end of the chord
            for (float du : {-18.0f, -12.0f, -6.0f, 0.0f, 3.5f})
                for (float b : {-2.5f, 0.0f, 2.0f}) {
                    Skater sk;
                    sk.reset(z.sBend0, 18.0f);
                    sk.chuteZone = tr.zoneIndexAt(z.sBend0);
                    sk.s = z.sBend0 + z.chord + du;
                    sk.x = b;
                    sk.alpha = 0.1f;
                    const Vec3 p = worldPos(tr, sk);
                    const float h = worldHeading(tr, sk);
                    const SkaterEvent ev = sk.step(SkaterInput(), tr, 0.0f);
                    if (ev != SkaterEvent::ChuteOut) continue;   // (not on the road yet: still riding the chute)
                    const Vec3 q = worldPos(tr, sk);
                    float dh = worldHeading(tr, sk) - h;
                    while (dh > kPi) dh -= kTwoPi;
                    while (dh < -kPi) dh += kTwoPi;
                    worstOut = std::max(worstOut, length(Vec3(q.x - p.x, 0, q.z - p.z)));
                    worstHOut = std::max(worstHOut, std::fabs(dh));
                    worstYOut = std::max(worstYOut, std::fabs(q.y - p.y));
                    if (sk.inChute() || std::fabs(sk.x) > cfg::kRailOffset) ++badOut;
                }
        }
    }
    std::printf("   %d entries: %d refused; moved %.4f m / %.5f rad; leaving: moved %.3f m / %.4f rad (height %.2f m), %d bad\n", n, badIn, worstIn, worstHIn, worstOut, worstHOut, worstYOut, badOut);
    CHECK(n > 400, "enough entries tried (%d)", n);
    CHECK(badIn == 0, "everyone beyond the shoulder in the opening is in the chute and inside its corridor (%d of %d not)", badIn, n);
    CHECK(worstIn < 0.002f && worstHIn < 0.002f, "entering a chute moves nothing: %.4f m %.5f rad", worstIn, worstHIn);
    CHECK(worstOut < 0.5f && worstHOut < 0.03f && worstYOut < 0.6f, "leaving: %.3f m, %.4f rad, %.2f m high", worstOut, worstHOut, worstYOut);
    CHECK(badOut == 0, "after leaving the rider is on the road, inside the rails");
}

// A rider in a chute who steers nowhere neither sticks nor leaves: it scrapes along a wall, crashes, or carries on out of the end.
void testNoSticking() {
    std::puts("no input in a chute");
    int tested = 0, stuck = 0;
    for (uint32_t seed = 1; seed <= 25; ++seed) {
        Track tr(seed);
        tr.ensureGenerated(7000.0f);
        for (const ShortcutZone* zp : chutesOf(tr)) {
            const ShortcutZone& z = *zp;
            if (!z.chuteReady || z.sBend1 + 200.0f > tr.generatedLength()) continue;
            for (float steerHold : {-0.6f, 0.0f, 0.6f}) {
                Skater sk;
                sk.reset(z.sBend0 - 20.0f, 20.0f);
                // put the rider straight into the chute, in the middle of it
                {
                    const TrackSample f = tr.at(z.sBend0);
                    float lo, hi;
                    z.window(0.0f, &lo, &hi);
                    sk.chuteZone = tr.zoneIndexAt(z.sBend0);
                    sk.s = z.sBend0 + 2.0f;
                    sk.x = 0.5f * (lo + hi);
                    sk.alpha = 0.0f;
                    (void)f;
                }
                ++tested;
                bool ended = false;
                for (int i = 0; i < 120 * 40 && !ended; ++i) {
                    SkaterInput in;
                    in.steer = steerHold;
                    const SkaterEvent ev = sk.step(in, tr, 1.0f / 120.0f);
                    if (sk.crashed || ev == SkaterEvent::ChuteOut) ended = true;
                }
                if (!ended) ++stuck;
            }
        }
    }
    std::printf("   %d rides without steering (and with the stick held to the side): %d got stuck\n", tested, stuck);
    CHECK(tested >= 150 && stuck == 0, "nobody gets stuck in a chute: %d of %d", stuck, tested);
}

// ---- obstacles ----------------------------------------------------------------------------------------------------------------------

// The collision rule of Game::collide, for a rider in a chute: what does it hit, if anything (kind + 1; bushes are soft and count as 0.5)?
const Obstacle* hitOf(const World& w, const Skater& sk) {
    for (const Obstacle& o : w.obstacles()) {
        if (o.chute != sk.chuteZone) continue;
        const float ds = o.s - sk.s;
        if (std::fabs(ds) < o.hs + cfg::kSkaterHalfLength && std::fabs(o.x - sk.x) < o.hx + cfg::kSkaterHalfWidth) return &o;
    }
    return nullptr;
}

float laneAt(const World::ChutePlan& pl, float u) {
    if (pl.laneU.empty()) return 0.0f;
    if (u <= pl.laneU.front()) return pl.laneB.front();
    if (u >= pl.laneU.back()) return pl.laneB.back();
    size_t i = 0;
    while (i + 2 < pl.laneU.size() && pl.laneU[i + 1] < u) ++i;
    return lerpf(pl.laneB[i], pl.laneB[i + 1], smoothstep(pl.laneU[i], pl.laneU[i + 1], u));
}

struct Pass { bool done = false; bool crashed = false; int bushes = 0; float time = 0; };

// A rider through the chute: follows the free line (`follow`) or just holds the middle of the corridor, steering by looking a few metres ahead.
Pass pass(const Track& tr, const World& w, int zi, float speed0, bool follow, bool slide = false) {
    const ShortcutZone& z = tr.shortcuts()[static_cast<size_t>(zi)];
    const World::ChutePlan& pl = w.chutePlan(zi);
    Skater sk;
    sk.reset(z.sBend0, speed0);
    sk.chuteZone = zi;
    sk.s = z.sBend0 + 2.0f;
    sk.x = laneAt(pl, 22.0f);
    Pass r;
    std::vector<const Obstacle*> seen;
    const float dt = 1.0f / 120.0f;
    for (int i = 0; i < 120 * 40; ++i) {
        const float u = sk.s - z.sBend0;
        float lo, hi;
        z.window(u, &lo, &hi);
        const float look = clampf(sk.speed * 0.45f, 6.0f, 14.0f);
        float target = follow ? laneAt(pl, u + look) : 0.5f * (lo + hi);
        if (u > z.chord - 22.0f) target = 0.0f;
        const float aDes = clampf(-0.30f * (sk.x - target), -0.40f, 0.40f);
        SkaterInput in;
        in.steer = clampf(3.5f * (aDes - sk.alpha), -1.0f, 1.0f);
        in.slide = slide && sk.speed > 14.0f && std::fabs(sk.x - target) > 1.5f;
        in.push = sk.speed < 6.0f;
        const SkaterEvent ev = sk.step(in, tr, dt);
        r.time += dt;
        if (ev == SkaterEvent::ChuteOut) { r.done = true; break; }
        if (sk.crashed) { r.crashed = true; break; }
        if (const Obstacle* o = hitOf(w, sk)) {
            if (o->kind == ObstacleKind::Bush) {
                if (std::find(seen.begin(), seen.end(), o) == seen.end()) { seen.push_back(o); ++r.bushes; sk.speed *= 0.8f; }
            } else {
                r.crashed = true;
                break;
            }
        }
    }
    return r;
}

void testObstacles() {
    std::puts("trees, rocks and bushes in the corridor");
    int chutes = 0, laneBad = 0, spreadBad = 0, outside = 0, rowsTotal = 0;
    int followN = 0, followOk = 0, middleN = 0, middleHit = 0, slideN = 0, slideOk = 0;
    int trees = 0, rocks = 0, bushes = 0;
    float minLaneGap = 1e9f;
    for (uint32_t seed = 1; seed <= 40; ++seed) {
        World w(seed);
        w.setObstaclesEnabled(true);
        w.track().ensureGenerated(9000.0f);
        const Track& tr = w.track();
        for (size_t zi = 0; zi < tr.shortcuts().size(); ++zi) {
            const ShortcutZone& z = tr.shortcuts()[zi];
            if (!z.isChute() || !z.chuteReady || z.sBend1 + 200.0f > tr.generatedLength()) continue;
            ++chutes;
            const World::ChutePlan& pl = w.chutePlan(static_cast<int>(zi));
            rowsTotal += static_cast<int>(pl.laneU.size());
            // every obstacle is in the corridor, off the free line, and the free line is wide and moves slowly
            for (const Obstacle& o : pl.obstacles) {
                const float u = o.s - z.sBend0;
                float lo, hi;
                z.window(u, &lo, &hi);
                if (o.x < lo || o.x > hi || o.chute != static_cast<int>(zi)) ++outside;
                const float gap = std::fabs(o.x - laneAt(pl, u)) - o.hx;
                minLaneGap = std::min(minLaneGap, gap);
                if (gap < 2.0f) ++laneBad;   // (the free line is 2.4 m each side of its middle at its row; between rows it moves a little)
                if (o.kind == ObstacleKind::Tree) ++trees;
                else if (o.kind == ObstacleKind::Rock) ++rocks;
                else ++bushes;
            }
            for (size_t i = 1; i < pl.laneB.size(); ++i)
                if (std::fabs(pl.laneB[i] - pl.laneB[i - 1]) > 1.55f || pl.laneU[i] - pl.laneU[i - 1] < 7.9f) ++spreadBad;
            CHECK(pl.laneU.size() >= 3 && pl.obstacles.size() >= 2, "seed %u: a chute has rows (%zu) and obstacles (%zu)", seed, pl.laneU.size(), pl.obstacles.size());
            // spawn them into the world the way the game does, and ride through
            PlayerRef pr;
            pr.s = z.sBend0 - 100.0f;
            w.update(0.0f, pr);
            for (float v : {12.0f, 18.0f, 24.0f}) {
                const Pass f = pass(tr, w, static_cast<int>(zi), v, true);
                ++followN;
                if (f.done && !f.crashed) ++followOk;
                const Pass m = pass(tr, w, static_cast<int>(zi), v, false);
                ++middleN;
                if (m.crashed) ++middleHit;
            }
            const Pass sl = pass(tr, w, static_cast<int>(zi), 22.0f, true, true);
            ++slideN;
            if (sl.done && !sl.crashed) ++slideOk;
        }
    }
    std::printf("   %d chutes, %d rows, %d trees %d rocks %d bushes; the free line: nearest obstacle edge %.2f m from its middle, %d bad, %d outside the corridor\n", chutes, rowsTotal, trees, rocks, bushes, minLaneGap, laneBad, outside);
    std::printf("   following the free line: %d/%d got through; riding straight down the middle: %d/%d hit something; with the slide: %d/%d\n", followOk, followN, middleHit, middleN, slideOk, slideN);
    CHECK(chutes >= 100, "enough chutes (%d)", chutes);
    CHECK(laneBad == 0 && outside == 0 && spreadBad == 0, "the free line is clear (%d), obstacles are inside the corridor (%d), the line moves slowly (%d)", laneBad, outside, spreadBad);
    CHECK(followOk >= followN * 0.97f, "a rider who follows the free line gets through at 12 to 24 m/s (%d/%d)", followOk, followN);
    CHECK(middleHit >= middleN / 4, "the obstacles matter: a rider who does not steer hits something (%d/%d)", middleHit, middleN);
    CHECK(middleHit <= middleN * 0.85f, "... but it is not hopeless (%d/%d hit)", middleHit, middleN);
    CHECK(slideOk >= slideN * 0.95f, "with a Coleman slide for the sharp moves (%d/%d)", slideOk, slideN);
    CHECK(trees > 50 && rocks > 50 && bushes > 50, "all three kinds appear: %d trees, %d rocks, %d bushes", trees, rocks, bushes);
}

}  // namespace

int main() {
    testGeometry();
    testMesh();
    testFrameChange();
    testRiding();
    testNoSticking();
    testObstacles();
    std::printf("\n%d checks, %d failed\n", checks, failures);
    return failures ? 1 : 0;
}
