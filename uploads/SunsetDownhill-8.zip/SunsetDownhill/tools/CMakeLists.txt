# Desktop tools for tuning / testing the platform independent core. NOT part of the Android build.
#   cmake -S tools -B build-tools && cmake --build build-tools
cmake_minimum_required(VERSION 3.16)
project(sunset_downhill_tools CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
if(NOT CMAKE_BUILD_TYPE)
    set(CMAKE_BUILD_TYPE Release)
endif()

set(CORE_DIR ${CMAKE_CURRENT_SOURCE_DIR}/../app/src/main/cpp/core)
file(GLOB CORE_SOURCES ${CORE_DIR}/*.cpp)

# GPU-free subset (simulation only)
set(SIM_SOURCES ${CORE_SOURCES})
list(FILTER SIM_SOURCES EXCLUDE REGEX ".*/(graphics_panel|renderer|engine|gl_util|shaders|scene_builder|hud|hud_mp|ui_batch|ui_font|ui_widgets|input|controls|controls_editor|audio_synth)\\.cpp$")

add_executable(sim_physics sim_physics.cpp ${SIM_SOURCES})
add_executable(sim_game sim_game.cpp ${SIM_SOURCES})
add_executable(audio_dump audio_dump.cpp ${CORE_DIR}/audio_synth.cpp)
add_executable(test_audio test_audio.cpp ${CORE_DIR}/audio_synth.cpp)   # no engine-like tone may follow the speed
# The drivers: thousands of cars over several seeds must never touch a cone, a rock or each other
add_executable(test_traffic test_traffic.cpp ${SIM_SOURCES})
# The LAN protocol on loopback: discovery, join, start, relay, interpolation, spoofed and malformed packets
add_executable(test_net test_net.cpp ${CORE_DIR}/net.cpp)
# Race rules and the gorge jump: finish line, simultaneous start, kicker jumps across the gorge, rider mesh budget
add_executable(test_race test_race.cpp ${SIM_SOURCES})
# The rolling road: hills, climbing without and with PUSH, the kick-push rules, the Coleman slide
add_executable(test_hills test_hills.cpp ${SIM_SOURCES})
# The forest: crowns of different trees keep apart, the world's crown radii match the meshes
add_executable(test_trees test_trees.cpp ${SIM_SOURCES})
# Checkpoints and respawns of LAN races: the gates, the wipe-out -> put back -> grace cycle, lives, the race clock
add_executable(test_respawn test_respawn.cpp ${SIM_SOURCES})
# Chutes (off-road shortcuts): the road round them, their ground and corridor, the terrain mesh in them, riding in and out, obstacles
add_executable(test_chute test_chute.cpp ${SIM_SOURCES})
# ... and the whole game around a chute: events, bonus, camera, the pose another phone builds, scenery (needs the scene builder, no GPU)
add_executable(test_chute_game test_chute_game.cpp ${CORE_DIR}/scene_builder.cpp ${SIM_SOURCES})
# How fast can a feedback driver take the bends (the yardstick for steering / the Coleman slide)? Build it against old and new physics to compare
add_executable(test_steering test_steering.cpp ${SIM_SOURCES})
# CPU cost of a frame (simulation + scene geometry) with and without other riders
add_executable(bench_frame bench_frame.cpp ${CORE_DIR}/scene_builder.cpp ${SIM_SOURCES})
foreach(t sim_physics sim_game audio_dump test_audio test_traffic test_net test_race test_hills test_trees test_respawn test_chute test_chute_game test_steering bench_frame)
    target_include_directories(${t} PRIVATE ${CORE_DIR})
endforeach()

# The graphics options: the saved text, the GRAPHICS screen on every aspect ratio, the slider and the presets
add_executable(test_graphics test_graphics.cpp ${CORE_DIR}/graphics_settings.cpp ${CORE_DIR}/graphics_panel.cpp ${CORE_DIR}/controls_config.cpp
    ${CORE_DIR}/ui_widgets.cpp ${CORE_DIR}/ui_batch.cpp ${CORE_DIR}/ui_font.cpp)
target_include_directories(test_graphics PRIVATE ${CORE_DIR})

# Control schemes, button customisation and tilt steering: input -> rider, HUD and CONTROLS screen (no GPU needed)
add_executable(test_controls test_controls.cpp
    ${CORE_DIR}/controls_config.cpp ${CORE_DIR}/tilt.cpp ${CORE_DIR}/input.cpp ${CORE_DIR}/controls_editor.cpp
    ${CORE_DIR}/controls.cpp ${CORE_DIR}/hud.cpp ${CORE_DIR}/hud_mp.cpp ${CORE_DIR}/ui_widgets.cpp ${CORE_DIR}/ui_batch.cpp ${CORE_DIR}/ui_font.cpp)
target_include_directories(test_controls PRIVATE ${CORE_DIR})
enable_testing()
add_test(NAME controls COMMAND test_controls)
add_test(NAME audio COMMAND test_audio)
add_test(NAME traffic COMMAND test_traffic 240 4)
add_test(NAME net COMMAND test_net)
add_test(NAME race COMMAND test_race)
add_test(NAME hills COMMAND test_hills)
add_test(NAME trees COMMAND test_trees)
add_test(NAME respawn COMMAND test_respawn)
add_test(NAME chute COMMAND test_chute)
add_test(NAME chute_game COMMAND test_chute_game)
add_test(NAME graphics COMMAND test_graphics)

# Renders the HUD / CONTROLS screen in every steering mode to PPM images (software rasteriser): ./dump_ui <out_dir>
add_executable(dump_ui dump_ui.cpp
    ${CORE_DIR}/controls_config.cpp ${CORE_DIR}/tilt.cpp ${CORE_DIR}/input.cpp ${CORE_DIR}/controls_editor.cpp
    ${CORE_DIR}/controls.cpp ${CORE_DIR}/hud.cpp ${CORE_DIR}/hud_mp.cpp ${CORE_DIR}/ui_widgets.cpp ${CORE_DIR}/ui_batch.cpp ${CORE_DIR}/ui_font.cpp)
target_include_directories(dump_ui PRIVATE ${CORE_DIR})

# Headless renderer session needs Mesa's EGL + GLES (e.g. apt install libegl-dev libgles-dev libgl1-mesa-dri)
find_library(EGL_LIB EGL)
find_library(GLES_LIB GLESv2)
if(EGL_LIB AND GLES_LIB)
    # render_session: the menu, a run and the crash screens; render_models: close-ups of the rider, board and every car type;
    # render_look: rider / board / tree / rail close-ups, frames of a real run and of a steered gorge flight;
    # render_traffic: the autopilot rides through traffic; render_lan: two phones race over loopback (one is rendered);
    # test_mp_engine: three complete engines play a LAN race through the lobby screens (no GPU needed at run time)
    # render_shots: frames of a real run (motion blur settings, quality tiers, a ride through a chute); render_ui: the menus incl. GRAPHICS
    foreach(t render_session render_models render_look render_traffic render_lan test_mp_engine render_shots render_ui)
        add_executable(${t} ${t}.cpp ${CORE_SOURCES})
        target_include_directories(${t} PRIVATE ${CORE_DIR})
        target_link_libraries(${t} ${EGL_LIB} ${GLES_LIB})
    endforeach()
    add_test(NAME multiplayer_engine COMMAND test_mp_engine)
else()
    message(STATUS "EGL/GLESv2 not found: skipping render_session, render_models, render_look, render_traffic, render_lan, test_mp_engine")
endif()
