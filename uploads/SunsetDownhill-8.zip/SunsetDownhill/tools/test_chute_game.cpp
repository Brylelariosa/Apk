// test_chute_game.cpp - the whole game around a chute (no GPU): a rider is steered into the first chute of several roads and through it, with the
// scene built every frame. Checks what the rest of the game makes of it: the events and the bonus, the camera, the rider's pose (and the one
// another phone would build from what we send), the scenery around the corridor, the obstacles in the instance lists, and the road afterwards.
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <vector>

#include "game.h"
#include "scene_builder.h"

using namespace sd;

namespace {
int failures = 0, checks = 0;
#define CHECK(cond, ...)                                          \
    do {                                                          \
        ++checks;                                                 \
        if (!(cond)) {                                            \
            ++failures;                                           \
            std::printf("  FAIL line %d: %s  ", __LINE__, #cond); \
            std::printf(__VA_ARGS__);                             \
            std::printf("\n");                                    \
        }                                                         \
    } while (0)

float laneAt(const World::ChutePlan& pl, float u) {
    if (pl.laneU.empty()) return 0.0f;
    if (u <= pl.laneU.front()) return pl.laneB.front();
    if (u >= pl.laneU.back()) return pl.laneB.back();
    size_t i = 0;
    while (i + 2 < pl.laneU.size() && pl.laneU[i + 1] < u) ++i;
    return lerpf(pl.laneB[i], pl.laneB[i + 1], smoothstep(pl.laneU[i], pl.laneU[i + 1], u));
}

SkaterInput policy(Game& g, int zi, bool take) {
    const Track& tr = g.world().track();
    const ShortcutZone& z = tr.shortcuts()[static_cast<size_t>(zi)];
    const Skater& sk = g.skater();
    SkaterInput in = g.autopilot().compute(tr, g.world().obstacles(), sk);
    if (sk.inChute()) {
        const float u = sk.s - z.sBend0;
        float lo, hi;
        z.window(u, &lo, &hi);
        const World::ChutePlan& pl = g.world().chutePlan(zi);
        float target = laneAt(pl, u + clampf(sk.speed * 0.45f, 6.0f, 14.0f));
        if (u > z.chord - 22.0f) target = 0.0f;
        in.steer = clampf(3.5f * (clampf(-0.30f * (sk.x - target), -0.4f, 0.4f) - sk.alpha), -1.0f, 1.0f);
        in.slide = false;
        in.tuck = false;
    } else if (take && sk.s > z.sBend0 - 46.0f && sk.s < z.sBend1) {
        float target = z.side * 4.4f;
        if (sk.s > z.sBend0 - 13.0f) target = z.side * 8.0f;
        const TrackSample f = tr.at(sk.s);
        const float follow = f.curvature * sk.speed * (1.0f - cfg::kAutoFollow);
        const float wMax = std::max(0.2f, std::min(cfg::kYawRateMax, sk.gripNow() / std::max(sk.speed, 3.0f)));
        in.steer = clampf(follow / wMax + 3.0f * (clampf(-0.25f * (sk.x - target), -0.35f, 0.35f) - sk.alpha), -1.0f, 1.0f);
        in.slide = false;
    }
    return in;
}

void testSeed(uint32_t seed) {
    Game g;
    g.setBaseSeed(seed);
    g.startRun();
    SceneGeometry geo;
    // the first chute that is far enough ahead for the rider to get going
    int zi = -1;
    for (int i = 0; i < 60 * 8 && g.phase() != Phase::Running; ++i) g.update(1.0f / 60.0f, SkaterInput());
    for (int tries = 0; tries < 400 && zi < 0; ++tries) {
        g.world().track();   // (generated as the rider goes)
        const auto& zones = g.world().track().shortcuts();
        for (size_t i = 0; i < zones.size(); ++i)
            if (zones[i].isChute() && zones[i].sBend0 > g.skater().s + 200.0f && zones[i].sBend0 < 2600.0f) { zi = static_cast<int>(i); break; }
        if (zi < 0) {   // plan a bit further: ride on
            for (int k = 0; k < 600 && g.phase() == Phase::Running; ++k) g.update(1.0f / 60.0f, g.autopilot().compute(g.world().track(), g.world().obstacles(), g.skater()));
            if (g.phase() != Phase::Running || g.skater().s > 2500.0f) return;
        }
    }
    if (zi < 0) return;
    const ShortcutZone zone = g.world().track().shortcuts()[static_cast<size_t>(zi)];
    // ride up to the chute with the autopilot (it keeps clear of cones and cars)
    float time = 0.0f;
    bool entered = false, exited = false, crashed = false;
    float scoreBefore = 0.0f, scoreAfter = 0.0f;
    int framesIn = 0, treesSeen = 0, grassSeen = 0, bushesSeen = 0;
    float worstCamJump = 0.0f, worstPoseDiff = 0.0f;
    Vec3 lastCam;
    bool haveCam = false;
    const Vec3 origin(0.0f, 0.0f, 0.0f);
    for (int i = 0; i < 60 * 120 && g.phase() == Phase::Running && !exited && !crashed; ++i) {
        const bool before = g.skater().inChute();
        const float scoreNow = g.score();
        g.update(1.0f / 60.0f, policy(g, zi, true));
        time += 1.0f / 60.0f;
        if (!before && g.skater().inChute()) { entered = true; scoreBefore = scoreNow; }
        if (before && !g.skater().inChute() && !g.skater().crashed) { exited = true; scoreAfter = g.score(); }
        if (g.skater().crashed) crashed = true;
        if (i % 2 == 0 && (g.skater().s > zone.sBend0 - 120.0f)) {
            const FrameParams fp = buildScene(g, 1.0f, geo);
            if (haveCam) worstCamJump = std::max(worstCamJump, length(fp.cam.pos - lastCam));
            lastCam = fp.cam.pos;
            haveCam = true;
            if (g.skater().inChute()) {
                ++framesIn;
                treesSeen = std::max<int>(treesSeen, static_cast<int>(geo.instances[kBatchPine].size() + geo.instances[kBatchAutumn].size() + geo.instances[kBatchBirch].size()));
                grassSeen = std::max<int>(grassSeen, static_cast<int>(geo.instances[kBatchGrass].size()));
                bushesSeen = std::max<int>(bushesSeen, static_cast<int>(geo.instances[kBatchBush].size()));
                // the pose another phone builds from what we send is the same
                const SkaterPose a = g.skaterPose(origin);
                const SkaterPose b = poseFromRiderNet(g.world().track(), g.riderNet(), origin, g.time());
                if (std::fabs(g.skater().stepVis) < 0.02f)   // (the settling after changing frames is only drawn locally)
                    worstPoseDiff = std::max(worstPoseDiff, length(a.origin - b.origin) + length(a.fwd - b.fwd) + length(a.up - b.up));
            }
        }
    }
    const char* tag = entered ? (exited ? "rode it" : (crashed ? "crashed in it" : "?")) : (crashed ? "crashed before it" : "never entered");
    if (!entered) std::printf("   (seed %u: s=%.1f x=%.2f speed=%.1f phase=%d crashed=%d cause=%d zone sBend0=%.0f side=%.0f)\n", seed, g.skater().s, g.skater().x, g.skater().speed, (int)g.phase(), g.skater().crashed, (int)g.skater().crashCause, zone.sBend0, zone.side);
    std::printf("   seed %u: chute at %.0f m: %s; in the chute %d frames; camera jump %.2f m; pose mismatch %.4f; %d trees/%d bushes/%d grass in view; bonus %+.0f\n", seed, zone.sBend0, tag,
                framesIn * 2, worstCamJump, worstPoseDiff, treesSeen, bushesSeen, grassSeen, scoreAfter - scoreBefore);
    if (!entered && crashed && g.skater().s < zone.sBend0 - 100.0f) return;   // (the autopilot's own run ended on a car or cone long before the chute)
    CHECK(entered, "seed %u: the rider steered into the chute is in it", seed);
    if (!entered) return;
    CHECK(exited || crashed, "seed %u: the ride ends one way or the other", seed);
    if (exited) {
        CHECK(scoreAfter - scoreBefore >= cfg::kChuteBonus - 1.0f, "seed %u: the style bonus is paid (%+.0f)", seed, scoreAfter - scoreBefore);
        CHECK(g.skater().s > zone.sBend1 - 40.0f, "seed %u: back on the road past the detour (s %.0f)", seed, g.skater().s);
    }
    CHECK(worstPoseDiff < 0.05f, "seed %u: another phone shows the rider where it is (%.4f)", seed, worstPoseDiff);
    CHECK(worstCamJump < 6.0f, "seed %u: the camera never jumps (%.2f m in a frame)", seed, worstCamJump);
    CHECK(framesIn > 20, "seed %u: it takes a while to ride (%d frames)", seed, framesIn);
    CHECK(treesSeen > 10 && grassSeen > 5, "seed %u: forest and meadow around the chute (%d trees, %d tufts)", seed, treesSeen, grassSeen);
}

}  // namespace

int main() {
    std::puts("a rider through a chute, with the whole game around it");
    for (uint32_t seed : {3u, 5u, 8u, 13u, 21u, 34u, 55u, 77u}) testSeed(seed);
    std::printf("\n%d checks, %d failed\n", checks, failures);
    return failures ? 1 : 0;
}
