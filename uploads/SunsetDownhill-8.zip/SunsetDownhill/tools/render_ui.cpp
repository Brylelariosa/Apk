// render_ui: screenshots of the menu screens that are new - the GRAPHICS screen at several settings, the pause overlay and the menu - driven by
// taps on the real Engine (headless Mesa GLES 3).   render_ui W H outDir
#include <EGL/egl.h>
#include <EGL/eglext.h>
#include <GLES3/gl3.h>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include "engine.h"
using namespace sd;

static void savePPM(const char* path, int w, int h) {
    std::vector<unsigned char> px(static_cast<size_t>(w) * h * 4), out(static_cast<size_t>(w) * h * 3);
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    glReadPixels(0, 0, w, h, GL_RGBA, GL_UNSIGNED_BYTE, px.data());
    for (int y = 0; y < h; ++y) for (int x = 0; x < w; ++x) { const unsigned char* s = &px[((h - 1 - y) * w + x) * 4]; unsigned char* d = &out[(y * w + x) * 3]; d[0]=s[0]; d[1]=s[1]; d[2]=s[2]; }
    FILE* f = std::fopen(path, "wb"); std::fprintf(f, "P6\n%d %d\n255\n", w, h); std::fwrite(out.data(), 1, out.size(), f); std::fclose(f);
}

int main(int argc, char** argv) {
    const int W = argc > 1 ? std::atoi(argv[1]) : 1600, H = argc > 2 ? std::atoi(argv[2]) : 720;
    const char* dir = argc > 3 ? argv[3] : "/tmp/ui";
    auto getPD = (PFNEGLGETPLATFORMDISPLAYEXTPROC)eglGetProcAddress("eglGetPlatformDisplayEXT");
    EGLDisplay dpy = getPD(EGL_PLATFORM_SURFACELESS_MESA, EGL_DEFAULT_DISPLAY, nullptr);
    EGLint maj, min; eglInitialize(dpy, &maj, &min); eglBindAPI(EGL_OPENGL_ES_API);
    const EGLint ca[] = {EGL_SURFACE_TYPE, EGL_PBUFFER_BIT, EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT, EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8, EGL_ALPHA_SIZE, 8, EGL_DEPTH_SIZE, 24, EGL_NONE};
    EGLConfig cfg; EGLint n; eglChooseConfig(dpy, ca, &cfg, 1, &n);
    const EGLint pa[] = {EGL_WIDTH, W, EGL_HEIGHT, H, EGL_NONE};
    EGLSurface surf = eglCreatePbufferSurface(dpy, cfg, pa);
    const EGLint xa[] = {EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE};
    EGLContext ctx = eglCreateContext(dpy, cfg, EGL_NO_CONTEXT, xa);
    eglMakeCurrent(dpy, surf, surf, ctx);

    Engine eng;
    eng.setControls("");
    eng.onSurfaceCreated();
    eng.onSurfaceChanged(W, H);
    auto frames = [&](int k) { for (int i = 0; i < k; ++i) eng.stepFrame(1.0f / 60.0f); };
    auto shot = [&](const char* name) { char p[256]; std::snprintf(p, sizeof(p), "%s/%s.ppm", dir, name); savePPM(p, W, H); std::fprintf(stderr, "wrote %s\n", name); };
    auto tap = [&](const Rect& r) { const float x = r.x + r.w * 0.5f, y = r.y + r.h * 0.5f; eng.onTouch(0, 1, x, y); eng.onTouch(2, 1, x, y); };
    const UiLayout& L = eng.controls().layout();
    frames(240);
    shot("menu");
    tap(L.graphicsMenu);
    frames(30);
    shot("gfx_default");
    const GraphicsPanel::Geometry g = GraphicsPanel::geometry(L);
    // drag the slider to 90%, then to the right end, then tap OFF
    const float x90 = g.trackX0 + (g.trackX1 - g.trackX0) * 0.9f;
    eng.onTouch(0, 2, g.trackX0 + (g.trackX1 - g.trackX0) * 0.3f, g.trackY);
    eng.onTouch(1, 2, x90, g.trackY);
    frames(20);
    eng.onTouch(2, 2, x90, g.trackY);
    shot("gfx_90");
    std::fprintf(stderr, "motion blur now %d%%\n", eng.graphics().motionBlur);
    tap(g.chip[0]);
    frames(20);
    shot("gfx_off");
    std::fprintf(stderr, "motion blur now %d%% | saved text: %s\n", eng.graphics().motionBlur, eng.controlsString().c_str());
    tap(g.done);
    frames(10);
    // pause overlay: start, ride a few seconds, pause
    tap(Rect{0, 0, (float)W, (float)H});
    frames(60 * 6);
    eng.requestPause();
    frames(30);
    shot("pause");
    tap(L.graphicsPause);
    frames(20);
    shot("gfx_from_pause");
    return 0;
}
