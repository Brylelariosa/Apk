// render_shots: frames of a real run for reviewing the look headlessly (software GLES 3 via Mesa).
//   render_shots speed W H outDir seed kmh blur1 [blur2 ...]    ride (autopilot, tucked) until kmh is reached, then render that moment once per
//                                                               motion blur setting (0..1)
//   render_shots at W H outDir seed seconds [name]              ride for `seconds` and render
//   render_shots sheet ...                                      (see below)
#include <EGL/egl.h>
#include <EGL/eglext.h>
#include <GLES3/gl3.h>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>
#include "atmosphere.h"
#include "autopilot.h"
#include "game.h"
#include "renderer.h"
#include "scene_builder.h"
using namespace sd;

static void savePPM(const char* path, int w, int h) {
    std::vector<unsigned char> px(static_cast<size_t>(w) * h * 4), out(static_cast<size_t>(w) * h * 3);
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    glReadPixels(0, 0, w, h, GL_RGBA, GL_UNSIGNED_BYTE, px.data());
    for (int y = 0; y < h; ++y) for (int x = 0; x < w; ++x) { const unsigned char* s = &px[((h - 1 - y) * w + x) * 4]; unsigned char* d = &out[(y * w + x) * 3]; d[0]=s[0]; d[1]=s[1]; d[2]=s[2]; }
    FILE* f = std::fopen(path, "wb"); std::fprintf(f, "P6\n%d %d\n255\n", w, h); std::fwrite(out.data(), 1, out.size(), f); std::fclose(f);
}

int main(int argc, char** argv) {
    if (argc < 7) { std::fprintf(stderr, "usage: see the top of render_shots.cpp\n"); return 1; }
    const std::string mode = argv[1];
    const int W = std::atoi(argv[2]), H = std::atoi(argv[3]);
    const char* dir = argv[4];
    const int seed = std::atoi(argv[5]);
    auto getPD = (PFNEGLGETPLATFORMDISPLAYEXTPROC)eglGetProcAddress("eglGetPlatformDisplayEXT");
    EGLDisplay dpy = getPD(EGL_PLATFORM_SURFACELESS_MESA, EGL_DEFAULT_DISPLAY, nullptr);
    EGLint maj, min; eglInitialize(dpy, &maj, &min); eglBindAPI(EGL_OPENGL_ES_API);
    const EGLint ca[] = {EGL_SURFACE_TYPE, EGL_PBUFFER_BIT, EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT, EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8, EGL_ALPHA_SIZE, 8, EGL_DEPTH_SIZE, 24, EGL_NONE};
    EGLConfig cfg; EGLint n; eglChooseConfig(dpy, ca, &cfg, 1, &n);
    const EGLint pa[] = {EGL_WIDTH, W, EGL_HEIGHT, H, EGL_NONE};
    EGLSurface surf = eglCreatePbufferSurface(dpy, cfg, pa);
    const EGLint xa[] = {EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE};
    EGLContext ctx = eglCreateContext(dpy, cfg, EGL_NO_CONTEXT, xa);
    eglMakeCurrent(dpy, surf, surf, ctx);
    Renderer r; r.onContextCreated(); r.onResize(W, H);
    r.setQualityTier(std::getenv("SD_TIER") ? std::atoi(std::getenv("SD_TIER")) : 3);

    Game game; game.setBaseSeed(static_cast<uint32_t>(seed)); game.startRun();
    const float dt = 1.0f / 60.0f;
    SceneGeometry geo; UiBatch ui; ui.setScreen((float)W, (float)H);
    float t = 0.0f;
    auto step = [&]() {
        SkaterInput in;
        if (game.phase() == Phase::Running) { in = game.autopilot().compute(game.world().track(), game.world().obstacles(), game.skater()); }
        game.update(dt, in); t += dt;
        if (game.phase() == Phase::GameOver) game.startRun();
    };
    auto shot = [&](const char* name, float blur) {
        FrameParams fp = buildScene(game, 1.0f, geo);
        fp.motionBlur = blur;
        r.render(fp, geo, ui);
        char path[256]; std::snprintf(path, sizeof(path), "%s/%s.ppm", dir, name); savePPM(path, W, H);
        std::fprintf(stderr, "wrote %s  t=%.1f s=%.0f speed=%.0f km/h\n", name, t, game.skater().s, game.speedKmh());
    };
    if (mode == "chute") {   // the first chute of the road, from the approach to the road afterwards
        const int want = argc > 6 ? std::atoi(argv[6]) : 0;   // which chute (0 = the first beyond 600 m)
        int zi = -1, seen = 0;
        for (int tries = 0; tries < 2000 && zi < 0; ++tries) {
            const auto& zones = game.world().track().shortcuts();
            for (size_t i = 0; i < zones.size(); ++i)
                if (zones[i].isChute() && zones[i].sBend0 > 500.0f && zones[i].sBend0 > game.skater().s + 150.0f) { if (seen++ == want) { zi = (int)i; break; } }
            if (zi >= 0) break;
            const bool run = game.phase() == Phase::Running;
            if (!run && game.phase() != Phase::Countdown) { game.startRun(); continue; }
            SkaterInput in; if (run) in = game.autopilot().compute(game.world().track(), game.world().obstacles(), game.skater());
            game.update(dt, in);
            if (game.skater().s > 5000.0f) break;
        }
        if (zi < 0) { std::fprintf(stderr, "no chute found\n"); return 2; }
        auto Zr = [&]() -> const ShortcutZone& { return game.world().track().shortcuts()[(size_t)zi]; };
        std::fprintf(stderr, "chute %d: sBend0 %.0f side %.0f\n", zi, Zr().sBend0, Zr().side);
        auto lane = [&](float u) { const auto& pl = game.world().chutePlan(zi); if (pl.laneU.empty()) return 0.0f; if (u <= pl.laneU.front()) return pl.laneB.front(); if (u >= pl.laneU.back()) return pl.laneB.back(); size_t i = 0; while (i + 2 < pl.laneU.size() && pl.laneU[i + 1] < u) ++i; return lerpf(pl.laneB[i], pl.laneB[i + 1], smoothstep(pl.laneU[i], pl.laneU[i + 1], u)); };
        const float marks[6] = {-60.0f, -22.0f, 8.0f, 45.0f, 78.0f, 200.0f};   // u along the chord (road s relative to the mouth before it, in it, and after)
        int next = 0;
        for (int i = 0; i < 60 * 200 && next < 6; ++i) {
            const Skater& sk = game.skater();
            const ShortcutZone& z = Zr();
            SkaterInput in = game.autopilot().compute(game.world().track(), game.world().obstacles(), sk);
            if (sk.inChute()) {
                const float u = sk.s - z.sBend0;
                float target = lane(u + clampf(sk.speed * 0.45f, 6.0f, 14.0f)); if (u > z.chord - 22.0f) target = 0.0f;
                in.steer = clampf(3.5f * (clampf(-0.30f * (sk.x - target), -0.4f, 0.4f) - sk.alpha), -1.0f, 1.0f); in.slide = false; in.tuck = false;
            } else if (sk.s > z.sBend0 - 46.0f && sk.s < z.sBend1) {
                float target = z.side * 4.4f; if (sk.s > z.sBend0 - 13.0f) target = z.side * 8.0f;
                const TrackSample f = game.world().track().at(sk.s);
                const float follow = f.curvature * sk.speed * (1.0f - cfg::kAutoFollow);
                const float wMax = std::max(0.2f, std::min(cfg::kYawRateMax, sk.gripNow() / std::max(sk.speed, 3.0f)));
                in.steer = clampf(follow / wMax + 3.0f * (clampf(-0.25f * (sk.x - target), -0.35f, 0.35f) - sk.alpha), -1.0f, 1.0f); in.slide = false;
            }
            game.update(dt, in); t += dt;
            if (game.phase() != Phase::Running) break;
            const float rel = sk.inChute() ? sk.s - z.sBend0 : (sk.s - z.sBend0);
            bool take = false;
            if (next < 2) take = !sk.inChute() && rel >= marks[next];
            else if (next < 5) take = sk.inChute() && rel >= marks[next];
            else take = !sk.inChute() && sk.s > z.sBend1 + 40.0f;
            if (take) { char nm[64]; std::snprintf(nm, sizeof(nm), "chute_%d", next); shot(nm, 0.4f); ++next; }
        }
        return 0;
    }
    if (mode == "speed") {
        const float kmh = (float)std::atof(argv[6]);
        for (int i = 0; i < 60 * 600 && !(game.phase() == Phase::Running && game.skater().s > 420.0f); ++i) step();
        for (int i = 0; i < 90; ++i) { const_cast<Skater&>(game.skater()).speed = kmh / 3.6f; step(); }   // (the harness holds the speed for the shot)
        for (int a = 7; a < argc; ++a) { char nm[64]; std::snprintf(nm, sizeof(nm), "blur_%03d", (int)std::lround(std::atof(argv[a]) * 100.0)); shot(nm, (float)std::atof(argv[a])); }
    } else if (mode == "at") {
        const float secs = (float)std::atof(argv[6]);
        while (t < secs) step();
        shot(argc > 7 ? argv[7] : "shot", 0.5f);
        if (std::getenv("SD_TIME")) {   // a rough cost of the frame: the software rasteriser stands in for a GPU (relative numbers only)
            FrameParams fp = buildScene(game, 1.0f, geo);
            glFinish();
            const auto t0 = std::chrono::steady_clock::now();
            for (int i = 0; i < 12; ++i) { r.render(fp, geo, ui); glFinish(); }
            const double ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count() / 12.0;
            std::fprintf(stderr, "render cost: %.1f ms per frame at %dx%d tier %s\n", ms, W, H, std::getenv("SD_TIER") ? std::getenv("SD_TIER") : "3");
        }
    }
    return 0;
}
