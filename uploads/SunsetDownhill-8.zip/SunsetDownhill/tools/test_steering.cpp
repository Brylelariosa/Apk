// test_steering.cpp - how well can a competent rider drive the bends? A feedback driver (it looks ahead at the road's curvature, holds
// the centre line and uses the Coleman slide when a bend needs more grip than the board has) takes every sharp bend of several roads:
//   A) at a fixed speed, to find the fastest speed each bend can be driven at without touching a rail (slide off / slide allowed)
//   B) arriving at a given speed on its own (the driver brakes with the slide before the bend), and counts the wipe-outs
// It is the yardstick for "can a player make a sharp turn without crashing unnecessarily"; run it against the old and the new physics.
#include <cmath>
#include <cstdio>
#include <vector>
#include "config.h"
#include "skater.h"
#include "track.h"

using namespace sd;

namespace {

#ifdef OLD_PHYS   // the original physics: no slide-specific yaw / follow constants
constexpr float kSlideYaw = 0.40f, kSlideFollow = 0.0f;
#else
constexpr float kSlideYaw = cfg::kSlideYawBoost, kSlideFollow = cfg::kSlideAutoFollow;
#endif

struct Bend { float s0 = 0, s1 = 0, k = 0; };

// stretches of the road whose curvature is at least kMin
std::vector<Bend> findBends(const Track& tr, float sMax, float kMin) {
    std::vector<Bend> out;
    bool in = false;
    Bend cur;
    for (float s = 220.0f; s < sMax; s += 2.0f) {
        const float k = std::fabs(tr.curvatureAt(s));
        if (!in && k >= kMin) { in = true; cur = Bend(); cur.s0 = s; }
        if (in) {
            cur.k = std::max(cur.k, k);
            if (k < kMin * 0.6f) { cur.s1 = s; in = false; if (cur.s1 - cur.s0 > 14.0f) out.push_back(cur); }
        }
    }
    return out;
}

struct Driver {
    bool slideOn = false;
    bool allowSlide = true;
    float steerPrev = 0.0f;

    SkaterInput step(const Track& tr, const Skater& sk) {
        SkaterInput in;
        const float v = std::max(sk.speed, 3.0f);
        const float look = clampf(v * 0.8f, 10.0f, 40.0f);
        float kMax = 0.0f, kHere = tr.curvatureAt(sk.s + 0.35f * look);
        for (float d = 0.0f; d <= look; d += 5.0f) kMax = std::max(kMax, std::fabs(tr.curvatureAt(sk.s + d)));
        // the grip the bend needs (with the board following the road on its own) against what the board has
        const float need = kMax * v * v * (1.0f - cfg::kAutoFollow);
        const float have = cfg::kGrip * 0.80f;
        if (allowSlide) {
            if (!slideOn && need > have) slideOn = true;
            else if (slideOn && need < have * 0.55f) slideOn = false;
        }
        in.slide = slideOn && sk.speed > 4.0f;
        const float wMax = std::max(0.2f, std::min(cfg::kYawRateMax * (1.0f + (in.slide ? kSlideYaw : 0.0f)), sk.gripNow() / v));
        const float follow = kHere * v * (1.0f - cfg::kAutoFollow - (in.slide ? kSlideFollow : 0.0f));
        const float aDes = clampf(-0.30f * sk.x, -0.35f, 0.35f);
        float steer = follow / wMax + 3.2f * (aDes - sk.alpha);
        steer = clampf(steer, -1.0f, 1.0f);
        in.steer = steer;
        in.push = sk.speed < 6.5f;   // a rider on a climb kicks along
        return in;
    }
};

struct Result { bool ok = true; float minGap = 99.0f; float apexSpeed = 0.0f; };

// A) the speed is held (a rider who brakes perfectly), the bend is driven
Result driveFixed(const Track& tr, const Bend& b, float speed, bool allowSlide) {
    Skater sk;
    sk.reset(b.s0 - 150.0f, speed);
    Driver d;
    d.allowSlide = allowSlide;
    Result r;
    const float dt = 1.0f / 120.0f;
    for (int i = 0; i < 120 * 40 && sk.s < b.s1 + 60.0f; ++i) {
        const SkaterInput in = d.step(tr, sk);
        sk.step(in, tr, dt);
        sk.speed = speed;   // held
        if (sk.crashed) { r.ok = false; break; }
        float lo, hi;
        tr.lateralWindow(sk.s, Track::kRoad, &lo, &hi);
        r.minGap = std::min(r.minGap, std::min(hi - sk.x, sk.x - lo));
        if (sk.s > b.s0 && sk.s < b.s1) r.apexSpeed = sk.speed;
    }
    return r;
}

// B) the rider arrives at speed v0 and brakes (slide) by itself where the bend needs it
Result driveFree(const Track& tr, const Bend& b, float v0) {
    Skater sk;
    sk.reset(b.s0 - 260.0f, v0);
    Driver d;
    Result r;
    const float dt = 1.0f / 120.0f;
    for (int i = 0; i < 120 * 60 && sk.s < b.s1 + 60.0f; ++i) {
        // look further ahead than the steering does: a rider brakes early for a bend
        Driver& dr = d;
        SkaterInput in = dr.step(tr, sk);
        in.push = sk.speed < 6.5f;
        float kFar = 0.0f;
        for (float dd = 0.0f; dd <= 110.0f; dd += 8.0f) kFar = std::max(kFar, std::fabs(tr.curvatureAt(sk.s + dd)));
        const float vSafe = std::sqrt(cfg::kGrip * 0.80f / std::max(1e-4f, kFar * (1.0f - cfg::kAutoFollow)));
        if (sk.speed > vSafe * 1.12f) { in.slide = true; d.slideOn = true; }
        sk.step(in, tr, dt);
        if (sk.crashed) { r.ok = false; break; }
        if (sk.s > b.s0 && sk.s < b.s1) r.apexSpeed = sk.speed;
    }
    return r;
}

}  // namespace

int main() {
    const float kMin = 1.0f / 95.0f;
    int bends = 0;
    double sumNo = 0, sumSl = 0;
    int okFree[5] = {0, 0, 0, 0, 0};
    const float v0s[5] = {16.0f, 22.0f, 28.0f, 33.0f, 38.0f};
    for (uint32_t seed = 1; seed <= 6; ++seed) {
        Track tr;
        tr.reset(seed);
        tr.ensureGenerated(4600.0f);
        const std::vector<Bend> list = findBends(tr, 4000.0f, kMin);
        for (const Bend& b : list) {
            // A) fastest speed that gets through (km/h), found by bisection on 8..45 m/s
            auto best = [&](bool slide) {
                float lo = 8.0f, hi = 45.0f;
                if (!driveFixed(tr, b, lo, slide).ok) return 0.0f;
                for (int i = 0; i < 9; ++i) {
                    const float mid = 0.5f * (lo + hi);
                    if (driveFixed(tr, b, mid, slide).ok) lo = mid; else hi = mid;
                }
                return lo * 3.6f;
            };
            const float vn = best(false), vs = best(true);
            sumNo += vn;
            sumSl += vs;
            for (int i = 0; i < 5; ++i) okFree[i] += driveFree(tr, b, v0s[i]).ok ? 1 : 0;
            ++bends;
        }
    }
    std::printf("bends analysed: %d (curvature >= 1/95 m)\n", bends);
    std::printf("A) fastest constant speed through a bend: no slide %.0f km/h on average, slide allowed %.0f km/h\n", sumNo / bends, sumSl / bends);
    std::printf("B) arriving at speed and braking by itself, bends driven without a wipe-out:\n");
    for (int i = 0; i < 5; ++i) std::printf("   %3.0f km/h : %d / %d\n", v0s[i] * 3.6f, okFree[i], bends);
    return 0;
}
