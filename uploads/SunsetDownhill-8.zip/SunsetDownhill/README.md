# Sunset Downhill

A 3D downhill longboard game for Android. Carve a winding mountain road at golden hour, tuck for speed,
slide into the corners, and dodge cones, boulders and traffic as the sun sinks toward dusk - alone, or racing
friends on the same Wi-Fi (**LAN multiplayer**).

Native C++ (OpenGL ES 3.0) engine with a very thin Kotlin shell. No assets: the world, the rider,
the HUD font and all audio are generated procedurally.

## Build the APK with your GitHub Action

1. Put `SunsetDownhill.zip` in the `uploads/` folder of your repository and push.
2. The *Build APK* workflow unzips it, finds `settings.gradle`, builds, and uploads
   `SunsetDownhill-debug-v<run>` (or `-release-` when the keystore secrets exist) as a workflow artifact.

The project is pinned to what that workflow provisions: Gradle 8.6, JDK 17, NDK 25.2.9519653,
CMake 3.22.1, AGP 8.2.2, Kotlin 1.9.22, `compileSdk`/`targetSdk` 34, `minSdk` 24 (needs OpenGL ES 3.0).
ABIs: `arm64-v8a`, `armeabi-v7a`, `x86_64`.

## Controls (landscape)

Choose how you steer in **CONTROLS** (a button on the main menu and on the pause screen). The choice and your
button layout are saved.

| Steering | How it works |
|---|---|
| **Stick** (default) | Drag on the **left half** of the screen. The first touch becomes the neutral point (floating stick). |
| **Arrows** | Two arrow buttons (bottom left). A tap nudges, holding turns harder; letting go straightens out. |
| **Tilt** | Turn the phone like a steering wheel. The straight-ahead position is taken from how you hold the phone during the 3-2-1 countdown (press **RECENTER** in CONTROLS to redo it); **TILT SENS** sets how far you must lean for full lock. A small gauge at the bottom shows what the tilt is doing. |
| **Arrows + Tilt** | Both at once. |

Tilt needs a gravity or accelerometer sensor; without one the tilt options are greyed out and the arrows are used.

These are the same in every scheme:

| Control | Action |
|---|---|
| Hold **TUCK** (bottom right) | Crouch: much less drag, higher top speed, but less grip. |
| Hold **SLIDE** (bottom right) | **Coleman slide**: the board kicks out sideways, the rider drops into a deep crouch with a hand on the road. The slide scrubs speed as the board comes round (a tap costs little, a committed slide costs a lot), gives more turning authority, and throws up tyre smoke + sparks. |
| **SLIDE + steer** left / right | Throws the slide out to that side, and further out the harder you steer (and a little less far at high speed). SLIDE alone slides to the side you last steered. |
| Hold **PUSH** (above TUCK and SLIDE) | **Kick-push**: the rider kicks along the road for as long as you hold it. This is how you keep rolling **uphill**. Only works below about 40 km/h; letting go finishes the kick in progress and puts the foot back on the deck; TUCK or SLIDE end it at once. It blinks "UPHILL - KICK!" when the road is climbing and the board is dying. |
| Pause button / Back | Pause; Back again returns to the menu. (With CONTROLS open, Back closes it first.) |

### Customising the buttons

In **CONTROLS**: drag any button to move it; the ringed one is selected, and **SIZE - / +** resizes it (60-160 %,
hold to repeat). **OPACITY** makes all buttons more see-through, **RESET** brings back the factory layout (keeping
your steering choice). Buttons stay on screen and below the HUD band, are kept from overlapping each other and from covering
the pause button. Changes are saved when you lift your finger.

Every run starts with a **kick-push**: the rider waits with a foot planted on the road, then kicks off four times
before settling onto the board. After two kicks, TUCK or SLIDE cuts the push short.

**The road rolls.** It is not one long descent: now and then it **climbs** for a hundred metres or so (1.3-3 degrees) and now and then it
drops **steeper**. On a climb the board bleeds speed fast - tuck to carry it as far as you can, and when it gets slow, hold **PUSH** to kick
your way up (you settle at about 25-30 km/h on a steep climb); without kicking the board stops and, if you do not push within a few
seconds, the rider bails. The first hill is never before 340 m, and hills keep well clear of the gorge detours.

Tips: tuck on straights, brake **before** a corner, and use the Coleman slide to rotate through it. Kick up the climbs.
Rubbing the guard rail scrapes speed off; grinding it for more than a second wipes you out.
Close calls and long Coleman slides score bonus points on top of distance.

## LAN multiplayer

Up to **6 riders** on the same Wi-Fi (or on a phone hotspot - the host phone can be the hotspot) ride the same road at the same time.

1. Everybody taps **MULTIPLAYER** on the main menu.
2. One phone taps **HOST A RACE**; the others tap **JOIN A RACE**. The host appears in the list within a second or two - tap it.
   The room shows who is in; every rider gets their own colour.
3. The host picks the race length with the **GOAL** button (1 / 2 / 3 / 5 km or endless) and taps **START RACE**. Everybody counts
   down together (the GO moment is synchronised across the phones) on the same road: the road, cones and rocks come from one shared
   seed (the cars are local to each phone). Riders do not collide with each other.
4. During the race you see the other riders (with name tag and distance ahead / behind) and a live standings list (metres to the
   finish line); the first across the line wins; the race can not be paused. **A crash does not send you back to the start**: after a short
   wipe-out you are put back on the road at the last **checkpoint gate** you passed (gates every 160 m, kept clear of the detours), rolling
   and blinking for a moment while nothing can hurt you, with the same cones and rocks every other phone sees. In a race to a finish line
   you can be wiped out as often as you like (the clock keeps running: that is the penalty); an endless race gives you 4 lives. **Once
   the first rider crosses the line the others have 45 seconds** (a banner counts them down) before the results come up. When your run ends
   you see everybody's results with finish times; tap for the lobby, where the host starts the next race.
   Leaving the room (Back, or **MENU**) never stops the others.

How it works: plain UDP (port 47825). The host advertises the room with a broadcast beacon; clients find it, join, and the host
relays every rider's state (30 times a second; protocol v3 adds a respawn counter and a ghost / chute flag). Every state carries the sender's
race time; the receivers play it back by that timestamp with a jitter-adaptive delay, so Wi-Fi jitter does not show as stutter, and a respawn
is shown as a jump, never as the rider gliding back along the road. The network clock runs on real time, not on the (clamped) frame time, and
the physics keeps up with real time down to 10 frames a second, so a slow phone neither falls behind the others nor rides in slow motion. The
state that goes out is stamped with the frame it describes, the socket is marked as low-delay traffic and has room for a burst. Clients measure the host's clock with a ping, and
START carries the host's clock, so the countdown ends at the same moment on every phone. All of it is polled from the game thread - no extra
threads. The Kotlin side takes a multicast lock (many phones drop broadcast packets without one) and a Wi-Fi low-latency lock (Wi-Fi power
saving otherwise delays packets by 100-200 ms), binds the process to the Wi-Fi
network (so it keeps working when Android prefers mobile data because the Wi-Fi has no internet) and supplies the device name.
Permissions: `INTERNET`, `ACCESS_NETWORK_STATE`, `ACCESS_WIFI_STATE`, `CHANGE_WIFI_MULTICAST_STATE`, `WAKE_LOCK` (all granted at install).

If nothing is found: both phones must be on the **same** Wi-Fi (guest networks and some routers isolate clients from each other - use a
phone hotspot then), and VPNs should be off.

## Gorge jumps

Every kilometre or so the road makes a **U-shaped detour round a gorge**: a sharp bend away from the straight, a leg going down the rim,
a hairpin round the head of the gorge, a leg back up the other rim and a sharp bend back onto the original line. It is the only road
there is - but where the detour starts there is a wooden **kicker** at the cliff edge, announced by two yellow signs. Hit it at the
edge of the road and you fly straight **across the mouth of the gorge** (about 60 m) to the road beyond it, skipping the whole detour
(a good 20 seconds), for +500 points. Everybody else rides the detour: sharp bends (about 12-14 m radius), a gentle downhill and a drop
of a few metres beside the road.

**The jump depends on your speed.** The kicker throws you up in proportion to how fast you hit it, and from then on it is an ordinary
arc: gravity pulls you down (a floaty gravity, `kGapGravity`), your speed carries you on, and a little air drag trims the very fast ones.
So the faster you are, the **higher and the further** you go (about 2 m above the lip at 65 km/h, nearly 5 m at 90 km/h and more, where
the kicker gives no more; at 100 km/h you come down well along the straight runway behind the detour), and the slower you are, the lower
you fly. **Slower than about 60 km/h you fall short of the road beyond the gorge** (into it, or onto the slope on the other side) and the
rider crashes; at 58 km/h you make it about one time in three, from 61 km/h every time (hold SLIDE and 50 km/h is enough). Creeping over
the lip slower than 25 km/h is only a hop, and the road takes you as usual.

**You steer the flight.** Steering turns the board and the flight drifts with it, **TUCK** dives (more gravity: you are down sooner, so
a dive at a speed that only just clears the gorge falls short) and **SLIDE** floats (less gravity: it saves a jump that is a little
short). Let go and you come down on the line; steer a little and you pick where on the road you land; hold full lock and you sail off the
road into the gorge (or the slope on the other side), and so does a landing more crooked than about 50 degrees. Every phone in a LAN race
draws the same flight from the rider's distance, offset, heading and height (`Track::gapFlightAt`), and the camera follows it. The
autopilot / menu demo never takes the kicker (and lets go of the controls if it ever ends up in the air). Zones are generated from the
seed, so a LAN race has the same ones everywhere.

## Chutes: off-road shortcuts without a ramp

Every other detour (they alternate with the gorge detours, about one every two kilometres) is a **chute detour**: a wider U (bends and
hairpin of 22-27 m radius) on a gentle 2 degree slope with a **grassy slope straight across its mouth** - 95-115 m of it, against 280 m of
road. Nothing forces you into it. The road goes round as usual; where the guard rail is open on the outside of the first bend (two green
**SHORTCUT** signs before it, orange flags at the ends of the opening) you leave the road to the side and are on the chute: the same controls
(the Coleman slide too), a steady 6-8 degree slope, a little more drag on the grass, a trail worn along the safe line, and **trees, boulders and
bushes** to steer between. A tree or a boulder is a wipe-out, a bush only slows you down, and so does a graze along the forest edge that
walls the corridor in (a scrape; a hard hit is a wipe-out). At the far end the corridor narrows to the road's width and you steer back onto
the road (+250 points); a rider who is too far out is turned in by the funnel. The obstacles come in rows 8-14 m apart with a **free line**
through them (4.5 m wide, never moving more than 1.5 m sideways from one row to the next), so there is always a way through at any speed.
Everything is a pure function of the seed; another phone draws a rider in a chute from `s = sBend0 + u`, `x = b` and a flag in its state.

Technically a chute is a `ShortcutZone` of `kind` 1: the same U detour as a gorge (`Track::planGorge(chute)`), no kicker. Its ground is a plane
sloping along the chord (`ShortcutZone::groundY`, eased into the road's slope at both ends and straight in between, so the terrain mesh, made
of big triangles out there, reproduces it to a centimetre); the bowl is shaped in world space in `Track::ringVertex`, so every strip of road
that reaches it agrees. `Skater::stepChute` is the ground physics in the chord's frame, `Skater::tryEnterChute` the change of frame (it moves
nothing: `test_chute` takes a step of no time and compares), `Track::roadNear` finds the road again at the merge.

## Graphics settings

**GRAPHICS** (a button on the main menu and on the pause screen) opens the graphics options. For now: **MOTION BLUR**, a 0-100 % slider (with
OFF / 25 / 50 / 90 / 100 % chips and - / + steppers; the scene behind shows the effect as you move it). 0 % turns the effect off completely
(its pass is skipped in the shader: the lightest setting on a slow phone), the default is 50 %. The blur only smears the left and right edges
of the picture - an ellipse around the road and what is coming stays sharp, so obstacles can be read in time - and its cost does not depend on
the setting (the tap count comes from the quality tier). The value is saved with the controls layout (`mb=` in the same text; the Kotlin
shell stores it as it is) and eased in by the engine, so moving the slider fades the effect instead of switching it.

**A sharper picture.** The quality tiers keep the resolution up (72 / 84 / 100 / 100 % + 4x MSAA, was 60 / 75 / 90 / 100 %); a scene drawn
below the display's resolution is enlarged with a Catmull-Rom filter (five fetches) and sharpened, FXAA only touches real edges, the
haze is thinner, the sky is drawn last (so it is only shaded where nothing else covers the pixel), and the ground takes its noise from a baked,
mip-mapped texture instead of 8 value-noise evaluations per pixel (the cost of a frame on a slow GPU) - which also pays for the meadow:
blades, clumps and a wind that rolls over it, plus instanced tufts of tall grass along the verge that sway in the wind.

## The traffic

Cars are five body styles (sedan, hatchback, SUV, pickup, van) driven by `traffic.cpp`, and they are **predictable** drivers: they keep
their lane and a safe following distance (they follow slower cars, they never overtake), slow for curves, brake in time (brake lights)
and never drive into rocks or each other. A car leaves its half of the road for one reason only - a boulder that blocks it - and then it
signals first, checks the mirror and the oncoming lane, and goes around it or waits for a gap. Traffic cones are light plastic: cars drive
through them and knock them over, like the rider does. They do not dodge the rider either (keeping clear of cars is the rider's job), but
they never pull out in front of a rider who is alongside or right behind.
`tools/test_traffic` lets thousands of cars loose on many seeds (also with a rider weaving across both lanes) and fails on any overlap
and on any car that swerves for something other than a boulder.

## Architecture

```
app/src/main/java/.../game/      Kotlin shell (6 small files)
    GameActivity                 immersive landscape window, lifecycle, persistence of best score / sound / controls
    GameSurfaceView              GLSurfaceView (ES 3.0) + multi-touch forwarding
    AudioEngine                  AudioTrack feeder thread
    TiltSensor                   gravity sensor -> screen axes (all tilt maths is native)
    NativeBridge                 the entire JNI surface
    LanSupport                   multicast lock, Wi-Fi binding and the device name for LAN races (the sockets are native)
app/src/main/cpp/
    jni_bridge.cpp               JNI <-> Engine
    core/                        platform independent engine (flat folder, namespace sd)
        math3d.h rng.h color.h config.h log.h      foundations; config.h holds every tunable
        track.*      procedural road: curvature/pitch/banking, terrain profile, detour zones (gorges with a kicker, chutes with a ground shortcut), checkpoint gates
        hills.*      the rolling profile: climbs and steeper descents placed in blocks along the road (a pure function of the seed)
        world.*      obstacles + traffic cars, chunked scenery, terrain mesh window (cones / rocks are a pure function of the seed)
        traffic.*    the drivers: perception, lane planning, gap acceptance, IDM speed control, indicators
        car_models.* five lofted car bodies with wheels and lamps;  model_kit.*  lofts, tubes and ellipsoids
        net.*        LAN sessions: lobby discovery, join, roster, clock sync, shared start, rider state relay, timestamped playback (UDP, polled)
        rider_net.h  what one rider tells the others
        skater.*     physics in road space (grip limit, tuck, slide, kick-push sessions, climbing, rail scrape, stall bail-out, kicker hops, the ballistic steerable flight over a gorge)
        autopilot.*  menu demo driver and test bot
        game.*       state machine (menu/countdown/run/crash/results/pause), scoring, effects
        camera.* atmosphere.* particles.* mesh_data.* mesh_library.*
        skater_model.*    the rider (helmet, sunglasses, T-shirt, shorts, pads, gloves, shoes; built from cached parts, two levels of detail) and the shaped longboard with wheels that turn; six matched colour styles
        scene_builder.*   game state -> renderer input (the only bridge between the two halves)
        renderer.* gl_util.* shaders.*   GLES3: sun shadow map, scene FBO, post FX, UI pass
        ui_batch.* ui_atlas.h ui_font.* ui_layout.* ui_widgets.* hud.*   in-engine UI: drawing, geometry, shared buttons, HUD
        hud_mp.*          the LAN screens: lobby (choose / search / room), standings, name tags, results
        controls.*        everything the player steers with, behind one interface (all GL free, tested on a desktop):
            controls_config.*   steering scheme + button layout + the text format it is saved in
            input.*             multi-touch: floating stick, arrow buttons, TUCK / SLIDE / PUSH, UI taps
            tilt.*              phone tilt -> steering (smoothing, neutral, dead zone, sensitivity)
            controls_editor.*   the CONTROLS screen: scheme, drag / resize buttons, opacity, tilt settings
        audio_synth.*     procedural wheels / seams / wind / Coleman slide / kick-push / crash / beeps
        graphics_settings.* graphics_panel.*   the GRAPHICS options (motion blur) and their screen
        engine.*          the one object the shell talks to (+ adaptive quality governor)
tools/                            optional desktop simulators and a headless renderer (see tools/README.md)
```

The HUD text is a stroke font rendered from a **signed-distance atlas generated at start-up** (`ui_font.cpp`): one quad per glyph,
so translucent text never shows overlapping strokes, fades evenly and stays crisp at any size; a soft dark halo keeps it
readable on bright sky. Plain shapes sample a solid block of the same atlas, so the whole HUD is one vertex format and one draw call.

Rendering highlights: procedural sky with sun, clouds and mountain ranges; road with wear, markings and
a sun sheen; instanced pines/autumn trees/rocks/rails (a few draw calls); a 1024px sun shadow map; scene
rendered to an offscreen target (up to the full display resolution with 4x MSAA on the top preset, FXAA / sharpen on the others)
with radial speed blur, glare, vignette and grading.
Quality adapts automatically: the engine measures frame time and steps between four presets
(render scale 72 / 84 / 100 / 100 %, shadow size, tree density, blur taps, MSAA).

## Tuning

Open `app/src/main/cpp/core/config.h`: gravity scale, drag, grip, steering response, tuck/slide effects,
road width, countdown length, difficulty ramp, kick-push (`kPush*`), Coleman slide (`kCole*`, `kSlide*`), the rail (`kRail*`), the rolling hills (`kHill*`,
`kUphill*`, `kSteep*`), the gorge and its jump (`kGorge*`, `kGap*`, `kKickerHeight`), the chutes (`kChute*`) and checkpoints / respawns (`kCheckpoint*`, `kRespawn*`).
`tools/sim_game` shows the effect on difficulty without a phone.

Controls: `TiltSteer::kFullLockDeg` (tilt.h) is the lean for full steering at 100 % sensitivity, and `kArrowRise` /
`kArrowFall` (input.cpp) set how quickly the arrow buttons turn in and out. `tools/test_steering` measures how fast a feedback driver can take
the bends of several roads (about 64 -> 94 km/h without a slide and 73 -> 149 km/h with one, compared with the previous physics). Factory button positions are in
`controls_config.cpp`.

**Volume:** `AudioSynth::kMasterVolume` in `app/src/main/cpp/core/audio_synth.h` is the one knob for all game sound
(0.5 by default; lower = quieter). `tools/audio_dump` prints the level of every sound in dBFS.

**Sound design rule:** the wheel and slide sounds are broadband noise only. Nothing in them may repeat at a rate that
follows the speed (the wheels used to be modulated once per turn): that is heard as a "flapping" when slow and as an
engine changing gear when the speed changes. `tools/test_audio` fails if such a tone comes back.
