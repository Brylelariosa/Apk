cmake_minimum_required(VERSION 3.22.1)
project(sunset_downhill LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)
set(CMAKE_POSITION_INDEPENDENT_CODE ON)

# Gradle debug builds would otherwise compile with -O0, which is far too slow for a real-time 3D game.
set(CMAKE_CXX_FLAGS_DEBUG "-O2 -g0")

# All engine code lives flat in core/ (platform independent); jni_bridge.cpp is the only JNI file.
file(GLOB CORE_SOURCES CONFIGURE_DEPENDS "${CMAKE_CURRENT_SOURCE_DIR}/core/*.cpp")

add_library(sunset_downhill SHARED jni_bridge.cpp ${CORE_SOURCES})

target_include_directories(sunset_downhill PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}")
target_compile_options(sunset_downhill PRIVATE -Wall -Wextra -Wno-unused-parameter -fvisibility=hidden)

if(ANDROID)
    target_link_libraries(sunset_downhill GLESv3 log)
else()
    # Desktop build (tests / tooling): Mesa EGL + GLES.
    target_link_libraries(sunset_downhill EGL GLESv2)
endif()
