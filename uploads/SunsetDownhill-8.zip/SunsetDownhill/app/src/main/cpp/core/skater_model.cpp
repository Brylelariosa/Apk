#include "skater_model.h"

#include <algorithm>
#include <cmath>
#include <memory>

#include "config.h"
#include "model_kit.h"

namespace sd {
namespace {

// One palette per rider: a T-shirt, shorts in a deeper tone that sits well with it, and trim / helmet / wheels that pick the colours up again.
//                      jacket (T-shirt)                  highlight                         sleeve hem / collar               accent
const RiderStyle kStyles[kRiderStyleCount] = {
    // 0: sunset - coral T-shirt, deep indigo shorts, cream trim and helmet, butterscotch wheels
    {rgba(0.93f, 0.43f, 0.26f), rgba(1.00f, 0.63f, 0.40f), rgba(0.99f, 0.91f, 0.76f), rgba(0.99f, 0.91f, 0.76f), rgba(0.17f, 0.18f, 0.33f),
     rgba(0.97f, 0.93f, 0.86f), rgba(0.93f, 0.40f, 0.22f), rgba(1.00f, 0.76f, 0.22f), rgba(0.97f, 0.96f, 0.92f), rgba(0.80f, 0.58f, 0.43f), rgba(0.16f, 0.10f, 0.07f)},
    // 1: red racer - red T-shirt, charcoal shorts, white trim, white wheels with red cores
    {rgba(0.82f, 0.14f, 0.17f), rgba(0.97f, 0.31f, 0.27f), rgba(0.97f, 0.97f, 0.97f), rgba(0.97f, 0.97f, 0.97f), rgba(0.16f, 0.17f, 0.21f),
     rgba(0.96f, 0.96f, 0.96f), rgba(0.90f, 0.14f, 0.13f), rgba(0.96f, 0.96f, 0.94f), rgba(0.84f, 0.14f, 0.13f), rgba(0.93f, 0.74f, 0.62f), rgba(0.55f, 0.38f, 0.17f)},
    // 2: teal - teal T-shirt, navy shorts, yellow trim, lime wheels
    {rgba(0.09f, 0.57f, 0.60f), rgba(0.27f, 0.82f, 0.78f), rgba(1.00f, 0.86f, 0.24f), rgba(1.00f, 0.86f, 0.24f), rgba(0.10f, 0.15f, 0.26f),
     rgba(0.94f, 0.97f, 0.97f), rgba(0.10f, 0.62f, 0.64f), rgba(0.84f, 0.95f, 0.30f), rgba(0.10f, 0.11f, 0.12f), rgba(0.52f, 0.34f, 0.24f), rgba(0.07f, 0.06f, 0.06f)},
    // 3: purple - violet T-shirt, indigo shorts, pink trim and wheels
    {rgba(0.52f, 0.30f, 0.80f), rgba(0.73f, 0.53f, 0.96f), rgba(1.00f, 0.52f, 0.82f), rgba(1.00f, 0.52f, 0.82f), rgba(0.15f, 0.13f, 0.28f),
     rgba(0.82f, 0.77f, 0.97f), rgba(0.55f, 0.25f, 0.80f), rgba(0.97f, 0.50f, 0.82f), rgba(0.96f, 0.94f, 0.96f), rgba(0.74f, 0.55f, 0.38f), rgba(0.38f, 0.14f, 0.08f)},
    // 4: lime - lime T-shirt, dark olive shorts, black trim, yellow wheels
    {rgba(0.50f, 0.70f, 0.16f), rgba(0.77f, 0.93f, 0.31f), rgba(0.12f, 0.12f, 0.11f), rgba(0.12f, 0.12f, 0.11f), rgba(0.17f, 0.21f, 0.12f),
     rgba(0.98f, 0.92f, 0.30f), rgba(0.62f, 0.85f, 0.18f), rgba(0.99f, 0.92f, 0.30f), rgba(0.12f, 0.12f, 0.10f), rgba(0.86f, 0.66f, 0.50f), rgba(0.45f, 0.32f, 0.14f)},
    // 5: pink and white - white T-shirt, deep rose shorts, hot pink trim and wheels
    {rgba(0.93f, 0.93f, 0.96f), rgba(1.00f, 1.00f, 1.00f), rgba(1.00f, 0.30f, 0.62f), rgba(1.00f, 0.30f, 0.62f), rgba(0.58f, 0.17f, 0.38f),
     rgba(1.00f, 0.62f, 0.78f), rgba(1.00f, 0.62f, 0.78f), rgba(1.00f, 0.40f, 0.68f), rgba(0.97f, 0.96f, 0.97f), rgba(0.38f, 0.24f, 0.17f), rgba(0.07f, 0.06f, 0.06f)},
};

// Gloss lives in the vertex alpha (255 = matte); the mesh shader turns it into a sun highlight and a hint of sky.
Rgba8 glossy(Rgba8 c, float g) {
    c.a = to8(1.0f - g);
    return c;
}

const Rgba8 kShoe = rgba(0.94f, 0.94f, 0.96f), kSole = rgba(0.86f, 0.80f, 0.66f), kLace = rgba(0.10f, 0.10f, 0.12f);
const Rgba8 kGlove = rgba(0.10f, 0.10f, 0.12f), kPad = rgba(0.11f, 0.11f, 0.13f), kSock = rgba(0.95f, 0.95f, 0.96f);
const Rgba8 kLensLo = rgba(0.05f, 0.04f, 0.05f), kLensHi = rgba(0.34f, 0.20f, 0.12f), kFrame = rgba(0.07f, 0.07f, 0.08f);
const Rgba8 kGrip = rgba(0.105f, 0.105f, 0.115f), kTruck = glossy(rgba(0.78f, 0.80f, 0.84f), 0.80f);

Rgba8 shade(Rgba8 c, float k) {
    return {static_cast<uint8_t>(std::min(255.0f, c.r * k)), static_cast<uint8_t>(std::min(255.0f, c.g * k)), static_cast<uint8_t>(std::min(255.0f, c.b * k)), c.a};
}

// A basis for an appended part must be a proper rotation (right-handed), or the triangles would face inwards: flip x if it is not.
Mat4 properFrame(Vec3 x, const Vec3& y, const Vec3& z, const Vec3& pos) {
    if (dot(cross(x, y), z) < 0.0f) x = -x;
    return Mat4::fromBasis(x, y, z, pos);
}

constexpr float kThigh = 0.405f, kShin = 0.405f;     // leg bones (hip to knee, knee to ankle)
constexpr float kUpperArm = 0.285f, kForeArm = 0.268f;   // arm bones (shoulder to elbow, elbow to wrist)

Vec3 solveJoint(const Vec3& root, const Vec3& target, float l1, float l2, const Vec3& pole, Vec3& endOut) {
    const Vec3 d = target - root;
    float dist = length(d);
    const float maxD = (l1 + l2) * 0.998f, minD = std::fabs(l1 - l2) * 1.002f + 0.01f;
    dist = clampf(dist, minD, maxD);
    const Vec3 dir = dist > 1e-5f ? normalize(d) : Vec3(0.0f, -1.0f, 0.0f);
    endOut = root + dir * dist;
    const float a = (l1 * l1 - l2 * l2 + dist * dist) / (2.0f * dist);
    const float h = std::sqrt(std::max(0.0f, l1 * l1 - a * a));
    Vec3 pv = pole - dir * dot(pole, dir);
    if (dot(pv, pv) < 1e-6f) pv = Vec3(0.0f, 0.0f, 1.0f) - dir * dot(Vec3(0.0f, 0.0f, 1.0f), dir);
    return root + dir * a + normalize(pv) * h;
}

// ---- the longboard (a rigid mesh built once per style and re-posed with a matrix) --------------------------------------
constexpr float kDeckY = 0.116f;        // height of the deck's mid-plane above the road
constexpr float kDeckHalfT = 0.013f;    // half the deck thickness
constexpr float kWheelR = 0.058f;       // wheel radius = axle height
constexpr float kWheelHalfW = 0.029f;   // half the wheel width
constexpr float kWheelX = 0.156f;       // wheel centre across the board
constexpr float kTruckZ = 0.31f;        // truck position along the deck

float deckHalfWidth(float z) {
    static const float zs[] = {-0.56f, -0.52f, -0.44f, -0.34f, -0.18f, 0.0f, 0.18f, 0.34f, 0.44f, 0.52f, 0.56f};
    static const float ws[] = {0.040f, 0.075f, 0.112f, 0.128f, 0.133f, 0.134f, 0.133f, 0.128f, 0.112f, 0.075f, 0.040f};
    const float az = std::fabs(z);
    for (int i = 5; i < 10; ++i) {
        if (az <= zs[i + 1]) return lerpf(ws[i], ws[i + 1], (az - zs[i]) / (zs[i + 1] - zs[i]));
    }
    return ws[10];
}

float deckKick(float z) {
    const float k = saturate((std::fabs(z) - 0.30f) / 0.26f);
    return 0.064f * k * k;
}

// how far the rails rise above the middle of the deck (the concave), fading out toward the nose and tail
float deckConcave(float z) { return 0.011f * (1.0f - smoothstep(0.30f, 0.50f, std::fabs(z))); }

// top of the grip tape at (x, z) in board space
float deckTopY(float x, float z) {
    const float w = std::max(0.02f, deckHalfWidth(z));
    const float u = std::min(1.0f, std::fabs(x) / w);
    return kDeckY + deckKick(z) + kDeckHalfT + deckConcave(z) * u * u;
}

// Cross section of the deck at z: a rounded slab with extra points along the top and bottom so that the concave can bend it.
kit::Ring deckRing(float z, int inner) {
    const float w = std::max(0.03f, deckHalfWidth(z));
    const float yMid = kDeckY + deckKick(z);
    const kit::Ring base = kit::roundedSection(z, yMid - kDeckHalfT, yMid + kDeckHalfT, w, w, 0.011f, 0.011f, 2);   // 12 points
    const int kInner = inner;
    kit::Ring ring;
    for (size_t i = 0; i < base.size(); ++i) {
        ring.push_back(base[i]);
        if (i == 5 || i == 11) {   // end of the top arc / end of the bottom arc: fill the flat face
            const float xa = base[i].x, xb = base[(i + 1) % base.size()].x;
            for (int k = 1; k <= kInner; ++k) ring.push_back(Vec3(lerpf(xa, xb, static_cast<float>(k) / static_cast<float>(kInner + 1)), base[i].y, z));
        }
    }
    const float conc = deckConcave(z);
    for (Vec3& p : ring) {
        const float u = std::min(1.0f, std::fabs(p.x) / w);
        p.y += conc * u * u;
    }
    return ring;
}

// A thin coloured ribbon lying on the grip tape. A lateral position is frac * halfWidth(z) + off, so a ribbon can follow the outline
// (tip bands) or keep a fixed offset (stripes).
struct Lat { float frac, off; };
void addDeckRibbon(MeshData& m, Lat a, Lat b, float z0, float z1, int nz, int nx, Rgba8 c, Material mat) {
    std::vector<uint16_t> ids;
    for (int i = 0; i <= nz; ++i) {
        const float z = lerpf(z0, z1, static_cast<float>(i) / static_cast<float>(nz));
        const float w = deckHalfWidth(z);
        for (int j = 0; j <= nx; ++j) {
            const float x = lerpf(a.frac * w + a.off, b.frac * w + b.off, static_cast<float>(j) / static_cast<float>(nx));
            const float e = 0.004f;
            const float dydx = (deckTopY(x + e, z) - deckTopY(x - e, z)) / (2.0f * e);
            const float dydz = (deckTopY(x, z + e) - deckTopY(x, z - e)) / (2.0f * e);
            ids.push_back(m.addVertex(Vec3(x, deckTopY(x, z) + 0.0009f, z), normalize(Vec3(-dydx, 1.0f, -dydz)), c, mat));
        }
    }
    const size_t row = static_cast<size_t>(nx) + 1;
    for (int i = 0; i < nz; ++i)
        for (int j = 0; j < nx; ++j) {
            const size_t k = static_cast<size_t>(i) * row + static_cast<size_t>(j);
            m.addQuad(ids[k], ids[k + 1], ids[k + row + 1], ids[k + row]);
        }
}

// Urethane wheel in its own frame: the axle is local +Y (pointing away from the board), the outer face has five spokes so that a turning
// wheel looks like one. Rounded shoulders, a slightly crowned tread, a dark bearing seat, a bright core with an axle recess and a steel nut.
MeshData makeWheel(const RiderStyle& st, bool low) {
    using P = kit::LathePoint;
    MeshData m;
    const float R = kWheelR, hw = kWheelHalfW, rs = 0.011f, c45 = 0.70710678f;
    const Rgba8 tire = glossy(st.wheel, 0.30f), shoulder = glossy(shade(st.wheel, 0.84f), 0.22f);
    const Rgba8 seat = rgba(0.06f, 0.06f, 0.07f);
    const Rgba8 core = glossy(st.hub, 0.45f), coreLo = glossy(shade(st.hub, 0.70f), 0.35f), hole = rgba(0.03f, 0.03f, 0.04f);
    const Rgba8 steel = glossy(rgba(0.80f, 0.82f, 0.86f), 0.85f);
    const Material none{};
    std::vector<P> tireProfile;
    if (low) {
        tireProfile = {{0.031f, -hw, seat, none, true}, {R - 0.008f, -hw, shoulder, none, false}, {R, -hw + 0.012f, tire, none, false},
                       {R, hw - 0.012f, tire, none, false}, {R - 0.008f, hw, shoulder, none, false}, {0.031f, hw, seat, none, true}};
    } else {
        tireProfile = {{0.031f, -hw, seat, none, true}, {R - rs, -hw, shoulder, none, false}, {R - rs + rs * c45, -hw + rs - rs * c45, shoulder, none, false},
                       {R, -hw + rs, tire, none, false}, {R + 0.0006f, 0.0f, tire, none, false}, {R, hw - rs, tire, none, false},
                       {R - rs + rs * c45, hw - rs + rs * c45, shoulder, none, false}, {R - rs, hw, shoulder, none, false}, {0.031f, hw, seat, none, true}};
    }
    const std::vector<P> hubFace = {   // outer face of the core, from the tyre in to the axle recess
        {0.0300f, hw, coreLo, none, false}, {0.0285f, 0.0250f, core, none, true}, {0.0125f, 0.0250f, core, none, true}, {0.0112f, 0.0200f, hole, none, true}, {0.0000f, 0.0200f, hole, none, false},
    };
    const std::vector<P> hubFaceLow = {{0.030f, hw, coreLo, none, false}, {0.0285f, 0.0250f, core, none, true}, {0.0f, 0.0250f, core, none, false}};
    const std::vector<P> nut = {{0.0f, 0.0200f, steel, none, false}, {0.0090f, 0.0200f, steel, none, true}, {0.0090f, 0.0290f, steel, none, true}, {0.0f, 0.0290f, steel, none, false}};
    kit::addLathe(m, Mat4::identity(), tireProfile, low ? 10 : 18);
    kit::addLathe(m, Mat4::identity(), low ? hubFaceLow : hubFace, low ? 8 : 14);
    if (!low) {
        kit::addLathe(m, Mat4::identity(), nut, 6);
        const Rgba8 spoke = glossy(shade(st.hub, 0.55f), 0.30f);
        for (int i = 0; i < 5; ++i) {
            const float a = kTwoPi * static_cast<float>(i) / 5.0f;
            const Vec3 radial(std::cos(a), 0.0f, std::sin(a)), tangent(-std::sin(a), 0.0f, std::cos(a));
            m.addBox(Mat4::fromBasis(radial, Vec3(0.0f, 1.0f, 0.0f), tangent, radial * 0.0205f + Vec3(0.0f, 0.0268f, 0.0f)), Vec3(0.0072f, 0.0022f, 0.0046f), spoke, spoke);
        }
    }
    return m;
}

// The frame of a wheel on the board: the axle runs across the board, outward on `side` (+1 right, -1 left), turned by `spin` about it.
Mat4 wheelFrame(const Vec3& centre, float side, float spin) {
    const float a = -side * spin;   // (rolling forward turns the two sides' wheels opposite ways about their own outward axles)
    const float c = std::cos(a), s = std::sin(a);
    const Vec3 xw(0.0f, 1.0f, 0.0f), zw(0.0f, 0.0f, -side);
    return Mat4::fromBasis(xw * c + zw * s, Vec3(side, 0.0f, 0.0f), zw * c - xw * s, centre);
}

void addWheel(MeshData& m, const Vec3& centre, float side, const RiderStyle& st, bool low) {
    m.append(makeWheel(st, low), wheelFrame(centre, side, 0.0f));
}

// Reverse-kingpin truck: riser pad, black baseplate, polished hanger, two coloured bushings and the axle (far away: a hanger and two blocks).
void addTruck(MeshData& m, float z, const RiderStyle& st, bool low) {
    using P = kit::LathePoint;
    const Rgba8 plate = glossy(rgba(0.13f, 0.13f, 0.15f), 0.55f), pad = rgba(0.05f, 0.05f, 0.06f), rubber = glossy(st.accent, 0.30f);
    m.addBox(Mat4::translation(Vec3(0.0f, 0.0975f, z)), Vec3(0.054f, 0.0055f, 0.072f), pad, pad);   // riser pad up to the deck
    if (low) {
        m.addBox(Mat4::translation(Vec3(0.0f, 0.087f, z)), Vec3(0.046f, 0.0048f, 0.060f), plate, plate);                       // baseplate
        static const float xs[] = {-0.118f, -0.060f, 0.0f, 0.060f, 0.118f};
        static const float hh[] = {0.0085f, 0.0145f, 0.0200f, 0.0145f, 0.0085f};
        static const float hz[] = {0.0120f, 0.0230f, 0.0320f, 0.0230f, 0.0120f};
        static const float yc[] = {0.0520f, 0.0555f, 0.0620f, 0.0555f, 0.0520f};
        std::vector<kit::Ring> rings;
        for (int i = 0; i < 5; ++i) rings.push_back(kit::roundedSection(xs[i], yc[i] - hh[i], yc[i] + hh[i], hz[i], hz[i], 0.006f, 0.006f, 1));
        const Mat4 xf = Mat4::fromBasis(Vec3(0.0f, 0.0f, 1.0f), Vec3(0.0f, 1.0f, 0.0f), Vec3(1.0f, 0.0f, 0.0f), Vec3(0.0f, 0.0f, z));
        kit::addLoft(m, xf, rings, [&](const Vec3&, const Vec3& n, Material&) -> Rgba8 { return mix(shade(kTruck, 0.60f), kTruck, saturate(n.y * 0.5f + 0.5f)); }, Material{});
        for (int k = -1; k <= 1; k += 2) m.addBox(Mat4::translation(Vec3(0.0f, 0.0630f, z + 0.040f * static_cast<float>(k))), Vec3(0.019f, 0.0070f, 0.0075f), rubber, rubber);   // bushings
        return;
    }
    {   // baseplate
        static const float zs[] = {-0.066f, -0.052f, 0.052f, 0.066f}, ws[] = {0.040f, 0.050f, 0.050f, 0.040f};
        std::vector<kit::Ring> rings;
        for (int i = 0; i < 4; ++i) rings.push_back(kit::roundedSection(zs[i], 0.0825f, 0.0920f, ws[i], ws[i], 0.004f, 0.004f, 2));
        kit::addLoft(m, Mat4::translation(Vec3(0.0f, 0.0f, z)), rings, [&](const Vec3&, const Vec3& n, Material&) -> Rgba8 {
            return mix(shade(plate, 0.8f), plate, saturate(n.y * 0.5f + 0.5f));
        }, Material{});
    }
    {   // hanger: a bar that is tall and wide in the middle and tapers to the axle ends (loft along the board's x axis)
        static const float xs[] = {-0.118f, -0.095f, -0.060f, -0.025f, 0.0f, 0.025f, 0.060f, 0.095f, 0.118f};
        static const float hh[] = {0.0085f, 0.0110f, 0.0160f, 0.0195f, 0.0200f, 0.0195f, 0.0160f, 0.0110f, 0.0085f};
        static const float hz[] = {0.0120f, 0.0170f, 0.0250f, 0.0310f, 0.0320f, 0.0310f, 0.0250f, 0.0170f, 0.0120f};
        static const float yc[] = {0.0520f, 0.0527f, 0.0568f, 0.0610f, 0.0620f, 0.0610f, 0.0568f, 0.0527f, 0.0520f};
        std::vector<kit::Ring> rings;
        for (int i = 0; i < 9; ++i) rings.push_back(kit::roundedSection(xs[i], yc[i] - hh[i], yc[i] + hh[i], hz[i] * 0.9f, hz[i], 0.006f, 0.008f, 1));
        const Mat4 xf = Mat4::fromBasis(Vec3(0.0f, 0.0f, 1.0f), Vec3(0.0f, 1.0f, 0.0f), Vec3(1.0f, 0.0f, 0.0f), Vec3(0.0f, 0.0f, z));
        kit::addLoft(m, xf, rings, [&](const Vec3&, const Vec3& n, Material&) -> Rgba8 {
            return mix(shade(kTruck, 0.60f), kTruck, saturate(n.y * 0.5f + 0.5f));
        }, Material{});
    }
    const std::vector<P> barrel = {   // bushing
        {0.0f, -0.0075f, rubber, {}, false}, {0.0125f, -0.0075f, rubber, {}, true}, {0.0185f, -0.0045f, rubber, {}, false}, {0.0200f, 0.0f, rubber, {}, false},
        {0.0185f, 0.0045f, rubber, {}, false}, {0.0125f, 0.0075f, rubber, {}, true}, {0.0f, 0.0075f, rubber, {}, false}};
    for (int k = -1; k <= 1; k += 2)
        kit::addLathe(m, Mat4::fromBasis(Vec3(1.0f, 0.0f, 0.0f), Vec3(0.0f, 0.0f, 1.0f), Vec3(0.0f, -1.0f, 0.0f), Vec3(0.0f, 0.0630f, z + 0.040f * static_cast<float>(k))), barrel, 8);
    kit::addTube(m, Vec3(-0.176f, kWheelR, z), Vec3(0.176f, kWheelR, z), 0.0072f, 0.0072f, 6, shade(kTruck, 0.7f), shade(kTruck, 0.7f), Material{}, true, true);   // axle
}

MeshData makeBoard(const RiderStyle& st, bool low, bool withWheels) {
    MeshData m;
    // lacquered maple edge, painted underside, black grip tape on top
    const Rgba8 maple = glossy(rgba(0.84f, 0.66f, 0.43f), 0.40f), mapleLo = glossy(rgba(0.58f, 0.41f, 0.25f), 0.35f);
    const Rgba8 under = glossy(st.deck, 0.45f), underLo = glossy(shade(st.deck, 0.70f), 0.45f);
    std::vector<kit::Ring> rings;
    const int n = low ? 13 : 27;
    for (int i = 0; i < n; ++i) rings.push_back(deckRing(-0.56f + 1.12f * static_cast<float>(i) / static_cast<float>(n - 1), low ? 1 : 2));
    kit::addLoft(m, Mat4::identity(), rings, [&](const Vec3& p, const Vec3& nrm, Material&) -> Rgba8 {
        if (nrm.y > 0.55f && std::fabs(p.x) < deckHalfWidth(p.z) - 0.0095f) return kGrip;     // grip tape, inset from the edge
        if (nrm.y < -0.5f) return mix(underLo, under, 0.5f);                                  // underside
        return mix(mapleLo, maple, saturate(nrm.y * 0.5f + 0.5f));                            // rails: lacquered wood
    }, Material{});
    for (int e = -1; e <= 1; e += 2)
        addDeckRibbon(m, {-1.0f, 0.014f}, {1.0f, -0.014f}, static_cast<float>(e) * 0.505f, static_cast<float>(e) * 0.540f, 3, 4, st.accent, Material{});   // tip bands
    if (!low)
    for (int e = -1; e <= 1; e += 2)   // an accent pinstripe along each rail: the outline of the board reads against the road
        addDeckRibbon(m, {static_cast<float>(e), static_cast<float>(-e) * 0.024f}, {static_cast<float>(e), static_cast<float>(-e) * 0.013f}, -0.47f, 0.47f, 10, 1, st.accent, Material{});
    {   // three sunset stripes toward the nose and the tail: gold, orange, rose (what the camera sees most is the tail)
        const Rgba8 bars[3] = {rgba(1.00f, 0.80f, 0.26f), rgba(1.00f, 0.48f, 0.16f), rgba(0.90f, 0.26f, 0.40f)};
        for (int e = -1; e <= 1; e += 2)
            for (int i = 0; i < 3; ++i) {
                const float z0 = static_cast<float>(e) * (0.370f + 0.040f * static_cast<float>(i)), th = 0.024f;
                const float half = 0.84f - 0.07f * static_cast<float>(i);
                addDeckRibbon(m, {-half, 0.0f}, {half, 0.0f}, z0, z0 + static_cast<float>(e) * th, 1, 6, bars[i], Material{});
            }
    }
    const Rgba8 bolt = glossy(rgba(0.55f, 0.57f, 0.60f), 0.8f);
    if (!low)
    for (int t = -1; t <= 1; t += 2)   // truck bolts through the grip tape
        for (int bx = -1; bx <= 1; bx += 2)
            for (int bz = -1; bz <= 1; bz += 2) {
                const float x = static_cast<float>(bx) * 0.030f, z = static_cast<float>(t) * kTruckZ + static_cast<float>(bz) * 0.044f;
                const float y = deckTopY(x, z);
                kit::addTube(m, Vec3(x, y, z), Vec3(x, y + 0.0035f, z), 0.0058f, 0.0050f, 5, bolt, bolt, Material{}, false, true);
            }

    for (int i = 0; i < 2; ++i) {
        const float z = i == 0 ? kTruckZ : -kTruckZ;
        addTruck(m, z, st, low);
        if (withWheels)
            for (int side = -1; side <= 1; side += 2) addWheel(m, Vec3(static_cast<float>(side) * kWheelX, kWheelR, z), static_cast<float>(side), st, low);
    }
    return m;
}

// ---- the rider's rigid parts: built once per style and level of detail, then re-posed with a matrix -----------------------------------

struct TKey { float z, w, db, df; };   // torso section: height up the spine, half width, depth behind and in front of the spine

kit::Ring torsoRing(const TKey& k, int corner) {
    const float r = std::min(k.w, std::min(k.db, k.df)) * 0.80f;
    return kit::roundedSection(k.z, -k.db, k.df, k.w, k.w, r, r, corner);
}

// Local frame of both torso parts: x across the chest, y to the front, z up the spine; the origin is the hip joint (lower part) or the
// waist (upper part, which starts at z = 0.22 of the same scale: the two overlap there).
MeshData makeTorsoLow(const RiderStyle& st, bool low) {
    MeshData m;
    static const TKey keys[] = {{-0.040f, 0.156f, 0.100f, 0.110f}, {-0.018f, 0.150f, 0.096f, 0.106f}, {0.040f, 0.142f, 0.090f, 0.100f},
                                {0.110f, 0.145f, 0.092f, 0.103f},  {0.185f, 0.158f, 0.098f, 0.112f},  {0.262f, 0.172f, 0.104f, 0.120f}};
    std::vector<kit::Ring> rings;
    for (const TKey& k : keys) rings.push_back(torsoRing(k, low ? 1 : 2));
    kit::addLoft(m, Mat4::identity(), rings, [&](const Vec3& p, const Vec3&, Material&) -> Rgba8 {
        if (p.z < -0.022f) return shade(st.jacket, 0.90f);                       // the hem
        return mix(st.jacket, st.jacketHi, saturate((p.z + 0.04f) / 0.60f));
    }, Material{});
    // the shorts: the pelvis seen below the hem of the T-shirt (the legs' shorts continue it)
    kit::addEllipsoid(m, Mat4::translation(Vec3(0.0f, -0.004f, -0.062f)), Vec3(0.170f, 0.112f, 0.100f), 1, shade(st.pants, 0.90f), st.pants);
    return m;
}

MeshData makeTorsoUp(const RiderStyle& st, bool low) {
    MeshData m;
    static const TKey keys[] = {{0.220f, 0.165f, 0.100f, 0.114f}, {0.300f, 0.186f, 0.106f, 0.126f}, {0.380f, 0.203f, 0.106f, 0.126f}, {0.450f, 0.216f, 0.098f, 0.110f},
                                {0.500f, 0.196f, 0.086f, 0.094f}, {0.540f, 0.130f, 0.072f, 0.078f}, {0.568f, 0.080f, 0.064f, 0.068f}, {0.592f, 0.068f, 0.060f, 0.064f}};
    std::vector<kit::Ring> rings;
    for (const TKey& k : keys) rings.push_back(torsoRing(k, low ? 1 : 2));
    kit::addLoft(m, Mat4::identity(), rings, [&](const Vec3& p, const Vec3&, Material&) -> Rgba8 {
        if (p.z > 0.560f) return st.sleeve;                                       // ribbed collar
        return mix(st.jacket, st.jacketHi, saturate((p.z + 0.08f) / 0.60f));
    }, Material{});
    // shoulder caps: the round of the shoulder under the sleeves
    for (int s = -1; s <= 1; s += 2)
        kit::addEllipsoid(m, Mat4::translation(Vec3(0.208f * static_cast<float>(s), 0.0f, 0.452f)), Vec3(0.062f, 0.075f, 0.070f), 1, shade(st.jacket, 0.94f), st.jacketHi);
    if (!low) {   // sunset badge on the back: a glowing disc with three dark stripes across its lower half
        const float zc = 0.300f;
        const float yBack = -0.106f - 0.0015f;
        const Material glow{0, 30, 0, 0};
        using P = kit::LathePoint;
        const std::vector<P> disc = {{0.070f, 0.0f, st.accent, glow, false}, {0.070f, 0.006f, st.accent, glow, true}, {0.0f, 0.006f, st.accent, glow, false}};
        kit::addLathe(m, Mat4::fromBasis(Vec3(1.0f, 0.0f, 0.0f), Vec3(0.0f, -1.0f, 0.0f), Vec3(0.0f, 0.0f, 1.0f), Vec3(0.0f, yBack, zc)), disc, 20);
        const Rgba8 gap = mix(st.jacket, st.jacketHi, 0.40f);
        for (int i = 0; i < 3; ++i) {
            const float dz = -0.014f - 0.018f * static_cast<float>(i);
            const float half = std::sqrt(std::max(0.0f, 0.070f * 0.070f - dz * dz));
            m.addBox(Mat4::translation(Vec3(0.0f, yBack - 0.0075f, zc + dz)), Vec3(half, 0.0022f, 0.0040f), gap, gap);
        }
    }
    return m;
}

// Head with an open-face helmet and sunglasses. Local frame: x right, y up, z forward, the origin in the middle of the head. The helmet is a half
// shell over the top and back of the head (the rim runs over the ears and down to the nape), tilted back a little, with a stripe, a peak and a strap.
MeshData makeHead(const RiderStyle& st, bool low) {
    MeshData m;
    const Rgba8 skin = st.skin, skinLo = shade(st.skin, 0.82f), lip = shade(st.skin, 0.66f);
    kit::addEllipsoid(m, Mat4::translation(Vec3(0.0f, 0.010f, -0.004f)), Vec3(0.077f, 0.096f, 0.092f), low ? 1 : 2, skinLo, skin);   // skull
    kit::addEllipsoid(m, Mat4::translation(Vec3(0.0f, -0.058f, 0.030f)), Vec3(0.056f, 0.056f, 0.060f), 1, skinLo, skin);               // jaw and chin
    kit::addEllipsoid(m, Mat4::translation(Vec3(0.0f, -0.022f, 0.094f)), Vec3(0.014f, 0.021f, 0.018f), 1, skin, skin);                // nose
    if (!low) {
        for (int s = -1; s <= 1; s += 2) {
            const float x = static_cast<float>(s);
            kit::addEllipsoid(m, Mat4::translation(Vec3(0.076f * x, -0.008f, -0.006f)), Vec3(0.010f, 0.025f, 0.018f), 1, skinLo, skinLo);   // ears
        }
        kit::addEllipsoid(m, Mat4::translation(Vec3(0.0f, -0.066f, 0.078f)), Vec3(0.017f, 0.0045f, 0.007f), 1, lip, lip);       // mouth
    }
    // sunglasses: two dark lenses with a warm sheen, a bridge and arms back to the ears
    for (int s = -1; s <= 1; s += 2) {
        const float x = static_cast<float>(s);
        kit::addEllipsoid(m, Mat4::translation(Vec3(0.033f * x, 0.012f, 0.082f)), Vec3(0.031f, 0.021f, 0.013f), 1, glossy(kLensLo, 0.9f), glossy(kLensHi, 0.9f));
        if (!low) m.addBox(properFrame(Vec3(1.0f, 0.0f, 0.0f), Vec3(0.0f, 1.0f, 0.0f), Vec3(0.0f, 0.0f, 1.0f), Vec3(0.074f * x, 0.014f, 0.040f)), Vec3(0.0035f, 0.0035f, 0.044f), kFrame, kFrame);
    }
    if (!low) m.addBox(Mat4::translation(Vec3(0.0f, 0.020f, 0.092f)), Vec3(0.010f, 0.0035f, 0.004f), kFrame, kFrame);
    // hair at the nape and the temples, below the helmet's rim
    const Rgba8 hair = st.hair;
    kit::addEllipsoid(m, Mat4::translation(Vec3(0.0f, -0.030f, -0.066f)), Vec3(0.060f, 0.048f, 0.042f), 1, shade(hair, 0.8f), hair);
    if (!low)
        for (int s = -1; s <= 1; s += 2) kit::addEllipsoid(m, Mat4::translation(Vec3(0.070f * static_cast<float>(s), 0.026f, 0.030f)), Vec3(0.012f, 0.030f, 0.026f), 1, hair, hair);

    // the helmet: a dome, lathed around an axis tilted back by 0.20 rad (so the rim sits lower at the back and over the ears), a little longer front to back
    const float tilt = -0.20f, ct = std::cos(tilt), stl = std::sin(tilt);
    const Vec3 ax(1.0f, 0.0f, 0.0f), ay(0.0f, ct, stl), az(0.0f, -stl, ct);
    const Mat4 dome = Mat4::fromBasis(ax * 1.0f, ay, az * 1.14f, Vec3(0.0f, 0.008f, -0.006f));
    using P = kit::LathePoint;
    const Rgba8 shellLo = glossy(shade(st.helmet, 0.76f), 0.55f), shellHi = glossy(st.helmet, 0.55f), rim = glossy(shade(st.helmet, 0.60f), 0.40f);
    const std::vector<P> shell = {
        {0.0f, -0.040f, rim, {}, false},   {0.098f, -0.040f, rim, {}, true},   {0.1005f, -0.022f, shellLo, {}, false}, {0.1005f, 0.004f, shellLo, {}, false},
        {0.0950f, 0.032f, shellLo, {}, false}, {0.0840f, 0.056f, shellHi, {}, false}, {0.0680f, 0.080f, shellHi, {}, false}, {0.0450f, 0.100f, shellHi, {}, false},
        {0.0220f, 0.111f, shellHi, {}, false}, {0.0f, 0.115f, shellHi, {}, false},
    };
    kit::addLathe(m, dome, shell, low ? 12 : 20);
    const Rgba8 stripe = glossy(st.jacketHi, 0.55f);
    kit::addEllipsoid(m, Mat4::fromBasis(ax, ay, az, Vec3(0.0f, 0.040f, -0.006f)), Vec3(0.017f, 0.088f, 0.112f), 1, stripe, stripe);   // racing stripe
    if (!low) {
        m.addBox(Mat4::fromBasis(ax, Vec3(0.0f, std::cos(-0.30f), std::sin(-0.30f)), Vec3(0.0f, -std::sin(-0.30f), std::cos(-0.30f)), Vec3(0.0f, 0.058f, 0.102f)),
                 Vec3(0.050f, 0.0036f, 0.022f), shade(st.helmet, 0.62f), shade(st.helmet, 0.70f));                                       // peak
        for (int s = -1; s <= 1; s += 2) {   // chin strap
            const float x = static_cast<float>(s);
            kit::addTube(m, Vec3(0.082f * x, -0.012f, 0.004f), Vec3(0.036f * x, -0.100f, 0.044f), 0.0045f, 0.0045f, 5, kFrame, kFrame, Material{}, false, false, Vec3(0.0f, 0.0f, 1.0f));
        }
        kit::addTube(m, Vec3(-0.036f, -0.100f, 0.044f), Vec3(0.036f, -0.100f, 0.044f), 0.0050f, 0.0050f, 5, kFrame, kFrame, Material{}, true, true, Vec3(0.0f, 0.0f, 1.0f));
    }
    return m;
}

// Skate shoe in its own frame: x across the foot, y up, z toward the toes, the origin at the ankle (heel -0.105, toe +0.205).
MeshData makeShoe(const RiderStyle& st, bool low) {
    MeshData m;
    const Vec3 side(1.0f, 0.0f, 0.0f), up(0.0f, 1.0f, 0.0f), dir(0.0f, 0.0f, 1.0f);
    (void)side;
    if (low) {
        m.addBox(Mat4::translation(Vec3(0.0f, -0.030f, 0.050f)), Vec3(0.060f, 0.017f, 0.150f), kSole, kSole);                                    // gum sole
        kit::addEllipsoid(m, Mat4::translation(Vec3(0.0f, 0.018f, 0.045f)), Vec3(0.056f, 0.046f, 0.135f), 1, shade(kShoe, 0.85f), kShoe);        // upper
        m.addBox(Mat4::translation(Vec3(0.0f, 0.060f, 0.062f)), Vec3(0.030f, 0.006f, 0.052f), kLace, kLace);                                    // laces
        return m;
    }
    static const float zs[] = {-0.105f, -0.080f, -0.030f, 0.030f, 0.100f, 0.160f, 0.205f};
    static const float ws[] = {0.040f, 0.048f, 0.051f, 0.056f, 0.060f, 0.052f, 0.034f};
    static const float yu[] = {0.036f, 0.048f, 0.050f, 0.044f, 0.028f, 0.011f, -0.004f};
    std::vector<kit::Ring> sole, upper;
    for (int i = 0; i < 7; ++i) {
        const float spring = 0.012f * smoothstep(0.12f, 0.205f, zs[i]);   // toe spring
        sole.push_back(kit::roundedSection(zs[i], -0.029f + spring, -0.011f + spring, ws[i], ws[i], 0.008f, 0.008f, 2));
        upper.push_back(kit::roundedSection(zs[i], -0.011f + spring, yu[i] + spring, ws[i] - 0.002f, (ws[i] - 0.002f) * 0.80f, 0.006f, 0.020f, 3));
    }
    kit::addLoft(m, Mat4::identity(), sole, [&](const Vec3&, const Vec3& n, Material&) -> Rgba8 { return mix(shade(kSole, 0.78f), kSole, saturate(n.y * 0.5f + 0.5f)); }, Material{});
    kit::addLoft(m, Mat4::identity(), upper, [&](const Vec3& p, const Vec3& n, Material&) -> Rgba8 {
        const Rgba8 base = mix(shade(kShoe, 0.80f), kShoe, saturate(n.y * 0.5f + 0.5f));
        if (p.z > 0.158f) return mix(base, kSole, 0.55f);                   // toe bumper
        if (std::fabs(p.x) > 0.040f && p.z < 0.06f && p.z > -0.03f && n.y < 0.5f) return st.accent;   // a stripe on the side
        return base;
    }, Material{});
    for (int i = 0; i < 3; ++i) {   // laces across the instep
        const float z = 0.012f + 0.033f * static_cast<float>(i);
        const float y = lerpf(0.0487f, 0.0320f, static_cast<float>(i) / 2.0f) + 0.002f;
        m.addBox(Mat4::translation(up * y + dir * z), Vec3(0.026f, 0.0035f, 0.007f), kLace, kLace);
    }
    m.addBox(Mat4::translation(up * 0.040f - dir * 0.100f), Vec3(0.014f, 0.012f, 0.004f), st.accent, st.accent);   // heel tab
    return m;
}

// Slide glove in its own frame: x across the hand (the thumb side is `thumb`), y along the fingers, z out of the palm; the origin at the wrist.
MeshData makeGlove(const RiderStyle& st, float thumb, bool low) {
    MeshData m;
    kit::addTube(m, Vec3(0.0f, -0.078f, 0.0f), Vec3(0.0f, -0.016f, 0.0f), 0.047f, 0.044f, low ? 6 : 8, kGlove, kGlove, Material{}, false, false, Vec3(0.0f, 0.0f, 1.0f));   // cuff
    if (!low) kit::addTube(m, Vec3(0.0f, -0.082f, 0.0f), Vec3(0.0f, -0.066f, 0.0f), 0.050f, 0.050f, 8, st.accent, st.accent, Material{}, true, true, Vec3(0.0f, 0.0f, 1.0f));      // band
    kit::addEllipsoid(m, Mat4::translation(Vec3(0.0f, 0.040f, -0.002f)), Vec3(0.043f, 0.070f, 0.026f), 1, kGlove, shade(kGlove, 1.5f));   // palm and the base of the fingers
    kit::addEllipsoid(m, Mat4::translation(Vec3(0.0f, 0.100f, 0.002f)), Vec3(0.040f, 0.040f, 0.020f), 1, kGlove, shade(kGlove, 1.5f));   // fingers
    if (!low) kit::addEllipsoid(m, Mat4::translation(Vec3(0.042f * thumb, 0.038f, 0.010f)), Vec3(0.015f, 0.032f, 0.015f), 1, kGlove, shade(kGlove, 1.4f));   // thumb
    kit::addTube(m, Vec3(0.0f, 0.036f, 0.026f), Vec3(0.0f, 0.036f, 0.040f), 0.031f, 0.029f, low ? 6 : 8, st.accent, st.accent, Material{}, true, true, Vec3(0.0f, 1.0f, 0.0f));   // slide puck
    return m;
}

// Knee pad in its own frame: x across, y along the leg, z out of the front of the knee; the origin at the knee. A hard shell with a trim cap
// and elastic straps above and below.
MeshData makeKneePad(const RiderStyle& st, bool low) {
    MeshData m;
    const Rgba8 pad = mix(kPad, st.pants, 0.30f);
    kit::addEllipsoid(m, Mat4::translation(Vec3(0.0f, 0.0f, 0.040f)), Vec3(0.062f, 0.072f, 0.032f), 1, pad, shade(pad, 1.6f));
    kit::addEllipsoid(m, Mat4::translation(Vec3(0.0f, 0.0f, 0.066f)), Vec3(0.026f, 0.030f, 0.008f), 1, st.accent, st.accent);
    if (!low) {
        kit::addTube(m, Vec3(0.0f, -0.092f, 0.0f), Vec3(0.0f, -0.070f, 0.0f), 0.062f, 0.062f, 8, kPad, kPad, Material{}, false, false, Vec3(0.0f, 0.0f, 1.0f));
        kit::addTube(m, Vec3(0.0f, 0.070f, 0.0f), Vec3(0.0f, 0.090f, 0.0f), 0.062f, 0.062f, 8, kPad, kPad, Material{}, false, false, Vec3(0.0f, 0.0f, 1.0f));
    }
    return m;
}

struct Parts {
    MeshData boardBare, boardFull, wheel, shoe, gloveL, gloveR, head, torsoLow, torsoUp, kneePad;
};

std::unique_ptr<Parts> buildParts(const RiderStyle& st, bool low) {
    std::unique_ptr<Parts> p(new Parts());
    p->boardBare = makeBoard(st, low, false);
    p->boardFull = makeBoard(st, low, true);
    p->wheel = makeWheel(st, low);
    p->shoe = makeShoe(st, low);
    p->gloveL = makeGlove(st, -1.0f, low);   // (the rider's left hand: the thumb is on the other side of the template)
    p->gloveR = makeGlove(st, 1.0f, low);
    p->head = makeHead(st, low);
    p->torsoLow = makeTorsoLow(st, low);
    p->torsoUp = makeTorsoUp(st, low);
    p->kneePad = makeKneePad(st, low);
    return p;
}

const Parts& partsFor(const RiderStyle& st, bool low) {
    static std::unique_ptr<Parts> cache[kRiderStyleCount][2];
    const long idx = &st - kStyles;
    if (idx >= 0 && idx < kRiderStyleCount) {
        std::unique_ptr<Parts>& slot = cache[idx][low ? 1 : 0];
        if (!slot) slot = buildParts(st, low);
        return *slot;
    }
    static thread_local std::unique_ptr<Parts> custom;   // a style that is not in the table: built for this one call
    custom = buildParts(st, low);
    return *custom;
}

struct Rig {
    const SkaterPose& p;
    MeshData& out;
    Vec3 o, r, u, f;
    const RiderStyle& st;
    bool low = false;   // remote rider: cheaper geometry
    const Parts& parts;

    Vec3 W(float x, float y, float z) const { return o + r * x + u * y + f * z; }
    // Round limb segment; the ends are hidden by joint balls, caps or the neighbouring parts.
    void tube(const Vec3& a, const Vec3& b, float rA, float rB, Rgba8 cA, Rgba8 cB, const Vec3& hint, bool capA = false, bool capB = false) const {
        kit::addTube(out, a, b, rA, rB, low ? 6 : 8, cA, cB, Material{}, capA, capB, hint);
    }
    void ball(const Vec3& c, float radius, Rgba8 col) const { kit::addEllipsoid(out, Mat4::translation(c), Vec3(radius, radius, radius), 1, col, col); }
};

// ---- the board: the deck and trucks as one mesh, the four wheels apart (they turn as the board travels) ---------------------------------
void buildBoard(const Rig& g, float spin, const Vec3& offset, float hop) {
    // Optionally detached board (crash): rotate its basis around the up vector by `spin`.
    const Vec3 o = g.o + offset + g.u * hop;
    const Vec3 f = rotateAround(g.f, g.u, spin), r = rotateAround(g.r, g.u, spin);
    const Mat4 base = properFrame(r, g.u, f, o);
    if (g.low) {
        g.out.append(g.parts.boardFull, base);   // (far away: the wheels are part of the board and do not turn)
        return;
    }
    g.out.append(g.parts.boardBare, base);
    for (int i = 0; i < 2; ++i) {
        const float z = i == 0 ? kTruckZ : -kTruckZ;
        for (int side = -1; side <= 1; side += 2)
            g.out.append(g.parts.wheel, base * wheelFrame(Vec3(static_cast<float>(side) * kWheelX, kWheelR, z), static_cast<float>(side), g.p.wheelSpin));
    }
}

// ---- body parts -------------------------------------------------------------------------------------------------------------------------
// A leg: the shorts (loose, ending above the knee), the bare thigh, the knee with its pad, the calf, a sock and the shoe. The foot follows
// `ankleTarget` as far as the leg reaches; returns where it ended up.
Vec3 drawLeg(const Rig& g, const Vec3& hip, const Vec3& ankleTarget, const Vec3& pole, const Vec3& toeDir, const Vec3& shoeUp) {
    const RiderStyle& st = g.st;
    Vec3 foot;
    const Vec3 knee = solveJoint(hip, ankleTarget, kThigh, kShin, pole, foot);
    const Vec3 thigh = normalize(knee - hip), shin = normalize(foot - knee);
    const Rgba8 shortsLo = shade(st.pants, 0.84f);
    const Vec3 hem = hip + (knee - hip) * 0.58f;
    g.tube(hip, hem, 0.106f, 0.098f, st.pants, shortsLo, pole, false, false);                       // shorts leg, flaring to the hem
    if (!g.low) {
        g.tube(hem - thigh * 0.022f, hem, 0.0985f, 0.0985f, shade(st.pants, 1.16f), shade(st.pants, 1.16f), pole, false, false);   // the hem, stitched
        g.tube(hem + thigh * 0.001f, hem + thigh * 0.004f, 0.095f, 0.095f, shade(st.pants, 0.30f), shade(st.pants, 0.30f), pole, true, true);   // the dark inside
        g.ball(hip, 0.106f, st.pants);
    }
    g.tube(hem - thigh * 0.030f, knee, 0.082f, 0.057f, st.skin, st.skin, pole);                       // bare thigh
    const Vec3 sockTop = knee + (foot - knee) * 0.62f;
    if (g.low) {
        g.tube(knee, sockTop, 0.056f, 0.050f, st.skin, st.skin, pole);                                   // shin
        g.tube(sockTop, foot, 0.0515f, 0.0440f, kSock, kSock, pole);                                     // sock
    } else {
        g.ball(knee, 0.056f, st.skin);
        const Vec3 mid = knee + (foot - knee) * 0.33f;
        g.tube(knee, mid, 0.052f, 0.059f, st.skin, st.skin, pole);                                       // calf
        g.tube(mid, foot, 0.059f, 0.040f, st.skin, shade(st.skin, 0.94f), pole);
        g.tube(sockTop, foot, 0.0515f, 0.0440f, kSock, kSock, pole);                                     // sock
        g.tube(sockTop - shin * 0.002f, sockTop + shin * 0.020f, 0.0535f, 0.0535f, st.accent, st.accent, pole);   // sock stripe
        g.ball(foot, 0.044f, kSock);
    }
    // knee pad on the front of the knee
    Vec3 kd = pole - thigh * dot(pole, thigh);
    kd = dot(kd, kd) > 1e-6f ? normalize(kd) : g.f;
    const Vec3 axis = normalize(foot - hip);
    g.out.append(g.parts.kneePad, properFrame(cross(axis, kd), axis, kd, knee));
    // shoe
    g.out.append(g.parts.shoe, properFrame(cross(shoeUp, toeDir), shoeUp, toeDir, foot));
    return foot;
}

struct ArmJoints { Vec3 sh, elbow, hand; };

// An arm: the short sleeve of the T-shirt (with a hem), the bare arm, the elbow, the forearm and a slide glove; `palmDir` is where the palm faces.
ArmJoints drawArm(const Rig& g, const Vec3& sh, const Vec3& handTarget, const Vec3& pole, const Vec3& palmDir, bool leftHand) {
    const RiderStyle& st = g.st;
    Vec3 wrist;
    const Vec3 elbow = solveJoint(sh, handTarget, kUpperArm, kForeArm, pole, wrist);
    const Vec3 up = normalize(elbow - sh), fa = normalize(wrist - elbow);
    const Vec3 sleeveEnd = sh + (elbow - sh) * 0.56f;
    g.tube(sh, sleeveEnd, 0.073f, 0.066f, st.jacket, shade(st.jacket, 0.90f), pole);                       // sleeve
    if (!g.low) {
        g.ball(sh, 0.072f, st.jacket);
        g.tube(sleeveEnd - up * 0.016f, sleeveEnd, 0.0675f, 0.0675f, st.sleeve, st.sleeve, pole);          // sleeve hem
        g.tube(sleeveEnd - up * 0.004f, sleeveEnd + up * 0.003f, 0.060f, 0.060f, shade(st.jacket, 0.30f), shade(st.jacket, 0.30f), pole, true, true);   // inside of the sleeve
    }
    g.tube(sleeveEnd - up * 0.020f, elbow, 0.058f, 0.046f, st.skin, st.skin, pole);                         // upper arm
    if (g.low) {
        g.tube(elbow, wrist, 0.046f, 0.034f, st.skin, st.skin, pole);                                       // forearm
    } else {
        g.ball(elbow, 0.046f, st.skin);
        const Vec3 mid = elbow + (wrist - elbow) * 0.34f;
        g.tube(elbow, mid, 0.045f, 0.048f, st.skin, st.skin, pole);                                          // forearm
        g.tube(mid, wrist, 0.048f, 0.034f, st.skin, shade(st.skin, 0.94f), pole);
    }
    Vec3 pd = palmDir - fa * dot(palmDir, fa);
    pd = dot(pd, pd) > 1e-6f ? normalize(pd) : -g.u;
    g.out.append(leftHand ? g.parts.gloveL : g.parts.gloveR, properFrame(cross(fa, pd), fa, pd, wrist));
    return {sh, elbow, wrist};
}

// Neck and head (with the helmet) at the top of the spine: one function for the riding poses, the slide and the crash.
void drawHead(const Rig& g, const Vec3& neckBase, const Vec3& td, const Vec3& headUp, const Vec3& hu, const Vec3& hf) {
    const RiderStyle& st = g.st;
    const Vec3 headC = neckBase + headUp * 0.150f + g.u * 0.012f;
    g.tube(neckBase - td * 0.040f, headC - headUp * 0.080f, 0.058f, 0.050f, st.skin, shade(st.skin, 0.92f), hf);   // neck
    const Vec3 fwd = normalize(hf - hu * dot(hf, hu));
    g.out.append(g.parts.head, properFrame(cross(hu, fwd), hu, fwd, headC));
}

// Rider on the board. Three poses are blended by weight:
//   riding stance (stand <-> tuck), kick-push (foot plants, drives back, swings forward) and Coleman slide
//   (board kicked out sideways, deep crouch, inside hand on the road, free arm out for balance).
// On top of those: the front foot turned toward the nose, the chest turned a little further than the hips, the head looking into the turn,
// the legs soaking up the road, the arms balancing against the lean.
void buildStanding(const Rig& g, const SkaterPose& p) {
    const float t = p.tuck;
    const float L = p.lean;
    const float sd = p.slideDir;
    const float pw = saturate(p.push);
    const float cw = saturate(p.slide) * (1.0f - pw);
    const Vec3 roadUp = normalize(p.roadUp);
    auto mixv = [](const Vec3& a, const Vec3& b, float k) { return a + (b - a) * k; };
    // point `pt` moved along the road normal so that it sits `h` above the road surface
    auto onRoad = [&](const Vec3& pt, float h) { return pt - roadUp * (dot(pt - g.o, roadUp) - h); };

    // axes aligned with the travel direction: the rider keeps looking where the road goes while the board kicks out
    const float cs = std::cos(p.slip), sn = std::sin(p.slip);
    const Vec3 fT = g.f * cs - g.r * sn;
    const Vec3 rT = g.r * cs + g.f * sn;

    // ---- riding stance
    Vec3 ankleL = g.W(0.0f, 0.158f, 0.20f);    // left leg = front foot
    Vec3 ankleR = g.W(0.0f, 0.158f, -0.20f);   // right leg = back (kicking) foot
    const float speed01 = saturate(p.speed / 25.0f);
    const float bob = (std::sin(p.time * 9.1f) + 0.7f * std::sin(p.time * 15.7f + 1.1f)) * 0.0045f * speed01 * (1.0f - 0.7f * t);   // the legs soak up the road
    const float hipY = lerpf(0.67f, 0.48f, t) + bob;
    Vec3 hip = g.W(L * 0.10f, hipY, lerpf(0.0f, -0.03f, t));
    const float twist = lerpf(0.50f, 0.95f, t);
    Vec3 facing = normalize(g.r * std::cos(twist + 0.20f) + g.f * std::sin(twist + 0.20f));   // the chest turns a little further toward the nose than the hips
    const float pitchT = lerpf(0.26f, 1.02f, t);
    Vec3 td = normalize(g.u * std::cos(pitchT) + facing * std::sin(pitchT) + g.r * (L * 0.30f));
    float toeL = 0.55f, toeR = 0.10f;         // shoe yaw: 0 = across the board, pi/2 = pointing at the nose (the front foot is angled toward the nose)
    Vec3 headFace = normalize(g.f + g.r * (0.42f * L));   // looks where it is going, into the turn
    float armSwing = 0.0f;                    // kick-push arm swing, +1 = left arm forward

    // ---- kick-push
    if (pw > 0.001f) {
        const float N = static_cast<float>(cfg::kPushStrokes);
        const float cyc = std::min(p.pushPhase, N);
        const float u = cyc - std::floor(cyc);
        const float c = cfg::kPushContact;
        float fx, fy, fz, kp;   // kicking foot (board space x right / z forward, height above the road) and kick progress 0..1
        if (u < c) {            // drive: the foot is on the road and slides back past the board
            const float s = u / c;
            fz = lerpf(0.10f, -0.50f, s);
            fx = lerpf(0.34f, 0.25f, s);
            fy = lerpf(0.050f, 0.090f, s * s);   // heel comes up at the end of the drive
            kp = s;
        } else {                // recovery: lift the foot and swing it forward to the next plant
            const float s = (u - c) / (1.0f - c);
            const float e = s * s * (3.0f - 2.0f * s);
            fz = lerpf(-0.50f, 0.10f, e);
            fx = lerpf(0.25f, 0.34f, e) + 0.03f * std::sin(kPi * s);
            fy = lerpf(0.090f, 0.050f, s) + 0.17f * std::sin(kPi * s);
            kp = 1.0f - e;
        }
        Vec3 kick = onRoad(g.o + g.r * fx + g.f * fz, fy);
        // the last recovery brings the foot back onto the deck instead of planting again
        const float landing = smoothstep(N - 0.55f, N, cyc);
        kick = mixv(kick, g.W(0.0f, 0.158f, -0.20f), landing);
        const float lunge = kp * (1.0f - landing);

        const Vec3 hipP = g.W(0.08f, 0.60f - 0.03f * lunge, lerpf(-0.04f, 0.06f, lunge));
        const Vec3 facingP = normalize(g.r * std::cos(1.0f) + g.f * std::sin(1.0f));
        const float pitchP = 0.46f + 0.14f * lunge;
        const Vec3 tdP = normalize(g.u * std::cos(pitchP) + facingP * std::sin(pitchP));
        ankleR = mixv(ankleR, kick, pw);
        hip = mixv(hip, hipP, pw);
        facing = normalize(mixv(facing, facingP, pw));
        td = normalize(mixv(td, tdP, pw));
        toeL = lerpf(toeL, 0.95f, pw);
        toeR = lerpf(toeR, lerpf(1.30f, 0.0f, landing), pw);
        armSwing = (lunge * 2.0f - 1.0f) * (1.0f - landing) * pw;
        headFace = normalize(mixv(headFace, g.f, pw));
    }

    // ---- Coleman slide
    if (cw > 0.001f) {
        const float mag = saturate((std::fabs(p.slip) - 0.80f) / 0.5f);
        const Vec3 hipC = g.o + g.u * 0.34f - g.f * 0.10f + rT * (sd * 0.04f);   // a deep squat
        const Vec3 facingC = normalize(fT * 0.85f + rT * (sd * 0.55f));
        const float phi = lerpf(0.95f, 1.20f, mag);   // leaning into the slide: harder the further the board is out
        const Vec3 leanDir = normalize(rT * (sd * 0.9f) + fT * 0.35f);
        const Vec3 tdC = normalize(g.u * std::cos(phi) + leanDir * std::sin(phi));
        // each foot stays on its own side of the board so the legs never cross
        const Vec3 aF = g.W(0.0f, 0.158f, 0.22f), aB = g.W(0.0f, 0.158f, -0.22f);
        const bool frontOnLeft = dot(aF - aB, rT) < 0.0f;
        ankleL = mixv(ankleL, frontOnLeft ? aF : aB, cw);
        ankleR = mixv(ankleR, frontOnLeft ? aB : aF, cw);
        hip = mixv(hip, hipC, cw);
        facing = normalize(mixv(facing, facingC, cw));
        td = normalize(mixv(td, tdC, cw));
        headFace = normalize(mixv(headFace, normalize(fT + rT * (sd * 0.40f)), cw));
        toeL = lerpf(toeL, 0.25f, cw);
        toeR = lerpf(toeR, 0.25f, cw);
    }

    const Vec3 left = normalize(cross(g.u, facing));     // rider's left
    // the spine: the hips lean less than the chest; the two torso parts meet at J
    const Vec3 tdLow = normalize(mixv(g.u, td, 0.55f));
    const Vec3 J = hip + tdLow * 0.24f;
    const Vec3 upperOrigin = J - td * 0.24f;
    const Vec3 neckBase = upperOrigin + td * 0.592f;

    // ---- legs
    const Vec3 hipL = hip + left * 0.088f, hipR = hip - left * 0.088f;
    const Vec3 dirL = normalize(g.r * std::cos(toeL) + g.f * std::sin(toeL)), dirR = normalize(g.r * std::cos(toeR) + g.f * std::sin(toeR));
    // knees point along the feet when riding, and along the chest direction while kicking / sliding
    Vec3 poleL = normalize(dirL + g.u * 0.15f);
    Vec3 poleR = normalize(dirR + g.u * 0.15f);
    const float wMode = std::max(pw, cw);
    if (wMode > 0.001f) {
        poleL = normalize(mixv(poleL, normalize(facing + g.u * 0.15f + left * 0.10f), wMode));
        poleR = normalize(mixv(poleR, normalize(facing + g.u * 0.15f - left * 0.10f), wMode));
    }
    drawLeg(g, hipL, ankleL, poleL, dirL, g.u);
    drawLeg(g, hipR, ankleR, poleR, dirR, g.u);

    // ---- pelvis, shorts and T-shirt: the lower part follows the hips, the upper part the chest
    const Vec3 fwLowRaw = mixv(facing, g.r, 0.35f);
    const Vec3 fwLow = normalize(fwLowRaw - tdLow * dot(fwLowRaw, tdLow));
    g.out.append(g.parts.torsoLow, properFrame(cross(fwLow, tdLow), fwLow, tdLow, hip));
    const Vec3 fwUp = normalize(facing - td * dot(facing, td));
    g.out.append(g.parts.torsoUp, properFrame(cross(fwUp, td), fwUp, td, upperOrigin));

    // ---- head + helmet
    const Vec3 headUp = normalize(td + g.u * (1.2f * cw));
    const Vec3 hu = normalize(mixv(g.u, headUp, 0.35f) + g.r * (0.10f * L));
    const Vec3 hf = normalize(headFace - hu * dot(headFace, hu));
    drawHead(g, neckBase, td, headUp, hu, hf);

    // ---- arms: relaxed -> hands behind the back (tuck) -> swinging (kick-push) -> inside hand on the road (Coleman)
    const Vec3 shoulderBase = upperOrigin + td * 0.452f;
    const Vec3 shL = shoulderBase + left * 0.222f, shR = shoulderBase - left * 0.222f;
    auto handFor = [&](int side) {
        const float sgn = side == 0 ? 1.0f : -1.0f;
        const Vec3 sh = side == 0 ? shL : shR;
        const float sway = std::sin(p.time * 2.3f + sgn) * 0.035f;
        // arms bent, out in front for balance; against the lean the outside arm opens up (like the rider counter-balancing)
        const float open = 0.5f * (L * sgn * -1.0f + std::fabs(L));   // the arm on the outside of the turn opens
        Vec3 relaxed = sh + left * (sgn * (0.20f + 0.14f * open)) - td * 0.34f + facing * 0.22f + g.r * (L * 0.2f) + g.u * (sway + 0.06f * open);
        const Vec3 back = hip - facing * 0.17f + left * (sgn * 0.16f) + g.u * 0.06f;
        Vec3 h = relaxed + (back - relaxed) * t;
        if (pw > 0.001f) {
            const float swing = side == 0 ? armSwing : -armSwing;   // opposite arm to the kicking leg swings forward
            h += g.f * (swing * 0.34f) + g.u * (0.10f * pw);
        }
        if (cw > 0.001f) {
            const bool inside = dot(sh - neckBase, rT * sd) > 0.0f;    // the shoulder on the side we slide toward
            Vec3 target;
            if (inside) {
                // hand flat on the road under the shoulder, as far out as the arm reaches
                const float drop = dot(sh - g.o, roadUp) - 0.05f;
                const float reach = 0.55f;
                const float horiz = std::sqrt(std::max(0.0f, reach * reach - drop * drop));
                const Vec3 outDir = normalize(rT * (sd * 0.85f) - fT * 0.30f);
                target = onRoad(sh + outDir * horiz, 0.05f);
            } else {
                // free arm thrown out behind and up for balance
                target = sh + rT * (-sd * 0.44f) + g.u * 0.22f - fT * 0.26f;   // elbow bent: balance, not pointing
            }
            h += (target - h) * cw;
        }
        return h;
    };
    for (int side = 0; side < 2; ++side) {
        const float sgn = side == 0 ? 1.0f : -1.0f;
        const Vec3 sh = side == 0 ? shL : shR;
        const Vec3 pole = normalize(-td * 0.4f - facing * 0.4f + left * (sgn * 0.5f) - g.u * 0.3f);
        // palms face the body when relaxed and the road when a hand is down for the slide
        const Vec3 inward = normalize(hip + td * 0.28f - handFor(side));
        const Vec3 palm = normalize(mixv(inward, -roadUp, cw));
        drawArm(g, sh, handFor(side), pole, palm, side == 0);
    }
}

void buildCrashed(const Rig& g, const SkaterPose& p) {
    const float t = p.crashTime;
    const float u1 = saturate(t / 1.4f);
    const float ease = 1.0f - (1.0f - u1) * (1.0f - u1);
    const float phi = ease * (kPi * 0.5f + kTwoPi);            // somersault then land on the back
    const float hopT = saturate(t / 0.95f);
    const float hop = 1.0f * std::sin(hopT * kPi) * (1.0f - u1 * 0.6f);
    const float restY = 0.20f;

    // board flies ahead and spins
    const float ahead = p.crashSpeed * 0.55f * (1.0f - std::exp(-1.4f * t)) / 1.4f;
    buildBoard(g, 7.0f * (1.0f - std::exp(-1.4f * t)), g.f * ahead + g.r * (0.7f * (1.0f - std::exp(-2.0f * t))),
               0.35f * std::sin(saturate(t / 0.8f) * kPi));

    // limp rider rotating around the board-right axis, arms and legs flailing until the tumble dies down
    const Vec3 axis = g.r;
    auto R = [&](const Vec3& v) { return rotateAround(v, axis, phi); };
    const Vec3 pivot = g.o + g.u * (restY + hop) - g.f * 0.1f;
    const float splay = 0.5f + 0.5f * saturate(t / 0.8f);
    const float fl = std::exp(-1.3f * t);   // how much the limbs still flail
    const Vec3 up = R(g.u), fw = R(g.f), rt = g.r;
    auto P = [&](float x, float y, float z) { return pivot + rt * x + up * y + fw * z; };
    const RiderStyle& st = g.st;

    const Vec3 hip = P(0.0f, 0.02f, 0.0f);
    const Vec3 lat = normalize(cross(fw, up));
    g.out.append(g.parts.torsoLow, properFrame(lat, fw, up, hip));
    g.out.append(g.parts.torsoUp, properFrame(lat, fw, up, hip));
    drawHead(g, P(0.0f, 0.592f + 0.02f, 0.0f), up, up, up, fw);
    for (int s = -1; s <= 1; s += 2) {
        const float sg = static_cast<float>(s);
        const float w1 = std::sin(t * 15.0f + sg * 1.3f) * fl, w2 = std::sin(t * 11.0f + sg * 2.1f + 0.7f) * fl, w3 = std::sin(t * 19.0f - sg) * fl;
        const Vec3 ankleT = P(0.27f * sg * splay + 0.12f * w1, -0.80f + 0.10f * w2, 0.02f + 0.20f * w3);
        drawLeg(g, P(0.088f * sg, 0.0f, 0.0f), ankleT, normalize(fw + rt * (0.2f * sg) + up * (0.3f * w2)), normalize(fw + rt * (0.5f * sg)), up);
        const Vec3 handT = P(0.78f * sg * splay + 0.10f * w2, 0.30f + 0.20f * w1, -0.12f * sg + 0.22f * w3);
        drawArm(g, P(0.222f * sg, 0.452f, 0.0f), handT, normalize(-fw * 0.5f + rt * (0.6f * sg) - up * 0.3f), -up, sg > 0.0f);
    }
    (void)st;
}

}  // namespace

const RiderStyle& riderStyle(int index) {
    const int n = kRiderStyleCount;
    return kStyles[((index % n) + n) % n];
}

void buildSkaterMesh(const SkaterPose& pose, MeshData& out, const RiderStyle& style) {
    // Build at natural size, then scale up around the board so the rider reads well on a phone screen.
    constexpr float kRiderScale = 1.2f;
    MeshData tmp;
    tmp.vertices.reserve(pose.lowDetail ? 3600 : 6500);
    tmp.indices.reserve(pose.lowDetail ? 12000 : 22000);
    const Parts& parts = partsFor(style, pose.lowDetail);
    Rig g{pose, tmp, pose.origin, pose.right, pose.up, pose.fwd, style, pose.lowDetail, parts};
    if (pose.crashed) {
        buildCrashed(g, pose);
    } else {
        buildBoard(g, 0.0f, Vec3(), 0.0f);
        buildStanding(g, pose);
    }
    const Mat4 xf = Mat4::translation(pose.origin) * Mat4::scaling(Vec3(kRiderScale, kRiderScale, kRiderScale)) *
                    Mat4::translation(-pose.origin);
    out.append(tmp, xf);
}

}  // namespace sd
