// graphics_panel.h - the GRAPHICS screen (opened from the menu and the pause overlay): a 0..100% slider for the motion blur, preset chips,
// - / + steppers and DONE. Drawn and driven by the engine, like the CONTROLS editor.
#pragma once

#include "graphics_settings.h"
#include "ui_batch.h"
#include "ui_layout.h"

namespace sd {

class GraphicsPanel {
public:
    struct Geometry {
        Rect panel, sliderHit, done, minus, plus;
        float trackX0 = 0.0f, trackX1 = 0.0f, trackY = 0.0f;
        Rect chip[5];
    };
    static constexpr int kPresetCount = 5;
    static constexpr int kPresets[kPresetCount] = {0, 25, 50, 90, 100};   // percent (0 = off)

    static Geometry geometry(const UiLayout& L);
    // Where a drag at pixel x leaves the slider, in percent: whole percents, with a magnet at the preset values.
    static int valueAt(const Geometry& g, float x);

    void open() { open_ = true; dragId_ = -1; changed_ = false; }
    void close() { open_ = false; dragId_ = -1; }
    bool isOpen() const { return open_; }

    // A touch while the panel is open (it takes all of them). Edits `gfx`; returns true when that changed the settings.
    bool onTouch(int action, int id, float x, float y, const UiLayout& L, GraphicsSettings& gfx);
    void draw(UiBatch& ui, const UiLayout& L, const GraphicsSettings& gfx, float time) const;

private:
    bool open_ = false;
    int dragId_ = -1;
    bool changed_ = false;
};

}  // namespace sd
