#include "scene_builder.h"

#include <cmath>

namespace sd {

FrameParams buildScene(Game& game, float treeDensity, SceneGeometry& geo, const std::vector<RemoteRider>* remotes) {
    geo.clear();
    const CameraView& cam = game.camera().view();
    const Vec3 origin = cam.pos;
    const Skater& sk = game.skater();
    World& world = game.world();

    const float focus = sk.focusS();   // (the road position the world is built around: while a rider flies over a gorge, the mouth of it)
    world.buildTerrain(focus, origin, geo);
    world.buildScenery(focus, origin, cam.fwd, treeDensity, geo);
    world.buildObstacles(origin, geo, game.time());
    world.buildStartGate(sk.s, origin, geo);
    world.buildShortcuts(focus, origin, geo);
    const SkaterPose riderPose = game.skaterPose(origin);
    // after a respawn the rider blinks for a moment (nothing can hurt it): half of every fifth of a second it is not drawn
    auto blinkOff = [](float grace, float time) { return grace > 0.0f && std::fmod(time, 0.2f) < 0.1f; };
    if (!blinkOff(sk.grace, game.time())) buildSkaterMesh(riderPose, geo.dynamicMesh, riderStyle(game.localStyle()));
    if (remotes) {
        // The riders around are drawn with the cheaper model; the one right next to the camera gets the full one (on a phone that can afford it:
        // treeDensity is the quality tier's level of detail). The mesh is skipped altogether if its 16-bit index range is nearly used up.
        const RemoteRider* nearest = nullptr;
        float nearestD = 16.0f;
        if (treeDensity >= 0.99f)
            for (const RemoteRider& rr : *remotes) {
                const float d = std::fabs(rr.net.s - sk.s);
                if (d < nearestD) { nearestD = d; nearest = &rr; }
            }
        for (const RemoteRider& rr : *remotes) {
            if (rr.net.s < sk.s - 90.0f || rr.net.s > sk.s + 420.0f) continue;   // out of sight
            const bool full = &rr == nearest;
            if (geo.dynamicMesh.vertices.size() + (full ? kRiderVertexBudget : kRemoteRiderVertexBudget) > kDynamicMeshVertexLimit) continue;
            if (blinkOff(rr.net.ghost ? 1.0f : 0.0f, game.time())) continue;
            SkaterPose rp = poseFromRiderNet(world.track(), rr.net, origin, game.time());
            rp.lowDetail = !full;
            buildSkaterMesh(rp, geo.dynamicMesh, riderStyle(rr.style));
        }
    }
    game.particles().build(origin, geo.smoke, geo.sparks);

    FrameParams fp;
    fp.cam = cam;
    fp.atmo = game.atmosphere();
    fp.time = game.time();
    fp.speed01 = game.speed01() * (game.phase() == Phase::Menu ? 0.75f : 1.0f);
    fp.slide = sk.slide;
    fp.flash = game.crashFlash();

    fp.shadowFocus = riderPose.origin + origin + riderPose.fwd * 12.0f;
    return fp;
}

}  // namespace sd
