// graphics_settings.h - the player's graphics options (saved together with the controls layout; see Engine::controlsString()).
#pragma once

#include <string>

namespace sd {

struct GraphicsSettings {
    static constexpr int kDefaultMotionBlur = 50;   // percent
    int motionBlur = kDefaultMotionBlur;            // 0 (off) .. 100: how strongly the edges of the picture smear at speed

    float blur01() const { return static_cast<float>(motionBlur) * 0.01f; }
    void sanitize();
    std::string serialize() const;                                  // "mb=50"
    static GraphicsSettings parse(const std::string& text);         // finds the "mb=" token anywhere in the text; the defaults if there is none
    bool operator==(const GraphicsSettings& o) const { return motionBlur == o.motionBlur; }
    bool operator!=(const GraphicsSettings& o) const { return !(*this == o); }
};

}  // namespace sd
