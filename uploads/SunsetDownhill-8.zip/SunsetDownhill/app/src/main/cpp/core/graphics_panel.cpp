#include "graphics_panel.h"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>

#include "input.h"
#include "ui_widgets.h"

namespace sd {

using namespace widgets;

constexpr int GraphicsPanel::kPresets[GraphicsPanel::kPresetCount];

GraphicsPanel::Geometry GraphicsPanel::geometry(const UiLayout& L) {
    Geometry g;
    const float u = L.u;
    const float pw = std::min(1240.0f * u, L.w - 1.2f * L.margin), ph = std::min(780.0f * u, L.h - 0.7f * L.margin);
    g.panel = {L.w * 0.5f - pw * 0.5f, L.h * 0.5f - ph * 0.5f, pw, ph};
    const float side = 150.0f * u;
    g.trackX0 = g.panel.x + side;
    g.trackX1 = g.panel.x + pw - side;
    g.trackY = g.panel.y + 330.0f * u;
    g.sliderHit = {g.trackX0 - 56.0f * u, g.trackY - 74.0f * u, (g.trackX1 - g.trackX0) + 112.0f * u, 148.0f * u};
    const float cw = 176.0f * u, ch = 78.0f * u, gap = 18.0f * u;
    const float total = cw * kPresetCount + gap * (kPresetCount - 1);
    const float cx0 = L.w * 0.5f - total * 0.5f, cy = g.panel.y + 450.0f * u;
    for (int i = 0; i < kPresetCount; ++i) g.chip[i] = {cx0 + (cw + gap) * static_cast<float>(i), cy, cw, ch};
    const float br = 44.0f * u;
    g.minus = {g.panel.x + 40.0f * u, g.trackY - br, 2.0f * br, 2.0f * br};
    g.plus = {g.panel.x + pw - 40.0f * u - 2.0f * br, g.trackY - br, 2.0f * br, 2.0f * br};
    const float dw = 380.0f * u, dh = 88.0f * u;
    g.done = {L.w * 0.5f - dw * 0.5f, g.panel.y + ph - dh - 34.0f * u, dw, dh};
    return g;
}

int GraphicsPanel::valueAt(const Geometry& g, float x) {
    const float t = std::min(1.0f, std::max(0.0f, (x - g.trackX0) / std::max(1.0f, g.trackX1 - g.trackX0)));
    int v = static_cast<int>(std::lround(t * 100.0f));
    for (int p : {0, 25, 50, 75, 90, 100})
        if (std::abs(v - p) <= 2) v = p;   // a magnet at the values people pick
    return v;
}

bool GraphicsPanel::onTouch(int action, int id, float x, float y, const UiLayout& L, GraphicsSettings& gfx) {
    if (!open_) return false;
    const Geometry g = geometry(L);
    const int before = gfx.motionBlur;
    if (action == kTouchDown) {
        if (g.done.contains(x, y)) {
            close();
        } else if (g.sliderHit.contains(x, y)) {
            dragId_ = id;
            gfx.motionBlur = valueAt(g, x);
        } else if (g.minus.contains(x, y)) {
            gfx.motionBlur = std::max(0, ((gfx.motionBlur - 1) / 5) * 5);   // down to the next multiple of 5
        } else if (g.plus.contains(x, y)) {
            gfx.motionBlur = std::min(100, (gfx.motionBlur / 5) * 5 + 5);
        } else {
            for (int i = 0; i < kPresetCount; ++i)
                if (g.chip[i].contains(x, y)) gfx.motionBlur = kPresets[i];
        }
    } else if (action == kTouchMove) {
        if (id == dragId_) gfx.motionBlur = valueAt(g, x);
    } else if (action == kTouchUp || action == kTouchCancel) {
        if (id == dragId_) dragId_ = -1;
    }
    gfx.sanitize();
    return gfx.motionBlur != before;
}

void GraphicsPanel::draw(UiBatch& ui, const UiLayout& L, const GraphicsSettings& gfx, float time) const {
    const float u = L.u;
    const Geometry g = geometry(L);
    ui.rect(0.0f, 0.0f, L.w, L.h, Rgba8{10, 6, 24, 120});   // (light: the edges of the scene behind show the blur as it is set)
    ui.roundRect(g.panel.x, g.panel.y, g.panel.w, g.panel.h, 38.0f * u, Rgba8{26, 16, 50, 242});
    ui.roundRect(g.panel.x, g.panel.y, g.panel.w, 10.0f * u, 5.0f * u, kAccent);
    const float cx = L.w * 0.5f;
    text(ui, "GRAPHICS", cx, g.panel.y + 44.0f * u, 72.0f * u, kWhite, TextAlign::Center);

    // the label and the value
    const float lx = g.panel.x + 60.0f * u, ly = g.panel.y + 176.0f * u;
    text(ui, "MOTION BLUR", lx, ly, 46.0f * u, kWhite);
    char buf[24];
    if (gfx.motionBlur <= 0) std::snprintf(buf, sizeof(buf), "OFF");
    else std::snprintf(buf, sizeof(buf), "%d%%", gfx.motionBlur);
    text(ui, buf, g.panel.x + g.panel.w - 60.0f * u, ly - 12.0f * u, 70.0f * u, gfx.motionBlur <= 0 ? kCyan : kGold, TextAlign::Right);

    // the slider
    const float th = 18.0f * u, kr = 36.0f * u;
    const float t = gfx.blur01();
    const float kx = g.trackX0 + (g.trackX1 - g.trackX0) * t;
    ui.roundRect(g.trackX0, g.trackY - th * 0.5f, g.trackX1 - g.trackX0, th, th * 0.5f, Rgba8{255, 255, 255, 60});
    if (t > 0.004f) ui.roundRect(g.trackX0, g.trackY - th * 0.5f, std::max(th, kx - g.trackX0), th, th * 0.5f, kAccent);
    for (int p : {0, 25, 50, 75, 100}) {   // ticks
        const float tx = g.trackX0 + (g.trackX1 - g.trackX0) * static_cast<float>(p) * 0.01f;
        ui.rect(tx - 2.0f * u, g.trackY + th * 0.5f + 8.0f * u, 4.0f * u, 14.0f * u, Rgba8{255, 255, 255, 90});
    }
    ui.circle(kx, g.trackY, kr + 6.0f * u, Rgba8{0, 0, 0, 70}, 40);
    ui.circle(kx, g.trackY, kr, kWhite, 40);
    ui.circle(kx, g.trackY, kr * 0.56f, kAccent, 32);

    // - / + steppers
    for (int k = 0; k < 2; ++k) {
        const Rect& r = k == 0 ? g.minus : g.plus;
        ui.circle(r.x + r.w * 0.5f, r.y + r.h * 0.5f, r.w * 0.5f, Rgba8{255, 255, 255, 38}, 36);
        ui.rect(r.x + r.w * 0.28f, r.y + r.h * 0.5f - 3.5f * u, r.w * 0.44f, 7.0f * u, kWhite);
        if (k == 1) ui.rect(r.x + r.w * 0.5f - 3.5f * u, r.y + r.h * 0.28f, 7.0f * u, r.h * 0.44f, kWhite);
    }

    // presets
    for (int i = 0; i < kPresetCount; ++i) {
        const bool on = gfx.motionBlur == kPresets[i];
        if (kPresets[i] == 0) std::snprintf(buf, sizeof(buf), "OFF");
        else std::snprintf(buf, sizeof(buf), "%d%%", kPresets[i]);
        const Rect& r = g.chip[i];
        ui.roundRect(r.x, r.y, r.w, r.h, r.h * 0.5f, on ? kAccent : Rgba8{255, 255, 255, 36});
        text(ui, buf, r.x + r.w * 0.5f, r.y + r.h * 0.5f - 16.0f * u, 34.0f * u, on ? kInk : kWhite, TextAlign::Center);
    }

    const float dy = g.chip[0].y + g.chip[0].h + 34.0f * u;
    const char* l1 = "SMEARS THE EDGES OF THE PICTURE AT SPEED. LOWER IT TO SPOT OBSTACLES EARLIER.";
    const char* l2 = "OFF LOOKS CRISPEST AND IS THE LIGHTEST SETTING FOR A SLOWER PHONE.";
    text(ui, l1, cx, dy, fitSize(l1, 25.0f * u, g.panel.w - 100.0f * u), alpha(kWhite, 0.78f), TextAlign::Center);
    text(ui, l2, cx, dy + 38.0f * u, fitSize(l2, 25.0f * u, g.panel.w - 100.0f * u), alpha(kWhite, 0.78f), TextAlign::Center);
    (void)time;
    pill(ui, g.done, "DONE", 44.0f * u, 1.0f, true);
}

}  // namespace sd
