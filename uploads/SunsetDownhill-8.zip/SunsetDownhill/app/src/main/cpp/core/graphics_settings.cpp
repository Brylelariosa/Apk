#include "graphics_settings.h"

#include <cstdio>
#include <cstdlib>

namespace sd {

void GraphicsSettings::sanitize() {
    if (motionBlur < 0) motionBlur = 0;
    if (motionBlur > 100) motionBlur = 100;
}

std::string GraphicsSettings::serialize() const {
    char buf[24];
    const int n = std::snprintf(buf, sizeof(buf), "mb=%d", motionBlur);
    return std::string(buf, static_cast<size_t>(n > 0 ? n : 0));
}

GraphicsSettings GraphicsSettings::parse(const std::string& text) {
    GraphicsSettings g;
    size_t pos = 0;
    while (pos < text.size()) {
        size_t end = text.find(' ', pos);
        if (end == std::string::npos) end = text.size();
        const std::string token = text.substr(pos, end - pos);
        pos = end + 1;
        if (token.size() > 3 && token.compare(0, 3, "mb=") == 0) {
            char* stop = nullptr;
            const long v = std::strtol(token.c_str() + 3, &stop, 10);
            if (stop != token.c_str() + 3 && *stop == '\0') g.motionBlur = static_cast<int>(v < -1000 ? -1000 : (v > 1000 ? 1000 : v));
        }
    }
    g.sanitize();
    return g;
}

}  // namespace sd
