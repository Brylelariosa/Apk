#include "mesh_data.h"

#include <algorithm>
#include <cmath>
#include <map>
#include <utility>
#include <vector>

#include "rng.h"

namespace sd {

uint16_t MeshData::addVertex(const Vec3& p, const Vec3& n, Rgba8 c, Material m) {
    MeshVertex v;
    v.px = p.x; v.py = p.y; v.pz = p.z;
    v.nx = n.x; v.ny = n.y; v.nz = n.z;
    v.r = c.r; v.g = c.g; v.b = c.b; v.a = c.a;
    v.tint = m.tint; v.emissive = m.emissive; v.foliage = m.foliage; v.sway = m.sway;
    vertices.push_back(v);
    return static_cast<uint16_t>(vertices.size() - 1);
}

void MeshData::addTriangle(uint16_t a, uint16_t b, uint16_t c) {
    const MeshVertex &va = vertices[a], &vb = vertices[b], &vc = vertices[c];
    const Vec3 pa(va.px, va.py, va.pz), pb(vb.px, vb.py, vb.pz), pc(vc.px, vc.py, vc.pz);
    const Vec3 gn = cross(pb - pa, pc - pa);
    if (dot(gn, gn) < 1e-14f) return;  // degenerate
    const Vec3 an(va.nx + vb.nx + vc.nx, va.ny + vb.ny + vc.ny, va.nz + vb.nz + vc.nz);
    if (dot(gn, an) < 0.0f) std::swap(b, c);
    indices.push_back(a);
    indices.push_back(b);
    indices.push_back(c);
}

void MeshData::addQuad(uint16_t a, uint16_t b, uint16_t c, uint16_t d) {
    addTriangle(a, b, c);
    addTriangle(a, c, d);
}

void MeshData::addBox(const Mat4& xf, const Vec3& half, Rgba8 bottom, Rgba8 top, Material m) {
    const float h[3] = {half.x, half.y, half.z};
    const int su[4] = {-1, 1, 1, -1}, sv[4] = {-1, -1, 1, 1};
    for (int a = 0; a < 3; ++a) {
        for (int sgn = -1; sgn <= 1; sgn += 2) {
            const int u = (a + 1) % 3, v = (a + 2) % 3;
            float n[3] = {0.0f, 0.0f, 0.0f};
            n[a] = static_cast<float>(sgn);
            const Vec3 wn = normalize(xf.transformDir(Vec3(n[0], n[1], n[2])));
            uint16_t idx[4];
            for (int k = 0; k < 4; ++k) {
                float p[3];
                p[a] = static_cast<float>(sgn) * h[a];
                p[u] = static_cast<float>(su[k]) * h[u];
                p[v] = static_cast<float>(sv[k]) * h[v];
                const float t = half.y > 0.0f ? (p[1] + half.y) / (2.0f * half.y) : 0.5f;
                idx[k] = addVertex(xf.transformPoint(Vec3(p[0], p[1], p[2])), wn, mix(bottom, top, t), m);
            }
            addQuad(idx[0], idx[1], idx[2], idx[3]);
        }
    }
}

void MeshData::addFrustum(const Mat4& xf, float r0, float r1, float height, int segments, Rgba8 bottom, Rgba8 top,
                          Material m, float normalLift, bool capBottom, bool capTop) {
    const float dr = r0 - r1;
    std::vector<uint16_t> lo(static_cast<size_t>(segments)), hi(static_cast<size_t>(segments));
    for (int i = 0; i < segments; ++i) {
        const float a = kTwoPi * static_cast<float>(i) / static_cast<float>(segments);
        const float ca = std::cos(a), sa = std::sin(a);
        const Vec3 n = normalize(xf.transformDir(normalize(Vec3(ca * height, dr + normalLift * height, sa * height))));
        lo[static_cast<size_t>(i)] = addVertex(xf.transformPoint(Vec3(ca * r0, 0.0f, sa * r0)), n, bottom, m);
        hi[static_cast<size_t>(i)] = addVertex(xf.transformPoint(Vec3(ca * r1, height, sa * r1)), n, top, m);
    }
    for (int i = 0; i < segments; ++i) {
        const size_t j = static_cast<size_t>((i + 1) % segments), k = static_cast<size_t>(i);
        addQuad(lo[k], lo[j], hi[j], hi[k]);
    }
    auto cap = [&](float y, float r, float ny, Rgba8 c) {
        const Vec3 n = normalize(xf.transformDir(Vec3(0.0f, ny, 0.0f)));
        const uint16_t centre = addVertex(xf.transformPoint(Vec3(0.0f, y, 0.0f)), n, c, m);
        std::vector<uint16_t> ring(static_cast<size_t>(segments));
        for (int i = 0; i < segments; ++i) {
            const float a = kTwoPi * static_cast<float>(i) / static_cast<float>(segments);
            ring[static_cast<size_t>(i)] = addVertex(xf.transformPoint(Vec3(std::cos(a) * r, y, std::sin(a) * r)), n, c, m);
        }
        for (int i = 0; i < segments; ++i) addTriangle(centre, ring[static_cast<size_t>(i)], ring[static_cast<size_t>((i + 1) % segments)]);
    };
    if (capBottom && r0 > 0.0f) cap(0.0f, r0, -1.0f, bottom);
    if (capTop && r1 > 0.0f) cap(height, r1, 1.0f, top);
}

namespace {

struct IcoFace { int a, b, c; };
struct Icosphere {
    std::vector<Vec3> pts;
    std::vector<IcoFace> faces;
};

Icosphere makeIcosphere(int subdiv) {
    Icosphere ico;
    const float t = (1.0f + std::sqrt(5.0f)) * 0.5f;
    ico.pts = {{-1, t, 0}, {1, t, 0}, {-1, -t, 0}, {1, -t, 0}, {0, -1, t},  {0, 1, t},
               {0, -1, -t}, {0, 1, -t}, {t, 0, -1}, {t, 0, 1}, {-t, 0, -1}, {-t, 0, 1}};
    for (Vec3& p : ico.pts) p = normalize(p);
    ico.faces = {{0, 11, 5}, {0, 5, 1},  {0, 1, 7},   {0, 7, 10}, {0, 10, 11}, {1, 5, 9}, {5, 11, 4},
                 {11, 10, 2}, {10, 7, 6}, {7, 1, 8},  {3, 9, 4},  {3, 4, 2},   {3, 2, 6}, {3, 6, 8},
                 {3, 8, 9},  {4, 9, 5},  {2, 4, 11},  {6, 2, 10}, {8, 6, 7},   {9, 8, 1}};
    for (int s = 0; s < subdiv; ++s) {
        std::map<std::pair<int, int>, int> mid;
        auto midpoint = [&](int a, int b) {
            const auto key = std::make_pair(std::min(a, b), std::max(a, b));
            auto it = mid.find(key);
            if (it != mid.end()) return it->second;
            ico.pts.push_back(normalize((ico.pts[static_cast<size_t>(a)] + ico.pts[static_cast<size_t>(b)]) * 0.5f));
            const int id = static_cast<int>(ico.pts.size()) - 1;
            mid[key] = id;
            return id;
        };
        std::vector<IcoFace> next;
        for (const IcoFace& f : ico.faces) {
            const int ab = midpoint(f.a, f.b), bc = midpoint(f.b, f.c), ca = midpoint(f.c, f.a);
            next.push_back({f.a, ab, ca});
            next.push_back({f.b, bc, ab});
            next.push_back({f.c, ca, bc});
            next.push_back({ab, bc, ca});
        }
        ico.faces.swap(next);
    }
    return ico;
}

// The topology only depends on the subdivision level, so it is built once and shared (the rider asks for a dozen spheres per frame).
const Icosphere& icosphere(int subdiv) {
    static const Icosphere cache[4] = {makeIcosphere(0), makeIcosphere(1), makeIcosphere(2), makeIcosphere(3)};
    return cache[std::max(0, std::min(subdiv, 3))];
}

}  // namespace

void MeshData::addBlob(const Mat4& xf, const Vec3& radii, uint32_t seed, int subdiv, float roughness, bool flatShaded,
                       Rgba8 bottom, Rgba8 top, Material m, float flatBottom) {
    const Icosphere& ico = icosphere(subdiv);
    const std::vector<Vec3>& pts = ico.pts;
    const std::vector<IcoFace>& faces = ico.faces;
    // displace
    std::vector<Vec3> pos(pts.size());
    for (size_t i = 0; i < pts.size(); ++i) {
        const Vec3 d = pts[i];
        const uint32_t qx = static_cast<uint32_t>(static_cast<int>(std::lround(d.x * 512.0f)));
        const uint32_t qy = static_cast<uint32_t>(static_cast<int>(std::lround(d.y * 512.0f)));
        const uint32_t qz = static_cast<uint32_t>(static_cast<int>(std::lround(d.z * 512.0f)));
        const float n = hash01(hash2(hash2(seed ^ qx, qy), qz));
        const float k = 1.0f + (n - 0.5f) * 2.0f * roughness;
        Vec3 p(d.x * radii.x * k, d.y * radii.y * k, d.z * radii.z * k);
        if (flatBottom > 0.0f) p.y = std::max(p.y, -flatBottom * radii.y);
        pos[i] = p;
    }
    auto colorAt = [&](float y) {
        const float tt = radii.y > 0.0f ? saturate((y / radii.y) * 0.5f + 0.5f) : 0.5f;
        return mix(bottom, top, tt);
    };
    if (flatShaded) {
        for (const IcoFace& f : faces) {
            const Vec3 &a = pos[static_cast<size_t>(f.a)], &b = pos[static_cast<size_t>(f.b)], &c = pos[static_cast<size_t>(f.c)];
            const Vec3 n = normalize(cross(b - a, c - a));
            const Vec3 wn = normalize(xf.transformDir(n));
            const uint16_t ia = addVertex(xf.transformPoint(a), wn, colorAt(a.y), m);
            const uint16_t ib = addVertex(xf.transformPoint(b), wn, colorAt(b.y), m);
            const uint16_t ic = addVertex(xf.transformPoint(c), wn, colorAt(c.y), m);
            addTriangle(ia, ib, ic);
        }
    } else {
        std::vector<Vec3> nrm(pts.size());
        for (const IcoFace& f : faces) {
            const Vec3 n = cross(pos[static_cast<size_t>(f.b)] - pos[static_cast<size_t>(f.a)], pos[static_cast<size_t>(f.c)] - pos[static_cast<size_t>(f.a)]);
            // orient every face away from the centre so accumulated normals are consistent
            const Vec3 centre = (pos[static_cast<size_t>(f.a)] + pos[static_cast<size_t>(f.b)] + pos[static_cast<size_t>(f.c)]) * (1.0f / 3.0f);
            const Vec3 o = dot(n, centre) < 0.0f ? -n : n;
            nrm[static_cast<size_t>(f.a)] += o; nrm[static_cast<size_t>(f.b)] += o; nrm[static_cast<size_t>(f.c)] += o;
        }
        std::vector<uint16_t> ids(pts.size());
        for (size_t i = 0; i < pts.size(); ++i) {
            ids[i] = addVertex(xf.transformPoint(pos[i]), normalize(xf.transformDir(normalize(nrm[i]))), colorAt(pos[i].y), m);
        }
        for (const IcoFace& f : faces) addTriangle(ids[static_cast<size_t>(f.a)], ids[static_cast<size_t>(f.b)], ids[static_cast<size_t>(f.c)]);
    }
}

void MeshData::append(const MeshData& other, const Mat4& xf) {
    // Meshes are appended every frame (the board, the rider's parts, cars): a tight loop - one resize instead of a push_back per vertex, and the
    // normals only rescaled by one factor when the matrix is a rotation with a uniform scale (the usual case), not normalised one by one.
    const size_t base = vertices.size(), n = other.vertices.size();
    if (n == 0) return;
    vertices.resize(base + n);
    const float* m = xf.m;
    const float l0 = m[0] * m[0] + m[1] * m[1] + m[2] * m[2], l1 = m[4] * m[4] + m[5] * m[5] + m[6] * m[6], l2 = m[8] * m[8] + m[9] * m[9] + m[10] * m[10];
    const float d01 = m[0] * m[4] + m[1] * m[5] + m[2] * m[6], d02 = m[0] * m[8] + m[1] * m[9] + m[2] * m[10], d12 = m[4] * m[8] + m[5] * m[9] + m[6] * m[10];
    const bool rigid = std::fabs(l0 - l1) < 1e-4f * l0 && std::fabs(l0 - l2) < 1e-4f * l0 && std::fabs(d01) < 1e-4f * l0 && std::fabs(d02) < 1e-4f * l0 &&
                       std::fabs(d12) < 1e-4f * l0 && l0 > 1e-12f;
    const float inv = rigid ? 1.0f / std::sqrt(l0) : 1.0f;
    MeshVertex* dst = vertices.data() + base;
    for (size_t i = 0; i < n; ++i) {
        const MeshVertex& v = other.vertices[i];
        MeshVertex& o = dst[i];
        o = v;
        o.px = m[0] * v.px + m[4] * v.py + m[8] * v.pz + m[12];
        o.py = m[1] * v.px + m[5] * v.py + m[9] * v.pz + m[13];
        o.pz = m[2] * v.px + m[6] * v.py + m[10] * v.pz + m[14];
        float nx = m[0] * v.nx + m[4] * v.ny + m[8] * v.nz, ny = m[1] * v.nx + m[5] * v.ny + m[9] * v.nz, nz = m[2] * v.nx + m[6] * v.ny + m[10] * v.nz;
        if (rigid) {
            nx *= inv; ny *= inv; nz *= inv;
        } else {
            const float k = 1.0f / std::sqrt(std::max(1e-20f, nx * nx + ny * ny + nz * nz));
            nx *= k; ny *= k; nz *= k;
        }
        o.nx = nx; o.ny = ny; o.nz = nz;
    }
    const size_t ib = indices.size(), ni = other.indices.size();
    indices.resize(ib + ni);
    uint16_t* di = indices.data() + ib;
    const uint16_t off = static_cast<uint16_t>(base);
    for (size_t i = 0; i < ni; ++i) di[i] = static_cast<uint16_t>(other.indices[i] + off);
}

}  // namespace sd
