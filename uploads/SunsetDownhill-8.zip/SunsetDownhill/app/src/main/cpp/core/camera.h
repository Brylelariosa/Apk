// camera.h - chase camera that rides along the road behind the skater.
#pragma once

#include "math3d.h"
#include "skater.h"
#include "track.h"

namespace sd {

struct CameraView {
    Vec3 pos, right, up, fwd;   // absolute position + orthonormal basis
    float fovY = 1.05f;         // radians
};

class ChaseCamera {
public:
    void reset(const Track& track, const Skater& sk);
    // intro: 1 = cinematic start framing, 0 = gameplay framing. orbit: slow menu motion strength (0..1).
    void update(float dt, const Track& track, const Skater& sk, float intro, float orbit, float time);
    void addShake(float amount) { shake_ = std::max(shake_, amount); }
    const CameraView& view() const { return view_; }

private:
    CameraView view_;
    float sCam_ = 0.0f, xCam_ = 0.0f, hCam_ = 1.9f, lookX_ = 0.0f, yCam_ = 0.0f;   // yCam_: the rider's height above the road (jumps, deck)
    float roll_ = 0.0f, fov_ = 1.05f, shake_ = 0.0f;
    // flight over a gorge: the camera follows the rider's real path in world space (the road-space chase above keeps tracking underneath,
    // so it is already in place at the touchdown and the camera simply blends back to it)
    float air_ = 0.0f;
    bool flying_ = false;
    float lastS_ = 0.0f;   // (a jump in the rider's road position - leaving a chute - puts the road camera straight behind it)
    Vec3 airPos_, airTarget_;
};

}  // namespace sd
