// track.h - procedural mountain road: centre line, frames, curvature, terrain profile.
#pragma once

#include <cstdint>
#include <vector>

#include "config.h"
#include "hills.h"
#include "math3d.h"
#include "rng.h"

namespace sd {

struct TrackSample {
    Vec3 pos;          // road centre line (road surface)
    Vec3 fwd;          // unit tangent, includes pitch
    Vec3 right0;       // horizontal right vector (unbanked)
    Vec3 up0;          // unbanked surface normal
    Vec3 right, up;    // banked frame
    float s = 0.0f;
    float heading = 0.0f;    // yaw, + turns right
    float pitch = 0.0f;      // + descends
    float curvature = 0.0f;  // 1/m, + right turn
    float bank = 0.0f;       // + lowers the right edge
};

// A gorge jump. Where one side of the road is the downhill side, the road makes a U-shaped detour round a gorge: a sharp bend away from
// the straight, a leg going down the rim, a hairpin round the head of the gorge, a leg coming back up the other rim and a sharp bend
// back onto the original line. There is only ever the one road. A kicker at the cliff edge where the detour begins lets a rider who
// has the speed fly straight across the mouth of the gorge and land on the road beyond it, skipping the whole detour; everybody else
// rides the detour. Everything is a pure function of the seed, so every phone in a LAN race has the same ones.
struct ShortcutZone {
    int kind = 0;                         // 0: a gorge with a kicker. 1: a chute - an off-road ground shortcut across the mouth of the detour (no ramp, no gap)
    float detourPitchDeg = cfg::kGorgePitchDeg;   // the slope of the detour road
    float side = 1.0f;                    // +1 right, -1 left: the side the gorge is on (the kicker is at that edge of the road)
    float sRamp0 = 0.0f, sLip = 0.0f;     // the kicker: where it starts and its lip
    float rampX0 = 2.0f, rampX1 = 4.9f;   // its lateral extent (measured toward the gorge side)
    float lipHeight = cfg::kKickerHeight;
    float sBend0 = 0.0f, sBend1 = 0.0f;   // the detour: from the first bend to where the road is straight again on its original line
    float sLand = 0.0f;                   // where the flight touches down: on the road, just after the detour
    float sGorge0 = 0.0f, sGorge1 = 0.0f; // the stretch of road with the gorge cut into the ground beside it
    float xsFlight = 1.8f;                // lateral line of the flight (toward the gorge side): the same at the lip and at the landing; it leaves room
                                          // on both sides of where the rider comes down, whichever way the rider steers
    float floorY = 0.0f;                  // the gorge floor, in the same reference as roadY
    int baseIndex = 0;                    // sample index of roadY[0]
    std::vector<float> roadY;             // per sample: height of the road relative to the first one (the descent of the detour)
    float roadYAt(float s) const;
    float rampHeight(float s, float xs) const;   // xs = lateral position toward the gorge side

    // ---- chute only (see cfg::kChute*). The chute runs along the chord from the road at sLip (the start of the first bend) to the road at sLand
    // (the end of the last one): `u` metres along it, `b` metres to its right. Filled in once the road round the detour has been generated.
    bool isChute() const { return kind == 1; }
    bool chuteReady = false;
    float roadSign = 1.0f;                // the side of the chord the detour road is on (+1 = right)
    float chord = 0.0f;                   // horizontal length of the chord
    Vec3 cp0, ce0, cr0;                   // chord start (on the road, world), the horizontal unit vector along the chord and the one to its right
    float cHeading = 0.0f;                // yaw of the chord (as a road heading)
    float y0 = 0.0f, yEnd = 0.0f, slope0 = 0.0f, slope1 = 0.0f;   // ground height at both ends and the slope (dy/du) there
    float easeLen = 0.0f, midSlope = 0.0f;                          // the slope eases from the road's to midSlope over easeLen metres at each end; between it is constant
    std::vector<float> cHi;               // per 2 m of chord, from u = -cfg::kChuteBack: how far toward the road side the corridor reaches (the road's rail line)
    float groundY(float u) const;         // world height of the chute's ground u metres along the chord (the same at every lateral position)
    float slopeAt(float u) const;         // dy/du (negative: downhill)
    void window(float u, float* bLo, float* bHi) const;   // the corridor's lateral limits (in b) at u
    float lipSlope() const { return sLip > sRamp0 ? lipHeight * 1.6f / (sLip - sRamp0) : 0.0f; }   // rise per metre at the lip: what a kicker throws a rider up at
};

class Track {
public:
    enum Surface { kVoid = 0, kRoad = 1, kKicker = 2 };

    explicit Track(uint32_t seed = 1u);
    void reset(uint32_t seed);
    uint32_t seed() const { return seed_; }

    void ensureGenerated(float sMax);
    float generatedLength() const { return samples_.empty() ? 0.0f : samples_.back().s; }
    int sampleCount() const { return static_cast<int>(samples_.size()); }
    const TrackSample& sampleAt(int i) const { return samples_[static_cast<size_t>(i)]; }

    // Interpolated frame at distance s (clamped to the generated range).
    TrackSample at(float s) const;

    float curvatureAt(float s) const;
    float pitchAt(float s) const;        // + descends; negative on a climb (see hills.h)
    float basePitchAt(float s) const;    // the same without the hills and the gorge detours: the long descent the road is built on
    float detourWeight(float s, float* pitchRad = nullptr) const;   // 1 inside a detour (it goes down at a steady gentle slope), easing out over 40 m either side
    const HillProfile& hills() const { return hills_; }
    float difficultyAt(float s) const;
    float hillBias(float s) const;   // -1..1, + means the right side is the uphill side

    static float bankDrop(float lateral, float bank);
    static float insideLimit(float curvature);

    // Height of the terrain above the road plane at lateral offset d.
    float terrainHeight(float s, float d) const;
    // World position of terrain-mesh vertex (ring, column).
    Vec3 ringVertex(int ring, int col) const;
    // World position on the terrain mesh at (s, d), consistent with the rendered mesh.
    Vec3 terrainPoint(float s, float d) const;
    // Point on the banked road surface at lateral offset, plus a height above it.
    static Vec3 surfacePoint(const TrackSample& f, float lateral, float height = 0.0f);

    // ---- checkpoints (LAN races): gates on the road where a wiped-out rider is put back. They sit every cfg::kCheckpointSpacing metres and
    // keep clear of the gorge detours (a gate that would fall within cfg::kCheckpointKeepClear of one moves to before it, or after it).
    // A pure function of the seed, like everything else.
    int checkpointCount() const { return static_cast<int>(checkpoints_.size()); }
    float checkpointS(int index) const;           // road position of gate `index` (1-based; the start line is gate 0 and is not listed)
    int checkpointIndexAt(float s) const;         // how many gates lie at or behind s: the number of the last gate passed (0 = none yet)
    bool nearCheckpoint(float s, float margin) const;

    // ---- chutes (see ShortcutZone::isChute): the world point of the chute's ground at (u, b), the chord coordinates of a world point, the road
    // position nearest to a world point (the merge at the end of a chute), the bowl the chute crosses
    Vec3 chutePoint(const ShortcutZone& z, float u, float b) const { return Vec3(z.cp0.x + z.ce0.x * u + z.cr0.x * b, z.groundY(u), z.cp0.z + z.ce0.z * u + z.cr0.z * b); }
    static void toChute(const ShortcutZone& z, const Vec3& p, float* u, float* b) {
        const float dx = p.x - z.cp0.x, dz = p.z - z.cp0.z;
        *u = dx * z.ce0.x + dz * z.ce0.z;
        *b = dx * z.cr0.x + dz * z.cr0.z;
    }
    bool roadNear(const ShortcutZone& z, const Vec3& p, float* s, float* x) const;   // the road's (s, x) under / beside a world point near the end of a chute
    bool inChuteBowl(float s, const Vec3& p) const;   // does this terrain vertex of the ring at s lie in the bowl a chute crosses (where the ground is the chute's own)?
    bool chuteBlocks(float s, float d, float margin) const;   // is the road-space point (s, d) inside a chute's corridor or its entrance (scenery keeps out)?

    // ---- gorge jumps (see ShortcutZone)
    const std::vector<ShortcutZone>& shortcuts() const { return zones_; }
    const ShortcutZone* zoneAt(float s) const;   // the zone whose kicker / detour is near s, or null
    int zoneIndexAt(float s) const;              // ... and its index, or -1
    // Height (above the road plane) of whatever carries a rider at (s, x); `kind` says what it is. Where nothing does, the terrain.
    float supportHeight(float s, float x, int* kind = nullptr) const;
    // How far a grounded rider may go to either side (the rails), including the gap at the kicker.
    void lateralWindow(float s, int kind, float* lo, float* hi) const;
    bool railGap(float s, float side) const;   // no guard rail here on that side (the kicker)
    bool shortcutBlocks(float s, float d, float margin) const;
    // Is the point `p` (beside the road at s) within `limit` of a far-away part of the road (more than 45 m along it)? Round a gorge detour the
    // road folds back on itself, and scenery placed for the two parts would grow into each other there. (Needs the detour's road generated.)
    bool foldsBack(float s, const Vec3& p, float limit) const;
    float foldReach() const { return 70.0f; }   // how far before and after a detour the road can fold back on itself   // trees and rocks keep out of the kicker and the start of the flight
    int gorgeSide(float s) const;              // +1 / -1: the side of the road the gorge is on at s; 0 where there is none
    // The flight over the gorge happens in a frame laid along the straight line from the lip to where the road beyond the detour begins
    // (it goes on past that point: the road is straight there for a good way).
    struct GapFrame {
        Vec3 p0, p1;           // the lip and the road at the far end of the detour (world)
        Vec3 e0, r0;           // horizontal unit vectors: along that line and to its right
        float chordH = 1.0f;   // its horizontal length (m)
        float heading = 0.0f;  // heading of e0 (yaw, + turns right)
    };
    GapFrame gapFrameOf(const ShortcutZone& z) const;
    // A point of the flight: `u` chords along the line from the lip (more than 1 is beyond the road's start), `b` metres to the right of
    // it, `h` metres above the lip's launch point; the board is turned `rel` radians (+ right) from the line and travels `slope` metres up
    // per metre of horizontal distance. Pure function of its arguments, so the rider, the camera and the other phones in a LAN race all
    // draw the same thing.
    void gapFlightAt(const ShortcutZone& z, float u, float b, float rel, float h, float slope, Vec3* pos, Vec3* dir) const;
    // The ground under a world point somewhere over a detour: the road position (s, lateral d) of the nearest part of the road and the
    // height of the terrain / road surface there. False where there is no road to measure from.
    bool groundNear(const ShortcutZone& z, const Vec3& p, float* s, float* d, float* groundY) const;

private:
    struct Segment {
        float s0, len, k;       // start, length, peak curvature (0 = straight)
        float ramp = 0.25f;     // share of the length spent easing the curvature in, and the same again easing it out
    };

    void generateNext();
    void planUntil(float sTarget);
    bool planGorge(bool chute);   // tries to plan a detour at the end of the plan: round a gorge (with a kicker), or round a bowl a chute crosses
    void finalizeChutes();        // gives every chute whose road has been generated its ground and corridor
    void extendCheckpoints(float upTo);
    bool nearDetour(float from, float to) const;                 // does [from, to] come within hill-clearance of a gorge detour?
    float hillPitchAt(float s, float basePitch) const;           // basePitch with the hills applied (hills near a detour are skipped whole)
    float carve(float s, float d, float h) const;
    static void buildFrame(TrackSample& t);

    uint32_t seed_ = 1u;
    Rng rng_;
    std::vector<TrackSample> samples_;
    std::vector<Segment> segments_;
    std::vector<ShortcutZone> zones_;
    std::vector<float> checkpoints_;
    HillProfile hills_;
    float lastJumpBend_ = -1e6f;
    float planEnd_ = 0.0f;
    float planHeading_ = 0.0f;
    float lastDir_ = 1.0f;
    bool lastWasStraight_ = true;
    float phase_[6] = {0, 0, 0, 0, 0, 0};
};

}  // namespace sd
