package com.game.topdown;

public class Gun {
    public String name;
    public int    maxAmmo, ammo;
    public float  fireRate, damage, bulletSpeed, spread, zoom, range;
    public int    pellets, color;
    public long   reloadMs;

    // runtime state
    public boolean reloading;
    public volatile long    reloadStart, lastFireTime;

    public boolean canFireNow() {
        if (ammo <= 0 || reloading) return false;
        return System.currentTimeMillis() - lastFireTime >= (long)(1000f / fireRate);
    }
    public void markFired() { lastFireTime = System.currentTimeMillis(); }

    public void startReload() {
        if (!reloading && ammo < maxAmmo) { reloading = true; reloadStart = System.currentTimeMillis(); }
    }
    public void tick() { tick(1.0f); }
    public void tick(float reloadMult) {
        if (reloading && System.currentTimeMillis() - reloadStart >= (long)(reloadMs * reloadMult)) {
            ammo = maxAmmo; reloading = false;
        }
    }

    // ── Special-mechanic flags (read by spawnBullets) ────────────────────────
    public int     bulletBounces;   // how many wall bounces each bullet gets
    public boolean bulletPiercing;  // bullet passes through enemies
    public boolean bulletExplosive; // bullet detonates on wall/range
    public boolean bulletHoming;    // bullet steers toward enemies
    public boolean bulletGhost;     // bullet ignores walls
    public boolean bulletHookSpear; // chained spear: pull + stun on hit
    public boolean bulletAirStrike; // triggers an air strike — no real bullet

    // ── Paint Launcher: color applied to bullets ───────────────────────────────
    // 0 = normal, 1 = blue (slow), 2 = green (poison), 3 = per-shot alternating (poison first, then slow)
    public int paintBulletColor = 0;
    public int paintShotToggle  = 2;  // 2=poison first, flips to 1=slow each shot

    // ── Coin Gun: damage scales with carrier's coin wealth ─────────────────────
    public boolean coinScaling = false;

    // ── Normalised stat accessors (0–1) for HUD stat bars ─────────────────────
    static final float MAX_DMG   = 95f;
    static final float MAX_SPD   = 1700f;
    static final float MAX_RANGE = 2100f;
    static final float MAX_RATE  = 22f;

    public float statDamage()   { return Math.min(1f, damage       / MAX_DMG);   }
    public float statSpeed()    { return Math.min(1f, bulletSpeed  / MAX_SPD);   }
    public float statRange()    { return Math.min(1f, range        / MAX_RANGE); }
    public float statFireRate() { return Math.min(1f, fireRate     / MAX_RATE);  }

    public static Gun[] createAll() {
        return new Gun[]{pistol(), smg(), shotgun(), assault(), sniper(), burst(), minigun(),
                         revolver(), lmg(), plasma(),
                         bouncer(), piercer(), seeker(), blaster(),
                         paintLauncher(), coinGun(), voltChakram(), hookSpear(), airStrike()};
    }

    // 19. Air Strike – calls down 5 sequential explosions along aimed line (Pharsa SS)
    public static Gun airStrike() {
        Gun g = new Gun(); g.name = "Air Strike"; g.maxAmmo = 3; g.ammo = 3;
        g.fireRate = 0.6f; g.damage = 0f;  // damage handled per-explosion, not per-bullet
        g.bulletSpeed = 0f; g.range = 0f;
        g.pellets = 1; g.spread = 0f; g.reloadMs = 4000;
        g.color = 0xFFE040FB; g.zoom = 0.85f;
        g.bulletAirStrike = true; return g;
    }

    // 18. Hook Spear – throw a chained spear; pulls and stuns the hit enemy
    public static Gun hookSpear() {
        Gun g = new Gun(); g.name = "Hook Spear"; g.maxAmmo = 1; g.ammo = 1;
        g.fireRate = 1.5f; g.damage = 20f; g.bulletSpeed = 900f; g.range = 720f;
        g.pellets = 1; g.spread = 0.0f; g.reloadMs = 2800;
        g.color = 0xFFFF8F00; g.zoom = 0.92f;
        g.bulletHookSpear = true; return g;
    }

    // 18. Volt Chakram – spin aim stick to charge, release to launch 3 returning discs
    public static Gun voltChakram() {
        Gun g = new Gun(); g.name = "Volt Chakram"; g.maxAmmo = 3; g.ammo = 3;
        g.fireRate = 0f; g.damage = 18f; g.bulletSpeed = 0f; g.range = 660f;
        g.pellets = 1; g.spread = 0f; g.reloadMs = 100;
        g.color = 0xFF80D8FF; g.zoom = 0.92f; return g;
    }

    // 1. Pistol – normal FOV, medium range
    public static Gun pistol() {
        Gun g=new Gun(); g.name="Pistol"; g.maxAmmo=12; g.ammo=12;
        g.fireRate=3f; g.damage=34f; g.bulletSpeed=1100f; g.range=650f;
        g.pellets=1; g.spread=0.04f; g.reloadMs=1200;
        g.color=0xFF4FC3F7; g.zoom=1.0f; return g;
    }
    // 2. SMG – zoomed in, short range
    public static Gun smg() {
        Gun g=new Gun(); g.name="SMG"; g.maxAmmo=30; g.ammo=30;
        g.fireRate=10f; g.damage=14f; g.bulletSpeed=900f; g.range=620f;
        g.pellets=1; g.spread=0.12f; g.reloadMs=2000;
        g.color=0xFF81C784; g.zoom=1.2f; return g;
    }
    // 3. Shotgun – most zoomed in, very short range
    public static Gun shotgun() {
        Gun g=new Gun(); g.name="Shotgun"; g.maxAmmo=8; g.ammo=8;
        g.fireRate=1.3f; g.damage=24f; g.bulletSpeed=950f; g.range=320f;
        g.pellets=6; g.spread=0.27f; g.reloadMs=2000;
        g.color=0xFFFF8A65; g.zoom=1.35f; return g;
    }
    // 4. Assault Rifle – medium-out, good range
    public static Gun assault() {
        Gun g=new Gun(); g.name="Assault"; g.maxAmmo=25; g.ammo=25;
        g.fireRate=7.5f; g.damage=19f; g.bulletSpeed=1050f; g.range=900f;
        g.pellets=1; g.spread=0.07f; g.reloadMs=1800;
        g.color=0xFFFFB347; g.zoom=0.85f; return g;
    }
    // 5. Sniper – max zoom out, extreme range
    public static Gun sniper() {
        Gun g=new Gun(); g.name="Sniper"; g.maxAmmo=5; g.ammo=5;
        g.fireRate=0.8f; g.damage=95f; g.bulletSpeed=1700f; g.range=2100f;
        g.pellets=1; g.spread=0.005f; g.reloadMs=2800;
        g.color=0xFFCE93D8; g.zoom=0.52f; return g;
    }
    // 6. Burst – slightly out, medium range
    public static Gun burst() {
        Gun g=new Gun(); g.name="Burst"; g.maxAmmo=24; g.ammo=24;
        g.fireRate=3f; g.damage=22f; g.bulletSpeed=1080f; g.range=720f;
        g.pellets=3; g.spread=0.035f; g.reloadMs=2000;
        g.color=0xFF4DD0E1; g.zoom=0.90f; return g;
    }
    // 7. Minigun – slightly in, short-medium range
    public static Gun minigun() {
        Gun g=new Gun(); g.name="Minigun"; g.maxAmmo=120; g.ammo=120;
        g.fireRate=22f; g.damage=12f; g.bulletSpeed=1100f; g.range=600f;
        g.pellets=1; g.spread=0.22f; g.reloadMs=4500;
        g.color=0xFFFF5252; g.zoom=1.1f; return g;
    }
    // 8. Revolver – high damage per shot, medium-long range, small clip
    public static Gun revolver() {
        Gun g=new Gun(); g.name="Revolver"; g.maxAmmo=6; g.ammo=6;
        g.fireRate=2.2f; g.damage=55f; g.bulletSpeed=1200f; g.range=850f;
        g.pellets=1; g.spread=0.02f; g.reloadMs=2200;
        g.color=0xFFFFD54F; g.zoom=0.95f; return g;
    }
    // 9. LMG – large magazine, sustained suppression fire, medium range
    public static Gun lmg() {
        Gun g=new Gun(); g.name="LMG"; g.maxAmmo=80; g.ammo=80;
        g.fireRate=11f; g.damage=13f; g.bulletSpeed=980f; g.range=750f;
        g.pellets=1; g.spread=0.15f; g.reloadMs=3800;
        g.color=0xFF90A4AE; g.zoom=1.0f; return g;
    }
    // 10. Plasma Rifle – slow heavy projectile, high damage, long range
    public static Gun plasma() {
        Gun g=new Gun(); g.name="Plasma"; g.maxAmmo=15; g.ammo=15;
        g.fireRate=2.2f; g.damage=72f; g.bulletSpeed=720f; g.range=1100f;
        g.pellets=1; g.spread=0.015f; g.reloadMs=2600;
        g.color=0xFF00E5FF; g.zoom=0.78f; return g;
    }
    // 11. Bouncer – rubber bullet ricochets off walls 3 times
    public static Gun bouncer() {
        Gun g=new Gun(); g.name="Bouncer"; g.maxAmmo=8; g.ammo=8;
        g.fireRate=1.8f; g.damage=45f; g.bulletSpeed=520f; g.range=1400f;
        g.pellets=1; g.spread=0.02f; g.reloadMs=2000;
        g.color=0xFF69F0AE; g.zoom=0.90f;
        g.bulletBounces=3; return g;
    }
    // 12. Piercer – needle punches through every enemy in a line
    public static Gun piercer() {
        Gun g=new Gun(); g.name="Piercer"; g.maxAmmo=15; g.ammo=15;
        g.fireRate=2.2f; g.damage=32f; g.bulletSpeed=1450f; g.range=1000f;
        g.pellets=1; g.spread=0.004f; g.reloadMs=1800;
        g.color=0xFF40C4FF; g.zoom=0.85f;
        g.bulletPiercing=true; return g;
    }
    // 13. Seeker – homing missile; only locks on within 160px, faster travel
    public static Gun seeker() {
        Gun g=new Gun(); g.name="Seeker"; g.maxAmmo=5; g.ammo=5;
        g.fireRate=0.7f; g.damage=48f; g.bulletSpeed=700f; g.range=800f;
        g.pellets=1; g.spread=0.0f; g.reloadMs=3500;
        g.color=0xFFFF6E40; g.zoom=0.82f;
        g.bulletHoming=true; return g;
    }
    // 14. Blaster – explosive round detonates on wall/range/player (150px AOE)
    //     Bullet direct damage nerfed; explosion is the primary damage source.
    public static Gun blaster() {
        Gun g=new Gun(); g.name="Blaster"; g.maxAmmo=6; g.ammo=6;
        g.fireRate=1.2f; g.damage=30f; g.bulletSpeed=980f; g.range=650f;
        g.pellets=1; g.spread=0.03f; g.reloadMs=2200;
        g.color=0xFFFFD740; g.zoom=0.88f;
        g.bulletExplosive=true; return g;
    }
    // 15. Ghost – bullets phase through walls
    public static Gun ghost() {
        Gun g=new Gun(); g.name="Ghost"; g.maxAmmo=5; g.ammo=5;
        g.fireRate=2.5f; g.damage=22f; g.bulletSpeed=880f; g.range=200f;
        g.pellets=1; g.spread=0.02f; g.reloadMs=2800;
        g.color=0xFFEA80FC; g.zoom=1.15f;
        g.bulletGhost=true; return g;
    }
    // 16. Paint Launcher – fires one blob per shot: poison → slow → poison → ...
    public static Gun paintLauncher() {
        Gun g=new Gun(); g.name="Paint"; g.maxAmmo=14; g.ammo=14;
        g.fireRate=2.5f; g.damage=15f; g.bulletSpeed=920f; g.range=750f;
        g.pellets=1; g.spread=0.0f; g.reloadMs=1700;
        g.color=0xFF26C6DA; g.zoom=1.0f;
        // 3 = per-shot alternating: even shots = green (poison), odd shots = blue (slow)
        g.paintBulletColor=3; g.paintShotToggle=2; return g;
    }
    // 17. Coin Gun – damage scales with player wealth  (20 @ 0 coins → 120 @ 600 coins)
    public static Gun coinGun() {
        Gun g=new Gun(); g.name="Coin Gun"; g.maxAmmo=12; g.ammo=12;
        g.fireRate=3.0f; g.damage=20f; g.bulletSpeed=1150f; g.range=850f;
        g.pellets=1; g.spread=0.03f; g.reloadMs=1600;
        g.color=0xFFFFD700; g.zoom=0.92f;
        g.coinScaling=true; return g;
    }
}
