package com.game.topdown;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.*;
import android.net.wifi.WifiManager;
import android.view.*;
import org.json.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class GameView extends SurfaceView
        implements SurfaceHolder.Callback, Runnable, NetworkManager.Callback {

    // ═══ WORLD ════════════════════════════════════════════════════════════════
    static final float MAP_W = 2400, MAP_H = 2400;
    static final int   PR    = 24;
    static final long  RESPAWN_MS = 5000;

    static final float[][] WALLS = {
        {400,310,760,350}, {880,120,920,560}, {280,660,315,980},
        {560,540,920,580}, {1100,370,1460,410}, {1530,210,1570,670},
        {680,960,720,1310}, {960,840,1320,880}, {180,1160,540,1200},
        {1430,960,1470,1320}, {540,1520,1060,1560}, {1250,1360,1570,1400},
        {1700,480,1740,920}, {300,1480,340,1920}, {820,1780,1220,1820},
        {1600,1580,1640,2020},
    };
    static final float[][] SPAWNS = {
        {120,120},{2280,120},{120,2280},{2280,2280},
        {1200,120},{120,1200},{2280,1200},{1200,2280},
    };

    // ═══ STATE ════════════════════════════════════════════════════════════════
    private volatile Player   localPlayer;   // volatile: written by net thread (client join)
    private final String      savedName;
    private final Map<Integer,Player> remote   = new ConcurrentHashMap<>();
    private final Map<Integer,Long>   deadAtMs = new ConcurrentHashMap<>();
    private final List<Bullet>        bullets  = new ArrayList<>();
    private int bulletId;

    // ═══ NETWORK ══════════════════════════════════════════════════════════════
    private final NetworkManager          net;
    private final boolean                 isHost;
    private volatile String               pendingState;
    private final Map<Integer,float[]>    inputs = new ConcurrentHashMap<>();
    private long lastBroadcast;
    private String hostIpDisplay = "";  // shown in HUD

    // ═══ INPUT ════════════════════════════════════════════════════════════════
    private Joystick moveStick, aimStick;
    private RectF    switchRect, reloadRect;

    // ═══ CONTROL SETTINGS ════════════════════════════════════════════════════
    private static final String PREFS = "shooter_ctrl";
    private volatile boolean settingsOpen = false;
    private RectF   gearRect, settingsPanel, closeSettingsRect;
    private final RectF[] jsSizeOpts  = new RectF[3];
    private final RectF[] swapOpts    = new RectF[2];
    private final RectF[] btnSizeOpts = new RectF[3];
    private final RectF[] opacityOpts = new RectF[3];
    private RectF moveBtnsRect;          // "MOVE BUTTONS" button in settings

    // ═══ BUTTON DRAG ══════════════════════════════════════════════════════════
    private boolean btnMoveMode  = false; // drag-to-reposition mode
    private int     draggingBtn  = -1;    // 0=switch, 1=reload, -1=none
    private float   dragOffX, dragOffY;
    private RectF   confirmMoveRect;      // ✓ button to exit move mode

    // ═══ CAMERA ZOOM ══════════════════════════════════════════════════════════
    private float currentZoom = 1.0f;    // smoothly interpolated per-gun zoom
    private Paint settingsBgP, settingsLabelP, optBtnP, optBtnSelP, optTxtP, settingsTitleP, closeBtnP;

    // ═══ RENDER ═══════════════════════════════════════════════════════════════
    private volatile boolean  gameRunning;
    private Thread            gameThread;
    private float             screenW, screenH, camX, camY;
    private int               tick;
    private long              deathTime;

    private Paint bgP,gridP,wallP,bdrP,remP,locP,shP,hpBgP,
                  bulletP,nameP,hudP,hudBgP,btnP,btnTxtP,
                  deathBgP,deathTxtP,gunTxtP,ipPaint;

    private final List<String> feed = new ArrayList<>();

    // ═══ CTOR ═════════════════════════════════════════════════════════════════
    public GameView(Context ctx, String name, boolean host, String hostIp) {
        super(ctx);
        savedName = name;
        isHost    = host;
        net       = new NetworkManager(this);
        getHolder().addCallback(this);
        setFocusable(true);
        initPaints();

        // Get this device's WiFi IP (for the host to display)
        if (host) {
            try {
                WifiManager wm = (WifiManager) ctx.getApplicationContext()
                        .getSystemService(Context.WIFI_SERVICE);
                int ip = wm.getConnectionInfo().getIpAddress();
                hostIpDisplay = String.format("%d.%d.%d.%d",
                        ip & 0xff, (ip>>8)&0xff, (ip>>16)&0xff, (ip>>24)&0xff);
            } catch (Exception ignored) { hostIpDisplay = "???.???.???.???"; }
        }

        try {
            if (host) { net.startHost(name); spawnLocal(0, name); }
            else        net.joinGame(hostIp, name);
        } catch (Exception e) { e.printStackTrace(); }
    }

    // ═══ PAINTS ═══════════════════════════════════════════════════════════════
    private void initPaints() {
        bgP     = fill(Color.rgb(12,25,18));
        gridP   = new Paint(Paint.ANTI_ALIAS_FLAG);
        gridP.setColor(Color.argb(22,255,255,255));
        gridP.setStyle(Paint.Style.STROKE); gridP.setStrokeWidth(1f);
        wallP   = fill(Color.rgb(68,72,112));
        bdrP    = new Paint(Paint.ANTI_ALIAS_FLAG);
        bdrP.setColor(Color.rgb(100,108,170)); bdrP.setStyle(Paint.Style.STROKE); bdrP.setStrokeWidth(6f);
        remP    = fill(Color.rgb(240,88,88));
        locP    = fill(Color.rgb(80,190,255));
        shP     = fill(Color.argb(65,0,0,0));
        hpBgP   = fill(Color.rgb(38,38,38));
        bulletP = fill(Color.rgb(255,218,0));
        nameP   = fill(Color.WHITE); nameP.setTextSize(21f); nameP.setTextAlign(Paint.Align.CENTER);
        nameP.setShadowLayer(3f,1f,1f,Color.BLACK);
        hudP    = fill(Color.WHITE); hudP.setTextSize(28f);
        hudBgP  = fill(Color.argb(145,0,0,0));
        btnP    = fill(Color.argb(205,195,55,85));
        btnTxtP = fill(Color.WHITE); btnTxtP.setTextSize(22f);
        btnTxtP.setTextAlign(Paint.Align.CENTER); btnTxtP.setTypeface(Typeface.DEFAULT_BOLD);
        deathBgP  = fill(Color.argb(165,0,0,0));
        deathTxtP = fill(Color.rgb(255,55,55)); deathTxtP.setTextSize(58f);
        deathTxtP.setTextAlign(Paint.Align.CENTER);
        gunTxtP = fill(Color.WHITE); gunTxtP.setTextSize(25f); gunTxtP.setTextAlign(Paint.Align.CENTER);
        // IP display paint – large, high contrast
        ipPaint = fill(Color.rgb(255,230,80)); ipPaint.setTextSize(28f);
        ipPaint.setTextAlign(Paint.Align.CENTER); ipPaint.setTypeface(Typeface.DEFAULT_BOLD);
        ipPaint.setShadowLayer(4f,0,2f,Color.BLACK);
        // Settings overlay paints
        settingsBgP   = fill(Color.argb(235,10,15,30));
        settingsTitleP= fill(Color.WHITE); settingsTitleP.setTextSize(26f);
        settingsTitleP.setTextAlign(Paint.Align.LEFT); settingsTitleP.setTypeface(Typeface.DEFAULT_BOLD);
        settingsLabelP= fill(Color.argb(210,200,210,230)); settingsLabelP.setTextSize(20f);
        settingsLabelP.setTextAlign(Paint.Align.LEFT);
        optBtnP   = fill(Color.argb(180,40,50,80));
        optBtnSelP= fill(Color.argb(230,80,130,220));
        optTxtP   = fill(Color.WHITE); optTxtP.setTextSize(17f);
        optTxtP.setTextAlign(Paint.Align.CENTER); optTxtP.setTypeface(Typeface.DEFAULT_BOLD);
        closeBtnP = fill(Color.argb(200,180,50,60));
    }
    private Paint fill(int c){Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);p.setColor(c);p.setStyle(Paint.Style.FILL);return p;}

    // ═══ SURFACE ══════════════════════════════════════════════════════════════
    @Override public void surfaceCreated(SurfaceHolder h)  { screenW=getWidth(); screenH=getHeight(); initControls(); resume(); }
    @Override public void surfaceChanged(SurfaceHolder h,int f,int w,int hh) { screenW=w; screenH=hh; initControls(); }
    @Override public void surfaceDestroyed(SurfaceHolder h) { pause(); }

    private void initControls() {
        SharedPreferences prefs = getContext().getSharedPreferences(PREFS, 0);
        int  jsSize  = prefs.getInt    ("js_size",  1);   // 0=S 1=M 2=L
        boolean swap = prefs.getBoolean("swap",     false);
        int  btnSize = prefs.getInt    ("btn_size", 1);   // 0=S 1=M 2=L
        int  opacity = prefs.getInt    ("opacity",  1);   // 0=lo 1=med 2=hi

        // Joysticks
        float[] muls = {0.10f, 0.145f, 0.19f};
        float r = Math.min(screenW, screenH) * muls[Math.max(0, Math.min(2, jsSize))];
        float m = r + 18f;
        float lx = swap ? screenW - m : m;
        float rx = swap ? m           : screenW - m;
        moveStick = new Joystick(lx, screenH - m, r);
        aimStick  = new Joystick(rx, screenH - m, r);
        int[] alphas = {90, 160, 225};
        int alpha = alphas[Math.max(0, Math.min(2, opacity))];
        moveStick.setAlpha(alpha);
        aimStick .setAlpha(alpha);

        // Action buttons with saved position + size
        float[] bws = {120f, 160f, 210f};
        float[] bhs = { 46f,  58f,  72f};
        float bw = bws[Math.max(0, Math.min(2, btnSize))];
        float bh = bhs[Math.max(0, Math.min(2, btnSize))];
        float defBx = screenW - bw - 14f;
        float bx = prefs.getFloat("btn_x", defBx);
        float by = prefs.getFloat("btn_y", 14f);
        bx = Math.max(0, Math.min(screenW - bw,     bx));
        by = Math.max(0, Math.min(screenH - bh*2-8, by));
        switchRect = new RectF(bx,     by,        bx+bw, by+bh);
        reloadRect = new RectF(bx,     by+bh+8f,  bx+bw, by+bh*2+8f);

        // Gear button
        gearRect = new RectF(12, screenH-72, 72, screenH-12);

        // Confirm-move button (shown only in btnMoveMode)
        confirmMoveRect = new RectF(screenW/2-70, screenH-90, screenW/2+70, screenH-30);

        // Settings panel
        float pw = Math.min(520f, screenW - 48f);
        float ph = 460f;
        float px = (screenW - pw) / 2f;
        float py = (screenH - ph) / 2f;
        settingsPanel     = new RectF(px, py, px+pw, py+ph);
        closeSettingsRect = new RectF(px+pw-54, py+8, px+pw-8, py+52);

        float optX = px + pw * 0.47f;
        float obw=72f, obh=42f, og=8f;
        float[] rowY = {py+78f, py+152f, py+226f, py+300f};
        for(int i=0;i<3;i++) jsSizeOpts[i]  = new RectF(optX+i*(obw+og), rowY[0], optX+i*(obw+og)+obw, rowY[0]+obh);
        for(int i=0;i<2;i++) swapOpts[i]    = new RectF(optX+i*(obw+og), rowY[1], optX+i*(obw+og)+obw, rowY[1]+obh);
        for(int i=0;i<3;i++) btnSizeOpts[i] = new RectF(optX+i*(obw+og), rowY[2], optX+i*(obw+og)+obw, rowY[2]+obh);
        for(int i=0;i<3;i++) opacityOpts[i] = new RectF(optX+i*(obw+og), rowY[3], optX+i*(obw+og)+obw, rowY[3]+obh);
        float mbY = py + 374f;
        moveBtnsRect = new RectF(px+20, mbY, px+pw-20, mbY+48f);
    }

    // ═══ TOUCH ════════════════════════════════════════════════════════════════
    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int act=e.getActionMasked(), idx=e.getActionIndex(), pid=e.getPointerId(idx);
        float x=e.getX(idx), y=e.getY(idx);

        // Settings overlay absorbs all input when open
        if (settingsOpen) {
            if (act == MotionEvent.ACTION_DOWN || act == MotionEvent.ACTION_POINTER_DOWN) {
                if (closeSettingsRect != null && closeSettingsRect.contains(x, y)) {
                    settingsOpen = false; return true;
                }
                handleSettingsTap(x, y);
            }
            return true;
        }

        // Button-move mode: drag switch/reload buttons, tap ✓ to save
        if (btnMoveMode) {
            switch(act) {
                case MotionEvent.ACTION_DOWN:
                case MotionEvent.ACTION_POINTER_DOWN:
                    if (confirmMoveRect != null && confirmMoveRect.contains(x, y)) {
                        // Save position and exit move mode
                        SharedPreferences.Editor ed = getContext().getSharedPreferences(PREFS, 0).edit();
                        if (switchRect != null) { ed.putFloat("btn_x", switchRect.left); ed.putFloat("btn_y", switchRect.top); }
                        ed.apply();
                        btnMoveMode = false; draggingBtn = -1; break;
                    }
                    if (switchRect != null && switchRect.contains(x, y)) { draggingBtn=0; dragOffX=x-switchRect.left; dragOffY=y-switchRect.top; }
                    else if (reloadRect != null && reloadRect.contains(x, y)) { draggingBtn=1; dragOffX=x-reloadRect.left; dragOffY=y-reloadRect.top; }
                    break;
                case MotionEvent.ACTION_MOVE:
                    if (draggingBtn >= 0 && switchRect != null && reloadRect != null) {
                        float bw = switchRect.width(), bh = switchRect.height();
                        float nx = Math.max(0, Math.min(screenW - bw, x - dragOffX));
                        float ny = Math.max(0, Math.min(screenH - bh*2 - 8, y - dragOffY));
                        switchRect.offsetTo(nx, ny);
                        reloadRect.offsetTo(nx, ny + bh + 8f);
                    }
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_POINTER_UP:
                    draggingBtn = -1; break;
            }
            return true;
        }

        switch(act){
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN:
                if(gearRect!=null&&gearRect.contains(x,y)){settingsOpen=true;break;}
                if(switchRect!=null&&switchRect.contains(x,y)){switchGun();break;}
                if(reloadRect!=null&&reloadRect.contains(x,y)){reload();break;}
                if(!moveStick.onTouchDown(pid,x,y)) aimStick.onTouchDown(pid,x,y);
                break;
            case MotionEvent.ACTION_MOVE:
                for(int i=0;i<e.getPointerCount();i++){
                    int p2=e.getPointerId(i);
                    moveStick.onTouchMove(p2,e.getX(i),e.getY(i));
                    aimStick.onTouchMove(p2,e.getX(i),e.getY(i));
                }
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP:
                moveStick.onTouchUp(pid); aimStick.onTouchUp(pid); break;
        }
        return true;
    }

    private void handleSettingsTap(float x, float y) {
        SharedPreferences.Editor ed = getContext().getSharedPreferences(PREFS, 0).edit();
        for(int i=0;i<3;i++) if(jsSizeOpts[i]!=null&&jsSizeOpts[i].contains(x,y)){ed.putInt("js_size",i);ed.apply();initControls();return;}
        for(int i=0;i<2;i++) if(swapOpts[i]!=null&&swapOpts[i].contains(x,y)){ed.putBoolean("swap",i==1);ed.apply();initControls();return;}
        for(int i=0;i<3;i++) if(btnSizeOpts[i]!=null&&btnSizeOpts[i].contains(x,y)){ed.putInt("btn_size",i);ed.apply();initControls();return;}
        for(int i=0;i<3;i++) if(opacityOpts[i]!=null&&opacityOpts[i].contains(x,y)){ed.putInt("opacity",i);ed.apply();initControls();return;}
        if(moveBtnsRect!=null&&moveBtnsRect.contains(x,y)){settingsOpen=false;btnMoveMode=true;return;}
    }

    private void switchGun(){if(localPlayer!=null&&localPlayer.alive) localPlayer.gunIndex=(localPlayer.gunIndex+1)%localPlayer.guns.length;}
    private void reload()   {if(localPlayer!=null&&localPlayer.alive) localPlayer.currentGun().startReload();}

    // ═══ LOOP ═════════════════════════════════════════════════════════════════
    public synchronized void resume(){
        if(gameRunning) return;
        gameRunning=true;
        gameThread=new Thread(this,"GameLoop"); gameThread.start();
    }
    public synchronized void pause(){
        gameRunning=false;
        if(gameThread!=null) try{gameThread.join(700);}catch(InterruptedException ignored){}
        gameThread=null;
    }
    public void stopGame(){ pause(); net.stop(); }

    @Override public void run(){
        long prev=System.nanoTime();
        while(gameRunning){
            long now=System.nanoTime();
            float dt=Math.min((now-prev)/1e9f,0.08f); prev=now;
            update(dt); render();
            long sleep=16_666_000L-(System.nanoTime()-now);
            if(sleep>0) try{Thread.sleep(sleep/1_000_000,(int)(sleep%1_000_000));}catch(InterruptedException ig){}
        }
    }

    // ═══ UPDATE ═══════════════════════════════════════════════════════════════
    private void update(float dt){
        tick++;
        if(!isHost && pendingState!=null){ applyState(pendingState); pendingState=null; }

        Player lp = localPlayer;  // snapshot reference — safe
        if(lp==null) return;

        if(lp.alive) for(Gun g:lp.guns) g.tick();

        if(isHost&&!lp.alive&&System.currentTimeMillis()-deathTime>=RESPAWN_MS)
            respawn(lp);

        if(lp.alive) moveAndAim(lp, dt);

        updateBullets(lp, dt);

        if(isHost){
            applyClientInputs(dt);
            checkRemoteRespawns();
            if(System.currentTimeMillis()-lastBroadcast>50){ broadcast(); lastBroadcast=System.currentTimeMillis(); }
        } else {
            if(tick%2==0) sendInput(lp);
        }

        // Smooth per-weapon zoom
        float targetZoom = (lp.alive) ? lp.currentGun().zoom : 1.0f;
        currentZoom += (targetZoom - currentZoom) * 0.07f;
        camX = lp.x - screenW / (2f * currentZoom);
        camY = lp.y - screenH / (2f * currentZoom);
    }

    private void moveAndAim(Player lp, float dt){
        if(moveStick==null||aimStick==null) return;
        float nx=lp.x+moveStick.getX()*280f*dt;
        float ny=lp.y+moveStick.getY()*280f*dt;
        nx=clamp(nx,PR,MAP_W-PR); ny=clamp(ny,PR,MAP_H-PR);
        float[] pos=walls(lp.x,lp.y,nx,ny);
        lp.x=pos[0]; lp.y=pos[1];

        float ax=aimStick.getX(), ay=aimStick.getY();
        if(ax*ax+ay*ay>0.01f) lp.angle=(float)Math.atan2(ay,ax);

        if(aimStick.isActive()){
            Gun g=lp.currentGun();
            if(g.canFireNow()){ spawnBullets(lp); g.markFired(); }
        }
    }

    private float[] walls(float ox,float oy,float nx,float ny){
        for(float[] w:WALLS){
            float cx=clamp(nx,w[0],w[2]), cy=clamp(ny,w[1],w[3]);
            if(d2(nx,ny,cx,cy)<PR*PR){
                float cx2=clamp(nx,w[0],w[2]), cy2=clamp(oy,w[1],w[3]);
                if(d2(nx,oy,cx2,cy2)<PR*PR) nx=ox;
                float cx3=clamp(ox,w[0],w[2]), cy3=clamp(ny,w[1],w[3]);
                if(d2(ox,ny,cx3,cy3)<PR*PR) ny=oy;
            }
        }
        return new float[]{nx,ny};
    }

    private void spawnBullets(Player p){
        Gun g=p.guns[p.gunIndex];
        if(g.ammo<=0) return;
        g.ammo--;
        for(int i=0;i<g.pellets;i++){
            float s=(float)(Math.random()-0.5)*g.spread*2, a=p.angle+s;
            float spd=g.bulletSpeed*(0.96f+(float)Math.random()*0.08f);
            bullets.add(new Bullet(p.x,p.y,(float)Math.cos(a)*spd,(float)Math.sin(a)*spd,p.id,g.damage,bulletId++));
        }
    }

    private void updateBullets(Player lp, float dt){
        Iterator<Bullet> it=bullets.iterator();
        while(it.hasNext()){
            Bullet b=it.next();
            b.x+=b.dx*dt; b.y+=b.dy*dt;
            boolean rm=false;
            if(b.x<0||b.x>MAP_W||b.y<0||b.y>MAP_H) rm=true;
            if(!rm) for(float[] w:WALLS)
                if(b.x>=w[0]&&b.x<=w[2]&&b.y>=w[1]&&b.y<=w[3]){rm=true;break;}
            if(!rm&&System.currentTimeMillis()-b.spawnTime>1800) rm=true;
            if(!rm&&isHost){
                if(lp.alive&&b.ownerId!=lp.id&&d2(b.x,b.y,lp.x,lp.y)<PR*PR){
                    lp.hp=Math.max(0,lp.hp-b.damage); rm=true;
                    if(lp.hp==0){lp.alive=false;deathTime=System.currentTimeMillis();addFeed(nameOf(b.ownerId)+" ➜ "+lp.name);}
                }
                if(!rm) for(Player rp:remote.values()){
                    if(b.ownerId==rp.id||!rp.alive) continue;
                    if(d2(b.x,b.y,rp.x,rp.y)<PR*PR){
                        rp.hp=Math.max(0,rp.hp-b.damage); rm=true;
                        if(rp.hp==0){rp.alive=false;deadAtMs.put(rp.id,System.currentTimeMillis());addFeed(nameOf(b.ownerId)+" ➜ "+rp.name);}
                        break;
                    }
                }
            }
            if(rm) it.remove();
        }
    }

    private void applyClientInputs(float dt){
        for(Map.Entry<Integer,float[]> e:inputs.entrySet()){
            Player p=remote.get(e.getKey()); if(p==null||!p.alive) continue;
            float[] inp=e.getValue();
            float nx=p.x+inp[0]*280f*dt, ny=p.y+inp[1]*280f*dt;
            nx=clamp(nx,PR,MAP_W-PR); ny=clamp(ny,PR,MAP_H-PR);
            float[] pos=walls(p.x,p.y,nx,ny); p.x=pos[0]; p.y=pos[1];
            if(inp[2]*inp[2]+inp[3]*inp[3]>0.01f) p.angle=(float)Math.atan2(inp[3],inp[2]);
            p.gunIndex=Math.max(0,Math.min((int)inp[5], p.guns.length-1));
            if(inp[6]>0.5f) p.guns[p.gunIndex].startReload();
            for(Gun g:p.guns) g.tick();
            if(inp[4]>0.5f){ Gun g=p.currentGun(); if(g.canFireNow()){spawnBullets(p);g.markFired();} }
        }
    }

    private void checkRemoteRespawns(){
        long now=System.currentTimeMillis();
        for(Player p:remote.values())
            if(!p.alive&&deadAtMs.containsKey(p.id)&&now-deadAtMs.get(p.id)>=RESPAWN_MS){
                respawn(p); deadAtMs.remove(p.id);
            }
    }

    private void respawn(Player p){
        float[] sp=SPAWNS[p.id%SPAWNS.length]; p.x=sp[0]; p.y=sp[1];
        p.hp=100; p.alive=true; p.guns=Gun.createAll(); p.gunIndex=0;
    }
    private void spawnLocal(int id, String name){
        Player p=new Player(); p.id=id; p.name=name; p.guns=Gun.createAll();
        float[] sp=SPAWNS[id%SPAWNS.length]; p.x=sp[0]; p.y=sp[1];
        localPlayer=p;
    }

    // ═══ RENDER ═══════════════════════════════════════════════════════════════
    private void render(){
        Canvas c=getHolder().lockCanvas(); if(c==null) return;
        try{ doDraw(c); }finally{ getHolder().unlockCanvasAndPost(c); }
    }

    private void doDraw(Canvas c){
        c.drawRect(0,0,c.getWidth(),c.getHeight(),bgP);
        c.save();
        c.scale(currentZoom, currentZoom);   // per-weapon camera zoom
        c.translate(-camX,-camY);

        for(float x=0;x<=MAP_W;x+=120) c.drawLine(x,0,x,MAP_H,gridP);
        for(float y=0;y<=MAP_H;y+=120) c.drawLine(0,y,MAP_W,y,gridP);
        c.drawRect(0,0,MAP_W,MAP_H,bdrP);

        for(float[] w:WALLS) c.drawRect(w[0],w[1],w[2],w[3],wallP);
        for(Bullet b:bullets) c.drawCircle(b.x,b.y,5f,bulletP);
        for(Player p:remote.values()) drawPlayer(c,p,false);
        Player lp=localPlayer;
        if(lp!=null) drawPlayer(c,lp,true);
        c.restore();

        drawHUD(c);
    }

    private void drawPlayer(Canvas c, Player p, boolean local){
        if(!p.alive){
            Paint xp=new Paint(Paint.ANTI_ALIAS_FLAG);
            xp.setColor(Color.argb(160,230,50,50)); xp.setStyle(Paint.Style.STROKE); xp.setStrokeWidth(4f);
            c.drawLine(p.x-13,p.y-13,p.x+13,p.y+13,xp);
            c.drawLine(p.x+13,p.y-13,p.x-13,p.y+13,xp); return;
        }
        float r=PR;
        c.drawCircle(p.x+4,p.y+4,r,shP);
        c.drawCircle(p.x,p.y,r,local?locP:remP);
        float gl=r+20f;
        Paint gp=new Paint(Paint.ANTI_ALIAS_FLAG);
        int barrelCol = local ? p.currentGun().color : Color.rgb(255,135,135);
        gp.setColor(barrelCol);
        gp.setStyle(Paint.Style.STROKE); gp.setStrokeWidth(7f); gp.setStrokeCap(Paint.Cap.ROUND);
        c.drawLine(p.x,p.y,p.x+(float)Math.cos(p.angle)*gl,p.y+(float)Math.sin(p.angle)*gl,gp);
        float bw=50f,bh=6f,bx=p.x-25f,by=p.y-r-14f;
        c.drawRoundRect(bx,by,bx+bw,by+bh,3,3,hpBgP);
        float fr=Math.max(0,p.hp/100f);
        Paint hpP=new Paint(Paint.ANTI_ALIAS_FLAG); hpP.setStyle(Paint.Style.FILL);
        hpP.setColor(fr>0.5f?Color.rgb(50,220,50):fr>0.25f?Color.rgb(240,175,0):Color.rgb(230,50,50));
        c.drawRoundRect(bx,by,bx+bw*fr,by+bh,3,3,hpP);
        c.drawText(p.name,p.x,p.y-r-17f,nameP);
    }

    private void drawHUD(Canvas c){
        Player lp=localPlayer; if(lp==null) return;
        float w=screenW, h=screenH;

        // ── HP ────────────────────────────────────────────────────────────────
        c.drawRoundRect(10,10,215,56,8,8,hudBgP);
        hudP.setColor(Color.rgb(255,75,75)); hudP.setTextSize(27f); hudP.setTextAlign(Paint.Align.LEFT);
        c.drawText("♥ "+(int)Math.ceil(lp.hp), 22, 46, hudP);

        // ── Gun + ammo ────────────────────────────────────────────────────────
        if(lp.alive){
            Gun g=lp.currentGun();
            String gs=g.name+"  "+(g.reloading?"RELOADING…":g.ammo+"/"+g.maxAmmo);
            c.drawRoundRect(w/2-175,10,w/2+175,54,8,8,hudBgP);
            gunTxtP.setColor(g.color);
            c.drawText(gs,w/2,43,gunTxtP);
        }

        // ── HOST: show IP so others can join ──────────────────────────────────
        if(isHost && !hostIpDisplay.isEmpty()){
            int count=remote.size()+1;
            String ipLine="Your IP: "+hostIpDisplay+"   Players: "+count;
            float bgW=ipPaint.measureText(ipLine)+24f;
            c.drawRoundRect(w/2-bgW/2,h-52,w/2+bgW/2,h-4,10,10,hudBgP);
            c.drawText(ipLine, w/2, h-14, ipPaint);
        }

        // ── Kill feed ─────────────────────────────────────────────────────────
        hudP.setColor(Color.rgb(255,210,70)); hudP.setTextSize(18f); hudP.setTextAlign(Paint.Align.LEFT);
        synchronized(feed){ for(int i=0;i<feed.size();i++) c.drawText(feed.get(i),12,72+i*24,hudP); }

        // ── Death overlay ─────────────────────────────────────────────────────
        if(!lp.alive){
            c.drawRect(0,0,w,h,deathBgP);
            c.drawText("YOU DIED",w/2,h/2-18,deathTxtP);
            long rem=RESPAWN_MS-(System.currentTimeMillis()-deathTime);
            if(rem>0){
                Paint t2=new Paint(deathTxtP); t2.setTextSize(28f); t2.setColor(Color.WHITE);
                t2.setTextAlign(Paint.Align.CENTER);
                c.drawText("Respawning in "+(rem/1000+1)+"s",w/2,h/2+38,t2);
            }
        }

        // ── Buttons ───────────────────────────────────────────────────────────
        c.drawRoundRect(switchRect,10,10,btnP);
        c.drawText("SWITCH GUN",switchRect.centerX(),switchRect.centerY()+8,btnTxtP);
        c.drawRoundRect(reloadRect,10,10,btnP);
        c.drawText("RELOAD",reloadRect.centerX(),reloadRect.centerY()+8,btnTxtP);

        // ── Gear button ───────────────────────────────────────────────────────
        if(gearRect!=null){
            Paint gearBg=fill(Color.argb(settingsOpen?210:140,40,50,80));
            c.drawRoundRect(gearRect,10,10,gearBg);
            Paint gearTxt=new Paint(Paint.ANTI_ALIAS_FLAG);
            gearTxt.setColor(Color.WHITE); gearTxt.setTextSize(26f);
            gearTxt.setTextAlign(Paint.Align.CENTER);
            c.drawText("⚙",gearRect.centerX(),gearRect.centerY()+10,gearTxt);
        }

        // ── Joysticks ─────────────────────────────────────────────────────────
        if(moveStick!=null) moveStick.draw(c);
        if(aimStick!=null)  aimStick.draw(c);

        // ── Button-move mode overlay ───────────────────────────────────────────
        if(btnMoveMode){
            Paint dimP = fill(Color.argb(120,0,0,0));
            c.drawRect(0,0,w,h,dimP);
            // Redraw buttons with highlight
            Paint hlP = fill(Color.argb(220,80,160,255));
            if(switchRect!=null){ c.drawRoundRect(switchRect,10,10,hlP); c.drawText("SWITCH GUN",switchRect.centerX(),switchRect.centerY()+8,btnTxtP); }
            if(reloadRect!=null){ c.drawRoundRect(reloadRect,10,10,hlP); c.drawText("RELOAD",reloadRect.centerX(),reloadRect.centerY()+8,btnTxtP); }
            // Instruction label
            Paint infoP = fill(Color.WHITE); infoP.setTextSize(20f); infoP.setTextAlign(Paint.Align.CENTER);
            infoP.setShadowLayer(3f,0,2f,Color.BLACK);
            c.drawText("Drag buttons to reposition", w/2, h/2 - 20, infoP);
            // Confirm button
            if(confirmMoveRect!=null){
                Paint confP = fill(Color.argb(230,50,190,90));
                c.drawRoundRect(confirmMoveRect,12,12,confP);
                Paint confTxt = new Paint(btnTxtP); confTxt.setTextSize(24f);
                c.drawText("✓  DONE", confirmMoveRect.centerX(), confirmMoveRect.centerY()+9, confTxt);
            }
        }

        // ── Settings overlay ──────────────────────────────────────────────────
        if(settingsOpen) drawSettings(c);
    }

    // ═══ SETTINGS OVERLAY ════════════════════════════════════════════════════
    private void drawSettings(Canvas c) {
        if(settingsPanel==null) return;
        SharedPreferences prefs = getContext().getSharedPreferences(PREFS, 0);
        int  jsSize  = prefs.getInt    ("js_size",  1);
        boolean swap = prefs.getBoolean("swap",     false);
        int  btnSize = prefs.getInt    ("btn_size", 1);
        int  opacity = prefs.getInt    ("opacity",  1);

        // Panel background + border
        c.drawRoundRect(settingsPanel, 16, 16, settingsBgP);
        Paint border = new Paint(Paint.ANTI_ALIAS_FLAG);
        border.setColor(Color.argb(160,80,120,200)); border.setStyle(Paint.Style.STROKE); border.setStrokeWidth(2f);
        c.drawRoundRect(settingsPanel, 16, 16, border);

        float px = settingsPanel.left, py = settingsPanel.top;
        float pw = settingsPanel.width();

        c.drawText("⚙  CONTROLS", px+20, py+42, settingsTitleP);

        c.drawRoundRect(closeSettingsRect, 8, 8, closeBtnP);
        Paint cTxt = new Paint(optTxtP); cTxt.setTextSize(20f);
        c.drawText("✕", closeSettingsRect.centerX(), closeSettingsRect.centerY()+7, cTxt);

        Paint div = fill(Color.argb(60,255,255,255));
        c.drawRect(px+16, py+58, px+pw-16, py+60, div);

        // Row labels
        String[] labels = {"JOYSTICK SIZE","SWAP SIDES","BUTTON SIZE","OPACITY"};
        float[] rowY = {py+78f, py+152f, py+226f, py+300f};
        for(int r=0;r<4;r++) c.drawText(labels[r], px+20, rowY[r]+28, settingsLabelP);

        String[] jsLabels = {"S","M","L"};
        for(int i=0;i<3;i++) drawOpt(c, jsSizeOpts[i],  jsLabels[i], i==jsSize);
        String[] swLabels = {"OFF","ON"};
        for(int i=0;i<2;i++) drawOpt(c, swapOpts[i],    swLabels[i], i==(swap?1:0));
        String[] bsLabels = {"S","M","L"};
        for(int i=0;i<3;i++) drawOpt(c, btnSizeOpts[i], bsLabels[i], i==btnSize);
        String[] opLabels = {"LO","MED","HI"};
        for(int i=0;i<3;i++) drawOpt(c, opacityOpts[i], opLabels[i], i==opacity);

        // MOVE BUTTONS button
        if(moveBtnsRect!=null){
            Paint mbP = fill(Color.argb(210,60,110,190));
            c.drawRoundRect(moveBtnsRect, 10, 10, mbP);
            Paint mbTxt = new Paint(optTxtP); mbTxt.setTextSize(19f); mbTxt.setColor(Color.WHITE);
            c.drawText("✥  MOVE BUTTONS", moveBtnsRect.centerX(), moveBtnsRect.centerY()+7, mbTxt);
        }
    }

    private void drawOpt(Canvas c, RectF r, String label, boolean selected) {
        if(r==null) return;
        c.drawRoundRect(r, 8, 8, selected ? optBtnSelP : optBtnP);
        Paint t = new Paint(optTxtP);
        if(selected) { t.setColor(Color.WHITE); } else { t.setColor(Color.argb(180,200,210,230)); }
        c.drawText(label, r.centerX(), r.centerY()+7, t);
    }

    // ═══ NETWORK SERIALIZE ════════════════════════════════════════════════════
    private void broadcast(){
        try{
            JSONObject root=new JSONObject();
            JSONArray pa=new JSONArray();
            Player lp=localPlayer; if(lp!=null) pa.put(pj(lp));
            for(Player p:remote.values()) pa.put(pj(p));
            root.put("p",pa);
            JSONArray ba=new JSONArray();
            for(Bullet b:bullets){
                JSONObject bj=new JSONObject();
                bj.put("x",(int)b.x); bj.put("y",(int)b.y);
                bj.put("u",(int)b.dx); bj.put("v",(int)b.dy);
                bj.put("o",b.ownerId); bj.put("d",(int)b.damage); bj.put("i",b.id);
                ba.put(bj);
            }
            root.put("b",ba);
            net.broadcastState(root.toString());
        }catch(Exception e){ e.printStackTrace(); }
    }
    private JSONObject pj(Player p) throws Exception {
        JSONObject o=new JSONObject();
        o.put("i",p.id); o.put("n",p.name);
        o.put("x",(int)p.x); o.put("y",(int)p.y);
        o.put("a",(double)p.angle);
        o.put("h",(int)p.hp); o.put("g",p.gunIndex); o.put("v",p.alive);
        return o;
    }
    private void applyState(String json){
        try{
            JSONObject root=new JSONObject(json);
            JSONArray pa=root.getJSONArray("p");
            for(int i=0;i<pa.length();i++){
                JSONObject o=pa.getJSONObject(i);
                int id=o.getInt("i"); boolean alive=o.getBoolean("v");
                Player lp=localPlayer;
                if(lp!=null&&id==lp.id){
                    boolean was=lp.alive;
                    lp.hp=o.getInt("h"); lp.alive=alive;
                    if(was&&!alive) deathTime=System.currentTimeMillis();
                    continue;
                }
                Player p=remote.get(id);
                if(p==null){p=new Player();p.id=id;p.guns=Gun.createAll();remote.put(id,p);}
                p.name=o.getString("n"); p.x=o.getInt("x"); p.y=o.getInt("y");
                p.angle=(float)o.getDouble("a"); p.hp=o.getInt("h");
                p.gunIndex=o.getInt("g"); p.alive=alive;
            }
            JSONArray ba=root.getJSONArray("b");
            bullets.clear();
            for(int i=0;i<ba.length();i++){
                JSONObject bj=ba.getJSONObject(i);
                bullets.add(new Bullet(bj.getInt("x"),bj.getInt("y"),
                    bj.getInt("u"),bj.getInt("v"),
                    bj.getInt("o"),bj.getInt("d"),bj.getInt("i")));
            }
        }catch(Exception e){ e.printStackTrace(); }
    }
    private void sendInput(Player lp){
        try{
            JSONObject o=new JSONObject();
            o.put("0",moveStick.getX()); o.put("1",moveStick.getY());
            o.put("2",aimStick.getX());  o.put("3",aimStick.getY());
            o.put("4",aimStick.isActive());
            o.put("5",lp.gunIndex);
            o.put("6",lp.currentGun().reloading);
            net.sendInput(o.toString());
        }catch(Exception e){ e.printStackTrace(); }
    }

    // ═══ CALLBACKS ════════════════════════════════════════════════════════════
    @Override public void onHostDiscovered(String ip,String n){}
    @Override public void onJoined(int id){
        // Network thread — just assign (volatile reference, atomic)
        Player p=new Player(); p.id=id; p.name=savedName; p.guns=Gun.createAll();
        float[] sp=SPAWNS[id%SPAWNS.length]; p.x=sp[0]; p.y=sp[1];
        localPlayer=p;
    }
    @Override public void onPlayerJoined(int id,String name){
        if(remote.containsKey(id)) return;
        Player p=new Player(); p.id=id; p.name=name; p.guns=Gun.createAll();
        float[] sp=SPAWNS[id%SPAWNS.length]; p.x=sp[0]; p.y=sp[1];
        remote.put(id,p); addFeed(name+" joined");
    }
    @Override public void onStateUpdate(String json){ pendingState=json; }
    @Override public void onInputReceived(int pid,String json){
        try{
            JSONObject o=new JSONObject(json);
            inputs.put(pid,new float[]{
                (float)o.getDouble("0"),(float)o.getDouble("1"),
                (float)o.getDouble("2"),(float)o.getDouble("3"),
                o.getBoolean("4")?1f:0f,(float)o.getInt("5"),o.getBoolean("6")?1f:0f
            });
        }catch(Exception e){ e.printStackTrace(); }
    }

    // ═══ UTIL ═════════════════════════════════════════════════════════════════
    private static float d2(float ax,float ay,float bx,float by){float dx=ax-bx,dy=ay-by;return dx*dx+dy*dy;}
    private static float clamp(float v,float lo,float hi){return Math.max(lo,Math.min(hi,v));}
    private String nameOf(int id){
        Player lp=localPlayer; if(lp!=null&&id==lp.id) return lp.name;
        Player p=remote.get(id); return p!=null?p.name:"P"+id;
    }
    private void addFeed(String msg){
        synchronized(feed){feed.add(0,msg);if(feed.size()>4)feed.remove(feed.size()-1);}
    }
}
