/* AI Empire Tycoon - tab panels */
(function () {
  'use strict';
  const G = window.G, D = G.D, U = G.U, S = G.scene, UI = G.ui, h = U.h, K = G.K;
  const I = UI.I, T = UI.T, CL = UI.CL, ST = UI.ST, DIS = UI.DIS, bind = UI.bind, btn = UI.btn, bar = UI.bar, setBar = UI.setBar, tile = UI.tile, sec = UI.sec;
  const col = (style) => ({ display: 'flex', flexDirection: 'column', flex: 1, minHeight: 0, ...(style || {}) });
  const head = (title, sub, right) => h('div', { class: 'ph' }, h('div', {}, h('div', { class: 'ptitle' }, title), sub ? h('div', { class: 'psub' }, sub) : null), right || null);
  const tabs2 = (list, cur, set) => h('div', { class: 'tabs2' }, list.map((x) => h('button', { class: cur === x[0] ? 'on' : '', onclick: () => { set(x[0]); UI.refresh(); G.audio.sfx('tap'); } }, x[1])));
  const seg = (list, cur, onset) => { const el = h('div', { class: 'seg' }, list.map((n, i) => h('button', { class: cur === i ? 'on' : '', onclick: () => { onset(i); el.querySelectorAll('button').forEach((b, j) => b.classList.toggle('on', j === i)); G.audio.sfx('tap'); } }, n))); return el; };

  /* ======================= AI MODELS ======================= */
  function arpuEst(m) {
    const C = G.C, s = G.state, conv = C.F.premium ? K.conv0 * C.M.conv * (0.5 + s.sat / 100) : 0;
    const ads = s.ads ? K.adsRpu * (1 + 0.15 * (m.gen - 1)) * (1 - conv) : 0;
    const subs = (conv * m.fair) / G.MONTH;
    const api = C.F.api ? (K.apiRate * C.M.api * K.apiBase * Math.pow((m.intel * C.M.intel) / 10, 0.55)) / G.MONTH : 0;
    return (ads + subs + api) * C.M.rev * C.arpuMul;
  }
  const RANGE = { intel: 1800, speed: 300, appeal: 0.8 };
  const logBar = (v, max) => U.clamp(Math.log10(1 + Math.max(0, v)) / Math.log10(1 + max), 0.04, 1);
  const fmtAppeal = (a) => (a * 100).toFixed(a < 0.01 ? 2 : 1) + '%';
  function modelStats(m) {
    const s = G.state, C = G.C, ms = s.models[m.id], tune = (ms && ms.tune) || 0;
    return { tune, intel: m.intel * (1 + 0.08 * tune) * C.M.intel, speed: m.speed * (1 + 0.05 * tune), appeal: Math.min(0.8, m.adopt * (1 + 0.05 * tune) * C.M.appeal) };
  }
  // Three plain meters (intelligence, speed, popularity). With a reference model the difference to it is shown in green/red.
  function statRows(m, ref) {
    const a = modelStats(m), r = ref ? modelStats(ref) : null;
    const row = (label, v, max, text, rv, unit) => {
      const b = bar('vio'); setBar(b, logBar(v, max));
      const d = r ? v - rv : 0;
      const delta = r && Math.abs(d) > 1e-9 ? h('span', { class: 'dl ' + (d > 0 ? 'up' : 'dn') }, (d > 0 ? '+' : '−') + unit(Math.abs(d))) : null;
      return h('div', { class: 'mm' }, h('span', { class: 'mml' }, label), b, h('span', { class: 'mmv' }, text, delta));
    };
    return h('div', { class: 'mms' },
      row('Intelligence', a.intel, RANGE.intel, U.num(a.intel), r && r.intel, (x) => U.num(x)),
      row('Speed', a.speed, RANGE.speed, Math.round(a.speed) + ' words/s', r && r.speed, (x) => String(Math.round(x))),
      row('Popularity', a.appeal, RANGE.appeal, fmtAppeal(a.appeal), r && r.appeal, (x) => fmtAppeal(x)));
  }
  function econ(m) {
    const C = G.C;
    return h('div', {}, h('div', { class: 'econ-h' }, 'For every 1 million users'),
      h('div', { class: 'grid3' },
        tile('Earns', h('div', { class: 'tv pos' }, U.money(arpuEst(m) * 1e6) + '/s')),
        tile('Costs', h('div', { class: 'tv neg' }, U.money(m.op * 1e6) + '/s')),
        tile('Server use', h('div', { class: 'tv' }, U.tf(m.cpu * 1e6 * C.M.dem)))));
  }
  function mhead(m, badge) {
    const ms = G.state.models[m.id], st = G.modelStatus(m.id);
    return h('div', { class: 'mhead' }, h('div', { class: 'ico' + (st === 'locked' ? ' dim' : st === 'rel' && m.id === G.state.active ? '' : ' vio') }, I(m.icon, 20)),
      h('div', { class: 'grow' }, h('div', { class: 'h3' }, m.name + (ms && ms.tune ? '  +' + ms.tune : '')), h('div', { class: 'xs mut' }, 'Generation ' + m.gen + ' · ' + m.tag)),
      badge ? h('span', { class: 'badge ' + badge[1] }, badge[0]) : null);
  }
  // The first thing that stops a model from being trained (null when it is ready).
  function lockWhy(m) {
    const s = G.state;
    const miss = m.req.find((r) => !s.res.done[r]);
    if (miss) return { t: 'Research ' + D.rmap[miss].name + ' first.', short: 'Research ' + D.rmap[miss].name, go: 'research', label: 'Open Research' };
    if (m.gen > 1) {
      const p = D.models[m.gen - 2], ps = G.modelStatus(p.id);
      if (ps !== 'rel') return { t: ps === 'trained' ? 'Release ' + p.name + ' first.' : ps === 'training' ? p.name + ' is still training.' : 'Train and release ' + p.name + ' first.', short: p.name + ' released' };
    }
    return null;
  }
  // Why an action that needs cash and free server power cannot be started right now (null when it can).
  function whyNot(cost, tf) {
    const s = G.state, C = G.C;
    if (s.job) return { t: 'The lab is busy ' + (s.job.kind === 'tune' ? 'fine-tuning ' : 'training ') + D.mmap[s.job.id].name + '.' };
    if (s.cash < cost) return { t: 'You need ' + U.money(cost - s.cash) + ' more cash.' };
    const have = C.capEff - C.ctf;
    if (have < tf) return { t: 'Not enough free server power: needs ' + U.tf(tf) + ', you have ' + U.tf(Math.max(0, have)) + '.', go: { tab: 'upgrades', cat: 'servers' }, label: 'Add servers' };
    return null;
  }
  const actionBlock = UI.actionBlock; // a button that explains why it is disabled (widgets.js)
  function jobBar(m, kind) {
    const pb = bar('vio lg anim'), eta = h('b', { class: 'vio' });
    const box = h('div', { class: 'col' }, h('div', { class: 'row between sm' }, h('span', {}, kind === 'tune' ? 'Fine-tuning in progress' : 'Training in progress'), eta), pb);
    bind(pb, () => { const j = G.state.job; if (j) { setBar(pb, 1 - j.left / j.total); T(eta, Math.floor((1 - j.left / j.total) * 100) + '% · ' + U.dur(j.left / G.C.M.trainSpeed) + ' left'); } });
    return box;
  }
  function tuneBlock(m, full) {
    const ti = G.tuneInfo(m.id), tune = modelStats(m).tune, C = G.C;
    const box = h('div', { class: 'col gap8' });
    box.append(h('div', { class: 'row between sm' }, h('span', { class: 'mut' }, 'Fine-tuning level'), h('span', { class: 'row gap4' }, h('span', { class: 'pips' }, [0, 1, 2, 3, 4].map((i) => h('i', { class: i < tune ? 'on' : '' }))), h('b', {}, tune + '/5'))));
    if (!ti) { if (tune >= 5) box.append(h('span', { class: 'badge good' }, 'FULLY TUNED')); return box; }
    if (full) box.append(h('div', { class: 'xs dimt' }, 'Each level makes this model 8% smarter and 5% faster.'));
    const blk = actionBlock('Fine-tune', 'gauge', '', () => { const t2 = G.tuneInfo(m.id); return t2 ? whyNot(t2.cost, t2.tf) : { t: 'Fully tuned.' }; }, () => UI.act(() => G.act.tune(m.id), 'train'));
    blk.firstChild._l.after(h('span', { class: 'sub' }, '· ' + U.money(ti.cost) + ' · ' + U.dur(ti.time / C.M.trainSpeed)));
    box.append(blk);
    return box;
  }
  /* full-size cards */
  function releaseCard(m, live) {
    const card = h('div', { class: 'card mcard ready' });
    card.append(mhead(m, ['READY TO RELEASE', 'gold']), statRows(m, live));
    const b = btn('Release ' + m.name, { cls: 'gold blk', icon: 'rocket', onclick: () => { G.audio.init(); const r = G.act.release(m.id); if (!r.ok) G.audio.sfx('err'); } });
    card.append(h('div', { class: 'xs mut' }, 'Training is done. Release it to make it your live model and bring in a surge of new users.'), b);
    return card;
  }
  function trainingCard(m, live) {
    const card = h('div', { class: 'card mcard trn' });
    card.append(mhead(m, ['TRAINING', 'vio']), jobBar(m, 'new'), statRows(m, live));
    const j = G.state.job;
    card.append(h('div', { class: 'xs dimt' }, 'Using ' + U.tf(j ? j.tf : m.tf) + ' of your server power until it finishes. Your service keeps running.'));
    return card;
  }
  function nextCard(m, live) {
    const C = G.C, st = G.modelStatus(m.id);
    const card = h('div', { class: 'card mcard' });
    card.append(mhead(m, st === 'ready' ? ['AVAILABLE', 'acc'] : ['LOCKED', '']), statRows(m, live), econ(m));
    if (st === 'locked') card.append(h('div', { class: 'col gap4' }, G.modelReqs(m.id).map((r) => h('div', { class: 'req' + (r.ok ? ' ok' : '') }, I(r.ok ? 'check' : 'lock', 14), r.text))));
    const cost = G.trainCost(m), dur = m.time / C.M.trainSpeed;
    card.append(h('div', { class: 'grid3' }, tile('Cost', h('div', { class: 'tv gold' }, U.money(cost))), tile('Time', h('div', { class: 'tv' }, U.dur(dur))), tile('Reserves', h('div', { class: 'tv' }, U.tf(m.tf)))));
    const note = h('div', { class: 'xs dimt' });
    bind(note, () => { const have = G.C.capEff - G.C.ctf, after = G.C.demand > 0 ? U.clamp((have - m.tf) / G.C.demand, 0, 1) : 1; T(note, 'While training it reserves ' + U.tf(m.tf) + ' of server power' + (have >= m.tf ? ', so ' + Math.round(after * 100) + '% of your users are still served.' : '.')); });
    card.append(note);
    card.append(actionBlock('Train ' + m.name, 'play', 'pri', () => { const lw = lockWhy(m); return lw || whyNot(cost, m.tf); }, () => UI.act(() => G.act.train(m.id), 'train')));
    return card;
  }
  function liveCard(m) {
    const card = h('div', { class: 'card mcard hl' });
    card.append(mhead(m, ['LIVE', 'acc']), statRows(m, null));
    const earn = h('div', { class: 'xs mut' });
    bind(earn, () => T(earn, 'Right now: ' + U.num(G.C.served) + ' users served · earning ' + U.money(G.C.rev.total) + '/s'));
    card.append(earn);
    const j = G.state.job;
    if (j && j.kind === 'tune' && j.id === m.id) card.append(jobBar(m, 'tune'));
    card.append(tuneBlock(m, true));
    const ms = G.state.models[m.id];
    if (ms && ms.rev) card.append(h('div', { class: 'xs dimt' }, 'Lifetime revenue ' + U.money(ms.rev)));
    return card;
  }
  /* compact rows */
  function ownedRow(m) {
    const a = modelStats(m), live = D.mmap[G.state.active];
    const ti = G.tuneInfo(m.id);
    const acts = h('div', { class: 'row gap4' }, btn('Deploy', { cls: 'sm', onclick: () => UI.act(() => G.act.deploy(m.id), 'tap') }));
    if (ti) { const f = btn('Tune', { cls: 'sm ghost', onclick: () => UI.act(() => G.act.tune(m.id), 'train') }); bind(f, () => { const t2 = G.tuneInfo(m.id); DIS(f, !t2 || !!whyNot(t2.cost, t2.tf)); }); acts.append(f); }
    const saves = live ? (live.op - m.op) * 1e6 : 0;
    return h('div', { class: 'mrow' }, h('div', { class: 'ico vio' }, I(m.icon, 18)),
      h('div', { class: 'grow' }, h('div', { class: 'sm b' }, m.name + (a.tune ? '  +' + a.tune : '')), h('div', { class: 'xs mut' }, 'Intelligence ' + U.num(a.intel) + ' · ' + U.num(a.speed) + ' words/s'),
        saves > 0 ? h('div', { class: 'xs good' }, 'Saves ' + U.money(saves) + '/s per 1M users') : null), acts);
  }
  function laterRow(m) {
    const lw = lockWhy(m);
    return h('div', { class: 'mrow dimr' }, h('div', { class: 'ico dim' }, I('lock', 16)),
      h('div', { class: 'grow' }, h('div', { class: 'sm b' }, m.name), h('div', { class: 'xs dimt' }, 'Generation ' + m.gen + ' · ' + m.tag)),
      h('span', { class: 'xs dimt tr later-n' }, lw ? lw.short : 'Ready'));
  }
  const secH = (title, right) => h('div', { class: 'sech full' }, h('span', {}, title), right || null);
  function modelsHelp() {
    const step = (ic, title, text) => h('div', { class: 'step' }, h('div', { class: 'ico' }, I(ic, 18)), h('div', {}, h('div', { class: 'sm b' }, title), h('div', { class: 'xs mut' }, text)));
    UI.modal(h('div', { class: 'col gap12' }, h('h2', {}, 'How models work'),
      step('play', '1. Train', 'Pick the next model. It costs cash and uses some of your server power while it trains. Your service keeps running.'),
      step('rocket', '2. Release', 'A trained model does nothing until you release it. Releasing makes it your live model and brings a surge of new users.'),
      step('gauge', '3. Fine-tune', 'Make your live model a little smarter and faster, up to five times. Cheaper than a new model.'),
      step('refresh', '4. Deploy', 'Switch your live model back to an older one to cut running costs.')));
  }
  UI.tabs.models = function () {
    const s = G.state;
    const root = h('div', { class: 'tab-split', style: col() });
    /* hero: the AI lab. One place that always says what the lab is doing. */
    const cv = h('canvas');
    const title = h('div', { class: 'labt' }), sub = h('div', { class: 'labs' }), coreIc = h('div', { class: 'labcore' });
    let coreKey = '';
    const srvPct = h('b', { class: 'labsrv-v' }), srvBar = bar('thin');
    const srv = h('button', { class: 'labsrv', type: 'button', 'aria-label': 'Server load. Open Upgrades', onclick: () => { G.audio.init(); G.audio.sfx('tap'); UI.follow({ tab: 'upgrades', cat: 'servers' }); } },
      srvPct, h('div', { class: 'labsrv-l' }, 'of servers in use'), srvBar);
    const pb = bar('vio lg anim'), eta = h('b', { class: 'vio' }), etaL = h('span', { class: 'mut' }, 'Progress');
    const prog = h('div', { class: 'labprog' }, h('div', { class: 'row between xs', style: { marginBottom: '4px' } }, etaL, eta), pb);
    const relB = btn('Release', { cls: 'gold blk', icon: 'rocket', onclick: () => { const id = relB._id; if (!id) return; G.audio.init(); const r = G.act.release(id); if (!r.ok) G.audio.sfx('err'); } });
    const hero = h('div', { class: 'labhero' }, cv,
      h('div', { class: 'labtop' }, h('div', { class: 'labtl' }, h('div', { class: 'micro' }, 'AI lab'), title, sub), srv),
      coreIc, h('div', { class: 'labov' }, prog, relB));
    bind(hero, () => {
      const j = G.state.job, C = G.C;
      const rdy = D.models.find((m) => G.modelStatus(m.id) === 'trained');
      const live = D.mmap[G.state.active] || D.models[0];
      const maxGen = Math.max(...D.models.filter((m) => (G.state.models[m.id] || {}).st).map((m) => m.gen));
      let icon, mode;
      if (j) {
        mode = 'train'; icon = D.mmap[j.id].icon;
        const p = 1 - j.left / j.total;
        T(title, (j.kind === 'new' ? 'Training ' : 'Fine-tuning ') + D.mmap[j.id].name);
        T(sub, 'Using ' + U.tf(j.tf) + ' of your server power');
        setBar(pb, p); T(eta, Math.floor(p * 100) + '% · ' + U.dur(j.left / C.M.trainSpeed) + ' left');
        G.lab.set({ gen: maxGen, prog: p, active: true, ready: false });
      } else if (rdy) {
        mode = 'ready'; icon = rdy.icon;
        T(title, rdy.name + ' is ready!'); T(sub, 'Release it to bring in new users.');
        relB._id = rdy.id; T(relB._l, 'Release ' + rdy.name);
        G.lab.set({ gen: maxGen, prog: 1, active: false, ready: true });
      } else {
        mode = 'idle'; icon = live.icon;
        T(title, 'Lab is free'); T(sub, 'Pick a model below to train or improve.');
        G.lab.set({ gen: maxGen, prog: 0, active: false, ready: false });
      }
      prog.hidden = mode !== 'train'; relB.hidden = mode !== 'ready';
      hero.dataset.mode = mode;
      if (mode + icon !== coreKey) { coreKey = mode + icon; coreIc.textContent = ''; coreIc.append(I(icon, 26)); }
      const u = Math.min(9.99, C.util);
      T(srvPct, Math.round(u * 100) + '%'); setBar(srvBar, Math.min(1, u));
      srvBar.classList.toggle('bad', u > 1); srvBar.classList.toggle('good', u <= 0.8);
    });
    /* the list, sorted by what you can act on: release -> training -> next model -> live model -> other models -> later */
    const panel = h('div', { class: 'panel cols', 'data-keep': 'models' });
    const all = D.models.map((m) => ({ m, st: G.modelStatus(m.id) }));
    const trained = all.filter((x) => x.st === 'trained').map((x) => x.m);
    const training = all.filter((x) => x.st === 'training').map((x) => x.m);
    const pending = all.filter((x) => x.st === 'ready' || x.st === 'locked').map((x) => x.m);
    const live = D.mmap[s.active] || D.models[0];
    const next = !trained.length && !training.length ? pending[0] : null;
    const later = pending.filter((m) => m !== next);
    const others = all.filter((x) => x.st === 'rel' && x.m !== live).map((x) => x.m).reverse();
    const help = h('button', { class: 'linkb', type: 'button', onclick: () => { G.audio.sfx('tap'); modelsHelp(); } }, I('info', 14), 'How it works');
    if (trained.length) { panel.append(secH('Ready to release')); trained.forEach((m) => panel.append(releaseCard(m, live))); }
    if (training.length) { panel.append(secH('In training')); training.forEach((m) => panel.append(trainingCard(m, live))); }
    if (next) { panel.append(secH('Next model', help)); panel.append(nextCard(next, live)); }
    panel.append(secH('Your live model', next ? null : help)); panel.append(liveCard(live));
    if (others.length) { panel.append(secH('Other models you own')); panel.append(h('div', { class: 'card full mlist' }, others.map(ownedRow))); }
    if (later.length) {
      const shown = UI.st.laterAll ? later : later.slice(0, 3);
      panel.append(secH('Coming later', later.length > 3 ? h('button', { class: 'linkb', type: 'button', onclick: () => { UI.st.laterAll = !UI.st.laterAll; UI.refresh(); } }, UI.st.laterAll ? 'Show less' : 'Show all ' + later.length) : null));
      panel.append(h('div', { class: 'card full mlist' }, shown.map(laterRow)));
    }
    if (s.hist.length) {
      panel.append(secH('Release history'), h('div', { class: 'card col full' }, s.hist.slice().reverse().slice(0, 12).map((x) => h('div', { class: 'row between sm' }, h('span', { class: 'row' }, I(D.mmap[x.id].icon, 16), D.mmap[x.id].name + ' released'), h('span', { class: 'dimt xs' }, U.num(x.users) + ' users · ' + U.dur((s.gt - x.gt)) + ' ago')))));
    }
    root.append(hero, panel);
    setTimeout(() => { G.lab.init(cv); G.lab.visible = true; }, 0);
    return root;
  };

  /* ======================= RESEARCH ======================= */
  const CW = 94, RH = 94, PX = 18, PY = 46;
  function laneVars(c) {
    return { '--lc': c, '--lc-a': U.rgba(c, 0.12), '--lc-b': U.rgba(c, 0.25), '--lc-c': U.rgba(c, 0.38), '--lc-d': U.rgba(c, 0.3), '--lc-e': U.rgba(c, 0.4), '--lc-f': U.mix('#101938', c, 0.36), '--lc-g': U.mix('#101938', c, 0.18), '--lc-h': U.rgba(c, 0.55), '--lc-i': U.rgba(c, 0.22) };
  }
  function researchSheet(id) {
    const n = D.rmap[id], s = G.state, lane = D.laneMap[n.lane];
    const stt = G.researchStatus(id);
    let m;
    const body = h('div', { class: 'col gap12' });
    body.append(h('div', { class: 'row' }, h('div', { class: 'ico', style: { color: lane.color, background: 'rgba(255,255,255,.06)' } }, I(n.icon || lane.icon, 22)), h('div', {}, h('div', { class: 'micro', style: { color: lane.color } }, lane.name), h('h2', {}, n.name))),
      h('div', { class: 'mut' }, n.desc));
    const fx = D.effText(n.eff);
    if (fx.length) body.append(h('div', { class: 'card' }, h('div', { class: 'micro' }, 'EFFECTS'), h('div', { class: 'col gap4', style: { marginTop: '6px' } }, fx.map((x) => h('div', { class: 'row acc sm' }, I('check', 14), x)))));
    const reqs = G.researchReqs(id);
    if (reqs.length) body.append(h('div', { class: 'col gap4' }, reqs.map((r) => h('div', { class: 'req' + (r.ok ? ' ok' : '') }, I(r.ok ? 'check' : 'lock', 14), r.text))));
    const cost = G.researchCost(n);
    body.append(h('div', { class: 'grid2' }, tile('Cost', h('div', { class: 'tv gold' }, U.money(cost))), tile('Time', h('div', { class: 'tv' }, U.dur(n.time / G.C.M.resSpeed)))));
    if (stt === 'done') body.append(h('span', { class: 'badge good' }, 'RESEARCHED'));
    else if (stt === 'active') {
      const p = s.res.q.find((x) => x.id === id), pb = bar('gold lg anim'), eta = h('b', { class: 'gold' });
      body.append(h('div', { class: 'col' }, h('div', { class: 'row between sm' }, h('span', {}, 'Researching'), eta), pb));
      bind(pb, () => { setBar(pb, 1 - p.left / p.total); T(eta, U.dur(p.left / G.C.M.resSpeed)); });
    } else {
      const b = btn('Start research', { cls: 'pri blk', icon: 'research', onclick: () => { const r = UI.act(() => G.act.research(id), 'tap'); if (r.ok) m.close(); } });
      bind(b, () => DIS(b, stt !== 'ready' || G.state.cash < cost || G.state.res.q.length >= G.C.resSlots));
      body.append(b);
      if (G.state.res.q.length >= G.C.resSlots && stt === 'ready') body.append(h('div', { class: 'xs warn tc' }, 'All research slots are busy.'));
    }
    m = UI.modal(body);
  }
  UI.tabs.research = function () {
    const s = G.state;
    const root = h('div', { style: col() });
    const slots = h('span', { class: 'badge acc' });
    root.append(head('Research', 'Five branches of technology', slots));
    bind(slots, () => T(slots, G.state.res.q.length + '/' + G.C.resSlots + ' active · x' + G.C.M.resSpeed.toFixed(2) + ' speed'));
    const active = s.res.q.map((p) => { const n = D.rmap[p.id], pb = bar('gold thin'), eta = h('span', { class: 'xs gold' }); const r = h('div', { class: 'row', style: { padding: '8px 14px 0' } }, I(n.icon || 'research', 16), h('span', { class: 'sm b grow' }, n.name), eta); bind(pb, () => { setBar(pb, 1 - p.left / p.total); T(eta, U.dur(p.left / G.C.M.resSpeed)); }); return h('div', {}, r, h('div', { style: { padding: '4px 14px 0' } }, pb)); });
    if (active.length) root.append(h('div', {}, active));
    const maxX = Math.max(...D.research.map((n) => n.x)) + 1;
    const wpx = maxX * CW + PX * 2, hpx = 10 * RH + PY;
    const inner = h('div', { class: 'tree-in', style: { width: wpx + 'px', height: hpx + 'px' } });
    for (const l of D.lanes) inner.append(h('div', { class: 'lane', style: Object.assign({ top: l.y * RH + PY - 32 + 'px', height: l.rows * RH + 'px' }, laneVars(l.color)) }, h('span', { class: 'lane-l' }, l.name)));
    const NS = 'http://www.w3.org/2000/svg';
    const svg = document.createElementNS(NS, 'svg');
    svg.setAttribute('class', 'edges'); svg.setAttribute('width', wpx); svg.setAttribute('height', hpx);
    const cx = (n) => PX + n.x * CW + 31, cy = (n) => PY + n.y * RH + 31;
    for (const n of D.research) for (const rq of n.req) {
      const a = D.rmap[rq], cross = a.lane !== n.lane;
      const p = document.createElementNS(NS, 'path');
      let d;
      if (n.x > a.x) {
        const x1 = cx(a) + 31, y1 = cy(a), x2 = cx(n) - 31, y2 = cy(n), dx = Math.max(24, Math.abs(x2 - x1) / 2);
        d = 'M' + x1 + ' ' + y1 + ' C' + (x1 + dx) + ' ' + y1 + ' ' + (x2 - dx) + ' ' + y2 + ' ' + x2 + ' ' + y2;
      } else {
        const down = cy(n) > cy(a), x1 = cx(a), y1 = cy(a) + (down ? 31 : -31), x2 = cx(n), y2 = cy(n) + (down ? -31 : 31), dy = Math.max(20, Math.abs(y2 - y1) / 2);
        d = 'M' + x1 + ' ' + y1 + ' C' + x1 + ' ' + (y1 + (down ? dy : -dy)) + ' ' + x2 + ' ' + (y2 + (down ? -dy : dy)) + ' ' + x2 + ' ' + y2;
      }
      p.setAttribute('d', d);
      const done = s.res.done[rq] && s.res.done[n.id], act = s.res.q.some((q) => q.id === n.id), lc = D.laneMap[n.lane].color;
      p.setAttribute('stroke', done ? lc : act ? '#f6b84a' : s.res.done[rq] ? lc + '99' : 'rgba(150,175,235,.2)');
      if (cross) { p.setAttribute('stroke-width', '1.4'); p.setAttribute('opacity', done ? '.55' : '.4'); if (!act) p.setAttribute('stroke-dasharray', '3 5'); }
      if (act) p.setAttribute('class', 'dash');
      svg.append(p);
    }
    inner.append(svg);
    for (const n of D.research) {
      const stt = G.researchStatus(n.id), lane = D.laneMap[n.lane];
      const circ = 2 * Math.PI * 33;
      const node = h('button', { class: 'node ' + stt, type: 'button', style: Object.assign({ left: PX + n.x * CW + 'px', top: PY + n.y * RH + 'px' }, laneVars(lane.color)), onclick: () => { G.audio.init(); G.audio.sfx('tap'); researchSheet(n.id); } }, I(n.icon || lane.icon, 24), h('span', { class: 'nl' }, n.name));
      if (stt === 'done') node.append(h('span', { class: 'chk' }, I('check', 12)));
      if (stt === 'locked') node.append(h('span', { class: 'lk' }, I('lock', 11)));
      if (stt === 'active') {
        const p = s.res.q.find((q) => q.id === n.id);
        node.insertAdjacentHTML('afterbegin', '<svg class="ring" viewBox="0 0 72 72"><circle cx="36" cy="36" r="33" fill="none" stroke="rgba(255,255,255,.1)" stroke-width="3"/><circle class="rp" cx="36" cy="36" r="33" fill="none" stroke="#f6b84a" stroke-width="3.5" stroke-linecap="round" stroke-dasharray="' + circ + '" stroke-dashoffset="' + circ + '"/></svg>');
        const rp = node.querySelector('.rp');
        bind(node, () => ST(rp, 'strokeDashoffset', String(circ * (p.left / p.total))));
      }
      if (stt === 'ready') bind(node, () => CL(node, 'afford', G.state.cash >= G.researchCost(n) && G.state.res.q.length < G.C.resSlots));
      if (UI.st.burst === n.id) { node.classList.add('burst'); UI.st.burst = null; }
      inner.append(node);
    }
    root.append(h('div', { class: 'tree', 'data-keep': 'tree' }, inner));
    return root;
  };

  /* ======================= BUSINESS ======================= */
  function bizStrategy() {
    const s = G.state, out = [];
    // price
    const price = h('b', { class: 'gold' }), conv = h('span', { class: 'xs mut' }), fairL = h('span', { class: 'xs acc' });
    const inp = h('input', { type: 'range', min: 1, max: 100, value: s.price });
    const upMax = () => { inp.max = Math.max(40, Math.ceil(G.C.fair * 3)); };
    upMax();
    inp.addEventListener('input', () => { G.act.setPrice(+inp.value); G.calc(); });
    const pcard = h('div', { class: 'card col' }, h('div', { class: 'row between' }, h('div', { class: 'micro' }, 'PREMIUM PRICE'), price), inp, h('div', { class: 'row between' }, fairL, conv),
      h('div', { class: 'xs dimt' }, 'Higher prices earn more per subscriber but fewer people subscribe. Stay near the fair price for your model.'),
      btn('Set to fair price', { cls: 'sm', onclick: () => { G.act.setPrice(Math.round(G.C.fair)); inp.value = G.state.price; G.calc(); } }));
    bind(pcard, () => { upMax(); T(price, '$' + G.state.price + ' / month'); T(fairL, 'Fair price ≈ $' + Math.round(G.C.fair)); T(conv, G.C.st.premium ? (G.C.conv * 100).toFixed(1) + '% subscribe' : 'Premium locked'); });
    out.push(pcard);
    // ads
    const ads = seg(['Ads off', 'Ads on'], s.ads ? 1 : 0, (i) => G.act.setAds(i === 1));
    out.push(h('div', { class: 'card col' }, h('div', { class: 'micro' }, 'ADVERTISING'), ads, h('div', { class: 'xs dimt' }, 'Ads earn from free users but lower satisfaction and slow growth a little.')));
    // marketing
    const mkt = seg(['Off', 'Light', 'Regional', 'National', 'Global'], s.mkt, (i) => G.act.setMkt(i));
    const mk = h('div', { class: 'xs mut' });
    out.push(h('div', { class: 'card col' }, h('div', { class: 'micro' }, 'MARKETING'), mkt, mk));
    bind(mk, () => T(mk, 'Spends ' + Math.round(K.mkt[G.state.mkt] * 100) + '% of revenue · users grow ' + K.mktG[G.state.mkt] + 'x faster'));
    const rd = seg(['Off', 'Lean', 'Focused', 'All-in'], s.rd, (i) => G.act.setRd(i));
    const rl = h('div', { class: 'xs mut' });
    out.push(h('div', { class: 'card col' }, h('div', { class: 'micro' }, 'R&D BUDGET'), rd, rl));
    bind(rl, () => T(rl, 'Spends ' + Math.round(K.rd[G.state.rd] * 100) + '% of revenue · research ' + K.rdSpd[G.state.rd] + 'x faster'));
    return out;
  }
  function bizMarket() {
    const out = [];
    const sb = h('div', { class: 'stack' }, [0, 1, 2, 3, 4].map(() => h('i')));
    const lg = h('div', { class: 'legend' }, [0, 1, 2, 3, 4].map(() => h('div', { class: 'li' }, h('span', { class: 'dotc' }), h('span', { class: 'mut' }), h('b'))));
    bind(sb, () => G.C.shares.forEach((x, i) => { ST(sb.children[i], 'width', (x.share * 100).toFixed(1) + '%'); ST(sb.children[i], 'background', x.color); const li = lg.children[i]; ST(li.children[0], 'background', x.color); T(li.children[1], x.name); T(li.children[2], (x.share * 100).toFixed(1) + '%'); }));
    out.push(h('div', { class: 'card col' }, h('div', { class: 'micro' }, 'MARKET SHARE'), sb, lg, h('div', { class: 'xs dimt' }, 'Share depends on your model intelligence, satisfaction, marketing and launch hype compared with rivals. Share sets how many people choose you.')));
    for (const c of D.comps) {
      const k = G.state.comp[c.id], pb = bar(), tx = h('b'), lb = h('span', { class: 'badge' });
      out.push(h('div', { class: 'card col' }, h('div', { class: 'row' }, h('div', { class: 'dotc', style: { background: c.color } }), h('div', { class: 'grow' }, h('div', { class: 'h3' }, c.name), h('div', { class: 'xs mut' }, c.style)), lb), h('div', { class: 'row between sm' }, h('span', { class: 'mut' }, 'Model intelligence'), tx), pb));
      bind(pb, () => { const kk = G.state.comp[c.id]; setBar(pb, kk.intel / Math.max(G.C.intel, kk.intel, 1)); T(tx, U.num(kk.intel)); T(lb, kk.buzz > 0.35 ? 'JUST LAUNCHED' : kk.launches + ' launches'); lb.className = 'badge ' + (kk.buzz > 0.35 ? 'gold' : ''); });
    }
    out.push(h('div', { class: 'card xs mut' }, 'Respond to rivals by releasing better models, fine-tuning, lowering your price, raising marketing or opening new regions.'));
    return out;
  }
  function bizPartners() {
    const s = G.state, out = [];
    const hd = h('div', { class: 'card row' }, h('div', { class: 'ico gold' }, I('doc', 20)), h('div', { class: 'grow' }, h('div', { class: 'h3' }, 'Enterprise partnerships'), h('div', { class: 'xs mut' }, 'Large companies pay a steady monthly fee for reserved computing power.')), h('span', { class: 'badge gold' }));
    bind(hd, () => T(hd.lastChild, G.C.nContracts + '/' + G.contractSlots() + ' slots'));
    out.push(hd);
    if (!G.C.F.ent) { out.push(h('div', { class: 'card row' }, I('lock', 18), h('span', { class: 'mut sm' }, 'Research Enterprise Sales to unlock partnerships.'))); return out; }
    for (const p of D.partners) {
      const signed = !!s.contracts[p.id];
      const card = h('div', { class: 'card col' + (signed ? ' hl' : '') });
      card.append(h('div', { class: 'row' }, h('div', { class: 'ico' + (signed ? '' : ' dim') }, I(signed ? 'check' : 'doc', 18)), h('div', { class: 'grow' }, h('div', { class: 'h3' }, p.name), h('div', { class: 'xs mut' }, p.sector)), h('div', { class: 'tr' }, h('div', { class: 'b pos' }, U.money((p.mrr / G.MONTH) * G.C.M.ent * G.C.M.rev) + '/s'), h('div', { class: 'xs dimt' }, U.money(p.mrr) + '/month'))));
      card.append(h('div', { class: 'row wrap gap12 xs mut' }, h('span', {}, 'Reserves ' + U.tf(p.tf)), h('span', {}, 'Signing fee ' + U.money(p.fee)), h('span', {}, 'Needs intelligence ' + p.intel)));
      if (signed) card.append(btn('End contract', { cls: 'sm ghost', onclick: () => UI.confirm('End contract?', 'You will lose this partner’s monthly income and your signing fee is not refunded.', 'End contract', () => UI.act(() => G.act.dropContract(p.id), 'tap'), 'gold') }));
      else {
        const b = btn('Sign partnership', { cls: 'gold blk', onclick: () => UI.act(() => G.act.signContract(p.id), 'ach') });
        bind(b, () => DIS(b, G.state.cash < p.fee || G.C.nContracts >= G.contractSlots() || G.C.intel < p.intel || G.C.capAvail < p.tf || G.C.uptime < 90));
        card.append(b);
      }
      out.push(card);
    }
    return out;
  }
  // Segments of the Money tab. money.js adds the first one ("money"); the others live here.
  UI.biz = { strategy: bizStrategy, market: bizMarket, partners: bizPartners };
  UI.bizSegs = [['money', 'Money'], ['strategy', 'Strategy'], ['market', 'Market'], ['partners', 'Partners']];
  UI.tabs.business = function () {
    const root = h('div', { style: col() });
    if (!UI.biz[UI.st.bizSeg]) UI.st.bizSeg = 'money';
    root.append(head('Money', 'How you earn, what it costs, and the market'));
    root.append(tabs2(UI.bizSegs, UI.st.bizSeg, (v) => (UI.st.bizSeg = v)));
    root.append(h('div', { class: 'panel cols', 'data-keep': 'biz' }, UI.biz[UI.st.bizSeg]()));
    return root;
  };

  /* ======================= GLOBAL EXPANSION ======================= */
  // The globe fills the top of the screen (the region chips sit on its lower edge). Under it there is one compact card for the picked
  // region: four numbers, one button, and the rest of the numbers behind "More details".
  UI.tabs.global = function () {
    const s = G.state, M = G.map, id = UI.st.region || 'na', r = D.rgmap[id], rc = M.COL[id];
    const root = h('div', { class: 'tab-split glob', style: col() });
    const mapbox = h('div', { class: 'mapbox globe' });
    const panel = h('div', { class: 'panel', 'data-keep': 'glob' });
    const pick = (rid) => { UI.st.region = rid; G.audio.sfx('tap'); M.select(rid); UI.refresh(); };

    // on the globe: how much of the world is reached, and the region chips
    const open = D.regions.filter((g) => s.regions[g.id]), world = D.regions.reduce((a, g) => a + g.pop, 0);
    const reached = open.reduce((a, g) => a + g.pop * D.hubReach[s.regions[g.id].hub], 0);
    const gm = (l, v) => h('div', { class: 'gm' }, h('div', { class: 'gm-l' }, l), h('div', { class: 'gm-v' }, v));
    mapbox.append(h('div', { class: 'gmeter' }, gm('Regions open', open.length + '/' + D.regions.length), gm('People reached', Math.round((reached / world) * 100) + '%')));
    mapbox.append(h('div', { class: 'gpills', 'data-keep': 'gpills' }, D.regions.map((g) => {
      const st = G.regionStatus(g.id), rr = s.regions[g.id];
      return h('button', { class: 'gpill st-' + st + (g.id === id ? ' on' : ''), type: 'button', style: { '--rc': M.COL[g.id] }, 'aria-label': g.name, onclick: () => pick(g.id) },
        h('i', { class: 'gdot' }), h('span', { class: 'gn' }, M.NAME[g.id]), rr ? h('span', { class: 'gs' }, 'Hub ' + rr.hub) : st === 'building' ? h('span', { class: 'gs gold' }, 'Building') : st === 'ready' ? h('span', { class: 'gs acc' }, 'Ready') : I('lock', 11));
    })));

    // the card of the picked region
    const st = G.regionStatus(id), rs = s.regions[id], nx = G.regionNext(id), reach = D.hubReach[rs ? rs.hub : 0];
    const stat = (label, val) => h('div', { class: 'gst' }, h('div', { class: 'gv' }, val), h('div', { class: 'gl' }, label));
    const card = h('div', { class: 'card gcard', style: { '--rc': rc } });
    card.append(h('div', { class: 'row gtop' }, h('div', { class: 'gdotbig' }, I('globe', 18)),
      h('div', { class: 'grow' }, h('div', { class: 'h3' }, r.name), h('div', { class: 'xs mut clamp2' }, r.blurb)),
      h('span', { class: 'badge ' + (st === 'open' || st === 'max' ? 'acc' : st === 'building' ? 'gold' : '') }, { open: 'OPEN', max: 'MAX HUB', building: 'BUILDING', ready: 'READY', locked: 'LOCKED' }[st])));
    const users = h('span', {}, '—');
    if (rs) bind(users, () => T(users, U.num((G.C.reg[id] || { pot: 0 }).pot)));
    card.append(h('div', { class: 'gstats' }, stat('Users', users), stat('Reach', Math.round(reach * 100) + '%'), stat('Hub level', (rs ? rs.hub : 0) + '/3'), stat('Spending', 'x' + r.arpu.toFixed(2))));
    if (!rs) card.append(h('div', { class: 'greq' }, G.regionReqs(id).map((q) => h('span', { class: 'req' + (q.ok ? ' ok' : '') }, I(q.ok ? 'check' : 'lock', 13), q.text))));
    const b = G.building('reg', id);
    if (b) {
      const pb = bar('gold anim'), eta = h('b', { class: 'gold' });
      card.append(h('div', { class: 'col' }, h('div', { class: 'row between sm' }, h('span', {}, 'Building hub level ' + b.to), eta), pb));
      bind(pb, () => { setBar(pb, 1 - b.left / b.total); T(eta, U.dur(b.left)); });
    } else if (nx) {
      const act = btn(rs ? 'Upgrade hub to level ' + nx.to : 'Open region', { cls: 'pri blk', icon: 'globe', onclick: () => UI.act(() => G.act.region(id), 'build') });
      act._l.after(h('span', { class: 'sub' }, '· ' + U.money(nx.cost) + ' · ' + U.dur(nx.time)));
      bind(act, () => DIS(act, G.state.cash < nx.cost || (!G.state.regions[id] && !G.regionReqs(id).every((q) => q.ok))));
      card.append(act, h('div', { class: 'xs dimt tc' }, rs ? 'Reach ' + Math.round(reach * 100) + '% → ' + Math.round(D.hubReach[nx.to] * 100) + '% of the people there, and +2% compute' : 'Builds a regional hub with 50% reach and starts attracting local users'));
    } else card.append(h('div', { class: 'xs good tc' }, 'Fully developed.'));
    // the numbers that matter less stay out of the way until asked for
    const more = !!UI.st.globMore;
    card.append(h('button', { class: 'gtog' + (more ? ' on' : ''), type: 'button', onclick: () => { UI.st.globMore = !more; G.audio.sfx('tap'); UI.refresh(); } }, more ? 'Hide details' : 'More details', I('chev', 14)));
    if (more) {
      card.append(h('div', { class: 'grid3' }, tile('Population', h('div', { class: 'tv' }, U.num(r.pop * 1e6))), tile('Op. costs', h('div', { class: 'tv' }, 'x' + r.opex.toFixed(2))), tile('Build costs', h('div', { class: 'tv' }, 'x' + r.infra.toFixed(2)))));
      card.append(h('div', { class: 'grid2' }, tile('Growth', h('div', { class: 'tv' }, 'x' + r.growth.toFixed(2))), tile('Rival strength', h('div', { class: 'tv' }, 'x' + r.comp.toFixed(2)))));
      card.append(h('div', { class: 'xs dimt' }, 'Each hub level raises reach: ' + [50, 75, 100].map((x) => x + '%').join(' → ') + ' of the local population, and adds 2% compute.'));
    }
    panel.append(card);
    root.append(mapbox, panel);
    setTimeout(() => { M.setInset(0, 40); M.mount(mapbox); M.select(id); M.onPick = (rid) => { UI.st.region = rid; G.audio.sfx('tap'); UI.refresh(); }; }, 0);
    return root;
  };

  /* ======================= ACHIEVEMENTS / GOALS ======================= */
  function fmtGoal(m, v) { return m.fmt === 'money' ? U.money(v) : U.num(v); }
  function missionsView() {
    const s = G.state, out = [];
    const cd = h('span', { class: 'xs dimt' });
    out.push(h('div', { class: 'row between' }, h('span', { class: 'micro' }, 'DAILY MISSIONS'), cd));
    bind(cd, () => { const n = new Date(), e = new Date(n.getFullYear(), n.getMonth(), n.getDate() + 1); T(cd, 'Resets in ' + U.clock((e - n) / 1000)); });
    s.daily.list.forEach((it, i) => {
      const m = D.mimap[it.id], pb = bar(it.claimed ? 'good' : ''), pv = h('b', { class: 'xs' });
      const b = btn(it.claimed ? 'Claimed' : 'Claim', { cls: 'sm gold', onclick: () => { const r = UI.act(() => G.act.claimMission(i), 'ach'); if (r.ok) UI.toast({ kind: 'reward', text: 'Mission reward collected.' }); } });
      out.push(h('div', { class: 'card col' }, h('div', { class: 'row' }, h('div', { class: 'ico ' + (it.claimed ? 'dim' : 'gold') }, I(it.claimed ? 'check' : 'target', 18)), h('div', { class: 'grow' }, h('div', { class: 'sm b' }, m.text + (m.id === 'earn' || m.id === 'users' ? ' (' + fmtGoal(m, it.goal) + ')' : '')), pv), b), pb));
      bind(pb, () => { const p = G.missionProg(it); setBar(pb, p / it.goal); T(pv, fmtGoal(m, p) + ' / ' + fmtGoal(m, it.goal)); DIS(b, it.claimed || p < it.goal); });
    });
    out.push(sec('LONG-TERM ROADMAP'));
    for (const a of D.ach.filter((x) => x.long)) {
      const got = !!s.ach[a.id], pb = bar(got ? 'good' : 'vio'), pv = h('span', { class: 'xs dimt' });
      out.push(h('div', { class: 'card col' + (got ? '' : '') }, h('div', { class: 'row' }, h('div', { class: 'ico ' + (got ? 'gold' : 'vio') }, I(a.icon, 18)), h('div', { class: 'grow' }, h('div', { class: 'sm b' }, a.name), h('div', { class: 'xs mut' }, a.desc)), got ? h('span', { class: 'badge good' }, 'DONE') : pv), got ? null : pb));
      if (!got) bind(pb, () => { const p = a.p ? U.clamp(a.p(G.state, G.C), 0, 1) : 0; setBar(pb, p); T(pv, Math.floor(p * 100) + '%'); });
    }
    return out;
  }
  function achView() {
    const s = G.state;
    const got = Object.keys(s.ach).length;
    return [h('div', { class: 'card row' }, h('div', { class: 'ico gold' }, I('trophy', 20)), h('div', { class: 'grow' }, h('div', { class: 'h3' }, got + ' of ' + D.ach.length + ' unlocked'), h('div', { class: 'xs mut' }, 'Every achievement permanently adds +1% to all revenue.'))),
      h('div', { class: 'badgeg' }, D.ach.map((a) => { const g = !!s.ach[a.id]; return h('div', { class: 'ach ' + (g ? 'got' : 'lock') }, h('div', { class: 'ico' }, I(g ? a.icon : 'lock', 20)), h('div', { class: 'xs b' }, a.name), h('div', { class: 'xs dimt' }, a.desc)); }))];
  }
  function legacyView() {
    const s = G.state, p = s.pres, out = [];
    const prog = bar('vio'), pv = h('b', { class: 'vio' });
    const go = btn('Reinvent company', { cls: 'vio blk', icon: 'refresh', onclick: () => UI.reinvent() });
    out.push(h('div', { class: 'card vio col' },
      h('div', { class: 'row' }, h('div', { class: 'ico vio' }, I('refresh', 20)), h('div', { class: 'grow' }, h('div', { class: 'h3' }, 'Corporate Reinvention'), h('div', { class: 'xs mut' }, 'Optional. Start a brand-new AI company with permanent bonuses.'))),
      h('div', { class: 'xs mut' }, 'Reinvent once your valuation reaches ' + U.money(D.prestige.min) + '. You earn Legacy Patents based on how valuable the company became. Patents buy permanent upgrades and every patent adds to all future revenue.'),
      h('div', { class: 'grid2' }, tile('You keep', h('div', { class: 'xs' }, 'Patents, upgrades, achievements, looks, settings')), tile('You restart', h('div', { class: 'xs' }, 'Cash, models, research, buildings, regions'))),
      h('div', { class: 'row between sm' }, h('span', { class: 'mut' }, 'Valuation'), pv), prog, go));
    bind(prog, () => { setBar(prog, G.C.val / D.prestige.min); T(pv, U.money(G.C.val) + ' / ' + U.money(D.prestige.min)); const can = G.canReinvent(); DIS(go, !can); T(go._l, can ? 'Reinvent for ' + G.reinventGain() + ' patents' : 'Not available yet'); });
    out.push(h('div', { class: 'grid3' }, tile('Patents', h('div', { class: 'tv vio' }, String(p.patents))), tile('Lifetime', h('div', { class: 'tv' }, String(p.total))), tile('Reinventions', h('div', { class: 'tv' }, String(p.count)))));
    out.push(h('div', { class: 'xs dimt' }, 'Revenue bonus from Legacy: +' + Math.round(30 * Math.sqrt(p.total)) + '%'));
    out.push(sec('LEGACY UPGRADES'));
    for (const l of D.legacy) {
      const lvl = p.up[l.id] || 0, cost = lvl >= l.max ? 0 : D.legacyCost(l, lvl);
      const b = btn(lvl >= l.max ? 'Maxed' : 'Buy · ' + cost + ' patents', { cls: 'vio sm', onclick: () => UI.act(() => G.act.buyLegacy(l.id), 'ach') });
      bind(b, () => DIS(b, lvl >= l.max || G.state.pres.patents < cost));
      out.push(h('div', { class: 'card col' }, h('div', { class: 'row' }, h('div', { class: 'ico vio' }, I(l.icon, 18)), h('div', { class: 'grow' }, h('div', { class: 'sm b' }, l.name + '  ' + lvl + '/' + l.max), h('div', { class: 'xs mut' }, l.desc)), b)));
    }
    return out;
  }
  UI.reinvent = function () {
    const gain = G.reinventGain();
    UI.confirm('Reinvent your company?', 'You will found a new AI company and earn ' + gain + ' Legacy Patents. Cash, models, research, buildings and regions reset. Patents, upgrades, achievements and looks stay.', 'Reinvent', () => {
      const r = G.act.reinvent();
      if (!r.ok) return;
      G.audio.sfx('prestige'); G.save();
      UI.initState(true);
      let mm;
      const body = h('div', { class: 'col gap12 tc' }, h('div', { class: 'ico vio', style: { margin: '0 auto', width: '64px', height: '64px', borderRadius: '20px' } }, I('refresh', 32)), h('h2', {}, 'A new company is born'), h('div', { class: 'mut' }, 'You earned ' + r.gain + ' Legacy Patents. Spend them on permanent upgrades in the Goals tab.'), UI.btn('Spend patents', { cls: 'vio blk', onclick: () => { mm.close(); UI.st.achSeg = 'legacy'; UI.go('achv'); } }));
      mm = UI.modal(body, { center: true });
    }, 'vio');
  };
  UI.tabs.achv = function () {
    const root = h('div', { style: col() });
    root.append(head('Achievements', 'Missions, milestones and Legacy'));
    root.append(tabs2([['missions', 'Missions'], ['ach', 'Achievements'], ['legacy', 'Legacy']], UI.st.achSeg, (v) => (UI.st.achSeg = v)));
    const body = { missions: missionsView, ach: achView, legacy: legacyView }[UI.st.achSeg]();
    root.append(h('div', { class: 'panel', 'data-keep': 'achv' }, body));
    return root;
  };

  /* ======================= INIT ======================= */
  UI.initState = function (keepTab) {
    UI.st.pick = null;
    G.audio.vol.music = G.state.set.music; G.audio.vol.sfx = G.state.set.sfx;
    G.audio.apply();
    UI.applyAnim();
    UI.st.region = 'na';
    if (S) S.sync(true);
    UI.go(keepTab ? 'hq' : UI.tab() || 'hq', true);
  };
  UI.init = function () {
    UI.buildChrome();
    G.on('toast', (t) => { UI.toast(t); if (t.kind === 'warn') G.audio.sfx('warn'); });
    G.on('purchase', () => { UI.refresh(); S.sync(true); });
    G.on('build_done', (b) => {
      G.audio.sfx('build');
      const id = b.k === 'dc' ? 'dc' + b.to : b.k === 'pwr' ? 'pwr' + b.to : b.k;
      S.pop(id);
      UI.refresh();
    });
    G.on('research_done', (n) => { G.audio.sfx('research'); UI.st.burst = n.id; UI.refresh(); });
    G.on('train_done', (j) => { G.audio.sfx('train'); G.lab.burst(); UI.refresh(); });
    G.on('release', (info) => { UI.launch(info); try { S.sync(true); } catch (e) { G.err(e); } UI.refresh(); });
    G.on('ach', (o) => UI.achievement(o));
    G.on('reward', (o) => { UI.toast({ kind: 'reward', text: o.text + ' · +' + U.money(o.reward) }); });
    G.on('skin', () => S.sync(true));
  };
})();
