#!/usr/bin/env python3
"""Catches the bug that broke the first 1.2.0 build: a patch that silently deletes a helper (function/class/val) that
other code still uses. Compares the functions, classes and objects DEFINED in the original sources with the patched ones
(local variables are ignored: replacing a function body legitimately removes its locals).
Usage: kotlin_defs_check.py ORIGINAL_DIR PATCHED_DIR   (only files present in both are compared)"""
import os, re, sys
def defs(path):
    s = open(path).read()
    n = set(re.findall(r'\bfun\s+(?:<[^>]+>\s*)?(?:[A-Za-z0-9_.]+\.)?([A-Za-z_]\w*)\s*\(', s))
    n |= set(re.findall(r'\b(?:class|object|interface)\s+([A-Za-z_]\w*)', s))
    return n
orig, new = sys.argv[1], sys.argv[2]
lost = {}
for f in sorted(os.listdir(new)):
    o = os.path.join(orig, f)
    if f.endswith('.kt') and os.path.exists(o):
        gone = defs(o) - defs(os.path.join(new, f))
        if gone: lost[f] = sorted(gone)
print("definitions missing after patching:", lost if lost else "none")
sys.exit(1 if lost else 0)
