// Runs the REAL supabase/functions/filebridge-mcp/index.ts under Node (>= 22) with two substitutions:
//   1. the `npm:@supabase/supabase-js@2` import is rewritten to tests/mock_supabase.mjs (in-memory DB),
//   2. Deno.serve / Deno.env are stubbed.
// The phone is simulated. The SQL itself is tested separately against the real database (tests/sql/).
//   node --test tests/edge_function.test.mjs
import { test, beforeEach } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { createHash } from "node:crypto";
import { fileURLToPath, pathToFileURL } from "node:url";
import * as mock from "./mock_supabase.mjs";

const here = path.dirname(fileURLToPath(import.meta.url));
const IMPORT = 'import { createClient } from "npm:@supabase/supabase-js@2";';
const src = fs.readFileSync(path.join(here, "..", "supabase", "functions", "filebridge-mcp", "index.ts"), "utf8");
assert.ok(src.includes(IMPORT), "supabase import line not found");
const tmp = path.join(here, ".index_under_test.ts");
fs.writeFileSync(tmp, src.replace(IMPORT, `import { createClient } from ${JSON.stringify(pathToFileURL(path.join(here, "mock_supabase.mjs")).href)};`));

const ENV = { SUPABASE_URL: "https://test.supabase.co", SUPABASE_SERVICE_ROLE_KEY: "svc", SUPABASE_ANON_KEY: "anon" };
globalThis.Deno = { env: { get: (k) => ENV[k] }, serve: (h) => { globalThis.__handler = h; } };
globalThis.fetch = async () => ({ ok: true, status: 200, text: async () => "", json: async () => ({}) });
const quiet = console.error; console.error = () => {};
await import(pathToFileURL(tmp).href);
console.error = quiet;

const sha = (s) => createHash("sha256").update(s).digest("hex");
const TOKEN = "T".repeat(30), MEM_TOKEN = "M".repeat(30), BASE = "https://test.supabase.co/functions/v1/filebridge-mcp";
const R1 = "1".repeat(64), R2 = "2".repeat(64);
const DEV = "FB-TEST0001";

async function http(pathname, body, headers = {}) {
  const res = await globalThis.__handler(new Request(BASE + pathname, { method: body === undefined ? "GET" : "POST", headers: { "content-type": "application/json", ...headers }, body: body === undefined ? undefined : JSON.stringify(body) }));
  return { status: res.status, json: await res.json().catch(() => null) };
}
const rpcMethod = async (method, params, token = TOKEN) => (await http(`/c/${token}`, { jsonrpc: "2.0", id: 1, method, params })).json;
async function tool(name, args = {}, token = TOKEN) {
  const r = await rpcMethod("tools/call", { name, arguments: args }, token);
  assert.ok(r.result, JSON.stringify(r));
  return { ...JSON.parse(r.result.content[0].text), _isError: r.result.isError };
}
const cmds = () => mock.state.tables.filebridge_commands;
const calls = (name) => mock.state.calls.filter((c) => c.name === name);

beforeEach(() => {
  mock.resetDb();
  const T = mock.state.tables;
  T.filebridge_clients.push({ id: "11111111-1111-4111-8111-111111111111", name: "Claude", scopes: ["files", "memory", "builds"], token_hash: sha(TOKEN) });
  T.filebridge_clients.push({ id: "22222222-2222-4222-8222-222222222222", name: "Notes AI", scopes: ["memory"], token_hash: sha(MEM_TOKEN) });
  T.filebridge_devices.push({ device_id: DEV, name: "Pixel", channel_id: "chan", channel_key: "key", status: "active", last_seen_at: new Date().toISOString(), app_version: "1.2.0", state: { claude_enabled: true, permissions: { read: true, create: true, modify: true, move: false, delete: false } } });
});

// ---------------------------------------------------------------- catalogue
test("health reports 1.2.0 and the new features", async () => {
  const r = await http("/health");
  assert.equal(r.json.version, "1.2.0");
  for (const f of ["resume_project", "leases", "journal", "revision_guard", "write_verify_readback"]) assert.ok(r.json.features.includes(f), f);
});

test("tools/list exposes the new tools with honest annotations", async () => {
  const r = await rpcMethod("tools/list", {});
  const by = Object.fromEntries(r.result.tools.map((t) => [t.name, t]));
  for (const n of ["edit_file", "verify_files", "verify_zip", "resume_project", "project_checkpoint", "file_lease", "test_run"]) assert.ok(by[n], `${n} missing`);
  assert.equal(by.write_file.annotations.destructiveHint, true, "write_file stays honestly destructive");
  assert.equal(by.write_file.annotations.readOnlyHint, false);
  assert.equal(by.verify_files.annotations.readOnlyHint, true);
  assert.equal(by.verify_zip.annotations.readOnlyHint, true);
  assert.equal(by.resume_project.annotations.readOnlyHint, true);
  assert.ok(by.write_file.inputSchema.properties.expected_revision && by.write_file.inputSchema.properties.session && by.write_file.inputSchema.properties.note);
  assert.ok(by.read_file.inputSchema.properties.session && !by.read_file.inputSchema.properties.note, "reads carry no note");
  assert.ok(by.create_zip.inputSchema.properties.expect_files && by.prepare_project_zip.inputSchema.properties.expect_files);
  assert.deepEqual(by.edit_file.inputSchema.required, ["path", "edits"]);
  for (const t of r.result.tools) { assert.equal(t.inputSchema.type, "object"); assert.ok(Array.isArray(t.inputSchema.required)); for (const k of t.inputSchema.required) assert.ok(k in t.inputSchema.properties, `${t.name}.${k}`); }
});

test("a memory-only connector sees memory and coordination tools, never file tools", async () => {
  const r = await rpcMethod("tools/list", {}, MEM_TOKEN);
  const names = r.result.tools.map((t) => t.name);
  assert.ok(names.includes("resume_project") && names.includes("test_run") && names.includes("memory_write"));
  assert.ok(!names.includes("write_file") && !names.includes("verify_files"));
  const denied = await tool("write_file", { path: "a.txt", content: "x" }, MEM_TOKEN);
  assert.equal(denied.error, "scope_denied");
});

test("instructions steer Claude to direct edits, resume_project and honest tests", async () => {
  const r = await rpcMethod("initialize", { protocolVersion: "2025-06-18" });
  const t = r.result.instructions;
  assert.equal(r.result.serverInfo.version, "1.2.0");
  for (const w of ["resume_project", "edit_file", "directly", "temp_copy", "never by Android", "revision_conflict", "expect_files"]) assert.ok(t.includes(w), w);
  assert.ok(!t.includes("Never overwrite unless"), "old discouraging sentence removed");
});

// ---------------------------------------------------------------- write_file / overwrite
test("write_file overwrite: owner, project, paths and note reach the journal; progress is reported back", async () => {
  const [res] = await Promise.all([
    tool("write_file", { path: "Proj/a.txt", content: "hello", overwrite: true, session: "s1", note: "fix overwrite" }),
    mock.phoneAnswer("write_file", { path: "Proj/a.txt", size: 5, revision: R1, verified: true }),
  ]);
  assert.equal(res.ok, true);
  assert.equal(res.revision, R1);
  assert.equal(res.project, "Proj");
  assert.equal(res.project_revision, 1);
  assert.equal(res.autosaved, true);
  const enq = calls("filebridge_enqueue")[0].args;
  assert.equal(enq.p_owner, "Claude#s1");
  assert.deepEqual(enq.p_paths, ["Proj/a.txt"]);
  assert.equal(enq.p_note, "fix overwrite");
  assert.equal(enq.p_destructive, true);
  assert.equal(enq.p_ttl, 45);
});

test("write_file without overwrite is not destructive and has no revision guard", async () => {
  await Promise.all([tool("write_file", { path: "n.txt", content: "x" }), mock.phoneAnswer("write_file", { size: 1, revision: R1 })]);
  assert.equal(calls("filebridge_enqueue")[0].args.p_destructive, false);
  assert.equal(calls("filebridge_lease_conflicts").length, 1, "leases are still honoured for creates");
});

test("overwrite fills expected_revision from what this session last read", async () => {
  mock.state.tables.filebridge_file_seen.push({ device_id: DEV, owner: "Claude#s1", path: "Proj/a.txt", sha256: R1 });
  const [res, cmd] = await Promise.all([
    tool("write_file", { path: "Proj/a.txt", content: "v2", overwrite: true, session: "s1" }),
    mock.phoneAnswer("write_file", { size: 2, revision: R2, previous_revision: R1 }),
  ]);
  assert.equal(JSON.parse(cmd.args_json ?? JSON.stringify(cmd.args)).expected_revision, R1);
  assert.equal(res.revision_checked_against, "the revision you last read");
});

test("an explicit expected_revision is passed through untouched", async () => {
  mock.state.tables.filebridge_file_seen.push({ device_id: DEV, owner: "Claude", path: "a.txt", sha256: R1 });
  const [, cmd] = await Promise.all([
    tool("write_file", { path: "a.txt", content: "x", overwrite: true, expected_revision: R2.toUpperCase() }),
    mock.phoneAnswer("write_file", { size: 1, revision: R1 }),
  ]);
  assert.equal(cmd.args.expected_revision, R2);
});

test("overwrite of a file another AI changed, never read by this AI, is refused before anything is queued", async () => {
  mock.state.tables.filebridge_file_state.push({ device_id: DEV, path: "Proj/a.txt", rev: 3, sha256: R2, deleted: false, updated_by: "Other AI", updated_at: new Date().toISOString() });
  const res = await tool("write_file", { path: "Proj/a.txt", content: "x", overwrite: true });
  assert.equal(res.error, "revision_unseen");
  assert.equal(res.changed_by, "Other AI");
  assert.equal(cmds().length, 0);
});

test("overwrite of a file this owner wrote itself is allowed", async () => {
  mock.state.tables.filebridge_file_state.push({ device_id: DEV, path: "a.txt", rev: 1, sha256: R1, deleted: false, updated_by: "Claude", updated_at: new Date().toISOString() });
  const [res] = await Promise.all([tool("write_file", { path: "a.txt", content: "x", overwrite: true }), mock.phoneAnswer("write_file", { size: 1, revision: R2 })]);
  assert.equal(res.ok, true);
});

test("a revision conflict reported by the phone reaches Claude with the current revision", async () => {
  const [res] = await Promise.all([
    tool("write_file", { path: "a.txt", content: "x", overwrite: true, expected_revision: R1 }),
    mock.phoneAnswer("write_file", { path: "a.txt", current_revision: R2, expected_revision: R1 }, { ok: false, error: "The file changed since you read it.", code: "revision_conflict" }),
  ]);
  assert.equal(res.ok, false);
  assert.equal(res.error, "revision_conflict");
  assert.equal(res.current_revision, R2);
});

test("bad revision strings are rejected before queueing", async () => {
  const res = await tool("write_file", { path: "a.txt", content: "x", overwrite: true, expected_revision: "not-a-hash" });
  assert.equal(res.error, "invalid_argument");
  assert.equal(cmds().length, 0);
});

test("the Modify permission is still required for overwrites", async () => {
  mock.state.tables.filebridge_devices[0].state.permissions.modify = false;
  const res = await tool("write_file", { path: "a.txt", content: "x", overwrite: true });
  assert.equal(res.error, "permission_denied");
  assert.equal(res.permission, "modify");
  assert.equal(cmds().length, 0);
});

test("session labels are validated", async () => {
  const res = await tool("write_file", { path: "a.txt", content: "x", session: "bad session!" });
  assert.equal(res.error, "invalid_argument");
});

test("secrets in the journal note are refused", async () => {
  const res = await tool("write_file", { path: "a.txt", content: "x", note: "key sk-ant-api03-" + "a".repeat(40) });
  assert.equal(res.ok, false);
  assert.equal(cmds().length, 0);
});

// ---------------------------------------------------------------- leases
test("a write inside another AI's lease is refused and nothing is queued", async () => {
  mock.state.rpc.filebridge_lease_conflicts = () => [{ lease_id: "x", owner: "Other AI", paths: ["Proj/src"], purpose: "refactor", expires_at: "2099-01-01T00:00:00Z" }];
  const res = await tool("write_file", { path: "Proj/src/Main.kt", content: "x", overwrite: true });
  assert.equal(res.error, "locked_by_other");
  assert.match(res.message, /Other AI holds a lease on Proj\/src/);
  assert.equal(res.conflicts.length, 1);
  assert.equal(cmds().length, 0);
});

test("leases guard only what an operation changes: a ZIP's source folder is read, its output is written", async () => {
  mock.state.rpc.filebridge_lease_conflicts = (a) => a.p_paths.some((p) => p.startsWith("ZIP/")) ? [{ owner: "Other AI", paths: ["ZIP"], expires_at: "2099-01-01T00:00:00Z" }] : [];
  const blocked = await tool("create_zip", { source: "Proj", output: "ZIP/Proj.zip" });
  assert.equal(blocked.error, "locked_by_other");
  assert.deepEqual(calls("filebridge_lease_conflicts")[0].args.p_paths, ["ZIP/Proj.zip"], "only the output is checked");
  assert.equal(cmds().length, 0);
  mock.state.rpc.filebridge_lease_conflicts = (a) => a.p_paths.includes("Proj") ? [{ owner: "Other AI", paths: ["Proj"], expires_at: "2099-01-01T00:00:00Z" }] : [];
  const [ok] = await Promise.all([tool("create_zip", { source: "Proj", output: "ZIP/Proj.zip" }), mock.phoneAnswer("create_zip", { success: true, output: "ZIP/Proj.zip", size: 1 })]);
  assert.equal(ok.ok, true, "a lease on the source folder does not stop a snapshot ZIP");
  mock.state.rpc.filebridge_lease_conflicts = (a) => a.p_paths.includes("Proj/b.txt") ? [{ owner: "Other AI", paths: ["Proj/b.txt"], expires_at: "2099-01-01T00:00:00Z" }] : [];
  const mv = await tool("copy_file", { source: "Proj/a.txt", destination: "Proj/b.txt" });
  assert.equal(mv.error, "locked_by_other", "the destination of a copy is written");
});

test("reads never check leases", async () => {
  const [res] = await Promise.all([tool("read_file", { path: "a.txt" }), mock.phoneAnswer("read_file", { content: "x", revision: R1 })]);
  assert.equal(res.ok, true);
  assert.equal(calls("filebridge_lease_conflicts").length, 0);
});

test("file_lease acquire / renew / release / list", async () => {
  mock.state.rpc.filebridge_lease_acquire = (a) => ({ ok: true, lease_id: "33333333-3333-4333-8333-333333333333", expires_at: "2099-01-01T00:00:00Z", paths: a.p_paths });
  mock.state.rpc.filebridge_lease_renew = () => ({ ok: true, lease_id: "33333333-3333-4333-8333-333333333333" });
  mock.state.rpc.filebridge_lease_release = () => ({ ok: true, released: 1 });
  mock.state.rpc.filebridge_lease_list = () => [];
  const acq = await tool("file_lease", { action: "acquire", paths: ["/Proj\\src/"], ttl_seconds: 120, purpose: "edit src", session: "s9" });
  assert.equal(acq.ok, true);
  const a = calls("filebridge_lease_acquire")[0].args;
  assert.deepEqual(a.p_paths, ["Proj/src"]);
  assert.equal(a.p_owner, "Claude#s9");
  assert.equal(a.p_device, DEV);
  assert.equal(a.p_ttl, 120);
  assert.equal(a.p_project, "Proj");
  assert.equal((await tool("file_lease", { action: "renew", lease_id: acq.lease_id })).ok, true);
  assert.equal((await tool("file_lease", { action: "release" })).released, 1);
  assert.deepEqual((await tool("file_lease", { action: "list" })).leases, []);
  assert.equal((await tool("file_lease", { action: "renew" })).error, "invalid_argument");
  assert.equal((await tool("file_lease", { action: "acquire" })).error, "invalid_argument");
  assert.equal((await tool("file_lease", { action: "acquire", paths: [""] })).error, "invalid_argument", "the whole workspace cannot be leased");
});

test("file_lease conflict is reported with the holder", async () => {
  mock.state.rpc.filebridge_lease_acquire = () => ({ ok: false, error: "locked_by_other", message: "Another AI holds a lease", conflicts: [{ owner: "Other AI" }] });
  const res = await tool("file_lease", { action: "acquire", paths: ["Proj/src"] });
  assert.equal(res.error, "locked_by_other");
  assert.equal(res.conflicts[0].owner, "Other AI");
});

// ---------------------------------------------------------------- edit_file / verify tools
test("edit_file: validation", async () => {
  for (const args of [{ path: "a.txt" }, { path: "a.txt", edits: [] }, { path: "a.txt", edits: [{ old_text: "", new_text: "x" }] }, { path: "a.txt", edits: [{ old_text: "a" }] }, { path: "a.txt", edits: [{ old_text: "a", new_text: "b", replace_all: "yes" }] }, { path: "a.txt", edits: new Array(21).fill({ old_text: "a", new_text: "b" }) }]) {
    assert.equal((await tool("edit_file", args)).error, "invalid_argument", JSON.stringify(args).slice(0, 80));
  }
  assert.equal(cmds().length, 0);
});

test("edit_file: queued as a destructive Modify operation with normalised edits", async () => {
  const [res, cmd] = await Promise.all([
    tool("edit_file", { path: "/Proj/a.kt", edits: [{ old_text: "foo", new_text: "bar" }, { old_text: "x", new_text: "", replace_all: true }] }),
    mock.phoneAnswer("edit_file", { path: "Proj/a.kt", revision: R2, replacements: 3, verified: true }),
  ]);
  assert.equal(res.ok, true);
  assert.equal(cmd.tool, "edit_file");
  assert.equal(cmd.destructive, true);
  assert.deepEqual(cmd.args.edits, [{ old_text: "foo", new_text: "bar", replace_all: false }, { old_text: "x", new_text: "", replace_all: true }]);
  assert.equal(cmd.args.path, "Proj/a.kt");
  assert.equal(res.project, "Proj");
});

test("edit_file needs the Modify permission", async () => {
  mock.state.tables.filebridge_devices[0].state.permissions.modify = false;
  assert.equal((await tool("edit_file", { path: "a.txt", edits: [{ old_text: "a", new_text: "b" }] })).error, "permission_denied");
});

test("edit_file uses the revision this session last read", async () => {
  mock.state.tables.filebridge_file_seen.push({ device_id: DEV, owner: "Claude", path: "a.txt", sha256: R1 });
  const [, cmd] = await Promise.all([tool("edit_file", { path: "a.txt", edits: [{ old_text: "a", new_text: "b" }] }), mock.phoneAnswer("edit_file", { revision: R2 })]);
  assert.equal(cmd.args.expected_revision, R1);
});

test("verify_files: validation and read-only queueing", async () => {
  assert.equal((await tool("verify_files", { paths: [] })).error, "invalid_argument");
  assert.equal((await tool("verify_files", { paths: new Array(41).fill("a") })).error, "invalid_argument");
  const [res, cmd] = await Promise.all([tool("verify_files", { paths: ["/Proj\\a.txt", "Proj/b.txt"] }), mock.phoneAnswer("verify_files", { files: [{ path: "Proj/a.txt", exists: true, revision: R1 }], count: 2 })]);
  assert.equal(res.ok, true);
  assert.deepEqual(cmd.args, { paths: ["Proj/a.txt", "Proj/b.txt"], hash: true });
  assert.equal(cmd.destructive, false);
});

test("create_zip with expect_files: success is only reported after the ZIP was verified", async () => {
  const run = (verifyReply, opts) => Promise.all([
    tool("create_zip", { source: "Proj", output: "ZIP/Proj.zip", overwrite: true, expect_files: ["app/build.gradle.kts", "supabase/"] }),
    mock.phoneAnswer("create_zip", { success: true, output: "ZIP/Proj.zip", size: 999, files: 3, verified: true }),
    (async () => { const c = await mock.phoneAnswer("verify_zip", verifyReply, opts); return c; })(),
  ]);
  const [ok, , vcmd] = await run({ ok: true, entries: 3, missing: [] });
  assert.equal(ok.ok, true);
  assert.equal(ok.verification.ok, true);
  assert.deepEqual(vcmd.args, { path: "ZIP/Proj.zip", expect_files: ["app/build.gradle.kts", "supabase/"], deep: false });
  mock.resetDb();
  mock.state.tables.filebridge_clients.push({ id: "11111111-1111-4111-8111-111111111111", name: "Claude", scopes: ["files", "memory", "builds"], token_hash: sha(TOKEN) });
  mock.state.tables.filebridge_devices.push({ device_id: DEV, name: "Pixel", channel_id: "chan", channel_key: "key", status: "active", last_seen_at: new Date().toISOString(), state: { permissions: { create: true, modify: true } } });
  const [bad] = await run({ missing: ["supabase/"] }, { ok: false, code: "zip_verification_failed", error: "1 expected entries are missing" });
  assert.equal(bad.ok, false);
  assert.equal(bad.error, "zip_verification_failed");
  assert.match(bad.message, /Do not report success/);
});

test("create_zip without expect_files queues no verification step", async () => {
  await Promise.all([tool("create_zip", { source: "Proj", output: "ZIP/Proj.zip" }), mock.phoneAnswer("create_zip", { success: true, output: "ZIP/Proj.zip", size: 1 })]);
  assert.equal(cmds().filter((c) => c.tool === "verify_zip").length, 0);
});

// ---------------------------------------------------------------- resume_project
const STATE = (over = {}) => ({
  project: "Proj", project_revision: 4, last_activity_at: "2026-10-17T10:00:00Z", last_owner: "Claude",
  checkpoint: { by: "Claude", summary: "did x", completed: ["a"], pending: ["task two"], next_steps: ["do y"] },
  modified_files: [{ path: "Proj/a.txt", device_id: DEV, rev: 2, sha256: R1, size: 5, by: "Claude" }, { path: "Proj/b.txt", device_id: DEV, rev: 1, sha256: R2, size: 5, by: "Claude" }, { path: "Proj/c.txt", device_id: DEV, rev: 1, sha256: null, size: 5, by: "Claude" }],
  deleted_files: [], unfinished_operations: [{ operation_id: "op1", tool: "write_file", paths: ["Proj/zzz.txt"], state: "interrupted", kind: "interrupted", owner: "Claude" }],
  recent_errors: [], tests: { counts: { interrupted: 1 }, latest: [{ name: "unit", status: "interrupted", environment: "temp_copy", stale_files: [] }, { name: "lint", status: "passed", environment: "temp_copy", stale_files: ["Proj/a.txt"] }] },
  leases: [{ owner: "Other AI", paths: ["Proj/src"], expires_at: "2099-01-01T00:00:00Z" }], expired_leases: [{ owner: "Gone AI", paths: ["Proj/old"] }], ...over,
});

test("resume_project without a project lists projects and hands out a session", async () => {
  mock.state.tables.filebridge_project_state.push({ project: "Proj", revision: 4, last_activity_at: "2026-10-17T10:00:00Z", last_owner: "Claude" });
  const res = await tool("resume_project", {});
  assert.equal(res.ok, true);
  assert.match(res.session, /^[0-9a-f]{8}$/);
  assert.equal(res.projects[0].project, "Proj");
  assert.equal(calls("filebridge_resume_state").length, 0);
});

test("resume_project checks the real files and tells the AI what is unfinished", async () => {
  mock.state.rpc.filebridge_resume_state = () => STATE();
  const [res, vcmd] = await Promise.all([
    tool("resume_project", { project: "Proj", session: "abc" }),
    mock.phoneAnswer("verify_files", () => ({ files: [
      { path: "Proj/a.txt", exists: true, revision: R1, size: 5, temp_siblings: ["a.txt.fbtmp"] },
      { path: "Proj/b.txt", exists: true, revision: "9".repeat(64), size: 9 },
      { path: "Proj/c.txt", exists: false },
      { path: "Proj/zzz.txt", exists: true, revision: R2, size: 1 },
    ] })),
  ]);
  assert.deepEqual(vcmd.args.paths.sort(), ["Proj/a.txt", "Proj/b.txt", "Proj/c.txt", "Proj/zzz.txt"]);
  assert.equal(calls("filebridge_resume_state")[0].args.p_owner, "Claude#abc");
  assert.equal(res.session, "abc");
  const w = res.workspace_check;
  assert.equal(w.status, "checked");
  assert.equal(w.matches_journal, 1);
  assert.deepEqual(w.drifted.map((d) => d.path), ["Proj/b.txt"]);
  assert.deepEqual(w.missing.map((d) => d.path), ["Proj/c.txt"]);
  assert.equal(w.leftover_temp_files[0].temp_files[0], "a.txt.fbtmp");
  assert.equal(w.unfinished_paths[0].path, "Proj/zzz.txt");
  const text = res.next_actions.join("\n");
  for (const must of ["Interrupted: write_file Proj/zzz.txt", "Test 'unit' was interrupted", "passed before Proj/a.txt changed", "Other AI holds a lease", "Gone AI", "Changed outside the recorded operations: Proj/b.txt", "Missing on the phone: Proj/c.txt", "Leftover temporary file", "do y", "task two"]) assert.ok(text.includes(must), must);
  assert.equal(res.memory.unavailable, undefined);
});

test("resume_project on an app older than 1.2.0 says so instead of failing", async () => {
  mock.state.rpc.filebridge_resume_state = () => STATE();
  const [res] = await Promise.all([tool("resume_project", { project: "Proj" }), mock.phoneAnswer("verify_files", {}, { ok: false, code: "unknown_tool", error: "Unknown tool: verify_files" })]);
  assert.equal(res.ok, true);
  assert.equal(res.workspace_check.status, "unsupported_by_app_version");
  assert.ok(res.next_actions.some((x) => x.includes("older than 1.2.0")));
});

test("resume_project works without the phone (journal only)", async () => {
  mock.state.rpc.filebridge_resume_state = () => STATE();
  mock.state.tables.filebridge_devices[0].state.emergency_stop = true;
  const res = await tool("resume_project", { project: "Proj" });
  assert.equal(res.ok, true);
  assert.equal(res.workspace_check.status, "unavailable");
  assert.equal(res.unfinished_operations.length, 1);
  assert.equal(cmds().length, 0);
});

test("resume_project: verify=false and memory-only connectors skip the phone", async () => {
  mock.state.rpc.filebridge_resume_state = () => STATE();
  assert.equal((await tool("resume_project", { project: "Proj", verify: false })).workspace_check.status, "skipped");
  const r = await tool("resume_project", { project: "Proj" }, MEM_TOKEN);
  assert.equal(r.workspace_check.status, "skipped");
  assert.match(r.workspace_check.reason, /files/);
  assert.equal(cmds().length, 0);
});

test("resume_project keeps working when shared memory cannot be read", async () => {
  mock.state.rpc.filebridge_resume_state = () => STATE({ modified_files: [], unfinished_operations: [] });
  mock.state.rpc.filebridge_active_ais = () => { throw new Error("memory down"); };
  const res = await tool("resume_project", { project: "Proj", verify: false });
  assert.equal(res.ok, true);
  assert.equal(res.project_revision, 4);
});

test("resume_project reuses the project the session resumed before", async () => {
  mock.state.rpc.filebridge_resume_state = () => STATE({ modified_files: [] });
  mock.state.tables.filebridge_owner_project.push({ owner: "Claude", project: "Proj", updated_at: new Date().toISOString() });
  await tool("resume_project", { verify: false });
  assert.equal(calls("filebridge_resume_state")[0].args.p_project, "Proj");
});

// ---------------------------------------------------------------- checkpoints and tests
test("project_checkpoint saves lists, rejects empty calls and secrets", async () => {
  mock.state.rpc.filebridge_checkpoint = (a) => ({ ok: true, project: a.p_project, project_revision: 3 });
  const ok = await tool("project_checkpoint", { project: "Proj", summary: "done x", completed: ["a"], pending: ["b"], next_steps: ["c"], session: "s2" });
  assert.equal(ok.ok, true);
  const a = calls("filebridge_checkpoint")[0].args;
  assert.deepEqual([a.p_owner, a.p_completed, a.p_pending, a.p_next], ["Claude#s2", ["a"], ["b"], ["c"]]);
  assert.equal((await tool("project_checkpoint", {})).error, "invalid_argument");
  assert.equal((await tool("project_checkpoint", { summary: "token ghp_" + "a".repeat(36) })).ok, false);
});

test("test_run: passes states through and keeps temp-copy results honest", async () => {
  mock.state.rpc.filebridge_test_run = (a) => a.p_action === "finish" && a.p_exit_code !== 0 && a.p_result === "passed"
    ? { ok: false, error: "invalid_argument", message: "A test with a non-zero exit code cannot be reported as passed." }
    : { ok: true, test: { id: "t1", status: { plan: "planned", start: "running", finish: a.p_result, interrupt: "interrupted" }[a.p_action], environment: a.p_environment ?? "temp_copy" } };
  const plan = await tool("test_run", { action: "plan", name: "unit", command: "node --test", environment: "temp_copy", files: ["/Proj\\a.txt"] });
  assert.match(plan.guidance, /nothing has been run/);
  assert.deepEqual(calls("filebridge_test_run")[0].args.p_files, ["Proj/a.txt"]);
  assert.match((await tool("test_run", { action: "start", id: "44444444-4444-4444-8444-444444444444" })).guidance, /Running/);
  const fin = await tool("test_run", { action: "finish", id: "44444444-4444-4444-8444-444444444444", result: "passed", exit_code: 0, summary: "ok", environment: "temp_copy" });
  assert.match(fin.guidance, /TEMPORARY COPY/);
  const bad = await tool("test_run", { action: "finish", id: "44444444-4444-4444-8444-444444444444", result: "passed", exit_code: 2 });
  assert.equal(bad.error, "invalid_argument");
  assert.match((await tool("test_run", { action: "interrupt", id: "44444444-4444-4444-8444-444444444444" })).guidance, /must not be reported as passed/);
});

test("test_run validation", async () => {
  assert.equal((await tool("test_run", {})).error, "invalid_argument");
  assert.equal((await tool("test_run", { action: "explode" })).error, "invalid_argument");
  assert.equal((await tool("test_run", { action: "finish", id: "nope" })).error, "invalid_argument");
  assert.equal((await tool("test_run", { action: "finish", id: "44444444-4444-4444-8444-444444444444", exit_code: 1.5 })).error, "invalid_argument");
  assert.equal((await tool("test_run", { action: "plan", name: "n", command: "curl -H 'Authorization: Bearer sk-ant-api03-" + "a".repeat(40) + "'", environment: "other" })).ok, false);
  assert.equal(calls("filebridge_test_run").length, 0);
});

// ---------------------------------------------------------------- memory protection, device endpoints, status hint
test("auto-saved progress entries cannot be edited or appended to by an AI", async () => {
  mock.state.tables.filebridge_memory.push({ id: "55555555-5555-4555-8555-555555555555", project: "Proj", kind: "fact", title: "Auto progress: Proj", content: "x", author: "filebridge-auto", version: 2, status: "open", pinned: true, archived: false, tags: [] });
  assert.equal((await tool("memory_write", { id: "55555555-5555-4555-8555-555555555555", content: "mine" })).error, "auto_managed");
  assert.equal((await tool("memory_append", { id: "55555555-5555-4555-8555-555555555555", text: "mine" })).error, "auto_managed");
  assert.equal(calls("filebridge_memory_append").length, 0);
});

test("a confirmation that is still pending names FileBridge as the source of the prompt", async () => {
  mock.state.tables.filebridge_commands.push({ id: "66666666-6666-4666-8666-666666666666", device_id: DEV, tool: "write_file", status: "awaiting_confirmation", created_at: new Date().toISOString(), progress: { waiting_for: "Overwrite file?" } });
  const res = await tool("get_operation_status", { operation_id: "66666666-6666-4666-8666-666666666666", wait_seconds: 0 });
  assert.equal(res.status, "awaiting_confirmation");
  assert.equal(res.confirmation_source, "filebridge_app");
  assert.match(res.hint, /not from Android and not from Claude/);
  assert.match(res.hint, /Always allow/);
});

test("list_devices surfaces the phone's confirmation policy and features", async () => {
  mock.state.tables.filebridge_devices[0].state.confirmations = { overwrite: "ask" };
  mock.state.tables.filebridge_devices[0].state.features = ["write_verify_readback", "overwrite_always_allow"];
  const res = await tool("list_devices", {});
  assert.deepEqual(res.devices[0].confirmations, { overwrite: "ask" });
  assert.ok(res.devices[0].features.includes("overwrite_always_allow"));
});

test("device endpoints: progress updates the journal, journal sync is authenticated and bounded", async () => {
  mock.state.tables.filebridge_devices[0].token_hash = sha("fbd_" + "a".repeat(40));
  const id = "77777777-7777-4777-8777-777777777777";
  mock.state.tables.filebridge_commands.push({ id, device_id: DEV, tool: "write_file", status: "delivered", created_at: new Date().toISOString() });
  mock.state.tables.filebridge_journal.push({ command_id: id, device_id: DEV, state: "delivered", tool: "write_file" });
  const auth = { authorization: "Bearer fbd_" + "a".repeat(40) };
  assert.equal((await http("/device/progress", { command_id: id, status: "awaiting_confirmation", progress: { waiting_for: "Overwrite file?" } }, auth)).status, 200);
  assert.equal(mock.state.tables.filebridge_journal[0].state, "awaiting_confirmation");
  mock.state.rpc.filebridge_journal_sync = (a) => ({ ok: true, updated: a.p_entries.length, added: 0 });
  const entries = Array.from({ length: 80 }, (_, i) => ({ command_id: id, i }));
  const r = await http("/device/journal/sync", { entries }, auth);
  assert.equal(r.status, 200);
  assert.equal(r.json.updated, 50, "at most 50 entries per call");
  assert.equal((await http("/device/journal/sync", { entries: [] })).status, 401);
});
