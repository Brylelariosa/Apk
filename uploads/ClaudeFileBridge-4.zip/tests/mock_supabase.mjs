// Minimal in-memory stand-in for @supabase/supabase-js, just enough for supabase/functions/filebridge-mcp/index.ts.
// It is NOT the database: the real SQL is tested separately (tests/sql/). This exists to test the TypeScript logic.
import { randomUUID } from "node:crypto";

export const state = { tables: {}, rpc: {}, calls: [] };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const TABLES = ["filebridge_devices", "filebridge_commands", "filebridge_results", "filebridge_memory", "filebridge_clients", "filebridge_config", "filebridge_file_seen", "filebridge_file_state", "filebridge_journal", "filebridge_project_state", "filebridge_owner_project", "filebridge_device_sessions"];

class Query {
  constructor(table) { this.t = table; this.op = null; this.f = []; this.ord = null; this.lim = null; this.mode = null; this.opts = null; this.ret = false; }
  select(_cols, opts) { if (this.op) this.ret = true; else this.op = "select"; this.opts = opts ?? null; return this; }
  insert(rows) { this.op = "insert"; this.rows = Array.isArray(rows) ? rows : [rows]; return this; }
  update(patch) { this.op = "update"; this.patch = patch; return this; }
  upsert(rows, o) { this.op = "upsert"; this.rows = Array.isArray(rows) ? rows : [rows]; this.onConflict = o?.onConflict; return this; }
  delete() { this.op = "delete"; return this; }
  eq(c, v) { this.f.push((r) => r[c] === v); return this; }
  neq(c, v) { this.f.push((r) => r[c] !== v); return this; }
  in(c, arr) { this.f.push((r) => arr.includes(r[c])); return this; }
  is(c, v) { this.f.push((r) => (r[c] ?? null) === v); return this; }
  order(c, o) { this.ord = { c, asc: o?.ascending !== false }; return this; }
  limit(n) { this.lim = n; return this; }
  maybeSingle() { this.mode = "maybe"; return this; }
  single() { this.mode = "one"; return this; }
  then(res, rej) { return this.exec().then(res, rej); }
  async exec() {
    const tbl = (state.tables[this.t] ??= []);
    const match = () => tbl.filter((r) => this.f.every((fn) => fn(r)));
    // like PostgREST, hand back copies: later updates must not change rows a caller already holds
    const shape = (rows) => {
      rows = structuredClone(rows);
      if (this.mode === "maybe") return { data: rows[0] ?? null, error: null };
      if (this.mode === "one") return rows[0] ? { data: rows[0], error: null } : { data: null, error: { message: "no rows" } };
      return { data: rows, error: null };
    };
    if (this.op === "select") {
      let rows = match();
      if (this.ord) rows = [...rows].sort((a, b) => (a[this.ord.c] > b[this.ord.c] ? 1 : a[this.ord.c] < b[this.ord.c] ? -1 : 0) * (this.ord.asc ? 1 : -1));
      if (this.opts?.count) return { data: this.opts.head ? null : structuredClone(rows), count: rows.length, error: null };
      if (this.lim != null) rows = rows.slice(0, this.lim);
      return shape(rows);
    }
    if (this.op === "insert") { const rows = this.rows.map((r) => ({ id: randomUUID(), ...r })); tbl.push(...rows); return shape(rows); }
    if (this.op === "upsert") { const out = []; for (const r of this.rows) { const k = this.onConflict; const i = k ? tbl.findIndex((x) => x[k] === r[k]) : -1; if (i >= 0) { tbl[i] = { ...tbl[i], ...r }; out.push(tbl[i]); } else { tbl.push(r); out.push(r); } } return shape(out); }
    if (this.op === "update") { const rows = match(); rows.forEach((r) => Object.assign(r, this.patch)); return this.ret ? shape(rows) : { data: null, error: null }; }
    if (this.op === "delete") { const rows = match(); rows.forEach((r) => tbl.splice(tbl.indexOf(r), 1)); return { data: null, error: null }; }
    return { data: null, error: { message: "unsupported" } };
  }
}

function defaultRpc() {
  return {
    filebridge_client_resolve: ({ p_hash }) => { const c = state.tables.filebridge_clients.find((x) => x.token_hash === p_hash && !x.revoked_at); return c ? [{ r_id: c.id, r_name: c.name, r_scopes: c.scopes }] : []; },
    filebridge_enqueue: (a) => {
      const id = randomUUID();
      const row = { id, device_id: a.p_device_id, tool: a.p_tool, args: a.p_args, destructive: a.p_destructive, nonce: a.p_nonce, status: "queued", progress: null, cancel_requested: false, created_at: new Date().toISOString(), expires_at: new Date(Date.now() + (a.p_ttl ?? 90) * 1000).toISOString(), client_name: a.p_client, ttl: a.p_ttl };
      state.tables.filebridge_commands.push(row);
      state.tables.filebridge_journal.push({ command_id: id, device_id: a.p_device_id, project: a.p_project || (a.p_paths?.[0]?.includes("/") ? a.p_paths[0].split("/")[0] : "general"), owner: a.p_owner, tool: a.p_tool, paths: a.p_paths, note: a.p_note, state: "queued" });
      return [row];
    },
    filebridge_finish: (a) => {
      const c = state.tables.filebridge_commands.find((x) => x.id === a.p_id && x.device_id === a.p_device_id && ["delivered", "running", "awaiting_confirmation"].includes(x.status));
      if (!c) return false;
      const st = a.p_status === "rejected" || a.p_status === "cancelled" ? a.p_status : a.p_ok ? "succeeded" : "failed";
      c.status = st; c.args = {};
      state.tables.filebridge_results.push({ command_id: a.p_id, device_id: a.p_device_id, ok: a.p_ok && st === "succeeded", result: a.p_result, error: a.p_error, error_code: a.p_error_code, duration_ms: a.p_duration_ms, consumed_at: null });
      const j = state.tables.filebridge_journal.find((x) => x.command_id === a.p_id);
      if (j) { j.state = st; if (st === "succeeded" && ["write_file", "edit_file", "create_zip", "prepare_project_zip", "copy_file", "move_file", "delete_file", "extract_zip", "create_folder"].includes(j.tool)) { const ps = (state.tables.filebridge_project_state.find((p) => p.project === j.project) ?? (state.tables.filebridge_project_state.push({ project: j.project, revision: 0 }), state.tables.filebridge_project_state.at(-1))); ps.revision++; } }
      return true;
    },
    filebridge_expire_command: ({ p_id }) => { const c = state.tables.filebridge_commands.find((x) => x.id === p_id); if (c && c.status === "queued") c.status = "expired"; return null; },
    filebridge_request_cancel: ({ p_id }) => { const c = state.tables.filebridge_commands.find((x) => x.id === p_id); if (!c) return "not_found"; if (c.status === "queued") { c.status = "cancelled"; return "cancelled"; } c.cancel_requested = true; return "cancel_requested"; },
    filebridge_claim: ({ p_device_id }) => { const c = state.tables.filebridge_commands.find((x) => x.device_id === p_device_id && x.status === "queued"); if (!c) return []; c.status = "delivered"; return [c]; },
    filebridge_hello: () => ({ expired_queued: 0 }),
    filebridge_active_ais: () => [],
    filebridge_memory_projects: () => [],
    filebridge_lease_conflicts: () => [],
    filebridge_pick_project: ({ p_explicit, p_paths }) => [{ r_project: p_explicit || (p_paths?.[0]?.includes("/") ? p_paths[0].split("/")[0] : "general"), r_source: "mock" }],
  };
}

export function resetDb() {
  state.tables = Object.fromEntries(TABLES.map((t) => [t, []]));
  state.rpc = defaultRpc();
  state.calls = [];
}
resetDb();

export function createClient() {
  return {
    from: (t) => new Query(t),
    rpc: async (name, args) => {
      state.calls.push({ name, args });
      const fn = state.rpc[name];
      if (!fn) return { data: null, error: { message: `rpc ${name} not mocked` } };
      try { const data = await fn(args ?? {}); return { data: data === undefined ? null : data, error: null }; }
      catch (e) { return { data: null, error: { message: String(e?.message ?? e) } }; }
    },
  };
}

// ---- simulated phone: answers the next queued command that matches, like the Android app would
export async function phoneAnswer(match, result, opts = {}) {
  for (let i = 0; i < 300; i++) {
    const cmd = state.tables.filebridge_commands.find((c) => c.status === "queued" && (typeof match === "function" ? match(c) : c.tool === match));
    if (cmd) {
      cmd.status = "delivered";
      const snapshot = JSON.parse(JSON.stringify(cmd));
      await sleep(5);
      const r = typeof result === "function" ? result(snapshot) : result;
      state.rpc.filebridge_finish({ p_id: cmd.id, p_device_id: cmd.device_id, p_ok: opts.ok !== false, p_status: opts.status ?? null, p_result: r, p_error: opts.error ?? null, p_error_code: opts.code ?? null, p_bytes: 1, p_duration_ms: 5 });
      return snapshot;
    }
    await sleep(10);
  }
  throw new Error("phone: no queued command matched " + String(match));
}
