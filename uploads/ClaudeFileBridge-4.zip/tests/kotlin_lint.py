#!/usr/bin/env python3
"""Tiny structural check for Kotlin sources (no Kotlin compiler is available in this environment):
balanced (), [], {} outside comments/strings, correctly terminated strings (including ${...} templates), char literals.
It does NOT type-check. Usage: kotlin_lint.py file.kt ..."""
import sys

def lint(src, name):
    pairs = {")": "(", "]": "[", "}": "{"}
    errors = []
    stack = []
    n = len(src)
    line_of = lambda i: src.count("\n", 0, i) + 1

    def skip_string(i, raw):
        # i points just after the opening quote(s); returns index after the closing quote(s)
        while i < n:
            c = src[i]
            if raw:
                if src.startswith('"""', i):
                    j = i + 3
                    while j < n and src[j] == '"': j += 1   # trailing quotes belong to the content
                    return j
            else:
                if c == "\\": i += 2; continue
                if c == '"': return i + 1
                if c == "\n": errors.append(f"{name}:{line_of(i)}: newline inside string literal"); return i
            if c == "$" and i + 1 < n and src[i + 1] == "{":
                i = lex_code(i + 2, True); continue
            i += 1
        errors.append(f"{name}: unterminated string"); return n

    def lex_code(i, in_template=False):
        depth_here = 0
        while i < n:
            c = src[i]
            if src.startswith("//", i):
                while i < n and src[i] != "\n": i += 1
                continue
            if src.startswith("/*", i):
                j = src.find("*/", i + 2)
                if j < 0: errors.append(f"{name}:{line_of(i)}: unterminated comment"); return n
                i = j + 2; continue
            if src.startswith('"""', i): i = skip_string(i + 3, True); continue
            if c == '"': i = skip_string(i + 1, False); continue
            if c == "'":
                j = i + 1
                if j < n and src[j] == "\\": j += 2
                else: j += 1
                while j < n and src[j] != "'" and src[j] != "\n": j += 1   # \u1234 etc.
                if j >= n or src[j] != "'": errors.append(f"{name}:{line_of(i)}: bad char literal")
                i = j + 1; continue
            if c in "([{":
                stack.append((c, line_of(i))); 
                if in_template and c == "{": depth_here += 1
            elif c in ")]}":
                if in_template and c == "}" and depth_here == 0:
                    return i + 1
                if not stack or stack[-1][0] != pairs[c]:
                    errors.append(f"{name}:{line_of(i)}: unexpected '{c}'"); 
                else:
                    stack.pop()
                if in_template and c == "}": depth_here -= 1
            i += 1
        return i

    lex_code(0)
    for ch, ln in stack: errors.append(f"{name}:{ln}: '{ch}' never closed")
    return errors

bad = 0
for f in sys.argv[1:]:
    errs = lint(open(f).read(), f.split("/")[-1])
    print(("OK   " if not errs else "FAIL ") + f.split("/")[-1])
    for e in errs[:8]: print("   ", e)
    bad += bool(errs)
sys.exit(1 if bad else 0)
