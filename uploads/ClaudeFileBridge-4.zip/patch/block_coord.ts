// ---------- 1.2.0: coordination (revisions, leases, journal, tests, resume) ----------
interface OpCtx { owner: string; project: string; note: string; paths: string[] }

// Several AIs on one phone: refuse writes inside somebody else's lease, and never let a replace silently overwrite a
// file that changed since this AI last read it (the phone re-checks the revision atomically before it writes).
async function guardWrite(dev: Dev, tool: string, args: Json, owner: string, paths: string[]): Promise<boolean> {
  const { data: conf, error: ce } = await db.rpc("filebridge_lease_conflicts", { p_owner: owner, p_device: dev.device_id, p_paths: paths });
  if (ce) console.error("lease check failed", ce.message); // coordination aid: fail open, the phone still checks revisions
  if (Array.isArray(conf) && conf.length) {
    const f: any = conf[0];
    throw new ToolErr("locked_by_other", `${f.owner} holds a lease on ${(f.paths ?? []).join(", ")} until ${f.expires_at}${f.purpose ? ` (${f.purpose})` : ""}. Work on other files, wait for it to expire, or ask that AI to release it. If the lease is yours, pass the same 'session' value you used to acquire it.`, { conflicts: conf });
  }
  const replaces = tool === "edit_file" || (tool === "write_file" && args.overwrite === true);
  if (!replaces) return false;
  const path = String(args.path ?? "");
  if (!path) return false;
  if (typeof args.expected_revision === "string" && args.expected_revision) return false;
  const { data: seen } = await db.from("filebridge_file_seen").select("sha256").eq("device_id", dev.device_id).eq("owner", owner).eq("path", path).maybeSingle();
  if (seen?.sha256) { args.expected_revision = String(seen.sha256); return true; }
  const { data: st } = await db.from("filebridge_file_state").select("updated_by,updated_at,deleted,rev").eq("device_id", dev.device_id).eq("path", path).maybeSingle();
  if (st && !st.deleted && st.updated_by !== owner && Date.now() - new Date(st.updated_at).getTime() < 7 * DAY_MS) {
    throw new ToolErr("revision_unseen", `${st.updated_by} changed '${path}' (revision ${st.rev}) and you have not read it since. Read it first (read_file returns its revision), merge, then write again.`, { path, changed_by: st.updated_by, changed_at: st.updated_at });
  }
  return false;
}

// After the phone answered: tell the AI that progress was saved, and verify ZIPs it asked to have verified.
async function decorate(dev: Dev, def: ToolDef, a: Json, args: Json, out: Json, c: Client, ctx: OpCtx, implicit: boolean): Promise<Json> {
  let res = out;
  const settled = res.status === "succeeded" || res.status === "failed" || res.status === "rejected";
  if (MUTATING.has(def.name) && typeof res.operation_id === "string" && settled) {
    try {
      const { data: j } = await db.from("filebridge_journal").select("project").eq("command_id", res.operation_id).maybeSingle();
      if (j?.project) {
        res = { ...res, project: j.project };
        if (res.ok === true) {
          const { data: ps } = await db.from("filebridge_project_state").select("revision").eq("project", j.project).maybeSingle();
          if (ps) res = { ...res, project_revision: ps.revision, autosaved: true };
        }
      }
    } catch (e) { console.error("decorate failed", String(e)); }
  }
  if (implicit && res.ok === true) res = { ...res, revision_checked_against: "the revision you last read" };
  if ((def.name === "create_zip" || def.name === "prepare_project_zip") && res.ok === true && res.status === "succeeded" && args.dry_run !== true) {
    const expect = arr(a, "expect_files", 200, 300);
    let zipPath = "";
    try { if (typeof res.output === "string") zipPath = pth({ p: res.output }, "p"); } catch { /* unusable path: skip the extra check */ }
    if (expect.length && zipPath) {
      const vdef = ALL_TOOLS.find((t) => t.name === "verify_zip")!;
      const v = await runOnDevice(dev, vdef, { path: zipPath, expect_files: expect, deep: false }, false, c, { ...ctx, note: "automatic ZIP verification", paths: [zipPath] });
      if (v.ok === true) res = { ...res, verification: { ok: true, ...v } };
      else res = { ...res, ok: false, error: "zip_verification_failed", message: `The ZIP was created but verification failed: ${String(v.message ?? v.error ?? "unknown")}. Do not report success.`, verification: v };
    }
  }
  return res;
}

const ownerProject = async (owner: string): Promise<string> => {
  const { data } = await db.from("filebridge_owner_project").select("project,updated_at").eq("owner", owner).maybeSingle();
  return data && Date.now() - new Date(data.updated_at).getTime() < 12 * 3_600_000 ? String(data.project) : "";
};

async function coordTool(name: string, a: Json, c: Client): Promise<Json> {
  switch (name) {
    case "resume_project": return await resumeProject(a, c);
    case "project_checkpoint": return await checkpointTool(a, c);
    case "file_lease": return await leaseTool(a, c);
    case "test_run": return await testRunTool(a, c);
  }
  throw new ToolErr("unknown_tool", `Unknown tool '${name}'`);
}

function nextActions(state: Json, ws: Json): string[] {
  const out: string[] = [];
  const unfinished = (state.unfinished_operations as any[]) ?? [];
  for (const u of unfinished) {
    const what = `${u.tool} ${(u.paths ?? []).join(", ")}`;
    out.push(u.kind === "not_executed" ? `Not executed (the phone never ran it): ${what}. Nothing changed; redo it if it is still needed.`
      : u.kind === "interrupted" ? `Interrupted: ${what}. It may have run partly or fully. Read the file(s) and compare with your plan before redoing it.`
      : `Still in flight: ${what}. Call get_operation_status with operation_id ${u.operation_id}.`);
  }
  const tests = ((state.tests as any)?.latest as any[]) ?? [];
  for (const t of tests) {
    if (t.status === "interrupted") out.push(`Test '${t.name}' was interrupted and never finished: re-run it. Do not report it as passed.`);
    else if (t.status === "running") out.push(`Test '${t.name}' is still marked running (started ${t.started_at}). If that session is gone, mark it interrupted and re-run.`);
    else if (t.status === "planned") out.push(`Test '${t.name}' is only planned: nothing has been run yet.`);
    else if ((t.stale_files ?? []).length) out.push(`Test '${t.name}' ${t.status} before ${(t.stale_files as string[]).join(", ")} changed: re-run it before relying on the result.`);
    else if (t.environment === "temp_copy" && t.status === "passed") out.push(`Test '${t.name}' passed on a temporary copy, not on the original files.`);
  }
  for (const l of ((state.leases as any[]) ?? [])) out.push(`${l.owner} holds a lease on ${(l.paths ?? []).join(", ")} until ${l.expires_at}: stay away from those paths.`);
  for (const l of ((state.expired_leases as any[]) ?? [])) out.push(`${l.owner}'s lease on ${(l.paths ?? []).join(", ")} expired without being released: that session probably stopped; check those files.`);
  if (ws.status === "checked") {
    for (const m of (ws.missing as any[]) ?? []) out.push(`Missing on the phone: ${m.path}. FileBridge recorded it but it is gone (deleted elsewhere?).`);
    for (const d of (ws.drifted as any[]) ?? []) out.push(`Changed outside the recorded operations: ${d.path}. Read it before editing.`);
    for (const t of (ws.leftover_temp_files as any[]) ?? []) out.push(`Leftover temporary file next to ${t.path}: ${(t.temp_files ?? []).join(", ")}. A write may have been interrupted; compare and delete it if the real file is complete.`);
  } else if (ws.status === "unsupported_by_app_version") out.push("The FileBridge app is older than 1.2.0, so the files could not be checked on the phone. Update the app.");
  const cp: any = state.checkpoint;
  if (cp?.next_steps?.length) out.push(`Next steps from ${cp.by}'s checkpoint: ${(cp.next_steps as string[]).join("; ")}`);
  if (cp?.pending?.length) out.push(`Pending: ${(cp.pending as string[]).join("; ")}`);
  if (!out.length) out.push("Nothing unfinished was found. Continue with the next task.");
  return out;
}

async function verifyWorkspace(state: Json, c: Client, owner: string, project: string): Promise<Json> {
  const modified = ((state.modified_files as any[]) ?? []).slice(0, 30);
  const unfinished = ((state.unfinished_operations as any[]) ?? []).slice(0, 10);
  const wanted = new Map<string, { sha256: string | null; unfinished: boolean }>();
  for (const m of modified) wanted.set(String(m.path), { sha256: m.sha256 ?? null, unfinished: false });
  for (const u of unfinished) for (const p of (u.paths ?? []) as string[]) if (p && !wanted.has(p)) wanted.set(p, { sha256: null, unfinished: true });
  const paths = [...wanted.keys()].slice(0, 40);
  if (!paths.length) return { status: "nothing_to_check", note: "No files have been changed through FileBridge in this project yet." };
  let dev: Dev;
  try { dev = await resolveDevice(modified[0]?.device_id ?? undefined); } catch (e) { return { status: "unavailable", reason: e instanceof ToolErr ? e.message : String(e) }; }
  try { precheck(dev, "verify_files", {}); } catch (e) { return { status: "unavailable", reason: e instanceof ToolErr ? e.message : String(e) }; }
  const def = ALL_TOOLS.find((t) => t.name === "verify_files")!;
  const out = await runOnDevice(dev, def, { paths, hash: true }, false, c, { owner, project, note: "resume_project check", paths });
  if (out.ok !== true) {
    if (out.error === "unknown_tool") return { status: "unsupported_by_app_version", hint: "Update the FileBridge app to 1.2.0 so resume_project can verify files on the phone." };
    return { status: "unavailable", error: out.error, message: out.message };
  }
  if (out.status !== "succeeded") return { status: "pending", operation_id: out.operation_id, hint: "The phone is still checking; call get_operation_status with this operation_id." };
  const byPath = new Map<string, any>(((out.files as any[]) ?? []).map((f) => [String(f.path), f]));
  const missing: Json[] = [], drifted: Json[] = [], leftovers: Json[] = [], unverified: string[] = [], unfinishedPaths: Json[] = [];
  let okCount = 0;
  for (const p of paths) {
    const exp = wanted.get(p)!;
    const f = byPath.get(p);
    if (!f) { unverified.push(p); continue; }
    if (Array.isArray(f.temp_siblings) && f.temp_siblings.length) leftovers.push({ path: p, temp_files: f.temp_siblings });
    if (exp.unfinished && !exp.sha256) { unfinishedPaths.push({ path: p, exists: !!f.exists, revision: f.revision ?? null, size: f.size ?? null }); continue; }
    if (!f.exists) { missing.push({ path: p, expected_revision: exp.sha256 }); continue; }
    if (exp.sha256 && f.revision && String(f.revision) !== exp.sha256) { drifted.push({ path: p, recorded_revision: exp.sha256, actual_revision: f.revision, size: f.size ?? null }); continue; }
    if (exp.sha256 && f.revision) okCount++; else unverified.push(p);
  }
  return { status: "checked", via: "phone", device_id: dev.device_id, checked: paths.length, matches_journal: okCount, missing, drifted, leftover_temp_files: leftovers, unverified, unfinished_paths: unfinishedPaths };
}

async function resumeProject(a: Json, c: Client): Promise<Json> {
  const owner = ownerOf(c, a);
  const session = sessionOf(a) || hexRand(4);
  let project = str(a, "project", 60, false).trim() || await ownerProject(owner);
  if (!project) {
    const { data: states } = await db.from("filebridge_project_state").select("project,revision,last_activity_at,last_owner").order("last_activity_at", { ascending: false, nullsFirst: false }).limit(20);
    const { data: memProjects } = await db.rpc("filebridge_memory_projects");
    return { ok: true, session, projects: states ?? [], memory_projects: memProjects ?? [], hint: "Call resume_project again with the project name. Use the returned session value as 'session' on every later call.", notice: NOTICE };
  }
  const { data: st, error } = await db.rpc("filebridge_resume_state", { p_project: project, p_owner: owner });
  if (error || !st) { console.error("resume failed", error?.message); throw new ToolErr("internal", "Could not load the project state."); }
  const state = st as Json;
  let memory: Json;
  try {
    const m = await memResume({ project });
    memory = { latest_handoff: m.latest_handoff, in_progress: m.in_progress, open_todos: m.open_todos, pinned: ((m.pinned as any[]) ?? []).filter((x) => x.author !== "filebridge-auto"), active_ais: m.active_ais };
  } catch (e) {
    console.error("resume: memory unavailable", String(e));
    memory = { unavailable: true, reason: "Shared memory could not be read. The automatic journal below is complete on its own." };
  }
  const wantVerify = bool(a, "verify", true);
  let workspace: Json;
  if (!wantVerify) workspace = { status: "skipped", reason: "verify=false" };
  else if (!c.scopes.includes("files")) workspace = { status: "skipped", reason: "this connector has no 'files' scope" };
  else workspace = await verifyWorkspace(state, c, owner, project);
  return {
    ok: true, project, session,
    use_session: `Pass session="${session}" on every later call so other AIs can tell you apart.`,
    project_revision: state.project_revision, last_activity_at: state.last_activity_at, last_owner: state.last_owner,
    next_actions: nextActions(state, workspace),
    unfinished_operations: state.unfinished_operations, workspace_check: workspace,
    tests: state.tests, leases: state.leases, expired_leases: state.expired_leases,
    modified_files: state.modified_files, deleted_files: state.deleted_files, recent_errors: state.recent_errors,
    checkpoint: state.checkpoint, memory, notice: NOTICE,
  };
}

async function checkpointTool(a: Json, c: Client): Promise<Json> {
  const owner = ownerOf(c, a);
  const summary = str(a, "summary", 4000, false);
  const completed = arr(a, "completed", 40, 300), pending = arr(a, "pending", 40, 300), next = arr(a, "next_steps", 40, 300);
  if (!summary && !completed.length && !pending.length && !next.length) throw new ToolErr("invalid_argument", "Give a summary and/or completed, pending or next_steps.");
  noSecrets(summary, ...completed, ...pending, ...next);
  const project = str(a, "project", 60, false).trim() || await ownerProject(owner) || "general";
  const { data, error } = await db.rpc("filebridge_checkpoint", { p_project: project, p_owner: owner, p_summary: summary || null, p_completed: completed, p_pending: pending, p_next: next });
  if (error || !data) { console.error("checkpoint failed", error?.message); throw new ToolErr("internal", "Could not save the checkpoint."); }
  return { ...(data as Json), hint: "Saved. File operations and test runs are recorded automatically; a checkpoint adds what only you know (what is done, what is pending, what comes next). It replaces your previous lists, so always send the full current lists." };
}

async function leaseTool(a: Json, c: Client): Promise<Json> {
  const owner = ownerOf(c, a);
  const action = oneOf(a, "action", ["acquire", "renew", "release", "list"]);
  if (!action) throw new ToolErr("invalid_argument", "'action' is required (acquire, renew, release or list)");
  const leaseId = str(a, "lease_id", 64, false);
  if (leaseId && !UUID_RE.test(leaseId)) throw new ToolErr("invalid_argument", "'lease_id' must come from an earlier acquire");
  const ttl = int(a, "ttl_seconds", 600, 30, 3600);
  if (action === "list") {
    const { data } = await db.rpc("filebridge_lease_list", { p_project: str(a, "project", 60, false).trim() });
    return { ok: true, leases: data ?? [] };
  }
  if (action === "renew") {
    if (!leaseId) throw new ToolErr("invalid_argument", "'lease_id' is required to renew");
    const { data, error } = await db.rpc("filebridge_lease_renew", { p_id: leaseId, p_owner: owner, p_ttl: ttl });
    if (error) throw new ToolErr("internal", "Could not renew the lease.");
    const r = data as Json; if (r.ok === false) throw new ToolErr(String(r.error), String(r.message));
    return r;
  }
  if (action === "release") {
    const { data, error } = await db.rpc("filebridge_lease_release", { p_id: leaseId || null, p_owner: owner });
    if (error) throw new ToolErr("internal", "Could not release the lease.");
    return data as Json;
  }
  const paths = arr(a, "paths", 20, 500).map((p) => pth({ p }, "p")).filter(Boolean);
  if (!paths.length) throw new ToolErr("invalid_argument", "'paths' is required (files or folders to lock; the whole workspace cannot be leased)");
  const purpose = str(a, "purpose", 200, false);
  noSecrets(purpose);
  let deviceId: string | null = str(a, "device_id", 20, false) || null;
  try { deviceId = (await resolveDevice(deviceId ?? undefined)).device_id; } catch { /* lease applies to every phone */ }
  const { data: pick } = await db.rpc("filebridge_pick_project", { p_explicit: str(a, "project", 60, false).trim(), p_owner: owner, p_paths: paths });
  const project = (Array.isArray(pick) ? (pick[0] as any)?.r_project : null) ?? "general";
  const { data, error } = await db.rpc("filebridge_lease_acquire", { p_owner: owner, p_project: project, p_device: deviceId, p_paths: paths, p_ttl: ttl, p_purpose: purpose || null });
  if (error) { console.error("lease acquire failed", error.message); throw new ToolErr("internal", "Could not acquire the lease."); }
  const r = data as Json;
  if (r.ok === false) throw new ToolErr(String(r.error), String(r.message), r.conflicts ? { conflicts: r.conflicts } : undefined);
  return { ...r, hint: "Writes by other AIs to these paths are refused until the lease expires or you release it. Renew it while you keep working; if your session ends unexpectedly it simply expires." };
}

async function testRunTool(a: Json, c: Client): Promise<Json> {
  const owner = ownerOf(c, a);
  const action = oneOf(a, "action", ["plan", "start", "heartbeat", "finish", "interrupt", "list"]);
  if (!action) throw new ToolErr("invalid_argument", "'action' is required (plan, start, heartbeat, finish, interrupt or list)");
  const id = str(a, "id", 64, false);
  if (id && !UUID_RE.test(id)) throw new ToolErr("invalid_argument", "'id' must come from an earlier plan/start");
  const name = str(a, "name", 120, false), command = str(a, "command", 500, false);
  const environment = oneOf(a, "environment", ["original", "temp_copy", "other"]);
  const result = oneOf(a, "result", ["passed", "failed"]);
  let exit: number | null = null;
  if (a.exit_code !== undefined && a.exit_code !== null) {
    if (typeof a.exit_code !== "number" || !Number.isInteger(a.exit_code)) throw new ToolErr("invalid_argument", "'exit_code' must be an integer");
    exit = a.exit_code;
  }
  const files = arr(a, "files", 50, 500).map((p) => pth({ p }, "p")).filter(Boolean);
  const summary = str(a, "summary", 2000, false), errors = str(a, "errors", 4000, false);
  noSecrets(name, command, summary, errors);
  const project = str(a, "project", 60, false).trim() || await ownerProject(owner);
  const { data, error } = await db.rpc("filebridge_test_run", { p_action: action, p_owner: owner, p_project: project, p_id: id || null, p_name: name || null, p_command: command || null, p_environment: environment || null, p_files: files, p_result: result || null, p_exit_code: exit, p_summary: summary || null, p_errors: errors || null });
  if (error || !data) { console.error("test_run failed", error?.message); throw new ToolErr("internal", "Could not record the test run."); }
  const r = data as Json;
  if (r.ok === false) throw new ToolErr(String(r.error), String(r.message));
  const t = r.test as Json | undefined;
  let guidance = "";
  if (t?.status === "planned") guidance = "Planned only: nothing has been run. Call action=start right before you run the command, then action=finish with its real exit code.";
  else if (t?.status === "running") guidance = "Running. Run the command now, then call action=finish with result and the real exit_code. If you stop before it ends, call action=interrupt so nobody reads it as passed.";
  else if (t?.status === "passed" || t?.status === "failed") guidance = t.environment === "temp_copy" ? `Recorded as ${t.status} on a TEMPORARY COPY: say so when you report it; it does not prove the original files.` : `Recorded as ${t.status}.`;
  else if (t?.status === "interrupted") guidance = "Recorded as interrupted: it did not finish and must not be reported as passed.";
  return guidance ? { ...r, guidance } : r;
}
