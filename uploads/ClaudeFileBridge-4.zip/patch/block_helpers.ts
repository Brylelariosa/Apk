// ---------- 1.2.0: sessions, owners, touched paths ----------
// Every call is attributed to an "owner": the connector name, plus the optional `session` label an AI passes so that
// two chats using the same connector can still be told apart (leases, revisions and the journal use the owner).
const SESSION_RE = /^[A-Za-z0-9_.-]{1,32}$/;
const SHA_RE = /^[0-9a-f]{64}$/i;
const MUTATING = new Set(["write_file", "edit_file", "create_folder", "copy_file", "move_file", "delete_file", "create_zip", "extract_zip", "prepare_project_zip"]);
const sessionOf = (a: Json): string => {
  const s = str(a, "session", 32, false);
  if (s && !SESSION_RE.test(s)) throw new ToolErr("invalid_argument", "'session' may only contain letters, digits, '_', '.' and '-' (max 32 characters)");
  return s;
};
const ownerOf = (c: { name: string }, a: Json): string => { const s = sessionOf(a); return s ? `${c.name}#${s}` : c.name; };
const sha = (a: Json, k: string): string => {
  const v = str(a, k, 64, false);
  if (v && !SHA_RE.test(v)) throw new ToolErr("invalid_argument", `'${k}' must be a revision (64 hex characters) returned by read_file, get_file_info, verify_files, write_file or edit_file`);
  return v.toLowerCase();
};

// Paths an operation touches, in the order the journal expects (source before destination).
function touchedPaths(name: string, a: Json): string[] {
  const g = (k: string) => (typeof a[k] === "string" ? (a[k] as string) : "");
  switch (name) {
    case "write_file": case "edit_file": case "create_folder": case "delete_file": return [g("path")];
    case "read_file": case "get_file_info": case "list_files": case "verify_zip": return [g("path")].filter(Boolean);
    case "copy_file": case "move_file": return [g("source"), g("destination")];
    case "create_zip": return [g("source"), g("output")];
    case "prepare_project_zip": return [g("project"), g("output")];
    case "extract_zip": return [g("zip"), g("destination")];
    case "verify_files": return Array.isArray(a.paths) ? (a.paths as unknown[]).filter((x): x is string => typeof x === "string").slice(0, 40) : [];
    case "start_build": return [g("zip") || g("project")].filter(Boolean);
    default: return [];
  }
}

// Paths an operation changes. Leases only guard these: the source folder of a ZIP, or the source of a copy, is only read.
function writtenPaths(name: string, a: Json): string[] {
  const g = (k: string) => (typeof a[k] === "string" ? (a[k] as string) : "");
  switch (name) {
    case "copy_file": case "extract_zip": return [g("destination")];
    case "create_zip": case "prepare_project_zip": return [g("output")];
    default: return touchedPaths(name, a);
  }
}

const DAY_MS = 86_400_000;
