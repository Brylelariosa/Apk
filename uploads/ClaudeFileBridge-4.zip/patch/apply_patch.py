#!/usr/bin/env python3
"""Builds supabase/functions/filebridge-mcp/index.ts (1.2.0) from the deployed 1.1.0 source.
Every replacement must match exactly once, so the unchanged 1.1.0 code stays byte-identical."""
import re, sys, pathlib

SRC = pathlib.Path(sys.argv[1])
DST = pathlib.Path(sys.argv[2])
HERE = pathlib.Path(__file__).parent
s = SRC.read_text()

def rep(old, new, label):
    global s
    n = s.count(old)
    if n != 1:
        raise SystemExit(f"patch '{label}': expected exactly 1 match, found {n}")
    s = s.replace(old, new)

def rep_line(prefix, new, label):
    """Replace the single line that starts with `prefix`."""
    global s
    lines = s.split("\n")
    idx = [i for i, l in enumerate(lines) if l.startswith(prefix)]
    if len(idx) != 1:
        raise SystemExit(f"patch '{label}': expected exactly 1 line, found {len(idx)}")
    lines[idx[0]] = new
    s = "\n".join(lines)

# ---- version / features
rep('const VERSION = "1.1.0";',
    'const VERSION = "1.2.0";\n'
    'const FEATURES = ["write_verify_readback", "edit_file", "revision_guard", "leases", "journal", "resume_project", "test_runs", "verify_files", "verify_zip", "late_journal_sync"];',
    "version")

rep('local?: boolean; memory?: boolean; wait: number }',
    'local?: boolean; memory?: boolean; coord?: boolean; wait: number }', "ToolDef")

# ---- helpers block (sessions, owners, touched paths)
rep('// ---------- tool catalogue (narrow, typed; no shell, no exec) ----------',
    (HERE / "block_helpers.ts").read_text() + '\n// ---------- tool catalogue (narrow, typed; no shell, no exec) ----------', "helpers")

rep('const PATHS = "Paths are relative to the user\'s Claude Workspace folder; ZIP/, APK/ and BuildWorkspace/ are virtual folders for the output locations the user picked.";',
    'const PATHS = "Paths are relative to the user\'s Claude Workspace folder; ZIP/, APK/ and BuildWorkspace/ are virtual folders for the output locations the user picked.";\n'
    'const EXPECT = A("Optional. Entries that must be inside the finished ZIP (exact path, or \'folder/\' for at least one entry below it). FileBridge re-opens the ZIP after creating it and fails with zip_verification_failed if anything is missing. Up to 200.");',
    "PATHS/EXPECT")

# ---- write_file + edit_file
WRITE = ('  { name: "write_file", title: "Write file", destructive: true, wait: 25000, required: ["path", "content"], props: { '
         'path: S("File to write."), content: S("Full text content (UTF-8, up to 1.5M chars)."), '
         'overwrite: B("Replace the COMPLETE content of an existing file (in place, verified by reading it back). Default false: an existing file is never touched and the error shows its current revision. Needs the Modify permission; unless the user chose Always allow on the phone, FileBridge asks there."), '
         'expected_revision: S("Optional. Revision (sha256) from your last read_file or write_file of this file; the write is refused with revision_conflict if the file changed since. Filled in automatically from what you last read when omitted."), '
         'create_parents: B("Create missing parent folders. Default true.") }, '
         'description: `Creates a text file, or with overwrite=true replaces the complete content of an existing one, directly in the user\'s workspace. Identical content is a no-op. The result carries the new revision and read-back verification. Never delete a file to rewrite it. ${PATHS}` },\n'
         '  { name: "edit_file", title: "Edit file in place", destructive: true, wait: 25000, required: ["path", "edits"], props: { '
         'path: S("Existing text file."), '
         'edits: { type: "array", minItems: 1, maxItems: 20, description: "Replacements applied in order, all or nothing. Each old_text must match exactly once unless replace_all is true.", '
         'items: { type: "object", properties: { old_text: S("Exact text to find (include enough context to be unique)."), new_text: S("Replacement text (may be empty to delete)."), replace_all: B("Replace every occurrence. Default false.") }, required: ["old_text", "new_text"] } }, '
         'expected_revision: S("Optional revision (sha256) you last read; refused with revision_conflict if the file changed since. Filled in automatically from what you last read when omitted.") }, '
         'description: `Changes part of an existing text file in place without resending it: each old_text must occur exactly once (or use replace_all). The whole file is rewritten, verified by reading it back, and its new revision is returned. Prefer this over write_file for small changes. ${PATHS}` },')
rep_line('  { name: "write_file",', WRITE, "write_file tool")

# ---- verify_files / verify_zip after get_file_info
lines = s.split("\n")
i = [k for k, l in enumerate(lines) if l.startswith('  { name: "get_file_info"')]
assert len(i) == 1
lines[i[0]] = lines[i[0]] + (
    '\n  { name: "verify_files", title: "Verify files", ro: true, wait: 30000, required: ["paths"], props: { paths: A("Up to 40 files or folders."), hash: B("Compute each file\'s revision (sha256, files up to 32 MB). Default true.") }, '
    'description: `Checks that files exist and returns size, modified time, revision and leftover temporary files (*.fbtmp) next to them. Use it to confirm what is really on the phone before you report success. ${PATHS}` },'
    '\n  { name: "verify_zip", title: "Verify ZIP", ro: true, wait: 50000, required: ["path"], props: { path: S("ZIP file to check."), expect_files: A("Entries that must be inside (exact path, or \'folder/\' for at least one entry below it). Up to 200."), deep: B("Also read every entry to check its CRC (slower). Default false.") }, '
    'description: `Opens a ZIP in the workspace, lists its entries and checks that the expected files are inside (with deep=true also that no entry is corrupt). Fails with zip_verification_failed when something is missing. ${PATHS}` },')
s = "\n".join(lines)

# ---- expect_files on the two ZIP creators
rep('include_root_folder: B("Put everything under a top-level folder named after the source. Default false.") }',
    'include_root_folder: B("Put everything under a top-level folder named after the source. Default false."), expect_files: EXPECT }', "create_zip expect")
rep('overwrite: B("Replace an existing ZIP. Default false.") }, description: `Stages',
    'overwrite: B("Replace an existing ZIP. Default false."), expect_files: EXPECT }, description: `Stages', "prepare_project_zip expect")

# ---- coordination tools + tool list
COORD_DEFS = r'''const SESSION_PROP = { session: S("Optional. Label of this AI session (resume_project returns one). Use the same value on every call so leases, revisions and the project journal can tell your session apart from other AIs using the same connector.", { maxLength: 32 }) };
const COMMON_PROPS = { project: S("Optional. Project this belongs to; defaults to the project you resumed, else the first folder of the path."), ...SESSION_PROP };
const NOTE_PROP = { note: S("Optional short label saved in the project journal, e.g. 'fix overwrite prompt'. Never include secrets.") };
const COORD_TOOLS: ToolDef[] = [
  { name: "resume_project", title: "Resume a project (journal + real files)", coord: true, local: true, ro: true, wait: 0, required: [], props: { project: PROJ, verify: B("Compare the recently changed files with what is really on the phone. Default true."), ...SESSION_PROP }, description: "START HERE when a session begins, after a usage limit, or when taking over from another AI. FileBridge saves progress automatically after every file operation, so this returns the project's latest state even if the previous AI never wrote a handoff: modified files with revisions, unfinished or interrupted operations, tests with honest states (planned, running, passed, failed, interrupted), leases held by other AIs, the latest checkpoint and handoff, and the result of comparing those files with what is really on the phone. It also returns a session value to pass on later calls." },
  { name: "project_checkpoint", title: "Save a progress checkpoint", coord: true, local: true, wait: 0, required: [], props: { project: PROJ, summary: S("What is done and the current state."), completed: A("Tasks completed (full current list)."), pending: A("Work still to do (full current list)."), next_steps: A("Concrete next actions."), ...SESSION_PROP }, description: "Records what only you know: finished tasks, pending work and next steps. File operations and test runs are journalled automatically; this adds the plan. Each call replaces your previous lists. Shown by resume_project and mirrored into shared memory." },
  { name: "file_lease", title: "Lease files or folders", coord: true, local: true, wait: 0, required: ["action"], props: { action: S("acquire, renew, release or list.", { enum: ["acquire", "renew", "release", "list"] }), paths: A("acquire: files or folders to reserve (up to 20)."), lease_id: S("renew/release: id from acquire. Release without it frees all your leases."), ttl_seconds: I("30-3600, default 600. Leases expire by themselves, so a stopped session never blocks the others for long.", 30, 3600), purpose: S("Short reason shown to other AIs."), project: PROJ, ...SESSION_PROP, ...DEV_PROP }, description: "Reserves files or folders while you work on them: other AIs' writes to leased paths are refused until the lease expires or is released. Several AIs can lease different paths at the same time. Reads are never blocked." },
  { name: "test_run", title: "Record a test run", coord: true, local: true, wait: 0, required: ["action"], props: { action: S("plan, start, heartbeat, finish, interrupt or list.", { enum: ["plan", "start", "heartbeat", "finish", "interrupt", "list"] }), id: S("Test run id (every action except plan, start without id, and list)."), name: S("Short test name, e.g. 'unit tests'."), command: S("The exact command that is or will be run."), environment: S("original = run against the original files in the workspace; temp_copy = run on a temporary copy elsewhere (say so honestly); other.", { enum: ["original", "temp_copy", "other"] }), files: A("Files the test covers. Their revisions are captured at start so later edits mark the result stale."), result: S("finish: passed or failed.", { enum: ["passed", "failed"] }), exit_code: I("finish: the real exit code of the command."), summary: S("finish: one-line outcome."), errors: S("finish: error output or reason."), project: PROJ, ...SESSION_PROP }, description: "Keeps an honest record of tests and builds. FileBridge cannot run commands itself, so run them where they can run (a temporary copy, recorded as environment=temp_copy) and record them here: plan, start, then finish(passed or failed) or interrupt. A planned test can never become passed without being started, passed needs exit_code 0, and a test whose session vanished is marked interrupted automatically. A result goes stale when a covered file changes afterwards." },
];
const ALL_TOOLS: ToolDef[] = [...TOOLS, ...MEM_TOOLS, ...COORD_TOOLS];
const TOOL_LIST = ALL_TOOLS.map((t) => ({
  name: t.name, title: t.title, description: t.description,
  inputSchema: { type: "object", properties: { ...t.props, ...(t.local ? {} : DEV_PROP), ...(t.local || t.open ? {} : COMMON_PROPS), ...(MUTATING.has(t.name) ? NOTE_PROP : {}) }, required: t.required },
  annotations: { title: t.title, readOnlyHint: !!t.ro, destructiveHint: !!t.destructive, idempotentHint: !!t.ro, openWorldHint: !!t.open },
}));'''
# drop the old ALL_TOOLS/TOOL_LIST definitions and install the new ones
m = re.search(r'const ALL_TOOLS: ToolDef\[\] = \[\.\.\.TOOLS, \.\.\.MEM_TOOLS\];\nconst TOOL_LIST = ALL_TOOLS\.map\(\(t\) => \(\{\n.*?\n\}\)\);\n', s, re.S)
if not m:
    raise SystemExit("patch 'tool list': block not found")
s = s[:m.start()] + COORD_DEFS + "\n" + s[m.end():]

# ---- scopes and permissions
rep_line('const toolScopes = ',
         'const COORD = new Set(["resume_project", "project_checkpoint", "file_lease", "test_run"]);\n'
         'const toolScopes = (n: string): string[] => COORD.has(n) ? ["memory", "files", "builds"] : n.startsWith("memory_") ? ["memory"] : BUILD_TOOLS.has(n) ? ["builds"] : (n === "get_operation_status" || n === "cancel_operation") ? ["files", "builds"] : ["files"];',
         "toolScopes")
rep('write_file: "create", create_folder:', 'write_file: "create", edit_file: "modify", verify_files: "read", verify_zip: "read", create_folder:', "PERM")

# ---- prep(): write_file expected_revision, edit_file, verify_files, verify_zip
rep('''      const ow = bool(a, "overwrite", false);
      return { args: { path: pth(a, "path"), content: c, overwrite: ow, create_parents: bool(a, "create_parents", true) }, destructive: ow };
    }''',
    '''      const ow = bool(a, "overwrite", false);
      const er = sha(a, "expected_revision");
      return { args: { path: pth(a, "path"), content: c, overwrite: ow, create_parents: bool(a, "create_parents", true), ...(er ? { expected_revision: er } : {}) }, destructive: ow };
    }
    case "edit_file": {
      const raw = a.edits;
      if (!Array.isArray(raw) || raw.length < 1 || raw.length > 20) throw new ToolErr("invalid_argument", "'edits' must be a list of 1-20 {old_text, new_text} objects");
      let total = 0;
      const edits = raw.map((e: unknown, i: number) => {
        const o = (e && typeof e === "object" ? e : {}) as Json;
        const oldT = o.old_text, newT = o.new_text;
        if (typeof oldT !== "string" || !oldT.length) throw new ToolErr("invalid_argument", `edits[${i}].old_text must be a non-empty string`);
        if (typeof newT !== "string") throw new ToolErr("invalid_argument", `edits[${i}].new_text must be a string`);
        if (o.replace_all !== undefined && typeof o.replace_all !== "boolean") throw new ToolErr("invalid_argument", `edits[${i}].replace_all must be true or false`);
        total += oldT.length + newT.length;
        return { old_text: oldT, new_text: newT, replace_all: o.replace_all === true };
      });
      if (total > 1_500_000) throw new ToolErr("too_large", "the edits are limited to 1.5M characters in total");
      const er = sha(a, "expected_revision");
      return { args: { path: pth(a, "path"), edits, ...(er ? { expected_revision: er } : {}) }, destructive: true };
    }
    case "verify_files": {
      const raw = a.paths;
      if (!Array.isArray(raw) || raw.length < 1 || raw.length > 40 || raw.some((x) => typeof x !== "string" || x.length > 1024)) throw new ToolErr("invalid_argument", "'paths' must be 1-40 short strings");
      return { args: { paths: (raw as string[]).map((p) => pth({ p }, "p", false)), hash: bool(a, "hash", true) }, destructive: false };
    }
    case "verify_zip": return { args: { path: pth(a, "path"), expect_files: arr(a, "expect_files", 200, 300), deep: bool(a, "deep", false) }, destructive: false };''',
    "prep")

# ---- confirmation hint (names the real source of the prompt)
rep('''return { ok: true, status: c.status, operation_id: id, progress: c.progress ?? undefined, hint: c.status === "awaiting_confirmation" ? "Waiting for the user to approve on the phone. Call get_operation_status to keep waiting." : "Still running. Call get_operation_status with this operation_id to keep waiting." };''',
    '''return { ok: true, status: c.status, operation_id: id, progress: c.progress ?? undefined, ...(c.status === "awaiting_confirmation" ? { confirmation_source: "filebridge_app", hint: "FileBridge on the phone is asking the user to approve this operation. This prompt comes from the FileBridge app itself, not from Android and not from Claude. Ask the user to tap Allow, or Always allow to stop being asked about overwrites in this workspace. Call get_operation_status to keep waiting; other AIs' changes queue behind it." } : { hint: "Still running. Call get_operation_status with this operation_id to keep waiting." }) };''',
    "await hint")

# ---- runOnDevice carries owner / project / paths / note into the journal
rep('async function runOnDevice(dev: Dev, def: ToolDef, args: Json, destructive: boolean, c: Client): Promise<Json> {',
    'async function runOnDevice(dev: Dev, def: ToolDef, args: Json, destructive: boolean, c: Client, ctx?: OpCtx): Promise<Json> {', "runOnDevice sig")
rep('p_nonce: hexRand(12), p_client: c.name });',
    'p_nonce: hexRand(12), p_client: c.name, p_owner: ctx?.owner ?? c.name, p_project: ctx?.project || null, p_paths: ctx?.paths ?? [], p_note: ctx?.note || null });', "enqueue params")

# ---- list_devices: what the phone will ask, which features it has
rep('permissions: d.state?.permissions ?? null, workspace: d.state?.workspace ?? null,',
    'permissions: d.state?.permissions ?? null, workspace: d.state?.workspace ?? null, confirmations: d.state?.confirmations ?? null, features: d.state?.features ?? null,', "listDevices")

# ---- dispatch
rep('  if (def.memory) return await memoryTool(def.name, a, c);\n',
    '  if (def.memory) return await memoryTool(def.name, a, c);\n  if (def.coord) return await coordTool(def.name, a, c);\n', "dispatch coord")
rep('''  precheck(dev, def.name, args);
  return await runOnDevice(dev, def, args, destructive, c);
}''',
    '''  precheck(dev, def.name, args);
  const owner = ownerOf(c, a);
  const note = str(a, "note", 200, false).trim();
  noSecrets(note);
  const ctx: OpCtx = { owner, project: str(a, "project", 60, false).trim(), note, paths: touchedPaths(def.name, args) };
  const implicit = MUTATING.has(def.name) ? await guardWrite(dev, def.name, args, owner, writtenPaths(def.name, args)) : false;
  const out = await runOnDevice(dev, def, args, destructive, c, ctx);
  return await decorate(dev, def, a, args, out, c, ctx, implicit);
}''', "dispatch device")

# ---- memory: auto-managed entries are read-only for AIs
rep('  const exp = a.expected_version;\n',
    '  if (cur.author === "filebridge-auto") throw new ToolErr("auto_managed", "This entry is written by FileBridge itself after every file operation and cannot be edited. Use project_checkpoint to record tasks and next steps.");\n  const exp = a.expected_version;\n', "memWrite auto")
rep('  noSecrets(text);\n  const { data, error } = await db.rpc("filebridge_memory_append",',
    '  noSecrets(text);\n  const { data: cur0 } = await db.from("filebridge_memory").select("author").eq("id", id).maybeSingle();\n  if (cur0?.author === "filebridge-auto") throw new ToolErr("auto_managed", "This entry is written by FileBridge itself after every file operation and cannot be appended to. Use project_checkpoint to record tasks and next steps.");\n  const { data, error } = await db.rpc("filebridge_memory_append",', "memAppend auto")
rep('    recent: ((r.data ?? []) as any[]).map(brief),\n    active_ais: activeAis,\n    notice: NOTICE,',
    '    recent: ((r.data ?? []) as any[]).map(brief),\n    active_ais: activeAis,\n    progress_hint: "FileBridge also saves file progress automatically. Call resume_project for unfinished operations, test states and a check against the real files.",\n    notice: NOTICE,', "memResume hint")

# ---- coordination block
rep('// ---------- MCP (Streamable HTTP, JSON responses) ----------',
    (HERE / "block_coord.ts").read_text() + '\n// ---------- MCP (Streamable HTTP, JSON responses) ----------', "coord block")

# ---- instructions
FILES_NEW = ('const FILES_TEXT = "FILES: work on the user\'s files directly through FileBridge; paths are relative to the user\'s Claude Workspace folder (ZIP/, APK/ and BuildWorkspace/ are virtual output folders). '
 'Do not copy a project into your own sandbox just to edit it: read_file, edit_file (surgical, verified) and write_file (complete replacement, verified by reading it back) change the original files in place. '
 'Only when you must compile or test something FileBridge cannot run, copy the smallest set of files you need and record the run with test_run (environment=temp_copy) so nobody mistakes it for a test of the originals. '
 'To change an existing file use edit_file or write_file with overwrite=true; never delete and recreate it. Reads return a revision; if another AI or the user changed the file after you read it, the write is refused with revision_conflict (read it again and merge). '
 'Every operation runs under permissions the user controls (move/delete/upload are OFF by default). Any confirmation prompt is shown by the FileBridge app on the phone, never by Android or this server. If a result says permission_denied, claude_disabled, emergency_stop or awaiting_confirmation, tell the user and do not retry in a loop. '
 'Long operations return status=running with an operation_id: call get_operation_status to wait. After create_zip or prepare_project_zip pass expect_files so the ZIP is verified before you report success. '
 'Never report a build or test as passed unless it really ran. Files are never uploaded to this server; only small structured results pass through it. '
 'Other AIs may use the phone at the same time: reads run in parallel, changes run one at a time, and each AI may have at most 5 operations waiting.";')
rep_line('const FILES_TEXT = ', FILES_NEW, "FILES_TEXT")
rep('function instructionsFor(c: Client): string {',
    'const COORD_TEXT = "COORDINATION: progress is saved automatically after every file operation and test run, so nothing depends on you remembering to write a handoff. Call resume_project at the start of every session (also after a usage limit or when taking over from another AI): it lists unfinished or interrupted operations, test states and what is really on the phone, and returns a session value. Pass that session on every later call. Before a longer edit lease the files with file_lease. Add what only you know with project_checkpoint. Record every test or build with test_run and never present a planned, running, interrupted or failed test as passed.";\nfunction instructionsFor(c: Client): string {', "COORD_TEXT")
rep('  if (c.scopes.includes("memory")) t += " " + MEMORY_TEXT;\n',
    '  if (c.scopes.includes("memory")) t += " " + MEMORY_TEXT;\n  if (c.scopes.length) t += " " + COORD_TEXT;\n', "instructionsFor")

# ---- device endpoints
rep('''.eq("id", b.command_id).eq("device_id", dev.device_id).in("status", ["delivered", "running", "awaiting_confirmation"]);
      return json({ ok: true });''',
    '''.eq("id", b.command_id).eq("device_id", dev.device_id).in("status", ["delivered", "running", "awaiting_confirmation"]);
      await db.from("filebridge_journal").update({ state: status }).eq("command_id", b.command_id).eq("device_id", dev.device_id).in("state", ["queued", "delivered", "running", "awaiting_confirmation"]);
      return json({ ok: true });''', "progress journal")
rep('    case "/device/state": {',
    '''    case "/device/journal/sync": {
      const entries = Array.isArray(b.entries) ? b.entries.slice(0, 50) : [];
      const { data, error } = await db.rpc("filebridge_journal_sync", { p_device_id: dev.device_id, p_entries: entries });
      if (error) { console.error("journal sync failed", error.message); return json({ error: "internal" }, 500); }
      return json({ ok: true, ...((data as Json) ?? {}) });
    }
    case "/device/state": {''', "journal sync")

rep('json({ ok: true, service: FN, version: VERSION })', 'json({ ok: true, service: FN, version: VERSION, features: FEATURES })', "health")

DST.write_text(s)
print("wrote", DST, len(s), "bytes,", s.count("\n") + 1, "lines")
