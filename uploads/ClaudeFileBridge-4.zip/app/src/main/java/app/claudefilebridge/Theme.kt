package app.claudefilebridge

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Shapes
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

val GoodColor = Color(0xFF6FD99B)
val WarnColor = Color(0xFFFFC857)
val BadColor = Color(0xFFFF7A7A)
val MutedColor = Color(0xFF8A96A6)
val DangerColor = Color(0xFFB3261E)

val FbColors = darkColorScheme(
    primary = Color(0xFF8AB4FF),
    onPrimary = Color(0xFF002B66),
    primaryContainer = Color(0xFF1F3F73),
    onPrimaryContainer = Color(0xFFD9E5FF),
    secondary = Color(0xFFB4C7E8),
    onSecondary = Color(0xFF1B2C46),
    secondaryContainer = Color(0xFF2A3B57),
    onSecondaryContainer = Color(0xFFD7E3FF),
    tertiary = Color(0xFF7FD8C3),
    background = Color(0xFF0E1218),
    onBackground = Color(0xFFE4E9F0),
    surface = Color(0xFF151B23),
    onSurface = Color(0xFFE4E9F0),
    surfaceVariant = Color(0xFF212A35),
    onSurfaceVariant = Color(0xFFAAB5C3),
    outline = Color(0xFF3B4756),
    error = Color(0xFFFF8A80),
    onError = Color(0xFF3A0905)
)

val FbShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp)
)

/** Vector icon from res/drawable (no emoji anywhere in the UI). */
@Composable
fun Icn(res: Int, modifier: Modifier = Modifier, tint: Color = LocalContentColor.current, size: Dp = 20.dp, desc: String? = null) {
    Icon(painter = painterResource(res), contentDescription = desc, modifier = modifier.size(size), tint = tint)
}

enum class BtnStyle { Primary, Tonal, Outline, Danger }

/** A real Material button (filled, tonal, outlined or danger) with an optional leading icon. */
@Composable
fun AppButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: Int? = null,
    enabled: Boolean = true,
    style: BtnStyle = BtnStyle.Primary
) {
    val body: @Composable RowScope.() -> Unit = {
        if (icon != null) {
            Icn(icon, size = 18.dp)
            Spacer(Modifier.width(8.dp))
        }
        Text(text)
    }
    when (style) {
        BtnStyle.Primary -> Button(onClick = onClick, modifier = modifier, enabled = enabled, content = body)
        BtnStyle.Tonal -> FilledTonalButton(onClick = onClick, modifier = modifier, enabled = enabled, content = body)
        BtnStyle.Outline -> OutlinedButton(onClick = onClick, modifier = modifier, enabled = enabled, content = body)
        BtnStyle.Danger -> Button(
            onClick = onClick,
            modifier = modifier,
            enabled = enabled,
            colors = ButtonDefaults.buttonColors(containerColor = DangerColor, contentColor = Color.White),
            content = body
        )
    }
}

/** Icon-only button (real IconButton). */
@Composable
fun IconBtn(icon: Int, desc: String, onClick: () -> Unit, modifier: Modifier = Modifier, tonal: Boolean = false) {
    if (tonal) {
        FilledTonalIconButton(onClick = onClick, modifier = modifier) { Icn(icon, desc = desc) }
    } else {
        IconButton(onClick = onClick, modifier = modifier) { Icn(icon, desc = desc) }
    }
}

@Composable
fun AppCard(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    val base = if (onClick != null) modifier.fillMaxWidth().clickable(onClick = onClick) else modifier.fillMaxWidth()
    Card(
        modifier = base,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))
    ) {
        Column(Modifier.padding(16.dp), content = content)
    }
}

@Composable
fun SectionHeader(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.labelLarge,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 4.dp, bottom = 6.dp)
    )
}

@Composable
fun Hint(text: String) {
    Text(text, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
fun Pill(text: String, color: Color) {
    Surface(shape = RoundedCornerShape(50), color = color.copy(alpha = 0.16f)) {
        Text(
            text,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp),
            color = color,
            style = MaterialTheme.typography.labelMedium
        )
    }
}

@Composable
fun StatusDot(color: Color, size: Dp = 14.dp) {
    Box(Modifier.size(size).background(color, CircleShape))
}

@Composable
fun ToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit, sub: String? = null) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(label)
            if (sub != null) Hint(sub)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun AppField(label: String, value: String, onChange: (String) -> Unit, secret: Boolean = false, modifier: Modifier = Modifier) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = true,
        visualTransformation = if (secret) PasswordVisualTransformation() else VisualTransformation.None,
        modifier = modifier.fillMaxWidth().padding(vertical = 3.dp)
    )
}

/** Title for the bottom-navigation screens; [trailing] holds icon buttons on the right. */
@Composable
fun TitleBar(title: String, trailing: @Composable RowScope.() -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 12.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
        trailing()
    }
}

/** Title for sub-screens with a real back button. */
@Composable
fun SubHeader(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        IconBtn(R.drawable.ic_back, "Back", onBack)
        Spacer(Modifier.width(4.dp))
        Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
    }
}

fun copyToClipboard(ctx: Context, label: String, text: String) {
    val cm = ctx.getSystemService(ClipboardManager::class.java)
    cm.setPrimaryClip(ClipData.newPlainText(label, text))
}

/** "3 min ago" style text from an ISO-8601 timestamp (PostgREST format). */
fun ago(iso: String?): String {
    if (iso.isNullOrEmpty() || iso == "null") return "never"
    return try {
        val t = java.time.OffsetDateTime.parse(iso).toInstant().toEpochMilli()
        val s = (System.currentTimeMillis() - t) / 1000
        when {
            s < 45 -> "just now"
            s < 3600 -> (s / 60).toString() + " min ago"
            s < 86400 -> (s / 3600).toString() + " h ago"
            else -> (s / 86400).toString() + " d ago"
        }
    } catch (e: Exception) {
        iso.take(16)
    }
}
