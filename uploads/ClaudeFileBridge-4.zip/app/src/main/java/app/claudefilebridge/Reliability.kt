package app.claudefilebridge

import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.InputStream
import java.security.MessageDigest
import java.util.zip.ZipFile
import java.util.zip.ZipInputStream

/** Capabilities this app version reports to the backend (shown by list_devices). */
object Features {
    val list: JSONArray = JSONArray(
        listOf("write_verify_readback", "edit_file", "revision_guard", "verify_files", "verify_zip", "overwrite_always_allow", "device_journal")
    )
}

/** Content revisions: the lowercase hex SHA-256 of a file's exact bytes. */
object Revisions {
    const val MAX_HASH_BYTES = 32L * 1024 * 1024
    private const val HEX = "0123456789abcdef"

    private fun hex(b: ByteArray): String {
        val sb = StringBuilder(b.size * 2)
        for (x in b) {
            val v = x.toInt() and 0xff
            sb.append(HEX[v shr 4]).append(HEX[v and 0x0f])
        }
        return sb.toString()
    }

    fun sha256(bytes: ByteArray): String = hex(MessageDigest.getInstance("SHA-256").digest(bytes))

    /** Streams [inp] through SHA-256; null when more than [max] bytes would have to be read. */
    fun sha256(inp: InputStream, max: Long = MAX_HASH_BYTES): String? {
        val md = MessageDigest.getInstance("SHA-256")
        val buf = ByteArray(64 * 1024)
        var total = 0L
        while (true) {
            val n = inp.read(buf)
            if (n < 0) break
            total += n
            if (total > max) return null
            md.update(buf, 0, n)
        }
        return hex(md.digest())
    }

    /** Revision of a stored file; null for folders, files above [MAX_HASH_BYTES] and files that cannot be read. */
    fun of(t: Tree, n: Node): String? {
        if (n.isDir || n.size > MAX_HASH_BYTES) return null
        return try {
            t.openIn(n).use { sha256(it) }
        } catch (e: Exception) {
            null
        }
    }
}

/**
 * The single place that decides whether replacing an existing file needs the user's approval on the phone.
 * "Always allow" is stored per workspace folder in SharedPreferences, so it survives repeated overwrites and app restarts,
 * and does not apply to any other folder.
 */
object OverwriteGate {
    /** never_ask (Confirm overwrites is off), always_allow (the user chose it for this workspace) or ask. */
    fun policyFor(treeUri: String?): String = when {
        !Prefs.confirmOverwrite -> "never_ask"
        treeUri != null && treeUri in Prefs.overwriteGrants -> "always_allow"
        else -> "ask"
    }

    fun policy(t: Tree): String = policyFor(t.treeUri.toString())

    /** Returns true when the user was asked and approved. Throws "declined" when the answer is no. */
    suspend fun ensure(ctx: OpCtx, t: Tree, title: String, detail: String): Boolean {
        if (policy(t) != "ask") return false
        val ask = ctx.confirmOverwrite
        val ok = if (ask != null) ask(title, detail, t.treeUri.toString()) else ctx.confirm(title, detail)
        if (!ok) throw OpError("declined", "The user declined the overwrite. Nothing was changed.")
        return true
    }

    fun describe(t: Tree, asked: Boolean): JSONObject = jsonOf("asked" to asked, "policy" to policy(t))
}

/**
 * Complete-file replacement that never leaves the user without a complete copy and proves the result:
 * new content is first written to NAME.fbtmp, then written into the original file in place (the file keeps its
 * identity), read back and compared by SHA-256. If the in-place write does not verify, the complete temporary
 * copy is swapped in instead.
 */
object SafeWrite {
    private const val MAX_BYTES = 3_000_000

    suspend fun write(path: String, content: String, overwrite: Boolean, createParents: Boolean, expectedRevision: String, ctx: OpCtx): JSONObject {
        val l = Workspace.loc(path)
        if (l.segs.isEmpty()) throw OpError("invalid_path", "Give a file path")
        val bytes = content.toByteArray(Charsets.UTF_8)
        if (bytes.size > MAX_BYTES) throw OpError("too_large", "Content is too large for write_file")
        val parentSegs = l.segs.dropLast(1)
        val parent = if (createParents) l.tree.ensureDir(parentSegs)
        else l.tree.find(parentSegs) ?: throw OpError("not_found", "Parent folder does not exist")
        val name = l.segs.last()
        val existing = l.tree.child(parent, name)
        val newRev = Revisions.sha256(bytes)
        if (existing == null) {
            if (expectedRevision.isNotEmpty()) {
                throw OpError(
                    "revision_conflict",
                    "The file no longer exists (it was deleted or moved after you read it). Nothing was written.",
                    jsonOf("path" to l.display, "expected_revision" to expectedRevision, "current_revision" to null)
                )
            }
            Space.require(l.tree, bytes.size.toLong())
            createNew(l, parent, name, bytes, newRev)
            return jsonOf("path" to l.display, "size" to bytes.size, "revision" to newRev, "overwritten" to false, "verified" to true)
        }
        if (existing.isDir) throw OpError("is_directory", "A folder with that name exists")
        val cur = Revisions.of(l.tree, existing)
        if (!overwrite) {
            throw OpError(
                "exists",
                "File exists. Pass overwrite=true to replace it (its current revision is in this error).",
                jsonOf("path" to l.display, "revision" to cur, "size" to existing.size)
            )
        }
        checkRevision(l, existing, cur, expectedRevision)
        if (cur != null && cur == newRev) {
            return jsonOf(
                "path" to l.display, "size" to bytes.size, "revision" to newRev, "overwritten" to false,
                "unchanged" to true, "verified" to true, "confirmation" to OverwriteGate.describe(l.tree, false)
            )
        }
        val asked = OverwriteGate.ensure(ctx, l.tree, "Overwrite file?", "Claude wants to replace ${l.display} (${fmtBytes(existing.size)}) with ${fmtBytes(bytes.size.toLong())}.")
        Space.require(l.tree, bytes.size.toLong())
        replaceInPlace(l, parent, existing, bytes, newRev)
        return jsonOf(
            "path" to l.display, "size" to bytes.size, "revision" to newRev, "previous_revision" to cur, "overwritten" to true,
            "verified" to true, "confirmation" to OverwriteGate.describe(l.tree, asked)
        )
    }

    suspend fun edit(path: String, edits: JSONArray, expectedRevision: String, ctx: OpCtx): JSONObject {
        val l = Workspace.loc(path)
        if (l.segs.isEmpty()) throw OpError("invalid_path", "Give a file path")
        val existing = FileOps.requireNode(l)
        if (existing.isDir) throw OpError("is_directory", "That is a folder, not a file")
        if (existing.size > MAX_BYTES) throw OpError("too_large", "The file is larger than 3 MB; edit_file works on files up to 3 MB.")
        val raw = l.tree.openIn(existing).use { it.readBytes() }
        if (raw.size > MAX_BYTES) throw OpError("too_large", "The file is larger than 3 MB; edit_file works on files up to 3 MB.")
        for (k in 0 until minOf(raw.size, 8192)) {
            if (raw[k] == 0.toByte()) throw OpError("binary_file", "Binary file: edit_file only changes text files")
        }
        val cur = Revisions.sha256(raw)
        checkRevision(l, existing, cur, expectedRevision)
        val original = String(raw, Charsets.UTF_8)
        if (!original.toByteArray(Charsets.UTF_8).contentEquals(raw)) {
            throw OpError("not_utf8", "${l.display} is not valid UTF-8 text, so edit_file refuses to touch it (it could corrupt the file).")
        }
        var text = original
        var replaced = 0
        for (i in 0 until edits.length()) {
            val e = edits.optJSONObject(i) ?: throw OpError("invalid_argument", "edits[$i] must be an object")
            val oldT = e.optString("old_text", "")
            val newT = e.optString("new_text", "")
            val all = e.optBoolean("replace_all", false)
            if (oldT.isEmpty()) throw OpError("invalid_argument", "edits[$i].old_text must not be empty")
            val n = countOf(text, oldT)
            if (n == 0) throw OpError("edit_not_found", "edits[$i].old_text was not found in ${l.display}. Nothing was changed.", jsonOf("edit_index" to i))
            if (n > 1 && !all) {
                throw OpError(
                    "edit_ambiguous",
                    "edits[$i].old_text matches $n places in ${l.display}. Add more context or set replace_all. Nothing was changed.",
                    jsonOf("edit_index" to i, "matches" to n)
                )
            }
            text = if (all) text.replace(oldT, newT) else text.replaceFirst(oldT, newT)
            replaced += if (all) n else 1
        }
        val bytes = text.toByteArray(Charsets.UTF_8)
        if (bytes.size > MAX_BYTES) throw OpError("too_large", "The edited file would be larger than 3 MB.")
        val newRev = Revisions.sha256(bytes)
        if (newRev == cur) {
            return jsonOf(
                "path" to l.display, "size" to bytes.size, "revision" to cur, "replacements" to replaced, "overwritten" to false,
                "unchanged" to true, "verified" to true, "confirmation" to OverwriteGate.describe(l.tree, false)
            )
        }
        val parent = l.tree.find(l.segs.dropLast(1)) ?: throw OpError("not_found", "Parent folder not found")
        val asked = OverwriteGate.ensure(ctx, l.tree, "Modify file?", "Claude wants to change ${l.display} ($replaced replacement${if (replaced == 1) "" else "s"}).")
        Space.require(l.tree, bytes.size.toLong())
        replaceInPlace(l, parent, existing, bytes, newRev)
        return jsonOf(
            "path" to l.display, "size" to bytes.size, "revision" to newRev, "previous_revision" to cur, "replacements" to replaced,
            "overwritten" to true, "verified" to true, "confirmation" to OverwriteGate.describe(l.tree, asked)
        )
    }

    private fun countOf(text: String, needle: String): Int {
        var c = 0
        var i = text.indexOf(needle)
        while (i >= 0) {
            c++
            i = text.indexOf(needle, i + needle.length)
        }
        return c
    }

    private fun checkRevision(l: Loc, existing: Node, cur: String?, expected: String) {
        if (expected.isEmpty()) return
        if (cur == null) {
            throw OpError(
                "revision_unavailable",
                "The existing file is too large to compare revisions. Read it with read_file and ask the user before replacing it.",
                jsonOf("path" to l.display, "size" to existing.size)
            )
        }
        if (!expected.equals(cur, ignoreCase = true)) {
            throw OpError(
                "revision_conflict",
                "${l.display} changed after you last read it (by the user, another app or another AI). Nothing was written. Read it again, merge your change, then retry.",
                jsonOf(
                    "path" to l.display, "expected_revision" to expected.lowercase(), "current_revision" to cur,
                    "size" to existing.size, "modified" to FileOps.isoTime(existing.modified)
                )
            )
        }
    }

    /** New file: written to NAME.fbtmp, renamed, then read back. A file that does not read back correctly is removed. */
    private fun createNew(l: Loc, parent: Node, name: String, bytes: ByteArray, newRev: String) {
        val tmpName = "$name.fbtmp"
        l.tree.child(parent, tmpName)?.let { l.tree.delete(it) }
        val tmp = l.tree.createFile(parent, tmpName)
        try {
            l.tree.openOut(tmp).use { it.write(bytes) }
        } catch (e: Exception) {
            l.tree.delete(tmp)
            throw if (e is OpError) e else OpError("storage_error", "Write failed: ${e.message}")
        }
        val fin = l.tree.rename(tmp, name) ?: throw OpError("storage_error", "Saved as $tmpName but renaming failed")
        val check = l.tree.child(parent, name)
        if (check == null || check.size != bytes.size.toLong() || Revisions.of(l.tree, check) != newRev) {
            l.tree.delete(fin)
            throw OpError("verify_failed", "The new file did not read back correctly, so it was removed. Nothing was kept.", jsonOf("path" to l.display))
        }
    }

    private fun replaceInPlace(l: Loc, parent: Node, existing: Node, bytes: ByteArray, newRev: String) {
        val name = existing.name
        val tmpName = "$name.fbtmp"
        l.tree.child(parent, tmpName)?.let { l.tree.delete(it) }
        val tmp = l.tree.createFile(parent, tmpName)
        try {
            l.tree.openOut(tmp).use { it.write(bytes) }
        } catch (e: Exception) {
            l.tree.delete(tmp)
            throw if (e is OpError) e else OpError("storage_error", "Write failed: ${e.message}")
        }
        val written = l.tree.child(parent, tmpName)
        if (written == null || written.size != bytes.size.toLong()) {
            l.tree.delete(tmp)
            throw OpError("storage_error", "The temporary copy was not written completely. The original file is unchanged.")
        }
        var verified = false
        try {
            for (attempt in 1..2) {
                l.tree.openOut(existing).use { it.write(bytes) } // mode "wt": truncates, so nothing is appended
                val check = l.tree.child(parent, name)
                if (check != null && check.size == bytes.size.toLong() && Revisions.of(l.tree, check) == newRev) {
                    verified = true
                    break
                }
            }
        } catch (e: Exception) {
            verified = false
        }
        if (verified) {
            l.tree.delete(tmp)
            return
        }
        // The in-place write did not verify: swap in the complete temporary copy instead.
        val recovery = l.display + ".fbtmp"
        val old = l.tree.child(parent, name)
        if (old != null && !l.tree.delete(old)) {
            throw OpError(
                "verify_failed",
                "The file could not be rewritten safely. The complete new content is saved as $recovery next to it.",
                jsonOf("path" to l.display, "recovery_file" to recovery)
            )
        }
        l.tree.rename(tmp, name) ?: throw OpError(
            "verify_failed",
            "The old file was removed but the safe copy could not be renamed. The complete new content is saved as $recovery.",
            jsonOf("path" to l.display, "recovery_file" to recovery)
        )
        val check = l.tree.child(parent, name)
        if (check == null || Revisions.of(l.tree, check) != newRev) {
            throw OpError("verify_failed", "The replacement did not read back correctly. Check ${l.display}.", jsonOf("path" to l.display))
        }
    }
}

/** verify_files / verify_zip: look at what is really on the phone, without changing anything. */
object Verify {
    private fun tempSiblings(l: Loc): JSONArray {
        val out = JSONArray()
        if (l.segs.isEmpty()) return out
        val parent = l.tree.find(l.segs.dropLast(1)) ?: return out
        val name = l.segs.last()
        for (c in l.tree.children(parent)) {
            if (c.name == "$name.fbtmp" || c.name == "$name.tmp") out.put(c.name)
        }
        return out
    }

    fun files(paths: JSONArray, hash: Boolean): JSONObject {
        val out = JSONArray()
        var hashed = 0
        for (i in 0 until minOf(paths.length(), 40)) {
            val l = Workspace.loc(paths.optString(i, ""))
            val n = l.tree.find(l.segs)
            if (n == null) {
                out.put(jsonOf("path" to l.display, "exists" to false, "temp_siblings" to tempSiblings(l)))
                continue
            }
            var rev: String? = null
            if (hash && !n.isDir) {
                rev = Revisions.of(l.tree, n)
                if (rev != null) hashed++
            }
            out.put(
                jsonOf(
                    "path" to l.display, "exists" to true, "type" to (if (n.isDir) "directory" else "file"),
                    "size" to (if (n.isDir) null else n.size), "modified" to FileOps.isoTime(n.modified),
                    "revision" to rev, "temp_siblings" to tempSiblings(l)
                )
            )
        }
        return jsonOf("files" to out, "count" to out.length(), "hashed" to hashed)
    }

    fun zip(path: String, expect: JSONArray, deep: Boolean): JSONObject {
        val l = Workspace.loc(path)
        val n = FileOps.requireNode(l)
        if (n.isDir) throw OpError("is_directory", "That is a folder, not a ZIP")
        val names = HashSet<String>()
        try {
            val pfd = Prefs.appCtx.contentResolver.openFileDescriptor(n.uri, "r") ?: throw OpError("storage_error", "Cannot open the ZIP")
            pfd.use {
                ZipFile("/proc/self/fd/${it.fd}").use { z ->
                    val en = z.entries()
                    while (en.hasMoreElements()) names.add(en.nextElement().name)
                }
            }
        } catch (e: OpError) {
            throw e
        } catch (e: Exception) {
            throw OpError("zip_verification_failed", "The file is not a readable ZIP: ${e.message}", jsonOf("path" to l.display, "verified" to false))
        }
        var crcChecked = 0
        var corrupt: String? = null
        if (deep) {
            try {
                l.tree.openIn(n).use { raw ->
                    ZipInputStream(BufferedInputStream(raw, 128 * 1024)).use { zin ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            zin.nextEntry ?: break
                            while (zin.read(buf) >= 0) {
                            }
                            crcChecked++
                        }
                    }
                }
            } catch (e: Exception) {
                corrupt = e.message ?: "unreadable entry"
            }
        }
        val missing = JSONArray()
        var expected = 0
        for (i in 0 until minOf(expect.length(), 200)) {
            val want = expect.optString(i, "").replace('\\', '/').trimStart('/')
            if (want.isEmpty()) continue
            expected++
            val found = if (want.endsWith("/")) names.any { it.startsWith(want) } else want in names
            if (!found) missing.put(want)
        }
        val ok = missing.length() == 0 && corrupt == null
        val out = jsonOf(
            "path" to l.display, "size" to n.size, "entries" to names.size, "expected" to expected, "missing" to missing,
            "deep" to deep, "crc_checked" to (if (deep) crcChecked else null), "corrupt" to corrupt, "verified" to ok
        )
        if (!ok) {
            val why = if (missing.length() > 0) "${missing.length()} expected entries are missing from the ZIP." else "The ZIP is corrupt: $corrupt"
            throw OpError("zip_verification_failed", why, out)
        }
        return out
    }
}
