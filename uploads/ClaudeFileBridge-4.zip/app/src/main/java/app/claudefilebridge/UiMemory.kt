package app.claudefilebridge

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

class MemRow(
    val id: String,
    val project: String,
    val kind: String,
    val title: String,
    val snippet: String,
    val tags: List<String>,
    val pinned: Boolean,
    val status: String,
    val archived: Boolean,
    val author: String,
    val updated: String
)

class AiRow(val id: String, val name: String, val scopes: List<String>, val lastUsed: String?)

private fun parseRows(a: JSONArray?): List<MemRow> {
    val out = ArrayList<MemRow>()
    if (a == null) return out
    for (i in 0 until a.length()) {
        val o = a.optJSONObject(i) ?: continue
        val tags = ArrayList<String>()
        val ta = o.optJSONArray("tags")
        if (ta != null) for (k in 0 until ta.length()) tags.add(ta.optString(k))
        out.add(
            MemRow(
                o.optString("id"), o.optString("project"), o.optString("kind"), o.optString("title"), o.optString("snippet"),
                tags, o.optBoolean("pinned"), o.optString("status"), o.optBoolean("archived"), o.optString("author"), o.optString("updated_at")
            )
        )
    }
    return out
}

private fun scopeList(a: JSONArray?): List<String> {
    val out = ArrayList<String>()
    if (a != null) for (i in 0 until a.length()) out.add(a.optString(i))
    return out
}

private fun kindColor(kind: String): Color = when (kind) {
    "handoff" -> Color(0xFF8AB4FF)
    "todo" -> WarnColor
    "decision" -> Color(0xFF7FD8C3)
    "fact" -> Color(0xFFB4C7E8)
    else -> MutedColor
}

@Composable
private fun FilterBtn(text: String, selected: Boolean, onClick: () -> Unit) {
    val mod = Modifier.height(36.dp)
    val pad = PaddingValues(horizontal = 14.dp, vertical = 0.dp)
    if (selected) {
        FilledTonalButton(onClick = onClick, modifier = mod, contentPadding = pad) { Text(text, maxLines = 1) }
    } else {
        OutlinedButton(onClick = onClick, modifier = mod, contentPadding = pad) { Text(text, maxLines = 1) }
    }
}

@Composable
private fun MemCard(m: MemRow, onClick: () -> Unit) {
    AppCard(onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(m.title, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Hint(m.project + "  |  " + m.author + "  |  " + ago(m.updated))
            }
            if (m.pinned) Icn(R.drawable.ic_pin, tint = MaterialTheme.colorScheme.primary, size = 18.dp, desc = "Pinned")
        }
        if (m.snippet.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            Text(
                m.snippet,
                style = MaterialTheme.typography.bodyMedium,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Pill(m.kind.uppercase(), kindColor(m.kind))
            if (m.kind == "todo") Pill(m.status.replace('_', ' '), if (m.status == "done") GoodColor else WarnColor)
            if (m.archived) Pill("archived", MutedColor)
            for (t in m.tags.take(3)) Pill(t, MutedColor)
        }
    }
}

@Composable
private fun MemDetail(m: MemRow, onClose: () -> Unit, onChanged: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var detail by remember(m.id) { mutableStateOf<JSONObject?>(null) }
    var askDelete by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }

    LaunchedEffect(m.id) {
        val r = try {
            withContext(Dispatchers.IO) { Backend.memoryGet(m.id) }
        } catch (e: Exception) {
            null
        }
        detail = r?.body?.optJSONObject("entry")
    }
    val d = detail
    val pinned = d?.optBoolean("pinned") ?: m.pinned
    val isArchived = d?.optBoolean("archived") ?: m.archived
    val status = d?.optString("status") ?: m.status
    val content = d?.optString("content") ?: "Loading..."

    fun act(pin: Boolean?, arch: Boolean?, st: String?) {
        busy = true
        scope.launch {
            val r = try {
                withContext(Dispatchers.IO) { Backend.memoryUpdate(m.id, pin, arch, st) }
            } catch (e: Exception) {
                null
            }
            busy = false
            if (r != null && r.code == 200) {
                onChanged()
                onClose()
            }
        }
    }

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.padding(16.dp)) {
            AppCard {
                Text(m.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                Hint(m.project + "  |  by " + m.author + "  |  " + ago(m.updated))
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Pill(m.kind.uppercase(), kindColor(m.kind))
                    if (m.kind == "todo") Pill(status.replace('_', ' '), if (status == "done") GoodColor else WarnColor)
                }
                HorizontalDivider(Modifier.padding(vertical = 10.dp))
                Column(Modifier.heightIn(max = 320.dp).verticalScroll(rememberScrollState())) {
                    SelectionContainer { Text(content, style = MaterialTheme.typography.bodyMedium) }
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AppButton(if (pinned) "Unpin" else "Pin", { act(!pinned, null, null) }, Modifier.weight(1f), R.drawable.ic_pin, !busy, BtnStyle.Tonal)
                    AppButton(if (isArchived) "Restore" else "Archive", { act(null, !isArchived, null) }, Modifier.weight(1f), R.drawable.ic_archive, !busy, BtnStyle.Tonal)
                }
                if (m.kind == "todo") {
                    Spacer(Modifier.height(8.dp))
                    AppButton(
                        if (status == "done") "Reopen" else "Mark done",
                        { act(null, null, if (status == "done") "open" else "done") },
                        Modifier.fillMaxWidth(), R.drawable.ic_check, !busy, BtnStyle.Tonal
                    )
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AppButton("Copy", { copyToClipboard(ctx, m.title, content) }, Modifier.weight(1f), R.drawable.ic_copy, style = BtnStyle.Outline)
                    AppButton("Delete", { askDelete = true }, Modifier.weight(1f), R.drawable.ic_delete, style = BtnStyle.Danger)
                }
                Spacer(Modifier.height(8.dp))
                AppButton("Close", onClose, Modifier.fillMaxWidth(), R.drawable.ic_close, style = BtnStyle.Outline)
            }
        }
    }

    if (askDelete) {
        AlertDialog(
            onDismissRequest = { askDelete = false },
            title = { Text("Delete this entry?") },
            text = { Text("It is removed for every connected AI and cannot be undone.") },
            confirmButton = {
                AppButton("Delete", {
                    askDelete = false
                    scope.launch {
                        try {
                            withContext(Dispatchers.IO) { Backend.memoryDelete(m.id) }
                        } catch (e: Exception) {
                        }
                        onChanged()
                        onClose()
                    }
                }, style = BtnStyle.Danger)
            },
            dismissButton = { AppButton("Cancel", { askDelete = false }, style = BtnStyle.Outline) }
        )
    }
}

@Composable
fun MemoryScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    var project by remember { mutableStateOf("") }
    var archived by remember { mutableStateOf(false) }
    var rows by remember { mutableStateOf<List<MemRow>>(emptyList()) }
    var projects by remember { mutableStateOf<List<String>>(emptyList()) }
    var msg by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var refresh by remember { mutableIntStateOf(0) }
    var open by remember { mutableStateOf<MemRow?>(null) }

    LaunchedEffect(query, project, archived, refresh) {
        if (query.isNotEmpty()) delay(350L)
        loading = true
        val r = try {
            withContext(Dispatchers.IO) { Backend.memoryList(query, project, archived) }
        } catch (e: Exception) {
            null
        }
        loading = false
        val b = r?.body
        if (r != null && r.code == 200 && b != null) {
            rows = parseRows(b.optJSONArray("entries"))
            val pa = b.optJSONArray("projects")
            val pl = ArrayList<String>()
            if (pa != null) for (i in 0 until pa.length()) pl.add(pa.getJSONObject(i).optString("project"))
            projects = pl
            msg = ""
        } else {
            msg = if (r == null) "Cannot reach the backend." else if (r.code == 404) "Update the backend function to version 1.1.0 to use shared memory." else "Backend returned HTTP " + r.code
        }
    }

    Column(Modifier.fillMaxSize()) {
        TitleBar("Shared memory") {
            IconBtn(R.drawable.ic_refresh, "Refresh", { refresh++ })
            IconBtn(R.drawable.ic_copy, "Copy all as Markdown", {
                scope.launch {
                    val r = try {
                        withContext(Dispatchers.IO) { Backend.memoryExport() }
                    } catch (e: Exception) {
                        null
                    }
                    val md = r?.body?.optString("markdown") ?: ""
                    if (md.isNotEmpty()) {
                        copyToClipboard(ctx, "FileBridge memory", md)
                        note = "Copied all memory as Markdown. Paste it into any AI to continue the work."
                    } else {
                        note = "Nothing to copy yet."
                    }
                }
            })
        }
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            singleLine = true,
            label = { Text("Search memory") },
            leadingIcon = { Icn(R.drawable.ic_search) },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
        )
        Spacer(Modifier.height(8.dp))
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterBtn("All projects", project.isEmpty()) { project = "" }
            for (p in projects) FilterBtn(p, project == p) { project = p }
            FilterBtn(if (archived) "Archived shown" else "Show archived", archived) { archived = !archived }
        }
        if (msg.isNotEmpty()) Text(msg, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(16.dp))
        if (note.isNotEmpty()) Box(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) { Hint(note) }
        LazyColumn(
            Modifier.weight(1f).padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (rows.isEmpty() && msg.isEmpty() && !loading) {
                item {
                    AppCard {
                        Text("No memory yet", fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(4.dp))
                        Hint("AIs save notes, decisions, to-dos and handoffs here. Connect another AI under Settings, Connected AIs, and it can pick up where the last one stopped.")
                    }
                }
            }
            items(rows, key = { it.id }) { m -> MemCard(m) { open = m } }
        }
    }

    val o = open
    if (o != null) MemDetail(o, { open = null }, { refresh++ })
}

@Composable
fun AisScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var clients by remember { mutableStateOf<List<AiRow>>(emptyList()) }
    var primaryUsed by remember { mutableStateOf<String?>(null) }
    var msg by remember { mutableStateOf("") }
    var refresh by remember { mutableIntStateOf(0) }
    var name by remember { mutableStateOf("") }
    var sFiles by remember { mutableStateOf(false) }
    var sMemory by remember { mutableStateOf(true) }
    var sBuilds by remember { mutableStateOf(false) }
    var created by remember { mutableStateOf("") }
    var createdName by remember { mutableStateOf("") }
    var primaryUrl by remember { mutableStateOf("") }
    var askRevoke by remember { mutableStateOf<AiRow?>(null) }
    var busy by remember { mutableStateOf(false) }

    LaunchedEffect(refresh) {
        val r = try {
            withContext(Dispatchers.IO) { Backend.clientsList() }
        } catch (e: Exception) {
            null
        }
        val b = r?.body
        if (r != null && r.code == 200 && b != null) {
            val out = ArrayList<AiRow>()
            val arr = b.optJSONArray("clients")
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    out.add(AiRow(o.optString("id"), o.optString("name"), scopeList(o.optJSONArray("scopes")), o.str("last_used_at")))
                }
            }
            clients = out
            primaryUsed = b.optJSONObject("primary")?.str("last_used_at")
            msg = ""
        } else {
            msg = if (r == null) "Cannot reach the backend." else if (r.code == 404) "Update the backend function to version 1.1.0 to manage AIs." else "Backend returned HTTP " + r.code
        }
    }

    Column(Modifier.fillMaxSize()) {
        SubHeader("Connected AIs", onBack)
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Hint("Give each AI its own connector. Two or more can work at the same time: reads run in parallel, changes run one at a time, and they share the same memory. Revoke any AI at any moment.")
            if (msg.isNotEmpty()) Text(msg, color = MaterialTheme.colorScheme.error)

            AppCard {
                SectionHeader("Primary connector")
                Text("Full access: files, memory and builds.")
                Hint("Last used " + ago(primaryUsed))
                Spacer(Modifier.height(10.dp))
                AppButton("Create new URL", {
                    scope.launch {
                        val r = try {
                            withContext(Dispatchers.IO) { Backend.rotate() }
                        } catch (e: Exception) {
                            null
                        }
                        primaryUrl = if (r != null && r.code == 200) (r.body?.optString("connector_url") ?: "") else "Failed (HTTP " + (r?.code ?: 0) + ")"
                    }
                }, Modifier.fillMaxWidth(), R.drawable.ic_refresh, style = BtnStyle.Outline)
                if (primaryUrl.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Text(primaryUrl, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                    Hint("Replaces the old primary URL. Treat it like a password.")
                    Spacer(Modifier.height(6.dp))
                    AppButton("Copy URL", { copyToClipboard(ctx, "Primary connector URL", primaryUrl) }, Modifier.fillMaxWidth(), R.drawable.ic_copy, style = BtnStyle.Tonal)
                }
            }

            SectionHeader("Other AIs")
            if (clients.isEmpty()) Hint("No other AI connected yet.")
            for (c in clients) {
                AppCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(c.name, fontWeight = FontWeight.SemiBold)
                            Hint("Last used " + ago(c.lastUsed))
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        for (s in c.scopes) Pill(s, if (s == "files") WarnColor else MutedColor)
                    }
                    Spacer(Modifier.height(10.dp))
                    AppButton("Revoke access", { askRevoke = c }, Modifier.fillMaxWidth(), R.drawable.ic_close, style = BtnStyle.Outline)
                }
            }

            AppCard {
                SectionHeader("Add another AI")
                AppField("Name (for example ChatGPT or Gemini)", name, { name = it })
                ToggleRow("Memory", sMemory, { sMemory = it }, "Shared notes, to-dos and handoffs")
                ToggleRow("Files", sFiles, { sFiles = it }, "Read and write files on this phone (still limited by your permissions)")
                ToggleRow("Builds", sBuilds, { sBuilds = it }, "Prepare ZIPs and run APK builds")
                Spacer(Modifier.height(8.dp))
                AppButton(
                    if (busy) "Creating..." else "Create connector",
                    {
                        busy = true
                        val scopes = ArrayList<String>()
                        if (sMemory) scopes.add("memory")
                        if (sFiles) scopes.add("files")
                        if (sBuilds) scopes.add("builds")
                        scope.launch {
                            val r = try {
                                withContext(Dispatchers.IO) { Backend.clientsCreate(name.trim(), scopes) }
                            } catch (e: Exception) {
                                null
                            }
                            busy = false
                            val b = r?.body
                            if (r != null && r.code == 200 && b != null && b.optBoolean("ok")) {
                                created = b.optString("connector_url")
                                createdName = b.optString("name")
                                name = ""
                                msg = ""
                                refresh++
                            } else {
                                val m = b?.optString("message") ?: ""
                                msg = if (m.isNotEmpty()) m else "Could not create the connector (HTTP " + (r?.code ?: 0) + ")."
                            }
                        }
                    },
                    Modifier.fillMaxWidth(), R.drawable.ic_add, !busy && name.isNotBlank() && (sMemory || sFiles || sBuilds)
                )
            }

            if (created.isNotEmpty()) {
                AppCard {
                    SectionHeader("Connector for " + createdName)
                    Text(created, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                    Hint("Shown once. Paste it into that AI as a custom MCP connector (remote server URL). Treat it like a password.")
                    Spacer(Modifier.height(8.dp))
                    AppButton("Copy URL", { copyToClipboard(ctx, "Connector URL", created) }, Modifier.fillMaxWidth(), R.drawable.ic_copy)
                    Spacer(Modifier.height(6.dp))
                    AppButton("Done", { created = "" }, Modifier.fillMaxWidth(), R.drawable.ic_check, style = BtnStyle.Outline)
                }
            }

            AppCard {
                SectionHeader("How to connect an AI")
                Hint("Claude: Settings, Connectors, Add custom connector. ChatGPT: Settings, Connectors, developer mode, add an MCP server. Other tools: add a remote MCP server (streamable HTTP) with the URL. Then tell the AI to call memory_resume to continue the work.")
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    val ar = askRevoke
    if (ar != null) {
        AlertDialog(
            onDismissRequest = { askRevoke = null },
            title = { Text("Revoke " + ar.name + "?") },
            text = { Text("That AI loses access immediately. Entries it wrote stay in memory.") },
            confirmButton = {
                AppButton("Revoke", {
                    askRevoke = null
                    scope.launch {
                        try {
                            withContext(Dispatchers.IO) { Backend.clientsRevoke(ar.id) }
                        } catch (e: Exception) {
                        }
                        refresh++
                    }
                }, style = BtnStyle.Danger)
            },
            dismissButton = { AppButton("Cancel", { askRevoke = null }, style = BtnStyle.Outline) }
        )
    }
}
