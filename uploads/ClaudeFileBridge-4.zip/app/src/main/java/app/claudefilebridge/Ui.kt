package app.claudefilebridge

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class Screen { HOME, SETUP, FILES, MEMORY, ACTIVITY, SETTINGS, ZIP, BUILD, APKS, AIS }

private class NavItem(val screen: Screen, val icon: Int, val label: String)

private val TABS = listOf(
    NavItem(Screen.HOME, R.drawable.ic_home, "Home"),
    NavItem(Screen.FILES, R.drawable.ic_folder, "Files"),
    NavItem(Screen.MEMORY, R.drawable.ic_memory, "Memory"),
    NavItem(Screen.ACTIVITY, R.drawable.ic_activity, "Activity"),
    NavItem(Screen.SETTINGS, R.drawable.ic_settings, "Settings")
)

// ---------------------------------------------------------------- helpers

private fun startBridge(ctx: Context) {
    Prefs.bridgeOn = true
    ContextCompat.startForegroundService(ctx, Intent(ctx, BridgeService::class.java))
}

private fun stopBridge(ctx: Context) {
    Bridge.stop()
    ctx.stopService(Intent(ctx, BridgeService::class.java))
}

private fun savePairing(b: JSONObject) {
    Prefs.deviceToken = b.optString("device_token")
    Prefs.channelKey = b.optString("channel_key")
    Prefs.channelTopic = b.optString("channel_topic")
    Prefs.realtimeUrl = b.optString("realtime_url")
    Prefs.realtimeKey = b.optString("realtime_apikey")
    val st = b.optLong("server_time_ms", 0L)
    if (st > 0L) Prefs.skewMs = st - System.currentTimeMillis()
    Prefs.paired = true
}

private fun batteryUnrestricted(ctx: Context): Boolean =
    try {
        ctx.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(ctx.packageName)
    } catch (e: Exception) {
        false
    }

private fun openBatterySettings(ctx: Context) {
    try {
        ctx.startActivity(Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
    }
}

@Composable
private fun rememberFolderPicker(role: String, onPicked: () -> Unit): () -> Unit {
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        if (uri != null) {
            try {
                ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            } catch (e: Exception) {
            }
            Prefs.setTreeUri(role, uri.toString())
            onPicked()
        }
    }
    return { launcher.launch(null) }
}

@Composable
private fun InfoRow(label: String, value: String, onClick: (() -> Unit)? = null) {
    val m = if (onClick != null) Modifier.fillMaxWidth().clickable(onClick = onClick) else Modifier.fillMaxWidth()
    Row(m.padding(vertical = 5.dp)) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.width(96.dp))
        Text(value, modifier = Modifier.weight(1f), maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun ToolButton(icon: Int, label: String, modifier: Modifier, onClick: () -> Unit) {
    FilledTonalButton(onClick = onClick, modifier = modifier.height(76.dp), contentPadding = PaddingValues(8.dp)) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icn(icon, size = 24.dp)
            Spacer(Modifier.height(4.dp))
            Text(label, style = MaterialTheme.typography.labelLarge)
        }
    }
}

@Composable
private fun OpRow(o: OpInfo) {
    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(o.tool, fontWeight = FontWeight.Medium)
            if (o.client.isNotEmpty()) Pill(o.client, MaterialTheme.colorScheme.primary)
        }
        if (o.note.isNotEmpty()) Hint(o.note)
        Spacer(Modifier.height(6.dp))
        val pr = o.progress
        if (pr != null) LinearProgressIndicator(progress = { pr }, modifier = Modifier.fillMaxWidth()) else LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
    }
}

// ---------------------------------------------------------------- root

@Composable
fun AppRoot() {
    var screen by remember { mutableStateOf(if (Prefs.paired && Workspace.hasWorkspace()) Screen.HOME else Screen.SETUP) }
    BackHandler(enabled = screen != Screen.HOME && screen != Screen.SETUP) {
        screen = if (screen == Screen.AIS) Screen.SETTINGS else Screen.HOME
    }
    MaterialTheme(colorScheme = FbColors, shapes = FbShapes) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            bottomBar = {
                if (TABS.any { it.screen == screen }) {
                    NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                        for (t in TABS) {
                            NavigationBarItem(
                                selected = screen == t.screen,
                                onClick = { screen = t.screen },
                                icon = { Icn(t.icon, desc = t.label) },
                                label = { Text(t.label) }
                            )
                        }
                    }
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when (screen) {
                    Screen.HOME -> HomeScreen(go = { screen = it })
                    Screen.SETUP -> SetupScreen(onDone = { screen = Screen.HOME })
                    Screen.FILES -> Column(Modifier.fillMaxSize()) {
                        TitleBar("Files")
                        Browser(Modifier.weight(1f), null)
                    }
                    Screen.MEMORY -> MemoryScreen()
                    Screen.ACTIVITY -> ActivityScreen()
                    Screen.SETTINGS -> SettingsScreen(onRepair = { screen = Screen.SETUP }, onAis = { screen = Screen.AIS })
                    Screen.ZIP -> ZipScreen { screen = Screen.HOME }
                    Screen.BUILD -> BuildScreen { screen = Screen.HOME }
                    Screen.APKS -> ApksScreen { screen = Screen.HOME }
                    Screen.AIS -> AisScreen { screen = Screen.SETTINGS }
                }
            }
        }
        ConfirmDialog()
    }
}

@Composable
private fun ConfirmDialog() {
    val p by BridgeState.pending.collectAsState()
    val cur = p ?: return
    AlertDialog(
        onDismissRequest = { Confirm.resolve(cur.id, false) },
        title = { Text(cur.title) },
        text = { Text(if (cur.alwaysScope != null) cur.detail + "\n\nAlways allow stops this question for replacing existing files in this folder. You can turn it off again in Settings." else cur.detail) },
        confirmButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (cur.alwaysScope != null) AppButton("Always allow", { Confirm.resolve(cur.id, true, true) }, style = BtnStyle.Outline)
                AppButton("Allow", { Confirm.resolve(cur.id, true) })
            }
        },
        dismissButton = { AppButton("Deny", { Confirm.resolve(cur.id, false) }, style = BtnStyle.Outline) }
    )
}

// ---------------------------------------------------------------- home

@Composable
private fun HomeScreen(go: (Screen) -> Unit) {
    val ctx = LocalContext.current
    val conn by BridgeState.conn.collectAsState()
    val detail by BridgeState.detail.collectAsState()
    val ops by BridgeState.ops.collectAsState()
    val usage by BridgeState.usage.collectAsState()
    val emergency by BridgeState.emergency.collectAsState()
    val enabled by BridgeState.claudeEnabled.collectAsState()
    val diag by BridgeState.diag.collectAsState()
    var askDisconnect by remember { mutableStateOf(false) }
    var showDiag by remember { mutableStateOf(false) }
    val running = conn != Conn.STOPPED && conn != Conn.UNPAIRED
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { startBridge(ctx) }

    val status: Pair<Color, String> = when {
        emergency -> Pair(BadColor, "Emergency stop active")
        !enabled -> Pair(WarnColor, "AI access disabled")
        conn == Conn.CONNECTED -> Pair(GoodColor, "Connected")
        conn == Conn.POLLING -> Pair(GoodColor, "Connected (polling)")
        conn == Conn.CONNECTING -> Pair(WarnColor, "Connecting...")
        conn == Conn.OFFLINE -> Pair(BadColor, "Offline")
        conn == Conn.UNPAIRED -> Pair(MutedColor, "Not paired")
        else -> Pair(MutedColor, "Bridge stopped")
    }
    val onToggle: (Boolean) -> Unit = { on ->
        if (!on) {
            stopBridge(ctx)
        } else if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            startBridge(ctx)
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Claude FileBridge", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            Pill("v" + BuildConfig.VERSION_NAME, MutedColor)
        }

        AppCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                StatusDot(status.first)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(status.second, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    if (detail.isNotEmpty()) Hint(detail)
                }
            }
            Spacer(Modifier.height(8.dp))
            ToggleRow(
                "Run in background", running, onToggle,
                if (running) "Keeps working while you use your phone. Stop it here or from the notification." else "Turn on to let your AIs reach this phone."
            )
            HorizontalDivider(Modifier.padding(vertical = 8.dp))
            InfoRow("Device", Prefs.deviceId) { copyToClipboard(ctx, "Device ID", Prefs.deviceId) }
            InfoRow("Workspace", treeLabel(Prefs.treeUri("workspace")))
            InfoRow("Data today", "up " + fmtBytes(usage.first) + "   down " + fmtBytes(usage.second))
            if (ops.isNotEmpty()) {
                HorizontalDivider(Modifier.padding(vertical = 8.dp))
                for (o in ops) OpRow(o)
            }
        }

        SectionHeader("Tools")
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ToolButton(R.drawable.ic_archive, "Create ZIP", Modifier.weight(1f)) { go(Screen.ZIP) }
            ToolButton(R.drawable.ic_build, "Build", Modifier.weight(1f)) { go(Screen.BUILD) }
            ToolButton(R.drawable.ic_phone, "APKs", Modifier.weight(1f)) { go(Screen.APKS) }
        }

        SectionHeader("Shared memory and AIs")
        AppCard {
            Text(
                "Connect more than one AI. They share the same memory, so work can move from one AI to another or run side by side.",
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AppButton("Open memory", { go(Screen.MEMORY) }, Modifier.weight(1f), R.drawable.ic_memory)
                AppButton("Connected AIs", { go(Screen.AIS) }, Modifier.weight(1f), R.drawable.ic_group, style = BtnStyle.Tonal)
            }
        }

        SectionHeader("Safety")
        AppCard {
            AppButton("Emergency stop", { Bridge.emergencyStop() }, Modifier.fillMaxWidth(), R.drawable.ic_stop, style = BtnStyle.Danger)
            Spacer(Modifier.height(4.dp))
            Hint("Cancels ZIPs, uploads and pending operations and pauses every AI. It never deletes files.")
            if (emergency) {
                Spacer(Modifier.height(8.dp))
                AppButton("Resume", { Bridge.resume() }, Modifier.fillMaxWidth(), R.drawable.ic_check, style = BtnStyle.Tonal)
            }
            Spacer(Modifier.height(6.dp))
            ToggleRow("Disable AI access", !enabled, { Bridge.setClaudeEnabled(!it) }, "Refuse every command from every AI until switched off")
            Spacer(Modifier.height(4.dp))
            AppButton("Disconnect this phone", { askDisconnect = true }, Modifier.fillMaxWidth(), R.drawable.ic_close, style = BtnStyle.Outline)
        }

        AppCard {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Diagnostics", fontWeight = FontWeight.SemiBold)
                    Hint(if (batteryUnrestricted(ctx)) "Battery: unrestricted" else "Battery: optimised by Android (see Settings, Background)")
                }
                IconBtn(
                    if (showDiag) R.drawable.ic_expand_less else R.drawable.ic_expand_more,
                    if (showDiag) "Hide log" else "Show log",
                    { showDiag = !showDiag }
                )
            }
            if (showDiag) {
                Spacer(Modifier.height(8.dp))
                Text(
                    if (diag.isEmpty()) "No events yet." else diag.takeLast(12).joinToString("\n"),
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp
                )
                Spacer(Modifier.height(8.dp))
                AppButton("Copy log", { copyToClipboard(ctx, "FileBridge log", diag.joinToString("\n")) }, icon = R.drawable.ic_copy, style = BtnStyle.Outline)
                Spacer(Modifier.height(4.dp))
                Hint("Same lines in logcat: adb logcat -s FileBridge")
            }
        }
        Spacer(Modifier.height(8.dp))
    }

    if (askDisconnect) {
        AlertDialog(
            onDismissRequest = { askDisconnect = false },
            title = { Text("Disconnect this phone?") },
            text = { Text("Your AIs lose access to this phone until you pair it again. No files are touched.") },
            confirmButton = {
                AppButton("Disconnect", {
                    askDisconnect = false
                    Bridge.disconnect {
                        ctx.stopService(Intent(ctx, BridgeService::class.java))
                        go(Screen.SETUP)
                    }
                }, style = BtnStyle.Danger)
            },
            dismissButton = { AppButton("Cancel", { askDisconnect = false }, style = BtnStyle.Outline) }
        )
    }
}

// ---------------------------------------------------------------- setup

@Composable
private fun SetupScreen(onDone: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var paired by remember { mutableStateOf(Prefs.paired) }
    var backend by remember { mutableStateOf(Prefs.backendUrl) }
    var code by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var tick by remember { mutableIntStateOf(0) }
    val hasWs = remember(tick) { Workspace.hasWorkspace() }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }
    val pickWs = rememberFolderPicker("workspace") { tick++ }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Set up Claude FileBridge", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
        Hint("Device ID: " + Prefs.deviceId)

        AppCard {
            SectionHeader("1. Pair with your backend")
            if (paired) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icn(R.drawable.ic_check, tint = GoodColor)
                    Text("Paired as " + Prefs.deviceId)
                }
            } else {
                AppField("Backend URL", backend, { backend = it })
                AppField("Pairing code", code, { code = it })
                Spacer(Modifier.height(6.dp))
                AppButton(
                    if (busy) "Pairing..." else "Pair this phone",
                    {
                        busy = true
                        msg = ""
                        Prefs.backendUrl = backend
                        scope.launch {
                            val r = try {
                                withContext(Dispatchers.IO) { Backend.pair(code.trim(), Build.MODEL ?: "Android") }
                            } catch (e: Exception) {
                                null
                            }
                            busy = false
                            val b = r?.body
                            if (r != null && r.code == 200 && b != null && b.optBoolean("ok")) {
                                savePairing(b)
                                paired = true
                                msg = ""
                            } else {
                                msg = when (r?.code) {
                                    null, 0 -> "Cannot reach the backend. Check the URL and your connection."
                                    403 -> "That code is wrong or has expired."
                                    429 -> "Too many attempts. Wait 10 minutes."
                                    else -> "Pairing failed (" + r?.code + ")."
                                }
                            }
                        }
                    },
                    Modifier.fillMaxWidth(), enabled = !busy && code.isNotBlank()
                )
                if (msg.isNotEmpty()) Text(msg, color = MaterialTheme.colorScheme.error)
            }
        }

        AppCard {
            SectionHeader("2. Claude Workspace (required)")
            Text(if (hasWs) treeLabel(Prefs.treeUri("workspace")) else "Pick a folder such as Download/Claude. Your AIs can only work inside it.")
            Spacer(Modifier.height(8.dp))
            AppButton(if (hasWs) "Change folder" else "Select folder", pickWs, Modifier.fillMaxWidth(), R.drawable.ic_folder, style = if (hasWs) BtnStyle.Tonal else BtnStyle.Primary)
        }

        AppCard {
            SectionHeader("3. Output folders (optional)")
            Hint("Skip these to use ZIP/, APK/ and BuildWorkspace/ sub-folders inside the workspace.")
            for (r in listOf("zip" to "ZIP Output", "apk" to "APK Output", "build" to "Build Workspace")) {
                FolderRow(r.first, r.second, tick) { tick++ }
            }
        }

        AppCard {
            SectionHeader("4. Background")
            Hint("Allow notifications and, for reliability with the screen off, unrestricted battery use.")
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AppButton("Notifications", {
                    if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }, Modifier.weight(1f), style = BtnStyle.Tonal)
                AppButton("Battery", { openBatterySettings(ctx) }, Modifier.weight(1f), style = BtnStyle.Tonal)
            }
        }

        AppButton("Start FileBridge", {
            startBridge(ctx)
            onDone()
        }, Modifier.fillMaxWidth(), R.drawable.ic_check, enabled = paired && hasWs)
        if (paired && hasWs) {
            AppButton("Skip, do not start yet", onDone, Modifier.fillMaxWidth(), style = BtnStyle.Outline)
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun FolderRow(role: String, label: String, tick: Int, changed: () -> Unit) {
    val pick = rememberFolderPicker(role, changed)
    val uri = remember(tick) { Prefs.treeUri(role) }
    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Text(label, fontWeight = FontWeight.Medium)
        Hint(if (uri == null) (if (role == "workspace") "Not selected" else "Not set (uses a sub-folder of the workspace)") else treeLabel(uri))
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            AppButton(if (uri == null) "Select folder" else "Change", pick, icon = R.drawable.ic_folder, style = BtnStyle.Tonal)
            if (uri != null && role != "workspace") {
                AppButton("Use sub-folder", {
                    Prefs.setTreeUri(role, null)
                    changed()
                }, style = BtnStyle.Outline)
            }
        }
    }
}

// ---------------------------------------------------------------- file browser (also folder picker)

@Composable
private fun BrowserRow(icon: Int, name: String, sub: String, onDelete: (() -> Unit)?, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icn(icon, tint = MaterialTheme.colorScheme.primary, size = 22.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(name, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (sub.isNotEmpty()) Hint(sub)
        }
        if (onDelete != null) IconBtn(R.drawable.ic_delete, "Delete " + name, onDelete)
    }
}

@Composable
private fun Browser(modifier: Modifier, onPick: ((String) -> Unit)?) {
    var path by remember { mutableStateOf(listOf<String>()) }
    var rows by remember { mutableStateOf<List<Node>>(emptyList()) }
    var virtual by remember { mutableStateOf<List<String>>(emptyList()) }
    var error by remember { mutableStateOf("") }
    var refresh by remember { mutableIntStateOf(0) }
    var toDelete by remember { mutableStateOf<Node?>(null) }
    var newFolder by remember { mutableStateOf(false) }
    var folderName by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }

    LaunchedEffect(path, refresh) {
        error = ""
        try {
            val res = withContext(Dispatchers.IO) {
                val l = Workspace.loc(PathUtil.join(path))
                val n = FileOps.requireNode(l)
                l.tree.children(n).sortedWith(compareBy<Node>({ !it.isDir }, { it.name.lowercase() }))
            }
            rows = res
            virtual = if (path.isEmpty()) {
                listOf("ZIP" to "zip", "APK" to "apk", "BuildWorkspace" to "build").filter { Prefs.treeUri(it.second) != null }.map { it.first }
            } else emptyList()
        } catch (e: Exception) {
            rows = emptyList()
            error = if (e is OpError) (e.message ?: "") else "Cannot read this folder: " + e.message
        }
    }

    Column(modifier) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                "/" + PathUtil.join(path),
                modifier = Modifier.weight(1f),
                fontFamily = FontFamily.Monospace,
                fontSize = 13.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (path.isNotEmpty()) AppButton("Up", { path = path.dropLast(1) }, icon = R.drawable.ic_up, style = BtnStyle.Tonal)
            AppButton("New", {
                newFolder = true
                folderName = ""
            }, icon = R.drawable.ic_add, style = BtnStyle.Tonal)
        }
        if (onPick != null) {
            AppButton("Use this folder", { onPick(PathUtil.join(path)) }, Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp), R.drawable.ic_check)
        }
        if (error.isNotEmpty()) Text(error, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(16.dp))
        if (note.isNotEmpty()) Box(Modifier.padding(horizontal = 16.dp)) { Hint(note) }
        LazyColumn(Modifier.weight(1f)) {
            items(virtual) { v -> BrowserRow(R.drawable.ic_link, "$v/", "", null) { path = path + v } }
            items(rows, key = { it.docId }) { n ->
                BrowserRow(
                    if (n.isDir) R.drawable.ic_folder else R.drawable.ic_file,
                    n.name,
                    if (n.isDir) "" else fmtBytes(n.size),
                    { toDelete = n }
                ) { if (n.isDir) path = path + n.name }
                HorizontalDivider(Modifier.padding(horizontal = 16.dp))
            }
        }
    }

    val d = toDelete
    if (d != null) {
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Delete " + d.name + "?") },
            text = { Text(if (d.isDir) "The folder and everything in it will be deleted." else "This file will be deleted.") },
            confirmButton = {
                AppButton("Delete", {
                    toDelete = null
                    val target = PathUtil.join(path + d.name)
                    Ops.runLocal("delete", { ctx -> FileOps.delete(target, true, ctx) }) { txt ->
                        note = if (txt.startsWith("{")) "Deleted." else txt
                        refresh++
                    }
                }, style = BtnStyle.Danger)
            },
            dismissButton = { AppButton("Cancel", { toDelete = null }, style = BtnStyle.Outline) }
        )
    }
    if (newFolder) {
        AlertDialog(
            onDismissRequest = { newFolder = false },
            title = { Text("New folder") },
            text = { AppField("Name", folderName, { folderName = it }) },
            confirmButton = {
                AppButton("Create", {
                    newFolder = false
                    val target = PathUtil.join(path + folderName.trim())
                    if (folderName.isNotBlank()) {
                        Ops.runLocal("create_folder", { _ -> FileOps.createFolder(target) }) { txt ->
                            note = if (txt.startsWith("{")) "Folder created." else txt
                            refresh++
                        }
                    }
                })
            },
            dismissButton = { AppButton("Cancel", { newFolder = false }, style = BtnStyle.Outline) }
        )
    }
}

// ---------------------------------------------------------------- ZIP

@Composable
private fun ZipScreen(onBack: () -> Unit) {
    var picked by remember { mutableStateOf<String?>(null) }
    var out by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val ops by BridgeState.ops.collectAsState()
    val src = picked
    Column(Modifier.fillMaxSize()) {
        SubHeader("Create ZIP") { if (src != null) picked = null else onBack() }
        if (src == null) {
            Box(Modifier.padding(horizontal = 16.dp)) { Hint("Choose the folder to ZIP") }
            Browser(Modifier.weight(1f)) {
                picked = it
                out = "ZIP/" + it.substringAfterLast('/').ifEmpty { "workspace" } + ".zip"
                result = ""
            }
        } else {
            Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                AppCard {
                    InfoRow("Source", "/$src")
                    AppField("Output (relative path)", out, { out = it })
                    Hint("Streamed on the phone: written as .tmp and renamed when complete. Never overwrites (adds ' (1)').")
                }
                AppButton(
                    if (busy) "Working..." else "Create ZIP",
                    {
                        busy = true
                        result = ""
                        Ops.runLocal("create_zip", { ctx -> ZipEngine.create(src, out, emptyList(), emptyList(), false, false, ctx) }) {
                            result = it
                            busy = false
                        }
                    },
                    Modifier.fillMaxWidth(), R.drawable.ic_archive, enabled = !busy && out.isNotBlank()
                )
                if (busy && ops.isNotEmpty()) {
                    for (o in ops) OpRow(o)
                    AppButton("Cancel", { Ops.current?.cancel() }, Modifier.fillMaxWidth(), R.drawable.ic_close, style = BtnStyle.Outline)
                }
                if (result.isNotEmpty()) Text(result, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
            }
        }
    }
}

// ---------------------------------------------------------------- build

@Composable
private fun BuildScreen(onBack: () -> Unit) {
    var project by remember { mutableStateOf<String?>(null) }
    val p = project
    Column(Modifier.fillMaxSize()) {
        SubHeader("Build project") { if (p != null) project = null else onBack() }
        if (p == null) {
            Box(Modifier.padding(horizontal = 16.dp)) { Hint("Choose the project folder") }
            Browser(Modifier.weight(1f)) { project = it }
        } else {
            BuildPanel(p, Modifier.weight(1f))
        }
    }
}

@Composable
private fun BuildPanel(project: String, modifier: Modifier) {
    val name = project.substringAfterLast('/').ifEmpty { "project" }
    val zipPath = "ZIP/$name-build.zip"
    var result by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var askUpload by remember { mutableStateOf(false) }
    var optimizeGradle by remember { mutableStateOf(false) }
    val ops by BridgeState.ops.collectAsState()

    fun exec(label: String, block: suspend (OpCtx) -> JSONObject, pretty: Boolean = false) {
        busy = true
        result = ""
        Ops.runLocal(label, block) { txt ->
            result = if (pretty) (try {
                JSONObject(txt).optString("optimization_report").ifEmpty { txt }
            } catch (e: Exception) {
                txt
            }) else txt
            busy = false
        }
    }

    Column(
        modifier.verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        AppCard {
            InfoRow("Project", "/$project")
            Hint("Prepare makes a filtered copy in BuildWorkspace (the original is untouched) and zips it. Always a universal APK; ABI splits are removed in the copy.")
            ToggleRow("Enable R8 and resource shrinking in the copy", optimizeGradle, { optimizeGradle = it }, "Skipped automatically for native (NDK) projects")
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            AppButton("Analyze", {
                exec("analyze", { ctx -> ProjectPreparer.prepare(project, zipPath, true, optimizeGradle, true, false, emptyList(), false, ctx) }, true)
            }, Modifier.weight(1f), R.drawable.ic_search, !busy, BtnStyle.Tonal)
            AppButton("Prepare ZIP", {
                exec("prepare_project_zip", { ctx -> ProjectPreparer.prepare(project, zipPath, true, optimizeGradle, false, false, emptyList(), false, ctx) })
            }, Modifier.weight(1f), R.drawable.ic_archive, !busy, BtnStyle.Tonal)
        }
        AppButton("Upload and build (GitHub)", { askUpload = true }, Modifier.fillMaxWidth(), R.drawable.ic_upload, !busy)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            AppButton("Status", { exec("build status", { _ -> GitHub.status("") }) }, Modifier.weight(1f), enabled = !busy, style = BtnStyle.Outline)
            AppButton("Logs", { exec("build logs", { _ -> GitHub.logs("", 120, "") }) }, Modifier.weight(1f), enabled = !busy, style = BtnStyle.Outline)
            AppButton("Cancel", { exec("cancel build", { _ -> GitHub.cancel("") }) }, Modifier.weight(1f), enabled = !busy, style = BtnStyle.Outline)
        }
        AppButton("Download APK", { exec("download APK", { ctx -> GitHub.download("", "APK", ctx) }) }, Modifier.fillMaxWidth(), R.drawable.ic_install, !busy, BtnStyle.Tonal)
        if (busy && ops.isNotEmpty()) {
            for (o in ops) OpRow(o)
            AppButton("Cancel operation", { Ops.current?.cancel() }, Modifier.fillMaxWidth(), R.drawable.ic_close, style = BtnStyle.Outline)
        }
        if (result.isNotEmpty()) Text(result, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
    }

    if (askUpload) {
        AlertDialog(
            onDismissRequest = { askUpload = false },
            title = { Text("Prepare and upload?") },
            text = { Text("Stages $name, creates $zipPath, uploads it to your configured GitHub repository and starts the build.") },
            confirmButton = {
                AppButton("Upload", {
                    askUpload = false
                    exec("start_build", { ctx ->
                        val prep = ProjectPreparer.prepare(project, zipPath, true, optimizeGradle, false, false, emptyList(), true, ctx)
                        val l = Workspace.loc(prep.optString("output").ifEmpty { zipPath })
                        GitHub.start(l.tree, FileOps.requireNode(l), l.display, "", ctx)
                    })
                })
            },
            dismissButton = { AppButton("Cancel", { askUpload = false }, style = BtnStyle.Outline) }
        )
    }
}

// ---------------------------------------------------------------- APKs

private fun installApk(ctx: Context, tree: Tree, n: Node, scope: CoroutineScope, onMsg: (String) -> Unit) {
    scope.launch {
        try {
            if (Build.VERSION.SDK_INT >= 26 && !ctx.packageManager.canRequestPackageInstalls()) {
                onMsg("Allow installs from FileBridge, then tap Install again.")
                ctx.startActivity(
                    Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                return@launch
            }
            val f = withContext(Dispatchers.IO) {
                val dir = File(ctx.cacheDir, "apk")
                dir.mkdirs()
                val out = File(dir, n.name.replace('/', '_'))
                tree.openIn(n).use { i -> out.outputStream().use { o -> i.copyTo(o) } }
                out
            }
            val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
            ctx.startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            onMsg("")
        } catch (e: Exception) {
            onMsg("Could not open the installer: " + e.message)
        }
    }
}

@Composable
private fun ApksScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var list by remember { mutableStateOf<List<Node>>(emptyList()) }
    var tree by remember { mutableStateOf<Tree?>(null) }
    var msg by remember { mutableStateOf("") }
    var refresh by remember { mutableIntStateOf(0) }
    var toDelete by remember { mutableStateOf<Node?>(null) }

    LaunchedEffect(refresh) {
        try {
            val res = withContext(Dispatchers.IO) {
                val l = Workspace.loc("APK")
                val dir = l.tree.ensureDir(l.segs)
                Pair(l.tree, l.tree.children(dir).filter { !it.isDir && it.name.lowercase().endsWith(".apk") }.sortedByDescending { it.modified })
            }
            tree = res.first
            list = res.second
            msg = ""
        } catch (e: Exception) {
            msg = if (e is OpError) (e.message ?: "") else "Cannot read the APK folder: " + e.message
        }
    }

    Column(Modifier.fillMaxSize()) {
        SubHeader("APKs", onBack)
        if (msg.isNotEmpty()) Text(msg, modifier = Modifier.padding(16.dp), color = MaterialTheme.colorScheme.error)
        if (list.isEmpty() && msg.isEmpty()) Box(Modifier.padding(16.dp)) { Hint("No APKs yet. Downloaded builds appear here (APK/).") }
        LazyColumn(
            Modifier.weight(1f).padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(list) { n ->
                AppCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icn(R.drawable.ic_phone, tint = MaterialTheme.colorScheme.primary, size = 22.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(n.name, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Hint(fmtBytes(n.size))
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AppButton("Install", { tree?.let { t -> installApk(ctx, t, n, scope) { msg = it } } }, Modifier.weight(1f), R.drawable.ic_install)
                        AppButton("Delete", { toDelete = n }, Modifier.weight(1f), R.drawable.ic_delete, style = BtnStyle.Outline)
                    }
                }
            }
        }
    }
    val d = toDelete
    val t = tree
    if (d != null && t != null) {
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Delete " + d.name + "?") },
            confirmButton = {
                AppButton("Delete", {
                    toDelete = null
                    scope.launch {
                        withContext(Dispatchers.IO) { t.delete(d) }
                        refresh++
                    }
                }, style = BtnStyle.Danger)
            },
            dismissButton = { AppButton("Cancel", { toDelete = null }, style = BtnStyle.Outline) }
        )
    }
}

// ---------------------------------------------------------------- activity

@Composable
private fun ActivityScreen() {
    val list by BridgeState.activity.collectAsState()
    val usage by BridgeState.usage.collectAsState()
    val fmt = remember { SimpleDateFormat("MMM d, HH:mm", Locale.getDefault()) }
    Column(Modifier.fillMaxSize()) {
        TitleBar("Activity")
        Box(Modifier.padding(horizontal = 16.dp)) {
            Hint("Data today: up " + fmtBytes(usage.first) + ", down " + fmtBytes(usage.second) + ". Only metadata is kept, never file contents.")
        }
        LazyColumn(
            Modifier.weight(1f).padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (list.isEmpty()) item { Hint("Nothing yet.") }
            items(list) { a ->
                AppCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(a.tool, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                        Pill(if (a.ok) "OK" else "FAILED", if (a.ok) GoodColor else BadColor)
                    }
                    val who = if (a.remote) (if (a.client.isNotEmpty()) a.client else "AI") else "you"
                    val size = if (a.bytes > 0) fmtBytes(a.bytes) + "  |  " else ""
                    val why = if (a.detail.isNotEmpty()) "  |  " + a.detail else ""
                    Hint(who + "  |  " + size + (a.ms / 1000).toString() + " s  |  " + fmt.format(Date(a.time)) + why)
                }
            }
        }
    }
}

// ---------------------------------------------------------------- settings

@Composable
private fun SettingsScreen(onRepair: () -> Unit, onAis: () -> Unit) {
    val ctx = LocalContext.current
    val enabled by BridgeState.claudeEnabled.collectAsState()
    var tick by remember { mutableIntStateOf(0) }
    var perms by remember { mutableStateOf(Perm.values().associateWith { Prefs.perm(it) }) }
    var cfOver by remember { mutableStateOf(Prefs.confirmOverwrite) }
    var owGrants by remember { mutableIntStateOf(Prefs.overwriteGrants.size) }
    var cfUp by remember { mutableStateOf(Prefs.confirmUpload) }
    var cfMove by remember { mutableStateOf(Prefs.confirmMove) }
    var cfStore by remember { mutableIntStateOf(Prefs.confirmLargeStorageMb) }
    var cfNet by remember { mutableIntStateOf(Prefs.confirmLargeNetworkMb) }
    var backend by remember { mutableStateOf(Prefs.backendUrl) }
    var ghOwner by remember { mutableStateOf(Prefs.ghOwner) }
    var ghRepo by remember { mutableStateOf(Prefs.ghRepo) }
    var ghBranch by remember { mutableStateOf(Prefs.ghBranch) }
    var ghWorkflow by remember { mutableStateOf(Prefs.ghWorkflow) }
    var ghZip by remember { mutableStateOf(Prefs.ghZipPath) }
    var ghArtifact by remember { mutableStateOf(Prefs.ghArtifact) }
    var ghToken by remember { mutableStateOf("") }
    var askDisconnect by remember { mutableStateOf(false) }
    var pollOnly by remember { mutableStateOf(Prefs.pollingOnly) }

    Column(Modifier.fillMaxSize()) {
        TitleBar("Settings")
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            AppCard {
                SectionHeader("AI access")
                Hint("What every connected AI may do on this phone. Move, delete and upload stay off until you switch them on.")
                Spacer(Modifier.height(4.dp))
                for (p in Perm.values()) {
                    ToggleRow(p.label, perms[p] == true, { v ->
                        Prefs.setPerm(p, v)
                        perms = perms + Pair(p, v)
                        Bridge.pushState()
                    })
                }
                ToggleRow("Disable AI access", !enabled, { Bridge.setClaudeEnabled(!it) }, "Refuse every command from every AI")
                Spacer(Modifier.height(8.dp))
                AppButton("Connected AIs and keys", onAis, Modifier.fillMaxWidth(), R.drawable.ic_group, style = BtnStyle.Tonal)
            }

            AppCard {
                SectionHeader("Storage")
                Hint("Your AIs can only reach inside the folders you pick. Change the workspace here at any time.")
                for (r in listOf("workspace" to "Claude Workspace", "zip" to "ZIP Output", "apk" to "APK Output", "build" to "Build Workspace")) {
                    FolderRow(r.first, r.second, tick) { tick++ }
                }
            }

            AppCard {
                SectionHeader("Confirmations")
                Hint("Deleting always asks. Everything else is up to you.")
                ToggleRow("Confirm overwrites", cfOver, { cfOver = it; Prefs.confirmOverwrite = it })
                if (owGrants > 0) {
                    Hint("Always allow is on for $owGrants folder(s): replacing existing files there no longer asks.")
                    AppButton("Ask again before overwriting", { Prefs.overwriteGrants = emptySet(); owGrants = 0 }, Modifier.fillMaxWidth(), style = BtnStyle.Outline)
                }
                ToggleRow("Confirm uploads", cfUp, { cfUp = it; Prefs.confirmUpload = it })
                ToggleRow("Confirm moves", cfMove, { cfMove = it; Prefs.confirmMove = it })
                Spacer(Modifier.height(6.dp))
                AppButton(
                    if (cfStore == 0) "Large storage use: never ask" else "Large storage use: ask above $cfStore MB",
                    {
                        val o = listOf(0, 100, 500, 1000, 2000)
                        cfStore = o[(o.indexOf(cfStore) + 1).mod(o.size)]
                        Prefs.confirmLargeStorageMb = cfStore
                    },
                    Modifier.fillMaxWidth(), style = BtnStyle.Outline
                )
                Spacer(Modifier.height(8.dp))
                AppButton(
                    if (cfNet == 0) "Large network use: never ask" else "Large network use: ask above $cfNet MB",
                    {
                        val o = listOf(0, 10, 50, 200, 1000)
                        cfNet = o[(o.indexOf(cfNet) + 1).mod(o.size)]
                        Prefs.confirmLargeNetworkMb = cfNet
                    },
                    Modifier.fillMaxWidth(), style = BtnStyle.Outline
                )
            }

            AppCard {
                SectionHeader("Connection")
                ToggleRow(
                    "Reliable mode (polling)", pollOnly,
                    { pollOnly = it; Prefs.pollingOnly = it; Bridge.restartConnection() },
                    "Ignore Realtime pings and long-poll the backend. Uses a little more data and battery, but works when pings are blocked."
                )
                AppField("Backend URL", backend, { backend = it; Prefs.backendUrl = it })
                InfoRow("Device ID", Prefs.deviceId) { copyToClipboard(ctx, "Device ID", Prefs.deviceId) }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AppButton("Re-pair", onRepair, Modifier.weight(1f), R.drawable.ic_refresh, style = BtnStyle.Tonal)
                    AppButton("Disconnect", { askDisconnect = true }, Modifier.weight(1f), R.drawable.ic_close, style = BtnStyle.Outline)
                }
            }

            AppCard {
                SectionHeader("Build provider (GitHub Actions)")
                Hint("Uploads go from this phone straight to your repository with your token (stored encrypted here, never sent to the backend).")
                AppField("Owner", ghOwner, { ghOwner = it; Prefs.ghOwner = it })
                AppField("Repository", ghRepo, { ghRepo = it; Prefs.ghRepo = it })
                AppField("Branch", ghBranch, { ghBranch = it; Prefs.ghBranch = it })
                AppField("Workflow file (for dispatch)", ghWorkflow, { ghWorkflow = it; Prefs.ghWorkflow = it })
                AppField("ZIP path in repo", ghZip, { ghZip = it; Prefs.ghZipPath = it })
                AppField("Artifact name (optional)", ghArtifact, { ghArtifact = it; Prefs.ghArtifact = it })
                AppField(
                    if (Prefs.ghToken.isNullOrEmpty()) "Access token" else "Access token (saved, type to replace)",
                    ghToken, { ghToken = it; Prefs.ghToken = it }, secret = true
                )
            }

            AppCard {
                SectionHeader("Background")
                Hint("FileBridge runs as a foreground service so you can keep using your phone. Stop it from the notification or the Home screen.")
                Spacer(Modifier.height(4.dp))
                Hint(
                    if (batteryUnrestricted(ctx)) "Battery: unrestricted."
                    else "Battery: optimised by Android. For reliability with the screen off choose Unrestricted. Some phones (for example Infinix XOS) also need Auto-start allowed and battery cleaning off for this app."
                )
                Spacer(Modifier.height(8.dp))
                AppButton("Battery settings", { openBatterySettings(ctx) }, Modifier.fillMaxWidth(), style = BtnStyle.Tonal)
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    if (askDisconnect) {
        AlertDialog(
            onDismissRequest = { askDisconnect = false },
            title = { Text("Disconnect this phone?") },
            text = { Text("Your AIs lose access until you pair again. No files are touched.") },
            confirmButton = {
                AppButton("Disconnect", {
                    askDisconnect = false
                    Bridge.disconnect {
                        ctx.stopService(Intent(ctx, BridgeService::class.java))
                        onRepair()
                    }
                }, style = BtnStyle.Danger)
            },
            dismissButton = { AppButton("Cancel", { askDisconnect = false }, style = BtnStyle.Outline) }
        )
    }
}
