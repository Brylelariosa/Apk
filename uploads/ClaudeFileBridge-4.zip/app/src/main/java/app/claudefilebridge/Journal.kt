package app.claudefilebridge

import kotlinx.coroutines.CancellationException
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Operation journal kept on the phone (one JSON object per line, newest last) so that nothing is lost when the backend
 * cannot be reached or the app is killed in the middle of an operation. The backend writes its own journal
 * automatically; this one fills the gaps: results that could not be delivered, and operations that were still running when
 * the process died. Pending entries are synchronised to the backend after every successful connection.
 * Only operations that change files are recorded, and never file content.
 */
object Journal {
    private const val MAX_LINES = 300
    private val lock = Any()
    private var recovered = false
    private val MUTATING = setOf("write_file", "edit_file", "create_folder", "copy_file", "move_file", "delete_file", "create_zip", "extract_zip", "prepare_project_zip")

    private fun file(): File = File(Prefs.appCtx.filesDir, "fb_journal.jsonl")

    private fun readAll(): MutableList<JSONObject> {
        val out = ArrayList<JSONObject>()
        val f = file()
        if (!f.exists()) return out
        try {
            f.forEachLine { line ->
                if (line.isNotBlank()) {
                    try {
                        out.add(JSONObject(line))
                    } catch (e: Exception) {
                    }
                }
            }
        } catch (e: Exception) {
        }
        return out
    }

    private fun writeAll(all: List<JSONObject>) {
        try {
            val keep = if (all.size > MAX_LINES) all.subList(all.size - MAX_LINES, all.size) else all
            val tmp = File(file().path + ".tmp")
            tmp.bufferedWriter().use { w ->
                for (o in keep) {
                    w.write(o.toString())
                    w.write("\n")
                }
            }
            if (!tmp.renameTo(file())) {
                file().delete()
                tmp.renameTo(file())
            }
        } catch (e: Exception) {
        }
    }

    private fun pathsOf(cmd: Command): JSONArray {
        val a = cmd.args
        val out = JSONArray()
        fun add(k: String) {
            out.put(a.optString(k, ""))
        }
        when (cmd.tool) {
            "write_file", "edit_file", "create_folder", "delete_file" -> add("path")
            "copy_file", "move_file" -> {
                add("source")
                add("destination")
            }
            "create_zip" -> {
                add("source")
                add("output")
            }
            "prepare_project_zip" -> {
                add("project")
                add("output")
            }
            "extract_zip" -> {
                add("zip")
                add("destination")
            }
        }
        return out
    }

    /** Called when a command starts running. */
    fun begin(cmd: Command) {
        if (cmd.tool !in MUTATING) return
        synchronized(lock) {
            val all = readAll()
            all.add(jsonOf("id" to cmd.id, "tool" to cmd.tool, "paths" to pathsOf(cmd), "t0" to System.currentTimeMillis(), "state" to "started", "reported" to false))
            writeAll(all)
        }
    }

    /** Called when a command ended (successfully or not), before the result is sent to the backend. */
    fun finish(cmd: Command, ok: Boolean, code: String?, result: JSONObject?, ms: Long) {
        if (cmd.tool !in MUTATING) return
        synchronized(lock) {
            val all = readAll()
            val e = all.lastOrNull { it.optString("id") == cmd.id } ?: return
            e.put("state", if (ok) "succeeded" else "failed")
            e.put("ms", ms)
            if (code != null) e.put("error_code", code)
            if (result != null) {
                val rev = result.optString("revision", "")
                if (rev.isNotEmpty() && rev != "null") e.put("revision", rev)
                if (result.has("size") && !result.isNull("size")) e.put("size", result.optLong("size", 0L))
                if (result.optBoolean("unchanged", false)) e.put("unchanged", true)
            }
            writeAll(all)
        }
    }

    /** The backend accepted the result: nothing left to synchronise for this command. */
    fun reported(id: String) {
        synchronized(lock) {
            val all = readAll()
            val e = all.lastOrNull { it.optString("id") == id } ?: return
            if (e.optBoolean("reported", false)) return
            e.put("reported", true)
            writeAll(all)
        }
    }

    /** Once per process start: operations that were still "started" died with the previous process. */
    fun recoverInterrupted() {
        synchronized(lock) {
            if (recovered) return
            recovered = true
            val all = readAll()
            var changed = false
            for (e in all) {
                if (e.optString("state") == "started") {
                    e.put("state", "interrupted")
                    e.put("reported", false)
                    changed = true
                }
            }
            if (changed) writeAll(all)
        }
    }

    /** Sends everything the backend has not confirmed (late results, interrupted operations). Safe to call often. */
    suspend fun syncPending() {
        val batch = JSONArray()
        val ids = ArrayList<String>()
        synchronized(lock) {
            for (e in readAll()) {
                if (batch.length() >= 50) break
                val st = e.optString("state")
                if (!e.optBoolean("reported", false) && (st == "succeeded" || st == "failed" || st == "interrupted")) {
                    batch.put(
                        jsonOf(
                            "command_id" to e.optString("id"), "tool" to e.optString("tool"), "state" to st,
                            "error_code" to e.optString("error_code", ""), "paths" to e.optJSONArray("paths"),
                            "revision" to e.optString("revision", ""), "size" to (if (e.has("size")) e.optLong("size") else null),
                            "unchanged" to e.optBoolean("unchanged", false)
                        )
                    )
                    ids.add(e.optString("id"))
                }
            }
        }
        if (batch.length() == 0) return
        val r = try {
            Backend.journalSync(batch)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            null
        }
        if (r != null && r.code == 200) {
            for (id in ids) reported(id)
            Dbg.log("journal: sent ${ids.size} operation(s) the backend had not confirmed")
        }
    }
}
