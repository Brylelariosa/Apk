-- Shared memory for every connected AI, per-AI connector keys with scopes, and multi-AI concurrency.
-- Already applied as migrations "filebridge_memory_and_clients_v1" and "filebridge_concurrency_v1" (additive only).

create table if not exists public.filebridge_clients (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 1 and 40),
  token_hash text not null unique,
  scopes text[] not null default '{memory}',
  created_at timestamptz not null default now(),
  last_used_at timestamptz,
  revoked_at timestamptz
);

create table if not exists public.filebridge_memory (
  id uuid primary key default gen_random_uuid(),
  project text not null default 'general' check (char_length(project) between 1 and 60),
  kind text not null default 'note' check (kind in ('note','decision','todo','handoff','fact')),
  title text not null check (char_length(title) between 1 and 160),
  content text not null default '' check (char_length(content) <= 20000),
  tags text[] not null default '{}',
  pinned boolean not null default false,
  status text not null default 'open',
  archived boolean not null default false,
  author text not null default 'ai',
  updated_by text not null default 'ai',
  version int not null default 1,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists filebridge_memory_project_idx on public.filebridge_memory (project, archived, updated_at desc);
create index if not exists filebridge_memory_pinned_idx on public.filebridge_memory (pinned) where pinned;

alter table public.filebridge_commands add column if not exists client_name text;
alter table public.filebridge_config add column if not exists primary_last_used_at timestamptz;
alter table public.filebridge_memory add column if not exists assignee text;
alter table public.filebridge_memory drop constraint if exists filebridge_memory_status_check;
alter table public.filebridge_memory add constraint filebridge_memory_status_check check (status in ('open','in_progress','done'));

do $$
declare t text;
begin
  foreach t in array array['filebridge_clients','filebridge_memory'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('revoke all on table public.%I from anon, authenticated', t);
    execute format('drop policy if exists filebridge_deny_all on public.%I', t);
    execute format('create policy filebridge_deny_all on public.%I as restrictive for all to anon, authenticated using (false) with check (false)', t);
  end loop;
end $$;

-- Resolve a connector key to a client (scoped keys first, then the primary full-access key).
create or replace function public.filebridge_client_resolve(p_hash text)
returns table (r_id uuid, r_name text, r_scopes text[])
language plpgsql set search_path = public as $$
begin
  if exists (select 1 from public.filebridge_clients c where c.token_hash = p_hash and c.revoked_at is null) then
    update public.filebridge_clients c set last_used_at = now()
     where c.token_hash = p_hash and (c.last_used_at is null or c.last_used_at < now() - interval '60 seconds');
    return query select c.id, c.name, c.scopes from public.filebridge_clients c where c.token_hash = p_hash and c.revoked_at is null;
    return;
  end if;
  if exists (select 1 from public.filebridge_config f where f.id = 1 and f.connector_token_hash = p_hash) then
    update public.filebridge_config f set primary_last_used_at = now()
     where f.id = 1 and (f.primary_last_used_at is null or f.primary_last_used_at < now() - interval '60 seconds');
    return query select null::uuid, 'primary'::text, array['files','memory','builds']::text[];
  end if;
end $$;

create or replace function public.filebridge_memory_append(p_id uuid, p_text text, p_by text)
returns public.filebridge_memory
language plpgsql set search_path = public as $$
declare r public.filebridge_memory;
begin
  select * into r from public.filebridge_memory where id = p_id and not archived for update;
  if not found then return null; end if;
  if char_length(r.content) + char_length(p_text) + 1 > 20000 then raise exception 'too_large'; end if;
  update public.filebridge_memory m
     set content = case when m.content = '' then p_text else m.content || E'\n' || p_text end,
         version = m.version + 1, updated_by = p_by, updated_at = now()
   where m.id = p_id
  returning * into r;
  return r;
end $$;

create or replace function public.filebridge_memory_search(p_query text, p_project text, p_kind text, p_include_archived boolean, p_limit int)
returns table (id uuid, project text, kind text, title text, snippet text, tags text[], pinned boolean, status text, archived boolean, author text, updated_by text, version int, updated_at timestamptz)
language sql stable set search_path = public as $$
  select m.id, m.project, m.kind, m.title, left(m.content, 240), m.tags, m.pinned, m.status, m.archived, m.author, m.updated_by, m.version, m.updated_at
    from public.filebridge_memory m
   where (coalesce(p_project, '') = '' or m.project = p_project)
     and (coalesce(p_kind, '') = '' or m.kind = p_kind)
     and (coalesce(p_include_archived, false) or not m.archived)
     and (btrim(coalesce(p_query, '')) = ''
          or to_tsvector('simple', m.title || ' ' || m.content || ' ' || array_to_string(m.tags, ' ')) @@ websearch_to_tsquery('simple', p_query)
          or m.title ilike '%' || p_query || '%' or m.content ilike '%' || p_query || '%')
   order by m.pinned desc,
            case when btrim(coalesce(p_query, '')) = '' then 0
                 else ts_rank(to_tsvector('simple', m.title || ' ' || m.content), websearch_to_tsquery('simple', p_query)) end desc,
            m.updated_at desc
   limit greatest(1, least(coalesce(p_limit, 20), 100));
$$;

create or replace function public.filebridge_memory_projects()
returns table (project text, entries bigint, last_updated timestamptz)
language sql stable set search_path = public as $$
  select m.project, count(*), max(m.updated_at) from public.filebridge_memory m
   where not m.archived group by m.project order by max(m.updated_at) desc;
$$;

-- Several AIs at once: per-AI attribution and queue limit (5 per AI, 10 per phone).
drop function if exists public.filebridge_enqueue(text, text, jsonb, boolean, int, text);
create or replace function public.filebridge_enqueue(p_device_id text, p_tool text, p_args jsonb, p_destructive boolean, p_ttl int, p_nonce text, p_client text default null)
returns public.filebridge_commands
language plpgsql set search_path = public as $$
declare n int; nc int; r public.filebridge_commands;
begin
  update public.filebridge_commands set status = 'expired', completed_at = now(), args = '{}'::jsonb
   where device_id = p_device_id
     and ((status = 'queued' and expires_at <= now())
       or (status in ('delivered','running','awaiting_confirmation') and delivered_at < now() - interval '2 hours'));
  select count(*) into n from public.filebridge_commands
   where device_id = p_device_id and status in ('queued','delivered','running','awaiting_confirmation');
  if n >= 10 then raise exception 'queue_full'; end if;
  if p_client is not null then
    select count(*) into nc from public.filebridge_commands
     where device_id = p_device_id and client_name = p_client and status in ('queued','delivered','running','awaiting_confirmation');
    if nc >= 5 then raise exception 'client_queue_full'; end if;
  end if;
  insert into public.filebridge_commands (device_id, tool, args, destructive, nonce, expires_at, client_name)
  values (p_device_id, p_tool, coalesce(p_args, '{}'::jsonb), coalesce(p_destructive, false), p_nonce,
          now() + make_interval(secs => greatest(10, least(coalesce(p_ttl, 90), 600))), left(p_client, 40))
  returning * into r;
  return r;
end $$;

create or replace function public.filebridge_active_ais(p_minutes int default 10)
returns table (name text, last_used_at timestamptz)
language sql stable set search_path = public as $$
  select c.name, c.last_used_at from public.filebridge_clients c
   where c.revoked_at is null and c.last_used_at > now() - make_interval(mins => greatest(1, least(coalesce(p_minutes, 10), 1440)))
  union all
  select 'primary'::text, f.primary_last_used_at from public.filebridge_config f
   where f.id = 1 and f.primary_last_used_at > now() - make_interval(mins => greatest(1, least(coalesce(p_minutes, 10), 1440)))
  order by 2 desc;
$$;

do $$
declare f text;
begin
  foreach f in array array[
    'filebridge_client_resolve(text)', 'filebridge_memory_append(uuid,text,text)',
    'filebridge_memory_search(text,text,text,boolean,int)', 'filebridge_memory_projects()',
    'filebridge_enqueue(text,text,jsonb,boolean,int,text,text)', 'filebridge_active_ais(int)'
  ] loop
    execute format('revoke all on function public.%s from public, anon, authenticated', f);
    execute format('grant execute on function public.%s to service_role', f);
  end loop;
end $$;
