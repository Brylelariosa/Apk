-- Claude FileBridge 1.2.0 backend, part A of 2 (additive; unique filebridge_* names only).
--
-- Adds: an operation journal that the server writes by itself (no AI has to remember anything), per-project
-- state mirrored into shared memory, file revisions, write leases for several AIs at once, test-run records with
-- honest states, recovery of interrupted work and late sync from the phone.
-- Nothing in the running 1.1.0 system calls these objects yet; part B wires them into the command queue.
-- Applied as migration "filebridge_v1_2a_state_leases_tests".

-- ===================== tables =====================

create table if not exists public.filebridge_journal (
  id bigint generated always as identity primary key,
  command_id uuid unique,
  device_id text,
  project text not null default 'general',
  project_source text not null default 'default',
  owner text not null default 'unknown',
  tool text not null,
  paths text[] not null default '{}',
  note text,
  state text not null default 'queued' check (state in ('queued','delivered','running','awaiting_confirmation','succeeded','failed','rejected','cancelled','expired','interrupted','recorded')),
  error_code text,
  detail text,
  revision jsonb,
  bytes bigint,
  duration_ms int,
  source text not null default 'server',
  created_at timestamptz not null default now(),
  finished_at timestamptz
);
create index if not exists filebridge_journal_project_idx on public.filebridge_journal (project, created_at desc);
create index if not exists filebridge_journal_open_idx on public.filebridge_journal (created_at) where state in ('queued','delivered','running','awaiting_confirmation');
create index if not exists filebridge_journal_device_idx on public.filebridge_journal (device_id, created_at desc);

create table if not exists public.filebridge_file_state (
  device_id text not null,
  path text not null,
  project text not null default 'general',
  rev int not null default 1,
  sha256 text,
  size bigint,
  deleted boolean not null default false,
  updated_by text not null,
  updated_at timestamptz not null default now(),
  primary key (device_id, path)
);
create index if not exists filebridge_file_state_project_idx on public.filebridge_file_state (project, updated_at desc);

create table if not exists public.filebridge_file_seen (
  device_id text not null,
  owner text not null,
  path text not null,
  sha256 text,
  seen_at timestamptz not null default now(),
  primary key (device_id, owner, path)
);

create table if not exists public.filebridge_owner_project (
  owner text primary key,
  project text not null,
  updated_at timestamptz not null default now()
);

create table if not exists public.filebridge_project_state (
  project text primary key,
  revision int not null default 0,
  last_activity_at timestamptz,
  last_owner text,
  summary text,
  completed text[] not null default '{}',
  pending text[] not null default '{}',
  next_steps text[] not null default '{}',
  checkpoint_at timestamptz,
  checkpoint_by text,
  updated_at timestamptz not null default now()
);

create table if not exists public.filebridge_leases (
  id uuid primary key default gen_random_uuid(),
  project text not null,
  device_id text,
  owner text not null,
  paths text[] not null,
  purpose text,
  created_at timestamptz not null default now(),
  renewed_at timestamptz not null default now(),
  expires_at timestamptz not null,
  released_at timestamptz,
  released_reason text
);
create index if not exists filebridge_leases_active_idx on public.filebridge_leases (expires_at) where released_at is null;
create index if not exists filebridge_leases_project_idx on public.filebridge_leases (project, created_at desc);

create table if not exists public.filebridge_test_runs (
  id uuid primary key default gen_random_uuid(),
  project text not null,
  owner text not null,
  name text not null check (char_length(name) between 1 and 120),
  command text not null check (char_length(command) between 1 and 500),
  environment text not null check (environment in ('original','temp_copy','other')),
  status text not null default 'planned' check (status in ('planned','running','passed','failed','interrupted')),
  affected_files text[] not null default '{}',
  file_revisions jsonb,
  project_revision int,
  exit_code int,
  result_summary text,
  errors text,
  created_at timestamptz not null default now(),
  started_at timestamptz,
  heartbeat_at timestamptz,
  finished_at timestamptz
);
create index if not exists filebridge_test_runs_project_idx on public.filebridge_test_runs (project, created_at desc);

-- Nothing is reachable with anon/authenticated keys; only the Edge Function (service role) touches these tables.
do $$
declare t text;
begin
  foreach t in array array['filebridge_journal','filebridge_file_state','filebridge_file_seen','filebridge_owner_project','filebridge_project_state','filebridge_leases','filebridge_test_runs'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('revoke all on table public.%I from anon, authenticated', t);
    execute format('drop policy if exists filebridge_deny_all on public.%I', t);
    execute format('create policy filebridge_deny_all on public.%I as restrictive for all to anon, authenticated using (false) with check (false)', t);
  end loop;
end $$;

-- ===================== small helpers =====================

create or replace function public.filebridge_norm_path(p text)
returns text language sql immutable set search_path = public as $$
  select btrim(regexp_replace(replace(coalesce(p, ''), E'\\', '/'), '/+', '/', 'g'), '/')
$$;

-- true when one path is the other or lives inside it ('' means the whole workspace)
create or replace function public.filebridge_path_overlap(a text, b text)
returns boolean language sql immutable set search_path = public as $$
  select a = '' or b = '' or a = b or left(a, length(b) + 1) = b || '/' or left(b, length(a) + 1) = a || '/'
$$;

-- Which project does an operation belong to? explicit argument > project this AI resumed > first folder of the path > general.
create or replace function public.filebridge_pick_project(p_explicit text, p_owner text, p_paths text[])
returns table (r_project text, r_source text)
language plpgsql set search_path = public as $$
declare v text; first_path text;
begin
  v := left(btrim(coalesce(p_explicit, '')), 60);
  if v <> '' then r_project := v; r_source := 'explicit'; return next; return; end if;
  select o.project into v from public.filebridge_owner_project o
   where o.owner = p_owner and o.updated_at > now() - interval '12 hours';
  if v is not null then r_project := v; r_source := 'session'; return next; return; end if;
  if p_paths is not null and cardinality(p_paths) > 0 then
    first_path := public.filebridge_norm_path(p_paths[1]);
    if position('/' in first_path) > 0 and split_part(first_path, '/', 1) not in ('ZIP', 'APK', 'BuildWorkspace') then
      r_project := left(split_part(first_path, '/', 1), 60); r_source := 'path'; return next; return;
    end if;
  end if;
  r_project := 'general'; r_source := 'default'; return next; return;
end $$;

create or replace function public.filebridge_owner_set_project(p_owner text, p_project text)
returns void language sql set search_path = public as $$
  insert into public.filebridge_owner_project (owner, project, updated_at)
  select left(p_owner, 80), left(btrim(p_project), 60), now() where btrim(coalesce(p_project, '')) <> ''
  on conflict (owner) do update set project = excluded.project, updated_at = now();
$$;

create or replace function public.filebridge_journal_close(p_command_id uuid, p_state text, p_detail text default null)
returns void language sql set search_path = public as $$
  update public.filebridge_journal
     set state = p_state, finished_at = coalesce(finished_at, now()), detail = coalesce(p_detail, detail)
   where command_id = p_command_id and state in ('queued','delivered','running','awaiting_confirmation');
$$;

create or replace function public.filebridge_project_ensure(p_project text, p_owner text)
returns void language sql set search_path = public as $$
  insert into public.filebridge_project_state (project, revision, last_activity_at, last_owner)
  values (left(p_project, 60), 0, now(), p_owner)
  on conflict (project) do update set last_activity_at = now(), last_owner = excluded.last_owner, updated_at = now();
$$;

-- every file-changing operation moves the project revision forward
create or replace function public.filebridge_project_touch(p_project text, p_owner text)
returns int language sql set search_path = public as $$
  insert into public.filebridge_project_state (project, revision, last_activity_at, last_owner)
  values (left(p_project, 60), 1, now(), p_owner)
  on conflict (project) do update
     set revision = public.filebridge_project_state.revision + 1, last_activity_at = now(),
         last_owner = excluded.last_owner, updated_at = now()
  returning revision;
$$;

create or replace function public.filebridge_forget_seen(p_device text, p_path text)
returns void language sql set search_path = public as $$
  delete from public.filebridge_file_seen
   where device_id = p_device and p_path <> '' and (path = p_path or left(path, length(p_path) + 1) = p_path || '/');
$$;

create or replace function public.filebridge_mark_deleted(p_device text, p_path text, p_by text)
returns void language sql set search_path = public as $$
  update public.filebridge_file_state
     set deleted = true, rev = rev + 1, updated_by = p_by, updated_at = now()
   where device_id = p_device and p_path <> '' and not deleted
     and (path = p_path or left(path, length(p_path) + 1) = p_path || '/');
$$;

create or replace function public.filebridge_file_bump(p_device text, p_path text, p_project text, p_sha text, p_size bigint, p_by text)
returns void language sql set search_path = public as $$
  insert into public.filebridge_file_state (device_id, path, project, rev, sha256, size, deleted, updated_by)
  select p_device, p_path, left(p_project, 60), 1, p_sha, p_size, false, p_by where coalesce(p_path, '') <> ''
  on conflict (device_id, path) do update
     set rev = public.filebridge_file_state.rev + 1, sha256 = excluded.sha256, size = excluded.size, deleted = false,
         project = excluded.project, updated_by = excluded.updated_by, updated_at = now();
$$;

create or replace function public.filebridge_see(p_device text, p_owner text, p_path text, p_sha text)
returns void language sql set search_path = public as $$
  insert into public.filebridge_file_seen (device_id, owner, path, sha256)
  select p_device, p_owner, p_path, p_sha where coalesce(p_path, '') <> '' and coalesce(p_sha, '') <> ''
  on conflict (device_id, owner, path) do update set sha256 = excluded.sha256, seen_at = now();
$$;

-- ===================== progress mirrored into shared memory =====================
-- One pinned "Auto progress" entry per project, rebuilt from the journal after every change. If shared memory is
-- full or unavailable the journal itself still holds everything (resume_project reads the journal directly).
create or replace function public.filebridge_refresh_auto_memory(p_project text)
returns void language plpgsql set search_path = public as $$
declare
  ps public.filebridge_project_state;
  v_files text; v_open text; v_tests text; v_errs text; v_cp text; v_body text; v_id uuid; v_n int;
begin
  select * into ps from public.filebridge_project_state where project = p_project;
  if not found then return; end if;

  select coalesce(string_agg(format('- %s (rev %s%s) by %s at %s', f.path, f.rev,
           case when f.sha256 is not null then ', ' || left(f.sha256, 12) else '' end,
           f.updated_by, to_char(f.updated_at at time zone 'utc', 'YYYY-MM-DD HH24:MI')), E'\n' order by f.updated_at desc), '- none recorded yet')
    into v_files
    from (select * from public.filebridge_file_state where project = p_project and not deleted order by updated_at desc limit 25) f;

  select coalesce(string_agg(format('- %s %s [%s] by %s since %s', j.tool, array_to_string(j.paths, ', '), j.state, j.owner,
           to_char(j.created_at at time zone 'utc', 'YYYY-MM-DD HH24:MI')), E'\n' order by j.created_at desc), '- none')
    into v_open
    from (select * from public.filebridge_journal
           where project = p_project and state in ('queued','delivered','running','awaiting_confirmation','interrupted')
             and created_at > now() - interval '3 days' order by created_at desc limit 10) j;

  select coalesce(string_agg(format('- [%s] %s (%s): %s', t.status, t.name, t.environment, left(t.command, 120)), E'\n' order by t.created_at desc), '- none recorded')
    into v_tests
    from (select * from public.filebridge_test_runs where project = p_project order by created_at desc limit 8) t;

  select coalesce(string_agg(format('- %s %s: %s (%s)', j.tool, array_to_string(j.paths, ', '), coalesce(j.error_code, j.state),
           to_char(j.created_at at time zone 'utc', 'YYYY-MM-DD HH24:MI')), E'\n' order by j.created_at desc), '- none')
    into v_errs
    from (select * from public.filebridge_journal
           where project = p_project and state in ('failed','rejected') and created_at > now() - interval '3 days'
           order by created_at desc limit 6) j;

  v_cp := '';
  if ps.checkpoint_at is not null then
    v_cp := format(E'\n## Checkpoint (%s, %s UTC)\n%s\n', ps.checkpoint_by, to_char(ps.checkpoint_at at time zone 'utc', 'YYYY-MM-DD HH24:MI'), coalesce(ps.summary, ''));
    if cardinality(ps.completed) > 0 then v_cp := v_cp || E'\nCompleted:\n' || (select string_agg('- ' || x, E'\n') from unnest(ps.completed) x) || E'\n'; end if;
    if cardinality(ps.pending) > 0 then v_cp := v_cp || E'\nPending:\n' || (select string_agg('- ' || x, E'\n') from unnest(ps.pending) x) || E'\n'; end if;
    if cardinality(ps.next_steps) > 0 then v_cp := v_cp || E'\nNext steps:\n' || (select string_agg('- ' || x, E'\n') from unnest(ps.next_steps) x) || E'\n'; end if;
  end if;

  v_body := left(format(E'Saved automatically by FileBridge after every file operation (not written by an AI). Project revision %s; last activity %s UTC by %s.\n%s\n## Recently modified files\n%s\n\n## Unfinished or interrupted operations\n%s\n\n## Tests\n%s\n\n## Recent errors\n%s\n',
           ps.revision, to_char(ps.last_activity_at at time zone 'utc', 'YYYY-MM-DD HH24:MI'), coalesce(ps.last_owner, '?'), v_cp, v_files, v_open, v_tests, v_errs), 19000);

  select id into v_id from public.filebridge_memory
   where project = p_project and author = 'filebridge-auto' and not archived order by created_at limit 1;
  if v_id is not null then
    update public.filebridge_memory set content = v_body, version = version + 1, updated_by = 'filebridge-auto', updated_at = now() where id = v_id;
  else
    select count(*) into v_n from public.filebridge_memory;
    if v_n < 2000 then
      insert into public.filebridge_memory (project, kind, title, content, tags, pinned, status, author, updated_by)
      values (left(p_project, 60), 'fact', left('Auto progress: ' || p_project, 160), v_body, array['auto','progress'], true, 'open', 'filebridge-auto', 'filebridge-auto');
    end if;
  end if;
end $$;

-- ===================== what a finished operation changes =====================
-- Called for every succeeded operation (from filebridge_finish or from a late sync by the phone).
create or replace function public.filebridge_apply_effects(j public.filebridge_journal, p_result jsonb)
returns void language plpgsql set search_path = public as $$
declare
  v_sha text;
  v_size bigint;
  v_unchanged boolean;
  v_p1 text := public.filebridge_norm_path(j.paths[1]);
  v_p2 text := public.filebridge_norm_path(j.paths[2]);
  v_changed boolean := false;
  f jsonb;
begin
  v_sha := nullif(p_result->>'revision', '');
  begin v_size := nullif(p_result->>'size', '')::bigint; exception when others then v_size := null; end;
  v_unchanged := coalesce(p_result->>'unchanged', '') = 'true';

  if j.tool in ('read_file', 'get_file_info') then
    perform public.filebridge_see(j.device_id, j.owner, v_p1, v_sha);
  elsif j.tool = 'verify_files' then
    for f in select value from jsonb_array_elements(coalesce(p_result->'files', '[]'::jsonb)) loop
      perform public.filebridge_see(j.device_id, j.owner, public.filebridge_norm_path(f->>'path'), f->>'revision');
    end loop;
  elsif j.tool in ('write_file', 'edit_file') then
    if v_p1 <> '' then
      if not v_unchanged then
        perform public.filebridge_file_bump(j.device_id, v_p1, j.project, v_sha, v_size, j.owner);
        v_changed := true;
      end if;
      perform public.filebridge_see(j.device_id, j.owner, v_p1, v_sha);
    end if;
  elsif j.tool = 'copy_file' then
    perform public.filebridge_file_bump(j.device_id, v_p2, j.project, null, v_size, j.owner);
    perform public.filebridge_forget_seen(j.device_id, v_p2);
    v_changed := true;
  elsif j.tool = 'move_file' then
    perform public.filebridge_mark_deleted(j.device_id, v_p1, j.owner);
    perform public.filebridge_forget_seen(j.device_id, v_p1);
    perform public.filebridge_file_bump(j.device_id, v_p2, j.project, null, v_size, j.owner);
    perform public.filebridge_forget_seen(j.device_id, v_p2);
    v_changed := true;
  elsif j.tool = 'delete_file' then
    perform public.filebridge_mark_deleted(j.device_id, v_p1, j.owner);
    perform public.filebridge_forget_seen(j.device_id, v_p1);
    v_changed := true;
  elsif j.tool in ('create_zip', 'prepare_project_zip') then
    perform public.filebridge_file_bump(j.device_id, v_p2, j.project, null, v_size, j.owner);
    perform public.filebridge_forget_seen(j.device_id, v_p2);
    v_changed := true;
  elsif j.tool = 'extract_zip' then
    if v_p2 = '' then
      delete from public.filebridge_file_seen where device_id = j.device_id;
      update public.filebridge_file_state set sha256 = null, rev = rev + 1, updated_by = j.owner, updated_at = now()
       where device_id = j.device_id and not deleted;
    else
      perform public.filebridge_forget_seen(j.device_id, v_p2);
      update public.filebridge_file_state set sha256 = null, rev = rev + 1, updated_by = j.owner, updated_at = now()
       where device_id = j.device_id and not deleted and (path = v_p2 or left(path, length(v_p2) + 1) = v_p2 || '/');
    end if;
    v_changed := true;
  end if;

  if v_changed then
    perform public.filebridge_project_touch(j.project, j.owner);
    perform public.filebridge_refresh_auto_memory(j.project);
  end if;
end $$;

create or replace function public.filebridge_journal_apply(p_id uuid, p_state text, p_result jsonb, p_error_code text, p_bytes bigint, p_ms int)
returns void language plpgsql set search_path = public as $$
declare
  j public.filebridge_journal;
  v_rev jsonb; v_sha text; v_size bigint; v_detail text;
begin
  select * into j from public.filebridge_journal where command_id = p_id for update;
  if not found then return; end if;
  v_sha := nullif(p_result->>'revision', '');
  begin v_size := nullif(p_result->>'size', '')::bigint; exception when others then v_size := null; end;
  if v_sha is not null and j.tool in ('write_file', 'edit_file') and j.paths[1] is not null then
    v_rev := jsonb_build_object(public.filebridge_norm_path(j.paths[1]), jsonb_build_object('sha256', v_sha, 'size', v_size));
  end if;
  if p_state = 'succeeded' and coalesce(p_result->>'unchanged', '') = 'true' then
    v_detail := 'content was already identical; nothing was written';
  end if;
  update public.filebridge_journal
     set state = p_state, error_code = left(p_error_code, 64), bytes = p_bytes, duration_ms = p_ms,
         revision = coalesce(v_rev, revision), finished_at = now(), detail = coalesce(v_detail, detail)
   where id = j.id;
  if p_state = 'succeeded' then
    perform public.filebridge_apply_effects(j, p_result);
  end if;
end $$;

-- ===================== recovery =====================

create or replace function public.filebridge_recover_tests()
returns void language sql set search_path = public as $$
  update public.filebridge_test_runs
     set status = 'interrupted', finished_at = now(),
         errors = left(coalesce(nullif(errors, '') || E'\n', '') || 'No heartbeat for 45 minutes: the session that started this test stopped before reporting a result. The test did not finish; do not treat it as passed.', 4000)
   where status = 'running' and coalesce(heartbeat_at, started_at, created_at) < now() - interval '45 minutes';
$$;

create or replace function public.filebridge_recover()
returns void language plpgsql set search_path = public as $$
begin
  perform public.filebridge_recover_tests();
  update public.filebridge_journal j
     set state = 'interrupted', finished_at = now(),
         detail = 'the command is no longer active on the server and no result was recorded; it may have run partly or fully'
   where j.state in ('queued','delivered','running','awaiting_confirmation') and j.command_id is not null
     and j.created_at < now() - interval '3 minutes'
     and not exists (select 1 from public.filebridge_commands c
                      where c.id = j.command_id and c.status in ('queued','delivered','running','awaiting_confirmation'));
  delete from public.filebridge_journal where created_at < now() - interval '30 days';
  delete from public.filebridge_file_seen where seen_at < now() - interval '14 days';
  delete from public.filebridge_test_runs where created_at < now() - interval '30 days';
  delete from public.filebridge_leases where coalesce(released_at, expires_at) < now() - interval '7 days';
  delete from public.filebridge_owner_project where updated_at < now() - interval '30 days';
end $$;

-- The phone keeps its own journal and sends what the server missed (result lost, app killed mid-operation).
create or replace function public.filebridge_journal_sync(p_device_id text, p_entries jsonb)
returns jsonb language plpgsql set search_path = public as $$
declare
  e jsonb; j public.filebridge_journal; v_id uuid; v_state text; v_paths text[]; v_proj text; v_src text;
  v_res jsonb; v_upd int := 0; v_new int := 0;
begin
  if p_entries is null or jsonb_typeof(p_entries) <> 'array' then
    return jsonb_build_object('ok', false, 'error', 'bad_request');
  end if;
  for e in select value from jsonb_array_elements(p_entries) limit 50 loop
    begin
      v_id := nullif(e->>'command_id', '')::uuid;
      v_state := case when e->>'state' in ('succeeded', 'failed') then e->>'state' else 'interrupted' end;
      v_res := jsonb_build_object('revision', e->>'revision', 'size', e->>'size', 'unchanged', e->>'unchanged');
      select * into j from public.filebridge_journal where command_id = v_id and device_id = p_device_id for update;
      if found then
        if j.state in ('queued','delivered','running','awaiting_confirmation','interrupted','expired') and j.state <> v_state then
          update public.filebridge_journal
             set state = v_state, error_code = left(e->>'error_code', 64), detail = 'reported later by the phone', source = 'device_sync',
                 finished_at = coalesce(finished_at, now()),
                 revision = case when nullif(e->>'revision', '') is not null and cardinality(j.paths) > 0 and j.tool in ('write_file', 'edit_file')
                                 then jsonb_build_object(public.filebridge_norm_path(j.paths[1]), jsonb_build_object('sha256', e->>'revision', 'size', e->>'size'))
                                 else revision end
           where id = j.id;
          if v_state = 'succeeded' then perform public.filebridge_apply_effects(j, v_res); end if;
          v_upd := v_upd + 1;
        end if;
      else
        v_paths := array(select public.filebridge_norm_path(x) from jsonb_array_elements_text(coalesce(e->'paths', '[]'::jsonb)) x);
        select pp.r_project, pp.r_source into v_proj, v_src from public.filebridge_pick_project(null, 'phone', v_paths) pp;
        insert into public.filebridge_journal (command_id, device_id, project, project_source, owner, tool, paths, state, error_code, detail, source, finished_at)
        values (v_id, p_device_id, v_proj, v_src, 'phone', left(coalesce(e->>'tool', 'unknown'), 40), v_paths, v_state,
                left(e->>'error_code', 64), 'reported by the phone journal; the server had no record of it', 'device_sync', now())
        on conflict (command_id) do nothing;
        if v_id is not null then
          select * into j from public.filebridge_journal where command_id = v_id and device_id = p_device_id;
          if found and v_state = 'succeeded' then perform public.filebridge_apply_effects(j, v_res); end if;
        end if;
        v_new := v_new + 1;
      end if;
    exception when others then
      raise warning 'filebridge journal sync entry skipped: %', sqlerrm;
    end;
  end loop;
  return jsonb_build_object('ok', true, 'updated', v_upd, 'added', v_new);
end $$;

-- ===================== leases (several AIs, interrupted sessions recover by expiry) =====================

create or replace function public.filebridge_lease_conflicts(p_owner text, p_device text, p_paths text[])
returns jsonb language sql stable set search_path = public as $$
  select coalesce(jsonb_agg(jsonb_build_object('lease_id', l.id, 'owner', l.owner, 'paths', to_jsonb(l.paths), 'purpose', l.purpose, 'expires_at', l.expires_at) order by l.expires_at), '[]'::jsonb)
    from public.filebridge_leases l
   where l.released_at is null and l.expires_at > now() and l.owner <> p_owner
     and (l.device_id is null or p_device is null or l.device_id = p_device)
     and exists (select 1 from unnest(l.paths) lp, unnest(coalesce(p_paths, '{}'::text[])) rp
                  where public.filebridge_path_overlap(lp, public.filebridge_norm_path(rp)))
$$;

create or replace function public.filebridge_lease_acquire(p_owner text, p_project text, p_device text, p_paths text[], p_ttl int, p_purpose text)
returns jsonb language plpgsql set search_path = public as $$
declare
  v_paths text[]; v_conf jsonb; v_id uuid; v_exp timestamptz; v_n int; v_proj text;
begin
  perform pg_advisory_xact_lock(hashtextextended('filebridge_leases', 0));
  v_proj := left(btrim(coalesce(p_project, '')), 60);
  if v_proj = '' then v_proj := 'general'; end if;
  v_paths := array(select distinct public.filebridge_norm_path(x) from unnest(coalesce(p_paths, '{}'::text[])) x);
  if cardinality(v_paths) = 0 then
    return jsonb_build_object('ok', false, 'error', 'invalid_argument', 'message', 'paths is required (files or folders to lock).');
  end if;
  v_conf := public.filebridge_lease_conflicts(p_owner, p_device, v_paths);
  if jsonb_array_length(v_conf) > 0 then
    return jsonb_build_object('ok', false, 'error', 'locked_by_other',
      'message', 'Another AI holds a lease on part of these paths. Wait until it expires, work on other files, or ask it to release it.', 'conflicts', v_conf);
  end if;
  v_exp := now() + make_interval(secs => greatest(30, least(coalesce(p_ttl, 600), 3600)));
  -- the same owner asking again for the same paths extends its lease instead of stacking another one
  update public.filebridge_leases set expires_at = v_exp, renewed_at = now(), project = v_proj, purpose = coalesce(left(p_purpose, 200), purpose)
   where owner = p_owner and released_at is null and expires_at > now() and paths @> v_paths and v_paths @> paths
  returning id into v_id;
  if v_id is not null then
    return jsonb_build_object('ok', true, 'lease_id', v_id, 'expires_at', v_exp, 'paths', to_jsonb(v_paths), 'extended', true);
  end if;
  select count(*) into v_n from public.filebridge_leases where owner = p_owner and released_at is null and expires_at > now();
  if v_n >= 10 then
    return jsonb_build_object('ok', false, 'error', 'too_many_leases', 'message', 'You already hold 10 leases. Release some first.');
  end if;
  insert into public.filebridge_leases (project, device_id, owner, paths, purpose, expires_at)
  values (v_proj, nullif(p_device, ''), p_owner, v_paths, left(p_purpose, 200), v_exp) returning id into v_id;
  return jsonb_build_object('ok', true, 'lease_id', v_id, 'expires_at', v_exp, 'paths', to_jsonb(v_paths));
end $$;

create or replace function public.filebridge_lease_renew(p_id uuid, p_owner text, p_ttl int)
returns jsonb language plpgsql set search_path = public as $$
declare v_exp timestamptz; v_n int;
begin
  v_exp := now() + make_interval(secs => greatest(30, least(coalesce(p_ttl, 600), 3600)));
  update public.filebridge_leases set expires_at = v_exp, renewed_at = now()
   where id = p_id and owner = p_owner and released_at is null and expires_at > now();
  get diagnostics v_n = row_count;
  if v_n = 0 then
    return jsonb_build_object('ok', false, 'error', 'lease_not_found', 'message', 'No active lease with that id for you (it expired or was released). Acquire a new one.');
  end if;
  return jsonb_build_object('ok', true, 'lease_id', p_id, 'expires_at', v_exp);
end $$;

create or replace function public.filebridge_lease_release(p_id uuid, p_owner text)
returns jsonb language plpgsql set search_path = public as $$
declare v_n int;
begin
  update public.filebridge_leases set released_at = now(), released_reason = 'released'
   where owner = p_owner and released_at is null and (p_id is null or id = p_id);
  get diagnostics v_n = row_count;
  return jsonb_build_object('ok', true, 'released', v_n);
end $$;

create or replace function public.filebridge_lease_list(p_project text)
returns jsonb language sql stable set search_path = public as $$
  select coalesce(jsonb_agg(jsonb_build_object('lease_id', l.id, 'owner', l.owner, 'project', l.project, 'paths', to_jsonb(l.paths), 'purpose', l.purpose, 'expires_at', l.expires_at, 'renewed_at', l.renewed_at) order by l.expires_at), '[]'::jsonb)
    from public.filebridge_leases l
   where l.released_at is null and l.expires_at > now() and (coalesce(p_project, '') = '' or l.project = p_project)
$$;

-- ===================== checkpoints and test runs =====================

create or replace function public.filebridge_checkpoint(p_project text, p_owner text, p_summary text, p_completed text[], p_pending text[], p_next text[])
returns jsonb language plpgsql set search_path = public as $$
declare v_proj text;
begin
  v_proj := left(btrim(coalesce(p_project, '')), 60);
  if v_proj = '' then v_proj := 'general'; end if;
  insert into public.filebridge_project_state (project, revision, last_activity_at, last_owner, summary, completed, pending, next_steps, checkpoint_at, checkpoint_by)
  values (v_proj, 0, now(), p_owner, left(p_summary, 4000), coalesce(p_completed, '{}'::text[]), coalesce(p_pending, '{}'::text[]), coalesce(p_next, '{}'::text[]), now(), p_owner)
  on conflict (project) do update
     set summary = excluded.summary, completed = excluded.completed, pending = excluded.pending, next_steps = excluded.next_steps,
         checkpoint_at = now(), checkpoint_by = excluded.checkpoint_by, last_activity_at = now(), last_owner = excluded.last_owner, updated_at = now();
  perform public.filebridge_owner_set_project(p_owner, v_proj);
  insert into public.filebridge_journal (project, project_source, owner, tool, note, state, finished_at, source)
  values (v_proj, 'explicit', p_owner, 'project_checkpoint', left(p_summary, 200), 'recorded', now(), 'server');
  perform public.filebridge_refresh_auto_memory(v_proj);
  return jsonb_build_object('ok', true, 'project', v_proj, 'project_revision', (select revision from public.filebridge_project_state where project = v_proj));
end $$;

create or replace function public.filebridge_test_json(p_id uuid)
returns jsonb language sql stable set search_path = public as $$
  select jsonb_build_object(
    'id', t.id, 'project', t.project, 'owner', t.owner, 'name', t.name, 'command', t.command, 'environment', t.environment,
    'status', t.status, 'affected_files', to_jsonb(t.affected_files), 'exit_code', t.exit_code,
    'result_summary', t.result_summary, 'errors', t.errors,
    'created_at', t.created_at, 'started_at', t.started_at, 'finished_at', t.finished_at,
    'stale_files', coalesce((select jsonb_agg(k) from jsonb_object_keys(coalesce(t.file_revisions, '{}'::jsonb)) k
                              where coalesce((select max(f.rev) from public.filebridge_file_state f where f.path = k), 0) > coalesce((t.file_revisions->>k)::int, 0)), '[]'::jsonb))
    from public.filebridge_test_runs t where t.id = p_id
$$;

create or replace function public.filebridge_tests_json(p_project text, p_limit int)
returns jsonb language sql stable set search_path = public as $$
  select coalesce(jsonb_agg(public.filebridge_test_json(t.id) order by t.created_at desc), '[]'::jsonb)
    from (select id, created_at from public.filebridge_test_runs
           where coalesce(p_project, '') = '' or project = p_project
           order by created_at desc limit greatest(1, least(coalesce(p_limit, 15), 50))) t
$$;

-- planned -> running -> passed | failed, or interrupted. A test can never jump from planned to passed, a passed test needs
-- exit code 0, and a test whose session vanished is marked interrupted automatically.
create or replace function public.filebridge_test_run(
  p_action text, p_owner text, p_project text, p_id uuid, p_name text, p_command text, p_environment text,
  p_files text[], p_result text, p_exit_code int, p_summary text, p_errors text)
returns jsonb language plpgsql set search_path = public as $$
declare
  t public.filebridge_test_runs; v_proj text; v_files text[]; v_revs jsonb;
begin
  perform public.filebridge_recover_tests();
  v_proj := left(btrim(coalesce(p_project, '')), 60);
  if v_proj = '' then
    select pp.r_project into v_proj from public.filebridge_pick_project(null, p_owner, '{}'::text[]) pp;
  end if;
  v_files := array(select distinct public.filebridge_norm_path(x) from unnest(coalesce(p_files, '{}'::text[])) x where public.filebridge_norm_path(x) <> '');

  if p_action = 'list' then
    return jsonb_build_object('ok', true, 'project', v_proj, 'tests', public.filebridge_tests_json(v_proj, 20));
  end if;

  if p_action in ('plan', 'start') and p_id is null then
    if coalesce(btrim(p_name), '') = '' or coalesce(btrim(p_command), '') = '' or coalesce(p_environment, '') = '' then
      return jsonb_build_object('ok', false, 'error', 'invalid_argument', 'message', 'name, command and environment (original | temp_copy | other) are required.');
    end if;
    if p_environment not in ('original', 'temp_copy', 'other') then
      return jsonb_build_object('ok', false, 'error', 'invalid_argument', 'message', 'environment must be original, temp_copy or other.');
    end if;
  end if;

  if p_action = 'plan' then
    perform public.filebridge_project_ensure(v_proj, p_owner);
    insert into public.filebridge_test_runs (project, owner, name, command, environment, status, affected_files)
    values (v_proj, p_owner, left(btrim(p_name), 120), left(btrim(p_command), 500), p_environment, 'planned', v_files) returning * into t;

  elsif p_action = 'start' then
    perform public.filebridge_project_ensure(v_proj, p_owner);
    if p_id is not null then
      select * into t from public.filebridge_test_runs where id = p_id for update;
      if not found then return jsonb_build_object('ok', false, 'error', 'not_found', 'message', 'No such test run.'); end if;
      if t.status <> 'planned' then
        return jsonb_build_object('ok', false, 'error', 'invalid_transition', 'message', format('Only a planned test can be started; this one is %s. Plan or start a new run.', t.status));
      end if;
      if cardinality(v_files) = 0 then v_files := t.affected_files; end if;
    end if;
    -- every affected file gets an entry (0 = FileBridge had never seen it change), so later changes show up as stale results
    select coalesce(jsonb_object_agg(fp, coalesce((select max(s.rev) from public.filebridge_file_state s where s.path = fp), 0)), '{}'::jsonb) into v_revs
      from unnest(v_files) fp;
    if p_id is not null then
      update public.filebridge_test_runs
         set status = 'running', started_at = now(), heartbeat_at = now(), file_revisions = v_revs, affected_files = v_files,
             project_revision = (select revision from public.filebridge_project_state where project = t.project)
       where id = p_id returning * into t;
    else
      insert into public.filebridge_test_runs (project, owner, name, command, environment, status, affected_files, file_revisions, project_revision, started_at, heartbeat_at)
      values (v_proj, p_owner, left(btrim(p_name), 120), left(btrim(p_command), 500), p_environment, 'running', v_files, v_revs,
              (select revision from public.filebridge_project_state where project = v_proj), now(), now()) returning * into t;
    end if;

  elsif p_action = 'heartbeat' then
    update public.filebridge_test_runs set heartbeat_at = now() where id = p_id and owner = p_owner and status = 'running' returning * into t;
    if not found then
      return jsonb_build_object('ok', false, 'error', 'not_running', 'message', 'No running test with that id for you (it may have finished or been marked interrupted).');
    end if;

  elsif p_action = 'finish' then
    if p_id is null then return jsonb_build_object('ok', false, 'error', 'invalid_argument', 'message', 'id of the test run is required.'); end if;
    select * into t from public.filebridge_test_runs where id = p_id for update;
    if not found then return jsonb_build_object('ok', false, 'error', 'not_found', 'message', 'No such test run.'); end if;
    if t.status <> 'running' then
      return jsonb_build_object('ok', false, 'error', 'not_running', 'message', format('Only a running test can be finished (this one is %s). A test that was never started cannot be reported as passed.', t.status));
    end if;
    if p_result not in ('passed', 'failed') then
      return jsonb_build_object('ok', false, 'error', 'invalid_argument', 'message', 'result must be passed or failed.');
    end if;
    if p_exit_code is null then
      return jsonb_build_object('ok', false, 'error', 'invalid_argument', 'message', 'exit_code is required: pass the real exit code of the command.');
    end if;
    if p_result = 'passed' and p_exit_code <> 0 then
      return jsonb_build_object('ok', false, 'error', 'invalid_argument', 'message', 'A test with a non-zero exit code cannot be reported as passed.');
    end if;
    if p_result = 'failed' and p_exit_code = 0 and coalesce(btrim(p_errors), '') = '' then
      return jsonb_build_object('ok', false, 'error', 'invalid_argument', 'message', 'A failed test needs errors text when the exit code is 0.');
    end if;
    update public.filebridge_test_runs
       set status = p_result, exit_code = p_exit_code, result_summary = left(p_summary, 2000), errors = left(p_errors, 4000),
           finished_at = now(), heartbeat_at = now()
     where id = p_id returning * into t;

  elsif p_action = 'interrupt' then
    update public.filebridge_test_runs
       set status = 'interrupted', finished_at = now(), errors = left(coalesce(nullif(p_errors, ''), 'Marked interrupted by ' || p_owner || '.'), 4000)
     where id = p_id and status = 'running' returning * into t;
    if not found then
      return jsonb_build_object('ok', false, 'error', 'not_running', 'message', 'No running test with that id.');
    end if;

  else
    return jsonb_build_object('ok', false, 'error', 'invalid_argument', 'message', 'action must be plan, start, heartbeat, finish, interrupt or list.');
  end if;

  perform public.filebridge_refresh_auto_memory(t.project);
  return jsonb_build_object('ok', true, 'test', public.filebridge_test_json(t.id));
end $$;

-- ===================== resume =====================

create or replace function public.filebridge_resume_state(p_project text, p_owner text)
returns jsonb language plpgsql set search_path = public as $$
declare
  ps public.filebridge_project_state;
  mutating text[] := array['write_file','edit_file','copy_file','move_file','delete_file','create_folder','create_zip','prepare_project_zip','extract_zip'];
begin
  perform public.filebridge_recover();
  perform public.filebridge_owner_set_project(p_owner, p_project);
  select * into ps from public.filebridge_project_state where project = p_project;
  return jsonb_build_object(
    'project', p_project,
    'project_revision', coalesce(ps.revision, 0),
    'last_activity_at', ps.last_activity_at,
    'last_owner', ps.last_owner,
    'checkpoint', case when ps.checkpoint_at is null then null else jsonb_build_object(
        'at', ps.checkpoint_at, 'by', ps.checkpoint_by, 'summary', ps.summary,
        'completed', to_jsonb(ps.completed), 'pending', to_jsonb(ps.pending), 'next_steps', to_jsonb(ps.next_steps)) end,
    'modified_files', coalesce((
        select jsonb_agg(jsonb_build_object('path', f.path, 'device_id', f.device_id, 'rev', f.rev, 'sha256', f.sha256, 'size', f.size, 'by', f.updated_by, 'at', f.updated_at) order by f.updated_at desc)
          from (select * from public.filebridge_file_state where project = p_project and not deleted order by updated_at desc limit 40) f), '[]'::jsonb),
    'deleted_files', coalesce((
        select jsonb_agg(f.path) from (select path from public.filebridge_file_state where project = p_project and deleted order by updated_at desc limit 10) f), '[]'::jsonb),
    'unfinished_operations', coalesce((
        select jsonb_agg(jsonb_build_object(
                 'operation_id', j.command_id, 'tool', j.tool, 'paths', to_jsonb(j.paths), 'state', j.state, 'owner', j.owner, 'since', j.created_at, 'detail', j.detail,
                 'kind', case when j.state = 'expired' then 'not_executed' when j.state = 'interrupted' then 'interrupted' else 'in_flight' end) order by j.created_at desc)
          from (select * from public.filebridge_journal j0
                 where j0.project = p_project and j0.created_at > now() - interval '3 days' and j0.tool = any (mutating)
                   and (j0.state in ('queued','delivered','running','awaiting_confirmation','interrupted')
                        or (j0.state = 'expired' and j0.created_at > now() - interval '1 day'))
                   and not exists (select 1 from public.filebridge_journal j2
                                    where j2.state = 'succeeded' and j2.project = j0.project and j2.created_at > j0.created_at
                                      and j2.tool = any (mutating) and j2.paths && j0.paths)
                 order by j0.created_at desc limit 20) j), '[]'::jsonb),
    'recent_errors', coalesce((
        select jsonb_agg(jsonb_build_object('tool', j.tool, 'paths', to_jsonb(j.paths), 'error_code', j.error_code, 'detail', j.detail, 'owner', j.owner, 'at', j.created_at) order by j.created_at desc)
          from (select * from public.filebridge_journal
                 where project = p_project and state in ('failed','rejected') and created_at > now() - interval '3 days'
                 order by created_at desc limit 10) j), '[]'::jsonb),
    'tests', jsonb_build_object(
        'counts', coalesce((select jsonb_object_agg(x.status, x.n) from (select status, count(*) n from public.filebridge_test_runs where project = p_project group by status) x), '{}'::jsonb),
        'latest', public.filebridge_tests_json(p_project, 10)),
    'leases', public.filebridge_lease_list(p_project),
    'expired_leases', coalesce((
        select jsonb_agg(jsonb_build_object('lease_id', l.id, 'owner', l.owner, 'paths', to_jsonb(l.paths), 'expired_at', l.expires_at, 'purpose', l.purpose) order by l.expires_at desc)
          from public.filebridge_leases l
         where l.project = p_project and l.released_at is null and l.expires_at <= now() and l.expires_at > now() - interval '24 hours'), '[]'::jsonb)
  );
end $$;

-- ===================== grants: service role only =====================

do $$
declare f text;
begin
  foreach f in array array[
    'filebridge_norm_path(text)', 'filebridge_path_overlap(text,text)', 'filebridge_pick_project(text,text,text[])',
    'filebridge_owner_set_project(text,text)', 'filebridge_journal_close(uuid,text,text)', 'filebridge_project_ensure(text,text)',
    'filebridge_project_touch(text,text)', 'filebridge_forget_seen(text,text)', 'filebridge_mark_deleted(text,text,text)',
    'filebridge_file_bump(text,text,text,text,bigint,text)', 'filebridge_see(text,text,text,text)',
    'filebridge_refresh_auto_memory(text)', 'filebridge_apply_effects(public.filebridge_journal,jsonb)',
    'filebridge_journal_apply(uuid,text,jsonb,text,bigint,int)',
    'filebridge_recover_tests()', 'filebridge_recover()', 'filebridge_journal_sync(text,jsonb)',
    'filebridge_lease_conflicts(text,text,text[])', 'filebridge_lease_acquire(text,text,text,text[],int,text)',
    'filebridge_lease_renew(uuid,text,int)', 'filebridge_lease_release(uuid,text)', 'filebridge_lease_list(text)',
    'filebridge_checkpoint(text,text,text,text[],text[],text[])', 'filebridge_test_json(uuid)',
    'filebridge_tests_json(text,int)', 'filebridge_test_run(text,text,text,uuid,text,text,text,text[],text,int,text,text)',
    'filebridge_resume_state(text,text)'
  ] loop
    execute format('revoke all on function public.%s from public, anon, authenticated', f);
    execute format('grant execute on function public.%s to service_role', f);
  end loop;
end $$;
