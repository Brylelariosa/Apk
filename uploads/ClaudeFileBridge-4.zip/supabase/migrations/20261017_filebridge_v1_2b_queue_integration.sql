-- Claude FileBridge 1.2.0 backend, part B of 2: command queue integration.
--
-- filebridge_enqueue / filebridge_claim / filebridge_finish / filebridge_hello / filebridge_expire_command /
-- filebridge_request_cancel are replaced by backward-compatible versions (same parameters, new ones optional),
-- so the 1.1.0 app and the 1.1.0 Edge Function keep working while this is rolled out. Requires part A.
-- Applied as migration "filebridge_v1_2b_queue_integration".

drop function if exists public.filebridge_enqueue(text, text, jsonb, boolean, int, text, text);
create or replace function public.filebridge_enqueue(
  p_device_id text, p_tool text, p_args jsonb, p_destructive boolean, p_ttl int, p_nonce text,
  p_client text default null, p_owner text default null, p_project text default null,
  p_paths text[] default '{}', p_note text default null)
returns public.filebridge_commands
language plpgsql set search_path = public as $$
declare
  n int; nc int; r public.filebridge_commands;
  v_ids uuid[]; v_owner text; v_proj text; v_src text; v_paths text[];
begin
  with q as (
    update public.filebridge_commands set status = 'expired', completed_at = now(), args = '{}'::jsonb
     where device_id = p_device_id and status = 'queued' and expires_at <= now()
    returning id)
  select array_agg(id) into v_ids from q;
  update public.filebridge_journal set state = 'expired', finished_at = now(), detail = 'expired before the phone picked it up; nothing was changed'
   where command_id = any (v_ids) and state = 'queued';

  with d as (
    update public.filebridge_commands set status = 'expired', completed_at = now(), args = '{}'::jsonb
     where device_id = p_device_id and status in ('delivered','running','awaiting_confirmation') and delivered_at < now() - interval '2 hours'
    returning id)
  select array_agg(id) into v_ids from d;
  update public.filebridge_journal set state = 'interrupted', finished_at = now(), detail = 'no result after 2 hours; the phone may have run it partly or fully'
   where command_id = any (v_ids) and state in ('queued','delivered','running','awaiting_confirmation');

  select count(*) into n from public.filebridge_commands
   where device_id = p_device_id and status in ('queued','delivered','running','awaiting_confirmation');
  if n >= 10 then raise exception 'queue_full'; end if;
  if p_client is not null then
    select count(*) into nc from public.filebridge_commands
     where device_id = p_device_id and client_name = p_client and status in ('queued','delivered','running','awaiting_confirmation');
    if nc >= 5 then raise exception 'client_queue_full'; end if;
  end if;

  insert into public.filebridge_commands (device_id, tool, args, destructive, nonce, expires_at, client_name)
  values (p_device_id, p_tool, coalesce(p_args, '{}'::jsonb), coalesce(p_destructive, false), p_nonce,
          now() + make_interval(secs => greatest(10, least(coalesce(p_ttl, 90), 600))), left(p_client, 40))
  returning * into r;

  v_owner := left(coalesce(nullif(p_owner, ''), p_client, 'unknown'), 80);
  v_paths := array(select public.filebridge_norm_path(x) from unnest(coalesce(p_paths, '{}'::text[])) x);
  select pp.r_project, pp.r_source into v_proj, v_src from public.filebridge_pick_project(p_project, v_owner, v_paths) pp;
  insert into public.filebridge_journal (command_id, device_id, project, project_source, owner, tool, paths, note, state)
  values (r.id, p_device_id, v_proj, v_src, v_owner, p_tool, v_paths, left(p_note, 200), 'queued');
  return r;
end $$;

create or replace function public.filebridge_claim(p_device_id text, p_limit int default 1)
returns setof public.filebridge_commands
language plpgsql set search_path = public as $$
begin
  return query
  with c as (
    select id from public.filebridge_commands
     where device_id = p_device_id and status = 'queued' and expires_at > now()
     order by created_at
     for update skip locked
     limit greatest(1, least(coalesce(p_limit, 1), 3))
  ), u as (
    update public.filebridge_commands f
       set status = 'delivered', delivered_at = now()
      from c
     where f.id = c.id
    returning f.*
  ), j as (
    update public.filebridge_journal jj set state = 'delivered'
      from u
     where jj.command_id = u.id and jj.state = 'queued'
    returning 1
  )
  select * from u;
end $$;

create or replace function public.filebridge_expire_command(p_id uuid)
returns void language sql set search_path = public as $$
  update public.filebridge_commands
     set status = 'expired', completed_at = now(), args = '{}'::jsonb
   where id = p_id and status = 'queued';
  update public.filebridge_journal
     set state = 'expired', finished_at = now(), detail = 'the phone did not pick the command up in time; nothing was changed'
   where command_id = p_id and state = 'queued';
$$;

create or replace function public.filebridge_request_cancel(p_id uuid)
returns text language plpgsql set search_path = public as $$
declare s text;
begin
  select status into s from public.filebridge_commands where id = p_id for update;
  if s is null then return 'not_found'; end if;
  if s = 'queued' then
    update public.filebridge_commands set status = 'cancelled', completed_at = now(), args = '{}'::jsonb where id = p_id;
    perform public.filebridge_journal_close(p_id, 'cancelled', 'cancelled before the phone ran it; nothing was changed');
    return 'cancelled';
  elsif s in ('delivered','running','awaiting_confirmation') then
    update public.filebridge_commands set cancel_requested = true where id = p_id;
    return 'cancel_requested';
  end if;
  return s;
end $$;

-- The result is always stored first; the bookkeeping (journal, revisions, project state, memory) can never block it.
create or replace function public.filebridge_finish(p_id uuid, p_device_id text, p_ok boolean, p_status text, p_result jsonb, p_error text, p_error_code text, p_bytes bigint, p_duration_ms int)
returns boolean
language plpgsql set search_path = public as $$
declare
  v_tool text;
  v_status text;
begin
  v_status := case when p_status in ('rejected','cancelled') then p_status when p_ok then 'succeeded' else 'failed' end;
  update public.filebridge_commands
     set status = v_status, completed_at = now(), args = '{}'::jsonb
   where id = p_id and device_id = p_device_id and status in ('delivered','running','awaiting_confirmation')
  returning tool into v_tool;
  if v_tool is null then return false; end if;
  insert into public.filebridge_results (command_id, device_id, ok, result, error, error_code, bytes, duration_ms)
  values (p_id, p_device_id, (p_ok and v_status = 'succeeded'), p_result, left(p_error, 2000), left(p_error_code, 64), p_bytes, p_duration_ms)
  on conflict (command_id) do nothing;
  insert into public.filebridge_history (device_id, tool, status, size_bytes, duration_ms, detail)
  values (p_device_id, v_tool, v_status, p_bytes, p_duration_ms, left(coalesce(p_error_code, ''), 64));
  begin
    perform public.filebridge_journal_apply(p_id, v_status, p_result, p_error_code, p_bytes, p_duration_ms);
  exception when others then
    raise warning 'filebridge journal bookkeeping failed: %', sqlerrm;
    begin
      perform public.filebridge_journal_close(p_id, v_status, 'bookkeeping failed; the result itself was stored');
    exception when others then
      null;
    end;
  end;
  return true;
end $$;

create or replace function public.filebridge_hello(p_device_id text, p_inflight text[], p_app_version text)
returns jsonb
language plpgsql set search_path = public as $$
declare v_expired int := 0; v_ids uuid[];
begin
  update public.filebridge_devices
     set last_seen_at = now(), app_version = coalesce(p_app_version, app_version)
   where device_id = p_device_id;
  -- Stale-command protection: destructive commands queued while the phone was away never run after reconnect.
  with u as (
    update public.filebridge_commands
       set status = 'expired', completed_at = now(), args = '{}'::jsonb
     where device_id = p_device_id and status = 'queued' and (destructive or expires_at <= now())
    returning id)
  select count(*), array_agg(id) into v_expired, v_ids from u;
  update public.filebridge_journal set state = 'expired', finished_at = now(), detail = 'expired while the phone was away; nothing was changed'
   where command_id = any (v_ids) and state = 'queued';
  -- In-flight commands the phone no longer knows about died with its previous process (they may have run partly or fully).
  with u as (
    update public.filebridge_commands
       set status = 'expired', completed_at = now(), args = '{}'::jsonb
     where device_id = p_device_id
       and status in ('delivered','running','awaiting_confirmation')
       and not (id::text = any (coalesce(p_inflight, '{}'::text[])))
    returning id)
  select array_agg(id) into v_ids from u;
  update public.filebridge_journal
     set state = 'interrupted', finished_at = now(),
         detail = 'the phone restarted or lost the connection before it reported a result; the operation may have run partly or fully. Verify the files.'
   where command_id = any (v_ids) and state in ('queued','delivered','running','awaiting_confirmation');
  insert into public.filebridge_device_sessions (device_id, app_version) values (p_device_id, p_app_version);
  -- Retention (keeps the database tiny)
  delete from public.filebridge_history where created_at < now() - interval '30 days';
  delete from public.filebridge_results where created_at < now() - interval '1 hour';
  delete from public.filebridge_commands where created_at < now() - interval '7 days';
  delete from public.filebridge_device_sessions where started_at < now() - interval '30 days';
  perform public.filebridge_recover();
  return jsonb_build_object('expired_queued', v_expired);
end $$;


do $$
declare f text;
begin
  foreach f in array array[
    'filebridge_enqueue(text,text,jsonb,boolean,int,text,text,text,text,text[],text)',
    'filebridge_claim(text,int)', 'filebridge_expire_command(uuid)', 'filebridge_request_cancel(uuid)',
    'filebridge_finish(uuid,text,boolean,text,jsonb,text,text,bigint,int)', 'filebridge_hello(text,text[],text)'
  ] loop
    execute format('revoke all on function public.%s from public, anon, authenticated', f);
    execute format('grant execute on function public.%s to service_role', f);
  end loop;
end $$;
