-- Claude FileBridge 1.2.0 database tests.
-- Run each DO block (with the Supabase SQL editor, the connector's execute_sql, or psql) AFTER both 1.2.0 migrations are applied.
-- Every block ends with a deliberate RAISE EXCEPTION, so everything it created is rolled back and nothing is left behind.
-- The exception message is the report: {"total": N, "passed": N, "failed": []}. An empty "failed" list means every check passed.
-- Record of what was actually run against the real project (uvxrpymncajhqtqpwdsb):
--   block 1, exactly as written here: 89 of 89 checks passed.
--   block 2: 31 checks were run together with the part-B migration text before it was applied: 30 passed and the 'cancel queued' check
--   failed only because it read the journal inside the same statement as the call that changed it (test artifact). After applying part B the
--   cancel path was re-run on its own (cancelled / cancelled / cancelled). The block below contains the corrected cancel checks; this exact
--   version of block 2 has not been run as a whole yet.

-- ===================================================== block 1: state, leases, tests, recovery, resume
do $outer$
declare
  j public.filebridge_journal; r jsonb; r2 jsonb; txt text; c1 uuid; c2 uuid; c3 uuid; tid uuid; tid2 uuid; lid uuid; i int;
  sha1 text := repeat('a', 64); sha2 text := repeat('b', 64);
begin
  create temp table fbt(name text, ok boolean, detail text) on commit drop;
  create function pg_temp.chk(p_name text, p_ok boolean, p_detail text default null) returns void language sql as $f$ insert into fbt(name, ok, detail) values (p_name, coalesce(p_ok, false), p_detail) $f$;

  perform pg_temp.chk('norm_path trims and fixes slashes', public.filebridge_norm_path('/a//b/c/') = 'a/b/c');
  perform pg_temp.chk('norm_path backslash', public.filebridge_norm_path('a\b') = 'a/b');
  perform pg_temp.chk('overlap equal', public.filebridge_path_overlap('a/b', 'a/b'));
  perform pg_temp.chk('overlap child', public.filebridge_path_overlap('a/b', 'a/b/c.txt'));
  perform pg_temp.chk('overlap parent', public.filebridge_path_overlap('a/b/c.txt', 'a/b'));
  perform pg_temp.chk('no overlap for sibling with same prefix', not public.filebridge_path_overlap('a/b', 'a/bc/x'));
  perform pg_temp.chk('overlap root', public.filebridge_path_overlap('', 'a'));

  perform pg_temp.chk('pick explicit', (select r_project || '/' || r_source from public.filebridge_pick_project('MyProj', 'o1', array['X/y.txt'])) = 'MyProj/explicit');
  perform pg_temp.chk('pick from path', (select r_project || '/' || r_source from public.filebridge_pick_project(null, 'o1', array['Alpha/src/a.kt'])) = 'Alpha/path');
  perform pg_temp.chk('pick root file -> general', (select r_project || '/' || r_source from public.filebridge_pick_project(null, 'o1', array['notes.txt'])) = 'general/default');
  perform pg_temp.chk('pick skips virtual folders', (select r_project from public.filebridge_pick_project(null, 'o1', array['ZIP/x.zip'])) = 'general');
  perform public.filebridge_owner_set_project('o1', 'Resumed');
  perform pg_temp.chk('pick session project', (select r_project || '/' || r_source from public.filebridge_pick_project(null, 'o1', array['Alpha/src/a.kt'])) = 'Resumed/session');
  perform pg_temp.chk('explicit beats session', (select r_source from public.filebridge_pick_project('Z', 'o1', null)) = 'explicit');

  insert into public.filebridge_journal (command_id, device_id, project, owner, tool, paths, state) values (gen_random_uuid(), 'DEV1', 'P1', 'A', 'write_file', array['P1/a.txt'], 'delivered') returning * into j;
  perform public.filebridge_journal_apply(j.command_id, 'succeeded', jsonb_build_object('revision', sha1, 'size', 5), null, 5, 10);
  select * into j from public.filebridge_journal where id = j.id;
  perform pg_temp.chk('write: journal succeeded with revision', j.state = 'succeeded' and (j.revision -> 'P1/a.txt' ->> 'sha256') = sha1, j.state);
  perform pg_temp.chk('write: file_state rev 1', (select rev from public.filebridge_file_state where device_id = 'DEV1' and path = 'P1/a.txt') = 1);
  perform pg_temp.chk('write: project revision 1', (select revision from public.filebridge_project_state where project = 'P1') = 1);
  perform pg_temp.chk('write: writer has seen the new revision', (select sha256 from public.filebridge_file_seen where device_id = 'DEV1' and owner = 'A' and path = 'P1/a.txt') = sha1);
  select content into txt from public.filebridge_memory where project = 'P1' and author = 'filebridge-auto' and not archived;
  perform pg_temp.chk('write: auto memory entry saved', txt like '%P1/a.txt%' and txt like '%Project revision 1%', left(txt, 160));

  insert into public.filebridge_journal (command_id, device_id, project, owner, tool, paths, state) values (gen_random_uuid(), 'DEV1', 'P1', 'B', 'write_file', array['P1/a.txt'], 'delivered') returning * into j;
  perform public.filebridge_journal_apply(j.command_id, 'succeeded', jsonb_build_object('revision', sha2, 'size', 7), null, 7, 10);
  perform pg_temp.chk('overwrite: rev 2 by B', (select rev || '/' || updated_by from public.filebridge_file_state where device_id = 'DEV1' and path = 'P1/a.txt') = '2/B');
  perform pg_temp.chk('overwrite: project revision 2', (select revision from public.filebridge_project_state where project = 'P1') = 2);
  perform pg_temp.chk('overwrite: auto memory version bumped', (select version from public.filebridge_memory where project = 'P1' and author = 'filebridge-auto') = 2);
  perform pg_temp.chk('overwrite: A last saw the old revision, current one differs', (select sha256 from public.filebridge_file_seen where device_id = 'DEV1' and owner = 'A' and path = 'P1/a.txt') = sha1 and (select sha256 from public.filebridge_file_state where device_id = 'DEV1' and path = 'P1/a.txt') = sha2);

  insert into public.filebridge_journal (command_id, device_id, project, owner, tool, paths, state) values (gen_random_uuid(), 'DEV1', 'P1', 'B', 'write_file', array['P1/a.txt'], 'delivered') returning * into j;
  perform public.filebridge_journal_apply(j.command_id, 'succeeded', jsonb_build_object('revision', sha2, 'size', 7, 'unchanged', true), null, 7, 10);
  perform pg_temp.chk('unchanged write does not bump anything', (select rev from public.filebridge_file_state where device_id = 'DEV1' and path = 'P1/a.txt') = 2 and (select revision from public.filebridge_project_state where project = 'P1') = 2);
  perform pg_temp.chk('unchanged write is labelled', (select detail from public.filebridge_journal where id = j.id) like '%identical%');

  insert into public.filebridge_journal (command_id, device_id, project, owner, tool, paths, state) values (gen_random_uuid(), 'DEV1', 'P1', 'C', 'copy_file', array['P1/a.txt', 'P1/b.txt'], 'delivered') returning * into j;
  perform public.filebridge_journal_apply(j.command_id, 'succeeded', jsonb_build_object('size', 7), null, 7, 10);
  perform pg_temp.chk('copy: destination tracked', (select rev || '/' || coalesce(size::text, '?') from public.filebridge_file_state where device_id = 'DEV1' and path = 'P1/b.txt') = '1/7');
  insert into public.filebridge_journal (command_id, device_id, project, owner, tool, paths, state) values (gen_random_uuid(), 'DEV1', 'P1', 'C', 'move_file', array['P1/b.txt', 'P1/c.txt'], 'delivered') returning * into j;
  perform public.filebridge_journal_apply(j.command_id, 'succeeded', jsonb_build_object('size', 7), null, 7, 10);
  perform pg_temp.chk('move: source deleted, destination live', (select deleted from public.filebridge_file_state where device_id = 'DEV1' and path = 'P1/b.txt') and not (select deleted from public.filebridge_file_state where device_id = 'DEV1' and path = 'P1/c.txt'));
  insert into public.filebridge_journal (command_id, device_id, project, owner, tool, paths, state) values (gen_random_uuid(), 'DEV1', 'P1', 'C', 'delete_file', array['P1/c.txt'], 'delivered') returning * into j;
  perform public.filebridge_journal_apply(j.command_id, 'succeeded', '{}'::jsonb, null, 0, 10);
  perform pg_temp.chk('delete: marked deleted', (select deleted from public.filebridge_file_state where device_id = 'DEV1' and path = 'P1/c.txt'));
  insert into public.filebridge_journal (command_id, device_id, project, owner, tool, paths, state) values (gen_random_uuid(), 'DEV1', 'P1', 'C', 'create_zip', array['P1', 'ZIP/P1.zip'], 'delivered') returning * into j;
  perform public.filebridge_journal_apply(j.command_id, 'succeeded', jsonb_build_object('size', 1234), null, 1234, 10);
  perform pg_temp.chk('zip: output tracked with size', (select size from public.filebridge_file_state where device_id = 'DEV1' and path = 'ZIP/P1.zip') = 1234);
  insert into public.filebridge_journal (command_id, device_id, project, owner, tool, paths, state) values (gen_random_uuid(), 'DEV1', 'P1', 'C', 'extract_zip', array['ZIP/P1.zip', 'P1/x'], 'delivered') returning * into j;
  perform public.filebridge_journal_apply(j.command_id, 'succeeded', '{}'::jsonb, null, 0, 10);
  perform pg_temp.chk('project revision counts every changing operation (7)', (select revision from public.filebridge_project_state where project = 'P1') = 7, (select revision::text from public.filebridge_project_state where project = 'P1'));
  perform pg_temp.chk('failed operations never change anything', (select count(*) from public.filebridge_file_state where path = 'P1/never') = 0);

  insert into public.filebridge_journal (command_id, device_id, project, owner, tool, paths, state) values (gen_random_uuid(), 'DEV1', 'P1', 'R', 'read_file', array['P1/a.txt'], 'delivered') returning * into j;
  perform public.filebridge_journal_apply(j.command_id, 'succeeded', jsonb_build_object('revision', sha2), null, 7, 10);
  perform pg_temp.chk('read: reader remembers what it saw', (select sha256 from public.filebridge_file_seen where device_id = 'DEV1' and owner = 'R' and path = 'P1/a.txt') = sha2);
  insert into public.filebridge_journal (command_id, device_id, project, owner, tool, paths, state) values (gen_random_uuid(), 'DEV1', 'P1', 'V', 'verify_files', array['P1/a.txt', 'P1/none'], 'delivered') returning * into j;
  perform public.filebridge_journal_apply(j.command_id, 'succeeded', jsonb_build_object('files', jsonb_build_array(jsonb_build_object('path', 'P1/a.txt', 'revision', sha2), jsonb_build_object('path', 'P1/none', 'revision', null))), null, 0, 10);
  perform pg_temp.chk('verify_files: seen recorded only for files that exist', (select count(*) from public.filebridge_file_seen where owner = 'V') = 1);

  c1 := gen_random_uuid(); c2 := gen_random_uuid(); c3 := gen_random_uuid();
  insert into public.filebridge_journal (command_id, device_id, project, owner, tool, paths, state, created_at) values (c1, 'DEV1', 'P1', 'A', 'write_file', array['P1/late.txt'], 'interrupted', now() - interval '10 minutes');
  insert into public.filebridge_journal (command_id, device_id, project, owner, tool, paths, state, created_at) values (c2, 'DEV1', 'P1', 'A', 'write_file', array['P1/other.txt'], 'interrupted', now() - interval '10 minutes');
  insert into public.filebridge_journal (command_id, device_id, project, owner, tool, paths, state, created_at) values (c3, 'DEV1', 'P1', 'A', 'write_file', array['P1/done.txt'], 'succeeded', now() - interval '10 minutes');
  r := public.filebridge_journal_sync('DEV1', jsonb_build_array(
         jsonb_build_object('command_id', c1, 'tool', 'write_file', 'state', 'succeeded', 'revision', sha1, 'size', 9, 'paths', jsonb_build_array('P1/late.txt')),
         jsonb_build_object('command_id', 'not-a-uuid', 'state', 'succeeded'),
         jsonb_build_object('command_id', c3, 'tool', 'write_file', 'state', 'failed', 'paths', jsonb_build_array('P1/done.txt')),
         jsonb_build_object('command_id', gen_random_uuid(), 'tool', 'write_file', 'state', 'succeeded', 'revision', sha2, 'size', 3, 'paths', jsonb_build_array('Orph/a.txt'))));
  perform pg_temp.chk('sync: counts (1 updated, 1 added, bad entry skipped)', (r ->> 'updated') = '1' and (r ->> 'added') = '1', r::text);
  perform pg_temp.chk('sync: interrupted -> succeeded via device_sync', (select state || '/' || source from public.filebridge_journal where command_id = c1) = 'succeeded/device_sync');
  perform pg_temp.chk('sync: late write applied to file_state', exists (select 1 from public.filebridge_file_state where device_id = 'DEV1' and path = 'P1/late.txt' and sha256 = sha1));
  perform pg_temp.chk('sync: orphan recorded under its path project', exists (select 1 from public.filebridge_journal where device_id = 'DEV1' and project = 'Orph' and source = 'device_sync' and state = 'succeeded') and exists (select 1 from public.filebridge_file_state where device_id = 'DEV1' and path = 'Orph/a.txt'));
  perform pg_temp.chk('sync: a result the server already holds is never overwritten', (select state from public.filebridge_journal where command_id = c3) = 'succeeded');
  perform public.filebridge_journal_sync('DEV2', jsonb_build_array(jsonb_build_object('command_id', c2, 'tool', 'write_file', 'state', 'succeeded', 'revision', sha1, 'size', 1, 'paths', jsonb_build_array('P1/other.txt'))));
  perform pg_temp.chk('sync: another device cannot rewrite this journal', (select state from public.filebridge_journal where command_id = c2) = 'interrupted');

  insert into public.filebridge_journal (command_id, device_id, project, owner, tool, paths, state, created_at) values (gen_random_uuid(), 'DEV1', 'P1', 'A', 'write_file', array['P1/zzz.txt'], 'delivered', now() - interval '10 minutes');
  insert into public.filebridge_journal (command_id, device_id, project, owner, tool, paths, state, created_at) values (gen_random_uuid(), 'DEV1', 'P1', 'A', 'write_file', array['P1/never.txt'], 'expired', now() - interval '2 hours');
  r := public.filebridge_resume_state('P1', 'A');
  perform pg_temp.chk('resume: vanished in-flight command became interrupted', (select state from public.filebridge_journal where paths = array['P1/zzz.txt']) = 'interrupted');
  perform pg_temp.chk('resume: interrupted op listed', exists (select 1 from jsonb_array_elements(r -> 'unfinished_operations') u where u -> 'paths' ->> 0 = 'P1/zzz.txt' and u ->> 'kind' = 'interrupted'), (r -> 'unfinished_operations')::text);
  perform pg_temp.chk('resume: never-executed op listed', exists (select 1 from jsonb_array_elements(r -> 'unfinished_operations') u where u -> 'paths' ->> 0 = 'P1/never.txt' and u ->> 'kind' = 'not_executed'));
  perform pg_temp.chk('resume: modified files and deletions reported', (select count(*) from jsonb_array_elements(r -> 'modified_files') m where m ->> 'path' = 'P1/a.txt' and (m ->> 'rev') = '2') = 1 and (r -> 'deleted_files') ? 'P1/c.txt');
  perform pg_temp.chk('resume: project revision reported', (r ->> 'project_revision')::int >= 7);
  insert into public.filebridge_journal (command_id, device_id, project, owner, tool, paths, state, created_at, finished_at) values (gen_random_uuid(), 'DEV1', 'P1', 'A', 'write_file', array['P1/zzz.txt'], 'succeeded', now() - interval '5 minutes', now() - interval '5 minutes');
  r := public.filebridge_resume_state('P1', 'A');
  perform pg_temp.chk('resume: an interrupted op disappears once a later write succeeded', not exists (select 1 from jsonb_array_elements(r -> 'unfinished_operations') u where u -> 'paths' ->> 0 = 'P1/zzz.txt'));

  r := public.filebridge_checkpoint('P1', 'A', 'Implemented overwrite fix', array['task one'], array['task two'], array['next one']);
  perform pg_temp.chk('checkpoint saved', (r ->> 'ok') = 'true', r::text);
  r2 := public.filebridge_resume_state('P1', 'A');
  perform pg_temp.chk('checkpoint returned by resume', (r2 -> 'checkpoint' -> 'pending' ->> 0) = 'task two' and (r2 -> 'checkpoint' ->> 'by') = 'A');
  select content into txt from public.filebridge_memory where project = 'P1' and author = 'filebridge-auto' and not archived;
  perform pg_temp.chk('checkpoint mirrored into shared memory', txt like '%next one%' and txt like '%task one%', left(txt, 200));

  r := public.filebridge_lease_acquire('A', 'P1', 'DEV1', array['P1/src'], 600, 'edit src');
  lid := (r ->> 'lease_id')::uuid;
  perform pg_temp.chk('lease: acquired', (r ->> 'ok') = 'true' and lid is not null, r::text);
  r2 := public.filebridge_lease_acquire('B', 'P1', 'DEV1', array['P1/src/Main.kt'], 600, 'x');
  perform pg_temp.chk('lease: other AI is refused inside the leased folder', (r2 ->> 'error') = 'locked_by_other' and (r2 -> 'conflicts' -> 0 ->> 'owner') = 'A', r2::text);
  perform pg_temp.chk('lease: write check reports the holder', jsonb_array_length(public.filebridge_lease_conflicts('B', 'DEV1', array['P1/src/Main.kt'])) = 1);
  perform pg_temp.chk('lease: holder is not blocked by its own lease', jsonb_array_length(public.filebridge_lease_conflicts('A', 'DEV1', array['P1/src/Main.kt'])) = 0);
  perform pg_temp.chk('lease: sibling with same prefix is free', jsonb_array_length(public.filebridge_lease_conflicts('B', 'DEV1', array['P1/srcX/a'])) = 0);
  perform pg_temp.chk('lease: other device is not affected', jsonb_array_length(public.filebridge_lease_conflicts('B', 'DEV2', array['P1/src/Main.kt'])) = 0);
  r2 := public.filebridge_lease_acquire('B', 'P1', 'DEV1', array['P1/docs'], 600, 'docs');
  perform pg_temp.chk('lease: disjoint paths can be leased in parallel', (r2 ->> 'ok') = 'true', r2::text);
  r2 := public.filebridge_lease_acquire('A', 'P1', 'DEV1', array['P1/src'], 900, 'again');
  perform pg_temp.chk('lease: asking again extends instead of stacking', (r2 ->> 'extended') = 'true' and (r2 ->> 'lease_id')::uuid = lid, r2::text);
  perform pg_temp.chk('lease: renew works for the owner', (public.filebridge_lease_renew(lid, 'A', 600) ->> 'ok') = 'true');
  perform pg_temp.chk('lease: renew refused for someone else', (public.filebridge_lease_renew(lid, 'B', 600) ->> 'error') = 'lease_not_found');
  perform pg_temp.chk('lease: release', (public.filebridge_lease_release(lid, 'A') ->> 'released') = '1');
  r2 := public.filebridge_lease_acquire('B', 'P1', 'DEV1', array['P1/src'], 600, 'now mine');
  perform pg_temp.chk('lease: freed path can be taken by the other AI', (r2 ->> 'ok') = 'true', r2::text);
  update public.filebridge_leases set expires_at = now() - interval '1 minute' where owner = 'B' and paths = array['P1/src'];
  perform pg_temp.chk('lease: an interrupted session recovers by expiry', jsonb_array_length(public.filebridge_lease_conflicts('A', 'DEV1', array['P1/src/Main.kt'])) = 0);
  perform pg_temp.chk('lease: expired lease cannot be renewed', (public.filebridge_lease_renew((r2 ->> 'lease_id')::uuid, 'B', 600) ->> 'error') = 'lease_not_found');
  r := public.filebridge_resume_state('P1', 'A');
  perform pg_temp.chk('resume: shows the expired lease of the vanished session', exists (select 1 from jsonb_array_elements(r -> 'expired_leases') l where l ->> 'owner' = 'B'), (r -> 'expired_leases')::text);
  for i in 1..10 loop perform public.filebridge_lease_acquire('M', 'P1', 'DEV1', array['M/' || i], 600, null); end loop;
  perform pg_temp.chk('lease: at most 10 per owner', (public.filebridge_lease_acquire('M', 'P1', 'DEV1', array['M/11'], 600, null) ->> 'error') = 'too_many_leases');

  perform pg_temp.chk('test: missing fields refused', (public.filebridge_test_run('start', 'A', 'P1', null, null, null, null, null, null, null, null, null) ->> 'error') = 'invalid_argument');
  perform pg_temp.chk('test: bad environment refused', (public.filebridge_test_run('plan', 'A', 'P1', null, 'x', 'y', 'moon', null, null, null, null, null) ->> 'error') = 'invalid_argument');
  r := public.filebridge_test_run('plan', 'A', 'P1', null, 'unit', 'node --test', 'temp_copy', array['P1/a.txt'], null, null, null, null);
  tid := (r -> 'test' ->> 'id')::uuid;
  perform pg_temp.chk('test: planned', (r -> 'test' ->> 'status') = 'planned' and (r -> 'test' ->> 'environment') = 'temp_copy', r::text);
  perform pg_temp.chk('test: planned test cannot be reported as passed', (public.filebridge_test_run('finish', 'A', 'P1', tid, null, null, null, null, 'passed', 0, 'ok', null) ->> 'error') = 'not_running');
  r := public.filebridge_test_run('start', 'A', 'P1', tid, null, null, null, null, null, null, null, null);
  perform pg_temp.chk('test: running with revisions captured', (r -> 'test' ->> 'status') = 'running' and jsonb_array_length(r -> 'test' -> 'stale_files') = 0, r::text);
  perform pg_temp.chk('test: a running test cannot be started twice', (public.filebridge_test_run('start', 'A', 'P1', tid, null, null, null, null, null, null, null, null) ->> 'error') = 'invalid_transition');
  perform pg_temp.chk('test: passed needs exit code 0', (public.filebridge_test_run('finish', 'A', 'P1', tid, null, null, null, null, 'passed', 1, 'x', null) ->> 'error') = 'invalid_argument');
  perform pg_temp.chk('test: exit code is mandatory', (public.filebridge_test_run('finish', 'A', 'P1', tid, null, null, null, null, 'passed', null, 'x', null) ->> 'error') = 'invalid_argument');
  perform pg_temp.chk('test: failed with exit 0 needs errors text', (public.filebridge_test_run('finish', 'A', 'P1', tid, null, null, null, null, 'failed', 0, 'x', null) ->> 'error') = 'invalid_argument');
  r := public.filebridge_test_run('finish', 'A', 'P1', tid, null, null, null, null, 'passed', 0, 'all green', null);
  perform pg_temp.chk('test: passed', (r -> 'test' ->> 'status') = 'passed' and (r -> 'test' ->> 'exit_code') = '0', r::text);
  perform pg_temp.chk('test: finished test cannot be finished again', (public.filebridge_test_run('finish', 'A', 'P1', tid, null, null, null, null, 'failed', 2, 'x', 'boom') ->> 'error') = 'not_running');
  insert into public.filebridge_journal (command_id, device_id, project, owner, tool, paths, state) values (gen_random_uuid(), 'DEV1', 'P1', 'C', 'write_file', array['P1/a.txt'], 'delivered') returning * into j;
  perform public.filebridge_journal_apply(j.command_id, 'succeeded', jsonb_build_object('revision', repeat('c', 64), 'size', 8), null, 8, 10);
  perform pg_temp.chk('test: result becomes stale when a tested file changes afterwards', (public.filebridge_test_json(tid) -> 'stale_files' ->> 0) = 'P1/a.txt', public.filebridge_test_json(tid)::text);
  r := public.filebridge_test_run('start', 'A', 'P1', null, 'integration', 'deno test', 'original', array['P1/a.txt'], null, null, null, null);
  tid2 := (r -> 'test' ->> 'id')::uuid;
  perform pg_temp.chk('test: direct start gives a running test', (r -> 'test' ->> 'status') = 'running', r::text);
  perform pg_temp.chk('test: heartbeat accepted for the owner', (public.filebridge_test_run('heartbeat', 'A', 'P1', tid2, null, null, null, null, null, null, null, null) ->> 'ok') = 'true');
  update public.filebridge_test_runs set heartbeat_at = now() - interval '2 hours' where id = tid2;
  perform public.filebridge_recover();
  perform pg_temp.chk('test: a vanished session is marked interrupted, never passed', (select status from public.filebridge_test_runs where id = tid2) = 'interrupted' and (select errors from public.filebridge_test_runs where id = tid2) like '%do not treat it as passed%');
  perform pg_temp.chk('test: interrupted test cannot be finished', (public.filebridge_test_run('finish', 'A', 'P1', tid2, null, null, null, null, 'passed', 0, 'x', null) ->> 'error') = 'not_running');
  r := public.filebridge_test_run('start', 'A', 'P1', null, 'lint', 'ktlint', 'other', null, null, null, null, null);
  r2 := public.filebridge_test_run('interrupt', 'A', 'P1', (r -> 'test' ->> 'id')::uuid, null, null, null, null, null, null, null, 'phone went to sleep');
  perform pg_temp.chk('test: explicit interrupt', (r2 -> 'test' ->> 'status') = 'interrupted', r2::text);
  r := public.filebridge_resume_state('P1', 'A');
  perform pg_temp.chk('resume: test counts by honest state', (r -> 'tests' -> 'counts' ->> 'passed') = '1' and (r -> 'tests' -> 'counts' ->> 'interrupted') = '2', (r -> 'tests' -> 'counts')::text);

  insert into public.filebridge_memory (title) select 'filler ' || g from generate_series(1, 2000) g;
  insert into public.filebridge_journal (command_id, device_id, project, owner, tool, paths, state) values (gen_random_uuid(), 'DEV1', 'Full1', 'A', 'write_file', array['Full1/a.txt'], 'delivered') returning * into j;
  perform public.filebridge_journal_apply(j.command_id, 'succeeded', jsonb_build_object('revision', sha1, 'size', 1), null, 1, 10);
  perform pg_temp.chk('memory full: journal and file state still recorded', (select state from public.filebridge_journal where id = j.id) = 'succeeded' and exists (select 1 from public.filebridge_file_state where path = 'Full1/a.txt'));
  perform pg_temp.chk('memory full: no auto entry, no error', not exists (select 1 from public.filebridge_memory where project = 'Full1'));
  r := public.filebridge_resume_state('Full1', 'A');
  perform pg_temp.chk('memory full: resume still reports the modified file', jsonb_array_length(r -> 'modified_files') = 1, r::text);

  perform pg_temp.chk('anon cannot call resume', not has_function_privilege('anon', 'public.filebridge_resume_state(text,text)', 'execute'));
  perform pg_temp.chk('authenticated cannot call finish helper', not has_function_privilege('authenticated', 'public.filebridge_journal_apply(uuid,text,jsonb,text,bigint,int)', 'execute'));
  perform pg_temp.chk('service role can call resume', has_function_privilege('service_role', 'public.filebridge_resume_state(text,text)', 'execute'));
  perform pg_temp.chk('RLS on for every new table', (select bool_and(relrowsecurity) from pg_class where oid in ('public.filebridge_journal'::regclass, 'public.filebridge_file_state'::regclass, 'public.filebridge_file_seen'::regclass, 'public.filebridge_owner_project'::regclass, 'public.filebridge_project_state'::regclass, 'public.filebridge_leases'::regclass, 'public.filebridge_test_runs'::regclass)));
  perform pg_temp.chk('anon has no table access', not has_table_privilege('anon', 'public.filebridge_journal', 'select') and not has_table_privilege('authenticated', 'public.filebridge_test_runs', 'select'));

  raise exception 'FBTEST %', (select jsonb_build_object('total', count(*), 'passed', count(*) filter (where ok), 'failed', coalesce(jsonb_agg(jsonb_build_object('name', name, 'detail', left(detail, 300))) filter (where not ok), '[]'::jsonb)) from fbt);
end
$outer$;

-- ===================================================== block 2: command queue integration (enqueue, claim, finish, hello, cancel)
do $outer$
declare
  cmd public.filebridge_commands; cmd2 public.filebridge_commands; cmd3 public.filebridge_commands; r jsonb; fin boolean; n int; caught text; i int; txt text;
  sha1 text := repeat('d', 64); cancel_result text;
begin
  create temp table fbt(name text, ok boolean, detail text) on commit drop;
  create function pg_temp.chk(p_name text, p_ok boolean, p_detail text default null) returns void language sql as $f$ insert into fbt(name, ok, detail) values (p_name, coalesce(p_ok, false), p_detail) $f$;

  insert into public.filebridge_devices (device_id, token_hash, channel_id, channel_key) values ('FB-ZZTEST01', 'h-zz1', 'c-zz1', 'k-zz1');
  insert into public.filebridge_devices (device_id, token_hash, channel_id, channel_key) values ('FB-ZZTEST02', 'h-zz2', 'c-zz2', 'k-zz2');

  select * into cmd from public.filebridge_enqueue(p_device_id => 'FB-ZZTEST01', p_tool => 'list_files', p_args => '{}'::jsonb, p_destructive => false, p_ttl => 90, p_nonce => 'n0', p_client => 'Claude');
  perform pg_temp.chk('compat: old 7-argument enqueue works and is journaled', (select owner || '/' || project || '/' || state from public.filebridge_journal where command_id = cmd.id) = 'Claude/general/queued');
  perform pg_temp.chk('compat: old enqueue signature is gone, new one exists', to_regprocedure('public.filebridge_enqueue(text,text,jsonb,boolean,int,text,text)') is null and to_regprocedure('public.filebridge_enqueue(text,text,jsonb,boolean,int,text,text,text,text,text[],text)') is not null);

  select * into cmd2 from public.filebridge_enqueue('FB-ZZTEST01', 'write_file', '{"path":"Proj/a.txt","content":"hi"}'::jsonb, false, 90, 'n1', 'Claude', 'Claude#s1', null, array['Proj/a.txt'], 'first write');
  perform pg_temp.chk('enqueue: journal row with project from path, owner session, note', (select project || '/' || project_source || '/' || owner || '/' || coalesce(note, '') || '/' || paths[1] from public.filebridge_journal where command_id = cmd2.id) = 'Proj/path/Claude#s1/first write/Proj/a.txt');
  select count(*) into n from public.filebridge_claim('FB-ZZTEST01', 3);
  perform pg_temp.chk('claim: both queued commands delivered', n = 2, n::text);
  perform pg_temp.chk('claim: journal follows to delivered', (select state from public.filebridge_journal where command_id = cmd2.id) = 'delivered');
  fin := public.filebridge_finish(cmd2.id, 'FB-ZZTEST01', true, null, jsonb_build_object('path', 'Proj/a.txt', 'size', 2, 'revision', sha1, 'overwritten', false), null, null, 2, 15);
  perform pg_temp.chk('finish: accepted', fin);
  perform pg_temp.chk('finish: command done and args wiped (privacy)', (select status || '/' || args::text from public.filebridge_commands where id = cmd2.id) = 'succeeded/{}');
  perform pg_temp.chk('finish: result and history stored as before', exists (select 1 from public.filebridge_results where command_id = cmd2.id and ok) and exists (select 1 from public.filebridge_history where device_id = 'FB-ZZTEST01' and tool = 'write_file' and status = 'succeeded'));
  perform pg_temp.chk('finish: journal succeeded with revision', (select state || '/' || (revision -> 'Proj/a.txt' ->> 'sha256') from public.filebridge_journal where command_id = cmd2.id) = 'succeeded/' || sha1);
  perform pg_temp.chk('finish: file revision, project revision, writer knowledge', (select rev from public.filebridge_file_state where device_id = 'FB-ZZTEST01' and path = 'Proj/a.txt') = 1 and (select revision from public.filebridge_project_state where project = 'Proj') = 1 and (select sha256 from public.filebridge_file_seen where owner = 'Claude#s1' and path = 'Proj/a.txt') = sha1);
  select content into txt from public.filebridge_memory where project = 'Proj' and author = 'filebridge-auto';
  perform pg_temp.chk('finish: progress saved to shared memory automatically', txt like '%Proj/a.txt%', left(txt, 120));
  perform pg_temp.chk('finish: second report of the same result is refused', not public.filebridge_finish(cmd2.id, 'FB-ZZTEST01', true, null, '{}'::jsonb, null, null, 0, 1));
  perform pg_temp.chk('finish: unknown command id refused', not public.filebridge_finish(gen_random_uuid(), 'FB-ZZTEST01', true, null, '{}'::jsonb, null, null, 0, 1));
  perform pg_temp.chk('finish: wrong device refused', not public.filebridge_finish(cmd.id, 'FB-ZZTEST02', true, null, '{}'::jsonb, null, null, 0, 1));

  select * into cmd3 from public.filebridge_enqueue('FB-ZZTEST01', 'write_file', '{}'::jsonb, true, 45, 'n2', 'Claude', 'Claude#s1', null, array['Proj/b.txt'], null);
  perform public.filebridge_claim('FB-ZZTEST01', 1);
  fin := public.filebridge_finish(cmd3.id, 'FB-ZZTEST01', false, 'rejected', null, 'The user declined', 'declined', 0, 120092);
  perform pg_temp.chk('rejected: journal records it, nothing tracked as changed', fin and (select state || '/' || error_code from public.filebridge_journal where command_id = cmd3.id) = 'rejected/declined' and not exists (select 1 from public.filebridge_file_state where path = 'Proj/b.txt') and (select revision from public.filebridge_project_state where project = 'Proj') = 1);

  select * into cmd3 from public.filebridge_enqueue('FB-ZZTEST01', 'write_file', '{}'::jsonb, false, 90, 'n3', 'Claude', 'Claude#s1', null, array['Proj/c.txt'], null);
  select * into cmd2 from public.filebridge_enqueue('FB-ZZTEST01', 'write_file', '{}'::jsonb, false, 90, 'n4', 'Claude', 'Claude#s1', null, array['Proj/keep.txt'], null);
  perform public.filebridge_claim('FB-ZZTEST01', 3);
  r := public.filebridge_hello('FB-ZZTEST01', array[cmd2.id::text], '1.2.0');
  perform pg_temp.chk('hello: unknown in-flight command expires and journal says interrupted', (select status from public.filebridge_commands where id = cmd3.id) = 'expired' and (select state from public.filebridge_journal where command_id = cmd3.id) = 'interrupted');
  perform pg_temp.chk('hello: in-flight command the phone still knows is untouched', (select status from public.filebridge_commands where id = cmd2.id) = 'delivered' and (select state from public.filebridge_journal where command_id = cmd2.id) = 'delivered');
  perform pg_temp.chk('hello: returns the expired_queued counter as before', r ? 'expired_queued');
  r := public.filebridge_journal_sync('FB-ZZTEST01', jsonb_build_array(jsonb_build_object('command_id', cmd3.id, 'tool', 'write_file', 'state', 'succeeded', 'revision', sha1, 'size', 4, 'paths', jsonb_build_array('Proj/c.txt'))));
  perform pg_temp.chk('late sync: phone reports the write really happened', (select state || '/' || source from public.filebridge_journal where command_id = cmd3.id) = 'succeeded/device_sync' and exists (select 1 from public.filebridge_file_state where path = 'Proj/c.txt' and sha256 = sha1), r::text);
  r := public.filebridge_resume_state('Proj', 'Claude#s1');
  perform pg_temp.chk('resume: no unfinished operation left for the recovered write', not exists (select 1 from jsonb_array_elements(r -> 'unfinished_operations') u where u -> 'paths' ->> 0 = 'Proj/c.txt'), (r -> 'unfinished_operations')::text);

  select * into cmd3 from public.filebridge_enqueue('FB-ZZTEST01', 'write_file', '{}'::jsonb, true, 45, 'n5', 'Claude', 'Claude#s1', null, array['Proj/d.txt'], null);
  perform public.filebridge_hello('FB-ZZTEST01', array[cmd2.id::text], '1.2.0');
  perform pg_temp.chk('hello: queued destructive command expired, journal says nothing was changed', (select status from public.filebridge_commands where id = cmd3.id) = 'expired' and (select state || '/' || detail from public.filebridge_journal where command_id = cmd3.id) like 'expired/%nothing was changed');

  select * into cmd3 from public.filebridge_enqueue('FB-ZZTEST01', 'list_files', '{}'::jsonb, false, 90, 'n6', 'Claude', 'Claude#s1', null, array['Proj'], null);
  perform public.filebridge_expire_command(cmd3.id);
  perform pg_temp.chk('expire_command: journal expired', (select state from public.filebridge_journal where command_id = cmd3.id) = 'expired');
  -- cancel: call first, check afterwards (a subquery in the same statement would still see the old snapshot)
  select * into cmd3 from public.filebridge_enqueue('FB-ZZTEST01', 'list_files', '{}'::jsonb, false, 90, 'n7', 'Claude', 'Claude#s1', null, array['Proj'], null);
  cancel_result := public.filebridge_request_cancel(cmd3.id);
  perform pg_temp.chk('cancel queued', cancel_result = 'cancelled' and (select state from public.filebridge_journal where command_id = cmd3.id) = 'cancelled', cancel_result);
  cancel_result := public.filebridge_request_cancel(cmd2.id);
  perform pg_temp.chk('cancel in-flight is only requested', cancel_result = 'cancel_requested' and (select state from public.filebridge_journal where command_id = cmd2.id) = 'delivered', cancel_result);
  perform pg_temp.chk('cancel unknown', public.filebridge_request_cancel(gen_random_uuid()) = 'not_found');

  insert into public.filebridge_commands (device_id, tool, args, destructive, nonce, expires_at, status) values ('FB-ZZTEST02', 'list_files', '{}'::jsonb, false, 'old', now() - interval '1 minute', 'queued') returning * into cmd3;
  insert into public.filebridge_journal (command_id, device_id, project, owner, tool, paths, state) values (cmd3.id, 'FB-ZZTEST02', 'general', 'Claude', 'list_files', '{}', 'queued');
  perform public.filebridge_enqueue('FB-ZZTEST02', 'list_files', '{}'::jsonb, false, 90, 'n8', 'Claude');
  perform pg_temp.chk('enqueue: stale queued command expired and journaled', (select status from public.filebridge_commands where id = cmd3.id) = 'expired' and (select state from public.filebridge_journal where command_id = cmd3.id) = 'expired');

  for i in 1..4 loop perform public.filebridge_enqueue('FB-ZZTEST02', 'list_files', '{}'::jsonb, false, 90, 'l' || i, 'Claude'); end loop;
  begin perform public.filebridge_enqueue('FB-ZZTEST02', 'list_files', '{}'::jsonb, false, 90, 'l9', 'Claude'); exception when others then caught := sqlerrm; end;
  perform pg_temp.chk('limits: per-client queue limit still enforced', caught = 'client_queue_full', caught);

  create function public.fbt_boom_fn() returns trigger language plpgsql as $f$ begin raise exception 'boom'; end $f$;
  create trigger fbt_boom before insert on public.filebridge_memory for each row execute function public.fbt_boom_fn();
  select * into cmd3 from public.filebridge_enqueue('FB-ZZTEST01', 'write_file', '{}'::jsonb, false, 90, 'n9', 'Claude', 'Claude#s1', 'BoomProj', array['BoomProj/x.txt'], null);
  perform public.filebridge_claim('FB-ZZTEST01', 3);
  fin := public.filebridge_finish(cmd3.id, 'FB-ZZTEST01', true, null, jsonb_build_object('revision', sha1, 'size', 1), null, null, 1, 5);
  perform pg_temp.chk('resilience: result accepted even when bookkeeping fails', fin and (select status from public.filebridge_commands where id = cmd3.id) = 'succeeded' and exists (select 1 from public.filebridge_results where command_id = cmd3.id and ok));
  perform pg_temp.chk('resilience: journal still closed', (select state || '/' || coalesce(detail, '') from public.filebridge_journal where command_id = cmd3.id) like 'succeeded/bookkeeping failed%');
  drop trigger fbt_boom on public.filebridge_memory;

  perform pg_temp.chk('anon cannot enqueue or finish', not has_function_privilege('anon', 'public.filebridge_enqueue(text,text,jsonb,boolean,int,text,text,text,text,text[],text)', 'execute') and not has_function_privilege('authenticated', 'public.filebridge_finish(uuid,text,boolean,text,jsonb,text,text,bigint,int)', 'execute'));
  perform pg_temp.chk('service role can', has_function_privilege('service_role', 'public.filebridge_enqueue(text,text,jsonb,boolean,int,text,text,text,text,text[],text)', 'execute') and has_function_privilege('service_role', 'public.filebridge_hello(text,text[],text)', 'execute'));

  raise exception 'FBTEST %', (select jsonb_build_object('total', count(*), 'passed', count(*) filter (where ok), 'failed', coalesce(jsonb_agg(jsonb_build_object('name', name, 'detail', left(detail, 300))) filter (where not ok), '[]'::jsonb)) from fbt);
end
$outer$;
