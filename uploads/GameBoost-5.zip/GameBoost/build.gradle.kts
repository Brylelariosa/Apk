// AGP 9's built-in Kotlin support replaces the org.jetbrains.kotlin.android
// plugin (applying it now fails the build outright), but built-in Kotlin
// defaults to bundling KGP 2.2.10. This classpath entry upgrades that to the
// same 2.3.21 the Compose Compiler plugin below is pinned to, so the two
// stay compatible. See https://developer.android.com/build/migrate-to-built-in-kotlin
buildscript {
    dependencies {
        classpath("org.jetbrains.kotlin:kotlin-gradle-plugin:2.3.21")
    }
}

plugins {
    id("com.android.application") version "9.2.0" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.3.21" apply false
}
