package com.bru.gameboost.data

import java.io.File

/**
 * Computes aggregate system-wide CPU utilization from /proc/stat deltas —
 * readable without root. Two consecutive reads are required: call
 * [readTimes] on each poll tick and diff it against the previous [CpuTimes]
 * via [percentBetween]. (Ported from SystemMonitor's CpuLoadReader, where
 * this technique is already validated on-device.)
 */
class CpuLoadReader {

    fun readTimes(): CpuTimes? = runCatching {
        // use{} closes the stream; without it every poll leaves a file descriptor for the GC to reap.
        val line = File("/proc/stat").bufferedReader().use { it.readLine() }
        val parts = line.trim().split(WHITESPACE).drop(1).map { it.toLong() }
        val idle = parts[3] + parts.getOrElse(4) { 0L }
        CpuTimes(total = parts.sum(), idle = idle)
    }.getOrNull()

    fun percentBetween(previous: CpuTimes, current: CpuTimes): Float? {
        val totalDelta = current.total - previous.total
        val idleDelta = current.idle - previous.idle
        if (totalDelta <= 0) return null
        return ((totalDelta - idleDelta).toFloat() / totalDelta) * 100f
    }

    private companion object {
        val WHITESPACE = Regex("\\s+") // built once, not on every poll
    }
}

data class CpuTimes(val total: Long, val idle: Long)
