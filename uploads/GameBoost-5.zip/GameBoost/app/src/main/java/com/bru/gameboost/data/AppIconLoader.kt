package com.bru.gameboost.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.util.LruCache
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Renders launcher icons for the lists and the notification. Each icon is drawn once, at a
 * fixed size, and kept in a small cache — scrolling a 100-app list doesn't re-decode anything,
 * and nothing is decoded on the main thread.
 */
class AppIconLoader(context: Context) {

    private val packageManager = context.applicationContext.packageManager
    private val cache = LruCache<String, Bitmap>(MAX_CACHED_ICONS)

    /** Null if the app is gone or its icon can't be rendered; callers show a placeholder. */
    suspend fun load(packageName: String): Bitmap? {
        cache.get(packageName)?.let { return it }
        return withContext(Dispatchers.IO) {
            runCatching {
                packageManager.getApplicationIcon(packageName).toSoftwareBitmap(ICON_SIZE_PX)
            }.getOrNull()?.also { cache.put(packageName, it) }
        }
    }

    fun clear() {
        cache.evictAll()
    }

    /**
     * Always a plain ARGB_8888 bitmap: notifications and software canvases refuse hardware-backed
     * ones, which bitmap drawables from resources can be.
     */
    private fun Drawable.toSoftwareBitmap(sizePx: Int): Bitmap {
        if (this is BitmapDrawable) {
            val source = bitmap
            val software = if (source.config == Bitmap.Config.HARDWARE) {
                source.copy(Bitmap.Config.ARGB_8888, false)
            } else {
                source
            }
            return Bitmap.createScaledBitmap(software, sizePx, sizePx, true)
        }
        val bitmap = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
        setBounds(0, 0, sizePx, sizePx)
        draw(Canvas(bitmap))
        return bitmap
    }

    private companion object {
        const val ICON_SIZE_PX = 120
        const val MAX_CACHED_ICONS = 160
    }
}
