package com.bru.gameboost.presentation.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

// The container and "on" colours are set explicitly: left at their defaults they stay purple,
// which clashes with the orange accent on the active-boost card and the buttons.
private val DarkColors = darkColorScheme(
    primary = AccentOrange,
    onPrimary = OnAccent,
    primaryContainer = AccentContainerDark,
    onPrimaryContainer = OnAccentContainerDark,
    background = SurfaceDark,
    surface = SurfaceCardDark,
    surfaceVariant = SurfaceVariantDark,
    onSurfaceVariant = OnSurfaceVariantDark,
    surfaceContainerHighest = CardDark
)

private val LightColors = lightColorScheme(
    primary = AccentOrange,
    onPrimary = OnAccent,
    primaryContainer = AccentContainerLight,
    onPrimaryContainer = OnAccentContainerLight,
    surfaceContainerHighest = CardLight
)

private val AppShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(28.dp)
)

@Composable
fun GameBoostTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        shapes = AppShapes,
        content = content
    )
}
