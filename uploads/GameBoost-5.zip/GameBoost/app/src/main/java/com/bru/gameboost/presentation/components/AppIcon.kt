package com.bru.gameboost.presentation.components

import android.graphics.Bitmap
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** Loads a launcher icon off the main thread; implemented by the view model on top of AppIconLoader. */
typealias IconLoader = suspend (String) -> Bitmap?

/**
 * The launcher icon of [packageName]: a neutral disc while it loads, then a short fade to the
 * real icon. Loads are cached, so scrolling back over a row shows its icon immediately.
 */
@Composable
fun AppIcon(
    packageName: String,
    loadIcon: IconLoader,
    modifier: Modifier = Modifier,
    size: Dp = 44.dp
) {
    val icon by produceState<ImageBitmap?>(initialValue = null, key1 = packageName) {
        value = loadIcon(packageName)?.asImageBitmap()
    }

    Crossfade(
        targetState = icon,
        modifier = modifier.size(size),
        animationSpec = tween(durationMillis = 180),
        label = "appIcon"
    ) { bitmap ->
        if (bitmap != null) {
            Image(
                bitmap = bitmap,
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Fit
            )
        } else {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surfaceVariant)
            )
        }
    }
}
