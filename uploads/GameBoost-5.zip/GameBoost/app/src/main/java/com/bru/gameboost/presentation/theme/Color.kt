package com.bru.gameboost.presentation.theme

import androidx.compose.ui.graphics.Color

val AccentOrange = Color(0xFFFF7A1A)
val OnAccent = Color(0xFF241000) // dark text on the orange: far more legible than white or the default purple
val AccentContainerDark = Color(0xFF4A2500)
val OnAccentContainerDark = Color(0xFFFFDCC2)
val AccentContainerLight = Color(0xFFFFDDC4)
val OnAccentContainerLight = Color(0xFF3B1A00)

val SurfaceDark = Color(0xFF121212)
val SurfaceCardDark = Color(0xFF1E1E1E)
val CardDark = Color(0xFF262626)
val CardLight = Color(0xFFF3ECE7)
val SurfaceVariantDark = Color(0xFF2B2B2B)
val OnSurfaceVariantDark = Color(0xFFCFCFCF)
