package com.bru.gameboost.data

import android.Manifest
import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Process
import com.bru.gameboost.domain.ForegroundAppMonitor
import com.bru.gameboost.domain.ForegroundTracker

/**
 * Answers "what's in front" from Usage Access events — the same capability
 * (and the same AppOpsManager grant check) SystemMonitor already uses.
 */
class ForegroundAppMonitorImpl(private val context: Context) : ForegroundAppMonitor {

    private val usageStatsManager =
        context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager

    @Suppress("DEPRECATION")
    override fun isAccessGranted(): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = appOps.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            Process.myUid(),
            context.packageName
        )
        return if (mode == AppOpsManager.MODE_DEFAULT) {
            // Some builds answer DEFAULT and leave the real verdict to the permission check.
            context.checkCallingOrSelfPermission(Manifest.permission.PACKAGE_USAGE_STATS) ==
                PackageManager.PERMISSION_GRANTED
        } else {
            mode == AppOpsManager.MODE_ALLOWED
        }
    }

    override fun newTracker(): ForegroundTracker = UsageEventsTracker(usageStatsManager)
}

/**
 * Remembers the last known foreground package and reads only the events that
 * arrived since the previous poll. The old approach — asking for the most
 * recent resume event in a fixed trailing window — lost the game the moment its
 * single resume event aged out of the window, even though it was still in front.
 */
private class UsageEventsTracker(
    private val usageStatsManager: UsageStatsManager
) : ForegroundTracker {

    private var cursorMs = System.currentTimeMillis() - INITIAL_LOOKBACK_MS
    private var foregroundPackage: String? = null
    private val event = UsageEvents.Event()

    @Suppress("DEPRECATION")
    override fun poll(): String? {
        val now = System.currentTimeMillis()
        runCatching {
            // A few seconds of overlap: events can be recorded slightly after their own
            // timestamp, and replaying them in order lands on the same final state.
            val events = usageStatsManager.queryEvents(cursorMs - OVERLAP_MS, now)
            while (events.hasNextEvent()) {
                events.getNextEvent(event)
                when (event.eventType) {
                    UsageEvents.Event.MOVE_TO_FOREGROUND -> foregroundPackage = event.packageName
                    UsageEvents.Event.MOVE_TO_BACKGROUND ->
                        if (foregroundPackage == event.packageName) foregroundPackage = null
                }
            }
            cursorMs = now
        }
        return foregroundPackage
    }

    private companion object {
        const val INITIAL_LOOKBACK_MS = 10_000L
        const val OVERLAP_MS = 3_000L
    }
}
