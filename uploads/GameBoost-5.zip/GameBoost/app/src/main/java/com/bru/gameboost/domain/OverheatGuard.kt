package com.bru.gameboost.domain

import com.bru.gameboost.domain.model.DeviceSnapshot

/**
 * Turns a stream of snapshots into "started / stopped running hot" transitions.
 * It cools off [hysteresisC] below the alert temperature on purpose: a phone
 * hovering around a single number would otherwise flap and re-alert every few seconds.
 */
class OverheatGuard(
    private val hysteresisC: Float = DEFAULT_HYSTERESIS_C
) {
    var isHot: Boolean = false
        private set

    /**
     * Feeds one snapshot and returns whether the device counts as hot afterwards.
     * [hotAtC] is passed per reading so a changed setting applies mid-session.
     */
    fun update(snapshot: DeviceSnapshot, hotAtC: Float): Boolean {
        val tempC = snapshot.batteryTempC
        val throttling = snapshot.thermalStatus?.isSevere == true
        isHot = when {
            throttling -> true
            tempC == null -> false
            isHot -> tempC >= hotAtC - hysteresisC
            else -> tempC >= hotAtC
        }
        return isHot
    }

    companion object {
        const val DEFAULT_HYSTERESIS_C = 2f
    }
}
