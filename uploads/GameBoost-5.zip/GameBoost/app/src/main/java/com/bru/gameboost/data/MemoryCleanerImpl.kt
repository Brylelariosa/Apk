package com.bru.gameboost.data

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import android.provider.Telephony
import android.telecom.TelecomManager
import com.bru.gameboost.domain.MemoryCleaner
import com.bru.gameboost.domain.model.CleanResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/**
 * Frees RAM the only way a normal app can: killBackgroundProcesses() for every
 * launchable app we can see. That drops *cached* background processes — it is
 * not a force-stop, it can't touch apps with a foreground service or a visible
 * window, and some apps will quietly restart themselves. The before/after
 * reading in [CleanResult] is there so the user can judge whether it's worth it.
 */
class MemoryCleanerImpl(
    context: Context,
    private val resolver: LaunchableAppResolver = LaunchableAppResolver(context.packageManager)
) : MemoryCleaner {

    private val appContext = context.applicationContext
    private val activityManager = appContext.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager

    override suspend fun cleanBackground(protectedPackages: Set<String>): CleanResult =
        withContext(Dispatchers.Default) {
            val skip = protectedPackages + essentialPackages()
            val targets = resolver.queryLaunchableApps()
                .map { it.packageName }
                .filterNot { it in skip }

            val freeBeforeMb = availableMb()
            targets.forEach { packageName ->
                runCatching { activityManager.killBackgroundProcesses(packageName) }
            }
            delay(SETTLE_MS) // the kills are carried out asynchronously by the system
            val freedMb = (availableMb() - freeBeforeMb).coerceAtLeast(0)

            CleanResult(appsChecked = targets.size, freedMb = freedMb)
        }

    private fun availableMb(): Long {
        val info = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(info)
        return info.availMem / BYTES_PER_MB
    }

    /** Apps whose sudden restart the user would feel: us, the launcher, keyboard, phone and SMS. */
    private fun essentialPackages(): Set<String> = buildSet {
        add(appContext.packageName)
        homePackage()?.let { add(it) }
        keyboardPackage()?.let { add(it) }
        dialerPackage()?.let { add(it) }
        smsPackage()?.let { add(it) }
    }

    @Suppress("DEPRECATION")
    private fun homePackage(): String? = runCatching {
        val homeIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        appContext.packageManager
            .resolveActivity(homeIntent, PackageManager.MATCH_DEFAULT_ONLY)
            ?.activityInfo?.packageName
    }.getOrNull()

    private fun keyboardPackage(): String? = runCatching {
        Settings.Secure.getString(appContext.contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
            ?.substringBefore('/')
    }.getOrNull()

    private fun dialerPackage(): String? = runCatching {
        (appContext.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager)?.defaultDialerPackage
    }.getOrNull()

    private fun smsPackage(): String? = runCatching {
        Telephony.Sms.getDefaultSmsPackage(appContext)
    }.getOrNull()

    private companion object {
        const val SETTLE_MS = 1_000L
        const val BYTES_PER_MB = 1024L * 1024L
    }
}
