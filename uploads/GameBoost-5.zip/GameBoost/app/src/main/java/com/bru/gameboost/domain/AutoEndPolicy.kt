package com.bru.gameboost.domain

/**
 * Decides, tick by tick, whether a boost session should end on its own.
 * A pure state machine with no Android types, so the rules can be read —
 * and tested — in isolation from the service that drives it.
 *
 * Three situations, each with its own patience:
 *  - the game hasn't reached the front yet (slow cold start on a 4 GB phone),
 *  - the game was in front and the user has since gone elsewhere,
 *  - the screen is off or locked (the game is paused, so absence proves nothing).
 */
class AutoEndPolicy(
    private val gamePackage: String,
    private val launchGraceTicks: Int = DEFAULT_LAUNCH_GRACE_TICKS,
    private val awayTicksToEnd: Int = DEFAULT_AWAY_TICKS,
    private val idleScreenTicksToEnd: Int = DEFAULT_IDLE_SCREEN_TICKS
) {
    enum class Verdict { KEEP, END }

    private var seenInFront = false
    private var launchTicks = 0
    private var awayTicks = 0
    private var idleScreenTicks = 0

    /**
     * @param foregroundPackage the package usage events say is in front, null if unknown
     * @param canObserveForeground false when Usage Access is missing; then only the screen rule applies
     * @param userPresent screen on and unlocked
     */
    fun onTick(
        foregroundPackage: String?,
        canObserveForeground: Boolean,
        userPresent: Boolean
    ): Verdict {
        if (!userPresent) {
            idleScreenTicks++
            return if (idleScreenTicks >= idleScreenTicksToEnd) Verdict.END else Verdict.KEEP
        }
        idleScreenTicks = 0

        if (!canObserveForeground) return Verdict.KEEP // manual-end only, apart from the screen rule above

        if (foregroundPackage == gamePackage) {
            seenInFront = true
            awayTicks = 0
            return Verdict.KEEP
        }

        return if (seenInFront) {
            awayTicks++
            if (awayTicks >= awayTicksToEnd) Verdict.END else Verdict.KEEP
        } else {
            launchTicks++
            if (launchTicks >= launchGraceTicks) Verdict.END else Verdict.KEEP
        }
    }

    // Tick counts, not durations: the service polls every 5 s.
    companion object {
        const val DEFAULT_LAUNCH_GRACE_TICKS = 9 // ~45 s for the game to show up
        const val DEFAULT_AWAY_TICKS = 3 // ~15 s out of the game
        const val DEFAULT_IDLE_SCREEN_TICKS = 24 // ~2 min of dark or locked screen
    }
}
