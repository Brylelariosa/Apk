package com.bru.gameboost.presentation.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

private const val PULSE_PERIOD_MS = 2200
private const val RING_COUNT = 3

/**
 * Rings that expand and fade, one after another — the "something is working" look for a boost.
 * The phase is read while drawing, so the animation redraws the canvas but never recomposes.
 */
@Composable
fun BoostPulse(
    modifier: Modifier = Modifier,
    color: Color = MaterialTheme.colorScheme.primary
) {
    val transition = rememberInfiniteTransition(label = "boostPulse")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = PULSE_PERIOD_MS, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulsePhase"
    )

    Canvas(modifier = modifier) {
        val maxRadius = size.minDimension / 2f
        val strokeWidth = 2.5.dp.toPx()
        for (ring in 0 until RING_COUNT) {
            val t = (phase + ring.toFloat() / RING_COUNT) % 1f
            drawCircle(
                color = color,
                radius = maxRadius * (0.38f + 0.62f * t),
                alpha = (1f - t) * 0.55f,
                style = Stroke(width = strokeWidth)
            )
        }
    }
}

/** A lightning bolt drawn as a path: no icon asset, and no icon-set version to keep in step. */
@Composable
fun BoltMark(
    modifier: Modifier = Modifier,
    color: Color = MaterialTheme.colorScheme.primary
) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val bolt = Path().apply {
            moveTo(w * 0.60f, h * 0.04f)
            lineTo(w * 0.20f, h * 0.56f)
            lineTo(w * 0.46f, h * 0.56f)
            lineTo(w * 0.38f, h * 0.96f)
            lineTo(w * 0.80f, h * 0.40f)
            lineTo(w * 0.54f, h * 0.40f)
            close()
        }
        drawPath(path = bolt, color = color)
    }
}

/** A small dot that breathes; marks a live, running state. */
@Composable
fun PulsingDot(
    modifier: Modifier = Modifier,
    color: Color = MaterialTheme.colorScheme.primary
) {
    val transition = rememberInfiniteTransition(label = "dot")
    val dotAlpha by transition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 900),
            repeatMode = RepeatMode.Reverse
        ),
        label = "dotAlpha"
    )

    Canvas(modifier = modifier.size(8.dp)) {
        drawCircle(color = color, alpha = dotAlpha)
    }
}
