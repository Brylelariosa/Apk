package com.bru.gameboost.data

import android.app.NotificationManager
import android.content.Context
import androidx.core.content.edit
import com.bru.gameboost.domain.DndController

/**
 * Uses PRIORITY (not NONE/total-silence) as the boosted filter, so the
 * user's own priority-only exceptions — alarms, starred contacts — still
 * come through.
 *
 * The filter that was active before boosting is written to disk *before* it is
 * changed. A heavy game can push a 4 GB phone hard enough for the system to
 * kill this process mid-session; with the marker on disk, the next app start
 * ([revertBoost] is called from Application.onCreate) can still put Do Not
 * Disturb back the way the user had it.
 */
class DndControllerImpl(context: Context) : DndController {

    private val notificationManager =
        context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    // Its own file, deliberately apart from gameboost_prefs: this marker only means
    // something on the install that wrote it.
    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    override fun isAccessGranted(): Boolean = notificationManager.isNotificationPolicyAccessGranted

    @Synchronized
    override fun applyBoost() {
        if (!isAccessGranted()) return
        if (prefs.contains(KEY_PREVIOUS_FILTER)) return // already boosting — keep the original filter

        val current = notificationManager.currentInterruptionFilter
        // Only ever tighten: if the user already runs a stricter mode, leave it be.
        if (current != NotificationManager.INTERRUPTION_FILTER_ALL &&
            current != NotificationManager.INTERRUPTION_FILTER_UNKNOWN
        ) return

        prefs.edit(commit = true) { putInt(KEY_PREVIOUS_FILTER, current) }
        runCatching {
            notificationManager.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
        }
    }

    /** Idempotent: does nothing unless a boost is recorded as applied. */
    @Synchronized
    override fun revertBoost() {
        if (!prefs.contains(KEY_PREVIOUS_FILTER)) return

        val stored = prefs.getInt(KEY_PREVIOUS_FILTER, NotificationManager.INTERRUPTION_FILTER_ALL)
        val toRestore = if (stored == NotificationManager.INTERRUPTION_FILTER_UNKNOWN) {
            NotificationManager.INTERRUPTION_FILTER_ALL
        } else {
            stored
        }

        if (isAccessGranted()) {
            runCatching { notificationManager.setInterruptionFilter(toRestore) }
        }
        prefs.edit(commit = true) { remove(KEY_PREVIOUS_FILTER) }
    }

    private companion object {
        const val PREFS_NAME = "gameboost_dnd"
        const val KEY_PREVIOUS_FILTER = "previous_filter"
    }
}
