package com.bru.gameboost.presentation.components

import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.bru.gameboost.domain.model.BoostSessionState
import com.bru.gameboost.domain.model.BoostStage
import com.bru.gameboost.presentation.SnapshotFormatter

private enum class StepStatus { DONE, RUNNING, PENDING }

private fun statusOf(current: BoostStage, step: BoostStage): StepStatus = when {
    current.ordinal > step.ordinal -> StepStatus.DONE
    current == step -> StepStatus.RUNNING
    else -> StepStatus.PENDING
}

/**
 * Full-screen "boosting" sequence shown while the service works through its stages. The checklist
 * mirrors what is really happening (stage by stage), and steps the user switched off or that
 * can't run (no DND access) are left out rather than faked.
 */
@Composable
fun BoostingOverlay(
    state: BoostSessionState.Active,
    showSilenceStep: Boolean,
    showCleanStep: Boolean,
    loadIcon: IconLoader,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.84f))
            // Swallow touches while the sequence runs, so nothing underneath can be tapped.
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = {}
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(32.dp)
        ) {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.size(240.dp)) {
                BoostPulse(modifier = Modifier.fillMaxSize())
                AppIcon(packageName = state.game.packageName, loadIcon = loadIcon, size = 76.dp)
            }

            Text(
                text = "Boosting ${state.game.label}",
                style = MaterialTheme.typography.titleLarge,
                color = Color.White,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 8.dp)
            )

            Column(
                modifier = Modifier.padding(top = 24.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (showSilenceStep) {
                    StepRow(
                        label = "Silencing notifications",
                        status = statusOf(state.stage, BoostStage.PREPARING)
                    )
                }
                if (showCleanStep) {
                    val cleanStatus = statusOf(state.stage, BoostStage.CLEANING)
                    val cleanResult = state.cleanResult
                    StepRow(
                        label = if (cleanStatus == StepStatus.DONE && cleanResult != null) {
                            SnapshotFormatter.freedShort(cleanResult)
                        } else {
                            "Freeing RAM"
                        },
                        status = cleanStatus
                    )
                }
                val launchStatus = statusOf(state.stage, BoostStage.LAUNCHING)
                StepRow(
                    label = if (launchStatus == StepStatus.DONE) "Game launched" else "Launching game",
                    status = launchStatus
                )
            }
        }
    }
}

@Composable
private fun StepRow(label: String, status: StepStatus) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(modifier = Modifier.size(22.dp), contentAlignment = Alignment.Center) {
            Crossfade(targetState = status, label = "stepStatus") { shown ->
                when (shown) {
                    StepStatus.DONE -> Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    StepStatus.RUNNING -> CircularProgressIndicator(
                        modifier = Modifier.size(18.dp),
                        strokeWidth = 2.dp,
                        color = MaterialTheme.colorScheme.primary
                    )
                    StepStatus.PENDING -> Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.3f))
                    )
                }
            }
        }
        Text(
            text = label,
            style = MaterialTheme.typography.bodyLarge,
            color = Color.White.copy(alpha = if (status == StepStatus.PENDING) 0.55f else 1f),
            modifier = Modifier.padding(start = 12.dp)
        )
    }
}
