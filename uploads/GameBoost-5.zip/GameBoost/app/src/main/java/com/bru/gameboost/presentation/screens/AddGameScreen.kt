package com.bru.gameboost.presentation.screens

import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.bru.gameboost.domain.model.BoostableGame
import com.bru.gameboost.presentation.GameBoostViewModel
import com.bru.gameboost.presentation.components.AppIcon

@OptIn(ExperimentalMaterial3Api::class) // TopAppBar
@Composable
fun AddGameScreen(
    viewModel: GameBoostViewModel,
    onDone: () -> Unit
) {
    var apps by remember { mutableStateOf<List<BoostableGame>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var query by remember { mutableStateOf("") }
    val addedGames by viewModel.addedGames.collectAsStateWithLifecycle()
    val addedPackageNames = remember(addedGames) { addedGames.map { it.packageName }.toSet() }
    val loadIcon = viewModel.iconLoader

    LaunchedEffect(Unit) {
        apps = viewModel.queryLaunchableApps()
        loading = false
    }

    val filteredApps = remember(apps, query) {
        if (query.isBlank()) apps else apps.filter { it.label.contains(query, ignoreCase = true) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Add a game") },
                navigationIcon = {
                    IconButton(onClick = onDone) {
                        Icon(Icons.Default.Close, contentDescription = "Done")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("Search installed apps") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            )
            when {
                loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
                filteredApps.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No matching apps", style = MaterialTheme.typography.bodyMedium)
                }
                else -> LazyColumn {
                    items(filteredApps, key = { it.packageName }) { app ->
                        val alreadyAdded = app.packageName in addedPackageNames
                        ListItem(
                            modifier = Modifier.animateItem(),
                            leadingContent = {
                                AppIcon(packageName = app.packageName, loadIcon = loadIcon, size = 44.dp)
                            },
                            headlineContent = {
                                Text(app.label, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            },
                            // The package name tells apart look-alikes (several apps called "Game", say).
                            supportingContent = {
                                Text(
                                    app.packageName,
                                    style = MaterialTheme.typography.bodySmall,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            },
                            trailingContent = {
                                Crossfade(targetState = alreadyAdded, label = "addedState") { added ->
                                    if (added) {
                                        Text(
                                            "Added",
                                            style = MaterialTheme.typography.labelLarge,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    } else {
                                        FilledTonalButton(onClick = { viewModel.addGame(app) }) {
                                            Text("Add")
                                        }
                                    }
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}
