package com.bru.gameboost.domain

import com.bru.gameboost.domain.model.BoostSessionState
import com.bru.gameboost.domain.model.BoostStage
import com.bru.gameboost.domain.model.BoostableGame
import com.bru.gameboost.domain.model.CleanResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/**
 * The single shared source of truth for "is a boost active, and for which
 * game". BoostSessionService writes to it; GameBoostViewModel only reads it —
 * neither class references the other directly, so the service can keep
 * running (and the notification stays authoritative) whether or not an
 * Activity is currently alive to observe it.
 */
class BoostSessionStateHolder {

    private val _state = MutableStateFlow<BoostSessionState>(BoostSessionState.Idle)
    val state: StateFlow<BoostSessionState> = _state.asStateFlow()

    fun setActive(game: BoostableGame) {
        _state.value = BoostSessionState.Active(game)
    }

    /** Moves the running session to its next stage; ignored if the session already ended. */
    fun setStage(stage: BoostStage) {
        _state.update { current ->
            if (current is BoostSessionState.Active) current.copy(stage = stage) else current
        }
    }

    /** Attaches the clean's outcome to the running session; ignored if the session already ended. */
    fun setCleanResult(result: CleanResult) {
        _state.update { current ->
            if (current is BoostSessionState.Active) current.copy(cleanResult = result) else current
        }
    }

    fun setIdle() {
        _state.value = BoostSessionState.Idle
    }
}
