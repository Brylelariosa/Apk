package com.bru.gameboost.presentation.screens

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.bru.gameboost.domain.model.BoostSessionState
import com.bru.gameboost.domain.model.BoostSettings
import com.bru.gameboost.domain.model.BoostStage
import com.bru.gameboost.domain.model.BoostableGame
import com.bru.gameboost.domain.model.DeviceSnapshot
import com.bru.gameboost.domain.model.PermissionState
import com.bru.gameboost.presentation.GameBoostViewModel
import com.bru.gameboost.presentation.RamCleanState
import com.bru.gameboost.presentation.SnapshotFormatter
import com.bru.gameboost.presentation.components.AppIcon
import com.bru.gameboost.presentation.components.BoltMark
import com.bru.gameboost.presentation.components.BoostPulse
import com.bru.gameboost.presentation.components.BoostingOverlay
import com.bru.gameboost.presentation.components.IconLoader
import com.bru.gameboost.presentation.components.PulsingDot
import com.bru.gameboost.presentation.components.StatBar
import kotlin.math.roundToInt

// The FAB (56 dp + margins) floats over the bottom-right corner, exactly where the last
// row's Boost/Remove buttons sit. Without this much room under the list they're unreachable.
private val FabClearance = 88.dp

// One slider stop per whole degree between the alert bounds.
private val OverheatSliderSteps =
    (BoostSettings.MAX_OVERHEAT_ALERT_C - BoostSettings.MIN_OVERHEAT_ALERT_C).roundToInt() - 1

// The temperature meter spans a realistic phone range; amber starts a few degrees before the alert.
private const val TEMP_BAR_MIN_C = 25f
private const val TEMP_BAR_MAX_C = 50f
private const val WARM_MARGIN_C = 3f
private val WarmColor = Color(0xFFFFB300)

@OptIn(ExperimentalMaterial3Api::class) // TopAppBar
@Composable
fun GamePickerScreen(
    viewModel: GameBoostViewModel,
    onAddGameClick: () -> Unit
) {
    val context = LocalContext.current
    val games by viewModel.addedGames.collectAsStateWithLifecycle()
    val permissionState by viewModel.permissionState.collectAsStateWithLifecycle()
    val sessionState by viewModel.sessionState.collectAsStateWithLifecycle()
    val snapshot by viewModel.deviceSnapshot.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val ramClean by viewModel.ramClean.collectAsStateWithLifecycle()
    val loadIcon = viewModel.iconLoader

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { viewModel.refreshPermissionState() }

    val activeState = sessionState as? BoostSessionState.Active
    // Only steps that will really happen: DND needs its access grant as well as the switch.
    val showSilenceStep = settings.silenceNotifications && permissionState.notificationPolicyAccessGranted
    val showCleanStep = settings.freeRamOnBoost
    // The sequence overlay covers only the start-up stages, and only when there is something to
    // show: with both optional steps off the launch is instant and a flash of dimming would just look glitchy.
    val overlayVisible = activeState != null &&
        activeState.stage != BoostStage.ACTIVE &&
        (showSilenceStep || showCleanStep)

    Box(modifier = Modifier.fillMaxSize()) {
        Scaffold(
            topBar = { TopAppBar(title = { Text("GameBoost") }) },
            floatingActionButton = {
                FloatingActionButton(onClick = onAddGameClick) {
                    Icon(Icons.Default.Add, contentDescription = "Add game")
                }
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentPadding = PaddingValues(start = 16.dp, top = 8.dp, end = 16.dp, bottom = FabClearance),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (activeState != null) {
                    item(key = "active") {
                        ActiveSessionCard(
                            state = activeState,
                            loadIcon = loadIcon,
                            onEndBoost = viewModel::endBoost,
                            modifier = Modifier.animateItem()
                        )
                    }
                }

                item(key = "stats") {
                    DeviceStatsCard(
                        snapshot = snapshot,
                        alertAtC = settings.overheatAlertC,
                        ramClean = ramClean,
                        onFreeRam = viewModel::freeRamNow,
                        onOpenBatterySaver = {
                            context.openSettings(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS))
                        },
                        modifier = Modifier.animateItem()
                    )
                }

                if (!permissionState.allGranted) {
                    item(key = "permissions") {
                        PermissionsCard(
                            state = permissionState,
                            onRequestNotifications = {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                    notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                } else {
                                    // No runtime prompt exists before Android 13; the switch lives in Settings.
                                    context.openNotificationSettings()
                                }
                            },
                            onOpenDndSettings = {
                                context.openSettings(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                            },
                            onOpenUsageSettings = { context.openUsageAccessSettings() },
                            modifier = Modifier.animateItem()
                        )
                    }
                }

                if (games.isEmpty()) {
                    item(key = "empty") {
                        EmptyGamesHint(onAddGameClick = onAddGameClick, modifier = Modifier.animateItem())
                    }
                } else {
                    item(key = "games_header") {
                        Text(
                            "Your games",
                            style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier
                                .animateItem()
                                .padding(start = 4.dp, top = 4.dp)
                        )
                    }
                    items(games, key = { it.packageName }) { game ->
                        GameRow(
                            game = game,
                            isBoosting = game.packageName == activeState?.game?.packageName,
                            loadIcon = loadIcon,
                            onBoostClick = { viewModel.boostAndLaunch(game) },
                            onRemoveClick = { viewModel.removeGame(game.packageName) },
                            modifier = Modifier.animateItem()
                        )
                    }
                }

                item(key = "options") {
                    BoostOptionsCard(
                        settings = settings,
                        onSilenceNotificationsChange = viewModel::setSilenceNotifications,
                        onFreeRamChange = viewModel::setFreeRamOnBoost,
                        onOverheatAlertChange = viewModel::setOverheatAlertC,
                        modifier = Modifier.animateItem()
                    )
                }
            }
        }

        AnimatedVisibility(
            visible = overlayVisible,
            enter = fadeIn(animationSpec = tween(160)),
            exit = fadeOut(animationSpec = tween(260))
        ) {
            if (activeState != null) {
                BoostingOverlay(
                    state = activeState,
                    showSilenceStep = showSilenceStep,
                    showCleanStep = showCleanStep,
                    loadIcon = loadIcon
                )
            }
        }
    }
}

private val PermissionState.allGranted: Boolean
    get() = notificationPolicyAccessGranted && usageAccessGranted && notificationsEnabled

@Composable
private fun DeviceStatsCard(
    snapshot: DeviceSnapshot?,
    alertAtC: Float,
    ramClean: RamCleanState,
    onFreeRam: () -> Unit,
    onOpenBatterySaver: () -> Unit,
    modifier: Modifier = Modifier
) {
    val usedMb = snapshot?.ramUsedMb
    val totalMb = snapshot?.ramTotalMb
    val ramFraction = if (usedMb != null && totalMb != null && totalMb > 0) usedMb.toFloat() / totalMb else null
    val cpuFraction = snapshot?.cpuLoadPercent?.let { it / 100f }
    val tempC = snapshot?.batteryTempC
    val tempFraction = tempC?.let { (it - TEMP_BAR_MIN_C) / (TEMP_BAR_MAX_C - TEMP_BAR_MIN_C) }
    val tempColor = when {
        tempC != null && tempC >= alertAtC -> MaterialTheme.colorScheme.error
        tempC != null && tempC >= alertAtC - WARM_MARGIN_C -> WarmColor
        else -> MaterialTheme.colorScheme.primary
    }

    val lastClean = ramClean.last
    val cleanLine = when {
        ramClean.running -> "Closing cached background apps…"
        lastClean != null -> SnapshotFormatter.cleanSummary(lastClean)
        else -> "Closes cached background apps to free memory."
    }

    Card(modifier = modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("This device right now", style = MaterialTheme.typography.titleMedium)

            if (snapshot == null) {
                Text("Reading…", style = MaterialTheme.typography.bodyMedium)
            } else {
                StatBar("CPU", SnapshotFormatter.cpu(snapshot), cpuFraction)
                StatBar("RAM", SnapshotFormatter.ram(snapshot), ramFraction)
                StatBar(
                    "Battery temp",
                    tempC?.let { SnapshotFormatter.temperature(it) } ?: "—",
                    tempFraction,
                    barColor = tempColor
                )
                Text(
                    listOfNotNull(
                        "Battery ${SnapshotFormatter.battery(snapshot)}",
                        SnapshotFormatter.throttling(snapshot)
                    ).joinToString(" · "),
                    style = MaterialTheme.typography.bodySmall
                )
            }

            if (snapshot?.powerSaveMode == true) {
                TextWithAction(
                    text = "Battery Saver is on — it can limit performance while you play.",
                    actionLabel = "Settings",
                    onAction = onOpenBatterySaver
                )
            }

            TextWithAction(
                text = cleanLine,
                actionLabel = "Free RAM",
                onAction = onFreeRam,
                actionEnabled = !ramClean.running
            )
        }
    }
}

@Composable
private fun ActiveSessionCard(
    state: BoostSessionState.Active,
    loadIcon: IconLoader,
    onEndBoost: () -> Unit,
    modifier: Modifier = Modifier
) {
    val cleanResult = state.cleanResult
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer,
            contentColor = MaterialTheme.colorScheme.onPrimaryContainer
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.size(80.dp)) {
                BoostPulse(modifier = Modifier.fillMaxSize())
                AppIcon(packageName = state.game.packageName, loadIcon = loadIcon, size = 44.dp)
            }
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    PulsingDot()
                    Text(
                        "BOOST ACTIVE",
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(start = 6.dp)
                    )
                }
                Text(
                    state.game.label,
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (cleanResult != null) {
                    Text(
                        SnapshotFormatter.cleanSummary(cleanResult),
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
            Button(onClick = onEndBoost) { Text("End") }
        }
    }
}

@Composable
private fun GameRow(
    game: BoostableGame,
    isBoosting: Boolean,
    loadIcon: IconLoader,
    onBoostClick: () -> Unit,
    onRemoveClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AppIcon(packageName = game.packageName, loadIcon = loadIcon, size = 48.dp)

            // weight(1f): a long title wraps or truncates instead of squeezing the buttons off the card.
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 12.dp)
            ) {
                Text(
                    game.label,
                    style = MaterialTheme.typography.bodyLarge,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (isBoosting) {
                        PulsingDot()
                        Spacer(Modifier.width(6.dp))
                    }
                    Text(
                        if (isBoosting) "Boosting now" else game.packageName,
                        style = MaterialTheme.typography.bodySmall,
                        color = if (isBoosting) {
                            MaterialTheme.colorScheme.primary
                        } else {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        },
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Button(
                onClick = onBoostClick,
                enabled = !isBoosting,
                contentPadding = PaddingValues(horizontal = 14.dp)
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(4.dp))
                Text("Boost")
            }
            IconButton(onClick = onRemoveClick) {
                Icon(Icons.Default.Delete, contentDescription = "Remove ${game.label}")
            }
        }
    }
}

@Composable
private fun PermissionsCard(
    state: PermissionState,
    onRequestNotifications: () -> Unit,
    onOpenDndSettings: () -> Unit,
    onOpenUsageSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text("A few permissions unlock more of this", style = MaterialTheme.typography.titleMedium)
            Text(
                "Everything works without them too — boosting just does less.",
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(top = 2.dp, bottom = 8.dp)
            )
            if (!state.notificationsEnabled) {
                PermissionRow("Show the live boost notification", onRequestNotifications)
            }
            if (!state.notificationPolicyAccessGranted) {
                PermissionRow("Do Not Disturb access (silences alerts while boosting)", onOpenDndSettings)
            }
            if (!state.usageAccessGranted) {
                PermissionRow("Usage access (ends the boost automatically when you quit)", onOpenUsageSettings)
            }
        }
    }
}

@Composable
private fun PermissionRow(label: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            label,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier
                .weight(1f)
                .padding(end = 8.dp)
        )
        TextButton(onClick = onClick) { Text("Grant") }
    }
}

@Composable
private fun BoostOptionsCard(
    settings: BoostSettings,
    onSilenceNotificationsChange: (Boolean) -> Unit,
    onFreeRamChange: (Boolean) -> Unit,
    onOverheatAlertChange: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(modifier = modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text("When boosting", style = MaterialTheme.typography.titleMedium)
            SwitchRow(
                label = "Silence notifications (Do Not Disturb)",
                checked = settings.silenceNotifications,
                onCheckedChange = onSilenceNotificationsChange
            )
            SwitchRow(
                label = "Free RAM first (closes cached background apps)",
                checked = settings.freeRamOnBoost,
                onCheckedChange = onFreeRamChange
            )
            Text(
                "Overheat alert at ${settings.overheatAlertC.roundToInt()}°C",
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(top = 12.dp)
            )
            Slider(
                value = settings.overheatAlertC,
                onValueChange = onOverheatAlertChange,
                valueRange = BoostSettings.MIN_OVERHEAT_ALERT_C..BoostSettings.MAX_OVERHEAT_ALERT_C,
                steps = OverheatSliderSteps
            )
            Text(
                "Battery temperature at which GameBoost warns you while boosting.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            label,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier
                .weight(1f)
                .padding(end = 12.dp)
        )
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

/** Small explanatory text with one action on the right; the text yields space to the button, not the reverse. */
@Composable
private fun TextWithAction(
    text: String,
    actionLabel: String,
    onAction: () -> Unit,
    modifier: Modifier = Modifier,
    actionEnabled: Boolean = true
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text,
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier
                .weight(1f)
                .padding(end = 8.dp)
        )
        TextButton(onClick = onAction, enabled = actionEnabled) { Text(actionLabel) }
    }
}

@Composable
private fun EmptyGamesHint(onAddGameClick: () -> Unit, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        BoltMark(modifier = Modifier.size(56.dp))
        Text(
            "No games added yet",
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(top = 12.dp)
        )
        Text(
            "Pick one from your installed apps. GameBoost frees RAM, silences alerts and watches the heat while you play.",
            style = MaterialTheme.typography.bodyMedium,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 4.dp)
        )
        Button(onClick = onAddGameClick, modifier = Modifier.padding(top = 16.dp)) {
            Text("Add a game")
        }
    }
}

/** Settings screens differ by OEM; a missing one should do nothing rather than crash the app. */
private fun Context.openSettings(intent: Intent) {
    runCatching { startActivity(intent) }
}

private fun Context.openUsageAccessSettings() {
    // Android 10+ can jump straight to this app's toggle; fall back to the full list where that isn't honored.
    val forThisApp = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS, Uri.fromParts("package", packageName, null))
    if (runCatching { startActivity(forThisApp) }.isFailure) {
        openSettings(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
    }
}

private fun Context.openNotificationSettings() {
    openSettings(
        Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
    )
}
