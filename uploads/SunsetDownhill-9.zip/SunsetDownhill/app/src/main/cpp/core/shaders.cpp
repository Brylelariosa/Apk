#include "shaders.h"

namespace sd {
namespace shaders {
namespace {

const char* kVersion = "#version 300 es\n";
const char* kFragPrecision = "precision highp float;\nprecision highp int;\n";

// ---------------------------------------------------------------------------------------
const char* kNoise = R"GLSL(
float hash12(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}
float vnoise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = hash12(i);
    float b = hash12(i + vec2(1.0, 0.0));
    float c = hash12(i + vec2(0.0, 1.0));
    float d = hash12(i + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}
float fbm(vec2 p) {
    float a = 0.5;
    float s = 0.0;
    for (int i = 0; i < 4; ++i) {
        s += a * vnoise(p);
        p = p * 2.03 + 17.1;
        a *= 0.5;
    }
    return s;
}
)GLSL";

// Lighting uniforms + helpers shared by terrain and mesh fragment shaders.
const char* kLit = R"GLSL(
uniform vec3 u_sunDir;
uniform vec3 u_sunColor;
uniform vec3 u_ambSky;
uniform vec3 u_ambGround;
uniform vec3 u_fogColor;
uniform vec3 u_fogSun;
uniform float u_fogDensity;
uniform float u_time;
uniform float u_shadowOn;
uniform vec2 u_shadowTexel;
uniform highp sampler2DShadow u_shadowMap;

vec3 fogColorDir(vec3 dir) {
    float s = clamp(dot(dir, u_sunDir), 0.0, 1.0);
    return mix(u_fogColor, u_fogSun, pow(s, 3.0));
}
vec3 finishColor(vec3 c) {
    return 1.0 - exp(-c * 1.25);
}
// sc is already in [0,1] shadow-map space (bias matrix baked into u_shadowMat).
float shadowFactor(vec4 sc) {
    if (u_shadowOn < 0.5) return 1.0;
    vec3 p = sc.xyz / sc.w;
    vec2 e = abs(p.xy - 0.5) * 2.0;
    float fade = 1.0 - smoothstep(0.78, 1.0, max(e.x, e.y));
    if (p.z >= 1.0 || fade <= 0.0) return 1.0;
    float bias = 0.0006;
    float s = 0.0;
    s += texture(u_shadowMap, vec3(p.xy + vec2(-0.75, -0.25) * u_shadowTexel, p.z - bias));
    s += texture(u_shadowMap, vec3(p.xy + vec2( 0.25, -0.75) * u_shadowTexel, p.z - bias));
    s += texture(u_shadowMap, vec3(p.xy + vec2( 0.75,  0.25) * u_shadowTexel, p.z - bias));
    s += texture(u_shadowMap, vec3(p.xy + vec2(-0.25,  0.75) * u_shadowTexel, p.z - bias));
    return mix(1.0, s * 0.25, fade);
}
)GLSL";

// Per-instance transform; with disabled instance arrays the constants give an identity transform.
const char* kInstance = R"GLSL(
layout(location = 0) in vec3 a_pos;
layout(location = 1) in vec3 a_nrm;
layout(location = 2) in vec4 a_col;
layout(location = 3) in vec4 a_mat;
layout(location = 4) in vec4 i_posYaw;
layout(location = 5) in vec4 i_scale;
layout(location = 6) in vec4 i_tint;
uniform float u_time;
uniform float u_swayAmp;   // how far the wind pushes the parts that move (per batch: trees sway a little, grass a lot)

void instanceTransform(out vec3 wpos, out vec3 wnrm) {
    float cy = cos(i_posYaw.w);
    float sy = sin(i_posYaw.w);
    float ca = cos(-i_scale.w);
    float sa = sin(-i_scale.w);
    vec3 p = a_pos * vec3(i_scale.x, i_scale.y, i_scale.x);
    float h = a_pos.y * i_scale.y;
    float sway = a_mat.w * (sin(u_time * 1.4 + i_scale.z) + 0.5 * sin(u_time * 2.3 + i_scale.z * 1.7)) * u_swayAmp * h;
    p.x += sway;
    vec3 n = a_nrm;
    p = vec3(p.x, ca * p.y - sa * p.z, sa * p.y + ca * p.z);
    n = vec3(n.x, ca * n.y - sa * n.z, sa * n.y + ca * n.z);
    p = vec3(cy * p.x - sy * p.z, p.y, sy * p.x + cy * p.z);
    n = vec3(cy * n.x - sy * n.z, n.y, sy * n.x + cy * n.z);
    wpos = i_posYaw.xyz + p;
    wnrm = n;
}
)GLSL";

}  // namespace

// ---------------------------------------------------------------------------------------
// Sky
// ---------------------------------------------------------------------------------------
std::string skyVertex() {
    return std::string(kVersion) + R"GLSL(
out vec2 v_ndc;
void main() {
    vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));
    v_ndc = p * 2.0 - 1.0;
    gl_Position = vec4(v_ndc, 1.0, 1.0);
}
)GLSL";
}

std::string skyFragment() {
    return std::string(kVersion) + kFragPrecision + kNoise + R"GLSL(
uniform vec3 u_camRight;
uniform vec3 u_camUp;
uniform vec3 u_camFwd;
uniform vec2 u_tanFov;
uniform float u_time;
uniform vec3 u_sunDir;
uniform vec3 u_sunColor;
uniform vec3 u_skyTop;
uniform vec3 u_skyMid;
uniform vec3 u_fogColor;
uniform vec3 u_fogSun;
uniform vec3 u_cloudLit;
uniform vec3 u_cloudShade;
uniform vec3 u_mtnNear;
uniform vec3 u_mtnFar;
in vec2 v_ndc;
out vec4 o_col;

vec3 hazeDir(vec3 dir) {
    float s = clamp(dot(dir, u_sunDir), 0.0, 1.0);
    return mix(u_fogColor, u_fogSun, pow(s, 3.0));
}

// Height of the horizon ranges (the elevation of the ridge line, as rd.y) in the direction q, a point on the unit circle. Range 0 is the far, tall
// alpine one, range 1 the middle one, range 2 the near, rolling, forested hills. The crests are ridged noise in three octaves: jagged like rock.
float ridged(vec2 p) { return 1.0 - abs(2.0 * vnoise(p) - 1.0); }
float ridgeAt(vec2 q, int i) {
    float fi = float(i);
    vec2 o = vec2(fi * 31.7, fi * 11.3);
    float env = vnoise(q * (1.4 + 0.7 * fi) + o);                         // where the big mountains stand
    float f = 7.0 + 3.0 * fi;
    float r = 0.58 * ridged(q * f + o) + 0.30 * ridged(q * (f * 2.3) + o + 4.1) + 0.12 * ridged(q * (f * 5.2) + o + 9.7);
    if (i == 0) return 0.100 + 0.320 * smoothstep(0.12, 0.62, env) * (0.28 + 0.72 * r);   // (never lower than 6 degrees: there are always mountains)
    if (i == 1) return 0.055 + 0.180 * smoothstep(0.15, 0.70, env) * (0.30 + 0.70 * r);
    return 0.022 + 0.085 * env + 0.020 * r;
}

// The three ranges, far to near: snow-capped peaks lit on the side that faces the sun, valley mist at their feet, forested hills in front.
vec3 mountains(vec3 rd, vec3 col, vec3 haze) {
    float el = rd.y;
    float aa = fwidth(el) * 0.9 + 0.0004;   // (before the early out: derivatives are only defined where every pixel of the quad gets here)
    if (el > 0.42) return col;              // above every ridge: most of the sky never gets here
    vec2 q = normalize(rd.xz + vec2(1e-5));
    vec2 sunXZ = normalize(u_sunDir.xz + vec2(1e-5));
    float lat = dot(sunXZ, normalize(u_camRight.xz + vec2(1e-5)));       // the sun to the right (+) or to the left (-) of the view
    float toward = clamp(dot(q, sunXZ), 0.0, 1.0);
    float h0 = ridgeAt(q, 0), h1 = ridgeAt(q, 1), h2 = ridgeAt(q, 2);
    int first = el < h2 - aa ? 2 : (el < h1 - aa ? 1 : 0);                 // a range that covers the pixel completely hides the ones behind it: skip their shading
    for (int i = first; i < 3; ++i) {
        float fi = float(i);
        float h = i == 0 ? h0 : (i == 1 ? h1 : h2);
        if (el > h + aa) continue;
        float cover = 1.0 - smoothstep(h - aa, h + aa, el);
        float sl = (ridgeAt(q + vec2(-q.y, q.x) * 0.010, i) - h) / 0.010;   // slope of the ridge to the right: it decides which faces the sun lights
        float lit = clamp(0.5 - 0.5 * clamp(sl * lat * 0.35, -1.0, 1.0), 0.0, 1.0);
        float dep = max(h - el, 0.0);                                       // how far below the crest
        vec3 rock = mix(u_mtnNear * 0.95, u_mtnNear * 0.62, fi * 0.5);      // bluish rock, darker toward us: it must stand out from the bright sky
        if (i == 2) rock = mix(rock, vec3(0.09, 0.20, 0.12), 0.75);         // forest
        rock *= 0.90 + 0.20 * vnoise(vec2(q.x * 34.0, el * 70.0) + vec2(fi * 9.0, 2.0));    // gullies and strata
        vec3 mc = rock * (0.58 + 0.62 * lit) + u_sunColor * vec3(1.0, 0.62, 0.48) * rock * (0.55 * lit * (0.35 + toward));
        mc += u_sunColor * vec3(0.55, 0.30, 0.20) * (1.0 - smoothstep(0.0, 0.020, dep)) * toward * toward * 0.35;   // a glowing crest against the sun
        if (i < 2) {   // snow above a ragged snow line, on the high peaks only
            float line = h - (0.034 + 0.050 * vnoise(q * 31.0 + vec2(fi * 3.7, 1.3))) * (1.25 - 0.45 * fi);
            float snow = smoothstep(line - 0.004, line + 0.014, el) * smoothstep(0.13 - 0.04 * fi, 0.24 - 0.06 * fi, h);
            vec3 snowCol = mix(vec3(0.42, 0.42, 0.72), u_sunColor * vec3(0.80, 0.68, 0.64) + vec3(0.22, 0.20, 0.24), lit);
            mc = mix(mc, mix(snowCol, haze, 0.10), snow * 0.95);
        }
        float mist = 0.14 - 0.05 * fi + 0.32 * (1.0 - smoothstep(0.0, h, el));   // farther ranges are hazier, and every range fades into mist at its foot
        mc = mix(mc, haze, clamp(mist, 0.0, 0.9));
        col = mix(col, mc, cover);
    }
    return col;
}

void main() {
    vec3 rd = normalize(u_camFwd + u_camRight * (v_ndc.x * u_tanFov.x) + u_camUp * (v_ndc.y * u_tanFov.y));
    float el = rd.y;
    float sd = clamp(dot(rd, u_sunDir), 0.0, 1.0);
    vec3 haze = hazeDir(rd);
    if (el < -0.036) {   // below the horizon the sky is pure haze; the terrain covers most of it anyway
        o_col = vec4(1.0 - exp(-haze * 1.25), 1.0);
        return;
    }

    vec3 col = mix(haze, u_skyMid, smoothstep(0.0, 0.30, el));
    col = mix(col, u_skyTop, smoothstep(0.12, 0.85, el));

    // sun glow and disc
    col += u_sunColor * (pow(sd, 6.0) * 0.17 + pow(sd, 80.0) * 0.42);
    col = mix(col, vec3(1.45, 1.05, 0.72), smoothstep(0.99964, 0.99986, sd));

    // layered clouds, lit from the low sun
    if (el > 0.005) {
        vec2 cuv = rd.xz / (el + 0.10);
        float cn = fbm(cuv * vec2(0.42, 0.95) + vec2(u_time * 0.006, 3.0));
        float cov = smoothstep(0.50, 0.80, cn) * smoothstep(0.005, 0.12, el);
        float sunSide = pow(clamp(dot(normalize(rd.xz + vec2(1e-5)), normalize(u_sunDir.xz + vec2(1e-5))) * 0.5 + 0.5, 0.0, 1.0), 2.0);
        float thick = smoothstep(0.55, 0.95, cn);
        vec3 cc = mix(u_cloudShade, u_cloudLit, clamp(sunSide * (1.15 - 0.55 * thick), 0.0, 1.0));
        cc = mix(cc, vec3(1.25, 0.82, 0.70), pow(sd, 10.0) * 0.45 * (1.0 - thick));
        col = mix(col, cc, cov * 0.88);
    }

    col = mountains(rd, col, haze);

    // below the horizon: atmospheric haze (the terrain mesh covers most of this)
    col = mix(col, haze, 1.0 - smoothstep(-0.035, 0.015, el));

    o_col = vec4(1.0 - exp(-col * 1.25), 1.0);
}
)GLSL";
}

// ---------------------------------------------------------------------------------------
// Terrain / road
// ---------------------------------------------------------------------------------------
std::string terrainVertex() {
    return std::string(kVersion) + R"GLSL(
uniform mat4 u_viewProj;
uniform mat4 u_shadowMat;
layout(location = 0) in vec3 a_pos;
layout(location = 1) in vec3 a_nrm;
layout(location = 2) in vec3 a_surf;
out vec3 v_pos;
out vec3 v_nrm;
out vec3 v_surf;
out vec4 v_sh;
void main() {
    v_pos = a_pos;
    v_nrm = a_nrm;
    v_surf = a_surf;
    v_sh = u_shadowMat * vec4(a_pos + a_nrm * 0.12, 1.0);
    gl_Position = u_viewProj * vec4(a_pos, 1.0);
}
)GLSL";
}

std::string terrainFragment() {
    return std::string(kVersion) + kFragPrecision + kLit + R"GLSL(
in vec3 v_pos;
in vec3 v_nrm;
in vec3 v_surf;
in vec4 v_sh;
out vec4 o_col;

// Four tileable value-noise fields (8 lattice cells per tile, baked and mip-mapped): a texture fetch instead of the hashing the ground used
// to do for every pixel, which was most of the cost of a frame on a slow GPU. tn(p) is the noise at p lattice units.
uniform sampler2D u_noise;
vec4 tn(vec2 p) { return texture(u_noise, p * 0.125); }

float lineMask(float x, float c, float hw, float aa) {
    return 1.0 - smoothstep(hw - aa, hw + aa, abs(x - c));
}

void main() {
    float d = v_surf.x;
    float s = v_surf.y;
    float edge = v_surf.z;
    float ad = abs(d);
    vec3 N = normalize(v_nrm);
    float dist = length(v_pos);
    vec3 V = -v_pos / max(dist, 0.001);
    float detail = 1.0 - smoothstep(50.0, 200.0, dist);
    float near = 1.0 - smoothstep(14.0, 62.0, dist);
    vec2 sd = vec2(s, d);
    float nFine = tn(sd * 1.3).r;
    float nMed = tn(sd * 0.11).g;
    float aa = fwidth(d) * 1.1 + 0.002;

    // asphalt with wheel tracks, worn double-yellow centre line and white edge lines
    vec3 asphalt = vec3(0.140, 0.138, 0.148) + (nFine - 0.5) * 0.05 * detail + (nMed - 0.5) * 0.045;
    float wheel = exp(-pow((ad - 1.75) / 0.6, 2.0));
    asphalt *= 1.0 - 0.22 * wheel;
    // tar seams across the road every 17 m, hairline cracks and patches of newer asphalt: the surface reads as a real worn road
    float seam = 1.0 - smoothstep(0.05, 0.13, fract(s / 17.0) * 17.0);
    float crack = 1.0 - smoothstep(0.0, 0.03, abs(tn(vec2(s * 0.33 + 3.0, d * 0.85)).b - 0.5));
    float repair = smoothstep(0.60, 0.66, tn(vec2(s * 0.045 + 11.0, d * 0.28)).a);
    asphalt *= 1.0 - (0.26 * seam + 0.20 * crack) * detail;
    asphalt *= 1.0 - 0.10 * repair;
    float yellow = max(lineMask(d, -0.16, 0.055, aa), lineMask(d, 0.16, 0.055, aa));
    float white = max(lineMask(d, -3.3, 0.07, aa), lineMask(d, 3.3, 0.07, aa));
    float worn = 0.78 + 0.22 * tn(vec2(s * 0.6, d * 3.0) + 5.0).r;
    asphalt = mix(asphalt, vec3(0.93, 0.70, 0.10), yellow * 0.92 * worn);
    asphalt = mix(asphalt, vec3(0.86), white * 0.88 * worn);

    vec3 gravel = vec3(0.30, 0.265, 0.235) + (nFine - 0.5) * 0.08 * detail;

    // the meadow: dry and green patches, lush clumps, dirt and rock where it is steep or worn, fallen leaves
    vec3 grassDry = vec3(0.58, 0.50, 0.20);
    vec3 grassGreen = vec3(0.25, 0.47, 0.12);
    vec3 grassLush = vec3(0.34, 0.63, 0.15);
    vec3 dirt = vec3(0.30, 0.21, 0.14);
    float grassPatch = tn(sd * 0.04 + 7.0).b;
    vec3 ground = mix(grassGreen, grassDry, smoothstep(0.50, 0.82, grassPatch));
    float tuft = tn(sd * 0.55 + 13.0).g;   // clumps a couple of metres across
    ground = mix(ground, grassLush, smoothstep(0.45, 0.80, tuft) * 0.65 * (1.0 - smoothstep(0.55, 0.85, grassPatch)));
    ground = mix(ground, dirt, smoothstep(0.62, 0.90, nMed * 0.6 + nFine * 0.4) * 0.34);
    vec3 rockC = mix(vec3(0.24, 0.21, 0.21), vec3(0.44, 0.37, 0.32), tn(vec2(s * 0.30, d * 0.05 + 5.0)).a);
    float steep = smoothstep(0.30, 0.52, 1.0 - N.y);
    ground = mix(ground, rockC, steep);
    float litter = smoothstep(0.72, 0.92, tn(sd * 0.85 + 21.0).g);   // fallen autumn leaves
    ground = mix(ground, vec3(0.50, 0.25, 0.07), litter * 0.30 * detail * smoothstep(0.55, 0.85, N.y));
    ground *= 0.88 + 0.24 * nFine * detail;
    // blades: fine streaks along the slope that you only see close to the camera, and gusts of wind that roll across the field
    float blades = tn(vec2(s * 6.0, d * 17.0) + 3.0).a;
    float blades2 = tn(vec2(s * 2.2, d * 7.0) + 9.0).r;
    ground *= 1.0 + ((blades - 0.5) * 0.30 + (blades2 - 0.5) * 0.18) * near * (1.0 - steep);
    float wind = tn(vec2(s * 0.09 + u_time * 0.85, d * 0.13 - u_time * 0.30) + 2.0).r;
    ground *= 0.93 + 0.14 * wind * (1.0 - smoothstep(70.0, 280.0, dist)) * (1.0 - steep);
    ground = mix(ground, dirt * 0.9, (1.0 - smoothstep(5.2, 7.5, ad)) * 0.6);

    float onRoad = 1.0 - smoothstep(3.6 - aa - 0.04, 3.6 + aa + 0.04, ad);
    float onShoulder = 1.0 - smoothstep(5.1, 5.3, ad);
    vec3 albedo = mix(ground, gravel, onShoulder);
    albedo = mix(albedo, asphalt, onRoad);
    // dry asphalt: a faint, broad sheen that only shows where tyres have polished the surface (no mirror-like reflection of the sky)
    float gloss = onRoad * 0.10 * (1.0 - yellow * 0.7 - white * 0.5) * (0.55 + 0.9 * wheel) * (0.75 + 0.5 * nMed);

    // the meadow takes the light softly (the grass lets some through): the hillside that faces away from the low sun stays green instead of going black
    float softness = (1.0 - onShoulder) * (1.0 - onRoad) * (1.0 - steep) * 0.45;
    float ndl = mix(max(dot(N, u_sunDir), 0.0), clamp(dot(N, u_sunDir) * 0.5 + 0.5, 0.0, 1.0), softness);
    float sh = shadowFactor(v_sh);
    vec3 amb = mix(u_ambGround, u_ambSky, N.y * 0.5 + 0.5);
    vec3 col = albedo * (u_sunColor * ndl * sh + amb);

    // soft sun sheen on polished tracks only
    vec3 H = normalize(u_sunDir + V);
    float spec = pow(max(dot(N, H), 0.0), 14.0) * gloss * 0.7 * sh;
    col += u_sunColor * spec;
    // low sun shining through the grass: looking toward it, the meadow glows a little
    float meadow = (1.0 - onShoulder) * smoothstep(0.70, 0.92, N.y) * (1.0 - smoothstep(30.0, 240.0, dist));
    float back = pow(clamp(dot(-V, u_sunDir) * 0.5 + 0.5, 0.0, 1.0), 5.0);
    col += vec3(0.50, 0.46, 0.12) * u_sunColor * back * meadow * (0.05 + 0.10 * blades) * sh;
    // reflective road studs along the centre line (a glint every 10 m)
    float studAlong = fract(s / 10.0) * 10.0 - 5.0;
    float stud = (1.0 - smoothstep(0.045, 0.075, ad)) * (1.0 - smoothstep(0.07, 0.11, abs(studAlong))) * onRoad * (1.0 - smoothstep(60.0, 220.0, dist));
    col += vec3(1.0, 0.82, 0.42) * stud * 0.9;

    float f = 1.0 - exp(-pow(dist * u_fogDensity, 2.0));
    f = max(f, smoothstep(0.55, 1.0, edge));
    col = mix(col, fogColorDir(-V), f);
    o_col = vec4(finishColor(col), 1.0);
}
)GLSL";
}

// ---------------------------------------------------------------------------------------
// Instanced scenery + dynamic mesh
// ---------------------------------------------------------------------------------------
std::string meshVertex() {
    return std::string(kVersion) + kInstance + R"GLSL(
uniform mat4 u_viewProj;
uniform mat4 u_shadowMat;
out vec3 v_pos;
out vec3 v_nrm;
out vec4 v_col;
out vec4 v_mat;
out vec4 v_tint;
out vec4 v_sh;
void main() {
    vec3 wp, wn;
    instanceTransform(wp, wn);
    v_pos = wp;
    v_nrm = wn;
    v_col = a_col;
    v_mat = a_mat;
    v_tint = i_tint;
    v_sh = u_shadowMat * vec4(wp + wn * 0.06, 1.0);
    gl_Position = u_viewProj * vec4(wp, 1.0);
}
)GLSL";
}

std::string meshFragment() {
    return std::string(kVersion) + kFragPrecision + kLit + R"GLSL(
in vec3 v_pos;
in vec3 v_nrm;
in vec4 v_col;
in vec4 v_mat;
in vec4 v_tint;
in vec4 v_sh;
out vec4 o_col;
uniform vec3 u_fill;   // a soft light from the camera's side: set for the riders, zero for the scenery
void main() {
    vec3 N = normalize(v_nrm);
    float dist = length(v_pos);
    vec3 V = -v_pos / max(dist, 0.001);
    vec3 albedo = v_col.rgb * mix(vec3(1.0), v_tint.rgb, v_mat.x);
    float ndl = dot(N, u_sunDir);
    float foliage = v_mat.z;
    float wrap = mix(max(ndl, 0.0), clamp(ndl * 0.5 + 0.5, 0.0, 1.0), foliage * 0.7);
    float sh = shadowFactor(v_sh);
    vec3 amb = mix(u_ambGround, u_ambSky, N.y * 0.5 + 0.5);
    vec3 col = albedo * (u_sunColor * wrap * sh + amb);
    // the low sun is mostly behind the rider, so his back would be lit by the dim ambient only: a wrapped light from the camera's side, a little from above
    col += albedo * u_fill * clamp(dot(N, normalize(V + vec3(0.0, 0.55, 0.0))) * 0.65 + 0.35, 0.0, 1.0);

    // back light: sun behind the object as seen from the camera
    float back = clamp(-dot(V, u_sunDir), 0.0, 1.0);
    float rim = pow(1.0 - clamp(dot(N, V), 0.0, 1.0), 3.0);
    col += u_sunColor * albedo * (back * back) * (foliage * 0.9 + rim * 0.35 * sh);
    col += v_col.rgb * v_mat.y * 2.5;

    // gloss (vertex alpha, 255 = matte): a sun highlight and a hint of sky on metal, paint, urethane and the visor
    float gloss = 1.0 - v_col.a;
    if (gloss > 0.01) {
        vec3 H = normalize(u_sunDir + V);
        float spec = pow(max(dot(N, H), 0.0), 14.0 + 90.0 * gloss) * gloss * sh;
        float fres = pow(1.0 - clamp(dot(N, V), 0.0, 1.0), 3.0);
        col += u_sunColor * spec * 0.9 + fogColorDir(reflect(-V, N)) * fres * gloss * 0.30;
    }

    float f = 1.0 - exp(-pow(dist * u_fogDensity, 2.0));
    f = max(f, v_tint.a);
    col = mix(col, fogColorDir(-V), f);
    o_col = vec4(finishColor(col), 1.0);
}
)GLSL";
}

// ---------------------------------------------------------------------------------------
// Shadow depth pass
// ---------------------------------------------------------------------------------------
std::string shadowVertex() {
    return std::string(kVersion) + kInstance + R"GLSL(
uniform mat4 u_lightVP;
void main() {
    vec3 wp, wn;
    instanceTransform(wp, wn);
    gl_Position = u_lightVP * vec4(wp, 1.0);
}
)GLSL";
}

std::string shadowFragment() {
    return std::string(kVersion) + "precision mediump float;\nvoid main() {}\n";
}

// ---------------------------------------------------------------------------------------
// Particles
// ---------------------------------------------------------------------------------------
std::string particleVertex() {
    return std::string(kVersion) + R"GLSL(
uniform mat4 u_view;
uniform mat4 u_proj;
layout(location = 0) in vec2 a_corner;
layout(location = 1) in vec4 i_posSize;
layout(location = 2) in vec4 i_color;
layout(location = 3) in vec3 i_vel;
out vec2 v_uv;
out vec4 v_color;
void main() {
    vec3 vp = (u_view * vec4(i_posSize.xyz, 1.0)).xyz;
    vec3 vv = (u_view * vec4(i_vel, 0.0)).xyz;
    float vl = length(vv.xy);
    vec2 off = a_corner * i_posSize.w;
    if (vl > 0.01) {
        vec2 ax = vv.xy / vl;
        vec2 ay = vec2(-ax.y, ax.x);
        float len = i_posSize.w * (1.0 + vl * 0.09);
        off = ax * a_corner.x * len + ay * a_corner.y * i_posSize.w;
    }
    vp.xy += off;
    gl_Position = u_proj * vec4(vp, 1.0);
    v_uv = a_corner;
    v_color = i_color;
}
)GLSL";
}

std::string particleFragment() {
    return std::string(kVersion) + kFragPrecision + R"GLSL(
uniform vec3 u_light;
uniform float u_additive;
in vec2 v_uv;
in vec4 v_color;
out vec4 o_col;
void main() {
    float d = length(v_uv);
    float a = 1.0 - smoothstep(0.25, 1.0, d);
    if (a <= 0.003) discard;
    vec3 rgb = mix(v_color.rgb * u_light, v_color.rgb * 2.2, u_additive);
    o_col = vec4(1.0 - exp(-rgb * 1.25), v_color.a * a);
}
)GLSL";
}

// ---------------------------------------------------------------------------------------
// Post processing
// ---------------------------------------------------------------------------------------
std::string postVertex() {
    return std::string(kVersion) + R"GLSL(
out vec2 v_uv;
void main() {
    vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));
    v_uv = p;
    gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);
}
)GLSL";
}

std::string postFragment() {
    return std::string(kVersion) + kFragPrecision + kNoise + R"GLSL(
uniform sampler2D u_scene;
uniform vec2 u_texel;
uniform float u_aspect;
uniform float u_speed;
uniform float u_blur;
uniform float u_slide;
uniform float u_flash;
uniform float u_time;
uniform vec2 u_center;
uniform vec2 u_sunUv;
uniform float u_sunVis;
uniform vec3 u_sunColor;
uniform float u_fxaa;
uniform float u_sharpen;
uniform float u_upscale;
uniform int u_taps;
in vec2 v_uv;
out vec4 o_col;

float luma(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }

// The scene at uv. When it was drawn below the display's resolution (u_upscale = 1) it is enlarged with a Catmull-Rom filter in five
// bilinear fetches instead of plain bilinear: edges stay crisp instead of going soft, which is most of what "blurry" is on a slower phone.
vec3 sceneAt(vec2 uv) {
    if (u_upscale < 0.5) return texture(u_scene, uv).rgb;
    vec2 pos = uv / u_texel;
    vec2 c = floor(pos - 0.5) + 0.5;
    vec2 f = pos - c;
    vec2 f2 = f * f;
    vec2 f3 = f2 * f;
    vec2 w0 = -0.5 * f3 + f2 - 0.5 * f;
    vec2 w1 = 1.5 * f3 - 2.5 * f2 + 1.0;
    vec2 w2 = -1.5 * f3 + 2.0 * f2 + 0.5 * f;
    vec2 w3 = 0.5 * f3 - 0.5 * f2;
    vec2 w12 = w1 + w2;
    vec2 t12 = (c + w2 / w12) * u_texel;
    vec2 t0 = (c - 1.0) * u_texel;
    vec2 t3 = (c + 2.0) * u_texel;
    vec3 col = texture(u_scene, vec2(t12.x, t0.y)).rgb * (w12.x * w0.y)
             + texture(u_scene, vec2(t0.x, t12.y)).rgb * (w0.x * w12.y)
             + texture(u_scene, t12).rgb * (w12.x * w12.y)
             + texture(u_scene, vec2(t3.x, t12.y)).rgb * (w3.x * w12.y)
             + texture(u_scene, vec2(t12.x, t3.y)).rgb * (w12.x * w3.y);
    float wsum = w12.x * w0.y + w0.x * w12.y + w12.x * w12.y + w3.x * w12.y + w12.x * w3.y;
    return max(col / wsum, vec3(0.0));
}

vec3 fxaaSample(vec2 uv) {
    vec3 rgbM = sceneAt(uv);
    if (u_fxaa < 0.5) return rgbM;
    vec3 rgbNW = texture(u_scene, uv + vec2(-1.0, -1.0) * u_texel).rgb;
    vec3 rgbNE = texture(u_scene, uv + vec2( 1.0, -1.0) * u_texel).rgb;
    vec3 rgbSW = texture(u_scene, uv + vec2(-1.0,  1.0) * u_texel).rgb;
    vec3 rgbSE = texture(u_scene, uv + vec2( 1.0,  1.0) * u_texel).rgb;
    float lM = luma(rgbM), lNW = luma(rgbNW), lNE = luma(rgbNE), lSW = luma(rgbSW), lSE = luma(rgbSE);
    float lMin = min(lM, min(min(lNW, lNE), min(lSW, lSE)));
    float lMax = max(lM, max(max(lNW, lNE), max(lSW, lSE)));
    if (lMax - lMin < max(0.035, lMax * 0.12)) return rgbM;   // no edge here: leave the pixel alone (anti-aliasing only blurs flat areas)
    vec2 dir;
    dir.x = -((lNW + lNE) - (lSW + lSE));
    dir.y =  ((lNW + lSW) - (lNE + lSE));
    float dirReduce = max((lNW + lNE + lSW + lSE) * (0.25 / 8.0), 1.0 / 128.0);
    float rcpDirMin = 1.0 / (min(abs(dir.x), abs(dir.y)) + dirReduce);
    dir = clamp(dir * rcpDirMin, vec2(-8.0), vec2(8.0)) * u_texel;
    vec3 rgbA = 0.5 * (texture(u_scene, uv + dir * (1.0 / 3.0 - 0.5)).rgb + texture(u_scene, uv + dir * (2.0 / 3.0 - 0.5)).rgb);
    vec3 rgbB = rgbA * 0.5 + 0.25 * (texture(u_scene, uv + dir * -0.5).rgb + texture(u_scene, uv + dir * 0.5).rgb);
    float lB = luma(rgbB);
    return (lB < lMin || lB > lMax) ? rgbA : rgbB;
}

// Light unsharp mask limited to the local min/max so it can't ring; hides some of the softness of an upscaled scene.
vec3 sharpenSample(vec2 uv, vec3 c) {
    if (u_sharpen < 0.01) return c;
    vec3 n = texture(u_scene, uv + vec2(0.0, -1.0) * u_texel).rgb;
    vec3 s = texture(u_scene, uv + vec2(0.0,  1.0) * u_texel).rgb;
    vec3 e = texture(u_scene, uv + vec2( 1.0, 0.0) * u_texel).rgb;
    vec3 w = texture(u_scene, uv + vec2(-1.0, 0.0) * u_texel).rgb;
    vec3 mn = min(c, min(min(n, s), min(e, w)));
    vec3 mx = max(c, max(max(n, s), max(e, w)));
    return clamp(c + (c - (n + s + e + w) * 0.25) * u_sharpen, mn, mx);
}

void main() {
    vec2 uv = v_uv;
    vec2 aspectVec = vec2(u_aspect, 1.0);
    vec2 toC = uv - u_center;
    float r = length(toC * aspectVec);

    vec3 col = sharpenSample(uv, fxaaSample(uv));

    // Radial speed blur + chromatic aberration, scaled by the player's setting (u_blur, 0 = off). The middle of the picture - the road and
    // whatever is coming - stays sharp: the smear starts in an ellipse around it (wide and short, so the strip along the left and right
    // edges gets most of it) and the length of the smear is about half what it used to be. At u_blur = 0 none of this runs at all.
    float strength = (u_speed + 0.5 * u_slide) * u_blur;
    if (strength > 0.004) {
        float rb = length(toC * vec2(u_aspect * 0.85, 1.35));
        float mask = smoothstep(0.42, 1.15, rb);
        float blurAmt = (u_speed * mask + u_slide * 0.05 * smoothstep(0.35, 1.0, r)) * u_blur;
        if (blurAmt > 0.003) {
            vec3 acc = col;
            float wsum = 1.0;
            float inv = 1.0 / float(max(u_taps - 1, 1));
            for (int i = 1; i < 10; ++i) {
                if (i >= u_taps) break;
                float t = float(i) * inv;
                vec2 suv = uv - toC * (t * blurAmt * 0.085);
                float w = 1.0 - t * 0.6;
                acc += texture(u_scene, suv).rgb * w;
                wsum += w;
            }
            col = mix(col, acc / wsum, clamp(blurAmt * 3.0, 0.0, 0.9));
            vec2 ca = toC * blurAmt * 0.003;
            col.r = mix(col.r, texture(u_scene, uv - ca).r, 0.5);
            col.b = mix(col.b, texture(u_scene, uv + ca).b, 0.5);
        }
    }

    // speed streaks near the edges at high speed (part of the motion effect: gone when the blur is off)
    if (u_blur > 0.004 && u_speed > 0.05) {
        vec2 q = toC * aspectVec;
        float ang = atan(q.y, q.x) * (40.0 / 6.2831853);
        float cell = floor(ang);
        float rnd = hash12(vec2(cell, floor(u_time * 22.0)));
        float line = (1.0 - smoothstep(0.03, 0.10, abs(fract(ang) - 0.5))) * step(0.80, rnd);
        col += line * smoothstep(0.55, 1.00, r) * pow(u_speed, 2.5) * 0.12 * u_blur;
    }

    // sun glare, only when the sun disc is not hidden by the scene
    vec2 sdv = (uv - u_sunUv) * aspectVec;
    float gd = dot(sdv, sdv);
    float occ = u_sunVis * smoothstep(0.30, 0.75, luma(texture(u_scene, clamp(u_sunUv, vec2(0.0), vec2(1.0))).rgb));
    col += u_sunColor * (exp(-gd * 14.0) * 0.065 + exp(-gd * 120.0) * 0.12) * occ;

    // vignette, grade, dither, crash flash
    col *= 1.0 - smoothstep(0.45, 1.30, r) * (0.26 + 0.20 * u_speed * u_blur);
    float l = luma(col);
    col = mix(col, col * vec3(1.06, 0.99, 0.91), smoothstep(0.35, 0.90, l));
    col = mix(col, col * vec3(0.90, 0.96, 1.10), 1.0 - smoothstep(0.0, 0.35, l));
    col += (hash12(gl_FragCoord.xy + fract(u_time) * 61.0) - 0.5) / 255.0;
    col = mix(col, vec3(1.0, 0.93, 0.85), u_flash);
    o_col = vec4(col, 1.0);
}
)GLSL";
}

// ---------------------------------------------------------------------------------------
// UI
// ---------------------------------------------------------------------------------------
std::string uiVertex() {
    return std::string(kVersion) + R"GLSL(
uniform vec2 u_screen;
layout(location = 0) in vec2 a_pos;
layout(location = 1) in vec2 a_uv;
layout(location = 2) in vec4 a_col;
layout(location = 3) in float a_halo;
out vec4 v_col;
out vec2 v_uv;
out float v_halo;
void main() {
    v_col = a_col;
    v_uv = a_uv;
    v_halo = a_halo;
    gl_Position = vec4(a_pos.x / u_screen.x * 2.0 - 1.0, 1.0 - a_pos.y / u_screen.y * 2.0, 0.0, 1.0);
}
)GLSL";
}

// Plain shapes sample the atlas' solid block (distance 1.0 -> full coverage, so the output is exactly the vertex colour).
// Glyphs sample their signed-distance cell: 0.5 is the edge of the stroke. The fill and the soft dark halo behind it are
// composited here with correct "over" maths, so a glyph is one fragment per pixel and translucent text fades evenly.
std::string uiFragment() {
    return std::string(kVersion) + kFragPrecision + R"GLSL(
uniform highp sampler2D u_atlas;
in vec4 v_col;
in vec2 v_uv;
in float v_halo;
out vec4 o_col;
void main() {
    float d = texture(u_atlas, v_uv).r;
    float w = max(fwidth(d) * 0.75, 0.0005);
    float fill = smoothstep(0.5 - w, 0.5 + w, d);
    float halo = v_halo * 0.62 * smoothstep(0.26, 0.5, d) * (1.0 - fill);
    float aFill = v_col.a * fill;
    float aHalo = v_col.a * halo;
    float a = aFill + aHalo * (1.0 - aFill);
    vec3 haloCol = vec3(0.094, 0.031, 0.141);
    vec3 rgb = (v_col.rgb * aFill + haloCol * aHalo * (1.0 - aFill)) / max(a, 0.0001);
    o_col = vec4(rgb, a);
}
)GLSL";
}

}  // namespace shaders
}  // namespace sd
