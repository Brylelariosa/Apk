// skater_model.h - procedural rider + longboard built from lofted shapes, tubes and ellipsoids each frame.
#pragma once

#include "color.h"
#include "math3d.h"
#include "mesh_data.h"

namespace sd {

struct SkaterPose {
    Vec3 origin;            // board centre on the road surface
    Vec3 right, up, fwd;    // board basis (orthonormal)
    Vec3 roadUp = Vec3(0.0f, 1.0f, 0.0f);   // road surface normal (hands and feet are planted on this plane)
    float tuck = 0.0f;      // 0..1 crouch
    float lean = 0.0f;      // rider lean into the turn (rad, + right)
    float slide = 0.0f;     // 0..1 Coleman slide (deep crouch, hand on the road)
    float slideDir = 1.0f;  // side of the slide (+1 right, -1 left)
    float slip = 0.0f;      // board angle to the travel direction (rad, + = nose to the right)
    float push = 0.0f;      // 0..1 kick-push pose weight
    float pushPhase = 0.0f; // kick cycles since the first kick (0 = foot planted, ready to drive)
    float time = 0.0f;
    float speed = 0.0f;     // m/s: how hard the wind pulls the hair back
    float wheelSpin = 0.0f; // how far the wheels have turned (rad): they roll as the board travels
    bool crashed = false;
    float crashTime = 0.0f;
    float crashSpeed = 0.0f;
    bool lowDetail = false; // remote riders: fewer segments and subdivisions (keeps six riders inside the 16-bit mesh budget)
};

// Colours of one rider: T-shirt, shorts, helmet, deck and the urethane of the wheels, plus skin and hair. Multiplayer gives every player their
// own. Every style is one palette: the shorts are always a deeper tone that sits well with the shirt, the trim picks up the helmet and wheels.
struct RiderStyle {
    Rgba8 jacket, jacketHi;   // T-shirt, dark -> light (kept under the old field names)
    Rgba8 sleeve;             // sleeve hems and the collar
    Rgba8 accent;             // trim: helmet stripe, pads, glove pucks, truck bushings, deck ribbons
    Rgba8 pants;              // shorts
    Rgba8 helmet;
    Rgba8 deck;
    Rgba8 wheel;              // urethane of the wheels
    Rgba8 hub;                // wheel core
    Rgba8 skin, hair;
};

constexpr int kRiderStyleCount = 6;
const RiderStyle& riderStyle(int index);   // wraps around; 0 is the classic orange look

// The rider is built at natural size and scaled up around the board: a bigger rider reads better on a phone screen and against the dark road.
constexpr float kRiderScale = 1.32f;
constexpr float kWheelRadiusWorld = 0.058f * kRiderScale;   // wheel radius as drawn

// Most vertices one rider (full detail) may add to a mesh; scene_builder uses it to stay inside the 16-bit index range.
constexpr size_t kRiderVertexBudget = 7600;
constexpr size_t kRemoteRiderVertexBudget = 3300;     // low-detail riders
constexpr size_t kDynamicMeshVertexLimit = 64000;    // indices are 16-bit

void buildSkaterMesh(const SkaterPose& pose, MeshData& out, const RiderStyle& style);
inline void buildSkaterMesh(const SkaterPose& pose, MeshData& out) { buildSkaterMesh(pose, out, riderStyle(0)); }

}  // namespace sd
