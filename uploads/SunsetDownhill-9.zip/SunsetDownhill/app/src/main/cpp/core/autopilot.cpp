#include "autopilot.h"

#include <algorithm>
#include <cmath>

namespace sd {

namespace {

constexpr float kLaneMargin = 0.55f;    // m: the rider's half width plus a little room
constexpr float kBlockerUrgency = 3.0f;  // a blocker right in front weighs (1 + this) times as much as one at the edge of the view

// Room left beside the nearest thing in a lane (m; below 0 the rider would hit it). A blocker counts for more the closer it is: a rock 20 m ahead
// leaves no time to change lanes later, a row of cones 120 m ahead can still be avoided on the way - they must not look equally bad.
float laneClearance(const std::vector<Obstacle>& obstacles, const Skater& sk, float cx, float look) {
    float clearance = 99.0f;
    for (const Obstacle& o : obstacles) {
        if (o.hit || o.chute >= 0) continue;
        const float ds = o.s - sk.s;
        if (ds < -2.0f || ds > look) continue;
        float gap = std::fabs(o.x - cx) - (o.hx + kLaneMargin);
        if (gap < 0.0f) {
            const float near = 1.0f - clampf(ds / look, 0.0f, 1.0f);
            gap *= 1.0f + kBlockerUrgency * near * near;
        }
        clearance = std::min(clearance, gap);
    }
    return clearance;
}

}  // namespace

SkaterInput AutoPilot::compute(const Track& track, const std::vector<Obstacle>& obstacles, const Skater& sk) {
    SkaterInput in;
    if (sk.gapFlight) return in;   // over a gorge the autopilot just lets go: the board settles onto the line to the landing
    const float v = std::max(sk.speed, 4.0f);

    // ---- pick a lateral target: preferred lane unless something blocks it
    // look far enough to react to fast closing traffic
    float closingMax = v;
    for (const Obstacle& o : obstacles) {
        if (o.chute >= 0) continue;
        const float ds = o.s - sk.s;
        if (ds > 0.0f && ds < 260.0f) closingMax = std::max(closingMax, v - o.vel);
    }
    const float look = (30.0f + closingMax * 3.2f) * (0.6f + 0.4f * skill);
    static const float kCandidates[] = {cfg::kLaneCenter, -cfg::kLaneCenter, 0.0f, 2.8f, -2.8f};
    float best = cfg::kLaneCenter;
    float bestScore = -1e9f;
    bool blocked = false;
    // the kicker of a gorge jump is an obstacle for a driver that doesn't want to jump
    const ShortcutZone* rz = track.zoneAt(sk.s);
    const bool nearKicker = rz && sk.s > rz->sRamp0 - 50.0f && sk.s < rz->sLip + 4.0f;
    for (float cx : kCandidates) {
        if (nearKicker && cx * rz->side > rz->rampX0 - 1.4f) continue;
        const float clearance = laneClearance(obstacles, sk, cx, look);
        const float score = std::min(clearance, 1.4f) * 2.0f - std::fabs(cx - cfg::kLaneCenter) * 0.35f - std::fabs(cx - sk.x) * 0.15f;
        if (cx == cfg::kLaneCenter && clearance < 0.3f) blocked = true;
        if (score > bestScore) { bestScore = score; best = cx; }
    }
    if (forcedX < 1e8f) best = forcedX;
    targetX_ += (best - targetX_) * 0.35f;

    // ---- steering: follow the road, then correct lateral error through the heading
    const float kAhead = track.curvatureAt(sk.s + v * 0.30f);
    const float wMax = std::max(0.05f, sk.yawRateLimit());
    const float alphaTarget = clampf((targetX_ - sk.x) * 0.15f, -0.30f, 0.30f);
    const float omega = kAhead * sk.speed * (1.0f - cfg::kAutoFollow) + 2.6f * (alphaTarget - sk.alpha) + cfg::kStability * sk.alpha;
    in.steer = clampf(omega / wMax, -1.0f, 1.0f);

    // ---- speed management: lateral grip limit for the sharpest curve ahead
    float maxK = 0.0f;
    const float horizon = 22.0f + v * 2.6f * (0.6f + 0.4f * skill);
    for (float d = 0.0f; d <= horizon; d += 8.0f) maxK = std::max(maxK, std::fabs(track.curvatureAt(sk.s + d)));
    const float vSafe = std::sqrt(cfg::kGrip * 0.78f / (std::max(maxK, 1e-3f) * (1.0f - cfg::kAutoFollow)));
    const float cap = std::min(speedCap, vSafe);
    if (sk.speed > cap * 1.02f) braking_ = true;
    if (sk.speed < cap * 0.92f) braking_ = false;
    in.slide = braking_;

    // ---- kick-push when nothing else keeps the board rolling: a climb, or a flat stretch at a low speed
    const float pitchAhead = std::min(track.pitchAt(sk.s), track.pitchAt(sk.s + 8.0f + v * 0.6f));
    in.push = !braking_ && Skater::coastAccel(pitchAhead, sk.speed) < 0.6f && sk.speed < cfg::kPushMaxSpeed - 0.5f;

    in.tuck = allowTuck && !braking_ && !in.push && maxK < 0.004f && !blocked && std::fabs(sk.x - targetX_) < 0.9f &&
              std::fabs(sk.alpha) < 0.12f && sk.speed < cap * 0.9f;
    return in;
}

}  // namespace sd
