// config.h - every tunable gameplay / world constant in one place.
#pragma once

namespace sd {
namespace cfg {

// ---- Road geometry (metres) -------------------------------------------------
constexpr float kRoadHalfWidth = 3.6f;   // asphalt edge
constexpr float kShoulderOuter = 5.2f;   // end of gravel shoulder
constexpr float kRailOffset = 5.35f;     // lateral limit for the skater (rail / embankment)
constexpr float kLaneCenter = 1.8f;
constexpr float kTrackStep = 2.0f;       // distance between centre-line samples
constexpr float kMinCurveRadius = 54.0f;

// ---- Terrain window ---------------------------------------------------------
constexpr int kTerrainCols = 15;
inline constexpr float kTerrainOffsets[kTerrainCols] = {
    -62.0f, -36.0f, -21.0f, -12.5f, -8.0f, -5.2f, -3.6f, 0.0f,
    3.6f,   5.2f,   8.0f,   12.5f,  21.0f, 36.0f, 62.0f};
constexpr float kTerrainMaxOffset = 62.0f;
constexpr int kTerrainRings = 208;                            // rings drawn per frame
constexpr float kViewBehind = 36.0f;                          // metres of road kept behind the focus
constexpr float kViewAhead = kTerrainRings * kTrackStep - kViewBehind;
constexpr float kChunkLength = 30.0f;                         // scenery generation unit
constexpr float kTreeOverlap = 0.80f;     // crowns of two trees may reach this much of their combined radii into each other's space (boughs touch, crowns do not merge)
constexpr int kTreeAttempts = 46;         // tree spots tried per chunk and side ...
constexpr int kTreeMax = 26;              // ... and the most that are kept

// ---- Skater physics ---------------------------------------------------------
constexpr float kGravityScale = 3.0f;      // arcade multiplier on g * sin(pitch)
constexpr float kGravity = 9.81f;
constexpr float kDragCoef = 0.0031f;       // a = k v^2
constexpr float kRolling = 0.35f;          // constant rolling resistance (m/s^2)
constexpr float kTuckDragCut = 0.45f;      // fraction of drag removed at full tuck
constexpr float kGrip = 6.4f;              // lateral acceleration limit (m/s^2); was 5.2: corners at speed were a gamble, now they can be driven
constexpr float kYawRateMax = 1.55f;       // rad/s at low speed
constexpr float kSteerResponse = 13.0f;    // 1/s: how fast the board follows the stick (time constant 77 ms; was 8 = 125 ms)
constexpr float kStability = 0.75f;        // board self-aligns with the road (1/s)
constexpr float kAutoFollow = 0.52f;       // fraction of road curvature the board follows on its own (a rider only has to supply the rest)
constexpr float kSlideDecelBase = 5.4f;    // m/s^2 (full once the board is out at its angle)
constexpr float kSlideDecelDrag = 0.0045f; // extra decel per v^2 while sliding
constexpr float kSlideScrubStart = 0.12f;  // board angle (rad) where the slide starts to scrub speed: a tap that has not swung the board out costs nothing ...
constexpr float kSlideScrubFull = 0.60f;   // ... and where it scrubs fully (the board's angle range is smaller than it was, the braking is as strong as before)
// The Coleman slide is the tool for sharp corners, but it must stay a controllable one: with full stick it turns the heading about 1.6x as fast as
// plain steering (it was 2.6x: +95 % grip, +80 % yaw rate and a self-aligning pull cut by more than half, which felt like a spin). tools/test_slide
// measures it and keeps it in that band.
constexpr float kSlideGripBoost = 0.45f;   // a Coleman slide gives the board more lateral grip (+45 %)
constexpr float kSlideYawBoost = 0.25f;    // ... turns the board a little faster (yaw rate x (1 + this * slide))
constexpr float kSlideAutoFollow = 0.14f;  // ... and makes the board follow the road's curvature on its own (added to kAutoFollow while sliding)
constexpr float kSlideStabilityCut = 0.20f;// ... and loosens the self-aligning pull of the road (stability x (1 - this * slide))
constexpr float kSlideOnRate = 7.0f;       // 1/s: how fast SLIDE comes on (about 0.15 s to be in it; was 12: a snap)
constexpr float kSlideOffRate = 5.0f;      // 1/s: how fast it lets go
constexpr float kTuckGripCut = 0.30f;
constexpr float kShoulderDrag = 0.32f;     // gravel slows you proportionally to speed (never to a stop)
constexpr float kAirGravity = 12.0f;       // m/s^2 while airborne (arcade: a little stronger than real life)
constexpr float kHardLanding = 17.0f;      // landing faster than this (vertical m/s) is a crash
constexpr float kStallTime = 3.5f;         // seconds below 1 m/s before the rider bails (PUSH gets a stopped rider going again)

// ---- Gorge jump (the kicker at the cliff edge that jumps across a U-shaped detour, see track.h) ----
// The jump is a real arc: the kicker throws the rider up at (speed x its slope), gravity pulls the rider down and the horizontal speed
// carries on. So the faster the rider, the higher and the further the jump; a rider who is too slow falls short of the road beyond
// the gorge, and one who is fast lands further along it (there is a long straight runway, cfg::kGorgeRunway).
constexpr float kGapHopSpeed = 7.0f;       // slower than this at the lip and the rider only hops over the kicker (m/s)
constexpr float kGapGravity = 3.4f;        // m/s^2 over the gorge: floaty, so that a rider with about 55 km/h just reaches the road beyond
constexpr float kGapPopMax = 6.0f;         // the most vertical speed the kicker can give (m/s): the jump gets no higher past about 85 km/h
constexpr float kGapDrag = 0.0015f;        // air drag over the gorge (per m/s of speed): a very fast jump does not fly on forever
constexpr float kGapTuckGravity = 0.40f;   // TUCK dives the flight: this much more gravity (fraction) ...
constexpr float kGapSlideGravity = 0.30f;  // ... and SLIDE floats it: this much less
// In the air over the gorge the rider steers: the board turns, the flight drifts sideways, and where it comes down is the rider's call.
constexpr float kGapYawRate = 0.55f;       // how fast full steering turns the board away from the line to the landing (rad/s)
constexpr float kGapCentering = 1.40f;     // ... and how fast it settles back toward that line without steering (1/s)
constexpr float kGapMaxRel = 0.50f;        // the most the board can point away from it (rad)
constexpr float kGapLandingTilt = 0.85f;   // touching down more crooked than this (rad, to the road) is a crash
constexpr float kHopYawRate = 0.60f;       // steering in the air after an ordinary kicker hop (rad/s)

// ---- The gorge detour itself: sized so that the jump over it is a ramp jump (about 60 m, a few metres of drop), not a flight ----
constexpr float kGorgeBendRadiusMin = 12.5f, kGorgeBendRadiusMax = 14.0f;       // the two 90 degree bends (radius at their tightest point)
constexpr float kGorgeHairpinRadiusMin = 11.5f, kGorgeHairpinRadiusMax = 13.5f; // the hairpin round the head of the gorge
constexpr float kGorgeLegMin = 30.0f, kGorgeLegMax = 38.0f;                     // the straight legs down and up the rims
constexpr float kGorgeCurveRamp = 0.15f;   // share of a gorge bend spent easing the curvature in and out (ordinary bends use 0.25)
constexpr float kGorgePitchDeg = 1.3f;     // the detour's steady downhill slope: the road beyond the gorge is only a few metres lower
constexpr float kGorgeDepth = 2.8f;        // the gorge floor lies this far below the road where the jump lands
constexpr float kKickerHeight = 1.1f;      // height of the kicker's lip (m); the slope at the lip is what throws the rider up
constexpr float kGorgeRunway = 110.0f;     // the road runs straight for this long after the detour: the landing strip for a fast jump

// ---- Rolling hills: the road is not one long descent. Hill events are placed in blocks along the road (see hills.h) ----
constexpr float kHillStart = 340.0f;       // no hills before this distance: the first stretch is for getting rolling
constexpr float kHillBlock = 320.0f;       // length of the blocks the hills are placed in (each holds at most one hill)
constexpr float kHillEase = 45.0f;         // a hill eases in and out over this many metres
constexpr float kUphillChance = 0.60f;     // chance a block holds a climb
constexpr float kUphillGradeMin = 1.3f, kUphillGradeMax = 3.0f;     // climb grade in degrees (the pitch at the heart of a climb is minus this)
constexpr float kUphillLenMin = 90.0f, kUphillLenMax = 160.0f;      // length of the steady part of a climb (m)
constexpr float kSteepChance = 0.30f;      // chance a block holds a steeper descent (so 10% of blocks stay plain)
constexpr float kSteepExtraMin = 1.8f, kSteepExtraMax = 3.4f;       // degrees added to the descent
constexpr float kSteepLenMin = 90.0f, kSteepLenMax = 170.0f;
constexpr float kMaxDescentDeg = 11.5f;    // the road never goes down steeper than this
constexpr float kHillClearBefore = 100.0f; // a hill never reaches within this distance before a gorge detour (the rider needs speed for the kicker)...
constexpr float kHillClearAfter = 40.0f;   // ...or this far after it (the detour keeps its own gentle slope)
constexpr float kPlanAhead = 560.0f;       // the road plan (bends, gorge detours) always reaches this far past the road being built: the hills
                                           // need to know where the detours are (a hill is at most 290 m wide, plus the clear zone, and a detour is known 70 m early)

// ---- Kick-push: the automatic kicks at the start of a run, and PUSH held on the road (plant, drive back, swing the foot forward, repeat) ----
constexpr int kPushStrokes = 4;            // kicks before the rider settles onto the board
constexpr float kPushPeriod = 0.58f;       // seconds per kick
constexpr float kPushContact = 0.50f;      // share of a kick the foot is on the road (the drive)
constexpr float kPushAccel = 13.0f;        // peak thrust of a drive from a standstill (m/s^2)
constexpr float kPushFadeSpeed = 12.5f;    // kicks stop helping as the board nears this speed (m/s)
constexpr float kPushMaxSpeed = 11.0f;     // PUSH held on the road (how the rider keeps going uphill) does nothing faster than this (m/s)
constexpr float kPushTime = kPushStrokes * kPushPeriod;
constexpr int kPushCancelAfter = 2;        // TUCK / SLIDE can cut the push short after this many kicks

// ---- Coleman slide (SLIDE held: board kicks out sideways, rider crouches with a hand on the road) ----
constexpr float kColeSlipMin = 0.62f;      // board angle to the travel direction (rad, about 36 degrees) with no steering (was 0.85)
constexpr float kColeSlipMax = 0.95f;      // ... with full steering (about 54 degrees; was 1.25 = 72: the board swung right round)
constexpr float kColeSpeedBlend = 0.18f;   // the board slides out this much less (a shallower angle) at the top speed
constexpr float kColeKick = 60.0f;         // spring that swings the board out: it comes round in about half a second (was 120: a snap) ...
constexpr float kColeDamp = 14.5f;         // ... and settles (nearly critically damped) instead of wobbling
constexpr float kRailGrindLimit = 1.9f;    // seconds of continuous rail contact before a wipe-out (was 1.1)
constexpr float kCrashLateralSpeed = 6.8f; // m/s into the rail that causes a wipe-out (was 4.2: a graze at 10 degrees at 90 km/h was a crash)
constexpr float kRailCushion = 0.45f;      // the last metres before the rail: a rider who is heading into it is eased back along it (a soft wall)
constexpr float kRailCushionRate = 7.0f;   // 1/s, at full depth
constexpr float kSkaterHalfLength = 0.45f;
constexpr float kSkaterHalfWidth = 0.35f;

// ---- Off-road shortcuts ("chutes") -------------------------------------------------------------------------------------------
// A chute is a ground shortcut with no ramp: the road makes a big U-shaped detour (the same kind of detour as round a gorge, only wider and
// on a gentler slope), and straight across the mouth of the U runs a grassy slope a rider can take instead, weaving between trees and rocks
// and rejoining the road further down. Nothing forces a rider into it: it starts where the guard rail is open on the outside of the first
// bend, and a rider who stays on the road just rides the detour.
constexpr float kChuteBendRadiusMin = 22.0f, kChuteBendRadiusMax = 27.0f;        // the two 90 degree bends
constexpr float kChuteHairpinRadiusMin = 22.0f, kChuteHairpinRadiusMax = 27.0f;  // the hairpin round the head of the bowl
constexpr float kChuteLegMin = 38.0f, kChuteLegMax = 52.0f;                      // the straight legs between them
constexpr float kChutePitchDeg = 2.0f;     // the detour road's steady slope; the chute across it is steeper (about 6-8 degrees)
constexpr float kChuteRunway = 70.0f;      // straight road after the detour
constexpr float kChuteHalfWidth = 9.0f;    // half width of the chute's corridor (metres each side of the chord)
constexpr float kChuteBack = 16.0f;        // the corridor starts this far before the chord (the rider has just left the road)
constexpr float kChuteDrag = 0.085f;       // 1/s of extra rolling drag on grass and dirt (about a third of a rider's speed loss per second at 30 m/s)
constexpr float kChuteEntryX = 5.0f;       // a rider this far from the road's centre line, toward the chute side, inside the open stretch of rail, is in the chute

constexpr float kChuteBonus = 250.0f;     // style points for riding a chute to the end

// ---- Checkpoints and respawns (LAN races): a crash puts the rider back on the road at the last checkpoint passed, not at the start ----
constexpr float kCheckpointSpacing = 160.0f;   // metres between checkpoint gates
constexpr float kCheckpointFirst = 140.0f;     // the first gate
constexpr float kCheckpointKeepClear = 90.0f;  // a gate keeps this far before a detour / shortcut entry (and the same after it)
constexpr float kRespawnDelay = 1.7f;          // seconds of wipe-out before the rider is put back
constexpr float kRespawnSpeed = 9.0f;          // m/s the rider rolls away with (a standing start would cost a kick-push)
constexpr float kRespawnGrace = 2.6f;          // seconds after a respawn in which nothing hurts the rider
constexpr int kEndlessLives = 4;               // endless LAN races (no finish line): the run is over after this many wipe-outs
constexpr float kRaceOvertime = 45.0f;         // a race with a finish line ends this long after the first rider crosses it (riders still on the road are out)

// ---- Game flow --------------------------------------------------------------
constexpr float kCountdownStep = 0.85f;    // seconds per 3-2-1
constexpr float kCrashDuration = 2.1f;     // wipe-out before the results screen
constexpr float kMaxPhysicsStep = 1.0f / 120.0f;
constexpr float kDifficultyDistance = 6000.0f;   // metres until full difficulty

}  // namespace cfg
}  // namespace sd
