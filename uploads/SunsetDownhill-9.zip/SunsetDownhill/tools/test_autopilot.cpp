// test_autopilot - how the demo / balancing driver picks its line among obstacles (no GPU needed).
//
// A blocker counts for more the closer it is: a rock 20 m ahead leaves no time to change lanes later, a row of cones 120 m ahead can still be avoided on
// the way. Before, both were weighed alike, so with the rock beside the preferred lane and the cones touching the other two the driver steered at
// the rock (and, with the softer Coleman slide, could no longer swerve at the last moment).
#include <cmath>
#include <cstdio>
#include <vector>

#include "autopilot.h"
#include "config.h"
#include "skater.h"
#include "track.h"

using namespace sd;

namespace {

int g_fails = 0, g_checks = 0;
#define CHECK(cond, ...)                                                            \
    do {                                                                            \
        ++g_checks;                                                                 \
        if (!(cond)) {                                                              \
            ++g_fails;                                                              \
            std::printf("  FAIL line %d: %s  ", __LINE__, #cond);                   \
            std::printf(__VA_ARGS__);                                               \
            std::printf("\n");                                                      \
        }                                                                           \
    } while (0)

// the start of a long, straight stretch of road
float findStraight(const Track& tr) {
    for (float s = 250.0f; s < 2200.0f; s += 4.0f) {
        bool ok = true;
        for (float d = -10.0f; d <= 200.0f && ok; d += 4.0f) ok = std::fabs(tr.curvatureAt(s + d)) < 2e-5f;
        if (ok) return s;
    }
    return -1.0f;
}

Obstacle make(ObstacleKind kind, float s, float x, float hx) {
    Obstacle o;
    o.kind = kind;
    o.s = s;
    o.x = x;
    o.hx = hx;
    o.hs = 0.4f;
    return o;
}

// What the driver asks for after it has had a few frames to settle on a line: the stick (+ = right, toward larger x).
float stickAfterSettling(const Track& tr, const std::vector<Obstacle>& obstacles, const Skater& sk) {
    AutoPilot ap;
    SkaterInput in;
    for (int i = 0; i < 8; ++i) in = ap.compute(tr, obstacles, sk);
    return in.steer;
}

}  // namespace

int main() {
    Track tr(12345u);
    tr.ensureGenerated(2500.0f);
    const float s0 = findStraight(tr);
    CHECK(s0 > 0.0f, "found a straight stretch to test on");
    if (s0 < 0.0f) return 1;

    Skater sk;
    sk.reset(s0, 30.0f);
    sk.x = 0.0f;

    // a rock 20 m ahead just beside the preferred lane, cones 120 m ahead that touch the middle and the left lane: the near rock decides
    {
        std::vector<Obstacle> obs;
        obs.push_back(make(ObstacleKind::Rock, s0 + 20.0f, 2.31f, 0.63f));
        obs.push_back(make(ObstacleKind::Cone, s0 + 122.0f, -1.90f, 0.28f));
        obs.push_back(make(ObstacleKind::Cone, s0 + 124.0f, -0.25f, 0.28f));
        const float stick = stickAfterSettling(tr, obs, sk);
        std::printf("rock 20 m ahead at x=2.31, cones 120 m ahead at x=-1.9 and -0.25: stick %+.2f\n", stick);
        CHECK(stick < 0.25f, "the driver does not steer at the near rock because far cones are about as bad: stick %+.2f", stick);
    }

    // a rock right in the driver's own lane: it goes round it, to one side or the other
    {
        Skater onLine = sk;
        onLine.x = cfg::kLaneCenter;
        std::vector<Obstacle> blocked;
        blocked.push_back(make(ObstacleKind::Rock, s0 + 25.0f, cfg::kLaneCenter, 0.63f));
        const float stick = stickAfterSettling(tr, blocked, onLine);
        std::printf("rock 25 m ahead in the driver's own lane: stick %+.2f\n", stick);
        CHECK(std::fabs(stick) > 0.3f, "the driver swerves round a rock in its lane: stick %+.2f", stick);
    }

    // nothing about: the driver keeps its line
    {
        std::vector<Obstacle> none;
        Skater onLine = sk;
        onLine.x = cfg::kLaneCenter;
        const float stick = stickAfterSettling(tr, none, onLine);
        CHECK(std::fabs(stick) < 0.15f, "an empty road: the driver keeps its lane: stick %+.2f", stick);
    }

    std::printf("\n%d checks, %d failed\n", g_checks, g_fails);
    return g_fails == 0 ? 0 : 1;
}
