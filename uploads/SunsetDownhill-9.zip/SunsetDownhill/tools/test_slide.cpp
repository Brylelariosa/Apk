// test_slide - the Coleman slide must be a controllable tool, not a spin (no GPU needed).
//
// With the stick held over, SLIDE turns the heading faster than plain steering - that is what it is for - but only by a limited factor: when it
// was 2.5x and the board swung right round to 70 degrees within half a second it felt like a violent spin. This test keeps it in a band:
//   - the heading turns faster than without the slide, but by at most kMaxRatio (and by at least kMinRatio, so it stays worth using)
//   - the board comes out progressively (it is not at its angle within a fraction of a second) and never past the configured angle
//   - the slide still scrubs speed (it is also the rider's brake) and lets go smoothly
//   - the autopilot, which drives with the same turn-rate limit as the physics (Skater::yawRateLimit), still takes the bends with it
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <vector>

#include "autopilot.h"
#include "config.h"
#include "skater.h"
#include "track.h"

using namespace sd;

namespace {

int g_fails = 0, g_checks = 0;
#define CHECK(cond, ...)                                                            \
    do {                                                                            \
        ++g_checks;                                                                 \
        if (!(cond)) {                                                              \
            ++g_fails;                                                              \
            std::printf("  FAIL line %d: %s  ", __LINE__, #cond);                   \
            std::printf(__VA_ARGS__);                                               \
            std::printf("\n");                                                      \
        }                                                                           \
    } while (0)

constexpr float kDt = 1.0f / 120.0f;
constexpr float kMinRatio = 1.25f;   // the slide must still turn clearly faster than plain steering ...
constexpr float kMaxRatio = 1.90f;   // ... but not by the 2.5x it once did

// the start of a long, straight stretch of road (there the heading relative to the road is the heading in the world)
float findStraight(const Track& tr) {
    for (float s = 250.0f; s < 2200.0f; s += 4.0f) {
        bool ok = true;
        for (float d = -10.0f; d <= 90.0f && ok; d += 4.0f) ok = std::fabs(tr.curvatureAt(s + d)) < 2e-5f;
        if (ok) return s;
    }
    return -1.0f;
}

struct Ride {
    float heading = 0.0f;    // |heading relative to the road| at the end (rad)
    float boardPeak = 0.0f;  // the largest board angle (rad)
    float tHalf = -1.0f;     // time until the board is half way to its final angle (s)
    float lost = 0.0f;       // speed lost (m/s)
    bool crashed = false;
};

// Rides a straight stretch for `seconds` with a fixed stick / SLIDE input.
Ride ride(const Track& tr, float s0, float v0, bool slide, float steer, float seconds) {
    Skater sk;
    sk.reset(s0, v0);
    sk.x = 0.0f;
    std::vector<float> board;
    Ride r;
    for (float t = 0.0f; t < seconds && !sk.crashed; t += kDt) {
        SkaterInput in;
        in.slide = slide;
        in.steer = steer;
        sk.step(in, tr, kDt);
        board.push_back(std::fabs(sk.yawVis));
        r.boardPeak = std::max(r.boardPeak, board.back());
    }
    r.crashed = sk.crashed;
    r.heading = std::fabs(sk.alpha);
    r.lost = v0 - sk.speed;
    if (!board.empty() && board.back() > 0.05f)
        for (size_t i = 0; i < board.size(); ++i)
            if (board[i] >= 0.5f * board.back()) { r.tHalf = static_cast<float>(i) * kDt; break; }
    return r;
}

}  // namespace

int main() {
    const uint32_t seeds[] = {12345u, 777u, 4242u, 99u};
    int roads = 0;
    for (uint32_t seed : seeds) {
        Track tr(seed);
        tr.ensureGenerated(2500.0f);
        const float s0 = findStraight(tr);
        if (s0 < 0.0f) continue;
        ++roads;
        std::printf("seed %u, straight at s=%.0f\n", seed, s0);

        for (float v0 : {10.0f, 16.0f, 22.0f, 30.0f}) {
            const Ride plain = ride(tr, s0, v0, false, 1.0f, 1.0f);
            const Ride slide = ride(tr, s0, v0, true, 1.0f, 1.0f);
            const float ratio = slide.heading / std::max(1e-4f, plain.heading);
            std::printf("  %2.0f m/s, full stick for 1 s: heading %4.1f deg plain, %4.1f deg sliding (x%.2f), board %2.0f deg, speed lost %.1f m/s\n", v0,
                        plain.heading / kDeg2Rad, slide.heading / kDeg2Rad, ratio, slide.boardPeak / kDeg2Rad, slide.lost);
            CHECK(!plain.crashed && !slide.crashed, "no crash on a straight (%.0f m/s)", v0);
            CHECK(ratio >= kMinRatio, "the slide still turns clearly faster than plain steering: x%.2f at %.0f m/s", ratio, v0);
            CHECK(ratio <= kMaxRatio, "the slide is not a spin: x%.2f at %.0f m/s (limit %.2f)", ratio, v0, kMaxRatio);
            CHECK(slide.boardPeak <= 1.12f * cfg::kColeSlipMax, "the board stays inside its angle: %.2f rad (limit %.2f)", slide.boardPeak, 1.12f * cfg::kColeSlipMax);
        }

        // SLIDE on its own: the board comes out progressively, to the angle with no steering, and it brakes
        {
            const Ride r = ride(tr, s0, 20.0f, true, 0.0f, 1.5f);
            std::printf("  SLIDE alone at 20 m/s: board %.0f deg, half way after %.2f s, speed lost in 1.5 s %.1f m/s\n", r.boardPeak / kDeg2Rad, r.tHalf, r.lost);
            CHECK(r.boardPeak > 0.85f * cfg::kColeSlipMin && r.boardPeak < 1.15f * cfg::kColeSlipMin, "no steering: the board comes out to about %.2f rad: %.2f", cfg::kColeSlipMin, r.boardPeak);
            CHECK(r.tHalf >= 0.22f, "the board does not snap out: half way after %.2f s", r.tHalf);
            CHECK(r.lost > 3.5f, "a committed slide still scrubs speed (it is the brake): %.1f m/s", r.lost);
        }

        // a tap costs nothing, and letting go is smooth: the slide is gone and the board straight within a second
        {
            const Ride tap = ride(tr, s0, 20.0f, true, 0.0f, 0.08f);
            CHECK(tap.lost < 0.3f, "a very short tap costs next to nothing: %.2f m/s", tap.lost);
            Skater sk;
            sk.reset(s0, 20.0f);
            sk.x = 0.0f;
            for (float t = 0.0f; t < 1.0f; t += kDt) { SkaterInput in; in.slide = true; sk.step(in, tr, kDt); }
            float peakAfter = 0.0f;
            for (float t = 0.0f; t < 1.0f; t += kDt) { SkaterInput in; sk.step(in, tr, kDt); peakAfter = std::max(peakAfter, std::fabs(sk.yawVis)); }
            CHECK(sk.slide < 0.05f && std::fabs(sk.yawVis) < 0.10f, "one second after letting go the slide is over: slide %.2f, board %.2f rad", sk.slide, sk.yawVis);
            CHECK(peakAfter < 1.12f * cfg::kColeSlipMin, "letting go does not swing the board further out: %.2f rad", peakAfter);
        }
    }
    CHECK(roads >= 3, "found straight stretches to test on: %d roads", roads);

    // the steering the autopilot gives is the same as the one the physics uses (Skater::yawRateLimit): it must still take bends, sliding when it brakes
    {
        int bends = 0, ok = 0;
        for (uint32_t seed : {3u, 5u, 8u}) {
            Track tr(seed * 7919u + 13u);
            tr.ensureGenerated(1800.0f);
            Skater sk;
            sk.reset(300.0f, 22.0f);
            sk.x = cfg::kLaneCenter;
            std::vector<Obstacle> none;
            AutoPilot ap;
            bool crashed = false;
            for (float t = 0.0f; t < 40.0f && !crashed && sk.s < 1500.0f; t += kDt) {
                sk.step(ap.compute(tr, none, sk), tr, kDt);
                crashed = sk.crashed;
            }
            ++bends;
            ok += crashed ? 0 : 1;
        }
        std::printf("autopilot: %d / %d rides of 1.2 km without a wipe-out\n", ok, bends);
        CHECK(ok == bends, "the autopilot still rides the roads with the calmer slide: %d / %d", ok, bends);
    }

    std::printf("\n%d checks, %d failed\n", g_checks, g_fails);
    return g_fails == 0 ? 0 : 1;
}
