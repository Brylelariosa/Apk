package com.browser.app

import android.content.Context
import android.util.AttributeSet
import android.webkit.WebView

/**
 * WebView subclass that exposes onScrollChanged as a public callback so
 * MainActivity can react to page scrolls without polling or reflection.
 *
 * NOTE: The previous onCreateInputConnection override has been removed.
 * Keyboard handling is done exclusively through the JS bridge
 * (WebKeyboardBridge) to avoid races with WindowInsetsController.
 */
class ScrollAwareWebView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : WebView(context, attrs, defStyleAttr) {

    /** Called on every scroll change. Invoked on the main thread. */
    var onScrollCallback: ((dy: Int) -> Unit)? = null

    override fun onScrollChanged(l: Int, t: Int, oldl: Int, oldt: Int) {
        super.onScrollChanged(l, t, oldl, oldt)
        onScrollCallback?.invoke(t - oldt)
    }
}
