# Changelog — v30

A UI bug fix, reported with a screenshot: the "Clear" buttons in Settings
(Download History / Build History) were rendering with garbled, overlapping
text.

## Fixed
- **Root cause:** `Widget.App.Button.Chip` (used by these Clear buttons, plus
  Copy/Share on the main screen) is a `MaterialButton` style, which reserves
  its own vertical inset/padding space on top of whatever height it's given.
  Several buttons using this style had an explicit `layout_height` (26dp for
  Clear, 30dp for Copy/Share) *smaller* than the style's own declared
  `minHeight` (34dp) — squeezing the text into less space than it needed and
  corrupting how it drew. Fixed at the style level (explicit
  `insetTop`/`insetBottom`/`paddingTop`/`paddingBottom` = 0dp) and by changing
  all 4 affected buttons to `wrap_content`, so the style's own sizing applies
  cleanly instead of fighting a smaller forced height. Copy/Share weren't
  reported as broken, but shared the identical mismatch and were fixed
  alongside rather than left as a latent version of the same bug.

## Improved (while already in this section)
- **Clearing history had no confirmation at all** — a single tap permanently
  wiped every download or build history entry with no "are you sure?" and no
  undo. Both Clear buttons now confirm first, stating exactly how many
  entries will be removed.
- The two Clear buttons are now tinted with the app's existing muted-red
  `text_error` color (previously the same neutral gray as Copy/Share),
  visually distinguishing a destructive, irreversible action from a neutral
  utility one.

---

# Changelog — v29

One focused addition: background build tracking + notifications.

## Added
- **Background build tracking.** A build no longer needs the app to stay in
  the foreground to keep going — a low-priority "Building… [live status]"
  notification now runs for the duration of a build, which keeps the app
  process (and its existing polling) alive if you switch away. When the
  build finishes, that's replaced with a dismissible result notification
  ("✓ Build succeeded" / "✗ Build failed") that reopens the app when tapped.
  A user-cancelled build intentionally does *not* post a result notification
  — you're already looking at the app when you cancel something.
- New `BuildTrackingService` (a small foreground service — deliberately just
  a notification/keep-alive shell, not a second copy of the existing
  build-polling logic, which stays exactly where it was in `MainActivity`).
- Requests the Android 13+ notification permission contextually, the first
  time a build starts (not on app launch) — following the same
  request-lazily-with-a-stored-pending-action pattern already used for the
  Android 7–9 storage permission. If denied, the build proceeds exactly as
  before; only the notification itself is skipped.

## Changed
- `versionCode`/`versionName` 28 → 29.
- Manifest: added `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_DATA_SYNC`, and
  `POST_NOTIFICATIONS` permissions, and declared the new (non-exported)
  service.

No existing behavior, screen, or dialog changed — this only adds a system
notification, which sits outside the app's own UI. Full detail in
`FEATURES_ADDED.md` and `FILE_CHANGES.md`.

---

# Changelog — v28

A network-reliability and bug-review release. The headline change is a real
resumable download engine (byte-level HTTP Range resume, automatic pause/
resume on connectivity loss, exponential-backoff retry) replacing the v27
download loop, which had none of that. Everything else is a targeted fix or
addition on top of the existing single-Activity design — no rewrites.

## Fixed
- **A cold-start cleanup sweep could delete a download you were about to
  resume.** The same 2-minute-old sweep that correctly clears truly-orphaned
  temp files was, before this release, also applied to resumable download
  partials — so closing the app and coming back more than 2 minutes later
  could silently erase your progress before you ever saw a Resume option.
  Partial downloads now get a 7-day grace window; only the always-ephemeral
  APK-info scratch file keeps the short 2-minute sweep. See `BUGS_FIXED.md`.
- **A stale/mismatched partial download could get stuck failing forever.**
  If the server ever rejects a resume (`HTTP 416 Range Not Satisfiable` —
  e.g. the partial no longer matches what the server has), the download now
  discards that one partial file and restarts once, instead of failing with
  no path forward.
- **Two file-read paths crashed with a raw `NullPointerException`** (reading
  a user-picked project ZIP, and uploading a single file from the file
  browser) if the picked file had been moved/deleted/revoked since selection.
  Both now surface a clear, actionable message instead.
- **"Use Existing" on an already-configured keystore could store the wrong
  alias.** GitHub never reveals a Secret's value, so the app never actually
  knew the real alias of a keystore that already existed remotely — it was
  storing whatever was currently typed (or freshly generated) in the alias
  field instead, which could mislabel the Settings display. It now shows the
  verified filename instead of guessing an alias.
- **A stray, misplaced doc comment** (describing `saveZipToDownloads`) had
  ended up sitting in front of an unrelated function, `logApkInfoFromZip`,
  after an earlier refactor split that function apart. Moved back to the
  function it actually documents.
- Verified every v27 fix in `BUGS_FIXED.md` against the current source; all
  still hold (see `REVIEW_REPORT.md` for the specific checks performed).

## Network Reliability & Download Resume
This is the main focus of v28 — see `V28_RELEASE_NOTES.md` for the full
write-up. Summary:
- Byte-level resume via HTTP `Range` requests whenever the server supports
  them; deterministic per-artifact/per-run file naming so a retry — manual,
  automatic, or after fully restarting the app — continues the same partial
  file instead of starting at 0%.
- Automatic network-loss detection (`ConnectivityManager`): a download pauses
  itself, shows "Paused (No Internet)", and resumes the instant connectivity
  returns — no user action required.
- Exponential-backoff automatic retry (2s → 4s → 8s… capped at 30s, 5 attempts)
  for transient server errors (HTTP 429/500/502/503/504) and I/O errors that
  happen while the network still tests as reachable.
- A manual Retry button appears after retries are exhausted, reusing the same
  partial bytes rather than discarding them.
- Speed, ETA, and remaining-bytes now shown during download (previously just
  downloaded/total and instantaneous speed).
- The same reliability policy (offline-wait + backoff retry) now also covers
  **uploads** — previously any network hiccup during upload failed the whole
  build immediately with no retry at all. True byte-resume isn't meaningful
  for GitHub's upload APIs (no partial-request support), so a failed upload
  retries the attempt from scratch — safe here because blobs/trees are
  content-addressed and a retried commit just adds one small extra commit,
  never corrupting anything.
- New downloaded-ZIP integrity verification (full CRC-32 re-check) — see
  Features below.

## Performance
- The live build-log streamer's full-log print (which can be hundreds or
  thousands of lines for a verbose Gradle build) now cleans and joins every
  line into a single log append instead of one `Handler.post` per line —
  same resulting text, far fewer main-thread posts for a large build.
- Consolidated two independent copies of the same three log-cleaning regexes
  (ANSI-code strip, timestamp strip, group-marker match) — one in the live
  build streamer, one in the saved-run log viewer — into shared, compiled-
  once fields, used by both.
- Confirmed release-build R8 code shrinking + resource shrinking are enabled
  with a minimal, correct keep-rule set (see `PERFORMANCE_REPORT.md` and
  `proguard-rules.pro`) — this app has no reflection-based (de)serialization
  or WebView JS interface, so very little needed to be kept.

## Reliability & Quality of Life
- Downloaded ZIPs (both the build artifact and the build-log archive) are now
  verified byte-for-byte (CRC-32 per entry, via a full re-read) before being
  saved to Downloads or reported as successful. A corrupted/truncated result
  is deleted and offered for retry instead of being silently handed to the
  user as if it succeeded.
- Download progress now also shows remaining bytes alongside downloaded/total.

## Code Quality
- Removed the last 2 unguarded `!!` non-null assertions on user-file I/O in
  favor of a clear thrown message (`openInputStreamOrThrow` /
  `openOutputStreamOrThrow`), reused at all 4 call sites that previously each
  wrote their own `contentResolver.open*Stream(uri)!!`.
- Generalized `sleepCancellable()` and `waitForNetwork()` to take which
  cancellation flag to watch (defaulting to the download flag, so every
  existing call site is unaffected) instead of duplicating both functions for
  the new upload-retry path.
- Verified there are no unused imports or unreferenced private functions
  anywhere in the file (checked systematically — see `REVIEW_REPORT.md`).

See `BUGS_FIXED.md`, `PERFORMANCE_REPORT.md`, `FEATURES_ADDED.md`,
`FILE_CHANGES.md`, `REVIEW_REPORT.md`, and `KNOWN_LIMITATIONS.md` for full
detail on each item above.

---

# Changelog — v27

A performance, reliability, quality-of-life, and feature update. No architectural
rewrites — every change is a targeted fix or addition on top of the existing
single-Activity design.

## Fixed
- **Owner chip showed even when it shouldn't.** Missing braces on an `if` meant
  `tvOwnerInfo.visibility = VISIBLE` ran unconditionally instead of only when
  `savedOwner` was actually set. See `BUGS_FIXED.md`.
- **New-repo creation waited up to ~18s longer than necessary.** A
  `repeat(10) { return@repeat }` loop can't actually break early —
  `return@repeat` just skips to the next iteration — so after the repo became
  reachable, the code kept sleeping and polling anyway. Now breaks immediately.
- **File editor lagged while typing in any reasonably large file.** The
  line-number gutter recomputed the entire line count on every keystroke.
  Now it only recomputes when the edit actually spans a newline.
- **Downloaded-file path could be wrong.** On a filename collision, Android's
  MediaStore silently renames the file (`name (1).zip`); the app used to
  report the originally-requested name regardless. It now queries the name
  MediaStore actually used.
- **One failed item could silently cancel an entire batch delete.** Deleting
  multiple files/folders at once now continues through all selected items
  even if one fails, and reports a clear summary at the end.
- **A temp file leaked into the cache on every artifact download.** The
  downloaded artifact ZIP was copied to Downloads but never removed from
  `cacheDir` afterward — every download left a permanent copy behind.
- **Duplicate/inconsistent byte-formatting.** Four separate implementations
  of "format bytes as KB/MB/GB" existed with different rounding and no GB
  tier on three of them. Unified into one.

## Performance
- Replaced 25 ad hoc `thread { }` spawns with a single shared, bounded
  (4-thread) background executor — less thread-creation overhead and memory
  per action, with enough concurrency that a long build never blocks
  unrelated actions like Browse Artifacts.
- `appendLog()` no longer queues a separate scroll pass for every streamed
  build-log line — bursts now coalesce into a single pending scroll.
- The console log now has a length cap (~200k characters) so a very long or
  looping build, or a long multi-build session, can't grow it unbounded.
- Added `android:largeHeap="true"` — uploading a project ZIP can briefly hold
  several full in-memory copies (raw bytes, Base64 string, JSON payload, UTF-8
  bytes); for a large ZIP this can approach the default per-app heap ceiling
  on a low-RAM device.
- `downloadArtifact()` no longer hand-builds its own ~115-line copy of the
  download-progress dialog; it reuses the same builder `downloadLatestRunLogs()`
  already relies on.
- Reviewed the embedded GitHub Actions workflow for build-speed opportunities.
  It already uses `setup-gradle` dependency caching, dedicated NDK/CMake
  caching, hash-keyed incremental C++ build caching, and
  `--configuration-cache --build-cache --parallel` — left untouched rather
  than adding redundant caching on top of what's already there.

## Reliability & Quality of Life
- **Pre-upload ZIP validation**: peeks the ZIP's entry list (already in memory,
  no extra I/O) for `settings.gradle(.kts)` and `gradlew` before uploading, and
  warns if either is missing — catching the most common "wrong ZIP" mistake
  before spending an upload and a full CI run on it.
- **Storage space check** before artifact/log downloads start, so a large file
  fails fast with a clear message instead of partway through.
- **Friendlier network error messages** (no internet, timeout, TLS/date issue,
  unreachable host) for the main build flow.
- **Automatic cleanup of leftover temp files** from a previous session that was
  killed before its own cleanup ran — swept once on cold start.
- **`onDestroy()` added** — shuts the background executor down and stops the
  status-dot animations, where previously nothing was cleaned up at all.
- Large ZIP (>40MB) uploads now log an upfront note that the upload will hold
  the file fully in memory and may take a while.
- `versionCode`/`versionName` now actually track the app's real version history
  (was frozen at `1` / `"1.0"` since the very first release, through 26 prior
  versions).

## New Features
- **Build History** (Settings → Build History): the last 30 builds triggered
  from this device, with outcome, repo/branch, duration, and time — recorded
  locally, no network call needed to view it.
- **Build Statistics**: a one-line summary (success rate, average successful
  build duration) computed from that same local history.
- **Build Duration Timer**: every build now measures and logs its own
  end-to-end elapsed time.
- **APK Info Viewer**: after a successful artifact download, the app peeks
  inside the ZIP for the `.apk` and logs its package name, version, min/target
  SDK, and size — a quick sanity check without installing it first.

## Code Quality
- Removed 2 fields (`btnDownloadLogs`, `btnSavedRepos`) that were declared,
  always null, and never read anywhere.
- Removed 3 duplicate local `fmtBytes()` copies (kept the one class-level
  version; all call sites are unaffected).
- Removed ~115 lines of duplicated dialog-construction code from
  `downloadArtifact()`.
- Removed the now-unused `kotlin.concurrent.thread` import.
- Verified there are no unused imports anywhere in the file (checked
  systematically, not spot-checked).

See `BUGS_FIXED.md`, `PERFORMANCE_REPORT.md`, `FEATURES_ADDED.md`, and
`FILE_CHANGES.md` for full detail on each item above.
