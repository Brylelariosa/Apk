package com.quickshare

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.Uri
import android.net.wifi.WifiConfiguration
import android.net.wifi.WifiManager
import android.net.wifi.WifiNetworkSpecifier
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pDevice
import android.net.wifi.p2p.WifiP2pInfo
import android.net.wifi.p2p.WifiP2pManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.OpenableColumns
import android.provider.Settings
import android.util.Log
import android.view.View
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import android.content.pm.ResolveInfo
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.CheckedTextView
import android.widget.ListView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanIntentResult
import com.journeyapps.barcodescanner.ScanOptions
import com.quickshare.databinding.ActivityMainBinding
import kotlinx.coroutines.*
import org.json.JSONObject
import java.io.*
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.text.DecimalFormat

class MainActivity : AppCompatActivity(), WifiP2pManager.ChannelListener {

    private lateinit var binding: ActivityMainBinding
    private lateinit var manager: WifiP2pManager
    private lateinit var channel: WifiP2pManager.Channel
    private lateinit var receiver: BroadcastReceiver

    private var isWifiP2pEnabled = false
    private var connectedDeviceInfo: WifiP2pInfo? = null
    private val peers = mutableListOf<WifiP2pDevice>()
    private lateinit var deviceAdapter: DeviceAdapter

    private var isReceiverMode = false
    private var isHotspotMode = false
    private var boundNetwork: Network? = null
    private var wifiNetworkCallback: ConnectivityManager.NetworkCallback? = null

    // Multi-file selection
    private val selectedFiles = mutableListOf<SelectedFile>()
    private lateinit var selectedFilesAdapter: SelectedFilesAdapter

    private val SERVER_PORT = 8988
    private val BUFFER_SIZE = 1024 * 256

    private var serverJob: Job? = null
    private var isReceiving = false
    private var hotspotConnectJob: Job? = null
    private var discoveryRetryJob: Job? = null

    companion object {
        private const val TAG = "QuickShare"
        private const val QR_PREFIX = "QS:"
        private const val GO_IP = "192.168.49.1"
    }

    // ── Activity Result Launchers ─────────────────────────────────────────────

    private val qrScanLauncher = registerForActivityResult(ScanContract()) { result: ScanIntentResult ->
        result.contents?.let { parseAndConnectQR(it) }
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        if (permissions.values.all { it }) initWifiDirect()
        else showToast("Some permissions denied — features may be limited")
    }

    // Image picker: multi-select images only
    private val imagePickerLauncher = registerForActivityResult(
        ActivityResultContracts.GetMultipleContents()
    ) { uris -> addSelectedFiles(uris) }

    // File picker: multi-select any file (APKs, docs, etc.)
    private val filePickerLauncher = registerForActivityResult(
        ActivityResultContracts.GetMultipleContents()
    ) { uris -> addSelectedFiles(uris) }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setupUI()
        checkPermissionsAndInit()
    }

    override fun onResume() {
        super.onResume()
        if (::receiver.isInitialized) {
            try { registerWifiReceiver() } catch (_: Exception) {}
        }
    }

    override fun onPause() {
        super.onPause()
        if (::receiver.isInitialized) {
            try { unregisterReceiver(receiver) } catch (_: Exception) {}
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        serverJob?.cancel()
        discoveryRetryJob?.cancel()
        releaseNetworkCallback()
    }

    // ── UI Setup ──────────────────────────────────────────────────────────────

    private fun setupUI() {
        deviceAdapter = DeviceAdapter(peers) { device -> connectToDevice(device) }
        binding.rvDevices.layoutManager = LinearLayoutManager(this)
        binding.rvDevices.adapter = deviceAdapter

        selectedFilesAdapter = SelectedFilesAdapter(selectedFiles) { position ->
            selectedFiles.removeAt(position)
            selectedFilesAdapter.notifyItemRemoved(position)
            updateSelectedFilesUI()
        }
        binding.rvSelectedFiles.layoutManager = LinearLayoutManager(this)
        binding.rvSelectedFiles.adapter = selectedFilesAdapter
        binding.rvSelectedFiles.isNestedScrollingEnabled = false

        binding.btnReceive.setOnClickListener {
            if (isReceiving) { stopReceiveMode(); return@setOnClickListener }
            if (!isWifiEnabled()) { showWifiOffDialog("Receiving requires WiFi to be on."); return@setOnClickListener }
            startReceiveMode()
        }

        binding.btnScanQR.setOnClickListener { scanQR() }

        binding.btnDiscover.setOnClickListener {
            showToast("System busy")
        }

        binding.btnPickImages.setOnClickListener { imagePickerLauncher.launch("image/*") }
        binding.btnPickFiles.setOnClickListener { filePickerLauncher.launch("*/*") }

        binding.btnPickApk.setOnClickListener {
            val pm = packageManager
            val launcherIntent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
            }
            val resolveInfos = pm.queryIntentActivities(launcherIntent, PackageManager.GET_META_DATA)
                .filter { it.activityInfo.packageName != packageName }
                .sortedBy { it.loadLabel(pm).toString() }

            if (resolveInfos.isEmpty()) {
                showToast("No installed apps found")
                return@setOnClickListener
            }

            val checked = BooleanArray(resolveInfos.size)

            // Custom list with icons + checkboxes
            val listView = ListView(this)
            val adapter = object : ArrayAdapter<ResolveInfo>(this, 0, resolveInfos) {
                override fun getView(pos: Int, convertView: View?, parent: ViewGroup): View {
                    val view = convertView ?: LayoutInflater.from(context)
                        .inflate(android.R.layout.simple_list_item_multiple_choice, parent, false)
                    val tv = view.findViewById<CheckedTextView>(android.R.id.text1)
                    val info = resolveInfos[pos]
                    tv.text = info.loadLabel(pm)
                    val icon = info.loadIcon(pm)
                    icon.setBounds(0, 0, 80, 80)
                    tv.setCompoundDrawables(icon, null, null, null)
                    tv.compoundDrawablePadding = 20
                    tv.isChecked = checked[pos]
                    return view
                }
            }
            listView.adapter = adapter
            listView.choiceMode = ListView.CHOICE_MODE_MULTIPLE
            listView.setOnItemClickListener { _, _, pos, _ ->
                checked[pos] = !checked[pos]
                listView.setItemChecked(pos, checked[pos])
            }

            AlertDialog.Builder(this)
                .setTitle("Select Apps to Send")
                .setView(listView)
                .setPositiveButton("Add") { _, _ ->
                    var added = 0
                    for (i in resolveInfos.indices) {
                        if (checked[i]) {
                            val appInfo = resolveInfos[i].activityInfo.applicationInfo
                            val apkFile = java.io.File(appInfo.sourceDir)
                            val uri = android.net.Uri.fromFile(apkFile)
                            val name = pm.getApplicationLabel(appInfo).toString() + ".apk"
                            val size = apkFile.length()
                            if (selectedFiles.none { it.uri == uri }) {
                                selectedFiles.add(SelectedFile(uri, name, size))
                                added++
                            }
                        }
                    }
                    if (added > 0) {
                        selectedFilesAdapter.notifyDataSetChanged()
                        updateSelectedFilesUI()
                        showToast("$added app(s) added")
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        binding.btnClearFiles.setOnClickListener {
            selectedFiles.clear()
            selectedFilesAdapter.notifyDataSetChanged()
            updateSelectedFilesUI()
        }

        binding.btnSendFile.setOnClickListener {
            if (selectedFiles.isEmpty()) { showToast("Pick at least one file first"); return@setOnClickListener }
            if (!isConnectedInAnyMode()) { showToast("Connect to a receiver first"); return@setOnClickListener }
            sendFiles()
        }

        binding.btnDisconnect.setOnClickListener { disconnect() }

        updateStatus("Ready — tap 📥 Receive on the receiver, 📷 Scan QR on the sender")
        updateConnectionUI(false)
    }

    private fun isConnectedInAnyMode() = connectedDeviceInfo != null || isHotspotMode

    private fun isWifiEnabled(): Boolean {
        val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
        return wm.isWifiEnabled
    }

    private fun showWifiOffDialog(message: String) {
        AlertDialog.Builder(this)
            .setTitle("WiFi is Off")
            .setMessage("$message\n\nOpen WiFi settings?")
            .setPositiveButton("Open Settings") { _, _ ->
                startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ── Selected Files ────────────────────────────────────────────────────────

    private fun addSelectedFiles(uris: List<Uri>) {
        var added = 0
        for (uri in uris) {
            if (selectedFiles.none { it.uri == uri }) {
                val (name, size) = getFileInfo(uri)
                selectedFiles.add(SelectedFile(uri, name, size))
                added++
            }
        }
        if (added > 0) selectedFilesAdapter.notifyDataSetChanged()
        updateSelectedFilesUI()
    }

    private fun updateSelectedFilesUI() {
        if (selectedFiles.isEmpty()) {
            binding.cardSelectedFiles.visibility = View.GONE
        } else {
            binding.cardSelectedFiles.visibility = View.VISIBLE
            val totalSize = selectedFiles.sumOf { it.size }
            binding.tvSelectedFilesHeader.text = "${selectedFiles.size} file(s) selected • ${formatSize(totalSize)}"
        }
        binding.btnSendFile.isEnabled = selectedFiles.isNotEmpty() && isConnectedInAnyMode()
    }

    // ── Permissions ───────────────────────────────────────────────────────────

    private fun checkPermissionsAndInit() {
        val perms = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.CAMERA
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms += listOf(
                Manifest.permission.NEARBY_WIFI_DEVICES,
                Manifest.permission.READ_MEDIA_IMAGES,
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_AUDIO
            )
        } else {
            perms.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        val missing = perms.filter {
            ActivityCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) initWifiDirect() else permissionLauncher.launch(missing.toTypedArray())
    }

    // ── WiFi Direct ───────────────────────────────────────────────────────────

    private fun initWifiDirect() {
        manager = getSystemService(Context.WIFI_P2P_SERVICE) as WifiP2pManager
        channel = manager.initialize(this, mainLooper, this)
        receiver = WiFiDirectBroadcastReceiver(manager, channel, this)
        registerWifiReceiver()
    }

    private fun registerWifiReceiver() {
        val filter = IntentFilter().apply {
            addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION)
        }
        registerReceiver(receiver, filter)
    }

    fun setWifiP2pEnabled(enabled: Boolean) {
        isWifiP2pEnabled = enabled
        if (!enabled) {
            updateStatus("WiFi is OFF — please enable WiFi")
            updateConnectionUI(false)
        }
    }

    private fun discoverPeers() {
        discoveryRetryJob?.cancel()
        updateStatus("🔍 Scanning for nearby devices…")
        binding.progressBar.visibility = View.VISIBLE
        if (!hasLocationPerm()) { showToast("Location permission needed"); return }

        manager.discoverPeers(channel, object : WifiP2pManager.ActionListener {
            override fun onSuccess() {
                updateStatus("Scanning… (auto-retry if nothing found)")
                // Auto-retry once after 8s if no peers appear
                discoveryRetryJob = lifecycleScope.launch {
                    delay(8000)
                    if (peers.isEmpty() && isWifiP2pEnabled) {
                        updateStatus("Nothing found yet — retrying…")
                        discoverPeers()
                    }
                }
            }
            override fun onFailure(reason: Int) {
                binding.progressBar.visibility = View.GONE
                val msg = when (reason) {
                    WifiP2pManager.P2P_UNSUPPORTED -> "WiFi Direct not supported on this device"
                    WifiP2pManager.BUSY -> "System busy — try again in a moment"
                    else -> "Discovery failed (code $reason)"
                }
                updateStatus(msg); showToast(msg)
            }
        })
    }

    fun updatePeerList(deviceList: Collection<WifiP2pDevice>) {
        binding.progressBar.visibility = View.GONE
        peers.clear(); peers.addAll(deviceList)
        deviceAdapter.notifyDataSetChanged()
        if (peers.isEmpty()) {
            updateStatus("No devices found — make sure receiver tapped 📥 Receive")
            binding.tvNoPeers.visibility = View.VISIBLE
        } else {
            discoveryRetryJob?.cancel() // found devices, stop retry
            updateStatus("Found ${peers.size} device(s) — tap to connect")
            binding.tvNoPeers.visibility = View.GONE
        }
    }

    private fun connectToDevice(device: WifiP2pDevice) {
        val config = WifiP2pConfig().apply {
            deviceAddress = device.deviceAddress
            groupOwnerIntent = if (isReceiverMode) 15 else 0
        }
        if (!hasLocationPerm()) return
        updateStatus("Connecting to ${device.deviceName}…")
        binding.progressBar.visibility = View.VISIBLE

        manager.connect(channel, config, object : WifiP2pManager.ActionListener {
            override fun onSuccess() { showToast("Connection request sent to ${device.deviceName}") }
            override fun onFailure(reason: Int) {
                binding.progressBar.visibility = View.GONE
                showToast("Connection failed: $reason")
                updateStatus("Connection failed — try again")
            }
        })
    }

    fun onConnectionInfoAvailable(info: WifiP2pInfo) {
        binding.progressBar.visibility = View.GONE
        connectedDeviceInfo = info

        if (info.groupFormed) {
            val role = if (info.isGroupOwner) "Host (GO)" else "Client"
            val goIp = info.groupOwnerAddress?.hostAddress ?: "?"
            updateStatus("✓ P2P Connected as $role — GO IP: $goIp")
            updateConnectionUI(true)

            if (info.isGroupOwner && isReceiverMode && !isReceiving) {
                startReceiveServer()
            }
        }
    }

    private fun disconnect() {
        discoveryRetryJob?.cancel()
        releaseNetworkCallback()
        if (connectedDeviceInfo != null) {
            manager.removeGroup(channel, object : WifiP2pManager.ActionListener {
                override fun onSuccess() = resetConnectionState()
                override fun onFailure(r: Int) = resetConnectionState()
            })
        } else {
            resetConnectionState()
        }
    }

    private fun resetConnectionState() {
        connectedDeviceInfo = null
        isHotspotMode = false
        boundNetwork = null
        isReceiverMode = false
        stopReceiveServer()
        updateConnectionUI(false)
        updateStatus("Disconnected — Ready")
        updateSelectedFilesUI() // re-evaluate send button state
    }

    override fun onChannelDisconnected() {
        showToast("WiFi Direct channel lost — reconnecting…")
        if (::manager.isInitialized) {
            channel = manager.initialize(this, mainLooper, this)
        }
    }

    // ── Receive Mode ──────────────────────────────────────────────────────────

    private fun startReceiveMode() {
        if (!::manager.isInitialized) { showToast("WiFi not ready yet — try again"); return }
        isReceiverMode = true
        binding.btnReceive.text = "⏹ Stop Receiving"
        binding.btnReceive.setBackgroundColor(getColor(R.color.red))
        updateStatus("Setting up hotspot…")
        binding.progressBar.visibility = View.VISIBLE

        manager.removeGroup(channel, object : WifiP2pManager.ActionListener {
            override fun onSuccess() = createGroupForReceiving()
            override fun onFailure(r: Int) = createGroupForReceiving()
        })
    }

    private fun createGroupForReceiving() {
        if (!hasLocationPerm()) {
            binding.progressBar.visibility = View.GONE
            showToast("Location permission needed")
            return
        }
        manager.createGroup(channel, object : WifiP2pManager.ActionListener {
            override fun onSuccess() {
                lifecycleScope.launch {
                    delay(600)
                    manager.requestGroupInfo(channel) { group ->
                        binding.progressBar.visibility = View.GONE
                        startReceiveServer()
                        if (group != null) {
                            updateStatus("📥 Ready to receive — show QR to sender")
                            showQRDialog(group.networkName, group.passphrase)
                        } else {
                            updateStatus("📥 Server active — sender can use Discover")
                        }
                    }
                }
            }
            override fun onFailure(reason: Int) {
                manager.requestGroupInfo(channel) { group ->
                    binding.progressBar.visibility = View.GONE
                    startReceiveServer()
                    if (group != null) {
                        updateStatus("📥 Ready to receive — show QR to sender")
                        showQRDialog(group.networkName, group.passphrase)
                    } else {
                        updateStatus("📥 Server active (createGroup failed: $reason) — use Discover")
                        showToast("Hotspot setup issue — try WiFi Direct discovery")
                    }
                }
            }
        })
    }

    private fun stopReceiveMode() {
        isReceiverMode = false
        stopReceiveServer()
        manager.removeGroup(channel, object : WifiP2pManager.ActionListener {
            override fun onSuccess() {}
            override fun onFailure(r: Int) {}
        })
        binding.btnReceive.text = "📥 Receive"
        binding.btnReceive.setBackgroundColor(getColor(R.color.green))
        updateStatus("Receive mode stopped")
    }

    // ── QR Code ───────────────────────────────────────────────────────────────

    private fun showQRDialog(ssid: String, passphrase: String) {
        val json = JSONObject().apply { put("s", ssid); put("p", passphrase) }.toString()
        val content = QR_PREFIX + json

        val size = 600
        val hints = mapOf(
            EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.M,
            EncodeHintType.MARGIN to 2
        )
        val matrix = QRCodeWriter().encode(content, BarcodeFormat.QR_CODE, size, size, hints)
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.RGB_565)
        for (x in 0 until size) for (y in 0 until size) {
            bmp.setPixel(x, y, if (matrix[x, y]) Color.BLACK else Color.WHITE)
        }

        val iv = ImageView(this).apply {
            setImageBitmap(bmp)
            setPadding(40, 40, 40, 16)
        }

        AlertDialog.Builder(this)
            .setTitle("📥 Ready to Receive")
            .setMessage("Have the sender tap 📷 Scan QR and scan this code")
            .setView(iv)
            .setPositiveButton("Keep Active") { d, _ -> d.dismiss() }
            .setNegativeButton("Stop Receiving") { d, _ -> d.dismiss(); stopReceiveMode() }
            .setCancelable(false)
            .show()
    }

    private fun scanQR() {
        val options = ScanOptions()
            .setDesiredBarcodeFormats(ScanOptions.QR_CODE)
            .setPrompt("Scan the receiver's QR code")
            .setCameraId(0)
            .setBeepEnabled(true)
            .setBarcodeImageEnabled(false)
        qrScanLauncher.launch(options)
    }

    private fun parseAndConnectQR(content: String) {
        try {
            val json = content.removePrefix(QR_PREFIX)
            val obj = JSONObject(json)
            val ssid = obj.getString("s")
            val passphrase = obj.getString("p")
            updateStatus("QR scanned — connecting to $ssid…")
            connectViaHotspot(ssid, passphrase)
        } catch (e: Exception) {
            showToast("Invalid QR code")
            Log.e(TAG, "QR parse error: ${e.message}")
        }
    }

    // ── Hotspot Connection (sender after QR scan) ─────────────────────────────

    private fun connectViaHotspot(ssid: String, passphrase: String) {
        binding.progressBar.visibility = View.VISIBLE
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            connectViaNetworkSpecifier(ssid, passphrase)
        } else {
            @Suppress("DEPRECATION")
            connectLegacyWifi(ssid, passphrase)
        }
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    private fun connectViaNetworkSpecifier(ssid: String, passphrase: String) {
        val specifier = WifiNetworkSpecifier.Builder()
            .setSsid(ssid)
            .setWpa2Passphrase(passphrase)
            .build()

        val request = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .setNetworkSpecifier(specifier)
            .build()

        val cm = getSystemService(ConnectivityManager::class.java)
        releaseNetworkCallback()

        hotspotConnectJob?.cancel()
        hotspotConnectJob = lifecycleScope.launch {
            delay(15_000)
            if (!isHotspotMode) {
                releaseNetworkCallback()
                binding.progressBar.visibility = View.GONE
                updateStatus("⏱ Connection timed out — make sure receiver's QR is still active")
                showToast("Timed out — try scanning QR again")
            }
        }

        wifiNetworkCallback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                hotspotConnectJob?.cancel()
                boundNetwork = network
                isHotspotMode = true
                runOnUiThread {
                    binding.progressBar.visibility = View.GONE
                    updateStatus("✅ Connected! Pick files and tap 🚀 Send Files")
                    updateConnectionUI(true)
                }
            }
            override fun onUnavailable() {
                hotspotConnectJob?.cancel()
                runOnUiThread {
                    binding.progressBar.visibility = View.GONE
                    updateStatus("❌ Could not connect — receiver may need to restart Receive mode")
                    showToast("Connection failed — try again")
                }
            }
            override fun onLost(network: Network) {
                if (boundNetwork == network) {
                    boundNetwork = null; isHotspotMode = false
                    runOnUiThread { updateStatus("Connection lost") }
                }
            }
        }
        cm.requestNetwork(request, wifiNetworkCallback!!)
        updateStatus("Connecting to receiver's hotspot…")
    }

    @Suppress("DEPRECATION")
    private fun connectLegacyWifi(ssid: String, passphrase: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            binding.progressBar.visibility = View.GONE
            updateStatus("📶 Connect to \"$ssid\" in WiFi settings\nPassword: $passphrase\n\nCome back here once connected")
            showToast("Open WiFi settings and connect to: $ssid")
            lifecycleScope.launch {
                val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
                val deadline = System.currentTimeMillis() + 60_000
                while (System.currentTimeMillis() < deadline) {
                    delay(1500)
                    @Suppress("DEPRECATION")
                    val currentSsid = wm.connectionInfo?.ssid?.trim('"') ?: ""
                    if (currentSsid == ssid) {
                        isHotspotMode = true; boundNetwork = null
                        withContext(Dispatchers.Main) {
                            updateStatus("✅ Connected! Pick files and tap 🚀 Send Files")
                            updateConnectionUI(true)
                        }
                        return@launch
                    }
                }
                withContext(Dispatchers.Main) {
                    updateStatus("⏱ Still not connected to \"$ssid\" — connect manually in WiFi settings")
                }
            }
            return
        }

        val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
        val cfg = WifiConfiguration().apply {
            SSID = "\"$ssid\""
            preSharedKey = "\"$passphrase\""
            allowedKeyManagement.set(WifiConfiguration.KeyMgmt.WPA_PSK)
        }
        val id = wm.addNetwork(cfg)
        if (id == -1) {
            binding.progressBar.visibility = View.GONE
            showToast("Failed to configure WiFi — connect manually to: $ssid")
            return
        }
        wm.disconnect(); wm.enableNetwork(id, true); wm.reconnect()

        lifecycleScope.launch {
            val deadline = System.currentTimeMillis() + 12_000
            while (System.currentTimeMillis() < deadline) {
                delay(1000)
                @Suppress("DEPRECATION")
                val currentSsid = wm.connectionInfo?.ssid?.trim('"') ?: ""
                if (currentSsid == ssid) {
                    isHotspotMode = true; boundNetwork = null
                    withContext(Dispatchers.Main) {
                        binding.progressBar.visibility = View.GONE
                        updateStatus("✅ Connected! Pick files and tap 🚀 Send Files")
                        updateConnectionUI(true)
                    }
                    return@launch
                }
            }
            withContext(Dispatchers.Main) {
                binding.progressBar.visibility = View.GONE
                isHotspotMode = true; boundNetwork = null
                updateStatus("⚠️ Connection unconfirmed — try tapping 🚀 Send Files")
                updateConnectionUI(true)
            }
        }
    }

    private fun releaseNetworkCallback() {
        wifiNetworkCallback?.let {
            try { getSystemService(ConnectivityManager::class.java).unregisterNetworkCallback(it) }
            catch (_: Exception) {}
            wifiNetworkCallback = null
        }
    }

    // ── TCP Receive Server ────────────────────────────────────────────────────

    private fun startReceiveServer() {
        if (isReceiving) return
        isReceiving = true

        serverJob?.cancel()
        serverJob = lifecycleScope.launch(Dispatchers.IO) {
            var serverSocket: ServerSocket? = null
            try {
                serverSocket = ServerSocket(SERVER_PORT)
                serverSocket.reuseAddress = true
                serverSocket.receiveBufferSize = BUFFER_SIZE
                Log.d(TAG, "Server listening on :$SERVER_PORT")

                while (isActive && isReceiving) {
                    try {
                        val client = serverSocket.accept()
                        client.receiveBufferSize = BUFFER_SIZE
                        launch { handleIncomingFiles(client) }
                    } catch (e: Exception) {
                        if (isActive && isReceiving) Log.e(TAG, "Accept error: ${e.message}")
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Server error: ${e.message}")
                withContext(Dispatchers.Main) { showToast("Server error: ${e.message}") }
            } finally {
                serverSocket?.close()
            }
        }
    }

    private fun stopReceiveServer() {
        isReceiving = false
        serverJob?.cancel()
        serverJob = null
    }

    // Protocol: [int: fileCount] then for each file: [int: nameLen][bytes: name][long: size][bytes: data]
    private suspend fun handleIncomingFiles(socket: Socket) {
        try {
            val input = DataInputStream(BufferedInputStream(socket.getInputStream(), BUFFER_SIZE))
            val fileCount = input.readInt()

            withContext(Dispatchers.Main) {
                updateStatus("Receiving $fileCount file(s)…")
            }

            val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            downloadsDir.mkdirs()

            var allReceived = 0L
            for (i in 1..fileCount) {
                val nameLen = input.readInt()
                val nameBytes = ByteArray(nameLen)
                input.readFully(nameBytes)
                val fileName = String(nameBytes, Charsets.UTF_8)
                val fileSize = input.readLong()

                withContext(Dispatchers.Main) {
                    showProgressUI(true, fileName, fileSize, i, fileCount)
                    updateStatus("Receiving $i/$fileCount: $fileName (${formatSize(fileSize)})")
                }

                val outFile = File(downloadsDir, getUniqueFileName(downloadsDir, fileName))
                val output = BufferedOutputStream(FileOutputStream(outFile), BUFFER_SIZE)
                val buffer = ByteArray(BUFFER_SIZE)
                var received = 0L
                val startTime = System.currentTimeMillis()

                while (received < fileSize) {
                    val toRead = minOf(buffer.size.toLong(), fileSize - received).toInt()
                    val read = input.read(buffer, 0, toRead)
                    if (read == -1) break
                    output.write(buffer, 0, read)
                    received += read

                    val pct = ((received * 100) / fileSize).toInt()
                    val elapsed = (System.currentTimeMillis() - startTime) / 1000.0
                    val speed = if (elapsed > 0) received / elapsed / 1024 / 1024 else 0.0
                    withContext(Dispatchers.Main) { updateProgress(pct, received, fileSize, speed) }
                }
                output.flush(); output.close()
                allReceived += received
            }

            input.close(); socket.close()

            withContext(Dispatchers.Main) {
                showProgressUI(false, "", 0)
                updateStatus("✅ Received $fileCount file(s) — ${formatSize(allReceived)} total → Downloads")
                showToast("$fileCount file(s) saved to Downloads")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Receive error: ${e.message}")
            withContext(Dispatchers.Main) {
                showProgressUI(false, "", 0)
                updateStatus("❌ Receive failed: ${e.message}")
            }
        }
    }

    // ── TCP Send ──────────────────────────────────────────────────────────────

    private fun sendFiles() {
        val hostIp: String = when {
            isHotspotMode -> GO_IP
            connectedDeviceInfo?.isGroupOwner == false ->
                connectedDeviceInfo?.groupOwnerAddress?.hostAddress ?: run {
                    showToast("Cannot determine receiver IP"); return
                }
            else -> {
                showToast("Role conflict — tap Disconnect and let the other device Discover you")
                return
            }
        }

        val filesToSend = selectedFiles.toList() // snapshot

        lifecycleScope.launch(Dispatchers.IO) {
            var socket: Socket? = null
            try {
                withContext(Dispatchers.Main) {
                    updateStatus("Connecting to $hostIp…")
                    showProgressUI(true, filesToSend.first().name, filesToSend.first().size, 1, filesToSend.size)
                }

                socket = connectToHost(hostIp)
                val output = DataOutputStream(BufferedOutputStream(socket.getOutputStream(), BUFFER_SIZE))

                // Write file count
                output.writeInt(filesToSend.size)

                var totalBytesSent = 0L
                for ((index, file) in filesToSend.withIndex()) {
                    withContext(Dispatchers.Main) {
                        showProgressUI(true, file.name, file.size, index + 1, filesToSend.size)
                        updateStatus("Sending ${index + 1}/${filesToSend.size}: ${file.name}")
                    }

                    val nameBytes = file.name.toByteArray(Charsets.UTF_8)
                    output.writeInt(nameBytes.size)
                    output.write(nameBytes)
                    output.writeLong(file.size)

                    val inputStream = contentResolver.openInputStream(file.uri)
                        ?: throw IOException("Cannot open: ${file.name}")
                    val buffer = ByteArray(BUFFER_SIZE)
                    var sent = 0L
                    val startTime = System.currentTimeMillis()

                    while (true) {
                        val read = inputStream.read(buffer)
                        if (read == -1) break
                        output.write(buffer, 0, read)
                        sent += read
                        totalBytesSent += read

                        val pct = if (file.size > 0) ((sent * 100) / file.size).toInt() else 0
                        val elapsed = (System.currentTimeMillis() - startTime) / 1000.0
                        val speed = if (elapsed > 0) sent / elapsed / 1024 / 1024 else 0.0
                        withContext(Dispatchers.Main) { updateProgress(pct, sent, file.size, speed) }
                    }
                    inputStream.close()
                }
                output.flush()

                withContext(Dispatchers.Main) {
                    showProgressUI(false, "", 0)
                    updateStatus("✅ Sent ${filesToSend.size} file(s) — ${formatSize(totalBytesSent)} total")
                    showToast("${filesToSend.size} file(s) sent!")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Send error: ${e.message}")
                withContext(Dispatchers.Main) {
                    showProgressUI(false, "", 0)
                    updateStatus("❌ Send failed: ${e.message}")
                    showToast("Send failed: ${e.message}")
                }
            } finally {
                try { socket?.close() } catch (_: Exception) {}
            }
        }
    }

    private suspend fun connectToHost(hostIp: String): Socket {
        val maxAttempts = 3
        var lastException: Exception? = null
        for (attempt in 1..maxAttempts) {
            try {
                val s = Socket()
                s.sendBufferSize = BUFFER_SIZE
                s.tcpNoDelay = true
                boundNetwork?.bindSocket(s)
                s.connect(InetSocketAddress(hostIp, SERVER_PORT), 6000)
                return s
            } catch (e: Exception) {
                lastException = e
                if (attempt < maxAttempts) {
                    withContext(Dispatchers.Main) { updateStatus("Attempt $attempt failed — retrying…") }
                    delay(2000)
                }
            }
        }
        throw lastException ?: IOException("Could not connect after $maxAttempts attempts")
    }

    // ── UI Helpers ────────────────────────────────────────────────────────────

    private fun updateStatus(msg: String) { binding.tvStatus.text = msg }

    private fun updateConnectionUI(connected: Boolean) {
        binding.btnDisconnect.visibility = if (connected) View.VISIBLE else View.GONE
        binding.btnSendFile.isEnabled = connected && selectedFiles.isNotEmpty()
        if (!connected) {
            connectedDeviceInfo = null; isHotspotMode = false; boundNetwork = null
        }
    }

    private fun showProgressUI(
        show: Boolean, fileName: String, fileSize: Long,
        fileIndex: Int = 1, fileCount: Int = 1
    ) {
        binding.cardProgress.visibility = if (show) View.VISIBLE else View.GONE
        if (show) {
            binding.tvProgressFile.text = fileName
            binding.tvProgressSize.text = formatSize(fileSize)
            binding.progressTransfer.progress = 0
            binding.tvProgressPercent.text = "0%"
            binding.tvProgressSpeed.text = ""
            if (fileCount > 1) {
                binding.tvProgressFileCount.text = "File $fileIndex / $fileCount"
                binding.tvProgressFileCount.visibility = View.VISIBLE
            } else {
                binding.tvProgressFileCount.visibility = View.GONE
            }
        }
    }

    private fun updateProgress(percent: Int, transferred: Long, total: Long, speedMBps: Double) {
        binding.progressTransfer.progress = percent
        binding.tvProgressPercent.text = "$percent%"
        binding.tvProgressTransferred.text = "${formatSize(transferred)} / ${formatSize(total)}"
        binding.tvProgressSpeed.text = "${String.format("%.1f", speedMBps)} MB/s"
    }

    private fun getFileInfo(uri: Uri): Pair<String, Long> {
        var name = "unknown_file"; var size = 0L
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val ni = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val si = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (ni >= 0) name = cursor.getString(ni) ?: name
                if (si >= 0) size = cursor.getLong(si)
            }
        }
        return Pair(name, size)
    }

    private fun getUniqueFileName(dir: File, name: String): String {
        var result = name; var counter = 1
        while (File(dir, result).exists()) {
            val dot = name.lastIndexOf('.')
            result = if (dot > 0) "${name.substring(0, dot)}($counter)${name.substring(dot)}" else "$name($counter)"
            counter++
        }
        return result
    }

    private fun formatSize(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB")
        val i = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt().coerceAtMost(3)
        return "${DecimalFormat("#,##0.#").format(bytes / Math.pow(1024.0, i.toDouble()))} ${units[i]}"
    }

    private fun hasLocationPerm(): Boolean {
        val hasLocation = ActivityCompat.checkSelfPermission(
            this, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        val hasNearby = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ActivityCompat.checkSelfPermission(
                this, Manifest.permission.NEARBY_WIFI_DEVICES
            ) == PackageManager.PERMISSION_GRANTED
        } else true
        return hasLocation && hasNearby
    }

    private fun showToast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
