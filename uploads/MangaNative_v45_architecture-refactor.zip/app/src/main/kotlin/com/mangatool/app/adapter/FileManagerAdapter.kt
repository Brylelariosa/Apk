package com.mangatool.app.adapter

import android.view.HapticFeedbackConstants
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.mangatool.app.R
import com.mangatool.app.manager.SelectionManager
import java.io.File
import java.text.DecimalFormat

data class FileEntry(val file: File, val isParent: Boolean = false)

class FileManagerAdapter(
    private val onFolderClick: (File) -> Unit,
    private val onSelectionChanged: (Set<File>) -> Unit
) : RecyclerView.Adapter<FileManagerAdapter.VH>() {

    companion object {
        // Payload for selection-only partial rebind — avoids re-setting icon/name/info.
        private const val PAYLOAD_SELECTION = "sel"
    }

    private var entries: List<FileEntry> = emptyList()
    private val selection = SelectionManager<File>()

    /**
     * Position of the last file selected by a plain tap — the "anchor" for
     * range selection. When the user then long-presses a different row,
     * [selectRange] fills in everything between the anchor and the held row
     * (in either direction — the anchor can be above OR below the hold).
     *
     * Cleared whenever the anchor file itself is deselected, the list is
     * rebuilt (setEntries), or the selection is cleared — so a stale anchor
     * from a previous folder/session can never leak into a new range.
     */
    private var anchorPosition: Int? = null

    fun setEntries(list: List<FileEntry>) {
        val oldEntries = entries
        entries = list
        selection.clear()
        anchorPosition = null
        DiffUtil.calculateDiff(object : DiffUtil.Callback() {
            override fun getOldListSize() = oldEntries.size
            override fun getNewListSize() = entries.size
            override fun areItemsTheSame(o: Int, n: Int) =
                oldEntries[o].file.absolutePath == entries[n].file.absolutePath &&
                oldEntries[o].isParent == entries[n].isParent
            override fun areContentsTheSame(o: Int, n: Int) = areItemsTheSame(o, n)
        }).dispatchUpdatesTo(this)
        onSelectionChanged(selection.asSet())
    }

    fun selectAll() {
        anchorPosition = null
        selection.selectAll(entries.filter { !it.isParent && !it.file.isDirectory }.map { it.file })
        // Payload-only rebind: only updates check/background, skips icon+name+info.
        notifyItemRangeChanged(0, entries.size, PAYLOAD_SELECTION)
        onSelectionChanged(selection.asSet())
    }

    fun clearSelection() {
        selection.clear()
        anchorPosition = null
        notifyItemRangeChanged(0, entries.size, PAYLOAD_SELECTION)
        onSelectionChanged(selection.asSet())
    }

    /** True once every selectable (non-folder, non-parent) row is selected — drives the
     *  toolbar's Select All ⇄ Clear All toggle. */
    fun isAllSelected(): Boolean =
        selection.isAllSelected(entries.filter { !it.isParent && !it.file.isDirectory }.map { it.file })

    fun getSelected(): Set<File> = selection.asSet()

    /**
     * Long-press range selection — selects every same-type file between the
     * held row and an anchor point, in whichever direction the anchor happens
     * to sit relative to the hold:
     *
     *   • No anchor yet (nothing tapped first): falls back to the original
     *     behavior — select this row and every matching-type file ABOVE it
     *     (position 0..here). This keeps the one-gesture "select everything
     *     above" shortcut working exactly as before.
     *
     *   • Anchor exists (a file was tapped first, above OR below the hold):
     *     select the whole span between the anchor and the held row,
     *     inclusive — so tapping a file at the bottom, then long-pressing one
     *     near the top, selects everything in between, not just "above".
     *
     * Matching is scoped to the current folder listing only (not recursive
     * into subfolders) since entries is a flat, already-sorted list of the
     * folder the user is currently looking at.
     */
    private fun selectRange(position: Int, view: View) {
        val target = entries.getOrNull(position) ?: return
        if (target.isParent || target.file.isDirectory) return
        val ext = target.file.extension.lowercase()

        val anchor = anchorPosition
        val anchorEntry = anchor?.let { entries.getOrNull(it) }
        val anchorUsable = anchor != null && anchor != position &&
            anchorEntry != null && !anchorEntry.isParent && !anchorEntry.file.isDirectory &&
            selection.contains(anchorEntry.file)

        val (start, end) = if (anchorUsable) {
            minOf(anchor!!, position) to maxOf(anchor, position)
        } else {
            0 to position // no usable anchor — original "select above" behavior
        }

        var added = 0
        for (i in start..end) {
            val e = entries.getOrNull(i) ?: continue
            if (e.isParent || e.file.isDirectory) continue
            if (e.file.extension.lowercase() == ext && selection.select(e.file)) added++
        }
        // The held row becomes the new anchor, so a third long-press keeps extending the range.
        anchorPosition = position
        if (added == 0) return // nothing new — target (and range) were already fully selected

        view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        notifyItemRangeChanged(start, end - start + 1, PAYLOAD_SELECTION)
        onSelectionChanged(selection.asSet())
        val label = if (ext.isEmpty()) "matching" else ".$ext"
        val suffix = if (anchorUsable) "" else " above"
        Toast.makeText(
            view.context,
            "Selected $added $label file${if (added == 1) "" else "s"}$suffix",
            Toast.LENGTH_SHORT
        ).show()
    }

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val accentBar: View    = v.findViewById(R.id.vAccentBar)
        val iconHolder: View   = v.findViewById(R.id.flIconHolder)
        val icon: ImageView    = v.findViewById(R.id.ivFileIcon)
        val name: TextView     = v.findViewById(R.id.tvFileName)
        val typeChip: TextView = v.findViewById(R.id.tvTypeChip)
        val info: TextView     = v.findViewById(R.id.tvFileInfo)
        val check: View        = v.findViewById(R.id.vCheck)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_file, parent, false))

    override fun getItemCount() = entries.size

    /** Payload-aware partial rebind — only updates selection visuals. */
    override fun onBindViewHolder(holder: VH, position: Int, payloads: MutableList<Any>) {
        if (payloads.isNotEmpty() && payloads.all { it == PAYLOAD_SELECTION }) {
            val entry = entries.getOrNull(position) ?: return
            if (!entry.isParent && !entry.file.isDirectory) {
                val isSelected = selection.contains(entry.file)
                holder.check.visibility = if (isSelected) View.VISIBLE else View.INVISIBLE
                holder.itemView.setBackgroundResource(
                    if (isSelected) R.drawable.bg_file_item_selected else R.drawable.bg_file_item
                )
            }
            return
        }
        super.onBindViewHolder(holder, position, payloads)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val entry = entries[position]
        val file  = entry.file

        if (entry.isParent) {
            holder.name.text = "↑  Parent folder"
            holder.info.text = ""
            holder.typeChip.visibility = View.GONE
            holder.icon.setImageResource(R.drawable.ic_file_parent_up)
            holder.icon.clearColorFilter()
            holder.iconHolder.setBackgroundResource(R.drawable.bg_icon_holder_neutral)
            holder.accentBar.setBackgroundColor(0x00000000)
            holder.check.visibility = View.GONE
            holder.itemView.setBackgroundResource(R.drawable.bg_file_item_parent)
            holder.itemView.setOnClickListener { onFolderClick(file) }
            holder.itemView.setOnLongClickListener(null)
            return
        }

        if (file.isDirectory) {
            val count = file.listFiles()?.size ?: 0
            holder.name.text = file.name
            holder.info.text = "$count item${if (count != 1) "s" else ""}"
            holder.typeChip.visibility = View.GONE
            holder.icon.setImageResource(R.drawable.ic_file_folder)
            holder.icon.clearColorFilter()
            holder.iconHolder.setBackgroundResource(R.drawable.bg_icon_holder_neutral)
            holder.accentBar.setBackgroundColor(0x00000000)
            holder.check.visibility = View.GONE
            holder.itemView.setBackgroundResource(R.drawable.bg_file_item)
            holder.itemView.setOnClickListener { onFolderClick(file) }
            holder.itemView.setOnLongClickListener(null)
        } else {
            val ext = file.extension.lowercase()
            val isMhtml = ext == "mhtml" || ext == "mht"
            // One accent per type, reused across icon tint, chip, and the left spine —
            // so all three visual cues always agree with each other.
            val accentColor = if (isMhtml) 0xFFA78BFA.toInt() else 0xFF60A5FA.toInt()

            holder.name.text = file.name
            holder.info.text = formatSize(file.length())
            holder.typeChip.visibility = View.VISIBLE
            holder.typeChip.text = ext.ifEmpty { "FILE" }.uppercase()
            holder.typeChip.setTextColor(accentColor)
            holder.typeChip.setBackgroundResource(
                if (isMhtml) R.drawable.bg_type_chip_mhtml else R.drawable.bg_type_chip_image
            )
            holder.accentBar.setBackgroundColor(accentColor)
            holder.iconHolder.setBackgroundResource(
                if (isMhtml) R.drawable.bg_icon_holder_mhtml else R.drawable.bg_icon_holder_image
            )
            // Distinct icon + tint per file type — makes it easy to scan which rows
            // share a type at a glance, which matters now that long-press range
            // selection only picks up same-type files within the held span.
            holder.icon.setImageResource(if (isMhtml) R.drawable.ic_file_mhtml else R.drawable.ic_file_image)
            holder.icon.setColorFilter(accentColor)
            val isSelected = selection.contains(file)
            holder.check.visibility = if (isSelected) View.VISIBLE else View.INVISIBLE
            holder.itemView.setBackgroundResource(
                if (isSelected) R.drawable.bg_file_item_selected else R.drawable.bg_file_item
            )
            holder.itemView.setOnClickListener {
                val livePos = holder.bindingAdapterPosition.takeIf { it >= 0 } ?: position
                val liveFile = entries.getOrNull(livePos)?.file ?: return@setOnClickListener
                if (selection.contains(liveFile)) {
                    selection.deselect(liveFile)
                    // Deselecting the anchor row invalidates it as a range endpoint.
                    if (anchorPosition == livePos) anchorPosition = null
                } else {
                    selection.select(liveFile)
                    // A plain tap marks this row as the anchor for the next long-press range.
                    anchorPosition = livePos
                }
                notifyItemChanged(livePos, PAYLOAD_SELECTION)
                onSelectionChanged(selection.asSet())
            }
            holder.itemView.setOnLongClickListener {
                val livePos = holder.bindingAdapterPosition.takeIf { it >= 0 } ?: position
                selectRange(livePos, holder.itemView)
                true
            }
        }
    }

    private fun formatSize(bytes: Long): String = when {
        bytes < 1_024L     -> "$bytes B"
        bytes < 1_048_576L -> "${bytes / 1_024} KB"
        else               -> DecimalFormat("#.#").format(bytes.toDouble() / 1_048_576.0) + " MB"
    }
}

