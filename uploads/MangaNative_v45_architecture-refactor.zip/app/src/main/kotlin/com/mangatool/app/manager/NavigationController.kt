package com.mangatool.app.manager

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.activity.result.contract.ActivityResultContracts
import com.mangatool.app.AppMode
import com.mangatool.app.AppState
import com.mangatool.app.ImagePreviewActivity
import com.mangatool.app.InternalFileManagerActivity
import com.mangatool.app.MainActivity
import com.mangatool.app.MergeImagePickerActivity

/**
 * Owns every ActivityResultLauncher MainActivity registers, routes their
 * results to the right handler, and decides which screen to open for
 * "+Add" (file browser vs system picker vs merge picker) and incoming
 * share intents.
 *
 * Registered launchers must be created unconditionally before the host
 * Activity leaves CREATED — this class is constructed synchronously inside
 * MainActivity.onCreate(), which satisfies that requirement exactly the way
 * the original inline field declarations did.
 */
class NavigationController(
    private val activity: MainActivity,
    private val fileManager: FileManager,
    private val uiState: UiStateManager,
    /** Called when ImagePreviewActivity returns — currently just triggers a filter/stats refresh. */
    private val onPreviewClosed: () -> Unit
) {

    // ── File open pickers ──────────────────────────────────────────────────────
    // Registered but never actually launched anywhere in the app today — kept
    // as-is (dead but harmless) rather than pruned, since deciding whether they
    // were meant as a future fallback entry point is outside an architecture-only
    // refactor's scope.
    private val openDocLauncher = activity.registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { r -> if (r.resultCode == Activity.RESULT_OK) handlePickResult(r.data) }

    private val getContentLauncher = activity.registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { r -> if (r.resultCode == Activity.RESULT_OK) handlePickResult(r.data) }

    private val mergePickerLauncher = activity.registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            val uriStrings = r.data?.getStringArrayListExtra(MergeImagePickerActivity.RESULT_URIS)
            val folderName = r.data?.getStringExtra(MergeImagePickerActivity.RESULT_FOLDER_NAME) ?: ""
            val uris = uriStrings?.mapNotNull { runCatching { Uri.parse(it) }.getOrNull() } ?: emptyList()
            if (uris.isNotEmpty()) fileManager.processFiles(uris, folderName)
        }
    }

    // ── Built-in file manager launcher ─────────────────────────────────────────
    private val internalFileManagerLauncher = activity.registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            val uriStrings = r.data?.getStringArrayListExtra(InternalFileManagerActivity.RESULT_URIS)
            val uris = uriStrings?.mapNotNull { runCatching { Uri.parse(it) }.getOrNull() } ?: emptyList()
            if (uris.isNotEmpty()) fileManager.processFiles(uris)
        }
    }

    private val previewLauncher = activity.registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { r -> if (r.resultCode == Activity.RESULT_OK) { onPreviewClosed() } }

    // ── Folder pickers — Settings "Choose" button ──────────────────────────────
    private val settingsExtractFolderLauncher = activity.registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri -> uri?.let { fileManager.persistAndRememberFolder(it, isMerge = false); uiState.updateSettingsFolderLabels() } }

    private val settingsMergeFolderLauncher = activity.registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri -> uri?.let { fileManager.persistAndRememberFolder(it, isMerge = true); uiState.updateSettingsFolderLabels() } }

    fun launchExtractFolderPicker() = settingsExtractFolderLauncher.launch(null)
    fun launchMergeFolderPicker()   = settingsMergeFolderLauncher.launch(null)

    // ── "+Add" routing ─────────────────────────────────────────────────────────
    fun showFileManagerChooser() {
        if (AppState.currentMode == AppMode.MERGE) {
            mergePickerLauncher.launch(Intent(activity, MergeImagePickerActivity::class.java)); return
        }
        internalFileManagerLauncher.launch(Intent(activity, InternalFileManagerActivity::class.java))
    }

    private fun handlePickResult(data: Intent?) {
        val uris: List<Uri> = when {
            data?.clipData != null -> (0 until data.clipData!!.itemCount).map { data.clipData!!.getItemAt(it).uri }
            data?.data != null     -> listOf(data.data!!)
            else                   -> emptyList()
        }
        if (uris.isNotEmpty()) fileManager.processFiles(uris)
    }

    // ── Image preview ──────────────────────────────────────────────────────────
    /** Opens a group's image at [imageIdx] in the reader. */
    fun launchImagePreview(groupIdx: Int, imageIdx: Int) {
        previewLauncher.launch(Intent(activity, ImagePreviewActivity::class.java).apply {
            putExtra(ImagePreviewActivity.EXTRA_GROUP_IDX, groupIdx)
            putExtra(ImagePreviewActivity.EXTRA_IMAGE_IDX, imageIdx)
            putExtra(ImagePreviewActivity.EXTRA_IS_MERGE, AppState.currentMode == AppMode.MERGE)
        })
    }

    /** Opens a group's FILTERED image list at [filteredIdx] in the reader. */
    fun launchFilteredImagePreview(groupIdx: Int, filteredIdx: Int) {
        previewLauncher.launch(Intent(activity, ImagePreviewActivity::class.java).apply {
            putExtra(ImagePreviewActivity.EXTRA_GROUP_IDX, groupIdx)
            putExtra(ImagePreviewActivity.EXTRA_IMAGE_IDX, filteredIdx)
            putExtra(ImagePreviewActivity.EXTRA_IS_FILTERED, true)
        })
    }

    // ── Incoming share intent ──────────────────────────────────────────────────
    fun handleIncomingShareIntent(intent: Intent?) {
        if (intent == null) return
        val uris = mutableListOf<Uri>()
        when (intent.action) {
            Intent.ACTION_SEND_MULTIPLE -> {
                val extras = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
                    intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java)
                else @Suppress("DEPRECATION") intent.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)
                extras?.forEach { uris.add(it) }
            }
            Intent.ACTION_SEND -> {
                val uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
                    intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
                else @Suppress("DEPRECATION") intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
                uri?.let { uris.add(it) }
            }
        }
        if (uris.isNotEmpty()) { fileManager.processFiles(uris); activity.setIntent(Intent(Intent.ACTION_MAIN)) }
    }
}
