package com.mangatool.app.manager

/**
 * Reusable ordered multi-select state holder.
 *
 * Backs the "tap to select, long-press to range-select, Select All" pattern
 * that InternalFileManagerActivity/FileManagerAdapter and
 * MergeImagePickerActivity previously implemented as two independent,
 * near-identical Set<T> + toggle/selectAll/clear blocks. This class is now
 * the single implementation of that bookkeeping.
 *
 * Selection order is preserved (LinkedHashSet) since MergeImagePickerActivity
 * shows numbered badges reflecting the order items were tapped in.
 *
 * Deliberately out of scope: this class only tracks *which* items are
 * selected. It knows nothing about RecyclerView positions, DiffUtil, or
 * payload notifications, and it does not manage "range anchor" state —
 * FileManagerAdapter's long-press range-select only extends across
 * same-file-type rows, while MergeImagePickerActivity's replicates the
 * anchor's selected state across the whole span (can select OR deselect
 * a range). Those two gestures are genuinely different algorithms, not
 * duplicated logic, so each screen keeps its own anchor field and calls
 * into this class only for the actual add/remove/contains bookkeeping.
 */
class SelectionManager<T> {

    private val selected = linkedSetOf<T>()

    val size: Int get() = selected.size
    fun isEmpty(): Boolean = selected.isEmpty()
    fun contains(item: T): Boolean = item in selected

    /** Position within the selection order (0 = selected first). -1 if not selected.
     *  Used for MergeImagePickerActivity's numbered selection badges. */
    fun orderOf(item: T): Int = selected.indexOf(item)

    /** Defensive copy — callers can't mutate our internal state through this. */
    fun asSet(): Set<T> = selected.toSet()

    /** Adds [item]. Returns true if it was newly added (false if already selected) —
     *  same contract as [MutableSet.add], so callers checking "was this new" work unchanged. */
    fun select(item: T): Boolean = selected.add(item)

    /** Removes [item]. Returns true if it was present. */
    fun deselect(item: T): Boolean = selected.remove(item)

    /** Flips [item] and returns whether it ended up selected. */
    fun toggle(item: T): Boolean =
        if (item in selected) { selected.remove(item); false }
        else                  { selected.add(item); true }

    /** Replaces the ENTIRE selection with exactly [items] — anything selected
     *  outside this set is cleared. Use only when the caller truly means
     *  "select all, and only, these" (e.g. a library-wide Select All); for a
     *  scoped toggle (only affecting a subset while leaving the rest of the
     *  selection untouched), select()/deselect() each item instead. */
    fun selectAll(items: List<T>) {
        selected.clear()
        selected.addAll(items)
    }

    fun clear() = selected.clear()

    /** True once every item in [selectable] is selected (and there's at least one). */
    fun isAllSelected(selectable: List<T>): Boolean =
        selectable.isNotEmpty() && selectable.all { it in selected }

    /**
     * Flips the selection within [selectable]: everything in it that IS
     * selected becomes unselected and vice versa. Selected items outside
     * [selectable] are left untouched.
     *
     * Provided for parity with the "reverse selection" capability called
     * out in the app's selection architecture — not currently wired to a
     * button in either screen, so nothing calls this yet.
     */
    fun invert(selectable: List<T>) {
        selectable.forEach { toggle(it) }
    }
}
