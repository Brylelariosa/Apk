package android.graphics;
public class Canvas {
    public Canvas() {}
    public Canvas(Bitmap b) {}
    public void drawColor(int c) {}
    public int save() { return 0; }
    public void restore() {}
    public void scale(float x, float y) {}
    public void translate(float x, float y) {}
    public void rotate(float d) {}
    public void drawRect(float l, float t, float r, float b, Paint p) {}
    public void drawRoundRect(float l, float t, float r, float b, float rx, float ry, Paint p) {}
    public void drawCircle(float x, float y, float r, Paint p) {}
    public void drawLine(float x0, float y0, float x1, float y1, Paint p) {}
    public void drawLines(float[] pts, int off, int count, Paint p) {}
    public void drawPath(Path path, Paint p) {}
    public void drawBitmap(Bitmap b, float l, float t, Paint p) {}
    public void drawText(String s, float x, float y, Paint p) {}
}
