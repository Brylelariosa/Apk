package android.graphics;
public class Paint {
    public static final int ANTI_ALIAS_FLAG = 1, FILTER_BITMAP_FLAG = 2;
    public enum Style { FILL, STROKE, FILL_AND_STROKE }
    public enum Cap { BUTT, ROUND, SQUARE }
    public enum Join { MITER, ROUND, BEVEL }
    public enum Align { LEFT, CENTER, RIGHT }
    public Paint() {}
    public Paint(int flags) {}
    public void setStyle(Style s) {}
    public void setColor(int c) {}
    public void setAlpha(int a) {}
    public void setStrokeWidth(float w) {}
    public void setStrokeCap(Cap c) {}
    public void setStrokeJoin(Join j) {}
    public Shader setShader(Shader s) { return s; }
    public Typeface setTypeface(Typeface t) { return t; }
    public void setTextSize(float s) {}
    public void setTextAlign(Align a) {}
    public void setLetterSpacing(float s) {}
}
