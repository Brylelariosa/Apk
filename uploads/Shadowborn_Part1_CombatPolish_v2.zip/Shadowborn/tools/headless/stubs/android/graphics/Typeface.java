package android.graphics;
public class Typeface {
    public static final int BOLD = 1;
    public static Typeface create(String family, int style) { return new Typeface(); }
}
