package android.view;
import android.graphics.Canvas;
public interface SurfaceHolder {
    interface Callback {
        void surfaceCreated(SurfaceHolder h);
        void surfaceChanged(SurfaceHolder h, int format, int w, int hgt);
        void surfaceDestroyed(SurfaceHolder h);
    }
    void addCallback(Callback c);
    Canvas lockCanvas();
    Canvas lockHardwareCanvas();
    void unlockCanvasAndPost(Canvas c);
}
