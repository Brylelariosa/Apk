package android.view;
import android.content.Context;
public class View {
    public View(Context c) {}
    public void setFocusable(boolean b) {}
    public void setKeepScreenOn(boolean b) {}
    public boolean onTouchEvent(MotionEvent e) { return false; }
}
