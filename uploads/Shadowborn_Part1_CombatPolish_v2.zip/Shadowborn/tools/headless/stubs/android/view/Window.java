package android.view;
public class Window {
    public void addFlags(int f) {}
    public WindowManager.LayoutParams getAttributes() { return null; }
    public void setAttributes(WindowManager.LayoutParams p) {}
    public void setDecorFitsSystemWindows(boolean b) {}
    public WindowInsetsController getInsetsController() { return null; }
}
