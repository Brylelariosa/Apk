package android.view;
import android.content.Context;
public class SurfaceView extends View {
    public SurfaceView(Context c) { super(c); }
    public SurfaceHolder getHolder() { return null; }
}
