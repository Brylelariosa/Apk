package android.app;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
public class Activity extends Context {
    public SharedPreferences getSharedPreferences(String n, int m) { return null; }
    protected void onCreate(Bundle b) {}
    protected void onResume() {}
    protected void onPause() {}
    public void onWindowFocusChanged(boolean f) {}
    public void onBackPressed() {}
    public Window getWindow() { return null; }
    public void setContentView(View v) {}
    public void finish() {}
}
