package com.shadowborn.game;

import android.graphics.Canvas;
import java.util.Random;

/** Random-input soak test: every state, random taps/buttons/resizes, rendering every frame. */
public class Monkey {
    public static void main(String[] args) {
        Canvas cv = new Canvas();
        long frames = 0;
        for (long seed = 1; seed <= 6; seed++) {
            Random r = new Random(seed);
            Game g = Sim.newGame(new Sim.Prefs());
            if (seed % 2 == 0) { g.save.dj = true; g.save.shards = 400; g.player.hasDJ = true; }
            boolean l = false, rt = false, j = false, at = false, d = false;
            int maxState = 0, rooms = 0, deaths = 0, bossFrames = 0;
            int lastRoom = 0;
            for (int f = 0; f < 120000; f++) {
                if (f % 7 == 0) { l = r.nextInt(3) == 0; rt = r.nextInt(2) == 0; j = r.nextInt(4) == 0; at = r.nextInt(3) == 0; d = r.nextInt(9) == 0; g.input.set(l, rt, j, at, d); }
                if (r.nextInt(900) == 0) g.taps.add(new float[] {r.nextFloat() * g.vw, r.nextFloat() * 360f});
                if (r.nextInt(5000) == 0) g.taps.add(new float[] {-1f, -1f});
                if (g.state == Game.MENU && r.nextInt(40) == 0) Sim.tap(g, g.btnPlay);
                if (g.state == Game.DEAD && g.deadT > 1.3f && r.nextInt(30) == 0) Sim.tap(g, g.dBtn[0]);
                if (r.nextInt(20000) == 0) g.setSize(640f + r.nextInt(300), 1f + r.nextFloat());
                // occasionally warp around to exercise every room and the boss arena
                if (g.state == Game.PLAY && r.nextInt(6000) == 0) {
                    g.save.cpRoom = r.nextInt(3);
                    g.save.cpCol = 3; g.save.cpRow = 9;
                    g.player.hp = 0;
                }
                if (g.state == Game.PLAY && g.player.hp < 30 && r.nextInt(50) == 0) g.player.hp = g.player.maxHp;
                g.update(1f / 60f);
                g.render(cv);
                frames++;
                if (g.world.index != lastRoom) { rooms++; lastRoom = g.world.index; }
                if (g.state == Game.DEAD && g.deadT < 0.02f) deaths++;
                if (g.boss != null && g.boss.active()) bossFrames++;
            }
            System.out.println("seed " + seed + " ok: roomChanges=" + rooms + " deaths=" + deaths + " bossFrames=" + bossFrames + " shards=" + g.save.shards + " state=" + g.state);
        }
        System.out.println("MONKEY OK frames=" + frames);
    }
}
