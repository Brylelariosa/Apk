package com.shadowborn.game;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import java.util.HashMap;
import java.util.Map;

/** Headless simulation harness (not shipped): drives Game with a scripted bot and checks behaviour. */
public class Sim {
    static final float DT = 1f / 60f;

    static class Prefs implements SharedPreferences {
        final Map<String, Object> m = new HashMap<>();
        public int getInt(String k, int d) { Object o = m.get(k); return o == null ? d : (Integer) o; }
        public boolean getBoolean(String k, boolean d) { Object o = m.get(k); return o == null ? d : (Boolean) o; }
        public String getString(String k, String d) { Object o = m.get(k); return o == null ? d : (String) o; }
        public Editor edit() {
            return new Editor() {
                public Editor putInt(String k, int v) { m.put(k, v); return this; }
                public Editor putBoolean(String k, boolean v) { m.put(k, v); return this; }
                public Editor putString(String k, String v) { m.put(k, v); return this; }
                public void apply() { }
            };
        }
    }

    static class Ctx extends Context {
        final Prefs p;
        Ctx(Prefs p) { this.p = p; }
        public SharedPreferences getSharedPreferences(String n, int mode) { return p; }
    }

    static int failures = 0;
    static void check(boolean ok, String what) {
        System.out.println((ok ? "PASS  " : "FAIL  ") + what);
        if (!ok) failures++;
    }

    static final Canvas CV = new Canvas();

    static void tap(Game g, float[] r) {
        g.taps.add(new float[] {r[0] + r[2] / 2f, r[1] + r[3] / 2f});
        g.update(DT);
    }

    static void frame(Game g, boolean render) {
        g.update(DT);
        if (render) g.render(CV);
    }

    // ---- simple bot ----
    static int atkTimer, jumpHold;
    static boolean usedDJ;

    static void bot(Game g, boolean useDJ) {
        Player p = g.player;
        World w = g.world;
        int feetRow = (int) Math.floor((p.y + p.h - 1f) / World.TS);
        int colGap = (int) Math.floor((p.cx() + 18f) / World.TS);
        int colWall = (int) Math.floor((p.cx() + 34f) / World.TS);
        boolean spike = w.isSpike(colGap, feetRow) || w.isSpike(colGap, feetRow + 1) || w.isSpike(colGap, feetRow + 2);
        boolean ground = false;
        for (int r = feetRow + 1; r <= feetRow + 3; r++) if (w.solid(colGap, r)) ground = true;
        boolean gap = spike || !ground;
        boolean wall = w.solid(colWall, feetRow) || w.solid(colWall, feetRow - 1);
        boolean jump = false, attack = false;
        if (p.onGround) {
            usedDJ = false;
            if ((gap || wall) && jumpHold <= 0) jumpHold = 20;
        } else if (useDJ && !usedDJ && p.vy > -40f && p.hasDJ) {
            usedDJ = true;
            jump = true;
            jumpHold = 14;
        }
        if (jumpHold > 0) { jump = true; jumpHold--; }
        Enemy near = null;
        float best = 1e9f;
        for (Enemy e : g.enemies) {
            if (e.dead) continue;
            float dx = e.cx() - p.cx();
            if (dx > -10f && dx < 62f && Math.abs(e.cy() - p.cy()) < 50f && dx < best) { best = dx; near = e; }
        }
        if (g.boss != null && g.boss.vulnerable() && Math.abs(g.boss.cx() - p.cx()) < 90f) attack = true;
        if (near != null) attack = true;
        if (attack && atkTimer <= 0) { atkTimer = 9; } else { attack = false; }
        if (atkTimer > 0) atkTimer--;
        g.input.set(false, true, jump, attack, false);
    }


    /** Brute-force: can the hero get from a standing start onto a target platform with scripted jumps? */
    static boolean reach(Game g, int room, int sx, int sRow, int dir, int tRow, int tc0, int tc1, boolean dj, String label) {
        Player p = g.player;
        for (int run = 0; run <= 45; run += 3) {
            for (int hold = 4; hold <= 26; hold += 2) {
                for (int d = -1; d <= 30; d += (dj ? 3 : 100)) {
                    g.world.load(room);
                    g.enemies.clear(); g.projs.clear(); g.pickups.clear(); g.boss = null;
                    p.hasDJ = dj; p.dead = false; p.hp = p.maxHp = 100000; p.invuln = 99f;
                    p.place(sx * 32 + 9, (sRow + 1) * 32 - p.h);
                    g.input.clear();
                    for (int i = 0; i < 4; i++) g.update(DT);
                    int jumpFrame = run;
                    for (int f = 0; f < 160; f++) {
                        boolean right = dir > 0, left = dir < 0;
                        boolean jump = f >= jumpFrame && f < jumpFrame + hold;
                        if (dj && d >= 0 && f >= jumpFrame + d && f < jumpFrame + d + 6) jump = true;
                        if (dj && d >= 0 && f == jumpFrame + d - 1) jump = false;   // release first so the second press is a new edge
                        g.input.set(left, right, jump, false, false);
                        g.update(DT);
                        if (p.onGround && Math.abs((p.y + p.h) - tRow * 32) < 0.5f && p.cx() >= tc0 * 32 && p.cx() <= (tc1 + 1) * 32) {
                            System.out.println("      " + label + ": reached with run=" + run + " hold=" + hold + " dj@" + d);
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    static Game newGame(Prefs prefs) {
        Game g = new Game(new Ctx(prefs));
        g.setSize(800f, 1f);
        return g;
    }

    public static void main(String[] args) {
        Prefs prefs = new Prefs();
        Game g = newGame(prefs);

        // ---------- menu / settings render + start
        for (int i = 0; i < 30; i++) frame(g, true);
        check(g.state == Game.MENU, "starts in main menu");
        tap(g, g.btnSettings);
        check(g.state == Game.SETTINGS, "settings opens from menu");
        frame(g, true);
        tap(g, g.sBtn[0]); tap(g, g.sBtn[1]); tap(g, g.sBtn[2]);
        check(!g.save.shake && g.save.ctrlOpacity == 100 && g.save.fps, "settings toggles work");
        tap(g, g.sBtn[0]); tap(g, g.sBtn[1]); tap(g, g.sBtn[2]);
        tap(g, g.sBtn[4]);
        check(g.state == Game.MENU, "settings back returns to menu");
        tap(g, g.btnPlay);
        check(g.state == Game.PLAY, "PLAY starts the game");
        for (int i = 0; i < 60; i++) frame(g, true);
        check(g.player.onGround, "player lands on the ground at the start");

        // ---------- room 0 traversal with single jumps only
        atkTimer = 0; jumpHold = 0;
        int frames = 0, maxX = 0;
        boolean reachedRoom1 = false;
        while (frames < 60 * 90) {
            bot(g, false);
            frame(g, frames % 4 == 0);
            frames++;
            if (g.state == Game.DEAD) { g.update(DT); break; }
            if (g.world.index == 1) { reachedRoom1 = true; break; }
        }
        check(reachedRoom1, "bot (no double jump) clears room 0 and reaches room 1 in " + frames / 60 + "s, hp=" + g.player.hp);
        check(g.save.shards > 0, "shards collected: " + g.save.shards);
        check(g.save.cpRoom == 0 && g.save.cpCol == 31, "checkpoint in room 0 was activated");

        // ---------- room 1: gating of the chasm
        for (int i = 0; i < 120; i++) { g.input.set(false, false, false, false, false); frame(g, false); }
        check(g.world.index == 1, "now in room 1 (" + g.world.room.name + ")");
        Player p = g.player;
        check(!p.hasDJ, "double jump not yet unlocked");
        Game rg = newGame(new Prefs());
        tap(rg, rg.btnPlay);
        for (int i = 0; i < 30; i++) frame(rg, false);
        check(reach(rg, 1, 7, 9, 1, 8, 8, 10, false, "floor->A"), "room1: floor -> platform A (single jump)");
        check(reach(rg, 1, 10, 7, 1, 7, 13, 15, false, "A->B"), "room1: platform A -> B (single jump)");
        check(reach(rg, 1, 15, 6, 1, 6, 18, 24, false, "B->C"), "room1: platform B -> shrine ledge (single jump)");
        check(!reach(rg, 1, 16, 9, 1, 6, 18, 24, false, "floor->C"), "room1: shrine ledge NOT reachable straight from the floor without DJ");
        check(!reach(rg, 0, 49, 9, 1, 6, 52, 56, false, "r0 floor->secret"), "room0: secret ledge NOT reachable without DJ");
        check(reach(rg, 0, 49, 9, 1, 6, 52, 56, true, "r0 floor->secret"), "room0: secret ledge reachable with DJ");
        check(reach(rg, 0, 7, 9, 1, 8, 8, 10, false, "r0 floor->low platform"), "room0: low platform reachable");
        check(reach(rg, 0, 24, 9, 1, 8, 26, 29, false, "r0 floor->mid platform"), "room0: mid platform reachable");
        // teleport to chasm edge without DJ and try to cross with jump
        p.hp = p.maxHp;
        p.place(47 * 32 + 6, 9 * 32 + 32 - p.h);
        for (int i = 0; i < 10; i++) frame(g, false);
        int falls = 0;
        boolean crossed = false;
        for (int attempt = 0; attempt < 4 && !crossed; attempt++) {
            p.place(46 * 32 + 6, 9 * 32 + 32 - p.h);
            p.hp = p.maxHp;
            atkTimer = 0; jumpHold = 0;
            for (int i = 0; i < 160; i++) {
                bot(g, false);
                frame(g, false);
                if (p.cx() > 54 * 32) { crossed = true; break; }
            }
            if (!crossed) falls++;
        }
        check(!crossed, "chasm cannot be crossed with a single jump (falls=" + falls + ")");

        // ---------- pick up the shrine by walking onto the ledge
        p.place(19 * 32, 6 * 32 - p.h);            // stand on the shrine ledge, walk to the orb
        for (int i = 0; i < 120; i++) { g.input.set(false, i > 5 && i < 60, false, false, false); frame(g, true); }
        check(g.save.dj && p.hasDJ, "shrine grants double jump (x=" + (int) p.x + ")");

        // ---------- cross the chasm with the double jump (brute-force over input timings)
        check(reach(rg, 1, 47, 9, 1, 10, 54, 56, true, "chasm with DJ"), "chasm crossable with the double jump");
        check(!reach(rg, 1, 47, 9, 1, 10, 54, 56, false, "chasm without DJ"), "chasm not crossable without it");

        // ---------- walk to the right exit into the boss room
        frames = 0;
        boolean inBossRoom = false;
        p.hp = p.maxHp;
        p.place(66 * 32, 9 * 32 + 32 - p.h);
        while (frames < 60 * 40) {
            bot(g, true);
            frame(g, frames % 5 == 0);
            frames++;
            if (g.world.index == 2) { inBossRoom = true; break; }
            if (g.state == Game.DEAD) break;
        }
        check(inBossRoom, "room 1 -> room 2 transition (frames=" + frames + ")");

        // ---------- boss fight (player made tanky; verifies all boss attacks run without errors)
        p = g.player;
        p.maxHp = 100000; p.hp = 100000;
        check(g.boss != null, "boss present in arena");
        frames = 0;
        boolean gate = false;
        int minHp = g.boss.hp;
        while (frames < 60 * 120 && g.boss != null) {
            // walk right until the boss is near, attack it; no dodge
            boolean near = Math.abs(g.boss.cx() - p.cx()) < 70f;
            boolean left = g.boss.cx() < p.cx() - 50f;
            boolean atk = near && (frames % 10 == 0);
            g.input.set(left, !near && !left, false, atk, false);
            frame(g, frames % 5 == 0);
            if (g.world.gateClosed) gate = true;
            frames++;
            if (p.x < 40 && g.boss != null && g.boss.hp > 0 && frames > 60 * 30) { /* allowed */ }
        }
        check(gate, "boss gate closed during fight");
        check(g.boss == null && g.save.boss, "boss defeated within " + frames / 60 + "s");
        check(!g.world.gateClosed, "gate reopened after boss death");
        boolean edgeSpawned = false;
        for (Pickup k : g.pickups) if (k.type == Pickup.EDGE) edgeSpawned = true;
        check(edgeSpawned, "Umbral Edge pickup spawned");

        // ---------- collect Umbral Edge
        for (int i = 0; i < 240 && !g.save.edge; i++) {
            float dx = 15 * 32 + 16 - p.cx();
            g.input.set(dx < -6, dx > 6, false, false, false);
            frame(g, false);
        }
        check(g.save.edge && p.edge, "Umbral Edge collected");

        // ---------- death + respawn
        p.maxHp = 100; p.hp = 1;
        p.invuln = 0f;
        p.hurt(g, 50, p.cx() + 10);
        for (int i = 0; i < 12; i++) frame(g, true);
        check(g.state == Game.DEAD, "player death -> DEAD state");
        for (int i = 0; i < 100; i++) frame(g, true);
        tap(g, g.dBtn[0]);
        check(g.state == Game.PLAY && g.player.hp == g.player.maxHp && !g.player.dead, "respawn at checkpoint with full hp (room " + g.world.index + ")");

        // ---------- pause menu + vitality upgrade
        g.save.shards = 500;
        g.input.clear();
        frame(g, true);
        g.taps.add(new float[] {-1f, -1f}); frame(g, true);
        check(g.state == Game.PAUSE, "back button pauses");
        int vitBefore = g.save.vit;
        tap(g, g.pBtn[1]);
        check(g.save.vit == vitBefore + 1 && g.player.maxHp == 120, "vitality upgrade bought (maxHp=" + g.player.maxHp + ", shards=" + g.save.shards + ")");
        frame(g, true);
        tap(g, g.pBtn[2]); frame(g, true); tap(g, g.sBtn[4]);
        check(g.state == Game.PAUSE, "settings from pause returns to pause");
        tap(g, g.pBtn[0]);
        check(g.state == Game.PLAY, "resume works");
        tap(g, g.pauseBtn);
        check(g.state == Game.PAUSE, "pause button works");
        tap(g, g.pBtn[3]);
        check(g.state == Game.MENU, "quit to menu works");

        // ---------- persistence
        Game g2 = newGame(prefs);
        check(g2.save.dj && g2.save.boss && g2.save.edge && g2.save.vit == 1 && g2.save.shards > 0, "save persisted: dj=" + g2.save.dj + " boss=" + g2.save.boss + " edge=" + g2.save.edge + " vit=" + g2.save.vit + " shards=" + g2.save.shards + " taken=" + g2.save.taken.size());
        tap(g2, g2.btnPlay);
        for (int i = 0; i < 90; i++) frame(g2, true);
        check(g2.state == Game.PLAY && g2.player.hasDJ && g2.player.maxHp == 120, "continue loads saved progress");
        boolean anyTakenCoin = false;
        for (Pickup k : g2.pickups) if (k.type == Pickup.SHARD && g2.save.taken.contains(k.id)) anyTakenCoin = true;
        check(!anyTakenCoin, "collected shards do not respawn");

        System.out.println(failures == 0 ? "ALL CHECKS PASSED" : failures + " CHECK(S) FAILED");
        System.exit(failures == 0 ? 0 : 1);
    }
}
