#!/usr/bin/env python3
"""Builds a labelled contact sheet from the PNG frames written by shots.sh.
Usage: python3 sheet.py <frameDir> <scenario> <out.png> [cols] [zoom]"""
import csv, glob, os, sys
from PIL import Image, ImageDraw, ImageFont

d, scn, out = sys.argv[1], sys.argv[2], sys.argv[3]
cols = int(sys.argv[4]) if len(sys.argv) > 4 else 6
zoom = float(sys.argv[5]) if len(sys.argv) > 5 else 0.6

rows = {}
with open(os.path.join(d, scn + ".csv")) as fh:
    for r in csv.DictReader(fh):
        rows[int(r["frame"])] = r

files = sorted(glob.glob(os.path.join(d, scn + "_*.png")))
tiles = []
for f in files:
    idx = int(os.path.basename(f).split("_")[-1].split(".")[0])
    im = Image.open(f).convert("RGB")
    im = im.resize((int(im.width * zoom), int(im.height * zoom)), Image.LANCZOS)
    r = rows.get(idx, {})
    cap = "f%d vx%s vy%s %s%s" % (idx, r.get("vx", "?").split(".")[0], r.get("vy", "?").split(".")[0],
                                   "G" if r.get("ground") == "true" else "A",
                                   (" atk%s" % r["atk"]) if r.get("atk", "0") != "0" else "")
    if r.get("dodgeT", "0.000") not in ("0.000", "-0.000") and float(r.get("dodgeT", 0)) > 0:
        cap += " DASH"
    tiles.append((im, cap))

if not tiles:
    sys.exit("no frames for " + scn)
tw, th = tiles[0][0].size
lab = 16
nrows = (len(tiles) + cols - 1) // cols
sheet = Image.new("RGB", (cols * tw, nrows * (th + lab)), (20, 20, 24))
dr = ImageDraw.Draw(sheet)
try:
    font = ImageFont.load_default()
except Exception:
    font = None
for i, (im, cap) in enumerate(tiles):
    cx, cy = (i % cols) * tw, (i // cols) * (th + lab)
    sheet.paste(im, (cx, cy + lab))
    dr.rectangle([cx, cy, cx + tw - 1, cy + lab - 1], fill=(40, 40, 52))
    dr.text((cx + 3, cy + 3), cap, fill=(230, 230, 240), font=font)
    dr.rectangle([cx, cy + lab, cx + tw - 1, cy + lab + th - 1], outline=(70, 70, 90))
sheet.save(out)
print(out, sheet.size)
