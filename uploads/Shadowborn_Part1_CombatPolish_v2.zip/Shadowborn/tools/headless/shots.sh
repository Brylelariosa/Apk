#!/bin/sh
# Frame renderer: compiles the game against a Java2D-backed android.graphics shim (tools/headless/render) and
# writes cropped PNG frames of scripted scenarios (run, jump, double jump, attack, dash ...) to the output folder.
# Needs a JDK (or a JRE with jdk.compiler) that includes java.desktop. Usage: sh shots.sh <outDir> [scenario ...]
set -e
cd "$(dirname "$0")"
OUT=$(mktemp -d)
if command -v javac >/dev/null 2>&1; then JAVAC="javac"; else JAVAC="java -m jdk.compiler/com.sun.tools.javac.Main"; fi
STUBS=$(find stubs -name '*.java' ! -path 'stubs/android/graphics/*')
$JAVAC -nowarn -d "$OUT" $STUBS $(find render -name '*.java') $(find ../../app/src/main/java -name '*.java') sim/com/shadowborn/game/Sim.java shots/com/shadowborn/game/Shots.java
DIR="${1:-/tmp/shots}"
shift 2>/dev/null || true
java -Djava.awt.headless=true -cp "$OUT" com.shadowborn.game.Shots "$DIR" "$@"
