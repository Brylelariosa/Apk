package android.graphics;

import java.awt.MultipleGradientPaint;
import java.awt.RadialGradientPaint;
import java.awt.geom.Point2D;

public class RadialGradient extends Shader {
    private final float x, y, r;
    private final int c0, c1;

    public RadialGradient(float x, float y, float r, int c0, int c1, TileMode t) {
        this.x = x;
        this.y = y;
        this.r = Math.max(0.001f, r);
        this.c0 = c0;
        this.c1 = c1;
    }

    @Override
    public java.awt.Paint awt(int paintAlpha) {
        return new RadialGradientPaint(new Point2D.Float(x, y), r, new float[] {0f, 1f},
            new java.awt.Color[] {mul(c0, paintAlpha), mul(c1, paintAlpha)}, MultipleGradientPaint.CycleMethod.NO_CYCLE);
    }
}
