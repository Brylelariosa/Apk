package android.graphics;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.util.ArrayDeque;

/**
 * Java2D-backed Canvas for the headless frame renderer. It implements only the Canvas/Paint calls the
 * game uses, so frames rendered with it approximate (not match) what Android draws.
 */
public class Canvas {
    public final BufferedImage img;
    private final Graphics2D g;
    private final ArrayDeque<AffineTransform> stack = new ArrayDeque<>();

    public Canvas() {
        this(new BufferedImage(1, 1, BufferedImage.TYPE_INT_ARGB));
    }

    public Canvas(Bitmap b) {
        this(b.img);
    }

    public Canvas(BufferedImage img) {
        this.img = img;
        g = img.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
        g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
    }

    public void drawColor(int c) {
        AffineTransform t = g.getTransform();
        g.setTransform(new AffineTransform());
        g.setComposite(java.awt.AlphaComposite.Src);
        g.setColor(new Color(c, true));
        g.fillRect(0, 0, img.getWidth(), img.getHeight());
        g.setComposite(java.awt.AlphaComposite.SrcOver);
        g.setTransform(t);
    }

    public int save() { stack.push(g.getTransform()); return stack.size(); }
    public void restore() { if (!stack.isEmpty()) g.setTransform(stack.pop()); }
    public void scale(float x, float y) { g.scale(x, y); }
    public void translate(float x, float y) { g.translate(x, y); }
    public void rotate(float deg) { g.rotate(Math.toRadians(deg)); }

    private void setPaint(Paint p) {
        int a = p.color >>> 24;
        if (p.shader != null) g.setPaint(p.shader.awt(a));
        else g.setColor(new Color((p.color >> 16) & 255, (p.color >> 8) & 255, p.color & 255, a));
    }

    private BasicStroke stroke(Paint p) {
        int cap = p.cap == Paint.Cap.ROUND ? BasicStroke.CAP_ROUND : (p.cap == Paint.Cap.SQUARE ? BasicStroke.CAP_SQUARE : BasicStroke.CAP_BUTT);
        int join = p.join == Paint.Join.ROUND ? BasicStroke.JOIN_ROUND : (p.join == Paint.Join.BEVEL ? BasicStroke.JOIN_BEVEL : BasicStroke.JOIN_MITER);
        return new BasicStroke(Math.max(0.05f, p.strokeWidth), cap, join, 4f);
    }

    private void shape(Shape s, Paint p) {
        if (p.style == Paint.Style.FILL || p.style == Paint.Style.FILL_AND_STROKE) {
            setPaint(p);
            g.fill(s);
        }
        if (p.style == Paint.Style.STROKE || p.style == Paint.Style.FILL_AND_STROKE) {
            setPaint(p);
            g.setStroke(stroke(p));
            g.draw(s);
        }
    }

    public void drawRect(float l, float t, float r, float b, Paint p) {
        shape(new Rectangle2D.Float(l, t, r - l, b - t), p);
    }

    public void drawRoundRect(float l, float t, float r, float b, float rx, float ry, Paint p) {
        shape(new RoundRectangle2D.Float(l, t, r - l, b - t, rx * 2f, ry * 2f), p);
    }

    public void drawCircle(float x, float y, float r, Paint p) {
        shape(new Ellipse2D.Float(x - r, y - r, r * 2f, r * 2f), p);
    }

    public void drawLine(float x0, float y0, float x1, float y1, Paint p) {
        setPaint(p);
        g.setStroke(stroke(p));
        g.draw(new Line2D.Float(x0, y0, x1, y1));
    }

    public void drawLines(float[] pts, int off, int count, Paint p) {
        setPaint(p);
        g.setStroke(stroke(p));
        for (int i = off; i + 3 < off + count; i += 4) g.draw(new Line2D.Float(pts[i], pts[i + 1], pts[i + 2], pts[i + 3]));
    }

    public void drawPath(Path path, Paint p) {
        shape(path.p, p);
    }

    public void drawBitmap(Bitmap b, float l, float t, Paint p) {
        g.drawImage(b.img, Math.round(l), Math.round(t), null);
    }

    public void drawText(String s, float x, float y, Paint p) {
        try {
            Font f = new Font(Font.SANS_SERIF, Font.BOLD, 12).deriveFont(p.textSize);
            g.setFont(f);
            setPaint(p);
            FontMetrics fm = g.getFontMetrics();
            float w = fm.stringWidth(s);
            float sx = p.align == Paint.Align.CENTER ? x - w / 2f : (p.align == Paint.Align.RIGHT ? x - w : x);
            g.drawString(s, sx, y);
        } catch (Throwable ignored) {
            // no fonts in this environment: skip text
        }
    }
}
