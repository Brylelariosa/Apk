package android.graphics;

import java.awt.LinearGradientPaint;
import java.awt.MultipleGradientPaint;
import java.awt.geom.Point2D;

public class LinearGradient extends Shader {
    private final float x0, y0, x1, y1;
    private final int c0, c1;

    public LinearGradient(float x0, float y0, float x1, float y1, int c0, int c1, TileMode t) {
        this.x0 = x0;
        this.y0 = y0;
        this.x1 = x1;
        this.y1 = y1 == y0 && x1 == x0 ? y0 + 0.001f : y1;
        this.c0 = c0;
        this.c1 = c1;
    }

    @Override
    public java.awt.Paint awt(int paintAlpha) {
        return new LinearGradientPaint(new Point2D.Float(x0, y0), new Point2D.Float(x1, y1), new float[] {0f, 1f},
            new java.awt.Color[] {mul(c0, paintAlpha), mul(c1, paintAlpha)}, MultipleGradientPaint.CycleMethod.NO_CYCLE);
    }
}
