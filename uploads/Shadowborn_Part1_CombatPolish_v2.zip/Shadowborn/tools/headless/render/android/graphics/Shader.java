package android.graphics;

/** Shader base for the headless frame renderer. Subclasses build a java.awt.Paint on demand. */
public abstract class Shader {
    public enum TileMode { CLAMP, REPEAT, MIRROR }

    /** Builds the AWT paint with the paint's alpha (0..255) multiplied into the gradient colours. */
    public abstract java.awt.Paint awt(int paintAlpha);

    static java.awt.Color mul(int argb, int paintAlpha) {
        int a = (int) Math.round(((argb >>> 24) & 255) * (paintAlpha / 255.0));
        return new java.awt.Color((argb >> 16) & 255, (argb >> 8) & 255, argb & 255, Math.max(0, Math.min(255, a)));
    }
}
