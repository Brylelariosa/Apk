package android.graphics;

public class Paint {
    public static final int ANTI_ALIAS_FLAG = 1, FILTER_BITMAP_FLAG = 2;

    public enum Style { FILL, STROKE, FILL_AND_STROKE }
    public enum Cap { BUTT, ROUND, SQUARE }
    public enum Join { MITER, ROUND, BEVEL }
    public enum Align { LEFT, CENTER, RIGHT }

    public int color = 0xFF000000;
    public Style style = Style.FILL;
    public float strokeWidth = 0f, textSize = 12f, letterSpacing = 0f;
    public Cap cap = Cap.BUTT;
    public Join join = Join.MITER;
    public Shader shader;
    public Align align = Align.LEFT;
    public Typeface typeface;

    public Paint() {}
    public Paint(int flags) {}

    public void setStyle(Style s) { style = s; }
    public void setColor(int c) { color = c; }
    public void setAlpha(int a) { color = (Math.max(0, Math.min(255, a)) << 24) | (color & 0x00FFFFFF); }
    public void setStrokeWidth(float w) { strokeWidth = w; }
    public void setStrokeCap(Cap c) { cap = c; }
    public void setStrokeJoin(Join j) { join = j; }
    public Shader setShader(Shader s) { shader = s; return s; }
    public Typeface setTypeface(Typeface t) { typeface = t; return t; }
    public void setTextSize(float s) { textSize = s; }
    public void setTextAlign(Align a) { align = a; }
    public void setLetterSpacing(float s) { letterSpacing = s; }
}
