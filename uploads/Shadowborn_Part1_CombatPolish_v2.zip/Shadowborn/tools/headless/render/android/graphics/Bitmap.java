package android.graphics;

import java.awt.image.BufferedImage;

/** Java2D-backed Bitmap used only by the headless frame renderer (tools/headless/shots.sh). */
public class Bitmap {
    public enum Config { ARGB_8888 }

    public final BufferedImage img;

    private Bitmap(int w, int h) {
        img = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
    }

    public static Bitmap createBitmap(int w, int h, Config c) {
        return new Bitmap(w, h);
    }
}
