package android.graphics;

import java.awt.geom.Path2D;

public class Path {
    public final Path2D.Float p = new Path2D.Float();
    private boolean open;

    public void moveTo(float x, float y) { p.moveTo(x, y); open = true; }
    public void lineTo(float x, float y) { if (!open) { p.moveTo(x, y); open = true; } else p.lineTo(x, y); }
    public void quadTo(float x1, float y1, float x2, float y2) { if (!open) { p.moveTo(x1, y1); open = true; } p.quadTo(x1, y1, x2, y2); }
    public void close() { if (open) p.closePath(); }
    public void reset() { p.reset(); open = false; }
}
