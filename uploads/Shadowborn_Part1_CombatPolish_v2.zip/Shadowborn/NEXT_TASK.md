# NEXT_TASK - Shadowborn Part 2 (audio, content, polish)

Read README.md and PROJECT_STATE.md first. Extend this project; do not rewrite it. Keep: Java, custom Canvas
renderer, no AndroidX/AppCompat, no external dependencies, no internet, procedural art only, no emoji.

## Step 0 - confirm the build (do this before adding anything)
1. Push the ZIP to the Build APK workflow (or build locally). If it fails, fix every compile or Gradle error
   first using the build log, then re-run `tools/headless/run.sh` (all checks must still pass).
2. If the user reports on-device problems (touch feel, performance, visuals, cutout overlap), fix those before
   new features. Measure CPU use and frame time while idling in the menu and in the boss room.

## Step 1 - Part 2 scope
1. Procedural audio with android.media.AudioTrack (generated PCM, no files): sword swings, hits, jump, double
   jump, dodge, shard pickup, checkpoint, boss roar and death, soft ambient drone. Add a Sound setting.
2. Content: 3 more rooms (6 total) with a branching route, a room-name map screen (simple grid, drawn in code),
   one more enemy type (e.g. a shield bearer that must be hit from behind or broken with the 3rd combo hit), and
   a second ability gate (dash upgrade or wall cling) with its own shrine and a gated shortcut back to the hub.
3. Progression: shard shop at a hub checkpoint (damage, health, dodge cooldown), a second save slot.
4. Polish: use real display-cutout insets for HUD and buttons, button haptics, hit-flash on bosses, settings for
   left-handed layout.
5. Tests: extend tools/headless/Sim.java for every new rule (reachability and gating checks for new abilities).

## Step 2 - delivery
Update README.md, PROJECT_STATE.md and this file. Package as `Shadowborn_Part2_<short-name>.zip` containing the
whole project (no build outputs), save it through the connected file manager (FileBridge) if it responds,
verify the ZIP contents, and report exactly what was and was not verified. Never claim a build succeeded unless
Gradle actually ran.
