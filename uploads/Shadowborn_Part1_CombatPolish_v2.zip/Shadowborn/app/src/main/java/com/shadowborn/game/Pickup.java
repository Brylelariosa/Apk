package com.shadowborn.game;

import android.graphics.Canvas;
import android.graphics.Paint;

/** Collectibles: shards (currency), the double-jump shrine orb and the Umbral Edge upgrade. */
final class Pickup {
    static final int SHARD = 0, DJ = 1, EDGE = 2;
    final int type, id;
    float x, y, t;
    boolean gone;

    Pickup(int type, float x, float y, int id) {
        this.type = type;
        this.x = x;
        this.y = y;
        this.id = id;
        t = (float) (Math.random() * 6.0);
    }

    void update(Game g, float dt) {
        t += dt;
        Player p = g.player;
        if (p.dead) return;
        float dx = p.cx() - x, dy = p.cy() - y, d2 = dx * dx + dy * dy;
        if (type == SHARD) {
            if (d2 < 6400f) {
                float d = (float) Math.sqrt(d2) + 0.001f, step = Math.min(280f * dt, d);
                x += dx / d * step;
                y += dy / d * step;
            }
            if (d2 < 256f) {
                gone = true;
                if (id >= 0) g.save.taken.add(id);
                g.addShards(1, x, y - 6f, false);
                g.fx.burst(x, y, 5, 0xFF9AF0FF, 70f, 0.3f, 1.8f);
            }
        } else if (d2 < 900f) {
            gone = true;
            if (type == DJ) g.unlockDoubleJump(x, y);
            else g.unlockEdge(x, y);
        }
    }

    void draw(Canvas c) {
        float bob = (float) Math.sin(t * 2.5f) * 3f;
        if (type == SHARD) {
            Art.shard(c, x, y + bob * 0.5f, t);
            return;
        }
        Paint p = Art.P;
        if (type == DJ) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF9AF0FF);
            p.setAlpha(22);
            c.drawRect(x - 14f, y - 150f, x + 14f, y + 16f, p);
            p.setAlpha(36);
            c.drawRect(x - 6f, y - 150f, x + 6f, y + 16f, p);
            p.setColor(0xFF2A2438);
            c.drawRect(x - 12f, y + 8f, x + 12f, y + 16f, p);
            p.setColor(0xFF4A3F5C);
            c.drawRect(x - 9f, y + 4f, x + 9f, y + 8f, p);
            Art.glow(c, Art.GLOW_CYAN, x, y + bob, 64f, 0.95f);
            Art.dot(c, x, y + bob, 6.5f, 0xFFE8FFFF, 255);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(1.4f);
            p.setColor(0xFF58E0FF);
            p.setAlpha(200);
            c.drawCircle(x, y + bob, 10f + (float) Math.sin(t * 4f) * 1.5f, p);
        } else {
            Art.glow(c, Art.GLOW_RED, x, y + bob, 60f, 0.95f);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setColor(0xFFFF3050);
            p.setAlpha(120);
            p.setStrokeWidth(7f);
            c.drawLine(x - 12f, y + bob + 12f, x + 12f, y + bob - 12f, p);
            p.setColor(0xFFFFE8EC);
            p.setAlpha(255);
            p.setStrokeWidth(2.6f);
            c.drawLine(x - 12f, y + bob + 12f, x + 12f, y + bob - 12f, p);
            c.drawLine(x - 9f, y + bob + 3f, x - 3f, y + bob + 9f, p);
        }
    }
}
