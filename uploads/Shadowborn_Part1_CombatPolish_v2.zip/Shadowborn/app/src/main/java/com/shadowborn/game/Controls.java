package com.shadowborn.game;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;

/** Custom-drawn virtual buttons with multi-touch hit testing (all coordinates are virtual units). */
final class Controls {
    static final int LEFT = 0, RIGHT = 1, JUMP = 2, ATTACK = 3, DODGE = 4, N = 5;
    private final float[] bx = new float[N], by = new float[N], br = new float[N];

    void layout(float vw, float vh) {
        br[LEFT] = 44f;   bx[LEFT] = 80f;          by[LEFT] = vh - 64f;
        br[RIGHT] = 44f;  bx[RIGHT] = 186f;        by[RIGHT] = vh - 64f;
        br[JUMP] = 46f;   bx[JUMP] = vw - 78f;     by[JUMP] = vh - 68f;
        br[ATTACK] = 46f; bx[ATTACK] = vw - 182f;  by[ATTACK] = vh - 58f;
        br[DODGE] = 36f;  bx[DODGE] = vw - 138f;   by[DODGE] = vh - 146f;
    }

    /** Returns the nearest button under (x, y) or -1. */
    int hit(float x, float y) {
        int best = -1;
        float bd = 1e9f;
        for (int i = 0; i < N; i++) {
            float dx = x - bx[i], dy = y - by[i];
            float d = (float) Math.sqrt(dx * dx + dy * dy);
            if (d <= br[i] * 1.3f && d < bd) { bd = d; best = i; }
        }
        return best;
    }

    /** dashReady is 0..1 (1 = recharged); dashOk is false while the dash cannot be used at all (e.g. mid-air before Wraith Stride). */
    void draw(Canvas c, Input in, int opacityPct, float dashReady, boolean dashOk) {
        float a = opacityPct / 100f;
        button(c, LEFT, in.left, a);
        button(c, RIGHT, in.right, a);
        button(c, JUMP, in.jump, a);
        button(c, ATTACK, in.attack, a);
        button(c, DODGE, in.dodge, a);
        if (a > 0f && (dashReady < 1f || !dashOk)) {
            Paint p = Art.P;
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF05070C);
            if (dashReady < 1f) {
                p.setAlpha((int) (a * 165f));
                c.drawCircle(bx[DODGE], by[DODGE], br[DODGE] * (1f - dashReady) * 0.92f + 2f, p);
            } else {
                p.setAlpha((int) (a * 105f));
                c.drawCircle(bx[DODGE], by[DODGE], br[DODGE] * 0.96f, p);
            }
        }
    }

    private void button(Canvas c, int i, boolean down, float alpha) {
        Paint p = Art.P;
        float x = bx[i], y = by[i], r = br[i] * (down ? 0.93f : 1f), k = r * 0.42f;
        p.setStyle(Paint.Style.FILL);
        p.setColor(down ? 0xFF2A6A8C : 0xFF0A0E16);
        p.setAlpha((int) (alpha * (down ? 210f : 150f)));
        c.drawCircle(x, y, r, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2.6f);
        p.setColor(0xFF58E0FF);
        p.setAlpha((int) (alpha * (down ? 255f : 175f)));
        c.drawCircle(x, y, r, p);
        p.setStrokeWidth(1f);
        p.setAlpha((int) (alpha * 70f));
        c.drawCircle(x, y, r - 6f, p);
        p.setColor(0xFFE8F8FF);
        p.setAlpha((int) (alpha * (down ? 255f : 215f)));
        p.setStrokeWidth(3.4f);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
        Path pa = Art.PA;
        pa.reset();
        switch (i) {
            case LEFT:
                pa.moveTo(x - k, y); pa.lineTo(x + k * 0.7f, y - k); pa.lineTo(x + k * 0.7f, y + k); pa.close();
                p.setStyle(Paint.Style.FILL);
                c.drawPath(pa, p);
                break;
            case RIGHT:
                pa.moveTo(x + k, y); pa.lineTo(x - k * 0.7f, y - k); pa.lineTo(x - k * 0.7f, y + k); pa.close();
                p.setStyle(Paint.Style.FILL);
                c.drawPath(pa, p);
                break;
            case JUMP:
                pa.moveTo(x - k, y + k * 0.1f); pa.lineTo(x, y - k * 0.7f); pa.lineTo(x + k, y + k * 0.1f);
                pa.moveTo(x - k, y + k * 0.9f); pa.lineTo(x, y + k * 0.1f); pa.lineTo(x + k, y + k * 0.9f);
                c.drawPath(pa, p);
                break;
            case ATTACK:
                c.drawLine(x - k * 0.9f, y + k * 0.9f, x + k * 0.9f, y - k * 0.9f, p);
                c.drawLine(x - k * 0.8f, y - k * 0.1f, x + k * 0.1f, y + k * 0.8f, p);
                break;
            default:
                c.drawLine(x - k, y, x + k, y, p);
                c.drawLine(x + k, y, x + k * 0.3f, y - k * 0.6f, p);
                c.drawLine(x + k, y, x + k * 0.3f, y + k * 0.6f, p);
                p.setStrokeWidth(2f);
                c.drawLine(x - k, y - k * 0.6f, x - k * 0.2f, y - k * 0.6f, p);
                c.drawLine(x - k, y + k * 0.6f, x - k * 0.2f, y + k * 0.6f, p);
                break;
        }
    }
}
