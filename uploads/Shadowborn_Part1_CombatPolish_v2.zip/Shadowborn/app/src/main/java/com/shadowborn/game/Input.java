package com.shadowborn.game;

/** Button state shared between the UI thread (writes) and the game thread (reads). */
final class Input {
    volatile boolean left, right, jump, attack, dodge;
    private volatile boolean jumpL, atkL, dodgeL;

    void set(boolean l, boolean r, boolean j, boolean a, boolean d) {
        if (j && !jump) jumpL = true;
        if (a && !attack) atkL = true;
        if (d && !dodge) dodgeL = true;
        left = l; right = r; jump = j; attack = a; dodge = d;
    }

    boolean takeJump() { boolean b = jumpL; jumpL = false; return b; }
    boolean takeAttack() { boolean b = atkL; atkL = false; return b; }
    boolean takeDodge() { boolean b = dodgeL; dodgeL = false; return b; }

    void clear() {
        left = false; right = false; jump = false; attack = false; dodge = false;
        jumpL = false; atkL = false; dodgeL = false;
    }
}
