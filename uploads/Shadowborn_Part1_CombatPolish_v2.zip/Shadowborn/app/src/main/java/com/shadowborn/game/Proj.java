package com.shadowborn.game;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;

/** Enemy projectiles: wraith orbs, boss blades and boss ground shockwaves. */
final class Proj {
    static final int ORB = 0, BLADE = 1, WAVE = 2;
    final int kind, dmg;
    float x, y, vx, vy, life, t;
    boolean dead;

    Proj(int kind, float x, float y, float vx, float vy, int dmg, float life) {
        this.kind = kind;
        this.x = x;
        this.y = y;
        this.vx = vx;
        this.vy = vy;
        this.dmg = dmg;
        this.life = life;
    }

    void update(Game g, float dt) {
        t += dt;
        life -= dt;
        if (life <= 0f) { dead = true; return; }
        x += vx * dt;
        y += vy * dt;
        World wd = g.world;
        if (kind == WAVE) {
            int wx = (int) Math.floor((x + (vx > 0f ? 10f : -10f)) / World.TS), wy = (int) Math.floor((y - 4f) / World.TS);
            if (wd.solid(wx, wy)) {
                dead = true;
                g.fx.burst(x, y - 6f, 6, 0xFFFF3050, 80f, 0.3f, 2f);
                return;
            }
            if (((int) (t * 30f) & 1) == 0) g.fx.burst(x, y - 3f, 1, 0xFFFF6070, 40f, 0.3f, 2f);
        } else if (wd.solid((int) Math.floor(x / World.TS), (int) Math.floor(y / World.TS))) {
            dead = true;
            g.fx.burst(x, y, 6, kind == ORB ? 0xFFB070FF : 0xFFFF3050, 80f, 0.3f, 2f);
            return;
        }
        Player p = g.player;
        if (p.dead || p.invuln > 0f) return;
        boolean hit = kind == WAVE
            ? Body.overlap(x - 9f, y - 20f, 18f, 20f, p.x, p.y, p.w, p.h)
            : Body.overlap(x - 5f, y - 5f, 10f, 10f, p.x, p.y, p.w, p.h);
        if (hit) {
            p.hurt(g, dmg, x);
            if (kind != WAVE) {
                dead = true;
                g.fx.burst(x, y, 8, 0xFFFFFFFF, 90f, 0.3f, 2f);
            }
        }
    }

    void draw(Canvas c) {
        Paint p = Art.P;
        if (kind == ORB) {
            Art.glow(c, Art.GLOW_VIOLET, x, y, 28f, 0.9f);
            Art.dot(c, x, y, 6f, 0xFF7A40C8, 210);
            Art.dot(c, x, y, 3.2f, 0xFFF0E0FF, 255);
        } else if (kind == BLADE) {
            Art.glow(c, Art.GLOW_RED, x, y, 26f, 0.8f);
            c.save();
            c.translate(x, y);
            c.rotate((float) Math.toDegrees(Math.atan2(vy, vx)));
            Path pa = Art.PA;
            pa.reset();
            pa.moveTo(-9f, 0f); pa.lineTo(0f, -3.5f); pa.lineTo(10f, 0f); pa.lineTo(0f, 3.5f); pa.close();
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFFFF3050);
            c.drawPath(pa, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(1f);
            p.setColor(0xFFFFE8EC);
            c.drawPath(pa, p);
            c.restore();
        } else {
            Art.glow(c, Art.GLOW_RED, x, y - 8f, 30f, 0.8f);
            Path pa = Art.PA;
            pa.reset();
            pa.moveTo(x - 10f, y); pa.lineTo(x - 2f, y - 16f); pa.lineTo(x + 3f, y - 8f); pa.lineTo(x + 10f, y); pa.close();
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFFFF3050);
            c.drawPath(pa, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(1f);
            p.setColor(0xFFFFE8EC);
            c.drawPath(pa, p);
        }
    }
}
