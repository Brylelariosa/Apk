package com.shadowborn.game;

import android.content.Context;
import android.graphics.Canvas;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

/** Surface, fixed-timestep game loop thread and multi-touch input. */
final class GameView extends SurfaceView implements SurfaceHolder.Callback, Runnable {
    private static final float STEP = 1f / 60f;
    private final Game game;
    private Thread thread;
    private volatile boolean running, surfaceOk, activityOn;
    private volatile float scale = 1f;
    private int renderErrors;

    GameView(Context ctx) {
        super(ctx);
        game = new Game(ctx);
        getHolder().addCallback(this);
        setFocusable(true);
        setKeepScreenOn(true);
    }

    void onResumeActivity() {
        activityOn = true;
        startLoop();
    }

    void onPauseActivity() {
        activityOn = false;
        stopLoop();
        game.onBackground();
    }

    boolean handleBack() {
        return game.onBack();
    }

    private synchronized void startLoop() {
        if (thread != null || !surfaceOk || !activityOn) return;
        running = true;
        thread = new Thread(this, "shadowborn-loop");
        thread.start();
    }

    private void stopLoop() {
        Thread t;
        synchronized (this) {
            running = false;
            t = thread;
            thread = null;
        }
        if (t != null) {
            try {
                t.join(1000);
            } catch (InterruptedException ignored) {
                // shutting down anyway
            }
        }
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        surfaceOk = true;
        startLoop();
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        float s = height / Game.VH;
        scale = s;
        game.setSize(width / s, s);
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        surfaceOk = false;
        stopLoop();
    }

    private Canvas lock() {
        SurfaceHolder h = getHolder();
        try {
            return h.lockHardwareCanvas();
        } catch (RuntimeException e) {
            try {
                return h.lockCanvas();
            } catch (RuntimeException e2) {
                return null;
            }
        }
    }

    @Override
    public void run() {
        long last = System.nanoTime(), fpsT = last;
        float acc = 0f;
        int frames = 0;
        while (running) {
            long now = System.nanoTime();
            float dt = (now - last) / 1e9f;
            last = now;
            if (dt > 0.1f) dt = 0.1f;
            acc += dt;
            int steps = 0;
            while (acc >= STEP && steps < 5) {
                game.update(STEP);
                acc -= STEP;
                steps++;
            }
            if (steps == 5) acc = 0f;
            Canvas c = lock();
            if (c != null) {
                try {
                    game.render(c);
                } catch (RuntimeException e) {
                    if (renderErrors++ < 5) Log.e("Shadowborn", "render error", e);
                } finally {
                    try {
                        getHolder().unlockCanvasAndPost(c);
                    } catch (RuntimeException ignored) {
                        // surface went away mid-frame
                    }
                }
            }
            frames++;
            if (now - fpsT >= 1_000_000_000L) {
                game.setFps(frames);
                frames = 0;
                fpsT = now;
            }
            long sleepMs = 16L - (System.nanoTime() - now) / 1_000_000L;
            if (sleepMs > 1L) {
                try {
                    Thread.sleep(sleepMs);
                } catch (InterruptedException ignored) {
                    // loop re-checks running
                }
            }
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int a = e.getActionMasked(), idx = e.getActionIndex();
        float s = scale;
        if (a == MotionEvent.ACTION_DOWN || a == MotionEvent.ACTION_POINTER_DOWN) {
            game.taps.add(new float[] {e.getX(idx) / s, e.getY(idx) / s});
        }
        boolean l = false, r = false, j = false, at = false, d = false;
        if (a != MotionEvent.ACTION_CANCEL) {
            boolean up = a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_POINTER_UP;
            for (int i = 0; i < e.getPointerCount(); i++) {
                if (up && i == idx) continue;
                switch (game.controls.hit(e.getX(i) / s, e.getY(i) / s)) {
                    case Controls.LEFT: l = true; break;
                    case Controls.RIGHT: r = true; break;
                    case Controls.JUMP: j = true; break;
                    case Controls.ATTACK: at = true; break;
                    case Controls.DODGE: d = true; break;
                    default: break;
                }
            }
        }
        game.input.set(l, r, j, at, d);
        return true;
    }
}
