package com.shadowborn.game;

import android.graphics.Canvas;
import android.graphics.Paint;

/** Menus, HUD and overlays, all drawn with code (no image assets). */
final class Ui {
    private Ui() {}

    private static final Art.Fig HERO = new Art.Fig();

    static int argb(int rgb, float a) {
        return ((int) (255f * Math.max(0f, Math.min(1f, a))) << 24) | (rgb & 0x00FFFFFF);
    }

    static void text(Canvas c, String s, float x, float y, float size, int col, Paint.Align al) {
        Paint p = Art.P;
        p.setStyle(Paint.Style.FILL);
        p.setTypeface(Art.FONT);
        p.setTextSize(size);
        p.setTextAlign(al);
        p.setColor(col);
        c.drawText(s, x, y, p);
    }

    static void title(Canvas c, String s, float x, float y, float size, int col, float spacing) {
        Art.P.setLetterSpacing(spacing);
        text(c, s, x, y, size, col, Paint.Align.CENTER);
        Art.P.setLetterSpacing(0f);
    }

    private static void dim(Canvas c, float vw, int col) {
        Art.P.setStyle(Paint.Style.FILL);
        Art.P.setColor(col);
        c.drawRect(0f, 0f, vw, Game.VH, Art.P);
    }

    private static void panel(Canvas c, float x, float y, float w, float h) {
        Paint p = Art.P;
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xE6080A14);
        c.drawRoundRect(x, y, x + w, y + h, 12f, 12f, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2f);
        p.setColor(0xFF58E0FF);
        p.setAlpha(140);
        c.drawRoundRect(x, y, x + w, y + h, 12f, 12f, p);
    }

    static void button(Canvas c, float[] r, String s, boolean primary) {
        button(c, r, s, primary, true);
    }

    static void button(Canvas c, float[] r, String s, boolean primary, boolean enabled) {
        Paint p = Art.P;
        p.setStyle(Paint.Style.FILL);
        p.setColor(primary ? 0xDD0C2230 : 0xDD10101C);
        c.drawRoundRect(r[0], r[1], r[0] + r[2], r[1] + r[3], 9f, 9f, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2f);
        p.setColor(enabled ? (primary ? 0xFF58E0FF : 0xFF8A82B8) : 0xFF4A4660);
        c.drawRoundRect(r[0], r[1], r[0] + r[2], r[1] + r[3], 9f, 9f, p);
        float size = primary ? 19f : 15f;
        text(c, s, r[0] + r[2] / 2f, r[1] + r[3] / 2f + size * 0.34f, size, enabled ? 0xFFF0F8FF : 0xFF7A7690, Paint.Align.CENTER);
    }

    // ------------------------------------------------------------------ main menu

    static void menu(Game g, Canvas c) {
        float vw = g.vw, vh = Game.VH, t = g.time, mx = g.menuX();
        Art.backdrop(c, 0, t * 24f, vw, vh, t);
        Paint p = Art.P;
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF08050E);
        c.drawRect(0f, 304f, vw, vh, p);
        p.setColor(0xFF5A4A80);
        c.drawRect(0f, 304f, vw, 306f, p);
        Art.Fig f = HERO;
        Art.hero(f, g.save.edge);
        f.x = vw * 0.2f;
        f.y = 304f;
        f.s = 2.4f;
        f.dir = 1;
        f.t = t;
        f.vx = 0f;
        Art.idle(f, t);
        Art.glow(c, Art.GLOW_CYAN, f.x, 262f, 120f, 0.45f);
        Art.draw(c, f);
        g.fx.ambient(c, vw, vh, t, 0xFFFFA060);
        title(c, "SHADOWBORN", mx + 3f, 113f, 54f, 0x5058E0FF, 0.14f);
        title(c, "SHADOWBORN", mx, 110f, 54f, 0xFFF4F0FF, 0.14f);
        title(c, "PART ONE  -  THE ASHEN GATE", mx, 138f, 14f, 0xFF9A8CC8, 0.18f);
        button(c, g.btnPlay, "PLAY", true);
        button(c, g.btnSettings, "SETTINGS", false);
        text(c, "v0.1.0", vw - 28f, vh - 8f, 11f, 0x88FFFFFF, Paint.Align.RIGHT);
        c.drawRect(0f, 0f, vw, vh, g.vignette);
    }

    // ------------------------------------------------------------------ in-game HUD

    static void hud(Game g, Canvas c) {
        Player pl = g.player;
        Paint p = Art.P;
        float vw = g.vw, vh = Game.VH;

        float bx = 30f, by = 14f, bw = pl.maxHp * 1.6f, bh = 13f;
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xCC05060A);
        c.drawRoundRect(bx - 3f, by - 3f, bx + bw + 3f, by + bh + 3f, 5f, 5f, p);
        float gh = Math.max(0f, g.hpGhost) / pl.maxHp, fr = Math.max(0f, (float) pl.hp) / pl.maxHp;
        p.setColor(0xFFF0E0B0);
        c.drawRect(bx, by, bx + bw * gh, by + bh, p);
        p.setColor(0xFFD42848);
        c.drawRect(bx, by, bx + bw * fr, by + bh, p);
        p.setColor(0xFFFF7088);
        c.drawRect(bx, by, bx + bw * fr, by + 4f, p);
        p.setColor(0x88000000);
        for (int i = 20; i < pl.maxHp; i += 20) c.drawRect(bx + i * 1.6f - 0.5f, by, bx + i * 1.6f + 0.5f, by + bh, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.5f);
        p.setColor(0xFF58E0FF);
        p.setAlpha(150);
        c.drawRoundRect(bx - 3f, by - 3f, bx + bw + 3f, by + bh + 3f, 5f, 5f, p);

        if (g.shardsShown != g.save.shards) {
            g.shardsShown = g.save.shards;
            g.shardStr = String.valueOf(g.shardsShown);
        }
        Art.shard(c, 38f, 44f, g.time);
        text(c, g.shardStr, 52f, 49f, 15f, 0xFFD8F8FF, Paint.Align.LEFT);

        Boss b = g.boss;
        if (b != null && b.active()) {
            float w = 300f, x = vw / 2f - w / 2f, y = 30f, f = Math.max(0, b.hp) / (float) b.maxHp;
            text(c, "THE ASHEN WARDEN", vw / 2f, y - 7f, 12f, 0xFFFFD8D8, Paint.Align.CENTER);
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xCC05060A);
            c.drawRoundRect(x - 3f, y - 3f, x + w + 3f, y + 11f, 4f, 4f, p);
            p.setColor(b.phase2 ? 0xFFFF6A28 : 0xFFD42848);
            c.drawRect(x, y, x + w * f, y + 8f, p);
            p.setColor(0xFFFFB0B8);
            c.drawRect(x, y, x + w * f, y + 3f, p);
            p.setColor(0xAA000000);
            c.drawRect(x + w * 0.5f - 0.75f, y, x + w * 0.5f + 0.75f, y + 8f, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(1.4f);
            p.setColor(0xFFFF5070);
            p.setAlpha(170);
            c.drawRoundRect(x - 3f, y - 3f, x + w + 3f, y + 11f, 4f, 4f, p);
        }

        if (g.state == Game.PLAY) {
            float[] r = g.pauseBtn;
            p.setStyle(Paint.Style.FILL);
            p.setColor(0x99080A12);
            c.drawRoundRect(r[0], r[1], r[0] + r[2], r[1] + r[3], 9f, 9f, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(1.8f);
            p.setColor(0xFF58E0FF);
            p.setAlpha(170);
            c.drawRoundRect(r[0], r[1], r[0] + r[2], r[1] + r[3], 9f, 9f, p);
            float mx = r[0] + r[2] / 2f, my = r[1] + r[3] / 2f;
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFFE8F8FF);
            c.drawRect(mx - 7f, my - 8f, mx - 2f, my + 8f, p);
            c.drawRect(mx + 2f, my - 8f, mx + 7f, my + 8f, p);
            g.controls.draw(c, g.input, g.save.ctrlOpacity, g.player.dashReady(), g.player.dashAvailable());
        }

        if (g.bannerT > 0f && g.bannerA.length() > 0) {
            float a = Math.min(1f, Math.min(g.bannerT / 0.6f, (3.2f - g.bannerT) / 0.35f));
            title(c, g.bannerA, vw / 2f, 100f, 24f, argb(0xF4F0FF, a), 0.12f);
            if (g.bannerB.length() > 0) text(c, g.bannerB, vw / 2f, 124f, 13f, argb(0x9AF0FF, a), Paint.Align.CENTER);
            p.setStyle(Paint.Style.FILL);
            p.setColor(argb(0x58E0FF, a * 0.6f));
            c.drawRect(vw / 2f - 70f, 108f, vw / 2f + 70f, 109f, p);
        }

        if (g.fx.flashA > 0f) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(g.fx.flashC);
            p.setAlpha((int) (200f * Math.min(1f, g.fx.flashA)));
            c.drawRect(0f, 0f, vw, vh, p);
        }
        if (g.fade > 0f) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF000000);
            p.setAlpha((int) (255f * Math.min(1f, g.fade)));
            c.drawRect(0f, 0f, vw, vh, p);
        }
        if (g.save.fps) text(c, g.fpsStr, vw / 2f, vh - 8f, 11f, 0xAAFFFFFF, Paint.Align.CENTER);
    }

    // ------------------------------------------------------------------ overlays

    static void pause(Game g, Canvas c) {
        float cx = g.vw / 2f;
        dim(c, g.vw, 0xB0000000);
        panel(c, cx - 150f, 62f, 300f, 262f);
        title(c, "PAUSED", cx, 96f, 26f, 0xFFF4F0FF, 0.2f);
        button(c, g.pBtn[0], "RESUME", true);
        boolean max = g.save.vit >= 5;
        int cost = g.upgradeCost();
        button(c, g.pBtn[1], max ? "VITALITY  MAX" : "VITALITY +20 HP    " + cost + " SHARDS", false, !max && g.save.shards >= cost);
        button(c, g.pBtn[2], "SETTINGS", false);
        button(c, g.pBtn[3], "QUIT TO MENU", false);
        text(c, "SHARDS  " + g.save.shards, cx, 340f, 13f, 0xFF9AF0FF, Paint.Align.CENTER);
    }

    static void settings(Game g, Canvas c) {
        float cx = g.vw / 2f;
        Save s = g.save;
        dim(c, g.vw, 0xD0000000);
        title(c, "SETTINGS", cx, 56f, 26f, 0xFFF4F0FF, 0.2f);
        button(c, g.sBtn[0], "SCREEN SHAKE:  " + (s.shake ? "ON" : "OFF"), false);
        button(c, g.sBtn[1], "CONTROL OPACITY:  " + s.ctrlOpacity + "%", false);
        button(c, g.sBtn[2], "SHOW FPS:  " + (s.fps ? "ON" : "OFF"), false);
        if (g.prevState == Game.MENU) button(c, g.sBtn[3], g.resetArmed ? "TAP AGAIN TO ERASE SAVE" : "RESET SAVE", g.resetArmed);
        button(c, g.sBtn[4], "BACK", true);
    }

    static void dead(Game g, Canvas c) {
        float cx = g.vw / 2f, a = Math.min(1f, g.deadT);
        Art.P.setStyle(Paint.Style.FILL);
        Art.P.setColor(0xFF10000A);
        Art.P.setAlpha((int) (190f * a));
        c.drawRect(0f, 0f, g.vw, Game.VH, Art.P);
        title(c, "YOU DIED", cx, 150f, 54f, argb(0xD02040, a), 0.15f);
        if (g.deadT > 1.2f) {
            button(c, g.dBtn[0], "RESPAWN", true);
            button(c, g.dBtn[1], "MAIN MENU", false);
        }
    }
}
