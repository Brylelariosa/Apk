package com.shadowborn.game;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.HashSet;

/** Tiny SharedPreferences-backed save: progress, checkpoint and settings. */
final class Save {
    private final SharedPreferences sp;
    int shards, vit, cpRoom, cpCol = 3, cpRow = 9, ctrlOpacity = 80;
    boolean dj, edge, boss, shake = true, fps;
    final HashSet<Integer> taken = new HashSet<>();

    Save(Context ctx) {
        sp = ctx.getSharedPreferences("shadowborn_save", Context.MODE_PRIVATE);
        load();
    }

    void load() {
        shards = sp.getInt("shards", 0);
        vit = sp.getInt("vit", 0);
        cpRoom = sp.getInt("cpRoom", 0);
        cpCol = sp.getInt("cpCol", 3);
        cpRow = sp.getInt("cpRow", 9);
        ctrlOpacity = sp.getInt("ctrl", 80);
        dj = sp.getBoolean("dj", false);
        edge = sp.getBoolean("edge", false);
        boss = sp.getBoolean("boss", false);
        shake = sp.getBoolean("shake", true);
        fps = sp.getBoolean("fps", false);
        taken.clear();
        String s = sp.getString("taken", "");
        if (s != null && s.length() > 0) {
            for (String part : s.split(",")) {
                try { taken.add(Integer.parseInt(part.trim())); } catch (NumberFormatException ignored) { }
            }
        }
    }

    void write() {
        StringBuilder sb = new StringBuilder();
        for (int id : taken) {
            if (sb.length() > 0) sb.append(',');
            sb.append(id);
        }
        sp.edit()
            .putInt("shards", shards).putInt("vit", vit)
            .putInt("cpRoom", cpRoom).putInt("cpCol", cpCol).putInt("cpRow", cpRow)
            .putInt("ctrl", ctrlOpacity)
            .putBoolean("dj", dj).putBoolean("edge", edge).putBoolean("boss", boss)
            .putBoolean("shake", shake).putBoolean("fps", fps)
            .putString("taken", sb.toString())
            .apply();
    }

    boolean hasProgress() {
        return dj || boss || vit > 0 || shards > 0 || cpRoom > 0 || !taken.isEmpty();
    }

    void resetProgress() {
        shards = 0; vit = 0; cpRoom = 0; cpCol = 3; cpRow = 9;
        dj = false; edge = false; boss = false;
        taken.clear();
        write();
    }
}
