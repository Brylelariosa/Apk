package com.shadowborn.game;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import java.util.Arrays;

/**
 * Tile world: three hand-built rooms, collision queries and tile rendering.
 * Tile legend: # solid, ^ spikes, c shard, C checkpoint, S start, L/R entrances,
 * H husk, W wraith, B boss, J double-jump shrine, . empty.
 */
final class World {
    static final int TS = 32;

    static final class Room {
        final String name;
        final int w, h, theme;
        int leftTo = -1, rightTo = -1;
        final char[][] t;

        Room(String name, int w, int h, int theme) {
            this.name = name;
            this.w = w;
            this.h = h;
            this.theme = theme;
            t = new char[h][w];
            for (char[] row : t) Arrays.fill(row, '.');
        }

        Room rect(int x0, int y0, int x1, int y1, char c) {
            for (int y = y0; y <= y1; y++) for (int x = x0; x <= x1; x++) t[y][x] = c;
            return this;
        }

        Room put(int x, int y, char c) {
            t[y][x] = c;
            return this;
        }
    }

    final Room[] rooms;
    Room room;
    int index;
    boolean gateClosed;
    private final float[] lines = new float[12 * 560];

    World() {
        rooms = build();
        load(0);
    }

    void load(int i) {
        index = i;
        room = rooms[i];
        gateClosed = false;
    }

    private static Room[] build() {
        // Room 0: tutorial hall. Spikes, a pit, platforms and a ledge that needs the double jump.
        Room r0 = new Room("ASHEN GATE", 64, 12, 0);
        r0.rightTo = 1;
        r0.rect(0, 0, 63, 0, '#').rect(0, 10, 63, 11, '#');
        r0.rect(40, 10, 42, 11, '.');
        r0.rect(20, 10, 22, 10, '^');
        r0.rect(8, 8, 10, 8, '#');
        r0.rect(26, 8, 29, 8, '#');
        r0.rect(34, 8, 35, 9, '#');
        r0.rect(52, 6, 56, 6, '#');
        r0.put(3, 9, 'S').put(31, 9, 'C').put(61, 9, 'R');
        r0.put(15, 9, 'H').put(46, 9, 'H').put(27, 5, 'W');
        r0.rect(8, 7, 10, 7, 'c');
        r0.put(20, 8, 'c').put(21, 7, 'c').put(22, 8, 'c');
        r0.put(41, 8, 'c');
        r0.rect(52, 5, 56, 5, 'c');
        r0.put(59, 9, 'c');

        // Room 1: crypt. Staircase to the double-jump shrine, hanging wall, spikes, and a 6-tile chasm.
        Room r1 = new Room("GLOOM CRYPT", 72, 12, 1);
        r1.leftTo = 0;
        r1.rightTo = 2;
        r1.rect(0, 0, 71, 0, '#').rect(0, 10, 71, 11, '#');
        r1.rect(48, 10, 53, 11, '.');
        r1.rect(8, 8, 10, 8, '#').rect(13, 7, 15, 7, '#').rect(18, 6, 24, 6, '#');
        r1.rect(30, 1, 31, 7, '#');
        r1.rect(38, 8, 39, 9, '#');
        r1.rect(43, 10, 44, 10, '^');
        r1.put(1, 9, 'L').put(69, 9, 'R').put(46, 9, 'C').put(21, 5, 'J');
        r1.put(12, 9, 'H').put(26, 9, 'H').put(36, 4, 'W').put(41, 9, 'H').put(58, 5, 'W').put(62, 9, 'H');
        r1.put(49, 8, 'c').put(50, 7, 'c').put(51, 7, 'c').put(52, 8, 'c');
        r1.put(23, 5, 'c').put(24, 5, 'c').put(34, 9, 'c');

        // Room 2: boss arena.
        Room r2 = new Room("HOLLOW SANCTUM", 30, 12, 2);
        r2.leftTo = 1;
        r2.rect(0, 0, 29, 0, '#').rect(0, 10, 29, 11, '#');
        r2.rect(7, 7, 9, 7, '#').rect(20, 7, 22, 7, '#');
        r2.put(2, 9, 'L').put(4, 9, 'C').put(25, 9, 'B');
        return new Room[] {r0, r1, r2};
    }

    boolean solid(int tx, int ty) {
        if (ty < 0) return true;
        if (ty >= room.h) return false;
        if (tx < 0) return room.leftTo < 0 || gateClosed;
        if (tx >= room.w) return room.rightTo < 0;
        return room.t[ty][tx] == '#';
    }

    boolean isSpike(int tx, int ty) {
        return tx >= 0 && ty >= 0 && tx < room.w && ty < room.h && room.t[ty][tx] == '^';
    }

    /** True if the body stands on solid ground with a one-tile margin from pits and spikes. */
    boolean safeSpot(Body b) {
        int row = (int) Math.floor((b.y + b.h - 1f) / TS);
        int ty = row + 1;
        int tl = (int) Math.floor(b.x / TS), tr = (int) Math.floor((b.x + b.w - 0.01f) / TS);
        return solid(tl - 1, ty) && solid(tl, ty) && solid(tr, ty) && solid(tr + 1, ty)
            && !isSpike(tl - 1, row) && !isSpike(tl, row) && !isSpike(tr, row) && !isSpike(tr + 1, row);
    }

    int[] find(char ch) {
        for (int y = 0; y < room.h; y++) {
            for (int x = 0; x < room.w; x++) {
                if (room.t[y][x] == ch) return new int[] {x, y};
            }
        }
        return null;
    }

    void draw(Canvas c, float camX, float camY, float vw, float vh, float time, Save sv) {
        int[] pal = Art.PAL[room.theme];
        int x0 = Math.max(0, (int) (camX / TS) - 1), x1 = Math.min(room.w - 1, (int) ((camX + vw) / TS) + 1);
        int y0 = Math.max(0, (int) (camY / TS) - 1), y1 = Math.min(room.h - 1, (int) ((camY + vh) / TS) + 1);
        Paint p = Art.P;
        int n = 0;
        for (int ty = y0; ty <= y1; ty++) {
            for (int tx = x0; tx <= x1; tx++) {
                char ch = room.t[ty][tx];
                float px = tx * TS, py = ty * TS;
                if (ch == '#') {
                    int v = (tx * 7 + ty * 13 + tx * ty) & 3;
                    p.setStyle(Paint.Style.FILL);
                    p.setColor(Art.mix(pal[5], 0xFF000000, v * 0.07f));
                    c.drawRect(px, py, px + TS, py + TS, p);
                    if (n + 12 <= lines.length) {
                        float a = px + (((ty & 1) == 0) ? 10f : 22f), b = px + (((ty & 1) == 0) ? 22f : 10f);
                        lines[n++] = px; lines[n++] = py + 16f; lines[n++] = px + TS; lines[n++] = py + 16f;
                        lines[n++] = a; lines[n++] = py + 4f; lines[n++] = a; lines[n++] = py + 16f;
                        lines[n++] = b; lines[n++] = py + 16f; lines[n++] = b; lines[n++] = py + TS;
                    }
                    if (ty > 0 && room.t[ty - 1][tx] != '#') {
                        p.setColor(pal[6]);
                        c.drawRect(px, py, px + TS, py + 3f, p);
                        p.setColor(Art.mix(pal[6], 0xFFFFFFFF, 0.4f));
                        c.drawRect(px, py, px + TS, py + 1f, p);
                    }
                    if (ty < room.h - 1 && room.t[ty + 1][tx] != '#') {
                        p.setColor(0x88000000);
                        c.drawRect(px, py + TS - 3f, px + TS, py + TS, p);
                    }
                    int side = Art.mix(pal[6], 0xFF000000, 0.4f);
                    if (tx > 0 && room.t[ty][tx - 1] != '#') {
                        p.setColor(side);
                        c.drawRect(px, py, px + 2f, py + TS, p);
                    }
                    if (tx < room.w - 1 && room.t[ty][tx + 1] != '#') {
                        p.setColor(side);
                        c.drawRect(px + TS - 2f, py, px + TS, py + TS, p);
                    }
                } else if (ch == '^') {
                    spike(c, tx, ty);
                } else if (ch == 'C') {
                    brazier(c, tx, ty, sv.cpRoom == index && sv.cpCol == tx && sv.cpRow == ty, time);
                }
            }
        }
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1f);
        p.setColor(0x66000000);
        c.drawLines(lines, 0, n, p);
        if (gateClosed) {
            float a = 0.55f + 0.3f * (float) Math.sin(time * 6f);
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFFFF3050);
            p.setAlpha((int) (90f * a));
            c.drawRect(0f, 0f, 16f, room.h * TS, p);
            p.setAlpha((int) (255f * a));
            c.drawRect(0f, 0f, 3f, room.h * TS, p);
        }
    }

    private void spike(Canvas c, int tx, int ty) {
        float px = tx * TS, py = ty * TS;
        boolean up = solid(tx, ty + 1);
        Path pa = Art.PA;
        pa.reset();
        for (int i = 0; i < 3; i++) {
            float bx = px + i * 10.67f + 1f;
            if (up) {
                pa.moveTo(bx, py + TS); pa.lineTo(bx + 4.7f, py + 12f); pa.lineTo(bx + 9.4f, py + TS);
            } else {
                pa.moveTo(bx, py); pa.lineTo(bx + 4.7f, py + 20f); pa.lineTo(bx + 9.4f, py);
            }
            pa.close();
        }
        Paint p = Art.P;
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFB8C0D8);
        c.drawPath(pa, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.2f);
        p.setColor(0xFFFF3050);
        p.setAlpha(190);
        c.drawPath(pa, p);
    }

    private void brazier(Canvas c, int tx, int ty, boolean lit, float time) {
        float cx = tx * TS + 16f, gy = ty * TS + TS;
        Paint p = Art.P;
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF2A2230);
        c.drawRect(cx - 6f, gy - 14f, cx + 6f, gy, p);
        p.setColor(0xFF3A3040);
        c.drawRect(cx - 10f, gy - 20f, cx + 10f, gy - 14f, p);
        p.setColor(0xFF5A4A66);
        c.drawRect(cx - 10f, gy - 20f, cx + 10f, gy - 18f, p);
        if (lit) {
            Art.glow(c, Art.GLOW_ORANGE, cx, gy - 30f, 56f + 6f * (float) Math.sin(time * 9f), 0.9f);
            float fl = 1f + 0.15f * (float) Math.sin(time * 13f);
            Path pa = Art.PA;
            pa.reset();
            pa.moveTo(cx - 6f, gy - 20f);
            pa.quadTo(cx - 8f, gy - 32f * fl, cx, gy - 42f * fl);
            pa.quadTo(cx + 8f, gy - 32f * fl, cx + 6f, gy - 20f);
            pa.close();
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFFFF9A30);
            c.drawPath(pa, p);
            pa.reset();
            pa.moveTo(cx - 3f, gy - 20f);
            pa.quadTo(cx - 4f, gy - 27f * fl, cx, gy - 32f * fl);
            pa.quadTo(cx + 4f, gy - 27f * fl, cx + 3f, gy - 20f);
            pa.close();
            p.setColor(0xFFFFE070);
            c.drawPath(pa, p);
        } else {
            Art.glow(c, Art.GLOW_ORANGE, cx, gy - 21f, 16f, 0.4f);
            Art.dot(c, cx, gy - 21f, 2.5f, 0xFF803010, 200);
        }
    }
}
