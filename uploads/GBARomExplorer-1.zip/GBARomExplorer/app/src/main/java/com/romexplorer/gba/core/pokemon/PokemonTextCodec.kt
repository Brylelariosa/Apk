package com.romexplorer.gba.core.pokemon

/**
 * Decodes the Generation III "Western" proprietary character encoding used
 * by Pokémon FireRed/LeafGreen/Emerald/Ruby/Sapphire for item names, trainer
 * names, and other in-ROM strings — verified against the character table at
 * https://bulbapedia.bulbagarden.net/wiki/Character_encoding_(Generation_III).
 *
 * This intentionally covers only the codepoints needed to render standard
 * English names correctly (letters, digits, space, and common punctuation):
 * enough for every FireRed item/trainer name. Regional-accented characters,
 * control codes (0xFC+), and the Japanese character set are out of scope —
 * unmapped bytes render as a hex placeholder rather than silently guessing.
 */
object PokemonTextCodec {
    private const val TERMINATOR = 0xFF
    private const val SPACE = 0x00

    private val table: Map<Int, Char> = buildMap {
        put(SPACE, ' ')
        // 0xA1..0xAA = '0'..'9'
        for (i in 0..9) put(0xA1 + i, ('0' + i))
        put(0xAB, '!')
        put(0xAC, '?')
        put(0xAD, '.')
        put(0xAE, '-')
        put(0xB0, '…')
        put(0xB1, '"')
        put(0xB2, '"')
        put(0xB3, '\'')
        put(0xB4, '\'')
        put(0xB5, '♂')
        put(0xB6, '♀')
        put(0xB7, '$')
        put(0xB8, ',')
        put(0xB9, '×')
        put(0xBA, '/')
        // 0xBB..0xD4 = 'A'..'Z'
        for (i in 0..25) put(0xBB + i, ('A' + i))
        // 0xD5..0xEE = 'a'..'z'
        for (i in 0..25) put(0xD5 + i, ('a' + i))
        put(0xF0, ':')
    }

    /**
     * Decodes bytes starting at [offset] up to [maxLength] bytes or the
     * 0xFF terminator, whichever comes first. Padding after the terminator
     * (conventionally 0x00) is not included in the result.
     */
    fun decode(bytes: ByteArray, offset: Int, maxLength: Int): String {
        val sb = StringBuilder()
        var i = offset
        val end = minOf(offset + maxLength, bytes.size)
        while (i < end) {
            val b = bytes[i].toInt() and 0xFF
            if (b == TERMINATOR) break
            sb.append(table[b] ?: '\uFFFD') // unmapped byte -> replacement char, never a guess
            i++
        }
        return sb.toString()
    }
}
