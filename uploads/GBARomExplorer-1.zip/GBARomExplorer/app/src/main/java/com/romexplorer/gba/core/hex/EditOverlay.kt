package com.romexplorer.gba.core.hex

/** A single undoable byte edit. */
private data class ByteEdit(val offset: Long, val previousValue: Int?, val newValue: Int)

/**
 * Tracks in-progress hex edits as a sparse offset -> byte overlay on top of
 * the original ROM bytes, without ever mutating the source file (SAF
 * documents may not even be writable in place). Supports full undo/redo.
 * "Save as new file" (in the repository layer) applies this overlay onto a
 * copy of the original bytes.
 */
class EditOverlay {
    private val overlay = LinkedHashMap<Long, Int>() // offset -> new byte value (0..255)
    private val undoStack = ArrayDeque<ByteEdit>()
    private val redoStack = ArrayDeque<ByteEdit>()

    val isDirty: Boolean get() = overlay.isNotEmpty()
    val editedOffsets: Set<Long> get() = overlay.keys

    /** Returns the overlaid value for [offset] if edited, else null (caller falls back to original byte). */
    fun get(offset: Long): Int? = overlay[offset]

    fun setByte(offset: Long, newValue: Int, originalValue: Int) {
        val previous = overlay[offset]
        val effectivePrevious = previous ?: originalValue
        if (effectivePrevious == newValue) return
        overlay[offset] = newValue
        undoStack.addLast(ByteEdit(offset, previous, newValue))
        redoStack.clear()
    }

    fun canUndo(): Boolean = undoStack.isNotEmpty()
    fun canRedo(): Boolean = redoStack.isNotEmpty()

    fun undo(): Long? {
        val edit = undoStack.removeLastOrNull() ?: return null
        if (edit.previousValue == null) overlay.remove(edit.offset) else overlay[edit.offset] = edit.previousValue
        redoStack.addLast(edit)
        return edit.offset
    }

    fun redo(): Long? {
        val edit = redoStack.removeLastOrNull() ?: return null
        overlay[edit.offset] = edit.newValue
        undoStack.addLast(edit)
        return edit.offset
    }

    fun clear() {
        overlay.clear()
        undoStack.clear()
        redoStack.clear()
    }

    /** Materializes the overlay onto a copy of [original], for export/save. */
    fun applyTo(original: ByteArray): ByteArray {
        val result = original.copyOf()
        for ((offset, value) in overlay) {
            if (offset >= 0 && offset < result.size) {
                result[offset.toInt()] = value.toByte()
            }
        }
        return result
    }
}
