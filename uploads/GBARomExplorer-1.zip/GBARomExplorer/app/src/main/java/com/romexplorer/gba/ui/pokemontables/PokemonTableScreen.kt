@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.romexplorer.gba.ui.pokemontables

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.romexplorer.gba.core.graphics.DecodedImage
import com.romexplorer.gba.core.pokemon.DisplayField
import com.romexplorer.gba.core.pokemon.DisplayRow
import com.romexplorer.gba.core.pokemon.FireRedTables
import com.romexplorer.gba.core.pokemon.model.KnownTableSchema
import org.koin.androidx.compose.koinViewModel

@Composable
fun PokemonTableScreen(
    navController: NavHostController,
    viewModel: PokemonTableViewModel = koinViewModel(),
) {
    val uiState by viewModel.uiState.collectAsState()
    val selectedTable by viewModel.selectedTable.collectAsState()
    val isLoading by viewModel.isLoadingTable.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(selectedTable?.schema?.displayName ?: "Pokémon Tables") },
                navigationIcon = {
                    IconButton(onClick = {
                        if (selectedTable != null) viewModel.clearSelection() else navController.popBackStack()
                    }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
            )
        },
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize().padding(padding)) {
            when {
                isLoading -> CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
                selectedTable != null -> EntryList(selectedTable!!, viewModel)
                uiState is PokemonTablesState.NoRomOpen -> CenteredMessage("Open a ROM first.")
                uiState is PokemonTablesState.NotFireRed -> CenteredMessage(
                    "These known tables are specific to Pokémon FireRed — this ROM isn't recognized as FireRed.",
                )
                uiState is PokemonTablesState.Ready -> TableList(
                    tables = (uiState as PokemonTablesState.Ready).availableTables,
                    onSelect = viewModel::selectTable,
                )
            }
        }
    }
}

@Composable
private fun CenteredMessage(text: String) {
    Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
        Text(text)
    }
}

@Composable
private fun TableList(tables: List<KnownTableSchema>, onSelect: (KnownTableSchema) -> Unit) {
    LazyColumn(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 8.dp)) {
        items(tables) { schema ->
            Card(onClick = { onSelect(schema) }, modifier = Modifier.padding(vertical = 4.dp)) {
                ListItem(
                    headlineContent = { Text(schema.displayName) },
                    supportingContent = { Text("${schema.entryCount} entries · ${schema.fields.size} fields") },
                )
            }
        }
    }
}

/**
 * One card per entry, fields laid out two-per-row and wrapped to the
 * screen's width — unlike a spreadsheet grid, this never needs horizontal
 * scrolling no matter how many fields a schema has. The list itself
 * scrolls vertically via LazyColumn for the (up to ~750) rows.
 */
@Composable
private fun EntryList(selection: PokemonTableSelection, viewModel: PokemonTableViewModel) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
    ) {
        items(selection.rows, key = { it.index }) { row -> EntryCard(selection.schema, row, viewModel) }
    }
}

@Composable
private fun EntryCard(schema: KnownTableSchema, row: DisplayRow, viewModel: PokemonTableViewModel) {
    val showsIcon = schema == FireRedTables.speciesBaseStats || schema == FireRedTables.items || schema == FireRedTables.trainers
    Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Column(modifier = Modifier.padding(12.dp)) {
            if (showsIcon) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    EntryIcon(schema, row, viewModel)
                    Spacer(modifier = Modifier.width(8.dp))
                    EntryTitle(row)
                }
            } else {
                EntryTitle(row)
            }
            Spacer(modifier = Modifier.height(6.dp))
            FieldGrid(row.fields)
            if (row.partyLines.isNotEmpty()) {
                Spacer(modifier = Modifier.height(6.dp))
                PartySection(row.partyLines)
            }
        }
    }
}

@Composable
private fun EntryTitle(row: DisplayRow) {
    Text(
        text = if (row.title != null) "#${row.index}  ${row.title}" else "#${row.index}",
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.Bold,
    )
}

/**
 * Loads its row's icon lazily, in a coroutine scoped to this composable's
 * own lifetime via `produceState` — not `viewModelScope` — so decoding
 * only happens while the row is actually on screen (LazyColumn only keeps
 * near-visible rows composed) and is cancelled the moment it scrolls away.
 * Shows nothing (not even a placeholder box) while loading or if this
 * particular entry has no image — a blank cell reads better here than a
 * "broken image" glyph for something that's often genuinely just empty.
 */
@Composable
private fun EntryIcon(schema: KnownTableSchema, row: DisplayRow, viewModel: PokemonTableViewModel) {
    val image by produceState<DecodedImage?>(initialValue = null, row.index, row.trainerPicIndex, schema) {
        value = when (schema) {
            FireRedTables.speciesBaseStats -> viewModel.loadSpeciesIcon(row.index)
            FireRedTables.items -> viewModel.loadItemIcon(row.index)
            FireRedTables.trainers -> row.trainerPicIndex?.let { viewModel.loadTrainerSprite(it) }
            else -> null
        }
    }
    val bitmap = image?.toImageBitmap()
    if (bitmap != null) {
        Image(bitmap = bitmap, contentDescription = null, modifier = Modifier.size(40.dp))
    } else {
        Spacer(modifier = Modifier.size(40.dp))
    }
}

private fun DecodedImage.toImageBitmap(): ImageBitmap {
    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    bitmap.setPixels(pixels, 0, width, 0, 0, width, height)
    return bitmap.asImageBitmap()
}

@Composable
private fun PartySection(partyLines: List<String>) {
    Column {
        Text("Party", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        partyLines.forEach { line ->
            Text(line, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 2.dp))
        }
    }
}

/** Two-column label/value layout; wraps within the available width instead of scrolling sideways. */
@Composable
private fun FieldGrid(fields: List<DisplayField>) {
    Column {
        fields.chunked(2).forEach { pair ->
            Row(modifier = Modifier.fillMaxWidth()) {
                FieldCell(pair[0], Modifier.weight(1f))
                if (pair.size > 1) FieldCell(pair[1], Modifier.weight(1f)) else Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun FieldCell(field: DisplayField, modifier: Modifier) {
    Column(modifier = modifier.padding(vertical = 3.dp)) {
        Text(field.label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(field.value, style = MaterialTheme.typography.bodyMedium)
    }
}
