package com.romexplorer.gba.core.pokemon

import com.romexplorer.gba.core.pokemon.model.DisplayHint
import com.romexplorer.gba.core.pokemon.model.FieldKind
import com.romexplorer.gba.core.pokemon.model.KnownTableSchema
import com.romexplorer.gba.core.pokemon.model.TableField
import com.romexplorer.gba.core.pokemon.model.TableRow

/** One field ready for display: its column label and a human-readable value. */
data class DisplayField(val label: String, val value: String)

/**
 * One table entry ready for display. [title] is the entry's own name (e.g.
 * a trainer's or a species' name) when one is available, so the UI can show
 * it once as a heading instead of burying it in the field list. [partyLines]
 * is trainer-specific (see [TrainerPartyFormatter]) and empty for every
 * other table. [trainerPicIndex] is also trainer-specific: unlike species
 * and item icons, which are keyed by the row's own [index], a trainer's
 * battle sprite is keyed by its separate "Trainer Pic" field (many trainers
 * share one sprite per trainer class — see [TrainerSpriteReader]), so it's
 * carried here rather than assumed to equal [index].
 */
data class DisplayRow(
    val index: Int,
    val title: String?,
    val fields: List<DisplayField>,
    val partyLines: List<String> = emptyList(),
    val trainerPicIndex: Int? = null,
)

/**
 * Turns raw [TableRow]s (plain decoded numbers/strings, keyed by field name
 * — see [PokemonTableReader]) into [DisplayRow]s ready to show in the UI:
 * resolves [DisplayHint.ITEM_ID] fields to item names via [itemNames], and
 * titles the row from [externalTitle] if the caller has one (e.g. a species
 * name — species data has no name field of its own, see [FireRedTables]),
 * falling back to the entry's own [FieldKind.POKEMON_STRING] field, if the
 * schema has one, rather than listing it as just another field.
 *
 * Pure and Android-free by design, so it's unit-testable without a ROM or
 * an Activity.
 */
object TableRowFormatter {
    private const val NO_ITEM = "-"

    fun format(
        schema: KnownTableSchema,
        row: TableRow,
        itemNames: Map<Int, String> = emptyMap(),
        externalTitle: String? = null,
    ): DisplayRow {
        val titleField = schema.fields.firstOrNull { it.kind == FieldKind.POKEMON_STRING }
        val fields = schema.fields
            .filter { it !== titleField }
            .map { field -> DisplayField(field.name, formatValue(field, row.values[field.name], itemNames)) }
        val embeddedTitle = titleField
            ?.let { row.values[it.name] as? String }
            ?.takeIf { it.isNotBlank() }
        return DisplayRow(row.index, externalTitle ?: embeddedTitle, fields)
    }

    private fun formatValue(field: TableField, raw: Any?, itemNames: Map<Int, String>): String = when {
        raw == null -> ""
        field.displayHint == DisplayHint.ITEM_ID -> formatItem(raw, itemNames)
        else -> raw.toString()
    }

    private fun formatItem(raw: Any, itemNames: Map<Int, String>): String {
        val id = (raw as? Long)?.toInt() ?: return raw.toString()
        if (id == 0) return NO_ITEM // Gen III's own "no item" sentinel
        return itemNames[id]?.takeIf { it.isNotBlank() } ?: "Item #$id"
    }
}
