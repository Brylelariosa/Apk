package com.romexplorer.gba.core.pokemon

import com.romexplorer.gba.core.pokemon.model.DisplayHint
import com.romexplorer.gba.core.pokemon.model.FieldKind
import com.romexplorer.gba.core.pokemon.model.KnownTableSchema
import com.romexplorer.gba.core.pokemon.model.TableField
import com.romexplorer.gba.core.pokemon.model.TableRow

/**
 * One field ready for display: [label] and a human-readable [value]. For
 * fields that can be edited, [rawValue] is the underlying number (what's
 * actually stored on disk — e.g. an item's numeric ID even when [value] is
 * showing that item's name) and [editableField] carries the byte-layout
 * metadata a write needs (see [PokemonTableWriter]). Both are null for
 * fields that aren't editable through this path — currently text
 * ([FieldKind.POKEMON_STRING]) and ROM pointers ([FieldKind.POINTER32]),
 * see [PokemonTableWriter] for why.
 */
data class DisplayField(
    val label: String,
    val value: String,
    val rawValue: Long? = null,
    val editableField: TableField? = null,
)

/**
 * One table entry ready for display. [title] is the entry's own name (e.g.
 * a trainer's or a species' name) when one is available, so the UI can show
 * it once as a heading instead of burying it in the field list. [partyLines]
 * is trainer-specific (see [TrainerPartyFormatter]) and empty for every
 * other table. [trainerPicIndex] is also trainer-specific: unlike species
 * and item icons, which are keyed by the row's own [index], a trainer's
 * battle sprite is keyed by its separate "Trainer Pic" field (many trainers
 * share one sprite per trainer class — see [TrainerSpriteReader]), so it's
 * carried here rather than assumed to equal [index].
 */
data class DisplayRow(
    val index: Int,
    val title: String?,
    val fields: List<DisplayField>,
    val partyLines: List<String> = emptyList(),
    val trainerPicIndex: Int? = null,
)

/**
 * Turns raw [TableRow]s (plain decoded numbers/strings, keyed by field name
 * — see [PokemonTableReader]) into [DisplayRow]s ready to show in the UI:
 * resolves [DisplayHint.ITEM_ID]/[DisplayHint.TYPE_ID] fields to their
 * names via [itemNames]/[typeNames], and titles the row from
 * [externalTitle] if the caller has one (e.g. a species name — species data
 * has no name field of its own, see [FireRedTables]), falling back to the
 * entry's own [FieldKind.POKEMON_STRING] field, if the schema has one,
 * rather than listing it as just another field.
 *
 * Pure and Android-free by design, so it's unit-testable without a ROM or
 * an Activity.
 */
object TableRowFormatter {
    private const val NO_ITEM = "-"

    fun format(
        schema: KnownTableSchema,
        row: TableRow,
        itemNames: Map<Int, String> = emptyMap(),
        typeNames: Map<Int, String> = emptyMap(),
        externalTitle: String? = null,
    ): DisplayRow {
        val titleField = schema.fields.firstOrNull { it.kind == FieldKind.POKEMON_STRING }
        val fields = schema.fields
            .filter { it !== titleField }
            .map { field -> buildDisplayField(field, row.values[field.name], itemNames, typeNames) }
        val embeddedTitle = titleField
            ?.let { row.values[it.name] as? String }
            ?.takeIf { it.isNotBlank() }
        return DisplayRow(row.index, externalTitle ?: embeddedTitle, fields)
    }

    private fun buildDisplayField(
        field: TableField,
        raw: Any?,
        itemNames: Map<Int, String>,
        typeNames: Map<Int, String>,
    ): DisplayField {
        val rawLong = raw as? Long
        val value = when {
            raw == null -> ""
            field.displayHint == DisplayHint.ITEM_ID && rawLong != null -> formatLookup(rawLong, itemNames, "Item", zeroMeansNone = true)
            field.displayHint == DisplayHint.TYPE_ID && rawLong != null -> formatLookup(rawLong, typeNames, "Type", zeroMeansNone = false)
            else -> raw.toString()
        }
        // Editing writes raw bytes back to the ROM (see PokemonTableWriter),
        // which only makes sense for plain numeric fields: text has its own
        // encoding, and pointers are file addresses, not stats.
        val editable = if (rawLong != null && field.kind != FieldKind.POKEMON_STRING && field.kind != FieldKind.POINTER32) {
            field
        } else {
            null
        }
        return DisplayField(field.name, value, rawLong, editable)
    }

    private fun formatLookup(id: Long, names: Map<Int, String>, label: String, zeroMeansNone: Boolean): String {
        val intId = id.toInt()
        if (zeroMeansNone && intId == 0) return NO_ITEM // Gen III's own "no item" sentinel — doesn't apply to types (0 = Normal, a real type)
        return names[intId]?.takeIf { it.isNotBlank() } ?: "$label #$intId"
    }
}
