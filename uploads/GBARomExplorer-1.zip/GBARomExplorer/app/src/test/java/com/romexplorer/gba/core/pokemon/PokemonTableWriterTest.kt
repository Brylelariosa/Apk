package com.romexplorer.gba.core.pokemon

import com.romexplorer.gba.core.hex.EditOverlay
import com.romexplorer.gba.core.pokemon.model.FieldKind
import com.romexplorer.gba.core.pokemon.model.KnownTableSchema
import com.romexplorer.gba.core.pokemon.model.TableField
import com.romexplorer.gba.core.rom.ByteArrayRomAccessor
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PokemonTableWriterTest {

    private val testSchema = KnownTableSchema(
        id = "test",
        displayName = "Test",
        romOffset = 100L,
        entrySize = 8,
        entryCount = 4,
        fields = listOf(
            TableField("HP", 0, 1, FieldKind.UINT8),
            TableField("Power", 1, 2, FieldKind.UINT16),
            TableField("Name", 3, 4, FieldKind.POKEMON_STRING),
            TableField("Pointer", 7, 1, FieldKind.UINT8), // deliberately short; not exercised as a pointer here
        )
    )

    @Test
    fun `writes a single-byte field at the correct offset`() = runBlocking {
        val rom = ByteArrayRomAccessor(ByteArray(200))
        val overlay = EditOverlay()

        val result = PokemonTableWriter.write(rom, overlay, testSchema, rowIndex = 2, field = testSchema.fields[0], newValue = 99L)

        assertEquals(FieldWriteResult.Success, result)
        // row 2 starts at romOffset(100) + 2*entrySize(8) = 116; HP is byteOffset 0 -> byte 116
        assertEquals(99, overlay.get(116L))
    }

    @Test
    fun `writes a two-byte field little-endian across two overlay bytes`() = runBlocking {
        val rom = ByteArrayRomAccessor(ByteArray(200))
        val overlay = EditOverlay()

        // row 0 Power field starts at 100 + 1 = 101
        val result = PokemonTableWriter.write(rom, overlay, testSchema, rowIndex = 0, field = testSchema.fields[1], newValue = 0x1234L)

        assertEquals(FieldWriteResult.Success, result)
        assertEquals(0x34, overlay.get(101L)) // low byte
        assertEquals(0x12, overlay.get(102L)) // high byte
    }

    @Test
    fun `rejects a value that does not fit the field's byte width`() = runBlocking {
        val rom = ByteArrayRomAccessor(ByteArray(200))
        val overlay = EditOverlay()

        val result = PokemonTableWriter.write(rom, overlay, testSchema, rowIndex = 0, field = testSchema.fields[0], newValue = 256L)

        assertEquals(FieldWriteResult.OutOfRange, result)
        assertTrue(overlay.editedOffsets.isEmpty())
    }

    @Test
    fun `refuses to write text fields`() = runBlocking {
        val rom = ByteArrayRomAccessor(ByteArray(200))
        val overlay = EditOverlay()

        val result = PokemonTableWriter.write(rom, overlay, testSchema, rowIndex = 0, field = testSchema.fields[2], newValue = 1L)

        assertEquals(FieldWriteResult.NotEditable, result)
    }

    @Test
    fun `refuses to write pointer fields`() = runBlocking {
        val rom = ByteArrayRomAccessor(ByteArray(200))
        val overlay = EditOverlay()
        val pointerField = TableField("Some Pointer", 0, 4, FieldKind.POINTER32)

        val result = PokemonTableWriter.write(rom, overlay, testSchema, rowIndex = 0, field = pointerField, newValue = 1000L)

        assertEquals(FieldWriteResult.NotEditable, result)
    }

    @Test
    fun `a written value round-trips back through PokemonTableReader unchanged`() = runBlocking {
        val rom = ByteArrayRomAccessor(ByteArray(200))
        val overlay = EditOverlay()
        val hpField = testSchema.fields[0]

        PokemonTableWriter.write(rom, overlay, testSchema, rowIndex = 1, field = hpField, newValue = 77L)
        val table = PokemonTableReader.read(rom, testSchema, overlay)

        assertEquals(77L, table.rows[1].values["HP"])
    }

    @Test
    fun `out-of-bounds offsets are rejected rather than throwing`() = runBlocking {
        val rom = ByteArrayRomAccessor(ByteArray(10)) // far smaller than the schema's own offset math needs
        val overlay = EditOverlay()

        val result = PokemonTableWriter.write(rom, overlay, testSchema, rowIndex = 0, field = testSchema.fields[0], newValue = 5L)

        assertEquals(FieldWriteResult.OutOfBounds, result)
    }

    @Test
    fun `an overlay edit outside this table's byte range does not leak into it`() = runBlocking {
        val rom = ByteArrayRomAccessor(ByteArray(200))
        val overlay = EditOverlay()
        overlay.setByte(offset = 5L, newValue = 42, originalValue = 0) // well before testSchema's romOffset of 100

        val table = PokemonTableReader.read(rom, testSchema, overlay)

        assertEquals(0L, table.rows[0].values["HP"]) // untouched — the stray edit is outside this table entirely
    }
}
