package com.romexplorer.gba.core.pokemon

import org.junit.Assert.assertEquals
import org.junit.Test

class PokemonTextCodecTest {

    @Test
    fun `decodes letters, digits, and space, and stops at the terminator`() {
        val bytes = byteArrayOf(
            0xBB.toByte(), 0xD4.toByte(), // 'A', 'Z'
            0xD5.toByte(), 0xEE.toByte(), // 'a', 'z'
            0x00, // space
            0xA1.toByte(), 0xAA.toByte(), // '0', '9'
            0xFF.toByte(), // terminator
            0xBB.toByte(), // must be ignored - after the terminator
        )
        assertEquals("AZaz 09", PokemonTextCodec.decode(bytes, 0, bytes.size))
    }

    @Test
    fun `decodes a real item name (POTION)`() {
        // P=0xCA, O=0xC9, T=0xCE, I=0xC3, O=0xC9, N=0xC8, terminator, then zero padding
        val bytes = byteArrayOf(
            0xCA.toByte(), 0xC9.toByte(), 0xCE.toByte(), 0xC3.toByte(), 0xC9.toByte(), 0xC8.toByte(),
            0xFF.toByte(), 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        )
        assertEquals("POTION", PokemonTextCodec.decode(bytes, 0, bytes.size))
    }

    @Test
    fun `decodes starting at a nonzero offset within a larger buffer`() {
        val bytes = byteArrayOf(0x00, 0x00, 0xBB.toByte(), 0xBC.toByte(), 0xFF.toByte())
        assertEquals("AB", PokemonTextCodec.decode(bytes, 2, 3))
    }
}
