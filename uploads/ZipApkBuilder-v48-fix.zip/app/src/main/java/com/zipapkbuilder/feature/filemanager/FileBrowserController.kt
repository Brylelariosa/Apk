package com.zipapkbuilder.feature.filemanager

import android.app.AlertDialog
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import com.zipapkbuilder.MainActivity
import com.zipapkbuilder.R
import com.zipapkbuilder.core.BoundedListView
import com.zipapkbuilder.core.ButtonTone
import com.zipapkbuilder.core.DialogAction
import com.zipapkbuilder.core.Formatters
import com.zipapkbuilder.core.IconMenuAdapter
import com.zipapkbuilder.core.IconMenuRow
import com.zipapkbuilder.core.PrefKeys
import com.zipapkbuilder.core.dialogMessage
import com.zipapkbuilder.core.dialogWithActions
import com.zipapkbuilder.core.pillButton
import com.zipapkbuilder.feature.build.BuildRetryManager
import com.zipapkbuilder.model.RepoItem
import com.zipapkbuilder.net.GitHubApi
import org.json.JSONArray
import org.json.JSONObject

/**
 * Browses the target GitHub repo via the Contents API: the entry point that
 * verifies a token and repo are set, the directory-listing fetch, and the
 * browser dialog itself (breadcrumb, search-filter, folder navigation, and
 * the per-item / bottom-bar action menus). Split out of [FileManagerController]
 * as the "look at what's there and get to the right screen" concern, distinct
 * from actually editing ([FileEditorController]) or mutating
 * ([FileOperationController]) a file — this class delegates to both for the
 * actions reachable from its menus, and to [FileUploadController] indirectly
 * (via [FileOperationController.showNewItemDialog]'s "Upload File" entry).
 */
class FileBrowserController(
    private val activity: MainActivity,
    private val fileEditorController: FileEditorController,
    private val fileOperationController: FileOperationController,
    private val zipExtractController: ZipExtractController
) {
    /**
     * Whether the browser dialog is currently on screen — as opposed to
     * `showBrowserDialog`'s own local `pendingDialog` var, which only tracks
     * one specific dialog instance's own self-dismiss actions (New/Delete/Up/Close)
     * and isn't visible outside that single function call. This one is, so a
     * caller elsewhere in the app (e.g. a background upload finishing) can ask
     * "is the user actually looking at the file browser right now" before
     * deciding whether refreshing it is a helpful update or an unwanted
     * pop-back-open — see [isShowing] and [fetchAndBrowse]'s callers.
     */
    private var browserDialogShowing = false

    /** True while the browser dialog is on screen — see [browserDialogShowing]'s kdoc. */
    fun isShowing(): Boolean = browserDialogShowing

    /** Maps a file extension to a color used for its name in the browser list. */
    private fun fileTypeColor(name: String): Int {
        val ext = name.substringAfterLast(".", "").lowercase()
        return when (ext) {
            "kt", "java", "py", "js", "ts", "c", "cpp", "h", "rs", "go", "rb", "swift" -> 0xFF5B8DEF.toInt() // code — blue
            "yml", "yaml", "gradle", "properties", "toml", "json", "lock" -> 0xFFF5A623.toInt()             // config/build — amber
            "xml", "md", "txt", "html", "css" -> 0xFF2ECC71.toInt()                                          // markup/docs — green
            "png", "jpg", "jpeg", "webp", "svg", "gif", "ico" -> 0xFFE066A8.toInt()                          // images — pink
            else -> 0xFF7C6BFF.toInt()                                                                       // everything else — original purple
        }
    }

    fun showManageFilesDialog() {
        val token = activity.etToken.text.toString().trim()
        val repo  = activity.etRepo.text.toString().trim()
        if (token.isEmpty()) { activity.appendLog("⚠ Enter your GitHub token first."); return }
        val branch = activity.etBranch.text.toString().trim().ifEmpty { "main" }

        // Allow opening the create-repo dialog even without a repo name
        if (repo.isEmpty()) {
            lateinit var dlg: AlertDialog
            val content = activity.dialogWithActions(
                activity.dialogMessage("No repo entered. Would you like to create a new repo?"),
                DialogAction("Create Repo", ButtonTone.GREEN, R.drawable.ic_add) { dlg.dismiss(); promptCreateRepo(token) },
                DialogAction("Cancel", ButtonTone.SURFACE, R.drawable.ic_close) { dlg.dismiss() }
            )
            dlg = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
                .setTitle("📂 File Manager")
                .setView(content)
                .show()
            return
        }

        // If owner is already cached, go straight to browsing
        if (activity.lastOwner.isNotEmpty()) {
            fetchAndBrowse(token, activity.lastOwner, repo, branch, "")
            return
        }

        // Otherwise look it up (same pattern as browseAllArtifacts / downloadLatestRunLogs)
        activity.setBusy(true)
        activity.appendLog("Verifying token…")
        activity.bgExecutor.execute {
            val owner = activity.buildFlowController.fetchOwner(token)
            if (owner == null) {
                activity.appendLog("✗ Could not verify token — check it has 'repo' scope.")
                activity.mainHandler.post { activity.setBusy(false) }
                return@execute
            }
            activity.lastOwner = owner
            activity.mainHandler.post {
                activity.tvOwnerInfo.text = "✓  @$owner / $repo"; activity.tvOwnerInfo.visibility = android.view.View.VISIBLE
                fetchAndBrowse(token, owner, repo, branch, "")
            }
        }
    }

    /** Fetches directory contents and opens the browser dialog. */
    fun fetchAndBrowse(token: String, owner: String, repo: String, branch: String, path: String) {
        activity.setBusy(true)
        activity.appendLog("Browsing ${if (path.isEmpty()) "repo root" else "/$path"} …")
        activity.bgExecutor.execute {
            try {
                val items = mutableListOf<RepoItem>()
                val (code, body) = GitHubApi.httpGet(token, GitHubApi.apiContents(owner, repo, path.ifEmpty { "" }))
                when {
                    code == 404  -> { /* empty dir — show empty browser */ }
                    code != 200  -> throw Exception("HTTP $code listing /${path.ifEmpty { "" }}")
                    else -> {
                        val arr = JSONArray(body)
                        for (i in 0 until arr.length()) {
                            val obj = arr.getJSONObject(i)
                            items.add(RepoItem(
                                type = obj.getString("type"),
                                name = obj.getString("name"),
                                path = obj.getString("path"),
                                sha  = obj.optString("sha", ""),
                                size = obj.optLong("size", 0L)
                            ))
                        }
                        // Folders first, then files, alphabetical within each group
                        items.sortWith(compareBy({ if (it.type == "dir") 0 else 1 }, { it.name }))
                    }
                }
                activity.mainHandler.post {
                    activity.setBusy(false)
                    // The GitHub fetch above can take a few seconds; if the user backed
                    // out of the app in the meantime, don't pop a new AlertDialog on a
                    // dead Activity (WindowManager.BadTokenException). This one guard
                    // covers every fetchAndBrowse() call site in the file, since they
                    // all funnel through here.
                    if (activity.isFinishing || activity.isDestroyed) return@post
                    showBrowserDialog(token, owner, repo, branch, path, items)
                }
            } catch (e: Exception) {
                activity.appendLog("✗ ${e.message}")
                activity.mainHandler.post { activity.setBusy(false) }
            }
        }
    }

    /** Main browsing dialog — tap folder to navigate, tap file to act on it. */
    private fun showBrowserDialog(
        token: String, owner: String, repo: String, branch: String,
        path: String, items: List<RepoItem>
    ) {
        val dp = activity.resources.displayMetrics.density

        // ── Custom title: header bar + action chips + breadcrumb ──────────
        val segments = if (path.isEmpty()) emptyList() else path.split("/")

        val titleRoot = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(android.graphics.Color.parseColor("#1C2038"))
        }

        // Top bar: icon + repo path
        val topBar = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity     = android.view.Gravity.CENTER_VERTICAL
            setPadding((16 * dp).toInt(), (12 * dp).toInt(), (8 * dp).toInt(), (6 * dp).toInt())
        }
        val folderIv = android.widget.ImageView(activity).apply {
            setImageResource(R.drawable.ic_folder)
            imageTintList = android.content.res.ColorStateList.valueOf(
                android.graphics.Color.parseColor("#FF9F43"))
            layoutParams = LinearLayout.LayoutParams((18 * dp).toInt(), (18 * dp).toInt()).also {
                it.marginEnd = (10 * dp).toInt()
            }
        }
        val titleTv = TextView(activity).apply {
            text      = "$owner / $repo"
            textSize  = 14f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(android.graphics.Color.parseColor("#E8EAED"))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val branchChip = TextView(activity).apply {
            text = "  $branch  "
            textSize = 9.5f
            setTextColor(0xFF2ECC71.toInt())
            typeface = android.graphics.Typeface.MONOSPACE
        }
        topBar.addView(folderIv); topBar.addView(titleTv); topBar.addView(branchChip)
        titleRoot.addView(topBar)

        // Action chips row
        var pendingDialog: AlertDialog? = null
        val chipRow = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding((14*dp).toInt(), (2*dp).toInt(), (14*dp).toInt(), (8*dp).toInt())
        }
        val switchChip = activity.pillButton("Switch", ButtonTone.SURFACE, R.drawable.ic_switch) {
            pendingDialog?.dismiss(); activity.repoSwitcher.showSavedReposDialog()
        }
        switchChip.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).also { it.marginEnd = (8*dp).toInt() }
        chipRow.addView(switchChip)
        chipRow.addView(activity.pillButton("Trigger", ButtonTone.ORANGE, R.drawable.ic_flash) {
            pendingDialog?.dismiss()
            activity.buildFlowController.triggerWorkflowDispatch(token, owner, repo, branch)
        })
        titleRoot.addView(chipRow)

        // Breadcrumb strip
        val breadScroll = HorizontalScrollView(activity).apply {
            isHorizontalScrollBarEnabled = false
            setPadding((16 * dp).toInt(), 0, (16 * dp).toInt(), (12 * dp).toInt())
        }
        val breadRow = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL }

        fun crumb(label: String, targetPath: String?, isLast: Boolean) = TextView(activity).apply {
            text     = label
            textSize = 13f
            setTextColor(if (isLast)
                android.graphics.Color.parseColor("#9AA0B8")
            else
                android.graphics.Color.parseColor("#7C6BFF"))
            setPadding(0, (4 * dp).toInt(), 0, (4 * dp).toInt())
            if (!isLast && targetPath != null) setOnClickListener {
                pendingDialog?.dismiss()
                fetchAndBrowse(token, owner, repo, branch, targetPath)
            }
        }
        fun sep() = TextView(activity).apply {
            text = " / "; textSize = 13f
            setTextColor(android.graphics.Color.parseColor("#3A4060"))
        }

        breadRow.addView(crumb("root", "", segments.isEmpty()))
        segments.forEachIndexed { i, seg ->
            breadRow.addView(sep())
            breadRow.addView(crumb(seg, segments.take(i + 1).joinToString("/"), i == segments.lastIndex))
        }
        breadScroll.addView(breadRow)
        breadScroll.post { breadScroll.fullScroll(HorizontalScrollView.FOCUS_RIGHT) }
        titleRoot.addView(breadScroll)

        // Search/filter box — only useful with something to filter, so it's only
        // shown when the folder actually has entries. Its View is created and
        // placed here for the right visual position (right below the breadcrumb);
        // the actual filtering behavior is wired up further down, once
        // filteredItems/adapter exist.
        val etFileSearch = EditText(activity).apply {
            hint = "Filter files in this folder…"
            textSize = 12f; isSingleLine = true
            setTextColor(0xFFE8EAED.toInt())
            setHintTextColor(0xFF50587A.toInt())
            setBackgroundColor(0xFF161B22.toInt())
            setPadding((12*dp).toInt(), (7*dp).toInt(), (12*dp).toInt(), (7*dp).toInt())
        }
        if (items.isNotEmpty()) {
            titleRoot.addView(etFileSearch, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { it.leftMargin = (16*dp).toInt(); it.rightMargin = (16*dp).toInt(); it.bottomMargin = (10*dp).toInt() })
        }

        // Thin accent line at bottom of title
        titleRoot.addView(android.view.View(activity).apply {
            setBackgroundColor(android.graphics.Color.parseColor("#232747"))
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1)
        })

        // ── Build nav list ───────────────────────────────────────────────
        val navItems = mutableListOf<RepoItem>()
        if (path.isNotEmpty()) {
            val parentPath = if (path.contains("/")) path.substringBeforeLast("/") else ""
            navItems.add(RepoItem(type = "__up__", name = "..", path = parentPath, sha = ""))
        }
        navItems.addAll(items)

        // ── Custom ArrayAdapter using item_file.xml ──────────────────────
        // filteredItems (not navItems directly) is what getCount/getItem/getView
        // all read from — this is what the search box below filters via
        // notifyDataSetChanged(), without relying on ArrayAdapter's own built-in
        // filtering machinery (which filters by toString() and wouldn't line up
        // with this adapter's custom getView()).
        val filteredItems = navItems.toMutableList()
        val adapter = object : android.widget.ArrayAdapter<RepoItem>(
            activity, R.layout.item_file, navItems
        ) {
            override fun getCount() = filteredItems.size
            override fun getItem(pos: Int) = filteredItems[pos]
            override fun getView(pos: Int, convertView: android.view.View?, parent: android.view.ViewGroup): android.view.View {
                val row = convertView ?: activity.layoutInflater.inflate(R.layout.item_file, parent, false)
                row.setBackgroundColor(android.graphics.Color.parseColor("#13162A"))
                val item = filteredItems[pos]
                val ivIcon  = row.findViewById<android.widget.ImageView>(R.id.ivFileIcon)
                val tvName  = row.findViewById<TextView>(R.id.tvFileName)
                val tvType  = row.findViewById<TextView>(R.id.tvFileType)
                val ivChev  = row.findViewById<android.widget.ImageView>(R.id.ivChevron)

                when (item.type) {
                    "__up__" -> {
                        ivIcon.setImageResource(R.drawable.ic_folder)
                        ivIcon.imageTintList = android.content.res.ColorStateList.valueOf(
                            android.graphics.Color.parseColor("#9AA0B8"))
                        tvName.text = ".. (up one level)"
                        tvName.setTextColor(android.graphics.Color.parseColor("#9AA0B8"))
                        tvType.text = "parent folder"
                        ivChev.visibility = android.view.View.VISIBLE
                    }
                    "dir" -> {
                        ivIcon.setImageResource(R.drawable.ic_folder)
                        ivIcon.imageTintList = android.content.res.ColorStateList.valueOf(
                            android.graphics.Color.parseColor("#FF9F43"))
                        tvName.text = item.name
                        tvName.setTextColor(android.graphics.Color.parseColor("#E8EAED"))
                        tvType.text = "folder"
                        ivChev.visibility = android.view.View.VISIBLE
                    }
                    else -> {
                        ivIcon.setImageResource(R.drawable.ic_file)
                        ivIcon.imageTintList = android.content.res.ColorStateList.valueOf(fileTypeColor(item.name))
                        tvName.text = item.name
                        tvName.setTextColor(android.graphics.Color.parseColor("#E8EAED"))
                        val ext = item.name.substringAfterLast(".", "")
                        val extLabel = if (ext.isNotEmpty()) ext.uppercase() else "file"
                        tvType.text = if (item.size > 0) "$extLabel  ·  ${Formatters.fmtBytes(item.size)}" else extLabel
                        ivChev.visibility = android.view.View.GONE
                    }
                }
                return row
            }
        }

        etFileSearch.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                val query = (s?.toString() ?: "").trim()
                filteredItems.clear()
                filteredItems.addAll(
                    if (query.isEmpty()) navItems
                    // "up one level" stays visible under any filter — filtering
                    // out the only way to navigate back up would strand the user.
                    else navItems.filter { it.type == "__up__" || it.name.contains(query, ignoreCase = true) }
                )
                adapter.notifyDataSetChanged()
            }
        })

        // ── List + action buttons ────────────────────────────────────────
        // Built as one custom content view (BoundedListView + dialogWithActions row)
        // rather than the AlertDialog's own `.setAdapter()` + `.setPositiveButton()`
        // button bar — see dialogWithActions' doc for why: the platform button bar's
        // OEM-dependent sizing took three rounds to get even approximately right and
        // still looked oversized, while this exact pillButton look is already proven
        // fine elsewhere (Switch/Trigger chips above).
        val maxListHeight = (activity.resources.displayMetrics.heightPixels * 0.5f).toInt()
        val listView: android.widget.ListView? = if (navItems.isEmpty()) null else
            BoundedListView(activity, maxListHeight).apply {
                this.adapter = adapter
                setBackgroundColor(android.graphics.Color.parseColor("#13162A"))
                divider = android.graphics.drawable.ColorDrawable(android.graphics.Color.parseColor("#1C2038"))
                dividerHeight = 1

                // Builds the same action list for a given file either way (tap vs long-press
                // uses this identically) — kept as one function so the two listeners below can't
                // drift out of sync with each other.
                fun showFileActionMenu(item: RepoItem) {
                    val colorInfo = 0xFF4DA6FF.toInt()
                    val colorRed  = 0xFFFF6B6B.toInt()
                    val colorZip  = 0xFF2ECC71.toInt()
                    // Built as a list of (row, action) pairs rather than a fixed set of
                    // rows dispatched by hardcoded index — Extract ZIP only applies to
                    // .zip files, and inserting it conditionally into a fixed-index `when`
                    // would silently shift every action after it for non-zip files.
                    val menuEntries = mutableListOf<Pair<IconMenuRow, () -> Unit>>().apply {
                        add(IconMenuRow("View / Edit", R.drawable.ic_eye, colorInfo) to {
                            fileEditorController.fetchAndViewFile(token, owner, repo, branch, item, path)
                        })
                        add(IconMenuRow("Copy content", R.drawable.ic_copy, colorInfo) to {
                            fileEditorController.fetchAndCopyFile(token, owner, repo, item)
                        })
                        if (item.name.endsWith(".zip", ignoreCase = true)) {
                            add(IconMenuRow("Extract ZIP", R.drawable.ic_download, colorZip) to {
                                zipExtractController.promptExtract(token, owner, repo, branch, item, path)
                            })
                        }
                        add(IconMenuRow("Move / Rename", R.drawable.ic_edit, colorInfo) to {
                            fileOperationController.promptMoveFile(token, owner, repo, branch, item, path)
                        })
                        add(IconMenuRow("Delete", R.drawable.ic_delete, colorRed, labelColor = colorRed) to {
                            fileOperationController.promptDeleteFile(token, owner, repo, branch, item, path)
                        })
                    }
                    // No Cancel button here — this is a plain tap-to-pick list,
                    // and dialogs already dismiss on outside-tap/back by default.
                    AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
                        .setTitle(item.name)
                        .setAdapter(IconMenuAdapter(activity, menuEntries.map { it.first })) { _, action ->
                            menuEntries[action].second()
                        }
                        .show()
                }

                setOnItemClickListener { _, _, which, _ ->
                    val item = filteredItems[which]
                    when {
                        item.type == "__up__" || item.type == "dir" -> {
                            pendingDialog?.dismiss()
                            fetchAndBrowse(token, owner, repo, branch, item.path)
                        }
                        // A single tap opens the file directly instead of an intermediate
                        // action menu — View/Edit is by far the most common thing to do with
                        // a file while browsing, and forcing a menu tap every single time
                        // (including on every folder you pass through while just looking for
                        // something) added a step to the single most frequent interaction in
                        // this screen. The full menu (Copy/Extract/Move/Delete) is still one
                        // long-press away — see setOnItemLongClickListener below — not removed,
                        // just no longer the default for a plain tap.
                        else -> fileEditorController.fetchAndViewFile(token, owner, repo, branch, item, path)
                    }
                }
                setOnItemLongClickListener { _, _, which, _ ->
                    val item = filteredItems[which]
                    if (item.type == "__up__" || item.type == "dir") return@setOnItemLongClickListener false
                    showFileActionMenu(item)
                    true
                }
            }

        val bodyView: android.view.View = listView ?: activity.dialogMessage("(empty folder)")

        val actions = mutableListOf<DialogAction>()
        actions += DialogAction("New", ButtonTone.GREEN, R.drawable.ic_add) {
            pendingDialog?.dismiss(); fileOperationController.showNewItemDialog(token, owner, repo, branch, path)
        }
        if (items.isNotEmpty()) {
            actions += DialogAction("Delete", ButtonTone.RED, R.drawable.ic_delete) {
                pendingDialog?.dismiss(); fileOperationController.showDeleteDialog(token, owner, repo, branch, path, items)
            }
        } else if (path.isEmpty()) {
            actions += DialogAction("New Repo", ButtonTone.GREEN, R.drawable.ic_add) {
                pendingDialog?.dismiss(); promptCreateRepo(token)
            }
        }
        actions += DialogAction(
            if (path.isNotEmpty()) "Up" else "Close", ButtonTone.SURFACE,
            if (path.isNotEmpty()) R.drawable.ic_arrow_up else R.drawable.ic_close
        ) {
            pendingDialog?.dismiss()
            if (path.isNotEmpty()) {
                val parentPath = if (path.contains("/")) path.substringBeforeLast("/") else ""
                fetchAndBrowse(token, owner, repo, branch, parentPath)
            }
        }

        val browserContent = activity.dialogWithActions(bodyView, *actions.toTypedArray())
        pendingDialog = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
            .setCustomTitle(titleRoot)
            .setView(browserContent)
            .show()
        browserDialogShowing = true
        pendingDialog?.setOnDismissListener { browserDialogShowing = false }
    }

    /**
     * Shows a dialog to create a brand-new GitHub repo without starting a build.
     * Resolves the owner from the token first (cached in [activity.lastOwner]).
     */
    private fun promptCreateRepo(token: String) {
        val input = EditText(activity).apply {
            hint = "my-new-repo"
            inputType = android.text.InputType.TYPE_CLASS_TEXT
            setPadding(64, 24, 64, 24)
        }
        lateinit var dlg: AlertDialog
        val body = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            addView(activity.dialogMessage("Enter a name for the new GitHub repo.\n⚠ Spaces will be replaced with hyphens."))
            addView(input)
        }
        val content = activity.dialogWithActions(
            body,
            DialogAction("Create", ButtonTone.GREEN, R.drawable.ic_add) {
                // Sanitize: trim, replace spaces/invalid chars with hyphens, collapse runs
                val rawName = input.text.toString().trim()
                val repoName = rawName
                    .replace(Regex("[^A-Za-z0-9._-]"), "-")  // only letters/digits/./−/_ allowed
                    .replace(Regex("-{2,}"), "-")             // collapse consecutive hyphens
                    .trim('-')                                 // strip leading/trailing hyphens
                when {
                    rawName.isEmpty() -> activity.appendLog("⚠ Repo name cannot be empty.")
                    repoName.isEmpty() -> activity.appendLog("⚠ Repo name invalid after sanitisation.")
                    else -> {
                        if (repoName != rawName) activity.appendLog("ℹ Repo name adjusted to: $repoName")
                        dlg.dismiss()
                        activity.setBusy(true)
                        activity.appendLog("Creating repo: $repoName …")
                        activity.bgExecutor.execute {
                            try {
                                val owner = if (activity.lastOwner.isNotEmpty()) activity.lastOwner else {
                                    val o = activity.buildFlowController.fetchOwner(token) ?: throw Exception("Could not verify token.")
                                    activity.lastOwner = o
                                    activity.mainHandler.post { activity.tvOwnerInfo.text = "✓  @$o / $repoName"; activity.tvOwnerInfo.visibility = android.view.View.VISIBLE }
                                    o
                                }
                                val reqBody = JSONObject().apply {
                                    put("name",        repoName)
                                    put("private",     false)
                                    put("auto_init",   true)
                                    put("description", "Repo created via ZipApkBuilder")
                                }.toString()
                                val (code, resp) = GitHubApi.httpPost(token, GitHubApi.apiUserRepos(), reqBody)
                                if (code !in 200..201) {
                                    activity.appendLog("✗ Create repo failed ($code): ${resp.take(200)}")
                                    activity.setBusy(false); return@execute
                                }
                                activity.appendLog("✓ Repo created: github.com/$owner/$repoName")

                                // Auto-fill the repo field
                                activity.mainHandler.post {
                                    activity.etRepo.setText(repoName)
                                    activity.prefs.edit().putString(PrefKeys.PREF_REPO, repoName).apply()
                                }

                                // Poll until GitHub has initialised the repo (up to ~20 s) instead
                                // of blindly waiting a fixed delay and hoping — same reasoning and
                                // same shared primitive as BuildFlowController.ensureRepo's own
                                // post-creation readiness check.
                                val branch = activity.etBranch.text.toString().trim().ifEmpty { "main" }
                                activity.appendLog("Waiting for GitHub to initialise repo…")
                                var ready = false
                                BuildRetryManager().poll(timeoutMs = 20_000L, intervalMs = 2_000L) {
                                    val (chk, _) = GitHubApi.httpGet(token, GitHubApi.apiRepo(owner, repoName))
                                    ready = chk == 200
                                    ready
                                }
                                if (!ready) {
                                    activity.appendLog("⚠ Repo created but not yet reachable — open file manager manually.")
                                    activity.setBusy(false); return@execute
                                }
                                activity.appendLog("Repo ready ✓")
                                activity.mainHandler.post { fetchAndBrowse(token, owner, repoName, branch, "") }
                            } catch (e: Exception) {
                                activity.appendLog("✗ ${e.message}")
                                activity.setBusy(false)
                            }
                        }
                    }
                }
            },
            DialogAction("Cancel", ButtonTone.SURFACE, R.drawable.ic_close) { dlg.dismiss() }
        )
        dlg = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
            .setTitle("🆕 Create Repository")
            .setView(content)
            .show()
    }
}
