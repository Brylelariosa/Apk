package com.zipapkbuilder.core

/**
 * SharedPreferences key names, centralized here because several of them are
 * written by one feature and read by another (e.g. [PREF_ARTIFACT_NAME] is
 * written when a build finishes but also updated from the artifact browser,
 * then read back by the download manager) — keeping every feature's copy of
 * the same string literal in sync was a real source of risk in the old
 * single-class layout.
 */
object PrefKeys {
    const val PREF_TOKEN            = "token"
    const val PREF_REPO             = "repo"
    const val PREF_BRANCH           = "branch"
    const val PREF_ARTIFACT_URL     = "artifact_url"
    const val PREF_ARTIFACT_NAME    = "artifact_name"
    const val PREF_LAST_RUN_ID      = "last_run_id"
    const val PREF_LAST_OWNER       = "last_owner"
    const val PREF_LAST_REPO_KEY    = "last_repo_saved"
    const val PREF_KEYSTORE_ALIAS   = "keystore_alias"
    const val PREF_KEYSTORE_SAVED   = "keystore_saved"
    const val PREF_SAVED_REPOS      = "saved_repos"
    const val PREF_ZIP_NAME         = "zip_name"
    const val PREF_DOWNLOAD_URI     = "download_uri"
    const val PREF_DOWNLOAD_HISTORY = "download_history"
    const val PREF_BUILD_HISTORY    = "build_history"

    /** Persisted snapshot of every non-completed [com.zipapkbuilder.model.DownloadTask] —
     *  see [com.zipapkbuilder.feature.download.DownloadPersistence]. Written on every
     *  meaningful state change so an active/paused/queued/failed download survives a
     *  process kill, app restart, or swipe from Recent Apps. */
    const val PREF_DOWNLOAD_QUEUE   = "download_queue_v1"

    /** `"true"`/`"false"` (via `getBoolean`/`putBoolean`) — whether the build ZIP
     *  uploads to the repo root instead of the default uploads folder. Off
     *  by default so every existing repo's already-committed workflow (which
     *  only watches the uploads folder) keeps working without the user needing
     *  to do anything; see [com.zipapkbuilder.feature.build.BuildFlowController.runFlow]. */
    const val PREF_UPLOAD_TO_ROOT   = "upload_to_root"
}
