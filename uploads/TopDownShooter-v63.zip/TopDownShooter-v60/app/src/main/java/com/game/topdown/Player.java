package com.game.topdown;

public class Player {
    public int    id;
    public String name   = "";
    public float  x, y, angle;
    public float  hp     = 100;
    public int    gunIndex;
    public boolean alive = true;
    public Gun[]  guns;
    public Gun currentGun() { return guns[gunIndex]; }

    // Economy & unlock state  (17 guns: indices 0-16)
    public int       coins        = 0;
    public boolean[] unlockedGuns = {true,false,false,false,false,false,false,false,
                                     false,false,false,false,false,false,false,false,false,false};

    // Bombs
    public int bombs = 2;

    // ── Spawn protection (3 s) ────────────────────────────────────────────────
    public volatile long spawnProtectionUntil = 0;
    public boolean isProtected() { return System.currentTimeMillis() < spawnProtectionUntil; }

    // ── Status effects ────────────────────────────────────────────────────────
    /** Timestamp until which the player is slowed (Paint Launcher blue). */
    public volatile long slowUntil      = 0;
    /** Timestamp until which the player takes poison damage (Paint Launcher green). */
    public volatile long poisonUntil    = 0;
    /** ID of the player who applied the poison (for kill-credit and coins). */
    public volatile int  poisonOwnerId  = -1;
    /** Last time poison dealt a damage tick. */
    public volatile long poisonLastTick = 0;

    public boolean isSlowed()   { return System.currentTimeMillis() < slowUntil; }
    public boolean isPoisoned() { return System.currentTimeMillis() < poisonUntil; }

    // ── Hook Spear status effects ─────────────────────────────────────────────
    /** Timestamp until which the player cannot move or fire (stunned). */
    public volatile long  stunUntil      = 0;
    /** Timestamp until which the player is being pulled toward hookPullFromX/Y. */
    public volatile long  hookPullUntil  = 0;
    /** World-space position the player is being yanked toward. */
    public float          hookPullFromX, hookPullFromY;

    public boolean isStunned()     { return System.currentTimeMillis() < stunUntil; }
    public boolean isBeingPulled() { return System.currentTimeMillis() < hookPullUntil; }

    // ── Passive skills (0-3 levels each) ──────────────────────────────────────
    public int skillReload    = 0;   // -20 % reload time per level
    public int skillFireRate  = 0;   // +20 % fire rate per level
    public int skillRange     = 0;   // +25 % bullet range per level
    public int skillMoveSpeed = 0;   // +12 % move speed per level

    public float reloadMult()    { return 1f / (1f + 0.20f * skillReload);   }
    public float fireRateMult()  { return 1f + 0.20f * skillFireRate;         }
    public float rangeMult()     { return 1f + 0.25f * skillRange;            }
    public float moveSpeedMult() { return 1f + 0.12f * skillMoveSpeed;        }

    // ── Active skill (one equipped, one press to use) ─────────────────────────
    public static final int ACTIVE_NONE = 0, ACTIVE_DASH = 1,
                             ACTIVE_STEALTH = 2, ACTIVE_HEAL = 3, ACTIVE_SHIELD = 4;
    public int   activeSkillType  = ACTIVE_NONE;
    public volatile long  skillCooldownEnd = 0;
    public volatile long  skillActiveUntil = 0;
    public float shieldHp         = 0;

    public boolean skillOnCooldown() { return System.currentTimeMillis() < skillCooldownEnd; }
    public boolean skillIsActive()   { return System.currentTimeMillis() < skillActiveUntil; }
    public boolean isStealthed()     { return activeSkillType == ACTIVE_STEALTH && skillIsActive(); }
    public boolean isShielded()      { return activeSkillType == ACTIVE_SHIELD  && shieldHp > 0 && skillIsActive(); }
}
