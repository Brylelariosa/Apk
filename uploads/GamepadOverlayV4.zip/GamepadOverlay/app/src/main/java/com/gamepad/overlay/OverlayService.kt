package com.gamepad.overlay

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.os.*
import android.util.DisplayMetrics
import android.view.*
import android.widget.TextView
import androidx.core.app.NotificationCompat
import kotlin.math.abs
import kotlin.math.sqrt

class OverlayService : Service() {

    companion object {
        private const val CHANNEL_ID = "gamepad_overlay_channel"
        private const val NOTIF_ID = 42
    }

    private lateinit var wm: WindowManager
    private val uiHandler = Handler(Looper.getMainLooper())

    private var screenW = 0f
    private var screenH = 0f

    /**
     * Every control is its own tiny WindowManager window sized to just that view.
     * FLAG_NOT_TOUCH_MODAL means any touch that doesn't land on a control window
     * passes straight through to whatever game is running underneath.
     */
    private data class WinEntry(
        val view: View,
        val params: WindowManager.LayoutParams,
        var xPct: Float,
        var yPct: Float,
        val wPx: Int,
        val hPx: Int,
        val alwaysVisible: Boolean = false
    )

    private val windows = mutableListOf<WinEntry>()
    private var controlsVisible = true

    // Joystick state — base is fixed; only the thumb inside JoystickView moves
    @Volatile private var joystickActive = false
    private var joystickThread: Thread? = null
    @Volatile private var joyNx = 0f
    @Volatile private var joyNy = 0f

    private lateinit var displayManager: DisplayManager
    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayChanged(displayId: Int) { uiHandler.post { onRotation() } }
        override fun onDisplayAdded(displayId: Int) {}
        override fun onDisplayRemoved(displayId: Int) {}
    }

    override fun onBind(intent: Intent?) = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        displayManager = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        displayManager.registerDisplayListener(displayListener, uiHandler)
        resolveScreen()
        createChannel()
        startForeground(NOTIF_ID, buildNotif())
        spawnControls()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "ACTION_STOP") stopSelf()
        return START_STICKY
    }

    override fun onDestroy() {
        joystickActive = false
        joystickThread?.interrupt()
        displayManager.unregisterDisplayListener(displayListener)
        windows.forEach { runCatching { wm.removeView(it.view) } }
        windows.clear()
        super.onDestroy()
    }

    // ── Screen / rotation ─────────────────────────────────────────────────────

    private fun resolveScreen() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val b = wm.currentWindowMetrics.bounds
            screenW = b.width().toFloat(); screenH = b.height().toFloat()
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
            screenW = dm.widthPixels.toFloat(); screenH = dm.heightPixels.toFloat()
        }
    }

    private fun onRotation() {
        resolveScreen()
        windows.forEach { e ->
            e.params.x = (e.xPct * screenW).toInt()
                .coerceIn(0, (screenW - e.wPx).toInt().coerceAtLeast(0))
            e.params.y = (e.yPct * screenH).toInt()
                .coerceIn(0, (screenH - e.hPx).toInt().coerceAtLeast(0))
            runCatching { wm.updateViewLayout(e.view, e.params) }
        }
    }

    // ── Notification ──────────────────────────────────────────────────────────

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "Gamepad Overlay",
                NotificationManager.IMPORTANCE_LOW).apply { setShowBadge(false) }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(ch)
        }
    }

    private fun buildNotif(): Notification {
        val openPi = PendingIntent.getActivity(this, 0,
            Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stopPi = PendingIntent.getService(this, 1,
            Intent(this, OverlayService::class.java).apply { action = "ACTION_STOP" },
            PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Gamepad Overlay Active")
            .setContentText("Running • long-press any button to reposition it")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(openPi)
            .addAction(android.R.drawable.ic_delete, "Stop", stopPi)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true).build()
    }

    // ── Spawn all controls ────────────────────────────────────────────────────

    private fun spawnControls() {
        val dp = resources.displayMetrics.density
        fun px(v: Float) = (v * dp).toInt()

        // ── Joystick — fixed, not draggable; only the thumb moves ──────────
        val joyPx = px(160f)
        val joyView = JoystickView(this).apply {
            onMoveListener = { nx, ny ->
                joyNx = nx; joyNy = ny
                val moving = abs(nx) > 0.12f || abs(ny) > 0.12f
                if (!joystickActive && moving) { joystickActive = true; startJoystickLoop() }
                else if (!moving) joystickActive = false
            }
            onReleaseListener = { joystickActive = false }
        }
        addWin(joyView, joyPx, joyPx,
            xPct = px(16f) / screenW,
            yPct = (screenH - joyPx - px(60f)) / screenH,
            draggable = false)

        // ── D-Pad — 4 individual windows, each draggable ───────────────────
        val dSz = px(46f)
        val dGap = px(50f)
        val dcx = px(290f).toInt()
        val dcy = (screenH - px(185f)).toInt()

        fun dBtn(label: String, dx: Int, dy: Int, swDx: Float, swDy: Float) =
            addWin(
                makeBtn(label, Color.argb(200, 70, 70, 100)) {
                    vibrate(18); swipe(screenW * .5f, screenH * .5f, swDx, swDy, 140)
                },
                dSz, dSz,
                (dcx + dx - dSz / 2f) / screenW,
                (dcy + dy - dSz / 2f) / screenH,
                draggable = true
            )

        dBtn("▲",    0, -dGap,  0f,            -px(130f).toFloat())
        dBtn("▼",    0, +dGap,  0f,            +px(130f).toFloat())
        dBtn("◄", -dGap,    0, -px(130f).toFloat(),  0f)
        dBtn("►", +dGap,    0, +px(130f).toFloat(),  0f)

        // ── ABXY — 4 individual windows, each draggable ────────────────────
        val aSz = px(54f)
        val aGap = px(56f)
        val acx = (screenW - px(90f)).toInt()
        val acy = (screenH - px(130f)).toInt()

        fun aBtn(label: String, color: Int, dx: Int, dy: Int, txPct: Float, tyPct: Float) =
            addWin(
                makeBtn(label, color) { vibrate(40); tap(txPct, tyPct) },
                aSz, aSz,
                (acx + dx - aSz / 2f) / screenW,
                (acy + dy - aSz / 2f) / screenH,
                draggable = true
            )

        aBtn("A", Color.argb(220,   0, 160,  70),    0,   +aGap, 0.78f, 0.82f)
        aBtn("B", Color.argb(220, 210,  40,  40), +aGap,     0,  0.88f, 0.72f)
        aBtn("X", Color.argb(220,  20, 100, 210), -aGap,     0,  0.68f, 0.72f)
        aBtn("Y", Color.argb(220, 200, 160,   0),    0,   -aGap, 0.78f, 0.62f)

        // ── Shoulder buttons ───────────────────────────────────────────────
        val bW = px(72f); val bH = px(36f)
        addWin(makeBtn("LB", Color.argb(200, 60, 60, 160)) { vibrate(25); tap(0.15f, 0.08f) },
            bW, bH, px(16f) / screenW, px(24f) / screenH, true)
        addWin(makeBtn("RB", Color.argb(200, 60, 60, 160)) { vibrate(25); tap(0.85f, 0.08f) },
            bW, bH, (screenW - bW - px(16f)) / screenW, px(24f) / screenH, true)

        val ltW = px(60f); val ltH = px(30f)
        addWin(makeBtn("LT", Color.argb(180, 40, 40, 130)) { vibrate(35); tap(0.08f, 0.04f) },
            ltW, ltH, px(94f) / screenW, px(10f) / screenH, true)
        addWin(makeBtn("RT", Color.argb(180, 40, 40, 130)) { vibrate(35); tap(0.92f, 0.04f) },
            ltW, ltH, (screenW - ltW - px(94f)) / screenW, px(10f) / screenH, true)

        // ── Start / Select ─────────────────────────────────────────────────
        val sW = px(44f); val sH = px(28f)
        addWin(makeBtn("▶", Color.argb(160, 50, 50, 100)) { vibrate(20); tap(0.60f, 0.08f) },
            sW, sH, (screenW / 2f + px(10f)) / screenW, px(20f) / screenH, true)
        addWin(makeBtn("☰", Color.argb(160, 50, 50, 100)) { vibrate(20); tap(0.40f, 0.08f) },
            sW, sH, (screenW / 2f - sW - px(10f)) / screenW, px(20f) / screenH, true)

        // ── Visibility toggle — always visible, draggable ──────────────────
        val tSz = px(46f)
        val togView = makeBtn("👁", Color.argb(200, 30, 30, 70)) {
            controlsVisible = !controlsVisible
            windows.forEach { e ->
                if (!e.alwaysVisible)
                    e.view.visibility = if (controlsVisible) View.VISIBLE else View.INVISIBLE
            }
        }
        addWin(togView, tSz, tSz,
            (screenW - tSz - px(16f)) / screenW,
            px(70f) / screenH,
            draggable = true,
            alwaysVisible = true)
    }

    // ── Window factory ────────────────────────────────────────────────────────

    private fun addWin(
        view: View,
        wPx: Int,
        hPx: Int,
        xPct: Float,
        yPct: Float,
        draggable: Boolean,
        alwaysVisible: Boolean = false
    ): WinEntry {
        val params = WindowManager.LayoutParams(
            wPx, hPx,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            // NOT_FOCUSABLE  : overlay never steals keyboard/back from the game
            // NOT_TOUCH_MODAL: touches outside this window's bounds hit the game directly
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (xPct * screenW).toInt()
            y = (yPct * screenH).toInt()
        }
        val entry = WinEntry(view, params, xPct, yPct, wPx, hPx, alwaysVisible)
        if (draggable) attachDrag(view, entry)
        windows.add(entry)
        wm.addView(view, params)
        return entry
    }

    /**
     * Long-press a button → it dims → drag to new position → release.
     *
     * Touch event contract:
     *   ACTION_DOWN  → save raw coords, return false so view's long-press timer arms
     *   (500ms)      → onLongClickListener fires → dragging = true
     *   ACTION_MOVE  → if dragging: move window, return true (consumed)
     *   ACTION_UP    → if dragging: save pct, reset; return true (suppress click)
     *                  if not dragging: return false → normal click fires
     */
    private fun attachDrag(view: View, entry: WinEntry) {
        var dragging = false
        var downRawX = 0f
        var downRawY = 0f
        var startX = 0
        var startY = 0

        view.isLongClickable = true
        view.setOnLongClickListener {
            dragging = true
            startX = entry.params.x
            startY = entry.params.y
            vibrate(80)
            view.alpha = 0.55f
            true
        }

        view.setOnTouchListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = ev.rawX
                    downRawY = ev.rawY
                    false  // let onTouchEvent arm the long-press detector
                }
                MotionEvent.ACTION_MOVE -> {
                    if (dragging) {
                        val nx = (startX + ev.rawX - downRawX).toInt()
                            .coerceIn(0, (screenW - entry.wPx).toInt().coerceAtLeast(0))
                        val ny = (startY + ev.rawY - downRawY).toInt()
                            .coerceIn(0, (screenH - entry.hPx).toInt().coerceAtLeast(0))
                        entry.params.x = nx
                        entry.params.y = ny
                        runCatching { wm.updateViewLayout(v, entry.params) }
                        true
                    } else false
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (dragging) {
                        dragging = false
                        view.alpha = 1f
                        entry.xPct = entry.params.x / screenW
                        entry.yPct = entry.params.y / screenH
                        true  // suppress click after drag
                    } else false
                }
                else -> false
            }
        }
    }

    // ── Button factory ────────────────────────────────────────────────────────

    private fun makeBtn(label: String, bgColor: Int, onClick: () -> Unit): TextView =
        TextView(this).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = if (label.length <= 1) 15f else 11f
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(bgColor)
                setStroke(3, Color.argb(140, 200, 200, 255))
            }
            isFocusable = false
            isClickable = true
            setOnClickListener { onClick() }
        }

    // ── Joystick swipe loop ───────────────────────────────────────────────────

    private fun startJoystickLoop() {
        joystickThread?.interrupt()
        joystickThread = Thread {
            while (joystickActive && !Thread.currentThread().isInterrupted) {
                val nx = joyNx; val ny = joyNy
                val mag = sqrt(nx * nx + ny * ny)
                if (mag > 0.15f) {
                    val dist = (mag * 160f).coerceIn(30f, 200f)
                    swipe(screenW * 0.5f, screenH * 0.55f, nx * dist, ny * dist, 90)
                }
                try { Thread.sleep(110) } catch (_: InterruptedException) { break }
            }
        }.also { it.isDaemon = true; it.start() }
    }

    // ── Input helpers ─────────────────────────────────────────────────────────

    private fun tap(xPct: Float, yPct: Float) {
        InputService.instance?.performTap(screenW * xPct, screenH * yPct)
    }

    private fun swipe(sx: Float, sy: Float, dx: Float, dy: Float, dur: Long) {
        InputService.instance?.performSwipe(sx, sy, dx, dy, dur)
    }

    // ── Haptics ───────────────────────────────────────────────────────────────

    private fun vibrate(ms: Long) {
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager)
                    .defaultVibrator
                    .vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                    v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
                else @Suppress("DEPRECATION") v.vibrate(ms)
            }
        }
    }
}
