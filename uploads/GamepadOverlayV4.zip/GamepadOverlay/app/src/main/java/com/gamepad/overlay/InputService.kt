package com.gamepad.overlay

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

/**
 * Accessibility service that receives commands from OverlayService and
 * dispatches real touch gestures to whatever app is in the foreground.
 */
class InputService : AccessibilityService() {

    companion object {
        // Singleton reference — set on connect, cleared on destroy
        @Volatile
        var instance: InputService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }

    /** Dispatch a short tap at (x, y) in screen coordinates. */
    fun performTap(x: Float, y: Float, duration: Long = 60L) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, duration)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }

    /**
     * Dispatch a swipe starting at (startX, startY) and ending at
     * (startX + dx, startY + dy) over [duration] milliseconds.
     */
    fun performSwipe(startX: Float, startY: Float, dx: Float, dy: Float, duration: Long) {
        val path = Path().apply {
            moveTo(startX, startY)
            lineTo(startX + dx, startY + dy)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0L, duration.coerceAtLeast(50L))
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }

    /**
     * Simulate a press-and-hold at (x, y).
     */
    fun performLongPress(x: Float, y: Float, duration: Long = 600L) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, duration)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* not needed */ }
    override fun onInterrupt() { /* not needed */ }
}
