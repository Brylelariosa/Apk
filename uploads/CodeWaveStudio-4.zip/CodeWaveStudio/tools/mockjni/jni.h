// Minimal stand-in for <jni.h>: just enough to compile and RUN jni_bridge.cpp on a desktop (test harness only).
#pragma once
#include <cstdint>
#include <cstring>
#include <string>
#include <vector>
typedef int32_t jint; typedef int64_t jlong; typedef float jfloat; typedef unsigned char jboolean; typedef jint jsize;
typedef int16_t jshort; typedef signed char jbyte;
#define JNI_TRUE 1
#define JNI_FALSE 0
#define JNI_ABORT 2
#define JNIEXPORT
#define JNICALL
struct _jobject { virtual ~_jobject() {} };
typedef _jobject* jobject; typedef jobject jclass; typedef jobject jstring; typedef jobject jarray;
typedef jobject jfloatArray; typedef jobject jshortArray; typedef struct _jmethodID* jmethodID;
struct MockString : _jobject { std::string s; explicit MockString(std::string v) : s(std::move(v)) {} };
struct MockFloatArray : _jobject { std::vector<float> v; };
struct MockShortArray : _jobject { std::vector<int16_t> v; };
struct JNIEnv_ {
  jclass FindClass(const char*) { return nullptr; }
  jmethodID GetMethodID(jclass, const char*, const char*) { return nullptr; }
  void DeleteLocalRef(jobject) {}
  bool ExceptionCheck() { return false; }
  void ExceptionClear() {}
  void CallVoidMethod(jobject, jmethodID, ...) {}
  jstring NewStringUTF(const char* s) { return new MockString(s); }
  jsize GetStringUTFLength(jstring s) { return (jsize) static_cast<MockString*>(s)->s.size(); }
  const char* GetStringUTFChars(jstring s, jboolean*) { return static_cast<MockString*>(s)->s.c_str(); }
  void ReleaseStringUTFChars(jstring, const char*) {}
  jsize GetArrayLength(jarray a) {
    if (auto* f = dynamic_cast<MockFloatArray*>(a)) return (jsize)f->v.size();
    if (auto* h = dynamic_cast<MockShortArray*>(a)) return (jsize)h->v.size();
    return 0;
  }
  void* GetPrimitiveArrayCritical(jarray a, jboolean*) {
    if (auto* f = dynamic_cast<MockFloatArray*>(a)) return f->v.data();
    if (auto* h = dynamic_cast<MockShortArray*>(a)) return h->v.data();
    return nullptr;
  }
  void ReleasePrimitiveArrayCritical(jarray, void*, jint) {}
  jfloat* GetFloatArrayElements(jfloatArray a, jboolean*) { return static_cast<MockFloatArray*>(a)->v.data(); }
  void ReleaseFloatArrayElements(jfloatArray, jfloat*, jint) {}
};
typedef JNIEnv_ JNIEnv;
