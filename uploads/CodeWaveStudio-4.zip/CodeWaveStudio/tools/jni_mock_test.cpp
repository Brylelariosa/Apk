// Runs the real JNI entry points (jni_bridge.cpp) on a desktop against a tiny fake JNIEnv (tools/mockjni/jni.h):
// import audio in pieces -> analyse it to a script file -> generate the sound from that file -> read it back.
// This is how the "whole song" path (audio kept in native memory, script kept in a file) is tested without a phone.
//
//   tools/jni_mock_test.sh [song.wav] [detail]
#include <jni.h>

#include <fcntl.h>
#include <unistd.h>

#include <atomic>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <thread>

extern "C" {
jlong Java_com_codewave_studio_engine_NativeBridge_create(JNIEnv*, jclass);
void Java_com_codewave_studio_engine_NativeBridge_destroy(JNIEnv*, jclass, jlong);
jint Java_com_codewave_studio_engine_NativeBridge_generateFromFile(JNIEnv*, jclass, jlong, jstring, jint, jint, jfloat, jobject);
jstring Java_com_codewave_studio_engine_NativeBridge_lastError(JNIEnv*, jclass, jlong);
jint Java_com_codewave_studio_engine_NativeBridge_frameCount(JNIEnv*, jclass, jlong);
jint Java_com_codewave_studio_engine_NativeBridge_channelCount(JNIEnv*, jclass, jlong);
jint Java_com_codewave_studio_engine_NativeBridge_sampleRate(JNIEnv*, jclass, jlong);
jint Java_com_codewave_studio_engine_NativeBridge_copyPcm16(JNIEnv*, jclass, jlong, jshortArray, jint, jint);
jboolean Java_com_codewave_studio_engine_NativeBridge_peaks(JNIEnv*, jclass, jlong, jint, jfloatArray);
jint Java_com_codewave_studio_engine_NativeBridge_writeWav(JNIEnv*, jclass, jlong, jint, jint);
jboolean Java_com_codewave_studio_engine_NativeBridge_importBegin(JNIEnv*, jclass, jint, jint);
jint Java_com_codewave_studio_engine_NativeBridge_importAppend(JNIEnv*, jclass, jfloatArray, jint);
void Java_com_codewave_studio_engine_NativeBridge_importDiscard(JNIEnv*, jclass);
void Java_com_codewave_studio_engine_NativeBridge_importCancel(JNIEnv*, jclass);
jstring Java_com_codewave_studio_engine_NativeBridge_analyzeImported(JNIEnv*, jclass, jstring, jint, jstring, jfloat, jobject);
}

#define NB(name) Java_com_codewave_studio_engine_NativeBridge_##name

static int g_fail = 0;
#define CHECK(cond, msg)                                         \
  do {                                                           \
    if (!(cond)) {                                               \
      std::printf("FAIL: %s\n", msg);                            \
      ++g_fail;                                                  \
    } else {                                                     \
      std::printf("ok:   %s\n", msg);                            \
    }                                                            \
  } while (0)

static bool readWav(const char* path, std::vector<float>& mono, int& sr) {
  std::ifstream in(path, std::ios::binary);
  if (!in) return false;
  std::stringstream ss;
  ss << in.rdbuf();
  const std::string d = ss.str();
  if (d.size() < 44 || d.compare(0, 4, "RIFF") != 0) return false;
  int ch = 1, bits = 16;
  size_t pos = 12;
  const char* data = nullptr;
  size_t dataLen = 0;
  while (pos + 8 <= d.size()) {
    const uint32_t len = *(const uint32_t*)&d[pos + 4];
    if (d.compare(pos, 4, "fmt ") == 0) {
      ch = *(const uint16_t*)&d[pos + 10];
      sr = (int)*(const uint32_t*)&d[pos + 12];
      bits = *(const uint16_t*)&d[pos + 22];
    } else if (d.compare(pos, 4, "data") == 0) {
      data = &d[pos + 8];
      dataLen = std::min<size_t>(len, d.size() - pos - 8);
      break;
    }
    pos += 8 + len + (len & 1);
  }
  if (!data || bits != 16) return false;
  const size_t frames = dataLen / (2u * (size_t)ch);
  mono.resize(frames);
  for (size_t i = 0; i < frames; ++i) {
    float s = 0;
    for (int c = 0; c < ch; ++c) s += (float)((const int16_t*)data)[i * (size_t)ch + (size_t)c] / 32768.0f;
    mono[i] = s / (float)ch;
  }
  return true;
}

static std::string str(jstring s) { return s ? static_cast<MockString*>(s)->s : std::string(); }

int main(int argc, char** argv) {
  const char* wavPath = argc > 1 ? argv[1] : "song.wav";
  const int detail = argc > 2 ? std::atoi(argv[2]) : 1;
  std::vector<float> mono;
  int sr = 0;
  if (!readWav(wavPath, mono, sr)) {
    std::printf("cannot read %s\n", wavPath);
    return 2;
  }
  JNIEnv_ envObj;
  JNIEnv* env = &envObj;
  const std::string out = "/tmp/jni_mock_script.cws";
  std::remove(out.c_str());

  // ---- 1. import in pieces like the decoder does, analyse into a file
  CHECK(NB(importBegin)(env, nullptr, sr, (jint)mono.size()) == JNI_TRUE, "importBegin");
  jint held = 0;
  for (size_t i = 0; i < mono.size(); i += 16384) {
    MockFloatArray piece;
    const size_t n = std::min<size_t>(16384, mono.size() - i);
    piece.v.assign(mono.begin() + (long)i, mono.begin() + (long)(i + n));
    held = NB(importAppend)(env, nullptr, &piece, (jint)n);
  }
  CHECK(held == (jint)mono.size(), "importAppend holds every sample");
  const auto t0 = std::chrono::steady_clock::now();
  MockString outPath(out), nm("jni test.wav");
  jstring reply = NB(analyzeImported)(env, nullptr, &outPath, detail, &nm, 0.0f, nullptr);
  const double secs = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
  const std::string r = str(reply);
  std::printf("analyzeImported -> %s  (%.1f s)\n", r.substr(0, 120).c_str(), secs);
  CHECK(r.compare(0, 3, "OK\n") == 0, "analysis reports OK");
  std::ifstream f(out, std::ios::binary | std::ios::ate);
  CHECK((bool)f && f.tellg() > 1000, "script file written");
  // the audio was taken over by the analysis: a second analysis has nothing to work on
  MockString out2("/tmp/jni_mock_script2.cws");
  const std::string again = str(NB(analyzeImported)(env, nullptr, &out2, detail, &nm, 0.0f, nullptr));
  CHECK(again.compare(0, 4, "ERR\n") == 0, "analysis without audio is an error, not a crash");

  // ---- 2. generate from the file
  const jlong h = NB(create)(env, nullptr);
  const jint st = NB(generateFromFile)(env, nullptr, h, &outPath, 44100, 2, 2.0f, nullptr);
  std::printf("generateFromFile -> %d %s\n", st, str(NB(lastError)(env, nullptr, h)).c_str());
  CHECK(st == 0, "generateFromFile ok");
  const jint frames = NB(frameCount)(env, nullptr, h);
  CHECK(NB(channelCount)(env, nullptr, h) == 2, "stereo output");
  CHECK(NB(sampleRate)(env, nullptr, h) == 44100, "sample rate");
  CHECK(std::fabs((double)frames / 44100.0 - (double)mono.size() / sr) < 1.5, "length matches the audio");
  MockShortArray pcm;
  pcm.v.assign(2 * 4096, 0);
  const jint got = NB(copyPcm16)(env, nullptr, h, &pcm, frames / 2, 4096);
  bool same = got == 4096, loud = false;
  for (int i = 0; i < got; ++i) {
    same = same && pcm.v[(size_t)(2 * i)] == pcm.v[(size_t)(2 * i + 1)];
    loud = loud || std::abs(pcm.v[(size_t)(2 * i)]) > 200;
  }
  CHECK(same, "dual-mono: left == right in the PCM copy");
  CHECK(loud, "the middle of the sound is not silent");
  MockFloatArray pk;
  pk.v.assign(2 * 300, 0.0f);
  CHECK(NB(peaks)(env, nullptr, h, 300, &pk) == JNI_TRUE, "peaks");
  float pmax = 0;
  for (float v : pk.v) pmax = std::max(pmax, std::fabs(v));
  CHECK(pmax > 0.2f, "waveform peaks are not flat");

  // the WAV exporter writes both channels of a dual-mono sound, 16-bit and 32-bit float
  for (int bits : {16, 32}) {
    const std::string wavOut = "/tmp/jni_mock_out.wav";
    const int fd = ::open(wavOut.c_str(), O_CREAT | O_TRUNC | O_WRONLY, 0644);
    const jint rc = NB(writeWav)(env, nullptr, h, fd, bits);
    ::close(fd);
    std::ifstream wf(wavOut, std::ios::binary | std::ios::ate);
    const long size = (long)wf.tellg();
    const long expect = 44 + (long)frames * 2 * (bits / 8);
    std::printf("      %d-bit wav: %ld bytes (expected about %ld)\n", bits, size, expect);
    CHECK(rc == 0 && size >= expect && size <= expect + 64, bits == 16 ? "writeWav 16-bit (stereo, dual mono)" : "writeWav 32-bit float");
  }

  // ---- 3. errors
  MockString missing("/tmp/does/not/exist.cws");
  CHECK(NB(generateFromFile)(env, nullptr, h, &missing, 44100, 2, 2.0f, nullptr) == 4, "missing script file -> status 4");
  std::printf("        message: %s\n", str(NB(lastError)(env, nullptr, h)).substr(0, 80).c_str());
  CHECK(NB(frameCount)(env, nullptr, h) == frames, "a failed generate keeps the previous sound");

  // ---- 4. cancel an analysis half way
  CHECK(NB(importBegin)(env, nullptr, sr, (jint)mono.size()) == JNI_TRUE, "importBegin (2nd)");
  for (size_t i = 0; i < mono.size(); i += 16384) {
    MockFloatArray piece;
    const size_t n = std::min<size_t>(16384, mono.size() - i);
    piece.v.assign(mono.begin() + (long)i, mono.begin() + (long)(i + n));
    NB(importAppend)(env, nullptr, &piece, (jint)n);
  }
  std::string cancelReply;
  std::thread worker([&]() { cancelReply = str(NB(analyzeImported)(env, nullptr, &out2, 2, &nm, 0.0f, nullptr)); });
  std::this_thread::sleep_for(std::chrono::milliseconds(400));
  NB(importCancel)(env, nullptr);
  const auto c0 = std::chrono::steady_clock::now();
  worker.join();
  const double stop = std::chrono::duration<double>(std::chrono::steady_clock::now() - c0).count();
  std::printf("cancelled analysis returned %s after %.2f s\n", cancelReply.substr(0, 20).c_str(), stop);
  CHECK(cancelReply == "CANCELLED" || cancelReply.compare(0, 3, "OK\n") == 0, "cancel ends the analysis (or it had just finished)");
  CHECK(stop < 5.0, "cancel is prompt");
  NB(importDiscard)(env, nullptr);
  NB(destroy)(env, nullptr, h);
  std::printf(g_fail ? "\n%d CHECK(S) FAILED\n" : "\nall checks passed\n", g_fail);
  return g_fail ? 1 : 0;
}
