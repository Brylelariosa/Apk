#!/bin/sh
# Builds and runs the JNI bridge test against the fake JNIEnv (no phone needed). Usage: tools/jni_mock_test.sh [song.wav] [detail]
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CPP="$ROOT/app/src/main/cpp"
OUT="${TMPDIR:-/tmp}/cw_jni_mock_test"
g++ -std=c++17 -O2 -Wall -Wextra -I"$CPP" -I"$ROOT/tools/mockjni" "$ROOT/tools/jni_mock_test.cpp" "$CPP/jni_bridge.cpp" \
  "$CPP"/analysis/*.cpp "$CPP"/dsp/*.cpp "$CPP"/parser/*.cpp "$CPP"/engine/*.cpp "$CPP"/audio/*.cpp "$CPP/crash/crash_handler.cpp" \
  -pthread -o "$OUT"
"$OUT" "$@"
