package com.codewave.studio.engine

/**
 * The complete JNI surface. Method names and signatures must match jni_bridge.cpp and are
 * protected from R8 in proguard-rules.pro. Scripts never reach anything except these calls.
 */
object NativeBridge {
    /** False when libcodewave.so could not be loaded (the UI then reports it instead of crashing). */
    @JvmField
    val available: Boolean = try {
        System.loadLibrary("codewave")
        true
    } catch (t: Throwable) {
        false
    }

    /** Installs the native (C++) crash reporter; reports are written to [path]. */
    external fun installCrashHandler(path: String)

    external fun create(): Long
    external fun destroy(handle: Long)
    external fun cancel(handle: Long)

    /** 0 ok, 1 script error, 2 out of memory, 3 cancelled, 4 internal error. */
    external fun generate(
        handle: Long,
        script: String,
        sampleRate: Int,
        channels: Int,
        defaultDuration: Float,
        listener: ProgressListener?
    ): Int

    external fun lastError(handle: Long): String
    external fun lastErrorLine(handle: Long): Int
    external fun lastWarnings(handle: Long): String
    external fun renderMillis(handle: Long): Int

    external fun frameCount(handle: Long): Int
    external fun channelCount(handle: Long): Int
    external fun sampleRate(handle: Long): Int

    external fun copyPcm16(handle: Long, dst: ShortArray, startFrame: Int, frames: Int): Int
    external fun peaks(handle: Long, columns: Int, out: FloatArray): Boolean

    /** Writes a WAV to an open file descriptor. 0 = success, otherwise an errno value. */
    external fun writeWav(handle: Long, fd: Int, bits: Int): Int

    /**
     * The same as [generate], for a script stored in a file (UTF-8): the code of a whole song is megabytes of text,
     * which is kept out of the Java heap and the editor.
     */
    external fun generateFromFile(
        handle: Long,
        path: String,
        sampleRate: Int,
        channels: Int,
        defaultDuration: Float,
        listener: ProgressListener?
    ): Int

    // ---- audio -> code. A decoded song is held as 16-bit samples in native memory (10 minutes at 44.1 kHz are
    // 53 MB; a float array on the Java heap would be twice that and could run the app out of memory).

    /** Starts a new import: drops the previous one and clears a pending cancel. False if it could not start. */
    external fun importBegin(sampleRate: Int, expectedFrames: Int): Boolean

    /** Adds [count] mono float samples (-1..1). Returns the number of samples held so far, or -1 on failure. */
    external fun importAppend(pcm: FloatArray, count: Int): Int

    /** Frees the imported audio (an import that is abandoned) and stops a running analysis. */
    external fun importDiscard()

    /** Stops a running [analyzeImported] at its next check. */
    external fun importCancel()

    /**
     * Analyses the imported audio and writes the CodeWave script to [outPath] ([detail]: 0 simple, 1 normal,
     * 2 detailed). Returns "OK\n<summary>\n<script bytes>\n", "CANCELLED" or "ERR\n<message>". [listener] receives
     * the progress (0..1). Pure computation: needs no engine instance, call it from a worker thread.
     */
    external fun analyzeImported(
        outPath: String,
        detail: Int,
        name: String,
        startSeconds: Float,
        listener: ProgressListener?
    ): String
}
