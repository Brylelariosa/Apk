package com.codewave.studio.importer

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.os.Build
import java.nio.ByteOrder

/**
 * Decodes the first audio track of any file this device can play (mp3, m4a / aac, wav, ogg, flac,
 * even the sound of an mp4 video) to mono float PCM. Android framework only (MediaExtractor +
 * MediaCodec): no library, no permission - the file arrives through the system file picker.
 *
 * The samples are handed over piece by piece ([PcmSink]) instead of being collected in one array: a whole song
 * would be 106 MB of floats (10 minutes at 44.1 kHz), which the Java heap cannot be counted on to hold.
 */
object AudioDecoder {

    /** Receives the decoded mono samples. Called on the decoding thread. */
    interface PcmSink {
        /**
         * Called once, before the first samples. [sampleRate] is the rate of the samples that follow (a 96 kHz file
         * is delivered at 48 kHz); [expectedFrames] is how many samples are about to come (an estimate).
         * Return false when the sink cannot take them (for example, no memory).
         */
        fun begin(sampleRate: Int, expectedFrames: Int): Boolean

        /** [count] samples of [pcm]. The array is reused afterwards: copy what you need. Return false to stop. */
        fun write(pcm: FloatArray, count: Int): Boolean
    }

    class Decoded(val frames: Int, val sampleRate: Int, val fileSeconds: Double)

    class DecodeException(message: String) : Exception(message)

    class DecodeCancelled : Exception()

    /** Collects samples into chunks for the sink; halves the sample rate of very high rate audio. */
    private class Pipe(private val sink: PcmSink, private val halve: Boolean) {
        private val chunk = FloatArray(CHUNK)
        private var n = 0
        private var pending = 0f
        private var havePending = false

        /** Samples delivered (or about to be) at the sink's sample rate. */
        var frames = 0
            private set

        /** True once the sink has said no to a chunk. */
        var sinkRefused = false
            private set

        fun add(v: Float) {
            val s: Float
            if (halve) {
                if (!havePending) {
                    pending = v
                    havePending = true
                    return
                }
                s = (pending + v) * 0.5f
                havePending = false
            } else {
                s = v
            }
            chunk[n++] = s
            frames++
            if (n == CHUNK) flush()
        }

        fun flush() {
            if (n > 0) {
                if (!sink.write(chunk, n)) sinkRefused = true
                n = 0
            }
        }

        companion object {
            const val CHUNK = 16384
        }
    }

    private const val NO_MEMORY = "Not enough memory to convert this audio. Try a shorter part."

    /**
     * Decodes up to [maxSeconds] starting at [startSeconds] and feeds the samples to [sink]. [cancelled] is polled
     * between buffers. [progress] receives 0..1 (share of the part to decode). Blocking: call from a worker thread.
     */
    fun decode(
        context: Context,
        uri: Uri,
        startSeconds: Double,
        maxSeconds: Double,
        sink: PcmSink,
        cancelled: () -> Boolean,
        progress: (Float) -> Unit
    ): Decoded {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            try {
                extractor.setDataSource(context, uri, null)
            } catch (e: Exception) {
                throw DecodeException("This file could not be opened.")
            }

            var trackIndex = -1
            var trackFormat: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                val m = f.getString(MediaFormat.KEY_MIME)
                if (m != null && m.startsWith("audio/")) {
                    trackIndex = i
                    trackFormat = f
                    break
                }
            }
            val format = trackFormat ?: throw DecodeException("This file has no audio track.")
            val mime = format.getString(MediaFormat.KEY_MIME) ?: throw DecodeException("Unknown audio format.")
            extractor.selectTrack(trackIndex)

            val fileSeconds =
                if (format.containsKey(MediaFormat.KEY_DURATION)) format.getLong(MediaFormat.KEY_DURATION) / 1_000_000.0 else 0.0
            if (fileSeconds > 0.0 && startSeconds >= fileSeconds) {
                throw DecodeException(
                    String.format(java.util.Locale.US, "The start time is past the end of the file (%.1f s long).", fileSeconds)
                )
            }
            // the part that will really be decoded (the file may be shorter than asked for)
            val wantSeconds = if (fileSeconds > 0.0) minOf(maxSeconds, fileSeconds - startSeconds) else maxSeconds

            var sampleRate = if (format.containsKey(MediaFormat.KEY_SAMPLE_RATE)) format.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 44100
            var channels = if (format.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) format.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 2
            var encoding = AudioFormat.ENCODING_PCM_16BIT

            val c: MediaCodec = try {
                val created = MediaCodec.createDecoderByType(mime)
                codec = created
                created.configure(format, null, null, 0)
                created.start()
                created
            } catch (e: Exception) {
                throw DecodeException("This device cannot decode this audio format ($mime).")
            }

            val startUs = (startSeconds * 1_000_000.0).toLong()
            if (startUs > 0L) extractor.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
            val endUs = startUs + ((maxSeconds + 1.0) * 1_000_000.0).toLong()

            var pipe: Pipe? = null
            var outRate = sampleRate
            var maxFrames = Int.MAX_VALUE  // set when the first samples arrive and their sample rate is known
            var targetFrames = 1
            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            var idle = 0
            var lastReported = -1f

            while (!outputDone) {
                val current = pipe
                if (current != null && current.frames >= maxFrames) break
                if (cancelled()) throw DecodeCancelled()
                var worked = false

                if (!inputDone) {
                    val inIdx = c.dequeueInputBuffer(5_000L)
                    if (inIdx >= 0) {
                        worked = true
                        val inBuf = c.getInputBuffer(inIdx)
                        val size = if (inBuf != null) extractor.readSampleData(inBuf, 0) else -1
                        val t = extractor.sampleTime
                        if (size < 0 || t < 0L || t > endUs) {
                            c.queueInputBuffer(inIdx, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            c.queueInputBuffer(inIdx, 0, size, t, 0)
                            extractor.advance()
                        }
                    }
                }

                val outIdx = c.dequeueOutputBuffer(info, 5_000L)
                if (outIdx >= 0) {
                    worked = true
                    val buf = c.getOutputBuffer(outIdx)
                    if (buf != null && info.size > 0) {
                        val existing = pipe
                        val out: Pipe = if (existing != null) {
                            existing
                        } else {
                            // the first samples: their sample rate is known now
                            val halve = sampleRate > 50_000
                            outRate = if (halve) sampleRate / 2 else sampleRate
                            maxFrames = (maxSeconds * outRate).toInt().coerceAtLeast(1)
                            targetFrames = (wantSeconds * outRate).toInt().coerceIn(1, maxFrames)
                            if (!sink.begin(outRate, targetFrames)) throw DecodeException(NO_MEMORY)
                            val created = Pipe(sink, halve)
                            pipe = created
                            created
                        }
                        buf.position(info.offset)
                        buf.limit(info.offset + info.size)
                        buf.order(ByteOrder.nativeOrder())
                        val ch = if (channels < 1) 1 else channels
                        val fb = if (encoding == AudioFormat.ENCODING_PCM_FLOAT) buf.asFloatBuffer() else null
                        val sb = if (encoding == AudioFormat.ENCODING_PCM_16BIT) buf.asShortBuffer() else null
                        val total = when {
                            fb != null -> fb.remaining()
                            sb != null -> sb.remaining()
                            else -> buf.remaining()
                        }
                        val frames = total / ch
                        var skip = 0
                        if (startUs > 0L) {
                            val bufStartFrame = info.presentationTimeUs.toDouble() * sampleRate / 1_000_000.0
                            val wantFrame = startUs.toDouble() * sampleRate / 1_000_000.0
                            skip = (wantFrame - bufStartFrame).toInt()
                            if (skip < 0) skip = 0
                            if (skip > frames) skip = frames
                        }
                        var f = skip
                        while (f < frames && out.frames < maxFrames) {
                            var sum = 0f
                            for (k in 0 until ch) {
                                val idx = f * ch + k
                                sum += when {
                                    fb != null -> fb.get(idx)
                                    sb != null -> sb.get(idx) / 32768f
                                    else -> ((buf.get(info.offset + idx).toInt() and 0xFF) - 128) / 128f
                                }
                            }
                            out.add(sum / ch)
                            f++
                        }
                        if (out.sinkRefused) throw DecodeException(NO_MEMORY)
                    }
                    c.releaseOutputBuffer(outIdx, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true
                } else if (outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    worked = true
                    val newFormat = c.outputFormat
                    if (newFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE)) sampleRate = newFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    if (newFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) channels = newFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    if (Build.VERSION.SDK_INT >= 24 && newFormat.containsKey(MediaFormat.KEY_PCM_ENCODING)) {
                        encoding = newFormat.getInteger(MediaFormat.KEY_PCM_ENCODING)
                    }
                }

                if (worked) idle = 0 else if (++idle > 400) break  // about 2 s without any progress

                val done = pipe?.frames ?: 0
                val frac = if (targetFrames > 0) done.toFloat() / targetFrames else 1f
                if (frac - lastReported >= 0.01f) {
                    lastReported = frac
                    progress(if (frac > 1f) 1f else frac)
                }
            }

            val last = pipe
            if (last != null) {
                last.flush()
                if (last.sinkRefused) throw DecodeException(NO_MEMORY)
            }
            if (last == null || last.frames < 1024) throw DecodeException("Not enough audio could be decoded from this file.")
            return Decoded(last.frames, outRate, fileSeconds)
        } finally {
            try {
                codec?.stop()
            } catch (e: Exception) {
                // already stopped
            }
            try {
                codec?.release()
            } catch (e: Exception) {
                // nothing left to release
            }
            try {
                extractor.release()
            } catch (e: Exception) {
                // nothing left to release
            }
        }
    }
}
