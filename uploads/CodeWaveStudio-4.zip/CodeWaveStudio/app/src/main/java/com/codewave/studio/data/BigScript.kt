package com.codewave.studio.data

import android.content.Context
import java.io.File
import java.io.FileInputStream

/**
 * A script that is too long for the editor: the code of a whole song is megabytes of text. It lives in a file in the
 * app's private storage and never in a Java string - the engine reads it from there, the screen shows its
 * beginning, and "Save code" copies it to a file the user picks.
 */
object BigScript {

    /** Scripts up to this many characters go into the editor as before; longer ones are kept in a file. */
    const val INLINE_CHARS = 250_000L

    /** How much of the start of a big script is shown on screen. */
    private const val PREVIEW_BYTES = 6_000

    private const val FILE_NAME = "big_script.cws"
    private const val INCOMING_NAME = "import_script.tmp"

    /** Size, number of lines and the first lines of a script file. */
    class Info(val bytes: Long, val lines: Int, val preview: String)

    /** The stored big script. */
    fun file(context: Context): File = File(context.applicationContext.filesDir, FILE_NAME)

    /** Where a conversion writes its result, before the app decides where it belongs. */
    fun incoming(context: Context): File = File(context.applicationContext.filesDir, INCOMING_NAME)

    fun exists(context: Context): Boolean {
        val f = file(context)
        return f.isFile && f.length() > 0L
    }

    /** Forgets the stored big script. */
    fun delete(context: Context) {
        file(context).delete()
    }

    private var cachedKey = ""
    private var cachedInfo: Info? = null

    /** [scan] of the stored script, remembered while the file does not change (a screen rotation asks again). */
    fun info(context: Context): Info? {
        val f = file(context)
        if (!f.isFile || f.length() == 0L) return null
        val key = f.length().toString() + ":" + f.lastModified()
        val known = cachedInfo
        if (known != null && key == cachedKey) return known
        return try {
            val fresh = scan(f)
            cachedKey = key
            cachedInfo = fresh
            fresh
        } catch (e: Exception) {
            null
        }
    }

    /** Reads [f] once: its size, its number of lines and its first lines (cut at the end of a line). */
    fun scan(f: File): Info {
        val head = ByteArray(PREVIEW_BYTES)
        var headLen = 0
        var lines = 0
        var total = 0L
        val newline = 10.toByte()
        FileInputStream(f).use { input ->
            val buf = ByteArray(1 shl 16)
            while (true) {
                val n = input.read(buf)
                if (n <= 0) break
                if (headLen < head.size) {
                    val take = minOf(n, head.size - headLen)
                    System.arraycopy(buf, 0, head, headLen, take)
                    headLen += take
                }
                for (i in 0 until n) if (buf[i] == newline) lines++
                total += n
            }
        }
        var preview = String(head, 0, headLen, Charsets.UTF_8)
        if (total > headLen) {
            val cut = preview.lastIndexOf('\n')
            if (cut > 0) preview = preview.substring(0, cut + 1)
        }
        return Info(total, lines, preview)
    }
}
