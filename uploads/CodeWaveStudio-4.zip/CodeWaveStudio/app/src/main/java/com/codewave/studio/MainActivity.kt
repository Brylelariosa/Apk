package com.codewave.studio

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Rect
import android.graphics.Typeface
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.text.Editable
import android.text.InputFilter
import android.text.InputType
import android.text.TextWatcher
import android.view.View
import android.view.ViewTreeObserver
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import com.codewave.studio.crash.CrashLog
import com.codewave.studio.data.AppSettings
import com.codewave.studio.data.BigScript
import com.codewave.studio.data.LanguageReference
import com.codewave.studio.data.PresetLibrary
import com.codewave.studio.data.Themes
import com.codewave.studio.engine.AudioEngine.FailureKind
import com.codewave.studio.engine.AudioEngine.Outcome
import com.codewave.studio.engine.NativeBridge
import com.codewave.studio.importer.AudioToCode
import com.codewave.studio.player.PcmPlayer
import com.codewave.studio.ui.CodeEditorView
import com.codewave.studio.ui.TimeFormat
import com.codewave.studio.ui.WaveformView
import com.codewave.studio.ui.dp
import com.codewave.studio.ui.themeColor
import java.util.Locale

class MainActivity : Activity(), SoundSession.Listener, WaveformView.Listener, AudioToCode.Listener {

    private lateinit var settings: AppSettings
    private lateinit var editor: CodeEditorView
    private lateinit var editorStats: TextView
    private lateinit var btnUndo: Button
    private lateinit var btnPaste: Button
    private lateinit var btnCopy: Button
    private lateinit var btnImport: Button
    private lateinit var btnClear: Button
    private lateinit var btnExamples: Button
    private lateinit var btnGenerate: Button
    private lateinit var progress: ProgressBar
    private lateinit var errorPanel: View
    private lateinit var errorTitle: TextView
    private lateinit var errorText: TextView
    private lateinit var waveform: WaveformView
    private lateinit var soundMeta: TextView
    private lateinit var soundNote: TextView
    private lateinit var timeText: TextView
    private lateinit var btnPlay: Button
    private lateinit var btnPause: Button
    private lateinit var btnStop: Button
    private lateinit var btnLoop: ImageButton
    private lateinit var btnSave: Button
    private lateinit var volumeSeek: SeekBar
    private lateinit var bigPanel: View
    private lateinit var bigText: TextView
    private lateinit var playerDock: View

    /** True while a script too long for the editor (the code of a whole song) is kept in a file (BigScript). */
    private var bigMode = false
    private var bigBytes = 0L
    private var bigLines = 0
    private var keyboardWatcher: ViewTreeObserver.OnGlobalLayoutListener? = null

    private var ready = false
    private var appliedTheme = AppSettings.THEME_DARK
    private var undoText: String? = null
    private var programmatic = false
    private var scrubbing = false
    private var lastTime = ""
    private val ui = Handler(Looper.getMainLooper())
    private var importDialog: AlertDialog? = null

    private val ticker = object : Runnable {
        override fun run() {
            updatePlayback()
            if (SoundSession.player?.state == PcmPlayer.State.PLAYING) waveform.postOnAnimation(this)
        }
    }

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        settings = AppSettings.get(this)
        appliedTheme = settings.theme
        setTheme(Themes.resolve(this, appliedTheme))
        super.onCreate(savedInstanceState)
        CrashLog.note("MainActivity.onCreate (restored=${savedInstanceState != null})")
        if (CrashLog.hasUnseen(this)) {
            // The previous run crashed (e.g. natively) and the report was not shown yet.
            CrashLog.showViewer(this)
            finish()
            return
        }
        setContentView(R.layout.activity_main)
        CrashLog.note("main layout inflated")
        bindViews()
        SoundSession.acquire(applicationContext)

        SoundSession.player?.let {
            it.loop = settings.loop
            it.volume = settings.volume
        }
        setupEditor(savedInstanceState)
        setupButtons()
        restoreBigScript()
        watchKeyboard()
        waveform.listener = this
        waveform.peaksProvider = { cols -> SoundSession.engine?.peaks(cols) }
        waveform.loopEnabled = settings.loop
        btnLoop.isSelected = settings.loop
        volumeSeek.progress = (settings.volume * 100f).toInt()
        ready = true
        CrashLog.note("MainActivity ready")
    }

    override fun onStart() {
        super.onStart()
        if (!ready) return
        CrashLog.note("MainActivity.onStart")
        SoundSession.listener = this
        AudioToCode.listener = this
        refreshAll()
        startTicker()
        AudioToCode.takePending()?.let { handleImportOutcome(it) }
    }

    override fun onResume() {
        super.onResume()
        if (ready && settings.theme != appliedTheme) recreate()
    }

    override fun onStop() {
        if (ready) {
            CrashLog.note("MainActivity.onStop")
            waveform.removeCallbacks(ticker)
            SoundSession.listener = null
            AudioToCode.listener = null
            importDialog?.dismiss()
            importDialog = null
            if (!bigMode) settings.script = editor.text.toString()
            if (!isChangingConfigurations) {
                SoundSession.player?.let { if (it.state == PcmPlayer.State.PLAYING) it.pause() }
            }
        }
        super.onStop()
    }

    override fun onDestroy() {
        keyboardWatcher?.let {
            val vto = window.decorView.viewTreeObserver
            if (vto.isAlive) vto.removeOnGlobalLayoutListener(it)
        }
        keyboardWatcher = null
        CrashLog.note("MainActivity.onDestroy (finishing=$isFinishing)")
        if (isFinishing) {
            AudioToCode.cancel()
            SoundSession.release()
        }
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_SAVE && resultCode == RESULT_OK) {
            data?.data?.let {
                CrashLog.note("Export: file chosen")
                exportTo(it)
            }
        }
        if (requestCode == REQ_SAVE_CODE && resultCode == RESULT_OK) {
            data?.data?.let { saveCodeTo(it) }
        }
        if (requestCode == REQ_IMPORT && resultCode == RESULT_OK) {
            data?.data?.let {
                CrashLog.note("Import: file chosen")
                showImportOptions(it)
            }
        }
    }

    // ---------------------------------------------------------------------- setup

    private fun bindViews() {
        editor = findViewById(R.id.editor)
        editorStats = findViewById(R.id.editorStats)
        btnUndo = findViewById(R.id.btnUndo)
        btnPaste = findViewById(R.id.btnPaste)
        btnCopy = findViewById(R.id.btnCopy)
        btnImport = findViewById(R.id.btnImport)
        btnClear = findViewById(R.id.btnClear)
        btnExamples = findViewById(R.id.btnExamples)
        btnGenerate = findViewById(R.id.btnGenerate)
        progress = findViewById(R.id.progress)
        errorPanel = findViewById(R.id.errorPanel)
        errorTitle = findViewById(R.id.errorTitle)
        errorText = findViewById(R.id.errorText)
        waveform = findViewById(R.id.waveform)
        soundMeta = findViewById(R.id.soundMeta)
        soundNote = findViewById(R.id.soundNote)
        timeText = findViewById(R.id.timeText)
        btnPlay = findViewById(R.id.btnPlay)
        btnPause = findViewById(R.id.btnPause)
        btnStop = findViewById(R.id.btnStop)
        btnLoop = findViewById(R.id.btnLoop)
        btnSave = findViewById(R.id.btnSave)
        volumeSeek = findViewById(R.id.volumeSeek)
        bigPanel = findViewById(R.id.bigPanel)
        bigText = findViewById(R.id.bigText)
        playerDock = findViewById(R.id.playerDock)
    }

    private fun setupEditor(savedInstanceState: Bundle?) {
        editor.filters = arrayOf<InputFilter>(InputFilter.LengthFilter(MAX_SCRIPT_CHARS))
        if (savedInstanceState == null) {
            programmatic = true
            editor.setText(settings.script.ifEmpty { PresetLibrary.DEFAULT_SCRIPT })
            programmatic = false
        }
        editor.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
            override fun afterTextChanged(s: Editable?) {
                if (!programmatic) {
                    undoText = null
                    btnUndo.visibility = View.GONE
                    editor.errorLine = 0
                }
                updateStats()
            }
        })
        errorPanel.setOnClickListener {
            val line = SoundSession.lastFailure?.line ?: 0
            if (line > 0) editor.goToLine(line)
        }
        updateStats()
    }

    private fun setupButtons() {
        findViewById<ImageButton>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        findViewById<ImageButton>(R.id.btnHelp).setOnClickListener { showReference() }

        btnPaste.setOnClickListener { confirmReplace { pasteFromClipboard() } }
        btnCopy.setOnClickListener { copyToClipboard() }
        btnImport.setOnClickListener {
            if (AudioToCode.running) AudioToCode.cancel() else pickAudio()
        }
        btnClear.setOnClickListener {
            confirmReplace { if (bigMode || editor.text.isNotEmpty()) replaceScript("") }
        }
        btnUndo.setOnClickListener {
            undoText?.let { previous ->
                programmatic = true
                editor.setText(previous)
                programmatic = false
                undoText = null
                btnUndo.visibility = View.GONE
            }
        }
        btnExamples.setOnClickListener { showExamples() }
        btnGenerate.setOnClickListener {
            if (SoundSession.generating) {
                SoundSession.cancelGeneration()
            } else {
                generate()
            }
        }

        btnPlay.setOnClickListener {
            SoundSession.player?.play()
            startTicker()
        }
        btnPause.setOnClickListener { SoundSession.player?.pause() }
        btnStop.setOnClickListener {
            SoundSession.player?.stop()
            updatePlayback()
        }
        btnLoop.setOnClickListener {
            val on = !btnLoop.isSelected
            btnLoop.isSelected = on
            settings.loop = on
            SoundSession.player?.loop = on
            waveform.loopEnabled = on
        }
        btnSave.setOnClickListener { startExport() }

        volumeSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, value: Int, fromUser: Boolean) {
                SoundSession.player?.volume = value / 100f
            }

            override fun onStartTrackingTouch(seekBar: SeekBar) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar) {
                settings.volume = seekBar.progress / 100f
            }
        })
    }

    /**
     * Portrait: while the keyboard is open the player (pinned to the bottom of the screen) steps aside, so the editor
     * gets the room instead of being squeezed between the keyboard and the player.
     */
    private fun watchKeyboard() {
        val decor = window.decorView
        val listener = ViewTreeObserver.OnGlobalLayoutListener {
            if (resources.configuration.orientation != Configuration.ORIENTATION_PORTRAIT) {
                if (playerDock.visibility != View.VISIBLE) playerDock.visibility = View.VISIBLE
                return@OnGlobalLayoutListener
            }
            val frame = Rect()
            decor.getWindowVisibleDisplayFrame(frame)
            val screen = decor.rootView.height
            val keyboardOpen = screen > 0 && (screen - frame.bottom) > screen * 0.15f
            val want = if (keyboardOpen) View.GONE else View.VISIBLE
            if (playerDock.visibility != want) playerDock.visibility = want
        }
        decor.viewTreeObserver.addOnGlobalLayoutListener(listener)
        keyboardWatcher = listener
    }

    // -------------------------------------------------------------------- editor

    private fun updateStats() {
        if (bigMode) {
            editorStats.text = String.format(Locale.US, "%,d lines · %s", bigLines, sizeText(bigBytes))
            return
        }
        val chars = editor.text.length
        editorStats.text = String.format(Locale.US, "%d lines · %d chars", editor.lineCount1, chars)
    }

    private fun sizeText(bytes: Long): String =
        if (bytes >= 1_000_000L) String.format(Locale.US, "%.1f MB", bytes / 1_000_000.0)
        else String.format(Locale.US, "%d KB", (bytes + 999L) / 1000L)

    /** Shows the start of the stored large script in place of the editor. */
    private fun showBigScript(info: BigScript.Info) {
        bigMode = true
        bigBytes = info.bytes
        bigLines = info.lines
        val shown = info.preview.count { it == '\n' }
        val text = StringBuilder()
        text.append(getString(R.string.big_script_banner, sizeText(info.bytes), info.lines))
        text.append(info.preview)
        if (info.lines > shown) text.append(getString(R.string.big_script_more, info.lines - shown))
        bigText.text = text
        bigPanel.scrollTo(0, 0)
        bigPanel.visibility = View.VISIBLE
        editor.visibility = View.GONE
        btnCopy.setText(R.string.btn_save_code)
        btnCopy.setCompoundDrawablesRelativeWithIntrinsicBounds(R.drawable.ic_save, 0, 0, 0)
        undoText = null
        btnUndo.visibility = View.GONE
        errorPanel.visibility = View.GONE
        hideKeyboard()
        updateStats()
    }

    /** Back to the editor; forgets the stored large script. */
    private fun hideBigScript() {
        if (!bigMode) return
        bigMode = false
        bigPanel.visibility = View.GONE
        editor.visibility = View.VISIBLE
        btnCopy.setText(R.string.btn_copy)
        btnCopy.setCompoundDrawablesRelativeWithIntrinsicBounds(R.drawable.ic_copy, 0, 0, 0)
        BigScript.delete(this)
        settings.bigScriptBytes = 0L
        updateStats()
    }

    /** After the app was closed: show the large script that was kept in a file, if it is still there. */
    private fun restoreBigScript() {
        if (settings.bigScriptBytes <= 0L) return
        val info = BigScript.info(this)
        if (info == null) {
            settings.bigScriptBytes = 0L
            return
        }
        showBigScript(info)
    }

    /** Runs [action]; first asks when it would throw away a large script that only exists as a file. */
    private fun confirmReplace(action: () -> Unit) {
        if (!bigMode) {
            action()
            return
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.big_replace_title)
            .setMessage(R.string.big_replace_text)
            .setPositiveButton(R.string.big_replace_yes) { _, _ -> action() }
            .setNeutralButton(R.string.btn_save_code) { _, _ -> saveCodeToFile() }
            .setNegativeButton(R.string.btn_cancel, null)
            .show()
    }

    private fun replaceScript(newText: String) {
        val wasBig = bigMode
        hideBigScript()
        val previous = if (wasBig) "" else editor.text.toString()
        programmatic = true
        editor.setText(newText)
        editor.setSelection(0)
        editor.scrollTo(0, 0)
        programmatic = false
        editor.errorLine = 0
        if (previous.isNotEmpty() && previous != newText) {
            undoText = previous
            btnUndo.visibility = View.VISIBLE
        }
    }

    private fun pasteFromClipboard() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip: ClipData? = cm.primaryClip
        val text = if (clip != null && clip.itemCount > 0) clip.getItemAt(0).coerceToText(this).toString() else ""
        if (text.isBlank()) {
            toast("The clipboard is empty")
        } else {
            replaceScript(text.take(MAX_SCRIPT_CHARS))
        }
    }

    private fun copyToClipboard() {
        if (bigMode) {
            saveCodeToFile()
            return
        }
        val text = editor.text.toString()
        if (text.isBlank()) {
            toast("There is no code to copy")
            return
        }
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        try {
            cm.setPrimaryClip(ClipData.newPlainText("CodeWave script", text))
            toast("Copied " + editor.lineCount1 + " lines")
        } catch (e: Exception) {
            toast(getString(R.string.copy_too_long))
        }
    }

    /** The large script is too long for the clipboard: let the user write it to a file. */
    private fun saveCodeToFile() {
        if (!BigScript.exists(this)) {
            toast(getString(R.string.save_code_failed))
            return
        }
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/plain"
            putExtra(Intent.EXTRA_TITLE, settings.suggestedFileName().replace(".wav", ".cws.txt"))
        }
        try {
            @Suppress("DEPRECATION")
            startActivityForResult(intent, REQ_SAVE_CODE)
        } catch (e: ActivityNotFoundException) {
            toast(getString(R.string.import_no_picker))
        }
    }

    private fun saveCodeTo(uri: Uri) {
        val source = BigScript.file(this)
        val app = applicationContext
        val resolver = contentResolver
        Thread({
            val saved = try {
                resolver.openOutputStream(uri, "wt")?.use { out ->
                    source.inputStream().use { input -> input.copyTo(out, 1 shl 16) }
                } != null
            } catch (e: Exception) {
                false
            }
            ui.post {
                Toast.makeText(app, app.getString(if (saved) R.string.save_code_done else R.string.save_code_failed), Toast.LENGTH_LONG).show()
            }
        }, "cw-save-code").start()
    }

    // ------------------------------------------------------------- audio -> code

    private fun pickAudio() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("audio/*", "video/mp4", "application/ogg"))
        }
        try {
            @Suppress("DEPRECATION")
            startActivityForResult(intent, REQ_IMPORT)
        } catch (e: ActivityNotFoundException) {
            toast(getString(R.string.import_no_picker))
        }
    }

    private fun displayNameOf(uri: Uri): String {
        var name: String? = null
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) name = c.getString(0)
            }
        } catch (e: Exception) {
            name = null
        }
        return name ?: uri.lastPathSegment ?: "audio"
    }

    /** Length of an audio file in seconds, or 0 when the device cannot tell. Reads only the file's header. */
    private fun probeSeconds(uri: Uri): Double {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(applicationContext, uri)
            (retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L) / 1000.0
        } catch (e: Exception) {
            0.0
        } finally {
            try {
                retriever.release()
            } catch (e: Exception) {
                // nothing left to release
            }
        }
    }

    private fun minutesText(seconds: Double): String {
        val total = seconds.toInt()
        return String.format(Locale.US, "%d:%02d", total / 60, total % 60)
    }

    /** Asks how much detail the code should have (and which part of the file), then converts. */
    private fun showImportOptions(uri: Uri) {
        val name = displayNameOf(uri)
        val pad = dp(20f).toInt()
        val primary = themeColor(R.attr.cwTextPrimary)
        val secondary = themeColor(R.attr.cwTextSecondary)

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, dp(8f).toInt(), pad, 0)
        }
        val infoView = TextView(this).apply {
            text = getString(R.string.import_info, name)
            setTextColor(secondary)
            textSize = 13f
        }
        box.addView(infoView)
        box.addView(TextView(this).apply {
            text = getString(R.string.import_detail)
            setTextColor(primary)
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(14f).toInt(), 0, dp(2f).toInt())
        })
        val group = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        val labels = intArrayOf(R.string.import_detail_simple, R.string.import_detail_normal, R.string.import_detail_detailed)
        val buttons = ArrayList<RadioButton>()
        for (label in labels) {
            val rb = RadioButton(this).apply {
                id = View.generateViewId()
                text = getString(label)
                setTextColor(primary)
                textSize = 14f
            }
            group.addView(rb)
            buttons.add(rb)
        }
        group.check(buttons[2].id)  // Detailed: the closest to the recording
        box.addView(group)
        box.addView(TextView(this).apply {
            text = getString(R.string.import_length)
            setTextColor(primary)
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(12f).toInt(), 0, 0)
        })
        val lengthEdit = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setSingleLine(true)
            hint = getString(R.string.import_length_hint)
            setTextColor(primary)
            setHintTextColor(secondary)
        }
        box.addView(lengthEdit)
        box.addView(TextView(this).apply {
            text = getString(R.string.import_start)
            setTextColor(primary)
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(12f).toInt(), 0, 0)
        })
        val startEdit = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setSingleLine(true)
            hint = "0"
            setTextColor(primary)
            setHintTextColor(secondary)
        }
        box.addView(startEdit)

        importDialog?.dismiss()
        val dialog = AlertDialog.Builder(this)
            .setTitle(R.string.import_title)
            .setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton(R.string.btn_convert) { _, _ ->
                if (AudioToCode.busy) {
                    toast(getString(R.string.import_busy))
                } else {
                    var detail = 2
                    for (i in buttons.indices) if (buttons[i].id == group.checkedRadioButtonId) detail = i
                    val startSeconds = startEdit.text.toString().trim().replace(',', '.').toDoubleOrNull() ?: 0.0
                    // empty (or 0) length = the whole file
                    val lengthSeconds = lengthEdit.text.toString().trim().replace(',', '.').toDoubleOrNull() ?: 0.0
                    AudioToCode.start(
                        applicationContext, uri, name,
                        if (startSeconds < 0.0) 0.0 else startSeconds,
                        if (lengthSeconds <= 0.0) 0.0 else lengthSeconds.coerceIn(1.0, AudioToCode.MAX_SECONDS),
                        detail
                    )
                    refreshGenerating()
                    refreshError()
                }
            }
            .setNegativeButton(R.string.btn_cancel, null)
            .show()
        importDialog = dialog

        // the length of the file, once the device has read its header (shown in the text at the top)
        Thread({
            val seconds = probeSeconds(uri)
            if (seconds > 0.0) {
                ui.post {
                    if (importDialog === dialog && dialog.isShowing) {
                        infoView.text = getString(R.string.import_info_length, name, minutesText(seconds))
                    }
                }
            }
        }, "cw-probe").start()
    }

    override fun onImportProgress(fraction: Float) {
        if (AudioToCode.running) progress.progress = (fraction * 1000f).toInt()
    }

    override fun onImportFinished(outcome: AudioToCode.Outcome) {
        handleImportOutcome(outcome)
    }

    private fun handleImportOutcome(outcome: AudioToCode.Outcome) {
        refreshAll()
        when (outcome) {
            is AudioToCode.Outcome.Success -> {
                if (useImportedScript(outcome)) {
                    Toast.makeText(this, getString(R.string.import_done, outcome.summary), Toast.LENGTH_LONG).show()
                    generate()
                }
            }
            is AudioToCode.Outcome.Failure ->
                showFailureText(outcome.message, 0, FailureKind.SCRIPT, R.string.import_error_title)
            AudioToCode.Outcome.Cancelled -> toast("Import cancelled")
        }
    }

    /**
     * Puts the converted code where it belongs: in the editor when it is short, otherwise kept in a file (the code
     * of a whole song is megabytes of text, too much for an editor). Returns false when that failed.
     */
    private fun useImportedScript(outcome: AudioToCode.Outcome.Success): Boolean {
        val info = outcome.info
        if (info.bytes <= BigScript.INLINE_CHARS) {
            val text = try {
                outcome.file.readText(Charsets.UTF_8)
            } catch (e: Exception) {
                ""
            }
            outcome.file.delete()
            if (text.isEmpty()) {
                showFailureText(getString(R.string.import_no_code), 0, FailureKind.SCRIPT, R.string.import_error_title)
                return false
            }
            replaceScript(text)
            return true
        }
        hideBigScript()  // forgets an earlier large script (and its file)
        val target = BigScript.file(this)
        target.delete()
        var moved = outcome.file.renameTo(target)
        if (!moved) {
            moved = try {
                outcome.file.copyTo(target, overwrite = true)
                outcome.file.delete()
                true
            } catch (e: Exception) {
                false
            }
        }
        if (!moved) {
            showFailureText(getString(R.string.save_code_failed), 0, FailureKind.SCRIPT, R.string.import_error_title)
            return false
        }
        settings.bigScriptBytes = info.bytes
        showBigScript(info)
        return true
    }

    private fun showExamples() {
        val presets = PresetLibrary.list(this)
        if (presets.isEmpty()) {
            toast("No examples found")
            return
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.btn_examples)
            .setItems(presets.map { it.name }.toTypedArray()) { _, which ->
                confirmReplace { replaceScript(PresetLibrary.load(this, presets[which])) }
            }
            .setNegativeButton(R.string.btn_close, null)
            .show()
    }

    private fun showReference() {
        val text = TextView(this).apply {
            this.text = LanguageReference.load(this@MainActivity)
            typeface = Typeface.MONOSPACE
            textSize = 12f
            setTextIsSelectable(true)
            setTextColor(themeColor(R.attr.cwTextPrimary))
            val pad = dp(20f).toInt()
            setPadding(pad, dp(8f).toInt(), pad, dp(8f).toInt())
        }
        val scroll = ScrollView(this).apply { addView(text) }
        AlertDialog.Builder(this)
            .setTitle(R.string.cd_help)
            .setView(scroll)
            .setPositiveButton(R.string.btn_copy_ai) { _, _ ->
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("CodeWave AI prompt", LanguageReference.aiPrompt(this)))
                toast("Copied. Paste it into Claude and describe your sound.")
            }
            .setNegativeButton(R.string.btn_close, null)
            .show()
    }

    // ---------------------------------------------------------------- generation

    private fun generate() {
        hideKeyboard()
        if (bigMode) {
            if (!BigScript.exists(this)) {
                hideBigScript()
                showFailureText(getString(R.string.big_script_missing), 0)
                return
            }
            CrashLog.note("Generate pressed (large script file, $bigBytes bytes)")
            SoundSession.generate(applicationContext, "", BigScript.file(this).absolutePath)
            return
        }
        val script = editor.text.toString()
        if (script.isBlank()) {
            showFailureText("The script is empty.\n\nPaste a CodeWave script, or pick one from Examples.", 0)
            return
        }
        CrashLog.note("Generate pressed (${script.length} chars)")
        SoundSession.generate(applicationContext, script)
    }

    override fun onGenerateStarted() {
        editor.errorLine = 0
        refreshGenerating()
        refreshError()
        refreshTransport()
    }

    override fun onGenerateProgress(fraction: Float) {
        progress.progress = (fraction * 1000f).toInt()
    }

    override fun onGenerateFinished(outcome: Outcome) {
        refreshAll()
        when (outcome) {
            is Outcome.Success -> {
                startTicker()
            }
            is Outcome.Failure -> {
                if (outcome.line > 0) editor.goToLine(outcome.line)
            }
            Outcome.Cancelled -> toast("Generation cancelled")
        }
    }

    // ------------------------------------------------------------------ UI refresh

    private fun refreshAll() {
        refreshGenerating()
        refreshError()
        refreshSound()
        refreshTransport()
        updatePlayback()
    }

    private fun refreshGenerating() {
        val gen = SoundSession.generating
        val imp = AudioToCode.running
        btnGenerate.setText(if (gen) R.string.btn_cancel else R.string.btn_generate)
        btnGenerate.setCompoundDrawablesRelativeWithIntrinsicBounds(
            if (gen) R.drawable.ic_stop else R.drawable.ic_generate, 0, 0, 0
        )
        btnGenerate.isEnabled = !imp
        btnImport.isEnabled = !gen
        btnImport.setText(if (imp) R.string.btn_cancel_import else R.string.btn_import)
        btnImport.setCompoundDrawablesRelativeWithIntrinsicBounds(
            if (imp) R.drawable.ic_stop else R.drawable.ic_audio_file, 0, 0, 0
        )
        progress.visibility = if (gen || imp) View.VISIBLE else View.GONE
        progress.progress = ((if (imp) AudioToCode.progress else SoundSession.progress) * 1000f).toInt()
    }

    private fun refreshError() {
        val failure = SoundSession.lastFailure
        if (failure == null || SoundSession.generating) {
            errorPanel.visibility = View.GONE
            editor.errorLine = 0
            return
        }
        showFailureText(failure.message, failure.line, failure.kind)
    }

    private fun showFailureText(
        message: String,
        line: Int,
        kind: FailureKind = FailureKind.SCRIPT,
        titleRes: Int = R.string.error_title
    ) {
        errorTitle.setText(titleRes)
        errorText.text =
            if (kind == FailureKind.INTERNAL && !NativeBridge.available) getString(R.string.error_native_missing) else message
        errorPanel.visibility = View.VISIBLE
        editor.errorLine = line
    }

    private fun refreshSound() {
        val info = SoundSession.sound
        waveform.setSound(info?.durationSeconds ?: 0.0, info != null)
        if (info == null) {
            soundMeta.text = ""
            soundNote.visibility = View.GONE
            return
        }
        soundMeta.text = String.format(
            Locale.US, "%.1f kHz · %s · %.1f s to make",
            info.sampleRate / 1000.0, if (info.channels == 1) "Mono" else "Stereo", SoundSession.lastMillis / 1000.0
        )
        val note = SoundSession.lastWarnings
        soundNote.text = note
        soundNote.visibility = if (note.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun refreshTransport() {
        val has = SoundSession.sound != null
        val gen = SoundSession.generating
        val st = SoundSession.player?.state ?: PcmPlayer.State.IDLE
        btnPlay.isEnabled = has && !gen && st != PcmPlayer.State.PLAYING
        btnPause.isEnabled = st == PcmPlayer.State.PLAYING
        btnStop.isEnabled = has && st != PcmPlayer.State.IDLE
        btnSave.isEnabled = has && !gen
        btnLoop.isSelected = settings.loop
    }

    private fun updatePlayback() {
        val info = SoundSession.sound
        val player = SoundSession.player
        if (info == null || player == null || info.frames <= 0) {
            setTime(0.0, 0.0)
            waveform.setPlayhead(0f)
            return
        }
        val frame = player.currentFrame()
        if (!scrubbing) waveform.setPlayhead(frame.toFloat() / info.frames)
        setTime(frame.toDouble() / info.sampleRate, info.durationSeconds)
    }

    private fun setTime(position: Double, duration: Double) {
        if (scrubbing) return
        val s = TimeFormat.clock(position) + " / " + TimeFormat.clock(duration)
        if (s != lastTime) {
            lastTime = s
            timeText.text = s
        }
    }

    private fun startTicker() {
        waveform.removeCallbacks(ticker)
        if (SoundSession.player?.state == PcmPlayer.State.PLAYING) waveform.postOnAnimation(ticker)
    }

    // ----------------------------------------------------------------- listeners

    override fun onPlayerStateChanged(state: PcmPlayer.State) {
        refreshTransport()
        updatePlayback()
        if (state == PcmPlayer.State.PLAYING) startTicker()
    }

    override fun onPlayerError(message: String) {
        refreshTransport()
        showFailureText(message, 0, FailureKind.SCRIPT, R.string.error_playback_title)
    }

    override fun onScrub(fraction: Float) {
        scrubbing = true
        val info = SoundSession.sound ?: return
        val seconds = fraction * info.durationSeconds
        val s = TimeFormat.clock(seconds) + " / " + TimeFormat.clock(info.durationSeconds)
        if (s != lastTime) {
            lastTime = s
            timeText.text = s
        }
    }

    override fun onSeek(fraction: Float) {
        scrubbing = false
        val info = SoundSession.sound ?: return
        SoundSession.player?.seekTo((fraction * info.frames).toInt())
        updatePlayback()
        startTicker()
    }

    // -------------------------------------------------------------------- export

    private fun startExport() {
        if (SoundSession.sound == null) return
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "audio/wav"
            putExtra(Intent.EXTRA_TITLE, settings.suggestedFileName())
        }
        try {
            @Suppress("DEPRECATION")
            startActivityForResult(intent, REQ_SAVE)
        } catch (e: ActivityNotFoundException) {
            toast("No file picker is available on this device")
        }
    }

    private fun exportTo(uri: Uri) {
        val engine = SoundSession.engine ?: return
        val resolver = contentResolver
        val app = applicationContext
        val name = settings.suggestedFileName()
        val bits = if (settings.exportFormat == AppSettings.FORMAT_WAV32F) 32 else 16
        Thread({
            val code = try {
                resolver.openFileDescriptor(uri, "wt")?.use { pfd -> engine.writeWav(pfd.fd, bits) } ?: -3
            } catch (e: Exception) {
                -4
            }
            CrashLog.note("Export finished, code=$code")
            ui.post {
                if (code == 0) {
                    val s = AppSettings.get(app)
                    s.exportCounter = s.exportCounter + 1
                    Toast.makeText(app, "Saved $name", Toast.LENGTH_LONG).show()
                } else {
                    val why = when (code) {
                        28 -> "not enough storage space"
                        -1 -> "there is no sound to export"
                        -3 -> "the file could not be opened"
                        else -> "write error $code"
                    }
                    Toast.makeText(app, "Export failed: $why", Toast.LENGTH_LONG).show()
                }
            }
        }, "cw-export").start()
    }

    // ------------------------------------------------------------------- helpers

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    private fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(editor.windowToken, 0)
    }

    companion object {
        private const val REQ_SAVE = 4001
        private const val REQ_IMPORT = 4002
        private const val REQ_SAVE_CODE = 4003
        private const val MAX_SCRIPT_CHARS = 300_000
    }
}
