package com.codewave.studio.importer

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import com.codewave.studio.crash.CrashLog
import com.codewave.studio.data.BigScript
import com.codewave.studio.engine.NativeBridge
import com.codewave.studio.engine.ProgressListener
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

/**
 * "Import audio, get code": decodes an audio file (a whole song, up to 15 minutes) and asks the native analyser to
 * write a CodeWave script that imitates it. The decoded audio is kept in native memory and the script is written to
 * a file, so a long song never has to fit in the Java heap. Runs on a worker thread; like
 * [com.codewave.studio.SoundSession] it survives Activity re-creation - a result that arrives while no screen is
 * attached waits in [takePending]. Main thread only (except the worker body).
 */
object AudioToCode {

    /** Longest part of a file that is converted: 15 minutes (a full song, or a ten minute piece). */
    const val MAX_SECONDS = 900.0

    /** Share of the progress bar used for decoding; the rest is the analysis. */
    private const val DECODE_SHARE = 0.1f

    interface Listener {
        fun onImportProgress(fraction: Float)
        fun onImportFinished(outcome: Outcome)
    }

    sealed class Outcome {
        /** [file] holds the script ([info]: its size, line count and first lines). */
        class Success(val file: File, val info: BigScript.Info, val summary: String) : Outcome()
        class Failure(val message: String) : Outcome()
        object Cancelled : Outcome()
    }

    private val main = Handler(Looper.getMainLooper())
    private var token = 0
    private var cancelFlag = AtomicBoolean(false)
    private val workerAlive = AtomicBoolean(false)
    private var pending: Outcome? = null

    var listener: Listener? = null

    var running: Boolean = false
        private set

    var progress: Float = 0f
        private set

    /** True while a conversion runs or is still winding down after a cancel: a new one cannot start yet. */
    val busy: Boolean get() = running || workerAlive.get()

    /**
     * [lengthSeconds] <= 0 means "the whole file" (up to [MAX_SECONDS]). [detail]: 0 simple, 1 normal, 2 detailed.
     */
    fun start(context: Context, uri: Uri, displayName: String, startSeconds: Double, lengthSeconds: Double, detail: Int) {
        if (busy) return
        running = true
        progress = 0f
        pending = null
        val mine = ++token
        val flag = AtomicBoolean(false)
        cancelFlag = flag
        val app = context.applicationContext
        val length = if (lengthSeconds <= 0.0) MAX_SECONDS else lengthSeconds.coerceIn(1.0, MAX_SECONDS)
        CrashLog.note("Import audio: detail=$detail, start=$startSeconds s, length=" + (if (lengthSeconds <= 0.0) "whole file" else "$length s"))
        workerAlive.set(true)
        Thread({
            val outcome = try {
                work(app, uri, displayName, startSeconds, length, detail, flag) { f ->
                    main.post {
                        if (token == mine && running) {
                            progress = f
                            listener?.onImportProgress(f)
                        }
                    }
                }
            } finally {
                workerAlive.set(false)
            }
            main.post { finish(mine, outcome) }
        }, "cw-import").start()
    }

    fun cancel() {
        if (!running) return
        cancelFlag.set(true)
        if (NativeBridge.available) {
            try {
                NativeBridge.importCancel()  // stops the analysis at its next check
            } catch (t: Throwable) {
                // the decoder stops by itself: it polls the flag
            }
        }
        token++
        running = false
        progress = 0f
        CrashLog.note("Import cancelled")
        listener?.onImportFinished(Outcome.Cancelled)
    }

    /** A result that arrived while no screen was listening (e.g. during rotation), or null. */
    fun takePending(): Outcome? {
        val p = pending
        pending = null
        return p
    }

    private fun finish(mine: Int, outcome: Outcome) {
        if (mine != token) return
        running = false
        progress = 0f
        CrashLog.note(
            when (outcome) {
                is Outcome.Success -> "Import OK: ${outcome.summary} (${outcome.info.bytes} bytes)"
                is Outcome.Failure -> "Import failed: ${outcome.message}"
                Outcome.Cancelled -> "Import cancelled"
            }
        )
        val l = listener
        if (l != null) l.onImportFinished(outcome) else pending = outcome
    }

    private fun work(
        app: Context,
        uri: Uri,
        displayName: String,
        startSeconds: Double,
        lengthSeconds: Double,
        detail: Int,
        flag: AtomicBoolean,
        report: (Float) -> Unit
    ): Outcome {
        if (!NativeBridge.available) {
            return Outcome.Failure("The native audio engine could not be loaded on this device.")
        }
        var imported = false
        try {
            val sink = object : AudioDecoder.PcmSink {
                override fun begin(sampleRate: Int, expectedFrames: Int): Boolean {
                    imported = true
                    return NativeBridge.importBegin(sampleRate, expectedFrames)
                }

                override fun write(pcm: FloatArray, count: Int): Boolean = NativeBridge.importAppend(pcm, count) >= 0
            }
            AudioDecoder.decode(
                app, uri, startSeconds, lengthSeconds, sink,
                { flag.get() },
                { f -> report(f * DECODE_SHARE) }
            )
            if (flag.get()) return Outcome.Cancelled
            report(DECODE_SHARE)

            val out = BigScript.incoming(app)
            out.delete()
            val analysisProgress = object : ProgressListener {
                override fun onProgress(fraction: Float) {
                    report(DECODE_SHARE + (1f - DECODE_SHARE) * fraction)
                }
            }
            imported = false  // the analysis takes the audio over (and frees it)
            val reply = NativeBridge.analyzeImported(out.absolutePath, detail, displayName, startSeconds.toFloat(), analysisProgress)
            if (flag.get() || reply == "CANCELLED") {
                out.delete()
                return Outcome.Cancelled
            }
            val lines = reply.split('\n')
            if (lines.isNotEmpty() && lines[0] == "OK") {
                val summary = if (lines.size > 1) lines[1] else ""
                if (!out.isFile || out.length() == 0L) return Outcome.Failure("The conversion produced no code.")
                val info = BigScript.scan(out)
                report(1f)
                return Outcome.Success(out, info, summary)
            }
            val message = if (lines.size > 1) lines.drop(1).joinToString("\n").trim() else ""
            return Outcome.Failure(if (message.isEmpty()) "The audio could not be converted." else message)
        } catch (e: AudioDecoder.DecodeCancelled) {
            return Outcome.Cancelled
        } catch (e: AudioDecoder.DecodeException) {
            return Outcome.Failure(e.message ?: "The audio could not be decoded.")
        } catch (e: OutOfMemoryError) {
            return Outcome.Failure("Not enough memory to convert this audio. Try a shorter part or a lower detail level.")
        } catch (t: Throwable) {
            return Outcome.Failure("The audio could not be converted (" + t.javaClass.simpleName + ").")
        } finally {
            // audio that was decoded but never analysed (cancelled, or the decoder failed) must not stay in memory
            if (imported) {
                try {
                    NativeBridge.importDiscard()
                } catch (t: Throwable) {
                    // nothing to free
                }
            }
        }
    }
}
