// CodeWave Studio - shared engine types.
// Everything an untrusted script can influence is bounded by the limits below.
#pragma once

#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <stdexcept>
#include <string>

namespace cw {

constexpr double kPi = 3.14159265358979323846;
constexpr double kTwoPi = 2.0 * kPi;

namespace limits {
// A full song (or a ten minute piece) must fit: the longest sound is 16 minutes. The cost of a long sound is
// kept in check by memoryBudgetFor() / workBudgetFor() below, which grow with the length of the sound.
constexpr double kMaxDurationSec = 960.0;
constexpr double kMinDurationSec = 0.01;
constexpr size_t kMaxScriptBytes = 48u * 1024u * 1024u;
constexpr int kMaxCommands = 600000;
constexpr int kMaxLayerDepth = 4;
constexpr int kMaxRepeatCount = 128;
constexpr int kMaxLayerInstances = 100000;
constexpr int kMaxPendingSources = 16;
constexpr int kMaxSourcesTotal = 400000;
constexpr size_t kMemoryBudgetBytes = 96u * 1024u * 1024u;   // base allowance (a sound of up to ~2 minutes)
constexpr int kMaxProcessorsPerLayer = 64;
constexpr int kMaxEnvelopePoints = 2048;      // (time, value) pairs in one envelope.custom
constexpr int kMaxPartialPoints = 2048;       // (time, frequency, volume) triples in one partial.track
constexpr int kMaxPartialHarmonics = 64;      // volumes in one partial.harmonics
constexpr double kWorkBudget = 1.2e10;  // base allowance of abstract "frame operations"

// Memory a render may hold: the base allowance, or room for a stereo copy of the whole sound plus 64 MB of
// working buffers, whichever is more. (A long song is one big buffer: 10 minutes at 44.1 kHz = 106 MB per channel.)
inline size_t memoryBudgetFor(long frames) {
  const size_t need = (size_t)(frames < 0 ? 0 : frames) * 2u * sizeof(float) + 64u * 1024u * 1024u;
  return need > kMemoryBudgetBytes ? need : kMemoryBudgetBytes;
}
// The work a render may do grows with the length of the sound: about 3000 operations per output sample on top of
// the base allowance, which is far more than a dense 40-voice, 16-band import needs.
inline double workBudgetFor(long frames) { return kWorkBudget + 3000.0 * (double)(frames < 0 ? 0 : frames); }
}  // namespace limits

enum class ErrorKind { Script, Limit, Memory };

// Thrown for anything the user can fix by editing the script (or by asking for less).
struct EngineError : public std::runtime_error {
  ErrorKind kind;
  int line;          // 1-based script line, 0 when not tied to a line
  std::string hint;  // extra lines, e.g. "Expected:\nsine\nsquare"

  EngineError(ErrorKind k, int ln, const std::string& msg, const std::string& h = std::string())
      : std::runtime_error(msg), kind(k), line(ln), hint(h) {}

  std::string format() const {
    std::string s;
    if (line > 0) s += "Line " + std::to_string(line) + ":\n";
    s += what();
    if (!hint.empty()) {
      s += "\n\n";
      s += hint;
    }
    return s;
  }
};

struct Cancelled {};

// xorshift64*: tiny, fast and fully deterministic (same script => same sound).
//
// Independent sources (every noise layer, every voice) get their own generator via Rng::child(). The child's
// seed is scrambled first: seeding a child with the parent's next output would make it the very same stream
// shifted by one sample (xorshift is a single cycle), so all noise layers of a script would be copies of each
// other and add up coherently - band-limited noise layers would no longer sum to the spectrum they describe.
struct Rng {
  uint64_t s;
  explicit Rng(uint32_t seed = 1u) : s(mix64((uint64_t)(seed ? seed : 0x9E3779B9u))) {
    for (int i = 0; i < 4; ++i) next();
  }
  static uint64_t mix64(uint64_t z) {  // splitmix64 finaliser
    z += 0x9E3779B97F4A7C15ull;
    z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ull;
    z = (z ^ (z >> 27)) * 0x94D049BB133111EBull;
    z ^= z >> 31;
    return z ? z : 0x9E3779B97F4A7C15ull;
  }
  static Rng child(Rng& parent) { return Rng(parent.next()); }
  uint32_t next() {
    s ^= s >> 12;
    s ^= s << 25;
    s ^= s >> 27;
    return (uint32_t)((s * 0x2545F4914F6CDD1Dull) >> 32);
  }
  float uni() { return (next() >> 8) * (1.0f / 16777216.0f); }  // [0,1)
  float bi() { return uni() * 2.0f - 1.0f; }                    // [-1,1)
};

// Volume curves written as points (envelope.deltas, partial.track) join two points with a straight line on a decibel
// scale - a natural decay or swell stays natural with very few points - unless one end is (almost) silent, where
// a straight line in volume fades from / to nothing.
constexpr double kGeoMin = 1e-4;
inline double joinVolume(double a, double b, double u) {
  return (a >= kGeoMin && b >= kGeoMin) ? a * std::pow(b / a, u) : a + (b - a) * u;
}

inline double clampd(double v, double lo, double hi) { return v < lo ? lo : (v > hi ? hi : v); }
inline float clampf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }
inline double lerpd(double a, double b, double t) { return a + (b - a) * t; }
inline double dbToLin(double db) { return std::pow(10.0, db / 20.0); }
inline float undenorm(float v) { return std::fabs(v) < 1e-18f ? 0.0f : v; }
inline int toFrames(double seconds, int sr) { return (int)std::lround(seconds * (double)sr); }

// Per-generation context: sample rate, deterministic RNG, memory + work budgets
// and cooperative cancellation. Not thread-safe (one render per context).
class RenderCtx {
 public:
  const int sr;
  Rng rng;

  RenderCtx(int sampleRate, uint32_t seed, const std::atomic<bool>* cancelFlag,
            size_t memLimit = limits::kMemoryBudgetBytes, double workLimit = limits::kWorkBudget)
      : sr(sampleRate), rng(seed), cancel_(cancelFlag), memLimit_(memLimit), workLimit_(workLimit) {}

  void allocate(size_t bytes) {
    if (memUsed_ + bytes > memLimit_) {
      throw EngineError(ErrorKind::Memory, 0,
                        "This sound needs more memory than the safety budget allows.",
                        "Use a shorter duration, fewer nested layers, or a lower sample rate.");
    }
    memUsed_ += bytes;
  }
  void release(size_t bytes) { memUsed_ = bytes > memUsed_ ? 0 : memUsed_ - bytes; }

  // Charge `units` of work (about one unit per processed sample); also polls cancellation.
  void spend(double units) {
    work_ += units;
    if (work_ > workLimit_) {
      throw EngineError(ErrorKind::Limit, 0, "This script is too expensive to render.",
                        "Reduce the duration, the number of layers/repeats, or heavy effects "
                        "(reverb, vocoder, pitch/time stretch).");
    }
    check();
  }
  void check() const {
    if (cancel_ && cancel_->load(std::memory_order_relaxed)) throw Cancelled();
  }

 private:
  const std::atomic<bool>* cancel_;
  size_t memLimit_;
  double workLimit_;
  size_t memUsed_ = 0;
  double work_ = 0;
};

}  // namespace cw
