#include "partials.h"

#include <algorithm>
#include <cmath>
#include <memory>
#include <utility>

#include "../dsp/common.h"
#include "parallel.h"
#include "spectral.h"

namespace cw {
namespace analysis {
namespace {

// ------------------------------------------------------------------ analysis bands
// Every band has its own window: the bass needs frequency resolution (and holds still), the highs need time
// resolution (a vibrato at 3 kHz moves tens of Hz within one long window and would smear into mush).
struct BandSpec {
  double fLo, fHi;
  int N, H;
};

std::vector<BandSpec> makeBandSpecs(int sr, double dur, double maxHz) {
  static const struct {
    double lo, hi;
    int N, hopDiv;
  } kBase[] = {{30.0, 230.0, 4096, 8}, {230.0, 1400.0, 4096, 8}, {1400.0, 5000.0, 2048, 4}, {5000.0, 14000.0, 1024, 4}};
  // (The lowest band used an 8192 point window. 4096 points follow a kick drum's pitch sweep and the start of a bass
  // note much better - the 40-200 Hz level error of a test piece fell from 1.5 to 1.1 dB and the pitch-class match
  // rose from 0.83 to 0.87 - while still telling apart bass notes that sound at the same time.)
  const double scale = dur > 4.0 ? 1.0 : (dur > 1.5 ? 0.5 : 0.25);  // short sounds need the time resolution
  std::vector<BandSpec> out;
  const double top = std::min(0.45 * sr, maxHz);
  for (const auto& b : kBase) {
    if (b.lo >= top) break;
    BandSpec s;
    s.fLo = b.lo;
    s.fHi = std::min(b.hi, top);
    s.N = std::max(256, (int)std::lround(b.N * scale));
    s.H = std::max(64, s.N / b.hopDiv);
    out.push_back(s);
  }
  return out;
}

// ----------------------------------------------------------------- peak picking
struct Pk {
  float freq, amp, wamp;  // Hz, linear amplitude (input peak = 1), amplitude x hearing weight
};

class PeakPicker {
 public:
  PeakPicker(const BandSpec& b, int sr, const PartialParams& P) : N_(b.N), half_(b.N / 2), binHz_((double)sr / b.N) {
    kLo_ = std::max(3, (int)std::ceil(b.fLo / binHz_));
    kHi_ = std::min(half_ - 3, (int)std::floor(b.fHi / binHz_));
    ampScale_ = hannAmp(N_);
    absFloor_ = std::pow(10.0, P.floorDb / 20.0) / ampScale_;
    dynMul_ = std::pow(10.0, -P.dynDb / 20.0);
    snrMul_ = (float)std::pow(10.0, P.snrDb / 20.0);
    w_.assign((size_t)half_ + 1, 0.0f);
    for (int k = 0; k <= half_; ++k) w_[(size_t)k] = (float)hearingWeight(k * binHz_);
    floor_.assign((size_t)half_ + 2, 0.0f);
    maxPeaks_ = P.maxPeaks;
  }

  int bins() const { return kHi_ - kLo_ + 1; }
  double binHz() const { return binHz_; }

  // Peaks of one frame, sorted by frequency.
  void pick(const float* mag, std::vector<Pk>& out) {
    out.clear();
    if (kHi_ <= kLo_) return;
    float mx = 0.0f;  // strongest peak as a listener hears it
    for (int k = kLo_; k <= kHi_; ++k) mx = std::max(mx, mag[k] * w_[(size_t)k]);
    if ((double)mx < absFloor_) return;
    const float thr = (float)std::max((double)mx * dynMul_, absFloor_);
    medianFloor(mag);

    cand_.clear();
    for (int k = kLo_; k <= kHi_; ++k) {
      const float m = mag[k];
      if (m <= mag[k - 1] || m < mag[k + 1]) continue;
      if (m * w_[(size_t)k] < thr) continue;
      if (m < snrMul_ * floor_[(size_t)k]) continue;               // not clearly above the noise around it
      if (std::max(mag[k - 1], mag[k + 1]) < 0.2f * m) continue;  // a needle, not a windowed sinusoid
      const double a = std::log((double)mag[k - 1] + 1e-12), b = std::log((double)m + 1e-12),
                   c = std::log((double)mag[k + 1] + 1e-12);
      const double den = a - 2.0 * b + c;
      const double p = den < -1e-9 ? clampd(0.5 * (a - c) / den, -0.5, 0.5) : 0.0;
      Cand cd;
      cd.pos = k + p;
      cd.mag = m;
      cd.amp = (float)(std::exp(b - 0.25 * (a - c) * p) * ampScale_);
      cd.wamp = cd.amp * w_[(size_t)k];
      cand_.push_back(cd);
    }
    // Strongest first; a weaker peak sitting where a stronger one's window side lobes are is a ghost.
    std::sort(cand_.begin(), cand_.end(), [](const Cand& a, const Cand& b) { return a.mag > b.mag; });
    acc_.clear();
    for (const Cand& c : cand_) {
      bool ghost = false;
      for (const Cand& s : acc_) {
        const double d = std::fabs(c.pos - s.pos);
        if (d > 12.0) continue;
        if (d < 3.0) {
          ghost = c.mag < 0.6f * s.mag;  // the same lobe seen twice
        } else {
          const double leak = std::pow(10.0, -(31.5 + 60.0 * std::log10(d / 2.5)) / 20.0);  // Hann side lobes
          ghost = (double)c.mag < 2.0 * (double)s.mag * leak;
        }
        if (ghost) break;
      }
      if (!ghost) acc_.push_back(c);
    }
    if ((int)acc_.size() > maxPeaks_) {
      std::nth_element(acc_.begin(), acc_.begin() + maxPeaks_, acc_.end(),
                       [](const Cand& a, const Cand& b) { return a.wamp > b.wamp; });
      acc_.resize((size_t)maxPeaks_);
    }
    std::sort(acc_.begin(), acc_.end(), [](const Cand& a, const Cand& b) { return a.pos < b.pos; });
    for (const Cand& c : acc_) out.push_back(Pk{(float)(c.pos * binHz_), c.amp, c.wamp});
  }

 private:
  struct Cand {
    double pos;  // bins
    float mag, amp, wamp;
  };

  // Level of the spectrum "between" the peaks: median of overlapping 32-bin blocks, interpolated.
  void medianFloor(const float* mag) {
    const int B = 32, S = 16;
    const int k0 = std::max(1, kLo_ - B), k1 = std::min(half_, kHi_ + B);
    const int nBlocks = std::max(1, (k1 - k0 - B) / S + 2);
    med_.assign((size_t)nBlocks, 0.0f);
    float tmp[32];
    for (int j = 0; j < nBlocks; ++j) {
      const int s = k0 + j * S;
      const int len = std::max(1, std::min(B, half_ + 1 - s));
      for (int i = 0; i < len; ++i) tmp[i] = mag[std::min(half_, s + i)];
      std::nth_element(tmp, tmp + len / 2, tmp + len);
      med_[(size_t)j] = tmp[len / 2];
    }
    for (int k = kLo_; k <= kHi_; ++k) {
      const double u = (double)(k - k0 - B / 2) / S;
      const int j = (int)std::floor(u);
      const double fr = u - j;
      const float a = med_[(size_t)clampi(j, 0, nBlocks - 1)], b = med_[(size_t)clampi(j + 1, 0, nBlocks - 1)];
      floor_[(size_t)k] = (float)(a + (b - a) * clampd(fr, 0.0, 1.0));
    }
  }
  static int clampi(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }

  int N_, half_;
  double binHz_;
  int kLo_ = 3, kHi_ = 3;
  double ampScale_, absFloor_, dynMul_;
  float snrMul_;
  int maxPeaks_;
  std::vector<float> w_, floor_, med_;
  std::vector<Cand> cand_, acc_;
};

// ------------------------------------------------------------------- tracking
struct Tp {
  int frame;
  float freq, amp;
};
struct Track {
  std::vector<Tp> pts;
  double lastSt = 0.0, vel = 0.0;
  int lastFrame = 0, missed = 0;
  bool ended = false;
};

// McAulay-Quatieri style tracking: every active track predicts where its partial goes next (position and
// slope in semitones) and takes the nearest peak within a tolerance that narrows as the track matures.
class Tracker {
 public:
  Tracker(double binHz, int minFrames) : binHz_(binHz), minFrames_(minFrames) {}

  void step(int f, const std::vector<Pk>& pk, std::vector<Track>& done) {
    sts_.resize(pk.size());
    for (size_t i = 0; i < pk.size(); ++i) sts_[i] = semis(pk[i].freq);
    cands_.clear();
    for (size_t t = 0; t < act_.size(); ++t) {
      const Track& tr = act_[t];
      const double pred = tr.lastSt + tr.vel * (f - tr.lastFrame);
      const size_t len = tr.pts.size();
      const double fHz = std::exp2(tr.lastSt / 12.0);
      const double binSt = 12.0 * std::log2(1.0 + 0.9 * binHz_ / std::max(20.0, fHz));  // ~0.9 bin, in semitones
      const double base = len == 1 ? 2.0 : (len == 2 ? 1.2 : 0.7);
      const double tol = std::max(base, binSt) + 0.25 * tr.missed;
      const size_t lo = (size_t)(std::lower_bound(sts_.begin(), sts_.end(), pred - tol) - sts_.begin());
      for (size_t p = lo; p < pk.size() && sts_[p] <= pred + tol; ++p)
        cands_.push_back({(float)std::fabs(sts_[p] - pred), (int)t, (int)p});
    }
    std::sort(cands_.begin(), cands_.end(), [](const Cand& a, const Cand& b) { return a.d < b.d; });
    pkUsed_.assign(pk.size(), 0);
    trUsed_.assign(act_.size(), 0);
    spawn_.clear();
    for (const Cand& c : cands_) {
      if (pkUsed_[(size_t)c.p] || trUsed_[(size_t)c.t]) continue;
      pkUsed_[(size_t)c.p] = 1;
      trUsed_[(size_t)c.t] = 1;
      Track& tr = act_[(size_t)c.t];
      const Pk& p = pk[(size_t)c.p];
      const size_t n = tr.pts.size();
      const double st = sts_[(size_t)c.p];
      // A sharp new attack on an already decaying / steady partial starts a new note.
      if (n >= 3) {
        const float a1 = tr.pts[n - 1].amp, a2 = tr.pts[n - 2].amp;
        if (p.amp >= 1.8f * a1 && a1 <= 1.1f * a2) {
          tr.ended = true;
          Track nt;
          nt.pts.push_back({f, p.freq, p.amp});
          nt.lastSt = st;
          nt.lastFrame = f;
          spawn_.push_back(std::move(nt));
          continue;
        }
      }
      const double v = (st - tr.lastSt) / (double)(f - tr.lastFrame);
      tr.vel = clampd(n == 1 ? v : 0.6 * tr.vel + 0.4 * v, -3.0, 3.0);
      tr.lastSt = st;
      tr.lastFrame = f;
      tr.missed = 0;
      tr.pts.push_back({f, p.freq, p.amp});
    }
    for (size_t t = 0; t < act_.size(); ++t)
      if (!trUsed_[t]) ++act_[t].missed;
    for (size_t p = 0; p < pk.size(); ++p) {
      if (pkUsed_[p]) continue;
      Track nt;
      nt.pts.push_back({f, pk[p].freq, pk[p].amp});
      nt.lastSt = sts_[p];
      nt.lastFrame = f;
      spawn_.push_back(std::move(nt));
    }
    next_.clear();
    for (Track& tr : act_) {
      if (tr.ended || tr.missed > kMaxGap) {
        if ((int)tr.pts.size() >= minFrames_) done.push_back(std::move(tr));
      } else {
        next_.push_back(std::move(tr));
      }
    }
    for (Track& tr : spawn_) next_.push_back(std::move(tr));
    act_.swap(next_);
  }

  void finish(std::vector<Track>& done) {
    for (Track& tr : act_)
      if ((int)tr.pts.size() >= minFrames_) done.push_back(std::move(tr));
    act_.clear();
  }

 private:
  struct Cand {
    float d;
    int t, p;
  };
  static constexpr int kMaxGap = 2;
  double binHz_;
  int minFrames_;
  std::vector<Track> act_, next_, spawn_;
  std::vector<Cand> cands_;
  std::vector<double> sts_;
  std::vector<char> pkUsed_, trUsed_;
};

// Noise links jump around by whole bins; a real partial (steady, gliding or with vibrato) has a smooth pitch curve.
bool smoothPitch(const Track& tr, double binHz) {
  const size_t n = tr.pts.size();
  if (n < 3) return true;
  std::vector<double> dBins, dSt;
  for (size_t i = 2; i < n; ++i) {
    const double a = tr.pts[i].freq, b = tr.pts[i - 1].freq, c = tr.pts[i - 2].freq;
    dBins.push_back(std::fabs(a - 2.0 * b + c) / binHz);
    dSt.push_back(std::fabs(semis(a) - 2.0 * semis(b) + semis(c)));
  }
  const size_t mid = dBins.size() / 2;
  std::nth_element(dBins.begin(), dBins.begin() + (long)mid, dBins.end());
  std::nth_element(dSt.begin(), dSt.begin() + (long)mid, dSt.end());
  const double kBins = n <= 3 ? 1.4 : 0.9, kSt = n <= 3 ? 1.0 : 0.6;
  return dBins[mid] < kBins && dSt[mid] < kSt;
}

// --------------------------------------------------------------- track -> partial
bool buildPartial(const Track& tr, const BandSpec& bs, int sr, double dur, const PartialParams& P, int bandIndex,
                  int minFrames, Partial& out) {
  const std::vector<Tp>& pts = tr.pts;
  int first = 0, last = (int)pts.size() - 1;
  // Window smearing makes a note appear a little early / late with a tiny amplitude: trim that.
  while (last - first + 1 > minFrames && pts[(size_t)first].amp < 0.3f * pts[(size_t)first + 1].amp) ++first;
  while (last - first + 1 > minFrames && pts[(size_t)last].amp < 0.3f * pts[(size_t)last - 1].amp) --last;
  const int n = last - first + 1;
  if (n < 1) return false;
  const double hop = (double)bs.H / sr;

  double peak = 0.0, energy = 0.0, heardMax = 0.0;
  for (int i = first; i <= last; ++i) {
    peak = std::max(peak, (double)pts[(size_t)i].amp);
    const double heard = (double)pts[(size_t)i].amp * hearingWeight(pts[(size_t)i].freq);
    heardMax = std::max(heardMax, heard);
    energy += heard * heard * hop;
  }
  if (peak <= 0.0) return false;

  // Frequencies: median of three, then a light binomial smoothing (estimation noise, not vibrato).
  std::vector<double> st((size_t)n);
  for (int i = 0; i < n; ++i) st[(size_t)i] = semis(pts[(size_t)(first + i)].freq);
  std::vector<double> med = st, sm = st;
  for (int i = 1; i + 1 < n; ++i) {
    const double a = st[(size_t)i - 1], b = st[(size_t)i], c = st[(size_t)i + 1];
    med[(size_t)i] = std::max(std::min(a, b), std::min(std::max(a, b), c));
  }
  for (int i = 1; i + 1 < n; ++i) sm[(size_t)i] = 0.25 * med[(size_t)i - 1] + 0.5 * med[(size_t)i] + 0.25 * med[(size_t)i + 1];

  std::vector<TrackPt> raw;
  const double tFirst = pts[(size_t)first].frame * hop, tLast = pts[(size_t)last].frame * hop;
  const double ts = tFirst - 0.8 * hop, te = tLast + 0.8 * hop;
  const double f0 = std::exp2(sm[0] / 12.0), f1 = std::exp2(sm[(size_t)n - 1] / 12.0);
  if (ts > 0.0) raw.push_back({ts, f0, 0.0});
  else if (tFirst > 0.0) raw.push_back({0.0, f0, (double)pts[(size_t)first].amp});
  for (int i = 0; i < n; ++i) {
    const double t = clampd(pts[(size_t)(first + i)].frame * hop, 0.0, dur);
    if (!raw.empty() && t <= raw.back().t) continue;
    raw.push_back({t, std::exp2(sm[(size_t)i] / 12.0), (double)pts[(size_t)(first + i)].amp});
  }
  if (te < dur) {
    if (te > raw.back().t) raw.push_back({te, f1, 0.0});
  } else if (dur > raw.back().t) {
    raw.push_back({dur, f1, (double)pts[(size_t)last].amp});
  }
  if (raw.size() < 2) return false;
  for (const TrackPt& p : raw)
    if (!std::isfinite(p.f) || !std::isfinite(p.a) || p.f < 20.0 || p.f > 22000.0) return false;

  out.pts = simplifyTrack(raw, P.maxPoints, P.ampTolDb, P.freqTolCents, std::max(1e-5, 0.02 * peak));
  out.peak = peak;
  out.energy = energy;
  out.heard = heardMax;
  out.t0 = out.pts.front().t;
  out.t1 = out.pts.back().t;
  out.band = bandIndex;
  return out.t1 - out.t0 >= 0.01;
}

}  // namespace

std::vector<Partial> findPartials(const Signal& x, int sr, const PartialParams& P,
                                  const std::function<void(double)>& progress) {
  const double dur = (double)x.size() / sr;
  const std::vector<BandSpec> bands = makeBandSpecs(sr, dur, P.maxHz);
  const size_t nBands = bands.size();
  std::vector<std::vector<Partial>> found(nBands);
  std::vector<int> totalFrames(nBands);
  std::unique_ptr<std::atomic<int>[]> framesDone(new std::atomic<int>[nBands]);
  for (size_t bi = 0; bi < nBands; ++bi) {
    totalFrames[bi] = (int)(x.size() / (size_t)bands[bi].H) + 2;
    framesDone[bi].store(0);
  }
  std::atomic<bool> stop{false};

  // One band: its own window length, picker and tracker; nothing is shared with the other bands.
  auto runBand = [&](int job) {
    const size_t bi = (size_t)job;
    const BandSpec& bs = bands[bi];
    PeakPicker picker(bs, sr, P);
    const double hop = (double)bs.H / sr;
    const int minFrames = std::max(2, (int)std::ceil(P.minTrackSec / hop));
    Tracker tracker(picker.binHz(), minFrames);
    std::vector<Track> done;
    std::vector<Pk> pk;
    // A finished track becomes a Partial right away (its raw frames are dropped), so memory stays flat.
    auto drain = [&]() {
      for (const Track& tr : done) {
        if (!smoothPitch(tr, picker.binHz())) continue;
        Partial p;
        if (buildPartial(tr, bs, sr, dur, P, (int)bi, minFrames, p)) found[bi].push_back(std::move(p));
      }
      done.clear();
    };
    forEachFrame(x, bs.N, bs.H, [&](int f, const float* mag) {
      picker.pick(mag, pk);
      tracker.step(f, pk, done);
      drain();
      if ((f & 63) == 0) {
        if (stop.load()) throw Cancelled();
        framesDone[bi].store(f);
      }
    });
    tracker.finish(done);
    drain();
    framesDone[bi].store(totalFrames[bi]);
  };
  auto report = [&](int) {
    if (!progress) return;
    double sum = 0.0;
    for (size_t bi = 0; bi < nBands; ++bi) sum += std::min(1.0, (double)framesDone[bi].load() / (double)totalFrames[bi]);
    progress(sum / (double)nBands);
  };
  parallelFor((int)nBands, analysisThreads(), stop, runBand, report);

  std::vector<Partial> result;
  for (std::vector<Partial>& band : found) {
    for (Partial& p : band) result.push_back(std::move(p));
    std::vector<Partial>().swap(band);
  }
  if (progress) progress(1.0);
  return result;
}

}  // namespace analysis
}  // namespace cw
