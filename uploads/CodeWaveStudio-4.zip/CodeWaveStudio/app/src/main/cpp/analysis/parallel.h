// A small fork-join helper: the analysis of a long song is a handful of independent jobs (the four frequency bands of
// the partial finder, then the twelve-second segments of the noise analysis), so it runs on several cores.
#pragma once

#include <algorithm>
#include <atomic>
#include <chrono>
#include <exception>
#include <functional>
#include <mutex>
#include <thread>
#include <vector>

#include "tuning.h"

namespace cw {
namespace analysis {

// How many threads the analysis may use: the cores of the device, at most four (a phone should not be run flat out
// for minutes), and always at least one. Development builds can force a number with A_THREADS.
inline int analysisThreads() {
  const double forced = knob("A_THREADS", 0.0);
  if (forced >= 1.0) return (int)forced;
  const unsigned cores = std::thread::hardware_concurrency();
  return cores == 0 ? 1 : (int)std::min(4u, cores);
}

// Runs fn(0) .. fn(count - 1). With one thread (or one job) it is a plain loop on the calling thread. Otherwise
// worker threads take the jobs in order while the calling thread waits and calls poll(jobsDone) every ~30 ms: that is
// where the caller reports progress and notices a cancel (poll may throw). When poll or a job throws, `stop` is set (a
// job that runs long should look at it now and then and return or throw), the workers are joined and the first
// exception is rethrown on the calling thread. Jobs must write to separate memory; results are therefore the same
// whatever the number of threads.
inline void parallelFor(int count, int threads, std::atomic<bool>& stop, const std::function<void(int)>& job,
                        const std::function<void(int)>& poll) {
  if (count <= 0) return;
  threads = std::max(1, std::min(threads, count));
  if (threads == 1) {
    for (int i = 0; i < count; ++i) {
      job(i);
      if (poll) poll(i + 1);
    }
    return;
  }
  std::atomic<int> next{0}, done{0};
  std::exception_ptr failure;
  std::mutex mu;
  auto fail = [&](std::exception_ptr e) {
    std::lock_guard<std::mutex> lk(mu);
    if (!failure) failure = e;
    stop.store(true);
  };
  auto worker = [&]() {
    for (;;) {
      if (stop.load()) return;
      const int i = next.fetch_add(1);
      if (i >= count) return;
      try {
        job(i);
      } catch (...) {
        fail(std::current_exception());
        return;
      }
      done.fetch_add(1);
    }
  };
  std::vector<std::thread> pool;
  pool.reserve((size_t)threads);
  try {
    for (int t = 0; t < threads; ++t) pool.emplace_back(worker);
  } catch (...) {
    // no more threads available: carry on with the ones that started (or with none)
  }
  if (pool.empty()) {
    worker();  // (no thread could be started: do the work here)
  } else {
    try {
      while (done.load() < count && !stop.load()) {
        std::this_thread::sleep_for(std::chrono::milliseconds(30));
        if (poll) poll(done.load());
      }
    } catch (...) {
      fail(std::current_exception());
    }
  }
  for (std::thread& t : pool) t.join();
  if (failure) std::rethrow_exception(failure);
}

}  // namespace analysis
}  // namespace cw
