// CodeWave Studio - audio -> script analysis: what Simple / Normal / Detailed mean.
#pragma once

#include <cstddef>

#include "partials.h"
#include "voices.h"

namespace cw {
namespace analysis {

struct Params {
  PartialParams partial;  // how hard to look for partials
  VoiceParams voice;      // how they are collapsed into harmonic stacks
  double toneRelDb;       // keep partials whose weighted peak is within this of the strongest
  int nBands;             // noise bands (the "everything else" channels)
  double noiseRelDb;      // noise bands this far below the loudest (weighted) part are dropped
  double bandTolDb;       // noise band envelope fit tolerance (dB); the shared point budget usually binds first
  size_t maxChars;        // size limit of the generated script for a short sound (characters) ...
  double charsPerSec;     // ... and for a long one: this many characters per second of audio (the larger of the two)
  double charShare;       // share of that the noise bands may use
  double minBandPtsPerSec;  // every noise band gets at least this many envelope points per second
  const char* label;

  // The size limit for `seconds` of audio. The text grows with the length of the audio, so a whole song gets as much
  // detail per second as a short clip (a fixed limit would spread the same text over ten times the music).
  size_t charBudget(double seconds) const;
};

constexpr size_t kLargestScript = 36u * 1024u * 1024u;  // engine limit 48 MB

// detail: 0 = Simple, 1 = Normal, 2 = Detailed (anything else is clamped).
Params paramsFor(int detail);

}  // namespace analysis
}  // namespace cw
