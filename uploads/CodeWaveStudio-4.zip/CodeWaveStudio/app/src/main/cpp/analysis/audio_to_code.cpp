#include "audio_to_code.h"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <new>
#include <utility>

#include "../dsp/dsp.h"
#include "curve_fit.h"
#include "detail_levels.h"
#include "noise_model.h"
#include "partials.h"
#include "script_text.h"
#include "spectral.h"
#include "tuning.h"
#include "voices.h"

namespace cw {
namespace {

using namespace analysis;

constexpr double kMaxAnalysisSec = 900.0;   // 15 minutes (the engine's longest sound is 16)
constexpr int kMaxCommandsUsed = 590000;    // engine limit is 600000
constexpr int kMaxLayersUsed = 95000;       // engine limit is 100000 layer instances
constexpr double kChunkSec = 20.0;          // noise-band layers are cut into pieces of at most this length
constexpr double kCharsPerPair = 8.5;       // text size of one envelope.deltas (milliseconds, value) pair
constexpr int kMinBandPts = 24;             // a band is worth at least this many points
constexpr size_t kHeaderReserve = 1600;     // header comments, sound.begin / normalize / end
constexpr double kBandOverhead = 135.0;     // text size of one noise layer around its envelope
constexpr double kLongSec = 45.0;           // up to this length a clip is treated as one piece
constexpr double kBlockSec = 20.0;          // longer audio: the text budget is spent block by block ...
constexpr double kFitSec = 30.0;            // ... and the noise envelopes are fitted piece by piece

// Reports progress and stops the work when the caller asks to (by throwing Cancelled, which unwinds the analysis).
struct Progress {
  const std::function<bool(float)>* fn = nullptr;
  void at(double f) const {
    if (!fn || !*fn) return;
    if (!(*fn)((float)std::min(1.0, std::max(0.0, f)))) throw Cancelled();
  }
  // A callback for a sub-task that covers [a, b] of the whole.
  std::function<void(double)> span(double a, double b) const {
    const Progress self = *this;
    return [self, a, b](double f) { self.at(a + (b - a) * f); };
  }
};

// ------------------------------------------------------------------ noise layers
struct NoiseChunk {
  double t0 = 0, len = 0;
  int band = 0;
  std::vector<Pt2> env;  // (time since t0, 0..1 of the band's loudest level)
};
struct NoiseBand {
  double vmax = 0;  // white-noise volume at the band's loudest moment (input peak = 1)
  std::vector<NoiseChunk> chunks;
};

std::string emitNoise(const NoiseBand& nb, const NoiseChunk& c, const Bands& B, double S) {
  const double vol = clampd(nb.vmax / S, 0.0, 4.0);
  const size_t j = (size_t)c.band;
  std::string s = "layer.begin(" + fmt(c.t0, 3) + ", " + fmt(c.len, 3) + ");   // noise " + fmt(B.edge[j], 0) + "-" +
                  fmt(B.edge[j + 1], 0) + " Hz\n";
  s += "  noise.add(" + fmtAmp(vol) + ");\n";
  s += "  filter.bandpass(" + fmt(B.center[j], 0) + ", " + fmt(B.q[j], 2) + ", order = 2);\n";
  s += envelopeDeltasText(c.env);
  s += "layer.end();\n";
  return s;
}

// ------------------------------------------------------------------ voices
std::string voiceText(const Voice& v, double S) {
  std::string s = partialTrackText(v.pts, S);
  if (!v.gains.empty()) s += partialHarmonicsText(v.gains);
  if (!v.dyn.empty()) s += partialDynamicsText(v.dyn);
  return s;
}
int voiceCommands(const Voice& v) { return 1 + (v.gains.empty() ? 0 : 1) + (v.dyn.empty() ? 0 : 1); }

// What the emitted voices sound like, rendered with the engine's own partial renderer (analysis by synthesis).
// Renders any stretch of the sound on demand, so the noise analysis can work through a long song piece by piece -
// and from several threads at once: render() only reads the voices.
class TonalRenderer {
 public:
  TonalRenderer(const std::vector<const Voice*>& chosen, int sr) : sr_(sr), voices_(chosen) {
    std::sort(voices_.begin(), voices_.end(), [](const Voice* a, const Voice* b) { return a->t0 < b->t0; });
  }

  // Overwrites dst[0, count) with the sound of samples [start, start + count).
  void render(long start, int count, float* dst) const {
    std::fill(dst, dst + count, 0.0f);
    const double ta = (double)start / sr_, tb = (double)(start + count) / sr_;
    std::vector<double> flat, harm, dyn;
    for (const Voice* v : voices_) {
      if (v->t0 > tb) break;
      if (v->t1 < ta) continue;
      flat.clear();
      harm.clear();
      dyn.clear();
      for (const TrackPt& p : v->pts) {
        flat.push_back(p.t - ta);  // (points outside the buffer are clipped by the renderer)
        flat.push_back(p.f);
        flat.push_back(p.a);
      }
      for (float g : v->gains) harm.push_back((double)g);
      for (float e : v->dyn) dyn.push_back((double)e);
      renderPartialTrack(flat.data(), v->pts.size(), harm.empty() ? nullptr : harm.data(), harm.size(),
                         dyn.empty() ? nullptr : dyn.data(), dyn.size(), dst, count, 1.0, 1.0, sr_, nullptr);
    }
  }

 private:
  int sr_;
  std::vector<const Voice*> voices_;
};

// ------------------------------------------------------------------ clean-up
// Reads the whole signal in short pieces and calls fn(block, count) for each.
template <class Fn>
void forEachBlock(const Signal& x, Fn fn) {
  constexpr int kBlock = 65536;
  std::vector<float> buf((size_t)kBlock);
  for (size_t i = 0; i < x.size(); i += (size_t)kBlock) {
    const int c = (int)std::min((size_t)kBlock, x.size() - i);
    x.read((long)i, c, buf.data());
    fn(buf.data(), c);
  }
}

// Removes the DC offset, scales the peak to 1 and cuts the silence (below -50 dB of the loudest 10 ms) off both ends.
// Nothing is copied: the result is a view with a gain and an offset.
bool prepare(const Signal& in, int sr, Signal& out, std::string& error) {
  double sum = 0.0;
  forEachBlock(in, [&](const float* b, int c) {
    for (int i = 0; i < c; ++i) sum += (double)b[i];
  });
  const double mean = sum / (double)in.size();
  double peak = 0.0;
  forEachBlock(in, [&](const float* b, int c) {
    for (int i = 0; i < c; ++i) peak = std::max(peak, std::fabs((double)b[i] - mean));
  });
  if (peak < 1e-4) {
    error = "The audio is silent.";
    return false;
  }
  const Signal norm = in.normalised(mean, 1.0 / peak);
  out = norm;
  const int blk = std::max(1, sr / 100);
  const size_t nBlk = norm.size() / (size_t)blk;
  std::vector<double> rms(nBlk, 0.0);
  std::vector<float> buf((size_t)blk);
  double mx = 0.0;
  for (size_t b = 0; b < nBlk; ++b) {
    norm.read((long)(b * (size_t)blk), blk, buf.data());
    double s = 0.0;
    for (int i = 0; i < blk; ++i) s += (double)buf[(size_t)i] * buf[(size_t)i];
    rms[b] = std::sqrt(s / blk);
    mx = std::max(mx, rms[b]);
  }
  const double thr = mx * 0.00316;
  size_t fb = 0, lb = nBlk;
  while (fb < nBlk && rms[fb] < thr) ++fb;
  while (lb > fb && rms[lb - 1] < thr) --lb;
  if (lb > fb) {
    const long s0 = std::max(0L, (long)(fb * (size_t)blk) - (long)(0.015 * sr));
    const long s1 = std::min((long)norm.size(), (long)(lb * (size_t)blk) + (long)(0.06 * sr));
    if (s1 - s0 >= (long)(0.05 * sr)) out = norm.slice((size_t)s0, (size_t)(s1 - s0));
  }
  return true;
}

// ------------------------------------------------------------------ the pipeline
AnalyzeResult analyseImpl(const Signal& input, int sr, const AnalyzeOptions& opt) {
  AnalyzeResult R;
  Lap lap;
  const Progress prog{&opt.progress};
  const Params P = paramsFor(opt.detail);
  if (input.size() < 1024 || sr < 4000 || sr > 400000) {
    R.error = "The audio is too short to analyse.";
    return R;
  }
  prog.at(0.0);

  // ---- 1. clean-up
  Signal x;
  if (!prepare(input.slice(0, std::min(input.size(), (size_t)(kMaxAnalysisSec * sr))), sr, x, R.error)) return R;
  const double dur = (double)x.size() / sr;
  R.seconds = dur;
  const size_t limitChars = P.charBudget(dur);
  prog.at(0.02);

  // ---- 2. text budget: the noise bands take a fixed share, the partials get the rest.
  // Fewer, wider bands with a usable time resolution beat many bands that cannot follow the rhythm, so long
  // clips get fewer bands.
  const size_t noiseChars = (size_t)(P.charShare * (double)(limitChars - kHeaderReserve));
  const size_t toneChars = limitChars - kHeaderReserve - noiseChars;
  const double chunksPerBand = std::ceil(dur / kChunkSec) + 1.0;
  const double bandOverhead = chunksPerBand * kBandOverhead;
  const double minPtsPerBand = std::max((double)kMinBandPts, 12.0 * dur);  // enough to follow a beat
  const int nbAffordable = (int)(((double)noiseChars / kCharsPerPair) / (minPtsPerBand + bandOverhead / kCharsPerPair));
  const Bands B = makeBands(std::max(4, std::min(P.nBands, nbAffordable)), sr);

  lap("cleanup");
  // ---- 3. partials -> voices, judged by how audible they are
  std::vector<Partial> partials = findPartials(x, sr, P.partial, prog.span(0.02, 0.50));
  lap("findPartials");
  double strongest = 0.0;
  for (const Partial& p : partials) strongest = std::max(strongest, p.heard);
  const double keepHeard = strongest * std::pow(10.0, -P.toneRelDb / 20.0);
  partials.erase(std::remove_if(partials.begin(), partials.end(), [&](const Partial& p) { return p.heard < keepHeard; }),
                 partials.end());
  const size_t nPartials = partials.size();
  (void)nPartials;  // (only logged in development builds)
  std::vector<Voice> voices = buildVoices(std::move(partials), P.voice);
  lap("buildVoices");
  prog.at(0.55);
  {
    size_t stacksBuilt = 0, memberSum = 0;
    for (const Voice& v : voices)
      if (!v.gains.empty()) {
        ++stacksBuilt;
        memberSum += (size_t)v.members;
      }
    A2C_LOG("[a2c] partials kept=%zu -> voices=%zu (stacks=%zu holding %zu partials)\n", nPartials, voices.size(), stacksBuilt, memberSum);
  }

  // ---- 4. choose what fits: most audible energy per character first. A long piece is cut into blocks of
  // kBlockSec; every block gets its share of the text (what a block does not use passes on to the next one), so the
  // loud passages cannot take the detail away from the quiet ones.
  struct Pick {
    const Voice* v;
    size_t chars;
    double density;
  };
  const bool multi = dur > kLongSec;
  const double blockSec = multi ? kBlockSec : std::max(dur, 1e-3);
  const int nBlocks = multi ? std::max(1, (int)std::ceil(dur / blockSec)) : 1;
  std::vector<std::vector<Pick>> blocks((size_t)nBlocks);
  size_t allChars = 0;
  for (const Voice& v : voices) {
    const size_t len = voiceText(v, 1.0).size();
    const int b = multi ? std::max(0, std::min(nBlocks - 1, (int)std::floor(v.t0 / blockSec))) : 0;
    blocks[(size_t)b].push_back({&v, len, v.energy / (double)(len + 30)});
    allChars += len;
  }
  // commands the noise layers will need
  const int noiseCmdReserve = (int)(5.0 * (double)P.nBands * chunksPerBand) + 32;
  std::vector<const Voice*> chosen;
  int cmds = 3;  // sound.begin, sound.normalize, sound.end
  size_t tChars = 0;
  double carry = 0.0;
  for (int b = 0; b < nBlocks; ++b) {
    std::vector<Pick>& pk = blocks[(size_t)b];
    std::sort(pk.begin(), pk.end(), [](const Pick& a, const Pick& c) { return a.density > c.density; });
    const double blockLen = multi ? std::min(blockSec, dur - (double)b * blockSec) : dur;
    const double share = (double)toneChars * blockLen / dur;
    const double budget = share + std::min(carry, share);
    double used = 0.0;
    for (const Pick& pk1 : pk) {
      const int c = voiceCommands(*pk1.v);
      if (cmds + c > kMaxCommandsUsed - noiseCmdReserve) continue;
      if (used + (double)pk1.chars > budget) continue;
      cmds += c;
      used += (double)pk1.chars;
      tChars += pk1.chars;
      chosen.push_back(pk1.v);
    }
    carry = budget - used;
  }
  blocks.clear();

  {
    double eAll = 0.0, eChosen = 0.0;
    for (const Voice& v : voices) eAll += v.energy;
    for (const Voice* v : chosen) eChosen += v->energy;
    A2C_LOG("[a2c] candidates=%zu (%zu chars) chosen=%zu (%zu chars of %zu); energy chosen/all=%.3f\n", voices.size(), allChars, chosen.size(), tChars, toneChars, eAll > 0 ? eChosen / eAll : 0.0);
  }
  (void)allChars;

  if (knob("A_NOTONES", 0) > 0.5) chosen.clear();  // (development: noise only)

  // ---- 5. noise bands: the rest of the sound, with a fine envelope each
  TonalRenderer tonalRenderer(chosen, sr);
  TonalFn tonalFn;
  if (!chosen.empty()) tonalFn = [&tonalRenderer](long start, int count, float* dst) { tonalRenderer.render(start, count, dst); };
  const NoiseLevels nl = analyseNoise(x, tonalFn, sr, B, prog.span(0.55, 0.92));
  lap("analyseNoise");
  double toneHeard = 0.0;
  for (const Voice* v : chosen) toneHeard = std::max(toneHeard, v->heard / std::sqrt(2.0));
  std::vector<double> bandMax((size_t)B.nb, 0.0), bandHeard((size_t)B.nb, 0.0);
  double ref = toneHeard;
  for (int i = 0; i < B.nb; ++i) {
    for (float v : nl.v[(size_t)i]) bandMax[(size_t)i] = std::max(bandMax[(size_t)i], (double)v);
    bandHeard[(size_t)i] = bandMax[(size_t)i] / std::sqrt(3.0) * hearingWeight(B.center[(size_t)i]);
    ref = std::max(ref, bandHeard[(size_t)i]);
  }
  std::vector<int> active;
  for (int i = 0; i < B.nb; ++i)
    if (bandHeard[(size_t)i] >= ref * std::pow(10.0, -P.noiseRelDb / 20.0) && bandMax[(size_t)i] > 0.0) active.push_back(i);
  if (knob("A_NONOISE", 0) > 0.5) active.clear();  // (development: partials only)
  const double overhead = (double)active.size() * bandOverhead;
  const int totalPts = (int)std::max(0.0, ((double)noiseChars - overhead) / kCharsPerPair);
  std::vector<double> envFloors = {0.05, 0.015, 0.004, 0.001};
  if (knob("A_ENVFLOOR", 0) > 0) envFloors = {knob("A_ENVFLOOR", 0)};  // (development)

  // the levels of every active band as an envelope (relative to the band's loudest moment), fitted one stretch of
  // the audio at a time: the points of a stretch go wherever a dB of error matters most in that stretch
  std::vector<NoiseBand> bands((size_t)B.nb);
  for (int i : active) bands[(size_t)i].vmax = bandMax[(size_t)i];
  std::vector<double> bandWeight((size_t)B.nb, 1.0);
  for (int i : active) bandWeight[(size_t)i] = clampd(std::sqrt(bandHeard[(size_t)i] / std::max(1e-12, ref)), 0.3, 1.0);

  const long nFrames = active.empty() ? 0 : (long)nl.v[(size_t)active[0]].size();
  const double hop = nl.hopSec;
  const long winFrames = multi ? std::max(8L, (long)std::lround(kFitSec / hop)) : nFrames;
  for (long w0 = 0; w0 + 1 < nFrames;) {
    long w1 = std::min(nFrames - 1, w0 + winFrames);  // last frame of the stretch (shared with the next one)
    if (nFrames - 1 - w1 < winFrames / 4) w1 = nFrames - 1;
    std::vector<std::vector<Pt2>> envs;
    std::vector<int> envBand;
    std::vector<EnvCurve> curves;
    envs.reserve(active.size());
    for (int i : active) {
      const double vmax = bands[(size_t)i].vmax;
      const std::vector<float>& v = nl.v[(size_t)i];
      std::vector<Pt2> env;
      for (long m = w0; m <= w1; ++m) {
        const double t = std::min(dur, (double)m * hop);
        if (!env.empty() && t <= env.back().first && m < w1) continue;
        env.push_back({std::max(t, env.empty() ? 0.0 : env.back().first), (double)v[(size_t)m] / vmax});
      }
      if (env.size() < 2) continue;
      envs.push_back(std::move(env));
      envBand.push_back(i);
    }
    for (size_t e = 0; e < envs.size(); ++e) curves.push_back({&envs[e], P.bandTolDb, bandWeight[(size_t)envBand[e]]});
    const double share = (double)(w1 - w0) / (double)std::max(1L, nFrames - 1);
    const int winPts = (int)std::lround((double)totalPts * share);
    const int minPts = (int)std::lround(P.minBandPtsPerSec * (double)(w1 - w0) * hop);
    const std::vector<std::vector<Pt2>> fitted = simplifyEnvelopes(curves, winPts, envFloors, minPts);
    for (size_t e = 0; e < fitted.size(); ++e) {
      const int i = envBand[e];
      NoiseBand& nb = bands[(size_t)i];
      const std::vector<Pt2>& pl = fitted[e];
      for (size_t s0 = 0; s0 + 1 < pl.size();) {
        size_t e0 = s0 + 1;
        while (e0 + 1 < pl.size() && pl[e0 + 1].first - pl[s0].first <= kChunkSec && e0 + 1 - s0 < 1500) ++e0;
        double hi = 0.0;
        for (size_t k = s0; k <= e0; ++k) hi = std::max(hi, pl[k].second);
        NoiseChunk c;
        c.band = i;
        c.t0 = round3(pl[s0].first);
        c.len = round3(round3(pl[e0].first) - c.t0);
        if (hi >= 0.004 && c.len >= 0.01 && c.t0 < dur) {
          for (size_t k = s0; k <= e0; ++k)
            c.env.push_back({std::max(0.0, std::min(c.len, round3(pl[k].first - c.t0))), pl[k].second});
          c.env.back().first = c.len;
          nb.chunks.push_back(std::move(c));
        }
        s0 = e0;
      }
    }
    w0 = w1;
  }

  lap("fitEnvelopes");
  prog.at(0.94);
  // ---- 6. assemble
  double S = 1e-9;
  for (const Voice* v : chosen) S = std::max(S, v->peak);
  for (const NoiseBand& nb : bands)
    if (!nb.chunks.empty()) S = std::max(S, nb.vmax);

  std::string noiseText;
  int noiseBandsOut = 0, layers = 0;
  for (const NoiseBand& nb : bands) {
    if (nb.chunks.empty()) continue;
    ++noiseBandsOut;
    for (const NoiseChunk& c : nb.chunks) {
      if (cmds + 5 > kMaxCommandsUsed || layers + 1 > kMaxLayersUsed) break;
      noiseText += emitNoise(nb, c, B, S);
      cmds += 5;
      ++layers;
    }
  }
  std::vector<const Voice*> out;
  size_t total = kHeaderReserve + noiseText.size();
  std::vector<const Voice*> byStart = chosen;
  std::sort(byStart.begin(), byStart.end(), [](const Voice* a, const Voice* b) { return a->t0 < b->t0; });
  std::string toneText;
  toneText.reserve(tChars + tChars / 8 + 64);
  int stacks = 0;
  // The voices were chosen by their size at volume scale 1; written at the final scale they come out a few percent
  // longer or shorter. The size limit is a target, not a wall, so the partials are allowed that margin: otherwise
  // the last voices in time (the end of the song) would be the ones to fall off.
  const size_t toneAllowance = toneChars + toneChars / 16 + 4096;
  const size_t hardLimit = kLargestScript + kLargestScript / 4;  // far below the engine's limit
  for (const Voice* v : byStart) {
    if (v->peak / S < 0.0003) continue;
    const std::string txt = voiceText(*v, S);
    if (toneText.size() + txt.size() > toneAllowance || total + txt.size() > hardLimit) continue;
    total += txt.size();
    toneText += txt;
    out.push_back(v);
    if (!v->gains.empty()) ++stacks;
  }
  if (out.empty() && noiseText.empty()) {
    R.error = "No clear sound could be found in this audio.";
    return R;
  }

  double topHz = 0.0, topAmp = 0.0;
  for (const Voice* v : out)
    if (v->peak > topAmp) {
      topAmp = v->peak;
      for (const TrackPt& p : v->pts)
        if (p.a >= v->peak) topHz = p.f;
    }

  std::string name = sanitizeName(opt.name);
  if (name.empty()) name = "audio";
  std::string text;
  text.reserve(total + 256);
  text += "// CodeWave script made from \"" + name + "\" (" + clockText(opt.startSeconds) + " - " +
          clockText(opt.startSeconds + dur) + ")\n";
  text += std::string("// Detail level: ") + P.label + ". " + std::to_string(out.size()) + " partials" +
          (stacks > 0 ? " (" + std::to_string(stacks) + " harmonic stacks)" : std::string()) + " + " +
          std::to_string(noiseBandsOut) + " noise bands. An approximation of the audio, not a copy.\n";
  if (topHz > 0.0) text += "// Strongest partial: " + noteName(topHz) + " (" + fmtHz(topHz) + " Hz)\n";
  text += "// partial.track = a sine whose pitch and volume follow the points (time, Hz, volume); partial.harmonics adds its overtones\n";
  text += "// noise = band-passed noise layers: everything the partials do not cover (drums, hiss, rumble, breath)\n";
  text += "sound.begin(" + fmt(round3(std::max(0.05, dur)), 3) + ");\n";
  if (!out.empty()) text += "\n// ---- partials\n" + toneText;
  if (!noiseText.empty()) text += "\n// ---- noise\n" + noiseText;
  text += "\nsound.normalize(0.9);\nsound.end();\n";

  R.ok = true;
  R.script = std::move(text);
  R.tones = (int)out.size();
  R.noiseBands = noiseBandsOut;
  R.commands = cmds;
  char sum[160];
  std::snprintf(sum, sizeof sum, "%d partials + %d noise bands, %.1f s", R.tones, R.noiseBands, dur);
  R.summary = sum;
  prog.at(1.0);
  return R;
}

// 88.2 / 96 kHz -> half rate (only < 16 kHz matters here)
std::vector<float> halveRate(const std::vector<float>& x) {
  std::vector<float> y(x.size() / 2);
  for (size_t i = 0; i < y.size(); ++i) {
    const float a = x[i == 0 ? 0 : 2 * i - 1], b = x[2 * i], c = x[std::min(x.size() - 1, 2 * i + 1)];
    y[i] = 0.25f * a + 0.5f * b + 0.25f * c;
  }
  return y;
}

AnalyzeResult guarded(const std::function<AnalyzeResult()>& run) {
  try {
    return run();
  } catch (const Cancelled&) {
    AnalyzeResult r;
    r.cancelled = true;
    r.error = "The conversion was cancelled.";
    return r;
  } catch (const std::bad_alloc&) {
    AnalyzeResult r;
    r.error = "Not enough memory to analyse this audio.";
    return r;
  } catch (...) {
    AnalyzeResult r;
    r.error = "The audio could not be analysed.";
    return r;
  }
}

AnalyzeResult analyseFloats(const float* mono, size_t frames, int sampleRate, const AnalyzeOptions& opt) {
  AnalyzeResult r;
  if (!mono || frames < 1024 || sampleRate < 4000 || sampleRate > 400000) {
    r.error = "The audio is too short to analyse.";
    return r;
  }
  bool finite = true;
  for (size_t i = 0; i < frames && finite; ++i) finite = std::isfinite(mono[i]);
  int sr = sampleRate;
  if (finite && sr <= 50000) return analyseImpl(Signal::ofFloats(mono, frames), sr, opt);
  // rare cases: damaged samples or a very high sample rate need a (cleaned) copy
  std::vector<float> x(mono, mono + frames);
  for (float& v : x)
    if (!std::isfinite(v)) v = 0.0f;
  while (sr > 50000 && x.size() > 8) {
    x = halveRate(x);
    sr /= 2;
  }
  return analyseImpl(Signal::ofFloats(x.data(), x.size()), sr, opt);
}

}  // namespace

AnalyzeResult analyzeAudioToScript(const float* mono, size_t frames, int sampleRate, const AnalyzeOptions& opt) {
  return guarded([&]() { return analyseFloats(mono, frames, sampleRate, opt); });
}

AnalyzeResult analyzeAudioToScript16(const int16_t* mono, size_t frames, int sampleRate, const AnalyzeOptions& opt) {
  return guarded([&]() {
    AnalyzeResult r;
    if (!mono || frames < 1024 || sampleRate < 4000 || sampleRate > 400000) {
      r.error = "The audio is too short to analyse.";
      return r;
    }
    if (sampleRate <= 50000) return analyseImpl(Signal::ofInt16(mono, frames), sampleRate, opt);
    std::vector<float> x(frames);  // very high sample rates: a float copy at half rate
    for (size_t i = 0; i < frames; ++i) x[i] = (float)mono[i] / 32768.0f;
    return analyseFloats(x.data(), x.size(), sampleRate, opt);
  });
}

}  // namespace cw
