// CodeWave Studio - audio -> script analysis: spectral building blocks (FFT, STFT, hearing weight).
#pragma once

#include <cmath>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <vector>

namespace cw {
namespace analysis {

// A read-only view of mono samples (floats or 16-bit integers) with a gain and an offset applied on the fly:
// value = raw * scale + offset, always in "full scale = 1" units. It lets the analysis walk through a recording
// of any length without making a float copy of it (10 minutes at 44.1 kHz = 106 MB as floats, 53 MB as 16-bit
// integers) and without copying it again to normalise it or to cut off its silent ends.
class Signal {
 public:
  Signal() = default;
  static Signal ofFloats(const float* d, size_t n) {
    Signal s;
    s.f_ = d;
    s.n_ = n;
    return s;
  }
  static Signal ofInt16(const int16_t* d, size_t n) {
    Signal s;
    s.i_ = d;
    s.n_ = n;
    s.scale_ = 1.0 / 32768.0;
    return s;
  }
  size_t size() const { return n_; }
  // The same samples as (value - mean) * gain.
  Signal normalised(double mean, double gain) const {
    Signal s = *this;
    s.scale_ = scale_ * gain;
    s.offset_ = (offset_ - mean) * gain;
    return s;
  }
  // [begin, begin + len) of this view (shares the data).
  Signal slice(size_t begin, size_t len) const {
    Signal s = *this;
    if (begin > n_) begin = n_;
    if (len > n_ - begin) len = n_ - begin;
    if (f_) s.f_ = f_ + begin;
    if (i_) s.i_ = i_ + begin;
    s.n_ = len;
    return s;
  }
  // dst[i] = sample(start + i) for i < count; zero outside [0, size()).
  void read(long start, int count, float* dst) const;

 private:
  const float* f_ = nullptr;
  const int16_t* i_ = nullptr;
  size_t n_ = 0;
  double scale_ = 1.0, offset_ = 0.0;
};

inline int nextPow2(int v) {
  int p = 1;
  while (p < v) p <<= 1;
  return p;
}

inline double semis(double hz) { return 12.0 * std::log2(hz); }

// How much a frequency matters to a listener (A-weighting, softened, 1.0 at 1 kHz). Used only to decide what
// is worth spending commands on - never to change a level.
double hearingWeight(double hz);

// Hann-window STFT. Frame f is centred on sample f*H (zero padded at both ends), frames = len/H + 2. Two real
// frames share one complex FFT. cb(frame, |X|[0..N/2]) receives the raw (unnormalised) magnitudes.
//   amplitude of a steady sine  = |X| * hannAmp(N)
//   variance share of a bin     = |X|^2 * hannPow(N)   (sums over bins to the signal variance)
using FrameFn = std::function<void(int frame, const float* mag)>;
void forEachFrame(const Signal& x, int N, int H, const FrameFn& cb);
inline void forEachFrame(const std::vector<float>& x, int N, int H, const FrameFn& cb) {
  forEachFrame(Signal::ofFloats(x.data(), x.size()), N, H, cb);
}

inline double hannAmp(int N) { return 4.0 / N; }
inline double hannPow(int N) { return 16.0 / (3.0 * (double)N * (double)N); }

}  // namespace analysis
}  // namespace cw
