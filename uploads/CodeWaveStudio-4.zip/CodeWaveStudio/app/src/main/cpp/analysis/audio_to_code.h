// CodeWave Studio - audio -> script analysis.
//
// Takes decoded mono PCM (from an mp3 / m4a / wav ... decoded by the platform) and writes a CodeWave script that
// approximates it:
//   * partials - sinusoids found by multi-resolution short-time spectra and tracked over time (partials.*), the
//                harmonic ones collapsed into stacks that share one pitch and one volume curve (voices.*); each
//                voice is one partial.track (+ partial.harmonics / partial.dynamics) command;
//   * noise    - everything the partials do not explain (drums, breath, hiss, rumble, reverb) as band-passed noise
//                layers whose level over time is fitted with envelope.deltas (noise_model.*), measured against
//                what the emitted partials will actually sound like.
// The pipeline lives in this directory, one module per step; audio_to_code.cpp only orchestrates it and spends the
// character budget of the chosen detail level (detail_levels.*). The result is an approximation, not a copy: the
// same kind of code a person could write to imitate the sound, and it always stays inside the script limits.
#pragma once

#include <cstddef>
#include <cstdint>
#include <functional>
#include <string>

namespace cw {

struct AnalyzeOptions {
  int detail = 1;             // 0 = simple, 1 = normal, 2 = detailed
  std::string name;           // source name for the header comment (sanitised before use)
  double startSeconds = 0.0;  // where in the source file the analysed part starts (header only)
  // Called now and then with the share of the work that is done (0..1). Return false to stop: the analysis then
  // ends with AnalyzeResult::cancelled set. Called on the thread that runs the analysis.
  std::function<bool(float)> progress;
};

struct AnalyzeResult {
  bool ok = false;
  bool cancelled = false;  // the progress callback asked to stop
  std::string error;    // set when !ok
  std::string script;   // set when ok
  std::string summary;  // one line for the UI, e.g. "42 partials + 5 noise bands, 3.2 s"
  int tones = 0;        // partial.track commands written (a harmonic stack counts once)
  int noiseBands = 0;
  int commands = 0;
  double seconds = 0.0;
};

// `mono` holds `frames` samples at `sampleRate` Hz. At most the first 15 minutes are used. The text grows with the
// length of the audio (see analysis/detail_levels.*): a whole song gets as much detail per second as a short clip.
// The memory used besides the audio itself is small and does not grow with the length (the audio is read in short
// pieces), so a ten minute song can be analysed on a phone.
AnalyzeResult analyzeAudioToScript(const float* mono, size_t frames, int sampleRate, const AnalyzeOptions& opt);

// The same for 16-bit samples (half the memory of floats: 10 minutes at 44.1 kHz are 53 MB).
AnalyzeResult analyzeAudioToScript16(const int16_t* mono, size_t frames, int sampleRate, const AnalyzeOptions& opt);

}  // namespace cw
