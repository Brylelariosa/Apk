#include "detail_levels.h"

#include <algorithm>

#include "tuning.h"

namespace cw {
namespace analysis {
namespace {

const Params& preset(int detail) {
  static const Params kPresets[3] = {
      // Simple: short code (about 5 000 characters per second of audio)
      {/*partial*/ {12.0, -62.0, 50.0, 48, 0.050, 2.5, 15.0, 24, 10000.0},
       /*voice*/ {true, 5.5, 0.55, 18, 2.5, 15.0, 24},
       /*toneRelDb*/ 40.0, /*nBands*/ 12, /*noiseRelDb*/ 50.0, /*bandTolDb*/ 2.0, /*maxChars*/ 60000,
       /*charsPerSec*/ 5000.0, /*charShare*/ 0.45, /*minBandPtsPerSec*/ 8.0, "Simple"},
      // Normal (about 9 000 characters per second): what "Detailed" used to be
      {{10.0, -70.0, 58.0, 96, 0.035, 2.2, 12.0, 40, 12000.0},
       {true, 5.0, 0.55, 24, 2.2, 12.0, 40},
       55.0, 16, 55.0, 1.2, 150000, 9000.0, 0.42, 8.0, "Normal"},
      // Detailed (about 20 000 characters per second): everything that is audible. A test piece scores a
      // log-mel error of 3.6 dB here against 4.3 at "Normal" and 5.3 at the old "Normal" (tools/eval).
      {{8.0, -80.0, 70.0, 150, 0.025, 1.2, 8.0, 64, 12000.0},
       {true, 5.0, 0.55, 24, 2.2, 12.0, 40},
       70.0, 24, 65.0, 0.8, 250000, 20000.0, 0.35, 8.0, "Detailed"},
  };
  return kPresets[detail < 0 ? 0 : (detail > 2 ? 2 : detail)];
}

}  // namespace

size_t Params::charBudget(double seconds) const {
  const double want = std::max((double)maxChars, charsPerSec * seconds);
  return (size_t)std::min(want, (double)kLargestScript);
}

Params paramsFor(int detail) {
  Params P = preset(detail);
  // (development builds only: every value can be overridden from the environment, see tuning.h)
  P.partial.snrDb = knob("A_SNR", P.partial.snrDb);
  P.partial.floorDb = knob("A_FLOOR", P.partial.floorDb);
  P.partial.dynDb = knob("A_DYN", P.partial.dynDb);
  P.partial.maxPeaks = (int)knob("A_PEAKS", P.partial.maxPeaks);
  P.partial.minTrackSec = knob("A_MINT", P.partial.minTrackSec);
  P.partial.ampTolDb = knob("A_ATOL", P.partial.ampTolDb);
  P.partial.freqTolCents = knob("A_FTOL", P.partial.freqTolCents);
  P.partial.maxPoints = (int)knob("A_PTS", P.partial.maxPoints);
  P.partial.maxHz = knob("A_MAXHZ", P.partial.maxHz);
  P.voice.stacks = knob("A_STACKS", P.voice.stacks ? 1 : 0) > 0.5;
  P.voice.maxFitErrDb = knob("A_FIT", P.voice.maxFitErrDb);
  P.voice.minCoverage = knob("A_COV", P.voice.minCoverage);
  P.voice.maxHarmonics = (int)knob("A_MAXK", P.voice.maxHarmonics);
  P.voice.ampTolDb = knob("A_VATOL", P.voice.ampTolDb);
  P.voice.freqTolCents = knob("A_VFTOL", P.voice.freqTolCents);
  P.voice.maxPoints = (int)knob("A_VPTS", P.voice.maxPoints);
  P.toneRelDb = knob("A_REL", P.toneRelDb);
  P.nBands = (int)knob("A_NB", P.nBands);
  P.noiseRelDb = knob("A_NREL", P.noiseRelDb);
  P.bandTolDb = knob("A_BTOL", P.bandTolDb);
  P.charShare = knob("A_SHARE", P.charShare);
  P.maxChars = (size_t)knob("A_CHARS", (double)P.maxChars);
  P.charsPerSec = knob("A_CPS", P.charsPerSec);
  P.minBandPtsPerSec = knob("A_MINBPS", P.minBandPtsPerSec);
  return P;
}

}  // namespace analysis
}  // namespace cw
