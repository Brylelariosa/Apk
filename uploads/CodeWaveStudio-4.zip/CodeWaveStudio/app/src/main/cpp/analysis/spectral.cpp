#include "spectral.h"

#include <algorithm>
#include <utility>

#include "../dsp/common.h"

namespace cw {
namespace analysis {
namespace {

// In-place radix-2 FFT. Twiddles are stored per stage (contiguous), bit reversal is precomputed.
struct Fft {
  int n;
  std::vector<double> twr, twi;  // stage with half-length h starts at index h - 1
  std::vector<int> rev;
  explicit Fft(int size) : n(size), twr((size_t)size), twi((size_t)size), rev((size_t)size) {
    for (int half = 1; half < n; half <<= 1) {
      for (int k = 0; k < half; ++k) {
        twr[(size_t)(half - 1 + k)] = std::cos(kPi * k / half);
        twi[(size_t)(half - 1 + k)] = -std::sin(kPi * k / half);
      }
    }
    int bits = 0;
    while ((1 << bits) < n) ++bits;
    for (int i = 0; i < n; ++i) {
      int r = 0;
      for (int b = 0; b < bits; ++b)
        if (i & (1 << b)) r |= 1 << (bits - 1 - b);
      rev[(size_t)i] = r;
    }
  }
  void run(double* re, double* im) const {
    for (int i = 0; i < n; ++i) {
      const int j = rev[(size_t)i];
      if (j > i) {
        std::swap(re[i], re[j]);
        std::swap(im[i], im[j]);
      }
    }
    for (int half = 1; half < n; half <<= 1) {
      const double* wr = &twr[(size_t)(half - 1)];
      const double* wi = &twi[(size_t)(half - 1)];
      for (int i = 0; i < n; i += 2 * half) {
        double* ar = re + i;
        double* ai = im + i;
        double* br = ar + half;
        double* bi = ai + half;
        for (int k = 0; k < half; ++k) {
          const double xr = br[k] * wr[k] - bi[k] * wi[k];
          const double xi = br[k] * wi[k] + bi[k] * wr[k];
          br[k] = ar[k] - xr;
          bi[k] = ai[k] - xi;
          ar[k] += xr;
          ai[k] += xi;
        }
      }
    }
  }
};

}  // namespace

double hearingWeight(double f) {
  if (f < 10.0) return 0.0;
  const double f2 = f * f;
  const double c1 = 20.6 * 20.6, c2 = 107.7 * 107.7, c3 = 737.9 * 737.9, c4 = 12194.0 * 12194.0;
  const double ra = (c4 * f2 * f2) / ((f2 + c1) * std::sqrt((f2 + c2) * (f2 + c3)) * (f2 + c4));
  return std::pow(ra / 0.7943, 0.6);
}

void Signal::read(long start, int count, float* dst) const {
  const long n = (long)n_;
  const float sc = (float)scale_, off = (float)offset_;
  long i = 0;
  for (; i < count && start + i < 0; ++i) dst[i] = 0.0f;
  const long hi = std::min<long>(count, n - start);  // samples that lie inside the signal
  if (i_) {
    for (; i < hi; ++i) dst[i] = (float)i_[start + i] * sc + off;
  } else if (f_) {
    for (; i < hi; ++i) dst[i] = f_[start + i] * sc + off;
  }
  for (; i < count; ++i) dst[i] = 0.0f;
}

void forEachFrame(const Signal& x, int N, int H, const FrameFn& cb) {
  Fft fft(N);
  std::vector<double> win((size_t)N);
  for (int i = 0; i < N; ++i) win[(size_t)i] = 0.5 - 0.5 * std::cos(kTwoPi * i / N);
  const long n = (long)x.size();
  const int frames = (int)(n / H) + 2;
  std::vector<double> re((size_t)N), im((size_t)N);
  std::vector<float> ma((size_t)N / 2 + 1), mb((size_t)N / 2 + 1), ta((size_t)N), tb((size_t)N);
  for (int f = 0; f < frames; f += 2) {
    const bool hasB = f + 1 < frames;
    x.read((long)f * H - N / 2, N, ta.data());
    if (hasB) x.read((long)(f + 1) * H - N / 2, N, tb.data());
    for (int i = 0; i < N; ++i) {
      re[(size_t)i] = (double)ta[(size_t)i] * win[(size_t)i];
      im[(size_t)i] = hasB ? (double)tb[(size_t)i] * win[(size_t)i] : 0.0;
    }
    fft.run(re.data(), im.data());
    for (int k = 0; k <= N / 2; ++k) {
      const int m = (N - k) & (N - 1);
      const double zr = re[(size_t)k], zi = im[(size_t)k], yr = re[(size_t)m], yi = im[(size_t)m];
      const double ar = zr + yr, ai = zi - yi, br = zr - yr, bi = zi + yi;  // (std::hypot is far slower than needed here)
      ma[(size_t)k] = (float)(0.5 * std::sqrt(ar * ar + ai * ai));
      mb[(size_t)k] = (float)(0.5 * std::sqrt(br * br + bi * bi));
    }
    cb(f, ma.data());
    if (hasB) cb(f + 1, mb.data());
  }
}

}  // namespace analysis
}  // namespace cw
