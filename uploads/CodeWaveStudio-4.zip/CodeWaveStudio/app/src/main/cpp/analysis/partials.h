// CodeWave Studio - audio -> script analysis: sinusoidal partials.
//
// Multi-resolution short-time spectra (long windows for the bass, short ones for the highs, where voices and
// instruments wobble fastest) -> spectral peaks -> partial tracks, each a list of (time, Hz, amplitude)
// breakpoints that the engine's partial.track renders back.
#pragma once

#include <functional>
#include <vector>

#include "curve_fit.h"
#include "spectral.h"

namespace cw {
namespace analysis {

struct PartialParams {
  double snrDb = 12.0;         // a peak must stand this far above the median level around it
  double floorDb = -65.0;      // absolute floor, relative to the (normalised) input peak
  double dynDb = 55.0;         // within this of the strongest (hearing-weighted) peak of its band and frame
  int maxPeaks = 80;           // peaks kept per band and frame
  double minTrackSec = 0.04;   // shortest partial
  double ampTolDb = 2.0;       // breakpoint fit tolerance: amplitude
  double freqTolCents = 12.0;  // breakpoint fit tolerance: frequency
  int maxPoints = 40;          // breakpoints per partial
  double maxHz = 12000.0;      // highest partial
};

struct Partial {
  std::vector<TrackPt> pts;  // simplified breakpoints: seconds, Hz, amplitude (input peak = 1); ends at 0 unless clipped
  double peak = 0.0;         // largest amplitude
  double energy = 0.0;       // hearing-weighted energy: what the partial is worth to a listener
  double heard = 0.0;        // largest amplitude x hearing weight: is it audible at all
  double t0 = 0.0, t1 = 0.0;
  int band = 0;              // analysis band that found it
};

// `x` is mono audio at `sr` Hz with its peak normalised to 1. The spectra are computed one frame at a time and a
// finished track is turned into a Partial at once, so the memory used does not grow with the length of the audio
// (only the partials found do). `progress`, when given, receives 0..1 now and then; it may throw to stop the work.
std::vector<Partial> findPartials(const Signal& x, int sr, const PartialParams& P,
                                  const std::function<void(double)>& progress = nullptr);

}  // namespace analysis
}  // namespace cw
