// JNI bridge for com.codewave.studio.engine.NativeBridge.
// No C++ exception ever crosses this boundary and nothing here lets script text reach
// anything but the audio engine.
#include <jni.h>

#include <atomic>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <functional>
#include <mutex>
#include <new>
#include <string>
#include <vector>

#include "analysis/audio_to_code.h"
#include "audio/audio_io.h"
#include "crash/crash_handler.h"
#include "engine/engine.h"

namespace {

using cw::Engine;

inline Engine* eng(jlong h) { return reinterpret_cast<Engine*>(h); }

// Calls ProgressListener.onProgress(float), throttled to ~16 updates per second.
class JniProgress {
 public:
  JniProgress(JNIEnv* env, jobject listener) : env_(env), listener_(listener), last_(std::chrono::steady_clock::now()) {
    if (listener_) {
      jclass cls = env_->FindClass("com/codewave/studio/engine/ProgressListener");
      if (cls) {
        mid_ = env_->GetMethodID(cls, "onProgress", "(F)V");
        env_->DeleteLocalRef(cls);
      }
      if (env_->ExceptionCheck()) env_->ExceptionClear();
    }
  }
  void operator()(float f) {
    if (!listener_ || !mid_) return;
    const auto now = std::chrono::steady_clock::now();
    if (f < 1.0f && now - last_ < std::chrono::milliseconds(60)) return;
    last_ = now;
    env_->CallVoidMethod(listener_, mid_, (jfloat)f);
    if (env_->ExceptionCheck()) env_->ExceptionClear();
  }

 private:
  JNIEnv* env_;
  jobject listener_;
  jmethodID mid_ = nullptr;
  std::chrono::steady_clock::time_point last_;
};

jstring toJString(JNIEnv* env, const std::string& s) { return env->NewStringUTF(s.c_str()); }

std::string toStdString(JNIEnv* env, jstring js) {
  std::string out;
  if (!js) return out;
  const char* utf = env->GetStringUTFChars(js, nullptr);
  if (utf) {
    out = utf;
    env->ReleaseStringUTFChars(js, utf);
  }
  return out;
}

// Reads a whole file. Stops one byte past `maxBytes`, so that a file that is too large still reaches the engine
// (which reports "script too long") instead of being silently cut.
bool readFile(const std::string& path, std::string& out, size_t maxBytes) {
  std::FILE* f = std::fopen(path.c_str(), "rb");
  if (!f) return false;
  out.clear();
  std::vector<char> buf(1u << 16);
  bool ok = true;
  for (;;) {
    const size_t n = std::fread(buf.data(), 1, buf.size(), f);
    if (n > 0) out.append(buf.data(), n);
    if (n < buf.size()) {
      ok = std::feof(f) != 0;
      break;
    }
    if (out.size() > maxBytes) break;
  }
  std::fclose(f);
  return ok;
}

bool writeFile(const std::string& path, const std::string& data) {
  std::FILE* f = std::fopen(path.c_str(), "wb");
  if (!f) return false;
  const bool ok = std::fwrite(data.data(), 1, data.size(), f) == data.size();
  return std::fclose(f) == 0 && ok;
}

cw::GenStatus runGenerate(JNIEnv* env, Engine* e, const std::string& text, jint sampleRate, jint channels,
                          jfloat defaultDuration, jobject listener) {
  cw::GenerateSettings gs;
  gs.sampleRate = (sampleRate == 22050 || sampleRate == 48000) ? sampleRate : 44100;
  gs.channels = channels == 1 ? 1 : 2;
  gs.defaultDuration = cw::clampd((double)defaultDuration, cw::limits::kMinDurationSec, cw::limits::kMaxDurationSec);
  JniProgress progress(env, listener);
  return e->generate(text, gs, [&progress](float f) { progress(f); });
}

// ---- audio import. A decoded song is kept here as 16-bit samples in native memory (10 minutes at 44.1 kHz are
// 53 MB; a float array on the Java heap would be twice that and could run the app out of memory). The analysis
// takes the samples over, so nothing can append to them while it runs.
struct ImportBuffer {
  std::mutex mu;
  std::vector<int16_t> samples;
  int sampleRate = 0;
};
ImportBuffer g_import;
std::atomic<bool> g_importCancel{false};

}  // namespace

extern "C" {

JNIEXPORT jlong JNICALL Java_com_codewave_studio_engine_NativeBridge_create(JNIEnv*, jclass) {
  try {
    return reinterpret_cast<jlong>(new Engine());
  } catch (...) {
    return 0;
  }
}

JNIEXPORT void JNICALL Java_com_codewave_studio_engine_NativeBridge_destroy(JNIEnv*, jclass, jlong h) {
  delete eng(h);
}

JNIEXPORT void JNICALL Java_com_codewave_studio_engine_NativeBridge_cancel(JNIEnv*, jclass, jlong h) {
  if (h) eng(h)->cancel();
}

// Returns a cw::GenStatus value (0 ok, 1 script error, 2 out of memory, 3 cancelled, 4 internal).
JNIEXPORT jint JNICALL Java_com_codewave_studio_engine_NativeBridge_generate(JNIEnv* env, jclass, jlong h,
                                                                             jstring script, jint sampleRate,
                                                                             jint channels, jfloat defaultDuration,
                                                                             jobject listener) {
  if (!h || !script) return (jint)cw::GenStatus::Internal;
  std::string text;
  try {
    const jsize len = env->GetStringUTFLength(script);
    const char* utf = env->GetStringUTFChars(script, nullptr);
    if (!utf) return (jint)cw::GenStatus::OutOfMemory;
    text.assign(utf, (size_t)len);
    env->ReleaseStringUTFChars(script, utf);
    return (jint)runGenerate(env, eng(h), text, sampleRate, channels, defaultDuration, listener);
  } catch (const std::bad_alloc&) {
    return (jint)cw::GenStatus::OutOfMemory;
  } catch (...) {
    return (jint)cw::GenStatus::Internal;
  }
}

// The same, for a script stored in a file (UTF-8): a script made from a whole song is megabytes of text, which is
// kept out of the Java heap and the editor. Returns a cw::GenStatus value.
JNIEXPORT jint JNICALL Java_com_codewave_studio_engine_NativeBridge_generateFromFile(JNIEnv* env, jclass, jlong h,
                                                                                     jstring path, jint sampleRate,
                                                                                     jint channels,
                                                                                     jfloat defaultDuration,
                                                                                     jobject listener) {
  if (!h || !path) return (jint)cw::GenStatus::Internal;
  try {
    std::string text;
    if (!readFile(toStdString(env, path), text, cw::limits::kMaxScriptBytes)) {
      eng(h)->reportFailure("The saved script could not be read.\n\nConvert the audio again.");
      return (jint)cw::GenStatus::Internal;
    }
    return (jint)runGenerate(env, eng(h), text, sampleRate, channels, defaultDuration, listener);
  } catch (const std::bad_alloc&) {
    return (jint)cw::GenStatus::OutOfMemory;
  } catch (...) {
    return (jint)cw::GenStatus::Internal;
  }
}

JNIEXPORT jstring JNICALL Java_com_codewave_studio_engine_NativeBridge_lastError(JNIEnv* env, jclass, jlong h) {
  return toJString(env, h ? eng(h)->lastError() : std::string());
}
JNIEXPORT jint JNICALL Java_com_codewave_studio_engine_NativeBridge_lastErrorLine(JNIEnv*, jclass, jlong h) {
  return h ? eng(h)->lastErrorLine() : 0;
}
JNIEXPORT jstring JNICALL Java_com_codewave_studio_engine_NativeBridge_lastWarnings(JNIEnv* env, jclass, jlong h) {
  return toJString(env, h ? eng(h)->lastWarnings() : std::string());
}
JNIEXPORT jint JNICALL Java_com_codewave_studio_engine_NativeBridge_renderMillis(JNIEnv*, jclass, jlong h) {
  return h ? eng(h)->lastRenderMillis() : 0;
}

JNIEXPORT jint JNICALL Java_com_codewave_studio_engine_NativeBridge_frameCount(JNIEnv*, jclass, jlong h) {
  const auto s = h ? eng(h)->sound() : nullptr;
  return s ? s->frames : 0;
}
JNIEXPORT jint JNICALL Java_com_codewave_studio_engine_NativeBridge_channelCount(JNIEnv*, jclass, jlong h) {
  const auto s = h ? eng(h)->sound() : nullptr;
  return s ? s->channels : 0;
}
JNIEXPORT jint JNICALL Java_com_codewave_studio_engine_NativeBridge_sampleRate(JNIEnv*, jclass, jlong h) {
  const auto s = h ? eng(h)->sound() : nullptr;
  return s ? s->sampleRate : 0;
}

// Fills dst with interleaved 16-bit PCM. Returns the number of frames copied.
JNIEXPORT jint JNICALL Java_com_codewave_studio_engine_NativeBridge_copyPcm16(JNIEnv* env, jclass, jlong h,
                                                                              jshortArray dst, jint startFrame,
                                                                              jint frames) {
  const auto s = h ? eng(h)->sound() : nullptr;
  if (!s || !dst) return 0;
  const int capacityFrames = (int)env->GetArrayLength(dst) / s->channels;
  const int n = frames < capacityFrames ? frames : capacityFrames;
  jshort* p = static_cast<jshort*>(env->GetPrimitiveArrayCritical(dst, nullptr));
  if (!p) return 0;
  const int copied = cw::copyPcm16(*s, reinterpret_cast<int16_t*>(p), startFrame, n);
  env->ReleasePrimitiveArrayCritical(dst, p, 0);
  return copied;
}

JNIEXPORT jboolean JNICALL Java_com_codewave_studio_engine_NativeBridge_peaks(JNIEnv* env, jclass, jlong h,
                                                                              jint columns, jfloatArray out) {
  const auto s = h ? eng(h)->sound() : nullptr;
  if (!s || !out || columns < 1 || env->GetArrayLength(out) < 2 * columns) return JNI_FALSE;
  jfloat* p = env->GetFloatArrayElements(out, nullptr);
  if (!p) return JNI_FALSE;
  cw::computePeaks(*s, columns, p);
  env->ReleaseFloatArrayElements(out, p, 0);
  return JNI_TRUE;
}

// Writes a WAV to an open file descriptor (owned and closed by the caller). 0 = success, else errno.
JNIEXPORT jint JNICALL Java_com_codewave_studio_engine_NativeBridge_writeWav(JNIEnv*, jclass, jlong h, jint fd,
                                                                             jint bits) {
  const auto s = h ? eng(h)->sound() : nullptr;
  if (!s) return -1;
  try {
    return cw::writeWav(*s, fd, bits == 32 ? 32 : 16);
  } catch (...) {
    return -2;
  }
}

// ---- Audio -> script, in three steps so that a whole song never has to exist as one Java array:
//   importBegin(sampleRate, expectedFrames)   start a new import (drops the previous one, clears a pending cancel)
//   importAppend(pcm, count)                  add mono float samples (-1..1), returns the frames held so far or -1
//   analyzeImported(...)                      analyse them and write the script to a file
// All text is plain ASCII.
JNIEXPORT jboolean JNICALL Java_com_codewave_studio_engine_NativeBridge_importBegin(JNIEnv*, jclass, jint sampleRate,
                                                                                    jint expectedFrames) {
  try {
    std::lock_guard<std::mutex> lk(g_import.mu);
    g_importCancel.store(false);
    std::vector<int16_t>().swap(g_import.samples);
    g_import.sampleRate = (int)sampleRate;
    if (expectedFrames > 0) g_import.samples.reserve((size_t)expectedFrames);
    return JNI_TRUE;
  } catch (...) {
    return JNI_FALSE;
  }
}

JNIEXPORT jint JNICALL Java_com_codewave_studio_engine_NativeBridge_importAppend(JNIEnv* env, jclass, jfloatArray pcm,
                                                                                 jint count) {
  try {
    if (!pcm || count < 0) return -1;
    const jsize cap = env->GetArrayLength(pcm);
    const jsize n = count < cap ? count : cap;
    std::lock_guard<std::mutex> lk(g_import.mu);
    const size_t old = g_import.samples.size();
    g_import.samples.resize(old + (size_t)n);
    jfloat* p = static_cast<jfloat*>(env->GetPrimitiveArrayCritical(pcm, nullptr));
    if (!p) {
      g_import.samples.resize(old);
      return -1;
    }
    int16_t* dst = g_import.samples.data() + old;
    for (jsize i = 0; i < n; ++i) {
      float v = p[i] * 32767.0f;
      if (!(v > -32767.0f)) v = -32767.0f;  // (also catches NaN)
      if (v > 32767.0f) v = 32767.0f;
      dst[i] = (int16_t)std::lrintf(v);
    }
    env->ReleasePrimitiveArrayCritical(pcm, p, JNI_ABORT);
    return (jint)g_import.samples.size();
  } catch (...) {
    return -1;
  }
}

// Frees the imported audio (when the import is abandoned before it is analysed) and stops a running analysis.
JNIEXPORT void JNICALL Java_com_codewave_studio_engine_NativeBridge_importDiscard(JNIEnv*, jclass) {
  g_importCancel.store(true);
  try {
    std::lock_guard<std::mutex> lk(g_import.mu);
    std::vector<int16_t>().swap(g_import.samples);
  } catch (...) {
  }
}

// Stops a running analyzeImported at its next check.
JNIEXPORT void JNICALL Java_com_codewave_studio_engine_NativeBridge_importCancel(JNIEnv*, jclass) {
  g_importCancel.store(true);
}

// Analyses the imported audio and writes the script to `outPath`. Returns "OK\n<summary>\n<script bytes>\n",
// "CANCELLED" or "ERR\n<message>". `listener` gets the progress (0..1).
JNIEXPORT jstring JNICALL Java_com_codewave_studio_engine_NativeBridge_analyzeImported(JNIEnv* env, jclass,
                                                                                       jstring outPath, jint detail,
                                                                                       jstring name,
                                                                                       jfloat startSeconds,
                                                                                       jobject listener) {
  try {
    std::vector<int16_t> audio;
    int sr = 0;
    {
      std::lock_guard<std::mutex> lk(g_import.mu);
      audio.swap(g_import.samples);
      sr = g_import.sampleRate;
    }
    if (audio.size() < 1024) return toJString(env, "ERR\nThere is no audio to analyse.");
    const std::string path = toStdString(env, outPath);
    if (path.empty()) return toJString(env, "ERR\nThere is nowhere to save the script.");

    JniProgress progress(env, listener);
    cw::AnalyzeOptions opt;
    opt.detail = (int)detail;
    opt.name = toStdString(env, name);
    opt.startSeconds = (double)startSeconds;
    opt.progress = [&progress](float f) {
      progress(f);
      return !g_importCancel.load();
    };
    cw::AnalyzeResult r = cw::analyzeAudioToScript16(audio.data(), audio.size(), sr, opt);
    std::vector<int16_t>().swap(audio);  // the audio is no longer needed: free it before the script is written
    if (r.cancelled) return toJString(env, "CANCELLED");
    if (!r.ok) return toJString(env, "ERR\n" + r.error);
    if (!writeFile(path, r.script)) return toJString(env, "ERR\nThe script could not be saved (is the storage full?).");
    progress(1.0f);
    return toJString(env, "OK\n" + r.summary + "\n" + std::to_string(r.script.size()) + "\n");
  } catch (const std::bad_alloc&) {
    return toJString(env, "ERR\nNot enough memory to analyse this audio. Try a shorter part or a lower detail level.");
  } catch (...) {
    return toJString(env, "ERR\nThe audio could not be analysed.");
  }
}

// Installs the native crash reporter; `path` is where the report is written on a native crash.
JNIEXPORT void JNICALL Java_com_codewave_studio_engine_NativeBridge_installCrashHandler(JNIEnv* env, jclass,
                                                                                         jstring path) {
  if (!path) return;
  const char* utf = env->GetStringUTFChars(path, nullptr);
  if (!utf) return;
  cw::installCrashHandler(utf);
  env->ReleaseStringUTFChars(path, utf);
}

}  // extern "C"
