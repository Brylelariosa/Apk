# CodeWave Studio

Native Android procedural-audio tool. Paste a script written by Claude (or any assistant), press
**Generate**, look at the real waveform, play it, tweak the code, and save a WAV.

```
Claude writes a script -> you paste it -> GENERATE -> C++ engine renders PCM
-> waveform -> PLAY / PAUSE / STOP / SEEK / LOOP -> edit -> Save WAV
```

The screen never needs scrolling to reach the player: in portrait the code editor takes the height that is
left and the player (waveform, time, Play / Pause / Stop / Loop, volume, **Save WAV**) is pinned to the bottom
(it steps aside while the keyboard is open); in landscape the code and the player sit side by side.

Kotlin (UI + controller) -> JNI -> C++ audio engine -> PCM -> AudioTrack / WAV exporter.
No WebView, no frameworks, **no third-party libraries** (Android framework + Kotlin stdlib only),
**no permissions**, no network.

## Using it with Claude

Tap the **?** button in the app, then **Copy AI prompt**. Paste that into Claude and finish the
sentence with the sound you want ("a heavy sci-fi door", "robot saying hello"). Copy Claude's
code block, open CodeWave Studio, tap **Paste**, then **Generate**.

## Import audio -> get the code

Pick any **mp3 / m4a (AAC) / wav / ogg / flac** file (anything the phone can play; the sound of an mp4
video works too) and CodeWave writes a script that imitates it:

```
Import -> choose file -> Detail (Simple / Normal / Detailed) + optional Length and "Start at" seconds
-> Convert -> the code is made and rendered automatically -> Play / Save WAV (and Save code)
```

* The **Import** button is under the editor. Leave **Length** empty to convert the **whole song** (up to
  15 minutes); type a number of seconds to convert only a part. **Start at** chooses where in the file to begin.
* **Detail** sets how much code is written per second of audio: about 5 000 characters (Simple), 9 000
  (Normal) or 20 000 (Detailed). The text grows with the length, so a whole song gets as much detail per second
  as a short clip: a 4 minute song at Detailed is about 5 MB of code, 10 minutes about 12 MB, and converting
  takes a minute or two on a phone (it uses up to four cores; keep the app open). It is an **approximation, not
  a copy** - the result keeps the notes, voices, beat and tone colour, but never every detail of the recording.
  On a test piece the log-mel distance to the original is 3.6 dB at Detailed, 4.3 at Normal and 5.3 at Simple
  (`tools/eval/`).
* **Long code** (over 250 000 characters - every whole song) is too much for a text editor and for the
  clipboard, so it is kept in a file in the app's private storage and never held in a Java string: the editor
  area shows the first lines and the size, Generate / Play / Save WAV use the whole script, and **Copy** becomes
  **Save code** (it writes the script to a file you pick). Clear, Paste and Examples replace it after asking.
  Shorter code goes into the editor as before, with Copy.
* How it works (`cpp/analysis/`, one module per step):
  1. **Partials** (`partials.cpp`): four analysis bands with their own window length - long for the bass, short
     for the highs, where a singer's vibrato moves fastest (the bass band uses 4096 points: long enough to tell
     bass notes apart, short enough to follow a kick drum's pitch sweep). The four bands run on their own cores. Spectral peaks are picked (side-lobe ghosts and
     noise bumps rejected), tracked from frame to frame (McAulay-Quatieri style, with pitch prediction) and
     each track is fitted with a few `(time, Hz, volume)` breakpoints.
  2. **Voices** (`voices.cpp`): partials that are harmonics of one pitch (same onset, same pitch curve) are
     collapsed into one *harmonic stack*: one pitch curve + one volume curve + a gain and a "how closely does it
     follow the volume" exponent per harmonic (`partial.harmonics`, `partial.dynamics`). A harmonic that does
     not follow the shared curve, or is seen only briefly (the highs of a plucked note), stays a plain partial.
  3. **Noise bands** (`noise_model.cpp`): the part the partials do not explain (drums, hats, breath, reverb,
     hiss) is measured as *original minus what the emitted partials will actually sound like* (analysis by
     synthesis, rendered with the engine's own partial renderer), every band with its own window (very short
     for treble so a hi-hat keeps its sharp start), and solved against the real band-pass filters. Their level
     over time is fitted with `envelope.deltas` lists; all bands share one point budget, so the points go to the
     bands that follow the beat.
  4. Budgets by Detail: characters per second of audio (see above; never less than 60 000 / 150 000 / 250 000
     for a short sound - it only writes what is needed). Partials are ranked by how audible they are (hearing
     weighted), so quiet sub-bass or inaudible overtones do not eat the budget. A long song is cut into 20 second
     blocks that each get their share of the text (what a block does not use passes on to the next), so a loud
     chorus cannot take the detail away from a quiet verse.
  5. **Memory**: the audio stays in native memory as 16-bit samples (53 MB for 10 minutes) and is read in short
     pieces; the noise analysis works through the song in twelve second segments; the script is written to a
     file. Nothing grows with the length except the result (tested up to 10 minutes: a 12 MB script renders in
     about 15 s on a desktop).
* The generated code always stays inside the engine limits and is checked by the real parser in the
  desktop tests (analysis of a 10 minute song at Detailed: about 35 s on one desktop core, so roughly 1-3
  minutes on a phone; rendering the result about 15 s on a desktop).
* Decoding uses `MediaExtractor` + `MediaCodec` (Android framework, no library) and the file comes
  through the system file picker, so there is still **no permission** and no network. DRM-protected
  files and codecs the phone cannot decode (e.g. Apple Lossless) are reported with a clear message.
* Code: `importer/AudioDecoder.kt` (decode, streams the samples to native memory), `importer/AudioToCode.kt`
  (background job, survives rotation, cancellable), `data/BigScript.kt` (the long script file),
  `cpp/analysis/` (analysis -> script). Tests: `tools/audio_to_code_test.cpp`, fuzzer
  `tools/audio_to_code_fuzz.cpp`, language tests `tools/partial_test.cpp`, the JNI path (import -> script file
  -> sound, cancel, errors) against a fake JNIEnv: `tools/jni_mock_test.sh`. Build the analyser with
  `-DA2C_DEBUG` to tune it (`A_*` environment variables, `A_THREADS`, per-stage timings), see `tools/eval/`.

## The scripting language

A tiny audio-only language. Every command is `group.method(values);` and must exist in the
command table (`app/src/main/cpp/parser/commands.cpp`) - anything else is rejected with a
line-numbered error such as:

```
Line 4:
Unknown command: oscillator.xyz

Expected:
sine
square
triangle
saw
pulse
noise
```

```
sound.begin(1.2);
oscillator.saw(90, 0.7);          // source
fm.modulate(35, 4.0);             // modifies the oscillator above
noise.add(0.08);
filter.lowpass(2400);             // processes everything so far
distortion.amount(0.15);
envelope.adsr(0.01, 0.12, 0.65, 0.3);
sound.end();
```

Supported: oscillators (sine, square, triangle, saw, pulse, noise + pink/brown), additive partials
(`partial.track` - a sine whose pitch and volume follow a list of points - plus `partial.harmonics` /
`partial.dynamics` to turn one into a harmonic stack), FM / AM / ring modulation, vibrato, pitch and frequency sweeps, pitch quantisation, ADSR / exponential / linear /
custom envelopes (`envelope.custom`, and `envelope.deltas`: compact, joined on a decibel scale), low/high/band-pass and notch filters (with cutoff sweeps), distortion
(soft/hard/fold), saturation, bit-crusher, delay, reverb, tremolo, chorus, compressor, layers,
repeats, normalize, fade, reverse, pitch shift, time stretch, pan/gain, and a voice section
(synthetic human vowels with formant morphing, formant filter, vocoder, metallic resonance).
Variables (`let base = 220;`), arithmetic and note names (`A4`, `C#3`) are supported.
The full reference is `app/src/main/assets/reference.txt` (generated from the command table by
`tools/dump_reference.cpp`, so it cannot drift from the parser).

The voice tools make *stylised synthetic* human/robot sounds. They are not speech synthesis.

### Safety model

Scripts are parsed and fully validated **before** any audio is rendered, and can only call commands
from the table. There is no file, network, shell, JNI, intent or system access in the language.
Hard limits: 48 MB script, 600000 commands, 16 minutes per sound, 2048 points per envelope.custom,
16 oscillators per layer, 4 nested layers, 128 repeats / 100000 layer instances, a memory budget (96 MB, or room for a
stereo copy of the sound plus 64 MB for a long one) and a CPU work budget that grows with the length of the sound. Rendering
runs on a worker thread with progress and a **Cancel** button; C++ exceptions never cross the JNI
boundary. A failed generation keeps the previous waveform and audio.

## Project layout

```
app/src/main/cpp/
  dsp/       oscillators, filters, envelopes, effects, voice, additive partials, utilities  (+ common.h, audio_buf.h)
  parser/    command table, lexer/parser/validator
  engine/    renderer (executes a validated program), Engine (result ownership, errors)
  analysis/  audio -> script: spectral.* (FFT/STFT), partials.* (peaks + tracking), voices.* (harmonic stacks),
             noise_model.* (leftover noise bands), curve_fit.h (breakpoint fitting), script_text.* (text), audio_to_code.cpp
  audio/     PCM16 copy, waveform peaks, WAV writer (16-bit PCM / 32-bit float)
  crash/     native crash reporter (signal handler + backtrace)
  jni_bridge.cpp
app/src/main/java/com/codewave/studio/
  engine/    NativeBridge (JNI surface), AudioEngine (async facade)
  importer/  AudioDecoder (MediaCodec -> mono PCM), AudioToCode (import job)
  player/    PcmPlayer (AudioTrack streaming, exact position, loop, seek)
  ui/        CodeEditorView, WaveformView, SyntaxHighlighter
  data/      AppSettings, PresetLibrary, LanguageReference, Themes, BigScript (the script file of a long import)
  crash/     CrashLog (Java + native crash capture), CrashReportActivity (separate process)
  SoundSession.kt (survives rotation), MainActivity.kt, SettingsActivity.kt
app/src/main/assets/   presets/*.cws (19 text scripts), reference.txt
tools/       desktop test harness, mutation fuzzer, crash-reporter test, reference generator,
             audio->code test + fuzzer
```

## Building

Matches the existing GitHub Actions workflow: JDK 17, Gradle 8.6, AGP 8.2.2, Kotlin 1.9.22,
NDK 25.2.9519653, CMake 3.22.1, compileSdk/targetSdk 34, minSdk 23. Zip the folder, put the ZIP in
`uploads/`, push. `./gradlew assembleDebug` and `./gradlew assembleRelease` need no signing
configuration (release is unsigned unless the workflow passes `-Pandroid.injected.signing.*`).

* `gradle/wrapper/gradle-wrapper.jar` is a binary and is not in the ZIP; the workflow downloads it
  ("Fetch gradle-wrapper.jar"). For a local build run `gradle wrapper --gradle-version 8.6` once.
* One universal APK, **no ABI splits**. ABIs built: `armeabi-v7a` + `arm64-v8a` (phones). Emulator
  ABIs are left out to save size - add `'x86_64'` to `abiFilters` in `app/build.gradle` if needed.
* Size: R8 (`minifyEnabled true`) + `shrinkResources true`, no dependencies, vector drawables only,
  compressed native libs, `-O2`, hidden symbols, `--gc-sections`, static libc++. JNI entry points and
  the progress callback are protected in `proguard-rules.pro`.
* Debug builds also compile the DSP at `-O2` (CMake would otherwise use `-O0`).

## Desktop tests (no Android needed)

```
sh tools/build_and_test.sh          # builds the engine for Linux/macOS and renders every preset to WAV
```

`tools/fuzz_test.cpp` mutates the presets (and feeds binary garbage); build it with
`-fsanitize=address,undefined` to hunt for crashes.

## Crash log (no root, Shizuku or PC)

* Java/Kotlin crashes **and native C++ crashes** (SIGSEGV, SIGABRT, ...) are caught by the app itself.
* After a crash a report screen opens by itself (it runs in a separate process and is built from
  plain views, so it works even if the main screen is what crashed). A native crash is shown the next
  time you start the app.
* Every report is saved privately inside the app **and**, on Android 10+, as a text file in
  `Download/CodeWaveStudio/` (not Android/data) - open it with any file manager.
* The screen has Copy, Share, Save as..., Older reports and Restart app. Reports include device,
  Android version, the stack trace and the last ~80 app events (generate, play, export, lifecycle).
* Settings > Diagnostics: view/clear reports and a **Test the crash logger** button.
* Nothing is ever sent anywhere and no permission is needed.

## Settings

Sample rate (22.05 / 44.1 / 48 kHz), mono/stereo, default sound duration (used by `sound.begin()`
without arguments), audio buffer size, default export format (16-bit PCM or 32-bit float WAV),
theme (dark / light / system), About. Engine settings apply on the next Generate.

## Not included

* **OGG export**: Android has no built-in Vorbis encoder; adding one would mean a native library
  and a bigger APK, so only WAV (16-bit PCM or 32-bit float) is offered.
