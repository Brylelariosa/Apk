#pragma once
// ============================================================================
// HZCM v4 — World.h
// ============================================================================
#ifndef GLES3_GL3_H_STUB
#include <GLES3/gl3.h>
#endif
#include <unordered_map>
#include <unordered_set>
#include <memory>
#include <thread>
#include <vector>
#include <mutex>
#include <shared_mutex>
#include <atomic>
#include <climits>

#include "Chunk.h"
#include "Noise.h"
#include "Math3D.h"
#include "hzcm/ClusterTypes.h"
#include "hzcm/MegaBuffer.h"
#include "hzcm/ThermalManager.h"
#include "hzcm/StreamScheduler.h"
#include "hzcm/LockFreeJobQueue.h"
#include "hzcm/RenderDistanceSystem.h"
#include "hzcm/HierarchicalVisibility.h"
#include "hzcm/DrawBatcher.h"
#include "DebugOverlay.h"

// ── Chunk key ─────────────────────────────────────────────────────────────────
struct ChunkKey {
    int cx, cz;
    bool operator==(const ChunkKey& o) const { return cx==o.cx && cz==o.cz; }
    bool operator< (const ChunkKey& o) const {
        return cx < o.cx || (cx == o.cx && cz < o.cz);
    }
};
struct ChunkKeyHash {
    size_t operator()(const ChunkKey& k) const {
        return (size_t)((uint32_t)k.cx * 2654435761u
                      ^ (uint32_t)k.cz * 1234567891u);
    }
};

// ── Upload task ───────────────────────────────────────────────────────────────
struct UploadTask {
    Chunk*   chunk;
    int      ci;
    uint32_t dirtyGen;
    // Chebyshev distance from camera chunk at time of enqueue (Manhattan approx).
    // Set by workerChunkBuild / workerClusterRebuild via camera state snapshot.
    // Used by updateGPU() to sort the upload queue nearest-first each frame.
    int      chebDist = 0;
};

// ── World ─────────────────────────────────────────────────────────────────────
class World {
public:
    World();
    ~World();

    void init(int seed = 42);

    // Per-frame GL-thread calls
    void update(float camX, float camZ, float camY,
                float velX, float velZ,
                float fwdX, float fwdZ, float dt);
    void updateGPU();
    void gatherAndDraw(const Frustum& frustum, GLint originUniformLoc);

    // Block access
    uint8_t getBlock(int wx, int wy, int wz) const;
    Chunk*  getChunk(int cx, int cz) const;  // caller holds shared lock

    // Runtime render distance
    RenderDistanceSystem& renderDistance()             { return m_renderDist; }
    const RenderDistanceSystem& renderDistance() const { return m_renderDist; }
    bool parseCommand(const char* cmd) { return m_renderDist.parseCommand(cmd); }

    // Diagnostics
    int getChunkCount()    const;
    int getVisibleCount()  const { return m_lastVisibleDraws; }
    int getEffectiveRadius() const { return m_effectiveRadius; }
    int surfaceHeightAt(int cx, int cz) const;
    const ThermalManager& thermal() const { return m_thermal; }
    MegaBuffer& megaBuffer() { return m_mega; }

    // Full telemetry snapshot — called from Renderer/JNI at ~4 Hz for the
    // debug overlay. Non-const because it reads MegaBuffer state (non-const methods).
    // fps is passed in from the Renderer's EMA tracker.
    WorldDebugStats getDebugStats(float fps);

    // Worker dispatch (public so executeJob can call private helpers)
    void executeJob(const WorldJob& job);

    using ChunkMap = std::unordered_map<ChunkKey, std::unique_ptr<Chunk>, ChunkKeyHash>;
    const ChunkMap&    chunksSnapshot() const { return m_chunks; }
    std::shared_mutex& chunksMutex()    const { return m_chunksMtx; }

    static constexpr GLsizei FACE_STRIDE = sizeof(PackedFace);

private:
    // Subsystems
    Noise                  m_noise;
    MegaBuffer             m_mega;
    ThermalManager         m_thermal;
    StreamScheduler        m_scheduler;
    RenderDistanceSystem   m_renderDist;
    HierarchicalVisibility m_visibility;
    DrawBatcher            m_drawBatcher;

    // Chunk storage
    mutable std::shared_mutex m_chunksMtx;
    ChunkMap                  m_chunks;
    // BUG FIX (v11→v12): was std::set (O(log N) lookup). At RD=200 the
    // filter does ~163k lookups per camera-chunk move; O(log 163k)≈17
    // comparisons each ≈ 30–80 ms GL stall. unordered_set = O(1) avg.
    std::unordered_set<ChunkKey, ChunkKeyHash> m_submitted;
    mutable int               m_lastVisibleDraws = 0;
    int                       m_effectiveRadius  = 7;
    int                       m_lastCamCX = INT_MIN, m_lastCamCZ = INT_MIN;
    // Atomically-updated camera chunk coords — readable from worker threads
    // without holding any lock, used to stamp chebDist on UploadTasks.
    std::atomic<int>          m_camCXAtomic{0};
    std::atomic<int>          m_camCZAtomic{0};
    uint32_t                  m_lastRdGen = 0;

    // Sorted candidate list — rebuilt on camera-chunk-change or RD-change,
    // then consumed incrementally every frame so a stationary player still loads
    // all chunks in priority order without requiring camera movement.
    std::vector<ChunkPriority> m_pendingCandidates;
    size_t                     m_candidateIdx = 0;

    // Upload queue (workers → GL thread)
    std::mutex              m_uploadMtx;
    std::vector<UploadTask> m_uploadQueue;

    // ── Deferred retry queue ──────────────────────────────────────────────────
    // Jobs that failed to push into m_jobQueue (queue full) are held here and
    // retried at the start of the next update() call.  This prevents the
    // silent-drop behaviour in enqueueChunkBuild / enqueueClusterRebuild that
    // left border seams unfixed when the queue overflowed at RD≥8.
    // Accessed from both GL thread (drain) and worker threads (push), so
    // protected by m_retryMtx.
    std::mutex             m_retryMtx;
    std::vector<WorldJob>  m_retryQueue;

    // ── Debug / telemetry counters (GL-thread writes, read anywhere) ──────────
    std::atomic<int>  m_overflowCount{0};   // push() failures total
    std::atomic<int>  m_retryQueueSize{0};  // current deferred retry depth
    int               m_frameCount = 0;     // frames since init()

    // Graveyard: chunks marked evicted but not yet deleted.
    // Each entry is (chunk, framesRemaining). Deleted when frames==0 AND inFlight==0.
    struct GraveyardEntry { std::unique_ptr<Chunk> chunk; int frames; };
    std::mutex                    m_graveyardMtx;
    std::vector<GraveyardEntry>   m_graveyard;

    // Lock-free worker pool
    LockFreeJobQueue         m_jobQueue;
    std::vector<std::thread> m_workers;

    // Internal helpers
    void workerLoop();
    void enqueueChunkBuild   (Chunk* chunk);
    void enqueueClusterRebuild(Chunk* chunk, int ci);
    void enqueueNeighbourFlush(int cx, int cz);

    void workerChunkBuild    (Chunk* chunk);
    void workerClusterRebuild(Chunk* chunk, int ci);
    void workerNeighbourFlush(int cx, int cz);

    void evictChunk(Chunk* chunk);
    void refreshEffectiveRadius();
    void drainRetryQueue();   // push deferred jobs back into m_jobQueue
};
