package com.studioadept.computer;

import android.os.Bundle;
import android.webkit.WebView;

import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import com.getcapacitor.BridgeActivity;
import com.studioadept.sdk.NotificationSettingsPlugin;

/**
 * Main activity of Idle CPU.
 *
 * Reconstructed from the behaviour of the original app's bytecode (v1.2.7, build 32):
 *  - registers the app's own Capacitor plugin(s) before the bridge starts,
 *  - pins the WebView text zoom to 100 % so the system font size cannot rescale the game UI,
 *  - runs in immersive mode (system bars hidden, shown transiently by an edge swipe), re-applied
 *    whenever the window regains focus.
 * The original also registered AppMetrica, Google Play Billing, Google Sign-In and In-App Review plugins;
 * they are online services and are not part of the offline build.
 */
public class MainActivity extends BridgeActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(NotificationSettingsPlugin.class);
        super.onCreate(savedInstanceState);

        WebView webView = getBridge() != null ? getBridge().getWebView() : null;
        if (webView != null) {
            webView.getSettings().setTextZoom(100);
        }
        enterImmersiveMode();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            enterImmersiveMode();
        }
    }

    private void enterImmersiveMode() {
        WindowInsetsControllerCompat controller =
                WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        controller.hide(WindowInsetsCompat.Type.systemBars());
        controller.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
    }
}
