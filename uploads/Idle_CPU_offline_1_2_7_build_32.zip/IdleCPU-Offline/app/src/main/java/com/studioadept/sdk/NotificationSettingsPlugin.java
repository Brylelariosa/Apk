package com.studioadept.sdk;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;

import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/**
 * "NotificationSettings.open()": opens the system notification settings of this app (the app-details
 * screen on Android versions before 8.0). Used by the game's notification settings row.
 *
 * Reconstructed from the behaviour of the original app's bytecode (v1.2.7, build 32). Purely local:
 * it only starts a system settings screen.
 */
@CapacitorPlugin(name = "NotificationSettings")
public class NotificationSettingsPlugin extends Plugin {

    @PluginMethod
    public void open(PluginCall call) {
        Context context = getContext();
        String packageName = context.getPackageName();

        Intent appDetails = new Intent(
                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.fromParts("package", packageName, null));
        Intent intent = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                : appDetails;

        try {
            getActivity().startActivity(intent);
        } catch (Exception first) {
            try {
                getActivity().startActivity(appDetails);
            } catch (Exception second) {
                call.reject("No settings screen available");
                return;
            }
        }
        call.resolve();
    }
}
