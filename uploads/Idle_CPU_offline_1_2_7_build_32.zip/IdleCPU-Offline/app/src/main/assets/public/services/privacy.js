/*
 * Idle CPU - offline build: privacy service stub.
 * The original service ran the ad-consent (UMP) and tracking-permission prompts. This build has no ads,
 * no analytics and no network, so there is nothing to ask: the launch flow gets "none" and the stored
 * state is "nothing collected".
 */
(function () {
  "use strict";
  var OC = (window.OC = window.OC || {});
  OC.services = OC.services || {};
  if (OC.services.privacy) return;

  function state() {
    return {
      platform: "android",
      native: true,
      appConsent: "declined",
      choices: { analytics: false, ads: false },
      attStatus: "unavailable",
      trackingRefused: false,
      systemTrackingDenied: false,
      canAnalytics: false,
      canAds: false,
      canTrack: false
    };
  }
  var done = function () { return Promise.resolve(state()); };

  OC.services.privacy = {
    id: "privacy",
    init: function () {},
    setRefusalPolicy: function () {},
    refusalPolicy: function () { return "decline-all"; },
    getState: done,
    launchPrompt: function () { return Promise.resolve("none"); },
    shouldShowLaunchPrompt: function () { return Promise.resolve(false); },
    launchPrivacyPending: function () { return Promise.resolve(false); },
    requestSystemPermission: done,
    saveChoices: done,
    acceptAndRequestSystemPermission: done,
    decline: done,
    openPlatformSettings: function () { return Promise.resolve(); },
    region: function () { return { country: "", eea: false, source: "none" }; },
    consentStatus: function () { return "declined"; },
    deriveTrackingConsentState: state,
    launchPromptFor: function () { return "none"; },
    refusalDeclineDue: function () { return false; }
  };
})();
