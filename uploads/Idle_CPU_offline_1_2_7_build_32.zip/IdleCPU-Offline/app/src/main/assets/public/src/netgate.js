/*
 * Idle CPU - offline build: connectivity-gate stub.
 * The original polled public "generate_204" endpoints and blocked the game with a NO INTERNET popup
 * until a connection came back. This build never needs a connection, so the gate is permanently open.
 * The public surface (OC.netGate) is kept for the screens that ask whether the device is offline.
 */
(function () {
  "use strict";
  var OC = (window.OC = window.OC || {});
  OC.netGate = {
    state: function () { return { on: false, enabled: false, down: false, downFor: 0, shown: false, fake: false, delay: 0 }; },
    show: function () {},
    check: function () { return Promise.resolve(true); },
    offline: function () { return false; }
  };
})();
