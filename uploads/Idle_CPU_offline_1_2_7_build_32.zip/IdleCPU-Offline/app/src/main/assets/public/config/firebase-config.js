/*
 * Idle CPU - offline build: backend configuration.
 * Every cloud feature is switched off and the Firebase project credentials that used to live here have
 * been removed. The limits block is kept because the local (sample) leaderboard logic still reads it.
 */
(function () {
  "use strict";
  var e = (window.OC = window.OC || {});
  e.CONFIG = e.CONFIG || {};
  e.CONFIG.firebase = {
    FIREBASE_ENABLED: false,
    CLANS_ENABLED: false,
    ARENA_ENABLED: false,
    CLASH_ENABLED: false,
    VAULT_ENABLED: false,
    CLAN_PUSH_ENABLED: false,
    webConfig: {},
    auth: { provider: "none" },
    appCheck: { mode: "off", webSiteKey: "" },
    paths: { players: "players", boards: "boards", shadowBans: "moderation/shadowBans" },
    boardIds: { global: "global", countryPrefix: "c-", weeklyPrefix: "w-" },
    functions: {},
    cloud: { CLOUD_SAVE_ENABLED: false },
    limits: {
      minWriteSec: 20, riseFactor: 1.5, riseSlack: 1e4, tierStepSec: 1800,
      tierMaxTps: [5e3, 15e4, 45e5, 135e6, 405e7, 1215e8, 3645e9],
      benchScale: 10, benchBonusMax: 25e3, benchSlack: 100,
      trophiesPerWin: 32, trophiesPaceSec: 8, trophiesBurst: 3, trophiesSlack: 100,
      trophiesCreateMax: 2e3, profileEditsPerDay: 20
    }
  };
})();
