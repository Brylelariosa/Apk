/*
 * Idle CPU - offline build: analytics stub.
 * The original module forwarded events to Firebase Analytics, Adjust, AppMetrica and Crashlytics and kept
 * an export buffer. This build collects nothing and sends nothing. The public API is kept so every caller
 * keeps working; the local de-duplication helpers (once / onceAt / resetOnce) keep their original meaning,
 * because the first-time-user flow relies on them.
 */
(function () {
  "use strict";
  var OC = (window.OC = window.OC || {});
  OC.services = OC.services || {};
  if (OC.services.analytics) return;

  var KEY = "oc.once.v1";
  var memo = null;

  function load() {
    if (memo) return memo;
    try {
      var raw = JSON.parse(localStorage.getItem(KEY) || "null");
      memo = raw && typeof raw === "object" && !Array.isArray(raw) ? raw : {};
    } catch (e) {
      memo = {};
    }
    return memo;
  }
  function save() {
    try { localStorage.setItem(KEY, JSON.stringify(load())); } catch (e) { /* storage unavailable */ }
  }
  function nowMs() {
    var c = OC.svc && typeof OC.svc.now === "function" ? OC.svc.now() : Date.now();
    return Math.round(c);
  }

  function noop() {}

  var api = {
    id: "analytics",
    // local de-duplication: true the first time a key is seen, false afterwards
    once: function (key) {
      var m = load(), k = String(key);
      if (m[k]) return false;
      m[k] = nowMs();
      save();
      return true;
    },
    onceAt: function (key) {
      var t = load()[String(key)];
      return typeof t === "number" && isFinite(t) ? t : null;
    },
    resetOnce: function (prefix) {
      var m = load(), p = String(prefix || ""), n = 0;
      Object.keys(m).forEach(function (k) {
        if (k.indexOf(p) === 0) { delete m[k]; n++; }
      });
      if (n) save();
      return n;
    },
    // read-only helpers used by the developer panels
    rows: function () { return []; },
    openEvents: function () { return []; },
    exportEvents: function () { return []; },
    exportJSON: function () { return "[]"; },
    exportBigQuery: function () { return ""; },
    clearRows: noop,
    userProperties: function () { return {}; },
    health: function () { return { consent: "offline", queued: 0, dropped: 0, invalid: 0 }; }
  };

  // everything else (track, appOpen, gameBoot, purchaseResult, ftueStep, ...) is a silent no-op
  OC.services.analytics = new Proxy(api, {
    get: function (target, prop) {
      if (prop in target) return target[prop];
      if (typeof prop === "symbol" || prop === "then") return undefined;
      return noop;
    },
    has: function () { return true; }
  });
})();
