/*
 * Idle CPU - offline build: preload guard.
 * Loaded first by index.html, before any other script.
 *
 *  1. The game is entirely local in this build, so it is told it is always "online":
 *     its local (sample) backends must never mistake airplane mode for a failure.
 *  2. Pins the switch the original code already provides for "no connectivity gate".
 *  3. Refuses - and records - any attempt to reach another host.  The page CSP blocks the same
 *     traffic at the browser level; this layer makes it visible (window.__OC_OFFLINE.blocked).
 */
(function () {
  "use strict";
  var W = window;
  var guard = (W.__OC_OFFLINE = { build: "offline-1", count: 0, blocked: [] });

  function note(kind, target) {
    guard.count++;
    if (guard.blocked.length < 50) guard.blocked.push(kind + " " + String(target).slice(0, 160));
  }

  function isLocal(u) {
    try {
      var url = new URL(String(u), W.location.href);
      return url.origin === W.location.origin || url.protocol === "data:" || url.protocol === "blob:";
    } catch (e) {
      return true; // not a parsable URL: a relative/local reference
    }
  }

  var DENIED = "Network access is disabled in the offline build";

  // 1. always "online" for the game's own local services
  try {
    Object.defineProperty(Navigator.prototype, "onLine", {
      configurable: true,
      get: function () { return true; }
    });
  } catch (e) { /* ignore */ }

  // 2. the game's own "no connectivity gate" switch (src/netgate.js is also a stub in this build)
  W.__OC_NETGATE = "off";

  // 3. network egress guard
  if (typeof W.fetch === "function") {
    var realFetch = W.fetch.bind(W);
    W.fetch = function (input, init) {
      var u = input && typeof input === "object" && "url" in input ? input.url : input;
      if (!isLocal(u)) {
        note("fetch", u);
        return Promise.reject(new TypeError(DENIED));
      }
      return realFetch(input, init);
    };
  }

  if (W.XMLHttpRequest && W.XMLHttpRequest.prototype) {
    var realOpen = W.XMLHttpRequest.prototype.open;
    W.XMLHttpRequest.prototype.open = function (method, url) {
      if (!isLocal(url)) {
        note("xhr", url);
        throw new DOMException(DENIED, "NetworkError");
      }
      return realOpen.apply(this, arguments);
    };
  }

  ["WebSocket", "EventSource"].forEach(function (name) {
    var Real = W[name];
    if (typeof Real !== "function") return;
    var Blocked = function (url) {
      note(name, url);
      throw new DOMException(DENIED, "SecurityError");
    };
    Blocked.prototype = Real.prototype;
    ["CONNECTING", "OPEN", "CLOSING", "CLOSED"].forEach(function (k) {
      if (k in Real) Blocked[k] = Real[k];
    });
    W[name] = Blocked;
  });

  try {
    W.navigator.sendBeacon = function (url) { note("beacon", url); return false; };
  } catch (e) { /* ignore */ }
})();
