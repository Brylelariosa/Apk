# Release builds are not minified (minifyEnabled false); nothing to keep here.
