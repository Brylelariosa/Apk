"""Headless-Chromium harness: serves a web root at https://localhost, emulates Capacitor's Android bridge
(Capacitor's own native-bridge.js + a tiny fake native side), blocks every other host and records attempts."""
import json, mimetypes, os, re, sys, time
from playwright.sync_api import sync_playwright

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
_BRIDGE = os.environ.get('NATIVE_BRIDGE_JS') or os.path.join(
    PROJECT_ROOT, 'node_modules', '@capacitor', 'android', 'capacitor', 'src', 'main', 'assets', 'native-bridge.js')
if not os.path.exists(_BRIDGE):
    sys.exit('native-bridge.js not found at %s\n'
             'Run "npm install" in the project root first (or point NATIVE_BRIDGE_JS at Capacitor\'s native-bridge.js).' % _BRIDGE)
NATIVE_BRIDGE = open(_BRIDGE, encoding='utf8').read()

HEADERS = {
  'Preferences': ['configure','get','set','remove','keys','clear','migrate','removeOld'],
  'App': ['exitApp','getInfo','getLaunchUrl','getState','minimizeApp','removeAllListeners'],
  'Haptics': ['impact','notification','vibrate','selectionStart','selectionChanged','selectionEnd'],
  'SplashScreen': ['show','hide'],
  'LocalNotifications': ['schedule','getPending','registerActionTypes','cancel','areEnabled','getDeliveredNotifications',
       'removeDeliveredNotifications','removeAllDeliveredNotifications','createChannel','deleteChannel','listChannels',
       'checkPermissions','requestPermissions','changeExactNotificationSetting','checkExactNotificationSetting','removeAllListeners'],
  'NotificationSettings': ['open'],
  'CapacitorCookies': ['getCookies','setCookie','deleteCookie','clearCookies','clearAllCookies'],
  'CapacitorHttp': ['request'],
  'WebView': ['setServerBasePath','getServerBasePath','persistServerBasePath'],
  'Console': ['log'],
}
LISTENER_PLUGINS = ['App', 'LocalNotifications']

SHIM = r"""
(function () {
  var AIRPLANE = %(airplane)s;
  if (AIRPLANE) {
    // the OS reports "no connectivity": this is the native getter the page's own code may or may not override
    Object.defineProperty(Navigator.prototype, 'onLine', { configurable: true, get: function () { return false; } });
  }
  var log = (window.__NATIVE_CALLS = []);
  var listeners = (window.__NATIVE_LISTENERS = {});
  var HEADERS = %(headers)s;
  var LISTENER_PLUGINS = %(lp)s;
  var ph = [];
  Object.keys(HEADERS).forEach(function (name) {
    var methods = HEADERS[name].map(function (m) { return { name: m, rtype: 'promise' }; });
    if (LISTENER_PLUGINS.indexOf(name) >= 0) {
      methods.push({ name: 'addListener', rtype: 'callback' });
      methods.push({ name: 'removeListener', rtype: 'promise' });
    }
    ph.push({ name: name, methods: methods });
  });
  window.WEBVIEW_SERVER_URL = 'https://localhost';
  window.Capacitor = { PluginHeaders: ph };
  var store = {};
  try { store = JSON.parse(localStorage.getItem('__native_prefs') || '{}'); } catch (e) {}
  function persist() { try { localStorage.setItem('__native_prefs', JSON.stringify(store)); } catch (e) {} }
  function reply(d, ok, data, err) {
    setTimeout(function () {
      window.Capacitor.fromNative({ callbackId: d.callbackId, pluginId: d.pluginId, methodName: d.methodName,
                                    success: ok, data: data, error: err });
    }, 0);
  }
  window.androidBridge = {
    postMessage: function (str) {
      var d = JSON.parse(str), p = d.pluginId, m = d.methodName, o = d.options || {};
      log.push(p + '.' + m);
      if (!HEADERS[p]) return reply(d, false, null, { message: p + ' is not implemented on android', code: 'UNIMPLEMENTED' });
      if (m === 'addListener') { (listeners[p + ':' + o.eventName] = listeners[p + ':' + o.eventName] || []).push(d.callbackId); return; }
      if (m === 'removeListener') return reply(d, true, {});
      if (p === 'Preferences') {
        if (m === 'get') return reply(d, true, { value: Object.prototype.hasOwnProperty.call(store, o.key) ? store[o.key] : null });
        if (m === 'set') { store[o.key] = o.value; persist(); return reply(d, true, {}); }
        if (m === 'remove') { delete store[o.key]; persist(); return reply(d, true, {}); }
        if (m === 'keys') return reply(d, true, { keys: Object.keys(store) });
        if (m === 'clear') { store = {}; persist(); return reply(d, true, {}); }
        return reply(d, true, {});
      }
      if (p === 'App') {
        if (m === 'getInfo') return reply(d, true, { name: 'Idle CPU', id: 'com.studioadept.computer.offline', build: '32', version: '1.2.7' });
        if (m === 'getState') return reply(d, true, { isActive: true });
        return reply(d, true, {});
      }
      if (p === 'LocalNotifications') {
        if (m === 'schedule') return reply(d, true, { notifications: (o.notifications || []).map(function (n) { return { id: n.id }; }) });
        if (m === 'getPending') return reply(d, true, { notifications: [] });
        if (m === 'checkPermissions' || m === 'requestPermissions') return reply(d, true, { display: 'granted' });
        if (m === 'areEnabled') return reply(d, true, { value: true });
        if (m === 'listChannels') return reply(d, true, { channels: [] });
        if (m === 'checkExactNotificationSetting') return reply(d, true, { exact_alarm: 'granted' });
        return reply(d, true, {});
      }
      if (p === 'CapacitorHttp') {
        (window.__NATIVE_HTTP = window.__NATIVE_HTTP || []).push(o.url);
        return reply(d, false, null, { message: 'offline', code: 'UNAVAILABLE' });
      }
      return reply(d, true, {});
    }
  };
  window.__fireNative = function (plugin, event, data) {
    (listeners[plugin + ':' + event] || []).forEach(function (id) {
      window.Capacitor.fromNative({ callbackId: id, pluginId: plugin, methodName: event, save: true, success: true, data: data || {} });
    });
  };
})();
""" 

def shim_source(airplane=True):
    return (SHIM % {'airplane': 'true' if airplane else 'false', 'headers': json.dumps(HEADERS), 'lp': json.dumps(LISTENER_PLUGINS)}
            + '\n' + NATIVE_BRIDGE)

class Session:
    def __init__(self, web_root, profile_dir, native=True, airplane=True, viewport=(412, 892)):
        self.root = web_root; self.profile = profile_dir; self.native = native; self.airplane = airplane
        self.viewport = viewport
        self.external = []      # requests that reached the (blocked) network layer
        self.console = []       # (type, text)
        self.errors = []        # uncaught page errors
        self.served = 0
    def __enter__(self):
        self.pw = sync_playwright().start()
        self.ctx = self.pw.chromium.launch_persistent_context(
            self.profile, headless=True, viewport={'width': self.viewport[0], 'height': self.viewport[1]},
            device_scale_factor=2, is_mobile=True, has_touch=True, args=['--autoplay-policy=no-user-gesture-required'])
        if self.native:
            self.ctx.add_init_script(shim_source(self.airplane))
        elif self.airplane:
            self.ctx.add_init_script("Object.defineProperty(Navigator.prototype,'onLine',{configurable:true,get:function(){return false}});")
        self.ctx.route('**/*', self._route)
        self.page = self.ctx.pages[0] if self.ctx.pages else self.ctx.new_page()
        self.page.on('console', lambda m: self.console.append((m.type, m.text)))
        self.page.on('pageerror', lambda e: self.errors.append(str(e)))
        return self
    def __exit__(self, *a):
        try: self.ctx.close()
        finally: self.pw.stop()
    def _route(self, route):
        url = route.request.url
        m = re.match(r'https://localhost(/[^?#]*)?', url)
        if not m:
            if not url.startswith('data:') and not url.startswith('blob:'):
                self.external.append(url)
            return route.abort()
        path = (m.group(1) or '/').lstrip('/') or 'index.html'
        full = os.path.join(self.root, path)
        if os.path.isdir(full): full = os.path.join(full, 'index.html')
        if not os.path.exists(full):
            return route.fulfill(status=404, body='not found')
        ctype = mimetypes.guess_type(full)[0] or 'application/octet-stream'
        if full.endswith('.js'): ctype = 'text/javascript'
        self.served += 1
        route.fulfill(status=200, body=open(full, 'rb').read(), headers={'content-type': ctype, 'cache-control': 'no-store'})
    def goto(self):
        self.page.goto('https://localhost/index.html', wait_until='load')
    def ev(self, js):
        return self.page.evaluate(js)
