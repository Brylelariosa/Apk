# Web-layer offline checks

`run_checks.py` launches the game (`app/src/main/assets/public`) in headless Chromium the way the Android app would:

* served from `https://localhost` (Capacitor's origin), with **Capacitor's own `native-bridge.js`** and a small fake native side
  (Preferences, App, Haptics, SplashScreen, LocalNotifications, NotificationSettings),
* in **airplane mode** (the browser reports `navigator.onLine === false` before the game's own offline guard runs),
* with **every non-local host blocked** and every attempt recorded.

It checks: boot, no "NO INTERNET" popup, device clock, zero network/CSP/native-HTTP attempts, only offline-capable native
plugins called, rewarded actions resolving locally, purchases refused, save + restart persistence, and 2 h of away time credited.

```
pip install playwright && playwright install chromium
npm install                      # (or let the first Gradle build do it) - provides Capacitor's native-bridge.js
python3 tools/web-checks/run_checks.py
```

This is a web-layer test in a desktop browser. It does not exercise the Android WebView, the Java classes or the APK.
