#!/usr/bin/env python3
"""Offline checks for the Idle CPU offline web layer.
Headless Chromium + an emulated Capacitor Android bridge, airplane mode, every non-local host blocked.
Usage: python3 run_checks.py [web_root]      (default: app/src/main/assets/public)
Needs: python3, playwright (pip install playwright; playwright install chromium), and node_modules from `npm install`
       (or NATIVE_BRIDGE_JS=/path/to/native-bridge.js)."""
import json, os, shutil, sys, tempfile, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from harness import Session, PROJECT_ROOT

WEB = sys.argv[1] if len(sys.argv) > 1 else os.path.join(PROJECT_ROOT, 'app', 'src', 'main', 'assets', 'public')
TMP = tempfile.mkdtemp(prefix='idlecpu_checks_')
ALLOWED_NATIVE = {'App', 'Haptics', 'LocalNotifications', 'Preferences', 'SplashScreen', 'NotificationSettings', 'Console', 'WebView'}
results = []

def check(name, ok, detail=''):
    results.append((name, bool(ok)))
    print(('PASS' if ok else 'FAIL') + ' - ' + name + ((' | ' + str(detail)) if detail != '' else ''), flush=True)

def skip_tutorial(s):
    try:
        s.page.get_by_text('SKIP', exact=True).first.click(timeout=1500); time.sleep(1)
    except Exception:
        pass

# ---------------------------------------------------------------- A. launch in airplane mode
prof = os.path.join(TMP, 'p1')
print('== A. launch in airplane mode (25 s) ==')
with Session(WEB, prof, native=True, airplane=True) as s:
    s.goto()
    t0 = time.time(); gone = None
    while time.time() - t0 < 25:
        time.sleep(1)
        if gone is None and s.ev("!document.getElementById('splash')"): gone = round(time.time() - t0, 1)
    info = s.ev("""(() => ({
      ready: !!(window.OC && OC.api),
      gateShown: !!(document.getElementById('netGate') && !document.getElementById('netGate').hidden),
      clock: OC.clock.mode() + '/' + (OC.clock.verified() ? 'verified' : 'unverified'),
      gameOnline: navigator.onLine,
      guard: __OC_OFFLINE.count, guardList: __OC_OFFLINE.blocked,
      native: Array.from(new Set(window.__NATIVE_CALLS || [])),
      nativeHttp: window.__NATIVE_HTTP || []
    }))()""")
    csp = [c[1][:120] for c in s.console if 'Content Security Policy' in c[1] or 'Refused to' in c[1]]
    plugins = sorted({c.split('.')[0] for c in info['native']})
    check('game boots and the first screen appears (splash removed)', info['ready'] and gone is not None, 'splash gone after %ss' % gone)
    check('no NO-INTERNET popup after 25 s offline', not info['gateShown'])
    check('game clock uses the device clock (offline time is credited)', info['clock'] == 'device/verified', info['clock'])
    check('no page errors', not s.errors, s.errors[:3])
    check('no requests reached the network layer', not s.external, s.external[:3])
    check('JS egress guard recorded nothing', info['guard'] == 0, info['guardList'])
    check('no Content-Security-Policy violations', not csp, csp[:2])
    check('no native HTTP calls', not info['nativeHttp'], info['nativeHttp'])
    check('only offline-capable native plugins used', set(plugins) <= ALLOWED_NATIVE, plugins)
    skip_tutorial(s)
    # ---------------------------------------------------------------- D. monetisation safety (same session)
    print('== D. ads / purchases ==')
    s.ev("OC.api.addGems(500, 'test')")
    t1 = time.time()
    rewarded = s.ev("OC.api.showRewardedAd('income_boost').then(x => x)")
    check('rewarded action resolves locally (no ad SDK, no network)', rewarded is True and time.time() - t1 < 5, 'result=%s in %.1fs' % (rewarded, time.time() - t1))
    g0 = s.ev('OC.api.state().gems'); ent0 = json.dumps(s.ev('OC.api.state().entitlements'), sort_keys=True)
    pr = s.ev("OC.api.purchase({sku:'income_2x', title:'2x', price:'$4.99', source:'check'}).then(x => x)")
    g1 = s.ev('OC.api.state().gems'); ent1 = json.dumps(s.ev('OC.api.state().entitlements'), sort_keys=True)
    check('real-money purchase is refused and grants nothing', not pr and g0 == g1 and ent0 == ent1, 'returned=%s gems %s->%s' % (pr, g0, g1))
    sp = s.ev("OC.services.season && OC.services.season.canPurchase ? OC.services.season.canPurchase('pro') : null")
    check('season-pass purchase disabled', sp is None or sp.get('ok') is False, sp)
    errs0 = len(s.errors)
    s.ev("window.uO = () => false; OC.api.goTo('shop')"); time.sleep(2)
    s.ev("OC.api.goTo('settings')"); time.sleep(2)
    check('shop + settings screens: no errors', len(s.errors) == errs0 and not s.external, s.errors[errs0:][:2])
    # ---------------------------------------------------------------- B. persistence
    print('== B. save + restart ==')
    s.ev('save()')
    key = s.ev('Lc.saveKey')
    life1 = s.ev('OC.api.state().lifetimeEarned')
    saved = s.ev('!!localStorage.getItem(Lc.saveKey)')
check('progress is saved locally', saved, key)

def reopen(src, label, away_ms):
    dst = os.path.join(TMP, label)
    shutil.copytree(src, dst)
    rewind = """(function(){try{var k=%s;var o=JSON.parse(localStorage.getItem(k));if(!o)return;var d=%d;
      o.savedAt-=d; if(typeof o.seen==='number') o.seen-=d; localStorage.setItem(k,JSON.stringify(o));}catch(e){}})();""" % (json.dumps(key), away_ms)
    with Session(WEB, dst, native=True, airplane=True) as s2:
        if away_ms: s2.ctx.add_init_script(rewind)
        s2.goto(); time.sleep(10)
        out = dict(life=s2.ev('OC.api.state().lifetimeEarned'), restored=s2.ev('!!localStorage.getItem(Lc.saveKey)'),
                   errors=list(s2.errors), external=list(s2.external))
    return out

control = reopen(prof, 'control', 0)
check('progress survives an app restart', control['restored'] and control['life'] >= life1, 'lifetime earned %.2f -> %.2f' % (life1, control['life']))
away2 = reopen(prof, 'away2h', 2 * 3600 * 1000)
extra = (away2['life'] - life1) - (control['life'] - life1)
print('== C. time away ==')
check('2 hours away are credited offline (device clock)', extra > 10, 'extra lifetime earned vs 0 h control: %+.2f' % extra)
check('restarts: no page errors, no network', not (control['errors'] or away2['errors'] or control['external'] or away2['external']))

shutil.rmtree(TMP, ignore_errors=True)
failed = [n for n, ok in results if not ok]
print('\n%d checks, %d passed, %d failed' % (len(results), len(results) - len(failed), len(failed)))
sys.exit(1 if failed else 0)
