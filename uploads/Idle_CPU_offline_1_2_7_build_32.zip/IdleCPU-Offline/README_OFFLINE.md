# Idle CPU 1.2.7 (build 32) — offline build

This is the **original Idle CPU app** (Capacitor shell + its web game) with every online dependency removed or replaced
by the game's own local fallbacks. It is not a re-implementation: the game code in `app/src/main/assets/public` is the
original JavaScript, with the changes listed in `docs/WEB_LAYER_CHANGES.txt`.

## Build (GitHub Actions workflow: JDK 17, Gradle 8.6)

The ZIP holds one Gradle project (`settings.gradle` at its root, module `app`). The workflow's steps work unchanged:
`./gradlew assembleDebug` → `app/build/outputs/apk/debug/*.apk`.

* The first Gradle run executes `npm install` from `settings.gradle` to fetch Capacitor's Android libraries
  (`@capacitor/android` + 5 plugins, all `^6.0.0`). Node.js 18+ and network access are needed **at build time only**.
* No NDK/CMake is used (the original has no native code of its own); those workflow steps are harmless.
* Not built in the authoring environment (no Android SDK, Gradle or network there) — see `docs`/the chat report.

## Facts

| | original (Play build) | this project |
|---|---|---|
| applicationId | `com.studioadept.computer` | `com.studioadept.computer.offline` (`-PidleCpuAppId=com.studioadept.computer` to change) |
| version | 1.2.7 (32) | 1.2.7-offline (32) |
| Capacitor | 7.x/8.x (needs JDK 21) | **6.x** (the newest line that builds on JDK 17) |
| compile/target SDK | 36 / 36 | 34 / 34 (min 24, unchanged) |
| permissions | 20 (INTERNET, billing, ad id, …) | 3: POST_NOTIFICATIONS, VIBRATE, RECEIVE_BOOT_COMPLETED |
| native plugins | 5 Capacitor + 5 Firebase + AppMetrica, Billing, Sign-In, Review, Adjust, AppLovin MAX (+ ~20 ad SDKs) | App, Haptics, LocalNotifications, Preferences, SplashScreen, NotificationSettings |

Verify the built APK has no network permission: `aapt2 dump permissions app-debug.apk` (expect only the three above).

## What changed (short)

* Web layer: connectivity gate removed; trusted network clock → device clock; Firebase (auth, cloud save, clans, clash, vault,
  arena, world feed, map events, push, remote config, analytics, crashlytics, app-check), AppLovin MAX, Adjust, AppMetrica,
  Play Billing, consent and review code removed or stubbed; remote-config defaults switched to local values; the prototype
  "TEST PURCHASE" sheet disabled so nothing paid is granted for free; page CSP + JS guard block every non-local host.
* Native layer: `MainActivity` and `NotificationSettingsPlugin` rebuilt from the original bytecode behaviour; manifest,
  icons, splash and theme taken from the original resources.

## Known limits

Real multiplayer/cloud/ads/purchases can't exist offline — the shop's real-money items show as unavailable, leaderboards/clans
use the game's built-in sample data. Save data of the Play version cannot be imported (it lives in the other app's storage).
Untested on a device: Android WebView behaviour, the Java classes, notifications, the APK itself.

`tools/web-checks` re-runs the web-layer offline checks (see its README).
