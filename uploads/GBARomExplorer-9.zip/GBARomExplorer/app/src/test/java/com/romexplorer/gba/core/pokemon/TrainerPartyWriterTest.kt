package com.romexplorer.gba.core.pokemon

import com.romexplorer.gba.core.graphics.GbaGraphics
import com.romexplorer.gba.core.hex.EditOverlay
import com.romexplorer.gba.core.rom.ByteArrayRomAccessor
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TrainerPartyWriterTest {

    @Test
    fun `entrySize grows with held-item and custom-moveset flags`() {
        assertEquals(6, TrainerPartyWriter.entrySize(partyFlags = 0))
        assertEquals(8, TrainerPartyWriter.entrySize(partyFlags = 0x2)) // + held item
        assertEquals(14, TrainerPartyWriter.entrySize(partyFlags = 0x1)) // + custom moves
        assertEquals(16, TrainerPartyWriter.entrySize(partyFlags = 0x3)) // both
    }

    @Test
    fun `writeMember round trips through TrainerPartyReader for a full-shape party`() = runTest {
        val partyFlags = 0x3 // held item + custom moves
        val entrySize = TrainerPartyWriter.entrySize(partyFlags)
        val partyPointer = 0x100L
        val rom = ByteArrayRomAccessor(ByteArray((partyPointer + entrySize * 2).toInt()) { 0xFF.toByte() })
        val overlay = EditOverlay()

        val member = TrainerPartyMember(species = 25, level = 50, heldItem = 13, moves = listOf(1, 2, 3, 4))
        val ok = TrainerPartyWriter.writeMember(rom, overlay, partyPointer, partyFlags, partySize = 2, memberIndex = 1, member)
        assertTrue(ok)

        // Read against the same rom + overlay writeMember was just given —
        // not a copy with the overlay pre-baked in — since that's what the
        // real app does (see PokemonTableViewModel.formatTrainerRow) and
        // is exactly the case a missing overlay parameter here wouldn't
        // catch: reading the *original* rom's bytes back would still pass
        // if TrainerPartyReader silently ignored the overlay altogether.
        val readBack = TrainerPartyReader.read(rom, partyFlags, partyPointer, partySize = 2, overlay = overlay)

        assertEquals(2, readBack.size)
        assertEquals(member, readBack[1])
    }

    @Test
    fun `a party edit is invisible without passing the overlay back in, and visible with it`() = runTest {
        // Guards the exact regression this app shipped once: writeMember
        // saving correctly (into the overlay) while the trainer team
        // screen kept showing stale, un-patched data because its read call
        // didn't pass the overlay back in — so a save appeared to silently
        // do nothing, or worse, show whatever stale bytes happened to sit
        // at that address.
        val partyFlags = 0
        val entrySize = TrainerPartyWriter.entrySize(partyFlags)
        val partyPointer = 0L
        val rom = ByteArrayRomAccessor(ByteArray(entrySize * 2) { 0xFF.toByte() })
        val overlay = EditOverlay()
        TrainerPartyWriter.writeMember(rom, overlay, partyPointer, partyFlags, partySize = 1, memberIndex = 0, TrainerPartyMember(1, 5, null, null))

        val withoutOverlay = TrainerPartyReader.read(rom, partyFlags, partyPointer, partySize = 1)
        assertEquals(0xFFFF, withoutOverlay[0].species) // stale — the edit exists only in the overlay

        val withOverlay = TrainerPartyReader.read(rom, partyFlags, partyPointer, partySize = 1, overlay = overlay)
        assertEquals(1, withOverlay[0].species) // the edit, correctly applied
    }

    @Test
    fun `writeMember leaves other slots untouched`() = runTest {
        val partyFlags = 0 // plain shape, 6 bytes/entry
        val entrySize = TrainerPartyWriter.entrySize(partyFlags)
        val partyPointer = 0L
        val rom = ByteArrayRomAccessor(ByteArray(entrySize * 3) { 0xFF.toByte() })
        val overlay = EditOverlay()

        TrainerPartyWriter.writeMember(rom, overlay, partyPointer, partyFlags, partySize = 3, memberIndex = 0, TrainerPartyMember(1, 5, null, null))
        TrainerPartyWriter.writeMember(rom, overlay, partyPointer, partyFlags, partySize = 3, memberIndex = 2, TrainerPartyMember(3, 15, null, null))

        val readBack = TrainerPartyReader.read(rom, partyFlags, partyPointer, partySize = 3, overlay = overlay)

        assertEquals(1, readBack[0].species)
        assertEquals(0xFFFF, readBack[1].species) // untouched slot still reads back as its original (unwritten) bytes
        assertEquals(3, readBack[2].species)
    }

    @Test
    fun `writeMember rejects a member index outside the real party size instead of writing past it`() = runTest {
        // Regression test: a stale memberIndex (e.g. a resize finishing
        // between when a caller read the party and when it calls this)
        // used to be trusted blindly, computing a destination past this
        // trainer's own party data and splicing the write into whatever
        // bytes happened to follow — which is indistinguishable, from the
        // UI, from "I edited a Pokémon and it now shows nonsense".
        val partyFlags = 0
        val entrySize = TrainerPartyWriter.entrySize(partyFlags)
        val partyPointer = 0L
        // Enough ROM for far more than one entry, so a wrongly-computed
        // destination would still land in-bounds and succeed silently if
        // this check didn't exist.
        val rom = ByteArrayRomAccessor(ByteArray(entrySize * 10) { 0xFF.toByte() })
        val overlay = EditOverlay()

        val ok = TrainerPartyWriter.writeMember(
            rom,
            overlay,
            partyPointer,
            partyFlags,
            partySize = 2,
            memberIndex = 5, // out of range for a party of 2
            TrainerPartyMember(1, 5, null, null),
        )

        assertEquals(false, ok)
        assertEquals(false, overlay.isDirty) // nothing was written anywhere, not even at the wrong offset
    }

    @Test
    fun `resize relocates the party into free space and the new party is visible once the overlay is applied`() = runTest {
        // No prior coverage of resize() existed at all — added alongside
        // the round-trip fix above since resize() feeds the exact same
        // downstream read path (TrainerPartyReader.read) that used to
        // silently ignore the overlay.
        val partyFlags = 0
        val trainerTableOffset = 0L
        // The trainer's own 40-byte row must NOT look like free space itself
        // (findFreeRun treats any 0xFF byte as claimable) — only the 64
        // bytes after it are free for resize() to place the party into.
        val rom = ByteArrayRomAccessor(ByteArray(40) { 0 } + ByteArray(64) { 0xFF.toByte() })
        val overlay = EditOverlay()

        val newMembers = listOf(
            TrainerPartyMember(species = 10, level = 7, heldItem = null, moves = null),
            TrainerPartyMember(species = 11, level = 8, heldItem = null, moves = null),
        )
        assertTrue(TrainerPartyWriter.resize(rom, overlay, trainerRowIndex = 0, trainerTableOffset, partyFlags, newMembers))

        // Party Size (offset 32) and Party Pointer (offset 36) are within
        // the trainer's own 40-byte row — read them the same way the app's
        // own trainer table read does, through the overlay.
        val headerBytes = rom.read(0, 40)
        overlay.applyToRange(headerBytes, trainerTableOffset)
        val partySize = headerBytes[32].toInt() and 0xFF
        val partyPointer = GbaGraphics.readPointer32(headerBytes, 36)!!

        assertEquals(2, partySize)
        assertEquals(newMembers, TrainerPartyReader.read(rom, partyFlags, partyPointer, partySize, overlay))
    }

    @Test
    fun `resize refuses to claim a reserved range even though it looks like free space`() = runTest {
        // Regression test for the actual reported bug: a real trainer's
        // party data routinely contains 0xFF bytes on purpose (the iv
        // field is conventionally 0xFFFF), so a plain byte-value scan can
        // mistake another trainer's real party for free space and
        // overwrite it. Here the only 0xFF run in the whole ROM is marked
        // reserved (standing in for "some other trainer's real party"),
        // and there's nowhere else free — resize() must fail rather than
        // silently write into it.
        val partyFlags = 0
        val rom = ByteArrayRomAccessor(ByteArray(40) { 0 } + ByteArray(64) { 0xFF.toByte() })
        val overlay = EditOverlay()
        val onlyFreeRun = 40L until 104L // the entire 0xFF block above

        val newMembers = listOf(TrainerPartyMember(species = 10, level = 7, heldItem = null, moves = null))
        val ok = TrainerPartyWriter.resize(
            rom, overlay, trainerRowIndex = 0, trainerTableOffset = 0L, partyFlags, newMembers,
            reservedRanges = listOf(onlyFreeRun),
        )

        assertEquals(false, ok)
        assertEquals(false, overlay.isDirty) // nothing was written anywhere, including a partial header update
    }

    @Test
    fun `resize skips a reserved range and uses free space beyond it instead of corrupting it`() = runTest {
        val partyFlags = 0
        // 40-byte header, then a reserved-looking 0xFF stretch (another
        // trainer's real party), then genuinely free space after it.
        val rom = ByteArrayRomAccessor(ByteArray(40) { 0 } + ByteArray(20) { 0xFF.toByte() } + ByteArray(64) { 0xFF.toByte() })
        val overlay = EditOverlay()
        val reservedTrainerPartyRange = 40L until 60L

        val newMembers = listOf(TrainerPartyMember(species = 10, level = 7, heldItem = null, moves = null))
        val ok = TrainerPartyWriter.resize(
            rom, overlay, trainerRowIndex = 0, trainerTableOffset = 0L, partyFlags, newMembers,
            reservedRanges = listOf(reservedTrainerPartyRange),
        )

        assertTrue(ok)
        val headerBytes = rom.read(0, 40)
        overlay.applyToRange(headerBytes, 0L)
        val partyPointer = GbaGraphics.readPointer32(headerBytes, 36)!!
        assertTrue("resize must not have placed the new party inside the reserved range", partyPointer !in reservedTrainerPartyRange)
    }
}
