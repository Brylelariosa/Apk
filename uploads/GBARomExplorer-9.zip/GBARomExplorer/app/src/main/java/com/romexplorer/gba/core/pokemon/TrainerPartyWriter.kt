package com.romexplorer.gba.core.pokemon

import com.romexplorer.gba.core.common.FreeSpaceAllocator
import com.romexplorer.gba.core.hex.EditOverlay
import com.romexplorer.gba.core.rom.RomAccessor

/**
 * Writes a trainer's party back to the ROM — the one write path in this
 * app that touches [FireRedTables.trainers]' "Party Pointer" field on
 * purpose. Ordinary field edits ([PokemonTableWriter]) refuse to touch any
 * [com.romexplorer.gba.core.pokemon.model.FieldKind.POINTER32] field
 * deliberately, since editing one usually means something is being
 * relocated, not just changed — that's exactly what [resize] does here,
 * explicitly and only when the party's member count actually changes.
 *
 * Party entry layout (6/8/10/12 bytes depending on the trainer's "Party
 * Flags") is the same one [TrainerPartyReader] decodes — see that class
 * and [FireRedTables]'s class doc for sourcing.
 */
object TrainerPartyWriter {
    private const val FLAG_CUSTOM_MOVESET = 0x1
    private const val FLAG_HELD_ITEM = 0x2
    private const val MOVES_PER_MON = 4
    private const val IV_LEVEL_SPECIES_SIZE = 6 // u16 iv + u8 lvl + 1 pad byte + u16 species — see TrainerPartyReader
    private const val PARTY_SIZE_FIELD_OFFSET = 32
    private const val PARTY_POINTER_FIELD_OFFSET = 36
    private const val TRAINER_ENTRY_SIZE = 40

    fun entrySize(partyFlags: Int): Int {
        val hasItem = partyFlags and FLAG_HELD_ITEM != 0
        val hasCustomMoves = partyFlags and FLAG_CUSTOM_MOVESET != 0
        return IV_LEVEL_SPECIES_SIZE + (if (hasItem) 2 else 0) + (if (hasCustomMoves) 2 * MOVES_PER_MON else 0)
    }

    private fun serialize(member: TrainerPartyMember, partyFlags: Int): ByteArray {
        val hasItem = partyFlags and FLAG_HELD_ITEM != 0
        val hasCustomMoves = partyFlags and FLAG_CUSTOM_MOVESET != 0
        val bytes = ByteArray(entrySize(partyFlags))
        // bytes[0..1] (iv) and bytes[3] (the species-alignment pad byte)
        // are left at 0 — TrainerPartyMember doesn't model a per-mon IV, so
        // there's nothing meaningful to write there.
        bytes[2] = member.level.toByte()
        writeU16(bytes, 4, member.species)
        var offset = IV_LEVEL_SPECIES_SIZE
        if (hasItem) {
            writeU16(bytes, offset, member.heldItem ?: 0)
            offset += 2
        }
        if (hasCustomMoves) {
            val moves = member.moves ?: List(MOVES_PER_MON) { 0 }
            for (m in 0 until MOVES_PER_MON) writeU16(bytes, offset + m * 2, moves.getOrElse(m) { 0 })
        }
        return bytes
    }

    private fun writeU16(bytes: ByteArray, offset: Int, value: Int) {
        bytes[offset] = (value and 0xFF).toByte()
        bytes[offset + 1] = ((value shr 8) and 0xFF).toByte()
    }

    /**
     * Edits one existing party slot in place — species/level/item/moves —
     * without touching the party's size or location. [member]'s shape
     * (whether [TrainerPartyMember.heldItem]/[TrainerPartyMember.moves]
     * are present) should match this trainer's "Party Flags"; a mismatch
     * isn't rejected — a missing item/moves field just serializes as 0,
     * same as [TrainerPartyReader.read] decoding it as "not present" would
     * expect.
     *
     * [partySize] must be this trainer's real, current party size (from
     * the same read [memberIndex] came from) — [memberIndex] is rejected
     * rather than trusted blindly once it's outside `0 until partySize`,
     * since a stale index (a resize finishing between when a caller read
     * the party and when it calls this) would otherwise compute a
     * destination past this trainer's own party data and silently splice
     * the write into whatever bytes happen to follow it.
     */
    suspend fun writeMember(
        rom: RomAccessor,
        overlay: EditOverlay,
        partyPointer: Long,
        partyFlags: Int,
        partySize: Int,
        memberIndex: Int,
        member: TrainerPartyMember,
    ): Boolean {
        if (partyPointer <= 0 || memberIndex !in 0 until partySize) return false
        val destination = partyPointer + memberIndex.toLong() * entrySize(partyFlags)
        return FreeSpaceAllocator.write(rom, overlay, destination, serialize(member, partyFlags))
    }

    /**
     * Changes how many Pokémon a trainer has. Unlike [writeMember], this
     * can't just overwrite in place — the party array's total byte length
     * changes, so growing it risks overwriting whatever happens to sit
     * right after the current array. Instead this always relocates the
     * *entire* party to a fresh block of free space (see
     * [FreeSpaceAllocator]) sized for [newMembers], then repoints the
     * trainer's own "Party Pointer" and "Party Size" fields at it — even
     * when shrinking, so a trainer's party is never split across two
     * locations. The old block is simply abandoned (its bytes stay as they
     * were; nothing reclaims them as free space automatically) — the same
     * trade-off every [FreeSpaceAllocator] caller in this app makes.
     *
     * [reservedRanges] should cover every *other* trainer's actual current
     * party data (see [PokemonTableViewModel.resizeTrainerParty], which
     * computes this from the same trainer-table read it already has) —
     * [FreeSpaceAllocator.findFreeRun] only looks at byte *values*, and a
     * real trainer Pokémon's `iv` field is conventionally 0xFFFF, the same
     * byte [FreeSpaceAllocator] treats as "unused ROM space". Without this,
     * a search that happens to run through a stretch of real party data
     * whose `iv` fields (and whatever else nearby happens to also be 0xFF)
     * chain into a long enough run can — and, in practice, does — get
     * claimed and overwritten, corrupting a *different* trainer's party
     * that was never touched on purpose.
     */
    suspend fun resize(
        rom: RomAccessor,
        overlay: EditOverlay,
        trainerRowIndex: Int,
        trainerTableOffset: Long,
        partyFlags: Int,
        newMembers: List<TrainerPartyMember>,
        reservedRanges: List<LongRange> = emptyList(),
    ): Boolean {
        if (trainerRowIndex < 0) return false
        val size = entrySize(partyFlags)
        val totalBytes = size * newMembers.size
        val trainerEntryStart = trainerTableOffset + trainerRowIndex.toLong() * TRAINER_ENTRY_SIZE

        val destination = if (totalBytes == 0) {
            0L
        } else {
            FreeSpaceAllocator.findFreeRun(rom, overlay, totalBytes, reservedRanges = reservedRanges) ?: return false
        }

        if (totalBytes > 0) {
            val serialized = ByteArray(totalBytes)
            newMembers.forEachIndexed { i, member -> serialize(member, partyFlags).copyInto(serialized, i * size) }
            if (!FreeSpaceAllocator.write(rom, overlay, destination, serialized)) return false
        }

        val pointerRaw = if (destination == 0L) 0L else FreeSpaceAllocator.toRomPointer(destination)
        val sizeOk = FreeSpaceAllocator.write(
            rom,
            overlay,
            trainerEntryStart + PARTY_SIZE_FIELD_OFFSET,
            FreeSpaceAllocator.leBytes(newMembers.size.toLong(), 1),
        )
        val pointerOk = FreeSpaceAllocator.write(
            rom,
            overlay,
            trainerEntryStart + PARTY_POINTER_FIELD_OFFSET,
            FreeSpaceAllocator.leBytes(pointerRaw, 4),
        )
        return sizeOk && pointerOk
    }
}
