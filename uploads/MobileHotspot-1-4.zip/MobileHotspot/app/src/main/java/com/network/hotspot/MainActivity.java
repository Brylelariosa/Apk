package com.network.hotspot;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

public class MainActivity extends AppCompatActivity {

    static final String PREFS_NAME = "hotspot_prefs";
    static final String KEY_ENABLED = "hotspot_enabled";

    private boolean mIgnoreToggle = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SwitchCompat mainSwitch = findViewById(R.id.switch_hotspot);
        TextView tvStatus = findViewById(R.id.tv_status);

        // Show the REAL hotspot state, not just what we saved last time
        boolean hotspotOn = HotspotManager.isHotspotEnabled(this);
        mIgnoreToggle = true;
        mainSwitch.setChecked(hotspotOn);
        mIgnoreToggle = false;
        updateStatus(tvStatus, hotspotOn);

        mainSwitch.setOnCheckedChangeListener((btn, isChecked) -> {
            if (mIgnoreToggle) return;

            if (isChecked) {
                // User turned ON → actually enable the real hotspot
                boolean ok = HotspotManager.enableHotspot(this);
                if (!ok) {
                    // Reflection was blocked — open system hotspot settings as fallback
                    Toast.makeText(this, "Opening hotspot settings…", Toast.LENGTH_SHORT).show();
                    try {
                        startActivity(new Intent("android.settings.TETHER_SETTINGS"));
                    } catch (Exception ex) {
                        startActivity(new Intent(Settings.ACTION_WIRELESS_SETTINGS));
                    }
                }
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                prefs.edit().putBoolean(KEY_ENABLED, true).apply();
                updateStatus(tvStatus, true);

            } else {
                // User tried to turn OFF → block it, snap switch back to ON
                // Hotspot stays running, nothing is disabled
                mIgnoreToggle = true;
                mainSwitch.setChecked(true);
                mIgnoreToggle = false;
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Re-read actual hotspot state when coming back (e.g. from system settings)
        SwitchCompat mainSwitch = findViewById(R.id.switch_hotspot);
        TextView tvStatus = findViewById(R.id.tv_status);
        boolean hotspotOn = HotspotManager.isHotspotEnabled(this);
        mIgnoreToggle = true;
        mainSwitch.setChecked(hotspotOn);
        mIgnoreToggle = false;
        updateStatus(tvStatus, hotspotOn);
    }

    private void updateStatus(TextView tv, boolean enabled) {
        tv.setText(enabled ? R.string.status_on : R.string.status_off);
    }
}
