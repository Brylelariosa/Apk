package com.network.hotspot;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

public class MainActivity extends AppCompatActivity {

    static final String PREFS_NAME = "hotspot_prefs";
    static final String KEY_ENABLED = "hotspot_enabled";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SwitchCompat mainSwitch = findViewById(R.id.switch_hotspot);
        TextView tvStatus = findViewById(R.id.tv_status);

        boolean hotspotOn = HotspotManager.isHotspotEnabled(this);
        mainSwitch.setChecked(hotspotOn);
        updateStatus(tvStatus, hotspotOn);

        mainSwitch.setOnCheckedChangeListener((btn, isChecked) -> {
            if (isChecked) {
                // ── Toggled ON ── actually enable the real hotspot
                boolean ok = HotspotManager.enableHotspot(this);
                if (!ok) {
                    // Reflection blocked by OS — open system tethering settings
                    // so the user can enable it with one tap there
                    Toast.makeText(this, "Opening hotspot settings…", Toast.LENGTH_SHORT).show();
                    openTetheringSettings();
                }
                prefs.edit().putBoolean(KEY_ENABLED, true).apply();
                updateStatus(tvStatus, true);

            } else {
                // ── Toggled OFF ── let the switch go to OFF visually
                // but DO NOT disable the hotspot — it keeps running
                prefs.edit().putBoolean(KEY_ENABLED, false).apply();
                updateStatus(tvStatus, false);
                // (no call to disable hotspot here — intentionally blank)
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Refresh real hotspot state when coming back from system settings
        SwitchCompat mainSwitch = findViewById(R.id.switch_hotspot);
        TextView tvStatus = findViewById(R.id.tv_status);
        boolean hotspotOn = HotspotManager.isHotspotEnabled(this);
        mainSwitch.setChecked(hotspotOn);
        updateStatus(tvStatus, hotspotOn);
    }

    private void openTetheringSettings() {
        // Try direct tethering settings page first
        try {
            startActivity(new Intent("android.settings.TETHER_SETTINGS"));
            return;
        } catch (Exception ignored) {}
        // Fallback: general wireless settings
        try {
            startActivity(new Intent(Settings.ACTION_WIRELESS_SETTINGS));
        } catch (Exception ignored) {}
    }

    private void updateStatus(TextView tv, boolean enabled) {
        tv.setText(enabled ? R.string.status_on : R.string.status_off);
    }
}
