package com.network.hotspot;

import android.content.SharedPreferences;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;

public class HotspotTileService extends TileService {

    @Override
    public void onStartListening() {
        super.onStartListening();
        refreshTile();
    }

    @Override
    public void onClick() {
        super.onClick();
        Tile tile = getQsTile();
        if (tile == null) return;

        if (tile.getState() != Tile.STATE_ACTIVE) {
            // Tile is OFF → enable the real hotspot
            HotspotManager.enableHotspot(this);
            SharedPreferences prefs = getSharedPreferences(MainActivity.PREFS_NAME, MODE_PRIVATE);
            prefs.edit().putBoolean(MainActivity.KEY_ENABLED, true).apply();
        }
        // If tile is already ACTIVE → do nothing, hotspot stays on

        refreshTile();
    }

    private void refreshTile() {
        Tile tile = getQsTile();
        if (tile == null) return;

        // Check the actual system hotspot state
        boolean enabled = HotspotManager.isHotspotEnabled(this);

        // Fall back to our saved pref if reflection can't read state
        if (!enabled) {
            SharedPreferences prefs = getSharedPreferences(MainActivity.PREFS_NAME, MODE_PRIVATE);
            enabled = prefs.getBoolean(MainActivity.KEY_ENABLED, false);
        }

        tile.setState(enabled ? Tile.STATE_ACTIVE : Tile.STATE_INACTIVE);
        tile.updateTile();
    }
}
