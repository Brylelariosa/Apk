package com.network.hotspot;

import android.content.SharedPreferences;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;

public class HotspotTileService extends TileService {

    @Override
    public void onStartListening() {
        super.onStartListening();
        refreshTile();
    }

    @Override
    public void onClick() {
        super.onClick();
        Tile tile = getQsTile();
        if (tile == null) return;

        SharedPreferences prefs = getSharedPreferences(MainActivity.PREFS_NAME, MODE_PRIVATE);

        if (tile.getState() == Tile.STATE_ACTIVE) {
            // ── Tapped while ON ── let tile show OFF visually
            // but DO NOT disable the hotspot — it keeps running
            tile.setState(Tile.STATE_INACTIVE);
            prefs.edit().putBoolean(MainActivity.KEY_ENABLED, false).apply();

        } else {
            // ── Tapped while OFF ── actually try to enable the hotspot
            HotspotManager.enableHotspot(this);
            tile.setState(Tile.STATE_ACTIVE);
            prefs.edit().putBoolean(MainActivity.KEY_ENABLED, true).apply();
        }

        tile.updateTile();
    }

    private void refreshTile() {
        Tile tile = getQsTile();
        if (tile == null) return;

        // Check real hotspot state first; fall back to saved pref
        boolean enabled = HotspotManager.isHotspotEnabled(this);
        if (!enabled) {
            SharedPreferences prefs = getSharedPreferences(MainActivity.PREFS_NAME, MODE_PRIVATE);
            enabled = prefs.getBoolean(MainActivity.KEY_ENABLED, false);
        }

        tile.setState(enabled ? Tile.STATE_ACTIVE : Tile.STATE_INACTIVE);
        tile.updateTile();
    }
}
