package com.network.hotspot;

import android.content.Context;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiManager;
import java.lang.reflect.Method;

public class HotspotManager {

    // Hidden AP state constants from WifiManager
    private static final int WIFI_AP_STATE_ENABLING = 12;
    private static final int WIFI_AP_STATE_ENABLED  = 13;

    /**
     * Returns true if the real system hotspot is currently on or starting up.
     * Uses reflection to call the hidden getWifiApState() method.
     */
    public static boolean isHotspotEnabled(Context context) {
        WifiManager manager = (WifiManager) context.getApplicationContext()
                .getSystemService(Context.WIFI_SERVICE);
        if (manager == null) return false;
        try {
            Method method = manager.getClass().getDeclaredMethod("getWifiApState");
            int state = (Integer) method.invoke(manager);
            return state == WIFI_AP_STATE_ENABLED || state == WIFI_AP_STATE_ENABLING;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Actually enables the system hotspot via reflection on setWifiApEnabled().
     * Returns true if the call was accepted (hotspot may take a moment to start).
     * Returns false if reflection is blocked (caller should open system settings).
     */
    public static boolean enableHotspot(Context context) {
        WifiManager manager = (WifiManager) context.getApplicationContext()
                .getSystemService(Context.WIFI_SERVICE);
        if (manager == null) return false;
        try {
            Method method = manager.getClass().getDeclaredMethod(
                    "setWifiApEnabled", WifiConfiguration.class, boolean.class);
            Object result = method.invoke(manager, null, true);
            // result is Boolean on older APIs, null on some newer ones — treat null as success
            return result == null || Boolean.TRUE.equals(result);
        } catch (Exception e) {
            return false;
        }
    }
}
