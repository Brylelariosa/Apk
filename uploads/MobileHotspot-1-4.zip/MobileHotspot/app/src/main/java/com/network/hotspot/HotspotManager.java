package com.network.hotspot;

import android.content.Context;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiManager;
import java.lang.reflect.Method;

public class HotspotManager {

    private static final int WIFI_AP_STATE_ENABLING = 12;
    private static final int WIFI_AP_STATE_ENABLED  = 13;

    /** True if the real system hotspot is currently on or starting. */
    public static boolean isHotspotEnabled(Context context) {
        WifiManager wm = (WifiManager) context.getApplicationContext()
                .getSystemService(Context.WIFI_SERVICE);
        if (wm == null) return false;
        try {
            Method m = wm.getClass().getDeclaredMethod("getWifiApState");
            m.setAccessible(true);
            int state = (Integer) m.invoke(wm);
            return state == WIFI_AP_STATE_ENABLED || state == WIFI_AP_STATE_ENABLING;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Tries to enable the system WiFi hotspot via reflection.
     * Returns true if the call was accepted, false if the OS blocked it
     * (caller should then open system tethering settings as fallback).
     */
    public static boolean enableHotspot(Context context) {
        WifiManager wm = (WifiManager) context.getApplicationContext()
                .getSystemService(Context.WIFI_SERVICE);
        if (wm == null) return false;
        try {
            Method m = wm.getClass().getDeclaredMethod(
                    "setWifiApEnabled", WifiConfiguration.class, boolean.class);
            m.setAccessible(true);
            Object result = m.invoke(wm, null, true);
            // result is Boolean on older APIs, null on some newer ones
            return result == null || Boolean.TRUE.equals(result);
        } catch (Exception e) {
            return false;
        }
    }
}
