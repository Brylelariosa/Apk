package com.browser.app

import android.content.Context
import android.util.AttributeSet
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.webkit.WebView

class ScrollAwareWebView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : WebView(context, attrs, defStyleAttr) {

    var onScrollCallback: ((dy: Int) -> Unit)? = null
    var onWebInputFocused: (() -> Unit)? = null
    var onDebugEvent: ((String) -> Unit)? = null   // debug overlay hook

    override fun onScrollChanged(l: Int, t: Int, oldl: Int, oldt: Int) {
        super.onScrollChanged(l, t, oldl, oldt)
        onScrollCallback?.invoke(t - oldt)
    }

    override fun onCheckIsTextEditor(): Boolean = true

    override fun onCreateInputConnection(outAttrs: EditorInfo): InputConnection? {
        val ic = super.onCreateInputConnection(outAttrs)
        onDebugEvent?.invoke("onCreateIC: ic=${if (ic != null) "OK" else "NULL"}")
        if (ic != null) {
            // Just update state — the IMM already has the InputConnection and will
            // show the keyboard itself. Calling showSoftInput here would create a
            // duplicate session and break typing on many devices.
            post { onWebInputFocused?.invoke() }
        }
        return ic
    }
}
