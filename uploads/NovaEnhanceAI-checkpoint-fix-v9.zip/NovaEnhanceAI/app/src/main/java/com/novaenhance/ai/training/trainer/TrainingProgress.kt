package com.novaenhance.ai.training.trainer

import com.novaenhance.ai.database.entities.TrainingStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Which stage of the pipeline is currently running. A session goes
 * TRAINING (the batch loop) -> SAVING_CHECKPOINT -> VALIDATING (old-vs-new
 * model comparison over held-out pairs) before it reaches a terminal
 * [TrainingStatus] - see where each phase is published in [ModelTrainer].
 * A *promoted* session is then followed by a separate RESCORING pass
 * ([SelfImprovementOrchestrator]) that isn't part of the session's own
 * unit budget (its size depends on whether promotion happens at all, which
 * isn't known until validation finishes), so it's reported as its own
 * phase with its own [TrainingProgressState.totalUnits] rather than folded
 * into the session's.
 */
enum class TrainingPhase { TRAINING, SAVING_CHECKPOINT, VALIDATING, RESCORING }

/** Live snapshot for the Train AI screen: phase, epoch, current pair, progress, loss, speed, ETA, memory. */
data class TrainingProgressState(
    val sessionId: Long,
    val phase: TrainingPhase,
    val epoch: Int,
    val totalEpochs: Int,
    /**
     * Progress within the *current phase*: batch-in-epoch while TRAINING,
     * old/new validation passes done while VALIDATING, sampled pairs
     * re-scored while RESCORING, (0,1)/(1,1) while SAVING_CHECKPOINT (one
     * atomic step). Meaningful only alongside [phase] - a UI reading this
     * should branch on phase first.
     */
    val phaseStepIndex: Int,
    val phaseStepTotal: Int,
    /**
     * Progress across the *whole pipeline* this [phase] belongs to (every
     * step of it, start to finish) - what [overallFraction] and the
     * progress bar/notification are bound to. For TRAINING/
     * SAVING_CHECKPOINT/VALIDATING this spans the full session (every
     * epoch's batches, the checkpoint write, and every held-out
     * validation pair) so it climbs smoothly through all three instead of
     * resetting or stalling between them. RESCORING's own totalUnits is
     * separate (see [phase]'s doc).
     */
    val unitsCompleted: Int,
    val totalUnits: Int,
    val latestLoss: Float?,
    val imagesPerSecond: Float,
    val estimatedSecondsRemaining: Long,
    val memoryUsedMb: Long,
    val status: TrainingStatus
)

/**
 * Progress through the pipeline [TrainingProgressState.phase] belongs to,
 * 0f..1f. A flat [unitsCompleted]/[totalUnits] ratio, not the nested
 * epoch/batch fraction this used to be: that math only ever reflected the
 * batch loop, so the checkpoint-save and validation tail after the very
 * last batch reported no progress at all and the bar visibly froze -
 * often short of 100%, since the last batch of the last epoch is index
 * totalBatches-1, not totalBatches - for as long as that tail took, which
 * for validation's own tile-based inference passes (see [ModelValidator])
 * can be a minute or more. [unitsCompleted] now keeps advancing through
 * that whole tail (see [ModelTrainer]), so this stays live the entire way
 * to completion.
 */
val TrainingProgressState.overallFraction: Float
    get() = if (totalUnits <= 0) 0f else (unitsCompleted.toFloat() / totalUnits).coerceIn(0f, 1f)

enum class TrainingCommand { RUN, PAUSE, CANCEL }

/**
 * The pause/resume/cancel channel between whatever is driving the UI
 * (Train AI screen buttons, or a notification action on the foreground
 * service) and every long-running stage of the pipeline: [ModelTrainer]'s
 * batch loop polls [command] directly between batches, and the tail phases
 * that run after it - validation, then a promoted session's rescoring pass
 * (see [stopRequested]) - poll between pairs. Never mid-batch or mid-pair,
 * so a pause/cancel always lands on a clean, checkpoint-safe boundary.
 */
class TrainingControlFlow {
    private val _command = MutableStateFlow(TrainingCommand.RUN)
    val command: StateFlow<TrainingCommand> = _command.asStateFlow()

    fun resume() { _command.value = TrainingCommand.RUN }
    fun pause() { _command.value = TrainingCommand.PAUSE }
    fun cancel() { _command.value = TrainingCommand.CANCEL }
}

/**
 * True once PAUSE or CANCEL has been requested. A single-purpose, reusable
 * check for any loop that just needs to stop promptly and can leave the
 * PAUSE-vs-CANCEL distinction to whoever actually acts on it - the tail
 * phases that run after the batch loop ([ModelValidator.validate],
 * [SelfImprovementOrchestrator]'s rescoring pass) each cost a full
 * tile-based enhance per pair, the same class of multi-second wait the
 * batch loop's own per-batch poll exists to bound, so they poll this too
 * rather than duplicating [TrainingCommand]'s three-way `when` at every
 * call site. [ModelTrainer]'s batch loop keeps reading [TrainingControlFlow.command]
 * directly since it's the one place that needs to choose between
 * [TrainingStatus.PAUSED] and [TrainingStatus.CANCELLED].
 */
val TrainingControlFlow.stopRequested: Boolean
    get() = command.value != TrainingCommand.RUN
