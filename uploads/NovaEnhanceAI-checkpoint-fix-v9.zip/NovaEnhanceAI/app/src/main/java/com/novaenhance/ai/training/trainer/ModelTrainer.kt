package com.novaenhance.ai.training.trainer

import android.graphics.Rect
import com.novaenhance.ai.ai.engine.NovaModelEngine
import com.novaenhance.ai.ai.engine.PixelBufferOps
import com.novaenhance.ai.ai.model.ModelRepository
import com.novaenhance.ai.database.dao.DatasetPairDao
import com.novaenhance.ai.database.dao.LossHistoryDao
import com.novaenhance.ai.database.dao.ModelDao
import com.novaenhance.ai.database.dao.ModelVersionDao
import com.novaenhance.ai.database.dao.TrainingSessionDao
import com.novaenhance.ai.database.dao.ValidationMetricDao
import com.novaenhance.ai.database.entities.DatasetPairEntity
import com.novaenhance.ai.database.entities.LossHistoryEntity
import com.novaenhance.ai.database.entities.ModelVersionEntity
import com.novaenhance.ai.database.entities.TrainingSessionEntity
import com.novaenhance.ai.database.entities.TrainingStatus
import com.novaenhance.ai.storage.AppStorage
import com.novaenhance.ai.training.dataset.DatasetAnalyzer
import com.novaenhance.ai.utils.DeviceCapabilities
import com.novaenhance.ai.utils.NovaLog
import com.novaenhance.ai.utils.ThermalGovernor
import com.novaenhance.ai.utils.decodeBitmapBounds
import com.novaenhance.ai.utils.decodeBitmapRegion
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.StateFlow
import kotlin.random.Random

private const val TAG = "ModelTrainer"
private const val CHECKPOINT_SAVE_EVERY_N_BATCHES = 20
private const val MIN_VALIDATION_HOLD_OUT = 1
private const val MAX_VALIDATION_HOLD_OUT = 20
private const val VALIDATION_HOLD_OUT_FRACTION = 0.15f

/**
 * The Self-Improvement Loop's engine room: collect data -> train -> evaluate
 * -> (find weak areas / prioritize similar data is handled one level up by
 * [SelfImprovementOrchestrator], which decides *when* to call this and with
 * what dataset slice). This class owns one training *session's* full
 * lifecycle: dataset analysis gate, adaptive planning, the pause/resume/
 * cancel-safe batch loop, periodic crash-recovery checkpoints, anti-
 * forgetting (anchor + replay), and validation-gated promotion.
 */
class ModelTrainer(
    private val modelRepository: ModelRepository,
    private val datasetPairDao: DatasetPairDao,
    private val trainingSessionDao: TrainingSessionDao,
    private val lossHistoryDao: LossHistoryDao,
    private val validationMetricDao: ValidationMetricDao,
    private val modelVersionDao: ModelVersionDao,
    private val modelDao: ModelDao,
    private val datasetAnalyzer: DatasetAnalyzer,
    private val adaptiveController: AdaptiveTrainingController,
    private val experienceMemory: ExperienceMemory,
    private val validator: ModelValidator,
    private val storage: AppStorage,
    private val deviceCapabilities: DeviceCapabilities,
    private val thermalGovernor: ThermalGovernor,
    private val progressPublisher: TrainingProgressPublisher
) {
    /**
     * [progress] and [lastError] delegate straight through to the shared
     * [TrainingProgressPublisher] (also written by [SelfImprovementOrchestrator]'s
     * RESCORING phase) rather than owning their own StateFlows, so every
     * existing caller of `modelTrainer.progress`/`.lastError` keeps working
     * unchanged while still seeing updates published by other stages of the
     * pipeline.
     */
    val progress: StateFlow<TrainingProgressState?> get() = progressPublisher.progress
    val lastError: StateFlow<String?> get() = progressPublisher.lastError

    /** Called by [com.novaenhance.ai.workers.TrainingForegroundService] when [runSession] throws. */
    fun reportStartupFailure(message: String) {
        progressPublisher.reportStartupFailure(message)
    }

    fun clearLastError() {
        progressPublisher.clearLastError()
    }

    /** Crash recovery: call at app/service start to find a session that never reached a terminal state. */
    suspend fun findRecoverableSession(): TrainingSessionEntity? =
        trainingSessionDao.findLatestWithStatus(TrainingStatus.RUNNING)

    /**
     * Runs (or resumes) one training session to completion, pause, or
     * cancellation. Must be called from a background-appropriate dispatcher
     * (this does blocking bitmap I/O and CPU-bound tensor work) - see
     * [com.novaenhance.ai.workers.TrainingForegroundService].
     *
     * Resets [control] to [TrainingCommand.RUN] before anything else runs.
     * [control] is a single process-lifetime instance (one per
     * [com.novaenhance.ai.di.ServiceLocator]) that only ever moves off RUN
     * via an explicit pause()/cancel() call and nothing ever moved it back
     * except this - so without the reset, the *first* pause or cancel of
     * the process's lifetime would leave it stuck at PAUSE/CANCEL forever.
     * Every later call to this function - a brand new session just as much
     * as an actual resume - would then hit the very first
     * `control.command.value` check in the batch loop below with a stale
     * command left over from a previous session, and immediately re-exit
     * via [finishAs] before running a single batch or publishing a single
     * progress update. That's what made the progress bar never appear and
     * Pause/Resume/Cancel look unresponsive: the buttons worked fine, but
     * every run they started was already over by the time the batch loop
     * got to its first iteration.
     */
    suspend fun runSession(modelId: String, resumeSessionId: Long?, control: TrainingControlFlow): TrainingSessionEntity {
        control.resume()
        progressPublisher.clearLastError()
        datasetAnalyzer.analyzeNewPairs(modelId)
        val usablePairs = datasetPairDao.getUsablePairsByDifficulty(modelId)
        require(usablePairs.isNotEmpty()) { "No usable training pairs for model $modelId" }

        val holdOut = (usablePairs.size * VALIDATION_HOLD_OUT_FRACTION).toInt()
            .coerceIn(MIN_VALIDATION_HOLD_OUT, MAX_VALIDATION_HOLD_OUT)
            .coerceAtMost(usablePairs.size - 1)
            .coerceAtLeast(0)
        // usablePairs is difficulty-ordered (hardest first, see
        // getUsablePairsByDifficulty), which trainPairs benefits from for
        // curriculum ordering - but WHICH pairs get held out is re-randomized
        // every session rather than always being the same fixed tail. On a
        // static/reused dataset a fixed takeLast() tail meant validation
        // metrics - and AdaptiveTrainingController's loss-trend heuristics,
        // which react to them indirectly via promoted-session history - kept
        // getting evaluated against the exact same (easiest) slice every
        // single session instead of a representative spread of difficulty.
        val validationIds = if (holdOut > 0) {
            usablePairs.shuffled().take(holdOut).map { it.id }.toSet()
        } else {
            emptySet()
        }
        val validationPairs = usablePairs.filter { it.id in validationIds }
        val trainPairs = usablePairs.filterNot { it.id in validationIds }

        val recentSessions = trainingSessionDao.getRecentCompleted(modelId, limit = 5)
        // Distinct high-quality-image hashes, not distinct pairs: several
        // synthetic variants (DatasetManager.addSyntheticPairs) share the
        // same source photo and same perceptualHashHigh even though each
        // gets its own randomized low-quality degradation and its own
        // perceptualHashLow (so DatasetAnalyzer's dedup doesn't catch them).
        // This is what actually distinguishes "20 pairs from 20 different
        // photos" from "20 pairs from 4 photos" for planSession's epoch cap.
        val uniqueSourceCount = trainPairs.distinctBy { it.perceptualHashHigh }.size
        val plan = adaptiveController.planSession(trainPairs.size, recentSessions, uniqueSourceCount)

        var session = resumeSessionId?.let { trainingSessionDao.getById(it) }
            ?: run {
                val fresh = TrainingSessionEntity(
                    modelId = modelId,
                    startedAt = System.currentTimeMillis(),
                    status = TrainingStatus.RUNNING,
                    plannedEpochs = plan.epochs,
                    batchSize = plan.batchSize,
                    learningRate = plan.learningRate,
                    replayFraction = plan.replayFraction,
                    datasetPairCount = trainPairs.size,
                    deviceRamMbAtStart = plan.deviceRamMbAtStart
                )
                val id = trainingSessionDao.insert(fresh)
                fresh.copy(id = id)
            }
        if (session.status != TrainingStatus.RUNNING) {
            session = session.copy(status = TrainingStatus.RUNNING)
            trainingSessionDao.update(session)
        }

        val activeVersion = modelVersionDao.getActiveVersion(modelId) ?: error("No active version for $modelId")
        val engine = modelRepository.getEngine(modelId)

        // Anti-forgetting anchor: snapshot pre-session weights once, before
        // any train() calls, so L2-SP can penalize drifting away from them.
        engine.setAnchor()

        val random = Random(System.currentTimeMillis())
        var initialLoss: Float? = null
        var lastLoss: Float? = null
        var batchesRun = 0
        var thermalCooldownOccurred = false
        val startMs = System.currentTimeMillis()
        // Same realPerBatch math buildBatches() uses (not plan.batchSize
        // directly), so this prediction can't drift from the batch counts
        // buildBatches() actually produces once replay blending shrinks how
        // many real pairs fit per batch.
        val realPerBatch = realPairsPerBatch(plan.batchSize, plan.replayFraction)
        val batchesPerEpoch = kotlin.math.ceil(trainPairs.size.toFloat() / realPerBatch).toInt().coerceAtLeast(1)
        val totalPlannedBatches = batchesPerEpoch * (session.plannedEpochs - session.epochsCompleted)
        // The session's full unit budget: every remaining batch, the final
        // checkpoint write (1 unit), and validation's old-model + new-model
        // pass over every held-out pair (see ModelValidator) - so the bar
        // keeps moving through the checkpoint-save and validation tail
        // instead of freezing the moment the last batch finishes.
        val totalUnits = totalPlannedBatches + 1 + validationPairs.size * 2

        for (epoch in session.epochsCompleted until session.plannedEpochs) {
            val batches = buildBatches(trainPairs, plan.batchSize, plan.replayFraction, modelId)

            for ((batchIndex, batch) in batches.withIndex()) {
                when (control.command.value) {
                    TrainingCommand.CANCEL -> return finishAs(session, TrainingStatus.CANCELLED, epoch, null)
                    TrainingCommand.PAUSE -> return finishAs(session, TrainingStatus.PAUSED, epoch, null)
                    TrainingCommand.RUN -> Unit
                }
                val throttle = thermalGovernor.evaluate()
                when (throttle.action) {
                    ThermalGovernor.ThrottleAction.PAUSE ->
                        return finishAs(session, TrainingStatus.PAUSED, epoch, null, throttled = true)
                    ThermalGovernor.ThrottleAction.COOL_DOWN -> {
                        thermalCooldownOccurred = true
                        delay(throttle.cooldownMillis)
                    }
                    ThermalGovernor.ThrottleAction.PROCEED -> Unit
                }

                val lowTiles = mutableListOf<IntArray>()
                val highTiles = mutableListOf<IntArray>()
                for ((lowPath, highPath) in batch) {
                    val (lowTile, highTile) = extractTrainingTile(lowPath, highPath, engine.tileSize, random) ?: continue
                    lowTiles += lowTile
                    highTiles += highTile
                }
                if (lowTiles.isEmpty()) continue

                val loss = engine.trainBatch(lowTiles, highTiles, plan.learningRate, plan.l2SpLambda)
                if (initialLoss == null) initialLoss = loss
                lastLoss = loss
                batchesRun++

                lossHistoryDao.insert(
                    LossHistoryEntity(sessionId = session.id, epoch = epoch, batchIndex = batchIndex, loss = loss, timestamp = System.currentTimeMillis())
                )

                publishProgress(session, epoch, plan, batchIndex, batches.size, loss, batchesRun, totalPlannedBatches, totalUnits, startMs)

                if (batchesRun % CHECKPOINT_SAVE_EVERY_N_BATCHES == 0) {
                    val inProgressFile = storage.weightsFile(modelId, activeVersion.versionNumber + 1)
                    runCatching { engine.saveCheckpoint(inProgressFile.path) }
                        .onFailure { NovaLog.w(TAG, "Mid-session checkpoint save failed", it) }
                }
            }
            session = session.copy(epochsCompleted = epoch + 1)
            trainingSessionDao.update(session)
        }

        if (thermalCooldownOccurred && !session.wasThrottledByThermal) {
            session = session.copy(wasThrottledByThermal = true)
            trainingSessionDao.update(session)
        }

        return finalizeSession(modelId, session, engine, activeVersion, trainPairs, validationPairs, initialLoss, lastLoss, totalPlannedBatches, totalUnits, control)
    }

    private suspend fun finalizeSession(
        modelId: String,
        session: TrainingSessionEntity,
        engine: NovaModelEngine,
        activeVersion: ModelVersionEntity,
        trainPairs: List<DatasetPairEntity>,
        validationPairs: List<DatasetPairEntity>,
        initialLoss: Float?,
        finalLoss: Float?,
        trainingUnitsCompleted: Int,
        totalUnits: Int,
        control: TrainingControlFlow
    ): TrainingSessionEntity {
        // Catches a pause/cancel that landed in the narrow gap between the
        // batch loop's last per-batch check and the loop simply running out
        // of batches - the epoch loop above only checks control *before*
        // each batch, so nothing polls it again between "last batch done"
        // and getting here. No checkpoint has been saved for this session
        // yet at this point (the periodic in-progress save is a crash-
        // recovery copy under the same path, not this session's own
        // promotion candidate), so there's nothing new to discard - same as
        // any other pause/cancel caught inside the batch loop itself.
        if (control.stopRequested) {
            return finishAs(
                session,
                if (control.command.value == TrainingCommand.CANCEL) TrainingStatus.CANCELLED else TrainingStatus.PAUSED,
                session.plannedEpochs,
                null
            )
        }

        publishPhase(session, TrainingPhase.SAVING_CHECKPOINT, 0, 1, trainingUnitsCompleted, totalUnits, finalLoss)

        val nextVersionNumber = (modelVersionDao.getLatestVersionNumber(modelId) ?: activeVersion.versionNumber) + 1
        val newWeightsFile = storage.weightsFile(modelId, nextVersionNumber)
        engine.saveCheckpoint(newWeightsFile.path)

        val afterCheckpointUnits = trainingUnitsCompleted + 1
        publishPhase(session, TrainingPhase.SAVING_CHECKPOINT, 1, 1, afterCheckpointUnits, totalUnits, finalLoss)

        // Independent, unmutated "before" model for a fair comparison -
        // `engine` has already moved on to the freshly trained weights.
        // (No close()/cleanup needed - NovaModelEngine is a plain Kotlin
        // object with no native handle to leak.)
        val oldEngine = NovaModelEngine.loadFromCheckpoint(activeVersion.weightsFilePath)

        // Old-model + new-model pass per held-out pair - matches the *2 this
        // phase was budgeted in totalUnits. Each pass is a full tile-based
        // enhancement (see EnhancementEngine/TileProcessor) that can take
        // several seconds to tens of seconds on a full-resolution image -
        // exactly the stretch that used to report no progress at all.
        val validationTotalPasses = (validationPairs.size * 2).coerceAtLeast(1)
        publishPhase(session, TrainingPhase.VALIDATING, 0, validationTotalPasses, afterCheckpointUnits, totalUnits, finalLoss)
        val validationResult = validator.validate(oldEngine, engine, validationPairs, session.id, control) { passesDone ->
            publishPhase(
                session, TrainingPhase.VALIDATING, passesDone, validationTotalPasses,
                afterCheckpointUnits + passesDone, totalUnits, finalLoss
            )
        }

        if (validationResult.wasInterrupted) {
            // Mirrors the batch loop's own pause/cancel contract: an
            // incomplete comparison can't support a promotion decision
            // either way (see ModelValidator.validate's overallImproved),
            // so the candidate checkpoint is discarded exactly like a
            // rejected one, and nothing lands in validationMetricDao for a
            // comparison that never finished.
            newWeightsFile.delete()
            return finishAs(
                session,
                if (control.command.value == TrainingCommand.CANCEL) TrainingStatus.CANCELLED else TrainingStatus.PAUSED,
                session.plannedEpochs,
                null,
                initialLoss = initialLoss,
                finalLoss = finalLoss
            )
        }

        if (validationResult.metrics.isNotEmpty()) {
            validationMetricDao.insertAll(validationResult.metrics)
        }

        // However many onProgress calls the validator actually made (fewer
        // than budgeted if e.g. there was no old model to compare a
        // first-ever session against), the session's own work is now
        // genuinely done - snap the bar to the full total rather than
        // leaving it just short of 100%, the same class of bug this
        // phase-tracking scheme exists to fix.
        publishPhase(session, TrainingPhase.VALIDATING, validationTotalPasses, validationTotalPasses, totalUnits, totalUnits, finalLoss)

        val completedAt = System.currentTimeMillis()

        return if (validationResult.overallImproved) {
            modelVersionDao.deactivateAllForModel(modelId)
            val versionId = modelVersionDao.insert(
                ModelVersionEntity(
                    modelId = modelId,
                    versionNumber = nextVersionNumber,
                    weightsFilePath = newWeightsFile.path,
                    sizeBytes = newWeightsFile.length(),
                    parameterCount = activeVersion.parameterCount,
                    createdAt = completedAt,
                    trainingSessionId = session.id,
                    validationScore = validationResult.metrics.map { it.scoreAfterTraining }.average().toFloat(),
                    isPromoted = true,
                    isActive = true,
                    notes = "Trained on ${trainPairs.size} pairs"
                )
            )
            modelVersionDao.activate(versionId)

            datasetPairDao.markUsedInSession(trainPairs.map { it.id }, session.id)
            experienceMemory.remember(modelId, trainPairs)

            val improvementDelta = (validationResult.metrics.map { it.delta }.average() * 100).toFloat()
            modelDao.getById(modelId)?.let { model ->
                modelDao.recordTrainingPromotion(
                    modelId = modelId,
                    versionNumber = nextVersionNumber,
                    parameterCount = activeVersion.parameterCount,
                    sizeBytes = newWeightsFile.length(),
                    newImagesLearned = trainPairs.size,
                    trainedAt = completedAt,
                    improvementScore = (model.improvementScore * 0.7f + improvementDelta * 0.3f).coerceIn(0f, 100f)
                )
            }

            finishAs(session, TrainingStatus.COMPLETED, session.plannedEpochs, versionId, initialLoss = initialLoss, finalLoss = finalLoss, promoted = true)
        } else {
            // Reject: discard the new checkpoint, old version stays active.
            newWeightsFile.delete()
            finishAs(
                session, TrainingStatus.COMPLETED, session.plannedEpochs, null,
                initialLoss = initialLoss, finalLoss = finalLoss, promoted = false,
                failureReason = "Validation showed no overall improvement over the current model"
            )
        }
    }

    private suspend fun finishAs(
        session: TrainingSessionEntity,
        status: TrainingStatus,
        epochsCompleted: Int,
        resultVersionId: Long?,
        initialLoss: Float? = null,
        finalLoss: Float? = null,
        promoted: Boolean = false,
        failureReason: String? = null,
        throttled: Boolean = false
    ): TrainingSessionEntity {
        val updated = session.copy(
            status = status,
            epochsCompleted = epochsCompleted,
            completedAt = if (status == TrainingStatus.PAUSED) session.completedAt else System.currentTimeMillis(),
            resultModelVersionId = resultVersionId,
            wasPromoted = promoted,
            initialLoss = initialLoss ?: session.initialLoss,
            finalLoss = finalLoss ?: session.finalLoss,
            wasThrottledByThermal = session.wasThrottledByThermal || throttled,
            failureReason = failureReason
        )
        trainingSessionDao.update(updated)
        progressPublisher.updateStatus(status)
        return updated
    }

    private fun publishProgress(
        session: TrainingSessionEntity,
        epoch: Int,
        plan: AdaptiveTrainingController.TrainingPlan,
        batchIndex: Int,
        batchesInEpoch: Int,
        loss: Float,
        batchesRun: Int,
        totalPlannedBatches: Int,
        totalUnits: Int,
        startMs: Long
    ) {
        val elapsedSec = (System.currentTimeMillis() - startMs) / 1000.0
        val imagesPerSecond = if (elapsedSec > 0) (batchesRun * plan.batchSize) / elapsedSec else 0.0
        // ETA stays scoped to the training phase's own throughput (images/sec)
        // - totalUnits also includes checkpoint-save and validation units,
        // which take far longer per unit than a training batch does, so
        // mixing them into this calculation would badly inflate the ETA.
        val remainingBatches = (totalPlannedBatches - batchesRun).coerceAtLeast(0)
        val etaSeconds = if (imagesPerSecond > 0) (remainingBatches * plan.batchSize / imagesPerSecond).toLong() else -1L
        val ram = deviceCapabilities.snapshot()

        progressPublisher.publish(
            TrainingProgressState(
                sessionId = session.id,
                phase = TrainingPhase.TRAINING,
                epoch = epoch,
                totalEpochs = session.plannedEpochs,
                phaseStepIndex = batchIndex,
                phaseStepTotal = batchesInEpoch,
                unitsCompleted = batchesRun,
                totalUnits = totalUnits,
                latestLoss = loss,
                imagesPerSecond = imagesPerSecond.toFloat(),
                estimatedSecondsRemaining = etaSeconds,
                memoryUsedMb = ram.totalRamMb - ram.availableRamMb,
                status = TrainingStatus.RUNNING
            )
        )
    }

    /**
     * Publishes a progress update for the SAVING_CHECKPOINT/VALIDATING tail
     * that follows the batch loop. Unlike [publishProgress] there's no
     * meaningful images/sec or ETA for these phases (a checkpoint write and
     * a validation pass aren't "batches"), so those are left at their
     * "unknown" values - [com.novaenhance.ai.ui.components.TrainingProgressCard]
     * already falls back to "Calculating…" for a negative ETA. [epoch]/
     * [TrainingProgressState.totalEpochs] and the previous phase's step
     * counts carry over from whatever was last published rather than being
     * reset to 0, purely so the data class doesn't hold misleading zeros -
     * the UI branches on [phase] before reading them.
     */
    private fun publishPhase(
        session: TrainingSessionEntity,
        phase: TrainingPhase,
        phaseStepIndex: Int,
        phaseStepTotal: Int,
        unitsCompleted: Int,
        totalUnits: Int,
        lastKnownLoss: Float?
    ) {
        val ram = deviceCapabilities.snapshot()
        val previous = progressPublisher.progress.value
        progressPublisher.publish(
            TrainingProgressState(
                sessionId = session.id,
                phase = phase,
                epoch = previous?.epoch ?: (session.plannedEpochs - 1).coerceAtLeast(0),
                totalEpochs = session.plannedEpochs,
                phaseStepIndex = phaseStepIndex,
                phaseStepTotal = phaseStepTotal,
                unitsCompleted = unitsCompleted,
                totalUnits = totalUnits,
                latestLoss = lastKnownLoss,
                imagesPerSecond = 0f,
                estimatedSecondsRemaining = -1L,
                memoryUsedMb = ram.totalRamMb - ram.availableRamMb,
                status = TrainingStatus.RUNNING
            )
        )
    }

    /**
     * How many real (non-replay) training pairs land in one batch once
     * replay blending sets aside [replayFraction] of each batch. Shared by
     * [buildBatches] (which uses it to build each epoch's actual chunks) and
     * the batches-per-epoch prediction in [runSession] (for totalPlannedBatches/
     * totalUnits) - the two previously computed this independently and could
     * drift apart whenever replayFraction > 0, since the actual chunk count
     * depends on realPerBatch, not plan.batchSize directly.
     */
    private fun realPairsPerBatch(batchSize: Int, replayFraction: Float): Int {
        val replayPerBatch = (batchSize * replayFraction).toInt().coerceIn(0, batchSize - 1)
        return (batchSize - replayPerBatch).coerceAtLeast(1)
    }

    /** Builds batches mixing real training pairs with a fraction drawn from the anti-forgetting replay buffer. */
    private suspend fun buildBatches(
        trainPairs: List<DatasetPairEntity>,
        batchSize: Int,
        replayFraction: Float,
        modelId: String
    ): List<List<Pair<String, String>>> {
        val realPerBatch = realPairsPerBatch(batchSize, replayFraction)
        val replayPerBatch = batchSize - realPerBatch

        val realChunks = trainPairs.map { it.lowQualityPath to it.highQualityPath }.chunked(realPerBatch)
        return realChunks.map { chunk ->
            val replaySample = if (replayPerBatch > 0) {
                experienceMemory.sample(modelId, replayPerBatch).map { it.lowQualityPath to it.highQualityPath }
            } else {
                emptyList()
            }
            chunk + replaySample
        }
    }

    /**
     * Decodes a pair and extracts one matching random `tileSize x tileSize`
     * patch from each (pixel-aligned). Reads only bounds up front, then
     * decodes just the chosen crop region at full resolution via
     * [decodeBitmapRegion] - this runs once per pair per batch, for every
     * batch of every epoch, so decoding the entire source photo (as this
     * used to) just to keep a tileSize square of it was the single most
     * repeated waste in the whole training loop.
     */
    private fun extractTrainingTile(lowPath: String, highPath: String, tileSize: Int, random: Random): Pair<IntArray, IntArray>? {
        val lowBounds = decodeBitmapBounds(lowPath) ?: return null
        val highBounds = decodeBitmapBounds(highPath) ?: return null

        val w = minOf(lowBounds.width, highBounds.width)
        val h = minOf(lowBounds.height, highBounds.height)
        if (w <= 0 || h <= 0) return null

        val cropW = minOf(tileSize, w)
        val cropH = minOf(tileSize, h)
        val x = if (w > cropW) random.nextInt(w - cropW) else 0
        val y = if (h > cropH) random.nextInt(h - cropH) else 0
        val region = Rect(x, y, x + cropW, y + cropH)

        val lowBitmap = decodeBitmapRegion(lowPath, region) ?: run {
            NovaLog.w(TAG, "Failed to decode training region $lowPath")
            return null
        }
        val highBitmap = decodeBitmapRegion(highPath, region) ?: run {
            NovaLog.w(TAG, "Failed to decode training region $highPath")
            lowBitmap.recycle()
            return null
        }

        try {
            val lowPixels = IntArray(cropW * cropH)
            val highPixels = IntArray(cropW * cropH)
            lowBitmap.getPixels(lowPixels, 0, cropW, 0, 0, cropW, cropH)
            highBitmap.getPixels(highPixels, 0, cropW, 0, 0, cropW, cropH)

            val lowTile = PixelBufferOps.padByReplication(lowPixels, cropW, cropH, tileSize)
            val highTile = PixelBufferOps.padByReplication(highPixels, cropW, cropH, tileSize)
            return lowTile to highTile
        } finally {
            lowBitmap.recycle()
            highBitmap.recycle()
        }
    }
}
