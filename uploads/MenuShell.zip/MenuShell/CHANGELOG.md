# Changelog

## Pass 1 — initial menu shell
- Landscape/reverse-landscape only (`sensorLandscape`), no portrait
- Immersive fullscreen, system bars hidden, cutout excluded from layout
  (`LAYOUT_IN_DISPLAY_CUTOUT_MODE_NEVER`) so nothing sits behind the camera
- Black background throughout, matching the cutout exclusion so the
  excluded area reads as an intentional margin, not a gap
- `ImmersiveActivity` base class holding the window/orientation setup,
  so future screens reuse it instead of duplicating window flags
- Main menu: title + Play/Settings, both currently placeholder actions
