package com.menushell

import android.os.Bundle
import android.widget.Toast
import com.menushell.databinding.ActivityMainBinding

class MainActivity : ImmersiveActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnPlay.setOnClickListener {
            Toast.makeText(this, R.string.toast_play_placeholder, Toast.LENGTH_SHORT).show()
        }
        binding.btnSettings.setOnClickListener {
            Toast.makeText(this, R.string.toast_settings_placeholder, Toast.LENGTH_SHORT).show()
        }
    }
}
