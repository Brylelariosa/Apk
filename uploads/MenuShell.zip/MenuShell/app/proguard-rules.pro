# Add project-specific ProGuard rules here.
# Currently no rules are needed — the app has no reflection-based
# libraries and minifyEnabled is off for the debug builds this
# workflow produces.
