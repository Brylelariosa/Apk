# File Changes — v28

## Modified

### `app/src/main/java/com/zipapkbuilder/MainActivity.kt`
4,735 → 5,218 lines (+688 / −205 across the file). Every behavioral change in
this update lives here. Roughly in the order it was touched:
- Added `ConnectivityManager`/`Network`/`NetworkCapabilities` imports and an
  `activeNetworkCallback` field + `connectivityManager` accessor.
- Added the resumable-download policy constants: `MAX_DOWNLOAD_RETRIES`,
  `INITIAL_RETRY_BACKOFF_MS`, `MAX_RETRY_BACKOFF_MS`, `RETRYABLE_HTTP_CODES`,
  `STALE_PARTIAL_DOWNLOAD_MS`.
- Rewrote `downloadArtifact()` and `downloadLatestRunLogs()` to drive their
  downloads through a new shared `performResumableDownload()` instead of each
  hand-rolling its own single-attempt read loop.
- Added `performResumableDownload()`, `resolveGithubRedirect()`,
  `stableIdFor()`, `offerManualRetry()`, `notifyRetrying()`,
  `isNetworkAvailable()`, `waitForNetwork()` — the resumable-download engine.
- Generalized the pre-existing `sleepCancellable()` to accept which
  cancellation flag to watch (`downloadCancelled` by default, so existing
  call sites are unaffected) instead of adding a duplicate for uploads.
- Added `verifyZipIntegrity()` and `requireZipIntegrity()`; wired into both
  download functions' success paths, right before the file is saved.
- Split `cleanupStaleCacheFiles()`'s single 2-minute sweep into a short-lived
  tier (`apkinfo_*`) and a long-lived tier (`artifact_*`, `logs_tmp_*`, now
  7 days) — see `BUGS_FIXED.md` #1.
- Added `openInputStreamOrThrow()` / `openOutputStreamOrThrow()`; replaced
  all 4 `contentResolver.open*Stream(uri)!!` call sites with them.
- Added `withUploadRetry()` and `retryableHttpCodeIn()`; wired around both
  upload paths (`httpPutWithProgress`, `uploadViaGitDataApi`) in `runFlow()`.
- Extended `UploadDialogHolder` with a `setStatus` callback (reusing the
  existing speed `TextView`, no new view added) so the retry wrapper can show
  pause/retry status the same way the download dialog already does.
- Added shared `logTimestampRegex` / `logAnsiRegex` / `logGroupRegex` fields
  and `cleanLogLine()` / `isLogGroupMarker()` helpers; removed the two
  independent local copies of the same three regexes from `streamBuildLog()`
  and `showLogDialog()`.
- `streamBuildLog()`'s full-log print now joins all cleaned, non-blank,
  non-group-marker lines into one string and appends it once, instead of
  once per line.
- Fixed the "Use Existing keystore" alias-guessing bug (`generateKeystore()`)
  and moved a misplaced doc comment back to the function it describes
  (`saveZipToDownloadsInternal()`) — see `BUGS_FIXED.md` #4–5.

### `app/src/main/AndroidManifest.xml`
Added the `ACCESS_NETWORK_STATE` permission (with an explanatory comment) —
required to detect connectivity loss/return for automatic download
pause/resume. No other changes; the UI is unaffected by a manifest permission.

### `app/build.gradle`
- `versionCode 27` / `versionName "27"` → `28` / `"28"`.
- `minifyEnabled false` → `true`, plus new `shrinkResources true` and a
  `proguardFiles` line referencing the new `proguard-rules.pro` (below).
  Judged safe because this app has no reflection-based (de)serialization and
  no WebView JS interface — see `PERFORMANCE_REPORT.md` for the full
  reasoning and `KNOWN_LIMITATIONS.md` for what to watch for if that ever
  changes.

### `app/proguard-rules.pro` (new file)
Minimal keep-rule set for the release build: keeps source file name + line
numbers (for readable release stack traces) and documents *why* nothing else
needs an explicit keep rule, so a future contributor doesn't wonder whether
it was simply forgotten.

## Added
- `app/proguard-rules.pro`
- `REVIEW_REPORT.md`
- `KNOWN_LIMITATIONS.md`
- `V28_RELEASE_NOTES.md`

## Deleted
None.

## Confirmed Unchanged
Every file under `app/src/main/res/` (all layouts, drawables, values, etc.)
is byte-for-byte identical to v27 — verified by diffing the complete resource
tree, not spot-checked. The UI is visually and structurally unchanged; every
new v28 surface (retry buttons, status text, "remaining size") reuses
existing dialog views rather than adding new ones. Also unchanged:
`settings.gradle`, `gradle.properties`, root `build.gradle`, `gradlew`,
`gradle-wrapper.properties`, and the embedded `WORKFLOW_YAML` /
`KEYSTORE_WORKFLOW_YAML` strings.

---

# File Changes — v27

## Modified

### `app/src/main/java/com/zipapkbuilder/MainActivity.kt`
4,492 → 4,739 lines (+461 / −214 across the file). Every behavioral change in
this update lives here. In one file, roughly in the order it was touched:
- Swapped the unused `kotlin.concurrent.thread` import for
  `java.util.concurrent.{Executors, ExecutorService}`.
- Added a shared `bgExecutor` (bounded 4-thread pool) field and an
  `onDestroy()` override that shuts it down and stops the status-dot
  animations.
- Replaced all 25 `thread { ... }` call sites with `bgExecutor.execute { ... }`
  (mechanical, verified no call site relied on the `Thread` return value or
  `.join()`). As part of this, all 9 `return@thread` labels were updated to
  `return@execute` — the implicit label always matches the enclosing
  function's name, so this follows directly from the rename.
- Fixed the `restoreSavedBuildState()` brace bug, the `promptCreateRepo()`
  `repeat`/`return@repeat` bug, the file editor's per-keystroke gutter
  rebuild, `deleteItemsRecursive()`'s abort-on-first-failure behavior, and the
  MediaStore path-reporting inaccuracy in `saveZipToDownloadsInternal()`.
- Removed the three duplicate local `fmtBytes()` definitions.
- Refactored `downloadArtifact()` to call `buildDownloadProgressDialog()`
  instead of hand-building its own copy of the dialog; renamed its local view
  references (`progressDialog` → `dlUi.dialog`, `progressBarDl` →
  `dlUi.progressBar`, etc.) to match the shared `DownloadDialogHolder`.
- Added `logApkInfoFromZip()`, `cleanupStaleCacheFiles()`,
  `hasEnoughStorage()`, `validateProjectZip()`, `friendlyError()`, and
  `fmtDuration()` as new helper functions.
- Added the Build History feature: `addBuildToHistory()` /
  `loadBuildHistory()` (mirroring the existing Download History pair), wired
  into `runFlow()`'s success and failure paths, plus the
  `refreshBuildHistory()` UI population function inside `showSettingsDialog()`.
- Wired `validateProjectZip()` and a large-ZIP memory warning into `runFlow()`
  right after the ZIP is read into memory.
- Wired `hasEnoughStorage()` into both `downloadArtifact()` and
  `downloadLatestRunLogs()` before their download loops start.
- Wired `logApkInfoFromZip()` + cache cleanup into `downloadArtifact()`'s
  success path.
- Added the `scrollPending` flag and `LOG_CHAR_CAP` constant, and rewrote
  `appendLog()` to use both.
- Removed two fully dead fields, `btnDownloadLogs` and `btnSavedRepos` (and
  their now-orphaned explanatory comments).

### `app/src/main/AndroidManifest.xml`
Added `android:largeHeap="true"` to the `<application>` tag. See
`PERFORMANCE_REPORT.md` #5 for why.

### `app/build.gradle`
`versionCode 1` → `27`, `versionName "1.0"` → `"27"`. This had never been
bumped since the first release; it now actually reflects the app's real
version history going forward.

### `app/src/main/res/layout/dialog_settings.xml`
422 → 487 lines. Added the **Build History** section (header row with a Clear
button, a stats summary `TextView`, and an entries container) directly below
the existing Download History section, following its exact structural
pattern. New IDs: `sBtnClearBuildHistory`, `tvBuildStats`,
`layoutBuildHistory`.

## Added
- `CHANGELOG.md`
- `FEATURES_ADDED.md`
- `PERFORMANCE_REPORT.md`
- `BUGS_FIXED.md`
- `FILE_CHANGES.md` (this file)

## Deleted
None.

## Reviewed, Not Changed
- The embedded `WORKFLOW_YAML` and `KEYSTORE_WORKFLOW_YAML` strings (the
  GitHub Actions workflows this app generates and pushes) — already
  well-optimized; see `PERFORMANCE_REPORT.md`.
- `settings.gradle`, `gradle.properties`, `gradle-wrapper.properties` — no
  issues found.
