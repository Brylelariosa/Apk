package com.hzcm.duelforge.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.hzcm.duelforge.data.EffectRegistry
import com.hzcm.duelforge.engine.*
import com.hzcm.duelforge.model.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val BgColor    = Color(0xFF0A1424)
private val MatColor   = Color(0xFF112338)
private val PanelColor = Color(0xFF152C46)
private val AccentGold = Color(0xFFE8B339)
private val DimText    = Color(0xFF7E96B5)
private val AttackRed  = Color(0xFFFF5533)

@Composable
fun GameScreen(
    viewModel: GameViewModel = viewModel(),
    onOpenDebug: () -> Unit = {}
) {
    val engine = viewModel.engine
    @Suppress("UNUSED_EXPRESSION")
    viewModel.refresh
    val state  = engine.state
    val scope  = rememberCoroutineScope()

    var showLog by remember { mutableStateOf(false) }

    val hasSelection = viewModel.selectedCard != null ||
        viewModel.tributeSelection != null ||
        viewModel.attackerSelection != null

    Box(modifier = Modifier.fillMaxSize().background(BgColor)) {

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 4.dp, vertical = 2.dp)
        ) {
            // ── Opponent HUD ──────────────────────────────────────────
            OpponentHud(engine, viewModel,
                onLogClick = { showLog = true },
                onOpenDebug = onOpenDebug)
            Spacer(Modifier.height(2.dp))

            // ── Field area (expands to fill remaining space) ──────────
            Box(modifier = Modifier.weight(1f)) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.SpaceEvenly
                ) {
                    // Opponent zones (spell/trap on top, monsters below)
                    FieldZoneRow(
                        cards = (0..4).map { state.field(PlayerId.AI).spellTrapZones[it] },
                        highlightAll = false
                    )
                    Spacer(Modifier.height(3.dp))
                    FieldZoneRow(
                        cards = (0..4).map { state.field(PlayerId.AI).monsterZones[it] },
                        highlightAll = viewModel.attackerSelection != null,
                        onTap = { c -> if (c != null) viewModel.onOpponentMonsterTapped(c) },
                        isSelected = { c -> false },
                        attackBadge = { false }
                    )

                    // Divider
                    Spacer(Modifier.height(2.dp))
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(Color(0xFF1C3550))
                    )
                    Spacer(Modifier.height(2.dp))

                    // Player zones (monsters on top, spell/trap below)
                    FieldZoneRow(
                        cards = (0..4).map { state.field(PlayerId.PLAYER).monsterZones[it] },
                        revealFaceDown = true,
                        highlightAll = false,
                        onTap = { c -> if (c != null) viewModel.onOwnMonsterTapped(c) },
                        isSelected = { c -> isSelected(c, viewModel) },
                        attackBadge = { c ->
                            c != null &&
                            state.phase == Phase.BATTLE &&
                            state.turnPlayer == PlayerId.PLAYER &&
                            c.faceUp &&
                            c.battlePosition == BattlePosition.ATTACK &&
                            !c.hasAttackedThisTurn
                        }
                    )
                    Spacer(Modifier.height(3.dp))
                    FieldZoneRow(
                        cards = (0..4).map { state.field(PlayerId.PLAYER).spellTrapZones[it] },
                        revealFaceDown = true,
                        highlightAll = false,
                        onTap = { c -> if (c != null) viewModel.onOwnSpellTrapTapped(c) },
                        isSelected = { c -> isSelected(c, viewModel) },
                        attackBadge = { false }
                    )
                }
            }

            Spacer(Modifier.height(2.dp))

            // ── Player HUD + turn controls (no middle phase bar) ──────
            PlayerHudRow(
                engine = engine,
                vm = viewModel,
                onDraw = {
                    viewModel.drawCard()
                    scope.launch { delay(600); viewModel.advancePhase() }
                },
                onBattle = { viewModel.goToBattlePhase() },
                onMain2  = { viewModel.skipToMainPhase2() },
                onEnd    = { viewModel.endTurnNow() },
                onAdvance = { viewModel.advancePhase() }
            )

            Spacer(Modifier.height(3.dp))

            // ── Hand ──────────────────────────────────────────────────
            PlayerHandRow(engine, viewModel)
        }

        // ── Action sheet at bottom ────────────────────────────────────
        AnimatedVisibility(
            visible = hasSelection,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = expandVertically(tween(180)) + fadeIn(tween(180)),
            exit  = shrinkVertically(tween(140)) + fadeOut(tween(120))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(BgColor.copy(alpha = 0.97f))
                    .padding(4.dp)
            ) {
                ActionSheet(viewModel, engine)
            }
        }

        // ── Overlays ──────────────────────────────────────────────────
        if (showLog) LogDialog(state) { showLog = false }
        state.pendingHumanPriority?.let { PriorityDialog(it, viewModel) }
        state.pendingDiscard?.let      { DiscardDialog(it, viewModel) }
        state.pendingCoinCall?.let     { CoinCallDialog(it, viewModel) }
        if (state.gameOver) GameOverOverlay(state, viewModel)

        viewModel.phasePopupText?.let    { PhasePopupOverlay(it) }
        viewModel.attackIndicator?.let   { AttackIndicatorOverlay(it) }
        viewModel.destroyAnimCard?.let   { CardBreakOverlay(it) }
        viewModel.coinFlipReveal?.let    { CoinFlipOverlay(it) { viewModel.dismissCoinFlipReveal() } }

        val previewCard = viewModel.previewCard
        var cachedPreview by remember { mutableStateOf(previewCard) }
        if (previewCard != null) cachedPreview = previewCard
        AnimatedVisibility(
            visible = previewCard != null,
            enter = fadeIn(tween(180)) + scaleIn(initialScale = 0.85f, animationSpec = tween(180)),
            exit  = fadeOut(tween(150)) + scaleOut(targetScale = 0.9f, animationSpec = tween(150))
        ) {
            cachedPreview?.let { card ->
                CardPreviewOverlay(
                    card = card,
                    autoDismiss = viewModel.previewAutoShow,
                    onDismiss = { viewModel.dismissPreview() }
                )
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Field zone row — 5 slots, fills screen width, optional attack badge overlay
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun FieldZoneRow(
    cards: List<CardInstance?>,
    revealFaceDown: Boolean = false,
    highlightAll: Boolean = false,
    onTap: (CardInstance?) -> Unit = {},
    isSelected: (CardInstance?) -> Boolean = { false },
    attackBadge: (CardInstance?) -> Boolean = { false }
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        cards.forEach { card ->
            Box(
                modifier = Modifier.weight(1f),
                contentAlignment = Alignment.Center
            ) {
                AnimatedCardSlot(
                    instance = card,
                    revealFaceDown = revealFaceDown,
                    selected = isSelected(card) || (highlightAll && card != null),
                    onClick = if (card != null || highlightAll) ({ onTap(card) }) else null
                )
                // ⚔ badge on monsters eligible to attack
                if (attackBadge(card)) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(top = 2.dp, end = 2.dp)
                            .size(15.dp)
                            .background(AttackRed, CircleShape)
                            .border(1.dp, Color.White, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("⚔", fontSize = 7.sp)
                    }
                }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Opponent HUD
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun OpponentHud(
    engine: GameEngine,
    vm: GameViewModel,
    onLogClick: () -> Unit,
    onOpenDebug: () -> Unit
) {
    val field = engine.state.field(PlayerId.AI)
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            // Opponent deck (not tappable)
            SmallDeckPile(field.deck.size)
            Column {
                Text("OPPONENT", color = DimText, fontSize = 7.sp, fontWeight = FontWeight.Bold)
                Text("LP ${field.lifePoints}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
            FieldSpellBadge(field.fieldZone, vm)
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("GY:${field.graveyard.size} ✦${field.banished.size}", color = DimText, fontSize = 7.sp)
            HudIconButton("📜", onLogClick)
            HudIconButton("⚙", onOpenDebug)
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Player HUD row — LP + deck (tappable for draw) + phase badge + turn buttons
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun PlayerHudRow(
    engine: GameEngine,
    vm: GameViewModel,
    onDraw: () -> Unit,
    onBattle: () -> Unit,
    onMain2: () -> Unit,
    onEnd: () -> Unit,
    onAdvance: () -> Unit
) {
    val state = engine.state
    val field = state.field(PlayerId.PLAYER)
    val isPlayerTurn = state.turnPlayer == PlayerId.PLAYER
    val canAct = isPlayerTurn && !state.gameOver &&
        state.chain.isEmpty() && state.pendingHumanPriority == null

    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        // Tappable deck in Draw phase
        val canDraw = canAct && state.phase == Phase.DRAW && !vm.playerHasDrawnThisTurn
        PlayerDeckPile(deckSize = field.deck.size, canDraw = canDraw, onDraw = onDraw)

        // LP + label
        Column(modifier = Modifier.weight(1f)) {
            Text("YOU", color = DimText, fontSize = 7.sp, fontWeight = FontWeight.Bold)
            Text("LP ${field.lifePoints}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            FieldSpellBadge(field.fieldZone, vm)
        }

        // GY count
        Text("GY:${field.graveyard.size}", color = DimText, fontSize = 7.sp)

        // Phase badge
        PhaseBadge(state)

        // Turn control buttons (only on player's turn)
        if (canAct) {
            TurnControlButtons(
                state = state,
                onDraw    = onDraw,
                onBattle  = onBattle,
                onMain2   = onMain2,
                onEnd     = onEnd,
                onAdvance = onAdvance,
                hasDrawn  = vm.playerHasDrawnThisTurn
            )
        } else if (!isPlayerTurn) {
            Text("…", color = DimText, fontSize = 11.sp)
        }
    }
}

@Composable
private fun PhaseBadge(state: GameState) {
    val label = when (state.phase) {
        Phase.DRAW         -> "DRAW"
        Phase.STANDBY      -> "STANDBY"
        Phase.MAIN1        -> "MAIN 1"
        Phase.BATTLE,
        Phase.BATTLE_START -> "BATTLE"
        Phase.MAIN2        -> "MAIN 2"
        Phase.END          -> "END"
    }
    val isPlayer = state.turnPlayer == PlayerId.PLAYER
    Box(
        modifier = Modifier
            .background(
                if (isPlayer) AccentGold.copy(alpha = 0.2f) else Color(0xFF3A1010),
                RoundedCornerShape(4.dp)
            )
            .border(1.dp, if (isPlayer) AccentGold else Color(0xFF883333), RoundedCornerShape(4.dp))
            .padding(horizontal = 6.dp, vertical = 3.dp)
    ) {
        Text(
            label,
            color = if (isPlayer) AccentGold else Color(0xFFCC6666),
            fontSize = 8.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun TurnControlButtons(
    state: GameState,
    hasDrawn: Boolean,
    onDraw: () -> Unit,
    onBattle: () -> Unit,
    onMain2: () -> Unit,
    onEnd: () -> Unit,
    onAdvance: () -> Unit
) {
    Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
        when (state.phase) {
            Phase.DRAW -> {
                // Auto-advances after draw; only show button if not yet drawn
                if (!hasDrawn) {
                    TurnBtn(if (state.turnCount == 1) "No Draw" else "Draw", AccentGold) { onDraw() }
                }
                // If drawn, waiting for auto-advance — show nothing extra
            }
            Phase.STANDBY -> TurnBtn("▶", AccentGold) { onAdvance() }
            Phase.MAIN1 -> {
                TurnBtn("⚔", AttackRed)  { onBattle() }
                TurnBtn("M2", DimText)   { onMain2() }
                TurnBtn("End", DimText)  { onEnd() }
            }
            Phase.BATTLE, Phase.BATTLE_START -> TurnBtn("M2 ▶", AccentGold) { onAdvance() }
            Phase.MAIN2 -> TurnBtn("End Turn", AccentGold) { onEnd() }
            Phase.END   -> TurnBtn("End Turn", AccentGold) { onAdvance() }
        }
    }
}

@Composable
private fun TurnBtn(label: String, tint: Color = AccentGold, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .height(28.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(tint.copy(alpha = 0.18f))
            .border(1.dp, tint.copy(alpha = 0.7f), RoundedCornerShape(6.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = tint, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun PlayerDeckPile(deckSize: Int, canDraw: Boolean, onDraw: () -> Unit) {
    Box(
        modifier = Modifier
            .size(CardWidth, CardHeight)
            .then(if (canDraw) Modifier.clickable(onClick = onDraw) else Modifier)
            .border(
                width = if (canDraw) 2.dp else 1.dp,
                color = if (canDraw) AccentGold else Color(0xFF2A3A50),
                shape = RoundedCornerShape(6.dp)
            ),
        contentAlignment = Alignment.Center
    ) {
        if (deckSize > 0) {
            CardBack(modifier = Modifier.fillMaxSize())
        } else {
            Box(Modifier.fillMaxSize().background(Color(0xFF111111), RoundedCornerShape(6.dp)))
        }
        // Count badge
        if (deckSize > 0) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(2.dp)
                    .size(16.dp)
                    .background(Color(0xDD000000), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(deckSize.toString(), color = Color.White, fontSize = 7.sp, fontWeight = FontWeight.Bold)
            }
        }
        // "TAP" draw prompt
        if (canDraw) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .offset(y = 3.dp)
                    .background(AccentGold, RoundedCornerShape(3.dp))
                    .padding(horizontal = 4.dp, vertical = 1.dp)
            ) {
                Text("DRAW", fontSize = 6.sp, color = Color(0xFF1A1300), fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun SmallDeckPile(deckSize: Int) {
    Box(
        modifier = Modifier.size(26.dp, 36.dp),
        contentAlignment = Alignment.BottomEnd
    ) {
        if (deckSize > 0) CardBack(modifier = Modifier.fillMaxSize())
        else Box(Modifier.fillMaxSize().background(Color(0xFF111111), RoundedCornerShape(4.dp)))
        if (deckSize > 0) {
            Box(
                modifier = Modifier
                    .size(14.dp)
                    .background(Color(0xCC000000), RoundedCornerShape(3.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(deckSize.toString(), color = Color.White, fontSize = 6.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun HudIconButton(icon: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(26.dp)
            .background(PanelColor, RoundedCornerShape(6.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(icon, fontSize = 12.sp)
    }
}

@Composable
private fun FieldSpellBadge(fieldZone: CardInstance?, vm: GameViewModel) {
    if (fieldZone == null) return
    Box(
        modifier = Modifier
            .background(Color(0xFF2E6B3E), RoundedCornerShape(5.dp))
            .clickable { if (fieldZone.faceUp) vm.showFieldPreview(fieldZone) }
            .padding(horizontal = 5.dp, vertical = 2.dp)
    ) {
        Text(
            "🌍 ${fieldZone.card.name}",
            color = Color.White, fontSize = 7.sp, fontWeight = FontWeight.Bold,
            maxLines = 1, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.widthIn(max = 90.dp)
        )
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Hand row
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun PlayerHandRow(engine: GameEngine, vm: GameViewModel) {
    val hand = engine.state.field(PlayerId.PLAYER).hand
    if (hand.isEmpty()) return
    LazyRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        items(hand) { cardInst ->
            CardView(
                instance = cardInst,
                revealFaceDown = true,
                selected = isSelected(cardInst, vm),
                onClick = { vm.onHandCardTapped(cardInst) }
            )
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Action sheet
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun ActionSheet(vm: GameViewModel, engine: GameEngine) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(PanelColor, RoundedCornerShape(topStart = 10.dp, topEnd = 10.dp))
            .border(1.dp, AccentGold.copy(alpha = 0.3f), RoundedCornerShape(topStart = 10.dp, topEnd = 10.dp))
            .padding(10.dp)
    ) {
        val tribute  = vm.tributeSelection
        val attacker = vm.attackerSelection
        val card     = vm.selectedCard

        when {
            tribute  != null -> TributePanel(vm, tribute)
            attacker != null -> AttackerPanel(vm, engine, attacker)
            card     != null -> CardActionPanel(vm, engine, card)
        }
    }
}

@Composable
private fun TributePanel(vm: GameViewModel, tribute: TributeSelection) {
    val action = if (tribute.asSet) "Set" else "Summon"
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                "$action: ${tribute.card.card.name}",
                color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold
            )
            Text(
                "Tap your monsters to tribute (${tribute.chosen.size}/${tribute.required})",
                color = DimText, fontSize = 10.sp
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            TurnBtn(
                label = "✓ Confirm",
                tint  = if (tribute.chosen.size == tribute.required) Color(0xFF44CC77) else DimText
            ) { if (tribute.chosen.size == tribute.required) vm.confirmTributeSummon() }
            TurnBtn("✕ Cancel", AttackRed) { vm.cancelTributeSummon() }
        }
    }
}

@Composable
private fun AttackerPanel(vm: GameViewModel, engine: GameEngine, attacker: CardInstance) {
    val computedAtk = engine.computeAtk(attacker)
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text("⚔ ${attacker.card.name}", color = AttackRed, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text("ATK $computedAtk", color = AccentGold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            val opMonsters = engine.state.field(PlayerId.AI).monsters()
            if (opMonsters.isEmpty()) {
                Text("No opponent monsters — tap below or attack directly", color = DimText, fontSize = 10.sp)
            } else {
                Text("Tap an opponent monster to attack it", color = DimText, fontSize = 10.sp)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            if (engine.canDeclareAttack(attacker, null)) {
                TurnBtn("⚔ Direct", AttackRed) { vm.declareDirectAttack() }
            }
            TurnBtn("✕ Cancel", DimText) { vm.clearSelection() }
        }
    }
}

@Composable
private fun CardActionPanel(vm: GameViewModel, engine: GameEngine, card: CardInstance) {
    val state    = engine.state
    val baseAtk  = card.card.atk ?: 0
    val compAtk  = if (card.card.isMonster && card.location == Location.MONSTER_ZONE)
        engine.computeAtk(card) else baseAtk
    val compDef  = if (card.card.isMonster && card.location == Location.MONSTER_ZONE)
        engine.computeDef(card) else (card.card.def ?: 0)
    val atkBoosted = compAtk != baseAtk

    Row(verticalAlignment = Alignment.Top) {
        Column(modifier = Modifier.weight(1f)) {
            Text(card.card.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            if (card.card.isMonster) {
                val atkStr = if (atkBoosted) "ATK $compAtk (+${compAtk - baseAtk})" else "ATK $compAtk"
                Text(
                    "Lv${card.card.level ?: 0}  ${card.card.attribute?.name ?: ""} " +
                    "${card.card.race?.name?.replace('_', ' ') ?: ""}  " +
                    "$atkStr / DEF $compDef",
                    color = if (atkBoosted) Color(0xFF88FF99) else AccentGold,
                    fontSize = 10.sp, fontWeight = FontWeight.Bold
                )
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            if (card.faceUp) {
                TurnBtn("🔍") { vm.showFieldPreview(card) }
            }
            TurnBtn("✕") { vm.clearSelection() }
        }
    }

    Spacer(Modifier.height(4.dp))
    Text(
        card.card.description,
        color = Color(0xFFCBD5E1), fontSize = 11.sp, lineHeight = 14.sp,
        maxLines = 3, overflow = TextOverflow.Ellipsis
    )
    Spacer(Modifier.height(8.dp))

    when (card.location) {
        Location.HAND            -> HandCardActions(vm, engine, card)
        Location.MONSTER_ZONE    -> FieldMonsterActions(vm, engine, card)
        Location.SPELL_TRAP_ZONE -> SpellTrapZoneActions(vm, engine, card)
        else -> {}
    }
}

@Composable
private fun HandCardActions(vm: GameViewModel, engine: GameEngine, card: CardInstance) {
    val state         = engine.state
    val playerMonsters = state.field(PlayerId.PLAYER).monsters()
    val tribReq       = card.card.tributesRequired
    val canSummon     = engine.canNormalSummon(card)
    val hasEnoughTrib = playerMonsters.size >= tribReq

    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        if (card.card.isMonster) {
            if (canSummon) {
                if (hasEnoughTrib) {
                    val tribNote = if (tribReq > 0) " ($tribReq tribute${if (tribReq > 1) "s" else ""})" else ""
                    ActionButton("Normal Summon$tribNote") { vm.beginSummon(false) }
                    if (engine.canSetMonster(card)) {
                        ActionButton("Set face-down$tribNote") { vm.beginSummon(true) }
                    }
                } else if (tribReq > 0) {
                    // Not enough tributes — show disabled hint
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF1C2A3A), RoundedCornerShape(6.dp))
                            .border(1.dp, Color(0xFF2A3A4A), RoundedCornerShape(6.dp))
                            .padding(horizontal = 10.dp, vertical = 8.dp)
                    ) {
                        Text(
                            "Need $tribReq monster${if (tribReq > 1) "s" else ""} to tribute (have ${playerMonsters.size})",
                            color = DimText, fontSize = 11.sp
                        )
                    }
                }
            }
        }
        if ((card.card.isSpell || card.card.isTrap) && engine.canSetSpellOrTrap(card)) {
            ActionButton("Set face-down") { vm.setTrap() }
        }
        for (effect in EffectRegistry.effectsFor(card.card.id)) {
            if (engine.canActivateEffect(card, effect)) {
                ActionButton("Activate: ${effect.description}") { vm.activateEffect(effect) }
            }
        }
    }
}

@Composable
private fun FieldMonsterActions(vm: GameViewModel, engine: GameEngine, card: CardInstance) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        if (engine.canFlipSummon(card)) {
            ActionButton("Flip Summon") { vm.flipSummon() }
        }
        val opposite = if (card.battlePosition == BattlePosition.ATTACK)
            BattlePosition.DEFENSE else BattlePosition.ATTACK
        if (engine.canChangeBattlePosition(card, opposite)) {
            ActionButton(if (opposite == BattlePosition.ATTACK) "→ Attack Pos" else "→ Defense Pos") {
                vm.changeBattlePosition(opposite)
            }
        }
        // Battle phase — offer attack shortcut
        if (engine.state.phase == Phase.BATTLE &&
            engine.state.turnPlayer == PlayerId.PLAYER &&
            card.battlePosition == BattlePosition.ATTACK &&
            card.faceUp && !card.hasAttackedThisTurn) {
            ActionButton("⚔ Declare Attack") { vm.onOwnMonsterTapped(card) }
        }
        for (effect in EffectRegistry.effectsFor(card.card.id)) {
            if (engine.canActivateEffect(card, effect)) {
                ActionButton("Activate: ${effect.description}") { vm.activateEffect(effect) }
            }
        }
    }
}

@Composable
private fun SpellTrapZoneActions(vm: GameViewModel, engine: GameEngine, card: CardInstance) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        for (effect in EffectRegistry.effectsFor(card.card.id)) {
            if (engine.canActivateEffect(card, effect)) {
                ActionButton("Activate: ${effect.description}") { vm.activateEffect(effect) }
            }
        }
        if (!card.faceUp) {
            val hint = when {
                card.card.isTrap  -> "Set Trap — activates during opponent's turn."
                card.card.isSpell -> "Set Spell — tap Activate on your turn."
                else -> ""
            }
            if (hint.isNotEmpty()) Text(hint, color = DimText, fontSize = 10.sp)
        }
    }
}

@Composable
private fun ActionButton(label: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp)
    ) {
        Text(label, fontSize = 11.sp)
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Helper
// ─────────────────────────────────────────────────────────────────────────────

private fun isSelected(card: CardInstance?, vm: GameViewModel): Boolean {
    if (card == null) return false
    return vm.selectedCard === card ||
        vm.attackerSelection === card ||
        vm.tributeSelection?.chosen?.contains(card) == true ||
        vm.discardChosen.contains(card)
}

// ─────────────────────────────────────────────────────────────────────────────
// Log dialog
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun LogDialog(state: GameState, onDismiss: () -> Unit) {
    val listState = rememberLazyListState()
    LaunchedEffect(Unit) { if (state.log.isNotEmpty()) listState.scrollToItem(state.log.size - 1) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Duel Log") },
        text = {
            LazyColumn(state = listState, modifier = Modifier.heightIn(max = 420.dp)) {
                items(state.log) { line ->
                    Text(line, color = Color(0xFFCCCCCC), fontSize = 11.sp, lineHeight = 14.sp)
                }
            }
        },
        confirmButton = { Button(onClick = onDismiss) { Text("Close") } }
    )
}

// ─────────────────────────────────────────────────────────────────────────────
// Dialogs
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun PriorityDialog(prompt: PriorityPrompt, vm: GameViewModel) {
    AlertDialog(
        onDismissRequest = {},
        title = { Text("Respond?") },
        text = {
            Column {
                Text(prompt.reason, fontSize = 11.sp)
                Spacer(Modifier.height(8.dp))
                prompt.optionLabels.forEachIndexed { index, label ->
                    Button(
                        onClick = { vm.submitPriorityChoice(index) },
                        modifier = Modifier.padding(vertical = 2.dp).fillMaxWidth()
                    ) { Text(label, fontSize = 10.sp) }
                }
            }
        },
        confirmButton = { Button(onClick = { vm.submitPriorityChoice(null) }) { Text("Pass") } }
    )
}

@Composable
private fun DiscardDialog(req: DiscardRequest, vm: GameViewModel) {
    val hand = vm.engine.state.field(req.player).hand
    AlertDialog(
        onDismissRequest = {},
        title = { Text("Discard ${req.count} card${if (req.count > 1) "s" else ""}") },
        text = {
            Column {
                Text(req.reason, fontSize = 10.sp, color = Color.LightGray)
                Spacer(Modifier.height(8.dp))
                Text("Tap to select (${vm.discardChosen.size}/${req.count}):", fontSize = 9.sp, color = Color.Gray)
                Spacer(Modifier.height(4.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    items(hand) { card ->
                        CardView(
                            instance = card,
                            revealFaceDown = true,
                            selected = vm.discardChosen.contains(card),
                            onClick = { vm.onDiscardCardToggled(card) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { vm.confirmDiscard() },
                enabled = vm.discardChosen.size == req.count
            ) { Text("Discard") }
        }
    )
}

@Composable
private fun CoinCallDialog(req: CoinCallRequest, vm: GameViewModel) {
    AlertDialog(
        onDismissRequest = {},
        title = { Text("Call it!") },
        text = {
            Column {
                Text(req.reason, fontSize = 11.sp, color = Color.LightGray)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { vm.callCoinToss(CoinSide.HEADS) }, modifier = Modifier.weight(1f)) { Text("Heads") }
                    Button(onClick = { vm.callCoinToss(CoinSide.TAILS) }, modifier = Modifier.weight(1f)) { Text("Tails") }
                }
            }
        },
        confirmButton = {}
    )
}

// ─────────────────────────────────────────────────────────────────────────────
// Coin flip overlay
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun CoinFlipOverlay(reveal: CoinFlipReveal, onDone: () -> Unit) {
    var displayedSide by remember(reveal) { mutableStateOf(reveal.called) }
    var settled by remember(reveal) { mutableStateOf(false) }
    val coinScale by animateFloatAsState(if (settled) 1.18f else 1f, tween(220), label = "coin")

    LaunchedEffect(reveal) {
        repeat(12) {
            displayedSide = if (displayedSide == CoinSide.HEADS) CoinSide.TAILS else CoinSide.HEADS
            delay(70L)
        }
        displayedSide = reveal.landed; settled = true; delay(1500L); onDone()
    }

    Box(Modifier.fillMaxSize().background(Color(0xCC000000)), Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier
                    .size(100.dp).scale(coinScale)
                    .background(Brush.radialGradient(listOf(Color(0xFFFFE9A8), Color(0xFFC9971F))), CircleShape)
                    .border(4.dp, Color(0xFF8A6418), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(if (displayedSide == CoinSide.HEADS) "H" else "T", fontSize = 40.sp, fontWeight = FontWeight.Black, color = Color(0xFF4A3300))
            }
            Spacer(Modifier.height(14.dp))
            Text(if (!settled) "Flipping…" else "${reveal.landed.displayName}!", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
            if (settled) {
                Spacer(Modifier.height(4.dp))
                Text(
                    "Called ${reveal.called.displayName} — " + if (reveal.won) "right!" else "wrong!",
                    color = if (reveal.won) Color(0xFF66E28A) else Color(0xFFFF6B6B),
                    fontWeight = FontWeight.Bold, fontSize = 14.sp
                )
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Phase popup / attack indicator / card break
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun PhasePopupOverlay(text: String) {
    val isEnemy = text.startsWith("ENEMY")
    Box(Modifier.fillMaxSize(), Alignment.Center) {
        Box(
            modifier = Modifier
                .background(if (isEnemy) Color(0xCC4A0A0A) else Color(0xCC0A2A4A), RoundedCornerShape(12.dp))
                .border(2.dp, if (isEnemy) Color(0xFFAA3333) else AccentGold, RoundedCornerShape(12.dp))
                .padding(horizontal = 28.dp, vertical = 14.dp)
        ) {
            Text(text, color = if (isEnemy) Color(0xFFFF8888) else AccentGold, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
    }
}

@Composable
private fun AttackIndicatorOverlay(text: String) {
    Box(Modifier.fillMaxSize(), Alignment.Center) {
        Box(
            modifier = Modifier
                .background(Color(0xCC000000), RoundedCornerShape(8.dp))
                .border(1.dp, Color(0xFF884422), RoundedCornerShape(8.dp))
                .padding(horizontal = 18.dp, vertical = 10.dp)
        ) {
            Text("⚔  $text", color = Color(0xFFFFAA44), fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
    }
}

@Composable
private fun CardBreakOverlay(card: CardInstance) {
    val scale    = remember { Animatable(1f) }
    val alpha    = remember { Animatable(1f) }
    val rotation = remember { Animatable(0f) }
    LaunchedEffect(card) {
        launch { scale.animateTo(1.15f, tween(150)) }
        delay(150L)
        launch { rotation.animateTo(15f, tween(300)) }
        launch { scale.animateTo(0f, tween(500)) }
        launch { alpha.animateTo(0f, tween(600)) }
    }
    Box(Modifier.fillMaxSize(), Alignment.Center) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.graphicsLayer { scaleX = scale.value; scaleY = scale.value; this.alpha = alpha.value; rotationZ = rotation.value }
        ) {
            Box(
                modifier = Modifier.size(CardWidth * 1.6f, CardHeight * 1.6f)
                    .background(Color(0xFFCC2222), RoundedCornerShape(8.dp))
                    .border(3.dp, Color(0xFFFF4444), RoundedCornerShape(8.dp))
                    .padding(4.dp),
                contentAlignment = Alignment.Center
            ) { Text("💥", fontSize = 28.sp) }
            Spacer(Modifier.height(4.dp))
            Text(card.card.name, color = Color(0xFFFF6666), fontWeight = FontWeight.Bold, fontSize = 11.sp)
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Card preview overlay
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun CardPreviewOverlay(card: CardInstance, autoDismiss: Boolean, onDismiss: () -> Unit) {
    if (autoDismiss) LaunchedEffect(card) { delay(2200L); onDismiss() }
    Box(
        modifier = Modifier.fillMaxSize().background(Color(0xCC000000)).clickable { onDismiss() },
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(modifier = Modifier.size(190.dp, 270.dp)) {
                val context = LocalContext.current
                val bitmap  = remember(card.card.imageId) { ImageLoader.loadCardImage(context, card.card.imageId) }
                if (bitmap != null) {
                    Image(bitmap.asImageBitmap(), card.card.name, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                } else {
                    Box(Modifier.fillMaxSize().background(cardTypeColor(card.card), RoundedCornerShape(10.dp)).padding(12.dp)) {
                        Column {
                            Text(card.card.name, color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Spacer(Modifier.height(8.dp))
                            Text(card.card.description, color = Color.DarkGray, fontSize = 11.sp, lineHeight = 13.sp)
                            if (card.card.isMonster) {
                                Spacer(Modifier.height(8.dp))
                                Text("ATK ${card.card.atk ?: 0} / DEF ${card.card.def ?: 0}", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Text(
                if (autoDismiss) "Tap to dismiss (auto-closes shortly)" else "Tap to dismiss",
                color = Color(0xFFBBBBBB), fontSize = 10.sp
            )
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Game over overlay
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun GameOverOverlay(state: GameState, vm: GameViewModel) {
    Box(Modifier.fillMaxSize().background(Color(0xCC000000)), Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                when (state.winner) { PlayerId.PLAYER -> "You Win! 🎉"; PlayerId.AI -> "Opponent Wins!"; null -> "Duel Over" },
                color = Color.White, fontWeight = FontWeight.Bold, fontSize = 28.sp
            )
            Spacer(Modifier.height(16.dp))
            Button(onClick = { vm.restart() }) { Text("New Duel") }
        }
    }
}
