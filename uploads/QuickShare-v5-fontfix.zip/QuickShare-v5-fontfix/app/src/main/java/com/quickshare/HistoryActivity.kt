package com.quickshare

import android.content.Context
import android.content.res.Configuration
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.quickshare.databinding.ActivityHistoryBinding

class HistoryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHistoryBinding

    override fun attachBaseContext(newBase: Context) {
        val config = Configuration(newBase.resources.configuration)
        if (config.fontScale > 1.0f) {
            config.fontScale = 1.0f
            super.attachBaseContext(newBase.createConfigurationContext(config))
        } else {
            super.attachBaseContext(newBase)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHistoryBinding.inflate(layoutInflater)
        setContentView(binding.root)
        loadHistory()

        binding.btnClearHistory.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Clear History")
                .setMessage("Delete all transfer records?")
                .setPositiveButton("Clear") { _, _ ->
                    HistoryManager.clear(this)
                    loadHistory()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    private fun loadHistory() {
        val records = HistoryManager.getAll(this)
        if (records.isEmpty()) {
            binding.rvHistory.visibility   = View.GONE
            binding.tvNoHistory.visibility = View.VISIBLE
        } else {
            binding.tvNoHistory.visibility = View.GONE
            binding.rvHistory.visibility   = View.VISIBLE
            binding.rvHistory.layoutManager = LinearLayoutManager(this)
            binding.rvHistory.adapter       = HistoryAdapter(records)
        }
    }
}
