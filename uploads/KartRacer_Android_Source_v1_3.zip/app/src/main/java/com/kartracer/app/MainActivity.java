package com.kartracer.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.opengl.GLSurfaceView;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.kartracer.gl.GameRenderer;
import com.kartracer.net.Discovery;
import com.kartracer.net.Msg;
import com.kartracer.net.NetConst;
import com.kartracer.sim.ResultRow;
import com.kartracer.util.Diag;
import com.kartracer.world.TrackData;

import java.util.ArrayList;
import java.util.List;

import javax.microedition.khronos.egl.EGL10;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.egl.EGLDisplay;

public final class MainActivity extends Activity implements Router, GameEngine.Listener, RaceOverlay.Callbacks {
    private Settings settings;
    private SettingsStore store;
    private GameEngine engine;
    private GameRenderer renderer;
    private GLSurfaceView glView;
    private RaceOverlay overlay;
    private FrameLayout root, uiLayer;
    private Screens screens;
    private Screens.Loading loading;
    private Screens.JoinScreen joinScreen;
    private Screens.LobbyScreen lobbyScreen;
    private View current, pauseView, resultsView;
    private int currentId = -1;
    private final ArrayList<Integer> stack = new ArrayList<Integer>();
    private boolean racing, menuReady, multiplayerRace;
    private TextView banner;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private float lastScale = -1f;
    private int insetL, insetT, insetR, insetB;

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON | WindowManager.LayoutParams.FLAG_FULLSCREEN);
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams wlp = getWindow().getAttributes();
            wlp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(wlp);
        }
        Diag.log("Main", "onCreate");
        store = new SettingsStore(this);
        settings = store.load();
        com.kartracer.audio.Sfx.init(this);
        com.kartracer.audio.Sfx.configure(settings.sound, settings.sfxVolume);
        engine = new GameEngine(this, settings, this);
        renderer = new GameRenderer(settings, engine);
        engine.renderer = renderer;
        screens = new Screens(this, settings, engine, renderer, this);

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        glView = new GLSurfaceView(this);
        glView.setEGLContextClientVersion(3);
        glView.setEGLConfigChooser(new Chooser(settings.quality >= 2 ? 4 : settings.quality == 1 ? 2 : 0));
        glView.setPreserveEGLContextOnPause(true);
        glView.setRenderer(renderer);
        glView.setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
        root.addView(glView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        overlay = new RaceOverlay(this, settings, renderer.hud, renderer.input, this);
        root.addView(overlay, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        uiLayer = new FrameLayout(this);
        root.addView(uiLayer, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        banner = Ui.text(this, "", 14, Ui.TEXT, true);
        banner.setBackground(Ui.rounded(0xDD0C1B2E, 18));
        banner.setPadding(Ui.dp(16), Ui.dp(8), Ui.dp(16), Ui.dp(8));
        banner.setVisibility(View.GONE);
        root.addView(banner, Ui.flpm(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.CENTER_HORIZONTAL, 0, 16, 0, 0));
        loading = screens.loading();
        root.addView(loading, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        loading.setMessage("Starting up...");
        setContentView(root);

        root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override public WindowInsets onApplyWindowInsets(View v, WindowInsets in) {
                int l = in.getSystemWindowInsetLeft(), t = in.getSystemWindowInsetTop(), r = in.getSystemWindowInsetRight(), bt = in.getSystemWindowInsetBottom();
                if (Build.VERSION.SDK_INT >= 28 && in.getDisplayCutout() != null) {
                    l = Math.max(l, in.getDisplayCutout().getSafeInsetLeft()); r = Math.max(r, in.getDisplayCutout().getSafeInsetRight());
                    t = Math.max(t, in.getDisplayCutout().getSafeInsetTop()); bt = Math.max(bt, in.getDisplayCutout().getSafeInsetBottom());
                }
                applyInsets(l, t, r, bt);
                return in;
            }
        });

        engine.bootstrap();
        showScreen(MAIN, false);
        handler.postDelayed(new Runnable() {
            @Override public void run() {
                if (!menuReady && !racing && loading.getVisibility() == View.VISIBLE) {
                    loading.setVisibility(View.GONE);
                    onNotice("The 3D scene is still loading. If it never appears, open Settings > Diagnostics.");
                }
            }
        }, 15000);
        if (DiagLog.crashedLastTime()) {
            DiagLog.clearCrashFlag();
            handler.postDelayed(new Runnable() { @Override public void run() { askAboutCrash(); } }, 1200);
        }
    }

    private void applyInsets(int l, int t, int r, int b) {
        insetL = l; insetT = t; insetR = r; insetB = b;
        for (View v : new View[]{overlay, uiLayer}) {
            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) v.getLayoutParams();
            lp.setMargins(l, t, r, b);
            v.setLayoutParams(lp);
        }
    }

    private void askAboutCrash() {
        new AlertDialog.Builder(this)
                .setTitle("The game closed unexpectedly")
                .setMessage("Something went wrong during the last session. Open the diagnostics log so it can be reported?")
                .setPositiveButton("Open log", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { stack.clear(); stack.add(MAIN); showScreen(DIAG, true); }
                })
                .setNegativeButton("Dismiss", null)
                .show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        glView.onResume();
        com.kartracer.audio.Sfx.resumeAll();
        goImmersive();
    }

    @Override
    protected void onPause() {
        if (racing && engine.mode() == GameEngine.MODE_OFFLINE && pauseView == null && resultsView == null) showPause();
        engine.onPause();
        glView.onPause();
        com.kartracer.audio.Sfx.pauseAll();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        Diag.log("Main", "onDestroy");
        com.kartracer.audio.Sfx.release();
        engine.shutdown();
        super.onDestroy();
    }

    @Override
    public void onWindowFocusChanged(boolean focus) {
        super.onWindowFocusChanged(focus);
        if (focus) goImmersive();
    }

    @SuppressWarnings("deprecation")
    private void goImmersive() {
        View d = getWindow().getDecorView();
        d.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override
    public void onBackPressed() {
        if (loading.getVisibility() == View.VISIBLE && !racing) return;
        if (overlay.isEditing()) return;
        if (resultsView != null) { quit(); return; }
        if (pauseView != null) { resume(); return; }
        if (racing) { showPause(); return; }
        if (currentId == LOBBY) { leaveLobby(); return; }
        if (currentId == MAIN) { super.onBackPressed(); return; }
        back();
    }

    // ------------------------------------------------------------------ screens

    private void showScreen(int id, boolean fade) {
        uiLayer.removeAllViews();
        current = null;
        pauseView = null;
        resultsView = null;
        currentId = id;
        View v;
        boolean kart = false;
        float shift = 0f;
        switch (id) {
            case MAIN: v = screens.main(); kart = true; shift = 0.32f; break;
            case SETUP: v = screens.setup(); break;
            case GARAGE: v = screens.garage(); kart = true; shift = 0f; break;
            case MP_MENU: v = screens.mpMenu(); break;
            case JOIN: joinScreen = screens.join(); v = joinScreen.view; engine.startBrowsing(); break;
            case LOBBY:
                if (lobbyScreen == null) lobbyScreen = screens.lobby();
                v = lobbyScreen.view;
                if (lobbyScreen.view.getParent() != null) ((ViewGroup) lobbyScreen.view.getParent()).removeView(lobbyScreen.view);
                break;
            case SETTINGS: v = screens.settingsScreen(); break;
            default: v = screens.diag(); break;
        }
        if (id != JOIN) engine.stopBrowsing();
        renderer.setMenuKartVisible(kart);
        renderer.setMenuShift(shift);
        renderer.setMenuKart(settings.kart, settings.paint, settings.driver);
        current = v;
        uiLayer.addView(v, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        if (fade) Ui.fadeIn(v);
    }

    @Override
    public void go(int screen) {
        if (currentId >= 0 && currentId != LOBBY || screen == GARAGE) stack.add(currentId);
        showScreen(screen, true);
    }

    @Override
    public void back() {
        int target = stack.isEmpty() ? MAIN : stack.remove(stack.size() - 1);
        if (target == LOBBY && lobbyScreen == null) target = MAIN;
        showScreen(target, true);
        if (target == MAIN) stack.clear();
    }

    @Override public void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_SHORT).show(); }

    @Override public void saveSettings() { store.save(settings); com.kartracer.audio.Sfx.configure(settings.sound, settings.sfxVolume); }

    // ------------------------------------------------------------------ race flow

    @Override
    public void startOffline() {
        store.save(settings);
        engine.startOffline();
    }

    @Override
    public void onLoading(boolean show, String msg) {
        loading.setVisibility(show ? View.VISIBLE : View.GONE);
        if (show) loading.setMessage(msg);
    }

    @Override
    public void onMenuSceneReady() {
        menuReady = true;
        loading.setVisibility(View.GONE);
        Diag.log("Main", "menu scene ready");
    }

    @Override
    public void onRaceReady(TrackData td, boolean multiplayer) {
        racing = true;
        multiplayerRace = multiplayer;
        uiLayer.removeAllViews();
        pauseView = null; resultsView = null; current = null; currentId = -1;
        renderer.setMenuKartVisible(false);
        overlay.setTrack(td);
        overlay.startLoop();
        loading.setVisibility(View.GONE);
    }

    @Override
    public void onRaceEnded(List<ResultRow> rows, boolean multiplayer, boolean isHost, int localSlot) {
        if (!racing) return;
        overlay.stopLoop();
        if (pauseView != null) { uiLayer.removeView(pauseView); pauseView = null; }
        resultsView = screens.results(rows, multiplayer, isHost, localSlot);
        uiLayer.addView(resultsView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        Ui.fadeIn(resultsView);
    }

    private void showPause() {
        if (pauseView != null || resultsView != null) return;
        engine.setPaused(true);
        pauseView = screens.pause(multiplayerRace);
        uiLayer.addView(pauseView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        Ui.fadeIn(pauseView);
    }

    @Override public void onPausePressed() { showPause(); }

    @Override
    public void resume() {
        if (pauseView != null) { uiLayer.removeView(pauseView); pauseView = null; }
        engine.setPaused(false);
    }

    @Override
    public void restart() {
        if (pauseView != null) { uiLayer.removeView(pauseView); pauseView = null; }
        if (resultsView != null) { uiLayer.removeView(resultsView); resultsView = null; }
        overlay.stopLoop();
        engine.setPaused(false);
        engine.restartOffline();
    }

    @Override
    public void quit() {
        leaveRaceUi();
        engine.quitToMenu();
        stack.clear();
        showScreen(MAIN, true);
    }

    private void leaveRaceUi() {
        racing = false;
        overlay.stopLoop();
        pauseView = null; resultsView = null;
        uiLayer.removeAllViews();
    }

    // ------------------------------------------------------------------ multiplayer

    @Override
    public void startHostingAndShowLobby() {
        store.save(settings);
        String err = engine.startHosting();
        if (err != null) { toast(err); return; }
        lobbyScreen = null;
        stack.clear(); stack.add(MAIN); stack.add(MP_MENU);
        showScreen(LOBBY, true);
    }

    @Override
    public void joinHost(String ip, int port) {
        store.save(settings);
        if (joinScreen != null) joinScreen.setStatus("Connecting to " + ip + "...");
        lobbyScreen = null;
        engine.join(ip, port);
    }

    @Override
    public void onLobby(Msg.Lobby lobby, int mySlot, boolean amHost) {
        if (racing && resultsView == null) return;
        if (racing) { // back to the lobby after a race
            leaveRaceUi();
            lobbyScreen = lobbyScreen == null ? null : lobbyScreen;
        }
        if (currentId != LOBBY) {
            if (lobbyScreen == null) lobbyScreen = screens.lobby();
            if (currentId == JOIN || currentId == MP_MENU) { stack.clear(); stack.add(MAIN); stack.add(MP_MENU); }
            showScreen(LOBBY, true);
        }
        lobbyScreen.update(lobby, mySlot, amHost);
    }

    @Override
    public void onHosts(List<Discovery.HostInfo> hosts) {
        if (joinScreen != null && currentId == JOIN) joinScreen.setHosts(hosts);
    }

    @Override public void hostStart() { engine.hostStartRace(); }

    @Override
    public void lobbyRaceAgain() {
        engine.hostBackToLobby();
    }

    @Override
    public void leaveLobby() {
        engine.quitToMenu();
        lobbyScreen = null;
        stack.clear();
        showScreen(MP_MENU, true);
        stack.add(MAIN);
    }

    @Override
    public void onNetEnded(String message) {
        if (currentId == JOIN && !racing && joinScreen != null) { // connection attempt failed: stay on the join screen
            loading.setVisibility(View.GONE);
            joinScreen.setStatus(message == null ? "" : message);
            engine.startBrowsing();
            return;
        }
        leaveRaceUi();
        lobbyScreen = null;
        stack.clear();
        loading.setVisibility(View.GONE);
        showScreen(MP_MENU, true);
        stack.add(MAIN);
        if (message != null && message.length() > 0) new AlertDialog.Builder(this).setMessage(message).setPositiveButton("OK", null).show();
    }

    @Override
    public void onNotice(String text) {
        banner.setText(text);
        banner.setVisibility(View.VISIBLE);
        banner.setAlpha(1f);
        banner.animate().cancel();
        banner.animate().alpha(0f).setStartDelay(2200).setDuration(500).withEndAction(new Runnable() {
            @Override public void run() { banner.setVisibility(View.GONE); }
        }).start();
    }

    // ------------------------------------------------------------------ graphics / profile / misc

    @Override
    public void onStats(int fps, float ms) { }

    @Override
    public void onFatal(final String message) {
        loading.setVisibility(View.GONE);
        if (racing) leaveRaceUi();
        new AlertDialog.Builder(this)
                .setTitle("Graphics problem")
                .setMessage(message + "\n\nThe diagnostics log has the details (Settings > Diagnostics).")
                .setPositiveButton("Open log", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { stack.clear(); stack.add(MAIN); showScreen(DIAG, true); }
                })
                .setNegativeButton("Dismiss", null)
                .show();
    }

    @Override
    public void onRenderScale(final float scale) {
        if (Math.abs(scale - lastScale) < 0.02f) return;
        lastScale = scale;
        final int w = root.getWidth(), h = root.getHeight();
        if (w <= 0 || h <= 0) { handler.postDelayed(new Runnable() { @Override public void run() { onRenderScale(scale); } }, 300); lastScale = -1f; return; }
        if (scale >= 0.99f) glView.getHolder().setSizeFromLayout();
        else glView.getHolder().setFixedSize(Math.round(w * scale), Math.round(h * scale));
        Diag.log("Main", "render scale " + scale + " -> " + Math.round(w * scale) + "x" + Math.round(h * scale));
    }

    @Override
    public void applyGraphics() {
        store.save(settings);
        lastScale = -1f;
        renderer.post(new Runnable() { @Override public void run() { renderer.applyQuality(); } });
    }

    @Override
    public void afterProfileChange() {
        if (engine.mode() == GameEngine.MODE_HOST) engine.hostProfileChanged();
        else if (engine.mode() == GameEngine.MODE_CLIENT) engine.clientUpdate(lobbyScreen != null && lobbyScreen.isReady());
    }

    @Override
    public void editLayout() {
        store.save(settings);
        uiLayer.removeAllViews();
        current = null;
        renderer.setMenuKartVisible(true);
        renderer.setMenuShift(0.3f);
        overlay.startEditing();
    }

    @Override
    public void onEditDone() {
        store.save(settings);
        overlay.stopLoop();
        showScreen(SETTINGS, true);
    }

    @Override public String exportLog() { return DiagLog.export(this); }

    @Override
    public void shareLog() {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_SUBJECT, "KartRacer diagnostics log");
        String t = DiagLog.readAll();
        if (t.length() > 150000) t = t.substring(t.length() - 150000);
        i.putExtra(Intent.EXTRA_TEXT, t);
        startActivity(Intent.createChooser(i, "Share log"));
    }

    @Override
    public void copyLog() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) {
            String t = DiagLog.readAll();
            if (t.length() > 90000) t = t.substring(t.length() - 90000);
            cm.setPrimaryClip(ClipData.newPlainText("KartRacer log", t));
            toast("Log copied");
        }
    }

    /** EGL config chooser with fallbacks so unusual devices still start. */
    private static final class Chooser implements GLSurfaceView.EGLConfigChooser {
        private final int samples;   // wanted multisampling (anti-aliasing), 0 = none

        Chooser(int samples) { this.samples = samples; }

        @Override
        public EGLConfig chooseConfig(EGL10 egl, EGLDisplay display) {
            int[][] specs = {{8, 8, 8, 0, 24, 0}, {8, 8, 8, 0, 16, 0}, {5, 6, 5, 0, 16, 0}, {8, 8, 8, 8, 16, 0}};
            // first pass asks for an anti-aliased config, the second pass is the plain list as before
            for (int pass = samples > 0 ? 0 : 1; pass < 2; pass++) {
                int ms = pass == 0 ? samples : 0;
                for (int[] s : specs) {
                    int[] base = {EGL10.EGL_RED_SIZE, s[0], EGL10.EGL_GREEN_SIZE, s[1], EGL10.EGL_BLUE_SIZE, s[2], EGL10.EGL_ALPHA_SIZE, s[3],
                            EGL10.EGL_DEPTH_SIZE, s[4], EGL10.EGL_STENCIL_SIZE, s[5], EGL10.EGL_RENDERABLE_TYPE, 0x40};
                    int[] attr = new int[base.length + (ms > 0 ? 4 : 0) + 1];
                    System.arraycopy(base, 0, attr, 0, base.length);
                    int p = base.length;
                    if (ms > 0) { attr[p++] = 0x3032; attr[p++] = 1; attr[p++] = 0x3031; attr[p++] = ms; }   // EGL_SAMPLE_BUFFERS, EGL_SAMPLES
                    attr[p] = EGL10.EGL_NONE;
                    int[] num = new int[1];
                    if (!egl.eglChooseConfig(display, attr, null, 0, num) || num[0] <= 0) continue;
                    EGLConfig[] cfgs = new EGLConfig[num[0]];
                    if (!egl.eglChooseConfig(display, attr, cfgs, num[0], num)) continue;
                    int[] v = new int[1];
                    for (EGLConfig c : cfgs) {
                        egl.eglGetConfigAttrib(display, c, EGL10.EGL_DEPTH_SIZE, v);
                        int d = v[0];
                        egl.eglGetConfigAttrib(display, c, EGL10.EGL_RED_SIZE, v);
                        int r = v[0];
                        egl.eglGetConfigAttrib(display, c, EGL10.EGL_STENCIL_SIZE, v);
                        if (d >= s[4] && r >= s[0] && v[0] == s[5]) { Diag.log("GL", "EGL config: rgb" + s[0] + s[1] + s[2] + " depth" + d + " msaa " + ms); return c; }
                    }
                    Diag.log("GL", "EGL config: first match, msaa " + ms);
                    return cfgs[0];
                }
            }
            throw new IllegalArgumentException("No suitable EGL config");
        }
    }
}
