package com.voxelsandbox.game.world

import com.voxelsandbox.game.world.WorldConfig.SUBCHUNKS_PER_CHUNK
import com.voxelsandbox.game.world.WorldConfig.SUBCHUNK_HEIGHT

class Chunk(val pos: ChunkPos) {
    val subChunks: Array<SubChunk> = Array(SUBCHUNKS_PER_CHUNK) { SubChunk() }

    /** Set once, when a player edit first touches this chunk. Only chunks in this
     *  state are written to the save file (everything else regenerates from seed). */
    @Volatile
    var hasPlayerEdits: Boolean = false

    /**
     * Y of the highest solid block of each column as the terrain generator left it
     * (index lz * 16 + lx; trees, plants and water do not count; 0 = unknown). Only a hint
     * for the mesher -- it tells cave interiors and the deep sea floor from real surface --
     * so it is deliberately NOT kept in step with player edits.
     */
    val heightMap = ShortArray(WorldConfig.CHUNK_SIZE * WorldConfig.CHUNK_SIZE)

    /** True if a cave mouth (an entrance ramp) opens inside or right next to this chunk. The
     *  hidden cave interior behind a mouth is then always meshed, so a far-away cave entrance
     *  is dark rock behind its opening instead of a see-through hole. */
    @Volatile
    var caveMouth: Boolean = false

    /** Whether the last mesh of this chunk included its deep faces (cave walls, deep sea
     *  floor), and whether the chunk has any at all. See WorldManager: those faces are only
     *  meshed while the chunk is near the player, which keeps the hidden underground out of
     *  memory and off the GPU everywhere else. */
    @Volatile
    var deepIncluded: Boolean = false

    @Volatile
    var deepCapable: Boolean = false

    /** Same two flags for the deep sea floor (top faces of the bed under 10+ blocks of water),
     *  which is only meshed while the player is underwater nearby. */
    @Volatile
    var seabedIncluded: Boolean = false

    @Volatile
    var seabedCapable: Boolean = false

    /** Fills [heightMap] from the blocks (used for chunks restored from a save, whose
     *  generator-time heights are gone). */
    fun computeHeightMap() {
        val size = WorldConfig.CHUNK_SIZE
        for (lz in 0 until size) {
            for (lx in 0 until size) {
                var y = WorldConfig.WORLD_HEIGHT - 1
                while (y > 0) {
                    val b = getBlock(lx, y, lz)
                    if (b.solid && b != BlockType.LEAVES && b != BlockType.BIRCH_LEAVES && b != BlockType.SPRUCE_LEAVES &&
                        b != BlockType.WOOD && b != BlockType.BIRCH_WOOD && b != BlockType.SPRUCE_WOOD && b != BlockType.CACTUS
                    ) break
                    y--
                }
                heightMap[lz * size + lx] = y.toShort()
            }
        }
    }

    fun getBlock(lx: Int, y: Int, lz: Int): BlockType {
        if (y < 0 || y >= WorldConfig.WORLD_HEIGHT) return BlockType.AIR
        val sub = y / SUBCHUNK_HEIGHT
        val ly = y % SUBCHUNK_HEIGHT
        return subChunks[sub].getBlock(lx, ly, lz)
    }

    fun setBlock(lx: Int, y: Int, lz: Int, type: BlockType) {
        if (y < 0 || y >= WorldConfig.WORLD_HEIGHT) return
        val sub = y / SUBCHUNK_HEIGHT
        val ly = y % SUBCHUNK_HEIGHT
        subChunks[sub].setBlock(lx, ly, lz, type)
    }

    /** The whole block byte (id plus water fill bits), 0 outside the world. */
    fun getRaw(lx: Int, y: Int, lz: Int): Int {
        if (y < 0 || y >= WorldConfig.WORLD_HEIGHT) return 0
        return subChunks[y / SUBCHUNK_HEIGHT].getRaw(lx, y % SUBCHUNK_HEIGHT, lz)
    }

    fun setRaw(lx: Int, y: Int, lz: Int, raw: Int) {
        if (y < 0 || y >= WorldConfig.WORLD_HEIGHT) return
        subChunks[y / SUBCHUNK_HEIGHT].setRaw(lx, y % SUBCHUNK_HEIGHT, lz, raw)
    }

    /** Concatenates all subchunk block arrays into one buffer for saving. */
    fun serializeBlocks(): ByteArray {
        val out = ByteArray(WorldConfig.BYTES_PER_CHUNK)
        var offset = 0
        for (sub in subChunks) {
            System.arraycopy(sub.blocks, 0, out, offset, WorldConfig.BLOCKS_PER_SUBCHUNK)
            offset += WorldConfig.BLOCKS_PER_SUBCHUNK
        }
        return out
    }

    fun deserializeBlocks(data: ByteArray) {
        require(data.size == WorldConfig.BYTES_PER_CHUNK) { "Bad chunk block array size" }
        var offset = 0
        for (sub in subChunks) {
            sub.fill(data.copyOfRange(offset, offset + WorldConfig.BLOCKS_PER_SUBCHUNK))
            offset += WorldConfig.BLOCKS_PER_SUBCHUNK
        }
        computeHeightMap()
    }
}
