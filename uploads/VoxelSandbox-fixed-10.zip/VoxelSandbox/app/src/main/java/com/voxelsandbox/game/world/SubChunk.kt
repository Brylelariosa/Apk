package com.voxelsandbox.game.world

import com.voxelsandbox.game.world.WorldConfig.CHUNK_SIZE

/**
 * One 16x16x16 vertical slice of a chunk. Blocks are stored as a single flat
 * ByteArray (one byte per block id) rather than individual objects — this is the
 * single most important memory decision in the engine: 4096 bytes instead of
 * thousands of allocated Block instances per subchunk.
 *
 * Only the affected subchunk (and, at boundaries, its neighbors) is remeshed when a
 * block changes — see WorldManager.markDirtyAround.
 */
class SubChunk {
    @Volatile
    var blocks: ByteArray = EMPTY

    /** True once this subchunk has been remeshed since its last block change. Read
     *  by WorldManager to decide whether a mesh job is still needed. */
    @Volatile
    var meshDirty: Boolean = true

    /** Quick "nothing to render" flag, updated by the mesher; lets the renderer and
     *  scheduler both skip fully-air subchunks cheaply. */
    @Volatile
    var isEmpty: Boolean = true

    /** True while this subchunk still shares the empty template array, i.e. nothing has
     *  ever been written into it (open sky, most of the upper half of every chunk). The
     *  mesher uses this to skip the 4096-cell scan entirely. */
    fun isAllAir(): Boolean = blocks === EMPTY

    fun getBlock(lx: Int, ly: Int, lz: Int): BlockType =
        BlockType.fromId(blocks[index(lx, ly, lz)])

    fun setBlock(lx: Int, ly: Int, lz: Int, type: BlockType) {
        if (blocks === EMPTY) {
            // First write into a subchunk that was still sharing the empty template:
            // give it its own backing array.
            blocks = ByteArray(WorldConfig.BLOCKS_PER_SUBCHUNK)
        }
        blocks[index(lx, ly, lz)] = type.id
        meshDirty = true
    }

    /** The whole block byte, 0..255: the block id in the low 5 bits and, for water, how
     *  full the cell is in the top 3 (see [Fluid]). */
    fun getRaw(lx: Int, ly: Int, lz: Int): Int =
        blocks[index(lx, ly, lz)].toInt() and 0xFF

    fun setRaw(lx: Int, ly: Int, lz: Int, raw: Int) {
        if (blocks === EMPTY) {
            if (raw == 0) return
            blocks = ByteArray(WorldConfig.BLOCKS_PER_SUBCHUNK)
        }
        blocks[index(lx, ly, lz)] = raw.toByte()
        meshDirty = true
    }

    fun fill(data: ByteArray) {
        require(data.size == WorldConfig.BLOCKS_PER_SUBCHUNK) { "Bad subchunk block array size" }
        blocks = data
        meshDirty = true
    }

    companion object {
        /** Shared immutable all-air backing array, so newly-generated but genuinely
         *  empty subchunks (e.g. high in the sky) cost no per-instance allocation. */
        private val EMPTY = ByteArray(WorldConfig.BLOCKS_PER_SUBCHUNK)

        fun index(lx: Int, ly: Int, lz: Int): Int = (ly * CHUNK_SIZE + lz) * CHUNK_SIZE + lx
    }
}

enum class ChunkState {
    UNLOADED, QUEUED, GENERATING, GENERATED, UNLOADING
}
