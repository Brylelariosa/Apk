package com.voxelsandbox.game.world.generation

import com.voxelsandbox.game.world.WorldConfig
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.tanh

/**
 * The land-form of the world as a pure function of (x, z): oceans, continents, rolling
 * hills, mountain ranges, river valleys, lake basins and swamp flats. It knows nothing
 * about blocks or chunks, so the chunk generator and the distant-terrain builder sample
 * exactly the same landscape.
 *
 * Layers, from large to small:
 *  1. A domain warp bends everything below so coastlines and ranges are organic.
 *  2. Continentalness (very low frequency) decides ocean vs. land and the base elevation
 *     through a hand-shaped curve: deep ocean, shelf, coast, plains, uplands.
 *  3. Mountains: a very slow mask picks where ranges stand; inside it a ridged noise gives
 *     the crests. Ridge height grows with the square of the mask, so a range rises through
 *     long gentle foothills before the cliffs start, and peaks reach ~180 blocks above sea.
 *  4. Hills of a locally varying roughness: calm plains next to rugged country.
 *  5. Rivers follow the zero-crossings of a noise field and cut valleys into lowlands;
 *     lake basins are carved where another noise field is high.
 *  6. Swamps flatten wet, low land to about sea level and scoop shallow ponds into it.
 *  7. Only a faint, slow detail layer on top: the ground is deliberately smooth (no
 *     per-block jitter), so slopes form wide clean terraces.
 */
class TerrainShape(seed: Long, private val climate: Climate) {
    private val warpA = NoiseGenerator(mixSeed(seed, 1))
    private val warpB = NoiseGenerator(mixSeed(seed, 2))
    private val continent = NoiseGenerator(mixSeed(seed, 3))
    private val mountainMask = NoiseGenerator(mixSeed(seed, 4))
    private val ridge = NoiseGenerator(mixSeed(seed, 5))
    private val roughness = NoiseGenerator(mixSeed(seed, 6))
    private val hill = NoiseGenerator(mixSeed(seed, 7))
    private val detail = NoiseGenerator(mixSeed(seed, 8))
    private val river = NoiseGenerator(mixSeed(seed, 9))
    private val lake = NoiseGenerator(mixSeed(seed, 10))
    private val riverWidth = NoiseGenerator(mixSeed(seed, 15))
    private val pond = NoiseGenerator(mixSeed(seed, 19))

    /**
     * Ground height (in blocks, continuous) at world position ([wx], [wz]).
     *
     * [lod] drops the finest features for distant terrain, which is sampled sparsely and
     * would only alias them: 0 = full detail (the voxel world), 1 = no micro roughness,
     * 2 and up = also fewer hill octaves and no mid-scale detail.
     */
    fun height(wx: Double, wz: Double, lod: Int = 0): Double {
        // 1. domain warp
        val wxw = wx + 90.0 * warpA.fbm2D(wx * 0.0021, wz * 0.0021, 2, 0.5, 2.0)
        val wzw = wz + 90.0 * warpB.fbm2D(wx * 0.0021 + 41.0, wz * 0.0021 - 23.0, 2, 0.5, 2.0)

        // 2. continents -> base elevation
        val c = continent.fbm2D(wxw * 0.00042, wzw * 0.00042, 4, 0.5, 2.0) + 0.14
        val baseElev = interpolate(c, BASE_C, BASE_H)
        val base = SEA + baseElev
        val landW = smoothStep(-0.20, 0.03, c)

        // 3. mountains
        val mm = mountainMask.fbm2D(wxw * MASK_FREQ + 57.0, wzw * MASK_FREQ - 13.0, 2, 0.3, 2.0)
        val m = smoothStep(0.0, 0.40, mm) * smoothStep(0.04, 0.26, c)
        var mountains = 0.0
        if (m > 0.0) {
            val r = ridge.ridged2D(wxw * RIDGE_FREQ, wzw * RIDGE_FREQ, 6, 2.0, 1.8)
            mountains = m * MOUNTAIN_UPLIFT + m.pow(1.6) * r.coerceIn(0.0, 1.0).pow(1.4) * MOUNTAIN_AMP
        }

        // 4. hills (amplitude varies from calm plains to rugged country)
        val rough = (0.5 + 0.7 * roughness.fbm2D(wx * 0.0023 + 9.0, wz * 0.0023 + 4.0, 2, 0.5, 2.0)).coerceIn(0.0, 1.0)
        val hillAmp = 1.8 + 15.5 * rough.pow(1.6)
        val coastal = smoothStep(0.0, 14.0, base - SEA)
        val hillOctaves = max(2, 4 - lod)
        val hills = hill.fbm2D(wx * 0.0062, wz * 0.0062, hillOctaves, 0.45, 2.0) * hillAmp * 2.0 * (0.22 + 0.78 * coastal)
        val fine = if (lod <= 1) detail.fbm2D(wx * 0.03 + 3.3, wz * 0.03 - 7.1, 2, 0.5, 2.0) * 0.5 else 0.0
        var h = base + hills * (0.25 + 0.75 * landW) + mountains + fine * landW

        // 5a. rivers: carve a channel along the zero-crossings of the river field
        val rv = abs(river.fbm2D(wxw * 0.0011 + 222.0, wzw * 0.0011 + 11.0, 3, 0.5, 2.0))
        val rwn = 0.5 + 0.5 * riverWidth.noise2D(wx * 0.004, wz * 0.004)
        val rIn = 0.012 + 0.014 * rwn
        val rOut = rIn + 0.07
        val rf = 1.0 - smoothStep(rIn, rOut, rv)
        val lowland = 1.0 - smoothStep(SEA + 7.0, SEA + 20.0, h)
        val fr = rf * lowland * smoothStep(-0.05, 0.05, c)
        val bed = SEA - 3.5 + 2.2 * (1.0 - rf)
        h = min(h, h + (bed - h) * fr)

        // 5b. lakes: basins scooped out of low ground
        val lk = lake.fbm2D(wxw * 0.0030 + 777.0, wzw * 0.0030 - 333.0, 3, 0.5, 2.0)
        val lf = smoothStep(0.30, 0.46, lk) * (1.0 - smoothStep(SEA + 10.0, SEA + 22.0, h)) * smoothStep(-0.05, 0.05, c)
        val lakeBed = SEA - 2.0 - 6.0 * lf
        h = min(h, h + (lakeBed - h) * lf)

        // 6. swamps: wet low land becomes flat ground at about sea level, pitted with
        //    shallow ponds. Only ground that is already low is touched, so a swamp zone never
        //    shaves a hill or mountain down.
        if (baseElev > -2.5 && baseElev < SWAMP_MAX_BASE) {
            val sw = climate.swampWeight(wx, wz, baseElev)
            if (sw > 0.0) {
                val p = 0.5 + 0.5 * pond.fbm2D(wx * 0.022 + 5.0, wz * 0.022 - 9.0, 2, 0.5, 2.0)
                val target = SEA + 1.6 - 3.4 * smoothStep(0.46, 0.66, p)
                val low = 1.0 - smoothStep(SEA + 10.0, SEA + 26.0, h)
                h += (target - h) * smoothStep(0.15, 0.7, sw) * low
            }
        }

        // soft ceiling so peaks never flat-clip against the top of the world
        if (h > SOFT_CEILING) h = SOFT_CEILING + SOFT_RANGE * tanh((h - SOFT_CEILING) / SOFT_RANGE)
        return h.coerceIn(3.0, WorldConfig.WORLD_HEIGHT - 4.0)
    }

    /**
     * Smooth base elevation above sea level (continents only: no hills, mountains or
     * rivers): negative out at sea, about 0 .. 2 along a coastline. Beaches and swamps are
     * decided from this, so a shoreline is one clean band rather than whatever bumps happen
     * to be low.
     */
    fun coastElevation(wx: Double, wz: Double): Double {
        val wxw = wx + 90.0 * warpA.fbm2D(wx * 0.0021, wz * 0.0021, 2, 0.5, 2.0)
        val wzw = wz + 90.0 * warpB.fbm2D(wx * 0.0021 + 41.0, wz * 0.0021 - 23.0, 2, 0.5, 2.0)
        val c = continent.fbm2D(wxw * 0.00042, wzw * 0.00042, 4, 0.5, 2.0) + 0.14
        return interpolate(c, BASE_C, BASE_H)
    }

    private companion object {
        val SEA: Double = WorldConfig.SEA_LEVEL.toDouble()

        /** Above this height the terrain is squeezed asymptotically towards the top of the
         *  world instead of being cut flat. Peaks end up ~180 blocks above sea level. */
        val SOFT_CEILING: Double = SEA + 135.0
        const val SOFT_RANGE = 46.0

        // Mountain tuning (see the class comment). The mask and ridge frequencies are low
        // on purpose: ranges are broad massifs hundreds of blocks across, not needles.
        const val MASK_FREQ = 0.00026
        const val RIDGE_FREQ = 0.0006
        const val MOUNTAIN_UPLIFT = 24.0
        const val MOUNTAIN_AMP = 245.0

        const val SWAMP_MAX_BASE = 22.0

        /** Continentalness -> base elevation above sea level. */
        val BASE_C = doubleArrayOf(-1.0, -0.42, -0.24, -0.11, -0.02, 0.06, 0.20, 0.38, 0.62, 1.0)
        val BASE_H = doubleArrayOf(-42.0, -36.0, -20.0, -8.0, 0.8, 5.0, 10.0, 16.0, 23.0, 30.0)
    }
}
