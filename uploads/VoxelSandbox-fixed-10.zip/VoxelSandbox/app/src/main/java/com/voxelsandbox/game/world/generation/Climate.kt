package com.voxelsandbox.game.world.generation

import com.voxelsandbox.game.world.WorldConfig
import kotlin.math.max

/** What covers the ground at a point of dry land. Shared by the chunk generator (which
 *  turns it into blocks) and the distant-terrain builder (which turns it into a colour),
 *  so a hillside looks the same colour from far away as it does up close. */
enum class SurfaceKind { GRASS, DRY_GRASS, DESERT, BEACH, SNOW, ROCK, GRAVEL, SWAMP }

/** The named regions of the world. A biome is decided by the (very slow) climate fields,
 *  the smooth coastline and the altitude -- never by the local one-block bumps of the
 *  ground -- so each one is a big contiguous region instead of a patchwork. */
enum class Biome(val displayName: String) {
    DEEP_OCEAN("Deep Ocean"),
    OCEAN("Ocean"),
    LAKE("Lake / River"),
    BEACH("Beach"),
    SNOWY_SHORE("Snowy Shore"),
    PLAINS("Plains"),
    FOREST("Forest"),
    BIRCH_FOREST("Birch Forest"),
    TAIGA("Taiga"),
    SNOWY_PLAINS("Snowy Plains"),
    SNOWY_TAIGA("Snowy Taiga"),
    SAVANNA("Savanna"),
    DESERT("Desert"),
    SWAMP("Swamp"),
    MOUNTAINS("Mountains"),
    SNOWY_PEAKS("Snowy Peaks")
}

/**
 * Temperature, humidity and forest cover as smooth pure functions of position, plus the
 * rules that turn them (with elevation, slope and the distance to the sea) into a [Biome]
 * and a [SurfaceKind].
 *
 * The biome of dry land comes from a temperature x humidity table, like a classic climate
 * diagram, using the temperature AT THE GROUND (sea-level temperature minus a lapse rate
 * per block of altitude). Two things follow from that and are the point of it:
 *  - Temperature is one smooth field cut into five bands (frozen, cold, temperate, warm,
 *    hot), and each band has its own biomes. Crossing from desert (hot) to snow (frozen)
 *    therefore always passes through savanna / plains / taiga on the way: the two can
 *    never touch, and the transition spans hundreds of blocks (a few hundred at the very
 *    least, about a thousand typically).
 *  - Mountains cool with height, so a range climbs through forest, then taiga, then bare
 *    rock, then a snow cap, and the snow line sits lower in cold climates and higher in
 *    hot ones, all from the same rule.
 * A little noise is added to both fields before they are cut into bands so biome borders
 * wander instead of following smooth contour lines.
 *
 * Swamps are wet, mild, low-lying land; [swampWeight] also drives TerrainShape, which turns
 * such land into flat ground dotted with shallow ponds (where the lily pads grow).
 */
class Climate(seed: Long) {
    private val temperatureNoise = NoiseGenerator(mixSeed(seed, 11))
    private val humidityNoise = NoiseGenerator(mixSeed(seed, 12))
    private val forestNoise = NoiseGenerator(mixSeed(seed, 13))
    private val jitterNoise = NoiseGenerator(mixSeed(seed, 16))
    private val variantNoise = NoiseGenerator(mixSeed(seed, 17))
    private val swampNoise = NoiseGenerator(mixSeed(seed, 18))

    /** Sea-level temperature in -1 (arctic) .. 1 (tropical). Slow: climate zones span
     *  well over a thousand blocks. */
    fun baseTemperature(wx: Double, wz: Double): Double =
        (temperatureNoise.fbm2D(wx * T_FREQ + 31.0, wz * T_FREQ - 17.0, 2, 0.5, 2.0) * T_SCALE + T_OFFSET).coerceIn(-1.0, 1.0)

    /** Humidity in -1 (arid) .. 1 (wet). */
    fun humidity(wx: Double, wz: Double): Double =
        (humidityNoise.fbm2D(wx * H_FREQ - 70.0, wz * H_FREQ + 44.0, 2, 0.5, 2.0) * H_SCALE).coerceIn(-1.0, 1.0)

    /** Forest-ness in 0..1 (0 = open ground, 1 = dense forest). Drives tree density and
     *  the darker green the distant terrain uses over forests. */
    fun forest(wx: Double, wz: Double): Double {
        val f = forestNoise.fbm2D(wx * 0.011, wz * 0.011, 2, 0.5, 2.0)
        return ((f + 0.02) / 0.5).coerceIn(0.0, 1.0)
    }

    /**
     * 0..1: how swampy the land at (wx, wz) is, given the smooth base elevation [baseElev]
     * above sea level (TerrainShape.coastElevation). Non-zero only on wet, mild, low-lying
     * land, in loose patches. Cheap when it is clearly not a swamp (most places).
     */
    fun swampWeight(wx: Double, wz: Double, baseElev: Double): Double {
        if (baseElev < -2.5 || baseElev > SWAMP_MAX_BASE) return 0.0
        val hum = humidity(wx, wz)
        if (hum < SWAMP_HUM_LO) return 0.0
        val t = baseTemperature(wx, wz)
        if (t < -0.15 || t > 0.74) return 0.0
        val w = smoothStep(SWAMP_HUM_LO, SWAMP_HUM_HI, hum) *
            smoothStep(-0.20, 0.0, t) *
            (1.0 - smoothStep(0.55, 0.72, t)) *
            (1.0 - smoothStep(SWAMP_MAX_BASE - 8.0, SWAMP_MAX_BASE, baseElev))
        val patch = smoothStep(
            SWAMP_PATCH_LO, SWAMP_PATCH_HI,
            swampNoise.fbm2D(wx * 0.0035 + 9.0, wz * 0.0035 - 4.0, 2, 0.5, 2.0)
        )
        return w * patch
    }

    /**
     * Biome of dry land at ground height [h] with local [slope] (blocks of rise per block,
     * measured over a 2-block baseline). [coast] is the smooth base elevation above sea level
     * (see TerrainShape.coastElevation): small only along real coastlines.
     */
    fun biome(wx: Double, wz: Double, h: Double, slope: Double, coast: Double): Biome {
        val alt = h - SEA
        val t0 = baseTemperature(wx, wz)
        val jt = jitterNoise.noise2D(wx * 0.011 + 5.0, wz * 0.011 - 3.0) * 0.07
        val jh = jitterNoise.noise2D(wx * 0.011 - 40.0, wz * 0.011 + 60.0) * 0.07
        // Temperature at the ground: cooler the higher you stand.
        val te = t0 + jt - LAPSE * max(0.0, alt)
        val hu = humidity(wx, wz) + jh
        val jr = jitterNoise.noise2D(wx * 0.05 + 5.0, wz * 0.05 - 3.0)

        if (alt >= ROCK_ALT + jr * 6.0) {
            return if (te < SNOW_T) Biome.SNOWY_PEAKS else Biome.MOUNTAINS
        }
        if (coast < 2.4 && alt < 7.0 && slope < 1.1) {
            return if (t0 + jt < COLD) Biome.SNOWY_SHORE else Biome.BEACH
        }
        if (alt < SWAMP_MAX_ALT && swampWeight(wx, wz, coast) > 0.5) return Biome.SWAMP

        if (te < FROZEN) return if (hu > -0.10) Biome.SNOWY_TAIGA else Biome.SNOWY_PLAINS
        if (te < COLD_MAX) return if (hu > -0.22) Biome.TAIGA else Biome.PLAINS
        if (te < TEMPERATE_MAX) {
            if (hu > 0.10) {
                val v = variantNoise.fbm2D(wx * 0.0012 + 3.0, wz * 0.0012 - 8.0, 2, 0.5, 2.0)
                return if (v > 0.10) Biome.BIRCH_FOREST else Biome.FOREST
            }
            if (hu < -0.50 && te > 0.18) return Biome.SAVANNA
            return Biome.PLAINS
        }
        if (te < WARM_MAX) {
            if (hu < -0.12) return Biome.SAVANNA
            if (hu > 0.22) return Biome.FOREST
            return Biome.PLAINS
        }
        if (hu < 0.0) return Biome.DESERT
        if (hu < 0.40) return Biome.SAVANNA
        return Biome.FOREST
    }

    /** Biome of a water column [depth] blocks below sea level at (wx, wz): shallow water in a
     *  swampy area is part of the swamp (that is where the lily pads grow). */
    fun waterBiome(wx: Double, wz: Double, depth: Double, coast: Double): Biome {
        if (depth <= 4.5 && coast >= -2.5 && swampWeight(wx, wz, coast) > 0.5) return Biome.SWAMP
        if (coast >= 1.0) return Biome.LAKE
        return if (depth > 14.0) Biome.DEEP_OCEAN else Biome.OCEAN
    }

    /** Ground cover of dry land in [biome] at height [h] with local [slope]. */
    fun surfaceFor(biome: Biome, wx: Double, wz: Double, h: Double, slope: Double): SurfaceKind {
        val alt = h - SEA
        val jitter = jitterNoise.noise2D(wx * 0.09 + 5.0, wz * 0.09 - 3.0)
        val kind = when (biome) {
            Biome.DESERT -> SurfaceKind.DESERT
            Biome.SAVANNA -> SurfaceKind.DRY_GRASS
            Biome.BEACH -> SurfaceKind.BEACH
            Biome.SNOWY_SHORE -> SurfaceKind.GRAVEL
            Biome.SNOWY_PLAINS, Biome.SNOWY_TAIGA, Biome.SNOWY_PEAKS -> SurfaceKind.SNOW
            Biome.SWAMP -> SurfaceKind.SWAMP
            // Bare rock, with the odd alpine meadow on flat ground below the snow line.
            Biome.MOUNTAINS -> if (slope < 0.45 && alt < ROCK_ALT + 30.0 && jitter > 0.15) SurfaceKind.GRASS else SurfaceKind.ROCK
            else -> SurfaceKind.GRASS
        }
        if (biome == Biome.BEACH || biome == Biome.SNOWY_SHORE || biome == Biome.SWAMP) return kind
        if (alt > 3.0 && slope > 1.1 + 0.25 * jitter) return SurfaceKind.ROCK // cliffs
        if (biome == Biome.SNOWY_PEAKS) return SurfaceKind.SNOW
        if (kind != SurfaceKind.SNOW && alt > 20.0 && slope > 0.75 + 0.2 * jitter) return SurfaceKind.GRAVEL // scree
        return kind
    }

    companion object {
        /** Sea-level temperature below which water is cold (gravel beds) and the shore is snowy. */
        const val COLD = -0.30

        // Temperature field: frequency, scale and offset (zones span a few thousand blocks).
        private const val T_FREQ = 0.00030
        private const val T_SCALE = 1.3
        private const val T_OFFSET = 0.12
        private const val H_FREQ = 0.0005
        private const val H_SCALE = 1.5

        /** Temperature lost per block of altitude above sea level. */
        private const val LAPSE = 0.0055

        // The five temperature bands, as ground temperature thresholds.
        private const val FROZEN = -0.55
        private const val COLD_MAX = -0.20
        private const val TEMPERATE_MAX = 0.38
        private const val WARM_MAX = 0.66

        /** Ground temperature below which a mountain top wears snow. */
        private const val SNOW_T = -0.50

        /** Height above sea level where the bare-rock mountain zone starts. */
        private const val ROCK_ALT = 72.0

        // Swamp: wet (humidity band), mild (temperature band), low (base elevation band).
        private const val SWAMP_HUM_LO = -0.05
        private const val SWAMP_HUM_HI = 0.20
        private const val SWAMP_PATCH_LO = -0.40
        private const val SWAMP_PATCH_HI = 0.0
        private const val SWAMP_MAX_BASE = 22.0
        private const val SWAMP_MAX_ALT = 14.0

        private val SEA: Double = WorldConfig.SEA_LEVEL.toDouble()
    }
}
