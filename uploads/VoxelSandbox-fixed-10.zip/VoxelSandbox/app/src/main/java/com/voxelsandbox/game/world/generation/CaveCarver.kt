package com.voxelsandbox.game.world.generation

import com.voxelsandbox.game.world.BlockType
import com.voxelsandbox.game.world.Chunk
import com.voxelsandbox.game.world.WorldConfig
import java.util.Arrays
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Carves the underground: winding tunnels, big caverns and a few entrance ramps.
 *
 * Everything is a pure function of the seed and the position, evaluated one chunk at a time
 * on a coarse lattice (every 4 blocks) that is interpolated per block. Lattice cells line
 * up with chunk borders, so a cave runs straight across chunks without a seam.
 *
 *  - Tunnels follow the zero-contours of 2D noise (think of rivers running underground),
 *    in four stacked layers at different depths. The distance to the contour is estimated
 *    from the noise gradient, which gives every tunnel a round cross-section of a chosen
 *    radius regardless of how steep the noise is there. The tunnel's centre height and
 *    radius drift slowly. A slow "cave system" mask scales the radius, so tunnels cluster
 *    into networks and pinch out at the edges instead of riddling all the rock.
 *  - Caverns are blobs where a stretched 3D noise is high.
 *  - Nothing ever comes closer to the surface than [COVER_LAND] blocks (more under water),
 *    so the ground is intact and the sea cannot drain. The only openings are entrance ramps:
 *    on a deterministic grid of "sites", a sloping tunnel leads from a hillside down into the
 *    rock. [caveMouthNear] / [nearMouth] tell the mesher and the tree planter about them.
 *  - Any carved cell that would touch water is put back as rock, so caves never leak.
 */
class CaveCarver(seed: Long, private val shape: TerrainShape) {
    private val salt = mixSeed(seed, 99)
    private val contourNoise = Array(LAYERS) { NoiseGenerator(mixSeed(seed, 50 + it)) }
    private val detailNoise = Array(LAYERS) { NoiseGenerator(mixSeed(seed, 60 + it)) }
    private val centerNoise = Array(LAYERS) { NoiseGenerator(mixSeed(seed, 70 + it)) }
    private val radiusNoise = Array(LAYERS) { NoiseGenerator(mixSeed(seed, 80 + it)) }
    private val systemNoise = NoiseGenerator(mixSeed(seed, 90))
    private val cavernNoise = NoiseGenerator(mixSeed(seed, 91))

    /** Per-thread working memory (chunks are generated on several threads at once). */
    private class Scratch {
        val carved = BooleanArray(CS * WorldConfig.WORLD_HEIGHT * CS)
        val limit = IntArray(CS * CS)
        val contour = Array(LAYERS) { FloatArray(LATTICE * LATTICE) }
        val centerY = Array(LAYERS) { FloatArray(LATTICE * LATTICE) }
        val radius = Array(LAYERS) { FloatArray(LATTICE * LATTICE) }
        val system = FloatArray(LATTICE * LATTICE)
        val cavern = FloatArray(LATTICE * LATTICE * MAX_NY)
    }

    private val scratch = object : ThreadLocal<Scratch>() {
        override fun initialValue(): Scratch = Scratch()
    }

    private class Site(val x: Double, val z: Double, val groundY: Int, val dirX: Double, val dirZ: Double, val length: Int, val phase: Double)

    private val sites = ConcurrentHashMap<Long, Any>()

    /**
     * Carves tunnels, caverns and entrance ramps into [chunk], whose terrain is already
     * filled in. [ground] is the top solid Y of each column (index lz * 16 + lx) and
     * [underWater] says whether that column is below the sea.
     */
    fun carve(chunk: Chunk, ground: IntArray, underWater: BooleanArray) {
        carveNetwork(chunk, ground, underWater)
        carveMouths(chunk, ground, underWater)
    }

    // ------------------------------------------------------------------ tunnels + caverns

    private fun carveNetwork(chunk: Chunk, ground: IntArray, underWater: BooleanArray) {
        val s = scratch.get() ?: return
        val bx = chunk.pos.x * CS
        val bz = chunk.pos.z * CS
        var yTop = 0
        for (i in 0 until CS * CS) {
            val cover = if (underWater[i]) COVER_WATER else COVER_LAND
            val lim = min(ground[i] - cover, Y_CAP)
            s.limit[i] = lim
            if (lim > yTop) yTop = lim
        }
        if (yTop < Y_LO) return

        // 1. sample the fields on the lattice
        for (gz in 0 until LATTICE) {
            for (gx in 0 until LATTICE) {
                val x = (bx + gx * 4).toDouble()
                val z = (bz + gz * 4).toDouble()
                val k = gz * LATTICE + gx
                s.system[k] = smoothStep(SYS_LO, SYS_HI, systemNoise.fbm2D(x * SYS_FREQ, z * SYS_FREQ, 2, 0.5, 2.0)).toFloat()
                for (l in 0 until LAYERS) {
                    s.contour[l][k] = (contourNoise[l].noise2D(x * FREQ, z * FREQ) + 0.25 * detailNoise[l].noise2D(x * FREQ * 2.6, z * FREQ * 2.6)).toFloat()
                    s.centerY[l][k] = (BASE_Y[l] + Y_AMP * centerNoise[l].noise2D(x / 90.0, z / 90.0)).toFloat()
                    s.radius[l][k] = (R_MIN + (R_MAX - R_MIN) * (0.5 + 0.5 * radiusNoise[l].noise2D(x / 55.0, z / 55.0))).toFloat()
                }
            }
        }
        val ny = (yTop - Y_LO) / 4 + 2
        for (gz in 0 until LATTICE) {
            for (gx in 0 until LATTICE) {
                val base = (gz * LATTICE + gx) * ny
                val x = (bx + gx * 4).toDouble()
                val z = (bz + gz * 4).toDouble()
                for (gy in 0 until ny) {
                    val y = (Y_LO + gy * 4).toDouble()
                    s.cavern[base + gy] = (
                        0.65 * cavernNoise.noise3D(x * CAV_FREQ, y * CAV_FREQ * 1.5, z * CAV_FREQ) +
                            0.35 * cavernNoise.noise3D(x * CAV_FREQ * 2.1 + 9.0, y * CAV_FREQ * 3.1, z * CAV_FREQ * 2.1 - 4.0)
                        ).toFloat()
                }
            }
        }

        // 2. decide, per column, which cells are carved
        Arrays.fill(s.carved, false)
        for (lz in 0 until CS) {
            for (lx in 0 until CS) {
                val lim = s.limit[lz * CS + lx]
                if (lim < Y_LO) continue
                val gx = lx shr 2
                val gz = lz shr 2
                val fx = (lx and 3) * 0.25
                val fz = (lz and 3) * 0.25
                val sys = bilinear(s.system, gx, gz, fx, fz)
                if (sys > 0.01) {
                    for (l in 0 until LAYERS) carveTunnel(s, l, gx, gz, fx, fz, sys, lim, lx, lz)
                }
                for (y in Y_LO..lim) {
                    val gy = (y - Y_LO) shr 2
                    val fy = ((y - Y_LO) and 3) * 0.25
                    val c = trilinear(s.cavern, gx, gz, gy, ny, fx, fy, fz)
                    val thr = CAV_THRESHOLD + 0.22 * (1.0 - min(1.0, (y - Y_LO) / 14.0)) + 0.25 * (1.0 - min(1.0, (lim - y + 1) / 10.0))
                    if (c > thr) s.carved[(y * CS + lz) * CS + lx] = true
                }
            }
        }

        // 3. apply: put air in, but never next to water (seals would-be leaks as rock)
        for (lz in 0 until CS) {
            for (lx in 0 until CS) {
                val lim = s.limit[lz * CS + lx]
                for (y in Y_LO..lim) {
                    if (!s.carved[(y * CS + lz) * CS + lx]) continue
                    if (touchesWater(chunk, lx, y, lz)) continue
                    chunk.setBlock(lx, y, lz, BlockType.AIR)
                }
            }
        }
    }

    private fun carveTunnel(s: Scratch, l: Int, gx: Int, gz: Int, fx: Double, fz: Double, sys: Double, lim: Int, lx: Int, lz: Int) {
        val f = s.contour[l]
        val i00 = gz * LATTICE + gx
        val n00 = f[i00].toDouble()
        val n10 = f[i00 + 1].toDouble()
        val n01 = f[i00 + LATTICE].toDouble()
        val n11 = f[i00 + LATTICE + 1].toDouble()
        val n = bilinear(f, gx, gz, fx, fz)
        val gxn = ((n10 - n00) + (n11 - n01)) * 0.5 / 4.0
        val gzn = ((n01 - n00) + (n11 - n10)) * 0.5 / 4.0
        val gm = max(1.0e-4, sqrt(gxn * gxn + gzn * gzn))
        val d = abs(n) / gm // distance (blocks) to the tunnel's centre line, roughly
        if (d > R_MAX * sys + 1.0) return
        val y0 = bilinear(s.centerY[l], gx, gz, fx, fz)
        // never come closer to the surface than the cover allows: the tunnel narrows instead
        val r = min(bilinear(s.radius[l], gx, gz, fx, fz) * sys, lim - y0 + 0.5)
        if (r < 1.2 || d >= r) return
        val hh = sqrt(r * r - d * d)
        val ya = max(Y_LO, ceil(y0 - hh).toInt())
        val yb = min(lim, floor(y0 + hh).toInt())
        for (y in ya..yb) s.carved[(y * CS + lz) * CS + lx] = true
    }

    private fun bilinear(f: FloatArray, gx: Int, gz: Int, fx: Double, fz: Double): Double {
        val i = gz * LATTICE + gx
        val a = f[i] + (f[i + 1] - f[i]) * fx
        val b = f[i + LATTICE] + (f[i + LATTICE + 1] - f[i + LATTICE]) * fx
        return a + (b - a) * fz
    }

    private fun trilinear(f: FloatArray, gx: Int, gz: Int, gy: Int, ny: Int, fx: Double, fy: Double, fz: Double): Double {
        val i000 = (gz * LATTICE + gx) * ny + gy
        val i100 = (gz * LATTICE + gx + 1) * ny + gy
        val i010 = ((gz + 1) * LATTICE + gx) * ny + gy
        val i110 = ((gz + 1) * LATTICE + gx + 1) * ny + gy
        val c00 = f[i000] + (f[i100] - f[i000]) * fx
        val c10 = f[i010] + (f[i110] - f[i010]) * fx
        val c01 = f[i000 + 1] + (f[i100 + 1] - f[i000 + 1]) * fx
        val c11 = f[i010 + 1] + (f[i110 + 1] - f[i010 + 1]) * fx
        val c0 = c00 + (c10 - c00) * fz
        val c1 = c01 + (c11 - c01) * fz
        return c0 + (c1 - c0) * fy
    }

    /** True if any of the six neighbours of the cell (inside this chunk) holds water. */
    private fun touchesWater(chunk: Chunk, lx: Int, y: Int, lz: Int): Boolean {
        if (lx > 0 && chunk.getBlock(lx - 1, y, lz).holdsWater) return true
        if (lx < CS - 1 && chunk.getBlock(lx + 1, y, lz).holdsWater) return true
        if (lz > 0 && chunk.getBlock(lx, y, lz - 1).holdsWater) return true
        if (lz < CS - 1 && chunk.getBlock(lx, y, lz + 1).holdsWater) return true
        if (y < WorldConfig.WORLD_HEIGHT - 1 && chunk.getBlock(lx, y + 1, lz).holdsWater) return true
        if (y > 0 && chunk.getBlock(lx, y - 1, lz).holdsWater) return true
        return false
    }

    // ------------------------------------------------------------------ entrance ramps

    /** True if a cave mouth is close enough that its (otherwise hidden) interior should always
     *  be meshed for the chunk at ([cx], [cz]). */
    fun caveMouthNear(cx: Int, cz: Int): Boolean {
        val mx = cx * CS + CS / 2.0
        val mz = cz * CS + CS / 2.0
        return anySiteWithin(mx, mz, MOUTH_ZONE)
    }

    /** True if (wx, wz) is on or beside a ramp's opening, where trees must not stand. */
    fun nearMouth(wx: Double, wz: Double): Boolean = anySiteWithin(wx, wz, MOUTH_CLEAR)

    private fun anySiteWithin(px: Double, pz: Double, radius: Double): Boolean {
        val c0x = Math.floorDiv((px - radius).toInt(), SITE_CELL)
        val c1x = Math.floorDiv((px + radius).toInt(), SITE_CELL)
        val c0z = Math.floorDiv((pz - radius).toInt(), SITE_CELL)
        val c1z = Math.floorDiv((pz + radius).toInt(), SITE_CELL)
        for (cz in c0z..c1z) {
            for (cx in c0x..c1x) {
                val site = siteAt(cx, cz) ?: continue
                val dx = site.x - px
                val dz = site.z - pz
                if (dx * dx + dz * dz <= radius * radius) return true
            }
        }
        return false
    }

    private fun carveMouths(chunk: Chunk, ground: IntArray, underWater: BooleanArray) {
        val bx = chunk.pos.x * CS
        val bz = chunk.pos.z * CS
        val reach = MOUTH_REACH
        val c0x = Math.floorDiv(bx - reach, SITE_CELL)
        val c1x = Math.floorDiv(bx + CS + reach, SITE_CELL)
        val c0z = Math.floorDiv(bz - reach, SITE_CELL)
        val c1z = Math.floorDiv(bz + CS + reach, SITE_CELL)
        for (cz in c0z..c1z) {
            for (cx in c0x..c1x) {
                val site = siteAt(cx, cz) ?: continue
                carveRamp(chunk, ground, underWater, site, bx, bz)
            }
        }
    }

    private fun carveRamp(chunk: Chunk, ground: IntArray, underWater: BooleanArray, site: Site, bx: Int, bz: Int) {
        for (t in -2..site.length) {
            val cx = site.x + site.dirX * t
            val cz = site.z + site.dirZ * t
            val cy = site.groundY + 1.0 - RAMP_SLOPE * t
            val r = if (t == site.length) 3.8 else 2.5 + 0.6 * sin(t * 0.4 + site.phase)
            carveSphere(chunk, ground, underWater, cx, cy, cz, r, bx, bz)
        }
    }

    private fun carveSphere(chunk: Chunk, ground: IntArray, underWater: BooleanArray, cx: Double, cy: Double, cz: Double, r: Double, bx: Int, bz: Int) {
        val x0 = max(bx, floor(cx - r).toInt())
        val x1 = min(bx + CS - 1, ceil(cx + r).toInt())
        val z0 = max(bz, floor(cz - r).toInt())
        val z1 = min(bz + CS - 1, ceil(cz + r).toInt())
        if (x0 > x1 || z0 > z1) return
        val y0 = max(3, floor(cy - r).toInt())
        val r2 = r * r
        for (z in z0..z1) {
            for (x in x0..x1) {
                val lx = x - bx
                val lz = z - bz
                val col = lz * CS + lx
                if (underWater[col] || ground[col] < SEA_I + 2) continue
                val y1 = min(ground[col], ceil(cy + r).toInt())
                val dx = x + 0.5 - cx
                val dz = z + 0.5 - cz
                for (y in y0..y1) {
                    val dy = y + 0.5 - cy
                    if (dx * dx + dy * dy + dz * dz > r2) continue
                    val block = chunk.getBlock(lx, y, lz)
                    if (block == BlockType.AIR || block.holdsWater) continue
                    if (touchesWater(chunk, lx, y, lz)) continue
                    chunk.setBlock(lx, y, lz, BlockType.AIR)
                    if (y >= ground[col]) clearAbove(chunk, lx, y + 1, lz)
                }
            }
        }
    }

    /** Removes the plants / cactus standing on a cell whose ground was just carved away. */
    private fun clearAbove(chunk: Chunk, lx: Int, fromY: Int, lz: Int) {
        var y = fromY
        while (y < WorldConfig.WORLD_HEIGHT) {
            val b = chunk.getBlock(lx, y, lz)
            if (b.plant || b == BlockType.CACTUS) {
                chunk.setBlock(lx, y, lz, BlockType.AIR)
                y++
            } else {
                return
            }
        }
    }

    private fun siteAt(cellX: Int, cellZ: Int): Site? {
        val key = (cellX.toLong() shl 32) xor (cellZ.toLong() and 0xFFFFFFFFL)
        var v = sites[key]
        if (v == null) {
            v = computeSite(cellX, cellZ) ?: NO_SITE
            if (sites.size > MAX_CACHED_SITES) sites.clear()
            sites[key] = v
        }
        return if (v === NO_SITE) null else v as Site
    }

    private fun computeSite(cellX: Int, cellZ: Int): Site? {
        val h = hash(cellX, cellZ)
        if (((h and 0xFFFF).toDouble() / 65536.0) >= SITE_CHANCE) return null
        val sx = cellX * SITE_CELL + 14.0 + ((h ushr 16) and 0xFF) / 255.0 * (SITE_CELL - 28.0)
        val sz = cellZ * SITE_CELL + 14.0 + ((h ushr 24) and 0xFF) / 255.0 * (SITE_CELL - 28.0)
        val gh = floor(shape.height(sx, sz, 0)).toInt()
        if (gh < SEA_I + 6 || gh > SEA_I + 110) return null
        // enter the hill: walk towards higher ground; on flat land any direction will do
        val gx = (shape.height(sx + 6.0, sz, 0) - shape.height(sx - 6.0, sz, 0)) / 12.0
        val gz = (shape.height(sx, sz + 6.0, 0) - shape.height(sx, sz - 6.0, 0)) / 12.0
        val gl = sqrt(gx * gx + gz * gz)
        val dirX: Double
        val dirZ: Double
        if (gl > 0.12) {
            dirX = gx / gl
            dirZ = gz / gl
        } else {
            val ang = ((h ushr 40) and 0xFFFF).toDouble() / 65536.0 * 2.0 * Math.PI
            dirX = cos(ang)
            dirZ = sin(ang)
        }
        val length = 30 + ((h ushr 56) and 0xF).toInt()
        val phase = ((h ushr 32) and 0xFF) / 255.0 * 6.28
        return Site(sx, sz, gh, dirX, dirZ, length, phase)
    }

    private fun hash(cx: Int, cz: Int): Long {
        var z = salt + cx.toLong() * -7046029254386353131L + cz.toLong() * 0x632BE59BD9B4E019L
        z = (z xor (z ushr 30)) * -4658895280553007687L
        z = (z xor (z ushr 27)) * -7723592293110705685L
        return z xor (z ushr 31)
    }

    private companion object {
        const val CS = WorldConfig.CHUNK_SIZE
        const val LATTICE = 5
        const val LAYERS = 4
        const val MAX_NY = 24
        val SEA_I: Int = WorldConfig.SEA_LEVEL

        const val Y_LO = 6
        val Y_CAP: Int = WorldConfig.SEA_LEVEL + 24
        const val COVER_LAND = 6
        const val COVER_WATER = 9

        // tunnels
        const val FREQ = 1.0 / 100.0
        val BASE_Y = doubleArrayOf(16.0, 30.0, 45.0, 62.0)
        const val Y_AMP = 9.0
        const val R_MIN = 2.0
        const val R_MAX = 4.2
        const val SYS_FREQ = 1.0 / 260.0
        const val SYS_LO = 0.0
        const val SYS_HI = 0.40

        // caverns
        const val CAV_FREQ = 1.0 / 42.0
        const val CAV_THRESHOLD = 0.66

        // entrance ramps
        const val SITE_CELL = 96
        const val SITE_CHANCE = 0.34
        const val RAMP_SLOPE = 0.7
        const val MOUTH_ZONE = 60.0
        const val MOUTH_CLEAR = 12.0
        const val MOUTH_REACH = 52
        const val MAX_CACHED_SITES = 40000
        val NO_SITE = Any()
    }
}
