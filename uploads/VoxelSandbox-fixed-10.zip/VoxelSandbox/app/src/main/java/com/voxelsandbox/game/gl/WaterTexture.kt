package com.voxelsandbox.game.gl

import android.opengl.GLES30
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

/**
 * The water tile: 128x128 stylised pixel art in five blues with thin light ripple lines,
 * generated once at start-up from tileable noise (so it repeats seamlessly in both
 * directions and the shader can scroll it freely, see Shaders.WATER_FRAGMENT).
 *
 * The shader stretches one repeat over about 8-12 blocks and blends two copies at
 * different scales and angles, so the eye never finds a lattice of repeats -- the old
 * one-block tile of single-pixel sparkles read as a grid, and aliased into moire in the
 * distance. The look is still deliberately flat and chunky (posterised bands, no
 * reflections), in keeping with the block textures.
 *
 * Construction, per texel of the unit tile:
 *  - A smooth height field (three octaves of periodic value noise, slightly domain-warped
 *    so it swirls) is stretched to 0..1 and cut into five bands, one blue each: the blobs.
 *  - A second, independent field gives the ripple lines: the texels close to its 0.5
 *    contour (about 8% of them) are crest texels, a lighter blue with alpha 255. The
 *    shader uses alpha as the highlight mask; the mip chain turns it into coverage.
 *
 * Nearest-texel filtering with mip-mapping: crisp square texels up close.
 */
class WaterTexture {
    private var textureId = 0

    fun upload() {
        val ids = IntArray(1)
        GLES30.glGenTextures(1, ids, 0)
        textureId = ids[0]
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textureId)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_NEAREST_MIPMAP_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_NEAREST)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_REPEAT)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_REPEAT)

        val buf = ByteBuffer.allocateDirect(SIZE * SIZE * 4).order(ByteOrder.nativeOrder())
        buf.put(generate())
        buf.position(0)
        GLES30.glTexImage2D(
            GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RGBA, SIZE, SIZE, 0,
            GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, buf
        )
        GLES30.glGenerateMipmap(GLES30.GL_TEXTURE_2D)
        enableAnisotropy()
    }

    fun bind(unit: Int) {
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0 + unit)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textureId)
    }

    /** RGBA bytes of the tile, row by row. */
    private fun generate(): ByteArray {
        val count = SIZE * SIZE
        val blobs = FloatArray(count)
        val ripples = FloatArray(count)
        var blobMin = 9f
        var blobMax = -9f
        var rippleMin = 9f
        var rippleMax = -9f
        for (y in 0 until SIZE) {
            for (x in 0 until SIZE) {
                val u = (x + 0.5f) / SIZE
                val v = (y + 0.5f) / SIZE
                val a = height(u, v, 0)
                val b = height(u, v, 40)
                blobs[y * SIZE + x] = a
                ripples[y * SIZE + x] = b
                blobMin = min(blobMin, a)
                blobMax = max(blobMax, a)
                rippleMin = min(rippleMin, b)
                rippleMax = max(rippleMax, b)
            }
        }
        val out = ByteArray(count * 4)
        for (i in 0 until count) {
            val n1 = (blobs[i] - blobMin) / (blobMax - blobMin)
            val n2 = (ripples[i] - rippleMin) / (rippleMax - rippleMin)
            val band = min(BANDS - 1, (n1 * BANDS).toInt())
            val crest = abs(n2 - 0.5f) < CREST_WIDTH
            var r = PALETTE_R[band]
            var g = PALETTE_G[band]
            var b = PALETTE_B[band]
            if (crest) {
                r = min(255, r + 70)
                g = min(255, g + 62)
                b = min(255, b + 28)
            }
            out[i * 4] = r.toByte()
            out[i * 4 + 1] = g.toByte()
            out[i * 4 + 2] = b.toByte()
            out[i * 4 + 3] = (if (crest) 255 else 0).toByte()
        }
        return out
    }

    /** Smooth 0..1-ish field over the unit tile: warped, three octaves; [salt] picks the field. */
    private fun height(u: Float, v: Float, salt: Int): Float {
        val wu = u + 0.045f * (valueNoise(u, v, 3, salt + 7) - 0.5f)
        val wv = v + 0.045f * (valueNoise(u, v, 3, salt + 8) - 0.5f)
        return 0.50f * valueNoise(wu, wv, 4, salt + 1) +
            0.32f * valueNoise(wu, wv, 8, salt + 2) +
            0.18f * valueNoise(wu, wv, 16, salt + 3)
    }

    /** Value noise over the unit tile with [cells] lattice cells per side: it wraps at the edge. */
    private fun valueNoise(u: Float, v: Float, cells: Int, salt: Int): Float {
        val fx = u * cells
        val fy = v * cells
        val ix = floor(fx).toInt()
        val iy = floor(fy).toInt()
        var tx = fx - ix
        var ty = fy - iy
        tx = tx * tx * tx * (tx * (tx * 6f - 15f) + 10f)
        ty = ty * ty * ty * (ty * (ty * 6f - 15f) + 10f)
        val a = lattice(ix, iy, cells, salt)
        val b = lattice(ix + 1, iy, cells, salt)
        val c = lattice(ix, iy + 1, cells, salt)
        val d = lattice(ix + 1, iy + 1, cells, salt)
        val top = a + (b - a) * tx
        val bottom = c + (d - c) * tx
        return top + (bottom - top) * ty
    }

    private fun lattice(ix: Int, iy: Int, period: Int, salt: Int): Float {
        val x = Math.floorMod(ix, period)
        val y = Math.floorMod(iy, period)
        var h = x * 374761393 + y * 668265263 + salt * 1274126177
        h = (h xor (h ushr 13)) * 1274126177
        h = h xor (h ushr 16)
        return ((h ushr 8) and 0xFFFF) / 65535f
    }

    /** A little anisotropy keeps the ripples from smearing over far-off ocean at grazing
     *  angles; skipped silently where the driver does not offer it. */
    private fun enableAnisotropy() {
        try {
            val extensions = GLES30.glGetString(GLES30.GL_EXTENSIONS) ?: return
            if (!extensions.contains("GL_EXT_texture_filter_anisotropic")) return
            val limit = FloatArray(1)
            GLES30.glGetFloatv(GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT, limit, 0)
            if (limit[0] > 1f) {
                GLES30.glTexParameterf(GLES30.GL_TEXTURE_2D, GL_TEXTURE_MAX_ANISOTROPY_EXT, minOf(ANISOTROPY, limit[0]))
            }
        } catch (t: Throwable) {
            // purely cosmetic; ignore
        }
    }

    private companion object {
        const val SIZE = 128
        const val BANDS = 5
        const val CREST_WIDTH = 0.030f

        // The five blues of the blobs, deep to light.
        val PALETTE_R = intArrayOf(30, 42, 56, 78, 106)
        val PALETTE_G = intArrayOf(72, 98, 122, 148, 172)
        val PALETTE_B = intArrayOf(160, 190, 210, 228, 240)

        const val GL_TEXTURE_MAX_ANISOTROPY_EXT = 0x84FE
        const val GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT = 0x84FF
        const val ANISOTROPY = 2f
    }
}
