package dev.hexmaniac.android.ui

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class HexGeometryTest {
    /** Ten pixels per character makes the arithmetic of the expected widths easy to follow. */
    private fun geometry(
        width: Int,
        showText: Boolean = true,
        rowHeight: Int = 20,
        headerHeight: Int = 20,
        addressDigits: Int = 6,
    ) = HexGeometry(
        width = width,
        charWidth = 10f,
        rowHeight = rowHeight,
        headerHeight = headerHeight,
        addressDigits = addressDigits,
        showText = showText,
        padding = 10f,
        rightReserve = 30f,
    )

    @Test
    fun bytesPerRowGrowsInMultiplesOfFourAsTheViewGetsWider() {
        // With the text column, a row of n bytes needs 50 + 10 * (10 + 3n - 1 + (n / 4 - 1) + n) pixels.
        assertEquals(4, geometry(100).bytesPerRow)
        assertEquals(4, geometry(469).bytesPerRow)
        assertEquals(8, geometry(470).bytesPerRow)
        assertEquals(8, geometry(639).bytesPerRow)
        assertEquals(12, geometry(640).bytesPerRow)
        assertEquals(16, geometry(810).bytesPerRow)
        assertEquals(28, geometry(1489).bytesPerRow)
        assertEquals(32, geometry(1490).bytesPerRow)
        assertEquals(32, geometry(5000).bytesPerRow)
    }

    @Test
    fun hidingTheTextColumnFitsMoreBytes() {
        assertEquals(4, geometry(369, showText = false).bytesPerRow)
        assertEquals(8, geometry(370, showText = false).bytesPerRow)
        assertEquals(4, geometry(370, showText = true).bytesPerRow)
    }

    @Test
    fun rowWidthsAreAlwaysAMultipleOfFour() {
        for (width in 0..3000 step 7) {
            assertEquals(0, geometry(width).bytesPerRow % 4)
            assertEquals(0, geometry(width, showText = false).bytesPerRow % 4)
        }
    }

    @Test
    fun bytesInAGroupAreEvenlySpacedAndGroupsHaveAnExtraGap() {
        val g = geometry(470)
        assertEquals(8, g.bytesPerRow)
        assertEquals(0f, g.gapExtra, 0.001f)
        assertEquals(30f, g.cellLeft(1) - g.cellLeft(0), 0.001f)
        assertEquals(30f, g.cellLeft(3) - g.cellLeft(2), 0.001f)
        assertEquals(40f, g.cellLeft(4) - g.cellLeft(3), 0.001f)
        assertEquals(20f, g.cellWidth, 0.001f)
        assertTrue(g.cellRight(3) < g.cellLeft(4))
        assertEquals(g.cellRight(g.bytesPerRow - 1), g.hexRight, 0.001f)
        assertEquals(10f, g.addressX, 0.001f)
        assertEquals(10f + 8 * 10f, g.hexX, 0.001f)
    }

    @Test
    fun leftoverWidthIsSpreadOverTheGapsAndTheMargins() {
        // 560 px for a row that needs 470: 90 px spare. Three gaps (address, between the groups, before the text)
        // grow by one character each; the remaining 60 px are split between the left and right margins.
        val g = geometry(560)
        assertEquals(8, g.bytesPerRow)
        assertEquals(10f, g.gapExtra, 0.001f)
        assertEquals(40f, g.addressX, 0.001f)
        assertEquals(130f, g.hexX, 0.001f)
        assertEquals(50f, g.cellLeft(4) - g.cellLeft(3), 0.001f)
        assertEquals(30f, g.textX - g.hexRight, 0.001f)
        val rightMargin = 560f - 30f - g.textRight
        assertEquals(g.addressX, rightMargin, 0.001f)
    }

    @Test
    fun smallLeftoverIsSharedBetweenTheGaps() {
        val g = geometry(500)
        assertEquals(10f, g.gapExtra, 0.001f)
        assertEquals(10f, g.addressX, 0.001f)
        val tiny = geometry(473)
        assertEquals(1f, tiny.gapExtra, 0.001f)
    }

    @Test
    fun dividersSitInTheMiddleOfTheirGaps() {
        val g = geometry(560)
        val addressGapLeft = g.addressX + 6 * 10f
        assertEquals((addressGapLeft + g.hexX) / 2, g.addressDividerX, 0.001f)
        assertEquals((g.hexRight + g.textX) / 2, g.textDividerX, 0.001f)
    }

    @Test
    fun textColumnComesAfterTheBytes() {
        val g = geometry(5000)
        assertTrue(g.textX > g.hexRight)
        assertEquals(g.textX + g.bytesPerRow * 10f, g.textRight, 0.001f)
        assertEquals(10f, g.textLeft(1) - g.textLeft(0), 0.001f)
    }

    @Test
    fun touchesMapBackToTheColumnTheyHit() {
        val g = geometry(5000)
        for (column in 0 until g.bytesPerRow) {
            assertEquals(column, g.columnAt(g.cellLeft(column) + g.cellWidth / 2))
            assertEquals(column, g.columnAt(g.textLeft(column) + 5f))
        }
    }

    @Test
    fun touchesBetweenGroupsGoToTheNearerByte() {
        val g = geometry(5000)
        assertEquals(3, g.columnAt(g.cellRight(3) + 1f))
        assertEquals(4, g.columnAt(g.cellLeft(4) - 1f))
    }

    @Test
    fun touchesOutsideTheColumnsStillHitAByte() {
        val g = geometry(5000)
        assertEquals(0, g.columnAt(0f))
        assertEquals(g.bytesPerRow - 1, g.columnAt(100000f))
        val plain = geometry(5000, showText = false)
        assertEquals(plain.bytesPerRow - 1, plain.columnAt(100000f))
    }

    @Test
    fun totalRowsRoundUp() {
        val g = geometry(470)
        assertEquals(8, g.bytesPerRow)
        assertEquals(0, g.totalRows(0))
        assertEquals(1, g.totalRows(1))
        assertEquals(1, g.totalRows(8))
        assertEquals(2, g.totalRows(9))
        assertEquals(4194304, g.totalRows(32 * 1024 * 1024))
    }

    @Test
    fun scrollingStopsWhenTheLastRowReachesTheBottom() {
        val g = geometry(470)
        // 100 bytes = 13 rows of 20 px = 260 px; a view of 120 px shows 100 px of rows below the 20 px header.
        assertEquals(160, g.maxScroll(100, 120))
        assertEquals(0, g.maxScroll(100, 1000))
        assertEquals(0, g.maxScroll(0, 120))
    }

    @Test
    fun hugeFilesDoNotOverflowTheScrollRange() {
        val g = geometry(100, rowHeight = 400)
        assertEquals(4, g.bytesPerRow)
        val size = 32 * 1024 * 1024
        assertEquals(8388608L * 400, g.contentHeight(size))
        assertEquals(Int.MAX_VALUE, g.maxScroll(size, 1000))
    }

    @Test
    fun rowsAreFoundByTheirPositionBelowTheHeader() {
        val g = geometry(470)
        assertEquals(-1, g.rowAt(5f, 0, 100))
        assertEquals(0, g.rowAt(20f, 0, 100))
        assertEquals(0, g.rowAt(39f, 0, 100))
        assertEquals(1, g.rowAt(40f, 0, 100))
        assertEquals(3, g.rowAt(20f, 60, 100))
        assertEquals(-1, g.rowAt(20f + 13 * 20, 0, 100))
    }

    @Test
    fun visibleRowsFollowTheScrollOffset() {
        val g = geometry(470)
        assertEquals(0, g.firstVisibleRow(0))
        assertEquals(3, g.firstVisibleRow(70))
        assertEquals(3, g.lastVisibleRow(0, 20 + 70, 1000))
        assertEquals(12, g.lastVisibleRow(0, 100000, 100))
    }

    @Test
    fun rowPositionsAndScrollOffsetsAgree() {
        val g = geometry(470)
        assertEquals(20, g.rowTop(0, 0))
        assertEquals(60, g.rowTop(2, 0))
        assertEquals(0, g.rowTop(1, 40))
        for (row in listOf(0, 1, 7, 100)) assertEquals(g.headerHeight, g.rowTop(row, g.scrollForRow(row)))
    }

    @Test
    fun offsetsCombineRowAndColumn() {
        val g = geometry(470)
        assertEquals(0, g.offsetOf(0, 0))
        assertEquals(8 * 5 + 3, g.offsetOf(5, 3))
    }
}
