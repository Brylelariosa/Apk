package dev.hexmaniac.android.io

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.io.OutputStream

/** Reading and writing ROM files through the Storage Access Framework. Blocking: call off the UI thread. */
object RomFiles {
    /** GBA ROMs are at most 32 MB; anything much bigger is not a ROM. */
    private const val MAX_BYTES = 64L * 1024 * 1024

    private const val TOO_LARGE = "This file is too large to be a GBA ROM."

    /** The file's display name, falling back to the last path segment. */
    fun displayName(resolver: ContentResolver, uri: Uri): String {
        try {
            resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (index >= 0) {
                        val name = cursor.getString(index)
                        if (name != null) return name
                    }
                }
            }
        } catch (e: Exception) {
            // fall through to the default name
        }
        return uri.lastPathSegment ?: "rom.gba"
    }

    private fun querySize(resolver: ContentResolver, uri: Uri): Long {
        try {
            resolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val index = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (index >= 0 && !cursor.isNull(index)) return cursor.getLong(index)
                }
            }
        } catch (e: Exception) {
            // unknown size
        }
        return -1L
    }

    /** Reads the whole file. */
    fun read(resolver: ContentResolver, uri: Uri): ByteArray {
        val stream = resolver.openInputStream(uri) ?: throw IOException("Cannot open the file.")
        val size = querySize(resolver, uri)
        if (size > MAX_BYTES) throw IOException(TOO_LARGE)
        return stream.use { input ->
            if (size > 0) {
                val data = ByteArray(size.toInt())
                var filled = 0
                while (filled < data.size) {
                    val n = input.read(data, filled, data.size - filled)
                    if (n < 0) break
                    filled += n
                }
                if (filled == data.size) data else data.copyOf(filled)
            } else {
                val out = ByteArrayOutputStream()
                val buffer = ByteArray(1 shl 16)
                var total = 0L
                while (true) {
                    val n = input.read(buffer)
                    if (n < 0) break
                    total += n
                    if (total > MAX_BYTES) throw IOException(TOO_LARGE)
                    out.write(buffer, 0, n)
                }
                out.toByteArray()
            }
        }
    }

    /** Replaces the content of the file with [data]. */
    fun write(resolver: ContentResolver, uri: Uri, data: ByteArray) {
        var stream: OutputStream? = null
        try {
            stream = resolver.openOutputStream(uri, "wt")
        } catch (e: Exception) {
            stream = null
        }
        if (stream == null) stream = resolver.openOutputStream(uri, "w")
        val out = stream ?: throw IOException("Cannot open the file for writing.")
        out.use {
            it.write(data)
            it.flush()
        }
    }
}

/** Keeps the last few opened ROMs in app-private storage as a safety net against bad saves. */
object Backups {
    private const val KEEP = 3

    fun save(context: Context, name: String, data: ByteArray) {
        try {
            val dir = File(context.filesDir, "backups")
            dir.mkdirs()
            val safe = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
            File(dir, "${System.currentTimeMillis()}-$safe").outputStream().use { it.write(data) }
            val files = dir.listFiles() ?: return
            val sorted = files.sortedBy { it.lastModified() }
            for (i in 0 until sorted.size - KEEP) sorted[i].delete()
        } catch (e: Exception) {
            // best effort only
        }
    }
}
