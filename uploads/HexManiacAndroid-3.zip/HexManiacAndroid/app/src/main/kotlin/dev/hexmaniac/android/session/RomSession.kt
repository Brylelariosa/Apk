package dev.hexmaniac.android.session

import android.net.Uri
import dev.hexmaniac.core.rom.BytePattern
import dev.hexmaniac.core.rom.OffsetHistory
import dev.hexmaniac.core.rom.RomDocument

/**
 * Everything about the ROM that is open: the document being edited, the file it came from and the user's
 * navigation state (where "back" leads, what "find next" looks for). It lives as long as the ROM is open.
 */
class RomSession(val document: RomDocument, var uri: Uri, var name: String) {
    /** Places the user jumped away from. */
    val history = OffsetHistory()

    /** The most recent search, repeated by "find next". */
    var lastSearch: BytePattern? = null
}
