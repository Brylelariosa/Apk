package dev.hexmaniac.android.ui

import android.content.Context
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import dev.hexmaniac.android.R

/**
 * A row of equal-width text actions along the bottom edge. [add] appends an action and returns the index that
 * [setActionEnabled] takes; a disabled action is drawn dim and ignores taps.
 */
class ActionRow(context: Context) : LinearLayout(context) {
    private val row = LinearLayout(context)
    private val actions = ArrayList<TextView>()

    init {
        orientation = VERTICAL
        setBackgroundColor(context.getColor(R.color.surface))
        addDivider()
        row.orientation = HORIZONTAL
        addView(row, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    /** Adds an action labelled with the string resource [label]; returns its index. */
    fun add(label: Int, onClick: () -> Unit): Int {
        val view = TextView(context)
        view.setText(label)
        view.textSize = 13.5f
        view.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        view.setTextColor(context.getColorStateList(R.color.action_text))
        view.gravity = Gravity.CENTER
        view.minHeight = context.dp(52)
        view.setBackgroundResource(R.drawable.bg_action)
        view.setOnClickListener { onClick() }
        row.addView(view, LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        actions.add(view)
        return actions.size - 1
    }

    fun setActionEnabled(index: Int, enabled: Boolean) {
        actions[index].isEnabled = enabled
    }
}
