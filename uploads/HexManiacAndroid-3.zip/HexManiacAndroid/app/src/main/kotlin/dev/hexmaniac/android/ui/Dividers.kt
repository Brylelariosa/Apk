package dev.hexmaniac.android.ui

import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import dev.hexmaniac.android.R

/** Appends a thin horizontal rule in the divider color to a vertical layout. */
fun LinearLayout.addDivider() {
    val line = View(context)
    line.setBackgroundColor(context.getColor(R.color.divider))
    addView(line, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, context.dp(1)))
}
