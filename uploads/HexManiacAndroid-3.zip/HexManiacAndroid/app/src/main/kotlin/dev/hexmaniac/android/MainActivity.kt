package dev.hexmaniac.android

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import dev.hexmaniac.android.io.Backups
import dev.hexmaniac.android.io.RomFiles
import dev.hexmaniac.android.session.RomSession
import dev.hexmaniac.android.ui.ActionRow
import dev.hexmaniac.android.ui.BusyRunner
import dev.hexmaniac.android.ui.EmptyState
import dev.hexmaniac.android.ui.HexView
import dev.hexmaniac.android.ui.InfoPanel
import dev.hexmaniac.android.ui.ViewSettings
import dev.hexmaniac.android.ui.choose
import dev.hexmaniac.android.ui.confirm
import dev.hexmaniac.android.ui.promptText
import dev.hexmaniac.android.ui.showMessage
import dev.hexmaniac.android.ui.toast
import dev.hexmaniac.core.io.ClasspathResources
import dev.hexmaniac.core.patch.PatchFormat
import dev.hexmaniac.core.patch.Patches
import dev.hexmaniac.core.rom.BytePattern
import dev.hexmaniac.core.rom.HexText
import dev.hexmaniac.core.rom.RomDocument
import dev.hexmaniac.core.rom.RomInfo
import dev.hexmaniac.core.rom.RomSearch
import dev.hexmaniac.core.rom.SearchQuery
import dev.hexmaniac.core.text.PcsTable

/**
 * The single screen of the app: an info panel, the hex dump and a row of selection actions, with file, search and
 * patch commands in the action bar menu. This class wires the pieces together and owns the file pickers; all ROM
 * logic is in the `core` module and all drawing is in the `ui` package.
 */
class MainActivity : Activity() {

    private lateinit var settings: ViewSettings
    private lateinit var busy: BusyRunner
    private lateinit var hexView: HexView
    private lateinit var infoPanel: InfoPanel
    private lateinit var actionRow: ActionRow
    private lateinit var emptyState: EmptyState
    private var shrinkAction = 0
    private var followAction = 0
    private var backAction = 0

    private val pcs: PcsTable by lazy { loadPcs() }
    private var session: RomSession? = null
    private var pendingPatch: ByteArray? = null
    private var pendingPatchFormat = PatchFormat.Ips

    private val documentListener = RomDocument.Listener { onDocumentChanged() }

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = ViewSettings(this)
        busy = BusyRunner(this) { showError(it) }
        setContentView(buildContent())
        refreshUi()
    }

    override fun onPause() {
        settings.textSizeSp = hexView.textSizeSp
        settings.showText = hexView.showText
        super.onPause()
    }

    override fun onDestroy() {
        busy.dismiss()
        super.onDestroy()
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        val current = session
        if (current != null && current.document.isDirty) {
            AlertDialog.Builder(this)
                .setTitle(R.string.dialog_unsaved_title)
                .setMessage(R.string.dialog_leave_message)
                .setPositiveButton(R.string.dialog_save_exit) { _, _ -> save(thenFinish = true) }
                .setNegativeButton(R.string.dialog_discard) { _, _ -> finish() }
                .setNeutralButton(android.R.string.cancel, null)
                .show()
        } else {
            super.onBackPressed()
        }
    }

    private fun buildContent(): View {
        hexView = HexView(this)
        hexView.pcs = pcs
        hexView.textSizeSp = settings.textSizeSp
        hexView.showText = settings.showText
        hexView.onSelectionChanged = { updateSelectionUi() }
        hexView.onEditRequested = { editSelection() }
        hexView.onFollowRequested = { followPointer() }

        infoPanel = InfoPanel(this)
        emptyState = EmptyState(this) { openRom() }

        actionRow = ActionRow(this)
        shrinkAction = actionRow.add(R.string.bar_shrink) { hexView.resizeSelection(-1) }
        actionRow.add(R.string.bar_grow) { hexView.resizeSelection(1) }
        actionRow.add(R.string.bar_word) { hexView.selectWord() }
        actionRow.add(R.string.bar_edit) { editSelection() }
        followAction = actionRow.add(R.string.bar_follow) { followPointer() }
        backAction = actionRow.add(R.string.bar_back) { goBack() }

        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
        val content = FrameLayout(this)
        content.addView(hexView, FrameLayout.LayoutParams(match, match))
        content.addView(emptyState, FrameLayout.LayoutParams(match, match))

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(getColor(R.color.bg))
        root.addView(infoPanel, LinearLayout.LayoutParams(match, wrap))
        root.addView(content, LinearLayout.LayoutParams(match, 0, 1f))
        root.addView(actionRow, LinearLayout.LayoutParams(match, wrap))
        return root
    }

    private fun loadPcs(): PcsTable = try {
        PcsTable.load(ClasspathResources())
    } catch (e: Throwable) {
        PcsTable.DEFAULT
    }

    // ------------------------------------------------------------------ screen state

    /** Brings every part of the screen in line with the open ROM (or the lack of one). */
    private fun refreshUi() {
        val current = session
        val open = current != null
        hexView.visibility = if (open) View.VISIBLE else View.GONE
        infoPanel.visibility = if (open) View.VISIBLE else View.GONE
        actionRow.visibility = if (open) View.VISIBLE else View.GONE
        emptyState.visibility = if (open) View.GONE else View.VISIBLE

        actionBar?.title = current?.name ?: getString(R.string.app_name)
        actionBar?.subtitle = current?.let { subtitleFor(it) }
        updateSelectionUi()
        invalidateOptionsMenu()
    }

    private fun subtitleFor(current: RomSession): String {
        val game = RomInfo.gameLabel(current.document) ?: getString(R.string.unknown_game)
        return if (current.document.isDirty) getString(R.string.subtitle_modified, game) else game
    }

    /** The parts of the screen that depend on the selection: the info panel and the enabled actions. */
    private fun updateSelectionUi() {
        val current = session
        if (current == null) {
            infoPanel.show(null)
            return
        }
        val start = hexView.selStart
        infoPanel.show(RomInfo.cursorSummary(current.document, start, pcs))
        actionRow.setActionEnabled(shrinkAction, hexView.selLength > 1)
        actionRow.setActionEnabled(followAction, current.document.rom.pointerNear(start) >= 0)
        actionRow.setActionEnabled(backAction, !current.history.isEmpty)
    }

    private fun onDocumentChanged() {
        hexView.refresh()
        val current = session
        actionBar?.subtitle = current?.let { subtitleFor(it) }
        updateSelectionUi()
        invalidateOptionsMenu()
    }

    // ------------------------------------------------------------------ menu

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main, menu)
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        val current = session
        val document = current?.document
        val open = document != null
        val needsRom = intArrayOf(
            R.id.action_goto, R.id.action_find, R.id.action_save_as,
            R.id.action_apply_patch, R.id.action_create_patch, R.id.action_rom_info,
        )
        for (id in needsRom) menu.findItem(id)?.isEnabled = open
        menu.findItem(R.id.action_save)?.isEnabled = document?.isDirty == true
        menu.findItem(R.id.action_find_next)?.isEnabled = current?.lastSearch != null

        val undo = menu.findItem(R.id.action_undo)
        undo?.isEnabled = document?.canUndo == true
        val undoLabel = document?.undoLabel
        undo?.title = if (undoLabel != null) getString(R.string.action_undo_with_label, undoLabel) else getString(R.string.action_undo)

        val redo = menu.findItem(R.id.action_redo)
        redo?.isEnabled = document?.canRedo == true
        val redoLabel = document?.redoLabel
        redo?.title = if (redoLabel != null) getString(R.string.action_redo_with_label, redoLabel) else getString(R.string.action_redo)

        menu.findItem(R.id.action_text_column)?.isChecked = hexView.showText
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_open -> openRom()
            R.id.action_save -> save(thenFinish = false)
            R.id.action_save_as -> saveAs()
            R.id.action_undo -> session?.document?.undo()
            R.id.action_redo -> session?.document?.redo()
            R.id.action_goto -> promptGoto()
            R.id.action_find -> promptFind()
            R.id.action_find_next -> findNext()
            R.id.action_apply_patch -> pickFile(REQ_OPEN_PATCH)
            R.id.action_create_patch -> startCreatePatch()
            R.id.action_rom_info -> showInfo()
            R.id.action_text_column -> {
                hexView.showText = !hexView.showText
                item.isChecked = hexView.showText
            }
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }

    // ------------------------------------------------------------------ file picking

    private fun pickFile(requestCode: Int) {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT)
        intent.addCategory(Intent.CATEGORY_OPENABLE)
        intent.type = "*/*"
        intent.addFlags(
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION,
        )
        startActivityForResult(intent, requestCode)
    }

    private fun createFile(requestCode: Int, suggestedName: String) {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT)
        intent.addCategory(Intent.CATEGORY_OPENABLE)
        intent.type = "application/octet-stream"
        intent.putExtra(Intent.EXTRA_TITLE, suggestedName)
        startActivityForResult(intent, requestCode)
    }

    private fun openRom() {
        val current = session
        if (current != null && current.document.isDirty) {
            confirm(
                getString(R.string.dialog_unsaved_title),
                getString(R.string.dialog_open_discard_message, current.name),
                getString(R.string.dialog_discard),
            ) { pickFile(REQ_OPEN_ROM) }
        } else {
            pickFile(REQ_OPEN_ROM)
        }
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        val uri = data.data ?: return
        when (requestCode) {
            REQ_OPEN_ROM -> {
                try {
                    val keep = data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                    contentResolver.takePersistableUriPermission(uri, keep)
                } catch (e: Exception) {
                    // the grant stays valid for this run even if it cannot be made permanent
                }
                loadRom(uri)
            }
            REQ_SAVE_AS -> saveTo(uri, makeCurrent = true, thenFinish = false)
            REQ_OPEN_PATCH -> applyPatchFrom(uri)
            REQ_PICK_ORIGINAL -> buildPatchAgainst(uri)
            REQ_CREATE_PATCH -> writePendingPatch(uri)
        }
    }

    // ------------------------------------------------------------------ open and save

    private fun loadRom(uri: Uri) {
        busy.run(getString(R.string.busy_opening), {
            val bytes = RomFiles.read(contentResolver, uri)
            val name = RomFiles.displayName(contentResolver, uri)
            Backups.save(this, name, bytes)
            RomSession(RomDocument(name, bytes), uri, name)
        }) { opened ->
            session?.document?.removeListener(documentListener)
            session = opened
            opened.document.addListener(documentListener)
            hexView.document = opened.document
            refreshUi()
            hexView.goTo(0)
        }
    }

    private fun save(thenFinish: Boolean) {
        val current = session ?: return
        saveTo(current.uri, makeCurrent = false, thenFinish = thenFinish)
    }

    private fun saveAs() {
        val current = session ?: return
        createFile(REQ_SAVE_AS, current.name.ifEmpty { "rom.gba" })
    }

    private fun saveTo(uri: Uri, makeCurrent: Boolean, thenFinish: Boolean) {
        val current = session ?: return
        val bytes = current.document.rom.bytes
        busy.run(getString(R.string.busy_saving), {
            RomFiles.write(contentResolver, uri, bytes)
            if (makeCurrent) RomFiles.displayName(contentResolver, uri) else null
        }) { newName ->
            if (makeCurrent) {
                current.uri = uri
                if (newName != null) current.name = newName
            }
            current.document.markSaved()
            actionBar?.title = current.name
            toast(R.string.toast_saved)
            if (thenFinish) finish()
        }
    }

    // ------------------------------------------------------------------ navigation and editing

    private fun promptGoto() {
        val current = session ?: return
        val size = current.document.rom.size
        promptText(
            title = getString(R.string.goto_title),
            message = getString(R.string.goto_message),
            initial = HexText.hex(hexView.selStart, 6),
            hint = getString(R.string.goto_hint),
            uppercase = true,
        ) { text ->
            val address = HexText.parseAddress(text)
            if (address == null || address >= size) toast(R.string.toast_invalid_offset, size) else jumpTo(address)
        }
    }

    /** Moves the cursor to [offset], remembering where it was so "back" can return. */
    private fun jumpTo(offset: Int) {
        val current = session ?: return
        current.history.push(hexView.selStart)
        hexView.goTo(offset)
    }

    private fun goBack() {
        val current = session ?: return
        val offset = current.history.pop()
        if (offset == null) toast(R.string.toast_nothing_back) else hexView.goTo(offset)
    }

    private fun followPointer() {
        val current = session ?: return
        val target = current.document.rom.pointerNear(hexView.selStart)
        if (target < 0) toast(R.string.toast_no_pointer) else jumpTo(target)
    }

    private fun editSelection() {
        val current = session ?: return
        val document = current.document
        val start = hexView.selStart
        promptText(
            title = getString(R.string.edit_title, HexText.hex(start, 6)),
            message = getString(R.string.edit_message),
            initial = HexText.format(document.rom.bytes, start, hexView.selLength),
            hint = getString(R.string.edit_hint),
            uppercase = true,
        ) { text ->
            val bytes = HexText.parseBytes(text)
            when {
                bytes == null -> toast(R.string.toast_enter_hex)
                start + bytes.size > document.rom.size -> toast(R.string.toast_past_end)
                else -> {
                    document.write(start, bytes, getString(R.string.undo_label_edit, HexText.hex(start, 6)))
                    hexView.select(start, bytes.size)
                }
            }
        }
    }

    // ------------------------------------------------------------------ search

    private fun promptFind() {
        val current = session ?: return
        promptText(
            title = getString(R.string.find_title),
            message = getString(R.string.find_message),
            initial = "",
            hint = getString(R.string.find_hint),
        ) { text ->
            val gameCode = current.document.header.game?.full ?: ""
            val pattern = SearchQuery.parse(text, pcs, gameCode)
            if (pattern == null) {
                toast(R.string.toast_bad_query)
            } else {
                current.lastSearch = pattern
                invalidateOptionsMenu()
                search(pattern, hexView.selStart)
            }
        }
    }

    private fun findNext() {
        val pattern = session?.lastSearch ?: return
        search(pattern, hexView.selStart + 1)
    }

    private fun search(pattern: BytePattern, from: Int) {
        val current = session ?: return
        val bytes = current.document.rom.bytes
        busy.run(getString(R.string.busy_searching), { RomSearch.findWrapping(bytes, pattern, from) }) { hit ->
            if (hit < 0) {
                toast(R.string.toast_not_found)
            } else {
                current.history.push(hexView.selStart)
                hexView.goTo(hit, pattern.length)
            }
        }
    }

    // ------------------------------------------------------------------ patches

    private fun applyPatchFrom(uri: Uri) {
        val current = session ?: return
        val rom = current.document.rom.bytes
        busy.run(getString(R.string.busy_applying_patch), {
            Patches.apply(rom, RomFiles.read(contentResolver, uri))
        }) { outcome ->
            current.document.replaceAll(outcome.data, getString(R.string.undo_label_patch))
            toast(outcome.message)
        }
    }

    private fun startCreatePatch() {
        if (session == null) return
        val formats = arrayOf(getString(R.string.patch_format_ips), getString(R.string.patch_format_ups))
        choose(getString(R.string.patch_create_title), formats) { index ->
            pendingPatchFormat = if (index == 0) PatchFormat.Ips else PatchFormat.Ups
            confirm(
                getString(R.string.patch_original_title),
                getString(R.string.patch_original_message),
                getString(R.string.patch_pick_file),
            ) { pickFile(REQ_PICK_ORIGINAL) }
        }
    }

    private fun buildPatchAgainst(uri: Uri) {
        val current = session ?: return
        val edited = current.document.rom.bytes
        val format = pendingPatchFormat
        busy.run(getString(R.string.busy_building_patch), {
            Patches.build(format, RomFiles.read(contentResolver, uri), edited)
        }) { patch ->
            pendingPatch = patch
            val base = current.name.substringBeforeLast('.', current.name).ifEmpty { "rom" }
            createFile(REQ_CREATE_PATCH, "$base.${format.extension}")
        }
    }

    private fun writePendingPatch(uri: Uri) {
        val patch = pendingPatch ?: return
        busy.run(getString(R.string.busy_saving_patch), { RomFiles.write(contentResolver, uri, patch) }) {
            pendingPatch = null
            toast(R.string.toast_patch_saved)
        }
    }

    // ------------------------------------------------------------------ messages

    private fun showInfo() {
        val current = session ?: return
        showMessage(getString(R.string.info_title), RomInfo.details(current.document, current.name))
    }

    private fun showError(error: Throwable) {
        val text = when (error) {
            is OutOfMemoryError -> getString(R.string.error_out_of_memory)
            else -> error.message ?: error.javaClass.simpleName
        }
        showMessage(getString(R.string.dialog_error_title), text)
    }

    private companion object {
        const val REQ_OPEN_ROM = 1
        const val REQ_SAVE_AS = 2
        const val REQ_OPEN_PATCH = 3
        const val REQ_PICK_ORIGINAL = 4
        const val REQ_CREATE_PATCH = 5
    }
}
