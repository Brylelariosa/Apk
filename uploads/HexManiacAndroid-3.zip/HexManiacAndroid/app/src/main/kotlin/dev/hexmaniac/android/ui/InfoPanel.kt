package dev.hexmaniac.android.ui

import android.content.Context
import android.graphics.Typeface
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextUtils
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import dev.hexmaniac.android.R
import dev.hexmaniac.core.rom.CursorSummary

/**
 * Two lines under the action bar that describe the byte under the cursor: its address and value as 8, 16 and 32
 * bits on the first line, the pointer it starts (if any) and a preview of the bytes read as game text on the second.
 */
class InfoPanel(context: Context) : LinearLayout(context) {
    private val valuesLine = newLine(context)
    private val detailLine = newLine(context)

    private val accent = context.getColor(R.color.accent)
    private val label = context.getColor(R.color.text_dim)
    private val value = context.getColor(R.color.text_primary)
    private val secondary = context.getColor(R.color.text_secondary)
    private val pointer = context.getColor(R.color.hex_pointer)
    private val pointerLabel = context.getString(R.string.info_pointer)

    init {
        orientation = VERTICAL
        setBackgroundColor(context.getColor(R.color.surface))

        val lines = LinearLayout(context)
        lines.orientation = VERTICAL
        lines.setPadding(context.dp(16), context.dp(8), context.dp(16), context.dp(8))
        lines.addView(valuesLine, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        lines.addView(detailLine, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        addView(lines, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        addDivider()
    }

    /** Shows [summary], or empty lines when it is null. */
    fun show(summary: CursorSummary?) {
        if (summary == null) {
            valuesLine.text = ""
            detailLine.text = ""
            return
        }
        valuesLine.text = SpannableStringBuilder()
            .appendSpan(summary.address, accent, bold = true)
            .appendSpan("   u8 ", label)
            .appendSpan(summary.u8, value)
            .appendSpan("   u16 ", label)
            .appendSpan(summary.u16, value)
            .appendSpan("   u32 ", label)
            .appendSpan(summary.u32, value)
        val detail = SpannableStringBuilder()
        val target = summary.pointerTarget
        if (target != null) {
            detail.appendSpan("$pointerLabel ", label).appendSpan(target, pointer, bold = true)
            if (summary.text.isNotEmpty()) detail.appendSpan("   ", label)
        }
        detailLine.text = detail.appendSpan(summary.text, secondary)
    }

    private fun SpannableStringBuilder.appendSpan(text: CharSequence, color: Int, bold: Boolean = false): SpannableStringBuilder {
        val start = length
        append(text)
        setSpan(ForegroundColorSpan(color), start, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        if (bold) setSpan(StyleSpan(Typeface.BOLD), start, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        return this
    }

    private companion object {
        fun newLine(context: Context): TextView {
            val view = TextView(context)
            view.typeface = Typeface.MONOSPACE
            view.textSize = 12.5f
            view.setTextColor(context.getColor(R.color.text_secondary))
            view.minLines = 1
            view.maxLines = 1
            view.ellipsize = TextUtils.TruncateAt.END
            return view
        }
    }
}
