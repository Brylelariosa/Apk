package dev.hexmaniac.android.ui

import android.content.Context
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import dev.hexmaniac.android.R

/** What the screen shows while no ROM is open: the logo, a short explanation and the one button that matters. */
class EmptyState(context: Context, onOpen: () -> Unit) : LinearLayout(context) {
    init {
        orientation = VERTICAL
        gravity = Gravity.CENTER
        setPadding(context.dp(32), context.dp(24), context.dp(32), context.dp(24))

        val logo = ImageView(context)
        logo.setImageResource(R.drawable.ic_logo)
        addCentered(logo, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, bottomMargin = 20)

        val title = TextView(context)
        title.setText(R.string.empty_title)
        title.textSize = 20f
        title.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        title.setTextColor(context.getColor(R.color.text_primary))
        title.gravity = Gravity.CENTER
        addCentered(title, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, bottomMargin = 8)

        val message = TextView(context)
        message.setText(R.string.empty_message)
        message.textSize = 14f
        message.setTextColor(context.getColor(R.color.text_secondary))
        message.gravity = Gravity.CENTER
        message.setLineSpacing(0f, 1.15f)
        addCentered(message, context.dp(280), ViewGroup.LayoutParams.WRAP_CONTENT, bottomMargin = 28)

        val open = Button(context)
        open.setText(R.string.empty_open)
        open.isAllCaps = false
        open.textSize = 15f
        open.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        open.setTextColor(context.getColor(R.color.on_accent))
        open.setBackgroundResource(R.drawable.bg_button_primary)
        open.stateListAnimator = null
        open.minWidth = context.dp(168)
        open.minHeight = context.dp(48)
        open.setPadding(context.dp(28), 0, context.dp(28), 0)
        open.setOnClickListener { onOpen() }
        addCentered(open, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, bottomMargin = 28)

        val hint = TextView(context)
        hint.setText(R.string.empty_hint)
        hint.textSize = 12f
        hint.setTextColor(context.getColor(R.color.text_dim))
        hint.gravity = Gravity.CENTER
        addCentered(hint, context.dp(280), ViewGroup.LayoutParams.WRAP_CONTENT, bottomMargin = 0)
    }

    private fun addCentered(view: View, width: Int, height: Int, bottomMargin: Int) {
        val params = LayoutParams(width, height)
        params.gravity = Gravity.CENTER_HORIZONTAL
        params.bottomMargin = context.dp(bottomMargin)
        addView(view, params)
    }
}
