package dev.hexmaniac.android.ui

import android.content.Context

/** The few view options that are remembered between runs: the zoom level and whether the text column shows. */
class ViewSettings(context: Context) {
    private val prefs = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    var textSizeSp: Float
        get() = prefs.getFloat(KEY_TEXT_SIZE, HexView.DEFAULT_TEXT_SP)
        set(value) {
            prefs.edit().putFloat(KEY_TEXT_SIZE, value).apply()
        }

    var showText: Boolean
        get() = prefs.getBoolean(KEY_SHOW_TEXT, true)
        set(value) {
            prefs.edit().putBoolean(KEY_SHOW_TEXT, value).apply()
        }

    private companion object {
        const val FILE = "view"
        const val KEY_TEXT_SIZE = "text_size_sp"
        const val KEY_SHOW_TEXT = "show_text"
    }
}
