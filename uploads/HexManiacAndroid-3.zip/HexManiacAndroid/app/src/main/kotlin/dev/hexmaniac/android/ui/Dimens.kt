package dev.hexmaniac.android.ui

import android.content.Context
import android.util.TypedValue

/** Density-independent pixels to whole pixels. */
fun Context.dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

/** Density-independent pixels to fractional pixels. */
fun Context.dpF(value: Float): Float = value * resources.displayMetrics.density

/** Scaled pixels (text sizes that follow the user's font setting) to pixels. */
fun Context.spF(value: Float): Float =
    TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, value, resources.displayMetrics)
