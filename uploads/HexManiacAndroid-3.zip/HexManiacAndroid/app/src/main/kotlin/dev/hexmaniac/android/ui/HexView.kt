package dev.hexmaniac.android.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.view.GestureDetector
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.widget.OverScroller
import dev.hexmaniac.core.rom.HexText
import dev.hexmaniac.core.rom.RomDocument
import dev.hexmaniac.core.text.PcsTable
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min

/**
 * A scrollable hex dump of a [RomDocument]: an address column, the bytes in groups of four (pointers tinted,
 * 00 and FF dimmed) and an optional text column in the game's character set. A header row with the column numbers
 * stays at the top. Where things sit is worked out by [HexGeometry]; this class draws and handles touch.
 *
 * Gestures: drag or fling to scroll, drag the right edge to jump through the file (the thumb shows the address),
 * pinch to zoom, tap to select a byte, double-tap to follow a pointer, long-press to edit.
 * The view never changes the document; it reports what the user asked for and the activity acts on it.
 */
class HexView(context: Context) : View(context) {

    /** The ROM being shown; setting it resets the selection and the scroll position. */
    var document: RomDocument? = null
        set(value) {
            field = value
            selStart = 0
            selLength = 1
            scrollPx = 0
            geometryDirty = true
            scroller.forceFinished(true)
            invalidate()
        }

    /** Character set of the text column. */
    var pcs: PcsTable = PcsTable.DEFAULT
        set(value) {
            field = value
            columnChars = Array(256) { value.columnChar(it) }
            invalidate()
        }

    var showText: Boolean = true
        set(value) {
            field = value
            geometryDirty = true
            invalidate()
        }

    /** Text size in sp; pinch zoom changes it. */
    var textSizeSp: Float = DEFAULT_TEXT_SP
        set(value) {
            field = value.coerceIn(MIN_TEXT_SP, MAX_TEXT_SP)
            geometryDirty = true
            invalidate()
        }

    /** First selected byte. */
    var selStart: Int = 0
        private set

    /** Number of selected bytes (at least 1). */
    var selLength: Int = 1
        private set

    var onSelectionChanged: (() -> Unit)? = null
    var onEditRequested: (() -> Unit)? = null
    var onFollowRequested: (() -> Unit)? = null

    private val palette = HexPalette(context)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shapePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val scroller = OverScroller(context)
    private var columnChars: Array<String?> = Array(256) { PcsTable.DEFAULT.columnChar(it) }
    private val digits = "0123456789ABCDEF".toCharArray()
    private val pair = CharArray(2)

    private var geometry: HexGeometry? = null
    private var geometryWidth = -1
    private var geometryDirty = true
    private var baseline = 0f
    private var scrollPx = 0
    private var fastScrolling = false

    /** A selection was made before the view had a size; scroll to it as soon as it has one. */
    private var revealWhenMeasured = false

    private val gestures = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean {
            scroller.forceFinished(true)
            return true
        }

        override fun onScroll(e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float): Boolean {
            scrollPx += distanceY.toInt()
            clampScroll()
            invalidate()
            return true
        }

        override fun onFling(e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float): Boolean {
            scroller.fling(0, scrollPx, 0, (-velocityY).toInt(), 0, 0, 0, maxScroll())
            postInvalidateOnAnimation()
            return true
        }

        override fun onSingleTapUp(e: MotionEvent): Boolean {
            val offset = offsetAt(e.x, e.y)
            if (offset >= 0) select(offset, 1)
            return true
        }

        override fun onDoubleTap(e: MotionEvent): Boolean {
            if (selectUnder(e)) onFollowRequested?.invoke()
            return true
        }

        override fun onLongPress(e: MotionEvent) {
            if (selectUnder(e)) {
                performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                onEditRequested?.invoke()
            }
        }
    })

    private val scaler = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            textSizeSp *= detector.scaleFactor
            return true
        }
    })

    // ---------------------------------------------------------------- public API

    /** Redraws after the document changed; keeps the selection inside a ROM that got smaller. */
    fun refresh() {
        val size = romSize()
        if (size > 0 && selStart >= size) selStart = size - 1
        selLength = selLength.coerceIn(1, max(1, size - selStart))
        if (geometry?.addressDigits != addressDigitsFor(size)) geometryDirty = true
        clampScroll()
        invalidate()
    }

    /** Selects [length] bytes at [offset] and scrolls them to a third of the way down the screen. */
    fun goTo(offset: Int, length: Int = 1) {
        if (document == null) return
        setSelection(offset, length)
        if (width == 0) {
            revealWhenMeasured = true
            return
        }
        scrollToSelection()
        scroller.forceFinished(true)
        invalidate()
    }

    /** Selects [length] bytes at [offset], scrolling only when the first of them is off screen. */
    fun select(offset: Int, length: Int = 1) {
        if (document == null) return
        setSelection(offset, length)
        if (width == 0) {
            revealWhenMeasured = true
            return
        }
        val g = geometry()
        val top = g.scrollForRow(selStart / g.bytesPerRow)
        if (top < scrollPx || top + g.rowHeight > scrollPx + g.viewportHeight(height)) scrollToSelection()
        invalidate()
    }

    /** Grows or shrinks the selection by [delta] bytes (never below one byte). */
    fun resizeSelection(delta: Int) {
        select(selStart, selLength + delta)
    }

    /** Selects the 4-byte word that contains the selection start. */
    fun selectWord() {
        select(selStart and 3.inv(), 4)
    }

    // ---------------------------------------------------------------- layout

    private fun romSize(): Int = document?.rom?.size ?: 0

    private fun addressDigitsFor(size: Int): Int = if (size > 0x1000000) 7 else 6

    /**
     * The current geometry, rebuilt when the width, text size or ROM size changed. A rebuild keeps the first
     * visible byte where it was, so rotating the phone or zooming does not lose the reader's place.
     */
    private fun geometry(): HexGeometry {
        val current = geometry
        if (current != null && !geometryDirty && geometryWidth == width) return current
        val topOffset = if (current == null) 0 else current.offsetOf(current.firstVisibleRow(scrollPx), 0)
        textPaint.typeface = Typeface.MONOSPACE
        textPaint.textSize = context.spF(textSizeSp)
        val metrics = textPaint.fontMetrics
        val glyphHeight = metrics.descent - metrics.ascent
        val rowHeight = max(1, ceil(glyphHeight + context.dpF(ROW_PADDING_DP)).toInt())
        baseline = (rowHeight - glyphHeight) / 2 - metrics.ascent
        val created = HexGeometry(
            width = width,
            charWidth = textPaint.measureText("0"),
            rowHeight = rowHeight,
            headerHeight = rowHeight,
            addressDigits = addressDigitsFor(romSize()),
            showText = showText,
            padding = context.dpF(PADDING_DP),
            rightReserve = context.dpF(SCROLL_ZONE_DP),
        )
        geometry = created
        geometryWidth = width
        geometryDirty = false
        scrollPx = created.scrollForRow(topOffset / created.bytesPerRow)
        clampScroll()
        return created
    }

    private fun maxScroll(): Int = geometry().maxScroll(romSize(), height)

    private fun clampScroll() {
        scrollPx = scrollPx.coerceIn(0, maxScroll())
    }

    /** Puts the selected row a third of the way down the rows area. */
    private fun scrollToSelection() {
        val g = geometry()
        scrollPx = g.scrollForRow(selStart / g.bytesPerRow) - g.viewportHeight(height) / 3
        clampScroll()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        geometryDirty = true
        if (revealWhenMeasured && w > 0) {
            revealWhenMeasured = false
            scrollToSelection()
        }
    }

    // ---------------------------------------------------------------- selection

    private fun setSelection(offset: Int, length: Int) {
        val size = romSize()
        if (size == 0) return
        selStart = offset.coerceIn(0, size - 1)
        selLength = length.coerceIn(1, size - selStart)
        onSelectionChanged?.invoke()
    }

    /** The byte under a touch point, or -1 when there is none. */
    private fun offsetAt(x: Float, y: Float): Int {
        val size = romSize()
        if (size == 0) return -1
        val g = geometry()
        val row = g.rowAt(y, scrollPx, size)
        if (row < 0) return -1
        return min(g.offsetOf(row, g.columnAt(x)), size - 1)
    }

    /** Selects the byte under [e] unless it is already part of the selection. Returns false when there is none. */
    private fun selectUnder(e: MotionEvent): Boolean {
        val offset = offsetAt(e.x, e.y)
        if (offset < 0) return false
        if (offset < selStart || offset >= selStart + selLength) select(offset, 1)
        return true
    }

    // ---------------------------------------------------------------- touch

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaler.onTouchEvent(event)
        if (scaler.isInProgress) return true
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (canFastScroll() && event.x > width - context.dpF(SCROLL_ZONE_DP)) {
                    fastScrolling = true
                    scroller.forceFinished(true)
                    fastScrollTo(event.y)
                    return true
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (fastScrolling) {
                    fastScrollTo(event.y)
                    return true
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (fastScrolling) {
                    fastScrolling = false
                    invalidate()
                    return true
                }
            }
        }
        return gestures.onTouchEvent(event)
    }

    private fun canFastScroll(): Boolean {
        val g = geometry()
        return g.contentHeight(romSize()) > g.viewportHeight(height)
    }

    /** Height of the scroll thumb: proportional to the visible part of the file, but never too small to grab. */
    private fun thumbHeight(g: HexGeometry): Float {
        val viewport = g.viewportHeight(height).toFloat()
        val content = g.contentHeight(romSize()).toFloat()
        if (content <= 0f) return viewport
        return min(viewport, max(context.dpF(MIN_THUMB_DP), viewport * viewport / content))
    }

    private fun fastScrollTo(y: Float) {
        val g = geometry()
        val thumb = thumbHeight(g)
        val travel = max(1f, g.viewportHeight(height) - thumb)
        val ratio = ((y - g.headerHeight - thumb / 2) / travel).coerceIn(0f, 1f)
        scrollPx = (ratio * maxScroll()).toInt()
        invalidate()
    }

    override fun computeScroll() {
        if (scroller.computeScrollOffset()) {
            scrollPx = scroller.currY
            clampScroll()
            postInvalidateOnAnimation()
        }
    }

    // ---------------------------------------------------------------- drawing

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(palette.background)
        val doc = document ?: return
        val size = doc.rom.size
        if (size == 0) return
        val g = geometry()
        drawRows(canvas, g, doc)
        drawHeader(canvas, g)
        drawScrollbar(canvas, g, size)
    }

    private fun drawRows(canvas: Canvas, g: HexGeometry, doc: RomDocument) {
        val rom = doc.rom
        val size = rom.size
        val n = g.bytesPerRow
        val firstRow = g.firstVisibleRow(scrollPx)
        val lastRow = g.lastVisibleRow(scrollPx, height, size)
        val selEnd = selStart + selLength
        val selectedRow = selStart / n
        val halfChar = g.charWidth / 2
        val inset = context.dpF(1f)
        val radius = context.dpF(SELECTION_RADIUS_DP)
        val lineWidth = context.dpF(1f)
        val viewTop = g.headerHeight.toFloat()

        canvas.save()
        canvas.clipRect(0f, viewTop, width.toFloat(), height.toFloat())

        shapePaint.color = palette.divider
        canvas.drawRect(g.addressDividerX, viewTop, g.addressDividerX + lineWidth, height.toFloat(), shapePaint)
        if (showText) canvas.drawRect(g.textDividerX, viewTop, g.textDividerX + lineWidth, height.toFloat(), shapePaint)

        for (row in firstRow..lastRow) {
            val top = g.rowTop(row, scrollPx).toFloat()
            val bottom = top + g.rowHeight
            val y = top + baseline
            val rowStart = row * n
            val rowEnd = min(rowStart + n, size)

            if (row == selectedRow) {
                shapePaint.color = palette.rowHighlight
                canvas.drawRect(0f, top, width.toFloat(), bottom, shapePaint)
            }
            if (selEnd > rowStart && selStart < rowEnd) {
                val first = max(selStart, rowStart) - rowStart
                val last = min(selEnd, rowEnd) - 1 - rowStart
                shapePaint.color = palette.selection
                canvas.drawRoundRect(
                    g.cellLeft(first) - halfChar, top + inset, g.cellRight(last) + halfChar, bottom - inset,
                    radius, radius, shapePaint,
                )
                if (showText) {
                    canvas.drawRoundRect(
                        g.textLeft(first), top + inset, g.textLeft(last) + g.charWidth, bottom - inset,
                        radius, radius, shapePaint,
                    )
                }
            }

            textPaint.color = if (row == selectedRow) palette.addressActive else palette.address
            drawAddress(canvas, rowStart, g.addressX, y, g.addressDigits)

            for (group in 0 until n / HexGeometry.GROUP_SIZE) {
                val groupStart = rowStart + group * HexGeometry.GROUP_SIZE
                if (groupStart >= size) break
                val pointer = rom.pointerTarget(groupStart) >= 0
                for (k in 0 until HexGeometry.GROUP_SIZE) {
                    val offset = groupStart + k
                    if (offset >= size) break
                    val column = group * HexGeometry.GROUP_SIZE + k
                    val value = rom[offset]
                    val selected = offset >= selStart && offset < selEnd
                    textPaint.color = when {
                        selected -> palette.selectionText
                        pointer -> palette.bytePointer
                        value == 0 || value == 0xFF -> palette.byteDim
                        else -> palette.byteNormal
                    }
                    drawByte(canvas, value, g.cellLeft(column), y)
                    if (showText) {
                        val character = columnChars[value]
                        textPaint.color = when {
                            selected -> palette.selectionText
                            character == null -> palette.byteDim
                            else -> palette.character
                        }
                        canvas.drawText(character ?: NON_TEXT, g.textLeft(column), y, textPaint)
                    }
                }
            }
        }
        canvas.restore()
    }

    /** The column numbers, drawn over the rows so data scrolls underneath them. */
    private fun drawHeader(canvas: Canvas, g: HexGeometry) {
        shapePaint.color = palette.background
        canvas.drawRect(0f, 0f, width.toFloat(), g.headerHeight.toFloat(), shapePaint)
        shapePaint.color = palette.divider
        canvas.drawRect(0f, g.headerHeight - context.dpF(1f), width.toFloat(), g.headerHeight.toFloat(), shapePaint)
        textPaint.color = palette.header
        for (column in 0 until g.bytesPerRow) drawByte(canvas, column, g.cellLeft(column), baseline)
    }

    private fun drawScrollbar(canvas: Canvas, g: HexGeometry, size: Int) {
        val viewport = g.viewportHeight(height)
        if (g.contentHeight(size) <= viewport) return
        val thumb = thumbHeight(g)
        val maxScroll = g.maxScroll(size, height)
        val ratio = if (maxScroll > 0) scrollPx.toFloat() / maxScroll else 0f
        val thumbTop = g.headerHeight + ratio * (viewport - thumb)
        val barWidth = context.dpF(if (fastScrolling) 8f else 3f)
        val right = width - context.dpF(2f)
        shapePaint.color = if (fastScrolling) palette.thumbActive else palette.thumb
        canvas.drawRoundRect(right - barWidth, thumbTop, right, thumbTop + thumb, barWidth / 2, barWidth / 2, shapePaint)
        if (fastScrolling) drawAddressBubble(canvas, g, right - barWidth, thumbTop + thumb / 2)
    }

    /** While dragging the thumb: a label next to it with the address at the top of the screen. */
    private fun drawAddressBubble(canvas: Canvas, g: HexGeometry, rightEdge: Float, centerY: Float) {
        val label = HexText.hex(g.firstVisibleRow(scrollPx) * g.bytesPerRow, g.addressDigits)
        val padding = context.dpF(10f)
        val bubbleHeight = g.rowHeight + context.dpF(8f)
        val bubbleWidth = textPaint.measureText(label) + 2 * padding
        val right = rightEdge - context.dpF(10f)
        val top = (centerY - bubbleHeight / 2).coerceIn(g.headerHeight.toFloat(), max(g.headerHeight.toFloat(), height - bubbleHeight))
        shapePaint.color = palette.bubble
        canvas.drawRoundRect(right - bubbleWidth, top, right, top + bubbleHeight, bubbleHeight / 2, bubbleHeight / 2, shapePaint)
        textPaint.color = palette.bubbleText
        canvas.drawText(label, right - bubbleWidth + padding, top + (bubbleHeight - g.rowHeight) / 2 + baseline, textPaint)
    }

    private fun drawByte(canvas: Canvas, value: Int, x: Float, y: Float) {
        pair[0] = digits[(value ushr 4) and 15]
        pair[1] = digits[value and 15]
        canvas.drawText(pair, 0, 2, x, y, textPaint)
    }

    private val addressBuffer = CharArray(8)

    private fun drawAddress(canvas: Canvas, value: Int, x: Float, y: Float, digitCount: Int) {
        var shift = (digitCount - 1) * 4
        for (i in 0 until digitCount) {
            addressBuffer[i] = digits[(value ushr shift) and 15]
            shift -= 4
        }
        canvas.drawText(addressBuffer, 0, digitCount, x, y, textPaint)
    }

    companion object {
        /** Text size of a fresh install: eight bytes and their text fit a 360 dp wide screen. */
        const val DEFAULT_TEXT_SP = 12f
        private const val MIN_TEXT_SP = 9f
        private const val MAX_TEXT_SP = 26f
        private const val ROW_PADDING_DP = 7f
        private const val PADDING_DP = 8f
        private const val SCROLL_ZONE_DP = 22f
        private const val MIN_THUMB_DP = 40f
        private const val SELECTION_RADIUS_DP = 4f

        /** Drawn in the text column for bytes that have no character (a centered dot). */
        private const val NON_TEXT = "\u00B7"
    }
}
