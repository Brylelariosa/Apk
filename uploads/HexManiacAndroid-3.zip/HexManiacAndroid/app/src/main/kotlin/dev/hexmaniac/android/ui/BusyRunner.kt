package dev.hexmaniac.android.ui

import android.app.Activity
import android.app.AlertDialog
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import dev.hexmaniac.android.R

/**
 * Runs slow work (reading or writing a ROM, searching, patching) on a background thread while a modal
 * "busy" dialog blocks the screen, then delivers the result on the UI thread. Failures go to [onError].
 */
class BusyRunner(private val activity: Activity, private val onError: (Throwable) -> Unit) {
    private var dialog: AlertDialog? = null

    /** Shows [message], runs [work] off the UI thread and then calls [done] with its result. */
    fun <T> run(message: String, work: () -> T, done: (T) -> Unit) {
        show(message)
        Thread {
            val outcome = runCatching(work)
            activity.runOnUiThread {
                dismiss()
                if (!activity.isFinishing && !activity.isDestroyed) deliver(outcome, done)
            }
        }.start()
    }

    fun dismiss() {
        dialog?.dismiss()
        dialog = null
    }

    private fun <T> deliver(outcome: Result<T>, done: (T) -> Unit) {
        val failure = outcome.exceptionOrNull()
        if (failure != null) {
            onError(failure)
            return
        }
        try {
            @Suppress("UNCHECKED_CAST")
            done(outcome.getOrNull() as T)
        } catch (t: Throwable) {
            onError(t)
        }
    }

    private fun show(message: String) {
        dismiss()
        val content = LinearLayout(activity)
        content.orientation = LinearLayout.HORIZONTAL
        content.gravity = Gravity.CENTER_VERTICAL
        content.setPadding(activity.dp(24), activity.dp(20), activity.dp(24), activity.dp(20))

        val spinner = ProgressBar(activity)
        content.addView(spinner, LinearLayout.LayoutParams(activity.dp(36), activity.dp(36)))

        val text = TextView(activity)
        text.text = message
        text.textSize = 16f
        text.setTextColor(activity.getColor(R.color.text_primary))
        val params = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        params.leftMargin = activity.dp(20)
        content.addView(text, params)

        val created = AlertDialog.Builder(activity).setView(content).setCancelable(false).create()
        created.show()
        dialog = created
    }
}
