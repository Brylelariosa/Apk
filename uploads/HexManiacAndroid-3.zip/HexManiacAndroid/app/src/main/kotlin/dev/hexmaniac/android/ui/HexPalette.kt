package dev.hexmaniac.android.ui

import android.content.Context
import dev.hexmaniac.android.R

/** The colors of the hex dump, resolved once from `res/values/colors.xml`. */
class HexPalette(context: Context) {
    val background = context.getColor(R.color.bg)
    val rowHighlight = context.getColor(R.color.hex_row_highlight)
    val divider = context.getColor(R.color.divider)
    val address = context.getColor(R.color.hex_address)
    val addressActive = context.getColor(R.color.text_secondary)
    val header = context.getColor(R.color.hex_header_text)
    val byteNormal = context.getColor(R.color.hex_text)
    val byteDim = context.getColor(R.color.hex_dim)
    val bytePointer = context.getColor(R.color.hex_pointer)
    val character = context.getColor(R.color.hex_text_column)
    val selection = context.getColor(R.color.hex_selection)
    val selectionText = context.getColor(R.color.hex_selection_text)
    val thumb = context.getColor(R.color.hex_thumb)
    val thumbActive = context.getColor(R.color.hex_thumb_active)
    val bubble = context.getColor(R.color.surface_raised)
    val bubbleText = context.getColor(R.color.accent)
}
