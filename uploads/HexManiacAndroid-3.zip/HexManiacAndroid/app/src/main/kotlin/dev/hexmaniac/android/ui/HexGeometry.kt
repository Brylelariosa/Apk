package dev.hexmaniac.android.ui

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Where everything in the hex dump sits, in pixels. Pure arithmetic with no Android classes, so it is unit tested
 * and [HexView] only has to draw what this class describes.
 *
 * A row reads, from left to right: the address, the hex bytes in groups of four (one extra character of space
 * between groups), and optionally the same bytes as text. The row width decides how many bytes fit on a row.
 *
 * @param width the view width in pixels
 * @param charWidth the advance of one monospace character
 * @param rowHeight height of one data row
 * @param headerHeight height of the column header, which stays at the top while the rows scroll under it
 * @param addressDigits number of hex digits of the address column
 * @param showText whether the text column is part of the row
 * @param padding space kept free at the left edge (and at the right edge of the content)
 * @param rightReserve extra space at the right edge, kept for the fast-scroll thumb
 */
class HexGeometry(
    val width: Int,
    val charWidth: Float,
    val rowHeight: Int,
    val headerHeight: Int,
    val addressDigits: Int,
    val showText: Boolean,
    val padding: Float,
    val rightReserve: Float,
) {
    /** Bytes on each row: a multiple of four, so a 4-byte pointer never straddles two rows. */
    val bytesPerRow: Int = chooseBytesPerRow()

    /** Number of gaps between the columns of a row (address, between groups of bytes, before the text). */
    private val gapCount = 1 + (bytesPerRow / GROUP_SIZE - 1) + (if (showText) 1 else 0)

    /** Width left over once the row has been laid out with the plain gaps. */
    private val slack = max(0f, width - requiredWidth(bytesPerRow))

    /**
     * Space added to every gap between the columns, at most one character: a row that is a little narrower than
     * the view is spread out a bit. Whatever is still left over is split between the left and the right margin.
     */
    val gapExtra: Float = min(charWidth, slack / gapCount)

    /** x of the first digit of the address column. */
    val addressX: Float = padding + (slack - gapExtra * gapCount) / 2

    /** x of the first digit of the first byte. */
    val hexX: Float = addressX + (addressDigits + ADDRESS_GAP) * charWidth + gapExtra

    /** Width of one byte cell (two hex digits). */
    val cellWidth: Float = 2 * charWidth

    /** x just right of the last byte cell. */
    val hexRight: Float = hexX + hexChars(bytesPerRow) * charWidth + (bytesPerRow / GROUP_SIZE - 1) * gapExtra

    /** x of the first character of the text column. */
    val textX: Float = hexRight + TEXT_GAP * charWidth + gapExtra

    /** x just right of the last character of the text column. */
    val textRight: Float = textX + bytesPerRow * charWidth

    /** x of the thin line between the address and the bytes. */
    val addressDividerX: Float = hexX - (ADDRESS_GAP * charWidth + gapExtra) / 2

    /** x of the thin line between the bytes and the text column. */
    val textDividerX: Float = hexRight + (TEXT_GAP * charWidth + gapExtra) / 2

    /** Left edge of the hex cell of [column] (0 until [bytesPerRow]). */
    fun cellLeft(column: Int): Float =
        hexX + (column * 3 + (column / GROUP_SIZE) * GROUP_GAP) * charWidth + (column / GROUP_SIZE) * gapExtra

    fun cellRight(column: Int): Float = cellLeft(column) + cellWidth

    /** Left edge of the text character of [column]. */
    fun textLeft(column: Int): Float = textX + column * charWidth

    /**
     * The column a touch at [x] belongs to: the text character under it when [x] lies in the text column,
     * otherwise the byte whose hex cell is nearest (touches in the gaps and in the address column still hit a byte).
     */
    fun columnAt(x: Float): Int {
        if (showText && x >= (hexRight + textX) / 2) {
            val column = ((x - textX) / charWidth).toInt()
            return column.coerceIn(0, bytesPerRow - 1)
        }
        var best = 0
        var bestDistance = Float.MAX_VALUE
        for (column in 0 until bytesPerRow) {
            val distance = abs(x - (cellLeft(column) + cellWidth / 2))
            if (distance < bestDistance) {
                best = column
                bestDistance = distance
            }
        }
        return best
    }

    // ---------------------------------------------------------------- rows and scrolling

    /** Number of rows needed for [size] bytes. */
    fun totalRows(size: Int): Int = ((size.toLong() + bytesPerRow - 1) / bytesPerRow).toInt()

    /** Height of all rows together. */
    fun contentHeight(size: Int): Long = totalRows(size).toLong() * rowHeight

    /** Height of the area the rows scroll in (the view minus the header). */
    fun viewportHeight(viewHeight: Int): Int = max(0, viewHeight - headerHeight)

    /** The largest scroll offset: where the last row ends at the bottom of the view. */
    fun maxScroll(size: Int, viewHeight: Int): Int {
        val range = contentHeight(size) - viewportHeight(viewHeight)
        return range.coerceIn(0L, Int.MAX_VALUE.toLong()).toInt()
    }

    /** Scroll offset that puts [row] at the top of the rows area. */
    fun scrollForRow(row: Int): Int = (row.toLong() * rowHeight).coerceAtMost(Int.MAX_VALUE.toLong()).toInt()

    /** y of the top edge of [row] in view coordinates, for the given scroll offset. */
    fun rowTop(row: Int, scroll: Int): Int = headerHeight + row * rowHeight - scroll

    /** First row that is at least partly visible. */
    fun firstVisibleRow(scroll: Int): Int = scroll / rowHeight

    /** Last row that is at least partly visible (never beyond the data). */
    fun lastVisibleRow(scroll: Int, viewHeight: Int, size: Int): Int =
        min(totalRows(size) - 1, (scroll + viewportHeight(viewHeight) - 1) / rowHeight)

    /** The row under view y coordinate [y], or -1 when [y] is over the header or past the last row of [size] bytes. */
    fun rowAt(y: Float, scroll: Int, size: Int): Int {
        if (y < headerHeight) return -1
        val row = ((scroll + y - headerHeight) / rowHeight).toInt()
        return if (row < totalRows(size)) row else -1
    }

    /** Offset of the byte at [row], [column]. */
    fun offsetOf(row: Int, column: Int): Int = row * bytesPerRow + column

    // ---------------------------------------------------------------- internals

    private fun chooseBytesPerRow(): Int {
        var n = MAX_BYTES_PER_ROW
        while (n > GROUP_SIZE && requiredWidth(n) > width) n -= GROUP_SIZE
        return n
    }

    private fun requiredWidth(n: Int): Float {
        var chars = addressDigits + ADDRESS_GAP + hexChars(n)
        if (showText) chars += TEXT_GAP + n
        return 2 * padding + rightReserve + chars * charWidth
    }

    /** Characters taken by [n] byte cells: two digits each, one space between cells, one extra between groups. */
    private fun hexChars(n: Int): Float = n * 3f - 1f + (n / GROUP_SIZE - 1) * GROUP_GAP

    companion object {
        const val GROUP_SIZE = 4
        const val MAX_BYTES_PER_ROW = 32

        /** Characters between the address and the first byte. */
        const val ADDRESS_GAP = 2

        /** Characters between the last byte and the text column. */
        const val TEXT_GAP = 2

        /** Extra characters between groups of four bytes. */
        const val GROUP_GAP = 1f
    }
}
