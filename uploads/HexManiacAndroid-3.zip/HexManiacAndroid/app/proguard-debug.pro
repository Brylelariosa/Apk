# Debug builds are shrunk and optimized like release builds but keep their names, so stack traces read normally.
-dontobfuscate
