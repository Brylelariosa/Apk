# HexManiac loads nothing by reflection. The only entry point is the launcher activity, which the rules generated
# from the manifest already keep, so R8 is free to shrink and optimize everything else.

# Readable stack traces in crash reports.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
