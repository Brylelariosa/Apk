# Notices

## HexManiacAdvance

This project is an Android remake of HexManiacAdvance (https://github.com/haven1433/HexManiacAdvance). The character
set reference data (`core/src/main/resources/hma/pcsReference.txt`) and the table and metadata reference files that
are kept in the same folder come from that project, and the formats and behaviour of the engine follow it.

HexManiacAdvance is released under the MIT license:

```
MIT License

Copyright (c) 2018 haven1433

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

## Material Icons

The toolbar icons in `app/src/main/res/drawable` (open, save, undo, redo) are taken from Google's Material Icons,
licensed under the Apache License 2.0 (https://www.apache.org/licenses/LICENSE-2.0).
