# HexManiac for Android

Android remake of HexManiacAdvance (GBA ROM hex and table editor), version 0.2.0.
One universal APK (no ABI or density splits, no native code), dark Material look, ASCII-only interface.

Build it with the "Build APK" GitHub Actions workflow: zip this folder, push the zip to `uploads/`, download the APK
artifact. Locally: `./gradlew assembleDebug` (or `assembleRelease`).

## What works

- Open a ROM through the system file picker (any `.gba`, up to 64 MB). Save in place or "Save as". Every opened ROM is
  copied to app-private storage first (the last three backups are kept).
- Hex dump drawn on a canvas: address column, column header, groups of four bytes, optional text column in the game's
  character set (PCS), pointers tinted, `00` and `FF` dimmed, merged selection highlight, current row highlight.
  The number of bytes per row follows the screen width (4, 8, 12, ... up to 32). Pinch to zoom (9 to 26 sp, remembered),
  drag the right edge to fast-scroll (a bubble shows the address).
- Tap selects a byte, double-tap follows a pointer, long-press edits the selected bytes. The bar under the dump has
  `-1`, `+1`, `Word` (resize the selection), `Edit`, `Follow` and `Back` (history of followed pointers).
- Go to (offset or an `08xxxxxx` pointer), Find (hex with `??` wildcards, or `"text"` in the game's character set),
  Find next (wraps around).
- Undo and redo with labelled steps, unsaved-changes guard on open and on exit.
- IPS and UPS patches: apply (UPS also removes), create against an original ROM.
- ROM info: title, game code, language and version, size, CRC-32.

## APK size

- R8 shrinking, optimization and obfuscation plus resource shrinking, in the debug build as well as the release build
  (the workflow builds whichever the signing secrets allow, and both are small). Debug keeps names (`-dontobfuscate`).
- No AndroidX or AppCompat: the app uses the framework `Activity`, the framework action bar, programmatic views and
  vector drawables. The only libraries are the Kotlin standard library (shrunk by R8) and the `core` module.
- Only the data files the app reads are packaged (`shippedData` in `core/build.gradle.kts`, kept in step with
  `hma/index.txt`). Add a file there when the feature that needs it lands.
- Kotlin's generated null-check calls are switched off, and build-time metadata is excluded from the APK.
- No ABI splits: there is no native code, so there is nothing to split.

## Layout

```
core/   pure Kotlin/JVM engine, no Android classes, unit tested (./gradlew :core:test)
  rom/    RomData, RomDocument (undo/redo), header + game detection, search, hex text, RomInfo, OffsetHistory
  text/   PCS text codec (decoder, encoder, reference parser, macros)
  patch/  IPS, UPS, CRC-32, Patches facade
  io/     ResourceSource (class-path access to the data files in src/main/resources/hma)
app/    thin Android shell (./gradlew :app:testDebugUnitTest runs the layout tests)
  MainActivity    wiring: menu, dialogs, flows (open, save, find, patch, ...)
  session/        RomSession: the open document, its Uri, pointer history, last search
  io/             RomFiles (storage access framework I/O), Backups
  ui/             HexView (canvas) + HexGeometry (pure layout maths, unit tested), InfoPanel, ActionRow,
                  EmptyState, Dialogs, BusyRunner (background work with a spinner), HexPalette, ViewSettings
```

Rules that keep the engine portable: `core` uses only Java 8 library APIs (it runs on Android API 24+), never touches
`android.*`, and reads its data files through `ResourceSource`. The app only draws and forwards input. All screen
geometry lives in `HexGeometry`, which has no Android dependency either.

## Build matrix

Gradle 8.6, AGP 8.4.2, Kotlin 2.0.21, JDK 17, compileSdk/targetSdk 34, minSdk 24.

The workflow replaces `gradle/wrapper/gradle-wrapper.jar` with the one from the Gradle 8.6.0 tag, and that jar has no
`Main-Class` entry. The `gradlew` and `gradlew.bat` scripts in this project therefore start the wrapper with
`-classpath gradle-wrapper.jar org.gradle.wrapper.GradleWrapperMain` instead of `-jar`.

## Next steps

Table and anchor model (tableReference / metadata TOML), table browser and editor, text repointing, LZ77 sprites and
palettes, script viewer.

## Credits

Based on HexManiacAdvance by haven1433 (MIT). Toolbar icons are Material Icons (Apache 2.0). See `NOTICE.md`.
