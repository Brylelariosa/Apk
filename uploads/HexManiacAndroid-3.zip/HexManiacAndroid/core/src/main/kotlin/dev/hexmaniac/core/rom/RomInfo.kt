package dev.hexmaniac.core.rom

import dev.hexmaniac.core.patch.Crc32
import dev.hexmaniac.core.text.PcsTable

/** What the info panel shows for the byte under the cursor. Every field is ready-to-display plain text. */
class CursorSummary(
    val address: String,
    val u8: String,
    val u16: String,
    val u32: String,
    /** Offset the pointer at the cursor leads to, or null when there is no pointer there. */
    val pointerTarget: String?,
    /** The bytes from the cursor on, decoded with the game's character set, on one line. */
    val text: String,
)

/** Plain-text descriptions of a ROM and of the bytes under the cursor, so any front end can show them. */
object RomInfo {
    /** How many bytes after the cursor are decoded as text. */
    private const val TEXT_PREVIEW_BYTES = 24

    /** The values at [offset] in several widths, the pointer there if any, and a text preview. */
    fun cursorSummary(document: RomDocument, offset: Int, pcs: PcsTable): CursorSummary {
        val rom = document.rom
        val target = rom.pointerNear(offset)
        val text = pcs.decode(rom.bytes, offset, TEXT_PREVIEW_BYTES, document.header.game?.full ?: "")
        return CursorSummary(
            address = HexText.hex(offset, 6),
            u8 = HexText.hex(rom[offset], 2),
            u16 = HexText.hex(rom.readShort(offset), 4),
            u32 = HexText.hex(rom.readWord(offset), 8),
            pointerTarget = if (target >= 0) HexText.hex(target, 6) else null,
            text = text.replace("\n", " / "),
        )
    }

    /** Name of the detected game, such as "FireRed (English) v0", or null when the ROM is not a known game. */
    fun gameLabel(document: RomDocument): String? = document.header.game?.displayName

    /** The multi-line "ROM info" text. */
    fun details(document: RomDocument, fileName: String): String {
        val header = document.header
        val game = header.game
        val size = document.rom.size
        return buildString {
            append("File: ").append(fileName).append('\n')
            append("Size: ").append(size).append(" bytes (").append(size / 1024).append(" KB)\n")
            append("Title: ").append(header.title).append('\n')
            append("Game code: ").append(game?.full ?: "unknown").append('\n')
            if (game != null) {
                append("Game: ").append(game.displayName).append('\n')
                append("Table data for this game: ")
                    .append(if (game.hasTableSupport) "available (coming soon)" else "not available").append('\n')
            }
            append("Maker: ").append(header.maker).append('\n')
            append("CRC-32: ").append(HexText.hex(Crc32.compute(document.rom.bytes), 8)).append('\n')
            append("Unsaved changes: ").append(if (document.isDirty) "yes" else "no")
        }
    }
}
