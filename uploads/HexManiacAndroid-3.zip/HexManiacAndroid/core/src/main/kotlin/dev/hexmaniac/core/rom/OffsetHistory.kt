package dev.hexmaniac.core.rom

/**
 * The places the user jumped away from (following a pointer, "go to"), so "back" can return to them.
 * Only the most recent [limit] places are kept.
 */
class OffsetHistory(private val limit: Int = 100) {
    private val entries = ArrayList<Int>()

    val isEmpty: Boolean get() = entries.isEmpty()

    val size: Int get() = entries.size

    /** Remembers [offset]. Pushing the place that is already on top changes nothing. */
    fun push(offset: Int) {
        if (entries.isNotEmpty() && entries[entries.size - 1] == offset) return
        entries.add(offset)
        if (entries.size > limit) entries.removeAt(0)
    }

    /** Removes and returns the most recently remembered offset, or null when the history is empty. */
    fun pop(): Int? = if (entries.isEmpty()) null else entries.removeAt(entries.size - 1)

    fun clear() {
        entries.clear()
    }
}
