package dev.hexmaniac.core.rom

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class OffsetHistoryTest {
    @Test
    fun popsInReverseOrder() {
        val history = OffsetHistory()
        history.push(0x10)
        history.push(0x20)
        history.push(0x30)
        assertEquals(0x30, history.pop())
        assertEquals(0x20, history.pop())
        assertEquals(0x10, history.pop())
        assertNull(history.pop())
        assertTrue(history.isEmpty)
    }

    @Test
    fun ignoresRepeatOfTheTopEntry() {
        val history = OffsetHistory()
        history.push(5)
        history.push(5)
        assertEquals(1, history.size)
        history.push(6)
        history.push(5)
        assertEquals(3, history.size)
    }

    @Test
    fun forgetsTheOldestEntriesBeyondTheLimit() {
        val history = OffsetHistory(limit = 3)
        for (i in 1..5) history.push(i)
        assertEquals(3, history.size)
        assertEquals(5, history.pop())
        assertEquals(4, history.pop())
        assertEquals(3, history.pop())
        assertNull(history.pop())
    }

    @Test
    fun clearEmptiesTheHistory() {
        val history = OffsetHistory()
        history.push(1)
        history.clear()
        assertTrue(history.isEmpty)
        assertFalse(history.size > 0)
    }
}
