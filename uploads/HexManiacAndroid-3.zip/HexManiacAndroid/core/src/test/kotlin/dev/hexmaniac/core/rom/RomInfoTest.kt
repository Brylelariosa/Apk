package dev.hexmaniac.core.rom

import dev.hexmaniac.core.text.PcsTable
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RomInfoTest {
    private fun ascii(rom: ByteArray, offset: Int, text: String) {
        for (i in text.indices) rom[offset + i] = text[i].code.toByte()
    }

    private fun fireRed(): RomDocument {
        val rom = ByteArray(0x200)
        ascii(rom, 0xA0, "POKEMON FIRE")
        ascii(rom, 0xAC, "BPRE")
        ascii(rom, 0xB0, "01")
        return RomDocument("fire.gba", rom)
    }

    private val pcs = PcsTable.DEFAULT

    @Test
    fun summaryShowsTheValueInEveryWidth() {
        val doc = fireRed()
        doc.write(0x40, byteArrayOf(0x0A, 0x1B, 0x2C, 0x3D), "bytes")
        val summary = RomInfo.cursorSummary(doc, 0x40, pcs)
        assertEquals("000040", summary.address)
        assertEquals("0A", summary.u8)
        assertEquals("1B0A", summary.u16)
        assertEquals("3D2C1B0A", summary.u32)
        assertNull(summary.pointerTarget)
    }

    @Test
    fun summaryReportsPointerTargets() {
        val doc = fireRed()
        doc.write(0x100, byteArrayOf(0xF0.toByte(), 0x01, 0x00, 0x08), "pointer")
        assertEquals("0001F0", RomInfo.cursorSummary(doc, 0x100, pcs).pointerTarget)
        // a byte inside the pointer reports it too
        assertEquals("0001F0", RomInfo.cursorSummary(doc, 0x102, pcs).pointerTarget)
        assertEquals("080001F0", RomInfo.cursorSummary(doc, 0x100, pcs).u32)
    }

    @Test
    fun summaryTextIsOneLine() {
        val doc = fireRed()
        val text = pcs.encode("\"AB\\nCD\"", "BPRE0").bytes
        doc.write(0x80, text, "text")
        val summary = RomInfo.cursorSummary(doc, 0x80, pcs)
        assertFalse(summary.text.contains('\n'))
        assertTrue(summary.text.startsWith("\"AB"))
    }

    @Test
    fun gameLabelNamesKnownGamesOnly() {
        assertEquals("FireRed (English) v0", RomInfo.gameLabel(fireRed()))
        assertNull(RomInfo.gameLabel(RomDocument("blank.gba", ByteArray(0x200))))
    }

    @Test
    fun detailsListTheHeaderFields() {
        val doc = fireRed()
        val details = RomInfo.details(doc, "fire.gba")
        assertTrue(details.contains("File: fire.gba"))
        assertTrue(details.contains("Size: 512 bytes (0 KB)"))
        assertTrue(details.contains("Title: POKEMON FIRE"))
        assertTrue(details.contains("Game code: BPRE0"))
        assertTrue(details.contains("Maker: 01"))
        assertTrue(details.contains("CRC-32: "))
        assertTrue(details.endsWith("Unsaved changes: no"))
        doc.writeByte(0x10, 1, "edit")
        assertTrue(RomInfo.details(doc, "fire.gba").endsWith("Unsaved changes: yes"))
        assertFalse(RomInfo.details(doc, "fire.gba").contains("unknown"))
    }
}
