package dev.hexmaniac.core.text

import dev.hexmaniac.core.io.ClasspathResources
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PcsTableTest {
    private val table = PcsTable.load(ClasspathResources())

    private fun bytes(vararg v: Int) = ByteArray(v.size) { v[it].toByte() }

    @Test
    fun bundledReferenceMapsLetters() {
        assertEquals("A", table.charFor(0xBB))
        assertEquals("a", table.charFor(0xD5))
        assertEquals("0", table.charFor(0xA1))
        assertEquals("\\n", table.charFor(0xFE))
        assertEquals("A", table.columnChar(0xBB))
        assertNull(table.columnChar(0xFE))
    }

    @Test
    fun encodeAndDecodeRoundTrip() {
        val encoded = table.encode("\"ABC abc 012\"")
        assertFalse(encoded.hasBadCharacters)
        assertEquals(0xFF, encoded.bytes.last().toInt() and 0xFF)
        assertEquals("\"ABC abc 012\"", table.decode(encoded.bytes, 0, encoded.bytes.size))
    }

    @Test
    fun encodeWithoutQuotesAddsTerminator() {
        assertArrayEquals(bytes(0xBB, 0xBC, 0xBD, 0xFF), table.encode("ABC").bytes)
    }

    @Test
    fun unknownCharactersAreReported() {
        val result = table.encode("A\u4E2DB")
        assertTrue(result.hasBadCharacters)
        assertArrayEquals(bytes(0xBB, 0xBC, 0xFF), result.bytes)
    }

    @Test
    fun rawBytesRoundTrip() {
        val decoded = table.decode(bytes(0x18, 0xBB, 0xFF), 0, 3)
        assertEquals("\"\\!18A\"", decoded)
        assertArrayEquals(bytes(0x18, 0xBB, 0xFF), table.encode(decoded).bytes)
    }

    @Test
    fun macrosDependOnTheGame() {
        assertEquals("\"[player]\"", table.decode(bytes(0xFD, 0x01, 0xFF), 0, 3, "BPRE0"))
        assertArrayEquals(bytes(0xFD, 0x01, 0xFF), table.encode("[player]", "BPRE0").bytes)
        assertTrue(table.encode("[player]", "").hasBadCharacters)
    }

    @Test
    fun readStringLength() {
        val data = bytes(0xBB, 0xBC, 0xBD, 0xFF, 0x00)
        assertEquals(4, table.readStringLength(data, 0))
        assertEquals(-1, table.readStringLength(bytes(0xBB, 0x18, 0xFF), 0)) // 0x18 has no character
        assertEquals(-1, table.readStringLength(bytes(0xBB, 0xBB, 0xBB, 0xBB, 0xBB, 0xFF), 0)) // too many repeats
        assertEquals(6, table.readStringLength(bytes(0xBB, 0xBB, 0xBB, 0xBB, 0xBB, 0xFF), 0, allowRepeats = true))
        assertEquals(-1, table.readStringLength(bytes(0xBB, 0xBC), 0)) // no terminator
        assertEquals(-1, table.readStringLength(data, 99))
    }

    @Test
    fun functionEscapeSkipsItsArguments() {
        // FC 01 04 (colour change, 2 argument bytes in the default table) must not end the string early
        assertEquals(5, table.readStringLength(bytes(0xFC, 0x01, 0x04, 0xBB, 0xFF), 0))
    }

    @Test
    fun defaultsWorkWithoutAReferenceFile() {
        val plain = PcsTable.DEFAULT
        assertArrayEquals(bytes(0xBB, 0xFF), plain.encode("A").bytes)
        assertEquals("\"Hi\"", plain.decode(plain.encode("Hi").bytes, 0, 3))
    }
}
