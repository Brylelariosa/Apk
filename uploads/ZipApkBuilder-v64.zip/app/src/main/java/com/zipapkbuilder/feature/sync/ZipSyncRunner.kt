package com.zipapkbuilder.feature.sync

import android.content.Context
import android.net.Uri
import com.zipapkbuilder.core.UriUtils
import org.json.JSONObject
import java.io.File
import java.util.zip.ZipFile

/**
 * Runs the Rust sync engine (`app/src/main/rust/zipsync` in this project, built into the APK as
 * `libzipsync.so`).
 *
 * The engine reads a ZIP, compares every file with the repo on GitHub (by Git blob id), uploads
 * only the files that differ — in small parallel requests, spaced out to what GitHub allows and each
 * retried on its own — and commits them in batches (each commit is a save point, only the last one
 * starts a build). That is why a 7 MB project ZIP no longer has to travel as a single 9 MB request:
 * the ZIP never leaves the phone, and a typical update uploads a few kilobytes.
 *
 * It is a separate process rather than a JNI library: nothing in the app can crash from inside
 * it, cancelling is just killing it, and its progress arrives as one JSON object per line on
 * stdout (`{"t":"log"|"progress"|"result", ...}`). The same executable also works from a
 * terminal — see RUST_ENGINE.md.
 *
 * A sync replaces what differs and adds what is new, `.github/workflows/*` included, and never
 * deletes anything.
 */
object ZipSyncRunner {

    /** Where the repo keeps the workflow this app builds with. */
    private const val BUILD_WORKFLOW_PATH = ".github/workflows/build.yml"

    /** A workflow file is a few KB; anything bigger is not read. */
    private const val MAX_WORKFLOW_BYTES = 1_000_000L

    class Result(
        /** The new commit, or null when the repo already matched the ZIP. */
        val commit: String?,
        val added: Int,
        val modified: Int,
        val unchanged: Int,
        val skipped: Int,
        val uploadedBytes: Long,
        /** Repo paths that were added or replaced (capped at a few thousand). */
        val changed: List<String>
    )

    /** The engine for this phone's CPU, or null when this build of the app doesn't contain it. */
    fun engineFile(context: Context): File? {
        val f = File(context.applicationInfo.nativeLibraryDir, "libzipsync.so")
        return if (f.isFile) f else null
    }

    /** Copies the picked ZIP into the app's cache, because the engine opens it by file path. */
    fun copyToCache(context: Context, uri: Uri): File {
        val dir = File(context.cacheDir, "sync")
        dir.mkdirs()
        // Anything still here is left over from a run that was killed.
        dir.listFiles()?.forEach { if (it.isFile) it.delete() }
        val out = File(dir, "sync-${System.currentTimeMillis()}.zip")
        UriUtils.openInputStreamOrThrow(context.contentResolver, uri).use { input ->
            out.outputStream().use { output -> input.copyTo(output) }
        }
        return out
    }

    /**
     * The text of the ZIP's own `.github/workflows/build.yml`, or null when it has none (or the ZIP
     * can't be read - the engine reports that properly a moment later). A folder wrapping the whole
     * project (`MyApp/.github/...`) counts: the engine cuts it off ("auto" strip), and this assumes
     * it does so whenever every file of the ZIP sits inside one folder.
     */
    fun readBuildWorkflow(zip: File): String? = try {
        ZipFile(zip).use { z ->
            val files = z.entries().asSequence()
                .filter { !it.isDirectory }
                .map { it.name.replace('\\', '/') to it }
                .filterNot { (name, _) -> isJunk(name) }
                .toList()
            val wrapper = files.map { (name, _) -> name.substringBefore('/', "") }
                .distinct().singleOrNull().orEmpty()
            val wanted = if (wrapper.isEmpty()) BUILD_WORKFLOW_PATH else "$wrapper/$BUILD_WORKFLOW_PATH"
            val entry = files.firstOrNull { (name, _) -> name == wanted }?.second ?: return@use null
            if (entry.size > MAX_WORKFLOW_BYTES) return@use null
            z.getInputStream(entry).use { it.readBytes().toString(Charsets.UTF_8) }
        }
    } catch (_: Exception) {
        null
    }

    /** The same files the engine drops before it looks at a ZIP. */
    private fun isJunk(path: String): Boolean {
        val name = path.substringAfterLast('/')
        return path.startsWith("__MACOSX/") || path.contains("/__MACOSX/") ||
            name == ".DS_Store" || name == "Thumbs.db"
    }

    /**
     * Runs the engine and blocks until it is done. Throws with a readable message when it fails
     * or when [isCancelled] turns true (the message then contains "Cancelled", which is what
     * the build flow looks for). [log] gets the engine's log lines, [progress] gets
     * (phase, done, total) where phase is "read" or "upload".
     */
    fun run(
        context: Context,
        token: String,
        owner: String,
        repo: String,
        branch: String,
        zip: File,
        message: String,
        log: (String) -> Unit,
        progress: (String, Long, Long) -> Unit,
        isCancelled: () -> Boolean
    ): Result {
        val engine = engineFile(context)
            ?: throw Exception(
                "This build of the app doesn't contain the Rust sync engine (it didn't compile, or there is none for this " +
                    "phone's CPU). Open the app's own build log and search it for \"zipsync engine\", " +
                    "or switch the Upload to row back to uploads/."
            )

        val command = listOf(
            engine.absolutePath, "sync", "--json",
            "--zip", zip.absolutePath,
            "--repo", "$owner/$repo",
            "--branch", branch,
            "--message", message,
            // "Replace everything": workflow files in the ZIP are synced like any other file.
            "--include-workflows"
        )
        val builder = ProcessBuilder(command)
        // The token goes through the environment, never the command line.
        builder.environment()["ZIPSYNC_TOKEN"] = token
        builder.redirectErrorStream(true)
        val process = try {
            builder.start()
        } catch (e: Exception) {
            throw Exception("Could not start the sync engine: ${e.message}")
        }

        // The engine is its own process, so cancelling is simply stopping it.
        val watcher = Thread {
            try {
                while (process.isAlive) {
                    if (isCancelled()) {
                        process.destroy()
                        break
                    }
                    Thread.sleep(250)
                }
            } catch (_: InterruptedException) {
            }
        }
        watcher.isDaemon = true
        watcher.start()

        var result: Result? = null
        var failure: String? = null
        val strayLines = ArrayList<String>()
        try {
            process.inputStream.bufferedReader(Charsets.UTF_8).forEachLine { raw ->
                val line = raw.trim()
                if (line.isEmpty()) return@forEachLine
                val json = if (line.startsWith("{")) {
                    try { JSONObject(line) } catch (_: Exception) { null }
                } else null
                if (json == null) {
                    // Not one of the engine's messages (a crash report, say): keep it for the error text.
                    strayLines.add(line)
                    if (strayLines.size > 20) strayLines.removeAt(0)
                    return@forEachLine
                }
                when (json.optString("t")) {
                    "log" -> log(json.optString("m"))
                    "progress" -> progress(json.optString("phase"), json.optLong("done"), json.optLong("total"))
                    "result" -> {
                        if (json.optBoolean("ok")) {
                            val changed = ArrayList<String>()
                            val arr = json.optJSONArray("changed")
                            if (arr != null) {
                                for (i in 0 until arr.length()) changed.add(arr.optString(i))
                            }
                            result = Result(
                                commit = if (json.isNull("commit")) null else json.optString("commit").ifEmpty { null },
                                added = json.optInt("added"),
                                modified = json.optInt("modified"),
                                unchanged = json.optInt("unchanged"),
                                skipped = json.optInt("skipped"),
                                uploadedBytes = json.optLong("uploaded_bytes"),
                                changed = changed
                            )
                        } else {
                            failure = json.optString("error", "The sync failed.")
                        }
                    }
                    else -> log(line)
                }
            }
        } finally {
            watcher.interrupt()
        }
        val exitCode = process.waitFor()

        if (isCancelled()) throw Exception("Cancelled by user")
        failure?.let { throw Exception(it) }
        val finished = result
        if (finished != null) return finished
        val tail = if (strayLines.isEmpty()) "" else " Last output: ${strayLines.takeLast(3).joinToString(" | ")}"
        throw Exception("The sync engine stopped unexpectedly (exit code $exitCode).$tail")
    }
}
