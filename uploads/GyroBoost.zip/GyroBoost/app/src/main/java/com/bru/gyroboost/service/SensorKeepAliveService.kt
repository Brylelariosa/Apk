package com.bru.gyroboost.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.bru.gyroboost.MainActivity
import com.bru.gyroboost.R
import com.bru.gyroboost.sensor.SensorRepository
import com.bru.gyroboost.sensor.SensorStatsTracker
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Foreground service that keeps a FASTEST-rate gyroscope listener alive for
 * the length of a gaming session.
 *
 * This matters beyond just "warming up" the hardware: starting with Android
 * 12, apps in the background are throttled to a slow default sensor rate
 * unless they're running a foreground service. A foreground service is the
 * only sanctioned way to keep a high-rate listener alive while Blood Strike
 * itself is the foreground app.
 *
 * Publishes live rate/jitter stats via [state] so the UI can show real
 * numbers instead of a placebo "boosted!" message.
 */
class SensorKeepAliveService : Service() {

    companion object {
        private const val CHANNEL_ID = "gyro_keep_alive"
        private const val NOTIFICATION_ID = 1001
        private const val ACTION_STOP = "com.bru.gyroboost.action.STOP"

        private val _state = MutableStateFlow<SensorStatsTracker.Stats?>(null)
        val state = _state.asStateFlow()

        private val _isRunning = MutableStateFlow(false)
        /** True from service creation until destruction - independent of whether a
         *  sample has arrived yet, so UI toggles can sync correctly on their own. */
        val isRunning = _isRunning.asStateFlow()

        fun start(context: Context) {
            val intent = Intent(context, SensorKeepAliveService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, SensorKeepAliveService::class.java))
        }
    }

    private lateinit var sensorRepository: SensorRepository
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        sensorRepository = SensorRepository(applicationContext)
        createNotificationChannel()
        _isRunning.value = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        startForeground(NOTIFICATION_ID, buildNotification(null))
        acquireWakeLock()
        sensorRepository.start { stats ->
            _state.value = stats
            updateNotification(stats)
        }
        return START_STICKY
    }

    private fun acquireWakeLock() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "GyroBoost:sensorKeepAlive").apply {
            setReferenceCounted(false)
            acquire(4 * 60 * 60 * 1000L) // 4h safety cap so it can't be left running forever by accident
        }
    }

    private fun buildNotification(stats: SensorStatsTracker.Stats?): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val text = if (stats != null && stats.sampleCount > 0) {
            "~${"%.0f".format(stats.estimatedHz)} Hz | jitter ${"%.2f".format(stats.jitterMs)} ms"
        } else {
            "Warming up gyroscope..."
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_gyro)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun updateNotification(stats: SensorStatsTracker.Stats) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, buildNotification(stats))
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notification_channel_description)
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        sensorRepository.stop()
        wakeLock?.let { if (it.isHeld) it.release() }
        _state.value = null
        _isRunning.value = false
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
