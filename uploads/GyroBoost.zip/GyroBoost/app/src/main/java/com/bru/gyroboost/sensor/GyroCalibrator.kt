package com.bru.gyroboost.sensor

/**
 * Static zero-rate bias calibration for the gyroscope.
 *
 * MEMS gyros report a small non-zero angular velocity even when perfectly
 * still ("zero-rate bias"), and it varies unit to unit - a single hardcoded
 * deadzone threshold can't reliably cover every device. This measures the
 * actual bias by averaging a short burst of raw samples while the device is
 * presumed stationary, then that measured offset is subtracted from every
 * subsequent reading.
 *
 * Pure logic, no Android dependency, so it's unit-testable on its own.
 */
class GyroCalibrator(private val sampleTarget: Int = 40) {

    data class Bias(val x: Float, val y: Float)

    var bias: Bias = Bias(0f, 0f)
        private set

    var isCalibrating = false
        private set

    val progress: Float
        get() = (sampleCount.toFloat() / sampleTarget).coerceIn(0f, 1f)

    private var sumX = 0f
    private var sumY = 0f
    private var sampleCount = 0

    /** Begin a new calibration pass. Feed subsequent raw samples via [feedDuringCalibration]. */
    fun startCalibration() {
        sumX = 0f
        sumY = 0f
        sampleCount = 0
        isCalibrating = true
    }

    /** Feed a raw sample while calibrating. Returns true once this call completes calibration. */
    fun feedDuringCalibration(rawX: Float, rawY: Float): Boolean {
        if (!isCalibrating) return false
        sumX += rawX
        sumY += rawY
        sampleCount++
        if (sampleCount >= sampleTarget) {
            bias = Bias(sumX / sampleCount, sumY / sampleCount)
            isCalibrating = false
            return true
        }
        return false
    }

    /** Apply the measured bias correction to a live raw sample. */
    fun correct(rawX: Float, rawY: Float): Pair<Float, Float> = (rawX - bias.x) to (rawY - bias.y)
}
