package com.bru.gyroboost.sensor

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager

/**
 * Minimal raw-axis gyroscope source for the interactive test screen.
 *
 * Kept separate from [SensorRepository]: that class owns the long-lived
 * background keep-alive session and only reports aggregate timing stats.
 * This one is foreground-only (no wake lock, no notification), lives only
 * as long as the test screen is visible, and hands back the actual x/y/z
 * angular velocity so the UI can move a reticle with it.
 */
class GyroSampleSource(context: Context) {

    fun interface Listener {
        fun onGyroSample(x: Float, y: Float, z: Float, timestampNs: Long)
    }

    private val sensorManager =
        context.applicationContext.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private var listener: SensorEventListener? = null

    fun start(onSample: Listener) {
        stop()
        val sensor = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE) ?: return
        val newListener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {
                onSample.onGyroSample(event.values[0], event.values[1], event.values[2], event.timestamp)
            }
            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
        }
        listener = newListener
        sensorManager.registerListener(newListener, sensor, SensorManager.SENSOR_DELAY_FASTEST)
    }

    fun stop() {
        listener?.let { sensorManager.unregisterListener(it) }
        listener = null
    }
}
