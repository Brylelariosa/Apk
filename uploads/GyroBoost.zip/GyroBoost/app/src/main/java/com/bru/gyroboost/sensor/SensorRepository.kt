package com.bru.gyroboost.sensor

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager

/**
 * Owns the actual gyroscope listener registration.
 *
 * Why this helps: on Android, an idle gyroscope is power-gated by the sensor
 * HAL between uses. When a game registers its own listener "cold," the first
 * batch of readings can arrive late while the hardware spins back up - this
 * is a real, measurable contributor to perceived aim delay on cheaper SoCs.
 * Keeping one FASTEST-rate listener continuously registered prevents that
 * power-gating, so the HAL is already streaming by the time the game asks
 * for data. It cannot alter Blood Strike's own internal input smoothing.
 *
 * Falls back to the game rotation vector if no raw gyroscope is present.
 */
class SensorRepository(context: Context) {

    private val sensorManager =
        context.applicationContext.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val statsTracker = SensorStatsTracker()

    private var activeSensor: Sensor? = null

    private var listener: SensorEventListener? = null

    fun availableGyroLabel(): String {
        val gyro = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
        return if (gyro != null) {
            val minDelayMs = gyro.minDelay / 1000.0
            "${gyro.name} - hardware min interval ~${"%.1f".format(minDelayMs)} ms"
        } else {
            "No raw hardware gyroscope reported - falling back to rotation vector fusion"
        }
    }

    fun start(onUpdate: (SensorStatsTracker.Stats) -> Unit) {
        stop()
        statsTracker.reset()

        val sensor = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
            ?: sensorManager.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR)
        activeSensor = sensor ?: return

        val newListener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {
                statsTracker.onSample(event.timestamp)
                onUpdate(statsTracker.currentStats())
            }
            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
        }
        listener = newListener
        sensorManager.registerListener(newListener, sensor, SensorManager.SENSOR_DELAY_FASTEST)
    }

    fun stop() {
        listener?.let { sensorManager.unregisterListener(it) }
        listener = null
        activeSensor = null
    }
}
