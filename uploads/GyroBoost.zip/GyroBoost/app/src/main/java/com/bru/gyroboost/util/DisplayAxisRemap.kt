package com.bru.gyroboost.util

import android.view.Surface

/**
 * Remaps a raw sensor (x, y) pair - reported by TYPE_GYROSCOPE in the
 * device's fixed natural-orientation frame - into the frame of whatever
 * rotation the display is currently locked to.
 *
 * Without this, a gyroscope signal read while the screen is in landscape
 * appears rotated/reversed relative to what the person actually did with
 * the device: the sensor HAL always reports angles in natural (usually
 * portrait) orientation, regardless of the app's current screen rotation.
 *
 * No Android Context dependency beyond the Surface.ROTATION_* constants,
 * so this is trivially unit-testable in isolation.
 */
object DisplayAxisRemap {
    fun remap(rotation: Int, x: Float, y: Float): Pair<Float, Float> = when (rotation) {
        Surface.ROTATION_90 -> -y to x
        Surface.ROTATION_180 -> -x to -y
        Surface.ROTATION_270 -> y to -x
        else -> x to y // Surface.ROTATION_0
    }
}
