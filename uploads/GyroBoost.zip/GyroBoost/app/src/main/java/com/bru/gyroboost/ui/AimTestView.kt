package com.bru.gyroboost.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View

/**
 * Self-contained visual gyro responsiveness test.
 *
 * Draws a reticle that moves as the device rotates, plus a short fading
 * trail behind it - a smooth trail means low jitter/consistent timing, a
 * jagged or stepped trail means the sensor stream is stuttering. This lets
 * the person judge the keep-alive boost by feel, without Blood Strike
 * needing to be installed or running.
 *
 * Pure rendering + integration logic, no sensor registration of its own -
 * the hosting Activity feeds it samples via [applyRotation].
 */
class AimTestView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    /** Tunable feel multiplier, roughly analogous to an in-game gyro sensitivity slider. */
    var sensitivity: Float = 12f

    private var reticleX = 0f
    private var reticleY = 0f
    private val trail = ArrayDeque<Pair<Float, Float>>()
    private val maxTrailPoints = 24

    private val reticleRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00E5C7")
        style = Paint.Style.STROKE
        strokeWidth = 4f
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00E5C7")
        style = Paint.Style.FILL
    }
    private val referenceCrosshairPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#5C6673")
        strokeWidth = 2f
    }

    /** Feed one gyroscope sample. [dtSeconds] should be clamped by the caller. */
    fun applyRotation(gyroX: Float, gyroY: Float, dtSeconds: Float) {
        if (width == 0 || height == 0) return

        reticleX -= gyroY * sensitivity * dtSeconds * 40f
        reticleY -= gyroX * sensitivity * dtSeconds * 40f

        val halfW = width / 2.2f
        val halfH = height / 2.2f
        reticleX = reticleX.coerceIn(-halfW, halfW)
        reticleY = reticleY.coerceIn(-halfH, halfH)

        trail.addLast(reticleX to reticleY)
        if (trail.size > maxTrailPoints) trail.removeFirst()

        postInvalidateOnAnimation()
    }

    fun recenter() {
        reticleX = 0f
        reticleY = 0f
        trail.clear()
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val centerX = width / 2f
        val centerY = height / 2f

        canvas.drawLine(centerX - 22, centerY, centerX + 22, centerY, referenceCrosshairPaint)
        canvas.drawLine(centerX, centerY - 22, centerX, centerY + 22, referenceCrosshairPaint)

        trail.forEachIndexed { index, (tx, ty) ->
            dotPaint.alpha = ((index + 1).toFloat() / trail.size * 120).toInt()
            canvas.drawCircle(centerX + tx, centerY + ty, 5f, dotPaint)
        }

        canvas.drawCircle(centerX + reticleX, centerY + reticleY, 26f, reticleRingPaint)
        dotPaint.alpha = 255
        canvas.drawCircle(centerX + reticleX, centerY + reticleY, 4f, dotPaint)
    }
}
