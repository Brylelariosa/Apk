package com.bru.gyroboost

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.bru.gyroboost.databinding.ActivityMainBinding
import com.bru.gyroboost.service.SensorKeepAliveService
import com.bru.gyroboost.sensor.SensorRepository
import com.bru.gyroboost.ui.GyroTestActivity
import com.bru.gyroboost.util.AppShortcuts
import kotlinx.coroutines.launch

// ComponentActivity (not AppCompatActivity): this app has no need for
// AppCompat's compatibility shims at minSdk 24, and skipping it keeps the
// APK meaningfully smaller. See app/build.gradle for the full rationale.
class MainActivity : ComponentActivity() {

    private lateinit var binding: ActivityMainBinding

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted || Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
                startKeepAlive()
            } else {
                binding.switchKeepAlive.isChecked = false
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.textGyroInfo.text = SensorRepository(this).availableGyroLabel()

        binding.switchKeepAlive.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) requestPermissionAndStart() else stopKeepAlive()
        }

        binding.buttonOpenTest.setOnClickListener {
            startActivity(Intent(this, GyroTestActivity::class.java))
        }

        binding.buttonBatteryExempt.setOnClickListener {
            AppShortcuts.requestIgnoreBatteryOptimizations(this)
        }

        binding.buttonBloodStrikeSettings.setOnClickListener {
            AppShortcuts.openAppSettings(this, AppShortcuts.BLOOD_STRIKE_PACKAGE)
        }

        if (!AppShortcuts.isPackageInstalled(this, AppShortcuts.BLOOD_STRIKE_PACKAGE)) {
            binding.buttonBloodStrikeSettings.isEnabled = false
            binding.buttonBloodStrikeSettings.text = getString(R.string.blood_strike_not_installed)
        }

        observeServiceState()
    }

    private fun requestPermissionAndStart() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            startKeepAlive()
        }
    }

    private fun startKeepAlive() {
        SensorKeepAliveService.start(this)
        binding.textStatus.text = getString(R.string.status_warming_up)
    }

    private fun stopKeepAlive() {
        SensorKeepAliveService.stop(this)
        binding.textStatus.text = getString(R.string.status_inactive)
        binding.textStats.text = ""
    }

    private fun observeServiceState() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                SensorKeepAliveService.state.collect { stats ->
                    if (stats == null || stats.sampleCount == 0) return@collect
                    binding.textStatus.text = getString(R.string.status_active)
                    binding.textStats.text = getString(
                        R.string.stats_format,
                        stats.estimatedHz,
                        stats.avgIntervalMs,
                        stats.jitterMs,
                        stats.sampleCount
                    )
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Reflect keep-alive state in case it was toggled from the test screen.
        binding.switchKeepAlive.setOnCheckedChangeListener(null)
        binding.switchKeepAlive.isChecked = SensorKeepAliveService.isRunning.value
        binding.switchKeepAlive.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) requestPermissionAndStart() else stopKeepAlive()
        }
    }
}
