package com.bru.gyroboost.sensor

/**
 * Tracks inter-sample intervals for a stream of SensorEvent timestamps and
 * derives live rate + jitter statistics.
 *
 * Deliberately has no Android dependency (just takes raw nanosecond
 * timestamps) so it can be unit tested and reused for any sensor stream,
 * not just the gyroscope.
 */
class SensorStatsTracker(private val windowSize: Int = 50) {

    data class Stats(
        val sampleCount: Int,
        val avgIntervalMs: Double,
        val jitterMs: Double,
        val estimatedHz: Double
    )

    private val intervalsNs = ArrayDeque<Long>(windowSize)
    private var lastTimestampNs: Long? = null

    fun reset() {
        intervalsNs.clear()
        lastTimestampNs = null
    }

    /** Feed the next SensorEvent.timestamp (monotonic nanoseconds). */
    fun onSample(timestampNs: Long) {
        lastTimestampNs?.let { prev ->
            val delta = timestampNs - prev
            if (delta > 0) {
                if (intervalsNs.size >= windowSize) intervalsNs.removeFirst()
                intervalsNs.addLast(delta)
            }
        }
        lastTimestampNs = timestampNs
    }

    fun currentStats(): Stats {
        if (intervalsNs.isEmpty()) return Stats(0, 0.0, 0.0, 0.0)
        val avgNs = intervalsNs.average()
        val varianceNs = intervalsNs.sumOf { (it - avgNs) * (it - avgNs) } / intervalsNs.size
        val stdDevNs = kotlin.math.sqrt(varianceNs)
        val avgMs = avgNs / 1_000_000.0
        val jitterMs = stdDevNs / 1_000_000.0
        val hz = if (avgMs > 0) 1000.0 / avgMs else 0.0
        return Stats(intervalsNs.size, avgMs, jitterMs, hz)
    }
}
