package com.bru.gyroboost.ui

import android.os.Build
import android.os.Bundle
import android.view.Surface
import androidx.activity.ComponentActivity
import com.bru.gyroboost.R
import com.bru.gyroboost.databinding.ActivityGyroTestBinding
import com.bru.gyroboost.sensor.GyroSampleSource
import com.bru.gyroboost.sensor.SensorStatsTracker
import com.bru.gyroboost.service.SensorKeepAliveService
import com.bru.gyroboost.util.DisplayAxisRemap

/**
 * Standalone test screen: a live reticle driven directly by the gyroscope,
 * with an in-screen toggle for the keep-alive boost so it can be A/B
 * compared without ever leaving the app or opening Blood Strike.
 */
class GyroTestActivity : ComponentActivity() {

    private lateinit var binding: ActivityGyroTestBinding
    private lateinit var gyroSource: GyroSampleSource
    private val statsTracker = SensorStatsTracker()
    private var lastTimestampNs = 0L
    private var rotation = Surface.ROTATION_0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGyroTestBinding.inflate(layoutInflater)
        setContentView(binding.root)

        gyroSource = GyroSampleSource(this)

        binding.switchBoostDuringTest.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) SensorKeepAliveService.start(this) else SensorKeepAliveService.stop(this)
        }

        binding.buttonRecenter.setOnClickListener {
            binding.aimTestView.recenter()
        }
    }

    override fun onResume() {
        super.onResume()
        binding.switchBoostDuringTest.setOnCheckedChangeListener(null)
        binding.switchBoostDuringTest.isChecked = SensorKeepAliveService.isRunning.value
        binding.switchBoostDuringTest.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) SensorKeepAliveService.start(this) else SensorKeepAliveService.stop(this)
        }

        statsTracker.reset()
        lastTimestampNs = 0L
        // Screen is orientation-locked (see manifest), so this is stable for
        // the whole session - no need to re-check it per sample.
        rotation = currentRotation()

        gyroSource.start { x, y, _, timestampNs ->
            val dt = if (lastTimestampNs == 0L) 0f else (timestampNs - lastTimestampNs) / 1_000_000_000f
            lastTimestampNs = timestampNs

            statsTracker.onSample(timestampNs)
            val (rx, ry) = DisplayAxisRemap.remap(rotation, x, y)
            binding.aimTestView.applyRotation(rx, ry, dt.coerceIn(0f, 0.1f))

            val stats = statsTracker.currentStats()
            if (stats.sampleCount > 0) {
                binding.textTestStats.text = getString(
                    R.string.stats_format,
                    stats.estimatedHz,
                    stats.avgIntervalMs,
                    stats.jitterMs,
                    stats.sampleCount
                )
            }
        }
    }

    private fun currentRotation(): Int = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        display?.rotation ?: Surface.ROTATION_0
    } else {
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.rotation
    }

    override fun onPause() {
        super.onPause()
        // Only the raw-axis test listener stops here; the keep-alive service
        // (if the person left the switch on) keeps running independently.
        gyroSource.stop()
    }
}
