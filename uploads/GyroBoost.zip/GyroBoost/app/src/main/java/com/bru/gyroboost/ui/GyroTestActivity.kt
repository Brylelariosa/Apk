package com.bru.gyroboost.ui

import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.view.Surface
import androidx.activity.ComponentActivity
import com.bru.gyroboost.R
import com.bru.gyroboost.databinding.ActivityGyroTestBinding
import com.bru.gyroboost.sensor.GyroCalibrator
import com.bru.gyroboost.sensor.GyroSampleSource
import com.bru.gyroboost.sensor.SensorStatsTracker
import com.bru.gyroboost.service.SensorKeepAliveService
import com.bru.gyroboost.util.DisplayAxisRemap

/**
 * Standalone test screen: a live reticle driven directly by the gyroscope,
 * with an in-screen toggle for the keep-alive boost so it can be A/B
 * compared without ever leaving the app or opening Blood Strike.
 */
class GyroTestActivity : ComponentActivity() {

    private lateinit var binding: ActivityGyroTestBinding
    private lateinit var gyroSource: GyroSampleSource
    private val statsTracker = SensorStatsTracker()
    private val calibrator = GyroCalibrator()
    private var lastTimestampNs = 0L
    private var rotation = Surface.ROTATION_0
    private var statsTextHoldUntilMs = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGyroTestBinding.inflate(layoutInflater)
        setContentView(binding.root)

        gyroSource = GyroSampleSource(this)

        binding.switchBoostDuringTest.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) SensorKeepAliveService.start(this) else SensorKeepAliveService.stop(this)
        }

        binding.buttonRecenter.setOnClickListener {
            binding.aimTestView.recenter()
        }

        binding.buttonCalibrate.setOnClickListener {
            beginCalibration()
        }
    }

    override fun onResume() {
        super.onResume()
        binding.switchBoostDuringTest.setOnCheckedChangeListener(null)
        binding.switchBoostDuringTest.isChecked = SensorKeepAliveService.isRunning.value
        binding.switchBoostDuringTest.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) SensorKeepAliveService.start(this) else SensorKeepAliveService.stop(this)
        }

        // Screen is orientation-locked (see manifest), so this is stable for
        // the whole session - no need to re-check it per sample.
        rotation = currentRotation()

        gyroSource.start { x, y, _, timestampNs -> onGyroSample(x, y, timestampNs) }
        beginCalibration()
    }

    /** Auto-runs on entry, and can be re-triggered any time via the Calibrate
     *  button - useful if you picked the phone up differently or drift creeps
     *  back in later. Assumes the phone is held still while this runs. */
    private fun beginCalibration() {
        binding.aimTestView.recenter()
        calibrator.startCalibration()
        binding.textTestStats.text = getString(R.string.calibrating_status, 0)
    }

    private fun onGyroSample(rawX: Float, rawY: Float, timestampNs: Long) {
        if (calibrator.isCalibrating) {
            val justFinished = calibrator.feedDuringCalibration(rawX, rawY)
            if (justFinished) {
                statsTracker.reset()
                lastTimestampNs = 0L
                binding.textTestStats.text =
                    getString(R.string.calibrated_status, calibrator.bias.x, calibrator.bias.y)
                statsTextHoldUntilMs = SystemClock.elapsedRealtime() + 900
            } else {
                binding.textTestStats.text =
                    getString(R.string.calibrating_status, (calibrator.progress * 100).toInt())
            }
            return
        }

        val dt = if (lastTimestampNs == 0L) 0f else (timestampNs - lastTimestampNs) / 1_000_000_000f
        lastTimestampNs = timestampNs
        statsTracker.onSample(timestampNs)

        val (correctedX, correctedY) = calibrator.correct(rawX, rawY)
        val (rx, ry) = DisplayAxisRemap.remap(rotation, correctedX, correctedY)
        binding.aimTestView.applyRotation(rx, ry, dt.coerceIn(0f, 0.1f))

        val stats = statsTracker.currentStats()
        if (stats.sampleCount > 0 && SystemClock.elapsedRealtime() >= statsTextHoldUntilMs) {
            binding.textTestStats.text = getString(
                R.string.stats_format,
                stats.estimatedHz,
                stats.avgIntervalMs,
                stats.jitterMs,
                stats.sampleCount
            )
        }
    }

    private fun currentRotation(): Int = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        display?.rotation ?: Surface.ROTATION_0
    } else {
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.rotation
    }

    override fun onPause() {
        super.onPause()
        // Only the raw-axis test listener stops here; the keep-alive service
        // (if the person left the switch on) keeps running independently.
        gyroSource.stop()
    }
}
