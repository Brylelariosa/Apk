# GyroBoost uses no reflection-based libraries, so the defaults are sufficient.
-keepattributes *Annotation*
