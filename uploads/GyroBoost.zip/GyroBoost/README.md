# GyroBoost

A gyroscope keep-alive + XOS background-restriction shortcut app, built for
reducing perceived gyro aim delay in Blood Strike (`com.netease.newspike`)
on the Infinix HOT 11 - plus a standalone test screen so you can judge it
without opening Blood Strike at all.

## What it actually does

1. **Sensor keep-alive (foreground service).** Registers a `SENSOR_DELAY_FASTEST`
   gyroscope listener continuously, so the sensor HAL never power-gates the
   gyro between uses. On Android 12+, background apps are also throttled to
   a slow default sensor rate unless they're running a foreground service -
   this app deliberately uses one so the listener stays at full rate.
2. **Standalone gyro test screen.** A landscape reticle test (matching how
   Blood Strike is actually played) with a fading trail so jitter/stutter is
   visible directly, live Hz/jitter numbers, and its own keep-alive toggle -
   so you can A/B compare boost on vs off without touching Blood Strike.
3. **Live diagnostics** on the main screen too: real measured sample rate,
   interval, and jitter - not a placebo "boosted!" message.
4. **One-tap shortcuts** into the App Info screens that matter most on XOS:
   battery-optimization exemption for GyroBoost itself, and Blood Strike's
   own app settings.

## What it can't do

It cannot patch or hook Blood Strike's own aim-smoothing code - that app is
closed-source, and a normal (non-root) Android app has no access to another
app's internals. If you're ever rooted and want an Xposed/LSPosed module
that hooks the game's own sensor registration directly, that's a different,
riskier project - just say the word.

## APK size

Audited and trimmed the dependency graph - three libraries were declared
but never actually used, plus AppCompat/Material were heavier than this UI
needs:

| Removed | Why |
|---|---|
| `androidx.constraintlayout` | Nothing in the project used it - plain `LinearLayout`/`FrameLayout` cover every screen. |
| `com.google.android.material` | `MaterialCardView`/`MaterialButton`/`SwitchMaterial` replaced with plain views + `drawable/bg_*.xml` shape drawables - identical look, zero library weight. |
| `androidx.appcompat` | `MainActivity`/`GyroTestActivity` now extend `ComponentActivity` directly; a plain `android:Theme.Material.NoActionBar` covers dark theming and ripples at minSdk 24 without AppCompat's compat-shim classes and per-locale string tables. |
| `androidx.lifecycle:lifecycle-service` | Dead weight - `SensorKeepAliveService` extends plain `Service`, not `LifecycleService`. |

Also: `buildConfig false` (no `BuildConfig` class generated, since it's
never referenced), and `minifyEnabled` + `shrinkResources` were already on
for release builds.

## Build

Zip this whole folder (keeping `GyroBoost/` as the root containing
`settings.gradle`) and upload it through ZipApkBuilder as usual. No native/
NDK code is used, so the existing NDK/CMake cache steps in the CI workflow
are simply no-ops for this project.

## In-app checklist (also shown in the app)

- Blood Strike → App Info → Battery: **Unrestricted**, Autostart: **on**
- Settings → Battery → Power Manager → turn off **Deep/Intelligent Optimization**
  for both apps (XOS can throttle even individually-excluded apps otherwise)
- Settings → Games/Xarena → Game Mode → **Extreme Performance**
- Turn the keep-alive switch on *before* launching Blood Strike, not after
