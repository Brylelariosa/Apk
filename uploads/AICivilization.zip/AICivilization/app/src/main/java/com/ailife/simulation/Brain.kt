package com.ailife.simulation

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

object Brain {

    fun decideGoal(e: Entity, world: World, tick: Long): Goal {
        if (!e.isAlive) return Goal.IDLE

        // ── Survival ──────────────────────────────────────────────────────
        if (e.thirst > 0.78f || (e.thirst > 0.50f && e.water == 0)) return Goal.SEEK_WATER
        if (e.hunger > 0.82f || (e.hunger > 0.58f && e.food  == 0)) return Goal.SEEK_FOOD
        if (e.health < 0.22f || e.energy < 0.12f)                   return Goal.REST

        // ── Threats ───────────────────────────────────────────────────────
        if (hasThreat(e, world)) return Goal.FLEE

        // ── Moderate needs ────────────────────────────────────────────────
        if (e.thirst > 0.42f && e.water < 2) return Goal.SEEK_WATER
        if (e.hunger > 0.45f && e.food  < 2) return Goal.SEEK_FOOD

        // ── Activities (adult only) ───────────────────────────────────────
        if (e.isAdult) {
            // Hunting — if knows hunting and animals nearby
            if (e.hunger > 0.30f && KnowledgeType.HUNTING in e.knowledge) {
                val prey = world.landAnimalCache
                    .minByOrNull { e.distanceTo(it.x, it.y) }
                if (prey != null && e.distanceTo(prey.x, prey.y) < 22f)
                    return Goal.HUNT
            }

            // Fishing — near water and hungry
            if (e.hunger > 0.25f && world.isNearWater(e.x, e.y) && Random.nextFloat() < 0.4f)
                return Goal.FISH

            // Chop wood — low on wood and forest nearby
            if (e.wood < 2 && Random.nextFloat() < 0.35f) {
                val f = world.nearestForest(e.x, e.y, 18)
                if (f != null) return Goal.CHOP_WOOD
            }

            // Build — civ has an unfinished building within range
            if (e.civId >= 0 && Random.nextFloat() < 0.20f) {
                val site = world.buildings
                    .filter { !it.isComplete && it.civId == e.civId }
                    .minByOrNull { e.distanceTo(it.worldX, it.worldY) }
                if (site != null && e.distanceTo(site.worldX, site.worldY) < 30f)
                    return Goal.BUILD
            }
        }

        // ── Social / reproduction ─────────────────────────────────────────
        if (e.isAdult && e.canReproduce(tick) && Random.nextFloat() < 0.25f)
            return Goal.SEEK_MATE

        // ── Knowledge sharing ─────────────────────────────────────────────
        if (e.isAdult && e.knowledge.size > 2 && Random.nextFloat() < 0.15f)
            return Goal.TEACH

        // ── General gather ────────────────────────────────────────────────
        if (e.food < 4 || e.water < 4) return Goal.GATHER

        // ── Explore ───────────────────────────────────────────────────────
        if (e.isCurious && Random.nextFloat() < 0.35f) return Goal.EXPLORE

        return Goal.IDLE
    }

    fun updateMovement(e: Entity, world: World, tick: Long) {
        val dist = e.distanceTo(e.targetX, e.targetY)
        if (dist > 0.25f) {
            val speed = e.dna.moveSpeed * world.moveCost(e.x, e.y)
            val step  = minOf(speed, dist)
            val nx = e.x + (e.targetX - e.x) / dist * step
            val ny = e.y + (e.targetY - e.y) / dist * step
            if (!world.isWater(nx.toInt(), ny.toInt())) {
                e.x = nx.coerceIn(0f, world.width  - 1f)
                e.y = ny.coerceIn(0f, world.height - 1f)
            }
        } else {
            pickTarget(e, world, tick)
        }
    }

    // ── Target pickers ────────────────────────────────────────────────────────

    private fun pickTarget(e: Entity, world: World, tick: Long) {
        when (e.currentGoal) {

            Goal.SEEK_WATER -> {
                val w = world.nearestWater(e.x, e.y, 35)
                if (w != null) { e.targetX = w.first.toFloat(); e.targetY = w.second.toFloat() }
                else wander(e, world, 8f)
            }

            Goal.SEEK_FOOD -> {
                if (e.food > 0) { e.food--; e.hunger = (e.hunger - 0.32f).coerceAtLeast(0f); wander(e, world, 4f) }
                else {
                    val f = world.nearestFood(e.x, e.y, 35)
                    if (f != null) { e.targetX = f.first.toFloat(); e.targetY = f.second.toFloat() }
                    else wander(e, world, 10f)
                }
            }

            Goal.GATHER -> {
                val r = world.nearestResource(e.x, e.y, 20)
                if (r != null) { e.targetX = r.first.toFloat(); e.targetY = r.second.toFloat() }
                else wander(e, world, 6f)
            }

            Goal.EXPLORE -> wander(e, world, if (e.dna.riskTaking > 0.5f) 22f else 11f)

            Goal.SEEK_MATE -> {
                val mate = world.getNearby(e.x, e.y, 16f)
                    .filter { o -> o.id != e.id && o.isAlive && o.gender != e.gender &&
                                   o.isAdult && o.canReproduce(tick) &&
                                   (o.civId == e.civId || e.dna.socialBehavior > 0.72f) }
                    .minByOrNull { e.distanceTo(it) }
                if (mate != null) { e.targetX = mate.x; e.targetY = mate.y; e.targetEntityId = mate.id }
                else wander(e, world, 12f)
            }

            Goal.TEACH -> {
                val student = world.getNearby(e.x, e.y, 10f)
                    .filter { o -> o.id != e.id && o.isAlive && o.isAdult && (o.civId == e.civId || e.isSocial) }
                    .minByOrNull { e.distanceTo(it) }
                if (student != null) { e.targetX = student.x; e.targetY = student.y; e.targetEntityId = student.id }
                else { e.currentGoal = Goal.IDLE; wander(e, world, 3f) }
            }

            Goal.FLEE -> {
                val threats = world.getNearby(e.x, e.y, 7f)
                    .filter { it.id != e.id && it.isAggressive && it.civId != e.civId }
                if (threats.isEmpty()) { wander(e, world, 5f); return }
                val atx = threats.map { it.x }.average().toFloat()
                val aty = threats.map { it.y }.average().toFloat()
                e.targetX = (e.x + (e.x - atx) * 3f).coerceIn(1f, world.width  - 2f)
                e.targetY = (e.y + (e.y - aty) * 3f).coerceIn(1f, world.height - 2f)
            }

            Goal.REST -> {
                e.energy = (e.energy + 0.12f).coerceAtMost(1f)
                e.health = (e.health + 0.025f).coerceAtMost(1f)
                e.targetX = e.x; e.targetY = e.y
            }

            Goal.HUNT -> {
                val prey = world.landAnimalCache
                    .minByOrNull { e.distanceTo(it.x, it.y) }
                if (prey != null) { e.targetX = prey.x; e.targetY = prey.y }
                else { e.currentGoal = Goal.IDLE; wander(e, world, 5f) }
            }

            Goal.FISH -> {
                // Move to nearest water edge
                val w = world.nearestWater(e.x, e.y, 20)
                if (w != null) { e.targetX = w.first.toFloat(); e.targetY = w.second.toFloat() }
                else { e.currentGoal = Goal.GATHER; wander(e, world, 5f) }
            }

            Goal.CHOP_WOOD -> {
                val f = world.nearestForest(e.x, e.y, 18)
                if (f != null) { e.targetX = f.first.toFloat(); e.targetY = f.second.toFloat() }
                else { e.currentGoal = Goal.IDLE; wander(e, world, 4f) }
            }

            Goal.BUILD -> {
                val site = world.buildings
                    .filter { !it.isComplete && it.civId == e.civId }
                    .minByOrNull { e.distanceTo(it.worldX, it.worldY) }
                if (site != null) { e.targetX = site.worldX; e.targetY = site.worldY }
                else { e.currentGoal = Goal.IDLE; wander(e, world, 4f) }
            }

            Goal.IDLE -> {
                if (e.idleTicksLeft <= 0) { wander(e, world, 3f); e.idleTicksLeft = 2 + Random.nextInt(6) }
                else e.idleTicksLeft--
            }

            Goal.ATTACK, Goal.SOCIALIZE -> wander(e, world, 4f)
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private fun hasThreat(e: Entity, world: World): Boolean {
        if (e.isAggressive) return false
        // Wolves nearby — use cached land list (updated every 3 ticks, wolves are land animals)
        val nearWolf = world.landAnimalCache
            .any { it.type == AnimalType.WOLF && e.distanceTo(it.x, it.y) < 5f }
        if (nearWolf) return true
        // Hostile entities
        return world.getNearby(e.x, e.y, 6f).any { o ->
            o.id != e.id && o.isAggressive && o.civId != e.civId &&
            (e.relationships[o.id] ?: 0f) < -0.2f
        }
    }

    private fun wander(e: Entity, world: World, radius: Float) {
        repeat(10) {
            val angle = Random.nextDouble() * 2.0 * PI
            val dist  = Random.nextFloat() * radius
            val nx = (e.x + cos(angle).toFloat() * dist).coerceIn(1f, world.width  - 2f)
            val ny = (e.y + sin(angle).toFloat() * dist).coerceIn(1f, world.height - 2f)
            if (!world.isWater(nx.toInt(), ny.toInt())) { e.targetX = nx; e.targetY = ny; return }
        }
        e.targetX = e.x; e.targetY = e.y
    }
}
