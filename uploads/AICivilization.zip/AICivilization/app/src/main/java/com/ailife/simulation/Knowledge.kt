package com.ailife.simulation

/**
 * Every technology an entity or civilization can discover.
 * Knowledge is NOT global — it belongs to individuals and spreads through
 * teaching, observation, and books. If the last carrier dies, it can be lost.
 */
enum class KnowledgeType(
    val displayName: String,
    val description: String,
    val prerequisites: List<KnowledgeType> = emptyList(),
    val era: Int = 0          // 0 prehistoric · 1 ancient · 2 classical · 3 medieval · 4 industrial · 5 modern
) {
    // ── Era 0 : Prehistoric ───────────────────────────────────────────────
    LANGUAGE(
        "Language", "Spoken communication between individuals", era = 0
    ),
    STONE_TOOLS(
        "Stone Tools", "Craft basic implements from knapped stone", era = 0
    ),
    FIRE(
        "Fire", "Control and sustain combustion for warmth and cooking", era = 0
    ),

    // ── Era 1 : Ancient ───────────────────────────────────────────────────
    COOKING(
        "Cooking", "Prepare food with heat, improving nutrition",
        listOf(FIRE), era = 1
    ),
    HUNTING(
        "Hunting", "Organised pursuit and trapping of animals",
        listOf(STONE_TOOLS), era = 1
    ),
    POTTERY(
        "Pottery", "Fire clay into durable vessels for storage",
        listOf(FIRE), era = 1
    ),
    FARMING(
        "Farming", "Cultivate and harvest crops instead of foraging",
        listOf(COOKING, STONE_TOOLS), era = 1
    ),
    ANIMAL_HUSBANDRY(
        "Animal Husbandry", "Domesticate and breed animals",
        listOf(HUNTING, FARMING), era = 1
    ),
    SAILING(
        "Sailing", "Navigate rivers and coastal waters by boat",
        listOf(STONE_TOOLS, HUNTING), era = 1
    ),

    // ── Era 2 : Classical ─────────────────────────────────────────────────
    WRITING(
        "Writing", "Record information symbolically on durable surfaces",
        listOf(FARMING, LANGUAGE), era = 2
    ),
    MEDICINE(
        "Herbal Medicine", "Use plants to treat wounds and illness",
        listOf(FARMING, COOKING), era = 2
    ),
    METALLURGY(
        "Metallurgy", "Smelt ore and work metals into tools and weapons",
        listOf(FIRE, STONE_TOOLS), era = 2
    ),
    MATHEMATICS(
        "Mathematics", "Abstract numerical reasoning and geometry",
        listOf(WRITING), era = 2
    ),
    ARCHITECTURE(
        "Architecture", "Design and construct large permanent structures",
        listOf(METALLURGY, WRITING), era = 2
    ),

    // ── Era 3 : Medieval ─────────────────────────────────────────────────
    ASTRONOMY(
        "Astronomy", "Study celestial bodies to navigate and predict seasons",
        listOf(MATHEMATICS, WRITING), era = 3
    ),
    PRINTING(
        "Printing Press", "Reproduce written works at scale, preserving knowledge",
        listOf(METALLURGY, WRITING), era = 3
    ),
    GUNPOWDER(
        "Gunpowder", "Harness explosive chemical reactions as a weapon",
        listOf(METALLURGY, MATHEMATICS), era = 3
    ),
    OPTICS(
        "Optics", "Grind lenses to extend vision and study the heavens",
        listOf(MATHEMATICS, METALLURGY), era = 3
    ),

    // ── Era 4 : Industrial ───────────────────────────────────────────────
    SCIENTIFIC_METHOD(
        "Scientific Method", "Systematic hypothesis, experiment, and verification",
        listOf(ASTRONOMY, MATHEMATICS, PRINTING), era = 4
    ),
    STEAM_POWER(
        "Steam Power", "Convert heat into mechanical work at scale",
        listOf(METALLURGY, MATHEMATICS), era = 4
    ),
    GERM_THEORY(
        "Germ Theory", "Understand that microorganisms cause disease",
        listOf(MEDICINE, OPTICS, SCIENTIFIC_METHOD), era = 4
    ),

    // ── Era 5 : Modern ────────────────────────────────────────────────────
    ELECTRICITY(
        "Electricity", "Harness and transmit electrical power",
        listOf(MATHEMATICS, STEAM_POWER, SCIENTIFIC_METHOD), era = 5
    ),
    VACCINES(
        "Vaccines", "Prevent disease through controlled immune priming",
        listOf(GERM_THEORY, SCIENTIFIC_METHOD), era = 5
    ),
    COMPUTERS(
        "Computers", "Programmable calculating machines",
        listOf(ELECTRICITY, MATHEMATICS), era = 5
    );

    /** True if all prerequisite knowledge is already held */
    fun canLearn(known: Set<KnowledgeType>): Boolean = prerequisites.all { it in known }

    val eraLabel: String get() = arrayOf(
        "Prehistoric", "Ancient", "Classical", "Medieval", "Industrial", "Modern"
    ).getOrElse(era) { "Unknown" }

    companion object {
        /** Cached to avoid re-allocating the array on every tryInvent call */
        val ALL: Array<KnowledgeType> = values()
    }
}
