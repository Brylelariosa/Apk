package com.ailife

import android.os.Bundle
import android.widget.Button
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.ailife.databinding.ActivityMainBinding
import com.ailife.simulation.*
import com.google.android.material.tabs.TabLayout
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val vm: SimViewModel by viewModels()

    private var currentTab    = 0
    private var worldCentered = false
    private var latestState: SimState? = null
    private var selectedEntity: Entity? = null

    private val speedBtns   get() = listOf(binding.btnPause, binding.btnSlow, binding.btnNormal, binding.btnFast, binding.btnUltra)
    private val speedValues = SimSpeed.values()

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setupSpeedButtons()
        setupTabs()
        setupWorldView()
        observeState()
        observeSelection()
        // Marquee ticker needs focus
        binding.tvTicker.isSelected = true
    }

    override fun onStop()  { super.onStop();  vm.setSpeed(SimSpeed.PAUSED) }
    override fun onStart() { super.onStart(); vm.setSpeed(SimSpeed.NORMAL) }

    // ── Speed buttons ─────────────────────────────────────────────────────────

    private fun setupSpeedButtons() {
        binding.btnPause .setOnClickListener { applySpeed(SimSpeed.PAUSED) }
        binding.btnSlow  .setOnClickListener { applySpeed(SimSpeed.SLOW)   }
        binding.btnNormal.setOnClickListener { applySpeed(SimSpeed.NORMAL) }
        binding.btnFast  .setOnClickListener { applySpeed(SimSpeed.FAST)   }
        binding.btnUltra .setOnClickListener { applySpeed(SimSpeed.ULTRA)  }
        selectSpeedButton(SimSpeed.NORMAL)
    }

    private fun applySpeed(s: SimSpeed) { vm.setSpeed(s); selectSpeedButton(s) }

    /** Drive the drawable selector state so the selected button glows */
    private fun selectSpeedButton(s: SimSpeed) {
        speedBtns.forEachIndexed { i, btn ->
            btn.isSelected = speedValues[i] == s
        }
    }

    // ── Tabs ──────────────────────────────────────────────────────────────────

    private fun setupTabs() {
        listOf("World", "Civs", "History", "Entity").forEach {
            binding.tabLayout.addTab(binding.tabLayout.newTab().setText(it))
        }
        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(t: TabLayout.Tab)   { currentTab = t.position; refreshInfo() }
            override fun onTabUnselected(t: TabLayout.Tab) {}
            override fun onTabReselected(t: TabLayout.Tab) {}
        })
    }

    // ── World view ────────────────────────────────────────────────────────────

    private fun setupWorldView() {
        binding.worldView.onTileClick = { wx, wy -> vm.selectAt(wx, wy) }
    }

    // ── State observation ─────────────────────────────────────────────────────

    private fun observeState() {
        lifecycleScope.launch {
            vm.simState.filterNotNull().collect { state ->
                latestState = state
                binding.worldView.setWorld(state.world, hud1(state), hud2(state), alert(state))
                binding.tvYear.text = "Year  ${state.stats.year}"
                updateTicker(state)
                if (!worldCentered) {
                    worldCentered = true
                    binding.worldView.post { binding.worldView.centerOnWorld(state.world) }
                }
                refreshInfo()
            }
        }
    }

    private fun observeSelection() {
        lifecycleScope.launch {
            vm.selected.collect { entity ->
                selectedEntity = entity
                binding.worldView.setSelected(entity?.id ?: -1)
                if (entity != null) binding.tabLayout.getTabAt(3)?.select()
                refreshInfo()
            }
        }
    }

    // ── Ticker ────────────────────────────────────────────────────────────────

    private fun updateTicker(s: SimState) {
        val ev = s.world.history.getRecentEvents(1).firstOrNull()
        if (ev != null) {
            val icon = when (ev.type) {
                EventType.WAR               -> "⚔"
                EventType.INVENTION         -> "💡"
                EventType.CIVILIZATION_FORMED -> "🏛"
                EventType.EXTINCTION        -> "☠"
                EventType.DISEASE           -> "⚕"
                EventType.DISASTER          -> "🌪"
                EventType.DISCOVERY         -> "⭐"
                EventType.ECONOMIC          -> "📊"
                else -> "▸"
            }
            binding.tvTicker.text = "$icon  [Year ${ev.year}]  ${ev.title}  —  ${ev.description}"
        }
    }

    // ── Info panel refresh ────────────────────────────────────────────────────

    private fun refreshInfo() {
        val s = latestState ?: return
        binding.tvInfo.text = when (currentTab) {
            0 -> worldTab(s)
            1 -> civsTab(s)
            2 -> historyTab(s)
            3 -> entityTab(s)
            else -> ""
        }
    }

    // ── Tab content builders ──────────────────────────────────────────────────

    private fun worldTab(s: SimState) = buildString {
        val st = s.stats
        appendLine("Population  ${pad(st.population, 5)}    Civilisations  ${st.civilizations}")
        appendLine("Born total  ${pad(st.totalBorn, 5)}    Deaths         ${st.totalDied}")
        appendLine("Avg age     ${"%.1f".format(st.avgAge)}        Avg intel      ${"%.2f".format(st.avgIntelligence)}")
        appendLine("Known tech  ${st.knowledgeTypeCount} types      Highest era    ${st.advancedEra}")
        appendLine()
        appendLine("Season      ${s.world.weather.seasonName}       ${s.world.weather.description()}")
        appendLine()
        appendLine("── Economy ───────────────────────────────")
        s.world.economy.commodities.forEach { c ->
            appendLine("  ${c.key.padEnd(6)}  ${"%.2f".format(c.price).padStart(5)}g   supply ${c.totalSupply}")
        }
        val diseases = s.world.disease.active
        if (diseases.isNotEmpty()) {
            appendLine()
            appendLine("── Active Diseases ───────────────────────")
            diseases.forEach { d ->
                val infected = s.world.entities.count { it.diseaseId == d.id }
                appendLine("  ${d.name}  (${infected} infected,  severity ${"%.0f".format(d.severity*100)}%)")
            }
        }
    }

    private fun civsTab(s: SimState) = buildString {
        val live = s.world.civilizations.filter { !it.isExtinct }.sortedByDescending { it.population }
        if (live.isEmpty()) {
            appendLine("No civilisations yet.")
            appendLine("Entities form tribes when social beings cluster and bond.")
        } else {
            live.take(8).forEach { civ ->
                appendLine("▶ ${civ.name}")
                appendLine("  ${civ.getEraName()}  ·  ${civ.government.label}  ·  Pop ${civ.population}")
                appendLine("  Tech ${civ.knowledge.size} types  ·  Language drift ${"%.1f".format(civ.languageDrift*100)}%")
                appendLine()
            }
        }
        val dead = s.world.civilizations.count { it.isExtinct }
        if (dead > 0) appendLine("☠  Extinct: $dead civilisation(s)")
    }

    private fun historyTab(s: SimState) = buildString {
        val events = s.world.history.getRecentEvents(20)
        if (events.isEmpty()) {
            appendLine("History is being written…")
        } else {
            events.forEach { ev ->
                val icon = when (ev.type) {
                    EventType.WAR               -> "⚔ "
                    EventType.INVENTION         -> "💡 "
                    EventType.CIVILIZATION_FORMED -> "🏛 "
                    EventType.EXTINCTION        -> "☠ "
                    EventType.DISEASE           -> "⚕ "
                    EventType.DISASTER          -> "🌪 "
                    EventType.DISCOVERY         -> "⭐ "
                    else -> "▸  "
                }
                appendLine("$icon[${ev.year}] ${ev.title}")
            }
        }
    }

    private fun entityTab(s: SimState) = buildString {
        val e = selectedEntity
        if (e == null || !e.isAlive) {
            appendLine("Tap any dot on the map to inspect a being.")
            appendLine()
            appendLine("  Dot colour  =  civilisation")
            appendLine("  Dot size    =  life stage")
            appendLine("  Red tint    =  disease")
            appendLine("  Gold tint   =  starving")
            appendLine("  Arc ring    =  health (green/amber/red)")
        } else {
            appendLine("${if (e.gender == Gender.MALE) "♂" else "♀"} ${e.dna.describe()}")
            appendLine("${e.lifeStage.name}  ·  Age ${e.age} / ${e.dna.maxAge}  ·  ${e.currentGoal.name}")
            appendLine()
            appendLine("${bar("HP",     e.health)}   ${bar("Energy", e.energy)}")
            appendLine("${bar("Hunger", 1f-e.hunger)} ${bar("Thirst", 1f-e.thirst)}")
            appendLine()
            appendLine("── Genes ─────────────────────────────────")
            appendLine("  Speed       ${geneBar(e.dna.speed)}  ${pct(e.dna.speed)}")
            appendLine("  Intel       ${geneBar(e.dna.intelligence)}  ${pct(e.dna.intelligence)}")
            appendLine("  Social      ${geneBar(e.dna.socialBehavior)}  ${pct(e.dna.socialBehavior)}")
            appendLine("  Aggression  ${geneBar(e.dna.aggression)}  ${pct(e.dna.aggression)}")
            appendLine("  Creativity  ${geneBar(e.dna.creativity)}  ${pct(e.dna.creativity)}")
            appendLine("  Fertility   ${geneBar(e.dna.fertility)}  ${pct(e.dna.fertility)}")
            appendLine("  Disease res ${geneBar(e.dna.diseaseResistance)}  ${pct(e.dna.diseaseResistance)}")
            appendLine()
            val kList = e.knowledge.toList()
            appendLine("── Knowledge  (${kList.size}) ────────────────────")
            kList.chunked(2).forEach { pair ->
                appendLine("  ${pair.joinToString("   ") { it.displayName }}")
            }
            val civ = s.world.civById(e.civId)
            if (civ != null) {
                appendLine()
                appendLine("── Civilisation ──────────────────────────")
                appendLine("  ${civ.name}  ·  ${civ.getEraName()}  ·  ${civ.government.label}")
            }
            if (e.diseaseId >= 0) {
                val d = s.world.disease.active.firstOrNull { it.id == e.diseaseId }
                appendLine()
                appendLine("⚕ Afflicted: ${d?.name ?: "unknown"}")
            }
        }
    }

    // ── HUD strings ───────────────────────────────────────────────────────────

    private fun hud1(s: SimState) =
        "Year ${s.stats.year}   Pop ${s.stats.population}   Civs ${s.stats.civilizations}   ${s.world.weather.seasonName}"

    private fun hud2(s: SimState) =
        "Era: ${s.stats.advancedEra}   Tech: ${s.stats.knowledgeTypeCount}   ${s.world.weather.description()}"

    private fun alert(s: SimState): String {
        val d = s.world.disease.active.firstOrNull() ?: return ""
        val n = s.world.entities.count { it.diseaseId == d.id }
        return "⚕ OUTBREAK: ${d.name}  ($n infected)"
    }

    // ── Formatting helpers ────────────────────────────────────────────────────

    private fun pad(n: Int, w: Int) = n.toString().padStart(w)

    private fun bar(label: String, v: Float): String {
        val filled = (v * 8).toInt().coerceIn(0, 8)
        val empty  = 8 - filled
        val blocks = "█".repeat(filled) + "░".repeat(empty)
        return "${label.padEnd(7)} $blocks"
    }

    private fun geneBar(v: Float): String {
        val filled = (v * 10).toInt().coerceIn(0, 10)
        return "▪".repeat(filled) + "·".repeat(10 - filled)
    }

    private fun pct(v: Float) = "${(v * 100).toInt()}%"
}
