package com.ailife.ui

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.*
import com.ailife.simulation.*
import kotlin.math.*
import kotlin.random.Random

class WorldView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    // ── State ─────────────────────────────────────────────────────────────────
    private var world: World? = null
    private var hudLine1 = ""; private var hudLine2 = ""; private var hudAlert = ""
    private var selectedId = -1
    var onTileClick: ((Float, Float) -> Unit)? = null

    // ── Camera ────────────────────────────────────────────────────────────────
    private var scale = 1f; private var offX = 0f; private var offY = 0f

    // ── Cached bitmap layers ──────────────────────────────────────────────────
    private var terrainBmp:   Bitmap? = null; private var terrainDirty = true
    private var territoryBmp: Bitmap? = null; private var lastTerritoryTick = -99L

    // ── Weather particles (screen-space) ──────────────────────────────────────
    private data class Particle(var x: Float, var y: Float, var vx: Float, var vy: Float,
                                 var life: Float, val maxLife: Float, val size: Float)
    private val particles      = ArrayList<Particle>(300)
    private var activeWeather  = WeatherEvent.NONE
    private var spawnCooldown  = 0

    // ── Event ripple ──────────────────────────────────────────────────────────
    private var rippleWX = 0f; private var rippleWY = 0f
    private var rippleAlpha = 0f; private var rippleColor = Color.WHITE
    private var rippleR = 0f; private var rippleMaxR = 0f
    private var lastEventCount = 0

    // ── Pulse for selected entity ─────────────────────────────────────────────
    private var pulsePhase = 0f

    // ── Paints ────────────────────────────────────────────────────────────────
    private val entityFill   = Paint(Paint.ANTI_ALIAS_FLAG)
    private val entityGlow   = Paint(Paint.ANTI_ALIAS_FLAG)   // outer semi-transparent halo
    private val healthArc    = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val pulsePaint   = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val ripplePaint  = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val particlePaint= Paint(Paint.ANTI_ALIAS_FLAG)
    private val pillPaint    = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(175, 6, 8, 20) }
    private val labelPaint   = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFCCDDFF.toInt(); textAlign = Paint.Align.CENTER
        isFakeBoldText = true
        setShadowLayer(2f, 0f, 1f, Color.BLACK)
    }
    private val hudBg        = Paint().apply { color = Color.argb(215, 5, 7, 18) }
    private val hudAccent    = Paint().apply { color = 0xFF0B1E3A.toInt() }
    private val accentLine   = Paint().apply { color = 0xFF1D5A9E.toInt() }
    private val hudPrimary   = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFCCDDFF.toInt()
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
    }
    private val hudSecondary = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF556688.toInt()
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
    }
    private val hudAlert_    = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFF6B6B.toInt()
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
    }
    private val heatOverlay  = Paint().apply { color = Color.argb(20, 255, 110, 0) }
    private val snowOverlay  = Paint().apply { color = Color.argb(22, 160, 210, 255) }

    private val sp = context.resources.displayMetrics.scaledDensity

    private val terrainColors = mapOf(
        TerrainType.DEEP_WATER    to 0xFF0A2850.toInt(),
        TerrainType.SHALLOW_WATER to 0xFF175E90.toInt(),
        TerrainType.BEACH         to 0xFFF2DC82.toInt(),
        TerrainType.PLAINS        to 0xFF72BB40.toInt(),
        TerrainType.GRASSLAND     to 0xFF459928.toInt(),
        TerrainType.FOREST        to 0xFF164D1E.toInt(),
        TerrainType.MOUNTAIN      to 0xFF848484.toInt(),
        TerrainType.SNOW          to 0xFFE8EEFF.toInt(),
        TerrainType.DESERT        to 0xFFE5C56A.toInt(),
        TerrainType.SWAMP         to 0xFF455840.toInt()
    )

    // ── Gestures ──────────────────────────────────────────────────────────────
    private var lastTX = 0f; private var lastTY = 0f; private var didDrag = false

    private val scaleDetector = ScaleGestureDetector(context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                val prev = scale
                scale = (scale * d.scaleFactor).coerceIn(0.35f, 20f)
                offX = d.focusX - (d.focusX - offX) * (scale / prev)
                offY = d.focusY - (d.focusY - offY) * (scale / prev)
                invalidate(); return true
            }
        })

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(ev)
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> { lastTX = ev.x; lastTY = ev.y; didDrag = false }
            MotionEvent.ACTION_MOVE -> if (!scaleDetector.isInProgress) {
                val dx = ev.x - lastTX; val dy = ev.y - lastTY
                if (didDrag || dx * dx + dy * dy > 20f) {
                    offX += dx; offY += dy; didDrag = true; invalidate()
                }
                lastTX = ev.x; lastTY = ev.y
            }
            MotionEvent.ACTION_UP -> if (!didDrag && !scaleDetector.isInProgress) {
                onTileClick?.invoke((ev.x - offX) / scale / TSIZE, (ev.y - offY) / scale / TSIZE)
            }
        }
        return true
    }

    // ── Public API ─────────────────────────────────────────────────────────────

    fun setWorld(w: World, line1: String, line2: String, alert: String) {
        world = w; hudLine1 = line1; hudLine2 = line2; hudAlert = alert

        // Territory overlay — rebuild every 60 sim-ticks
        if (w.tick - lastTerritoryTick >= 60L || territoryBmp == null) {
            rebuildTerritory(w); lastTerritoryTick = w.tick
        }
        updateParticles(w)
        checkRipple(w)
        invalidate()
    }

    fun markTerrainDirty()  { terrainDirty = true; territoryBmp = null }
    fun setSelected(id: Int){ selectedId = id; invalidate() }

    fun centerOnWorld(w: World) {
        val bw = w.width * TSIZE; val bh = w.height * TSIZE
        scale = minOf(width / bw, height / bh) * 0.90f
        offX  = (width  - bw * scale) / 2f
        offY  = (height - bh * scale) / 2f
        invalidate()
    }

    // ── Master draw ───────────────────────────────────────────────────────────

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = world ?: run { canvas.drawColor(0xFF060810.toInt()); return }
        canvas.drawColor(0xFF060810.toInt())

        canvas.save()
        canvas.translate(offX, offY)
        canvas.scale(scale, scale)
        drawTerrain(canvas, w)
        drawTerritory(canvas)
        drawEntities(canvas, w)
        drawRipple(canvas)
        canvas.restore()

        drawScreenFX(canvas, w)
        drawParticles(canvas)
        drawHUD(canvas)

        // Animate: advance phase, schedule next frame only if something is moving
        pulsePhase = (pulsePhase + 0.09f) % (2f * Math.PI.toFloat())
        if (rippleAlpha > 0f) { rippleAlpha -= 0.035f; rippleR += rippleMaxR * 0.05f }
        tickParticles()
        if (rippleAlpha > 0f || particles.isNotEmpty() || selectedId >= 0) invalidate()
    }

    // ── Layer: terrain ────────────────────────────────────────────────────────

    private fun drawTerrain(canvas: Canvas, w: World) {
        val bw = w.width * TSIZE_I; val bh = w.height * TSIZE_I
        if (terrainDirty || terrainBmp == null || terrainBmp!!.width != bw) {
            terrainBmp?.recycle()
            val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.RGB_565)
            val bc  = Canvas(bmp); val p = Paint(); p.isAntiAlias = false
            for (x in 0 until w.width) for (y in 0 until w.height) {
                p.color = shadedTile(w, x, y)
                bc.drawRect((x*TSIZE_I).toFloat(), (y*TSIZE_I).toFloat(),
                    ((x+1)*TSIZE_I).toFloat(), ((y+1)*TSIZE_I).toFloat(), p)
            }
            terrainBmp = bmp; terrainDirty = false
        }
        canvas.drawBitmap(terrainBmp!!, 0f, 0f, Paint().apply { isFilterBitmap = false })
    }

    /** Slight edge vignette so the world doesn't look uniformly flat */
    private fun shadedTile(w: World, x: Int, y: Int): Int {
        val base  = terrainColors[w.terrain[x][y]] ?: Color.GRAY
        val edge  = minOf(x, y, w.width-1-x, w.height-1-y).toFloat() / 10f
        val dim   = (0.72f + edge.coerceIn(0f, 1f) * 0.28f)
        return Color.rgb(
            (Color.red(base)   * dim).toInt().coerceIn(0,255),
            (Color.green(base) * dim).toInt().coerceIn(0,255),
            (Color.blue(base)  * dim).toInt().coerceIn(0,255))
    }

    // ── Layer: territory glow ─────────────────────────────────────────────────

    private fun rebuildTerritory(w: World) {
        val bw = w.width * TSIZE_I; val bh = w.height * TSIZE_I
        territoryBmp?.recycle()
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val bc  = Canvas(bmp); val p = Paint(Paint.ANTI_ALIAS_FLAG)

        for (civ in w.civilizations) {
            if (civ.isExtinct || civ.population < 2) continue
            val r = Color.red(civ.color); val g = Color.green(civ.color); val b = Color.blue(civ.color)
            val cx = civ.centerX * TSIZE; val cy = civ.centerY * TSIZE
            // Radius grows with sqrt(population) so large civs don't dominate
            val rad = (sqrt(civ.population.toFloat()) * 3.0f + 5f) * TSIZE
            p.shader = RadialGradient(cx, cy, rad,
                intArrayOf(Color.argb(80,r,g,b), Color.argb(38,r,g,b), Color.argb(0,r,g,b)),
                floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP)
            bc.drawCircle(cx, cy, rad, p)
        }
        p.shader = null
        territoryBmp = bmp
    }

    private fun drawTerritory(canvas: Canvas) {
        val bmp = territoryBmp ?: return
        canvas.drawBitmap(bmp, 0f, 0f, Paint().apply { isFilterBitmap = true })
    }

    // ── Layer: entities ───────────────────────────────────────────────────────

    private fun drawEntities(canvas: Canvas, w: World) {
        val baseR = ERAD / scale.coerceAtLeast(0.8f)
        val r     = baseR.coerceIn(1.4f, ERAD)

        for (e in w.entities) {
            if (!e.isAlive) continue
            val ex = e.x * TSIZE; val ey = e.y * TSIZE

            val civColor = if (e.civId >= 0) w.civById(e.civId)?.color ?: WILD_COLOR else WILD_COLOR
            val col = when {
                e.diseaseId >= 0 -> blend(civColor, 0xFFCC2020.toInt(), 0.65f)
                e.hunger > 0.68f -> blend(civColor, 0xFFDD8800.toInt(), 0.50f)
                e.health < 0.35f -> blend(civColor, 0xFF882222.toInt(), 0.42f)
                else             -> civColor
            }
            val er = when (e.lifeStage) {
                LifeStage.CHILD -> r * 0.54f
                LifeStage.ELDER -> r * 0.80f
                else            -> r
            }

            // Outer halo — cheap semi-transparent fill (no blur shader)
            entityGlow.color = Color.argb(40, Color.red(col), Color.green(col), Color.blue(col))
            canvas.drawCircle(ex, ey, er * 2.4f, entityGlow)

            // Core
            entityFill.color = col
            entityFill.alpha = (e.health * 210f + 45f).toInt().coerceIn(60, 255)
            canvas.drawCircle(ex, ey, er, entityFill)

            // Health arc ring (only when zoomed enough to be visible)
            if (scale > 2.8f && er > 2f) {
                healthArc.color       = healthColor(e.health)
                healthArc.strokeWidth = (er * 0.40f).coerceAtLeast(1f)
                healthArc.alpha       = 190
                val rect = RectF(ex - er*1.55f, ey - er*1.55f, ex + er*1.55f, ey + er*1.55f)
                canvas.drawArc(rect, -90f, e.health * 360f, false, healthArc)
            }

            // Selected entity: animated pulse ring
            if (e.id == selectedId) {
                val pulse = (sin(pulsePhase.toDouble()).toFloat() + 1f) * 0.5f
                pulsePaint.strokeWidth = (1.8f + pulse * 2.5f) / scale
                pulsePaint.color = Color.argb((150 + (pulse * 100).toInt()), 255, 255, 255)
                canvas.drawCircle(ex, ey, er + (3.5f + pulse * 3.5f) / scale, pulsePaint)
            }
        }

        // Civ labels with pill background
        if (scale < 7f) {
            labelPaint.textSize = (13f / scale).coerceIn(8f, 22f)
            for (civ in w.civilizations) {
                if (civ.isExtinct || civ.population < 5) continue
                val lx = civ.centerX * TSIZE
                val ly = civ.centerY * TSIZE - (9f / scale)
                val tw = labelPaint.measureText(civ.name)
                val pad = 3.5f / scale; val ts = labelPaint.textSize
                canvas.drawRoundRect(lx-tw/2f-pad, ly-ts+1f, lx+tw/2f+pad, ly+pad,
                    5f/scale, 5f/scale, pillPaint)
                canvas.drawText(civ.name, lx, ly, labelPaint)
            }
        }
    }

    // ── Layer: event ripple ───────────────────────────────────────────────────

    private fun checkRipple(w: World) {
        if (w.history.events.size <= lastEventCount) return
        lastEventCount = w.history.events.size
        val ev = w.history.events.last()
        if (rippleAlpha > 0.4f) return   // don't stack

        val (fx, fy) = when {
            ev.entityId >= 0 -> w.entities.firstOrNull { it.id == ev.entityId }
                ?.let { it.x to it.y } ?: (w.width/2f to w.height/2f)
            ev.civId >= 0    -> w.civById(ev.civId)
                ?.let { it.centerX to it.centerY } ?: (w.width/2f to w.height/2f)
            else -> w.width/2f to w.height/2f
        }
        rippleWX = fx; rippleWY = fy; rippleAlpha = 1f; rippleR = 0f
        rippleMaxR = 14f * TSIZE
        rippleColor = when (ev.type) {
            EventType.WAR               -> 0xFFFF3333.toInt()
            EventType.INVENTION         -> 0xFF33FFAA.toInt()
            EventType.CIVILIZATION_FORMED -> 0xFF4499FF.toInt()
            EventType.EXTINCTION        -> 0xFFAA44FF.toInt()
            EventType.DISEASE           -> 0xFFFF8844.toInt()
            EventType.DISASTER          -> 0xFFFFBB00.toInt()
            else -> 0xFF88CCFF.toInt()
        }
    }

    private fun drawRipple(canvas: Canvas) {
        if (rippleAlpha <= 0f) return
        val a = (rippleAlpha * 220f).toInt().coerceIn(0, 220)
        ripplePaint.color = rippleColor; ripplePaint.strokeWidth = 2.5f / scale
        ripplePaint.alpha = a
        canvas.drawCircle(rippleWX * TSIZE, rippleWY * TSIZE, rippleR, ripplePaint)
        ripplePaint.alpha = a / 3
        canvas.drawCircle(rippleWX * TSIZE, rippleWY * TSIZE, rippleR * 0.55f, ripplePaint)
    }

    // ── Screen-space FX ───────────────────────────────────────────────────────

    private fun drawScreenFX(canvas: Canvas, w: World) {
        when (w.weather.currentEvent) {
            WeatherEvent.HEATWAVE -> canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), heatOverlay)
            WeatherEvent.BLIZZARD -> canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), snowOverlay)
            else -> {}
        }
    }

    // ── Weather particles ─────────────────────────────────────────────────────

    private fun updateParticles(w: World) {
        val ev = w.weather.currentEvent
        if (ev != activeWeather) { particles.clear(); activeWeather = ev }
        if (ev == WeatherEvent.NONE || ev == WeatherEvent.DROUGHT || ev == WeatherEvent.HEATWAVE) {
            particles.clear(); return
        }
        spawnCooldown--
        if (spawnCooldown <= 0 && particles.size < 260) {
            spawnCooldown = if (ev == WeatherEvent.BLIZZARD) 3 else 1
            repeat(if (ev == WeatherEvent.BLIZZARD) 2 else 4) {
                when (ev) {
                    WeatherEvent.FLOOD, WeatherEvent.STORM ->
                        particles.add(Particle(Random.nextFloat()*width, -8f,
                            Random.nextFloat()*1.5f - 0.4f, 4f + Random.nextFloat()*3.5f,
                            1f, 1f, 1.2f + Random.nextFloat()*1.5f))
                    WeatherEvent.BLIZZARD ->
                        particles.add(Particle(Random.nextFloat()*width, -8f,
                            Random.nextFloat()*2.5f - 1.2f, 1.5f + Random.nextFloat()*1.5f,
                            1f, 1f, 2f + Random.nextFloat()*3f))
                    else -> {}
                }
            }
        }
    }

    private fun tickParticles() {
        val it = particles.iterator()
        while (it.hasNext()) {
            val p = it.next(); p.x += p.vx; p.y += p.vy; p.life -= 0.018f
            if (p.life <= 0f || p.y > height+20f) it.remove()
        }
    }

    private fun drawParticles(canvas: Canvas) {
        for (p in particles) {
            val alpha = (p.life * 190f).toInt().coerceIn(0, 190)
            when (activeWeather) {
                WeatherEvent.FLOOD, WeatherEvent.STORM -> {
                    particlePaint.style = Paint.Style.STROKE
                    particlePaint.strokeWidth = p.size * 0.5f
                    particlePaint.color = Color.argb(alpha, 90, 160, 255)
                    canvas.drawLine(p.x, p.y, p.x - p.vx*3.5f, p.y - p.vy*3.5f, particlePaint)
                }
                WeatherEvent.BLIZZARD -> {
                    particlePaint.style = Paint.Style.FILL
                    particlePaint.color = Color.argb(alpha, 200, 225, 255)
                    canvas.drawCircle(p.x, p.y, p.size, particlePaint)
                }
                else -> {}
            }
        }
    }

    // ── HUD ───────────────────────────────────────────────────────────────────

    private fun drawHUD(canvas: Canvas) {
        hudPrimary.textSize   = 12f * sp
        hudSecondary.textSize = 10f * sp
        hudAlert_.textSize    = 10f * sp

        val lineH = hudPrimary.textSize * 1.32f
        val barH  = lineH * (if (hudAlert.isNotEmpty()) 3.2f else 2.6f) + 6f * sp

        canvas.drawRect(0f, 0f, width.toFloat(), barH, hudBg)
        // Accent band at very top
        canvas.drawRect(0f, 0f, width.toFloat(), 3f * sp, accentLine)

        val pad = 10f * sp
        canvas.drawText(hudLine1, pad, lineH,        hudPrimary)
        canvas.drawText(hudLine2, pad, lineH * 2.2f, hudSecondary)
        if (hudAlert.isNotEmpty()) canvas.drawText(hudAlert, pad, lineH * 3.1f, hudAlert_)
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private fun healthColor(h: Float) = when {
        h > 0.65f -> 0xFF33CC77.toInt()
        h > 0.35f -> 0xFFFFBB22.toInt()
        else      -> 0xFFFF4444.toInt()
    }

    private fun blend(base: Int, tint: Int, t: Float): Int {
        val s = 1f - t
        return Color.argb(255,
            (Color.red(base)*s   + Color.red(tint)*t  ).toInt().coerceIn(0,255),
            (Color.green(base)*s + Color.green(tint)*t).toInt().coerceIn(0,255),
            (Color.blue(base)*s  + Color.blue(tint)*t ).toInt().coerceIn(0,255))
    }

    companion object {
        const val TSIZE   = 7f
        const val TSIZE_I = 7
        const val ERAD    = 4.5f
        private val WILD_COLOR = 0xFF888899.toInt()
    }
}
