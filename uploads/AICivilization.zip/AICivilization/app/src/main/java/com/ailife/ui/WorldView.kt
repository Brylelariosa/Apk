package com.ailife.ui

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.*
import com.ailife.simulation.*
import kotlin.math.*
import kotlin.random.Random

class WorldView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    // ── State ─────────────────────────────────────────────────────────────────
    private var world: World? = null
    private var hudLine1 = ""; private var hudLine2 = ""; private var hudAlert = ""
    private var selectedId = -1
    private var centeredOnce = false
    var onTileClick: ((Float, Float) -> Unit)? = null

    // ── Camera ────────────────────────────────────────────────────────────────
    private var scale = 1f; private var offX = 0f; private var offY = 0f

    // ── Bitmap caches ─────────────────────────────────────────────────────────
    private var terrainBmp: Bitmap? = null; private var terrainDirty = true
    private var territoryBmp: Bitmap? = null; private var lastTerritoryTick = -99L

    // ── Weather particles ─────────────────────────────────────────────────────
    private data class Particle(var x: Float, var y: Float, var vx: Float, var vy: Float,
                                 var life: Float, val size: Float)
    private val particles     = ArrayList<Particle>(300)
    private var activeWeather = WeatherEvent.NONE
    private var spawnCD       = 0

    // ── Event ripple ──────────────────────────────────────────────────────────
    private var ripWX = 0f; private var ripWY = 0f; private var ripAlpha = 0f
    private var ripColor = Color.WHITE; private var ripR = 0f; private var ripMaxR = 0f
    private var lastEventCount = 0

    // ── Pulse animation ───────────────────────────────────────────────────────
    private var pulse = 0f

    // ── Paths (reused) ────────────────────────────────────────────────────────
    private val triPath = Path()

    // ── Paints ────────────────────────────────────────────────────────────────
    private val pFill    = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pGlow    = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pArc     = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val pPulse   = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val pRipple  = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val pParticle= Paint(Paint.ANTI_ALIAS_FLAG)
    private val pPill    = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(175, 6, 8, 20) }
    private val pLabel   = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFCCDDFF.toInt(); textAlign = Paint.Align.CENTER; isFakeBoldText = true
        setShadowLayer(2f, 0f, 1f, Color.BLACK)
    }
    private val pBldFill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pBldBdr  = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 0.8f; color = Color.argb(160,0,0,0) }
    private val pBldProg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(110, 200,180,80) }
    private val pBldSym  = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.argb(200,0,0,0) }
    private val pActIcon = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pHudBg   = Paint().apply { color = Color.argb(215, 5, 7, 18) }
    private val pAccLine = Paint().apply { color = 0xFF1D5A9E.toInt() }
    private val pHudMain = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFCCDDFF.toInt(); typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD) }
    private val pHudDim  = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF556688.toInt(); typeface = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL) }
    private val pHudAlert= Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFF6B6B.toInt(); typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD) }
    private val pHeat    = Paint().apply { color = Color.argb(20, 255, 110, 0) }
    private val pCold    = Paint().apply { color = Color.argb(22, 160, 210, 255) }

    private val sp = context.resources.displayMetrics.scaledDensity

    private val terrainColors = mapOf(
        TerrainType.DEEP_WATER    to 0xFF0A2850.toInt(),
        TerrainType.SHALLOW_WATER to 0xFF175E90.toInt(),
        TerrainType.BEACH         to 0xFFF2DC82.toInt(),
        TerrainType.PLAINS        to 0xFF72BB40.toInt(),
        TerrainType.GRASSLAND     to 0xFF459928.toInt(),
        TerrainType.FOREST        to 0xFF164D1E.toInt(),
        TerrainType.MOUNTAIN      to 0xFF848484.toInt(),
        TerrainType.SNOW          to 0xFFE8EEFF.toInt(),
        TerrainType.DESERT        to 0xFFE5C56A.toInt(),
        TerrainType.SWAMP         to 0xFF455840.toInt()
    )

    // ── Gestures ──────────────────────────────────────────────────────────────
    private var lastTX = 0f; private var lastTY = 0f; private var didDrag = false

    private val scaleDetector = ScaleGestureDetector(context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                val prev = scale
                scale = (scale * d.scaleFactor).coerceIn(0.35f, 22f)
                offX  = d.focusX - (d.focusX - offX) * (scale / prev)
                offY  = d.focusY - (d.focusY - offY) * (scale / prev)
                invalidate(); return true
            }
        })

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(ev)
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> { lastTX = ev.x; lastTY = ev.y; didDrag = false }
            MotionEvent.ACTION_MOVE -> if (!scaleDetector.isInProgress) {
                val dx = ev.x - lastTX; val dy = ev.y - lastTY
                if (didDrag || dx * dx + dy * dy > 20f) {
                    offX += dx; offY += dy; didDrag = true; invalidate()
                }
                lastTX = ev.x; lastTY = ev.y
            }
            MotionEvent.ACTION_UP -> if (!didDrag && !scaleDetector.isInProgress) {
                onTileClick?.invoke((ev.x - offX) / scale / T, (ev.y - offY) / scale / T)
            }
        }
        return true
    }

    // ── Auto-center when view is first sized ─────────────────────────────────
    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w > 0 && h > 0 && !centeredOnce) world?.let { doCenter(it) }
    }

    // ── Public API ─────────────────────────────────────────────────────────────

    fun setWorld(w: World, l1: String, l2: String, alert: String) {
        val first = world == null
        world = w; hudLine1 = l1; hudLine2 = l2; hudAlert = alert
        if (first && width > 0 && !centeredOnce) doCenter(w)
        if (w.tick - lastTerritoryTick >= 120L || territoryBmp == null) { rebuildTerritory(w); lastTerritoryTick = w.tick }
        updateParticles(w)
        checkRipple(w)
        invalidate()
    }

    fun markTerrainDirty() { terrainDirty = true; territoryBmp = null }
    fun setSelected(id: Int) { selectedId = id; invalidate() }

    fun centerOnWorld(w: World) { doCenter(w) }

    private fun doCenter(w: World) {
        if (width <= 0 || height <= 0) return
        val bw = w.width * T; val bh = w.height * T
        scale = minOf(width.toFloat() / bw, height.toFloat() / bh) * 0.94f
        offX  = (width  - bw * scale) / 2f
        offY  = (height - bh * scale) / 2f
        centeredOnce = true
        invalidate()
    }

    // ── Draw ──────────────────────────────────────────────────────────────────

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = world ?: run { canvas.drawColor(0xFF060810.toInt()); return }
        canvas.drawColor(0xFF060810.toInt())

        canvas.save()
        canvas.translate(offX, offY)
        canvas.scale(scale, scale)

        drawTerrain(canvas, w)
        drawTerritory(canvas)
        drawBuildings(canvas, w)
        drawAnimals(canvas, w)
        drawEntities(canvas, w)
        drawRipple(canvas)

        canvas.restore()

        drawScreenFX(canvas, w)
        drawParticles(canvas)
        drawHUD(canvas)

        // Advance animation state
        pulse = (pulse + 0.09f) % (2f * Math.PI.toFloat())
        if (ripAlpha > 0f) { ripAlpha -= 0.035f; ripR += ripMaxR * 0.05f }
        tickParticles()
        if (ripAlpha > 0f || particles.isNotEmpty() || selectedId >= 0) postInvalidateOnAnimation()
    }

    // ── Terrain ───────────────────────────────────────────────────────────────

    private fun drawTerrain(canvas: Canvas, w: World) {
        val bw = w.width * TI; val bh = w.height * TI
        if (terrainDirty || terrainBmp == null || terrainBmp!!.width != bw) {
            terrainBmp?.recycle()
            val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.RGB_565)
            val bc  = Canvas(bmp); val p = Paint(); p.isAntiAlias = false
            for (x in 0 until w.width) for (y in 0 until w.height) {
                p.color = shadeTile(w, x, y)
                bc.drawRect((x*TI).toFloat(), (y*TI).toFloat(), ((x+1)*TI).toFloat(), ((y+1)*TI).toFloat(), p)
            }
            terrainBmp = bmp; terrainDirty = false
        }
        canvas.drawBitmap(terrainBmp!!, 0f, 0f, Paint().apply { isFilterBitmap = false })
    }

    private fun shadeTile(w: World, x: Int, y: Int): Int {
        val base = terrainColors[w.terrain[x][y]] ?: Color.GRAY
        val edge = minOf(x, y, w.width-1-x, w.height-1-y).toFloat() / 10f
        val dim  = 0.72f + edge.coerceIn(0f, 1f) * 0.28f
        return Color.rgb(
            (Color.red(base)   * dim).toInt().coerceIn(0,255),
            (Color.green(base) * dim).toInt().coerceIn(0,255),
            (Color.blue(base)  * dim).toInt().coerceIn(0,255))
    }

    // ── Territory overlay (uses claimedTiles array, one setPixels call) ──────

    private fun rebuildTerritory(w: World) {
        val pixels = IntArray(w.width * w.height)   // pre-allocated; transparent = 0
        val civMap = HashMap<Int, IntArray>(16)      // civId → [r,g,b]
        for (civ in w.civilizations) {
            if (civ.isExtinct) continue
            civMap[civ.id] = intArrayOf(Color.red(civ.color), Color.green(civ.color), Color.blue(civ.color))
        }

        // Fast pass 1: stamp claimed-tile base colour (flat, no gradient)
        for (y in 0 until w.height) {
            for (x in 0 until w.width) {
                val cid = w.claimedTiles[y * w.width + x]
                if (cid < 0) continue
                val rgb = civMap[cid] ?: continue
                pixels[y * w.width + x] = Color.argb(38, rgb[0], rgb[1], rgb[2])
            }
        }

        // Pass 2: radial glow around civ centres for soft halo
        for (civ in w.civilizations) {
            if (civ.isExtinct || civ.population < 2) continue
            val rgb = civMap[civ.id] ?: continue
            val cx = civ.centerX; val cy = civ.centerY
            val rad = (kotlin.math.sqrt(civ.population.toFloat()) * 3.2f + 5f)
            val radSq = rad * rad
            val x0 = (cx - rad).toInt().coerceAtLeast(0)
            val x1 = (cx + rad).toInt().coerceAtMost(w.width  - 1)
            val y0 = (cy - rad).toInt().coerceAtLeast(0)
            val y1 = (cy + rad).toInt().coerceAtMost(w.height - 1)
            for (y in y0..y1) {
                for (x in x0..x1) {
                    val dx = x - cx; val dy = y - cy
                    val alpha = (1f - (dx*dx + dy*dy) / radSq).coerceIn(0f, 1f)
                    if (alpha < 0.05f) continue
                    val a = (alpha * 70).toInt()
                    val idx = y * w.width + x
                    val ca  = (pixels[idx] ushr 24) and 0xFF
                    if (a > ca) pixels[idx] = Color.argb(a, rgb[0], rgb[1], rgb[2])
                }
            }
        }

        // One bulk call instead of 10 000 setPixel calls
        territoryBmp?.recycle()
        territoryBmp = Bitmap.createBitmap(w.width, w.height, Bitmap.Config.ARGB_8888)
        territoryBmp!!.setPixels(pixels, 0, w.width, 0, 0, w.width, w.height)
    }

    private fun drawTerritory(canvas: Canvas) {
        val bmp = territoryBmp ?: return
        val m   = Matrix(); m.setScale(T, T)
        canvas.drawBitmap(bmp, m, Paint().apply { isFilterBitmap = true })
    }

    // ── Buildings ─────────────────────────────────────────────────────────────

    private fun drawBuildings(canvas: Canvas, w: World) {
        for (b in w.buildings) {
            val bx = b.tileX * T; val by = b.tileY * T
            val pad = T * 0.12f; val sz = T - pad * 2f
            if (!b.isComplete) {
                // Scaffolding under construction
                pBldFill.color = Color.argb(90, 160, 140, 80)
                canvas.drawRect(bx+pad, by+pad, bx+pad+sz, by+pad+sz, pBldFill)
                pBldFill.color = Color.argb(140, 200, 180, 100)
                canvas.drawRect(bx+pad, by+pad+sz*(1f-b.progress), bx+pad+sz, by+pad+sz, pBldFill)
            } else {
                pBldFill.color = b.type.mapColor
                canvas.drawRect(bx+pad, by+pad, bx+pad+sz, by+pad+sz, pBldFill)
                canvas.drawRect(bx+pad, by+pad, bx+pad+sz, by+pad+sz, pBldBdr)
                drawBuildingSymbol(canvas, b.type, bx + T/2f, by + T/2f, sz * 0.32f)
            }
        }
    }

    private fun drawBuildingSymbol(canvas: Canvas, type: BuildingType, cx: Float, cy: Float, r: Float) {
        pBldSym.strokeWidth = (r * 0.35f).coerceAtLeast(0.5f)
        pBldSym.style = Paint.Style.STROKE
        when (type) {
            BuildingType.HUT, BuildingType.FISHING_HUT -> {
                triPath.reset(); triPath.moveTo(cx, cy-r); triPath.lineTo(cx-r*0.85f, cy+r*0.6f)
                triPath.lineTo(cx+r*0.85f, cy+r*0.6f); triPath.close()
                pBldSym.style = Paint.Style.FILL; canvas.drawPath(triPath, pBldSym)
            }
            BuildingType.CAMPFIRE -> {
                pBldSym.style = Paint.Style.FILL; pBldSym.color = Color.argb(220, 255, 120, 20)
                canvas.drawCircle(cx, cy, r*0.6f, pBldSym)
                pBldSym.color = Color.argb(200,0,0,0)
            }
            BuildingType.FARM -> {
                canvas.drawLine(cx-r, cy-r*0.3f, cx+r, cy-r*0.3f, pBldSym)
                canvas.drawLine(cx-r, cy+r*0.3f, cx+r, cy+r*0.3f, pBldSym)
                canvas.drawLine(cx-r*0.4f, cy-r, cx-r*0.4f, cy+r, pBldSym)
                canvas.drawLine(cx+r*0.4f, cy-r, cx+r*0.4f, cy+r, pBldSym)
            }
            BuildingType.MINE -> {
                canvas.drawLine(cx-r, cy-r, cx+r, cy+r, pBldSym)
                canvas.drawLine(cx+r, cy-r, cx-r, cy+r, pBldSym)
            }
            BuildingType.FORGE -> {
                canvas.drawRect(cx-r*0.7f, cy-r*0.5f, cx+r*0.7f, cy+r*0.7f, pBldSym)
                canvas.drawLine(cx-r*0.3f, cy-r*0.5f, cx-r*0.3f, cy-r, pBldSym)
                canvas.drawLine(cx+r*0.3f, cy-r*0.5f, cx+r*0.3f, cy-r, pBldSym)
            }
            BuildingType.LIBRARY, BuildingType.MARKET -> {
                pBldSym.style = Paint.Style.FILL; canvas.drawRect(cx-r*0.8f, cy-r*0.6f, cx+r*0.8f, cy+r*0.6f, pBldSym)
                pBldSym.style = Paint.Style.STROKE; pBldSym.color = Color.argb(200, 180, 150, 80)
                canvas.drawLine(cx-r*0.3f, cy-r*0.6f, cx-r*0.3f, cy+r*0.6f, pBldSym)
                canvas.drawLine(cx+r*0.3f, cy-r*0.6f, cx+r*0.3f, cy+r*0.6f, pBldSym)
                pBldSym.color = Color.argb(200,0,0,0)
            }
            BuildingType.WATCHTOWER -> {
                canvas.drawLine(cx, cy-r, cx, cy+r*0.8f, pBldSym)
                canvas.drawLine(cx-r*0.5f, cy-r*0.2f, cx+r*0.5f, cy-r*0.2f, pBldSym)
            }
        }
    }

    // ── Animals ───────────────────────────────────────────────────────────────

    private fun drawAnimals(canvas: Canvas, w: World) {
        val baseR = (ERAD * 0.62f / scale.coerceAtLeast(0.8f)).coerceIn(1f, ERAD * 0.62f)
        for (a in w.animals) {
            if (!a.isAlive) continue
            val ax = a.x * T; val ay = a.y * T
            pFill.color = a.type.displayColor; pFill.alpha = 200
            when (a.type) {
                AnimalType.DEER -> {
                    triPath.reset(); triPath.moveTo(ax, ay - baseR * 1.1f)
                    triPath.lineTo(ax - baseR * 0.8f, ay + baseR * 0.6f)
                    triPath.lineTo(ax + baseR * 0.8f, ay + baseR * 0.6f); triPath.close()
                    canvas.drawPath(triPath, pFill)
                }
                AnimalType.RABBIT -> canvas.drawCircle(ax, ay, baseR * 0.65f, pFill)
                AnimalType.WOLF -> canvas.drawRect(ax-baseR*0.85f, ay-baseR*0.85f, ax+baseR*0.85f, ay+baseR*0.85f, pFill)
                AnimalType.FISH -> {
                    val rf = RectF(ax-baseR*1.4f, ay-baseR*0.55f, ax+baseR*1.4f, ay+baseR*0.55f)
                    canvas.drawOval(rf, pFill)
                }
            }
        }
        pFill.alpha = 255
    }

    // ── Entities ──────────────────────────────────────────────────────────────

    private fun drawEntities(canvas: Canvas, w: World) {
        val baseR = ERAD / scale.coerceAtLeast(0.8f)
        val r     = baseR.coerceIn(1.4f, ERAD)

        for (e in w.entities) {
            if (!e.isAlive) continue
            val ex = e.x * T; val ey = e.y * T
            val civColor = if (e.civId >= 0) w.civById(e.civId)?.color ?: WILD else WILD
            val col = when {
                e.diseaseId >= 0 -> blend(civColor, 0xFFCC2020.toInt(), 0.65f)
                e.hunger > 0.68f -> blend(civColor, 0xFFDD8800.toInt(), 0.50f)
                e.health < 0.35f -> blend(civColor, 0xFF882222.toInt(), 0.42f)
                else             -> civColor
            }
            // Mood tint: joyful = slightly brighter, miserable = slightly greyer
            val moodedCol = if (e.mood > 0.65f)
                blend(col, 0xFFFFFFFF.toInt(), (e.mood - 0.65f) * 0.25f)
            else if (e.mood < 0.35f)
                blend(col, 0xFF555566.toInt(), (0.35f - e.mood) * 0.45f)
            else col
            val er = when (e.lifeStage) {
                LifeStage.CHILD -> r * 0.54f
                LifeStage.ELDER -> r * 0.80f
                else            -> r
            }
            // Halo
            pGlow.color = Color.argb(38, Color.red(moodedCol), Color.green(moodedCol), Color.blue(moodedCol))
            canvas.drawCircle(ex, ey, er * 2.3f, pGlow)
            // Core
            pFill.color = moodedCol; pFill.alpha = (e.health * 210f + 45f).toInt().coerceIn(60, 255)
            canvas.drawCircle(ex, ey, er, pFill); pFill.alpha = 255
            // Health arc
            if (scale > 2.5f && er > 1.8f) {
                pArc.color = healthColor(e.health)
                pArc.strokeWidth = (er * 0.40f).coerceAtLeast(0.8f); pArc.alpha = 185
                canvas.drawArc(RectF(ex-er*1.55f, ey-er*1.55f, ex+er*1.55f, ey+er*1.55f),
                    -90f, e.health * 360f, false, pArc); pArc.alpha = 255
            }
            // Activity indicator
            if (scale > 2f && e.currentGoal != Goal.IDLE && e.currentGoal != Goal.REST) {
                pActIcon.color = activityColor(e.currentGoal)
                val ir = (1.8f / scale).coerceAtLeast(0.8f)
                canvas.drawCircle(ex, ey - er - ir * 2f, ir, pActIcon)
            }
            // Selection pulse
            if (e.id == selectedId) {
                val p2 = (sin(pulse.toDouble()).toFloat() + 1f) * 0.5f
                pPulse.strokeWidth = (1.8f + p2 * 2.5f) / scale
                pPulse.color = Color.argb((150 + (p2*100).toInt()), 255, 255, 255)
                canvas.drawCircle(ex, ey, er + (3.5f + p2 * 3.5f) / scale, pPulse)
            }
        }

        // Civ labels
        if (scale < 7f) {
            pLabel.textSize = (13f / scale).coerceIn(8f, 22f)
            for (civ in w.civilizations) {
                if (civ.isExtinct || civ.population < 5) continue
                val lx = civ.centerX * T; val ly = civ.centerY * T - 9f / scale
                val tw = pLabel.measureText(civ.name); val pad = 3.5f / scale; val ts = pLabel.textSize
                canvas.drawRoundRect(lx-tw/2f-pad, ly-ts+1f, lx+tw/2f+pad, ly+pad, 5f/scale, 5f/scale, pPill)
                canvas.drawText(civ.name, lx, ly, pLabel)
            }
        }
    }

    // ── Ripple ────────────────────────────────────────────────────────────────

    private fun checkRipple(w: World) {
        if (w.history.events.size <= lastEventCount) return
        lastEventCount = w.history.events.size
        val ev = w.history.events.last()
        if (ripAlpha > 0.4f) return
        val (fx, fy) = when {
            ev.entityId >= 0 -> w.entities.firstOrNull { it.id == ev.entityId }?.let { it.x to it.y } ?: (w.width/2f to w.height/2f)
            ev.civId    >= 0 -> w.civById(ev.civId)?.let { it.centerX to it.centerY } ?: (w.width/2f to w.height/2f)
            else -> w.width/2f to w.height/2f
        }
        ripWX = fx; ripWY = fy; ripAlpha = 1f; ripR = 0f; ripMaxR = 14f * T
        ripColor = when (ev.type) {
            EventType.WAR               -> 0xFFFF3333.toInt()
            EventType.INVENTION         -> 0xFF33FFAA.toInt()
            EventType.CIVILIZATION_FORMED -> 0xFF4499FF.toInt()
            EventType.EXTINCTION        -> 0xFFAA44FF.toInt()
            EventType.DISEASE           -> 0xFFFF8844.toInt()
            EventType.DISASTER          -> 0xFFFFBB00.toInt()
            else -> 0xFF88CCFF.toInt()
        }
    }

    private fun drawRipple(canvas: Canvas) {
        if (ripAlpha <= 0f) return
        pRipple.color = ripColor; pRipple.strokeWidth = 2.5f / scale
        pRipple.alpha = (ripAlpha * 220f).toInt().coerceIn(0, 220)
        canvas.drawCircle(ripWX * T, ripWY * T, ripR, pRipple)
        pRipple.alpha = (ripAlpha * 80f).toInt().coerceIn(0, 80)
        canvas.drawCircle(ripWX * T, ripWY * T, ripR * 0.55f, pRipple)
    }

    // ── Screen FX & particles ─────────────────────────────────────────────────

    private fun drawScreenFX(canvas: Canvas, w: World) {
        when (w.weather.currentEvent) {
            WeatherEvent.HEATWAVE -> canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), pHeat)
            WeatherEvent.BLIZZARD -> canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), pCold)
            else -> {}
        }
    }

    private fun updateParticles(w: World) {
        val ev = w.weather.currentEvent
        if (ev != activeWeather) { particles.clear(); activeWeather = ev }
        if (ev == WeatherEvent.NONE || ev == WeatherEvent.DROUGHT || ev == WeatherEvent.HEATWAVE) { particles.clear(); return }
        spawnCD--
        if (spawnCD <= 0 && particles.size < 250) {
            spawnCD = if (ev == WeatherEvent.BLIZZARD) 3 else 1
            repeat(if (ev == WeatherEvent.BLIZZARD) 2 else 4) {
                when (ev) {
                    WeatherEvent.FLOOD, WeatherEvent.STORM ->
                        particles.add(Particle(Random.nextFloat()*width, -8f, Random.nextFloat()*1.5f-0.4f,
                            4f + Random.nextFloat()*3.5f, 1f, 1.2f + Random.nextFloat()*1.5f))
                    WeatherEvent.BLIZZARD ->
                        particles.add(Particle(Random.nextFloat()*width, -8f, Random.nextFloat()*2.5f-1.2f,
                            1.5f + Random.nextFloat()*1.5f, 1f, 2f + Random.nextFloat()*3f))
                    else -> {}
                }
            }
        }
    }

    private fun tickParticles() {
        val it = particles.iterator()
        while (it.hasNext()) { val p = it.next(); p.x += p.vx; p.y += p.vy; p.life -= 0.018f; if (p.life <= 0f || p.y > height+20f) it.remove() }
    }

    private fun drawParticles(canvas: Canvas) {
        for (p in particles) {
            val alpha = (p.life * 190f).toInt().coerceIn(0, 190)
            when (activeWeather) {
                WeatherEvent.FLOOD, WeatherEvent.STORM -> {
                    pParticle.style = Paint.Style.STROKE; pParticle.strokeWidth = p.size*0.5f
                    pParticle.color = Color.argb(alpha, 90, 160, 255)
                    canvas.drawLine(p.x, p.y, p.x-p.vx*3.5f, p.y-p.vy*3.5f, pParticle)
                }
                WeatherEvent.BLIZZARD -> {
                    pParticle.style = Paint.Style.FILL; pParticle.color = Color.argb(alpha, 200, 225, 255)
                    canvas.drawCircle(p.x, p.y, p.size, pParticle)
                }
                else -> {}
            }
        }
    }

    // ── HUD ───────────────────────────────────────────────────────────────────

    private fun drawHUD(canvas: Canvas) {
        pHudMain.textSize = 12f * sp; pHudDim.textSize = 10f * sp; pHudAlert.textSize = 10f * sp
        val lineH = pHudMain.textSize * 1.32f
        val barH  = lineH * (if (hudAlert.isNotEmpty()) 3.2f else 2.6f) + 6f * sp
        canvas.drawRect(0f, 0f, width.toFloat(), barH, pHudBg)
        canvas.drawRect(0f, 0f, width.toFloat(), 3f * sp, pAccLine)
        val pad = 10f * sp
        canvas.drawText(hudLine1, pad, lineH,        pHudMain)
        canvas.drawText(hudLine2, pad, lineH * 2.2f, pHudDim)
        if (hudAlert.isNotEmpty()) canvas.drawText(hudAlert, pad, lineH * 3.1f, pHudAlert)
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private fun healthColor(h: Float) = when { h > 0.65f -> 0xFF33CC77.toInt(); h > 0.35f -> 0xFFFFBB22.toInt(); else -> 0xFFFF4444.toInt() }

    private fun activityColor(g: Goal) = when (g) {
        Goal.HUNT      -> 0xFFCC3311.toInt()
        Goal.FISH      -> 0xFF2299DD.toInt()
        Goal.CHOP_WOOD -> 0xFF886622.toInt()
        Goal.BUILD     -> 0xFFFFCC22.toInt()
        Goal.SEEK_MATE -> 0xFFFF88BB.toInt()
        Goal.TEACH     -> 0xFF7799FF.toInt()
        Goal.SEEK_FOOD -> 0xFFFF8833.toInt()
        Goal.FLEE      -> 0xFFFFFF44.toInt()
        Goal.EXPLORE   -> 0xFF55DDAA.toInt()
        else           -> 0xFF888888.toInt()
    }

    private fun blend(base: Int, tint: Int, t: Float): Int {
        val s = 1f - t
        return Color.argb(255,
            (Color.red(base)*s   + Color.red(tint)*t  ).toInt().coerceIn(0,255),
            (Color.green(base)*s + Color.green(tint)*t).toInt().coerceIn(0,255),
            (Color.blue(base)*s  + Color.blue(tint)*t ).toInt().coerceIn(0,255))
    }

    companion object {
        const val T  = 7f   // tile size in world-bitmap pixels
        const val TI = 7    // integer version
        const val ERAD = 4.5f
        private val WILD = 0xFF888899.toInt()
    }
}
