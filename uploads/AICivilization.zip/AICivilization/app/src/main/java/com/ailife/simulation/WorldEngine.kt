package com.ailife.simulation

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.random.Random

// ── Speed presets ─────────────────────────────────────────────────────────────
enum class SimSpeed(val label: String, val ticksPerSec: Int) {
    PAUSED("⏸", 0),
    SLOW  ("1×", 1),
    NORMAL("5×", 5),
    FAST  ("20×", 20),
    ULTRA ("MAX", 120)
}

// ── Published state (read by UI) ─────────────────────────────────────────────
data class SimState(
    val world:     World,
    val stats:     WorldStats,
    val isRunning: Boolean,
    val speed:     SimSpeed
)

// ─────────────────────────────────────────────────────────────────────────────
class WorldEngine {

    private val _state = MutableStateFlow<SimState?>(null)
    val state: StateFlow<SimState?> = _state.asStateFlow()

    private val world = World()
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var simJob: Job? = null
    private var running = false
    private var speed   = SimSpeed.NORMAL

    // ── Civilisation palette ─────────────────────────────────────────────────
    private val civColors = listOf(
        0xFFE74C3C.toInt(), 0xFF3498DB.toInt(), 0xFF2ECC71.toInt(),
        0xFFF39C12.toInt(), 0xFF9B59B6.toInt(), 0xFF1ABC9C.toInt(),
        0xFFE67E22.toInt(), 0xFF5D6D7E.toInt(), 0xFFC0392B.toInt(),
        0xFF2980B9.toInt(), 0xFF27AE60.toInt(), 0xFF8E44AD.toInt(),
        0xFFD4AC0D.toInt(), 0xFF117A65.toInt(), 0xFFCB4335.toInt(),
        0xFF1A5276.toInt()
    )

    private val civFirstNames  = listOf("Ara","Bel","Cor","Dav","Eth","Fer","Gor","Hiv","Ili","Jor","Kev","Lor","Mir","Nov","Ora","Pra","Quo","Rav","Sol","Tir","Ulv","Vor","Wes","Xer","Yal","Zan")
    private val civSuffixes    = listOf("ath","un","os","an","os","an","an","os","on","ak","na","an","an","us","ath","en","on","an","an","an","an","ak","an","on","al","an")

    // ── Lifecycle ────────────────────────────────────────────────────────────

    fun initialize() {
        WorldGenerator.generate(world, Random.nextLong())
        WorldGenerator.placeStartingEntities(world, 48)
        WorldGenerator.placeAnimals(world)
        publishState()
    }

    fun setSpeed(s: SimSpeed) {
        speed = s
        if (s == SimSpeed.PAUSED) stopLoop() else startLoop()
    }

    fun pause()  = stopLoop()
    fun resume() = startLoop()

    fun getWorld()   = world
    fun isRunning()  = running
    fun getSpeed()   = speed

    fun selectAt(worldX: Float, worldY: Float): Entity? =
        world.entities.filter { it.isAlive }
            .minByOrNull { it.distanceTo(worldX, worldY) }
            ?.takeIf { it.distanceTo(worldX, worldY) < 3.5f }

    fun destroy() = scope.cancel()

    // ── Loop control ─────────────────────────────────────────────────────────

    private fun startLoop() {
        running = true
        simJob?.cancel()
        simJob = scope.launch {
            val msPerTick = if (speed == SimSpeed.ULTRA) 0L else 1000L / speed.ticksPerSec
            while (isActive && running) {
                val t0 = System.currentTimeMillis()
                tick()
                val elapsed = System.currentTimeMillis() - t0
                val wait    = msPerTick - elapsed
                if (wait > 0) delay(wait)
            }
        }
    }

    private fun stopLoop() {
        running = false
        simJob?.cancel()
        publishState()
    }

    // ── Master tick ──────────────────────────────────────────────────────────

    private fun tick() {
        world.tick++
        world.rebuildSpatialGrid()

        // Entity updates
        val snapshot = world.entities.filter { it.isAlive }
        for (e in snapshot) tickEntity(e)

        // Nearby interactions (every other tick for performance)
        if (world.tick % 2L == 0L) handleInteractions(snapshot)

        // System updates
        world.weather.update()
        world.disease.update()

        if (world.tick % 7L  == 0L) world.regenerateResources()
        if (world.tick % 4L  == 0L) updateCivilizations()
        if (world.tick % 13L == 0L) world.economy.update(world)
        if (world.tick % 3L  == 0L) {
            updateAnimals()
            // Refresh living-animal caches used by Brain to avoid per-entity filter allocation
            world.landAnimalCache  = world.animals.filter { it.isAlive && !it.type.livesInWater }
            world.waterAnimalCache = world.animals.filter { it.isAlive &&  it.type.livesInWater }
        }
        if (world.tick % 18L == 0L) updateBuildings()

        // Yearly milestone
        if (world.tick % 52L == 0L) onNewYear()

        // Prune dead entities every 250 ticks — use bulk removeAll(Collection) which
        // CopyOnWriteArrayList overrides with a lock-based implementation (safe).
        if (world.tick % 250L == 0L && world.entities.size > world.populationCount + 400) {
            val dead = world.entities.filter { !it.isAlive }
            if (dead.isNotEmpty()) world.entities.removeAll(dead)
        }

        // Publish every 3 ticks
        if (world.tick % 3L == 0L) publishState()
    }

    // ── Single entity update ─────────────────────────────────────────────────

    private fun tickEntity(e: Entity) {
        // Age once per in-game year
        if (world.tick % 52L == 0L) {
            e.age++
            if (e.age >= e.dna.maxAge) { kill(e, "Old age"); return }
        }

        // Drain needs
        val droughtMod = if (world.weather.currentEvent == WeatherEvent.DROUGHT) 0.004f else 0f
        e.hunger += 0.007f + droughtMod
        e.thirst += 0.009f + droughtMod * 1.5f
        e.energy -= 0.004f

        // Death by starvation / dehydration
        if (e.hunger >= 1f) { kill(e, "Starvation");  return }
        if (e.thirst >= 1f) { kill(e, "Dehydration"); return }
        if (e.health <= 0f) { kill(e, e.deathCause ?: "Illness"); return }

        // Blizzard / heatwave kills weak entities
        if (world.weather.currentEvent == WeatherEvent.BLIZZARD && e.dna.diseaseResistance < 0.25f && Random.nextFloat() < 0.002f) {
            kill(e, "Exposure"); return
        }
        if (world.weather.currentEvent == WeatherEvent.HEATWAVE && e.thirst > 0.8f && Random.nextFloat() < 0.003f) {
            kill(e, "Heat stroke"); return
        }

        // Consume carried supplies
        if (e.hunger > 0.48f && e.food  > 0) { e.food--;  e.hunger = (e.hunger - 0.30f).coerceAtLeast(0f) }
        if (e.thirst > 0.48f && e.water > 0) { e.water--; e.thirst = (e.thirst - 0.35f).coerceAtLeast(0f) }

        // Harvest from current tile
        val tx = e.x.toInt().coerceIn(0, world.width - 1)
        val ty = e.y.toInt().coerceIn(0, world.height - 1)
        world.harvest(tx, ty, e)

        // Drink from shallow water tile
        if (world.terrain[tx][ty] == TerrainType.SHALLOW_WATER) {
            e.thirst = (e.thirst - 0.45f).coerceAtLeast(0f)
            if (e.water < 8) e.water++
        }

        // AI decision + movement
        e.currentGoal = Brain.decideGoal(e, world, world.tick)
        Brain.updateMovement(e, world, world.tick)

        // ── Mood update — creates behavioral variety beyond DNA ────────────
        var moodDelta = 0f
        if (e.hunger  > 0.60f) moodDelta -= 0.015f
        if (e.thirst  > 0.60f) moodDelta -= 0.015f
        if (e.health  < 0.50f) moodDelta -= 0.012f
        if (e.currentGoal == Goal.FLEE || e.diseaseId >= 0) moodDelta -= 0.020f
        if (e.energy  > 0.70f && e.hunger < 0.30f) moodDelta += 0.006f
        // Socialising near civ members lifts mood
        if (e.civId >= 0 && world.tick % 5L == 0L) {
            val friends = world.getNearby(e.x, e.y, 4f).count { it.civId == e.civId && it.id != e.id }
            moodDelta += friends * 0.004f
        }
        e.mood = (e.mood + moodDelta).coerceIn(0f, 1f)

        // ── Activity resolution ────────────────────────────────────────────
        when (e.currentGoal) {
            Goal.HUNT -> {
                val prey = world.landAnimalCache
                    .minByOrNull { e.distanceTo(it.x, it.y) }
                if (prey != null && e.distanceTo(prey.x, prey.y) < 1.4f) {
                    prey.isAlive = false
                    e.food  = (e.food + prey.type.foodValue).coerceAtMost(8)
                    e.hunger = (e.hunger - 0.48f).coerceAtLeast(0f)
                    e.mood   = (e.mood + 0.15f).coerceAtMost(1f)   // successful hunt feels good
                    e.currentGoal = Goal.IDLE
                }
            }
            Goal.FISH -> {
                if (world.isNearWater(e.x, e.y) && Random.nextFloat() < 0.10f) {
                    val fish = world.waterAnimalCache
                        .minByOrNull { e.distanceTo(it.x, it.y) }
                    if (fish != null && e.distanceTo(fish.x, fish.y) < 5f) {
                        fish.isAlive = false
                        e.food   = (e.food + fish.type.foodValue).coerceAtMost(8)
                        e.hunger = (e.hunger - 0.30f).coerceAtLeast(0f)
                    }
                }
            }
            Goal.CHOP_WOOD -> {
                val tx = e.x.toInt().coerceIn(0, world.width - 1)
                val ty = e.y.toInt().coerceIn(0, world.height - 1)
                if (world.terrain[tx][ty] == TerrainType.FOREST && Random.nextFloat() < 0.22f) {
                    val r = world.resources[tx][ty]
                    if (r.wood > 0) { r.wood--; e.wood = (e.wood + 1).coerceAtMost(8) }
                }
            }
            Goal.BUILD -> {
                val site = world.buildings
                    .filter { !it.isComplete && it.civId == e.civId }
                    .minByOrNull { e.distanceTo(it.worldX, it.worldY) }
                if (site != null && e.distanceTo(site.worldX, site.worldY) < 2f) {
                    site.progress = (site.progress + 0.025f).coerceAtMost(1f)
                    if (site.isComplete) {
                        world.history.record(HistoryEvent(world.year, EventType.ECONOMIC,
                            "Built: ${site.type.displayName}",
                            "A ${site.type.displayName} has been completed.", civId = e.civId))
                    }
                }
            }
            else -> {}
        }

        // Chance to invent new knowledge
        if (e.isAdult && Random.nextFloat() < e.dna.inventChance) tryInvent(e)
    }

    private fun kill(e: Entity, cause: String) {
        e.isAlive    = false
        e.deathCause = cause
        world.populationCount--
        world.totalDied++

        // Check if this was the last member of a civilisation
        if (e.civId >= 0) {
            val civ = world.civById(e.civId)
            if (civ != null && !civ.isExtinct && world.entitiesForCiv(e.civId).isEmpty()) {
                civ.isExtinct      = true
                civ.extinctionTick = world.tick
                world.history.record(HistoryEvent(
                    world.year, EventType.EXTINCTION,
                    "Civilisation Extinct: ${civ.name}",
                    "The ${civ.name} (${civ.getEraName()}) has ceased to exist after ${world.year - (civ.foundedTick / 52).toInt()} years."
                ))
            }
        }
    }

    // ── Entity interactions ───────────────────────────────────────────────────

    private fun handleInteractions(snapshot: List<Entity>) {
        for (e in snapshot) {
            if (!e.isAlive) continue      // may have died during tickEntity this same tick
            val nearby = world.getNearby(e.x, e.y, 2.2f)

            for (other in nearby) {
                if (other.id <= e.id || !other.isAlive) continue   // process each pair once

                // ── Reproduction ──────────────────────────────────────────
                if (e.gender != other.gender &&
                    e.isAdult && other.isAdult &&
                    e.canReproduce(world.tick) && other.canReproduce(world.tick) &&
                    (e.civId == other.civId || e.isSocial || other.isSocial) &&
                    world.populationCount < 750) {
                    reproduce(e, other)
                }

                // ── Knowledge transfer ────────────────────────────────────
                val sameGroup = e.civId >= 0 && e.civId == other.civId
                val friendly  = (e.relationships[other.id] ?: 0f) > -0.1f
                if (sameGroup && friendly && e.isAdult && other.isAdult) {
                    shareKnowledge(e, other)
                    shareKnowledge(other, e)
                }

                // ── Relationship drift ────────────────────────────────────
                if (sameGroup) {
                    e.updateRelationship(other.id,  0.01f)
                    other.updateRelationship(e.id,  0.01f)
                }

                // ── Civilisation join ─────────────────────────────────────
                if (e.civId == -1 && other.civId >= 0 && e.isSocial && e.isAdult) {
                    if (Random.nextFloat() < e.dna.socialBehavior * 0.025f) {
                        e.civId = other.civId
                        world.civById(other.civId)?.let { shareCivKnowledge(it, e) }
                    }
                }

                // ── Inter-civ combat ─────────────────────────────────────
                if (e.civId >= 0 && other.civId >= 0 && e.civId != other.civId && e.isAggressive) {
                    val eCiv     = world.civById(e.civId)     ?: continue
                    val otherCiv = world.civById(other.civId) ?: continue
                    if (eCiv.getRelation(other.civId) < -0.35f && Random.nextFloat() < 0.015f) {
                        other.health -= e.dna.combatStr * 0.06f
                        e.health     -= other.dna.combatStr * 0.04f
                        e.updateRelationship(other.id, -0.05f)
                        other.updateRelationship(e.id, -0.05f)
                    }
                }
            }
        }

        // Spontaneous civilisation formation from clustered lone socials
        val unciv = snapshot.filter { it.civId == -1 && it.isSocial && it.isAdult }
        if (unciv.size >= 4 && Random.nextFloat() < 0.004f) {
            val cluster = unciv.take(4)
            val cx = cluster.map { it.x }.average().toFloat()
            val cy = cluster.map { it.y }.average().toFloat()
            val allClose = cluster.all { e ->
                val dx = e.x - cx; val dy = e.y - cy
                dx * dx + dy * dy < 144f  // within 12 tiles
            }
            if (allClose) formCivilisation(cluster)
        }
    }

    private fun reproduce(a: Entity, b: Entity) {
        val mother = if (a.gender == Gender.FEMALE) a else b
        val father = if (a.gender == Gender.MALE)   a else b

        val childDna    = DNA.combine(mother.dna, father.dna)
        val childGender = if (Random.nextBoolean()) Gender.MALE else Gender.FEMALE
        val civId       = when {
            mother.civId >= 0 -> mother.civId
            father.civId >= 0 -> father.civId
            else              -> -1
        }

        val cx = (mother.x + (Random.nextFloat() - 0.5f)).coerceIn(0.5f, world.width  - 1.5f)
        val cy = (mother.y + (Random.nextFloat() - 0.5f)).coerceIn(0.5f, world.height - 1.5f)
        val child = world.spawnEntity(cx, cy, childGender, childDna, civId)
        child.parentAId = mother.id
        child.parentBId = father.id
        // Inherit knowledge both parents share
        child.knowledge.addAll(mother.knowledge.intersect(father.knowledge))

        mother.childCount++; mother.ticksSinceMating = world.tick
        father.childCount++; father.ticksSinceMating = world.tick
        mother.updateRelationship(father.id, 0.18f)
        father.updateRelationship(mother.id, 0.18f)
    }

    private fun shareKnowledge(teacher: Entity, student: Entity) {
        if (teacher.knowledge.size <= student.knowledge.size) return
        val learnable = (teacher.knowledge - student.knowledge)
            .filter { it.canLearn(student.knowledge) }
        val toLearn = learnable.randomOrNull() ?: return
        // Slower transfer unless teacher is actively teaching (3× slower for passive proximity)
        val rate = if (teacher.currentGoal == Goal.TEACH) student.dna.learnRate * 0.12f
                   else student.dna.learnRate * 0.04f
        if (Random.nextFloat() < rate) {
            student.acquireKnowledge(toLearn)
        }
    }

    private fun shareCivKnowledge(civ: Civilization, e: Entity) {
        for (k in civ.knowledge.filter { it.canLearn(e.knowledge) }) e.acquireKnowledge(k)
    }

    // ── Invention ────────────────────────────────────────────────────────────

    private fun tryInvent(e: Entity) {
        val learnable = KnowledgeType.ALL.filter { it !in e.knowledge && it.canLearn(e.knowledge) }
        val invention = learnable.randomOrNull() ?: return
        if (!e.acquireKnowledge(invention)) return

        // Gift to civilisation
        world.civById(e.civId)?.addKnowledge(invention)

        world.history.record(HistoryEvent(
            world.year, EventType.INVENTION,
            "Discovered: ${invention.displayName}",
            "${invention.description}. (Era: ${invention.eraLabel})",
            e.id, e.civId
        ))
    }

    // ── Civilisation logic ────────────────────────────────────────────────────

    private fun formCivilisation(founders: List<Entity>) {
        val idx     = world.civilizations.size
        val color   = civColors[idx % civColors.size]
        val name    = civFirstNames[idx % civFirstNames.size] + civSuffixes[idx % civSuffixes.size] + " People"
        val cx      = founders.map { it.x }.average().toFloat()
        val cy      = founders.map { it.y }.average().toFloat()

        val civ = world.spawnCivilization(name, color, cx, cy)
        founders.forEach { it.civId = civ.id }

        // Pool founding knowledge
        val pooled = founders.flatMap { it.knowledge }.toSet()
        civ.knowledge.addAll(pooled)
        founders.forEach { it.knowledge.addAll(pooled.filter { k -> k.canLearn(it.knowledge) }) }

        world.history.record(HistoryEvent(
            world.year, EventType.CIVILIZATION_FORMED,
            "Founded: $name",
            "${name.replaceFirstChar { it.uppercase() }} formed with ${founders.size} founders in the ${civ.getEraName()}.",
            civId = civ.id
        ))
    }

    private fun updateCivilizations() {
        for (civ in world.civilizations) {
            if (civ.isExtinct) continue

            val members = world.entitiesForCiv(civ.id)
            civ.population = members.size

            if (members.isEmpty()) {
                if (!civ.isExtinct) {
                    civ.isExtinct = true; civ.extinctionTick = world.tick
                }
                continue
            }

            // Pool member knowledge into civ
            for (m in members) civ.knowledge.addAll(m.knowledge)

            // Drip civ knowledge down to members
            val civKList = civ.knowledge.toList()
            val learner  = members.filter { it.isAdult }.randomOrNull() ?: continue
            val toLearn  = civKList.filter { it !in learner.knowledge && it.canLearn(learner.knowledge) }.randomOrNull()
            toLearn?.let { learner.acquireKnowledge(it) }

            // Update centre
            civ.centerX = members.map { it.x }.average().toFloat()
            civ.centerY = members.map { it.y }.average().toFloat()

            // Stamp territory — each member claims a small radius around their position
            if (world.tick % 8L == 0L) {
                for (m in members) {
                    val mx = m.x.toInt(); val my = m.y.toInt()
                    for (dx in -3..3) for (dy in -3..3) {
                        val tx = (mx + dx).coerceIn(0, world.width  - 1)
                        val ty = (my + dy).coerceIn(0, world.height - 1)
                        if (!world.isWater(tx, ty)) {
                            val idx = ty * world.width + tx
                            // Only claim neutral or own territory (don't erase enemy territory cheaply)
                            val current = world.claimedTiles[idx]
                            if (current == -1 || current == civ.id) world.claimedTiles[idx] = civ.id
                        }
                    }
                }
            }

            // Language drift each year
            if (world.tick % 52L == 0L) civ.languageDrift += Random.nextFloat() * 0.0008f

            civ.updateGovernment()
            civ.decayRelations()

            // Inter-civ diplomacy
            val others = world.civilizations.filter { !it.isExtinct && it.id != civ.id }
            for (other in others) {
                val rel  = civ.getRelation(other.id)
                val canComm = civ.canCommunicate(other)
                val dx = civ.centerX - other.centerX; val dy = civ.centerY - other.centerY
                val close = dx * dx + dy * dy < 625f  // within 25 tiles

                val avgAggr = members.map { it.dna.aggression }.average().toFloat()

                if (close && avgAggr > 0.58f && rel < -0.28f && Random.nextFloat() < 0.0012f) {
                    civ.setRelation(other.id, -0.85f)
                    other.setRelation(civ.id, -0.85f)
                    world.history.record(HistoryEvent(
                        world.year, EventType.WAR,
                        "War: ${civ.name} vs ${other.name}",
                        "${civ.name} has declared war on ${other.name}."
                    ))
                } else if (canComm && rel > 0.28f && Random.nextFloat() < 0.0018f) {
                    // Trade knowledge
                    val share = civ.knowledge.filter { it !in other.knowledge }.randomOrNull()
                    share?.let { other.addKnowledge(it) }
                    // Improve relations
                    civ.setRelation(other.id,   (rel + 0.08f).coerceAtMost(1f))
                    other.setRelation(civ.id, (other.getRelation(civ.id) + 0.08f).coerceAtMost(1f))
                } else if (!canComm && Random.nextFloat() < 0.0006f) {
                    // Language barrier breeds suspicion
                    civ.setRelation(other.id, (rel - 0.04f).coerceAtLeast(-1f))
                }
            }
        }
    }

    // ── Animal simulation ─────────────────────────────────────────────────────

    private fun updateAnimals() {
        // Respawn periodically if wildlife is low
        val alive = world.animals.count { it.isAlive }
        if (world.tick % 52L == 0L && alive < 120) {
            repeat(6) {
                val type = when (Random.nextInt(4)) {
                    0 -> AnimalType.DEER; 1 -> AnimalType.RABBIT
                    2 -> AnimalType.FISH; else -> AnimalType.WOLF
                }
                spawnAnimalNear(type)
            }
        }
        // Prune dead animals list
        if (world.tick % 300L == 0L) {
            val dead = world.animals.filter { !it.isAlive }
            if (dead.isNotEmpty()) world.animals.removeAll(dead)
        }

        for (a in world.animals) {
            if (!a.isAlive) continue

            // Wander / flee logic
            a.wanderCooldown--
            val dist = a.distanceTo(a.targetX, a.targetY)
            if (dist < 0.4f || a.wanderCooldown <= 0) {
                a.wanderCooldown = 8 + Random.nextInt(12)
                val angle = Random.nextDouble() * 2.0 * Math.PI
                val range = if (a.type.livesInWater) 4f else 7f
                var nx = (a.x + Math.cos(angle).toFloat() * range).coerceIn(1f, world.width  - 2f)
                var ny = (a.y + Math.sin(angle).toFloat() * range).coerceIn(1f, world.height - 2f)
                // Validate terrain
                val tx = nx.toInt().coerceIn(0, world.width - 1)
                val ty = ny.toInt().coerceIn(0, world.height - 1)
                val valid = if (a.type.livesInWater) world.isWater(tx, ty)
                            else !world.isWater(tx, ty)
                if (valid) { a.targetX = nx; a.targetY = ny }
            }

            // Move toward target
            if (dist > 0.4f) {
                val spd = a.type.speed
                a.x = (a.x + (a.targetX - a.x) / dist * spd).coerceIn(0f, world.width  - 1f)
                a.y = (a.y + (a.targetY - a.y) / dist * spd).coerceIn(0f, world.height - 1f)
            }

            // Wolves attack nearby entities
            if (a.type == AnimalType.WOLF && Random.nextFloat() < 0.004f) {
                val victim = world.getNearby(a.x, a.y, 2.5f).filter { it.isAlive }.randomOrNull()
                if (victim != null) {
                    victim.health -= 0.10f
                    a.targetX = victim.x; a.targetY = victim.y
                }
            }

            // Deer flee from nearby entities
            if (a.type == AnimalType.DEER || a.type == AnimalType.RABBIT) {
                val threat = world.getNearby(a.x, a.y, 4f).filter { it.isAlive && it.isAdult }.firstOrNull()
                if (threat != null) {
                    a.targetX = (a.x + (a.x - threat.x) * 4f).coerceIn(1f, world.width  - 2f)
                    a.targetY = (a.y + (a.y - threat.y) * 4f).coerceIn(1f, world.height - 2f)
                    a.wanderCooldown = 15
                }
            }
        }
    }

    private fun spawnAnimalNear(type: AnimalType) {
        val targetWater = type.livesInWater
        for (attempt in 0..30) {
            val x = Random.nextInt(world.width); val y = Random.nextInt(world.height)
            val inWater = world.isWater(x, y)
            if (inWater == targetWater) {
                world.animals.add(Animal(world.nextAnimalId++,
                    x + Random.nextFloat(), y + Random.nextFloat(), type))
                return
            }
        }
    }

    // ── Building system ───────────────────────────────────────────────────────

    private fun updateBuildings() {
        // Commission new buildings from civilizations that have the resources
        for (civ in world.civilizations) {
            if (civ.isExtinct) continue
            val members = world.entitiesForCiv(civ.id).filter { it.isAdult }
            if (members.isEmpty()) continue
            val existingCount = world.buildings.count { it.civId == civ.id && it.isComplete }
            val maxBuildings  = (civ.population / 8).coerceAtLeast(1)
            if (existingCount >= maxBuildings) continue
            if (world.buildings.any { !it.isComplete && it.civId == civ.id }) continue

            // Pick best building type for current era
            val type = when {
                KnowledgeType.PRINTING      in civ.knowledge && Random.nextFloat() < 0.15f -> BuildingType.LIBRARY
                KnowledgeType.ARCHITECTURE  in civ.knowledge && Random.nextFloat() < 0.20f -> BuildingType.WATCHTOWER
                KnowledgeType.METALLURGY    in civ.knowledge && Random.nextFloat() < 0.25f -> BuildingType.FORGE
                KnowledgeType.FARMING       in civ.knowledge && Random.nextFloat() < 0.35f -> BuildingType.FARM
                KnowledgeType.STONE_TOOLS   in civ.knowledge && Random.nextFloat() < 0.25f -> BuildingType.MINE
                KnowledgeType.FIRE          in civ.knowledge && Random.nextFloat() < 0.30f -> BuildingType.CAMPFIRE
                Random.nextFloat() < 0.40f                                                  -> BuildingType.FISHING_HUT
                else                                                                         -> BuildingType.HUT
            }
            if (type.requiredKnowledge != null && type.requiredKnowledge !in civ.knowledge) continue

            // Find a builder with enough resources
            val builder = members.firstOrNull { e ->
                e.wood >= type.woodCost && e.stone >= type.stoneCost
            } ?: continue

            builder.wood  -= type.woodCost
            builder.stone -= type.stoneCost
            val tx = builder.x.toInt().coerceIn(1, world.width  - 2)
            val ty = builder.y.toInt().coerceIn(1, world.height - 2)
            // Don't build on water or existing building
            if (world.isWater(tx, ty)) continue
            if (world.buildings.any { it.tileX == tx && it.tileY == ty }) continue

            world.buildings.add(Building(world.nextBuildingId++, type, tx, ty, civ.id))
        }

        // Buildings provide passive resource bonuses nearby
        if (world.tick % 52L == 0L) {
            for (b in world.buildings) {
                if (!b.isComplete) continue
                val nearby = world.getNearby(b.worldX, b.worldY, 5f)
                when (b.type) {
                    BuildingType.FARM         -> nearby.filter { it.civId == b.civId }.forEach { it.food  = (it.food + 1).coerceAtMost(8) }
                    BuildingType.MINE         -> nearby.filter { it.civId == b.civId }.forEach { it.stone = (it.stone + 1).coerceAtMost(5) }
                    BuildingType.CAMPFIRE     -> nearby.filter { it.civId == b.civId }.forEach { it.energy = (it.energy + 0.15f).coerceAtMost(1f) }
                    BuildingType.FISHING_HUT  -> nearby.filter { it.civId == b.civId }.forEach { it.food  = (it.food + 1).coerceAtMost(8) }
                    BuildingType.LIBRARY      -> nearby.filter { it.civId == b.civId && it.isAdult }.forEach { e ->
                        val learnable = b.civId.let { cid -> world.civById(cid)?.knowledge?.toList() }
                            ?.filter { k -> k !in e.knowledge && k.canLearn(e.knowledge) }?.randomOrNull()
                        learnable?.let { e.acquireKnowledge(it) }
                    }
                    else -> {}
                }
            }
        }
    }

    // ── Yearly milestone ──────────────────────────────────────────────────────

    private fun onNewYear() {
        // Decade census
        if (world.year % 10 == 0 && world.year > 0) {
            val s = world.statistics()
            world.history.record(HistoryEvent(
                world.year, EventType.ECONOMIC,
                "Year ${world.year} Census",
                "Pop: ${s.population} | Civs: ${s.civilizations} | Era: ${s.advancedEra} | Knowledge types: ${s.knowledgeTypeCount}"
            ))
        }

        // Note remarkable scholars (rare)
        if (Random.nextFloat() < 0.04f) {
            val scholar = world.entities
                .filter { it.isAlive && it.isAdult && it.knowledge.size >= 8 }
                .maxByOrNull { it.knowledge.size }
            if (scholar != null) {
                world.history.record(HistoryEvent(
                    world.year, EventType.DISCOVERY,
                    "Renowned Scholar",
                    "An individual of the ${world.civById(scholar.civId)?.name ?: "wilderness"} has mastered ${scholar.knowledge.size} fields of knowledge.",
                    scholar.id, scholar.civId
                ))
            }
        }
    }

    // ── Publishing ────────────────────────────────────────────────────────────

    private fun publishState() {
        _state.value = SimState(
            world     = world,
            stats     = world.statistics(world.tick),
            isRunning = running,
            speed     = speed
        )
    }
}
