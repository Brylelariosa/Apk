package com.ailife.simulation

import kotlin.random.Random

/**
 * Immutable genetic blueprint for an entity.
 * All values are in [0.01, 0.99] — no gene is fully absent or fully dominant.
 */
data class DNA(
    val speed: Float,
    val intelligence: Float,
    val curiosity: Float,
    val aggression: Float,
    val fertility: Float,
    val lifespan: Float,
    val diseaseResistance: Float,
    val socialBehavior: Float,
    val creativity: Float,
    val memoryCapacity: Float,
    val learningSpeed: Float,
    val riskTaking: Float
) {
    companion object {
        private const val MUTATION_RATE = 0.08f
        private const val MUTATION_STRENGTH = 0.25f

        fun random(): DNA = DNA(
            speed            = Random.nextFloat().clamp(),
            intelligence     = Random.nextFloat().clamp(),
            curiosity        = Random.nextFloat().clamp(),
            aggression       = Random.nextFloat().clamp(),
            fertility        = Random.nextFloat().clamp(),
            lifespan         = Random.nextFloat().clamp(),
            diseaseResistance= Random.nextFloat().clamp(),
            socialBehavior   = Random.nextFloat().clamp(),
            creativity       = Random.nextFloat().clamp(),
            memoryCapacity   = Random.nextFloat().clamp(),
            learningSpeed    = Random.nextFloat().clamp(),
            riskTaking       = Random.nextFloat().clamp()
        )

        fun combine(a: DNA, b: DNA): DNA {
            fun inherit(g1: Float, g2: Float): Float {
                val base = if (Random.nextBoolean()) g1 else g2
                val delta = if (Random.nextFloat() < MUTATION_RATE)
                    (Random.nextFloat() - 0.5f) * MUTATION_STRENGTH else 0f
                return (base + delta).clamp()
            }
            return DNA(
                speed             = inherit(a.speed, b.speed),
                intelligence      = inherit(a.intelligence, b.intelligence),
                curiosity         = inherit(a.curiosity, b.curiosity),
                aggression        = inherit(a.aggression, b.aggression),
                fertility         = inherit(a.fertility, b.fertility),
                lifespan          = inherit(a.lifespan, b.lifespan),
                diseaseResistance = inherit(a.diseaseResistance, b.diseaseResistance),
                socialBehavior    = inherit(a.socialBehavior, b.socialBehavior),
                creativity        = inherit(a.creativity, b.creativity),
                memoryCapacity    = inherit(a.memoryCapacity, b.memoryCapacity),
                learningSpeed     = inherit(a.learningSpeed, b.learningSpeed),
                riskTaking        = inherit(a.riskTaking, b.riskTaking)
            )
        }

        private fun Float.clamp() = coerceIn(0.05f, 0.95f)
    }

    // ── Derived stats ────────────────────────────────────────────────────────
    val maxAge: Int        get() = (28 + lifespan * 72).toInt()        // 28–100
    val moveSpeed: Float   get() = 0.25f + speed * 0.75f
    val maxChildren: Int   get() = (1 + fertility * 6).toInt()          // 1–7
    val learnRate: Float   get() = 0.04f + learningSpeed * 0.46f
    val inventChance: Float get() = creativity * intelligence * 0.0008f  // was 0.004 — slowed 5× so full tech tree takes centuries not decades
    val combatStr: Float   get() = aggression * 0.65f + speed * 0.35f

    fun describe(): String {
        val t = mutableListOf<String>()
        if (intelligence     > 0.70f) t += "Wise"      else if (intelligence < 0.30f) t += "Dull"
        if (aggression       > 0.70f) t += "Fierce"    else if (aggression   < 0.20f) t += "Docile"
        if (curiosity        > 0.70f) t += "Curious"
        if (creativity       > 0.70f) t += "Creative"
        if (socialBehavior   > 0.70f) t += "Gregarious" else if (socialBehavior < 0.20f) t += "Loner"
        if (riskTaking       > 0.70f) t += "Daring"
        if (diseaseResistance> 0.70f) t += "Hardy"
        if (lifespan         > 0.75f) t += "Long-lived"
        return t.take(3).joinToString(", ").ifEmpty { "Ordinary" }
    }
}
