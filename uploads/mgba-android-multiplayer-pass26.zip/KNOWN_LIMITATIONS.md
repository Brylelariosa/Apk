# KNOWN_LIMITATIONS — Nineteenth pass

## The honest state of things right now

Still broken. Eighteenth pass's SIOCNT-mirroring fix was tested against a
real matched capture this pass and showed **no observed change**: the
child's own exchange log still shows `childData` as only ever
`0x0000`/`0xFEFE` — the exact same two values every capture back to the
Sixth pass has shown, with nothing else ever appearing. The host's `recv`
correspondingly still only ever reflects those same two values (plus the
occasional `0xFFFF` timeout). Not reverted — it's still a correctness fix
on its own terms — but it is not, or not the whole of, what's actually
wrong.

## Where this leaves the running theories

- **Missing SIO IRQ (Seventh pass):** fixed, confirmed present in the code
  on both host and child paths. No observed effect on its own (Eighth
  pass) or in combination with FIX 18 (this pass).
- **Child's SIOCNT busy bit never mirrored (Eighteenth pass):** fixed,
  confirmed present in the code. No observed effect this pass.
- **Timing/cycle-count mismatch (Sixteenth/Seventeenth pass):** still
  untouched, still the only remaining code-level theory with any real
  reasoning behind it that hasn't actually been tried yet.

Two independent, individually well-reasoned fixes producing zero visible
change is worth pausing on rather than reaching for a third blind one
immediately — per Eighth pass's own precedent for exactly this situation.

## A question worth answering before the next code change

Nothing in any capture so far has said what's actually on each phone's
*screen* at the moment of capture. Every log confirms the SIO protocol
layer is cycling through a fixed "not ready yet" pattern — but that's also
exactly what a game legitimately shows while a human hasn't yet pressed
Start/confirmed on the in-game link menu on one or both phones. Worth
ruling out directly: at the moment of capture, does either phone still say
something like "Waiting for other player," or has a player already
pressed A/Start on both screens with nothing happening afterward? The
former would mean there's no bug in this file at all yet to find; the
latter narrows things back to the timing theory above.

## Log-capture tooling note (this pass)

The two logs this pass covered different real-world spans, which had no
quick explanation before now. Confirmed root cause: the host's code logs
~3 lines per SIO exchange (two writes + one result) against the child's
~1 ("Child exchange" line), so the same 40,000-character export cap holds
less real time on the denser, host side — not a phone problem, and not
specific to this capture. `copyLinkDebugLog()` now appends the exact copy
timestamp so this is visible at a glance on future captures.

---

# KNOWN_LIMITATIONS — Eighteenth pass

## The honest state of things right now

Multiplayer still doesn't work — not fixed, not yet re-tested against a
real device. What's different this pass: for the first time since this
project started asking for it (Twelfth pass onward), a real matched
two-phone capture came in — `wifi_host`/`wifi_join`-style logs from *both*
phones, timestamps overlapping to the second (07-16 14:02:58–14:03:00),
not minutes apart. Seventeenth pass's file-based logging is what made this
possible.

## What the matched capture actually confirms

Cross-referencing both sides directly (not just each side's own aggregate
stats, which is all any previous pass had) confirms Sixteenth/Seventeenth
pass's read and rules out one whole category of explanation for good:

- The host's own live, changing outgoing values — its counter-embedded
  probe sequence (`0xFEFE`, `0x4921`, `0x2002`, `0x0001`, `0x0020`, plus
  the slowly-drifting counter bytes) — show up **correctly** as `hostData`
  in the child's own exchange log, value for value.
- The child's fixed `0x0000`/`0xFEFE` show up **correctly** as `recv` in
  the host's own exchange log.

Data crosses the network both ways, correctly, confirmed from both ends
of the same attempt at once. This was always the leading "boring"
explanation to rule out, and it's now ruled out as solidly as a log-only
sandbox can manage — not a relay/corruption bug, not a network-timing
bug on the transport itself.

## New finding and this pass's fix

With the network layer cleared, the child ROM's own code is the only
place left unaccounted for — and re-reading `nativeLinkChildExchange()`
specifically against that framing (rather than re-reading everything from
scratch again) turned up a gap the function's own comment already
admitted to: it writes SIOMULTI0-3 and raises the SIO IRQ, but never
touched the child device's own SIOCNT. GBATEK documents Multi-Player
SIOCNT bit 7 (Start/Busy) as a hardware-mirrored reflection of the
parent's clock line on *every* connected unit, not something a child's
CPU sets — polling it to notice "a transfer just landed" is a normal
technique alongside, or instead of, IntrWait on the IRQ this file already
raises correctly. Since nothing here ever pulsed that bit on the child's
device, a child ROM using that technique would see a flat, never-changing
value — indistinguishable from "no transfer has ever happened" — no
matter how correct the IRQ or the data registers already are.

Fixed: `nativeLinkChildExchange()` now refreshes SIOCNT bits 2 (child), 3
(ready), 4-5 (player ID) and clears bit 7 (busy) on the child's own device
after every exchange, preserving every other bit exactly as the ROM last
set it. See `mgba_jni.c`'s own FIX 18 comment for the full reasoning.

**Not confirmed** — same caveat as every fix in this project, still no
device in this sandbox — but grounded in a gap the code already admitted
to itself, cross-referenced against GBATEK, rather than a new guess about
either test ROM's internals.

## Found but not addressed this pass

- **Exchange completion still isn't cycle-timed against any real transfer
  duration** — the timing/lockstep theory from Sixteenth/Seventeenth pass
  is untouched by this fix and remains a live secondary candidate if this
  one turns out not to be the whole answer.
- Everything else listed as open in Seventeenth pass's own section below
  is still open; this pass didn't revisit any of it.

## What would move this forward

Exactly what would have moved every pass since the Twelfth forward: a real
device re-test with this fix in place, ideally with another matched
same-attempt pair from both phones (now easy to get, since Seventeenth
pass's logging doesn't need logcat access on either device). If the child
ROM was polling SIOCNT bit 7, its own `Child exchange:` log entries should
finally show `childData` values other than `0x0000`/`0xFEFE` — that's the
one thing to check first.

---

# KNOWN_LIMITATIONS — Seventeenth pass

## The honest state of things right now

Multiplayer still doesn't work. This pass had two goals: get more out of
the first evidence taken with Sixteenth pass's exchange-result/child-
exchange logging, and close the logcat-access gap that's been blocking a
truly simultaneous two-phone capture since the Twelfth. Neither goal
produces a confirmed fix — see BUGS_FIXED.md's own honesty note, same as
every pass since the Ninth.

## What the new logs actually show

W sent `wifi_host__1_.text` (2128 lines) and `wifi_join__1_.text` (1739
lines) this pass — real captures, both taken with Sixteenth pass's new
trace points already built in, so for the first time the *content* of
each side's exchanges is visible, not just that an exchange happened.

**Caveat first, same as every pass since the Fifteenth:** these are two
separate sessions. Host timestamps run 12:46:02.132–12:46:03.726; join
timestamps run 12:49:13.435–12:49:15.423 — about three minutes apart, not
the same connection attempt. Nothing below can be cross-referenced
transfer-by-transfer. What follows is each side's own aggregate behavior,
which is real evidence on its own, just not proof the two sides were
actually failing the same handshake at the same moment.

**Host side.** 704 completed exchanges in ~1.6s. 694 (98.6%) got a real
reply, not a timeout — only 10 timed out, and each of those correctly
shows up as `recv=0xFFFF` (Ninth pass's own placeholder for a timed-out
round), not silently dropped. A network layer replying this fast, this
reliably, is real evidence it isn't the bottleneck. But of those 694 real
replies, every single one was either `0xFEFE` (544 times) or `0x0000` (150
times) — never once anything resembling the host's own outgoing data,
which cycles through a repeating ~20-value set (`0x0000`, `0xFEFE`,
`0x4921`, `0x2002`, `0x0001`, `0x0020`) plus two slowly-incrementing
counter-like bytes (`0x56xx`, `0x40xx`) — the same shape Sixteenth pass
already described from the trigger side alone.

**Child side.** This is the real addition this pass. Across all 1586 of
this capture's own `nativeLinkChildExchange()` calls, `childData` — this
device's own `g_link_driver.localSend`, i.e. whatever its ROM most
recently wrote to its own SIOMLT_SEND — is `0xFEFE` (1137 times) or
`0x0000` (449 times) and **literally nothing else**, for the entire ~2
second capture. This is a directly-traced local write, not a relay
question: the child ROM itself never writes anything past these two
placeholders. Its SIOCNT/RCNT/SIOMLT_SEND writes repeat the same
five-write sequence roughly every 200ms (10 RCNT=0x0000 writes across the
capture, 194–209ms apart each time) — write SIOCNT, write RCNT=0x0000,
write SIOCNT again, reset SIOMLT_SEND to 0x0000, write SIOCNT a third
time. Per GBATEK, RCNT bit 14-15 combined with SIOCNT bit 12-13 is exactly
how Multi-Player mode gets *selected* — writing RCNT=0 here (with SIOCNT's
bit 13 already set from the previous write) is part of that selection, not
a fallback to Normal mode. So this really does look like the child ROM's
own "waiting for the other unit" setup loop — the kind of thing a real
game does while sitting on a link/lobby screen — just one that never gets
past its own opening move and keeps restarting.

Put together: the network is delivering data quickly and reliably in both
directions (confirmed independently from both sides now, not just
inferred from the host's trigger pattern). The child ROM's own code is
what never progresses. This doesn't identify why yet, but it does move the
question from "is something dropping or corrupting data" (looking
unlikely) to "why does the child's own negotiation never see whatever
condition it's waiting for" (still open).

## Re-checked: is bit3 (all-ready) actually reaching the child?

This was the single most likely explanation going into this pass — GBATEK
says SIOCNT bit 3 tells a unit "all connected GBAs are in Multi-Player
mode"; a child ROM that never sees that bit set would plausibly just keep
re-initializing forever, which is exactly the observed symptom. Ninth
pass's fix (`link_sio_write_register()` ORing bit 3, and bit 2 for
parent/child identity, into every SIOCNT write while `g_link_active` is
true) was checked specifically against this theory this pass.

On paper it already covers this correctly: the OR happens unconditionally
on *every* SIOCNT write, gated only on `g_link_active`, not on
`g_link_is_host` — unlike the exchange-trigger branch right below it in
the same function, which *is* host-gated (Fifteenth pass, FIX 14). Since
`g_link_active` is true for this entire capture (confirmed — every one of
the 1586 child-exchange calls produced real data, never hit the early-exit
skip path), the child ROM should already be seeing bit3=1 from its very
first SIOCNT poll onward. **No bug found here this pass** — worth stating
plainly rather than silently re-confirming, since it was the leading
candidate coming in and ruling it out (as much as static reading can rule
anything out) is itself useful for whoever picks this up next.

## Best current theory, updated but still NOT confirmed

Per DeepWiki's generated documentation of mgba-emu/mgba's own real
`src/gba/sio/lockstep.c` (a secondary source describing the real file,
cross-referencing real line ranges — not fetched directly this pass), the
actual mGBA project's own multiplayer implementation — used by its Qt
frontend for local multi-instance play, unrelated to this project's code
but the source Eighth pass's `GBASIOMultiplayerFinishTransfer` reference
came from — is built around a lockstep coordinator: a transfer-start event
gets enqueued to every secondary player, the coordinator explicitly waits
for all of them to acknowledge, and completion is timed against a
`GBASIOCyclesPerTransfer` table so every transfer takes the same number of
emulated cycles a real cable would.

This file's own exchange has no equivalent of any of that. It's a single
blocking network round-trip that completes the instant one UDP/RFCOMM
reply comes back — real SIO hardware (and mGBA's own lockstep driver)
never completes that fast relative to the CPU's own instruction stream,
because a real transfer takes a fixed, non-zero number of cycles no matter
how fast the physical link is. The same DeepWiki page lists
"desynchronization due to timing issues" as the most common multiplayer
bug class in mGBA's own reference implementation — real, independent
support for timing/synchronization being a plausible category here too,
not a guess invented from nothing. It is still not evidence that this
specific codebase's specific instance of that category is what's actually
happening — that would take a real device test, same as every other
theory this project has ever proposed.

**Deliberately not attempted this pass:** reworking the exchange to be
event-paced / cycle-timed instead of one blocking call. That's a real
protocol redesign, not a logging addition, and every prior pass's stated
policy — most explicitly the Eighth's — has been to not make that kind of
change blind, without a real device to check it against. Flagging it here
as the most promising remaining direction for whoever has device access
next, not attempting it speculatively now.

## The fix this pass: logging that doesn't need logcat at all

W's report this round — real evidence on one phone, nothing on the other,
same split as Sixteenth pass's screenshot — confirms the logcat-access gap
flagged then but not fixed is still standing between this project and the
one thing every pass since the Twelfth has actually asked for: a capture
from *both* phones during the *same* connection attempt. Without that,
even the theory above can only ever be "plausible," never checked.

`copyLinkDebugLog()` no longer touches `logcat` at all. Every `LOGI`/
`LOGW`/`LOGE` call in `mgba_jni.c`, plus `LinkMultiplayer.kt`'s own 7
connection-lifecycle log lines (Fifteenth pass), now also writes to a
plain file this app owns outright, under its own `filesDir` — no
permission needed, no OS logcat access of any kind, on any OEM build,
because it was never reading logcat in the first place. Re-truncated at
the start of every `nativeLinkStart()`, so a capture is one attempt, not
an accumulation. See CHANGELOG.md and FILE_CHANGES.md for the mechanics.

**This should directly unblock the thing that's been stuck since the
Twelfth pass.** If it does, the actual next step is unchanged from every
recent pass: connect, get both ROMs into their in-game link screens, let
it sit a few seconds, then tap "Copy link log" on *both* phones within the
same short window, and send both. With that — and only with that — the
theory above (or whatever the logs actually show instead) can finally be
checked against a real, matched pair instead of two windows minutes apart.

## Found but not addressed this pass

- **Exchange completion isn't cycle-timed against any real transfer
  duration** — see "Best current theory" above. Real redesign, needs
  device feedback to attempt safely.
- **`nativeLinkChildExchange()` is called from a background Kotlin thread,
  asynchronously with respect to `nativeRunFrame()`'s own instruction
  stream** (protected by `g_core_mutex` for data-race safety, but not
  synchronized to any particular point in the emulated frame). Whether
  this matters is unknown — flagged as a distinct angle from the timing
  theory above, not folded into it, since it's about *when within a frame*
  an interrupt lands rather than *how long a transfer takes*. Not
  investigated this pass; noted so it isn't lost.

## What would move this forward

Unchanged in substance from every pass since the Twelfth, hopefully now
actually reachable: a real, simultaneous two-phone capture of one
connection attempt, both ROMs actually on their in-game link screens, both
logs pulled via "Copy link log" within the same short window. Everything
else in this section is downstream of finally having that.

---

# KNOWN_LIMITATIONS — Sixteenth pass

## The honest state of things right now

Fifteenth pass's logging fix worked: W's four uploads this pass are the
first real evidence this project has had in sixteen passes. One screenshot
shows the debug-log tool producing nothing on one specific phone (see its
own section below); the other three are genuine logcat captures with real
content — `wifi_host.text` (2243 lines, host role), `wifi_join.text` (271
lines, child role), `bluetoth__1_.text` (136 lines, child role).

What they show, read plainly:

- **The network layer is very likely working.** The host recorded 1124
  Start-bit-triggered exchange attempts in 1.67 seconds. At
  `WIFI_XCHG_MS=30` per timeout, hitting that ceiling on most of them would
  take upwards of 30 seconds — it didn't. The overwhelming majority
  completed fast, which only happens if a reply is actually arriving
  quickly from the other phone.
- **The host doesn't seem to be making progress.** Its outgoing data isn't
  varied — it cycles through what looks like the same ~20-value sequence
  repeatedly (a handful of fixed values, plus two that drift by exactly ±1
  between cycles: `4007→4008`, `56B4→56B3`, which reads like a live
  counter embedded in an otherwise-static probe). It never seems to
  advance to different content, which is what you'd expect from a
  handshake that keeps getting rejected and restarting rather than one
  progressing normally.
- **The child doesn't seem to be making progress either.** Both child-role
  logs (Wi-Fi and Bluetooth, separate sessions) show the same pattern:
  SIOCNT/RCNT written in a short setup sequence, then the whole thing
  repeated again roughly every 200ms, indefinitely. That looks like a ROM
  that keeps abandoning its own negotiation and starting over, on both
  transports, not a transport-specific problem.

**One important caveat: `wifi_host.text` and `wifi_join.text` are
timestamped about two minutes apart.** They're not two windows into the
same live conversation — each shows that device's own behavior in its own
attempt, not a matched pair that can be directly cross-referenced
transfer-by-transfer. Nothing below should be read as "the host sent X and
the child's log shows it receiving X" — that comparison isn't possible with
what's been captured so far.

**Best current theory — not confirmed, and explicitly a guess about
game-specific protocol behavior this sandbox has no way to verify:** each
side's own link-negotiation code is independently timing out and
restarting because whatever it's reading back from the other side doesn't
look like a valid response — plausible if a network round trip frequently
lands while the far side is itself mid-reset, since a device mid-reset has
nothing better than a stale placeholder value to hand back, creating a
loop where neither side's "good" moment ever lines up with the other's.
That is one plausible story that fits the shape of the data. It is not
confirmed, and it isn't the only story that would fit.

The concrete gap closed this pass: neither theory *could* have been
checked before now, because the only thing ever logged was the write that
*triggers* a host-side exchange — never what came back, and never anything
at all from the child's own receive function
(`nativeLinkChildExchange()`), which had zero logging in either of its two
paths across all sixteen passes. Both fixed (logging only, see
CHANGELOG.md items 1-2).

## What would actually move this forward

The single most valuable thing that hasn't happened yet: **capture both
phones' logs from the same connection attempt**, not sequential ones
minutes apart. Concretely:

1. Connect (Wi-Fi first). Get both ROMs to their in-game link screens.
2. Let it sit for a few seconds — long enough to accumulate a real sample,
   short enough that `Copy link log`'s 20000-line window comfortably
   covers the whole thing on both phones.
3. Open `Copy link log` on **both** phones within the same short window,
   right after, before doing anything else.
4. Repeat over Bluetooth.

With items 1-2 from this pass in place, that capture should show, per
phone: every exchange the host triggered and what actually came back
(timeout or real data, and what data); every exchange the child's own
receive path actually processed, or logged as skipped and why. If the
"mutual reset livelock" theory is right, the host's `recv=` values during
a child's own reset window should visibly be the same placeholder-looking
values (`0xFEFE`/`0x0000`) the child logs show it writing to its own
SIOMLT_SEND right around then — checkable for the first time with a
matched pair of logs and approximately synchronized clocks (both phones'
system clocks, not the app — logcat timestamps are wall-clock).

## The debug-log tool doesn't work on every phone

W reported and screenshotted an empty capture (`"(no matching lines
yet...)"`) on one phone, while the other produced real output — the three
files above. Not addressed as a code fix this pass. Likely explanation,
not fully confirmed: a non-root, non-system, non-debuggable app's ability
to read back even its own logcat output varies by Android version and OEM
policy — some builds allow it unconditionally, some restrict it further.
Shizuku (which W already has working on the productive phone) is a common
workaround for exactly this, which is itself circumstantial evidence for
this explanation over some other cause.

A durable fix would mean not depending on OS logcat access at all — e.g.
the app writing its own diagnostic lines to a private file directly (both
from Kotlin and, via a small JNI addition, from this file's own LOGI/LOGW
call sites) and having `copyLinkDebugLog()` read that file back instead of
shelling out to `logcat`. That's a real feature addition (new JNI entry
point, a file path handshake at startup, touching every existing log call
site) — not attempted blind, in the same pass as everything else above,
given there's no device or compiler here to catch a mistake in it. Worth
doing if the one working phone turns out not to be enough to finish this
investigation; not yet necessary, since it's currently providing usable
evidence on its own.

## Found but not addressed this pass

- Everything in this section from the Fifteenth pass below is still open.
- The Twelfth-pass "many exchanges within one 16ms window" observation
  (further below, unmoved for several passes now) looks, in hindsight,
  like an earlier sighting of the exact same fast-repeating-attempts
  pattern `wifi_host.text` shows clearly this pass. Worth formally
  connecting once a matched host+child capture exists to check against.

# KNOWN_LIMITATIONS — Earlier passes (summary)

Full write-ups trimmed for length. The throughline, condensed:

- **Fifteenth** — Built the exchange-result/child-exchange trace logging
  that Sixteenth pass's evidence and this pass's matched capture both
  depend on. No new evidence of its own yet.
- **Thirteenth** — Save-state thumbnails pass; no new link evidence.
- **Twelfth** — Added the (logcat-based) "Copy link log" tool. First step
  toward getting any real evidence at all, but no capture yet.
- **Ninth** — First pass to explicitly ask for real logcat evidence
  instead of another round of static-only theorizing; none available yet.
- **Eighth** — Seventh pass's real IRQ fix produced zero observed change
  on either test game. Flagged that this pointed further upstream than
  more protocol guessing could reach from this sandbox alone.
- **Seventh** — SIO IRQ fix (see BUGS_FIXED.md); expected to matter for
  interrupt-driven ROMs specifically.
- **Sixth** — The original root-cause pass: child never answers the host
  at all (fixed with the passive responder), SIOCNT status bits never
  set, peer-disconnect never detected.
- **Fifth** — First multiplayer-focused pass; thread-safety and socket-
  lifecycle fixes, no protocol-level work yet.

Every pass from the Sixth through the Seventeenth shares one constraint,
unchanged until this pass: no Android device or NDK toolchain in this
sandbox, so nothing has ever been build- or runtime-verified here — every
fix is confirmed only by static reading against GBATEK and/or mGBA's own
source, and by whatever the user reports back after a real-device test.
