package com.shadowborn.game;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import java.util.Random;

/**
 * Particles, rings, floating text, the sword trail, dash speed streaks, impact flashes and screen-level effects
 * (shake, camera kick, hit-stop, flash). Everything lives in fixed ring buffers: no allocation while playing.
 */
final class Fx {
    private static final int MAXP = 240, MAXR = 14, MAXT = 10, MAXTR = 72, MAXS = 28, MAXF = 8;
    private static final float TRAIL_LIFE = 0.2f, TEXT_LIFE = 0.8f, RING_LIFE = 0.35f, STREAK_LIFE = 0.16f, FLASH_LIFE = 0.14f;

    final Random rnd = new Random();
    float freeze, shake, slowT, flashA, kickX, kickY;
    int flashC = 0xFFFFFFFF;

    private final float[] px = new float[MAXP], py = new float[MAXP], pvx = new float[MAXP], pvy = new float[MAXP];
    private final float[] pl = new float[MAXP], pm = new float[MAXP], ps = new float[MAXP], pg = new float[MAXP];
    private final int[] pc = new int[MAXP];
    private int pcur;

    private final float[] rx = new float[MAXR], ry = new float[MAXR], rm = new float[MAXR], rl = new float[MAXR];
    private final int[] rc = new int[MAXR];
    private int rcur;

    private final float[] tx = new float[MAXT], ty = new float[MAXT], tl = new float[MAXT];
    private final String[] ts = new String[MAXT];
    private final int[] tc = new int[MAXT];
    private int tcur;

    private final float[] trBx = new float[MAXTR], trBy = new float[MAXTR], trTx = new float[MAXTR], trTy = new float[MAXTR];
    private final float[] trl = new float[MAXTR];
    private final boolean[] trFirst = new boolean[MAXTR];
    private final int[] trc = new int[MAXTR];
    private int trCur;

    private final float[] sx = new float[MAXS], sy = new float[MAXS], slen = new float[MAXS], sdir = new float[MAXS], sl = new float[MAXS];
    private final int[] sc = new int[MAXS];
    private int scur;

    private final float[] fx0 = new float[MAXF], fy0 = new float[MAXF], fr0 = new float[MAXF], fl0 = new float[MAXF];
    private int fcur;

    void emit(float x, float y, float vx, float vy, float life, float size, int col, float grav) {
        int i = pcur;
        pcur = (pcur + 1) % MAXP;
        px[i] = x; py[i] = y; pvx[i] = vx; pvy[i] = vy;
        pl[i] = life; pm[i] = life; ps[i] = size; pc[i] = col; pg[i] = grav;
    }

    void burst(float x, float y, int n, int col, float speed, float life, float size) {
        for (int i = 0; i < n; i++) {
            float a = rnd.nextFloat() * 6.2832f, s = speed * (0.3f + 0.7f * rnd.nextFloat());
            emit(x, y, (float) Math.cos(a) * s, (float) Math.sin(a) * s, life * (0.6f + 0.4f * rnd.nextFloat()), size, col, 0f);
        }
    }

    /** Directional sparks; dirX is -1 or +1. */
    void sparks(float x, float y, float dirX, int col) {
        for (int i = 0; i < 9; i++) {
            float a = (rnd.nextFloat() - 0.5f) * 2.2f, s = 120f + rnd.nextFloat() * 220f;
            emit(x, y, (float) Math.cos(a) * s * dirX, (float) Math.sin(a) * s - 40f, 0.25f + rnd.nextFloat() * 0.25f, 1.6f + rnd.nextFloat(), col, 500f);
        }
    }

    /** Sparks thrown along the direction ang (radians, screen space) with a narrow spread. */
    void sparksAng(float x, float y, float ang, int n, int col) {
        for (int i = 0; i < n; i++) {
            float a = ang + (rnd.nextFloat() - 0.5f) * 0.9f, s = 140f + rnd.nextFloat() * 260f;
            emit(x, y, (float) Math.cos(a) * s, (float) Math.sin(a) * s - 30f, 0.2f + rnd.nextFloat() * 0.22f, 1.5f + rnd.nextFloat() * 1.2f, col, 420f);
        }
    }

    void dust(float x, float y) {
        for (int i = 0; i < 6; i++) {
            emit(x + (rnd.nextFloat() - 0.5f) * 10f, y - 1f, (rnd.nextFloat() - 0.5f) * 70f, -rnd.nextFloat() * 30f, 0.35f, 2.4f, 0xFFB8B0C8, 0f);
        }
    }

    /** Landing dust that scales with the impact (power 0..1): a wider, faster puff for harder landings. */
    void dustLand(float x, float y, float power) {
        int n = 4 + (int) (8f * power);
        for (int i = 0; i < n; i++) {
            float side = i % 2 == 0 ? -1f : 1f;
            emit(x + side * 3f, y - 1f, side * (30f + rnd.nextFloat() * (50f + 90f * power)), -rnd.nextFloat() * (20f + 30f * power),
                0.28f + 0.18f * rnd.nextFloat(), 2f + 1.6f * power, 0xFFB8B0C8, 60f);
        }
    }

    /** Small puff kicked backwards while running or skidding (dir = direction of travel). */
    void dustTrail(float x, float y, float dir, int n) {
        for (int i = 0; i < n; i++) {
            emit(x + (rnd.nextFloat() - 0.5f) * 4f, y - 1f, -dir * (20f + rnd.nextFloat() * 40f), -rnd.nextFloat() * 26f,
                0.26f + 0.12f * rnd.nextFloat(), 1.8f + rnd.nextFloat(), 0xFFB8B0C8, 0f);
        }
    }

    void ring(float x, float y, float maxR, int col) {
        int i = rcur;
        rcur = (rcur + 1) % MAXR;
        rx[i] = x; ry[i] = y; rm[i] = maxR; rl[i] = RING_LIFE; rc[i] = col;
    }

    void text(float x, float y, String s, int col) {
        int i = tcur;
        tcur = (tcur + 1) % MAXT;
        tx[i] = x; ty[i] = y; ts[i] = s; tc[i] = col; tl[i] = TEXT_LIFE;
    }

    /** Adds one sword-trail sample; first = true starts a new strip. */
    void trail(float bx, float by, float tipX, float tipY, boolean first) {
        trail(bx, by, tipX, tipY, first, 0xFF58E0FF);
    }

    void trail(float bx, float by, float tipX, float tipY, boolean first, int col) {
        int i = trCur;
        trCur = (trCur + 1) % MAXTR;
        trBx[i] = bx; trBy[i] = by; trTx[i] = tipX; trTy[i] = tipY; trl[i] = TRAIL_LIFE; trFirst[i] = first; trc[i] = col;
    }

    /** A horizontal speed line that trails behind (x, y); dir is the direction of travel. */
    void streak(float x, float y, float len, float dir, int col) {
        int i = scur;
        scur = (scur + 1) % MAXS;
        sx[i] = x; sy[i] = y; slen[i] = len; sdir[i] = dir; sl[i] = STREAK_LIFE; sc[i] = col;
    }

    /** Bright flash at a point of contact. */
    void flash(float x, float y, float r) {
        int i = fcur;
        fcur = (fcur + 1) % MAXF;
        fx0[i] = x; fy0[i] = y; fr0[i] = r; fl0[i] = FLASH_LIFE;
    }

    void shake(float m) {
        if (m > shake) shake = m;
    }

    /** Camera shove (world units) that springs back; used for hit and dash punch. */
    void kick(float dx, float dy) {
        kickX += dx;
        kickY += dy;
        float m = 7f;
        kickX = Math.max(-m, Math.min(m, kickX));
        kickY = Math.max(-m, Math.min(m, kickY));
    }

    void update(float dt) {
        for (int i = 0; i < MAXP; i++) {
            if (pl[i] <= 0f) continue;
            pl[i] -= dt;
            pvy[i] += pg[i] * dt;
            px[i] += pvx[i] * dt;
            py[i] += pvy[i] * dt;
        }
        for (int i = 0; i < MAXR; i++) if (rl[i] > 0f) rl[i] -= dt;
        for (int i = 0; i < MAXT; i++) if (tl[i] > 0f) tl[i] -= dt;
        for (int i = 0; i < MAXTR; i++) if (trl[i] > 0f) trl[i] -= dt;
        for (int i = 0; i < MAXS; i++) if (sl[i] > 0f) sl[i] -= dt;
        for (int i = 0; i < MAXF; i++) if (fl0[i] > 0f) fl0[i] -= dt;
        shake *= Math.max(0f, 1f - 10f * dt);
        if (shake < 0.05f) shake = 0f;
        float kd = Math.max(0f, 1f - 13f * dt);
        kickX *= kd;
        kickY *= kd;
        if (Math.abs(kickX) < 0.02f) kickX = 0f;
        if (Math.abs(kickY) < 0.02f) kickY = 0f;
        if (slowT > 0f) slowT -= dt;
        if (flashA > 0f) flashA = Math.max(0f, flashA - dt * 2.5f);
    }

    /** World-space effects: trail, particles, rings and floating numbers. */
    void draw(Canvas c) {
        Paint p = Art.P;
        Path pa = Art.PA;
        p.setStyle(Paint.Style.FILL);
        for (int k = 1; k < MAXTR; k++) {
            int i = (trCur + k - 1) % MAXTR, j = (trCur + k) % MAXTR;
            if (trl[i] <= 0f || trl[j] <= 0f || trFirst[j]) continue;
            pa.reset();
            pa.moveTo(trBx[i], trBy[i]);
            pa.lineTo(trTx[i], trTy[i]);
            pa.lineTo(trTx[j], trTy[j]);
            pa.lineTo(trBx[j], trBy[j]);
            pa.close();
            p.setColor(trc[j]);
            p.setAlpha((int) (96f * trl[j] / TRAIL_LIFE));
            c.drawPath(pa, p);
        }
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        for (int k = 1; k < MAXTR; k++) {
            int i = (trCur + k - 1) % MAXTR, j = (trCur + k) % MAXTR;
            if (trl[i] <= 0f || trl[j] <= 0f || trFirst[j]) continue;
            float a = trl[j] / TRAIL_LIFE;
            p.setStrokeWidth(1.0f + 1.9f * a);
            p.setColor(0xFFFFFFFF);
            p.setAlpha((int) (240f * a));
            c.drawLine(trTx[i], trTy[i], trTx[j], trTy[j], p);
        }
        p.setStrokeWidth(1.6f);
        for (int i = 0; i < MAXS; i++) {
            if (sl[i] <= 0f) continue;
            float k = sl[i] / STREAK_LIFE;
            p.setColor(sc[i]);
            p.setAlpha((int) (210f * k));
            c.drawLine(sx[i], sy[i], sx[i] - sdir[i] * slen[i] * (0.35f + 0.65f * k), sy[i], p);
        }
        p.setStyle(Paint.Style.FILL);
        for (int i = 0; i < MAXP; i++) {
            if (pl[i] <= 0f) continue;
            float k = pl[i] / pm[i];
            p.setColor(pc[i]);
            p.setAlpha((int) (255f * k));
            c.drawCircle(px[i], py[i], ps[i] * (0.4f + 0.6f * k), p);
        }
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2f);
        for (int i = 0; i < MAXR; i++) {
            if (rl[i] <= 0f) continue;
            float k = rl[i] / RING_LIFE;
            p.setColor(rc[i]);
            p.setAlpha((int) (230f * k));
            c.drawCircle(rx[i], ry[i], rm[i] * (1f - k * k) + 2f, p);
        }
        for (int i = 0; i < MAXF; i++) {
            if (fl0[i] <= 0f) continue;
            float k = fl0[i] / FLASH_LIFE;
            Art.glow(c, Art.GLOW_WHITE, fx0[i], fy0[i], fr0[i] * (0.6f + 0.6f * (1f - k)), 0.95f * k);
        }
        p.setStyle(Paint.Style.FILL);
        p.setTypeface(Art.FONT);
        p.setTextSize(11f);
        p.setTextAlign(Paint.Align.CENTER);
        for (int i = 0; i < MAXT; i++) {
            if (tl[i] <= 0f) continue;
            float k = tl[i] / TEXT_LIFE;
            p.setColor(tc[i]);
            p.setAlpha((int) (255f * Math.min(1f, k * 2f)));
            c.drawText(ts[i], tx[i], ty[i] - (1f - k) * 24f, p);
        }
    }

    /** Screen-space drifting embers. */
    void ambient(Canvas c, float vw, float vh, float time, int col) {
        Paint p = Art.P;
        p.setStyle(Paint.Style.FILL);
        p.setColor(col);
        for (int i = 0; i < 18; i++) {
            float k = i * 0.6180339f;
            float x = ((k * 977f + time * (8f + (i % 5) * 4f)) % (vw + 40f)) - 20f + (float) Math.sin(time * 1.3f + i) * 8f;
            float y = vh - ((k * 531f + time * (14f + (i % 4) * 6f)) % (vh + 20f)) + 10f;
            p.setAlpha((int) (90f + 60f * Math.sin(time * 3f + i * 2f)));
            c.drawCircle(x, y, 1.1f + (i % 3) * 0.5f, p);
        }
    }
}
