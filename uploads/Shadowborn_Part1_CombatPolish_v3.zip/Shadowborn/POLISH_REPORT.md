# Shadowborn - combat / movement polish (work in progress)

Status: **iteration 3 of the critic loop**. Compiles against the headless Android stubs and passes the existing
regression (`tools/headless/run.sh`: 40 sim checks + 80 new mechanics checks + 720 000-frame monkey soak, ~20 s). NOT yet built with the real Android SDK
or played on a device - please build it with your GitHub Actions workflow and report anything that feels off.

## What changed so far
* **Player rewritten** (`Player.java`): explicit move tables (startup / active / recovery frames), pose-blend animation,
  swept-blade hit detection. Public fields used elsewhere (hp, facing, atk, atkT, dodgeT, dodgeCd, invuln ...) kept.
* **Jump**: asymmetric gravity (snappier fall), apex hang, gravity-based jump cut (smooth short hops, min hop 34 units),
  coyote 0.10 s, buffer 0.14 s, ceiling-corner nudge, ledge step-up (<= 7 units), air drag / reverse-turn accel,
  landing squash scaled by impact. Full-jump height 86.6 (was 85.8) and run-jump reach 133 (was 130): level geometry unchanged.
* **Double jump**: somersault with tucked pose, wraith afterimages, double ring, feather burst, redirect on press,
  "smart" buffering (a press just before landing becomes a ground jump instead of wasting the double jump),
  floatier descent after the second jump (keeps the DJ-gated gaps as forgiving as before).
* **Dash**: instant full speed, eased exit (no hard stop), full-figure afterimages, speed streaks, dust, ring, camera kick,
  wall bump instead of grinding, sub-stepped collision, cooldown shown on the button.
  **Air dash now needs Wraith Stride** (see "bug found").
* **Attacks**: ground combo 10/12/22 (same damage), aerial combo (slash, reverse slash, plunge finisher 22 + landing slam),
  dash slash. Hits register only when the swept blade touches the enemy (before: hit at frame 4 with the blade still
  overhead, up to ~70 units away; stage 3 hit with the blade behind the hero). Smooth slash arcs, hit-stop, flash,
  directional sparks, camera kick. Lunge auto-spaces to the nearest enemy.
* **Bug found in the original**: jump + air dodge crossed the 6-tile chasm WITHOUT the double jump (2154 of 3528 tested
  timings). The old bot test never pressed dodge. Fixed: the air dash is part of Wraith Stride; ground dash unchanged.

## Exploits the new gating search found in MY OWN first draft (all fixed)
The mechanics suite throws 20 000 random jump / attack / dash programs per spot at the double-jump gates:
1. Aerial-slash hover applied while still rising = anti-gravity (+16..60 units): reached the secret ledge without the double jump.
   Now the hover is only earned when an aerial slash connects, and only slows a fall.
2. Ground dash -> dash slash -> coyote jump launched from mid-chasm at dash speed. Coyote time is now void when leaving the
   ground mid-dash or above run speed, and a jump's takeoff speed is capped at run speed.
3. A jump cancelled out of a dash used the dash's zero gravity on its first frame (+8.7 units of apex). Fixed.
Result with 20 000 programs per spot: chasm closest approach 37 units short, secret ledge 40 units short (needs the double jump).

## Not done yet (next loops)
* README / PROJECT_STATE update, render interpolation for non-60 Hz displays (unverified without a device).

## Tests added (tools/headless/sim/.../Mechanics.java, run by run.sh)
Input latency (press frame = frame 0), buffers, coyote, corner nudge, ledge step-up, jump height/air-time/reach vs the
original, double-jump rules and resets, smart buffering, dash distance/cooldown/i-frames/wall collision/tunnelling,
attack frame tables, blade-vs-hit synchronisation (no hit without the blade near, no whiff through the blade),
cancels and combos, random-input invariant fuzz (360 000 frames), gating search, allocation per frame.

## Tools added
* `tools/headless/shots.sh` + `sheet.py`: renders real game frames to PNG through a Java2D shim and builds contact sheets
  (this is how the animations were inspected). It approximates, not reproduces, Android's Canvas.
