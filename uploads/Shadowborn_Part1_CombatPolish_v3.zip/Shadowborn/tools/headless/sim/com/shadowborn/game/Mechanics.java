package com.shadowborn.game;

import java.lang.management.ManagementFactory;
import java.lang.reflect.Method;
import java.util.Random;

/**
 * Mechanics test suite (not shipped in the APK): input latency, buffers, jump physics, double jump, dash, attack timing,
 * blade/hit synchronisation, combos and cancels, a random-input invariant fuzz and a progression-gating search.
 * Everything runs headless against the real Player/Game code at the fixed 60 Hz step.
 * Usage: java Mechanics [gatingProgramsPerSpot] (default 12000)
 */
public class Mechanics {
    static final float DT = 1f / 60f, FLOOR = 10 * 32f;
    static int failures, checks;

    static void check(boolean ok, String what) {
        checks++;
        System.out.println((ok ? "PASS  " : "FAIL  ") + what);
        if (!ok) failures++;
    }

    static void info(String s) {
        System.out.println("      " + s);
    }

    // ------------------------------------------------------------------ fixtures

    /** A fresh game standing on the floor of room 0 with no enemies. */
    static Game arena(boolean dj) {
        Game g = Sim.newGame(new Sim.Prefs());
        g.save.shake = false;
        Sim.tap(g, g.btnPlay);
        g.enemies.clear(); g.projs.clear(); g.pickups.clear(); g.boss = null;
        g.save.dj = dj;
        g.player.hasDJ = dj;
        g.player.maxHp = g.player.hp = 100000;
        g.player.place(44 * 32 + 8f, FLOOR - g.player.h);
        for (int i = 0; i < 40; i++) { g.input.clear(); g.update(DT); }
        return g;
    }

    static void step(Game g, boolean l, boolean r, boolean j, boolean a, boolean d) {
        g.input.set(l, r, j, a, d);
        g.bannerT = 0f;
        g.update(DT);
    }

    static void idle(Game g, int n) {
        for (int i = 0; i < n; i++) step(g, false, false, false, false, false);
    }

    static boolean finite(float v) {
        return !Float.isNaN(v) && !Float.isInfinite(v);
    }

    // ------------------------------------------------------------------ 1. input latency

    static void latency() {
        System.out.println("-- input latency (frame of the press = frame 0)");
        Game g = arena(false);
        Player p = g.player;
        step(g, false, false, true, false, false);
        check(p.vy < -400f && !p.onGround, "jump: launch velocity applied on the press frame (vy=" + (int) p.vy + ")");
        g = arena(false);
        p = g.player;
        step(g, false, false, false, true, false);
        check(p.atk == 1, "attack: move starts on the press frame");
        check(p.fig.swordAng > 1.6f, "attack: blade already moving on the press frame (sword angle " + String.format("%.2f", p.fig.swordAng) + ")");
        g = arena(false);
        p = g.player;
        step(g, false, false, false, false, true);
        check(p.dodgeT > 0f && Math.abs(p.vx) >= 500f, "dash: full speed on the press frame (vx=" + (int) p.vx + ")");
        g = arena(true);
        p = g.player;
        for (int f = 0; f < 3; f++) step(g, false, false, true, false, false);
        step(g, false, false, false, false, false);
        for (int f = 0; f < 6; f++) step(g, false, false, false, false, false);
        step(g, false, false, true, false, false);
        check(p.vy < -400f && p.jumpsLeft() == 0, "double jump: launch velocity applied on the press frame (vy=" + (int) p.vy + ")");
    }

    // ------------------------------------------------------------------ 2. jump physics

    /** returns {apex height, air frames, horizontal distance, peak fall speed} */
    static float[] jump(int hold, boolean right) {
        Game g = arena(false);
        Player p = g.player;
        if (right) for (int i = 0; i < 30; i++) step(g, false, true, false, false, false);
        final float y0 = p.y, x0 = p.x;
        float min = y0, peak = 0f;
        int air = 0;
        for (int f = 0; f < 150; f++) {
            step(g, false, right, f < hold, false, false);
            min = Math.min(min, p.y);
            peak = Math.max(peak, p.vy);
            if (p.onGround && f > 2) { air = f; break; }
        }
        return new float[] {y0 - min, air, p.x - x0, peak};
    }

    static void jumps() {
        System.out.println("-- jump physics");
        float[] full = jump(40, false), tap = jump(1, false), run = jump(40, true);
        check(full[0] >= 84f && full[0] <= 90f, "full jump apex " + String.format("%.1f", full[0]) + " units (original 85.8; level geometry needs 84-90)");
        check(full[1] >= 38 && full[1] <= 44, "full jump air time " + (int) full[1] + " frames (original 40)");
        check(run[2] >= 125f && run[2] <= 140f, "run-jump reach " + String.format("%.1f", run[2]) + " units (original 129.8)");
        check(tap[0] >= 30f && tap[0] <= 45f, "tap hop " + String.format("%.1f", tap[0]) + " units (original 26.6: a tap now clears a useful step)");
        float a4 = jump(4, false)[0], a8 = jump(8, false)[0], a14 = jump(14, false)[0], a22 = jump(22, false)[0];
        check(a4 < a8 && a8 < a14 && a14 < a22, "variable height is monotonic: hold 4/8/14/22 -> " + (int) a4 + "/" + (int) a8 + "/" + (int) a14 + "/" + (int) a22);
        check(full[3] > 520f * 1.1f, "falls faster than it rises (peak fall speed " + (int) full[3] + " vs launch 520)");

        // air control
        Game g = arena(false);
        Player p = g.player;
        step(g, false, true, true, false, false);
        int toFull = -1;
        for (int f = 1; f < 30 && toFull < 0; f++) { step(g, false, true, true, false, false); if (p.vx >= 188f) toFull = f; }
        check(toFull >= 0 && toFull <= 8, "air control: full speed " + toFull + " frames after leaving the ground");
        int toZero = -1;
        for (int f = 1; f < 30 && toZero < 0; f++) { step(g, true, false, true, false, false); if (p.vx <= 0f) toZero = f; }
        check(toZero >= 0 && toZero <= 8, "air control: reversal through zero in " + toZero + " frames");
        g = arena(false);
        p = g.player;
        step(g, false, true, false, false, false);
        for (int f = 0; f < 30; f++) step(g, false, true, false, false, false);
        for (int f = 0; f < 5; f++) step(g, false, true, false, false, false);
        check(p.vx >= 189f, "ground run reaches full speed (vx=" + (int) p.vx + ")");

        // coyote time
        for (int k : new int[] {3, 8}) {
            g = arena(false);
            p = g.player;
            p.place(1280f - 60f, FLOOR - p.h);
            for (int i = 0; i < 5; i++) step(g, false, true, false, false, false);
            int off = 0;
            for (int f = 0; f < 120 && p.onGround; f++) step(g, false, true, false, false, false);
            for (int f = 1; f < k; f++) step(g, false, true, false, false, false);
            step(g, false, true, true, false, false);
            final boolean jumped = p.vy < -400f;
            if (k == 3) check(jumped, "coyote: jump " + k + " frames after leaving a ledge works");
            else check(!jumped, "coyote: jump " + k + " frames after leaving a ledge is refused (window is 6 frames)");
        }

        // jump buffer: press n frames before touchdown
        int landFrame = -1;
        {
            Game b = arena(false);
            for (int f = 0; f < 80; f++) { step(b, false, false, f < 20, false, false); if (f > 3 && b.player.onGround) { landFrame = f; break; } }
        }
        for (int n : new int[] {6, 14}) {
            g = arena(false);
            p = g.player;
            boolean launched = false;
            for (int f = 0; f <= landFrame + 3; f++) {
                step(g, false, false, f < 20 || f == landFrame - n, false, false);
                if (f > landFrame - 1 && p.vy < -400f) launched = true;
            }
            if (n == 6) check(launched, "jump buffer: a press 6 frames before landing jumps on touchdown");
            else check(!launched, "jump buffer: a press 14 frames before landing is not remembered (buffer is ~8 frames)");
        }

        // ceiling corner nudge: a block overhead catches only the edge of the head
        for (float overlap : new float[] {3f, 9f}) {
            g = arena(false);
            p = g.player;
            g.world.room.put(50, 6, '#');
            p.place(1600f - p.w + overlap, FLOOR - p.h);
            idle(g, 5);
            final float x0 = p.x;
            float min = p.y;
            for (int f = 0; f < 50; f++) { step(g, false, false, f < 25, false, false); min = Math.min(min, p.y); }
            final float rise = FLOOR - p.h - min;
            if (overlap < 6f) check(rise > 80f && p.x < x0 - 1f, "corner nudge: overlapping a ceiling edge by " + (int) overlap + " units slides past it (rise " + (int) rise + ")");
            else check(rise < 70f, "corner nudge: overlapping by " + (int) overlap + " units still bonks (rise " + (int) rise + ")");
        }

        // ledge step-up: feet a few units below a platform top while pressing into its side
        for (float below : new float[] {5f, 11f}) {
            g = arena(false);
            p = g.player;
            for (int tx = 50; tx <= 58; tx++) g.world.room.put(tx, 8, '#');       // platform top at y = 256
            p.place(1600f - p.w - 1f, 256f - p.h + below);
            p.vx = 0f;
            idle(g, 2);
            for (int f = 0; f < 40; f++) step(g, false, true, false, false, false);
            final boolean up = p.onGround && Math.abs(p.y + p.h - 256f) < 0.6f;
            if (below < 7f) check(up, "ledge step-up: " + (int) below + " units below a platform edge climbs onto it");
            else check(!up && p.x + p.w <= 1600.01f, "ledge step-up: " + (int) below + " units below is a wall (no free climb)");
        }
    }

    // ------------------------------------------------------------------ 3. double jump

    static void doubleJump() {
        System.out.println("-- double jump");
        Game g = arena(true);
        Player p = g.player;
        for (int f = 0; f < 30; f++) step(g, false, false, f < 25, false, false);
        // we are past the apex of the first jump: press again
        float vyBefore = p.vy;
        step(g, false, false, true, false, false);
        check(vyBefore > -200f && p.vy < -450f, "second press in the air launches (vy " + (int) vyBefore + " -> " + (int) p.vy + ")");
        step(g, false, false, false, false, false);
        for (int f = 0; f < 6; f++) step(g, false, false, false, false, false);
        step(g, false, false, true, false, false);
        check(p.vy > -450f, "a third press does nothing (only one air jump)");
        for (int f = 0; f < 150 && !p.onGround; f++) step(g, false, false, false, false, false);
        idle(g, 3);
        check(p.jumpsLeft() == 1, "landing restores the air jump");
        for (int f = 0; f < 30; f++) step(g, false, false, f < 25, false, false);
        step(g, false, false, false, false, false);
        step(g, false, false, true, false, false);
        check(p.vy < -450f, "the air jump works again after landing");

        g = arena(false);
        p = g.player;
        for (int f = 0; f < 30; f++) step(g, false, false, f < 25, false, false);
        step(g, false, false, true, false, false);
        check(p.vy > -200f, "without Wraith Stride there is no double jump");

        // a press just before touchdown must become a ground jump, not burn the air jump
        g = arena(true);
        p = g.player;
        for (int f = 0; f < 22; f++) step(g, false, false, f < 20, false, false);
        step(g, false, false, false, false, false);
        int guard = 0;
        while ((p.y + p.h) < FLOOR - 18f && guard++ < 100) step(g, false, false, false, false, false);
        final float vyAtPress = p.vy;
        step(g, false, false, true, false, false);
        check(vyAtPress > 0f && p.vy > 0f, "press 18 units above the floor does not fire the air jump in mid-air (vy=" + (int) p.vy + ")");
        boolean launched = false;
        for (int f = 0; f < 8 && !launched; f++) { step(g, false, false, false, false, false); launched = p.vy < -450f; }
        check(launched, "...it becomes a ground jump when the hero lands");
        check(p.jumpsLeft() == 1, "...and the air jump is still available");

        // redirect: holding the other way when double jumping turns the hero around at once
        g = arena(true);
        p = g.player;
        for (int f = 0; f < 22; f++) step(g, false, true, f < 20, false, false);
        step(g, false, true, false, false, false);
        step(g, true, false, true, false, false);
        check(p.vx < 0f && p.facing == -1, "double jump while holding the opposite direction redirects (vx=" + (int) p.vx + ")");

        // somersault: the body actually rotates a full turn
        g = arena(true);
        p = g.player;
        for (int f = 0; f < 22; f++) step(g, false, false, f < 20, false, false);
        step(g, false, false, false, false, false);
        step(g, false, false, true, false, false);
        float maxRot = 0f;
        for (int f = 0; f < 30; f++) { step(g, false, false, f < 14, false, false); maxRot = Math.max(maxRot, Math.abs(p.fig.rot)); }
        check(maxRot > 5.5f, "double jump has its own animation: somersault rotation reaches " + String.format("%.1f", maxRot) + " rad");
    }

    // ------------------------------------------------------------------ 4. dash

    static void dash() {
        System.out.println("-- dash");
        Game g = arena(false);
        Player p = g.player;
        final float x0 = p.x;
        int start = -1, end = -1;
        float peak = 0f, worstDrop = 0f, lastV = 0f;
        for (int f = 0; f < 70; f++) {
            step(g, false, false, false, false, f == 2);
            if (start < 0 && p.dodgeT > 0f) start = f;
            if (start >= 0 && end < 0 && p.dodgeT <= 0f) end = f;
            if (start >= 0 && f > start) worstDrop = Math.max(worstDrop, Math.abs(lastV) - Math.abs(p.vx));
            lastV = p.vx;
            peak = Math.max(peak, Math.abs(p.vx));
        }
        final float dist = p.x - x0;
        check(dist >= 95f && dist <= 118f, "ground dash distance " + String.format("%.1f", dist) + " units (original 104)");
        check(end - start >= 13 && end - start <= 16, "ground dash lasts " + (end - start) + " frames (original 14)");
        check(peak >= 500f, "dash peak speed " + (int) peak);
        check(worstDrop <= 90f, "no hard stop: largest speed drop in one frame " + (int) worstDrop + " (original 310)");

        g = arena(false);
        p = g.player;
        step(g, true, false, false, false, true);
        check(p.vx < 0f && p.facing == -1, "dash goes the way the stick is held (even backwards)");
        g = arena(false);
        p = g.player;
        step(g, false, false, false, false, true);
        check(p.vx > 0f && p.facing == 1, "dash with no direction goes the way the hero faces");

        // cooldown and buffering
        g = arena(false);
        p = g.player;
        int first = -1, second = -1;
        for (int f = 0; f < 120; f++) {
            final boolean wasDash = p.dodgeT > 0f;
            step(g, false, false, false, false, f % 2 == 0);
            if (!wasDash && p.dodgeT > 0f) { if (first < 0) first = f; else if (second < 0) second = f; }
        }
        check(second - first >= 32 && second - first <= 35, "dash cooldown " + (second - first) + " frames start-to-start (0.55 s = 33; original 42)");
        for (int early : new int[] {8, 22}) {
            g = arena(false);
            p = g.player;
            step(g, false, false, false, false, true);
            idle(g, 40);
            // cooldown is over at frame 33 after the first dash began; press `early` frames before that
            g = arena(false);
            p = g.player;
            step(g, false, false, false, false, true);
            int f0 = 1, startedAt = -1;
            for (int f = f0; f < 80 && startedAt < 0; f++) {
                step(g, false, false, false, false, f == 33 - early);
                if (f > 33 - early && p.dodgeT > 0f && p.dodgeT > 0.2f) startedAt = f;
            }
            if (early == 8) check(startedAt >= 33 && startedAt <= 35, "dash buffer: a press 8 frames early fires when ready (frame " + startedAt + ")");
            else check(startedAt < 0 || startedAt > 40, "dash buffer: a press 22 frames early is not remembered");
        }

        // invulnerability covers the whole dash
        g = arena(false);
        p = g.player;
        p.hp = p.maxHp = 100;
        boolean allInv = true;
        for (int f = 0; f < 20; f++) {
            step(g, false, false, false, false, f == 0);
            if (p.dodgeT > 0f && p.invuln <= 0f) allInv = false;
            if (f == 6) p.hurt(g, 30, p.cx() - 10f);
        }
        check(allInv && p.hp == 100, "dash is invulnerable from the first to the last frame (hp " + p.hp + ")");

        // collision: wall bump instead of grinding, never inside a wall
        g = arena(false);
        p = g.player;
        p.place(60f, FLOOR - p.h);
        idle(g, 3);
        boolean inside = false;
        int bumped = -1;
        for (int f = 0; f < 30; f++) {
            step(g, true, false, false, false, f == 0);
            if (!p.free(g.world, p.x, p.y)) inside = true;
            if (bumped < 0 && p.dodgeT <= 0f && f > 0) bumped = f;
        }
        check(!inside && Math.abs(p.x) < 0.01f, "dash into the room wall stops flush against it (x=" + String.format("%.2f", p.x) + ")");
        check(bumped >= 0 && bumped < 12, "the dash ends on impact (frame " + bumped + " of " + (int) (Player.DASH_T_GROUND * 60) + ")");

        g = arena(false);
        p = g.player;
        g.world.room.put(50, 8, '#');
        g.world.room.put(50, 9, '#');
        p.place(1500f, FLOOR - p.h);
        idle(g, 3);
        inside = false;
        for (int f = 0; f < 30; f++) {
            step(g, false, true, false, false, f == 0);
            if (!p.free(g.world, p.x, p.y)) inside = true;
        }
        check(!inside && p.x + p.w <= 1600.01f, "a one-tile wall stops the dash (right edge " + String.format("%.1f", p.x + p.w) + " <= 1600)");

        // air dash: needs Wraith Stride, once per air time, flat
        g = arena(false);
        p = g.player;
        boolean any = false;
        for (int f = 0; f < 40; f++) { step(g, false, true, f < 20, false, f == 8 || f == 9); if (f > 4 && p.dodgeT > 0f && !p.onGround) any = true; }
        check(!any, "before Wraith Stride the dash cannot be used in mid-air");
        g = arena(true);
        p = g.player;
        float yAtStart = 0f, maxDy = 0f;
        boolean dashed = false;
        int dashes = 0;
        boolean was = false;
        for (int f = 0; f < 120; f++) {
            final boolean jmp = f < 20 || (f >= 26 && f < 44);
            step(g, false, true, jmp, false, f == 8 || f == 9 || f == 50 || f == 51 || f == 52);
            if (p.dodgeT > 0f && !p.onGround && !was) { dashes++; yAtStart = p.y; dashed = true; }
            if (p.dodgeT > 0f && dashed) maxDy = Math.max(maxDy, Math.abs(p.y - yAtStart));
            was = p.dodgeT > 0f;
            if (p.onGround && f > 60) break;
        }
        check(dashes == 1, "after Wraith Stride: one air dash per air time (" + dashes + ")");
        check(maxDy < 0.5f, "air dash holds its height (max drift " + String.format("%.2f", maxDy) + " units)");

        // a dash pressed shortly before landing starts on touchdown
        g = arena(false);
        p = g.player;
        int land = -1;
        for (int f = 0; f < 80 && land < 0; f++) { step(g, false, false, f < 20, false, false); if (f > 3 && p.onGround) land = f; }
        g = arena(false);
        p = g.player;
        boolean fired = false;
        for (int f = 0; f <= land + 4; f++) {
            step(g, false, false, f < 20, false, f == land - 3);
            if (f >= land && p.dodgeT > 0f) fired = true;
        }
        check(fired, "a dash pressed 3 frames before landing fires on touchdown");
    }

    // ------------------------------------------------------------------ 5. attacks: timing and hit/blade synchronisation

    /** Chebyshev distance: the hit region is the enemy box grown by the blade radius on every side (a square blade profile). */
    static float distPtBox(float px, float py, float l, float t, float r, float b) {
        final float dx = Math.max(Math.max(l - px, 0f), px - r), dy = Math.max(Math.max(t - py, 0f), py - b);
        return Math.max(dx, dy);
    }

    /** Smallest distance from the (optionally extended) blade swept from prev to cur to the box. */
    static float bladeDist(float[] prev, float[] cur, float ext, float bx, float by, float bw, float bh) {
        float best = 1e9f;
        for (int s = 0; s <= 10; s++) {
            final float u = s / 10f;
            final float hx = prev[0] + (cur[0] - prev[0]) * u, hy = prev[1] + (cur[1] - prev[1]) * u;
            final float tx = prev[2] + (cur[2] - prev[2]) * u, ty = prev[3] + (cur[3] - prev[3]) * u;
            final float dx = tx - hx, dy = ty - hy, len = (float) Math.sqrt(dx * dx + dy * dy) + 1e-4f;
            for (int i = 0; i <= 24; i++) {
                final float t = i / 24f * (len + ext);
                best = Math.min(best, distPtBox(hx + dx / len * t, hy + dy / len * t, bx, by, bx + bw, by + bh));
            }
        }
        return best;
    }

    static float[] blade(Player p) {
        return new float[] {p.fig.j[20], p.fig.j[21], p.fig.j[22], p.fig.j[23]};
    }

    static void attackTiming() {
        System.out.println("-- attack timing and combo chain");
        Game g = arena(false);
        Player p = g.player;
        StringBuilder sb = new StringBuilder();
        int[] at = new int[8];
        java.util.Arrays.fill(at, -1);
        int last = 0, endFrame = -1;
        for (int f = 0; f < 90; f++) {
            step(g, false, false, false, f % 3 == 0, false);
            if (p.atk != last) {
                if (p.atk > 0 && at[p.atk] < 0) at[p.atk] = f;
                if (p.atk == 0 && endFrame < 0 && at[3] >= 0) endFrame = f;
                last = p.atk;
            }
        }
        check(at[1] == 0, "attack 1 begins on the press frame");
        check(Math.abs(at[2] - (Player.ST[1] + Player.AC[1])) <= 1, "attack 2 chains the moment attack 1's active frames end (frame " + at[2] + ")");
        check(Math.abs(at[3] - (at[2] + Player.ST[2] + Player.AC[2])) <= 1, "attack 3 chains the moment attack 2's active frames end (frame " + at[3] + ")");
        final int total3 = Player.ST[3] + Player.AC[3] + Player.RC[3];
        check(Math.abs(endFrame - (at[3] + total3)) <= 1, "the finisher lasts " + total3 + " frames (ends at frame " + endFrame + ")");
    }

    static void hitSync() {
        System.out.println("-- hit detection is synchronised with the blade");
        final int[] dists = {-60, -30, 10, 24, 36, 48, 60, 72, 90, 110, 140};
        int soundnessFail = 0, completenessFail = 0, firstFrameTooEarly = 0, total = 0, hitsTotal = 0;
        int minFirstHit = 99;
        for (int d : dists) {
            for (int move = 0; move < 3; move++) {
                Game g = arena(false);
                Player p = g.player;
                final Enemy e = new Enemy(Enemy.HUSK, p.cx() + d - 8f, FLOOR - 30f);
                e.hp = e.maxHp = 100000;
                g.enemies.add(e);
                float[] prev = blade(p);
                final int[] swingMin = new int[4];
                final float[] minDist = {1e9f, 1e9f, 1e9f, 1e9f};
                final int[] hitFrame = {-1, -1, -1, -1};
                final int[] swingStart = {-1, -1, -1, -1};
                final int[] hpBefore = new int[4];
                int curSwing = 0;
                for (int f = 0; f < 70; f++) {
                    g.input.set(false, false, false, f % 3 == 0, false);
                    final int hp0 = e.hp, sw0 = p.swing;
                    p.update(g, g.input, DT);
                    if (p.swing != sw0 || (p.atk > 0 && curSwing == 0)) { curSwing++; if (curSwing <= 3) { swingStart[curSwing] = f; hpBefore[curSwing] = hp0; } }
                    final float[] cur = blade(p);
                    if (curSwing >= 1 && curSwing <= 3 && p.atk > 0) {
                        final float fr = p.atkT / Player.FRAME;
                        final int m = p.atk;
                        if (fr >= Player.ST[m] - 0.5f && fr < Player.ST[m] + Player.AC[m]) {
                            final float dist = bladeDist(prev, cur, Player.EXT[m], e.x, e.y, e.w, e.h);
                            minDist[curSwing] = Math.min(minDist[curSwing], dist);
                        }
                    }
                    if (e.hp < hp0 && curSwing >= 1 && curSwing <= 3 && hitFrame[curSwing] < 0) {
                        hitFrame[curSwing] = f;
                        final float dist = bladeDist(prev, cur, Player.EXT[p.atk], e.x, e.y, e.w, e.h);
                        if (dist > Player.BLADE_R + 1.5f) { soundnessFail++; info("violation: d=" + d + " move=" + p.atk + " frame=" + (f - swingStart[curSwing]) + " blade distance " + String.format("%.1f", dist)); }
                    }
                    prev = cur;
                }
                final int s = move + 1;
                if (swingStart[s] < 0) continue;
                total++;
                final boolean hit = hitFrame[s] >= 0;
                if (hit) { hitsTotal++; minFirstHit = Math.min(minFirstHit, hitFrame[s] - swingStart[s]); }
                if (!hit && minDist[s] <= Player.BLADE_R - 3.5f) completenessFail++;
                if (hit && hitFrame[s] - swingStart[s] < Player.ST[s] - 1) firstFrameTooEarly++;
            }
        }
        check(soundnessFail == 0, "every hit happened with the extended blade within " + Player.BLADE_R + "+1.5 units of the enemy (" + soundnessFail + " violations in " + hitsTotal + " hits)");
        check(completenessFail == 0, "no whiffs: whenever the blade came well inside the enemy's box a hit registered (" + completenessFail + " violations in " + total + " swings)");
        check(firstFrameTooEarly == 0, "no hit lands during a move's wind-up (earliest hit " + minFirstHit + " frames after the press)");

        // nothing behind or far away
        for (int d : new int[] {-40, 130}) {
            Game g = arena(false);
            Player p = g.player;
            final Enemy e = new Enemy(Enemy.HUSK, p.cx() + d - 8f, FLOOR - 30f);
            e.hp = e.maxHp = 100000;
            g.enemies.add(e);
            for (int f = 0; f < 60; f++) { g.input.set(false, false, false, f < 2, false); p.update(g, g.input, DT); }
            check(e.hp == e.maxHp, "an enemy " + (d < 0 ? "behind" : "130 units in front of") + " the hero is not hit by a single swing");
        }

        // one hit per swing, correct damage, feedback
        int[] expect = {10, 12, 22};
        for (int pass = 0; pass < 2; pass++) {
            Game g = arena(false);
            Player p = g.player;
            p.edge = pass == 1;
            final Enemy e = new Enemy(Enemy.HUSK, p.cx() + 36f - 8f, FLOOR - 30f);
            e.hp = e.maxHp = 100000;
            g.enemies.add(e);
            int[] dmg = new int[4];
            final int swing0 = p.swing;
            float freeze = 0f, shake = 0f;
            for (int f = 0; f < 46; f++) {
                g.input.set(false, false, false, f % 3 == 0, false);
                final int hp0 = e.hp;
                p.update(g, g.input, DT);
                final int idx = p.swing - swing0;
                if (e.hp < hp0 && idx >= 1 && idx <= 3) { dmg[idx] += hp0 - e.hp; freeze = Math.max(freeze, g.fx.freeze); shake = Math.max(shake, g.fx.shake); }
            }
            boolean ok = true;
            for (int i = 1; i <= 3; i++) {
                final int want = Math.round(expect[i - 1] * (pass == 1 ? 1.5f : 1f));
                if (dmg[i] != want) ok = false;
            }
            check(ok, (pass == 1 ? "Umbral Edge " : "") + "each swing hits exactly once for " + (pass == 1 ? "15/18/33" : "10/12/22") + " (got " + dmg[1] + "/" + dmg[2] + "/" + dmg[3] + ")");
            if (pass == 0) check(freeze >= Player.STOP[3] - 1e-4f && shake > 0f, "hits give hit-stop (" + String.format("%.3f", freeze) + " s on the finisher) and shake");
        }
    }

    // ------------------------------------------------------------------ 6. combos, cancels, aerial moves

    static void combos() {
        System.out.println("-- combos and cancels");
        // jump cancels an attack immediately
        Game g = arena(false);
        Player p = g.player;
        step(g, false, false, false, true, false);
        step(g, false, false, false, false, false);
        step(g, false, false, true, false, false);
        check(p.atk == 0 && p.vy < -400f, "jump cancels an attack on the press frame");
        // dash cancels an attack immediately
        g = arena(false);
        p = g.player;
        step(g, false, false, false, true, false);
        step(g, false, false, false, false, false);
        step(g, false, false, false, false, true);
        check(p.atk == 0 && p.dodgeT > 0f, "dash cancels an attack on the press frame");
        // attack during a dash becomes a dash slash
        g = arena(false);
        p = g.player;
        step(g, false, false, false, false, true);
        int slashAt = -1;
        for (int f = 1; f < 20 && slashAt < 0; f++) { step(g, false, false, false, f == 3, false); if (p.atk == Player.M_DASH) slashAt = f; }
        check(slashAt >= 5 && slashAt <= 9, "attack pressed mid-dash turns into the dash slash (frame " + slashAt + " of the dash)");
        // and the dash slash chains into the ground combo
        int chain = 0;
        for (int f = 0; f < 40; f++) { step(g, false, false, false, f % 2 == 0, false); if (p.atk == 2) chain++; }
        check(chain > 0, "the dash slash chains into combo hit 2");
        // being hit cancels everything
        g = arena(false);
        p = g.player;
        step(g, false, false, false, false, true);
        step(g, false, false, false, false, false);
        p.invuln = 0f;
        p.hurt(g, 10, p.cx() - 20f);
        step(g, false, false, false, false, false);
        check(p.dodgeT == 0f && p.atk == 0 && p.hurtT > 0f, "a hit cancels a dash");

        // aerial combo: slash, reverse slash, plunge
        g = arena(false);
        p = g.player;
        boolean s4 = false, s5 = false, s6 = false;
        float maxVy = 0f;
        int airFrames = 0, landed = -1;
        for (int f = 0; f < 140; f++) {
            step(g, false, false, f < 18, f >= 14 && f % 3 == 0, false);
            if (p.atk == 4) s4 = true;
            if (p.atk == 5) s5 = true;
            if (p.atk == Player.M_PLUNGE) s6 = true;
            maxVy = Math.max(maxVy, p.vy);
            if (!p.onGround) airFrames = f;
            if (f > 20 && p.onGround && landed < 0) landed = f;
        }
        check(s4 && s5 && s6, "aerial combo plays slash -> reverse slash -> plunge");
        check(maxVy >= 600f, "the plunge dives fast (peak " + (int) maxVy + ")");
        idle(g, 60);
        check(p.onGround && p.atk == 0 && p.dodgeT == 0f, "the hero ends in a clean standing state after the plunge");
        // an air attack pressed from the ground-jump apex does not float the hero for ever
        g = arena(false);
        p = g.player;
        int air = 0;
        for (int f = 0; f < 200; f++) {
            step(g, false, false, f < 20, f >= 10 && f % 2 == 0, false);
            if (!p.onGround) air = f;
            else if (f > 25) break;
        }
        check(air < 80, "attacking in the air cannot hold the hero up (air time " + air + " frames; plain jump 41)");
        // plunge slam hits an enemy standing at the landing spot
        g = arena(false);
        p = g.player;
        final Enemy e = new Enemy(Enemy.HUSK, p.cx() + 18f - 8f, FLOOR - 30f);
        e.hp = e.maxHp = 1000;
        g.enemies.add(e);
        for (int f = 0; f < 100; f++) {
            g.input.set(false, false, f < 18, f >= 14 && f % 3 == 0, false);
            p.update(g, g.input, DT);
        }
        check(e.hp < 1000, "the plunge damages an enemy near the landing spot (hp " + e.hp + "/1000)");
    }

    // ------------------------------------------------------------------ 7. invariants under random play

    static String invariant(Game g) {
        final Player p = g.player;
        if (!finite(p.x) || !finite(p.y) || !finite(p.vx) || !finite(p.vy)) return "non-finite state";
        for (int i = 0; i < 26; i++) if (!finite(p.fig.j[i])) return "non-finite joint " + i;
        if (g.state != Game.PLAY || p.dead) return null;
        if (!p.free(g.world, p.x, p.y) && g.fadeDir == 0) return "hero overlaps a solid tile at " + p.x + "," + p.y;
        if (Math.abs(p.vx) > 520f) return "vx " + p.vx;
        if (p.vy > 900.5f || p.vy < -700f) return "vy " + p.vy;
        if (p.atk < 0 || p.atk > 7) return "atk " + p.atk;
        if (p.atkT < 0f) return "atkT " + p.atkT;
        if (p.dodgeT < 0f || p.dodgeT > Player.DASH_T_GROUND + 0.001f) return "dodgeT " + p.dodgeT;
        if (p.dodgeCd < -0.02f || p.dodgeCd > Player.DASH_CD + 0.001f) return "dodgeCd " + p.dodgeCd;
        if (p.dodgeT > 0.001f && p.invuln <= 0f) return "dashing without invulnerability";
        if (p.dodgeT > 0.001f && Math.abs(p.vy) > 0.001f && p.hurtT <= 0f) return "dashing with vertical speed " + p.vy;
        if (p.hp < 0 || p.hp > p.maxHp) return "hp " + p.hp;
        if (p.jumpsLeft() < 0 || p.jumpsLeft() > 1) return "air jumps " + p.jumpsLeft();
        if (p.dodgeT > 0.001f && p.atk != 0) return "dashing and attacking at once";
        return null;
    }

    static void fuzz() {
        System.out.println("-- random-input invariant fuzz (fine-grained presses, real enemies and boss)");
        long frames = 0;
        String bad = null;
        for (long seed = 11; seed <= 16 && bad == null; seed++) {
            final Random r = new Random(seed);
            final Game g = Sim.newGame(new Sim.Prefs());
            g.save.shake = false;
            if (seed % 2 == 0) { g.save.dj = true; g.player.hasDJ = true; }
            Sim.tap(g, g.btnPlay);
            boolean l = false, rt = false, j = false, a = false, d = false;
            int hold = 0;
            for (int f = 0; f < 60000 && bad == null; f++) {
                if (--hold <= 0) {
                    hold = 1 + r.nextInt(r.nextInt(5) == 0 ? 30 : 9);
                    l = r.nextInt(4) == 0; rt = r.nextInt(5) < 3; j = r.nextInt(3) == 0; a = r.nextInt(3) == 0; d = r.nextInt(8) == 0;
                }
                g.input.set(l, rt, j, a, d);
                if (g.state == Game.DEAD && g.deadT > 1.3f) Sim.tap(g, g.dBtn[0]);
                if (g.state == Game.PLAY && g.player.hp < 40 && r.nextInt(30) == 0) g.player.hp = g.player.maxHp;
                if (g.state == Game.PLAY && r.nextInt(5000) == 0) { g.save.cpRoom = r.nextInt(3); g.save.cpCol = 3; g.save.cpRow = 9; g.player.hp = 0; }
                g.update(DT);
                frames++;
                final String v = invariant(g);
                if (v != null) bad = "seed " + seed + " frame " + f + ": " + v;
            }
        }
        check(bad == null, "invariants held over " + frames + " random frames" + (bad == null ? "" : " - " + bad));
    }

    // ------------------------------------------------------------------ 8. progression gating

    /**
     * Random button programs from the edge of a gap: can the hero get across without the double jump?
     * returns {successes, longest air time (frames), best margin metric}: for a gap, the furthest right edge reached while
     * still at floor height; for a ledge, the highest point reached (smallest feet y).
     */
    static float[] gating(int room, int startCol, int tRow, int tc0, int tc1, boolean dj, int programs, long seed, boolean gap) {
        final Game g = Sim.newGame(new Sim.Prefs());
        Sim.tap(g, g.btnPlay);
        final Player p = g.player;
        g.enemies.clear(); g.projs.clear(); g.pickups.clear(); g.boss = null;
        final Random r = new Random(seed);
        int ok = 0, maxAir = 0;
        float bestRight = 0f, bestFeet = 1e9f;
        for (int n = 0; n < programs; n++) {
            g.world.load(room);
            p.hasDJ = dj; p.dead = false; p.hp = p.maxHp = 100000; p.invuln = 99f;
            p.place(startCol * 32 + 10f + r.nextInt(13), 10 * 32 - p.h);
            g.input.clear();
            for (int i = 0; i < 4; i++) p.update(g, g.input, DT);
            boolean l = false, rt = true, j = false, a = false, d = false;
            int rem = 0, air = 0;
            boolean done = false;
            for (int f = 0; f < 260 && !done; f++) {
                if (--rem <= 0) {
                    rem = 1 + r.nextInt(14);
                    rt = r.nextInt(100) < 88; l = !rt && r.nextInt(3) == 0;
                    j = r.nextInt(100) < 50; a = r.nextInt(100) < 25; d = r.nextInt(100) < 14;
                }
                g.input.set(l, rt, j, a, d);
                p.update(g, g.input, DT);
                p.invuln = 99f;
                air = p.onGround ? 0 : air + 1;
                maxAir = Math.max(maxAir, air);
                final float feet = p.y + p.h;
                if (gap && feet <= 10 * 32f + 0.5f && p.x > startCol * 32f + 40f) bestRight = Math.max(bestRight, p.x + p.w);
                if (!gap) bestFeet = Math.min(bestFeet, feet);
                if (p.y > 12 * 32f) done = true;
                if (p.onGround && Math.abs(feet - tRow * 32f) < 0.5f && p.cx() >= tc0 * 32f && p.cx() <= (tc1 + 1) * 32f) { ok++; done = true; }
            }
        }
        return new float[] {ok, maxAir, gap ? bestRight : bestFeet};
    }

    static void gatingSearch(int programs) {
        System.out.println("-- progression gating (" + programs + " random programs per spot, jump/attack/dash mashed at random)");
        float[] chasm = gating(1, 46, 10, 54, 56, false, programs, 101, true);
        final float farEdge = 54 * 32f;
        check(chasm[0] == 0, "chasm cannot be crossed without the double jump: " + (int) chasm[0] + " of " + programs + " programs succeeded");
        info("closest approach: right edge reached x=" + (int) chasm[2] + " at floor height; the far ledge starts at x=" + (int) farEdge + " (margin " + (int) (farEdge - chasm[2]) + " units)");
        check(farEdge - chasm[2] >= 15f, "chasm margin without the double jump is at least 15 units");
        float[] secret = gating(0, 49, 6, 52, 56, false, programs, 202, false);
        check(secret[0] == 0, "secret ledge cannot be reached without the double jump: " + (int) secret[0] + " of " + programs + " programs succeeded");
        final float rise = 10 * 32f - secret[2];
        info("highest point reached: " + (int) rise + " units above the floor; the ledge needs more than " + (int) (10 * 32f - 6 * 32f) + " (margin " + (int) (4 * 32f - rise) + " units)");
        check(4 * 32f - rise >= 25f, "secret-ledge height margin without the double jump is at least 25 units");
        check(chasm[1] <= 80 && secret[1] <= 80, "no input mash can hold the hero in the air (> 80 frames) without the double jump (longest " + (int) Math.max(chasm[1], secret[1]) + ")");
        float[] chasmDj = gating(1, 46, 10, 54, 56, true, Math.max(2000, programs / 4), 303, true);
        check(chasmDj[0] > 0, "with the double jump the same search does cross the chasm (" + (int) chasmDj[0] + " successes) - the test is not vacuous");
        float[] secretDj = gating(0, 49, 6, 52, 56, true, Math.max(2000, programs / 4), 404, false);
        check(secretDj[0] > 0, "with the double jump the secret ledge is reachable (" + (int) secretDj[0] + " successes)");
    }

    // ------------------------------------------------------------------ 9. allocation

    static void allocation() {
        System.out.println("-- per-frame allocation");
        long per = -1;
        try {
            final Object bean = ManagementFactory.getThreadMXBean();
            final Method m = Class.forName("com.sun.management.ThreadMXBean").getMethod("getThreadAllocatedBytes", long.class);
            final long id = Thread.currentThread().getId();
            final Game g = arena(true);
            final Random r = new Random(5);
            boolean l = false, rt = false, j = false, a = false, d = false;
            for (int f = 0; f < 3000; f++) {
                if (f % 5 == 0) { l = r.nextInt(4) == 0; rt = r.nextInt(5) < 3; j = r.nextInt(3) == 0; a = r.nextInt(2) == 0; d = r.nextInt(10) == 0; }
                g.input.set(l, rt, j, a, d);
                g.update(DT);
            }
            final long a0 = (Long) m.invoke(bean, id);
            final int n = 20000;
            for (int f = 0; f < n; f++) {
                if (f % 5 == 0) { l = r.nextInt(4) == 0; rt = r.nextInt(5) < 3; j = r.nextInt(3) == 0; a = r.nextInt(2) == 0; d = r.nextInt(10) == 0; }
                g.input.set(l, rt, j, a, d);
                g.update(DT);
            }
            per = ((Long) m.invoke(bean, id) - a0) / n;
        } catch (Throwable t) {
            info("allocation counter not available on this JVM (" + t.getClass().getSimpleName() + "), skipped");
            return;
        }
        check(per < 400, "Game.update allocates " + per + " bytes per frame during constant combat (target < 400)");
    }

    public static void main(String[] args) {
        final int programs = args.length > 0 ? Integer.parseInt(args[0]) : 12000;
        latency();
        jumps();
        doubleJump();
        dash();
        attackTiming();
        hitSync();
        combos();
        fuzz();
        gatingSearch(programs);
        allocation();
        System.out.println(failures == 0 ? "ALL " + checks + " MECHANICS CHECKS PASSED" : failures + " of " + checks + " MECHANICS CHECKS FAILED");
        if (failures > 0) System.exit(1);
    }
}
