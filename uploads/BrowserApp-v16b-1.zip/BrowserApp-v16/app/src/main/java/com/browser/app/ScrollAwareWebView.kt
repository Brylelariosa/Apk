package com.browser.app

import android.content.Context
import android.util.AttributeSet
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.webkit.WebView

class ScrollAwareWebView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : WebView(context, attrs, defStyleAttr) {

    var onScrollCallback: ((dy: Int) -> Unit)? = null

    /**
     * Invoked after onCreateInputConnection returns a non-null IC and the
     * IMM has had a chance (50 ms) to register it.  MainActivity uses this
     * to explicitly call showSoftInput — necessary because adjustResize alone
     * is sometimes not enough on older WebView versions to auto-open the IME.
     */
    var onWebInputFocused: (() -> Unit)? = null

    var onDebugEvent: ((String) -> Unit)? = null

    override fun onScrollChanged(l: Int, t: Int, oldl: Int, oldt: Int) {
        super.onScrollChanged(l, t, oldl, oldt)
        onScrollCallback?.invoke(t - oldt)
    }

    /** Tells the IMM this view is always a text editor so it never rejects IC requests. */
    override fun onCheckIsTextEditor(): Boolean = true

    override fun onCreateInputConnection(outAttrs: EditorInfo): InputConnection? {
        val ic = super.onCreateInputConnection(outAttrs)
        onDebugEvent?.invoke("onCreateIC: ic=${if (ic != null) "OK" else "NULL"}")
        if (ic != null) {
            // Give the IMM 50 ms to fully register the new InputConnection before
            // we request showSoftInput.  An immediate post {} sometimes fires before
            // the IMM's internal state is updated on Blink-side, causing showSoftInput
            // to return false on the first call even though the IC is valid.
            postDelayed({ onWebInputFocused?.invoke() }, 50)
        }
        return ic
    }
}
