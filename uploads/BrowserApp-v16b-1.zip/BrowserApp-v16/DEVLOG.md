# BrowserApp Development Log

## v9 → v10 Changes

---

### 🐛 Keyboard Not Showing on Website Inputs

**Problem:**
In immersive/fullscreen mode, tapping any `<input>` or `<textarea>` on a webpage never showed the keyboard. The system suppresses automatic IME display in immersive mode, so the normal Android behavior didn't apply.

**Attempts:**

1. **v9 — `onCreateInputConnection` + `showSoftInput(SHOW_IMPLICIT)`**
   Overrode `onCreateInputConnection` in `ScrollAwareWebView` and called `showSoftInput` via `post {}`. Failed — `showSoftInput` is ignored in immersive mode.

2. **v10 first attempt — JS bridge + `WindowInsetsControllerCompat` on `window.decorView`**
   Added a JavaScript `focusin` listener that called `Android.onInputFocused()` via a `JavascriptInterface`. The bridge called `WindowInsetsControllerCompat(window, window.decorView).show(ime())`. Failed — the `decorView` is not the focused view so the system ignores the request.

3. **v10 second attempt — JS bridge + `webView` as the host view + `showSoftInput(SHOW_FORCED)` fallback**
   Changed to `WindowInsetsControllerCompat(window, webView).show(ime())` and added `showSoftInput(webView, SHOW_FORCED)` as backup. Failed — `showSoftInput` on a WebView still doesn't work because WebView is not a standard text editor view.

4. **v10 final fix — `onCreateInputConnection` in `ScrollAwareWebView` with correct view**
   Removed the redundant `showSoftInput` call. Restored `onCreateInputConnection` override but used `WindowInsetsControllerCompat(activity.window, this).show(ime())` where `this` is the WebView itself — the correct focused view at that exact moment. This fires at the right time (system has just set up the input connection) and uses the right view reference. Keyboard now shows on website inputs.

**Remaining JS bridge:** Kept as a belt-and-suspenders backup for `contenteditable` divs that sometimes don't trigger `onCreateInputConnection`.

---

### 🐛 Tapping Website Search Bar Opened URL Bar Instead

**Problem:**
A `onSingleTapConfirmed` gesture was added to let users tap the top 22% of the screen to reveal the URL bar. Google's search box and many other site inputs sit in that zone, so tapping them intercepted the touch and opened the URL bar instead of letting the user type. This also blocked the keyboard from showing.

**Fix:**
Removed the "tap top area → show URL bar" gesture entirely. The globe button is already the dedicated trigger for the URL bar. The gesture detector now only handles double-tap (dismiss URL bar) and the "Tap page to hide" FAB mode.

---

### ✨ URL Bar — No Keyboard on Open

**Problem:**
Opening the URL bar forced the keyboard open immediately, which was disruptive when the user just wanted to paste a URL or glance at the current address.

**Fix:**
Removed `showSoftInput` from `showUrlBar()`. The input still gets focus and selects all text (so paste works immediately), but the keyboard only opens if the user explicitly taps the input field.

---

### ✨ Globe Button (FAB) — Configurable Hide Behavior

**Problem:**
The globe button auto-hid on scroll and reappeared after 2.5 seconds. Users had no control over this behavior, and the timer reappear was unexpected.

**Changes:**
- Removed the 2.5-second auto-reappear timer. In scroll mode, the button now stays hidden until the user scrolls back up.
- Added a **"URL Button"** setting in the Settings dialog with three options:
  - **Auto-hide on scroll** — hides on scroll down, reappears on scroll up (default)
  - **Tap page to hide** — single tap anywhere on the page hides the button
  - **Always visible** — never auto-hides

---

### 🔧 Code Quality Fixes

- Removed `onCreateInputConnection` race with JS bridge (they were both firing and potentially conflicting).
- Removed unused `Handler`, `Looper`, `SHOW_DELAY`, `scrollHandler`, and `showToggleRunnable` after the timer was eliminated.
- Fixed `@SuppressLint("ClickableViewAccessibility")` being placed on a lambda expression (invalid target in Kotlin) — moved it to the enclosing function `bindViews()`.
- Extracted `AlertDialog.styleDialog()` extension to remove duplicated dark-theme styling boilerplate across dialog builders.

---

## What Still Works

- Ad blocker with host-based blocking
- Data Saver levels (Off / High / Medium / Low / No Images)
- Speed-dial home page with clock
- Progress bar during page load
- Back / Forward / Refresh navigation
- Immersive fullscreen mode
- Double-tap anywhere on the page to dismiss the URL bar
- URL bar slides in/out with animation
- Keyboard shows correctly on URL bar input (tap to type)
- Paste into URL bar works (text is pre-selected on open)
