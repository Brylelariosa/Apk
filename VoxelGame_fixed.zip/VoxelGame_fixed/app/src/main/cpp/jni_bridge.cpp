#include <jni.h>
#include <GLES3/gl3.h>
#include <android/log.h>
#include <cmath>
#include <ctime>
#include <memory>
#include <string>

#include "core/CrashReporter.h"
#include "core/DebugLog.h"
#include "core/Renderer.h"
#include "core/World.h"
#include "core/Camera.h"
#include "core/Input.h"
#include "core/BlockDefs.h"
#include "core/MathUtils.h"

#define LOG_TAG "VoxelJNI"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

// ── State ─────────────────────────────────────────────────────────────────────
static std::unique_ptr<Renderer> g_renderer;
static std::unique_ptr<World>    g_world;
static std::unique_ptr<Camera>   g_camera;
static std::unique_ptr<Input>    g_input;

static int   g_width=1, g_height=1;
static long  g_lastNs=0;
static bool  g_inited=false;
static std::string g_errorMsg;
static bool  g_showError=false;

// Physics
static float g_velY    = 0.f;
static bool  g_onGround = false;
// Separate physics and render positions so step-up can be smoothed visually.
// g_physPos  = true collision position (used for all physics queries)
// g_smoothY  = camera Y that lerps toward g_physPos.y after a step-up snap,
//              giving a smooth glide instead of an instant teleport.
static Vec3  g_physPos  = {8.f, 100.f, 8.f};
static float g_smoothY  = 100.f;

// Break
static int   g_breakX=-99999, g_breakY=-99999, g_breakZ=-99999;
static float g_breakProgress=0.f;
static const float BREAK_TIME = 0.7f;

// Settings – panel coords match Renderer exactly
static bool  g_settingsOpen = false;
static int   g_renderDist   = 4;

// Render distance slider geometry (updated on resize, used for touch hit-test)
static float g_panelX=0, g_panelY=0, g_panelW=680, g_panelH=220;
static float g_sliderL=0, g_sliderR=0, g_sliderY=0;  // track endpoints & centre Y
static float g_sliderThumbR = 18.f;
static bool  g_sliderDragging = false;
static const float SLIDER_MAX = 64.f;  // visual max; actual renderDist unclamped

static void recomputePanelGeometry(float sw, float sh) {
    g_panelW = 680; g_panelH = 220;
    g_panelX = (sw - g_panelW) * 0.5f;
    g_panelY = (sh - g_panelH) * 0.5f;
    g_sliderL = g_panelX + 40.f;
    g_sliderR = g_panelX + g_panelW - 40.f;
    g_sliderY = g_panelY + g_panelH * 0.68f;
}

// FPS
static float g_fpsTimer=0.f;
static int   g_fpsFrames=0, g_fpsDisplay=0;

// Debug
static float  g_debugTimer   = 0.f;   // flush debug log every 2 sec
static bool   g_copyDebugPending = false;  // set when user taps COPY DEBUG button
static float  g_shakeMetric  = 0.f;   // rolling measure of camera jitter
static int    g_frameCount   = 0;
static float  g_avgFrameTime = 0.f;

// Loading
static int  g_loadFrame=0;
static bool g_everHadChunks=false;

// Hotbar
static uint8_t g_hotbar[9]={
    BLOCK_GRASS,BLOCK_DIRT,BLOCK_STONE,
    BLOCK_SAND,BLOCK_LOG,BLOCK_LEAVES,
    BLOCK_GLOWSTONE,BLOCK_LAVA,BLOCK_WATER
};
static int g_hotbarSel=0;
static char g_crashPath[512]={};

// ── Helpers ───────────────────────────────────────────────────────────────────
static long nowNs(){
    struct timespec ts; clock_gettime(CLOCK_MONOTONIC,&ts);
    return ts.tv_sec*1000000000L+ts.tv_nsec;
}
static bool solidAt(const World* w,float x,float y,float z){
    // Uses blockSolidForCollision: treats unloaded chunks as solid
    // so the player never falls through terrain that hasn't generated yet.
    return w->blockSolidForCollision((int)floorf(x),(int)floorf(y),(int)floorf(z));
}
static bool onGround(const World* w, Vec3 pos){
    // Sample 0.2 below feet to give a stable detection band.
    // Without this margin, floating-point imprecision at the exact surface
    // causes onGround to flicker true/false → 1-frame gravity jolts.
    float feet = pos.y - 1.85f - 0.20f;
    for(float dx : {-0.28f, 0.28f})
        for(float dz : {-0.28f, 0.28f})
            if(solidAt(w, pos.x+dx, feet, pos.z+dz)) return true;
    return false;
}

static Vec3 collide(const World* w, Vec3 pos, Vec3 d) {
    const float EY   = 1.8f;   // eye height above feet
    const float HW   = 0.28f;  // half-width

    float origDx = d.x, origDz = d.z;  // save for step-up check

    // ── X collision ─────────────────────────────────────────────────────────
    if (d.x != 0.f) {
        float sx = d.x > 0 ? HW : -HW;
        bool hitX = false;
        for (float dz : {-HW, 0.f, HW})
            if (solidAt(w, pos.x+d.x+sx, pos.y-EY+0.1f, pos.z+dz) ||
                solidAt(w, pos.x+d.x+sx, pos.y-EY+0.9f, pos.z+dz) ||
                solidAt(w, pos.x+d.x+sx, pos.y-0.05f,   pos.z+dz)) { hitX=true; break; }
        if (hitX) d.x = 0.f;
    }
    // ── Z collision ─────────────────────────────────────────────────────────
    if (d.z != 0.f) {
        float sz = d.z > 0 ? HW : -HW;
        bool hitZ = false;
        for (float dx : {-HW, 0.f, HW})
            if (solidAt(w, pos.x+dx, pos.y-EY+0.1f, pos.z+d.z+sz) ||
                solidAt(w, pos.x+dx, pos.y-EY+0.9f, pos.z+d.z+sz) ||
                solidAt(w, pos.x+dx, pos.y-0.05f,   pos.z+d.z+sz)) { hitZ=true; break; }
        if (hitZ) d.z = 0.f;
    }

    // ── Auto step-up (instant snap — no velocity drift) ─────────────────────
    // When grounded and blocked, try stepping up 1 block instantly.
    bool blockedX = (d.x == 0.f && origDx != 0.f);
    bool blockedZ = (d.z == 0.f && origDz != 0.f);
    if (g_onGround && (blockedX || blockedZ)) {
        // Head room: top of player must be clear
        bool aboveClear = true;
        for (float dx : {-HW, 0.f, HW})
            for (float dz : {-HW, 0.f, HW})
                if (solidAt(w, pos.x+dx, pos.y+0.1f, pos.z+dz)) { aboveClear=false; break; }

        if (aboveClear) {
            // Raised position: 1 block up
            Vec3 rp = {pos.x, pos.y + 1.001f, pos.z};
            bool stepXok = !blockedX;
            bool stepZok = !blockedZ;

            if (blockedX) {
                float sx2 = origDx > 0 ? HW : -HW;
                bool ok = true;
                for (float dz2 : {-HW, 0.f, HW})
                    if (solidAt(w, rp.x+origDx+sx2, rp.y-EY+0.1f, rp.z+dz2) ||
                        solidAt(w, rp.x+origDx+sx2, rp.y-EY+0.9f, rp.z+dz2) ||
                        solidAt(w, rp.x+origDx+sx2, rp.y-0.05f,   rp.z+dz2))
                        { ok=false; break; }
                if (ok) stepXok = true;
            }
            if (blockedZ) {
                float sz2 = origDz > 0 ? HW : -HW;
                bool ok = true;
                for (float dx2 : {-HW, 0.f, HW})
                    if (solidAt(w, rp.x+dx2, rp.y-EY+0.1f, rp.z+origDz+sz2) ||
                        solidAt(w, rp.x+dx2, rp.y-EY+0.9f, rp.z+origDz+sz2) ||
                        solidAt(w, rp.x+dx2, rp.y-0.05f,   rp.z+origDz+sz2))
                        { ok=false; break; }
                if (ok) stepZok = true;
            }

            if ((blockedX && stepXok) || (blockedZ && stepZok)) {
                d.y = 1.001f;                         // snap up to step
                if (blockedX && stepXok) d.x = origDx;
                if (blockedZ && stepZok) d.z = origDz;
                g_velY = 0.f;
            }
        }
    }

    // ── Y down ──────────────────────────────────────────────────────────────
    if (d.y < 0.f) {
        bool bl = false;
        for (float dx : {-HW, HW}) for (float dz : {-HW, HW})
            if (solidAt(w, pos.x+dx, pos.y-EY+d.y, pos.z+dz)) { bl=true; break; }
        if (bl) { d.y = 0.f; g_velY = 0.f; }
    }
    // ── Y up ────────────────────────────────────────────────────────────────
    if (d.y > 0.f) {
        bool bl = false;
        for (float dx : {-HW, HW}) for (float dz : {-HW, HW})
            if (solidAt(w, pos.x+dx, pos.y+d.y+0.05f, pos.z+dz)) { bl=true; break; }
        if (bl) { d.y = 0.f; g_velY = 0.f; }
    }
    return pos + d;
}


static void renderError(){
    static int f=0; f++;
    float r=((f/20)%2==0)?.85f:.45f;
    glClearColor(r,.03f,.03f,1.f);
    glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
}

// ── Game tick (only runs when settings closed) ────────────────────────────────
static void gameTick(float dt){
    if(!g_world||!g_camera||!g_input) return;
    if(dt>0.05f) dt=0.05f;   // cap at 50ms — prevents huge jumps after stutter

    g_fpsTimer+=dt; g_fpsFrames++; g_frameCount++;
    g_avgFrameTime += (dt - g_avgFrameTime) * 0.1f;  // EMA
    if(g_fpsTimer>=0.5f){
        g_fpsDisplay=(int)(g_fpsFrames/g_fpsTimer+.5f);
        g_fpsTimer=0; g_fpsFrames=0;
    }

    // Look — smooth the raw delta to dampen device-vibration shake.
    // Exponential moving average: smoothed = 0.65*prev + 0.35*new
    // This reduces single-frame spikes (from walking vibration) by 65%.
    static float smoothYaw   = 0.f;
    static float smoothPitch = 0.f;
    float rawYaw   = g_input->consumeDX() * -0.0025f;
    float rawPitch = g_input->consumeDY() *  0.0025f;
    // Deadzone: ignore sub-3px raw deltas (device vibration noise).
    // 3px * 0.0025 = 0.0075 rad threshold.
    const float LOOK_DEAD = 0.0075f;
    if (fabsf(rawYaw)   < LOOK_DEAD) rawYaw   = 0.f;
    if (fabsf(rawPitch) < LOOK_DEAD) rawPitch = 0.f;
    // When no input, snap smoothed values to zero to prevent drift
    if (rawYaw == 0.f && rawPitch == 0.f) {
        smoothYaw = 0.f; smoothPitch = 0.f;
    } else {
        smoothYaw   = smoothYaw   * 0.4f + rawYaw   * 0.6f;
        smoothPitch = smoothPitch * 0.4f + rawPitch * 0.6f;
    }
    g_camera->rotate(smoothYaw, smoothPitch);

    // Track shake: magnitude of camera delta this frame
    float camDelta = sqrtf(smoothYaw*smoothYaw + smoothPitch*smoothPitch);
    g_shakeMetric  = g_shakeMetric * 0.9f + camDelta * 0.1f;

    // Move
    Vec3 mov=g_input->getMovement();
    Vec3 fwd=g_camera->getForward(); fwd.y=0; fwd=normalize(fwd);
    Vec3 rgt=g_camera->getRight();   rgt.y=0; rgt=normalize(rgt);
    Vec3 movW=rgt*(mov.x*5.5f*dt)+fwd*(-mov.z*5.5f*dt);

    // Movement direction (normalised) passed to World::update for chunk priority
    float movLen = sqrtf(movW.x*movW.x + movW.z*movW.z);
    float movDirX = (movLen > 1e-4f) ? movW.x/movLen : 0.f;
    float movDirZ = (movLen > 1e-4f) ? movW.z/movLen : 0.f;

    g_onGround = onGround(g_world.get(), g_physPos);
    if (g_onGround) {
        if (g_velY < 0.f) g_velY = 0.f;
        if (g_input->isJumpPressed()) g_velY = 9.5f;
    } else {
        g_velY -= 22.f * dt;
        if (g_velY < -60.f) g_velY = -60.f;
    }
    movW.y = g_velY * dt;

    float prevY = g_physPos.y;
    Vec3 newPos = collide(g_world.get(), g_physPos, movW);

    // ── Smooth step-up camera ────────────────────────────────────────────────
    // collide() may snap the physics Y up by ~1 block (step-up).
    // Instead of teleporting the camera, we keep g_smoothY at the old height
    // and let it lerp up at 10 blocks/sec — giving a smooth glide up the step.
    // For all other Y changes (jumping, falling) camera snaps instantly.
    bool stepped = (newPos.y - prevY > 0.5f) && g_onGround;
    if (stepped) {
        // Keep smoothY at old level; it will interpolate up next frames
        // (g_smoothY is already at prevY from last frame, no assignment needed)
    } else {
        g_smoothY = newPos.y;  // snap for falls / jumps / normal walk
    }
    // Glide camera Y up toward physics Y at Minecraft-like speed.
    // 4 blocks/sec → a 1-block step takes ~0.25s — matches Minecraft's feel.
    if (g_smoothY < newPos.y) {
        g_smoothY += 4.f * dt;
        if (g_smoothY > newPos.y) g_smoothY = newPos.y;
    }
    // Always snap down (falling)
    if (g_smoothY > newPos.y) g_smoothY = newPos.y;

    // Respawn if player falls out of world
    if (newPos.y < -10.f) {
        newPos   = {8.f, 100.f, 8.f};
        g_velY   = 0.f;
        g_smoothY = 100.f;
    }
    g_physPos = newPos;
    // Camera uses smooth Y for rendering; physics always uses g_physPos
    g_camera->setPosition({g_physPos.x, g_smoothY, g_physPos.z});

    // Raycast from visual eye position
    Vec3 eye=g_camera->getPosition(), dir=g_camera->getForward();
    Vec3 hitPos,hitNorm;
    bool hasTarget=g_world->raycast(eye,dir,6.f,hitPos,hitNorm);

    // Place
    if(g_input->isPlacePressed()&&hasTarget){
        // hitPos is already integer block coords (from raycast floorf).
        // hitNorm is exactly {-1,0,+1}. Simple integer addition is correct.
        int px=(int)hitPos.x + (int)roundf(hitNorm.x);
        int py=(int)hitPos.y + (int)roundf(hitNorm.y);
        int pz=(int)hitPos.z + (int)roundf(hitNorm.z);
        Vec3 ep=g_camera->getPosition();
        bool inside=(px==(int)floorf(ep.x)&&pz==(int)floorf(ep.z))&&
                    (py==(int)floorf(ep.y)||py==(int)floorf(ep.y)-1||py==(int)floorf(ep.y)-2);
        if(!inside) g_world->setBlock(px,py,pz,g_hotbar[g_hotbarSel]);
    }

    // Break (hold) — only solid blocks can be broken
    if(g_input->isBreakHeld() && hasTarget) {
        int hx=(int)floorf(hitPos.x), hy=(int)floorf(hitPos.y), hz=(int)floorf(hitPos.z);
        uint8_t targetBlock = g_world->getBlock(hx, hy, hz);
        bool breakable = blockSolid(targetBlock); // only solid blocks break
        if (breakable) {
            if(hx==g_breakX && hy==g_breakY && hz==g_breakZ) {
                g_breakProgress += dt / BREAK_TIME;
                if(g_breakProgress >= 1.f) {
                    g_world->setBlock(hx, hy, hz, BLOCK_AIR);
                    g_breakProgress=0.f; g_breakX=g_breakY=g_breakZ=-99999;
                }
            } else {
                // New target: reset progress
                g_breakX=hx; g_breakY=hy; g_breakZ=hz; g_breakProgress=0.f;
            }
        } else {
            // Non-solid target (water/lava): don't show progress
            g_breakProgress=0.f; g_breakX=g_breakY=g_breakZ=-99999;
        }
    } else { g_breakProgress=0.f; g_breakX=g_breakY=g_breakZ=-99999; }

    g_input->clearActions();
    g_world->update(g_physPos.x, g_physPos.z, g_renderDist, movDirX, movDirZ);

    // ── Debug recording (every 2 sec) ────────────────────────────────────────
    g_debugTimer += dt;
    if (g_debugTimer >= 2.0f) {
        g_debugTimer = 0.f;
        Vec3 p = g_camera->getPosition();
        DBGLOG("CAMERA",  "pos=(%.1f,%.1f,%.1f) yaw=%.2f pitch=%.2f",
               p.x, p.y, p.z,
               g_camera->getYaw(), g_camera->getPitch());
        DBGLOG("PHYSICS", "velY=%.2f onGround=%d shake=%.5f",
               g_velY, (int)g_onGround, g_shakeMetric);
        DBGLOG("WORLD",   "chunks=%zu renderDist=%d fps=%d avgDt=%.1fms",
               g_world->chunkCount(), g_renderDist, g_fpsDisplay,
               g_avgFrameTime*1000.f);
        DBGLOG("BREAK",   "progress=%.2f target=(%d,%d,%d)",
               g_breakProgress, g_breakX, g_breakY, g_breakZ);
        DebugLog::get().flush();
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
extern "C" {

JNIEXPORT jstring JNICALL
Java_com_voxel_game_GameRenderer_nativeSetup(JNIEnv* env,jobject,jstring jDir){
    const char* dir=env->GetStringUTFChars(jDir,nullptr);
    snprintf(g_crashPath,sizeof(g_crashPath),"%s/crash.txt",dir);
    // Set debug log path next to crash log
    char dbgPath[512];
    snprintf(dbgPath, sizeof(dbgPath), "%s/debug.txt", dir);
    DebugLog::get().setPath(dbgPath);
    DBGLOG("STARTUP", "Debug log started. Path: %s", dbgPath);
    env->ReleaseStringUTFChars(jDir,dir);
    installCrashHandler(g_crashPath);
    std::string rep=loadAndClearCrashReport(g_crashPath);
    return env->NewStringUTF(rep.empty()?"":rep.c_str());
}

JNIEXPORT void JNICALL
Java_com_voxel_game_GameRenderer_nativeInit(JNIEnv*,jobject){
    LOGI("nativeInit");
    const char* glv=(const char*)glGetString(GL_VERSION);
    LOGI("GL: %s",glv?glv:"null");
    if(!glv){g_errorMsg="OpenGL ES unavailable.";g_showError=true;return;}
    try {
        g_renderer=std::make_unique<Renderer>();
        if(!g_renderer->init()){g_errorMsg="Shader compile failed.";g_showError=true;return;}
        g_world  =std::make_unique<World>(12345u);
        g_camera =std::make_unique<Camera>();
        g_input  =std::make_unique<Input>();
        g_camera->setPosition({8.f,100.f,8.f});
        g_physPos = {8.f, 100.f, 8.f};
        g_smoothY = 100.f;
        g_velY=0.f; g_lastNs=nowNs(); g_inited=true;
        LOGI("nativeInit OK");
    } catch(const std::exception& e){
        g_errorMsg=std::string("Init exception: ")+e.what(); g_showError=true;
    } catch(...){g_errorMsg="Unknown init exception";g_showError=true;}
}

JNIEXPORT void JNICALL
Java_com_voxel_game_GameRenderer_nativeResize(JNIEnv*,jobject,jint w,jint h){
    g_width=w; g_height=h;
    if(g_renderer) g_renderer->resize(w,h);
    if(g_camera)   g_camera->updateProjection((float)w/(float)h);
    if(g_input)    g_input->setScreenSize((float)w,(float)h);
    recomputePanelGeometry((float)w,(float)h);
    LOGI("resize %dx%d panelX=%.0f sliderY=%.0f", w,h,g_panelX,g_sliderY);
}

JNIEXPORT void JNICALL
Java_com_voxel_game_GameRenderer_nativeRender(JNIEnv*,jobject){
    if(g_showError){renderError();return;}
    if(!g_inited) return;

    long now=nowNs();
    float dt=(float)(now-g_lastNs)*1e-9f;
    g_lastNs=now;

    if(!g_settingsOpen) gameTick(dt);

    g_renderer->beginFrame();

    size_t ready=g_world->chunkCount();
    if(!g_everHadChunks){
        if(ready>=2) g_everHadChunks=true;
        else{
            g_loadFrame++;
            g_renderer->renderLoading((float)g_width,(float)g_height,g_loadFrame);
            return;
        }
    }

    glUseProgram(g_renderer->getWorldProg());
    Mat4 vp=g_camera->getViewProjection();
    g_world->renderAll(g_renderer->getMVPLoc(),vp.m);

    g_renderer->renderHUD(
        (float)g_width,(float)g_height,
        g_input->joyBaseX(), g_input->joyBaseY(),
        g_input->joyThumbX(),g_input->joyThumbY(),
        g_input->joyActive(),
        g_breakProgress,
        g_fpsDisplay,
        g_renderDist,
        g_settingsOpen,
        g_hotbarSel,
        g_hotbar
    );
}

JNIEXPORT void JNICALL
Java_com_voxel_game_GameRenderer_nativeTouchDown(JNIEnv*,jobject,jint id,jfloat x,jfloat y){
    if(!g_input) return;
    float sw=(float)g_width;
    // Gear button: top-right corner
    if (x > sw-70.f && y < 70.f) { g_settingsOpen=!g_settingsOpen; return; }
    if (g_settingsOpen) {
        // ── Render distance slider ─────────────────────────────────────────
        // Hit-test: within thumb radius of the slider track (generous zone)
        float distToTrack = fabsf(y - g_sliderY);
        if (distToTrack <= g_sliderThumbR * 1.5f &&
            x >= g_sliderL - g_sliderThumbR && x <= g_sliderR + g_sliderThumbR) {
            g_sliderDragging = true;
            float frac = (x - g_sliderL) / (g_sliderR - g_sliderL);
            frac = frac < 0.f ? 0.f : frac > 1.f ? 1.f : frac;
            int newDist = 1 + (int)(frac * (SLIDER_MAX - 1.f) + 0.5f);
            if (newDist < 1) newDist = 1;
            g_renderDist = newDist;
            return;
        }
        // COPY DEBUG LOG button (bottom-right of panel, matches Renderer coords)
        {
            float dbgBx=g_panelX+g_panelW-90, dbgBy=g_panelY+g_panelH-36;
            float dbgBw=80, dbgBh=26;
            if (x>=dbgBx && x<=dbgBx+dbgBw && y>=dbgBy && y<=dbgBy+dbgBh) {
                DebugLog::get().flush();
                g_copyDebugPending = true;
                return;
            }
        }
        // Tap outside panel = close
        bool inPanel=(x>=g_panelX && x<=g_panelX+g_panelW &&
                      y>=g_panelY && y<=g_panelY+g_panelH);
        if (!inPanel) g_settingsOpen=false;
        return;  // eat all taps while panel open
    }

    // Hotbar slot tap (bottom centre)
    {
        float sh_f=(float)g_height, sw_f=(float)g_width;
        const float slotW=54.f, gap=6.f;
        float totalW=9*(slotW+gap)-gap;
        float startX=(sw_f-totalW)*0.5f;
        float slotY=sh_f-slotW-14.f;
        if (y>=slotY && y<=sh_f-8.f) {
            int slot=(int)((x-startX)/(slotW+gap));
            if (slot>=0 && slot<9) { g_hotbarSel=slot; return; }
        }
    }
    g_input->onTouchDown(id,x,y);
}
JNIEXPORT void JNICALL
Java_com_voxel_game_GameRenderer_nativeTouchMove(JNIEnv*,jobject,jint id,jfloat x,jfloat y){
    // Slider drag takes priority — update renderDist even while settings panel is open
    if (g_sliderDragging) {
        float frac = (x - g_sliderL) / (g_sliderR - g_sliderL);
        frac = frac < 0.f ? 0.f : frac > 1.f ? 1.f : frac;
        int newDist = 1 + (int)(frac * (SLIDER_MAX - 1.f) + 0.5f);
        if (newDist < 1) newDist = 1;
        g_renderDist = newDist;
        return;
    }
    if(g_input&&!g_settingsOpen) g_input->onTouchMove(id,x,y);
}
JNIEXPORT void JNICALL
Java_com_voxel_game_GameRenderer_nativeTouchUp(JNIEnv*,jobject,jint id,jfloat x,jfloat y){
    g_sliderDragging = false;
    if(g_input) g_input->onTouchUp(id,x,y);
}

// ── Debug export ─────────────────────────────────────────────────────────────
JNIEXPORT jstring JNICALL
Java_com_voxel_game_GameRenderer_nativeGetDebugLog(JNIEnv* env, jobject) {
    std::string log = DebugLog::get().all();
    return env->NewStringUTF(log.c_str());
}

JNIEXPORT void JNICALL
Java_com_voxel_game_GameRenderer_nativeFlushDebugLog(JNIEnv*, jobject) {
    DebugLog::get().flush();
}

// Called every frame from onDrawFrame() — returns pending debug log to copy, else "".
JNIEXPORT jstring JNICALL
Java_com_voxel_game_GameRenderer_nativeGetPendingDebugCopy(JNIEnv* env, jobject) {
    if (!g_copyDebugPending) return env->NewStringUTF("");
    g_copyDebugPending = false;
    if (g_camera && g_world) {
        Vec3 p = g_camera->getPosition();
        DBGLOG("SNAPSHOT", "=== User-requested debug snapshot ===");
        DBGLOG("CAMERA",   "pos=(%.2f,%.2f,%.2f) yaw=%.3f pitch=%.3f",
               p.x, p.y, p.z, g_camera->getYaw(), g_camera->getPitch());
        DBGLOG("PHYSICS",  "velY=%.3f onGround=%d shake=%.5f",
               g_velY, (int)g_onGround, g_shakeMetric);
        DBGLOG("WORLD",    "chunks=%zu renderDist=%d fps=%d avgDt=%.2fms",
               g_world->chunkCount(), g_renderDist, g_fpsDisplay,
               g_avgFrameTime*1000.f);
        DebugLog::get().flush();
    }
    std::string log = DebugLog::get().all();
    if (log.empty()) log = "(no debug entries yet — play for a moment and try again)";
    return env->NewStringUTF(log.c_str());
}

} // extern "C"
