#include "Renderer.h"
#include "BlockDefs.h"
#include "Input.h"
#include <cmath>
#include <cstring>
#include <cstdio>
#include <algorithm>
#include <android/log.h>

#define LOG_TAG "VoxelRenderer"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)

// ── World shader ──────────────────────────────────────────────────────────────
static const char* WORLD_VERT = R"(#version 300 es
precision highp float;
layout(location=0) in vec3 aPos;
layout(location=1) in vec3 aColor;
layout(location=2) in float aLight;
uniform mat4 uMVP;
out vec3 vColor;
void main(){
    gl_Position = uMVP * vec4(aPos, 1.0);
    vColor = aColor * aLight;
}
)";
static const char* WORLD_FRAG = R"(#version 300 es
precision mediump float;
in vec3 vColor;
out vec4 fragColor;
void main(){ fragColor = vec4(vColor, 1.0); }
)";

// ── HUD batch shader — per-vertex colour, no uniform colour ──────────────────
// All HUD geometry (triangles + lines) is drawn with a single shader.
// Per-vertex colour eliminates the need to flush the batch per colour change.
static const char* HUD_VERT = R"(#version 300 es
precision mediump float;
layout(location=0) in vec2 aPos;
layout(location=1) in vec4 aColor;
uniform mat4 uOrtho;
out vec4 vColor;
void main(){ gl_Position = uOrtho * vec4(aPos, 0.0, 1.0); vColor = aColor; }
)";
static const char* HUD_FRAG = R"(#version 300 es
precision mediump float;
in vec4 vColor;
out vec4 fragColor;
void main(){ fragColor = vColor; }
)";

// ── Shader helpers ─────────────────────────────────────────────────────────
GLuint Renderer::compileShader(GLenum type, const char* src) {
    GLuint s = glCreateShader(type);
    glShaderSource(s, 1, &src, nullptr);
    glCompileShader(s);
    GLint ok; glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
    if (!ok) { char b[512]; glGetShaderInfoLog(s,512,nullptr,b); LOGE("Shader: %s",b); }
    return s;
}
GLuint Renderer::linkProgram(GLuint v, GLuint f) {
    GLuint p = glCreateProgram();
    glAttachShader(p, v); glAttachShader(p, f); glLinkProgram(p);
    GLint ok; glGetProgramiv(p, GL_LINK_STATUS, &ok);
    if (!ok) { char b[512]; glGetProgramInfoLog(p,512,nullptr,b); LOGE("Link: %s",b); }
    glDeleteShader(v); glDeleteShader(f);
    return p;
}

bool Renderer::init() {
    LOGI("GL: %s | %s", glGetString(GL_VENDOR), glGetString(GL_RENDERER));
    worldProg = linkProgram(compileShader(GL_VERTEX_SHADER,   WORLD_VERT),
                            compileShader(GL_FRAGMENT_SHADER, WORLD_FRAG));
    hudProg   = linkProgram(compileShader(GL_VERTEX_SHADER,   HUD_VERT),
                            compileShader(GL_FRAGMENT_SHADER, HUD_FRAG));
    mvpLoc      = glGetUniformLocation(worldProg, "uMVP");
    hudOrthoLoc = glGetUniformLocation(hudProg,   "uOrtho");

    // Single VBO for all HUD batch data (resized dynamically)
    glGenVertexArrays(1, &hudVAO);
    glGenBuffers(1, &hudVBO);
    glBindVertexArray(hudVAO);
    glBindBuffer(GL_ARRAY_BUFFER, hudVBO);
    // Pre-allocate 64KB — enough for ~5400 HUD vertices
    glBufferData(GL_ARRAY_BUFFER, 65536, nullptr, GL_DYNAMIC_DRAW);
    // aPos   @ loc 0: 2 floats, stride=6*4=24, offset=0
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 24, (void*)0);
    // aColor @ loc 1: 4 floats, stride=24, offset=8
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, 24, (void*)(2*sizeof(float)));
    glBindVertexArray(0);

    // Reserve expected capacity to avoid realloc during renderHUD
    hudTriBatch.reserve(2048);
    hudLineBatch.reserve(4096);

    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LEQUAL);
    glEnable(GL_CULL_FACE);
    glCullFace(GL_BACK);
    return (worldProg != 0 && hudProg != 0);
}

Renderer::~Renderer() {
    if (worldProg) glDeleteProgram(worldProg);
    if (hudProg)   glDeleteProgram(hudProg);
    if (hudVAO)    glDeleteVertexArrays(1, &hudVAO);
    if (hudVBO)    glDeleteBuffers(1, &hudVBO);
}

void Renderer::resize(int w, int h) {
    screenW = w; screenH = h;
    glViewport(0, 0, w, h);
}

void Renderer::beginFrame() {
    glClearColor(0.53f, 0.81f, 0.98f, 1.f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
}

// ── Batch helpers — zero GL calls, just append to CPU vectors ─────────────────
// Vertex layout: x, y, r, g, b, a (6 floats)
static inline void pushVert(std::vector<float>& v,
                             float x, float y, float r, float g, float b, float a) {
    v.push_back(x); v.push_back(y);
    v.push_back(r); v.push_back(g); v.push_back(b); v.push_back(a);
}

void Renderer::batchLine(float x0, float y0, float x1, float y1,
                          float r, float g, float b, float a) {
    pushVert(hudLineBatch, x0, y0, r, g, b, a);
    pushVert(hudLineBatch, x1, y1, r, g, b, a);
}

void Renderer::batchRect(float x, float y, float w, float h,
                          float r, float g, float b, float a) {
    // 2 triangles (6 vertices)
    pushVert(hudTriBatch, x,   y,   r,g,b,a);
    pushVert(hudTriBatch, x+w, y,   r,g,b,a);
    pushVert(hudTriBatch, x+w, y+h, r,g,b,a);
    pushVert(hudTriBatch, x,   y,   r,g,b,a);
    pushVert(hudTriBatch, x+w, y+h, r,g,b,a);
    pushVert(hudTriBatch, x,   y+h, r,g,b,a);
}

void Renderer::batchCircle(float cx, float cy, float radius,
                            float r, float g, float b, float a, bool filled) {
    const int N = 32;   // reduced from 40 — imperceptible on mobile
    if (filled) {
        for (int i = 0; i < N; i++) {
            float a0 = 6.2831853f * i / N;
            float a1 = 6.2831853f * (i+1) / N;
            pushVert(hudTriBatch, cx, cy, r,g,b,a);
            pushVert(hudTriBatch, cx+cosf(a0)*radius, cy+sinf(a0)*radius, r,g,b,a);
            pushVert(hudTriBatch, cx+cosf(a1)*radius, cy+sinf(a1)*radius, r,g,b,a);
        }
    } else {
        for (int i = 0; i < N; i++) {
            float a0 = 6.2831853f * i / N;
            float a1 = 6.2831853f * (i+1) / N;
            pushVert(hudLineBatch, cx+cosf(a0)*radius, cy+sinf(a0)*radius, r,g,b,a);
            pushVert(hudLineBatch, cx+cosf(a1)*radius, cy+sinf(a1)*radius, r,g,b,a);
        }
    }
}

void Renderer::batchArc(float cx, float cy, float radius,
                         float startAngle, float endAngle,
                         float r, float g, float b, float a) {
    if (endAngle <= startAngle) return;
    const int N = 32;
    for (int i = 0; i < N; i++) {
        float t0 = startAngle + (endAngle-startAngle)*i/N;
        float t1 = startAngle + (endAngle-startAngle)*(i+1)/N;
        pushVert(hudLineBatch, cx+cosf(t0)*radius, cy+sinf(t0)*radius, r,g,b,a);
        pushVert(hudLineBatch, cx+cosf(t1)*radius, cy+sinf(t1)*radius, r,g,b,a);
    }
}

// ── flushHUD — exactly 2 GL draw calls for all HUD geometry ──────────────────
// Replaces ~1300 GL operations per frame with ~10.
static void buildOrtho(float l, float r, float b, float t, float* m) {
    memset(m, 0, 64);
    m[0]=2/(r-l); m[5]=2/(t-b); m[10]=-1;
    m[12]=-(r+l)/(r-l); m[13]=-(t+b)/(t-b); m[15]=1;
}

void Renderer::flushHUD() {
    if (hudTriBatch.empty() && hudLineBatch.empty()) return;

    glUseProgram(hudProg);
    float ortho[16];
    buildOrtho(0, (float)screenW, (float)screenH, 0, ortho);
    glUniformMatrix4fv(hudOrthoLoc, 1, GL_FALSE, ortho);
    glBindVertexArray(hudVAO);
    glBindBuffer(GL_ARRAY_BUFFER, hudVBO);

    // ── Triangles ─────────────────────────────────────────────────────────────
    if (!hudTriBatch.empty()) {
        GLsizeiptr sz = (GLsizeiptr)(hudTriBatch.size()*sizeof(float));
        // If data fits in existing buffer, use SubData (no realloc)
        glBufferData(GL_ARRAY_BUFFER, sz, hudTriBatch.data(), GL_DYNAMIC_DRAW);
        glDrawArrays(GL_TRIANGLES, 0, (GLsizei)(hudTriBatch.size()/6));
    }

    // ── Lines ─────────────────────────────────────────────────────────────────
    if (!hudLineBatch.empty()) {
        GLsizeiptr sz = (GLsizeiptr)(hudLineBatch.size()*sizeof(float));
        glBufferData(GL_ARRAY_BUFFER, sz, hudLineBatch.data(), GL_DYNAMIC_DRAW);
        glLineWidth(2.f);
        glDrawArrays(GL_LINES, 0, (GLsizei)(hudLineBatch.size()/6));
    }

    glBindVertexArray(0);
    hudTriBatch.clear();
    hudLineBatch.clear();
}

// ── 7-segment digit font (batch version) ─────────────────────────────────────
static const uint8_t SEG7[10] = {
    0b0111111, 0b0000110, 0b1011011, 0b1001111, 0b1100110,
    0b1101101, 0b1111101, 0b0000111, 0b1111111, 0b1101111,
};

void Renderer::batchDigit(int digit, float x, float y, float scale,
                            float r, float g, float b, float a) {
    if (digit < 0 || digit > 9) return;
    uint8_t segs = SEG7[digit];
    float w = scale*4.f, h = scale*4.f;
    struct Seg { float x0,y0,x1,y1; };
    Seg S[7] = {
        {x+scale,y,     x+w-scale,y    },
        {x+w,   y+scale,x+w,      y+h-scale},
        {x+w,   y+h+scale,x+w,    y+2*h-scale},
        {x+scale,y+2*h, x+w-scale,y+2*h},
        {x,     y+h+scale,x,      y+2*h-scale},
        {x,     y+scale,  x,      y+h-scale},
        {x+scale,y+h,   x+w-scale,y+h  },
    };
    for (int i = 0; i < 7; i++)
        if (segs & (1<<i))
            batchLine(S[i].x0,S[i].y0, S[i].x1,S[i].y1, r,g,b,a);
}

void Renderer::batchNumber(int num, float x, float y, float scale,
                             float r, float g, float b, float a) {
    if (num < 0) num = 0;
    char buf[8]; snprintf(buf, 8, "%d", num);
    float charW = scale*6.f;
    for (int i = 0; buf[i]; i++)
        batchDigit(buf[i]-'0', x+i*charW, y, scale, r,g,b,a);
}

// ── Stroke font A-Z ───────────────────────────────────────────────────────────
namespace {
static const float FA[]={0,6,2,0, 2,0,4,6, 1,3,3,3, -1};
static const float FB[]={0,0,0,6, 0,0,3,0, 3,0,4,1, 4,1,4,2, 4,2,3,3, 3,3,0,3, 0,3,3,3, 3,3,4,4, 4,4,4,5, 4,5,3,6, 3,6,0,6, -1};
static const float FC[]={4,1,3,0, 3,0,1,0, 1,0,0,1, 0,1,0,5, 0,5,1,6, 1,6,3,6, 3,6,4,5, -1};
static const float FD[]={0,0,0,6, 0,0,2,0, 2,0,4,2, 4,2,4,4, 4,4,2,6, 2,6,0,6, -1};
static const float FE[]={0,0,0,6, 0,0,4,0, 0,3,3,3, 0,6,4,6, -1};
static const float FF[]={0,0,0,6, 0,0,4,0, 0,3,3,3, -1};
static const float FG[]={4,1,3,0, 3,0,1,0, 1,0,0,1, 0,1,0,5, 0,5,1,6, 1,6,3,6, 3,6,4,5, 4,5,4,3, 4,3,2,3, -1};
static const float FH[]={0,0,0,6, 4,0,4,6, 0,3,4,3, -1};
static const float FI[]={1,0,3,0, 2,0,2,6, 1,6,3,6, -1};
static const float FJ[]={2,0,4,0, 3,0,3,5, 3,5,2,6, 2,6,1,6, 1,6,0,5, -1};
static const float FK[]={0,0,0,6, 4,0,0,3, 0,3,4,6, -1};
static const float FL[]={0,0,0,6, 0,6,4,6, -1};
static const float FM[]={0,6,0,0, 0,0,2,3, 2,3,4,0, 4,0,4,6, -1};
static const float FN[]={0,6,0,0, 0,0,4,6, 4,6,4,0, -1};
static const float FO[]={1,0,3,0, 3,0,4,1, 4,1,4,5, 4,5,3,6, 3,6,1,6, 1,6,0,5, 0,5,0,1, 0,1,1,0, -1};
static const float FP[]={0,0,0,6, 0,0,3,0, 3,0,4,1, 4,1,4,2, 4,2,3,3, 3,3,0,3, -1};
static const float FQ[]={1,0,3,0, 3,0,4,1, 4,1,4,5, 4,5,3,6, 3,6,1,6, 1,6,0,5, 0,5,0,1, 0,1,1,0, 3,4,4,6, -1};
static const float FR[]={0,0,0,6, 0,0,3,0, 3,0,4,1, 4,1,4,2, 4,2,3,3, 3,3,0,3, 2,3,4,6, -1};
static const float FS[]={4,1,3,0, 3,0,1,0, 1,0,0,1, 0,1,0,3, 0,3,4,3, 4,3,4,5, 4,5,3,6, 3,6,1,6, 1,6,0,5, -1};
static const float FT[]={0,0,4,0, 2,0,2,6, -1};
static const float FU[]={0,0,0,5, 0,5,1,6, 1,6,3,6, 3,6,4,5, 4,5,4,0, -1};
static const float FV[]={0,0,2,6, 2,6,4,0, -1};
static const float FW[]={0,0,1,6, 1,6,2,4, 2,4,3,6, 3,6,4,0, -1};
static const float FX[]={0,0,4,6, 4,0,0,6, -1};
static const float FY[]={0,0,2,3, 4,0,2,3, 2,3,2,6, -1};
static const float FZ[]={0,0,4,0, 4,0,0,6, 0,6,4,6, -1};
static const float* FONT_TABLE[26] = {
    FA,FB,FC,FD,FE,FF,FG,FH,FI,FJ,FK,FL,FM,
    FN,FO,FP,FQ,FR,FS,FT,FU,FV,FW,FX,FY,FZ
};
} // namespace

void Renderer::batchChar(char c, float x, float y, float scale,
                          float r, float g, float b, float a) {
    if (c >= 'a' && c <= 'z') c -= 32;
    if (c < 'A' || c > 'Z') return;
    const float* s = FONT_TABLE[c - 'A'];
    for (int i = 0; s[i] >= 0; i += 4)
        batchLine(x+s[i]*scale, y+s[i+1]*scale,
                  x+s[i+2]*scale, y+s[i+3]*scale, r,g,b,a);
}

void Renderer::batchText(const char* str, float x, float y, float scale,
                          float r, float g, float b, float a) {
    float charW = scale * 5.f;
    for (int i = 0; str[i]; i++) {
        char c = str[i];
        if (c >= 'a' && c <= 'z') c -= 32;
        if (c != ' ') batchChar(c, x+i*charW, y, scale, r,g,b,a);
    }
}

// ── Main HUD ──────────────────────────────────────────────────────────────────
void Renderer::renderHUD(
    float sw, float sh,
    float joyBaseX, float joyBaseY,
    float joyThumbX, float joyThumbY,
    bool  joyActive,
    float breakProgress,
    int   fps,
    int   renderDist,
    bool  settingsOpen,
    int   hotbarSel,
    const uint8_t* hotbarTypes)
{
    glDisable(GL_DEPTH_TEST);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    // ── Crosshair ─────────────────────────────────────────────────────────────
    float cx=sw*0.5f, cy=sh*0.5f, cs=22.f;
    batchLine(cx-cs,cy, cx+cs,cy, 1,1,1);
    batchLine(cx,cy-cs, cx,cy+cs, 1,1,1);

    // ── Break arc ─────────────────────────────────────────────────────────────
    if (breakProgress > 0.f)
        batchArc(cx,cy, cs+12.f, -1.5707f, -1.5707f+breakProgress*6.2831853f,
                 1.f,0.3f,0.1f);

    // ── Joystick ──────────────────────────────────────────────────────────────
    float jAlpha = joyActive ? 0.65f : 0.28f;
    batchCircle(joyBaseX,joyBaseY, Input::JOY_RADIUS,    1,1,1,jAlpha,        false);
    batchCircle(joyBaseX,joyBaseY, Input::JOY_RADIUS*0.35f,1,1,1,jAlpha*0.5f,false);
    float tAlpha = joyActive ? 0.80f : 0.35f;
    batchCircle(joyThumbX,joyThumbY, 34.f, 0.85f,0.85f,0.90f,tAlpha, true);
    batchCircle(joyThumbX,joyThumbY, 34.f, 1.f,  1.f,  1.f,  tAlpha, false);

    // ── Action buttons ────────────────────────────────────────────────────────
    float jBx=sw*0.82f, jBy=sh*0.65f;
    float pBx=sw*0.72f, pBy=sh*0.77f;
    float bBx=sw*0.89f, bBy=sh*0.77f;
    float bR=54.f;

    // JUMP
    batchCircle(jBx,jBy,bR, 0.10f,0.65f,0.10f,0.65f, true);
    batchCircle(jBx,jBy,bR, 0.30f,1.00f,0.30f,0.90f, false);
    batchLine(jBx-14,jBy+10, jBx,jBy-10,    1,1,1);
    batchLine(jBx,jBy-10,   jBx+14,jBy+10,  1,1,1);
    batchLine(jBx-22,jBy+bR+12, jBx+22,jBy+bR+12, 0.4f,1.f,0.4f,0.8f);

    // PLACE
    batchCircle(pBx,pBy,bR, 0.70f,0.35f,0.05f,0.65f, true);
    batchCircle(pBx,pBy,bR, 1.00f,0.65f,0.20f,0.90f, false);
    batchLine(pBx-16,pBy, pBx+16,pBy,    1,1,1);
    batchLine(pBx,pBy-16, pBx,pBy+16,    1,1,1);
    batchLine(pBx-26,pBy+bR+12, pBx+26,pBy+bR+12, 1.f,0.65f,0.2f,0.8f);

    // BREAK
    batchCircle(bBx,bBy,bR, 0.65f,0.05f,0.05f,0.65f, true);
    batchCircle(bBx,bBy,bR, 1.00f,0.25f,0.25f,0.90f, false);
    batchLine(bBx-14,bBy-14, bBx+14,bBy+14, 1,1,1);
    batchLine(bBx+14,bBy-14, bBx-14,bBy+14, 1,1,1);
    batchLine(bBx-28,bBy+bR+12, bBx+28,bBy+bR+12, 1.f,0.3f,0.3f,0.8f);

    // ── FPS counter ───────────────────────────────────────────────────────────
    float fc0,fc1,fc2;
    if      (fps < 25) { fc0=1.f; fc1=0.2f; fc2=0.1f; }
    else if (fps < 45) { fc0=1.f; fc1=0.8f; fc2=0.1f; }
    else               { fc0=0.2f;fc1=1.f; fc2=0.2f; }
    batchRect(8,8,130,38, 0,0,0,0.45f);
    batchNumber(fps, 16, 14, 3.f, fc0,fc1,fc2);

    // ── Hotbar ────────────────────────────────────────────────────────────────
    if (hotbarTypes) {
        const float slotW=54.f, slotH=54.f, gap=6.f;
        float totalW=9*slotW+8*gap;
        float startX=(sw-totalW)*0.5f;
        float slotY=sh-slotH-14.f;

        float cols[14][3]={
            {0,0,0},
            {0.30f,0.68f,0.18f}, {0.56f,0.36f,0.15f}, {0.50f,0.50f,0.50f},
            {0.85f,0.80f,0.50f}, {0.46f,0.44f,0.43f}, {0.36f,0.22f,0.10f},
            {0.15f,0.45f,0.10f}, {0.96f,0.96f,1.00f}, {0.03f,0.18f,0.62f},
            {0.90f,0.30f,0.05f}, {0.28f,0.28f,0.28f}, {0.62f,0.55f,0.48f},
            {0.90f,0.80f,0.40f},
        };
        static const char* BNAME[14] = {
            "","GRSS","DIRT","STON","SAND","GRVL",
            "LOG","LEAF","SNOW","WATR","LAVA","COAL","IRON","GLOW"
        };

        for (int i = 0; i < 9; i++) {
            float sx=startX+i*(slotW+gap);
            bool sel=(i==hotbarSel);
            batchRect(sx,slotY,slotW,slotH,
                      sel?0.20f:0.10f, sel?0.20f:0.10f, sel?0.25f:0.12f,
                      sel?0.90f:0.65f);
            int t=(int)hotbarTypes[i];
            if (t>0 && t<14) {
                float swH=slotH*0.62f;
                batchRect(sx+5,slotY+4,slotW-10,swH, cols[t][0],cols[t][1],cols[t][2],1.f);
                const char* nm=BNAME[t];
                int nl=0; while(nm[nl]) nl++;
                float ts=1.4f, tw=nl*ts*5.f;
                batchText(nm, sx+(slotW-tw)*0.5f, slotY+swH+7.f, ts, 0.95f,0.95f,0.95f,0.92f);
            }
            if (sel) {
                float bx=sx,by=slotY;
                batchLine(bx,by,      bx+slotW,by,       1,1,1);
                batchLine(bx+slotW,by,bx+slotW,by+slotH, 1,1,1);
                batchLine(bx+slotW,by+slotH,bx,by+slotH, 1,1,1);
                batchLine(bx,by+slotH,bx,by,              1,1,1);
            }
        }
    }

    // ── Gear button ───────────────────────────────────────────────────────────
    float gx=sw-40.f, gy=40.f;
    batchRect(gx-30,gy-30,60,60, 0,0,0,0.5f);
    batchCircle(gx,gy,18.f, 0.9f,0.9f,0.9f,1.f, false);
    batchCircle(gx,gy, 8.f, 0.9f,0.9f,0.9f,1.f, false);
    for (int ti=0;ti<8;ti++) {
        float ang=3.14159f*ti/4.f;
        batchLine(gx+cosf(ang)*18,gy+sinf(ang)*18,
                  gx+cosf(ang)*25,gy+sinf(ang)*25, 0.9f,0.9f,0.9f);
    }

    // ── Settings panel ────────────────────────────────────────────────────────
    if (settingsOpen) {
        batchRect(0,0,sw,sh, 0,0,0,0.60f);
        float pw=680.f,ph=220.f,ppx=(sw-pw)*0.5f,ppy=(sh-ph)*0.5f;
        batchRect(ppx,ppy,pw,ph, 0.07f,0.07f,0.12f,0.97f);
        batchRect(ppx,ppy,pw,5.f, 0.35f,0.55f,1.f,1.f);
        batchLine(ppx+20,ppy+22,ppx+pw-20,ppy+22, 0.5f,0.6f,0.9f,0.8f);

        // ── Render distance slider ────────────────────────────────────────
        // Continuous drag slider, no upper limit (clamp handled in jni_bridge).
        // Range displayed: 1–64. Thumb position is proportional to renderDist.
        const float slMax   = 64.f;       // visual max on slider
        const float trL     = ppx + 40.f;  // track left
        const float trR     = ppx + pw - 40.f; // track right
        const float trW     = trR - trL;
        const float trY     = ppy + ph * 0.68f; // vertical centre of track
        const float trH     = 8.f;
        const float thumbR  = 18.f;

        // Fraction clamped for display (beyond 64 thumb stays at right edge)
        float frac = std::min((float)(renderDist - 1) / (slMax - 1.f), 1.f);
        float thumbX = trL + frac * trW;

        // Track background
        batchRect(trL, trY - trH*0.5f, trW, trH, 0.15f,0.15f,0.20f, 0.90f);
        // Filled portion
        batchRect(trL, trY - trH*0.5f, thumbX-trL, trH, 0.25f,0.50f,0.95f, 0.95f);
        // Thumb circle
        batchCircle(thumbX, trY, thumbR, 0.35f,0.65f,1.00f, 1.f, true);
        batchCircle(thumbX, trY, thumbR, 0.70f,0.85f,1.00f, 1.f, false);

        // Current value label centred above thumb
        // Draw big number: renderDist value
        {
            char buf[8]; snprintf(buf, 8, "%d", renderDist);
            int digits = 0; while(buf[digits]) digits++;
            float scale = 5.f;
            float numW  = digits * scale * 6.f;
            float nx    = thumbX - numW * 0.5f;
            float ny    = trY - thumbR - scale*10.f - 4.f;
            batchNumber(renderDist, nx, ny, scale, 1.f,1.f,1.f);
        }
        // "CHUNKS" unit label (small stroke text below thumb)
        batchText("CHUNKS", thumbX - 3*1.4f*5.f, trY + thumbR + 6.f, 1.4f,
                  0.6f,0.7f,0.9f,0.8f);
        // Debug log button
        float dbgBx=ppx+pw-90,dbgBy=ppy+ph-36,dbgBw=80,dbgBh=26;
        batchRect(dbgBx,dbgBy,dbgBw,dbgBh, 0.12f,0.12f,0.20f,0.90f);
        batchLine(dbgBx+6,dbgBy+13,dbgBx+dbgBw-6,dbgBy+13, 0.5f,0.8f,0.5f,0.9f);
        batchLine(dbgBx+6,dbgBy+8, dbgBx+dbgBw-6,dbgBy+8,  0.5f,0.8f,0.5f,0.6f);
        batchLine(dbgBx+6,dbgBy+18,dbgBx+dbgBw-6,dbgBy+18, 0.5f,0.8f,0.5f,0.6f);
        batchLine(ppx+30,ppy+ph-44,dbgBx-8,ppy+ph-44, 0.35f,0.35f,0.35f,0.5f);
    }

    // ── Single flush — 2 GL draw calls for everything above ──────────────────
    flushHUD();

    glDisable(GL_BLEND);
    glEnable(GL_DEPTH_TEST);
}

void Renderer::renderLoading(float sw, float sh, int frame) {
    glDisable(GL_DEPTH_TEST);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    float cx=sw*0.5f, cy=sh*0.5f;
    const int N=8;
    for (int i=0;i<N;i++) {
        float ang=6.2831853f*i/N;
        float bright=(i==(frame/4)%N)?1.f:0.3f;
        batchCircle(cx+cosf(ang)*60.f, cy+sinf(ang)*60.f, 10.f,
                    bright,bright,bright,bright, true);
    }
    for (int i=0;i<3;i++) {
        float bright=((frame/8)%3==i)?1.f:0.25f;
        batchCircle(cx+(i-1)*30.f, cy+100.f, 8.f, 1,1,1,bright, true);
    }
    flushHUD();
    glDisable(GL_BLEND);
    glEnable(GL_DEPTH_TEST);
}
