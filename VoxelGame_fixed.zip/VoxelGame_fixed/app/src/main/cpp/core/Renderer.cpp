#include "Renderer.h"
#include "Input.h"
#include <cmath>
#include <cstring>
#include <cstdio>
#include <android/log.h>

#define LOG_TAG "VoxelRenderer"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)

// ── World shader ──────────────────────────────────────────────────────────────
static const char* WORLD_VERT = R"(#version 300 es
precision highp float;
layout(location=0) in vec3 aPos;
layout(location=1) in vec3 aColor;
layout(location=2) in float aLight;
uniform mat4 uMVP;
out vec3 vColor;
void main(){
    gl_Position = uMVP * vec4(aPos, 1.0);
    vColor = aColor * aLight;
}
)";
static const char* WORLD_FRAG = R"(#version 300 es
precision mediump float;
in vec3 vColor;
out vec4 fragColor;
void main(){
    // No fog: interpolating depth across large greedy quads causes visible
    // seam lines at quad boundaries. Chunk loading distance already limits
    // visibility naturally. Sky clear-colour provides depth perception.
    fragColor = vec4(vColor, 1.0);
}
)";

// ── HUD shader ────────────────────────────────────────────────────────────────
static const char* HUD_VERT = R"(#version 300 es
precision mediump float;
layout(location=0) in vec2 aPos;
uniform mat4 uOrtho;
void main(){ gl_Position = uOrtho * vec4(aPos, 0.0, 1.0); }
)";
static const char* HUD_FRAG = R"(#version 300 es
precision mediump float;
uniform vec4 uColor;
out vec4 fragColor;
void main(){ fragColor = uColor; }
)";

// ── Shader helpers ────────────────────────────────────────────────────────────
GLuint Renderer::compileShader(GLenum type, const char* src) {
    GLuint s = glCreateShader(type);
    glShaderSource(s, 1, &src, nullptr);
    glCompileShader(s);
    GLint ok; glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
    if (!ok) { char b[512]; glGetShaderInfoLog(s,512,nullptr,b); LOGE("Shader: %s",b); }
    return s;
}
GLuint Renderer::linkProgram(GLuint v, GLuint f) {
    GLuint p = glCreateProgram();
    glAttachShader(p, v); glAttachShader(p, f); glLinkProgram(p);
    GLint ok; glGetProgramiv(p, GL_LINK_STATUS, &ok);
    if (!ok) { char b[512]; glGetProgramInfoLog(p,512,nullptr,b); LOGE("Link: %s",b); }
    glDeleteShader(v); glDeleteShader(f);
    return p;
}

bool Renderer::init() {
    LOGI("GL: %s | %s", glGetString(GL_VENDOR), glGetString(GL_RENDERER));
    worldProg = linkProgram(compileShader(GL_VERTEX_SHADER,   WORLD_VERT),
                            compileShader(GL_FRAGMENT_SHADER, WORLD_FRAG));
    hudProg   = linkProgram(compileShader(GL_VERTEX_SHADER,   HUD_VERT),
                            compileShader(GL_FRAGMENT_SHADER, HUD_FRAG));
    mvpLoc      = glGetUniformLocation(worldProg, "uMVP");
    hudOrthoLoc = glGetUniformLocation(hudProg,   "uOrtho");
    hudColorLoc = glGetUniformLocation(hudProg,   "uColor");

    glGenVertexArrays(1, &hudVAO);
    glGenBuffers(1, &hudVBO);
    glBindVertexArray(hudVAO);
    glBindBuffer(GL_ARRAY_BUFFER, hudVBO);
    // 512 vec2 vertices = 1024 floats worth of scratch space
    glBufferData(GL_ARRAY_BUFFER, 1024 * sizeof(float), nullptr, GL_DYNAMIC_DRAW);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 0, nullptr);
    glBindVertexArray(0);

    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LEQUAL);
    glEnable(GL_CULL_FACE);
    glCullFace(GL_BACK);
    // Polygon offset: pull filled polygons toward camera by a tiny amount
    // so chunk-seam T-junction gaps (which show as blue sky lines) are covered
    // Polygon offset: pull terrain polygons slightly toward camera to eliminate
    // z-fighting at chunk boundary seams (which appear as blue/sky-colored lines).
    // Factor=-1 (slope-based) + Units=-2 (constant bias) is strong enough for all angles.
    return (worldProg != 0 && hudProg != 0);
}

void Renderer::resize(int w, int h) {
    screenW = w; screenH = h;
    glViewport(0, 0, w, h);
}

void Renderer::beginFrame() {
    glClearColor(0.53f, 0.81f, 0.98f, 1.f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
}

Renderer::~Renderer() {
    if (worldProg) glDeleteProgram(worldProg);
    if (hudProg)   glDeleteProgram(hudProg);
    if (hudVAO)    glDeleteVertexArrays(1, &hudVAO);
    if (hudVBO)    glDeleteBuffers(1, &hudVBO);
}

// ── Low-level submit helper ───────────────────────────────────────────────────
void Renderer::submitAndDraw(const float* pts, int count, GLenum mode,
                              float r, float g, float b, float a) {
    glBindVertexArray(hudVAO);
    glBindBuffer(GL_ARRAY_BUFFER, hudVBO);
    glBufferSubData(GL_ARRAY_BUFFER, 0, count * 2 * sizeof(float), pts);
    glUniform4f(hudColorLoc, r, g, b, a);
    glDrawArrays(mode, 0, count);
    glBindVertexArray(0);
}

void Renderer::drawLine(float x0, float y0, float x1, float y1,
                         float r, float g, float b, float a) {
    float pts[4] = {x0, y0, x1, y1};
    submitAndDraw(pts, 2, GL_LINES, r, g, b, a);
}

void Renderer::drawRect(float x, float y, float w, float h,
                         float r, float g, float b, float a) {
    float pts[12] = {
        x,   y,   x+w, y,   x+w, y+h,
        x,   y,   x+w, y+h, x,   y+h
    };
    submitAndDraw(pts, 6, GL_TRIANGLES, r, g, b, a);
}

void Renderer::drawCircle(float cx, float cy, float radius,
                           float r, float g, float b, float a, bool filled) {
    const int N = 40;
    if (filled) {
        // GL_TRIANGLE_FAN: vertex 0 is the shared center.
        // Then N edge vertices, then repeat vertex 1 to close the fan.
        // Total: 1 + N + 1 = N+2 vertices.
        float pts[(N + 2) * 2];
        pts[0] = cx; pts[1] = cy;  // center
        for (int i = 0; i <= N; i++) {   // N+1 edge points (last = first, closes loop)
            float ang = 6.2831853f * i / N;
            pts[(i+1)*2]   = cx + cosf(ang) * radius;
            pts[(i+1)*2+1] = cy + sinf(ang) * radius;
        }
        submitAndDraw(pts, N + 2, GL_TRIANGLE_FAN, r, g, b, a);
    } else {
        float pts[N * 2];
        for (int i = 0; i < N; i++) {
            float ang = 6.2831853f * i / N;
            pts[i*2]   = cx + cosf(ang) * radius;
            pts[i*2+1] = cy + sinf(ang) * radius;
        }
        submitAndDraw(pts, N, GL_LINE_LOOP, r, g, b, a);
    }
}

void Renderer::drawArc(float cx, float cy, float radius,
                        float startAngle, float endAngle,
                        float r, float g, float b, float) {
    if (endAngle <= startAngle) return;
    const int N = 48;
    float pts[(N+1) * 2];  // N+1 points: i=0..N inclusive
    int   count = 0;
    for (int i = 0; i <= N; i++) {
        float t   = startAngle + (endAngle - startAngle) * i / N;
        pts[count++] = cx + cosf(t) * radius;
        pts[count++] = cy + sinf(t) * radius;
    }
    submitAndDraw(pts, count/2, GL_LINE_STRIP, r, g, b, 1.f);
}

// ── 7-Segment digit renderer ──────────────────────────────────────────────────
// Each char cell is (scale*5) wide × (scale*9) tall.
// Segments A-G:
//   A=top, B=top-right, C=bot-right, D=bottom, E=bot-left, F=top-left, G=middle
static const uint8_t SEG7[10] = {
    0b0111111,  // 0: ABCDEF
    0b0000110,  // 1: BC
    0b1011011,  // 2: ABDEG (A,B,D,E,G)
    0b1001111,  // 3: ABCDG
    0b1100110,  // 4: BCFG
    0b1101101,  // 5: ACDFG
    0b1111101,  // 6: ACDEFG
    0b0000111,  // 7: ABC
    0b1111111,  // 8: all
    0b1101111,  // 9: ABCDFG
};

void Renderer::drawDigit(int digit, float x, float y, float s,
                          float r, float g, float b) {
    if (digit < 0 || digit > 9) return;
    uint8_t segs = SEG7[digit];
    float w = s * 4.f, h = s * 4.f;   // half height

    // Segment endpoints
    struct Seg { float x0,y0,x1,y1; };
    Seg S[7] = {
        {x+s,   y,     x+w-s, y    },  // A top
        {x+w,   y+s,   x+w,   y+h-s},  // B top-right
        {x+w,   y+h+s, x+w,   y+2*h-s},// C bot-right
        {x+s,   y+2*h, x+w-s, y+2*h},  // D bottom
        {x,     y+h+s, x,     y+2*h-s},// E bot-left
        {x,     y+s,   x,     y+h-s},  // F top-left
        {x+s,   y+h,   x+w-s, y+h  },  // G middle
    };
    for (int i = 0; i < 7; i++) {
        if (segs & (1 << i)) {
            float pts[4] = {S[i].x0, S[i].y0, S[i].x1, S[i].y1};
            submitAndDraw(pts, 2, GL_LINES, r, g, b, 1.f);
        }
    }
}

void Renderer::drawNumber(int num, float x, float y, float scale,
                           float r, float g, float b) {
    if (num < 0) num = 0;
    char buf[8]; snprintf(buf, 8, "%d", num);
    float charW = scale * 6.f;
    for (int i = 0; buf[i]; i++) {
        drawDigit(buf[i] - '0', x + i * charW, y, scale, r, g, b);
    }
}

// ── Static ortho matrix ───────────────────────────────────────────────────────
static void buildOrtho(float l, float r, float b, float t, float* m) {
    memset(m, 0, 64);
    m[0]=2/(r-l); m[5]=2/(t-b); m[10]=-1;
    m[12]=-(r+l)/(r-l); m[13]=-(t+b)/(t-b); m[15]=1;
}

// ── Main HUD ──────────────────────────────────────────────────────────────────
void Renderer::renderHUD(
    float sw, float sh,
    float joyBaseX, float joyBaseY,
    float joyThumbX, float joyThumbY,
    bool  joyActive,
    float breakProgress,
    int   fps,
    int   renderDist,
    bool  settingsOpen,
    int   hotbarSel,
    const uint8_t* hotbarTypes)
{
    glDisable(GL_DEPTH_TEST);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    glUseProgram(hudProg);
    float ortho[16];
    buildOrtho(0, sw, sh, 0, ortho);   // top-left origin
    glUniformMatrix4fv(hudOrthoLoc, 1, GL_FALSE, ortho);
    glLineWidth(3.f);

    // ── Crosshair ─────────────────────────────────────────────────────────────
    float cx = sw * 0.5f, cy = sh * 0.5f, cs = 22.f;
    drawLine(cx-cs, cy,  cx+cs, cy,  1,1,1);
    drawLine(cx,  cy-cs, cx,  cy+cs, 1,1,1);

    // ── Break progress arc (around crosshair) ─────────────────────────────────
    if (breakProgress > 0.f) {
        float endAng = -1.5707f + breakProgress * 6.2831853f;
        drawArc(cx, cy, cs + 12.f, -1.5707f, endAng, 1.f, 0.3f, 0.1f);
    }

    // ── Joystick (always visible) ─────────────────────────────────────────────
    float jAlpha = joyActive ? 0.65f : 0.28f;
    // Base ring
    drawCircle(joyBaseX, joyBaseY, Input::JOY_RADIUS, 1,1,1, jAlpha, false);
    // Inner ring guide
    drawCircle(joyBaseX, joyBaseY, Input::JOY_RADIUS * 0.35f, 1,1,1, jAlpha*0.5f, false);
    // Thumb
    float tAlpha = joyActive ? 0.80f : 0.35f;
    drawCircle(joyThumbX, joyThumbY, 34.f, 0.85f, 0.85f, 0.90f, tAlpha, true);
    drawCircle(joyThumbX, joyThumbY, 34.f, 1.f,   1.f,   1.f,   tAlpha, false);

    // ── Action buttons (right side) ───────────────────────────────────────────
    // Buttons moved inward from screen edges to avoid Android gesture zones
    float jBx=sw*0.82f, jBy=sh*0.65f;   // JUMP  - top
    float pBx=sw*0.72f, pBy=sh*0.77f;   // PLACE - bottom-left
    float bBx=sw*0.89f, bBy=sh*0.77f;   // BREAK - bottom-right (was 0.94 = too close to edge)
    float bR=54.f;

    // JUMP (green)
    drawCircle(jBx, jBy, bR, 0.10f,0.65f,0.10f, 0.65f, true);
    drawCircle(jBx, jBy, bR, 0.30f,1.00f,0.30f, 0.90f, false);
    // ^ arrow
    glLineWidth(4.f);
    drawLine(jBx-14,jBy+10, jBx,   jBy-10, 1,1,1);
    drawLine(jBx,   jBy-10, jBx+14,jBy+10, 1,1,1);
    // "JUMP" label below
    glLineWidth(2.f);
    drawLine(jBx-22,jBy+bR+12, jBx+22,jBy+bR+12, 0.4f,1.f,0.4f, 0.8f);

    // PLACE (orange) — "+" = place block
    drawCircle(pBx, pBy, bR, 0.70f,0.35f,0.05f, 0.65f, true);
    drawCircle(pBx, pBy, bR, 1.00f,0.65f,0.20f, 0.90f, false);
    glLineWidth(4.f);
    drawLine(pBx-16,pBy, pBx+16,pBy, 1,1,1);
    drawLine(pBx,pBy-16, pBx,pBy+16, 1,1,1);
    glLineWidth(2.f);
    drawLine(pBx-26,pBy+bR+12, pBx+26,pBy+bR+12, 1.f,0.65f,0.2f, 0.8f);

    // BREAK (red) — "x" = break/destroy block (HOLD to break)
    drawCircle(bBx, bBy, bR, 0.65f,0.05f,0.05f, 0.65f, true);
    drawCircle(bBx, bBy, bR, 1.00f,0.25f,0.25f, 0.90f, false);
    glLineWidth(4.f);
    drawLine(bBx-14,bBy-14, bBx+14,bBy+14, 1,1,1);
    drawLine(bBx+14,bBy-14, bBx-14,bBy+14, 1,1,1);
    glLineWidth(2.f);
    drawLine(bBx-28,bBy+bR+12, bBx+28,bBy+bR+12, 1.f,0.3f,0.3f, 0.8f);

    glLineWidth(2.f);

    // ── FPS counter (top-left) ────────────────────────────────────────────────
    float fpsColor[3] = {0.2f, 1.0f, 0.2f};
    if (fps < 45) { fpsColor[0]=1.f; fpsColor[1]=0.8f; fpsColor[2]=0.1f; }
    if (fps < 25) { fpsColor[0]=1.f; fpsColor[1]=0.2f; fpsColor[2]=0.1f; }

    // Semi-transparent background
    drawRect(8, 8, 130, 38, 0, 0, 0, 0.45f);
    // "FPS" label
    glLineWidth(2.f);
    // Draw "FPS:" as simple tick marks then the number
    drawNumber(fps, 16, 14, 3.f, fpsColor[0], fpsColor[1], fpsColor[2]);


    // ── Hotbar (bottom centre) ────────────────────────────────────────────────
    if (hotbarTypes) {
        const float slotW=54.f, slotH=54.f, gap=6.f;
        float totalW = 9*slotW + 8*gap;
        float startX = (sw - totalW) * 0.5f;
        float slotY  = sh - slotH - 14.f;

        // Block colours (matches BlockDefs order)
        float cols[14][3]={
            {0,0,0},               // AIR
            {0.30f,0.68f,0.18f},   // GRASS
            {0.56f,0.36f,0.15f},   // DIRT
            {0.50f,0.50f,0.50f},   // STONE
            {0.85f,0.80f,0.50f},   // SAND
            {0.46f,0.44f,0.43f},   // GRAVEL
            {0.36f,0.22f,0.10f},   // LOG
            {0.15f,0.45f,0.10f},   // LEAVES
            {0.96f,0.96f,1.00f},   // SNOW
            {0.03f,0.18f,0.62f},   // WATER
            {0.90f,0.30f,0.05f},   // LAVA
            {0.28f,0.28f,0.28f},   // COAL
            {0.62f,0.55f,0.48f},   // IRON
            {0.90f,0.80f,0.40f},   // GLOWSTONE
        };
        for (int i = 0; i < 9; i++) {
            float sx = startX + i*(slotW+gap);
            bool sel = (i == hotbarSel);
            // Slot background
            drawRect(sx, slotY, slotW, slotH,
                     sel?0.20f:0.10f, sel?0.20f:0.10f, sel?0.25f:0.12f,
                     sel?0.90f:0.65f);
            // Colour swatch
            int t = (int)hotbarTypes[i];
            if (t >= 0 && t < 14) {
                drawRect(sx+5, slotY+5, slotW-10, slotH-10,
                         cols[t][0], cols[t][1], cols[t][2], 1.f);
            }
            // Selection border
            if (sel) {
                glLineWidth(3.f);
                float bx=sx,by=slotY;
                drawLine(bx,by,bx+slotW,by, 1,1,1);
                drawLine(bx+slotW,by,bx+slotW,by+slotH, 1,1,1);
                drawLine(bx+slotW,by+slotH,bx,by+slotH, 1,1,1);
                drawLine(bx,by+slotH,bx,by, 1,1,1);
            }
        }
        glLineWidth(2.f);
    }

    // ── Settings gear button (top-right corner, always visible) ────────────────
    float gx = sw - 40.f, gy = 40.f;
    drawRect(gx-30, gy-30, 60, 60, 0,0,0, 0.5f);
    // Gear outline = two concentric circles + 8 teeth lines
    glLineWidth(3.f);
    drawCircle(gx, gy, 18.f, 0.9f,0.9f,0.9f, 1.f, false);
    drawCircle(gx, gy,  8.f, 0.9f,0.9f,0.9f, 1.f, false);
    for (int ti=0;ti<8;ti++){
        float a=3.14159f*ti/4.f;
        drawLine(gx+cosf(a)*18,gy+sinf(a)*18,
                 gx+cosf(a)*25,gy+sinf(a)*25, 0.9f,0.9f,0.9f);
    }

    // ── Settings panel (shown when open) ─────────────────────────────────────
    if (settingsOpen) {
        // Dim screen
        drawRect(0,0,sw,sh, 0,0,0, 0.60f);

        // Panel: 500 x 220, centred
        float pw=680.f, ph=220.f;
        float ppx=(sw-pw)*0.5f, ppy=(sh-ph)*0.5f;
        drawRect(ppx,ppy,pw,ph, 0.07f,0.07f,0.12f, 0.97f);
        drawRect(ppx,ppy,pw,5.f, 0.35f,0.55f,1.f, 1.f);

        // Title: "RENDER DIST" as thick line
        glLineWidth(2.f);
        drawLine(ppx+20,ppy+22, ppx+pw-20,ppy+22, 0.5f,0.6f,0.9f,0.8f);

        // 5 preset tiles: [4] [8] [12] [16] [24]
        // Tile centres evenly spaced; highlight selected one
        const int PRESETS[8] = {2, 4, 6, 8, 12, 16, 24, 32};
        const int PRESET_COUNT = 8;
        float tileW=66.f, tileH=86.f, tileY=ppy+ph*0.58f;
        float totalW=PRESET_COUNT*tileW+(PRESET_COUNT-1)*8.f;
        float startX=ppx+(pw-totalW)*0.5f;
        for (int i=0;i<PRESET_COUNT;i++) {
            float tx=startX+i*(tileW+8.f);
            bool sel=(PRESETS[i]==renderDist);
            // Tile background
            drawRect(tx,tileY-tileH*0.5f,tileW,tileH,
                sel?0.15f:0.10f, sel?0.30f:0.12f, sel?0.55f:0.18f, 0.95f);
            // Highlight border for selected
            if (sel) {
                glLineWidth(3.f);
                float bx=tx, by=tileY-tileH*.5f;
                drawLine(bx,by,bx+tileW,by, 0.4f,0.7f,1.f,1.f);
                drawLine(bx+tileW,by,bx+tileW,by+tileH, 0.4f,0.7f,1.f,1.f);
                drawLine(bx+tileW,by+tileH,bx,by+tileH, 0.4f,0.7f,1.f,1.f);
                drawLine(bx,by+tileH,bx,by, 0.4f,0.7f,1.f,1.f);
            }
            // Number centred in tile
            glLineWidth(sel?3.f:2.f);
            float nw=(PRESETS[i]>=10)?36.f:18.f;
            drawNumber(PRESETS[i], tx+tileW*0.5f-nw*0.5f, tileY-22.f, 4.f,
                sel?1.f:0.7f, sel?1.f:0.7f, sel?1.f:0.7f);
        }

        // ── "COPY DEBUG LOG" button (bottom-right of panel) ─────────────
        float dbgBx = ppx+pw-90, dbgBy = ppy+ph-36, dbgBw = 80, dbgBh = 26;
        drawRect(dbgBx, dbgBy, dbgBw, dbgBh, 0.12f,0.12f,0.20f, 0.90f);
        // Mini label: just a simple horizontal bar + "DBG" hint
        glLineWidth(1.5f);
        drawLine(dbgBx+6, dbgBy+13, dbgBx+dbgBw-6, dbgBy+13, 0.5f,0.8f,0.5f, 0.9f);
        drawLine(dbgBx+6, dbgBy+8,  dbgBx+dbgBw-6, dbgBy+8,  0.5f,0.8f,0.5f, 0.6f);
        drawLine(dbgBx+6, dbgBy+18, dbgBx+dbgBw-6, dbgBy+18, 0.5f,0.8f,0.5f, 0.6f);
        // Footer separator
        glLineWidth(1.f);
        drawLine(ppx+30, ppy+ph-44, dbgBx-8, ppy+ph-44, 0.35f,0.35f,0.35f, 0.5f);
    }

    glLineWidth(1.f);
    glDisable(GL_BLEND);
    glEnable(GL_DEPTH_TEST);
}

void Renderer::renderLoading(float sw, float sh, int frame) {
    // Draw spinning dots so user knows it's alive
    glDisable(GL_DEPTH_TEST);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glUseProgram(hudProg);
    float ortho[16];
    buildOrtho(0, sw, sh, 0, ortho);
    glUniformMatrix4fv(hudOrthoLoc, 1, GL_FALSE, ortho);

    float cx = sw * 0.5f, cy = sh * 0.5f;
    const int N = 8;
    for (int i = 0; i < N; i++) {
        float angle = 6.2831853f * i / N;
        float dx = cosf(angle) * 60.f;
        float dy = sinf(angle) * 60.f;
        // Dot lights up based on spinning frame
        float bright = (i == (frame/4) % N) ? 1.f : 0.3f;
        drawCircle(cx+dx, cy+dy, 10.f, bright,bright,bright, bright, true);
    }
    // Small "LOADING" indicator dots below spinner
    for (int i = 0; i < 3; i++) {
        float bright = ((frame/8) % 3 == i) ? 1.f : 0.25f;
        drawCircle(cx + (i-1)*30.f, cy + 100.f, 8.f, 1,1,1, bright, true);
    }
    glDisable(GL_BLEND);
    glEnable(GL_DEPTH_TEST);
}
