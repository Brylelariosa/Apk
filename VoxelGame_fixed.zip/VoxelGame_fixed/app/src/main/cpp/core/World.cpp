#include "World.h"
#include "BlockDefs.h"
#include <cmath>
#include <algorithm>
#include <condition_variable>
#include <android/log.h>

#define LOG_TAG "VoxelWorld"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

World::World(uint32_t s) : noise(s), seed(s) {
    workerRunning = true;
    for (int i = 0; i < NUM_WORKERS; i++)
        workers.emplace_back(&World::workerMain, this);
}

World::~World() {
    {
        std::lock_guard<std::mutex> lk(reqMutex);
        workerRunning = false;
    }
    reqCV.notify_all();          // wake ALL workers so they can exit cleanly
    for (auto& t : workers) if (t.joinable()) t.join();
}

// ── Block access (GL thread) ──────────────────────────────────────────────────
uint8_t World::getBlock(int x, int y, int z) const {
    if (y < 0 || y >= CH) return 0;
    int cx = (x < 0) ? ((x+1)/CW)-1 : x/CW;
    int cz = (z < 0) ? ((z+1)/CD)-1 : z/CD;
    auto it = chunks.find({cx,cz});
    if (it == chunks.end()) return 0;
    return it->second->getBlock(x - cx*CW, y, z - cz*CD);
}

bool World::blockSolidForCollision(int x, int y, int z) const {
    if (y < 0)    return true;   // below world = solid floor
    if (y >= CH)  return false;  // above world = air
    int cx = (x < 0) ? ((x+1)/CW)-1 : x/CW;
    int cz = (z < 0) ? ((z+1)/CD)-1 : z/CD;
    auto it = chunks.find({cx,cz});
    if (it == chunks.end()) {
        // Unloaded chunk: treat entire column as solid so player never falls through.
        // This is safe — the player can't be above real terrain, so solid=true
        // just keeps them standing until the chunk finishes loading.
        return true;
    }
    return blockSolid(it->second->getBlock(x - cx*CW, y, z - cz*CD));
}

void World::setBlock(int x, int y, int z, uint8_t type) {
    if (y < 0 || y >= CH) return;
    int cx = (x<0)?((x+1)/CW)-1:x/CW;
    int cz = (z<0)?((z+1)/CD)-1:z/CD;
    auto it = chunks.find({cx,cz});
    if (it == chunks.end()) return;
    it->second->setBlock(x-cx*CW, y, z-cz*CD, type);
    // Mark chunk dirty and track it for remeshing
    int lx = x-cx*CW, lz = z-cz*CD;
    auto markAndTrack = [&](int ncx, int ncz) {
        ChunkKey dk{ncx, ncz};
        auto n = chunks.find(dk);
        if (n == chunks.end()) return;
        n->second->markDirty();
        // Add to list if not already present (avoid O(n²) with small list)
        bool found = false;
        for (auto& k : dirtyChunks) if (k.x==ncx&&k.z==ncz){found=true;break;}
        if (!found) dirtyChunks.push_back(dk);
    };
    markAndTrack(cx, cz);
    if (lx == 0)    markAndTrack(cx-1, cz);
    if (lx == CW-1) markAndTrack(cx+1, cz);
    if (lz == 0)    markAndTrack(cx,   cz-1);
    if (lz == CD-1) markAndTrack(cx,   cz+1);
}

Chunk* World::getChunk(int cx, int cz) const {
    auto it = chunks.find({cx,cz});
    return it != chunks.end() ? it->second.get() : nullptr;
}

// ── Worker thread — condition-variable driven, no busy-polling ────────────────
void World::workerMain() {
    while (true) {
        ChunkKey key{0, 0};
        {
            std::unique_lock<std::mutex> lk(reqMutex);
            // Sleep until there's work or shutdown
            reqCV.wait(lk, [this]{ return !requested.empty() || !workerRunning; });
            if (!workerRunning && requested.empty()) break;
            if (requested.empty()) continue;
            key = requested.back();
            requested.pop_back();
            inFlight.push_back(key);
        }
        try {
            generateAndMesh(key.x, key.z);
        } catch (const std::exception& e) {
            LOGE("Worker exception: %s", e.what());
        } catch (...) {
            LOGE("Worker unknown exception");
        }
        {
            std::lock_guard<std::mutex> lk(reqMutex);
            inFlight.erase(
                std::remove_if(inFlight.begin(), inFlight.end(),
                    [&](const ChunkKey& k){ return k.x==key.x && k.z==key.z; }),
                inFlight.end());
        }
        // Notify all so other workers can pick up the next item
        reqCV.notify_all();
    }  // while(true)
}

uint8_t World::workerGetBlock(int x, int y, int z,
    const std::unordered_map<ChunkKey,std::unique_ptr<Chunk>,ChunkHash>& local) const
{
    if (y < 0 || y >= CH) return 0;
    int cx = (x<0)?((x+1)/CW)-1:x/CW;
    int cz = (z<0)?((z+1)/CD)-1:z/CD;
    auto it = local.find({cx,cz});
    if (it == local.end()) return 0;
    return it->second->getBlock(x-cx*CW, y, z-cz*CD);
}

void World::generateAndMesh(int cx, int cz) {
    // Generate centre + 4 cardinal neighbours for correct boundary face culling.
    // Diagonal neighbours are never queried by the greedy mesher.
    std::unordered_map<ChunkKey,std::unique_ptr<Chunk>,ChunkHash> local;
    for (auto [dx,dz] : std::initializer_list<std::pair<int,int>>{
            {0,0},{-1,0},{1,0},{0,-1},{0,1}}) {
        auto c = std::make_unique<Chunk>(cx+dx, cz+dz);
        generateChunk(c.get());
        local[{cx+dx, cz+dz}] = std::move(c);
    }
    auto worldGet = [&](int x, int y, int z) -> uint8_t {
        return workerGetBlock(x, y, z, local);
    };
    local[{cx,cz}]->buildMesh(worldGet);

    std::lock_guard<std::mutex> lk(resMutex);
    results.push_back({cx, cz, std::move(local[{cx,cz}])});
}

void World::generateChunk(Chunk* c) {
    const int wx0 = c->getChunkX() * CW;
    const int wz0 = c->getChunkZ() * CD;
    float tempBase = noise.noise2D(wx0/300.f+500.f, wz0/300.f)*0.5f+0.5f;

    for (int lx = 0; lx < CW; lx++) {
        for (int lz = 0; lz < CD; lz++) {
            float wx = (float)(wx0+lx), wz = (float)(wz0+lz);
            float h  = noise.fbm(wx/120.f, wz/120.f, 5);
            float h2 = noise.fbm(wx/40.f+7.f, wz/40.f+3.f, 3)*0.3f;
            int   height = 60 + (int)((h+h2)*28.f);
            height = std::max(2, std::min(CH-2, height));

            float temp = tempBase + noise.noise2D(wx/80.f, wz/80.f)*0.15f;

            uint8_t surface = BLOCK_GRASS, sub = BLOCK_DIRT;
            if      (height <= 61)  { surface=BLOCK_SAND; sub=BLOCK_SAND; }
            else if (temp  > 0.65f) { surface=BLOCK_SAND; sub=BLOCK_SAND; }
            else if (temp  < 0.35f) { surface=BLOCK_SNOW; }
            else if (height > 90)   { surface=BLOCK_SNOW; }

            for (int y = 0; y <= height; y++) {
                uint8_t type;
                if      (y == height)    type = surface;
                else if (y >= height-3)  type = sub;
                else                     type = BLOCK_STONE;

                if (type == BLOCK_STONE) {
                    float ore = noise.noise3D(wx/8.f, (float)y/8.f, wz/8.f);
                    // Check rarest first so higher thresholds take priority
                    if      (ore > 0.48f && y < 20) type = BLOCK_GLOWSTONE;
                    else if (ore > 0.47f && y < 50) type = BLOCK_IRON;
                    else if (ore > 0.45f && y < 30) type = BLOCK_COAL;
                }
                c->setBlock(lx, y, lz, type);
            }
            // No auto-water fill: water placed manually causes a solid
            // blue horizontal stripe visible across the entire world at Y=60.
            // Low-lying areas are dry shores/riverbeds — water is in hotbar.

            // Trees — only in safe inner zone to avoid boundary writes
            if (surface == BLOCK_GRASS && lx>=3 && lx<=CW-4 && lz>=3 && lz<=CD-4) {
                uint32_t rng = (uint32_t)(wx0+lx)*73856093u ^ (uint32_t)(wz0+lz)*19349663u ^ seed;
                rng = rng*1664525u + 1013904223u;
                if ((rng % 60) == 0) placeTree(c, lx, height+1, lz, wx, wz);
            }
        }
    }
    c->markDirty();
}

void World::placeTree(Chunk* c, int lx, int y, int lz, float wx, float wz) {
    // Use world coords for trunk height so height varies across the world
    int trunkH = 4 + (int)((noise.noise2D(wx*0.07f, wz*0.07f)+1.f)*1.5f);
    trunkH = std::max(3, std::min(7, trunkH));
    for (int i = 0; i < trunkH; i++)
        c->setBlock(lx, y+i, lz, BLOCK_LOG);
    for (int dy = trunkH-2; dy <= trunkH+1; dy++) {
        int r = (dy < trunkH) ? 2 : 1;
        for (int dx = -r; dx <= r; dx++)
            for (int dz = -r; dz <= r; dz++) {
                if (abs(dx)+abs(dz) > r+1) continue;
                int bx = lx+dx, bz = lz+dz;
                if (bx>=0 && bx<CW && bz>=0 && bz<CD)
                    if (c->getBlock(bx, y+dy, bz) == BLOCK_AIR)
                        c->setBlock(bx, y+dy, bz, BLOCK_LEAVES);
            }
    }
}

// ── GL thread update ──────────────────────────────────────────────────────────
void World::update(float px, float pz, int renderDist) {
    int pcx = (int)floorf(px/CW);
    int pcz = (int)floorf(pz/CD);

    // ── Pull finished chunks from worker and upload (max 8 per frame) ─────────
    {
        std::lock_guard<std::mutex> lk(resMutex);
        int done = 0;
        while (!results.empty() && done < 8) {
            auto& r = results.back();
            r.chunk->uploadMesh();
            pendingSet.erase({r.cx, r.cz});    // GL-thread safe: pendingSet is GL-only
            chunks[{r.cx, r.cz}] = std::move(r.chunk);
            results.pop_back();
            done++;
        }
    }

    // ── Rebuild dirty chunks (placed/broken blocks) — max 1 per frame ─────────
    for (auto it = dirtyChunks.begin(); it != dirtyChunks.end(); ) {
        auto cit = chunks.find(*it);
        if (cit == chunks.end() || !cit->second->isDirty()) {
            it = dirtyChunks.erase(it);
            continue;
        }
        auto worldGet = [this](int x, int y, int z)->uint8_t{ return getBlock(x,y,z); };
        try {
            cit->second->buildMesh(worldGet);
            cit->second->uploadMesh();
        } catch (...) { LOGE("buildMesh exception on dirty chunk"); }
        it = dirtyChunks.erase(it);
        break;
    }

    // ── Unload far chunks ──────────────────────────────────────────────────────
    const int maxDist = renderDist + 4;
    for (auto it = chunks.begin(); it != chunks.end(); ) {
        int dx = it->first.x-pcx, dz = it->first.z-pcz;
        if (dx*dx+dz*dz > maxDist*maxDist) {
            ChunkKey k = it->first;
            dirtyChunks.erase(
                std::remove_if(dirtyChunks.begin(), dirtyChunks.end(),
                    [&k](const ChunkKey& dk){ return dk.x==k.x && dk.z==k.z; }),
                dirtyChunks.end());
            pendingSet.erase(k);   // allow re-queue if player returns
            it = chunks.erase(it);
        } else ++it;
    }

    // ── Queue missing chunks nearest-first ────────────────────────────────────
    // Uses pendingSet (GL-thread-only hash set) for O(1) "already queued?" check.
    // Only re-scans the grid when player crosses a chunk boundary or renderDist changes.
    bool didQueue = false;
    {
        std::lock_guard<std::mutex> lk(reqMutex);

        // Purge stale requests (player moved away while they were waiting)
        {
            std::vector<ChunkKey> kept;
            kept.reserve(requested.size());
            for (auto& k : requested) {
                int dx = k.x-pcx, dz = k.z-pcz;
                if (dx*dx+dz*dz <= (renderDist+2)*(renderDist+2)) {
                    kept.push_back(k);
                } else {
                    pendingSet.erase(k);
                }
            }
            requested = std::move(kept);
        }

        // Queue all chunks in render circle that aren't loaded or pending
        const int rd2 = renderDist * renderDist;
        for (int r = 0; r <= renderDist; r++) {
            for (int dx = -r; dx <= r; dx++) {
                for (int dz = -r; dz <= r; dz++) {
                    if (abs(dx) != r && abs(dz) != r) continue;  // shell only
                    if (dx*dx+dz*dz > rd2) continue;
                    ChunkKey key{pcx+dx, pcz+dz};
                    if (chunks.find(key) != chunks.end()) continue;
                    if (pendingSet.count(key))           continue;
                    pendingSet.insert(key);
                    // Nearest chunks (r<=2) go to front so workers pick them first
                    if (r <= 2) requested.insert(requested.begin(), key);
                    else        requested.push_back(key);
                    didQueue = true;
                }
            }
        }
    }
    if (didQueue) reqCV.notify_all();
}

void World::renderAll(GLint mvpLoc, const float* vp) const {
    glUniformMatrix4fv(mvpLoc, 1, GL_FALSE, vp);

    // ── Frustum culling (Gribb-Hartmann) ─────────────────────────────────────
    // Matrix is column-major (OpenGL). Row i = vp[i], vp[4+i], vp[8+i], vp[12+i].
    // Left   = row3+row0,  Right  = row3-row0
    // Bottom = row3+row1,  Top    = row3-row1
    // Near   = row3+row2   (skip Far — render distance handles it)
    // Each plane (a,b,c,d): point P is inside if a*Px + b*Py + c*Pz + d >= 0.
    const float pl[5][4] = {
        {vp[3]+vp[0], vp[7]+vp[4], vp[11]+vp[8],  vp[15]+vp[12]},  // Left
        {vp[3]-vp[0], vp[7]-vp[4], vp[11]-vp[8],  vp[15]-vp[12]},  // Right
        {vp[3]+vp[1], vp[7]+vp[5], vp[11]+vp[9],  vp[15]+vp[13]},  // Bottom
        {vp[3]-vp[1], vp[7]-vp[5], vp[11]-vp[9],  vp[15]-vp[13]},  // Top
        {vp[3]+vp[2], vp[7]+vp[6], vp[11]+vp[10], vp[15]+vp[14]},  // Near
    };

    for (auto& [key, chunk] : chunks) {
        // Chunk AABB in world space
        float ax = (float)(key.x * CW),    bx = ax + (float)CW;
        float ay = 0.f,                     by = (float)CH;
        float az = (float)(key.z * CD),    bz = az + (float)CD;

        // For each plane, test the "positive vertex" (p-vertex).
        // If p-vertex is outside any plane, the whole AABB is outside → cull.
        bool cull = false;
        for (int p = 0; p < 5 && !cull; p++) {
            const float a = pl[p][0], b = pl[p][1], c = pl[p][2], d = pl[p][3];
            float px = (a >= 0.f) ? bx : ax;
            float py = (b >= 0.f) ? by : ay;
            float pz = (c >= 0.f) ? bz : az;
            if (a*px + b*py + c*pz + d < 0.f) cull = true;
        }
        if (!cull) chunk->render();
    }
}

// ── DDA Raycast ───────────────────────────────────────────────────────────────
bool World::raycast(Vec3 origin, Vec3 dir, float maxDist,
                    Vec3& hitPos, Vec3& hitNormal) const {
    dir = normalize(dir);
    int bx=(int)floorf(origin.x), by=(int)floorf(origin.y), bz=(int)floorf(origin.z);
    int sx=(dir.x>0)?1:-1, sy=(dir.y>0)?1:-1, sz=(dir.z>0)?1:-1;
    float ddx=(fabsf(dir.x)>1e-6f)?fabsf(1.f/dir.x):1e30f;
    float ddy=(fabsf(dir.y)>1e-6f)?fabsf(1.f/dir.y):1e30f;
    float ddz=(fabsf(dir.z)>1e-6f)?fabsf(1.f/dir.z):1e30f;
    auto frac=[](float v){return v-floorf(v);};
    float tx=(dir.x>0)?(1.f-frac(origin.x))*ddx:frac(origin.x)*ddx;
    float ty=(dir.y>0)?(1.f-frac(origin.y))*ddy:frac(origin.y)*ddy;
    float tz=(dir.z>0)?(1.f-frac(origin.z))*ddz:frac(origin.z)*ddz;
    Vec3 normal{};
    for (int i = 0; i < 200; i++) {
        uint8_t blk = getBlock(bx, by, bz);
        if (blk != BLOCK_AIR && blockSolid(blk)) { // only hit solid blocks
            hitPos    = {(float)bx, (float)by, (float)bz};
            hitNormal = normal;
            return true;
        }
        float tmin = std::min({tx,ty,tz});
        if (tmin > maxDist) break;
        if      (tx <= ty && tx <= tz) { tx+=ddx; bx+=sx; normal={-(float)sx,0,0}; }
        else if (ty <= tz)             { ty+=ddy; by+=sy; normal={0,-(float)sy,0}; }
        else                           { tz+=ddz; bz+=sz; normal={0,0,-(float)sz}; }
    }
    return false;
}
