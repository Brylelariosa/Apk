#include "Chunk.h"
#include "BlockDefs.h"
#include <cstring>
#include <cmath>
#include <android/log.h>

#define LOG_TAG "VoxelChunk"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

Chunk::Chunk(int cx, int cz) : chunkX(cx), chunkZ(cz) {
    memset(blocks, 0, sizeof(blocks));
}

Chunk::~Chunk() {
    if (vao) glDeleteVertexArrays(1, &vao);
    if (vbo) glDeleteBuffers(1, &vbo);
    if (ebo) glDeleteBuffers(1, &ebo);
}

uint8_t Chunk::getBlock(int x, int y, int z) const {
    if (x<0||x>=CW||y<0||y>=CH||z<0||z>=CD) return 0;
    return blocks[x][y][z];
}

void Chunk::setBlock(int x, int y, int z, uint8_t t) {
    if (x<0||x>=CW||y<0||y>=CH||z<0||z>=CD) return;
    blocks[x][y][z] = t;
    dirty = true; gpuReady = false;
}

// ── Greedy Meshing ────────────────────────────────────────────────────────────
// For each of 6 face directions, sweep slices perpendicular to that axis.
// Within each slice build a 2-D face-presence mask, then greedily merge
// adjacent same-type cells into the largest possible rectangle.
//
// Dimension mapping:
//   dim=0 (X faces): slice=X, u=Y, v=Z   sizes: CW / CH / CD
//   dim=1 (Y faces): slice=Y, u=X, v=Z   sizes: CH / CW / CD
//   dim=2 (Z faces): slice=Z, u=X, v=Y   sizes: CD / CW / CH

static const int SIZES[3]  = {CW, CH, CD};
static const int UDIM[3]   = {1,  0,  0};
static const int VDIM[3]   = {2,  2,  1};

// Convert (dim, slice, u, v) to local block coords (lx,ly,lz)
static inline void toLocal(int dim, int s, int u, int v,
                            int& lx, int& ly, int& lz) {
    switch(dim) {
        case 0: lx=s; ly=u; lz=v; break;
        case 1: lx=u; ly=s; lz=v; break;
        default:lx=u; ly=v; lz=s; break;
    }
}

// Convert (dim, slice, u, v) to neighbour coords with offset dir
static inline void toNeighbour(int dim, int s, int dir, int u, int v,
                                int& nx, int& ny, int& nz) {
    toLocal(dim, s+dir, u, v, nx, ny, nz);
}

void Chunk::buildMesh(const GetBlock& world) {
    vertData.clear();
    idxData.clear();
    dirty    = false;
    gpuReady = false;

    const int wx0 = chunkX * CW;
    const int wz0 = chunkZ * CD;

    // Temporary mask (max possible slice = max(CW,CH,CD)^2 = 128*16 = 2048)
    uint8_t mask[CH * CD];

    for (int dim = 0; dim < 3; dim++) {
        const int sSize = SIZES[dim];
        const int uSize = SIZES[UDIM[dim]];
        const int vSize = SIZES[VDIM[dim]];

        for (int dir : {-1, 1}) {
            for (int slice = 0; slice < sSize; slice++) {

                // ── Build face mask ──────────────────────────────────────────
                for (int u = 0; u < uSize; u++) {
                    for (int v = 0; v < vSize; v++) {
                        int lx,ly,lz, nx,ny,nz;
                        toLocal(dim, slice, u, v, lx, ly, lz);
                        uint8_t here = blocks[lx][ly][lz];

                        // Neighbour is in same chunk or across boundary?
                        toNeighbour(dim, slice, dir, u, v, nx, ny, nz);
                        uint8_t nb;
                        if (nx>=0&&nx<CW&&ny>=0&&ny<CH&&nz>=0&&nz<CD)
                            nb = blocks[nx][ny][nz];
                        else
                            nb = world(wx0+nx, ny, wz0+nz);

                        // Face visible: current block opaque, neighbour transparent.
                        // SEAM DEDUP: when dir==-1 and slice==0, this face lies exactly
                        // on the chunk boundary shared with the adjacent chunk.
                        // The adjacent chunk generates the SAME plane (dir==+1, slice==last).
                        // Skip this duplicate to eliminate z-fighting blue lines.
                        // Exception: if neighbour is air/unloaded (nb==0), we must draw it.
                        bool isSharedBoundary = (dir == -1 && slice == 0);
                        bool nbOwns = isSharedBoundary && (nb != 0);
                        mask[u*vSize+v] =
                            (blockOpaque(here) && !blockOpaque(nb) && !nbOwns) ? here : 0;
                    }
                }

                // ── Greedy sweep ─────────────────────────────────────────────
                bool done[CH*CD];
                memset(done, 0, (size_t)(uSize*vSize)*sizeof(bool));

                const int faceSlice = (dir==1) ? slice+1 : slice;

                for (int u = 0; u < uSize; u++) {
                    for (int v = 0; v < vSize; ) {
                        uint8_t type = mask[u*vSize+v];
                        if (!type || done[u*vSize+v]) { v++; continue; }

                        // Expand in v direction (width wv)
                        int wv = 1;
                        while (v+wv < vSize &&
                               mask[u*vSize+v+wv]==type &&
                               !done[u*vSize+v+wv]) wv++;

                        // Expand in u direction (height wu)
                        int wu = 1;
                        bool stop = false;
                        while (u+wu < uSize && !stop) {
                            for (int k=v; k<v+wv; k++) {
                                if (mask[(u+wu)*vSize+k]!=type || done[(u+wu)*vSize+k])
                                { stop=true; break; }
                            }
                            if (!stop) wu++;
                        }

                        // Mark done
                        for (int pu=u; pu<u+wu; pu++)
                            for (int pv=v; pv<v+wv; pv++)
                                done[pu*vSize+pv] = true;

                        addQuad(dim, dir, faceSlice, u, v, wu, wv, type);
                        v += wv;
                    }
                }
            }
        }
    }
}

void Chunk::addQuad(int dim, int dir,
                    int faceSlice, int u0, int v0, int wu, int wv,
                    uint8_t blockType) {
    const BlockInfo& bi = BLOCKS[blockType];
    const bool isTop    = (dim==1 && dir== 1);
    const bool isBot    = (dim==1 && dir==-1);

    float r = isTop ? bi.tr : bi.r;
    float g = isTop ? bi.tg : bi.g;
    float b = isTop ? bi.tb : bi.b;

    // Directional ambient shading (cheap but effective)
    float light = isTop  ? 1.00f :
                  isBot  ? 0.50f :
                  (dim==0)? 0.70f : 0.80f;

    if (bi.emissive) light = 1.0f;

    const int wx0 = chunkX * CW;
    const int wz0 = chunkZ * CD;

    // 4 corners:  (s, u0,      v0)
    //             (s, u0+wu,   v0)
    //             (s, u0+wu,   v0+wv)
    //             (s, u0,      v0+wv)
    struct C { int u, v; };
    C corners[4] = {{u0,v0},{u0+wu,v0},{u0+wu,v0+wv},{u0,v0+wv}};

    const uint32_t base = (uint32_t)(vertData.size() / 7);

    for (auto& c : corners) {
        float fx, fy, fz;
        switch(dim) {
            case 0: fx=(float)faceSlice; fy=(float)c.u; fz=(float)c.v; break;
            case 1: fx=(float)c.u;       fy=(float)faceSlice; fz=(float)c.v; break;
            default:fx=(float)c.u;       fy=(float)c.v; fz=(float)faceSlice; break;
        }
        fx += (float)wx0;
        fz += (float)wz0;
        vertData.push_back(fx);
        vertData.push_back(fy);
        vertData.push_back(fz);
        vertData.push_back(r);
        vertData.push_back(g);
        vertData.push_back(b);
        vertData.push_back(light);
    }

    // Y-axis (dim==1) quads have opposite vertex-winding to X/Z quads
    // because the U/V axes lie in the XZ plane (not XY or YZ).
    // Verified by cross-product: for dim==1 we must flip CCW/CW sense.
    bool normalWinding = (dir == 1) ^ (dim == 1);
    if (normalWinding) {
        idxData.push_back(base+0); idxData.push_back(base+1); idxData.push_back(base+2);
        idxData.push_back(base+0); idxData.push_back(base+2); idxData.push_back(base+3);
    } else {
        idxData.push_back(base+0); idxData.push_back(base+2); idxData.push_back(base+1);
        idxData.push_back(base+0); idxData.push_back(base+3); idxData.push_back(base+2);
    }
}

// ── GPU Upload ────────────────────────────────────────────────────────────────
void Chunk::uploadMesh() {
    if (vertData.empty()) { indexCount=0; gpuReady=true; return; }

    if (!vao) {
        glGenVertexArrays(1, &vao);
        glGenBuffers(1, &vbo);
        glGenBuffers(1, &ebo);
    }

    glBindVertexArray(vao);

    glBindBuffer(GL_ARRAY_BUFFER, vbo);
    glBufferData(GL_ARRAY_BUFFER,
                 (GLsizeiptr)(vertData.size()*sizeof(float)),
                 vertData.data(), GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ebo);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER,
                 (GLsizeiptr)(idxData.size()*sizeof(uint32_t)),
                 idxData.data(), GL_STATIC_DRAW);

    const GLsizei stride = 7 * sizeof(float);
    // aPos   @ location 0
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0,3,GL_FLOAT,GL_FALSE,stride,(void*)0);
    // aColor @ location 1
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1,3,GL_FLOAT,GL_FALSE,stride,(void*)(3*sizeof(float)));
    // aLight @ location 2
    glEnableVertexAttribArray(2);
    glVertexAttribPointer(2,1,GL_FLOAT,GL_FALSE,stride,(void*)(6*sizeof(float)));

    glBindVertexArray(0);

    indexCount = (int)idxData.size();
    gpuReady   = true;

    // Free CPU-side data
    vertData.clear(); vertData.shrink_to_fit();
    idxData.clear();  idxData.shrink_to_fit();
}

void Chunk::render() const {
    if (!gpuReady || indexCount == 0) return;
    glBindVertexArray(vao);
    glDrawElements(GL_TRIANGLES, indexCount, GL_UNSIGNED_INT, nullptr);
    glBindVertexArray(0);
}
