#include "Chunk.h"
#include "BlockDefs.h"
#include <cstring>
#include <cmath>
#include <android/log.h>

#define LOG_TAG "VoxelChunk"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

Chunk::Chunk(int cx, int cz) : chunkX(cx), chunkZ(cz) {
    memset(blocks, 0, sizeof(blocks));
}

Chunk::~Chunk() {
    if (vao) glDeleteVertexArrays(1, &vao);
    if (vbo) glDeleteBuffers(1, &vbo);
    if (ebo) glDeleteBuffers(1, &ebo);
}

uint8_t Chunk::getBlock(int x, int y, int z) const {
    if (x<0||x>=CW||y<0||y>=CH||z<0||z>=CD) return 0;
    return blocks[bidx(x,y,z)];
}

void Chunk::setBlock(int x, int y, int z, uint8_t t) {
    if (x<0||x>=CW||y<0||y>=CH||z<0||z>=CD) return;
    blocks[bidx(x,y,z)] = t;
    // Update spans incrementally.
    // For colMaxY: if placing above current top, update directly.
    // If removing the top block, rescan the column (rare — only on break).
    uint8_t& top = colMaxY[x * CD + z];
    if (t != 0) {
        if (y > top) top = (uint8_t)y;
        yOccupied[y >> 6] |= (1ULL << (y & 63));
    } else {
        // Block removed — rescan this column and this Y slice
        uint8_t newTop = 0;
        for (int sy = 0; sy < CH; sy++)
            if (blocks[bidx(x,sy,z)] != 0 && sy > newTop) newTop = (uint8_t)sy;
        top = newTop;
        // Rescan the Y slice for occupancy
        bool anyInSlice = false;
        for (int sx = 0; sx < CW && !anyInSlice; sx++)
            for (int sz = 0; sz < CD && !anyInSlice; sz++)
                if (blocks[bidx(sx,y,sz)] != 0) anyInSlice = true;
        if (anyInSlice)
            yOccupied[y >> 6] |= (1ULL << (y & 63));
        else
            yOccupied[y >> 6] &= ~(1ULL << (y & 63));
    }
    dirty = true; gpuReady = false;
}


void Chunk::uploadMesh() {
    if (vertData.empty()) { indexCount=0; gpuReady=true; return; }

    if (!vao) {
        glGenVertexArrays(1, &vao);
        glGenBuffers(1, &vbo);
        glGenBuffers(1, &ebo);
    }

    glBindVertexArray(vao);

    glBindBuffer(GL_ARRAY_BUFFER, vbo);
    glBufferData(GL_ARRAY_BUFFER,
                 (GLsizeiptr)(vertData.size() * sizeof(PackedVert)),
                 vertData.data(), GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ebo);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER,
                 (GLsizeiptr)(idxData.size() * sizeof(uint32_t)),
                 idxData.data(), GL_STATIC_DRAW);

    // PackedVert layout (10 bytes, stride=10):
    //   offset 0: int16 x,y,z  (3 × 2 bytes = 6 bytes)
    //   offset 6: uint8 r,g,b,light (4 × 1 byte = 4 bytes, GL_TRUE = normalized 0-1)
    const GLsizei stride = (GLsizei)sizeof(PackedVert);  // 10

    // aPos   @ location 0: 3 × GL_SHORT (integer attrib, cast to float in shader)
    glEnableVertexAttribArray(0);
    glVertexAttribIPointer(0, 3, GL_SHORT, stride, (void*)0);

    // aColorLight @ location 1: 4 × GL_UNSIGNED_BYTE normalized → 0.0-1.0
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 4, GL_UNSIGNED_BYTE, GL_TRUE, stride, (void*)6);

    glBindVertexArray(0);

    indexCount = (int)idxData.size();
    gpuReady   = true;

    // Clear CPU-side vectors but keep capacity — next rebuild reuses the allocation.
    // (shrink_to_fit was causing heap churn on every chunk upload)
    vertData.clear();
    idxData.clear();
}

void Chunk::render() const {
    if (!gpuReady || indexCount == 0) return;
    glBindVertexArray(vao);
    glDrawElements(GL_TRIANGLES, indexCount, GL_UNSIGNED_INT, nullptr);
    // No unbind here — caller does one glBindVertexArray(0) after all chunks.
    // Removing per-chunk unbind saves ~2400 GL calls/frame at renderDist=32.
}

void Chunk::addQuad(int dim, int dir,
                    int faceSlice, int u0, int v0, int wu, int wv,
                    uint8_t blockType) {
    const BlockInfo& bi = BLOCKS[blockType];
    const bool isTop    = (dim==1 && dir== 1);
    const bool isBot    = (dim==1 && dir==-1);

    float rf = isTop ? bi.tr : bi.r;
    float gf = isTop ? bi.tg : bi.g;
    float bf = isTop ? bi.tb : bi.b;

    float lightf = isTop  ? 1.00f :
                   isBot  ? 0.50f :
                   (dim==0)? 0.70f : 0.80f;
    if (bi.emissive) lightf = 1.0f;

    // Pack color and light as uint8 (GPU receives normalized float via GL_TRUE)
    const uint8_t r8 = (uint8_t)(rf     * 255.f + 0.5f);
    const uint8_t g8 = (uint8_t)(gf     * 255.f + 0.5f);
    const uint8_t b8 = (uint8_t)(bf     * 255.f + 0.5f);
    const uint8_t l8 = (uint8_t)(lightf * 255.f + 0.5f);

    const int wx0 = chunkX * CW;
    const int wz0 = chunkZ * CD;

    struct C { int u, v; };
    C corners[4] = {{u0,v0},{u0+wu,v0},{u0+wu,v0+wv},{u0,v0+wv}};

    const uint32_t base = (uint32_t)vertData.size();

    for (auto& c : corners) {
        int16_t px, py, pz;
        switch(dim) {
            case 0: px=(int16_t)(faceSlice+wx0); py=(int16_t)c.u; pz=(int16_t)(c.v+wz0); break;
            case 1: px=(int16_t)(c.u+wx0); py=(int16_t)faceSlice; pz=(int16_t)(c.v+wz0); break;
            default:px=(int16_t)(c.u+wx0); py=(int16_t)c.v;       pz=(int16_t)(faceSlice+wz0); break;
        }
        vertData.push_back({px, py, pz, r8, g8, b8, l8});
    }

    bool normalWinding = (dir == 1) ^ (dim == 1);
    if (normalWinding) {
        idxData.push_back(base+0); idxData.push_back(base+1); idxData.push_back(base+2);
        idxData.push_back(base+0); idxData.push_back(base+2); idxData.push_back(base+3);
    } else {
        idxData.push_back(base+0); idxData.push_back(base+2); idxData.push_back(base+1);
        idxData.push_back(base+0); idxData.push_back(base+3); idxData.push_back(base+2);
    }
}
