#pragma once
#include <cstdint>
#include <vector>
#include <functional>
#include <GLES3/gl3.h>

// Chunk dimensions
static constexpr int CW = 16;   // width  (X)
static constexpr int CH = 128;  // height (Y)
static constexpr int CD = 16;   // depth  (Z)

class Chunk {
public:
    Chunk(int cx, int cz);
    ~Chunk();

    uint8_t  getBlock(int x, int y, int z) const;
    void     setBlock(int x, int y, int z, uint8_t type);

    // Build CPU-side mesh — safe to call from any thread
    using GetBlock = std::function<uint8_t(int,int,int)>;
    void buildMesh(const GetBlock& world);

    // Upload built mesh to GPU — must be called from GL thread
    void uploadMesh();

    // Draw — caller must set MVP uniform before calling renderAll()
    void render() const;

    int  getChunkX() const { return chunkX; }
    int  getChunkZ() const { return chunkZ; }
    bool isDirty()   const { return dirty;    }
    bool hasGpu()    const { return gpuReady; }
    // true when CPU mesh data is present (built but not yet uploaded)
    bool hasCpuMesh() const { return !vertData.empty(); }
    void markDirty()        { dirty = true; gpuReady = false; }

private:
    uint8_t blocks[CW][CH][CD]{};
    int chunkX, chunkZ;

    std::vector<float>    vertData;
    std::vector<uint32_t> idxData;

    GLuint vao = 0, vbo = 0, ebo = 0;
    int    indexCount = 0;
    bool   dirty      = true;
    bool   gpuReady   = false;

    void addQuad(int dim, int dir, int faceSlice,
                 int u0, int v0, int wu, int wv,
                 uint8_t blockType);
};
