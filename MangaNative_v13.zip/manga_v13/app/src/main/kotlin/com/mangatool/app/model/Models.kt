package com.mangatool.app.model

import java.io.File

/**
 * A single manga image stored as a temp file on disk.
 *
 * Keeping raw ByteArrays in RAM causes severe GC pressure and OOM errors —
 * a 30-image chapter at 300 KB/image is 9 MB of heap just for source bytes,
 * on top of the thumbnail LruCache. Instead we write every image to a temp
 * file immediately on import and read it back only when decoding is needed.
 * BitmapFactory.decodeFile() streams from disk without allocating a ByteArray,
 * so the only heap objects are the decoded Bitmaps themselves (which the LRU
 * cache already manages).
 */
data class ImageItem(
    val originalIdx: Int,
    /** Absolute path to the temp file holding this image's raw bytes. */
    val filePath: String,
    val ext: String,
    /** File size in bytes — stored so stats work without re-reading. */
    val size: Int,
    var name: String = "",
    var userDeleted: Boolean = false,
    var forceKeep: Boolean = false,
    var filterReason: String? = null,
    val width: Int = 0,
    val height: Int = 0
) {
    /** Read raw bytes from disk. Use sparingly — decoding functions prefer filePath directly. */
    fun readBytes(): ByteArray = File(filePath).readBytes()

    // Reference identity: two ImageItems from different groups can share
    // the same originalIdx and must never be considered equal.
    override fun equals(other: Any?) = this === other
    override fun hashCode() = System.identityHashCode(this)
}

data class ImageGroup(
    val groupName: String,
    val allImages: MutableList<ImageItem> = mutableListOf(),
    var displayImages: List<ImageItem> = emptyList(),
    var filteredImages: List<ImageItem> = emptyList(),
    /** Pair indices (0-based) where the two images are swapped (right shown on left). */
    val pairSwaps: MutableSet<Int> = mutableSetOf()
)

data class ImageGroup(
    val groupName: String,
    val allImages: MutableList<ImageItem> = mutableListOf(),
    var displayImages: List<ImageItem> = emptyList(),
    var filteredImages: List<ImageItem> = emptyList(),
    /** Set of pair indices (0-based) where the two images are swapped (right shown on left) */
    val pairSwaps: MutableSet<Int> = mutableSetOf()
)
