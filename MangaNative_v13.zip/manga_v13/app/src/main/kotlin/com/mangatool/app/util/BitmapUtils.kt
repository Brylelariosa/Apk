package com.mangatool.app.util

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.util.concurrent.Executors
import kotlinx.coroutines.asCoroutineDispatcher

object BitmapUtils {

    /**
     * Limited-concurrency dispatcher for ALL bitmap operations.
     *
     * Dispatchers.IO allows 64 concurrent threads. With 300+ images all
     * decoding simultaneously that thrashes the CPU, spikes GC, and freezes
     * the UI thread. 3 threads pipelines decodes smoothly without overloading
     * the scheduler.
     */
    val decodeDispatcher = Executors.newFixedThreadPool(3).asCoroutineDispatcher()

    // ── Path-based API — always prefer this ──────────────────────────────────
    //
    // BitmapFactory.decodeFile() streams directly from the file descriptor —
    // it does NOT allocate a ByteArray for the whole file. Only the decoded
    // Bitmap pixels hit the heap. This is why the API moved from ByteArray to
    // file path: a 200 KB JPEG decoded at 300 px needs ~360 KB of Bitmap RAM,
    // not 200 KB raw + 360 KB decoded = 560 KB.

    /** Decode just pixel dimensions — no pixel data loaded. */
    fun decodeDimensions(filePath: String): Pair<Int, Int> {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(filePath, opts)
        return opts.outWidth to opts.outHeight
    }

    /**
     * Decode a thumbnail ≤ [maxPx] using RGB_565 (half the RAM of ARGB_8888).
     * Manga pages are JPEGs with no alpha — identical visual quality at 2×
     * the cache density.
     *
     * 1. inSampleSize coarse decode to ~2× target (avoids over-allocating)
     * 2. Bilinear createScaledBitmap for a smooth final size
     */
    fun decodeThumbnail(filePath: String, maxPx: Int = 256): Bitmap? {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(filePath, opts)
        if (opts.outWidth <= 0 || opts.outHeight <= 0) return null

        var sample = 1
        while (opts.outWidth / (sample * 2) >= maxPx && opts.outHeight / (sample * 2) >= maxPx)
            sample *= 2

        val rough = BitmapFactory.decodeFile(filePath, BitmapFactory.Options().apply {
            inSampleSize      = sample
            inPreferredConfig = Bitmap.Config.RGB_565
        }) ?: return null

        val largest = maxOf(rough.width, rough.height)
        if (largest <= maxPx) return rough

        val scale = maxPx.toFloat() / largest
        val w = (rough.width  * scale).toInt().coerceAtLeast(1)
        val h = (rough.height * scale).toInt().coerceAtLeast(1)
        val scaled = Bitmap.createScaledBitmap(rough, w, h, true)
        if (scaled !== rough) rough.recycle()
        return scaled
    }

    /** Decode at full resolution for preview or merge compositing. */
    fun decodeFull(filePath: String): Bitmap? = BitmapFactory.decodeFile(filePath)
}

    // ── Stream/ByteArray overloads — for Uri streams only ───────────────────
    // MergeImagePickerActivity reads from content:// URIs that can't be cached
    // as temp files (the user hasn't imported them yet). These overloads keep
    // the Uri-stream decoding path without polluting the main path.

    /** Decode thumbnail from an InputStream (for Uri streams). */
    fun decodeThumbnail(bytes: ByteArray, maxPx: Int = 256): Bitmap? {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
        if (opts.outWidth <= 0 || opts.outHeight <= 0) return null

        var sample = 1
        while (opts.outWidth / (sample * 2) >= maxPx && opts.outHeight / (sample * 2) >= maxPx)
            sample *= 2

        val rough = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply {
            inSampleSize      = sample
            inPreferredConfig = Bitmap.Config.RGB_565
        }) ?: return null

        val largest = maxOf(rough.width, rough.height)
        if (largest <= maxPx) return rough

        val scale = maxPx.toFloat() / largest
        val w = (rough.width  * scale).toInt().coerceAtLeast(1)
        val h = (rough.height * scale).toInt().coerceAtLeast(1)
        val scaled = Bitmap.createScaledBitmap(rough, w, h, true)
        if (scaled !== rough) rough.recycle()
        return scaled
    }
}
