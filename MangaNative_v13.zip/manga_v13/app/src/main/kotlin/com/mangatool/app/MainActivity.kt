package com.mangatool.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.snackbar.Snackbar
import com.mangatool.app.adapter.AppPickerAdapter
import com.mangatool.app.adapter.AppPickerItem
import com.mangatool.app.adapter.ChapterAdapter
import com.mangatool.app.databinding.ActivityMainBinding
import com.mangatool.app.databinding.BottomSheetAppPickerBinding
import com.mangatool.app.databinding.BottomSheetSavedBinding
import com.mangatool.app.model.ImageGroup
import com.mangatool.app.model.ImageItem
import com.mangatool.app.util.CbzCreator
import com.mangatool.app.util.FolderSaver
import com.mangatool.app.util.ImageSaver
import com.mangatool.app.util.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Collections

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private var chapterAdapter: ChapterAdapter? = null
    private var chapterTouchHelper: ItemTouchHelper? = null
    private var processingJob: Job? = null

    // ── Share pre-cache ────────────────────────────────────────────────────────
    private val shareCacheAll   = mutableMapOf<String, List<Uri>>()
    private val shareCacheGroup = mutableMapOf<String, List<Uri>>()
    private var preCacheJob: Job? = null

    // ── File open pickers ──────────────────────────────────────────────────────
    private val openDocLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { r -> if (r.resultCode == Activity.RESULT_OK) handlePickResult(r.data) }

    private val getContentLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { r -> if (r.resultCode == Activity.RESULT_OK) handlePickResult(r.data) }

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (!granted) Toast.makeText(this, getString(R.string.permission_storage_needed), Toast.LENGTH_LONG).show()
    }

    private val mergePickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            val uriStrings = r.data?.getStringArrayListExtra(MergeImagePickerActivity.RESULT_URIS)
            val folderName = r.data?.getStringExtra(MergeImagePickerActivity.RESULT_FOLDER_NAME) ?: ""
            val uris = uriStrings?.mapNotNull { runCatching { Uri.parse(it) }.getOrNull() } ?: emptyList()
            if (uris.isNotEmpty()) processFiles(uris, folderName)
        }
    }

    private val previewLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { r -> if (r.resultCode == Activity.RESULT_OK) { AppState.applyFilters(); refreshChapterList() } }

    // ── Folder pickers — Settings "Choose" button ──────────────────────────────
    private val settingsExtractFolderLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri -> uri?.let { persistAndRememberFolder(it, isMerge = false); updateSettingsFolderLabels() } }

    private val settingsMergeFolderLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri -> uri?.let { persistAndRememberFolder(it, isMerge = true); updateSettingsFolderLabels() } }

    // ── (Folder launchers for save-without-folder removed — now redirects to Settings) ──
    // ── Folder helpers ─────────────────────────────────────────────────────────
    private fun persistAndRememberFolder(uri: Uri, isMerge: Boolean) {
        runCatching {
            contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        }
        val name = runCatching {
            androidx.documentfile.provider.DocumentFile.fromTreeUri(this, uri)?.name
        }.getOrNull() ?: uri.lastPathSegment ?: "Selected folder"

        if (isMerge) {
            Prefs.mergeFolderUri  = uri.toString()
            Prefs.mergeFolderName = name
        } else {
            Prefs.extractFolderUri  = uri.toString()
            Prefs.extractFolderName = name
        }
    }

    /**
     * Returns the stored URI if it is still accessible (permission not revoked),
     * otherwise clears it from prefs and returns null so the user is asked to pick again.
     */
    private fun getValidFolderUri(isMerge: Boolean): Uri? {
        val stored = if (isMerge) Prefs.mergeFolderUri else Prefs.extractFolderUri
            ?: return null
        val uri = runCatching { Uri.parse(stored) }.getOrNull() ?: return null

        // Check we still have write permission by trying to open the DocumentFile
        val accessible = runCatching {
            val df = androidx.documentfile.provider.DocumentFile.fromTreeUri(this, uri)
            df != null && df.canWrite()
        }.getOrDefault(false)

        return if (accessible) uri else {
            // Permission was revoked (e.g. app reinstall, ROM reset) — clear and re-ask
            if (isMerge) { Prefs.mergeFolderUri = null; Prefs.mergeFolderName = null }
            else         { Prefs.extractFolderUri = null; Prefs.extractFolderName = null }
            updateSettingsFolderLabels()
            null
        }
    }

    private fun updateSettingsFolderLabels() {
        val eName = Prefs.extractFolderName
        b.tvExtractFolderName.text = eName ?: "Not set — asks each time"
        b.btnClearExtractFolder.visibility = if (eName != null) View.VISIBLE else View.GONE

        val mName = Prefs.mergeFolderName
        b.tvMergeFolderName.text = mName ?: "Not set — asks each time"
        b.btnClearMergeFolder.visibility = if (mName != null) View.VISIBLE else View.GONE
    }

    // ── Lifecycle ──────────────────────────────────────────────────────────────
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        Prefs.init(this)
        AppState.minSizeKb    = Prefs.minSizeKb
        AppState.excludeGifs  = Prefs.excludeGifs
        AppState.reverseOrder = Prefs.reverseOrder
        ImageSaver.clearShareCache(this)
        AppState.imgCacheDir = java.io.File(cacheDir, "img_cache")

        setupTabs()
        setupControls()
        setupActionBar()
        setupDragToReorder()
        applyMode(AppMode.EXTRACT)
        handleIncomingShareIntent(intent)
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); handleIncomingShareIntent(intent) }
    override fun onTrimMemory(level: Int)    { super.onTrimMemory(level); AppState.trimThumbCache(level) }
    override fun onDestroy()                 { processingJob?.cancel(); super.onDestroy() }

    // ── Incoming share ─────────────────────────────────────────────────────────
    private fun handleIncomingShareIntent(intent: Intent?) {
        if (intent == null) return
        val uris = mutableListOf<Uri>()
        when (intent.action) {
            Intent.ACTION_SEND_MULTIPLE -> {
                val extras = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
                    intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java)
                else @Suppress("DEPRECATION") intent.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)
                extras?.forEach { uris.add(it) }
            }
            Intent.ACTION_SEND -> {
                val uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
                    intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
                else @Suppress("DEPRECATION") intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
                uri?.let { uris.add(it) }
            }
        }
        if (uris.isNotEmpty()) { processFiles(uris); setIntent(Intent(Intent.ACTION_MAIN)) }
    }

    // ── Tabs ───────────────────────────────────────────────────────────────────
    private fun setupTabs() {
        b.tabExtract.setOnClickListener { applyMode(AppMode.EXTRACT) }
        b.tabMerge.setOnClickListener   { applyMode(AppMode.MERGE) }
    }

    private fun applyMode(mode: AppMode) {
        AppState.currentMode = mode
        val active   = 0xFFFFFFFF.toInt()
        val inactive = 0xFF9090B0.toInt()
        if (mode == AppMode.EXTRACT) {
            b.tabExtract.setBackgroundResource(R.drawable.bg_tab_active); b.tabExtract.setTextColor(active)
            b.tabMerge.setBackgroundResource(android.R.color.transparent); b.tabMerge.setTextColor(inactive)
        } else {
            b.tabMerge.setBackgroundResource(R.drawable.bg_tab_active); b.tabMerge.setTextColor(active)
            b.tabExtract.setBackgroundResource(android.R.color.transparent); b.tabExtract.setTextColor(inactive)
        }
        // Close settings when switching mode; destroy adapter so it rebuilds
        // with the correct isMerge flag from AppState.currentMode.
        b.settingsPanel.visibility = View.GONE
        chapterAdapter?.destroy(); chapterAdapter = null
        AppState.applyFilters(); refreshChapterList()
    }

    // ── Controls ───────────────────────────────────────────────────────────────
    private fun setupControls() {
        // Settings toggle — one panel, both modes
        b.settingsToggle.setOnClickListener {
            b.settingsPanel.visibility =
                if (b.settingsPanel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }

        // Extract folder
        b.btnSetExtractFolder.setOnClickListener { settingsExtractFolderLauncher.launch(null) }
        b.btnClearExtractFolder.setOnClickListener {
            Prefs.extractFolderUri = null; Prefs.extractFolderName = null
            updateSettingsFolderLabels()
        }

        // Merge folder
        b.btnSetMergeFolder.setOnClickListener { settingsMergeFolderLauncher.launch(null) }
        b.btnClearMergeFolder.setOnClickListener {
            Prefs.mergeFolderUri = null; Prefs.mergeFolderName = null
            updateSettingsFolderLabels()
        }

        updateSettingsFolderLabels()

        // Extract filters
        b.sizeSlider.progress = AppState.minSizeKb
        updateSizeLabel()
        b.sizeSlider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, v: Int, user: Boolean) {
                AppState.minSizeKb = v; Prefs.minSizeKb = v; updateSizeLabel()
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) { AppState.applyFilters(); refreshChapterList() }
        })
        b.toggleGifs.isChecked    = AppState.excludeGifs
        b.toggleReverse.isChecked = AppState.reverseOrder
        b.toggleGifs.setOnCheckedChangeListener    { _, c -> AppState.excludeGifs = c;  Prefs.excludeGifs = c;  AppState.applyFilters(); refreshChapterList() }
        b.toggleReverse.setOnCheckedChangeListener { _, c -> AppState.reverseOrder = c; Prefs.reverseOrder = c; AppState.applyFilters(); refreshChapterList() }

        b.dropZone.setOnClickListener { showFileManagerChooser() }
        b.chapterList.layoutManager = LinearLayoutManager(this)
        b.chapterList.setItemViewCacheSize(10)   // keep 10 chapter rows off-screen warm
    }

    private fun setupActionBar() {
        b.btnAddMore.setOnClickListener     { showFileManagerChooser() }
        b.btnDownload.setOnClickListener    { startSave(asCbz = false) }
        b.btnSaveCbz.setOnClickListener     { startSave(asCbz = true) }
        b.btnShareDirect.setOnClickListener { startShareAll() }
        b.btnViewAll.setOnClickListener     { if (AppState.groups.isNotEmpty()) startActivity(Intent(this, AllPhotosActivity::class.java)) }
        b.btnReset.setOnClickListener {
            processingJob?.cancel()          // stop any in-progress file loading
            preCacheJob?.cancel()
            chapterAdapter?.destroy(); chapterAdapter = null
            b.chapterList.adapter = null
            AppState.resetAll()  // also deletes cached image temp files
            invalidateShareCache()
            ImageSaver.clearShareCache(this)
            refreshChapterList()
        }
    }

    private fun setupDragToReorder() {
        val callback = object : ItemTouchHelper.SimpleCallback(ItemTouchHelper.UP or ItemTouchHelper.DOWN, 0) {
            override fun onMove(rv: RecyclerView, from: RecyclerView.ViewHolder, to: RecyclerView.ViewHolder): Boolean {
                val f = from.adapterPosition; val t = to.adapterPosition
                if (f < 0 || t < 0) return false
                Collections.swap(AppState.groups, f, t); chapterAdapter?.notifyItemMoved(f, t); return true
            }
            override fun onSwiped(vh: RecyclerView.ViewHolder, dir: Int) {}
            override fun isLongPressDragEnabled() = false
        }
        chapterTouchHelper = ItemTouchHelper(callback).also { it.attachToRecyclerView(b.chapterList) }
    }

    private fun updateSizeLabel() { b.sizeLabel.text = getString(R.string.size_kb, AppState.minSizeKb) }

    // ── Refresh UI ─────────────────────────────────────────────────────────────
    private fun refreshUI() {
        val hasGroups = AppState.groups.isNotEmpty()
        val isMerge   = AppState.currentMode == AppMode.MERGE

        b.dropZone.visibility    = if (hasGroups) View.GONE    else View.VISIBLE
        b.chapterList.visibility = if (hasGroups) View.VISIBLE else View.GONE
        b.actionBar.visibility   = if (hasGroups) View.VISIBLE else View.GONE
        b.mergeTip.visibility    = if (isMerge && hasGroups) View.VISIBLE else View.GONE

        if (hasGroups) {
            b.btnDownload.text      = if (isMerge) "💾 Save Images" else "📁 Save Folder"
            b.btnSaveCbz.visibility = if (isMerge) View.GONE else View.VISIBLE
            b.btnAddMore.text       = if (isMerge) getString(R.string.btn_add_images) else getString(R.string.btn_add_more)
        }

        if (isMerge && hasGroups) {
            val total = AppState.groups.sumOf { it.displayImages.size }
            b.mergeImageCount.text = getString(R.string.merge_image_count, total, (total + 1) / 2)
        }

        if (hasGroups) {
            val totalImgs     = AppState.groups.sumOf { it.displayImages.size }
            val totalFiltered = AppState.groups.sumOf { it.filteredImages.size }
            val totalKb       = AppState.groups.sumOf { g -> g.displayImages.sumOf { it.size.toLong() } } / 1024
            val sizeStr       = if (totalKb > 1024) "%.1f MB".format(totalKb / 1024.0) else "${totalKb} KB"
            b.statsText.text = if (isMerge) {
                getString(R.string.stats_merge, AppState.groups.size, totalImgs, (totalImgs + 1) / 2, sizeStr)
            } else if (totalFiltered > 0) {
                getString(R.string.stats_extract_filtered, AppState.groups.size, totalImgs, sizeStr, totalFiltered)
            } else {
                getString(R.string.stats_extract, AppState.groups.size, totalImgs, sizeStr)
            }
        }
    }

    private fun refreshChapterList() {
        // Reuse the existing adapter (and its coroutine scope + warm thumbnail cache)
        // instead of destroying + recreating it on every small action.
        if (chapterAdapter != null) {
            chapterAdapter?.update()
            refreshUI()
            return
        }
        chapterAdapter = ChapterAdapter(
            groups           = AppState.groups,
            onImageClick     = { gIdx, iIdx ->
                previewLauncher.launch(Intent(this, ImagePreviewActivity::class.java).apply {
                    putExtra(ImagePreviewActivity.EXTRA_GROUP_IDX, gIdx)
                    putExtra(ImagePreviewActivity.EXTRA_IMAGE_IDX, iIdx)
                    putExtra(ImagePreviewActivity.EXTRA_IS_MERGE, AppState.currentMode == AppMode.MERGE)
                })
            },
            onGroupRemove    = { idx -> AppState.groups.removeAt(idx); AppState.applyFilters(); refreshChapterList() },
            onGroupShare     = { idx -> shareGroup(idx) },
            onGroupRename    = { idx -> renameGroup(idx) },
            onImageLongClick = { img -> img.userDeleted = true; img.forceKeep = false; AppState.applyFilters(); refreshChapterList() },
            onImageRestore   = { img -> img.forceKeep = true; img.userDeleted = false; AppState.applyFilters(); refreshChapterList() },
            onFilteredPreview = { gIdx, filtIdx ->
                previewLauncher.launch(Intent(this, ImagePreviewActivity::class.java).apply {
                    putExtra(ImagePreviewActivity.EXTRA_GROUP_IDX, gIdx)
                    putExtra(ImagePreviewActivity.EXTRA_IMAGE_IDX, filtIdx)
                    putExtra(ImagePreviewActivity.EXTRA_IS_FILTERED, true)
                })
            },
            onBatchRestore   = { gIdx ->
                AppState.groups.getOrNull(gIdx)?.allImages?.forEach { if (!it.userDeleted) it.forceKeep = true }
                AppState.applyFilters(); refreshChapterList()
                Toast.makeText(this, getString(R.string.toast_restored_all), Toast.LENGTH_SHORT).show()
            }
        )
        b.chapterList.adapter = chapterAdapter
        chapterAdapter?.touchHelper = chapterTouchHelper
        refreshUI()
    }

    // ── Per-chapter share ──────────────────────────────────────────────────────
    private fun shareGroup(groupIdx: Int) {
        val group   = AppState.groups.getOrNull(groupIdx) ?: return
        val isMerge = AppState.currentMode == AppMode.MERGE
        val key     = "${groupIdx}_${group.groupName}_${group.displayImages.size}"

        shareCacheGroup[key]?.let { launchShare(it); return }

        b.progressArea.visibility = View.VISIBLE
        lifecycleScope.launch(Dispatchers.IO) {
            runCatching {
                ImageSaver.buildShareUris(this@MainActivity, listOf(group), isMerge) { p ->
                    lifecycleScope.launch(Dispatchers.Main) {
                        b.progressStatus.text  = p.message
                        b.progressBar.progress = p.percent
                    }
                }
            }.onSuccess { uris ->
                shareCacheGroup[key] = uris
                withContext(Dispatchers.Main) { b.progressArea.visibility = View.GONE; launchShare(uris) }
            }.onFailure { e ->
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility = View.GONE
                    Toast.makeText(this@MainActivity, "Share failed: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    // ── Per-chapter rename ─────────────────────────────────────────────────────
    private fun renameGroup(groupIdx: Int) {
        val group = AppState.groups.getOrNull(groupIdx) ?: return
        val input = EditText(this).apply {
            setText(group.groupName); setSelection(0, group.groupName.length)
            hint = "Chapter name"; setPadding(48, 24, 48, 8)
        }
        AlertDialog.Builder(this).setTitle("Rename chapter").setView(input)
            .setPositiveButton("Rename") { _, _ ->
                val newName = input.text.toString().trim().ifBlank { group.groupName }
                AppState.groups[groupIdx] = group.copy(groupName = newName)
                refreshChapterList()
            }
            .setNegativeButton("Cancel", null).show()
    }

    // ── File manager chooser ───────────────────────────────────────────────────
    private fun showFileManagerChooser() {
        if (AppState.currentMode == AppMode.MERGE) {
            mergePickerLauncher.launch(Intent(this, MergeImagePickerActivity::class.java)); return
        }
        val pm = packageManager
        val probeGet = Intent(Intent.ACTION_GET_CONTENT).apply { type = "*/*"; addCategory(Intent.CATEGORY_OPENABLE) }
        val probeDoc = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "*/*"; addCategory(Intent.CATEGORY_OPENABLE) }
        val blocked = setOf("com.android.providers.media", "com.android.providers.media.photopicker",
            "com.android.photopicker", "com.google.android.providers.media",
            "com.google.android.apps.nbu.files", packageName)
        val seen = mutableSetOf<String>(); val items = mutableListOf<AppPickerItem>()
        fun addApp(pkg: String, actName: String?, actionType: String) {
            if (pkg in blocked || !seen.add(pkg)) return
            runCatching {
                val info = pm.getApplicationInfo(pkg, 0)
                val icon = runCatching {
                    if (actName != null) pm.getActivityIcon(ComponentName(pkg, actName))
                    else pm.getApplicationIcon(info)
                }.getOrElse { pm.getApplicationIcon(info) }
                items.add(AppPickerItem(pm.getApplicationLabel(info).toString(), icon, pkg, actName, actionType))
            }
        }
        pm.queryIntentActivities(probeGet, 0).sortedBy { it.loadLabel(pm).toString().lowercase() }
            .forEach { addApp(it.activityInfo.packageName, it.activityInfo.name, "GET_CONTENT") }
        pm.queryIntentActivities(probeDoc, 0).sortedBy { it.loadLabel(pm).toString().lowercase() }
            .forEach { addApp(it.activityInfo.packageName, it.activityInfo.name, "OPEN_DOCUMENT") }
        listOf("ru.zdevs.zarchiver","com.amaze.filemanager","com.ghisler.android.TotalCommander",
            "com.estrongs.android.pop","nextapp.fx","com.cxinventor.file.explorer",
            "com.sec.android.app.myfiles","com.mi.android.globalFileExplorer",
            "com.asus.filemanager","com.coloros.filemanager","com.rhmsoft.fm")
            .forEach { pkg -> if (pm.getLaunchIntentForPackage(pkg) != null) addApp(pkg, null, "GET_CONTENT") }

        val dialog = BottomSheetDialog(this, com.google.android.material.R.style.Theme_Material3_Dark_BottomSheetDialog)
        val sheet  = BottomSheetAppPickerBinding.inflate(layoutInflater)
        dialog.setContentView(sheet.root)
        sheet.tvPickerTitle.text = getString(R.string.picker_title)
        sheet.tvSubtitle.text   = getString(R.string.picker_subtitle)
        sheet.rvApps.layoutManager = GridLayoutManager(this, 4)
        sheet.rvApps.adapter = AppPickerAdapter(items) { item -> dialog.dismiss(); launchAppOrGuide(item) }
        sheet.tvCancel.setOnClickListener { dialog.dismiss() }
        dialog.show()
    }

    private fun launchAppOrGuide(item: AppPickerItem) {
        if (item.packageName == "ru.zdevs.zarchiver") {
            packageManager.getLaunchIntentForPackage("ru.zdevs.zarchiver")?.let {
                startActivity(it)
                Snackbar.make(b.root, getString(R.string.zarchiver_hint), Snackbar.LENGTH_LONG)
                    .setBackgroundTint(0xFF7C3AED.toInt()).setTextColor(0xFFFFFFFF.toInt()).show()
            }; return
        }
        val action = if (item.actionType == "OPEN_DOCUMENT") Intent.ACTION_OPEN_DOCUMENT else Intent.ACTION_GET_CONTENT
        val intent = Intent(action).apply {
            type = "*/*"; putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/jpeg","image/png","image/webp","image/gif",
                "multipart/related","message/rfc822","application/octet-stream"))
            addCategory(Intent.CATEGORY_OPENABLE)
            if (item.packageName != null && item.activityName != null)
                component = ComponentName(item.packageName, item.activityName)
            else if (item.packageName != null) setPackage(item.packageName)
        }
        val launcher = if (item.actionType == "OPEN_DOCUMENT") openDocLauncher else getContentLauncher
        runCatching { launcher.launch(intent) }.onFailure {
            runCatching {
                launcher.launch(Intent(action).apply {
                    type = "*/*"; putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                    addCategory(Intent.CATEGORY_OPENABLE)
                    if (item.packageName != null) setPackage(item.packageName)
                })
            }.onFailure {
                getContentLauncher.launch(Intent.createChooser(
                    Intent(Intent.ACTION_GET_CONTENT).apply {
                        type = "*/*"; putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                        addCategory(Intent.CATEGORY_OPENABLE)
                    }, getString(R.string.picker_open_files)))
            }
        }
    }

    private fun handlePickResult(data: Intent?) {
        val uris: List<Uri> = when {
            data?.clipData != null -> (0 until data.clipData!!.itemCount).map { data.clipData!!.getItemAt(it).uri }
            data?.data != null     -> listOf(data.data!!)
            else                   -> emptyList()
        }
        if (uris.isNotEmpty()) processFiles(uris)
    }

    // ── File processing ────────────────────────────────────────────────────────
    private fun processFiles(uris: List<Uri>, folderName: String = "") {
        processingJob?.cancel()
        b.progressArea.visibility = View.VISIBLE
        b.dropZone.visibility     = View.GONE
        b.actionBar.visibility    = View.GONE

        processingJob = lifecycleScope.launch {
            val looseImages    = mutableListOf<ImageItem>()
            var duplicateCount = 0

            uris.forEachIndexed { i, uri ->
                withContext(Dispatchers.Main) {
                    b.progressStatus.text  = getString(R.string.reading_file, i + 1, uris.size)
                    b.progressBar.progress = (i * 100) / uris.size
                }
                val uriStr = uri.toString()
                if (!AppState.seenUris.add(uriStr)) { duplicateCount++; return@forEachIndexed }
                val name = getFileName(uri).lowercase()
                val data: ByteArray? = withContext(Dispatchers.IO) {
                    runCatching { contentResolver.openInputStream(uri)?.readBytes() }.getOrNull()
                }
                if (data == null) return@forEachIndexed
                when {
                    name.endsWith(".mhtml") || name.endsWith(".mht") -> {
                        val displayName = getFileName(uri)
                        val tempDir = java.io.File(cacheDir, "img_cache/${System.currentTimeMillis()}")
                        val group = withContext(Dispatchers.IO) {
                            MhtmlParser.parse(data, displayName, tempDir) { found ->
                                b.root.post {
                                    b.progressStatus.text = "Extracting … $found images found"
                                }
                            }
                        }
                        if (group != null) AppState.groups.add(group)
                    }
                    name.matches(Regex(".*\\.(jpg|jpeg|png|webp|gif)")) -> {
                        // Write to cache file immediately — don't keep ByteArray in RAM
                        val ext = name.substringAfterLast('.')
                        val tempDir = java.io.File(cacheDir, "img_cache/loose")
                        tempDir.mkdirs()
                        val file = java.io.File(tempDir, "${looseImages.size.toString().padStart(6,'0')}.$ext")
                        withContext(Dispatchers.IO) { file.writeBytes(data) }
                        looseImages.add(ImageItem(looseImages.size, file.absolutePath, ext, data.size))
                    }
                }
            }

            if (looseImages.isNotEmpty()) {
                val n = AppState.groups.size + 1
                val label = when {
                    AppState.currentMode == AppMode.MERGE && folderName.isNotBlank() -> folderName
                    AppState.currentMode == AppMode.MERGE -> "Merge Group $n (${looseImages.size} images)"
                    uris.size == 1 -> getFileName(uris[0]).substringBeforeLast('.').ifBlank { "Images $n" }
                    else           -> "Images $n (${looseImages.size})"
                }
                AppState.groups.add(ImageGroup(label).also { it.allImages.addAll(looseImages) })
            }

            AppState.applyFilters()
            b.progressArea.visibility = View.GONE
            refreshChapterList()
            preCacheShareUris()

            // ── Lazy dims decode ─────────────────────────────────────────────
            // Fix #2: build originalIdx→displayIdx map ONCE per group (O(n) total
            // instead of O(n²)). Fix #3: collect all dims first, then do a single
            // list replacement per group instead of one per image.
            lifecycleScope.launch(com.mangatool.app.util.BitmapUtils.decodeDispatcher) {
                AppState.groups.forEachIndexed { gIdx, group ->
                    // Build lookup map once — O(n), not O(n²)
                    val origToDisplay = group.displayImages
                        .mapIndexedNotNull { dIdx, img -> img.originalIdx to dIdx }
                        .toMap()

                    val pending = mutableListOf<Int>()
                    val displayUpdates = mutableMapOf<Int, Pair<Int,Int>>() // dIdx -> (w,h)

                    group.allImages.forEachIndexed { idx, img ->
                        if (img.width == 0) {
                            val (w, h) = com.mangatool.app.util.BitmapUtils
                                .decodeDimensions(img.filePath)
                            group.allImages[idx] = img.copy(width = w, height = h)
                            origToDisplay[img.originalIdx]?.let { dIdx ->
                                displayUpdates[dIdx] = w to h
                                pending += dIdx
                            }
                        }
                        // Flush to UI every 20 images to avoid hammering Main thread
                        if (pending.size >= 20) {
                            val batch = pending.toList(); pending.clear()
                            // Single list replacement per flush instead of one per image
                            val mut = group.displayImages.toMutableList()
                            displayUpdates.forEach { (dIdx, wh) ->
                                if (dIdx < mut.size) mut[dIdx] = mut[dIdx].copy(width = wh.first, height = wh.second)
                            }
                            group.displayImages = mut
                            displayUpdates.clear()
                            withContext(Dispatchers.Main) {
                                batch.forEach { chapterAdapter?.notifyImageDimsChanged(gIdx, it) }
                            }
                        }
                    }
                    // Flush remainder
                    if (pending.isNotEmpty()) {
                        val mut = group.displayImages.toMutableList()
                        displayUpdates.forEach { (dIdx, wh) ->
                            if (dIdx < mut.size) mut[dIdx] = mut[dIdx].copy(width = wh.first, height = wh.second)
                        }
                        group.displayImages = mut
                        val batch = pending.toList()
                        withContext(Dispatchers.Main) {
                            batch.forEach { chapterAdapter?.notifyImageDimsChanged(gIdx, it) }
                        }
                    }
                }
            }

            if (duplicateCount > 0) {
                Snackbar.make(b.root, getString(R.string.toast_duplicate_skipped, duplicateCount), Snackbar.LENGTH_SHORT)
                    .setBackgroundTint(0xFF21262D.toInt()).setTextColor(0xFFF0F6FC.toInt()).show()
            }
        }
    }

    private fun getFileName(uri: Uri): String =
        contentResolver.query(uri, null, null, null, null)?.use {
            val idx = it.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && it.moveToFirst()) it.getString(idx) else "file"
        } ?: uri.lastPathSegment ?: "file"

    // ── Share pre-cache ────────────────────────────────────────────────────────
    private fun preCacheShareUris() {
        preCacheJob?.cancel()
        if (AppState.groups.isEmpty()) return
        val isMerge = AppState.currentMode == AppMode.MERGE
        val allKey  = AppState.groups.joinToString("|") { "${it.groupName}_${it.displayImages.size}" }

        preCacheJob = lifecycleScope.launch(Dispatchers.IO) {
            if (!shareCacheAll.containsKey(allKey)) {
                runCatching { ImageSaver.buildShareUris(this@MainActivity, AppState.groups, isMerge) {} }
                    .onSuccess { shareCacheAll[allKey] = it }
            }
            AppState.groups.forEachIndexed { idx, group ->
                val key = "${idx}_${group.groupName}_${group.displayImages.size}"
                if (!shareCacheGroup.containsKey(key)) {
                    runCatching { ImageSaver.buildShareUris(this@MainActivity, listOf(group), isMerge) {} }
                        .onSuccess { shareCacheGroup[key] = it }
                }
            }
        }
    }

    private fun invalidateShareCache() {
        preCacheJob?.cancel()
        shareCacheAll.clear()
        shareCacheGroup.clear()
    }

    // ── Save ───────────────────────────────────────────────────────────────────
    private fun startSave(asCbz: Boolean) {
        if (AppState.groups.isEmpty()) return
        when {
            asCbz -> checkWritePermission { showCbzNameDialog() }
            AppState.currentMode == AppMode.MERGE -> {
                val savedUri = getValidFolderUri(isMerge = true)
                if (savedUri != null) showMergeNameDialog(savedUri)
                else                  openSettingsToSetFolder(isMerge = true)
            }
            else -> {
                val savedUri = getValidFolderUri(isMerge = false)
                if (savedUri != null) performSaveExtract(savedUri)
                else                  openSettingsToSetFolder(isMerge = false)
            }
        }
    }

    /** No folder set yet — open Settings panel and highlight the right Choose button */
    private fun openSettingsToSetFolder(isMerge: Boolean) {
        // 1. Open the settings panel
        b.settingsPanel.visibility = View.VISIBLE

        // 2. Identify the row and button to highlight
        val row    = if (isMerge) b.rowMergeFolder    else b.rowExtractFolder
        val btn    = if (isMerge) b.btnSetMergeFolder else b.btnSetExtractFolder
        val label  = if (isMerge) "Merge"             else "Extract"

        // 3. Scroll the row into view (it may be offscreen)
        row.post { row.requestRectangleOnScreen(android.graphics.Rect(0, 0, row.width, row.height), true) }

        // 4. Pulse the row with an accent highlight 3× so the user sees it
        val accentColor  = androidx.core.content.ContextCompat.getColor(this, R.color.primary)
        val transparent  = android.graphics.Color.TRANSPARENT
        val pulse = android.animation.ObjectAnimator.ofArgb(row, "backgroundColor", transparent, accentColor, transparent)
        pulse.duration      = 500
        pulse.repeatCount   = 2
        pulse.repeatMode    = android.animation.ValueAnimator.REVERSE
        pulse.startDelay    = 200
        pulse.start()

        // 5. Show a Snackbar anchored above the action bar
        com.google.android.material.snackbar.Snackbar
            .make(b.root, "Set your $label save folder first", com.google.android.material.snackbar.Snackbar.LENGTH_LONG)
            .setAction("Choose") { btn.performClick() }
            .setAnchorView(b.actionBar)
            .show()
    }

    /** Merge — folder already known: just ask for the photo name */
    private fun showMergeNameDialog(treeUri: Uri) {
        val default = if (AppState.groups.size == 1) AppState.groups[0].groupName else "Merged"
        val input = EditText(this).apply {
            setText(default); setSelection(0, default.length)
            hint = "e.g. Chapter 1"; setPadding(48, 24, 48, 8)
        }
        val totalPairs = AppState.groups.sumOf {
            com.mangatool.app.util.ImageMerger.pairImages(it.displayImages).size
        }
        val hint = if (totalPairs == 1) "Saves as: Name.png"
                   else "Saves as: Name_1.png, Name_2.png…"
        AlertDialog.Builder(this)
            .setTitle("Name your photos")
            .setMessage("Folder: ${Prefs.mergeFolderName}\n$hint")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val name = sanitizeName(input.text.toString(), default)
                performSaveMerge(treeUri, name)
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun showCbzNameDialog() {
        val default = if (AppState.groups.size == 1) AppState.groups[0].groupName else "Manga_Batch"
        val input = EditText(this).apply {
            setText(default); setSelection(0, default.length)
            hint = "CBZ filename"; setPadding(48, 24, 48, 8)
        }
        AlertDialog.Builder(this).setTitle("Save as CBZ").setView(input)
            .setPositiveButton(getString(R.string.btn_save)) { _, _ ->
                val raw = sanitizeName(input.text.toString(), default)
                performSaveCbz(if (raw.endsWith(".cbz", true)) raw else "$raw.cbz")
            }
            .setNegativeButton(getString(R.string.btn_cancel), null).show()
    }

    private fun sanitizeName(input: String, fallback: String) =
        input.trim().replace(Regex("""[\\/:*?"<>|]"""), "_").ifBlank { fallback }

    // ── Save workers ───────────────────────────────────────────────────────────
    private fun performSaveExtract(treeUri: Uri) {
        b.btnDownload.isEnabled = false; b.btnSaveCbz.isEnabled = false
        b.progressArea.visibility = View.VISIBLE
        lifecycleScope.launch(Dispatchers.IO) {
            runCatching {
                FolderSaver.saveExtractToTree(this@MainActivity, treeUri, AppState.groups) { p ->
                    lifecycleScope.launch(Dispatchers.Main) {
                        b.progressStatus.text = p.message; b.progressBar.progress = p.percent
                    }
                }
            }.onSuccess { result ->
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility = View.GONE
                    b.btnDownload.isEnabled = true; b.btnSaveCbz.isEnabled = true
                    val subtitle = if (AppState.groups.size == 1)
                        "${result.count} images → ${result.folderName}/${AppState.groups[0].groupName}"
                    else
                        "${result.count} images → ${result.folderName}"
                    showSavedSheet("Saved!", subtitle, emptyList(), saveFirst = true)
                }
            }.onFailure { e ->
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility = View.GONE
                    b.btnDownload.isEnabled = true; b.btnSaveCbz.isEnabled = true
                    Toast.makeText(this@MainActivity, getString(R.string.toast_failed, e.message), Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun performSaveMerge(treeUri: Uri, photoName: String) {
        b.btnDownload.isEnabled = false
        b.progressArea.visibility = View.VISIBLE
        lifecycleScope.launch(Dispatchers.IO) {
            runCatching {
                FolderSaver.saveMergeToTree(this@MainActivity, treeUri, AppState.groups, photoName) { p ->
                    lifecycleScope.launch(Dispatchers.Main) {
                        b.progressStatus.text = p.message; b.progressBar.progress = p.percent
                    }
                }
            }.onSuccess { result ->
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility = View.GONE
                    b.btnDownload.isEnabled   = true
                    showSavedSheet(
                        title     = "Saved ${result.count} photos",
                        subtitle  = "$photoName.png in ${result.folderName}",
                        shareUris = emptyList(),
                        saveFirst = true
                    )
                }
            }.onFailure { e ->
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility = View.GONE
                    b.btnDownload.isEnabled   = true
                    Toast.makeText(this@MainActivity, getString(R.string.toast_failed, e.message), Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun performSaveCbz(filename: String) {
        b.btnDownload.isEnabled = false; b.btnSaveCbz.isEnabled = false
        b.progressArea.visibility = View.VISIBLE
        lifecycleScope.launch(Dispatchers.IO) {
            runCatching {
                val uri = CbzCreator.create(this@MainActivity, AppState.groups, filename, false) { p ->
                    lifecycleScope.launch(Dispatchers.Main) {
                        b.progressStatus.text = p.message; b.progressBar.progress = p.percent
                    }
                }
                ImageSaver.SaveResult(listOf(uri), filename)
            }.onSuccess { result ->
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility = View.GONE
                    b.btnDownload.isEnabled = true; b.btnSaveCbz.isEnabled = true
                    showSavedSheet("Saved: $filename", "Downloads/$filename", result.uris, saveFirst = true)
                }
            }.onFailure { e ->
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility = View.GONE
                    b.btnDownload.isEnabled = true; b.btnSaveCbz.isEnabled = true
                    Toast.makeText(this@MainActivity, getString(R.string.toast_failed, e.message), Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    // ── Share all ──────────────────────────────────────────────────────────────
    private fun startShareAll() {
        if (AppState.groups.isEmpty()) return
        val allKey = AppState.groups.joinToString("|") { "${it.groupName}_${it.displayImages.size}" }

        shareCacheAll[allKey]?.let { launchShare(it); return }

        b.btnShareDirect.isEnabled = false
        b.progressArea.visibility  = View.VISIBLE
        lifecycleScope.launch(Dispatchers.IO) {
            runCatching {
                ImageSaver.buildShareUris(this@MainActivity, AppState.groups, AppState.currentMode == AppMode.MERGE) { p ->
                    lifecycleScope.launch(Dispatchers.Main) {
                        b.progressStatus.text = p.message; b.progressBar.progress = p.percent
                    }
                }
            }.onSuccess { uris ->
                shareCacheAll[allKey] = uris
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility = View.GONE; b.btnShareDirect.isEnabled = true
                    launchShare(uris)
                }
            }.onFailure { e ->
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility = View.GONE; b.btnShareDirect.isEnabled = true
                    Toast.makeText(this@MainActivity, "Failed: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    // ── Saved bottom sheet ─────────────────────────────────────────────────────
    private fun showSavedSheet(title: String, subtitle: String, shareUris: List<Uri>, saveFirst: Boolean) {
        val dialog = BottomSheetDialog(this, com.google.android.material.R.style.Theme_Material3_Dark_BottomSheetDialog)
        val sheet  = BottomSheetSavedBinding.inflate(layoutInflater)
        dialog.setContentView(sheet.root)
        sheet.tvSavedTitle.text    = title
        sheet.tvSavedFilename.text = subtitle

        // Open in reader — only for a single CBZ
        sheet.btnOpenReader.visibility = if (saveFirst && shareUris.size == 1) View.VISIBLE else View.GONE
        sheet.btnOpenReader.setOnClickListener {
            dialog.dismiss()
            runCatching {
                startActivity(Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(shareUris[0], "application/x-cbz")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                })
            }.onFailure { Toast.makeText(this, "No CBZ reader installed", Toast.LENGTH_SHORT).show() }
        }

        // Share button — only when there are URIs (folder saves have none)
        sheet.btnShare.visibility = if (shareUris.isNotEmpty()) View.VISIBLE else View.GONE
        sheet.btnShare.setOnClickListener { dialog.dismiss(); launchShare(shareUris) }

        sheet.btnDone.setOnClickListener { dialog.dismiss() }
        dialog.show()
    }

    // ── Launch share intent ────────────────────────────────────────────────────
    private fun launchShare(uris: List<Uri>) {
        if (uris.isEmpty()) return
        val intent = if (uris.size == 1) {
            Intent(Intent.ACTION_SEND).apply {
                type = "image/*"
                putExtra(Intent.EXTRA_STREAM, uris[0])
            }
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                type = "image/*"
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(uris))
            }
        }
        // clipData is required on Android 10+ so every URI gets read permission,
        // not just the first one in EXTRA_STREAM
        val clip = ClipData.newRawUri("", uris[0])
        for (i in 1 until uris.size) clip.addItem(ClipData.Item(uris[i]))
        intent.clipData = clip
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        startActivity(Intent.createChooser(intent, "Share images via…"))
    }

    private fun checkWritePermission(onGranted: () -> Unit) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
            permLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        else onGranted()
    }
}
