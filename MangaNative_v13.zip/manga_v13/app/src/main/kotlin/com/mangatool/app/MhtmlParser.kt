package com.mangatool.app

import android.util.Base64
import com.mangatool.app.model.ImageGroup
import java.io.File
import com.mangatool.app.model.ImageItem

object MhtmlParser {

    /**
     * Parse an MHTML file into an ImageGroup, writing each extracted image
     * to a temp file in [tempDir] instead of keeping ByteArrays in RAM.
     *
     * A 30-image chapter at 300 KB/image = 9 MB of ByteArray heap if we kept
     * them in memory. Writing to disk immediately lets GC reclaim the decoded
     * bytes while the LruCache holds only the rendered thumbnails.
     *
     * [onProgress] is called with (imagesFoundSoFar) as each image is found.
     * Pixel dimensions are deferred (width/height = 0) so the caller can show
     * the list immediately and fill dims in a background pass.
     */
    fun parse(data: ByteArray, filename: String,
              tempDir: File,
              onProgress: ((done: Int) -> Unit)? = null): ImageGroup? {
        return try {
            // 1. Detect boundary string from first 4 KB
            val header = String(data.copyOfRange(0, minOf(4096, data.size)), Charsets.UTF_8)
            val boundary = Regex("""boundary="?([^";\s\r\n]+)"?""", RegexOption.IGNORE_CASE)
                .find(header)?.groupValues?.get(1)
                ?: Regex("""^--[a-fA-F0-9\-]+""", RegexOption.MULTILINE)
                    .find(header)?.value?.removePrefix("--")
                ?: return null

            val boundaryBytes = "--$boundary".toByteArray(Charsets.UTF_8)

            // 2. Binary scan — extract every image part
            val extracted = mutableListOf<RawImage>()
            var pos = 0
            var partIdx = 0

            while (pos < data.size) {
                val bPos = findBytes(data, boundaryBytes, pos)
                if (bPos == -1) break

                if (pos > 0) {
                    val chunkEnd = bPos
                    val maxHdr = minOf(chunkEnd, pos + 2048)
                    val hdrSlice = data.copyOfRange(pos, maxHdr)

                    // Find blank-line separator (CRLFCRLF or LFLF)
                    val bodyOffset: Int? = run {
                        val a = findBytes(hdrSlice, byteArrayOf(13, 10, 13, 10), 0)
                        if (a != -1) a + 4
                        else {
                            val b = findBytes(hdrSlice, byteArrayOf(10, 10), 0)
                            if (b != -1) b + 2 else null
                        }
                    }

                    if (bodyOffset != null) {
                        val bodyStart = pos + bodyOffset
                        if (bodyStart < chunkEnd) {
                            val headers = String(data.copyOfRange(pos, bodyStart), Charsets.UTF_8)
                            val typeMatch = Regex("""Content-Type:\s*image/(jpeg|jpg|png|gif|webp)""",
                                RegexOption.IGNORE_CASE).find(headers)
                            val encMatch  = Regex("""Content-Transfer-Encoding:\s*(base64|quoted-printable)""",
                                RegexOption.IGNORE_CASE).find(headers)

                            if (typeMatch != null) {
                                val rawExt = typeMatch.groupValues[1].lowercase()
                                val ext    = if (rawExt == "jpeg") "jpg" else rawExt
                                val body   = data.copyOfRange(bodyStart, chunkEnd)

                                val bytes: ByteArray? = when (encMatch?.groupValues?.get(1)?.lowercase()) {
                                    "base64" -> try {
                                        val b64 = String(body, Charsets.UTF_8)
                                            .filter { !it.isWhitespace() }
                                        Base64.decode(b64, Base64.DEFAULT)
                                    } catch (_: Exception) { null }
                                    "quoted-printable" -> decodeQP(String(body, Charsets.ISO_8859_1))
                                        .toByteArray(Charsets.ISO_8859_1)
                                    else -> body.copyOf()
                                }

                                if (bytes != null && bytes.size > 100) {
                                    // Write immediately to disk — ByteArray is GC-eligible after this block
                                    tempDir.mkdirs()
                                    val file = File(tempDir, "${partIdx.toString().padStart(8, '0')}.$ext")
                                    file.writeBytes(bytes)
                                    extracted += RawImage(
                                        sortKey  = partIdx.toString().padStart(8, '0'),
                                        filePath = file.absolutePath,
                                        size     = bytes.size,
                                        ext      = ext
                                    )
                                    onProgress?.invoke(extracted.size)
                                }
                            }
                        }
                    }
                }

                partIdx++
                pos = bPos + boundaryBytes.size
            }

            if (extracted.isEmpty()) return null

            extracted.sortBy { it.sortKey }

            val images = extracted.mapIndexed { i, r ->
                // width/height = 0 — filled in a background pass after the list is shown
                ImageItem(originalIdx = i, filePath = r.filePath, ext = r.ext, size = r.size)
            }

            val groupName = smartRename(filename)
            ImageGroup(groupName = groupName).also { g -> g.allImages.addAll(images) }

        } catch (_: Exception) {
            null
        }
    }

    // ── helpers ──────────────────────────────────────────────────────────────

    private data class RawImage(val sortKey: String, val filePath: String, val size: Int, val ext: String)

    /**
     * Knuth-Morris-Pratt failure function.
     * Pre-computes the longest proper prefix which is also a suffix for each position.
     */
    private fun kmpFailure(pattern: ByteArray): IntArray {
        val f = IntArray(pattern.size)
        var k = 0
        for (i in 1 until pattern.size) {
            while (k > 0 && pattern[k] != pattern[i]) k = f[k - 1]
            if (pattern[k] == pattern[i]) k++
            f[i] = k
        }
        return f
    }

    /**
     * KMP search — returns the index of the first occurrence of [seq] in [buf]
     * starting at [from], or -1 if not found.
     * O(n + m) vs the previous O(n·m) naive scan — crucial for large MHTML files.
     */
    private fun findBytes(buf: ByteArray, seq: ByteArray, from: Int): Int {
        if (seq.isEmpty()) return from
        val fail = kmpFailure(seq)
        var k = 0
        for (i in from until buf.size) {
            while (k > 0 && seq[k] != buf[i]) k = fail[k - 1]
            if (seq[k] == buf[i]) k++
            if (k == seq.size) return i - seq.size + 1
        }
        return -1
    }

    private fun decodeQP(s: String): String =
        s.replace(Regex("=[\\r\\n]+"), "")
         .replace(Regex("=[0-9A-Fa-f]{2}")) { it.value.substring(1).toInt(16).toChar().toString() }

    /**
     * Convert a raw MHTML filename into a clean, sortable chapter title.
     *
     * Key fix vs v7: chapter/volume number is extracted FIRST (before any bracket
     * stripping), so markers like "v2" or "Vol.3" in the original name are
     * preserved and contribute to the final title instead of being silently dropped.
     */
    private fun smartRename(filename: String): String {
        var n = filename.replace(Regex("\\.mhtml?$", RegexOption.IGNORE_CASE), "")
        n = n.replace(Regex("[_+]"), " ")
        // Strip generic noise words before extraction (they don't carry chapter info)
        n = n.replace(Regex("\\b(read manga online|read online|manga)\\b", RegexOption.IGNORE_CASE), "")
        n = n.trim()

        // Extract chapter/volume number BEFORE stripping any brackets, so that
        // filenames like "My Title (v2) ch.12.mhtml" keep the "(v2)" info.
        val m = Regex("""^(.*?)(\b(?:chapter|ch\.?|no\.?|c\.?|vol\.?|volume|#)\s*[\d.]+|\b\d+)(.*)$""",
            RegexOption.IGNORE_CASE).find(n)

        if (m != null) {
            val prefix = m.groupValues[1].trim()
            var num    = m.groupValues[2].trim()
            val suffix = m.groupValues[3].trim()
            num = num.replace(Regex("(\\d+)")) { it.value.padStart(3, '0') }
            // Strip decorative brackets only from the title prefix, not from num/suffix
            val cp = prefix.replace(Regex("\\[.*?]|\\(.*?\\)"), "").trimEnd('-', '_').trim()
            n = if (cp.isNotEmpty()) "$num - $cp $suffix".trim() else "$num $suffix".trim()
        } else {
            // No chapter number found — safe to strip decorative brackets now
            n = n.replace(Regex("\\[.*?]|\\(.*?\\)"), "").trim()
        }

        return n.replace(Regex("\\s+-\\s*$"), "").replace(Regex("\\s+"), " ").trim()
            .ifEmpty { filename.substringBefore('.') }
    }
}
