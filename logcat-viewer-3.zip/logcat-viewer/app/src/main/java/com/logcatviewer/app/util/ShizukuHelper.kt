package com.logcatviewer.app.util

import android.content.ComponentName
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import android.os.ParcelFileDescriptor
import android.util.Log
import com.logcatviewer.app.IRemoteService
import com.logcatviewer.app.RemoteService
import rikka.shizuku.Shizuku

private const val TAG = "ShizukuHelper"
private const val SHIZUKU_CODE = 1001

object ShizukuHelper {

    val isAvailable: Boolean
        get() = runCatching { Shizuku.pingBinder() }.getOrDefault(false)

    val hasShizukuPermission: Boolean
        get() = runCatching {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        }.getOrDefault(false)

    fun requestShizukuPermission() {
        if (!isAvailable || Shizuku.isPreV11()) return
        Shizuku.requestPermission(SHIZUKU_CODE)
    }

    private var activeConnection: ServiceConnection? = null
    private var activeServiceArgs: Shizuku.UserServiceArgs? = null
    private var remoteService: IRemoteService? = null

    private fun buildServiceArgs(packageName: String) = Shizuku.UserServiceArgs(
        ComponentName(packageName, RemoteService::class.java.name)
    )
        .daemon(false)
        .processNameSuffix("logcat_service")
        .debuggable(false)
        .version(1)

    /**
     * Bind the UserService and deliver it via [onConnected].
     */
    fun bindService(packageName: String, onConnected: (IRemoteService?) -> Unit) {
        if (!isAvailable || !hasShizukuPermission) {
            onConnected(null)
            return
        }
        val args = buildServiceArgs(packageName)
        activeServiceArgs = args

        val conn = object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName, binder: IBinder) {
                val svc = IRemoteService.Stub.asInterface(binder)
                remoteService = svc
                onConnected(svc)
            }
            override fun onServiceDisconnected(name: ComponentName) {
                Log.w(TAG, "UserService disconnected")
                remoteService = null
                onConnected(null)
            }
        }
        activeConnection = conn
        try {
            Shizuku.bindUserService(args, conn)
        } catch (e: Exception) {
            Log.e(TAG, "bindUserService failed", e)
            onConnected(null)
        }
    }

    fun unbindService() {
        val args = activeServiceArgs ?: return
        val conn = activeConnection ?: return
        runCatching { Shizuku.unbindUserService(args, conn, true) }
        activeConnection = null
        activeServiceArgs = null
        remoteService = null
    }

    fun getService(): IRemoteService? = remoteService

    /**
     * One-shot: bind → grant READ_LOGS → unbind.
     */
    fun grantReadLogsPermission(packageName: String, callback: (Boolean) -> Unit) {
        if (!isAvailable || !hasShizukuPermission) { callback(false); return }

        val args = buildServiceArgs(packageName)
        val conn = object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName, binder: IBinder) {
                val exitCode = runCatching {
                    IRemoteService.Stub.asInterface(binder).grantReadLogs(packageName)
                }.getOrDefault(-1)
                runCatching { Shizuku.unbindUserService(args, this, true) }
                callback(exitCode == 0)
            }
            override fun onServiceDisconnected(name: ComponentName) { callback(false) }
        }
        try {
            Shizuku.bindUserService(args, conn)
        } catch (e: Exception) {
            Log.e(TAG, "bindUserService (grant) failed", e)
            callback(false)
        }
    }

    /**
     * Open a pipe, tell the UserService to stream logcat into the write-end,
     * and return the read-end [ParcelFileDescriptor] to read log lines from.
     */
    fun openLogcatPipe(packageName: String): ParcelFileDescriptor? {
        val svc = remoteService ?: return null
        return try {
            val pipe = ParcelFileDescriptor.createPipe()
            // pipe[0] = read end (we keep), pipe[1] = write end (service writes)
            svc.startLogcat(pipe[1])
            pipe[1].close() // close our copy of the write end
            pipe[0]         // return read end
        } catch (e: Exception) {
            Log.e(TAG, "openLogcatPipe failed", e)
            null
        }
    }

    fun lookupPid(packageName: String): Int =
        runCatching { remoteService?.lookupPid(packageName) ?: -1 }.getOrDefault(-1)

    fun stopLogcat() {
        runCatching { remoteService?.stopLogcat() }
    }

    fun addBinderReceivedListener(l: Shizuku.OnBinderReceivedListener) =
        Shizuku.addBinderReceivedListenerSticky(l)
    fun removeBinderReceivedListener(l: Shizuku.OnBinderReceivedListener) =
        Shizuku.removeBinderReceivedListener(l)
    fun addBinderDeadListener(l: Shizuku.OnBinderDeadListener) =
        Shizuku.addBinderDeadListener(l)
    fun removeBinderDeadListener(l: Shizuku.OnBinderDeadListener) =
        Shizuku.removeBinderDeadListener(l)
    fun addPermissionResultListener(l: Shizuku.OnRequestPermissionResultListener) =
        Shizuku.addRequestPermissionResultListener(l)
    fun removePermissionResultListener(l: Shizuku.OnRequestPermissionResultListener) =
        Shizuku.removeRequestPermissionResultListener(l)
}
