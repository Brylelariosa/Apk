package com.logcatviewer.app

import android.os.ParcelFileDescriptor
import android.util.Log
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream

private const val TAG = "RemoteService"

/**
 * Runs inside a Shizuku UserService as shell uid (2000).
 * Shell always has READ_LOGS and can run ps/pidof.
 */
class RemoteService : IRemoteService.Stub() {

    @Volatile private var logcatProcess: Process? = null

    override fun grantReadLogs(packageName: String): Int {
        return try {
            val p = Runtime.getRuntime().exec(
                arrayOf("pm", "grant", packageName, "android.permission.READ_LOGS")
            )
            p.waitFor()
        } catch (e: Exception) {
            Log.e(TAG, "grantReadLogs failed", e)
            -1
        }
    }

    override fun startLogcat(writeFd: ParcelFileDescriptor) {
        stopLogcat()
        Thread {
            var out: OutputStream? = null
            try {
                val process = Runtime.getRuntime().exec(
                    arrayOf("logcat", "-v", "threadtime", "*:V")
                )
                logcatProcess = process
                out = ParcelFileDescriptor.AutoCloseOutputStream(writeFd)
                process.inputStream.copyTo(out, 8192)
            } catch (e: Exception) {
                Log.e(TAG, "logcat stream error", e)
            } finally {
                runCatching { out?.close() }
                runCatching { writeFd.close() }
            }
        }.apply { isDaemon = true; start() }
    }

    override fun stopLogcat() {
        runCatching { logcatProcess?.destroy() }
        logcatProcess = null
    }

    /**
     * Resolves package name → PID using `ps -A`.
     * Returns -1 if not running or on error.
     */
    override fun lookupPid(packageName: String): Int {
        return try {
            // "ps -A" columns: USER PID PPID VSZ RSS WCHAN ADDR S NAME
            val p = Runtime.getRuntime().exec(arrayOf("ps", "-A"))
            val reader = BufferedReader(InputStreamReader(p.inputStream))
            var pid = -1
            reader.lineSequence().forEach { line ->
                if (line.contains(packageName)) {
                    val parts = line.trim().split("\\s+".toRegex())
                    // PID is the second column
                    if (parts.size >= 2) {
                        parts[1].toIntOrNull()?.let { pid = it }
                    }
                }
            }
            reader.close()
            p.waitFor()
            pid
        } catch (e: Exception) {
            Log.e(TAG, "lookupPid failed", e)
            -1
        }
    }
}
