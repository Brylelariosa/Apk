package com.logcatviewer.app

import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.logcatviewer.app.ui.LogcatScreen
import com.logcatviewer.app.ui.theme.LogcatViewerTheme
import com.logcatviewer.app.util.ShizukuHelper
import rikka.shizuku.Shizuku

class MainActivity : ComponentActivity() {

    private val viewModel: LogcatViewModel by viewModels()

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        viewModel.checkAndBind()
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        viewModel.checkAndBind()
    }

    private val permissionResultListener =
        Shizuku.OnRequestPermissionResultListener { _, grantResult ->
            if (grantResult == PackageManager.PERMISSION_GRANTED) {
                viewModel.requestViaShizuku()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        ShizukuHelper.addBinderReceivedListener(binderReceivedListener)
        ShizukuHelper.addBinderDeadListener(binderDeadListener)
        ShizukuHelper.addPermissionResultListener(permissionResultListener)

        setContent {
            LogcatViewerTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    LogcatScreen(viewModel)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.checkAndBind()
    }

    override fun onDestroy() {
        super.onDestroy()
        ShizukuHelper.removeBinderReceivedListener(binderReceivedListener)
        ShizukuHelper.removeBinderDeadListener(binderDeadListener)
        ShizukuHelper.removePermissionResultListener(permissionResultListener)
    }
}
