package com.logcatviewer.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.logcatviewer.app.data.LogEntry
import com.logcatviewer.app.data.LogLevel
import com.logcatviewer.app.data.LogcatReader
import com.logcatviewer.app.util.ShizukuHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class LogcatUiState(
    val logs: List<LogEntry> = emptyList(),
    val filteredLogs: List<LogEntry> = emptyList(),
    val searchQuery: String = "",
    val packageFilter: String = "",
    val resolvedPid: String = "",
    val tagFilter: String = "",
    val autoScroll: Boolean = true,
    val isRunning: Boolean = false,
    val permissionState: PermissionState = PermissionState.UNKNOWN,
    val shizukuAvailable: Boolean = false,
    val errorMessage: String? = null,
)

enum class PermissionState { UNKNOWN, GRANTED, DENIED, REQUESTING }

class LogcatViewModel(app: Application) : AndroidViewModel(app) {

    private val reader = LogcatReader()
    private var readJob: Job? = null
    private var pidPollJob: Job? = null
    private val maxLogs = 5_000

    private val _uiState = MutableStateFlow(LogcatUiState())
    val uiState: StateFlow<LogcatUiState> = _uiState.asStateFlow()

    // FIX 1: No checkAndBind() in init — wait for MainActivity's
    // onResume() and OnBinderReceivedListener to call it instead.
    // This prevents the "DENIED flash" before Shizuku binder is alive.

    fun checkAndBind() {
        val shizukuAvailable = ShizukuHelper.isAvailable
        _uiState.update { it.copy(shizukuAvailable = shizukuAvailable) }
        if (!shizukuAvailable) {
            // Don't immediately go to DENIED — Shizuku binder may not be alive yet.
            // Stay UNKNOWN so the UI shows a "waiting for Shizuku" message.
            if (_uiState.value.permissionState == PermissionState.UNKNOWN) return
            _uiState.update { it.copy(permissionState = PermissionState.DENIED) }
            return
        }
        if (!ShizukuHelper.hasShizukuPermission) {
            _uiState.update { it.copy(permissionState = PermissionState.DENIED) }
            return
        }
        // Already bound and streaming — nothing to do
        if (_uiState.value.permissionState == PermissionState.GRANTED &&
            ShizukuHelper.getService() != null) return

        _uiState.update { it.copy(permissionState = PermissionState.REQUESTING) }
        ShizukuHelper.bindService(getApplication<Application>().packageName) { svc ->
            if (svc != null) {
                _uiState.update { it.copy(permissionState = PermissionState.GRANTED, errorMessage = null) }
                startReading()
            } else {
                _uiState.update { it.copy(permissionState = PermissionState.DENIED) }
            }
        }
    }

    fun requestShizukuApiPermission() = ShizukuHelper.requestShizukuPermission()

    fun requestViaShizuku() {
        _uiState.update { it.copy(permissionState = PermissionState.REQUESTING) }
        ShizukuHelper.grantReadLogsPermission(getApplication<Application>().packageName) { granted ->
            if (granted) checkAndBind()
            else _uiState.update { it.copy(permissionState = PermissionState.DENIED) }
        }
    }

    fun startReading() {
        if (readJob?.isActive == true) return
        val pfd = ShizukuHelper.openLogcatPipe(getApplication<Application>().packageName)
        if (pfd == null) {
            _uiState.update {
                it.copy(isRunning = false,
                    errorMessage = "Could not open logcat pipe — is Shizuku running?")
            }
            return
        }

        // FIX 2: Start PID polling loop so we catch processes that start AFTER the filter is set
        startPidPolling()

        readJob = viewModelScope.launch {
            _uiState.update { it.copy(isRunning = true, errorMessage = null) }
            reader.readFromPipe(pfd)
                .catch { e -> _uiState.update { it.copy(isRunning = false, errorMessage = e.message) } }
                .collect { entry ->
                    _uiState.update { state ->
                        val newLogs = (state.logs + entry).takeLast(maxLogs)
                        state.copy(logs = newLogs, filteredLogs = applyFilters(newLogs, state))
                    }
                }
            _uiState.update { it.copy(isRunning = false) }
        }
    }

    /**
     * Polls every 3 seconds for the PID of the current packageFilter.
     * This handles apps that launch AFTER the filter is typed, and apps
     * that restart (new PID after a crash).
     */
    private fun startPidPolling() {
        pidPollJob?.cancel()
        pidPollJob = viewModelScope.launch(Dispatchers.IO) {
            while (isActive) {
                val pkg = _uiState.value.packageFilter
                if (pkg.contains('.')) {
                    val pid = ShizukuHelper.lookupPid(pkg).takeIf { it > 0 }?.toString() ?: ""
                    if (pid != _uiState.value.resolvedPid) {
                        _uiState.update { state ->
                            val u = state.copy(resolvedPid = pid)
                            u.copy(filteredLogs = applyFilters(state.logs, u))
                        }
                    }
                }
                delay(3_000)
            }
        }
    }

    fun stopReading() {
        ShizukuHelper.stopLogcat()
        readJob?.cancel()
        pidPollJob?.cancel()
        _uiState.update { it.copy(isRunning = false) }
    }

    fun clearLogs() = _uiState.update { it.copy(logs = emptyList(), filteredLogs = emptyList()) }

    fun setSearchQuery(query: String) {
        _uiState.update { state ->
            val u = state.copy(searchQuery = query)
            u.copy(filteredLogs = applyFilters(state.logs, u))
        }
    }

    fun setPackageFilter(pkg: String) {
        _uiState.update { state ->
            val u = state.copy(packageFilter = pkg, resolvedPid = "")
            u.copy(filteredLogs = applyFilters(state.logs, u))
        }
        // Immediate first lookup
        if (pkg.contains('.')) {
            viewModelScope.launch {
                val pid = withContext(Dispatchers.IO) {
                    ShizukuHelper.lookupPid(pkg).takeIf { it > 0 }?.toString() ?: ""
                }
                _uiState.update { state ->
                    val u = state.copy(resolvedPid = pid)
                    u.copy(filteredLogs = applyFilters(state.logs, u))
                }
            }
        }
    }

    fun setTagFilter(tag: String) {
        _uiState.update { state ->
            val u = state.copy(tagFilter = tag)
            u.copy(filteredLogs = applyFilters(state.logs, u))
        }
    }

    fun toggleAutoScroll() = _uiState.update { it.copy(autoScroll = !it.autoScroll) }
    fun setAutoScroll(value: Boolean) = _uiState.update { it.copy(autoScroll = value) }

    private fun applyFilters(logs: List<LogEntry>, state: LogcatUiState): List<LogEntry> {
        return logs.filter { entry ->
            val matchesSearch = state.searchQuery.isEmpty() ||
                    entry.message.contains(state.searchQuery, ignoreCase = true) ||
                    entry.tag.contains(state.searchQuery, ignoreCase = true)

            val matchesTag = state.tagFilter.isEmpty() ||
                    entry.tag.contains(state.tagFilter, ignoreCase = true)

            val matchesPkg = when {
                state.packageFilter.isEmpty() -> true

                state.resolvedPid.isNotEmpty() -> {
                    // Primary: entry is FROM the target app process
                    val isFromApp = entry.pid == state.resolvedPid

                    // NDK tombstones: system crash_dump64 process logs under DEBUG tag
                    val isNdkTombstone = entry.tag in listOf("DEBUG", "crash_dump64", "crash_dump32") &&
                            entry.level.ordinal >= LogLevel.ERROR.ordinal

                    // Java crashes: AndroidRuntime mentions the package
                    val isJavaCrash = entry.tag == "AndroidRuntime" &&
                            entry.message.contains(state.packageFilter, ignoreCase = true)

                    isFromApp || isNdkTombstone || isJavaCrash
                }

                // PID not yet resolved (app not running) — show text matches
                // AND all FATAL entries so crashes are never missed
                else -> {
                    val textMatch =
                        entry.tag.contains(state.packageFilter, ignoreCase = true) ||
                        entry.message.contains(state.packageFilter, ignoreCase = true)
                    // Always surface FATAL/ERROR-level entries when a filter is active
                    // so crashes from an app that just launched are never silently dropped
                    val isFatal = entry.level.ordinal >= LogLevel.ERROR.ordinal &&
                            entry.tag in listOf(
                                "AndroidRuntime", "DEBUG",
                                "crash_dump64", "crash_dump32",
                                "FATAL", "libc"
                            )
                    textMatch || isFatal
                }
            }

            matchesSearch && matchesTag && matchesPkg
        }
    }

    override fun onCleared() {
        super.onCleared()
        ShizukuHelper.stopLogcat()
        ShizukuHelper.unbindService()
        pidPollJob?.cancel()
        readJob?.cancel()
    }
}
