package com.logcatviewer.app.data

import android.os.ParcelFileDescriptor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.isActive
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.atomic.AtomicLong
import kotlin.coroutines.coroutineContext

class LogcatReader {

    private val idCounter = AtomicLong(0)

    /**
     * Read logcat lines from a [ParcelFileDescriptor] provided by the
     * Shizuku UserService (which runs as shell uid and always has READ_LOGS).
     */
    fun readFromPipe(pfd: ParcelFileDescriptor): Flow<LogEntry> = flow {
        val reader = BufferedReader(
            InputStreamReader(ParcelFileDescriptor.AutoCloseInputStream(pfd)),
            16 * 1024
        )
        try {
            while (coroutineContext.isActive) {
                val line = reader.readLine() ?: break
                parseLine(line)?.let { emit(it) }
            }
        } finally {
            runCatching { reader.close() }
        }
    }.flowOn(Dispatchers.IO)

    // threadtime format: MM-DD HH:MM:SS.mmm  PID   TID  LEVEL TAG  : message
    private fun parseLine(raw: String): LogEntry? {
        if (raw.isBlank() || raw.startsWith("-----")) return null
        return try {
            val parts = raw.trim().split("\\s+".toRegex(), limit = 6)
            if (parts.size < 6) {
                LogEntry(
                    id = idCounter.incrementAndGet(),
                    timestamp = "", pid = "", tid = "",
                    level = LogLevel.VERBOSE, tag = "?",
                    message = raw, raw = raw
                )
            } else {
                val timestamp = "${parts[0]} ${parts[1]}"
                val pid = parts[2]
                val tid = parts[3]
                val level = LogLevel.fromChar(parts[4].firstOrNull() ?: 'V')
                val tagAndMsg = parts[5]
                val colonIdx = tagAndMsg.indexOf(':')
                val tag = if (colonIdx > 0) tagAndMsg.substring(0, colonIdx).trim() else "?"
                val message = if (colonIdx >= 0) tagAndMsg.substring(colonIdx + 1).trim() else tagAndMsg
                LogEntry(
                    id = idCounter.incrementAndGet(),
                    timestamp = timestamp,
                    pid = pid, tid = tid,
                    level = level, tag = tag,
                    message = message, raw = raw
                )
            }
        } catch (e: Exception) {
            LogEntry(
                id = idCounter.incrementAndGet(),
                timestamp = "", pid = "", tid = "",
                level = LogLevel.VERBOSE, tag = "parse_error",
                message = raw, raw = raw
            )
        }
    }
}
