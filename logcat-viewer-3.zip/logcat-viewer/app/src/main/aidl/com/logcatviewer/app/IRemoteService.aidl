package com.logcatviewer.app;

interface IRemoteService {
    /** Grant READ_LOGS to the given package. Returns 0 on success. */
    int grantReadLogs(String packageName);

    /** Start streaming logcat into writeFd. */
    void startLogcat(in ParcelFileDescriptor writeFd);

    /** Stop the running logcat stream. */
    void stopLogcat();

    /** Resolve a package name to its current PID. Returns -1 if not running. */
    int lookupPid(String packageName);
}
