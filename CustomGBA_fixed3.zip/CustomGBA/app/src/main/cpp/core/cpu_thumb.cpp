#include "cpu.h"
#include "gba.h"

// ── THUMB dispatch ────────────────────────────────────────────────────────────
void ARM7TDMI::executeTHUMB(u16 i) {

    if      ((i >> 13) == 0b000 && (i>>11)!=0b00011)     thumbMoveShiftedReg(i);
    else if ((i >> 11) == 0b00011)                        thumbAddSub(i);
    else if ((i >> 13) == 0b001)                          thumbMovCmpAddSubImm(i);
    else if ((i >> 10) == 0b010000)                       thumbALU(i);
    else if ((i >> 10) == 0b010001)                       thumbHiRegOps(i);
    else if ((i >> 11) == 0b01001)                        thumbPCRelLoad(i);
    else if ((i >> 12) == 0b0101 && !((i>>9)&1))          thumbLoadStoreReg(i);
    else if ((i >> 12) == 0b0101 &&  ((i>>9)&1))          thumbLoadStoreReg(i);
    else if ((i >> 13) == 0b011)                          thumbLoadStoreImm(i);
    else if ((i >> 12) == 0b1000)                         thumbLoadStoreHalf(i);
    else if ((i >> 12) == 0b1001)                         thumbSPRelLoadStore(i);
    else if ((i >> 12) == 0b1010)                         thumbLoadAddress(i);
    else if ((i >> 12) == 0b1011 && ((i>>10)&3)==0b10)    thumbPushPop(i);
    else if ((i >> 12) == 0b1011 && ((i>>8)&0xF)==0b0000) thumbAddOffsetSP(i);
    else if ((i >> 12) == 0b1100)                         thumbMultiLoadStore(i);
    else if ((i >> 12) == 0b1101 && ((i>>8)&0xF)!=0xF)   thumbConditionalBranch(i);
    else if ((i >> 8)  == 0b11011111)                     thumbSWI(i);
    else if ((i >> 11) == 0b11100)                        thumbUnconditionalBranch(i);
    else if ((i >> 12) == 0b1111)                         thumbLongBranchLink(i);
    else cycles += 1;
}

// ── THUMB: Move Shifted Register ──────────────────────────────────────────────
void ARM7TDMI::thumbMoveShiftedReg(u16 i) {
    u32 op  = (i >> 11) & 3;
    u32 off = (i >> 6)  & 31;
    u32 rs  = (i >> 3)  & 7;
    u32 rd  =  i        & 7;
    bool c  = getFlag(FLAG_C);
    u32 res = barrelShift(r[rs], op, off, c, false);
    r[rd] = res;
    setFlag(FLAG_N, res>>31);
    setFlag(FLAG_Z, res==0);
    setFlag(FLAG_C, c);
    cycles += 1;
}

// ── THUMB: Add/Sub ────────────────────────────────────────────────────────────
void ARM7TDMI::thumbAddSub(u16 i) {
    bool imm  = (i >> 10) & 1;
    bool sub  = (i >> 9)  & 1;
    u32  val  = (i >> 6)  & 7;
    u32  rs   = (i >> 3)  & 7;
    u32  rd   =  i        & 7;
    u32  op1  = r[rs];
    u32  op2  = imm ? val : r[val];
    u32  res;
    if (sub) {
        res = op1 - op2;
        setFlag(FLAG_C, op1 >= op2);
        setFlag(FLAG_V, subOverflow(op1,op2,res));
    } else {
        res = op1 + op2;
        setFlag(FLAG_C, res < op1);
        setFlag(FLAG_V, addOverflow(op1,op2,res));
    }
    r[rd] = res;
    setFlag(FLAG_N, res>>31);
    setFlag(FLAG_Z, res==0);
    cycles += 1;
}

// ── THUMB: MOV/CMP/ADD/SUB Immediate ─────────────────────────────────────────
void ARM7TDMI::thumbMovCmpAddSubImm(u16 i) {
    u32 op  = (i >> 11) & 3;
    u32 rd  = (i >> 8)  & 7;
    u32 imm = i & 0xFF;
    u32 op1 = r[rd];
    u32 res;
    switch (op) {
        case 0: // MOV
            res = imm;
            setFlag(FLAG_N,0); setFlag(FLAG_Z,res==0);
            r[rd] = res;
            break;
        case 1: // CMP
            res = op1 - imm;
            setFlag(FLAG_N,res>>31); setFlag(FLAG_Z,res==0);
            setFlag(FLAG_C,op1>=imm); setFlag(FLAG_V,subOverflow(op1,imm,res));
            break;
        case 2: // ADD
            res = op1 + imm;
            setFlag(FLAG_N,res>>31); setFlag(FLAG_Z,res==0);
            setFlag(FLAG_C,res<op1); setFlag(FLAG_V,addOverflow(op1,imm,res));
            r[rd] = res;
            break;
        case 3: // SUB
            res = op1 - imm;
            setFlag(FLAG_N,res>>31); setFlag(FLAG_Z,res==0);
            setFlag(FLAG_C,op1>=imm); setFlag(FLAG_V,subOverflow(op1,imm,res));
            r[rd] = res;
            break;
    }
    cycles += 1;
}

// ── THUMB: ALU operations ─────────────────────────────────────────────────────
void ARM7TDMI::thumbALU(u16 i) {
    u32 op = (i >> 6) & 0xF;
    u32 rs = (i >> 3) & 7;
    u32 rd =  i       & 7;
    u32 a  = r[rd], b = r[rs];
    u32 res= a;
    bool c = getFlag(FLAG_C);

    switch (op) {
        case 0x0: res = a & b; break; // AND
        case 0x1: res = a ^ b; break; // EOR
        case 0x2: // LSL
            c   = b<32 ? (a>>(32-b))&1 : b==32 ? a&1 : 0;
            res = b<32 ? a<<b : 0;
            break;
        case 0x3: // LSR
            c   = b<32 ? (a>>(b-1))&1 : b==32 ? a>>31 : 0;
            res = b<32 ? a>>b : 0;
            break;
        case 0x4: // ASR
            c   = b<32 ? (a>>(b-1))&1 : a>>31;
            res = b<32 ? (s32)a>>b : (s32)a>>31;
            break;
        case 0x5: { // ADC
            u64 r64 = (u64)a+b+getFlag(FLAG_C);
            res=(u32)r64; c=r64>>32;
            setFlag(FLAG_V,addOverflow(a,b,res));
            break;
        }
        case 0x6: { // SBC
            u64 r64 = (u64)a-b-(1-getFlag(FLAG_C));
            res=(u32)r64; c=!(r64>>32);
            setFlag(FLAG_V,subOverflow(a,b,res));
            break;
        }
        case 0x7: // ROR
            b &= 31;
            c   = b ? (a>>(b-1))&1 : a>>31;
            res = b ? (a>>b)|(a<<(32-b)) : a;
            break;
        case 0x8: res = a & b; break; // TST (no writeback)
        case 0x9: // NEG
            res = 0 - b;
            setFlag(FLAG_C, b==0); setFlag(FLAG_V, subOverflow(0,b,res));
            break;
        case 0xA: { // CMP
            res = a - b;
            setFlag(FLAG_C,a>=b); setFlag(FLAG_V,subOverflow(a,b,res));
            setFlag(FLAG_N,res>>31); setFlag(FLAG_Z,res==0);
            return; // no writeback
        }
        case 0xB: { // CMN
            res = a + b;
            setFlag(FLAG_C,res<a); setFlag(FLAG_V,addOverflow(a,b,res));
            setFlag(FLAG_N,res>>31); setFlag(FLAG_Z,res==0);
            return;
        }
        case 0xC: res = a | b; break; // ORR
        case 0xD: res = a * b; break; // MUL
        case 0xE: res = a & ~b;break; // BIC
        case 0xF: res = ~b;    break; // MVN
    }

    setFlag(FLAG_N,res>>31); setFlag(FLAG_Z,res==0);
    if (op < 8 || op==0xC || op==0xD || op==0xE || op==0xF) setFlag(FLAG_C,c);
    if (op!=8) r[rd] = res;
    cycles += (op==0xD) ? 4 : 1;
}

// ── THUMB: Hi Register Operations / BX ───────────────────────────────────────
void ARM7TDMI::thumbHiRegOps(u16 i) {
    u32 op = (i>>8)&3;
    u32 h1 = (i>>7)&1, h2 = (i>>6)&1;
    u32 rs = ((i>>3)&7) | (h2<<3);
    u32 rd = (i&7)      | (h1<<3);
    u32 sv = r[rs]; if (rs==15) sv = PC();

    switch (op) {
        case 0: // ADD
            r[rd] += sv;
            if (rd==15) { PC() &= ~1u; cycles+=2; }
            break;
        case 1: { // CMP
            u32 res = r[rd] - sv;
            setFlag(FLAG_N,res>>31); setFlag(FLAG_Z,res==0);
            setFlag(FLAG_C,r[rd]>=sv); setFlag(FLAG_V,subOverflow(r[rd],sv,res));
            break;
        }
        case 2: // MOV
            r[rd] = sv;
            if (rd==15) { PC() &= ~1u; cycles+=2; }
            break;
        case 3: // BX
            if (sv & 1) { cpsr |= FLAG_T; PC() = sv & ~1u; }
            else        { cpsr &= ~FLAG_T; PC() = sv & ~3u; }
            cycles += 3;
            break;
    }
    cycles += 1;
}

// ── THUMB: PC-relative load ───────────────────────────────────────────────────
void ARM7TDMI::thumbPCRelLoad(u16 i) {
    u32 rd  = (i>>8)&7;
    u32 off = (i&0xFF) << 2;
    u32 base= (PC()) & ~3u;
    r[rd]   = read32(base + off);
    cycles += 3;
}

// ── THUMB: Load/Store register offset ────────────────────────────────────────
void ARM7TDMI::thumbLoadStoreReg(u16 i) {
    u32 op = (i>>10)&7;
    u32 ro = (i>>6)&7, rb=(i>>3)&7, rd=i&7;
    u32 addr = r[rb]+r[ro];
    switch (op) {
        case 0: write32(addr,r[rd]); break;            // STR
        case 1: write16(addr,r[rd]&0xFFFF); break;     // STRH
        case 2: write8(addr,r[rd]&0xFF); break;        // STRB
        case 3: r[rd]=(s32)(s8)read8(addr); break;     // LDSB
        case 4: r[rd]=read32(addr); break;             // LDR
        case 5: r[rd]=read16(addr); break;             // LDRH
        case 6: r[rd]=read8(addr); break;              // LDRB
        case 7: r[rd]=(s32)(s16)read16(addr); break;   // LDSH
    }
    cycles += 2;
}

// ── THUMB: Load/Store immediate offset ───────────────────────────────────────
void ARM7TDMI::thumbLoadStoreImm(u16 i) {
    bool byte = (i>>12)&1;
    bool load = (i>>11)&1;
    u32  off  = (i>>6)&31;
    u32  rb   = (i>>3)&7, rd = i&7;
    u32  addr = r[rb] + (byte ? off : off<<2);
    if (load) r[rd] = byte ? read8(addr) : read32(addr);
    else      byte  ? write8(addr,r[rd]&0xFF) : write32(addr,r[rd]);
    cycles += 2;
}

// ── THUMB: Load/Store halfword ────────────────────────────────────────────────
void ARM7TDMI::thumbLoadStoreHalf(u16 i) {
    bool load = (i>>11)&1;
    u32  off  = ((i>>6)&31)<<1;
    u32  rb   = (i>>3)&7, rd = i&7;
    u32  addr = r[rb]+off;
    if (load) r[rd]=read16(addr);
    else      write16(addr,r[rd]&0xFFFF);
    cycles += 2;
}

// ── THUMB: SP-relative load/store ────────────────────────────────────────────
void ARM7TDMI::thumbSPRelLoadStore(u16 i) {
    bool load = (i>>11)&1;
    u32  rd   = (i>>8)&7;
    u32  off  = (i&0xFF)<<2;
    u32  addr = r[13]+off;
    if (load) r[rd]=read32(addr);
    else      write32(addr,r[rd]);
    cycles += 2;
}

// ── THUMB: Load address ───────────────────────────────────────────────────────
void ARM7TDMI::thumbLoadAddress(u16 i) {
    bool sp = (i>>11)&1;
    u32  rd = (i>>8)&7;
    u32  off= (i&0xFF)<<2;
    r[rd]   = sp ? r[13]+off : (PC()&~3u)+off;
    cycles += 1;
}

// ── THUMB: Add offset to SP ───────────────────────────────────────────────────
void ARM7TDMI::thumbAddOffsetSP(u16 i) {
    bool neg = (i>>7)&1;
    u32  off = (i&0x7F)<<2;
    r[13] = neg ? r[13]-off : r[13]+off;
    cycles += 1;
}

// ── THUMB: Push/Pop ───────────────────────────────────────────────────────────
void ARM7TDMI::thumbPushPop(u16 i) {
    bool load = (i>>11)&1;
    bool pcLr = (i>>8)&1;
    u32  list = i & 0xFF;
    if (load) {
        for (int b=0;b<8;b++) if (list&(1<<b)) { r[b]=read32(r[13]); r[13]+=4; }
        if (pcLr) { PC()=read32(r[13])&~1u; r[13]+=4; cycles+=2; }
    } else {
        if (pcLr) { r[13]-=4; write32(r[13],r[14]); }
        for (int b=7;b>=0;b--) if (list&(1<<b)) { r[13]-=4; write32(r[13],r[b]); }
    }
    cycles += 2;
}

// ── THUMB: Multiple load/store ────────────────────────────────────────────────
void ARM7TDMI::thumbMultiLoadStore(u16 i) {
    bool load = (i>>11)&1;
    u32  rb   = (i>>8)&7;
    u32  list = i & 0xFF;
    u32  addr = r[rb];
    for (int b=0;b<8;b++) {
        if (!(list&(1<<b))) continue;
        if (load) r[b]=read32(addr);
        else      write32(addr,r[b]);
        addr += 4;
    }
    r[rb] = addr;
    cycles += 2;
}

// ── THUMB: Conditional branch ─────────────────────────────────────────────────
void ARM7TDMI::thumbConditionalBranch(u16 i) {
    u32 cond = (i>>8)&0xF;
    if (!checkCondition(cond)) { cycles+=1; return; }
    s32 off  = (s32)(s8)(i&0xFF) << 1;
    PC()    += off;
    cycles   += 3;
}

// ── THUMB: SWI ───────────────────────────────────────────────────────────────
void ARM7TDMI::thumbSWI(u16 i) {
    u32 swiNum = i & 0xFF;
    // Save return state
    u32 savedCpsr = cpsr;
    u32 savedPC   = PC(); // Thumb LR = PC of instruction after SWI
    spsr_svc = savedCpsr;
    r14_svc  = savedPC;
    switchMode(CpuMode::SVC);
    cpsr |= FLAG_I;
    cpsr &= ~FLAG_T;
    // HLE: execute BIOS function directly
    biosHLE(swiNum);
    // Return to Thumb caller
    cpsr = savedCpsr;
    PC() = savedPC; // already past the SWI instruction
    switchMode(static_cast<CpuMode>(savedCpsr & 0x1F));
}

// ── THUMB: Unconditional branch ───────────────────────────────────────────────
void ARM7TDMI::thumbUnconditionalBranch(u16 i) {
    s32 off = (s32)((i&0x7FF)<<21)>>20;
    PC() += off;
    cycles += 3;
}

// ── THUMB: Long branch with link ──────────────────────────────────────────────
void ARM7TDMI::thumbLongBranchLink(u16 i) {
    bool hi = !((i>>11)&1);
    if (hi) {
        // First instruction: LR = PC + (offset << 12)
        s32 off = (s32)((i&0x7FF)<<21)>>9;
        r[14] = PC() + off;
    } else {
        // Second instruction: PC = LR + (offset << 1), LR = PC | 1
        u32 tmp = PC() - 2;
        PC()    = (r[14] + ((i&0x7FF)<<1)) & ~1u;
        r[14]   = tmp | 1;
        cycles += 2;
    }
    cycles += 1;
}
