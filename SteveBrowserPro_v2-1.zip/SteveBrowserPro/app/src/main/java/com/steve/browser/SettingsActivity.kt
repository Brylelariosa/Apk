package com.steve.browser

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.view.View
import android.webkit.CookieManager
import android.webkit.WebStorage
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.steve.browser.databinding.ActivitySettingsBinding

class SettingsActivity : AppCompatActivity() {

    private lateinit var b: ActivitySettingsBinding
    private lateinit var prefs: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(b.root)
        prefs = getSharedPreferences(MainActivity.PREFS_NAME, Context.MODE_PRIVATE)

        b.backBtn.setOnClickListener { finish() }

        setupDataSaver()
        setupAdBlocker()
        setupProxy()
        setupClearData()
    }

    // ── Data Saver ────────────────────────────────────────────────────────────

    private fun setupDataSaver() {
        val level = DataSaverLevel.fromOrdinal(prefs.getInt(MainActivity.KEY_DATA_SAVER, 0))
        when (level) {
            DataSaverLevel.OFF    -> b.dsOff.isChecked    = true
            DataSaverLevel.LOW    -> b.dsLow.isChecked    = true
            DataSaverLevel.MEDIUM -> b.dsMedium.isChecked = true
            DataSaverLevel.HIGH   -> b.dsHigh.isChecked   = true
        }
        b.dataSaverGroup.setOnCheckedChangeListener { _, checkedId ->
            val newLevel = when (checkedId) {
                R.id.dsOff    -> DataSaverLevel.OFF
                R.id.dsLow    -> DataSaverLevel.LOW
                R.id.dsMedium -> DataSaverLevel.MEDIUM
                R.id.dsHigh   -> DataSaverLevel.HIGH
                else          -> DataSaverLevel.OFF
            }
            prefs.edit().putInt(MainActivity.KEY_DATA_SAVER, newLevel.ordinal).apply()
            Toast.makeText(this, "Data Saver: ${newLevel.label}", Toast.LENGTH_SHORT).show()
        }
    }

    // ── Ad Blocker ────────────────────────────────────────────────────────────

    private fun setupAdBlocker() {
        b.adBlockSwitch.isChecked = prefs.getBoolean(MainActivity.KEY_AD_BLOCK, true)
        b.adBlockSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(MainActivity.KEY_AD_BLOCK, checked).apply()
            Toast.makeText(this,
                if (checked) "Ad Blocker ON" else "Ad Blocker OFF",
                Toast.LENGTH_SHORT).show()
        }
    }

    // ── Proxy ─────────────────────────────────────────────────────────────────

    private fun setupProxy() {
        val host = prefs.getString(MainActivity.KEY_PROXY_HOST, "") ?: ""
        val port = prefs.getInt(MainActivity.KEY_PROXY_PORT, 8080)
        val proxyEnabled = host.isNotBlank()

        b.proxySwitch.isChecked = proxyEnabled
        b.proxyFieldsLayout.visibility = if (proxyEnabled) View.VISIBLE else View.GONE
        b.proxyHostInput.setText(host)
        b.proxyPortInput.setText(if (port > 0) port.toString() else "8080")

        b.proxySwitch.setOnCheckedChangeListener { _, checked ->
            b.proxyFieldsLayout.visibility = if (checked) View.VISIBLE else View.GONE
            if (!checked) {
                prefs.edit().putString(MainActivity.KEY_PROXY_HOST, "").apply()
                ProxyHelper.proxyHost = ""
                ProxyHelper.clear(this)
                Toast.makeText(this, "Proxy disabled", Toast.LENGTH_SHORT).show()
            }
        }

        b.saveProxyBtn.setOnClickListener {
            val newHost = b.proxyHostInput.text.toString().trim()
            val newPort = b.proxyPortInput.text.toString().toIntOrNull() ?: 8080
            if (newHost.isBlank()) {
                Toast.makeText(this, "Enter a proxy host", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            ProxyHelper.proxyHost = newHost
            ProxyHelper.proxyPort = newPort
            prefs.edit()
                .putString(MainActivity.KEY_PROXY_HOST, newHost)
                .putInt(MainActivity.KEY_PROXY_PORT, newPort)
                .apply()
            ProxyHelper.apply(this)
            Toast.makeText(this, "Proxy saved: $newHost:$newPort", Toast.LENGTH_SHORT).show()
        }
    }

    // ── Clear Data ────────────────────────────────────────────────────────────

    private fun setupClearData() {
        b.clearHistoryRow.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Clear History")
                .setMessage("Delete all browsing history?")
                .setPositiveButton("Clear") { _, _ ->
                    prefs.edit().remove(MainActivity.KEY_HISTORY).apply()
                    Toast.makeText(this, "History cleared", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        b.clearCookiesRow.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Clear Cookies & Cache")
                .setMessage("This will delete all cookies, cache and storage data.")
                .setPositiveButton("Clear") { _, _ ->
                    CookieManager.getInstance().removeAllCookies(null)
                    CookieManager.getInstance().flush()
                    WebStorage.getInstance().deleteAllData()
                    Toast.makeText(this, "Cookies & cache cleared", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }
}
