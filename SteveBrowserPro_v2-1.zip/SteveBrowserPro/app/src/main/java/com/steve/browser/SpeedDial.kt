package com.steve.browser

object SpeedDial {

    data class SpeedDialItem(
        val title: String,
        val url: String,
        val emoji: String,
        val color: String
    )

    val DEFAULT_DIALS = listOf(
        SpeedDialItem("Facebook", "https://www.facebook.com", "📘", "#1877F2"),
        SpeedDialItem("Free FB", "https://mbasic.facebook.com", "🆓", "#0066cc"),
        SpeedDialItem("YouTube", "https://m.youtube.com", "▶️", "#FF0000"),
        SpeedDialItem("Google", "https://www.google.com", "🔍", "#4285F4"),
        SpeedDialItem("Gmail", "https://mail.google.com", "📧", "#EA4335"),
        SpeedDialItem("TikTok", "https://www.tiktok.com", "🎵", "#010101"),
        SpeedDialItem("Twitter/X", "https://twitter.com", "🐦", "#1DA1F2"),
        SpeedDialItem("Shopee", "https://shopee.ph", "🛒", "#EE4D2D"),
        SpeedDialItem("Lazada", "https://www.lazada.com.ph", "🛍️", "#0F1464"),
        SpeedDialItem("Messenger", "https://m.me", "💬", "#0084FF"),
        SpeedDialItem("Instagram", "https://www.instagram.com", "📸", "#E1306C"),
        SpeedDialItem("WhatsApp", "https://web.whatsapp.com", "📱", "#25D366")
    )

    fun generateHtml(dials: List<SpeedDialItem> = DEFAULT_DIALS, isDarkMode: Boolean = true): String {
        val bg = if (isDarkMode) "#0d0d1a" else "#f0f2ff"
        val cardBg = if (isDarkMode) "#12122a" else "#ffffff"
        val textColor = if (isDarkMode) "#e8eaff" else "#1a1a2e"
        val subColor = if (isDarkMode) "#7788cc" else "#556699"

        val dialCards = dials.joinToString("") { dial ->
            """
            <a href="${dial.url}" class="dial-card" style="background:${cardBg}">
                <div class="dial-icon">${dial.emoji}</div>
                <div class="dial-title" style="color:${textColor}">${dial.title}</div>
            </a>
            """.trimIndent()
        }

        return """
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>New Tab — SteveBrowser</title>
<style>
  * { margin:0; padding:0; box-sizing:border-box; }
  body {
    background: ${bg};
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    min-height: 100vh;
    padding: 20px 12px;
  }
  .header {
    text-align: center;
    margin-bottom: 24px;
  }
  .header h1 {
    font-size: 22px;
    font-weight: 700;
    color: #7c6fff;
    letter-spacing: 1px;
  }
  .header p {
    font-size: 12px;
    color: ${subColor};
    margin-top: 4px;
  }
  .dials-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 12px;
    max-width: 460px;
    margin: 0 auto;
  }
  .dial-card {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 14px 6px 10px;
    border-radius: 14px;
    text-decoration: none;
    transition: transform 0.15s, box-shadow 0.15s;
    box-shadow: 0 2px 8px rgba(0,0,0,0.25);
    border: 1px solid rgba(124,111,255,0.15);
  }
  .dial-card:active { transform: scale(0.93); }
  .dial-icon { font-size: 28px; margin-bottom: 6px; }
  .dial-title {
    font-size: 10px;
    font-weight: 600;
    text-align: center;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    width: 100%;
  }
  .tip {
    text-align: center;
    margin-top: 20px;
    font-size: 11px;
    color: ${subColor};
    padding: 0 16px;
  }
</style>
</head>
<body>
  <div class="header">
    <h1>⚡ SteveBrowser</h1>
    <p>Tap a site to visit it</p>
  </div>
  <div class="dials-grid">
    $dialCards
  </div>
  <div class="tip">💡 Tap Free FB to browse Facebook using Dito free data</div>
</body>
</html>
        """.trimIndent()
    }
}
