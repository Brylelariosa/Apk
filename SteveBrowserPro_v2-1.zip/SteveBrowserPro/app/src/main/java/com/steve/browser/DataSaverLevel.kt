package com.steve.browser

/**
 * Data Saver levels — named by image quality (not saving amount).
 * Low Quality  = most data saved (images blocked)
 * High Quality = least data saved (cache only, all images load)
 */
enum class DataSaverLevel(val label: String, val description: String) {
    OFF(
        label       = "Off",
        description = "Normal browsing — full quality"
    ),
    LOW(
        label       = "Low Quality",
        description = "Block images & video — saves ~80%"
    ),
    MEDIUM(
        label       = "Medium Quality",
        description = "Block GIFs & large images — saves ~40%"
    ),
    HIGH(
        label       = "High Quality",
        description = "Cache-first loading — saves ~15%"
    );

    companion object {
        fun fromOrdinal(ord: Int) = entries.getOrElse(ord) { OFF }
    }

    val blockedMimes: Set<String> get() = when (this) {
        OFF    -> emptySet()
        LOW    -> setOf(
            "image/jpeg", "image/png", "image/gif", "image/webp",
            "image/svg+xml", "image/avif", "video/mp4", "video/webm",
            "video/ogg", "audio/mpeg", "audio/ogg"
        )
        MEDIUM -> setOf("image/gif", "video/mp4", "video/webm", "video/ogg")
        HIGH   -> emptySet()
    }

    val blockNetworkImages: Boolean get() = this == LOW

    val cacheMode: Int get() = when (this) {
        OFF  -> android.webkit.WebSettings.LOAD_DEFAULT
        else -> android.webkit.WebSettings.LOAD_CACHE_ELSE_NETWORK
    }

    val isActive: Boolean get() = this != OFF
}
