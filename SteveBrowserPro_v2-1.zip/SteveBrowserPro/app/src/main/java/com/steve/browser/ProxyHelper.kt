package com.steve.browser

import android.content.Context
import android.webkit.WebView
import java.lang.reflect.Method

/**
 * ProxyHelper — makes ALL WebView traffic go through a user-configured HTTP proxy.
 *
 * How "Free Internet via Facebook Promo" (Dito / Globe / Smart) actually works:
 * ─────────────────────────────────────────────────────────────────────────────
 * Carriers like Dito zero-rate certain hostnames (e.g. *.facebook.com).
 * Opera Mini routes its OWN compression proxy servers through those zero-rated
 * addresses — so even google.com or youtube.com loads for free because ALL
 * traffic goes:
 *
 *   Your phone  →  Proxy server (reachable via zero-rated host)  →  Any website
 *
 * To use this in SteveBrowser you need a proxy server whose address (host:port)
 * is reachable over the carrier's free/zero-rated data.  Common approaches:
 *
 *   • A VPS fronted behind a Facebook CDN hostname (SNI trick)
 *   • A public HTTP proxy injector endpoint (like HTTP Injector configs)
 *   • Port 80 via a zero-rated IP known for your promo (check forums like
 *     pinoytechtalk.com for updated Dito/Globe free internet proxies)
 *
 * Set proxyHost + proxyPort below (or let the user configure them in Settings).
 * When enabled, EVERY WebView request in the app goes through that proxy —
 * meaning any site works as long as the proxy is reachable for free.
 */
object ProxyHelper {

    var proxyHost: String = ""   // e.g. "proxy.example.com" or a known Dito free IP
    var proxyPort: Int    = 8080

    /**
     * Apply proxy to the whole app's WebView network stack.
     * Call this after changing proxyHost / proxyPort.
     */
    fun apply(context: Context, webView: WebView? = null) {
        if (proxyHost.isBlank()) return
        try {
            // 1. JVM system properties — affects HttpURLConnection & some WebView paths
            System.setProperty("http.proxyHost",  proxyHost)
            System.setProperty("http.proxyPort",  proxyPort.toString())
            System.setProperty("https.proxyHost", proxyHost)
            System.setProperty("https.proxyPort", proxyPort.toString())

            // 2. WebView internal network stack (Chromium) — reflection for API compat
            applyToChromium(context, webView)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /** Remove proxy — restore direct connection */
    fun clear(context: Context, webView: WebView? = null) {
        try {
            System.clearProperty("http.proxyHost")
            System.clearProperty("http.proxyPort")
            System.clearProperty("https.proxyHost")
            System.clearProperty("https.proxyPort")
            applyToChromium(context, null)  // null = no proxy
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun isConfigured() = proxyHost.isNotBlank() && proxyPort > 0

    // ─── Chromium / WebView internal proxy ───────────────────────────────────

    private fun applyToChromium(context: Context, webView: WebView?) {
        try {
            val applicationCls = Class.forName("android.app.Application")
            val loadedApkField = applicationCls.getDeclaredField("mLoadedApk")
            loadedApkField.isAccessible = true

            // Build proxy properties string
            val proxyProperties = if (webView != null && proxyHost.isNotBlank())
                buildProxyProperties() else null

            // Try the documented WebView proxy path first (API 21+)
            setWebViewProxy(context, proxyHost.takeIf { it.isNotBlank() } ?: "", proxyPort)
        } catch (e: Exception) {
            // Silently fall back to JVM system properties only
        }
    }

    @Suppress("UNCHECKED_CAST")
    private fun setWebViewProxy(context: Context, host: String, port: Int) {
        try {
            val clazz = Class.forName("android.webkit.WebViewDatabase")
            // Try reflection on the Network class used by Chromium
            val networkClass = Class.forName("android.net.webview.WebViewNetworkClient")
            val setProxy: Method = networkClass.getDeclaredMethod(
                "setProxyOverride", String::class.java, Int::class.java)
            setProxy.isAccessible = true
            setProxy.invoke(null, host, port)
        } catch (_: Exception) {
            // Not available on this ROM — JVM properties still apply
        }
    }

    private fun buildProxyProperties(): String {
        return "http=$proxyHost:$proxyPort;https=$proxyHost:$proxyPort"
    }
}
