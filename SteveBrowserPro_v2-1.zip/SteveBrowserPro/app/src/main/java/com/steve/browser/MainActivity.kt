package com.steve.browser

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.*
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.util.Base64
import android.view.*
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.steve.browser.databinding.ActivityMainBinding
import org.json.JSONArray
import org.json.JSONObject
import java.util.*

data class BrowserTab(
    val id: String = UUID.randomUUID().toString(),
    var title: String = "New Tab",
    var url: String = "about:blank",
    var isIncognito: Boolean = false
)

@SuppressLint("SetJavaScriptEnabled")
class MainActivity : AppCompatActivity() {

    companion object {
        const val HOME_URL       = "about:blank"
        const val PREFS_NAME     = "browser_prefs"
        const val KEY_BOOKMARKS  = "bookmarks"
        const val KEY_HISTORY    = "history"
        const val KEY_DATA_SAVER = "data_saver_level"
        const val KEY_AD_BLOCK   = "ad_block"
        const val KEY_PROXY_HOST = "proxy_host"
        const val KEY_PROXY_PORT = "proxy_port"
        const val MAX_HISTORY    = 200
        const val MAX_TABS       = 15
    }

    private lateinit var b: ActivityMainBinding
    private lateinit var prefs: SharedPreferences

    private var dataSaverLevel: DataSaverLevel = DataSaverLevel.OFF
    private var isAdBlockOn = true

    private var adsBlocked = 0
    private var dataSaved  = 0L

    private lateinit var tabAdapter: TabAdapter
    private val tabs     = mutableListOf<BrowserTab>()
    private val webViews = mutableMapOf<String, WebView>()
    private var currentTabId: String = ""

    private val currentTab     get() = tabs.find { it.id == currentTabId }
    private val currentWebView get() = webViews[currentTabId]

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

        loadPrefs()
        if (ProxyHelper.isConfigured()) ProxyHelper.apply(this)

        setupTabsRecycler()
        setupUrlBar()
        setupButtons()
        addNewTab()
    }

    override fun onResume() {
        super.onResume()
        currentWebView?.onResume()
        reloadPrefs()
    }

    private fun loadPrefs() {
        dataSaverLevel      = DataSaverLevel.fromOrdinal(prefs.getInt(KEY_DATA_SAVER, 0))
        isAdBlockOn         = prefs.getBoolean(KEY_AD_BLOCK, true)
        ProxyHelper.proxyHost = prefs.getString(KEY_PROXY_HOST, "") ?: ""
        ProxyHelper.proxyPort = prefs.getInt(KEY_PROXY_PORT, 8080)
    }

    private fun reloadPrefs() {
        val newLevel = DataSaverLevel.fromOrdinal(prefs.getInt(KEY_DATA_SAVER, 0))
        if (newLevel != dataSaverLevel) {
            dataSaverLevel = newLevel
            reapplyDataSaverToAll()
        }
        val newAdBlock = prefs.getBoolean(KEY_AD_BLOCK, true)
        if (newAdBlock != isAdBlockOn) {
            isAdBlockOn = newAdBlock
            if (isAdBlockOn) currentWebView?.reload()
        }
        ProxyHelper.proxyHost = prefs.getString(KEY_PROXY_HOST, "") ?: ""
        ProxyHelper.proxyPort = prefs.getInt(KEY_PROXY_PORT, 8080)
    }

    // ── Setup ─────────────────────────────────────────────────────────────────

    private fun setupTabsRecycler() {
        tabAdapter = TabAdapter(tabs,
            onTabClick = { switchToTab(it.id) },
            onTabClose = { closeTab(it.id) }
        )
        b.tabsRecycler.apply {
            layoutManager = LinearLayoutManager(
                this@MainActivity, LinearLayoutManager.HORIZONTAL, false)
            adapter = tabAdapter
        }
    }

    private fun setupUrlBar() {
        b.urlBar.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) {
                navigateTo(b.urlBar.text.toString().trim()); hideKeyboard(); true
            } else false
        }
        b.urlBar.setOnFocusChangeListener { _, hasFocus -> if (hasFocus) b.urlBar.selectAll() }
    }

    private fun setupButtons() {
        b.backButton.setOnClickListener    { if (currentWebView?.canGoBack()    == true) currentWebView?.goBack() }
        b.forwardButton.setOnClickListener { if (currentWebView?.canGoForward() == true) currentWebView?.goForward() }
        b.refreshButton.setOnClickListener {
            if (currentWebView?.progress == 100) currentWebView?.reload() else currentWebView?.stopLoading()
        }
        b.newTabButton.setOnClickListener { showNewTabOptions() }
        b.menuButton.setOnClickListener   { showMenu() }
    }

    // ── Navigation ────────────────────────────────────────────────────────────

    private fun navigateTo(input: String) {
        if (input.isEmpty()) return
        val url = when {
            input.startsWith("http://") || input.startsWith("https://") -> input
            input.matches(Regex("^[a-zA-Z0-9-]+(\\.[a-zA-Z]{2,})+(/.*)?$")) -> "https://$input"
            else -> "https://www.google.com/search?q=${Uri.encode(input)}"
        }
        currentWebView?.loadUrl(url)
    }

    // ── WebView Factory ───────────────────────────────────────────────────────

    @SuppressLint("SetJavaScriptEnabled")
    private fun createWebView(isIncognito: Boolean): WebView {
        val wv = WebView(this)
        wv.layoutParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)

        applyWebViewSettings(wv, isIncognito)

        if (isIncognito) CookieManager.getInstance().setAcceptCookie(false)
        else {
            CookieManager.getInstance().setAcceptCookie(true)
            CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true)
        }

        wv.webViewClient  = buildWebViewClient()
        wv.webChromeClient = buildWebChromeClient()
        wv.setDownloadListener(buildDownloadListener())
        return wv
    }

    private fun applyWebViewSettings(wv: WebView, isIncognito: Boolean) {
        wv.settings.apply {
            javaScriptEnabled               = true
            domStorageEnabled               = !isIncognito
            databaseEnabled                 = !isIncognito
            setSupportZoom(true)
            builtInZoomControls             = true
            displayZoomControls             = false
            useWideViewPort                 = true
            loadWithOverviewMode            = true
            setSupportMultipleWindows(true)
            mixedContentMode                = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            mediaPlaybackRequiresUserGesture = false
            blockNetworkImage               = dataSaverLevel.blockNetworkImages
            cacheMode                       = if (isIncognito) WebSettings.LOAD_NO_CACHE
                                              else dataSaverLevel.cacheMode
            userAgentString                 = standardUA()
        }
    }

    private fun reapplyDataSaverToAll() {
        webViews.values.forEach { wv ->
            wv.settings.blockNetworkImage = dataSaverLevel.blockNetworkImages
            wv.settings.cacheMode = dataSaverLevel.cacheMode
        }
    }

    private fun standardUA() =
        "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 " +
        "(KHTML, like Gecko) Chrome/124.0.6367.82 Mobile Safari/537.36"

    // ── WebViewClient ─────────────────────────────────────────────────────────

    private fun buildWebViewClient() = object : WebViewClient() {

        override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
            if (view != currentWebView) return
            b.progressBar.visibility = View.VISIBLE
            b.refreshButton.setImageResource(android.R.drawable.ic_menu_close_clear_cancel)
            b.urlBar.setText(url ?: "")
            currentTab?.url = url ?: ""
            updateNavButtons()
        }

        override fun onPageFinished(view: WebView, url: String?) {
            if (view != currentWebView) return
            b.progressBar.visibility = View.GONE
            b.refreshButton.setImageResource(android.R.drawable.ic_menu_rotate)
            url?.let {
                currentTab?.apply { this.url = it; this.title = view.title ?: it }
                tabAdapter.notifyDataSetChanged()
                if (currentTab?.isIncognito == false) addToHistory(it, view.title ?: it)
            }
            updateNavButtons()
            if (isAdBlockOn) injectAdHideCss(view)
        }

        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            val url = request.url.toString()
            if (!url.startsWith("http")) {
                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))); return true }
                catch (_: Exception) {}
            }
            return false
        }

        override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
            val url = request.url.toString()

            if (isAdBlockOn && AdBlocker.isAdUrl(url)) {
                adsBlocked++
                return emptyResponse()
            }

            if (dataSaverLevel.isActive) {
                val mime = mimeFromUrl(url)
                if (mime in dataSaverLevel.blockedMimes) {
                    dataSaved += estimatedSize(mime)
                    return emptyResponse()
                }
            }

            return super.shouldInterceptRequest(view, request)
        }
    }

    private fun buildWebChromeClient() = object : WebChromeClient() {
        override fun onProgressChanged(view: WebView, newProgress: Int) {
            if (view != currentWebView) return
            b.progressBar.progress = newProgress
            if (newProgress == 100) b.progressBar.visibility = View.GONE
        }
        override fun onReceivedTitle(view: WebView, title: String?) {
            val tabId = webViews.entries.find { it.value == view }?.key ?: return
            tabs.find { it.id == tabId }?.title = title ?: "New Tab"
            tabAdapter.notifyDataSetChanged()
        }
    }

    private fun buildDownloadListener() = DownloadListener { url, ua, cd, mime, _ ->
        try {
            val name = URLUtil.guessFileName(url, cd, mime)
            val req  = DownloadManager.Request(Uri.parse(url)).apply {
                setMimeType(mime); addRequestHeader("User-Agent", ua)
                setTitle(name); setDescription("Downloading $name")
                setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
            }
            (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
            Toast.makeText(this, "⬇️ Downloading: $name", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Download failed: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private fun emptyResponse() = WebResourceResponse("text/plain", "utf-8", "".byteInputStream())

    private fun mimeFromUrl(url: String) = when {
        url.contains(".jpg",  true) || url.contains(".jpeg", true) -> "image/jpeg"
        url.contains(".png",  true) -> "image/png"
        url.contains(".gif",  true) -> "image/gif"
        url.contains(".webp", true) -> "image/webp"
        url.contains(".svg",  true) -> "image/svg+xml"
        url.contains(".avif", true) -> "image/avif"
        url.contains(".mp4",  true) -> "video/mp4"
        url.contains(".webm", true) -> "video/webm"
        url.contains(".mp3",  true) -> "audio/mpeg"
        url.contains(".woff2",true) -> "font/woff2"
        url.contains(".woff", true) -> "font/woff"
        else -> "application/octet-stream"
    }

    private fun estimatedSize(mime: String): Long = when {
        mime.startsWith("image") -> 80_000L
        mime.startsWith("video") -> 500_000L
        mime.startsWith("font")  -> 30_000L
        else -> 5_000L
    }

    private fun injectAdHideCss(view: WebView) {
        val css = "[id*='ad'],[class*='ad-'],[class*='-ad'],[id*='banner'],[class*='banner']," +
                  "[id*='popup'],[class*='popup'],[id*='sponsor'],[class*='sponsor']," +
                  "ins.adsbygoogle,.adsbygoogle,#google_ads_iframe,.ad-container," +
                  ".advertisement,.ad-slot,.ad-unit,.ads-wrapper{display:none!important;" +
                  "visibility:hidden!important;height:0!important;}"
        val b64 = Base64.encodeToString(css.toByteArray(), Base64.NO_WRAP)
        view.evaluateJavascript(
            "try{var s=document.createElement('style');s.innerHTML=atob('$b64');" +
            "document.head&&document.head.appendChild(s);}catch(e){}", null)
    }

    // ── Tab Management ────────────────────────────────────────────────────────

    private fun addNewTab(isIncognito: Boolean = false, url: String = HOME_URL) {
        if (tabs.size >= MAX_TABS) {
            Toast.makeText(this, "Max $MAX_TABS tabs reached", Toast.LENGTH_SHORT).show(); return
        }
        val tab = BrowserTab(isIncognito = isIncognito, url = url)
        val wv  = createWebView(isIncognito)
        wv.visibility = View.GONE

        if (url == HOME_URL || url == "about:blank") {
            wv.loadDataWithBaseURL("https://stevebrowser.local",
                SpeedDial.generateHtml(), "text/html", "UTF-8", null)
        } else {
            wv.loadUrl(url)
        }

        tabs.add(tab); webViews[tab.id] = wv; b.webViewContainer.addView(wv)
        tabAdapter.notifyItemInserted(tabs.size - 1)
        switchToTab(tab.id); updateTabBadge()
    }

    private fun switchToTab(tabId: String) {
        currentWebView?.visibility = View.GONE
        currentTabId = tabId
        currentWebView?.visibility = View.VISIBLE
        currentTab?.let {
            b.urlBar.setText(it.url.takeIf { u -> u != "about:blank" } ?: "")
            b.incognitoBar.visibility = if (it.isIncognito) View.VISIBLE else View.GONE
        }
        updateNavButtons()
        val idx = tabs.indexOfFirst { it.id == tabId }
        if (idx >= 0) { tabAdapter.setSelected(idx); b.tabsRecycler.scrollToPosition(idx) }
    }

    private fun closeTab(tabId: String) {
        val idx = tabs.indexOfFirst { it.id == tabId }
        if (idx < 0) return
        webViews.remove(tabId).also { b.webViewContainer.removeView(it); it?.destroy() }
        tabs.removeAt(idx); tabAdapter.notifyItemRemoved(idx); updateTabBadge()
        if (tabs.isEmpty()) addNewTab()
        else switchToTab(tabs[(idx - 1).coerceAtLeast(0)].id)
    }

    // ── UI Updates ────────────────────────────────────────────────────────────

    private fun updateNavButtons() {
        val canBack = currentWebView?.canGoBack()    == true
        val canFwd  = currentWebView?.canGoForward() == true
        b.backButton.alpha    = if (canBack) 1f else 0.35f; b.backButton.isEnabled    = canBack
        b.forwardButton.alpha = if (canFwd)  1f else 0.35f; b.forwardButton.isEnabled = canFwd
    }

    private fun updateTabBadge() { b.tabCountBadge.text = tabs.size.toString() }

    // ── Menus ─────────────────────────────────────────────────────────────────

    private fun showNewTabOptions() {
        AlertDialog.Builder(this)
            .setTitle("Open New Tab")
            .setItems(arrayOf(
                "🌐  New Tab",
                "🕵️  Incognito Tab",
                "📘  Facebook",
                "🔍  Google Search"
            )) { _, which ->
                when (which) {
                    0 -> addNewTab()
                    1 -> addNewTab(isIncognito = true)
                    2 -> addNewTab(url = "https://www.facebook.com")
                    3 -> addNewTab(url = "https://www.google.com")
                }
            }.show()
    }

    private fun showMenu() {
        val popup = PopupMenu(this, b.menuButton)
        popup.menu.apply {
            add(0,1,0,"⭐  Add Bookmark");  add(0,2,0,"📚  Bookmarks")
            add(0,3,0,"🕐  History");       add(0,4,0,"📤  Share")
            add(0,5,0,"🏠  Home");          add(0,6,0,"📋  Copy URL")
            add(0,7,0,"🖥️  Desktop Site");  add(0,8,0,"📊  Stats")
            add(0,9,0,"⚙️  Settings")
        }
        popup.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> addBookmark(); 2 -> showBookmarks(); 3 -> showHistory()
                4 -> sharePage();   5 -> addNewTab();     6 -> copyUrl()
                7 -> toggleDesktop(); 8 -> showStats();   9 -> openSettings()
            }; true
        }
        popup.show()
    }

    private fun openSettings() {
        startActivity(Intent(this, SettingsActivity::class.java))
    }

    private fun showStats() {
        val savedKb = dataSaved / 1000
        AlertDialog.Builder(this)
            .setTitle("📊 Browser Stats")
            .setMessage(
                "🛡️ Ads Blocked:   $adsBlocked\n" +
                "💾 Data Saved:    ~${savedKb}KB\n" +
                "💾 Data Saver:    ${dataSaverLevel.label}\n" +
                "🛡️ Ad Blocker:    ${if (isAdBlockOn) "ON" else "OFF"}\n" +
                "🔀 Proxy:         ${if (ProxyHelper.isConfigured()) "${ProxyHelper.proxyHost}:${ProxyHelper.proxyPort}" else "None"}\n" +
                "🗂️ Open Tabs:     ${tabs.size}"
            )
            .setPositiveButton("OK", null)
            .setNeutralButton("Reset Stats") { _, _ -> adsBlocked = 0; dataSaved = 0L }
            .show()
    }

    // ── Bookmarks ─────────────────────────────────────────────────────────────

    private fun loadBookmarks(): MutableList<Pair<String,String>> = try {
        val arr = JSONArray(prefs.getString(KEY_BOOKMARKS, "[]"))
        MutableList(arr.length()) { arr.getJSONObject(it).run { getString("title") to getString("url") } }
    } catch (_: Exception) { mutableListOf() }

    private fun saveBookmarks(bm: List<Pair<String,String>>) {
        val arr = JSONArray()
        bm.forEach { (t,u) -> arr.put(JSONObject().apply { put("title",t); put("url",u) }) }
        prefs.edit().putString(KEY_BOOKMARKS, arr.toString()).apply()
    }

    private fun addBookmark() {
        val tab = currentTab ?: return
        val bm = loadBookmarks()
        if (bm.none { it.second == tab.url }) {
            val input = EditText(this).apply { setText(tab.title); selectAll() }
            AlertDialog.Builder(this).setTitle("Add Bookmark").setView(input)
                .setPositiveButton("Save") { _,_ ->
                    bm.add(input.text.toString().ifBlank { tab.title } to tab.url)
                    saveBookmarks(bm)
                    Toast.makeText(this, "⭐ Saved!", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Cancel", null).show()
        } else Toast.makeText(this, "Already bookmarked", Toast.LENGTH_SHORT).show()
    }

    private fun showBookmarks() {
        val bm = loadBookmarks()
        if (bm.isEmpty()) { Toast.makeText(this,"No bookmarks yet",Toast.LENGTH_SHORT).show(); return }
        AlertDialog.Builder(this).setTitle("Bookmarks (${bm.size})")
            .setItems(bm.map { "⭐ ${it.first}" }.toTypedArray()) { _,i -> navigateTo(bm[i].second) }
            .setNeutralButton("🗑 Clear") { _,_ ->
                AlertDialog.Builder(this).setMessage("Delete all bookmarks?")
                    .setPositiveButton("Delete") { _,_ -> saveBookmarks(emptyList()) }
                    .setNegativeButton("Cancel",null).show()
            }
            .setNegativeButton("Close", null).show()
    }

    // ── History ───────────────────────────────────────────────────────────────

    private fun loadHistory(): MutableList<Pair<String,String>> = try {
        val arr = JSONArray(prefs.getString(KEY_HISTORY, "[]"))
        MutableList(arr.length()) { arr.getJSONObject(it).run { getString("title") to getString("url") } }
    } catch (_: Exception) { mutableListOf() }

    private fun addToHistory(url: String, title: String) {
        if (url == HOME_URL || url == "about:blank") return
        val h = loadHistory().also { it.removeAll { e -> e.second == url } }
        h.add(0, title to url)
        val arr = JSONArray()
        h.take(MAX_HISTORY).forEach { (t,u) -> arr.put(JSONObject().apply { put("title",t); put("url",u) }) }
        prefs.edit().putString(KEY_HISTORY, arr.toString()).apply()
    }

    private fun showHistory() {
        val h = loadHistory()
        if (h.isEmpty()) { Toast.makeText(this,"No history",Toast.LENGTH_SHORT).show(); return }
        AlertDialog.Builder(this).setTitle("History (${h.size})")
            .setItems(h.map { "🕐 ${it.first}" }.toTypedArray()) { _,i -> navigateTo(h[i].second) }
            .setNeutralButton("🗑 Clear") { _,_ -> prefs.edit().remove(KEY_HISTORY).apply() }
            .setNegativeButton("Close", null).show()
    }

    // ── Utilities ─────────────────────────────────────────────────────────────

    private fun sharePage() {
        val tab = currentTab ?: return
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, tab.url)
            putExtra(Intent.EXTRA_SUBJECT, tab.title)
        }, "Share via"))
    }

    private fun copyUrl() {
        val url = currentTab?.url ?: return
        (getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager)
            .setPrimaryClip(android.content.ClipData.newPlainText("URL", url))
        Toast.makeText(this, "URL copied!", Toast.LENGTH_SHORT).show()
    }

    private var isDesktopSite = false
    private fun toggleDesktop() {
        isDesktopSite = !isDesktopSite
        currentWebView?.settings?.userAgentString = if (isDesktopSite)
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0.0.0 Safari/537.36"
        else standardUA()
        currentWebView?.reload()
        Toast.makeText(this, if (isDesktopSite) "🖥️ Desktop" else "📱 Mobile", Toast.LENGTH_SHORT).show()
    }

    private fun hideKeyboard() {
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(b.urlBar.windowToken, 0)
        b.urlBar.clearFocus()
    }

    // ── System ────────────────────────────────────────────────────────────────

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (currentWebView?.canGoBack() == true) currentWebView?.goBack()
        else { @Suppress("DEPRECATION") super.onBackPressed() }
    }

    override fun onPause()   { super.onPause();   currentWebView?.onPause() }
    override fun onDestroy() { webViews.values.forEach { it.destroy() }; super.onDestroy() }
}
