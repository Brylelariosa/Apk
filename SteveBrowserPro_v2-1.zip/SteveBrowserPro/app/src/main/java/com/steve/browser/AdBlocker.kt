package com.steve.browser

object AdBlocker {

    // Comprehensive ad/tracker domain blocklist
    private val BLOCKED_DOMAINS = setOf(
        // Google Ads
        "doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "google-analytics.com", "googletagmanager.com", "googletagservices.com",
        "adservice.google.com", "pagead2.googlesyndication.com",
        // Facebook/Meta Trackers
        "connect.facebook.net", "graph.facebook.com",
        // Major Ad Networks
        "ads.twitter.com", "ads.linkedin.com", "ads.yahoo.com",
        "advertising.com", "adbrite.com", "adcolony.com",
        "adform.net", "adnxs.com", "adroll.com", "adtech.de",
        "appnexus.com", "bing.com/ads", "casalemedia.com",
        "criteo.com", "criteo.net", "crwdcntrl.net",
        "demdex.net", "dotomi.com", "doublepimp.com",
        "everesttech.net", "eyeota.net", "flashtalking.com",
        "freewheel.tv", "gumgum.com", "imonomy.com",
        "imedia.com", "indexww.com", "innovid.com",
        "lijit.com", "liveramp.com", "lotame.com",
        "media.net", "mediaplex.com", "moatads.com",
        "mopub.com", "openx.net", "outbrain.com",
        "pubmatic.com", "quantserve.com", "realmedia.com",
        "revjet.com", "rfihub.com", "rlcdn.com",
        "rubiconproject.com", "scorecardresearch.com",
        "serving-sys.com", "sharethis.com", "sizmek.com",
        "smartadserver.com", "spotxchange.com", "springserve.com",
        "taboolasyndication.com", "taboola.com", "teads.tv",
        "tradedoubler.com", "tribalfusion.com", "turn.com",
        "tynt.com", "undertonenetworks.com", "undertone.com",
        "valueclick.com", "valueclick.net", "vibrantmedia.com",
        "xaxis.com", "yieldmanager.com", "zedo.com",
        // Trackers / Spyware
        "bluekai.com", "comscore.com", "doubleverify.com",
        "exelator.com", "idsync.rlcdn.com", "krux.com",
        "mathtag.com", "mxpnl.com", "mixpanel.com",
        "newrelic.com", "nr-data.net", "omtrdc.net",
        "pixel.quantserve.com", "rayjump.com", "sailthru.com",
        "segment.com", "segment.io", "tt.omtrdc.net",
        "visitorqueue.com", "wt-eu02.net",
        // Pop-up / Redirect Ads
        "popcash.net", "propellerads.com", "revcontent.com",
        "trafficjunky.net", "trafficleader.com",
        // Misc
        "ad.doubleclick.net", "cdn.adnxs.com", "pixel.facebook.com",
        "stats.g.doubleclick.net", "www.googleadservices.com"
    )

    fun shouldBlock(url: String): Boolean {
        val lower = url.lowercase()
        return BLOCKED_DOMAINS.any { domain -> lower.contains(domain) }
    }

    fun isAdUrl(url: String): Boolean {
        val lower = url.lowercase()
        // Block common ad URL patterns
        return lower.contains("/ads/") ||
               lower.contains("/ad/") ||
               lower.contains("adserver") ||
               lower.contains("ad-server") ||
               lower.contains("banner_ad") ||
               lower.contains("track.php") ||
               lower.contains("/pixel.gif") ||
               lower.contains("click_track") ||
               shouldBlock(lower)
    }
}
