#pragma once
#include <GLES3/gl3.h>
#include <vector>

class Renderer {
public:
    Renderer() = default;
    ~Renderer();

    bool init();
    void resize(int w, int h);
    void beginFrame();

    GLint  getMVPLoc()    const { return mvpLoc;    }
    GLuint getWorldProg() const { return worldProg; }

    void renderLoading(float sw, float sh, int frame);
    void renderHUD(
        float sw, float sh,
        float joyBaseX, float joyBaseY,
        float joyThumbX, float joyThumbY,
        bool  joyActive,
        float breakProgress,
        int   fps,
        int   renderDist,
        bool  settingsOpen,
        int   hotbarSel,
        const uint8_t* hotbarTypes
    );

private:
    // ── World rendering ───────────────────────────────────────────────────────
    GLuint worldProg = 0;
    GLint  mvpLoc    = -1;

    // ── HUD batch renderer ────────────────────────────────────────────────────
    // All HUD geometry is accumulated each frame into two CPU-side vectors
    // (triangles and lines), then flushed with exactly 2 GL draw calls.
    // This replaces the old ~260 submitAndDraw calls (1300 GL operations)
    // with 2, cutting HUD cost from ~15ms to ~0.1ms per frame.
    GLuint hudProg    = 0;
    GLuint hudVAO     = 0;
    GLuint hudVBO     = 0;
    GLint  hudOrthoLoc = -1;
    // Vertex format: x, y, r, g, b, a  (6 floats per vertex)
    // Color is per-vertex so all geometry can be batched without sorting by color.
    std::vector<float> hudTriBatch;   // triangle vertices  (6 floats each)
    std::vector<float> hudLineBatch;  // line vertices      (6 floats each)

    int screenW = 1, screenH = 1;

    static GLuint compileShader(GLenum type, const char* src);
    static GLuint linkProgram(GLuint vert, GLuint frag);

    // Batch helpers — append to CPU vectors, zero GL calls
    void batchLine  (float x0, float y0, float x1, float y1,
                     float r, float g, float b, float a = 1.f);
    void batchRect  (float x, float y, float w, float h,
                     float r, float g, float b, float a);
    void batchCircle(float cx, float cy, float radius,
                     float r, float g, float b, float a, bool filled);
    void batchArc   (float cx, float cy, float radius,
                     float startAngle, float endAngle,
                     float r, float g, float b, float a = 1.f);
    // Flush both batches — exactly 2 GL draw calls (triangles + lines)
    void flushHUD();

    // Stroke font helpers (append to hudLineBatch)
    void batchChar(char c, float x, float y, float scale,
                   float r, float g, float b, float a = 1.f);
    void batchText(const char* str, float x, float y, float scale,
                   float r, float g, float b, float a = 1.f);

    // 7-segment number (appends to hudLineBatch)
    void batchDigit (int digit, float x, float y, float scale,
                     float r, float g, float b, float a = 1.f);
    void batchNumber(int num, float x, float y, float scale,
                     float r, float g, float b, float a = 1.f);
};
