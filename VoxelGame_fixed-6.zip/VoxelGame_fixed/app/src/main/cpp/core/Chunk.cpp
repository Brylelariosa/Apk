#include "Chunk.h"
#include "BlockDefs.h"
#include <cstring>
#include <cmath>
#include <android/log.h>

#define LOG_TAG "VoxelChunk"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

Chunk::Chunk(int cx, int cz) : chunkX(cx), chunkZ(cz) {
    memset(blocks, 0, sizeof(blocks));
}

Chunk::~Chunk() {
    if (vao) glDeleteVertexArrays(1, &vao);
    if (vbo) glDeleteBuffers(1, &vbo);
    if (ebo) glDeleteBuffers(1, &ebo);
}

uint8_t Chunk::getBlock(int x, int y, int z) const {
    if (x<0||x>=CW||y<0||y>=CH||z<0||z>=CD) return 0;
    return blocks[bidx(x,y,z)];
}

void Chunk::setBlock(int x, int y, int z, uint8_t t) {
    if (x<0||x>=CW||y<0||y>=CH||z<0||z>=CD) return;
    blocks[bidx(x,y,z)] = t;
    // Update spans incrementally.
    // For colMaxY: if placing above current top, update directly.
    // If removing the top block, rescan the column (rare — only on break).
    uint8_t& top = colMaxY[x * CD + z];
    if (t != 0) {
        if (y > top) top = (uint8_t)y;
        yOccupied[y >> 6] |= (1ULL << (y & 63));
    } else {
        // Block removed — rescan this column and this Y slice
        uint8_t newTop = 0;
        for (int sy = 0; sy < CH; sy++)
            if (blocks[bidx(x,sy,z)] != 0 && sy > newTop) newTop = (uint8_t)sy;
        top = newTop;
        // Rescan the Y slice for occupancy
        bool anyInSlice = false;
        for (int sx = 0; sx < CW && !anyInSlice; sx++)
            for (int sz = 0; sz < CD && !anyInSlice; sz++)
                if (blocks[bidx(sx,y,sz)] != 0) anyInSlice = true;
        if (anyInSlice)
            yOccupied[y >> 6] |= (1ULL << (y & 63));
        else
            yOccupied[y >> 6] &= ~(1ULL << (y & 63));
    }
    dirty = true; gpuReady = false;
}


void Chunk::uploadMesh() {
    if (vertData.empty()) { indexCount=0; gpuReady=true; return; }

    if (!vao) {
        glGenVertexArrays(1, &vao);
        glGenBuffers(1, &vbo);
        glGenBuffers(1, &ebo);
    }

    glBindVertexArray(vao);

    glBindBuffer(GL_ARRAY_BUFFER, vbo);
    glBufferData(GL_ARRAY_BUFFER,
                 (GLsizeiptr)(vertData.size()*sizeof(float)),
                 vertData.data(), GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ebo);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER,
                 (GLsizeiptr)(idxData.size()*sizeof(uint32_t)),
                 idxData.data(), GL_STATIC_DRAW);

    const GLsizei stride = 7 * sizeof(float);
    // aPos   @ location 0
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0,3,GL_FLOAT,GL_FALSE,stride,(void*)0);
    // aColor @ location 1
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1,3,GL_FLOAT,GL_FALSE,stride,(void*)(3*sizeof(float)));
    // aLight @ location 2
    glEnableVertexAttribArray(2);
    glVertexAttribPointer(2,1,GL_FLOAT,GL_FALSE,stride,(void*)(6*sizeof(float)));

    glBindVertexArray(0);

    indexCount = (int)idxData.size();
    gpuReady   = true;

    // Free CPU-side data
    vertData.clear(); vertData.shrink_to_fit();
    idxData.clear();  idxData.shrink_to_fit();
}

void Chunk::render() const {
    if (!gpuReady || indexCount == 0) return;
    glBindVertexArray(vao);
    glDrawElements(GL_TRIANGLES, indexCount, GL_UNSIGNED_INT, nullptr);
    glBindVertexArray(0);
}

void Chunk::addQuad(int dim, int dir,
                    int faceSlice, int u0, int v0, int wu, int wv,
                    uint8_t blockType) {
    const BlockInfo& bi = BLOCKS[blockType];
    const bool isTop    = (dim==1 && dir== 1);
    const bool isBot    = (dim==1 && dir==-1);

    float r = isTop ? bi.tr : bi.r;
    float g = isTop ? bi.tg : bi.g;
    float b = isTop ? bi.tb : bi.b;

    float light = isTop  ? 1.00f :
                  isBot  ? 0.50f :
                  (dim==0)? 0.70f : 0.80f;
    if (bi.emissive) light = 1.0f;

    const int wx0 = chunkX * CW;
    const int wz0 = chunkZ * CD;

    struct C { int u, v; };
    C corners[4] = {{u0,v0},{u0+wu,v0},{u0+wu,v0+wv},{u0,v0+wv}};

    const uint32_t base = (uint32_t)(vertData.size() / 7);

    for (auto& c : corners) {
        float fx, fy, fz;
        switch(dim) {
            case 0: fx=(float)faceSlice; fy=(float)c.u; fz=(float)c.v; break;
            case 1: fx=(float)c.u;       fy=(float)faceSlice; fz=(float)c.v; break;
            default:fx=(float)c.u;       fy=(float)c.v; fz=(float)faceSlice; break;
        }
        fx += (float)wx0;
        fz += (float)wz0;
        vertData.push_back(fx);
        vertData.push_back(fy);
        vertData.push_back(fz);
        vertData.push_back(r);
        vertData.push_back(g);
        vertData.push_back(b);
        vertData.push_back(light);
    }

    bool normalWinding = (dir == 1) ^ (dim == 1);
    if (normalWinding) {
        idxData.push_back(base+0); idxData.push_back(base+1); idxData.push_back(base+2);
        idxData.push_back(base+0); idxData.push_back(base+2); idxData.push_back(base+3);
    } else {
        idxData.push_back(base+0); idxData.push_back(base+2); idxData.push_back(base+1);
        idxData.push_back(base+0); idxData.push_back(base+3); idxData.push_back(base+2);
    }
}
