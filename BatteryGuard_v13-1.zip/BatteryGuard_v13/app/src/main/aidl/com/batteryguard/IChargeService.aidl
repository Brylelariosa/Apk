package com.batteryguard;

interface IChargeService {
    /** Returns exit code of running the shell command. */
    int exec(String cmd);
}
