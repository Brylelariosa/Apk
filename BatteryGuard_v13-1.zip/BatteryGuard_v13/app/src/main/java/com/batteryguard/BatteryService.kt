package com.batteryguard

import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.media.RingtoneManager
import android.os.*
import androidx.core.app.NotificationCompat

class BatteryService : Service() {

    companion object {
        const val CHANNEL_PERSISTENT = "bg_persistent"
        const val CHANNEL_ALERT      = "bg_alert"
        const val NOTIF_PERSISTENT   = 1
        const val NOTIF_ALERT        = 2
        const val NOTIF_LOW_BATTERY  = 3
        const val ACTION_UPDATE_UI   = "com.batteryguard.UPDATE_UI"
        const val ACTION_SNOOZE      = "com.batteryguard.SNOOZE"
        private const val POLL_MS    = 5_000L
        private const val SNOOZE_MS  = 15 * 60 * 1_000L   // 15 minutes
    }

    private var batteryReceiver: BroadcastReceiver? = null
    private var lastAlertPercent  = -1
    private var lastLowAlertFired = false

    /** Elapsed-realtime timestamp until which high-threshold alerts are silenced. */
    @Volatile private var snoozedUntil = 0L

    private val handler = Handler(Looper.getMainLooper())
    private val pollRunnable = object : Runnable {
        override fun run() {
            tick()
            handler.postDelayed(this, POLL_MS)
        }
    }

    // ── Lifecycle ──────────────────────────────────────────────────────────────

    override fun onCreate() {
        super.onCreate()
        // Immediately mark the service as running so BootReceiver and UI are correct
        prefs().edit().putBoolean("service_running", true).apply()

        createChannels()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIF_PERSISTENT,
                buildPersistentNotif(getString(R.string.notif_monitoring), 0),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_PERSISTENT,
                buildPersistentNotif(getString(R.string.notif_monitoring), 0))
        }
        registerBatteryReceiver()
        handler.post(pollRunnable)

        // Verify root via real exec (runs on background executor, result cached)
        ChargingController.verifyRootInBackground()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_SNOOZE) {
            snoozedUntil = SystemClock.elapsedRealtime() + SNOOZE_MS
            // Dismiss the alert notification that carried the snooze button
            getSystemService(NotificationManager::class.java).cancel(NOTIF_ALERT)
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(pollRunnable)
        batteryReceiver?.let { unregisterReceiver(it) }
        // Mark stopped so the pill and BootReceiver both know the service is down
        prefs().edit().putBoolean("service_running", false).apply()
    }

    // ── Core poll loop ─────────────────────────────────────────────────────────

    private fun tick() {
        val info      = PowerReader.read(this)
        val prefs     = prefs()
        val threshold    = prefs.getInt("threshold",     100)
        val lowThreshold = prefs.getInt("low_threshold",  20)

        // Update persistent notification
        val wStr      = if (info.watts >= 0.05) " · ${info.wattsStr}" else ""
        val statusStr = if (info.isCharging) "Charging" else "On Battery"
        updatePersistentNotif("${info.percent}%  ·  $statusStr$wStr", info.percent)
        sendBroadcast(Intent(ACTION_UPDATE_UI))

        // ── High threshold (charging-stop) alert ──
        val isSnoozed = SystemClock.elapsedRealtime() < snoozedUntil
        if (!isSnoozed &&
            info.isCharging &&
            info.percent >= threshold &&
            lastAlertPercent != info.percent) {

            lastAlertPercent = info.percent
            // disableCharging runs on its own background executor; post result back to main thread
            ChargingController.disableCharging { success ->
                handler.post {
                    val wattStr = if (info.watts >= 0.05) " (${info.wattsStr})" else ""
                    if (success) {
                        sendHighAlert(
                            getString(R.string.alert_stopped_title, info.percent, wattStr),
                            getString(R.string.alert_stopped_body),
                            loud = false
                        )
                    } else if (ChargingController.availableMethod() == ChargingController.Method.NONE) {
                        sendHighAlert(
                            getString(R.string.alert_unplug_title, info.percent, wattStr),
                            getString(R.string.alert_unplug_body),
                            loud = true
                        )
                    } else {
                        sendHighAlert(
                            getString(R.string.alert_failed_title, info.percent),
                            getString(R.string.alert_failed_body),
                            loud = true
                        )
                    }
                }
            }
        } else if (!info.isCharging && info.percent < threshold - 5 && lastAlertPercent != -1) {
            lastAlertPercent = -1
            ChargingController.enableCharging()
        }

        // ── Low battery alert ──
        if (!info.isCharging && info.percent <= lowThreshold && !lastLowAlertFired) {
            lastLowAlertFired = true
            sendLowBatteryAlert(info.percent)
        } else if (info.percent > lowThreshold + 5) {
            // Reset once the battery is meaningfully above the threshold again
            lastLowAlertFired = false
        }
    }

    // ── Receiver ──────────────────────────────────────────────────────────────

    private fun registerBatteryReceiver() {
        batteryReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                handler.removeCallbacks(pollRunnable)
                tick()
                handler.postDelayed(pollRunnable, POLL_MS)
            }
        }
        registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    }

    // ── Notification helpers ───────────────────────────────────────────────────

    private fun createChannels() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_PERSISTENT,
                getString(R.string.notif_channel_persistent_name),
                NotificationManager.IMPORTANCE_LOW)
                .apply { description = getString(R.string.notif_channel_persistent_desc) }
        )
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ALERT,
                getString(R.string.notif_channel_alert_name),
                NotificationManager.IMPORTANCE_HIGH)
                .apply {
                    description = getString(R.string.notif_channel_alert_desc)
                    enableVibration(true)
                    vibrationPattern = longArrayOf(0, 400, 150, 400, 150, 400)
                }
        )
    }

    private fun buildPersistentNotif(text: String, progress: Int): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_PERSISTENT)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentIntent(pi)
            .setOngoing(true)
            .setSilent(true)
            .setProgress(100, progress, false)
            .build()
    }

    private fun updatePersistentNotif(text: String, progress: Int) {
        getSystemService(NotificationManager::class.java)
            .notify(NOTIF_PERSISTENT, buildPersistentNotif(text, progress))
    }

    /**
     * Sends a high-threshold (charging stop / unplug) alert.
     * When [loud] is true a snooze action is attached so the user can silence
     * future alerts for 15 minutes without opening the app.
     */
    private fun sendHighAlert(title: String, body: String, loud: Boolean) {
        val tapPi = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(this, CHANNEL_ALERT)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setSmallIcon(R.drawable.ic_notif)
            .setContentIntent(tapPi)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)

        if (loud) {
            val sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            builder.setSound(sound)
            builder.setVibrate(longArrayOf(0, 600, 200, 600, 200, 600))

            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                (getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
            } else {
                @Suppress("DEPRECATION") getSystemService(VIBRATOR_SERVICE) as Vibrator
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(
                    VibrationEffect.createWaveform(longArrayOf(0, 600, 200, 600), -1))
            }

            // Snooze action — routes back through onStartCommand
            val snoozePi = PendingIntent.getService(
                this, 0,
                Intent(this, BatteryService::class.java).apply { action = ACTION_SNOOZE },
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            builder.addAction(
                NotificationCompat.Action(0, getString(R.string.btn_snooze), snoozePi)
            )
        }

        getSystemService(NotificationManager::class.java).notify(NOTIF_ALERT, builder.build())
    }

    /** Sends a low-battery warning notification. */
    private fun sendLowBatteryAlert(percent: Int) {
        val tapPi = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_IMMUTABLE
        )
        val title = getString(R.string.alert_low_battery_title, percent)
        val body  = getString(R.string.alert_low_battery_body)
        val notif = NotificationCompat.Builder(this, CHANNEL_ALERT)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setSmallIcon(R.drawable.ic_notif)
            .setContentIntent(tapPi)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_STATUS)
            .build()
        getSystemService(NotificationManager::class.java).notify(NOTIF_LOW_BATTERY, notif)
    }

    private fun prefs() = getSharedPreferences("settings", MODE_PRIVATE)
}
