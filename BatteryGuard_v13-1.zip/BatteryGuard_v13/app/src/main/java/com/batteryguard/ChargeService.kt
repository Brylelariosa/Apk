package com.batteryguard

import android.util.Log

/**
 * This class is instantiated by Shizuku inside the privileged shell user process.
 * It implements IChargeService so callers can exec shell commands with elevated privileges.
 */
class ChargeService : IChargeService.Stub() {

    companion object {
        // Passed to Shizuku.bindUserService — tells Shizuku which class to instantiate
        val ARGS = rikka.shizuku.Shizuku.UserServiceArgs(
            android.content.ComponentName("com.batteryguard", ChargeService::class.java.name)
        )
            .daemon(false)
            .processNameSuffix("charge_service")
            .debuggable(false)
            .version(1)
    }

    override fun exec(cmd: String): Int {
        return try {
            val p = Runtime.getRuntime().exec(arrayOf("sh", "-c", cmd))
            p.waitFor()
        } catch (e: Exception) {
            Log.e("ChargeService", "exec failed: ${e.message}")
            -1
        }
    }
}
