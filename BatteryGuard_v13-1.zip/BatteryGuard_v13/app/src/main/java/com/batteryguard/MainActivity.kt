package com.batteryguard

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.batteryguard.databinding.ActivityMainBinding
import rikka.shizuku.Shizuku

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val shizukuPermissionListener = Shizuku.OnRequestPermissionResultListener { _, result ->
        if (result == PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, getString(R.string.toast_shizuku_authorized), Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, getString(R.string.toast_shizuku_denied), Toast.LENGTH_SHORT).show()
        }
        refreshPrivilegeCard()
    }

    private val uiReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            refreshBatteryCard()
            refreshPrivilegeCard()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        Shizuku.addRequestPermissionResultListener(shizukuPermissionListener)

        requestNotifPermission()
        setupThresholdSlider()
        setupLowThresholdSlider()
        setupButtons()
        refreshBatteryCard()
        refreshPrivilegeCard()
        refreshServiceState()
    }

    override fun onResume() {
        super.onResume()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(uiReceiver, IntentFilter(BatteryService.ACTION_UPDATE_UI), RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(uiReceiver, IntentFilter(BatteryService.ACTION_UPDATE_UI))
        }
        refreshBatteryCard()
        refreshPrivilegeCard()
        refreshServiceState()
    }

    override fun onPause() {
        super.onPause()
        try { unregisterReceiver(uiReceiver) } catch (_: Exception) {}
    }

    override fun onDestroy() {
        super.onDestroy()
        Shizuku.removeRequestPermissionResultListener(shizukuPermissionListener)
    }

    // ── Button setup ──────────────────────────────────────────────────────────

    private fun setupButtons() {
        binding.btnToggleService.setOnClickListener {
            val running = prefs().getBoolean("service_running", false)
            if (running) stopGuard() else startGuard()
        }
        binding.btnShizuku.setOnClickListener {
            when {
                !ChargingController.isShizukuAvailable() -> {
                    Toast.makeText(this,
                        getString(R.string.toast_shizuku_not_running),
                        Toast.LENGTH_LONG).show()
                }
                ChargingController.isShizukuGranted() -> {
                    Toast.makeText(this,
                        getString(R.string.toast_shizuku_already_authorized),
                        Toast.LENGTH_SHORT).show()
                }
                else -> {
                    Shizuku.requestPermission(1001)
                }
            }
        }
    }

    private fun startGuard() {
        val i = Intent(this, BatteryService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i)
        else startService(i)
        prefs().edit().putBoolean("service_running", true).apply()
        refreshServiceState()
        Toast.makeText(this, getString(R.string.toast_service_started), Toast.LENGTH_SHORT).show()
    }

    private fun stopGuard() {
        stopService(Intent(this, BatteryService::class.java))
        prefs().edit().putBoolean("service_running", false).apply()
        refreshServiceState()
        Toast.makeText(this, getString(R.string.toast_service_stopped), Toast.LENGTH_SHORT).show()
    }

    // ── Sliders ───────────────────────────────────────────────────────────────

    /** High threshold slider: range 50–100 %, seekbar max = 50. */
    private fun setupThresholdSlider() {
        val saved = prefs().getInt("threshold", 100)
        binding.seekbarThreshold.progress = saved - 50
        binding.tvThresholdValue.text = "$saved%"
        binding.seekbarThreshold.setOnSeekBarChangeListener(
            object : android.widget.SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: android.widget.SeekBar?, p: Int, u: Boolean) {
                    val t = 50 + p
                    binding.tvThresholdValue.text = "$t%"
                    prefs().edit().putInt("threshold", t).apply()
                }
                override fun onStartTrackingTouch(sb: android.widget.SeekBar?) {}
                override fun onStopTrackingTouch(sb: android.widget.SeekBar?) {}
            })
    }

    /** Low-battery alert slider: range 10–50 %, seekbar max = 40. */
    private fun setupLowThresholdSlider() {
        val saved = prefs().getInt("low_threshold", 20)
        binding.seekbarLowThreshold.progress = saved - 10
        binding.tvLowThresholdValue.text = "$saved%"
        binding.seekbarLowThreshold.setOnSeekBarChangeListener(
            object : android.widget.SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: android.widget.SeekBar?, p: Int, u: Boolean) {
                    val t = 10 + p
                    binding.tvLowThresholdValue.text = "$t%"
                    prefs().edit().putInt("low_threshold", t).apply()
                }
                override fun onStartTrackingTouch(sb: android.widget.SeekBar?) {}
                override fun onStopTrackingTouch(sb: android.widget.SeekBar?) {}
            })
    }

    // ── Card refresh ──────────────────────────────────────────────────────────

    private fun refreshBatteryCard() {
        val info = PowerReader.read(this)

        binding.tvBatteryPercent.text = "${info.percent}%"
        binding.progressBattery.progress = info.percent

        val colorRes = when {
            info.percent >= 80 -> android.R.color.holo_green_light
            info.percent >= 40 -> android.R.color.holo_orange_light
            else               -> android.R.color.holo_red_light
        }
        val color = ContextCompat.getColor(this, colorRes)
        binding.tvBatteryPercent.setTextColor(color)
        binding.progressBattery.progressTintList =
            android.content.res.ColorStateList.valueOf(color)

        binding.tvChargingStatus.text = when {
            info.isCharging && info.percent >= 100 -> "🔋 Full"
            info.isCharging                         -> "⚡ Charging"
            else                                    -> "🔋 On Battery"
        }

        binding.tvWatts.text = when {
            info.isCharging && info.watts >= 0.05 ->
                "▲ ${info.wattsStr}  ·  ${info.currentStr}  ·  ${info.voltageStr}"
            !info.isCharging && info.watts >= 0.05 ->
                "▼ ${info.wattsStr}  ·  ${info.currentStr}  ·  ${info.voltageStr}"
            else -> info.voltageStr
        }
    }

    private fun refreshPrivilegeCard() {
        val method       = ChargingController.availableMethod()
        val shizukuAvail = ChargingController.isShizukuAvailable()

        when (method) {
            ChargingController.Method.ROOT -> {
                binding.tvPrivilegeStatus.text = getString(R.string.privilege_root)
                binding.tvPrivilegeStatus.setTextColor(
                    ContextCompat.getColor(this, android.R.color.holo_green_light))
                binding.btnShizuku.visibility = View.GONE
            }
            ChargingController.Method.SHIZUKU -> {
                binding.tvPrivilegeStatus.text = getString(R.string.privilege_shizuku)
                binding.tvPrivilegeStatus.setTextColor(
                    ContextCompat.getColor(this, android.R.color.holo_green_light))
                binding.btnShizuku.visibility = View.GONE
            }
            ChargingController.Method.NONE -> {
                if (shizukuAvail) {
                    binding.tvPrivilegeStatus.text = getString(R.string.privilege_shizuku_needs_auth)
                    binding.tvPrivilegeStatus.setTextColor(
                        ContextCompat.getColor(this, android.R.color.holo_orange_light))
                    binding.btnShizuku.text = getString(R.string.btn_how_to_authorize)
                } else {
                    binding.tvPrivilegeStatus.text = getString(R.string.privilege_none)
                    binding.tvPrivilegeStatus.setTextColor(
                        ContextCompat.getColor(this, android.R.color.holo_red_light))
                    binding.btnShizuku.text = getString(R.string.btn_setup_shizuku)
                }
                binding.btnShizuku.visibility = View.VISIBLE
            }
        }
    }

    private fun refreshServiceState() {
        val running = prefs().getBoolean("service_running", false)

        // Status pill text + dot color
        binding.tvServiceStatus.text = if (running)
            getString(R.string.status_active) else getString(R.string.status_stopped)

        val statusColor = if (running)
            ContextCompat.getColor(this, android.R.color.holo_green_light)
        else
            ContextCompat.getColor(this, android.R.color.holo_red_light)
        binding.tvServiceStatus.setTextColor(statusColor)

        // Redraw the dot with the correct color (create a new drawable to avoid shared-state issues)
        val dotDrawable = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(statusColor)
        }
        binding.viewStatusDot.background = dotDrawable

        // Toggle button label + tint
        if (running) {
            binding.btnToggleService.text = getString(R.string.btn_stop_protection)
            binding.btnToggleService.backgroundTintList =
                android.content.res.ColorStateList.valueOf(0xFFB91C1C.toInt())
        } else {
            binding.btnToggleService.text = getString(R.string.btn_start_protection)
            binding.btnToggleService.backgroundTintList =
                android.content.res.ColorStateList.valueOf(0xFF059669.toInt())
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private fun prefs() = getSharedPreferences("settings", MODE_PRIVATE)

    private fun requestNotifPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
    }
}
