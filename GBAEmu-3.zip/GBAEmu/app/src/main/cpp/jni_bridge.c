/* jni_bridge.c
 * Bridges Android/Java ↔ mGBA C core.
 * All emulation runs on a dedicated high-priority native thread.
 */
#include <jni.h>
#include <android/log.h>
#include <android/native_window.h>
#include <android/native_window_jni.h>
#include <EGL/egl.h>
#include <GLES2/gl2.h>
#include <OPENSLES/OpenSLES.h>
#include <OPENSLES/OpenSLES_Android.h>
#include <pthread.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/prctl.h>
#include <sched.h>

#include <mgba/core/core.h>
#include <mgba/core/log.h>
#include <mgba/gba/core.h>
#include <mgba/internal/gba/gba.h>
#include <mgba/internal/gba/sio.h>
#include <mgba/internal/gba/video.h>
#include <mgba/internal/arm/arm.h>
#include <mgba-util/vfs.h>

#include "lan_sio_driver.h"
#include "audio_ring.h"

#define LOG_TAG "GBAEmu"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

/* ── GBA screen dimensions ─────────────────────────────────────────────── */
#define GBA_WIDTH  240
#define GBA_HEIGHT 160

/* ── Emulator state ────────────────────────────────────────────────────── */
typedef struct {
    struct mCore*   core;
    struct VFile*   romVf;
    struct VFile*   saveVf;

    /* Threading */
    pthread_t       emuThread;
    pthread_mutex_t mutex;
    pthread_cond_t  cond;
    volatile int    running;
    volatile int    paused;
    volatile int    framePending;

    /* Input - 16-bit GBA key mask */
    volatile uint16_t keys;

    /* Pixel buffer for software renderer */
    uint32_t  framebuf[GBA_WIDTH * GBA_HEIGHT];

    /* EGL rendering */
    ANativeWindow* window;
    EGLDisplay     display;
    EGLSurface     surface;
    EGLContext     context;
    GLuint         texId;
    GLuint         prog;
    GLuint         vbo;

    /* Audio ring buffer */
    AudioRing  audioRing;
    SLObjectItf slEngine;
    SLObjectItf slOutputMix;
    SLObjectItf slPlayer;
    SLPlayItf   slPlay;
    SLAndroidSimpleBufferQueueItf slQueue;

    /* LAN SIO driver */
    LanSIODriver lanDriver;

    /* Save path */
    char savePath[512];
} EmuState;

static EmuState g_emu;

/* ─── OpenGL helpers ──────────────────────────────────────────────────── */
static const char* VERT_SRC =
    "attribute vec2 aPos;\n"
    "attribute vec2 aUV;\n"
    "varying vec2 vUV;\n"
    "void main(){gl_Position=vec4(aPos,0,1);vUV=aUV;}\n";

static const char* FRAG_SRC =
    "precision mediump float;\n"
    "varying vec2 vUV;\n"
    "uniform sampler2D uTex;\n"
    "void main(){gl_FragColor=texture2D(uTex,vUV);}\n";

static GLuint compileShader(GLenum type, const char* src) {
    GLuint s = glCreateShader(type);
    glShaderSource(s, 1, &src, NULL);
    glCompileShader(s);
    return s;
}

static void initGL(EmuState* e) {
    GLuint vs = compileShader(GL_VERTEX_SHADER,   VERT_SRC);
    GLuint fs = compileShader(GL_FRAGMENT_SHADER, FRAG_SRC);
    e->prog = glCreateProgram();
    glAttachShader(e->prog, vs);
    glAttachShader(e->prog, fs);
    glLinkProgram(e->prog);
    glDeleteShader(vs);
    glDeleteShader(fs);

    glGenTextures(1, &e->texId);
    glBindTexture(GL_TEXTURE_2D, e->texId);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, GBA_WIDTH, GBA_HEIGHT,
                 0, GL_RGBA, GL_UNSIGNED_BYTE, NULL);

    /* Full-screen quad */
    static const float verts[] = {
        -1,-1, 0,1,
         1,-1, 1,1,
        -1, 1, 0,0,
         1, 1, 1,0,
    };
    glGenBuffers(1, &e->vbo);
    glBindBuffer(GL_ARRAY_BUFFER, e->vbo);
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW);
}

static void renderFrame(EmuState* e) {
    if (!e->surface || e->surface == EGL_NO_SURFACE) return;

    glBindTexture(GL_TEXTURE_2D, e->texId);
    glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, GBA_WIDTH, GBA_HEIGHT,
                    GL_RGBA, GL_UNSIGNED_BYTE, e->framebuf);

    glUseProgram(e->prog);
    glBindBuffer(GL_ARRAY_BUFFER, e->vbo);

    GLint pos = glGetAttribLocation(e->prog, "aPos");
    GLint uv  = glGetAttribLocation(e->prog, "aUV");
    glEnableVertexAttribArray(pos);
    glEnableVertexAttribArray(uv);
    glVertexAttribPointer(pos, 2, GL_FLOAT, GL_FALSE, 4*4, (void*)0);
    glVertexAttribPointer(uv,  2, GL_FLOAT, GL_FALSE, 4*4, (void*)(2*4));

    glUniform1i(glGetUniformLocation(e->prog, "uTex"), 0);
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);

    eglSwapBuffers(e->display, e->surface);
}

/* ─── Audio callback ─────────────────────────────────────────────────── */
static int16_t g_audioBuf[2][1470]; /* ~2 frames of 16-bit stereo @ 32768 Hz */
static int     g_audioBufIdx = 0;

static void audioCallback(SLAndroidSimpleBufferQueueItf bq, void* ctx) {
    EmuState* e = (EmuState*)ctx;
    int16_t* buf = g_audioBuf[g_audioBufIdx ^ 1];
    size_t samples = audioRingRead(&e->audioRing, buf, 735);
    if (samples < 735) memset(buf + samples*2, 0, (735 - samples) * 4);
    (*bq)->Enqueue(bq, buf, 735 * 4);
    g_audioBufIdx ^= 1;
}

static void initAudio(EmuState* e) {
    audioRingInit(&e->audioRing, 8192);

    SLEngineItf eng;
    slCreateEngine(&e->slEngine, 0, NULL, 0, NULL, NULL);
    (*e->slEngine)->Realize(e->slEngine, SL_BOOLEAN_FALSE);
    (*e->slEngine)->GetInterface(e->slEngine, SL_IID_ENGINE, &eng);

    SLInterfaceID ids[] = { SL_IID_VOLUME };
    SLboolean reqs[]    = { SL_BOOLEAN_FALSE };
    (*eng)->CreateOutputMix(eng, &e->slOutputMix, 1, ids, reqs);
    (*e->slOutputMix)->Realize(e->slOutputMix, SL_BOOLEAN_FALSE);

    SLDataLocator_AndroidSimpleBufferQueue bqLoc = {
        SL_DATALOCATOR_ANDROIDSIMPLEBUFFERQUEUE, 2
    };
    SLDataFormat_PCM fmt = {
        SL_DATAFORMAT_PCM, 2, SL_SAMPLINGRATE_32,
        SL_PCMSAMPLEFORMAT_FIXED_16, SL_PCMSAMPLEFORMAT_FIXED_16,
        SL_SPEAKER_FRONT_LEFT | SL_SPEAKER_FRONT_RIGHT,
        SL_BYTEORDER_LITTLEENDIAN
    };
    SLDataSource audioSrc = { &bqLoc, &fmt };
    SLDataLocator_OutputMix outLoc = { SL_DATALOCATOR_OUTPUTMIX, e->slOutputMix };
    SLDataSink audioSink = { &outLoc, NULL };

    SLInterfaceID pIds[] = { SL_IID_ANDROIDSIMPLEBUFFERQUEUE };
    SLboolean pReqs[]    = { SL_BOOLEAN_TRUE };
    (*eng)->CreateAudioPlayer(eng, &e->slPlayer, &audioSrc, &audioSink, 1, pIds, pReqs);
    (*e->slPlayer)->Realize(e->slPlayer, SL_BOOLEAN_FALSE);
    (*e->slPlayer)->GetInterface(e->slPlayer, SL_IID_PLAY, &e->slPlay);
    (*e->slPlayer)->GetInterface(e->slPlayer, SL_IID_ANDROIDSIMPLEBUFFERQUEUE, &e->slQueue);

    (*e->slQueue)->RegisterCallback(e->slQueue, audioCallback, e);
    (*e->slPlay)->SetPlayState(e->slPlay, SL_PLAYSTATE_PLAYING);

    /* Prime the queue */
    memset(g_audioBuf[0], 0, sizeof(g_audioBuf[0]));
    (*e->slQueue)->Enqueue(e->slQueue, g_audioBuf[0], 735 * 4);
}

/* ─── mGBA callbacks ─────────────────────────────────────────────────── */
static void coreVideoFrame(struct mCoreCallbacks* cb) {
    EmuState* e = (EmuState*)cb->context;
    renderFrame(e);
}

static int32_t coreAudioRate(struct mCoreCallbacks* cb) {
    (void)cb;
    return 32768;
}

/* ─── Emulator thread ────────────────────────────────────────────────── */
static void* emuThreadFn(void* arg) {
    EmuState* e = (EmuState*)arg;
    prctl(PR_SET_NAME, "gba_emu", 0, 0, 0);

    /* Elevate thread priority to SCHED_FIFO for minimal jitter */
    struct sched_param sp = { .sched_priority = sched_get_priority_max(SCHED_FIFO) - 1 };
    pthread_setschedparam(pthread_self(), SCHED_FIFO, &sp);

    /* EGL context on this thread */
    EGLint attr[] = { EGL_CONTEXT_CLIENT_VERSION, 2, EGL_NONE };
    e->display = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    eglInitialize(e->display, NULL, NULL);

    EGLint cfg_attr[] = {
        EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
        EGL_RENDERABLE_TYPE, EGL_OPENGL_ES2_BIT,
        EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8,
        EGL_NONE
    };
    EGLConfig cfg;
    EGLint    nCfg;
    eglChooseConfig(e->display, cfg_attr, &cfg, 1, &nCfg);
    e->context = eglCreateContext(e->display, cfg, EGL_NO_CONTEXT, attr);
    e->surface = eglCreateWindowSurface(e->display, cfg, e->window, NULL);
    eglMakeCurrent(e->display, e->surface, e->surface, e->context);

    initGL(e);
    glViewport(0, 0, ANativeWindow_getWidth(e->window), ANativeWindow_getHeight(e->window));

    /* mGBA core init */
    e->core = GBACoreCreate();
    e->core->init(e->core);
    mCoreInitConfig(e->core, NULL);

    e->core->setVideoBuffer(e->core, e->framebuf, GBA_WIDTH);

    /* Audio */
    initAudio(e);
    e->core->setAudioBufferSize(e->core, 512);

    /* Load ROM */
    e->core->loadROM(e->core, e->romVf);
    if (e->saveVf) {
        e->core->loadSave(e->core, e->saveVf);
    }

    /* Attach LAN SIO driver if multiplayer active */
    if (e->lanDriver.active) {
        struct GBA* gba = (struct GBA*)e->core->board;
        GBASIOSetDriver(&gba->sio, &e->lanDriver.base);
    }

    e->core->reset(e->core);

    /* Frame loop */
    const long FRAME_NS = 16750000L; /* ~59.7275 fps */
    struct timespec next;
    clock_gettime(CLOCK_MONOTONIC, &next);

    while (e->running) {
        pthread_mutex_lock(&e->mutex);
        while (e->paused && e->running) {
            pthread_cond_wait(&e->cond, &e->mutex);
        }
        uint16_t keys = e->keys;
        pthread_mutex_unlock(&e->mutex);

        if (!e->running) break;

        e->core->setKeys(e->core, keys);
        e->core->runFrame(e->core);

        /* Audio: drain the mGBA audio buffer into our ring */
        struct blip_t* blipL = e->core->getAudioChannel(e->core, 0);
        struct blip_t* blipR = e->core->getAudioChannel(e->core, 1);
        if (blipL && blipR) {
            int avail = blip_samples_avail(blipL);
            if (avail > 0) {
                int16_t tmp[1024];
                int got = blip_read_samples(blipL, tmp, 512, 1);
                blip_read_samples(blipR, tmp + 1, 512, 1);
                audioRingWrite(&e->audioRing, tmp, got);
            }
        }

        /* Precise frame timing */
        next.tv_nsec += FRAME_NS;
        if (next.tv_nsec >= 1000000000L) {
            next.tv_nsec -= 1000000000L;
            next.tv_sec++;
        }
        clock_nanosleep(CLOCK_MONOTONIC, TIMER_ABSTIME, &next, NULL);
    }

    /* Save */
    if (e->saveVf) {
        e->core->saveSave(e->core, e->saveVf);
    }

    e->core->deinit(e->core);
    eglMakeCurrent(e->display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
    eglDestroySurface(e->display, e->surface);
    eglDestroyContext(e->display, e->context);
    return NULL;
}

/* ═══════════════════════ JNI exports ════════════════════════════════════ */

JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM* vm, void* reserved) {
    (void)vm; (void)reserved;
    memset(&g_emu, 0, sizeof(g_emu));
    pthread_mutex_init(&g_emu.mutex, NULL);
    pthread_cond_init(&g_emu.cond, NULL);
    return JNI_VERSION_1_6;
}

JNIEXPORT void JNICALL
Java_com_gbaemu_core_GBACore_nativeInit(JNIEnv* env, jobject thiz,
        jstring romPath, jstring savePath, jobject surface) {
    (void)thiz;

    const char* rom  = (*env)->GetStringUTFChars(env, romPath,  NULL);
    const char* save = (*env)->GetStringUTFChars(env, savePath, NULL);

    g_emu.romVf  = VFileOpen(rom,  O_RDONLY);
    g_emu.saveVf = VFileOpen(save, O_RDWR | O_CREAT);
    strncpy(g_emu.savePath, save, 511);

    g_emu.window  = ANativeWindow_fromSurface(env, surface);
    g_emu.running = 1;
    g_emu.paused  = 0;

    (*env)->ReleaseStringUTFChars(env, romPath,  rom);
    (*env)->ReleaseStringUTFChars(env, savePath, save);

    pthread_create(&g_emu.emuThread, NULL, emuThreadFn, &g_emu);
}

JNIEXPORT void JNICALL
Java_com_gbaemu_core_GBACore_nativeSetKeys(JNIEnv* env, jobject thiz, jint keys) {
    (void)env; (void)thiz;
    __atomic_store_n(&g_emu.keys, (uint16_t)keys, __ATOMIC_RELEASE);
}

JNIEXPORT void JNICALL
Java_com_gbaemu_core_GBACore_nativePause(JNIEnv* env, jobject thiz) {
    (void)env; (void)thiz;
    pthread_mutex_lock(&g_emu.mutex);
    g_emu.paused = 1;
    pthread_mutex_unlock(&g_emu.mutex);
}

JNIEXPORT void JNICALL
Java_com_gbaemu_core_GBACore_nativeResume(JNIEnv* env, jobject thiz) {
    (void)env; (void)thiz;
    pthread_mutex_lock(&g_emu.mutex);
    g_emu.paused = 0;
    pthread_cond_signal(&g_emu.cond);
    pthread_mutex_unlock(&g_emu.mutex);
}

JNIEXPORT void JNICALL
Java_com_gbaemu_core_GBACore_nativeStop(JNIEnv* env, jobject thiz) {
    (void)env; (void)thiz;
    pthread_mutex_lock(&g_emu.mutex);
    g_emu.running = 0;
    g_emu.paused  = 0;
    pthread_cond_signal(&g_emu.cond);
    pthread_mutex_unlock(&g_emu.mutex);
    pthread_join(g_emu.emuThread, NULL);

    if (g_emu.window) {
        ANativeWindow_release(g_emu.window);
        g_emu.window = NULL;
    }
}

JNIEXPORT void JNICALL
Java_com_gbaemu_core_GBACore_nativeSurfaceChanged(JNIEnv* env, jobject thiz,
        jobject surface, jint w, jint h) {
    (void)thiz; (void)w; (void)h;
    /* Surface replacement handled gracefully */
    ANativeWindow* newWin = ANativeWindow_fromSurface(env, surface);
    pthread_mutex_lock(&g_emu.mutex);
    if (g_emu.window) ANativeWindow_release(g_emu.window);
    g_emu.window = newWin;
    pthread_mutex_unlock(&g_emu.mutex);
}

/* ── LAN multiplayer JNI ─────────────────────────────────────────────── */

JNIEXPORT void JNICALL
Java_com_gbaemu_core_GBACore_nativeLanConnect(JNIEnv* env, jobject thiz,
        jstring ip, jint port, jint playerId) {
    (void)thiz;
    const char* ipStr = (*env)->GetStringUTFChars(env, ip, NULL);
    lanSIOConnect(&g_emu.lanDriver, ipStr, (uint16_t)port, playerId);
    (*env)->ReleaseStringUTFChars(env, ip, ipStr);
}

JNIEXPORT void JNICALL
Java_com_gbaemu_core_GBACore_nativeLanHost(JNIEnv* env, jobject thiz, jint port) {
    (void)env; (void)thiz;
    lanSIOHost(&g_emu.lanDriver, (uint16_t)port);
}

JNIEXPORT void JNICALL
Java_com_gbaemu_core_GBACore_nativeLanDisconnect(JNIEnv* env, jobject thiz) {
    (void)env; (void)thiz;
    lanSIODisconnect(&g_emu.lanDriver);
}

JNIEXPORT jint JNICALL
Java_com_gbaemu_core_GBACore_nativeLanGetPing(JNIEnv* env, jobject thiz) {
    (void)env; (void)thiz;
    return (jint)lanSIOGetPing(&g_emu.lanDriver);
}
