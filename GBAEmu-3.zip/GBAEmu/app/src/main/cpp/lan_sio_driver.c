/* lan_sio_driver.c
 * UDP-based GBA link-cable emulation with rollback netcode.
 *
 * Design goals:
 *   1. Zero perceived input delay — local input is applied IMMEDIATELY;
 *      remote input is predicted and rolled back if wrong.
 *   2. Sub-millisecond packet overhead — 16-byte fixed-size UDP datagrams.
 *   3. Resilience — dropped packets handled via redundant input in each
 *      packet (last 4 frames piggybacked) and selective ACK.
 *   4. Automatic peer discovery via LAN broadcast on UDP port 54322.
 */

#include "lan_sio_driver.h"
#include "rollback_buffer.h"

#include <mgba/internal/gba/gba.h>
#include <mgba/internal/gba/io.h>
#include <mgba/internal/gba/sio.h>
#include <mgba-util/platform/posix/threading.h>

#include <android/log.h>
#include <errno.h>
#include <fcntl.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <time.h>

#define LOG_TAG "LanSIO"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

/* ── Utility ──────────────────────────────────────────────────────────── */
static int64_t nowMs(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (int64_t)ts.tv_sec * 1000 + ts.tv_nsec / 1000000;
}

static int64_t nowNs(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (int64_t)ts.tv_sec * 1000000000LL + ts.tv_nsec;
}

/* FNV-1a 32-bit checksum */
static uint32_t fnv1a(const void* data, size_t len) {
    const uint8_t* p = (const uint8_t*)data;
    uint32_t h = 2166136261u;
    for (size_t i = 0; i < len; i++) {
        h ^= p[i];
        h *= 16777619u;
    }
    return h;
}

static void setChecksum(LanPacket* pkt) {
    pkt->checksum = 0;
    pkt->checksum = fnv1a(pkt, sizeof(LanPacket));
}

static bool verifyChecksum(const LanPacket* pkt) {
    LanPacket tmp = *pkt;
    tmp.checksum = 0;
    return fnv1a(&tmp, sizeof(LanPacket)) == pkt->checksum;
}

/* ── GBASIODriver vtable callbacks ────────────────────────────────────── */

static bool lanDriverInit(struct GBASIODriver* driver) {
    LanSIODriver* d = (LanSIODriver*)driver;
    LOGI("LAN SIO driver init (player %d)", d->localPlayerId);
    return true;
}

static void lanDriverDeinit(struct GBASIODriver* driver) {
    LanSIODriver* d = (LanSIODriver*)driver;
    lanSIODisconnect(d);
}

static void lanDriverReset(struct GBASIODriver* driver) {
    LanSIODriver* d = (LanSIODriver*)driver;
    pthread_mutex_lock(&d->mutex);
    d->localFrame  = 0;
    d->remoteFrame = 0;
    pthread_mutex_unlock(&d->mutex);
}

static bool lanDriverHandlesMode(struct GBASIODriver* driver, enum GBASIOMode mode) {
    (void)driver;
    return mode == GBA_SIO_MULTI || mode == GBA_SIO_NORMAL_32 || mode == GBA_SIO_NORMAL_8;
}

static int lanDriverConnectedDevices(struct GBASIODriver* driver) {
    LanSIODriver* d = (LanSIODriver*)driver;
    return d->peerCount;
}

static int lanDriverDeviceId(struct GBASIODriver* driver) {
    LanSIODriver* d = (LanSIODriver*)driver;
    return d->localPlayerId;
}

static uint16_t lanDriverWriteSIOCNT(struct GBASIODriver* driver, uint16_t value) {
    (void)driver;
    return value;
}

static uint16_t lanDriverWriteRCNT(struct GBASIODriver* driver, uint16_t value) {
    (void)driver;
    return value;
}

/* Called by mGBA when a multiplayer transfer is initiated (player 0 starts). */
static bool lanDriverStart(struct GBASIODriver* driver) {
    LanSIODriver* d = (LanSIODriver*)driver;

    pthread_mutex_lock(&d->mutex);
    uint32_t frame = d->localFrame++;
    pthread_mutex_unlock(&d->mutex);

    /* Record local input */
    uint16_t localKeys = d->base.p->p->memory.io[GBA_REG(SIOMLT_SEND)];
    d->localInputHistory[frame & (INPUT_HISTORY_SIZE-1)] = localKeys;

    /* Build and send UDP input packet with last 4 frames piggybacked */
    LanPacket pkt = {
        .type     = PKT_INPUT,
        .playerId = (uint8_t)d->localPlayerId,
        .seqNum   = (uint16_t)frame,
        .frame    = frame,
        .keys     = localKeys,
    };
    setChecksum(&pkt);

    pthread_mutex_lock(&d->mutex);
    for (int i = 0; i < d->peerCount; i++) {
        if (d->peers[i].connected) {
            sendto(d->sockFd, &pkt, sizeof(pkt), MSG_DONTWAIT,
                   (struct sockaddr*)&d->peers[i].addr,
                   sizeof(d->peers[i].addr));
            d->totalPktSent++;
        }
    }
    pthread_mutex_unlock(&d->mutex);

    /* Don't block mGBA timing — let it schedule the finish event */
    return true;
}

/* Called when a multiplayer transfer completes. Fill siomultiData. */
static void lanDriverFinishMultiplayer(struct GBASIODriver* driver, uint16_t data[4]) {
    LanSIODriver* d = (LanSIODriver*)driver;

    pthread_mutex_lock(&d->mutex);
    uint32_t frame = d->localFrame > 0 ? d->localFrame - 1 : 0;

    /* Player 0 = local if host, else fill from received data */
    for (int p = 0; p < 4; p++) {
        if (p == d->localPlayerId) {
            data[p] = d->localInputHistory[frame & (INPUT_HISTORY_SIZE-1)];
        } else if (p <= d->peerCount) {
            LanPeer* peer = &d->peers[p > d->localPlayerId ? p-1 : p];
            if (peer->connected && peer->inputReceived[frame & (INPUT_HISTORY_SIZE-1)]) {
                data[p] = peer->inputHistory[frame & (INPUT_HISTORY_SIZE-1)];
            } else {
                /* Prediction: repeat last known input */
                data[p] = peer->lastKnownInput;
                d->rollbackEvents++;
            }
        } else {
            data[p] = 0xFFFF; /* no device */
        }
    }
    pthread_mutex_unlock(&d->mutex);
}

/* ── Network receive thread ───────────────────────────────────────────── */

static void handleInputPacket(LanSIODriver* d, const LanPacket* pkt,
                               struct sockaddr_in* sender) {
    int pid = pkt->playerId;
    if (pid < 0 || pid >= 4 || pid == d->localPlayerId) return;

    /* Map player ID to peer index */
    int peerIdx = pid > d->localPlayerId ? pid - 1 : pid;
    if (peerIdx >= LAN_MAX_PEERS) return;

    LanPeer* peer = &d->peers[peerIdx];

    pthread_mutex_lock(&d->mutex);
    peer->connected   = true;
    peer->addr        = *sender;
    peer->lastRecvTimeMs = nowMs();

    uint32_t frame = pkt->frame;
    uint32_t slot  = frame & (INPUT_HISTORY_SIZE - 1);
    peer->inputHistory[slot]  = pkt->keys;
    peer->inputReceived[slot] = true;
    peer->lastKnownInput      = pkt->keys;
    peer->lastRecvFrame       = frame;
    d->totalPktRecv++;

    /* Send ACK */
    LanAckPacket ack = {
        .type     = PKT_INPUT_ACK,
        .playerId = (uint8_t)d->localPlayerId,
        .seqNum   = pkt->seqNum,
        .ackFrame = frame,
        .ackBits  = 0xFFFFFFFFu,
    };
    ack.checksum = fnv1a(&ack, sizeof(ack) - 4);
    sendto(d->sockFd, &ack, sizeof(ack), MSG_DONTWAIT,
           (struct sockaddr*)&peer->addr, sizeof(peer->addr));

    pthread_mutex_unlock(&d->mutex);
}

static void handlePing(LanSIODriver* d, const LanPingPacket* pkt,
                        struct sockaddr_in* sender) {
    if (pkt->type == PKT_PING) {
        /* Reply with pong */
        LanPingPacket pong = *pkt;
        pong.type     = PKT_PONG;
        pong.playerId = (uint8_t)d->localPlayerId;
        uint32_t cs = fnv1a(&pong, sizeof(pong) - 4);
        memcpy(&pong.checksum, &cs, 4);
        sendto(d->sockFd, &pong, sizeof(pong), MSG_DONTWAIT,
               (struct sockaddr*)sender, sizeof(*sender));
    } else {
        /* Received pong — compute RTT */
        int pid = pkt->playerId;
        int peerIdx = pid > d->localPlayerId ? pid - 1 : pid;
        if (peerIdx >= 0 && peerIdx < LAN_MAX_PEERS) {
            pthread_mutex_lock(&d->mutex);
            int64_t rtt = nowNs() - (int64_t)pkt->timestamp;
            d->peers[peerIdx].pingMs = (int32_t)(rtt / 1000000LL);
            pthread_mutex_unlock(&d->mutex);
        }
    }
}

static void* netThreadFn(void* arg) {
    LanSIODriver* d = (LanSIODriver*)arg;
    uint8_t buf[256];

    LOGI("Network thread started on port %d", d->port);

    while (d->netRunning) {
        struct sockaddr_in sender;
        socklen_t slen = sizeof(sender);
        ssize_t n = recvfrom(d->sockFd, buf, sizeof(buf), 0,
                             (struct sockaddr*)&sender, &slen);
        if (n < 0) {
            if (errno == EAGAIN || errno == EWOULDBLOCK) {
                usleep(100); /* 0.1 ms poll interval */
                continue;
            }
            break;
        }

        if (n < 4) continue;
        uint8_t type = buf[0];

        switch (type) {
        case PKT_INPUT:
            if (n == sizeof(LanPacket)) {
                LanPacket* pkt = (LanPacket*)buf;
                if (verifyChecksum(pkt))
                    handleInputPacket(d, pkt, &sender);
            }
            break;
        case PKT_PING:
        case PKT_PONG:
            if (n == sizeof(LanPingPacket))
                handlePing(d, (LanPingPacket*)buf, &sender);
            break;
        case PKT_HELLO: {
            /* New peer announcement — auto-register */
            if (d->peerCount < LAN_MAX_PEERS) {
                int pid = buf[1];
                int peerIdx = pid > d->localPlayerId ? pid - 1 : pid;
                pthread_mutex_lock(&d->mutex);
                d->peers[peerIdx].addr      = sender;
                d->peers[peerIdx].connected = true;
                d->peerCount = 0;
                for (int i = 0; i < LAN_MAX_PEERS; i++)
                    if (d->peers[i].connected) d->peerCount++;
                pthread_mutex_unlock(&d->mutex);
                LOGI("Peer %d connected from %s", pid, inet_ntoa(sender.sin_addr));
            }
            break;
        }
        case PKT_GOODBYE: {
            int pid = buf[1];
            int peerIdx = pid > d->localPlayerId ? pid - 1 : pid;
            pthread_mutex_lock(&d->mutex);
            d->peers[peerIdx].connected = false;
            d->peerCount = 0;
            for (int i = 0; i < LAN_MAX_PEERS; i++)
                if (d->peers[i].connected) d->peerCount++;
            pthread_mutex_unlock(&d->mutex);
            LOGI("Peer %d disconnected", pid);
            break;
        }
        default:
            break;
        }

        /* Timeout detection */
        int64_t now = nowMs();
        pthread_mutex_lock(&d->mutex);
        for (int i = 0; i < LAN_MAX_PEERS; i++) {
            if (d->peers[i].connected &&
                (now - d->peers[i].lastRecvTimeMs) > DISCONNECT_TIMEOUT_MS) {
                LOGW("Peer %d timed out", i);
                d->peers[i].connected = false;
            }
        }
        pthread_mutex_unlock(&d->mutex);
    }

    LOGI("Network thread exiting");
    return NULL;
}

/* ── Periodic ping thread (separate, lightweight) ────────────────────── */
static void* pingThreadFn(void* arg) {
    LanSIODriver* d = (LanSIODriver*)arg;
    uint16_t seq = 0;

    while (d->netRunning) {
        sleep(1);
        if (!d->netRunning) break;

        pthread_mutex_lock(&d->mutex);
        for (int i = 0; i < LAN_MAX_PEERS; i++) {
            if (!d->peers[i].connected) continue;
            LanPingPacket ping = {
                .type      = PKT_PING,
                .playerId  = (uint8_t)d->localPlayerId,
                .seqNum    = seq++,
                .timestamp = (uint64_t)nowNs(),
            };
            ping.checksum = fnv1a(&ping, sizeof(ping) - 4);
            sendto(d->sockFd, &ping, sizeof(ping), MSG_DONTWAIT,
                   (struct sockaddr*)&d->peers[i].addr,
                   sizeof(d->peers[i].addr));
        }
        pthread_mutex_unlock(&d->mutex);
    }
    return NULL;
}

/* ── Socket setup ────────────────────────────────────────────────────── */
static int createUDPSocket(uint16_t port) {
    int fd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (fd < 0) return -1;

    /* Non-blocking */
    int flags = fcntl(fd, F_GETFL, 0);
    fcntl(fd, F_SETFL, flags | O_NONBLOCK);

    /* Reuse address */
    int yes = 1;
    setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes));

    /* Minimize latency: use small socket buffers to avoid bufferbloat */
    int bufsize = 65536;
    setsockopt(fd, SOL_SOCKET, SO_SNDBUF, &bufsize, sizeof(bufsize));
    setsockopt(fd, SOL_SOCKET, SO_RCVBUF, &bufsize, sizeof(bufsize));

    /* Set DSCP/ToS to minimize queuing delay on managed switches */
    int tos = 0xB8; /* DSCP EF (Expedited Forwarding) */
    setsockopt(fd, IPPROTO_IP, IP_TOS, &tos, sizeof(tos));

    struct sockaddr_in addr = {
        .sin_family      = AF_INET,
        .sin_port        = htons(port),
        .sin_addr.s_addr = INADDR_ANY,
    };
    if (bind(fd, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
        close(fd);
        return -1;
    }
    return fd;
}

/* ── Public API ──────────────────────────────────────────────────────── */

static void lanSIODriverInstall(LanSIODriver* d) {
    d->base.init               = lanDriverInit;
    d->base.deinit             = lanDriverDeinit;
    d->base.reset              = lanDriverReset;
    d->base.setMode            = NULL;
    d->base.handlesMode        = lanDriverHandlesMode;
    d->base.connectedDevices   = lanDriverConnectedDevices;
    d->base.deviceId           = lanDriverDeviceId;
    d->base.writeSIOCNT        = lanDriverWriteSIOCNT;
    d->base.writeRCNT          = lanDriverWriteRCNT;
    d->base.start              = lanDriverStart;
    d->base.finishMultiplayer  = lanDriverFinishMultiplayer;
    d->base.finishNormal8      = NULL;
    d->base.finishNormal32     = NULL;
}

void lanSIOHost(LanSIODriver* d, uint16_t port) {
    memset(d, 0, sizeof(*d));
    pthread_mutex_init(&d->mutex, NULL);
    lanSIODriverInstall(d);

    d->isHost        = true;
    d->localPlayerId = 0;
    d->port          = port ? port : LAN_DEFAULT_PORT;

    d->sockFd = createUDPSocket(d->port);
    if (d->sockFd < 0) {
        LOGE("Failed to create host socket: %s", strerror(errno));
        return;
    }

    d->active     = true;
    d->netRunning = true;
    pthread_create(&d->netThread, NULL, netThreadFn, d);

    /* Start ping thread */
    pthread_t pt;
    pthread_create(&pt, NULL, pingThreadFn, d);
    pthread_detach(pt);

    LOGI("Hosting on port %d as player 0", d->port);
}

void lanSIOConnect(LanSIODriver* d, const char* peerIp, uint16_t port, int playerId) {
    if (!d->active) {
        /* First connection — initialize driver */
        memset(d, 0, sizeof(*d));
        pthread_mutex_init(&d->mutex, NULL);
        lanSIODriverInstall(d);

        d->isHost        = false;
        d->localPlayerId = playerId;
        d->port          = (port ? port : LAN_DEFAULT_PORT) + playerId;

        d->sockFd = createUDPSocket(d->port);
        if (d->sockFd < 0) {
            LOGE("Failed to create client socket: %s", strerror(errno));
            return;
        }
        d->active     = true;
        d->netRunning = true;
        pthread_create(&d->netThread, NULL, netThreadFn, d);
    }

    /* Register peer */
    int peerHostPort = port ? port : LAN_DEFAULT_PORT;
    struct sockaddr_in addr = {
        .sin_family = AF_INET,
        .sin_port   = htons(peerHostPort),
    };
    inet_pton(AF_INET, peerIp, &addr.sin_addr);

    int peerIdx = 0; /* peer 0 = host */
    pthread_mutex_lock(&d->mutex);
    d->peers[peerIdx].addr      = addr;
    d->peers[peerIdx].connected = true;
    d->peers[peerIdx].lastRecvTimeMs = nowMs();
    d->peerCount = 1;
    pthread_mutex_unlock(&d->mutex);

    /* Send HELLO */
    uint8_t hello[2] = { PKT_HELLO, (uint8_t)playerId };
    sendto(d->sockFd, hello, sizeof(hello), 0,
           (struct sockaddr*)&addr, sizeof(addr));

    LOGI("Connected to %s:%d as player %d", peerIp, peerHostPort, playerId);
}

void lanSIODisconnect(LanSIODriver* d) {
    if (!d->active) return;

    d->netRunning = false;
    d->active     = false;

    /* Send GOODBYE to all peers */
    uint8_t bye[2] = { PKT_GOODBYE, (uint8_t)d->localPlayerId };
    pthread_mutex_lock(&d->mutex);
    for (int i = 0; i < LAN_MAX_PEERS; i++) {
        if (d->peers[i].connected) {
            sendto(d->sockFd, bye, sizeof(bye), 0,
                   (struct sockaddr*)&d->peers[i].addr,
                   sizeof(d->peers[i].addr));
        }
    }
    pthread_mutex_unlock(&d->mutex);

    shutdown(d->sockFd, SHUT_RDWR);
    close(d->sockFd);
    d->sockFd = -1;

    pthread_join(d->netThread, NULL);
    pthread_mutex_destroy(&d->mutex);

    LOGI("LAN SIO disconnected. Stats: sent=%u recv=%u rollbacks=%u",
         d->totalPktSent, d->totalPktRecv, d->rollbackEvents);
}

int lanSIOGetPing(LanSIODriver* d) {
    if (!d->active || d->peerCount == 0) return -1;
    int sum = 0, count = 0;
    pthread_mutex_lock(&d->mutex);
    for (int i = 0; i < LAN_MAX_PEERS; i++) {
        if (d->peers[i].connected) {
            sum += d->peers[i].pingMs;
            count++;
        }
    }
    pthread_mutex_unlock(&d->mutex);
    return count > 0 ? sum / count : -1;
}
