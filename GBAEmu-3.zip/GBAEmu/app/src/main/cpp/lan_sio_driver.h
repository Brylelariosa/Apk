#pragma once
/* lan_sio_driver.h
 * Zero-delay LAN multiplayer SIO driver using UDP + rollback netcode.
 *
 * Architecture:
 *   - UDP datagrams on a chosen port (default 54321)
 *   - mDNS/UDP broadcast for peer discovery on the LAN
 *   - Per-frame input exchange: each peer sends its 16-bit key mask
 *     tagged with a frame counter, then both sides advance together.
 *   - Rollback: if a peer's input arrives late we predict (repeat last
 *     known input), run ahead, then rollback+resimulate when real input
 *     arrives. Rollback depth is capped at MAX_ROLLBACK_FRAMES (8).
 *   - Packet format: fixed 16-byte header + payload for minimal overhead.
 */

#include <mgba/internal/gba/sio.h>
#include <stdint.h>
#include <stdbool.h>
#include <pthread.h>
#include <netinet/in.h>

#define LAN_DEFAULT_PORT       54321
#define LAN_DISCOVERY_PORT     54322
#define LAN_MAX_PEERS          3          /* up to 4-player link cable */
#define MAX_ROLLBACK_FRAMES    8
#define INPUT_HISTORY_SIZE     256        /* power-of-2 ring */
#define PING_INTERVAL_FRAMES   60
#define DISCONNECT_TIMEOUT_MS  3000

/* ── Packet types ──────────────────────────────────────────────────────── */
#define PKT_INPUT      0x01   /* frame input */
#define PKT_INPUT_ACK  0x02   /* acknowledge frames */
#define PKT_PING       0x10
#define PKT_PONG       0x11
#define PKT_HELLO      0x20   /* peer introduction */
#define PKT_GOODBYE    0x21   /* graceful disconnect */
#define PKT_SYNC_REQ   0x30   /* request state hash for resync check */
#define PKT_SYNC_RESP  0x31

/* ── Wire packet layout (little-endian) ───────────────────────────────── */
#pragma pack(push, 1)
typedef struct {
    uint8_t  type;
    uint8_t  playerId;    /* sender's player index 0-3 */
    uint16_t seqNum;      /* rolling sequence number */
    uint32_t frame;       /* emulation frame this packet belongs to */
    uint16_t keys;        /* GBA 10-bit key mask */
    uint16_t reserved;
    uint32_t checksum;    /* FNV-1a of [type..reserved] */
} LanPacket;              /* 16 bytes */

typedef struct {
    uint8_t  type;        /* PKT_PING or PKT_PONG */
    uint8_t  playerId;
    uint16_t seqNum;
    uint64_t timestamp;   /* CLOCK_MONOTONIC nanoseconds */
    uint32_t checksum;
} LanPingPacket;          /* 16 bytes */

typedef struct {
    uint8_t  type;
    uint8_t  playerId;
    uint16_t seqNum;
    uint32_t ackFrame;    /* highest contiguous frame acknowledged */
    uint32_t ackBits;     /* bitfield of frames [ackFrame-31 .. ackFrame] */
    uint32_t checksum;
} LanAckPacket;           /* 16 bytes */
#pragma pack(pop)

/* ── Per-peer state ────────────────────────────────────────────────────── */
typedef struct {
    struct sockaddr_in addr;
    bool               connected;
    uint32_t           lastRecvFrame;
    int64_t            lastRecvTimeMs;
    /* Input ring: index = frame & (INPUT_HISTORY_SIZE-1) */
    uint16_t           inputHistory[INPUT_HISTORY_SIZE];
    bool               inputReceived[INPUT_HISTORY_SIZE];
    uint16_t           lastKnownInput;  /* used for prediction */
    /* Round-trip time tracking */
    int32_t            pingMs;
    uint16_t           pingSeq;
    int64_t            pingTime;
} LanPeer;

/* ── Driver state ──────────────────────────────────────────────────────── */
typedef struct LanSIODriver {
    struct GBASIODriver base;           /* must be first */

    bool               active;
    bool               isHost;
    int                localPlayerId;
    int                peerCount;
    LanPeer            peers[LAN_MAX_PEERS];

    /* Sockets */
    int                sockFd;          /* UDP data socket */
    int                discoverySockFd; /* UDP broadcast discovery */
    uint16_t           port;

    /* Frame synchronisation */
    uint32_t           localFrame;
    uint32_t           remoteFrame;     /* lowest confirmed frame across peers */
    uint16_t           localInputHistory[INPUT_HISTORY_SIZE];

    /* Rollback */
    int                rollbackPending; /* >0 frames to roll back */
    uint32_t           rollbackToFrame;

    /* Thread */
    pthread_t          netThread;
    pthread_mutex_t    mutex;
    volatile bool      netRunning;

    /* Multiplayer data for SIO finish */
    uint16_t           siomultiData[4];

    /* Stats */
    uint32_t           totalPktSent;
    uint32_t           totalPktRecv;
    uint32_t           rollbackEvents;
} LanSIODriver;

/* ── Public API ─────────────────────────────────────────────────────────── */
void lanSIOHost       (LanSIODriver* d, uint16_t port);
void lanSIOConnect    (LanSIODriver* d, const char* peerIp, uint16_t port, int playerId);
void lanSIODisconnect (LanSIODriver* d);
int  lanSIOGetPing    (LanSIODriver* d);  /* average RTT ms */
