#include "Chunk.h"
#include "BlockDefs.h"
#include <cstring>
#include <cmath>
#include <android/log.h>

#define LOG_TAG "VoxelChunk"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

Chunk::Chunk(int cx, int cz) : chunkX(cx), chunkZ(cz) {
    memset(blocks, 0, sizeof(blocks));
}

Chunk::~Chunk() {
    if (vao) glDeleteVertexArrays(1, &vao);
    if (vbo) glDeleteBuffers(1, &vbo);
    if (ebo) glDeleteBuffers(1, &ebo);
}

uint8_t Chunk::getBlock(int x, int y, int z) const {
    if (x<0||x>=CW||y<0||y>=CH||z<0||z>=CD) return 0;
    return blocks[bidx(x,y,z)];
}

void Chunk::setBlock(int x, int y, int z, uint8_t t) {
    if (x<0||x>=CW||y<0||y>=CH||z<0||z>=CD) return;
    blocks[bidx(x,y,z)] = t;
    // Update spans incrementally.
    // For colMaxY: if placing above current top, update directly.
    // If removing the top block, rescan the column (rare — only on break).
    uint8_t& top = colMaxY[x * CD + z];
    if (t != 0) {
        if (y > top) top = (uint8_t)y;
        yOccupied[y >> 6] |= (1ULL << (y & 63));
    } else {
        // Block removed — rescan this column and this Y slice
        uint8_t newTop = 0;
        for (int sy = 0; sy < CH; sy++)
            if (blocks[bidx(x,sy,z)] != 0 && sy > newTop) newTop = (uint8_t)sy;
        top = newTop;
        // Rescan the Y slice for occupancy
        bool anyInSlice = false;
        for (int sx = 0; sx < CW && !anyInSlice; sx++)
            for (int sz = 0; sz < CD && !anyInSlice; sz++)
                if (blocks[bidx(sx,y,sz)] != 0) anyInSlice = true;
        if (anyInSlice)
            yOccupied[y >> 6] |= (1ULL << (y & 63));
        else
            yOccupied[y >> 6] &= ~(1ULL << (y & 63));
    }
    dirty = true; gpuReady = false;
}


void Chunk::uploadMesh() {
    if (vertData.empty()) { indexCount=0; gpuReady=true; return; }

    if (!vao) {
        glGenVertexArrays(1, &vao);
        glGenBuffers(1, &vbo);
        glGenBuffers(1, &ebo);
    }

    glBindVertexArray(vao);

    glBindBuffer(GL_ARRAY_BUFFER, vbo);
    glBufferData(GL_ARRAY_BUFFER,
                 (GLsizeiptr)(vertData.size()*sizeof(float)),
                 vertData.data(), GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ebo);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER,
                 (GLsizeiptr)(idxData.size()*sizeof(uint32_t)),
                 idxData.data(), GL_STATIC_DRAW);

    const GLsizei stride = 7 * sizeof(float);
    // aPos   @ location 0
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0,3,GL_FLOAT,GL_FALSE,stride,(void*)0);
    // aColor @ location 1
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1,3,GL_FLOAT,GL_FALSE,stride,(void*)(3*sizeof(float)));
    // aLight @ location 2
    glEnableVertexAttribArray(2);
    glVertexAttribPointer(2,1,GL_FLOAT,GL_FALSE,stride,(void*)(6*sizeof(float)));

    glBindVertexArray(0);

    indexCount = (int)idxData.size();
    gpuReady   = true;

    // Free CPU-side data
    vertData.clear(); vertData.shrink_to_fit();
    idxData.clear();  idxData.shrink_to_fit();
}

void Chunk::render() const {
    if (!gpuReady || indexCount == 0) return;
    glBindVertexArray(vao);
    glDrawElements(GL_TRIANGLES, indexCount, GL_UNSIGNED_INT, nullptr);
    glBindVertexArray(0);
}
