#pragma once
#include <cstdint>
#include <vector>
#include <functional>
#include <GLES3/gl3.h>

// Chunk dimensions
static constexpr int CW = 16;   // width  (X)
static constexpr int CH = 128;  // height (Y)
static constexpr int CD = 16;   // depth  (Z)
// Flat index — layout: X-major so Z is stride-1 (cache-friendly for mesher inner v loop)
// blocks[x][y][z]  →  blocks[x*CH*CD + y*CD + z]
static constexpr int CSIZE = CW * CH * CD;
static constexpr int bidx(int x, int y, int z) { return x*CH*CD + y*CD + z; }

class Chunk {
public:
    Chunk(int cx, int cz);
    ~Chunk();

    uint8_t  getBlock(int x, int y, int z) const;
    void     setBlock(int x, int y, int z, uint8_t type);

    // Build CPU-side mesh — safe to call from any thread
    using GetBlock = std::function<uint8_t(int,int,int)>;
    void buildMesh(const GetBlock& world);

    // Upload built mesh to GPU — must be called from GL thread
    void uploadMesh();

    // Draw — caller must set MVP uniform before calling renderAll()
    void render() const;

    int  getChunkX() const { return chunkX; }
    int  getChunkZ() const { return chunkZ; }
    bool isDirty()   const { return dirty;    }
    bool hasGpu()    const { return gpuReady; }
    // true when CPU mesh data is present (built but not yet uploaded)
    bool hasCpuMesh() const { return !vertData.empty(); }
    void markDirty()        { dirty = true; gpuReady = false; }
    // Copy flat terrain data directly into block array (worker thread safe)
    void populate(const uint8_t* src) {
        memcpy(blocks, src, CSIZE);
        dirty = true; gpuReady = false;
    }
    // Direct read of flat block array (for terrain cache copy-out)
    const uint8_t* rawBlocks() const { return blocks; }

private:
    uint8_t blocks[CSIZE]{};
    int chunkX, chunkZ;

    std::vector<float>    vertData;
    std::vector<uint32_t> idxData;

    GLuint vao = 0, vbo = 0, ebo = 0;
    int    indexCount = 0;
    bool   dirty      = true;
    bool   gpuReady   = false;

    void addQuad(int dim, int dir, int faceSlice,
                 int u0, int v0, int wu, int wv,
                 uint8_t blockType);
};
