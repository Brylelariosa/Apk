package com.mangatool.app.util

import android.graphics.Bitmap
import android.graphics.BitmapFactory

object BitmapUtils {

    /** Decode just the pixel dimensions without loading the full bitmap. */
    fun decodeDimensions(data: ByteArray): Pair<Int, Int> {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(data, 0, data.size, opts)
        return opts.outWidth to opts.outHeight
    }

    /** Decode a thumbnail at most [maxPx] wide/tall. Uses inSampleSize to save memory. */
    fun decodeThumbnail(data: ByteArray, maxPx: Int = 256): Bitmap? {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(data, 0, data.size, opts)

        var sample = 1
        while (opts.outWidth / sample > maxPx || opts.outHeight / sample > maxPx) sample *= 2

        return BitmapFactory.decodeByteArray(data, 0, data.size,
            BitmapFactory.Options().apply { inSampleSize = sample })
    }

    /** Decode at full resolution (for preview). */
    fun decodeFull(data: ByteArray): Bitmap? =
        BitmapFactory.decodeByteArray(data, 0, data.size)
}
