package com.mangatool.app

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mangatool.app.util.BitmapUtils

class MergeImagePickerActivity : AppCompatActivity() {

    companion object {
        const val RESULT_URIS = "selected_uris"
    }

    // ── Views ──────────────────────────────────────────────────────────────────
    private lateinit var recyclerPhotos: RecyclerView
    private lateinit var recyclerAlbums: RecyclerView
    private lateinit var btnAdd: Button
    private lateinit var selectionBar: TextView
    private lateinit var tvCount: TextView
    private lateinit var tvTitle: TextView
    private lateinit var tabAllPhotos: TextView
    private lateinit var tabAlbums: TextView
    private lateinit var tabIndicator: View

    // ── Data ───────────────────────────────────────────────────────────────────
    data class DeviceImage(val uri: Uri, val id: Long, val bucketId: Long)
    data class Album(
        val bucketId: Long,
        val name: String,
        val count: Int,
        val coverUri: Uri
    )

    private val allImages    = mutableListOf<DeviceImage>()
    private val albums       = mutableListOf<Album>()
    private val selectedUris = linkedSetOf<String>()

    // ── Mode state ─────────────────────────────────────────────────────────────
    private enum class Mode { ALL_PHOTOS, ALBUMS, ALBUM_PHOTOS }
    private var currentMode  = Mode.ALL_PHOTOS
    private var currentAlbum: Album? = null

    // Currently displayed photos (filtered when inside an album)
    private val displayedImages = mutableListOf<DeviceImage>()

    private var cellSize    = 0
    private var photoAdapter: PickerAdapter? = null

    // ── Permission ─────────────────────────────────────────────────────────────
    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results.values.any { it }) loadImages()
        else tvCount.text = "Storage permission denied"
    }

    // ──────────────────────────────────────────────────────────────────────────
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_merge_picker)

        recyclerPhotos = findViewById(R.id.picker_grid)
        recyclerAlbums = findViewById(R.id.album_grid)
        btnAdd         = findViewById(R.id.btn_add_selected)
        selectionBar   = findViewById(R.id.tv_selection_bar)
        tvCount        = findViewById(R.id.tv_picker_count)
        tvTitle        = findViewById(R.id.tv_picker_title)
        tabAllPhotos   = findViewById(R.id.tab_all_photos)
        tabAlbums      = findViewById(R.id.tab_albums)
        tabIndicator   = findViewById(R.id.tab_indicator)

        cellSize = resources.displayMetrics.widthPixels / 3

        findViewById<ImageButton>(R.id.btn_picker_back).setOnClickListener { handleBack() }
        btnAdd.setOnClickListener { returnSelected() }
        btnAdd.isEnabled = false

        tabAllPhotos.setOnClickListener { switchToAllPhotos() }
        tabAlbums.setOnClickListener    { switchToAlbums()   }

        checkAndLoad()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (!handleBack()) super.onBackPressed()
    }

    /** Returns true if back was consumed (album drill-down → album list). */
    private fun handleBack(): Boolean {
        return when (currentMode) {
            Mode.ALBUM_PHOTOS -> { switchToAlbums(); true }
            else              -> false
        }
    }

    // ── Tab switching ──────────────────────────────────────────────────────────

    private fun switchToAllPhotos() {
        currentMode  = Mode.ALL_PHOTOS
        currentAlbum = null
        displayedImages.clear()
        displayedImages.addAll(allImages)
        photoAdapter?.notifyDataSetChanged()

        recyclerPhotos.visibility = View.VISIBLE
        recyclerAlbums.visibility = View.GONE
        selectionBar.visibility   = View.VISIBLE

        tvTitle.text = "Add Images to Merge"
        tvCount.text = "${allImages.size} photos"
        highlightTab(all = true)
        updateTabIndicator(leftSide = true)
    }

    private fun switchToAlbums() {
        currentMode  = Mode.ALBUMS
        currentAlbum = null

        recyclerPhotos.visibility = View.GONE
        recyclerAlbums.visibility = View.VISIBLE
        selectionBar.visibility   = View.VISIBLE

        tvTitle.text = "Albums"
        tvCount.text = "${albums.size} album${if (albums.size == 1) "" else "s"}"
        highlightTab(all = false)
        updateTabIndicator(leftSide = false)

        // Refresh album adapter so selection tints update
        recyclerAlbums.adapter?.notifyDataSetChanged()
    }

    private fun openAlbum(album: Album) {
        currentMode  = Mode.ALBUM_PHOTOS
        currentAlbum = album

        displayedImages.clear()
        displayedImages.addAll(allImages.filter { it.bucketId == album.bucketId })
        photoAdapter?.notifyDataSetChanged()

        recyclerPhotos.visibility = View.VISIBLE
        recyclerAlbums.visibility = View.GONE

        tvTitle.text = album.name
        tvCount.text = "${displayedImages.size} photos"
        highlightTab(all = false)
        updateTabIndicator(leftSide = false)
    }

    private fun highlightTab(all: Boolean) {
        tabAllPhotos.setTextColor(
            if (all) getColor(R.color.accent) else getColor(R.color.text_secondary)
        )
        tabAlbums.setTextColor(
            if (!all) getColor(R.color.accent) else getColor(R.color.text_secondary)
        )
    }

    private fun updateTabIndicator(leftSide: Boolean) {
        tabIndicator.post {
            val parent = tabIndicator.parent as? View ?: return@post
            val halfW  = parent.width / 2
            val params = tabIndicator.layoutParams
            params.width = halfW
            tabIndicator.layoutParams = params
            tabIndicator.translationX = if (leftSide) 0f else halfW.toFloat()
        }
    }

    // ── Permission + data loading ──────────────────────────────────────────────

    private fun checkAndLoad() {
        val needed = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            arrayOf(Manifest.permission.READ_MEDIA_IMAGES)
        else
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)

        val ok = needed.all {
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
        }
        if (ok) loadImages() else permLauncher.launch(needed)
    }

    private fun loadImages() {
        Thread {
            val proj = arrayOf(
                MediaStore.Images.Media._ID,
                MediaStore.Images.Media.DATE_ADDED,
                MediaStore.Images.Media.BUCKET_ID,
                MediaStore.Images.Media.BUCKET_DISPLAY_NAME
            )
            contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                proj, null, null,
                "${MediaStore.Images.Media.DATE_ADDED} DESC"
            )?.use { cursor ->
                val idCol      = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                val bucketIdCol= cursor.getColumnIndexOrThrow(MediaStore.Images.Media.BUCKET_ID)
                val bucketNameCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.BUCKET_DISPLAY_NAME)

                // albumMap: bucketId -> (name, count, coverUri)
                val albumMap = linkedMapOf<Long, Triple<String, Int, Uri>>()

                while (cursor.moveToNext()) {
                    val id    = cursor.getLong(idCol)
                    val bid   = cursor.getLong(bucketIdCol)
                    val bname = cursor.getString(bucketNameCol) ?: "Unknown"
                    val uri   = ContentUris.withAppendedId(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id
                    )
                    allImages.add(DeviceImage(uri, id, bid))

                    val existing = albumMap[bid]
                    albumMap[bid] = if (existing == null)
                        Triple(bname, 1, uri)
                    else
                        Triple(existing.first, existing.second + 1, existing.third)
                }

                albums.addAll(albumMap.map { (bid, t) -> Album(bid, t.first, t.second, t.third) })
                // Camera/DCIM first, then by photo count descending
                albums.sortWith(
                    compareByDescending<Album> {
                        it.name.equals("Camera", ignoreCase = true) ||
                        it.name.equals("DCIM", ignoreCase = true)
                    }.thenByDescending { it.count }
                )
            }

            runOnUiThread {
                displayedImages.clear()
                displayedImages.addAll(allImages)

                tvCount.text = "${allImages.size} photos"

                recyclerPhotos.layoutManager = GridLayoutManager(this, 3)
                photoAdapter = PickerAdapter(cellSize)
                recyclerPhotos.adapter = photoAdapter

                val albumCellSize = resources.displayMetrics.widthPixels / 2
                recyclerAlbums.layoutManager = GridLayoutManager(this, 2)
                recyclerAlbums.adapter = AlbumAdapter(albumCellSize)

                updateTabIndicator(leftSide = true)
            }
        }.start()
    }

    // ── Selection helpers ──────────────────────────────────────────────────────

    private fun refreshSelectionUI() {
        val n = selectedUris.size
        btnAdd.isEnabled = n > 0
        btnAdd.text = if (n > 0) "Add $n image${if (n == 1) "" else "s"}" else "Add"
        selectionBar.text = if (n > 0) "$n selected  ·  tap to deselect" else "Tap images to select"
    }

    private fun returnSelected() {
        if (selectedUris.isEmpty()) { finish(); return }
        val data = Intent().apply {
            putStringArrayListExtra(RESULT_URIS, ArrayList(selectedUris))
        }
        setResult(Activity.RESULT_OK, data)
        finish()
    }

    // ── Photo grid adapter ─────────────────────────────────────────────────────
    inner class PickerAdapter(private val cellSz: Int) : RecyclerView.Adapter<PickerAdapter.VH>() {

        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val image:   ImageView = v.findViewById(R.id.picker_thumb)
            val check:   View      = v.findViewById(R.id.picker_check)
            val overlay: View      = v.findViewById(R.id.picker_overlay)
            val badge:   TextView  = v.findViewById(R.id.picker_badge)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_picker_thumb, parent, false)
            v.layoutParams = v.layoutParams.also { it.height = cellSz }
            return VH(v)
        }

        override fun getItemCount() = displayedImages.size

        override fun onBindViewHolder(holder: VH, position: Int) {
            val img    = displayedImages[position]
            val uriStr = img.uri.toString()
            val sel    = uriStr in selectedUris

            holder.overlay.visibility = if (sel) View.VISIBLE else View.GONE
            holder.check.visibility   = if (sel) View.VISIBLE else View.GONE

            val selIdx = selectedUris.indexOf(uriStr)
            holder.badge.visibility = if (selIdx >= 0) View.VISIBLE else View.GONE
            if (selIdx >= 0) holder.badge.text = "${selIdx + 1}"

            holder.image.setImageBitmap(null)
            val cacheKey = "pick_${img.id}"
            AppState.thumbCache.get(cacheKey)?.let { holder.image.setImageBitmap(it); return }

            holder.image.tag = cacheKey
            Thread {
                val bmp = runCatching {
                    contentResolver.openInputStream(img.uri)?.use { s ->
                        BitmapUtils.decodeThumbnail(s.readBytes(), 240)
                    }
                }.getOrNull()
                if (bmp != null) {
                    AppState.thumbCache.put(cacheKey, bmp)
                    if (holder.image.tag == cacheKey)
                        holder.image.post { holder.image.setImageBitmap(bmp) }
                }
            }.start()

            holder.itemView.setOnClickListener {
                if (uriStr in selectedUris) selectedUris.remove(uriStr)
                else selectedUris.add(uriStr)
                notifyItemChanged(position)
                refreshSelectionUI()
            }
        }
    }

    // ── Album grid adapter ─────────────────────────────────────────────────────
    inner class AlbumAdapter(private val cellSz: Int) : RecyclerView.Adapter<AlbumAdapter.VH>() {

        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val cover: ImageView = v.findViewById(R.id.album_cover)
            val name:  TextView  = v.findViewById(R.id.album_name)
            val count: TextView  = v.findViewById(R.id.album_count)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_album_folder, parent, false)
            v.layoutParams = v.layoutParams.also { it.height = cellSz }
            return VH(v)
        }

        override fun getItemCount() = albums.size

        override fun onBindViewHolder(holder: VH, position: Int) {
            val album = albums[position]

            val selInAlbum = allImages.count { it.bucketId == album.bucketId && it.uri.toString() in selectedUris }
            holder.name.text  = album.name
            holder.count.text = buildString {
                append("${album.count} photo${if (album.count == 1) "" else "s"}")
                if (selInAlbum > 0) append("  ·  $selInAlbum selected")
            }

            holder.cover.setImageBitmap(null)
            val cacheKey = "album_cover_${album.bucketId}"
            AppState.thumbCache.get(cacheKey)?.let { holder.cover.setImageBitmap(it); return }

            holder.cover.tag = cacheKey
            Thread {
                val bmp = runCatching {
                    contentResolver.openInputStream(album.coverUri)?.use { s ->
                        BitmapUtils.decodeThumbnail(s.readBytes(), 400)
                    }
                }.getOrNull()
                if (bmp != null) {
                    AppState.thumbCache.put(cacheKey, bmp)
                    if (holder.cover.tag == cacheKey)
                        holder.cover.post { holder.cover.setImageBitmap(bmp) }
                }
            }.start()

            holder.itemView.setOnClickListener { openAlbum(album) }
        }
    }
}

private fun <T> LinkedHashSet<T>.indexOf(element: T): Int {
    var i = 0; for (e in this) { if (e == element) return i; i++ }; return -1
}
