package com.mangatool.app

import android.util.Base64
import com.mangatool.app.model.ImageGroup
import com.mangatool.app.model.ImageItem
import com.mangatool.app.util.BitmapUtils

object MhtmlParser {

    fun parse(data: ByteArray, filename: String): ImageGroup? {
        return try {
            // 1. Detect boundary string from first 4 KB
            val header = String(data.copyOfRange(0, minOf(4096, data.size)), Charsets.UTF_8)
            val boundary = Regex("""boundary="?([^";\s\r\n]+)"?""", RegexOption.IGNORE_CASE)
                .find(header)?.groupValues?.get(1)
                ?: Regex("""^--[a-fA-F0-9\-]+""", RegexOption.MULTILINE)
                    .find(header)?.value?.removePrefix("--")
                ?: return null

            val boundaryBytes = "--$boundary".toByteArray(Charsets.UTF_8)

            // 2. Binary scan — extract every image part
            val extracted = mutableListOf<RawImage>()
            var pos = 0
            var partIdx = 0

            while (pos < data.size) {
                val bPos = findBytes(data, boundaryBytes, pos)
                if (bPos == -1) break

                if (pos > 0) {
                    val chunkEnd = bPos
                    val maxHdr = minOf(chunkEnd, pos + 2048)
                    val hdrSlice = data.copyOfRange(pos, maxHdr)

                    // Find blank-line separator (CRLFCRLF or LFLF)
                    val bodyOffset: Int? = run {
                        val a = findBytes(hdrSlice, byteArrayOf(13,10,13,10), 0)
                        if (a != -1) a + 4
                        else {
                            val b = findBytes(hdrSlice, byteArrayOf(10,10), 0)
                            if (b != -1) b + 2 else null
                        }
                    }

                    if (bodyOffset != null) {
                        val bodyStart = pos + bodyOffset
                        if (bodyStart < chunkEnd) {
                            val headers = String(data.copyOfRange(pos, bodyStart), Charsets.UTF_8)
                            val typeMatch = Regex("""Content-Type:\s*image/(jpeg|jpg|png|gif|webp)""",
                                RegexOption.IGNORE_CASE).find(headers)
                            val encMatch  = Regex("""Content-Transfer-Encoding:\s*(base64|quoted-printable)""",
                                RegexOption.IGNORE_CASE).find(headers)

                            if (typeMatch != null) {
                                val rawExt = typeMatch.groupValues[1].lowercase()
                                val ext    = if (rawExt == "jpeg") "jpg" else rawExt
                                val body   = data.copyOfRange(bodyStart, chunkEnd)

                                val bytes: ByteArray? = when (encMatch?.groupValues?.get(1)?.lowercase()) {
                                    "base64" -> try {
                                        val b64 = String(body, Charsets.UTF_8)
                                            .filter { !it.isWhitespace() }
                                        Base64.decode(b64, Base64.DEFAULT)
                                    } catch (_: Exception) { null }
                                    "quoted-printable" -> decodeQP(String(body, Charsets.ISO_8859_1))
                                        .toByteArray(Charsets.ISO_8859_1)
                                    else -> body.copyOf()
                                }

                                if (bytes != null && bytes.size > 100) {
                                    extracted += RawImage(partIdx.toString().padStart(8,'0'), bytes, ext)
                                }
                            }
                        }
                    }
                }

                partIdx++
                pos = bPos + boundaryBytes.size
            }

            if (extracted.isEmpty()) return null

            extracted.sortBy { it.sortKey }

            val images = extracted.mapIndexed { i, r ->
                val (w, h) = BitmapUtils.decodeDimensions(r.data)
                ImageItem(originalIdx = i, data = r.data, ext = r.ext, size = r.data.size,
                    width = w, height = h)
            }

            val groupName = smartRename(filename)
            ImageGroup(groupName = groupName).also { g -> g.allImages.addAll(images) }

        } catch (_: Exception) {
            null
        }
    }

    // ── helpers ─────────────────────────────────────────────────────────────

    private data class RawImage(val sortKey: String, val data: ByteArray, val ext: String)

    /** Returns index of [seq] in [buf] starting at [from], or -1 if not found. */
    private fun findBytes(buf: ByteArray, seq: ByteArray, from: Int): Int {
        outer@ for (i in from..buf.size - seq.size) {
            for (j in seq.indices) if (buf[i + j] != seq[j]) continue@outer
            return i
        }
        return -1
    }

    private fun decodeQP(s: String): String =
        s.replace(Regex("=[\\r\\n]+"), "")
         .replace(Regex("=[0-9A-Fa-f]{2}")) { it.value.substring(1).toInt(16).toChar().toString() }

    private fun smartRename(filename: String): String {
        var n = filename.replace(Regex("\\.mhtml?$", RegexOption.IGNORE_CASE), "")
        n = n.replace(Regex("[_+]"), " ")
        n = n.replace(Regex("\\[.*?]|\\(.*?\\)"), "")
        n = n.replace(Regex("\\b(read manga online|read online|manga)\\b", RegexOption.IGNORE_CASE), "")
        n = n.trim()

        val m = Regex("""^(.*?)(\b(?:chapter|ch\.?|no\.?|c\.?|vol\.?|volume|#)\s*[\d.]+|\b\d+)(.*)$""",
            RegexOption.IGNORE_CASE).find(n)
        if (m != null) {
            val prefix = m.groupValues[1].trim()
            var num    = m.groupValues[2].trim()
            val suffix = m.groupValues[3].trim()
            num = num.replace(Regex("(\\d+)")) { it.value.padStart(3, '0') }
            val cp = prefix.trimEnd('-', '_').trim()
            n = if (cp.isNotEmpty()) "$num - $cp $suffix".trim() else "$num $suffix".trim()
        }

        return n.replace(Regex("\\s+-\\s*$"), "").replace(Regex("\\s+"), " ").trim()
            .ifEmpty { filename.substringBefore('.') }
    }
}
