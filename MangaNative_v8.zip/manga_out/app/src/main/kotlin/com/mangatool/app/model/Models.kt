package com.mangatool.app.model

data class ImageItem(
    val originalIdx: Int,
    val data: ByteArray,
    val ext: String,
    val size: Int,
    var name: String = "",
    var userDeleted: Boolean = false,
    var forceKeep: Boolean = false,
    var filterReason: String? = null,
    val width: Int = 0,
    val height: Int = 0
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is ImageItem) return false
        return originalIdx == other.originalIdx
    }
    override fun hashCode() = originalIdx
}

data class ImageGroup(
    val groupName: String,
    val allImages: MutableList<ImageItem> = mutableListOf(),
    var displayImages: List<ImageItem> = emptyList(),
    var filteredImages: List<ImageItem> = emptyList(),
    /** Set of pair indices (0-based) where the two images are swapped (right shown on left) */
    val pairSwaps: MutableSet<Int> = mutableSetOf()
)
