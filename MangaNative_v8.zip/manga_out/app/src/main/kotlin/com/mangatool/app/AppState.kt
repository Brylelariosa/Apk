package com.mangatool.app

import android.graphics.Bitmap
import android.util.LruCache
import com.mangatool.app.model.ImageGroup

object AppState {
    /** Extract mode has its own group list */
    val extractGroups: MutableList<ImageGroup> = mutableListOf()
    /** Merge mode has its own completely separate group list */
    val mergeGroups: MutableList<ImageGroup> = mutableListOf()

    var currentMode: String = "extract"   // "extract" or "merge"
    var minSizeKb: Int = 40
    var excludeGifs: Boolean = true
    var reverseOrder: Boolean = false

    /** Convenience: returns the active mode's list */
    val groups: MutableList<ImageGroup>
        get() = if (currentMode == "merge") mergeGroups else extractGroups

    val thumbCache: LruCache<String, Bitmap> = object : LruCache<String, Bitmap>(
        (Runtime.getRuntime().maxMemory() / 1024 / 8).toInt()
    ) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount / 1024
    }

    fun reset() {
        // Reset only the active mode's list
        groups.clear()
        thumbCache.evictAll()
    }

    fun resetAll() {
        extractGroups.clear()
        mergeGroups.clear()
        thumbCache.evictAll()
    }

    fun applyFilters() {
        groups.forEach { group ->
            if (currentMode == "merge") {
                // Merge mode: no filtering — show all images as-is
                group.displayImages = group.allImages.mapIndexed { i, img ->
                    img.copy(name = "${(i + 1).toString().padStart(3, '0')}.${img.ext}")
                }
                group.filteredImages = emptyList()
                return@forEach
            }

            // Extract mode: apply size/gif/reverse filters
            val valid    = mutableListOf<com.mangatool.app.model.ImageItem>()
            val filtered = mutableListOf<com.mangatool.app.model.ImageItem>()
            val minBytes = minSizeKb * 1024

            group.allImages.forEach { img ->
                val reason = when {
                    img.userDeleted -> "Manually Deleted"
                    img.forceKeep  -> null
                    img.size < minBytes -> "Too Small (${img.size / 1024}KB)"
                    excludeGifs && img.ext.equals("gif", true) -> "GIF Excluded"
                    else -> null
                }
                if (reason != null) filtered.add(img.copy(filterReason = reason))
                else valid.add(img)
            }
            if (reverseOrder) valid.reverse()
            group.displayImages  = valid.mapIndexed { i, img ->
                img.copy(name = "${(i + 1).toString().padStart(3, '0')}.${img.ext}")
            }
            group.filteredImages = filtered
        }
    }
}
