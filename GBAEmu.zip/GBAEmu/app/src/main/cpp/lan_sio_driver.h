#pragma once
/* lan_sio_driver.h — standalone LAN multiplayer driver (no mGBA headers needed) */

#include <stdint.h>
#include <stdbool.h>
#include <pthread.h>
#include <netinet/in.h>

#define LAN_DEFAULT_PORT      54321
#define LAN_MAX_PEERS         3
#define MAX_ROLLBACK_FRAMES   8
#define INPUT_HISTORY_SIZE    256
#define DISCONNECT_TIMEOUT_MS 3000

/* Packet types */
#define PKT_INPUT     0x01
#define PKT_INPUT_ACK 0x02
#define PKT_PING      0x10
#define PKT_PONG      0x11
#define PKT_HELLO     0x20
#define PKT_GOODBYE   0x21

#pragma pack(push, 1)
typedef struct {
    uint8_t  type;
    uint8_t  playerId;
    uint16_t seqNum;
    uint32_t frame;
    uint16_t keys;
    uint16_t reserved;
    uint32_t checksum;
} LanPacket;

typedef struct {
    uint8_t  type;
    uint8_t  playerId;
    uint16_t seqNum;
    uint64_t timestamp;
    uint32_t checksum;
} LanPingPacket;
#pragma pack(pop)

typedef struct {
    struct sockaddr_in addr;
    bool               connected;
    uint32_t           lastRecvFrame;
    int64_t            lastRecvTimeMs;
    uint16_t           inputHistory[INPUT_HISTORY_SIZE];
    bool               inputReceived[INPUT_HISTORY_SIZE];
    uint16_t           lastKnownInput;
    int32_t            pingMs;
    uint16_t           pingSeq;
    int64_t            pingTime;
} LanPeer;

typedef struct LanSIODriver {
    bool            active;
    bool            isHost;
    int             localPlayerId;
    int             peerCount;
    LanPeer         peers[LAN_MAX_PEERS];
    int             sockFd;
    uint16_t        port;
    uint32_t        localFrame;
    uint16_t        localInputHistory[INPUT_HISTORY_SIZE];
    pthread_t       netThread;
    pthread_mutex_t mutex;
    volatile bool   netRunning;
    uint16_t        multiData[4];
    uint32_t        totalPktSent;
    uint32_t        totalPktRecv;
    uint32_t        rollbackEvents;
} LanSIODriver;

void lanSIOHost      (LanSIODriver* d, uint16_t port);
void lanSIOConnect   (LanSIODriver* d, const char* peerIp, uint16_t port, int playerId);
void lanSIODisconnect(LanSIODriver* d);
int  lanSIOGetPing   (LanSIODriver* d);
void lanSIOSetKeys   (LanSIODriver* d, uint16_t keys);
void lanSIOGetAllKeys(LanSIODriver* d, uint16_t out[4]);
