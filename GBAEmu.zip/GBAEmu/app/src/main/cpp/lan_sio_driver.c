/* lan_sio_driver.c — UDP LAN multiplayer, fully standalone */
#include "lan_sio_driver.h"

#include <android/log.h>
#include <errno.h>
#include <fcntl.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <time.h>

#define LOG_TAG "LanSIO"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

static int64_t nowMs(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (int64_t)ts.tv_sec * 1000 + ts.tv_nsec / 1000000;
}

static int64_t nowNs(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (int64_t)ts.tv_sec * 1000000000LL + ts.tv_nsec;
}

static uint32_t fnv1a(const void* data, size_t len) {
    const uint8_t* p = (const uint8_t*)data;
    uint32_t h = 2166136261u;
    for (size_t i = 0; i < len; i++) { h ^= p[i]; h *= 16777619u; }
    return h;
}

static void setChecksum(LanPacket* pkt) {
    pkt->checksum = 0;
    pkt->checksum = fnv1a(pkt, sizeof(LanPacket));
}

static bool verifyChecksum(const LanPacket* pkt) {
    LanPacket tmp = *pkt;
    tmp.checksum = 0;
    return fnv1a(&tmp, sizeof(LanPacket)) == pkt->checksum;
}

static int createUDPSocket(uint16_t port) {
    int fd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (fd < 0) return -1;
    int flags = fcntl(fd, F_GETFL, 0);
    fcntl(fd, F_SETFL, flags | O_NONBLOCK);
    int yes = 1;
    setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes));
    int tos = 0xB8;
    setsockopt(fd, IPPROTO_IP, IP_TOS, &tos, sizeof(tos));
    struct sockaddr_in addr = {
        .sin_family = AF_INET,
        .sin_port = htons(port),
        .sin_addr.s_addr = INADDR_ANY,
    };
    if (bind(fd, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
        close(fd); return -1;
    }
    return fd;
}

static void handleInputPacket(LanSIODriver* d, const LanPacket* pkt,
                               struct sockaddr_in* sender) {
    int pid = pkt->playerId;
    if (pid < 0 || pid >= 4 || pid == d->localPlayerId) return;
    int peerIdx = pid > d->localPlayerId ? pid - 1 : pid;
    if (peerIdx >= LAN_MAX_PEERS) return;
    LanPeer* peer = &d->peers[peerIdx];
    pthread_mutex_lock(&d->mutex);
    peer->connected = true;
    peer->addr = *sender;
    peer->lastRecvTimeMs = nowMs();
    uint32_t frame = pkt->frame;
    uint32_t slot = frame & (INPUT_HISTORY_SIZE - 1);
    peer->inputHistory[slot] = pkt->keys;
    peer->inputReceived[slot] = true;
    peer->lastKnownInput = pkt->keys;
    peer->lastRecvFrame = frame;
    d->totalPktRecv++;
    pthread_mutex_unlock(&d->mutex);
}

static void handlePing(LanSIODriver* d, const LanPingPacket* pkt,
                        struct sockaddr_in* sender) {
    if (pkt->type == PKT_PING) {
        LanPingPacket pong = *pkt;
        pong.type = PKT_PONG;
        pong.playerId = (uint8_t)d->localPlayerId;
        uint32_t cs = fnv1a(&pong, sizeof(pong) - 4);
        memcpy(&pong.checksum, &cs, 4);
        sendto(d->sockFd, &pong, sizeof(pong), MSG_DONTWAIT,
               (struct sockaddr*)sender, sizeof(*sender));
    } else {
        int pid = pkt->playerId;
        int peerIdx = pid > d->localPlayerId ? pid - 1 : pid;
        if (peerIdx >= 0 && peerIdx < LAN_MAX_PEERS) {
            pthread_mutex_lock(&d->mutex);
            int64_t rtt = nowNs() - (int64_t)pkt->timestamp;
            d->peers[peerIdx].pingMs = (int32_t)(rtt / 1000000LL);
            pthread_mutex_unlock(&d->mutex);
        }
    }
}

static void* netThreadFn(void* arg) {
    LanSIODriver* d = (LanSIODriver*)arg;
    uint8_t buf[256];
    while (d->netRunning) {
        struct sockaddr_in sender;
        socklen_t slen = sizeof(sender);
        ssize_t n = recvfrom(d->sockFd, buf, sizeof(buf), 0,
                             (struct sockaddr*)&sender, &slen);
        if (n < 0) {
            if (errno == EAGAIN || errno == EWOULDBLOCK) {
                usleep(500);
                continue;
            }
            break;
        }
        if (n < 4) continue;
        uint8_t type = buf[0];
        switch (type) {
        case PKT_INPUT:
            if (n == sizeof(LanPacket)) {
                LanPacket* pkt = (LanPacket*)buf;
                if (verifyChecksum(pkt)) handleInputPacket(d, pkt, &sender);
            }
            break;
        case PKT_PING:
        case PKT_PONG:
            if (n == sizeof(LanPingPacket))
                handlePing(d, (LanPingPacket*)buf, &sender);
            break;
        case PKT_HELLO: {
            int pid = buf[1];
            int peerIdx = pid > d->localPlayerId ? pid - 1 : pid;
            if (peerIdx >= 0 && peerIdx < LAN_MAX_PEERS) {
                pthread_mutex_lock(&d->mutex);
                d->peers[peerIdx].addr = sender;
                d->peers[peerIdx].connected = true;
                d->peers[peerIdx].lastRecvTimeMs = nowMs();
                d->peerCount = 0;
                for (int i = 0; i < LAN_MAX_PEERS; i++)
                    if (d->peers[i].connected) d->peerCount++;
                pthread_mutex_unlock(&d->mutex);
            }
            break;
        }
        case PKT_GOODBYE: {
            int pid = buf[1];
            int peerIdx = pid > d->localPlayerId ? pid - 1 : pid;
            if (peerIdx >= 0 && peerIdx < LAN_MAX_PEERS) {
                pthread_mutex_lock(&d->mutex);
                d->peers[peerIdx].connected = false;
                d->peerCount = 0;
                for (int i = 0; i < LAN_MAX_PEERS; i++)
                    if (d->peers[i].connected) d->peerCount++;
                pthread_mutex_unlock(&d->mutex);
            }
            break;
        }
        }
        int64_t now = nowMs();
        pthread_mutex_lock(&d->mutex);
        for (int i = 0; i < LAN_MAX_PEERS; i++) {
            if (d->peers[i].connected &&
                (now - d->peers[i].lastRecvTimeMs) > DISCONNECT_TIMEOUT_MS) {
                d->peers[i].connected = false;
            }
        }
        pthread_mutex_unlock(&d->mutex);
    }
    return NULL;
}

void lanSIOHost(LanSIODriver* d, uint16_t port) {
    memset(d, 0, sizeof(*d));
    pthread_mutex_init(&d->mutex, NULL);
    d->isHost = true;
    d->localPlayerId = 0;
    d->port = port ? port : LAN_DEFAULT_PORT;
    d->sockFd = createUDPSocket(d->port);
    if (d->sockFd < 0) { LOGE("Host socket failed"); return; }
    d->active = true;
    d->netRunning = true;
    pthread_create(&d->netThread, NULL, netThreadFn, d);
    LOGI("Hosting on port %d", d->port);
}

void lanSIOConnect(LanSIODriver* d, const char* peerIp, uint16_t port, int playerId) {
    if (!d->active) {
        memset(d, 0, sizeof(*d));
        pthread_mutex_init(&d->mutex, NULL);
        d->isHost = false;
        d->localPlayerId = playerId;
        d->port = (port ? port : LAN_DEFAULT_PORT) + playerId;
        d->sockFd = createUDPSocket(d->port);
        if (d->sockFd < 0) { LOGE("Client socket failed"); return; }
        d->active = true;
        d->netRunning = true;
        pthread_create(&d->netThread, NULL, netThreadFn, d);
    }
    struct sockaddr_in addr = { .sin_family = AF_INET, .sin_port = htons(port ? port : LAN_DEFAULT_PORT) };
    inet_pton(AF_INET, peerIp, &addr.sin_addr);
    pthread_mutex_lock(&d->mutex);
    d->peers[0].addr = addr;
    d->peers[0].connected = true;
    d->peers[0].lastRecvTimeMs = nowMs();
    d->peerCount = 1;
    pthread_mutex_unlock(&d->mutex);
    uint8_t hello[2] = { PKT_HELLO, (uint8_t)playerId };
    sendto(d->sockFd, hello, sizeof(hello), 0, (struct sockaddr*)&addr, sizeof(addr));
    LOGI("Connected to %s as player %d", peerIp, playerId);
}

void lanSIODisconnect(LanSIODriver* d) {
    if (!d->active) return;
    d->netRunning = false;
    d->active = false;
    uint8_t bye[2] = { PKT_GOODBYE, (uint8_t)d->localPlayerId };
    pthread_mutex_lock(&d->mutex);
    for (int i = 0; i < LAN_MAX_PEERS; i++) {
        if (d->peers[i].connected)
            sendto(d->sockFd, bye, sizeof(bye), 0,
                   (struct sockaddr*)&d->peers[i].addr, sizeof(d->peers[i].addr));
    }
    pthread_mutex_unlock(&d->mutex);
    shutdown(d->sockFd, SHUT_RDWR);
    close(d->sockFd);
    d->sockFd = -1;
    pthread_join(d->netThread, NULL);
    pthread_mutex_destroy(&d->mutex);
}

int lanSIOGetPing(LanSIODriver* d) {
    if (!d->active || d->peerCount == 0) return -1;
    int sum = 0, count = 0;
    pthread_mutex_lock(&d->mutex);
    for (int i = 0; i < LAN_MAX_PEERS; i++) {
        if (d->peers[i].connected) { sum += d->peers[i].pingMs; count++; }
    }
    pthread_mutex_unlock(&d->mutex);
    return count > 0 ? sum / count : -1;
}

void lanSIOSetKeys(LanSIODriver* d, uint16_t keys) {
    if (!d->active) return;
    uint32_t frame = d->localFrame++;
    uint32_t slot = frame & (INPUT_HISTORY_SIZE - 1);
    d->localInputHistory[slot] = keys;
    LanPacket pkt = {
        .type = PKT_INPUT, .playerId = (uint8_t)d->localPlayerId,
        .seqNum = (uint16_t)frame, .frame = frame, .keys = keys,
    };
    setChecksum(&pkt);
    pthread_mutex_lock(&d->mutex);
    for (int i = 0; i < LAN_MAX_PEERS; i++) {
        if (d->peers[i].connected) {
            sendto(d->sockFd, &pkt, sizeof(pkt), MSG_DONTWAIT,
                   (struct sockaddr*)&d->peers[i].addr, sizeof(d->peers[i].addr));
            d->totalPktSent++;
        }
    }
    pthread_mutex_unlock(&d->mutex);
}

void lanSIOGetAllKeys(LanSIODriver* d, uint16_t out[4]) {
    uint32_t frame = d->localFrame > 0 ? d->localFrame - 1 : 0;
    for (int p = 0; p < 4; p++) {
        if (p == d->localPlayerId) {
            out[p] = d->localInputHistory[frame & (INPUT_HISTORY_SIZE - 1)];
        } else if (p <= d->peerCount) {
            int pi = p > d->localPlayerId ? p - 1 : p;
            LanPeer* peer = &d->peers[pi];
            if (peer->connected && peer->inputReceived[frame & (INPUT_HISTORY_SIZE - 1)])
                out[p] = peer->inputHistory[frame & (INPUT_HISTORY_SIZE - 1)];
            else
                out[p] = peer->lastKnownInput;
        } else {
            out[p] = 0xFFFF;
        }
    }
}
