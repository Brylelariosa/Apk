#include "rollback_buffer.h"
#include <stdlib.h>
#include <string.h>

void rollbackBufferInit(RollbackBuffer* rb) {
    memset(rb, 0, sizeof(*rb));
    /* Pre-allocate 200 KB per slot for GBA state */
    for (int i = 0; i < ROLLBACK_SLOTS; i++) {
        rb->slots[i].data = malloc(200 * 1024);
        rb->slots[i].size  = 0;
        rb->slots[i].valid = false;
    }
}

void rollbackBufferFree(RollbackBuffer* rb) {
    for (int i = 0; i < ROLLBACK_SLOTS; i++) {
        free(rb->slots[i].data);
        rb->slots[i].data = NULL;
    }
}

void rollbackBufferSave(RollbackBuffer* rb, uint32_t frame,
                        const uint8_t* state, size_t size) {
    RollbackSlot* slot = &rb->slots[rb->head];
    if (size > 200 * 1024) return; /* safety */
    memcpy(slot->data, state, size);
    slot->size  = size;
    slot->frame = frame;
    slot->valid = true;
    rb->head = (rb->head + 1) % ROLLBACK_SLOTS;
}

bool rollbackBufferLoad(RollbackBuffer* rb, uint32_t frame,
                        uint8_t** stateOut, size_t* sizeOut) {
    /* Search backwards from head */
    for (int i = 0; i < ROLLBACK_SLOTS; i++) {
        int idx = ((rb->head - 1 - i) + ROLLBACK_SLOTS) % ROLLBACK_SLOTS;
        RollbackSlot* slot = &rb->slots[idx];
        if (slot->valid && slot->frame == frame) {
            *stateOut = slot->data;
            *sizeOut  = slot->size;
            return true;
        }
    }
    return false;
}
