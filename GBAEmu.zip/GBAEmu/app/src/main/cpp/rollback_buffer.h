/* rollback_buffer.h / rollback_buffer.c
 * Circular savestate buffer for rollback netcode.
 * Each slot holds a full serialized GBA state (≈180 KB compressed).
 */
#pragma once
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>

#define ROLLBACK_SLOTS 16   /* must be > MAX_ROLLBACK_FRAMES */

typedef struct {
    uint8_t* data;
    size_t   size;
    uint32_t frame;
    bool     valid;
} RollbackSlot;

typedef struct {
    RollbackSlot slots[ROLLBACK_SLOTS];
    int          head;      /* next slot to write */
} RollbackBuffer;

void rollbackBufferInit(RollbackBuffer* rb);
void rollbackBufferFree(RollbackBuffer* rb);
void rollbackBufferSave(RollbackBuffer* rb, uint32_t frame,
                        const uint8_t* state, size_t size);
bool rollbackBufferLoad(RollbackBuffer* rb, uint32_t frame,
                        uint8_t** stateOut, size_t* sizeOut);
