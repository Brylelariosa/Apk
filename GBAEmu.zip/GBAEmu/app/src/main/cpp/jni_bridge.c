/* jni_bridge.c — mGBA Android JNI bridge with LAN multiplayer */
#include <jni.h>
#include <android/log.h>
#include <android/native_window.h>
#include <android/native_window_jni.h>
#include <EGL/egl.h>
#include <GLES2/gl2.h>
#include <SLES/OpenSLES.h>
#include <SLES/OpenSLES_Android.h>
#include <pthread.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/prctl.h>
#include <time.h>

/* mGBA headers (available after FetchContent) */
#include <mgba/core/core.h>
#include <third-party/blip_buf/blip_buf.h>
#include <mgba/gba/core.h>
#include <mgba/internal/gba/gba.h>
#include <mgba-util/vfs.h>

#include "lan_sio_driver.h"
#include "audio_ring.h"

#define LOG_TAG "GBAEmu"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

#define GBA_WIDTH  240
#define GBA_HEIGHT 160

/* ── State ──────────────────────────────────────────────────────────── */
typedef struct {
    struct mCore*   core;

    pthread_t       emuThread;
    pthread_mutex_t mutex;
    pthread_cond_t  cond;
    volatile int    running;
    volatile int    paused;
    volatile uint16_t keys;

    uint32_t        framebuf[GBA_WIDTH * GBA_HEIGHT];

    ANativeWindow*  window;
    EGLDisplay      display;
    EGLSurface      surface;
    EGLContext      context;
    GLuint          texId;
    GLuint          prog;
    GLuint          vbo;

    AudioRing       audioRing;
    SLObjectItf     slEngine;
    SLObjectItf     slOutputMix;
    SLObjectItf     slPlayer;
    SLPlayItf       slPlay;
    SLAndroidSimpleBufferQueueItf slQueue;

    LanSIODriver    lanDriver;
    char            romPath[512];
    char            savePath[512];
} EmuState;

static EmuState g_emu;

/* ── OpenGL ─────────────────────────────────────────────────────────── */
static const char* VERT =
    "attribute vec2 p;attribute vec2 u;varying vec2 v;\n"
    "void main(){gl_Position=vec4(p,0,1);v=u;}\n";
static const char* FRAG =
    "precision mediump float;varying vec2 v;uniform sampler2D t;\n"
    "void main(){gl_FragColor=texture2D(t,v);}\n";

static GLuint makeShader(GLenum type, const char* src) {
    GLuint s = glCreateShader(type);
    glShaderSource(s,1,&src,NULL); glCompileShader(s); return s;
}

static void initGL(EmuState* e) {
    GLuint vs = makeShader(GL_VERTEX_SHADER, VERT);
    GLuint fs = makeShader(GL_FRAGMENT_SHADER, FRAG);
    e->prog = glCreateProgram();
    glAttachShader(e->prog,vs); glAttachShader(e->prog,fs);
    glLinkProgram(e->prog);
    glDeleteShader(vs); glDeleteShader(fs);

    glGenTextures(1, &e->texId);
    glBindTexture(GL_TEXTURE_2D, e->texId);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,GBA_WIDTH,GBA_HEIGHT,
                 0,GL_RGBA,GL_UNSIGNED_BYTE,NULL);

    static const float verts[]={-1,-1,0,1, 1,-1,1,1, -1,1,0,0, 1,1,1,0};
    glGenBuffers(1,&e->vbo);
    glBindBuffer(GL_ARRAY_BUFFER,e->vbo);
    glBufferData(GL_ARRAY_BUFFER,sizeof(verts),verts,GL_STATIC_DRAW);
}

static void renderFrame(EmuState* e) {
    if (!e->surface || e->surface==EGL_NO_SURFACE) return;
    glBindTexture(GL_TEXTURE_2D, e->texId);
    glTexSubImage2D(GL_TEXTURE_2D,0,0,0,GBA_WIDTH,GBA_HEIGHT,
                    GL_RGBA,GL_UNSIGNED_BYTE,e->framebuf);
    glUseProgram(e->prog);
    glBindBuffer(GL_ARRAY_BUFFER,e->vbo);
    GLint pos=glGetAttribLocation(e->prog,"p");
    GLint uv =glGetAttribLocation(e->prog,"u");
    glEnableVertexAttribArray(pos); glEnableVertexAttribArray(uv);
    glVertexAttribPointer(pos,2,GL_FLOAT,GL_FALSE,16,(void*)0);
    glVertexAttribPointer(uv, 2,GL_FLOAT,GL_FALSE,16,(void*)8);
    glUniform1i(glGetUniformLocation(e->prog,"t"),0);
    glDrawArrays(GL_TRIANGLE_STRIP,0,4);
    eglSwapBuffers(e->display,e->surface);
}

/* ── Audio ──────────────────────────────────────────────────────────── */
static int16_t g_abuf[2][1470];
static int     g_abufIdx = 0;

static void audioCb(SLAndroidSimpleBufferQueueItf bq, void* ctx) {
    EmuState* e = ctx;
    int16_t* buf = g_abuf[g_abufIdx^1];
    size_t got = audioRingRead(&e->audioRing, buf, 735);
    if (got<735) memset(buf+got*2,0,(735-got)*4);
    (*bq)->Enqueue(bq,buf,735*4);
    g_abufIdx^=1;
}

static void initAudio(EmuState* e) {
    audioRingInit(&e->audioRing, 8192);
    SLEngineItf eng;
    slCreateEngine(&e->slEngine,0,NULL,0,NULL,NULL);
    (*e->slEngine)->Realize(e->slEngine,SL_BOOLEAN_FALSE);
    (*e->slEngine)->GetInterface(e->slEngine,SL_IID_ENGINE,&eng);
    SLInterfaceID ids[]={SL_IID_VOLUME}; SLboolean reqs[]={SL_BOOLEAN_FALSE};
    (*eng)->CreateOutputMix(eng,&e->slOutputMix,1,ids,reqs);
    (*e->slOutputMix)->Realize(e->slOutputMix,SL_BOOLEAN_FALSE);
    SLDataLocator_AndroidSimpleBufferQueue bql={SL_DATALOCATOR_ANDROIDSIMPLEBUFFERQUEUE,2};
    SLDataFormat_PCM fmt={SL_DATAFORMAT_PCM,2,SL_SAMPLINGRATE_32,
        SL_PCMSAMPLEFORMAT_FIXED_16,SL_PCMSAMPLEFORMAT_FIXED_16,
        SL_SPEAKER_FRONT_LEFT|SL_SPEAKER_FRONT_RIGHT,SL_BYTEORDER_LITTLEENDIAN};
    SLDataSource src={&bql,&fmt};
    SLDataLocator_OutputMix outl={SL_DATALOCATOR_OUTPUTMIX,e->slOutputMix};
    SLDataSink sink={&outl,NULL};
    SLInterfaceID pids[]={SL_IID_ANDROIDSIMPLEBUFFERQUEUE}; SLboolean preqs[]={SL_BOOLEAN_TRUE};
    (*eng)->CreateAudioPlayer(eng,&e->slPlayer,&src,&sink,1,pids,preqs);
    (*e->slPlayer)->Realize(e->slPlayer,SL_BOOLEAN_FALSE);
    (*e->slPlayer)->GetInterface(e->slPlayer,SL_IID_PLAY,&e->slPlay);
    (*e->slPlayer)->GetInterface(e->slPlayer,SL_IID_ANDROIDSIMPLEBUFFERQUEUE,&e->slQueue);
    (*e->slQueue)->RegisterCallback(e->slQueue,audioCb,e);
    (*e->slPlay)->SetPlayState(e->slPlay,SL_PLAYSTATE_PLAYING);
    memset(g_abuf[0],0,sizeof(g_abuf[0]));
    (*e->slQueue)->Enqueue(e->slQueue,g_abuf[0],735*4);
}

/* ── Emulator thread ────────────────────────────────────────────────── */
static void* emuThreadFn(void* arg) {
    EmuState* e = arg;
    prctl(PR_SET_NAME,"gba_emu",0,0,0);

    /* EGL init */
    EGLint attr[]={EGL_CONTEXT_CLIENT_VERSION,2,EGL_NONE};
    e->display=eglGetDisplay(EGL_DEFAULT_DISPLAY);
    eglInitialize(e->display,NULL,NULL);
    EGLint ca[]={EGL_SURFACE_TYPE,EGL_WINDOW_BIT,EGL_RENDERABLE_TYPE,
                 EGL_OPENGL_ES2_BIT,EGL_RED_SIZE,8,EGL_GREEN_SIZE,8,
                 EGL_BLUE_SIZE,8,EGL_NONE};
    EGLConfig cfg; EGLint nc;
    eglChooseConfig(e->display,ca,&cfg,1,&nc);
    e->context=eglCreateContext(e->display,cfg,EGL_NO_CONTEXT,attr);
    e->surface=eglCreateWindowSurface(e->display,cfg,e->window,NULL);
    eglMakeCurrent(e->display,e->surface,e->surface,e->context);
    initGL(e);
    initAudio(e);

    /* mGBA core init */
    e->core = GBACoreCreate();
    if (!e->core) { LOGE("Failed to create GBA core"); return NULL; }
    e->core->init(e->core);
    mCoreInitConfig(e->core, NULL);

    /* Set video buffer — XBGR8888 pixel format */
    e->core->setVideoBuffer(e->core, e->framebuf, GBA_WIDTH);

    /* Set audio */
    e->core->setAudioBufferSize(e->core, 512);
    struct blip_t* blipL = e->core->getAudioChannel(e->core, 0);
    struct blip_t* blipR = e->core->getAudioChannel(e->core, 1);
    if (blipL) blip_set_rates(blipL, GBA_ARM7TDMI_FREQUENCY, 32768);
    if (blipR) blip_set_rates(blipR, GBA_ARM7TDMI_FREQUENCY, 32768);

    /* Load ROM */
    struct VFile* rom = VFileOpen(e->romPath, O_RDONLY);
    if (!rom) { LOGE("Cannot open ROM: %s", e->romPath); e->core->deinit(e->core); return NULL; }
    e->core->loadROM(e->core, rom);

    /* Load save */
    struct VFile* sav = VFileOpen(e->savePath, O_RDWR|O_CREAT);
    if (sav) e->core->loadSave(e->core, sav);

    e->core->reset(e->core);
    LOGI("mGBA running: %s", e->romPath);

    const long FRAME_NS = 16750000L; /* 59.7275 fps */
    struct timespec next;
    clock_gettime(CLOCK_MONOTONIC, &next);

    while (e->running) {
        pthread_mutex_lock(&e->mutex);
        while (e->paused && e->running)
            pthread_cond_wait(&e->cond, &e->mutex);
        uint16_t keys = e->keys;
        pthread_mutex_unlock(&e->mutex);
        if (!e->running) break;

        /* LAN: send local keys, get all-player keys */
        if (e->lanDriver.active) {
            lanSIOSetKeys(&e->lanDriver, keys);
            uint16_t allKeys[4];
            lanSIOGetAllKeys(&e->lanDriver, allKeys);
            /* For now use player 0 keys — full link-cable emulation
               requires hooking mGBA's SIO registers */
            keys = allKeys[0];
        }

        e->core->setKeys(e->core, keys);
        e->core->runFrame(e->core);

        /* Drain audio */
        if (blipL && blipR) {
            int avail = blip_samples_avail(blipL);
            if (avail > 0) {
                int16_t tmp[2048];
                int got = blip_read_samples(blipL, tmp,   1024, 1);
                        blip_read_samples(blipR, tmp+1, 1024, 1);
                audioRingWrite(&e->audioRing, tmp, got);
            }
        }

        renderFrame(e);

        next.tv_nsec += FRAME_NS;
        if (next.tv_nsec >= 1000000000L) { next.tv_nsec -= 1000000000L; next.tv_sec++; }
        clock_nanosleep(CLOCK_MONOTONIC, TIMER_ABSTIME, &next, NULL);
    }

    e->core->saveSave(e->core, sav);
    e->core->deinit(e->core);
    eglMakeCurrent(e->display,EGL_NO_SURFACE,EGL_NO_SURFACE,EGL_NO_CONTEXT);
    eglDestroySurface(e->display,e->surface);
    eglDestroyContext(e->display,e->context);
    return NULL;
}

/* ═══════════════════ JNI ═══════════════════════════════════════════ */

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void* r) {
    (void)vm;(void)r;
    memset(&g_emu,0,sizeof(g_emu));
    pthread_mutex_init(&g_emu.mutex,NULL);
    pthread_cond_init(&g_emu.cond,NULL);
    return JNI_VERSION_1_6;
}

JNIEXPORT void JNICALL
Java_com_gbaemu_core_GBACore_nativeInit(JNIEnv* e, jobject t,
        jstring rom, jstring sav, jobject surf) {
    (void)t;
    const char* r = (*e)->GetStringUTFChars(e,rom,NULL);
    const char* s = (*e)->GetStringUTFChars(e,sav,NULL);
    strncpy(g_emu.romPath, r, 511);
    strncpy(g_emu.savePath,s, 511);
    g_emu.window  = ANativeWindow_fromSurface(e,surf);
    g_emu.running = 1; g_emu.paused = 0;
    (*e)->ReleaseStringUTFChars(e,rom,r);
    (*e)->ReleaseStringUTFChars(e,sav,s);
    pthread_create(&g_emu.emuThread,NULL,emuThreadFn,&g_emu);
}

JNIEXPORT void JNICALL
Java_com_gbaemu_core_GBACore_nativeSetKeys(JNIEnv* e, jobject t, jint k) {
    (void)e;(void)t;
    __atomic_store_n(&g_emu.keys,(uint16_t)k,__ATOMIC_RELEASE);
}

JNIEXPORT void JNICALL
Java_com_gbaemu_core_GBACore_nativePause(JNIEnv* e, jobject t) {
    (void)e;(void)t;
    pthread_mutex_lock(&g_emu.mutex); g_emu.paused=1; pthread_mutex_unlock(&g_emu.mutex);
}

JNIEXPORT void JNICALL
Java_com_gbaemu_core_GBACore_nativeResume(JNIEnv* e, jobject t) {
    (void)e;(void)t;
    pthread_mutex_lock(&g_emu.mutex); g_emu.paused=0;
    pthread_cond_signal(&g_emu.cond); pthread_mutex_unlock(&g_emu.mutex);
}

JNIEXPORT void JNICALL
Java_com_gbaemu_core_GBACore_nativeStop(JNIEnv* e, jobject t) {
    (void)e;(void)t;
    pthread_mutex_lock(&g_emu.mutex); g_emu.running=0; g_emu.paused=0;
    pthread_cond_signal(&g_emu.cond); pthread_mutex_unlock(&g_emu.mutex);
    pthread_join(g_emu.emuThread,NULL);
    if(g_emu.window){ANativeWindow_release(g_emu.window);g_emu.window=NULL;}
}

JNIEXPORT void JNICALL
Java_com_gbaemu_core_GBACore_nativeSurfaceChanged(JNIEnv* e, jobject t,
        jobject surf, jint w, jint h) {
    (void)t;(void)w;(void)h;
    ANativeWindow* n=ANativeWindow_fromSurface(e,surf);
    pthread_mutex_lock(&g_emu.mutex);
    if(g_emu.window) ANativeWindow_release(g_emu.window);
    g_emu.window=n;
    pthread_mutex_unlock(&g_emu.mutex);
}

JNIEXPORT void JNICALL
Java_com_gbaemu_core_GBACore_nativeLanHost(JNIEnv* e, jobject t, jint port) {
    (void)e;(void)t; lanSIOHost(&g_emu.lanDriver,(uint16_t)port);
}

JNIEXPORT void JNICALL
Java_com_gbaemu_core_GBACore_nativeLanConnect(JNIEnv* e, jobject t,
        jstring ip, jint port, jint pid) {
    (void)t;
    const char* s=(*e)->GetStringUTFChars(e,ip,NULL);
    lanSIOConnect(&g_emu.lanDriver,s,(uint16_t)port,pid);
    (*e)->ReleaseStringUTFChars(e,ip,s);
}

JNIEXPORT void JNICALL
Java_com_gbaemu_core_GBACore_nativeLanDisconnect(JNIEnv* e, jobject t) {
    (void)e;(void)t; lanSIODisconnect(&g_emu.lanDriver);
}

JNIEXPORT jint JNICALL
Java_com_gbaemu_core_GBACore_nativeLanGetPing(JNIEnv* e, jobject t) {
    (void)e;(void)t; return (jint)lanSIOGetPing(&g_emu.lanDriver);
}
