#include "audio_ring.h"
#include <stdlib.h>
#include <string.h>

void audioRingInit(AudioRing* r, size_t stereoFrames) {
    r->cap = stereoFrames * 2; /* 2 samples per frame */
    r->buf = calloc(r->cap, sizeof(int16_t));
    atomic_init(&r->readPos,  0);
    atomic_init(&r->writePos, 0);
}

void audioRingFree(AudioRing* r) {
    free(r->buf);
    r->buf = NULL;
}

size_t audioRingWrite(AudioRing* r, const int16_t* data, size_t frames) {
    size_t w    = atomic_load_explicit(&r->writePos, memory_order_relaxed);
    size_t rd   = atomic_load_explicit(&r->readPos,  memory_order_acquire);
    size_t free = (r->cap - (w - rd) % r->cap) / 2;
    size_t todo = frames < free ? frames : free;
    for (size_t i = 0; i < todo; i++) {
        size_t idx = ((w + i*2) % r->cap);
        r->buf[idx]   = data[i*2];
        r->buf[idx+1] = data[i*2+1];
    }
    atomic_store_explicit(&r->writePos, w + todo*2, memory_order_release);
    return todo;
}

size_t audioRingRead(AudioRing* r, int16_t* out, size_t frames) {
    size_t rd   = atomic_load_explicit(&r->readPos,  memory_order_relaxed);
    size_t w    = atomic_load_explicit(&r->writePos, memory_order_acquire);
    size_t avail = ((w - rd) % r->cap) / 2;
    size_t todo  = frames < avail ? frames : avail;
    for (size_t i = 0; i < todo; i++) {
        size_t idx = (rd + i*2) % r->cap;
        out[i*2]   = r->buf[idx];
        out[i*2+1] = r->buf[idx+1];
    }
    atomic_store_explicit(&r->readPos, rd + todo*2, memory_order_release);
    return todo;
}
