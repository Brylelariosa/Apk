/* audio_ring.h / audio_ring.c
 * Lock-free SPSC ring buffer for 16-bit stereo audio samples.
 */
#pragma once
#include <stdint.h>
#include <stddef.h>
#include <stdatomic.h>

typedef struct {
    int16_t*        buf;     /* interleaved L,R samples */
    size_t          cap;     /* total samples (stereo pairs * 2) */
    atomic_size_t   readPos;
    atomic_size_t   writePos;
} AudioRing;

void   audioRingInit (AudioRing* r, size_t stereoFrames);
void   audioRingFree (AudioRing* r);
size_t audioRingWrite(AudioRing* r, const int16_t* data, size_t frames);
size_t audioRingRead (AudioRing* r, int16_t* out,  size_t frames);
