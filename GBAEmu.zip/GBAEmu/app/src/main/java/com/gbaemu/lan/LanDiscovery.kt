package com.gbaemu.lan

import android.content.Context
import android.net.wifi.WifiManager
import kotlinx.coroutines.*
import java.net.*
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Discovers other GBAEmu instances on the local network using UDP broadcast.
 *
 * Protocol (all little-endian):
 *   ANNOUNCE packet (12 bytes):
 *     [0]    magic[0] = 0x47 ('G')
 *     [1]    magic[1] = 0x42 ('B')
 *     [2]    magic[2] = 0x41 ('A')
 *     [3]    type     = 0x01 (announce) | 0x02 (response) | 0x03 (leave)
 *     [4-5]  port     (uint16)
 *     [6]    playerId (uint8)
 *     [7]    maxPlayers (uint8)  — host fills this
 *     [8-11] checksum (FNV-1a of bytes 0-7)
 *
 * The host sends ANNOUNCE every 2 s; clients respond with RESPONSE so
 * the host knows who is on the network.
 */
class LanDiscovery(private val context: Context) {

    data class Peer(
        val ip: String,
        val port: Int,
        val playerId: Int,
        val maxPlayers: Int,
        val lastSeenMs: Long = System.currentTimeMillis()
    )

    private val DISCOVERY_PORT = 54322
    private val MAGIC = byteArrayOf(0x47, 0x42, 0x41)
    private val TYPE_ANNOUNCE  = 0x01.toByte()
    private val TYPE_RESPONSE  = 0x02.toByte()
    private val TYPE_LEAVE     = 0x03.toByte()

    private var socket: DatagramSocket? = null
    private var multicastLock: WifiManager.MulticastLock? = null
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private val _peers = mutableMapOf<String, Peer>()
    val peers: Map<String, Peer> get() = _peers.toMap()

    var onPeerFound  : ((Peer) -> Unit)? = null
    var onPeerLeft   : ((String) -> Unit)? = null

    private fun acquireMulticastLock() {
        val wifi = context.applicationContext
            .getSystemService(Context.WIFI_SERVICE) as WifiManager
        multicastLock = wifi.createMulticastLock("GBAEmu")
            .also { it.setReferenceCounted(true); it.acquire() }
    }

    fun startHosting(dataPort: Int, maxPlayers: Int, playerId: Int = 0) {
        acquireMulticastLock()
        socket = DatagramSocket(DISCOVERY_PORT).apply {
            broadcast = true
            soTimeout = 500
        }
        scope.launch {
            // Listen for responses
            launch { receiveLoop(isHost = true) }
            // Announce periodically
            while (isActive) {
                broadcast(TYPE_ANNOUNCE, dataPort, playerId.toByte(), maxPlayers.toByte())
                delay(2000)
            }
        }
    }

    fun startScanning(dataPort: Int, playerId: Int) {
        acquireMulticastLock()
        socket = DatagramSocket(DISCOVERY_PORT).apply {
            broadcast = true
            soTimeout = 500
        }
        scope.launch {
            launch { receiveLoop(isHost = false) }
            // Periodically re-send responses so the host sees us
            while (isActive) {
                broadcast(TYPE_RESPONSE, dataPort, playerId.toByte(), 0)
                delay(3000)
            }
        }
    }

    fun stop() {
        scope.cancel()
        broadcast(TYPE_LEAVE, 0, 0, 0)
        socket?.close()
        multicastLock?.release()
    }

    private fun broadcast(type: Byte, port: Int, playerId: Byte, maxPlayers: Byte) {
        try {
            val buf = buildPacket(type, port, playerId, maxPlayers)
            val addr = InetAddress.getByName("255.255.255.255")
            socket?.send(DatagramPacket(buf, buf.size, addr, DISCOVERY_PORT))
        } catch (_: Exception) {}
    }

    private fun buildPacket(type: Byte, port: Int, playerId: Byte, maxPlayers: Byte): ByteArray {
        val bb = ByteBuffer.allocate(12).order(ByteOrder.LITTLE_ENDIAN)
        bb.put(MAGIC)
        bb.put(type)
        bb.putShort(port.toShort())
        bb.put(playerId)
        bb.put(maxPlayers)
        val cs = fnv1a(bb.array(), 8)
        bb.putInt(cs)
        return bb.array()
    }

    private suspend fun receiveLoop(isHost: Boolean) {
        val buf = ByteArray(64)
        val pkt = DatagramPacket(buf, buf.size)
        while (scope.isActive) {
            try {
                socket?.receive(pkt)
                parsePacket(pkt, isHost)
            } catch (_: SocketTimeoutException) {
                // Prune stale peers
                val now = System.currentTimeMillis()
                val stale = _peers.filter { now - it.value.lastSeenMs > 6000 }
                stale.keys.forEach { ip ->
                    _peers.remove(ip)
                    withContext(Dispatchers.Main) { onPeerLeft?.invoke(ip) }
                }
            } catch (_: Exception) {}
        }
    }

    private suspend fun parsePacket(pkt: DatagramPacket, isHost: Boolean) {
        val data = pkt.data
        if (data.size < 12) return
        if (data[0] != MAGIC[0] || data[1] != MAGIC[1] || data[2] != MAGIC[2]) return

        val bb = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN)
        bb.position(3)
        val type       = bb.get()
        val port       = bb.short.toInt() and 0xFFFF
        val playerId   = bb.get().toInt() and 0xFF
        val maxPlayers = bb.get().toInt() and 0xFF

        val ip = pkt.address.hostAddress ?: return

        when (type) {
            TYPE_ANNOUNCE, TYPE_RESPONSE -> {
                val peer = Peer(ip, port, playerId, maxPlayers)
                val isNew = !_peers.containsKey(ip)
                _peers[ip] = peer
                if (isNew) {
                    withContext(Dispatchers.Main) { onPeerFound?.invoke(peer) }
                }
            }
            TYPE_LEAVE -> {
                if (_peers.remove(ip) != null) {
                    withContext(Dispatchers.Main) { onPeerLeft?.invoke(ip) }
                }
            }
        }
    }

    private fun fnv1a(data: ByteArray, len: Int): Int {
        var h = -2128831035 // 0x811c9dc5
        for (i in 0 until len) {
            h = h xor data[i].toInt()
            h *= 16777619
        }
        return h
    }
}
