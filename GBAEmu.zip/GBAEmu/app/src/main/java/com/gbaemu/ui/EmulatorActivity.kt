package com.gbaemu.ui

import android.os.Bundle
import android.view.*
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.gbaemu.core.GBACore
import com.gbaemu.databinding.ActivityEmulatorBinding
import com.gbaemu.input.TouchController
import kotlinx.coroutines.*

class EmulatorActivity : AppCompatActivity(), SurfaceHolder.Callback {

    private lateinit var binding: ActivityEmulatorBinding
    private lateinit var touchController: TouchController
    private var romPath  = ""
    private var savePath = ""
    private var lanMode  = false
    private var pingJob  : Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Full-screen immersive
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        )

        binding = ActivityEmulatorBinding.inflate(layoutInflater)
        setContentView(binding.root)

        romPath  = intent.getStringExtra(EXTRA_ROM_PATH)  ?: ""
        savePath = intent.getStringExtra(EXTRA_SAVE_PATH) ?: ""
        lanMode  = intent.getBooleanExtra(EXTRA_LAN_MODE, false)

        binding.surfaceView.holder.addCallback(this)

        touchController = TouchController(binding.controllerOverlay) { keys ->
            GBACore.nativeSetKeys(keys)
        }

        if (lanMode) {
            binding.pingOverlay.visibility = View.VISIBLE
            pingJob = lifecycleScope.launch {
                while (isActive) {
                    delay(500)
                    val ms = GBACore.nativeLanGetPing()
                    val txt = if (ms >= 0) "LAN ${ms}ms" else "LAN --"
                    binding.pingOverlay.text = txt
                    binding.pingOverlay.setTextColor(pingColor(ms))
                }
            }
        }
    }

    private fun pingColor(ms: Int) = when {
        ms < 0   -> 0xFFAAAAAA.toInt()
        ms < 16  -> 0xFF44FF44.toInt()
        ms < 50  -> 0xFFFFFF44.toInt()
        else     -> 0xFFFF4444.toInt()
    }

    // ── SurfaceHolder.Callback ────────────────────────────────────────

    override fun surfaceCreated(holder: SurfaceHolder) {
        if (romPath.isNotEmpty()) {
            GBACore.nativeInit(romPath, savePath, holder.surface)
        }
    }

    override fun surfaceChanged(holder: SurfaceHolder, fmt: Int, w: Int, h: Int) {
        GBACore.nativeSurfaceChanged(holder.surface, w, h)
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        GBACore.nativePause()
    }

    // ── Lifecycle ─────────────────────────────────────────────────────

    override fun onResume() {
        super.onResume()
        GBACore.nativeResume()
    }

    override fun onPause() {
        super.onPause()
        GBACore.nativePause()
    }

    override fun onDestroy() {
        pingJob?.cancel()
        GBACore.nativeStop()
        super.onDestroy()
    }

    // ── Hardware keys (game controllers / keyboards) ──────────────────

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        val bit = keyCodeToGBA(keyCode) ?: return super.onKeyDown(keyCode, event)
        touchController.pressHardwareKey(bit)
        return true
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean {
        val bit = keyCodeToGBA(keyCode) ?: return super.onKeyUp(keyCode, event)
        touchController.releaseHardwareKey(bit)
        return true
    }

    private fun keyCodeToGBA(keyCode: Int) = when (keyCode) {
        KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_Z         -> GBACore.Keys.A
        KeyEvent.KEYCODE_BUTTON_B, KeyEvent.KEYCODE_X         -> GBACore.Keys.B
        KeyEvent.KEYCODE_BUTTON_L1, KeyEvent.KEYCODE_Q        -> GBACore.Keys.L
        KeyEvent.KEYCODE_BUTTON_R1, KeyEvent.KEYCODE_W        -> GBACore.Keys.R
        KeyEvent.KEYCODE_BUTTON_START, KeyEvent.KEYCODE_ENTER -> GBACore.Keys.START
        KeyEvent.KEYCODE_BUTTON_SELECT, KeyEvent.KEYCODE_BACK -> GBACore.Keys.SELECT
        KeyEvent.KEYCODE_DPAD_UP,    KeyEvent.KEYCODE_W       -> GBACore.Keys.UP
        KeyEvent.KEYCODE_DPAD_DOWN,  KeyEvent.KEYCODE_S       -> GBACore.Keys.DOWN
        KeyEvent.KEYCODE_DPAD_LEFT,  KeyEvent.KEYCODE_A       -> GBACore.Keys.LEFT
        KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_D       -> GBACore.Keys.RIGHT
        else -> null
    }

    companion object {
        const val EXTRA_ROM_PATH  = "rom_path"
        const val EXTRA_SAVE_PATH = "save_path"
        const val EXTRA_LAN_MODE  = "lan_mode"
    }
}
