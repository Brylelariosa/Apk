package com.gbaemu.lan

import android.content.Context
import com.gbaemu.core.GBACore
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.net.NetworkInterface

data class LanSession(
    val isHost    : Boolean,
    val localIp   : String,
    val port      : Int,
    val playerId  : Int,
    val maxPlayers: Int
)

sealed class LanState {
    object Idle                                  : LanState()
    object Discovering                           : LanState()
    data class Lobby(val session: LanSession,
                     val peers: List<LanDiscovery.Peer>) : LanState()
    data class InGame(val session: LanSession,
                      val pingMs: Int)            : LanState()
    data class Error(val msg: String)            : LanState()
}

/**
 * High-level LAN session manager.
 * Wires together LanDiscovery (UDP broadcast) and GBACore (native SIO driver).
 */
class LanSessionManager(private val context: Context) {

    companion object {
        const val DATA_PORT = 54321
        const val MAX_PLAYERS = 4
    }

    private val _state = MutableStateFlow<LanState>(LanState.Idle)
    val state: StateFlow<LanState> = _state

    private val discovery = LanDiscovery(context)
    private val scope     = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private val peerList  = mutableListOf<LanDiscovery.Peer>()
    private var session   : LanSession? = null

    // ── Host ──────────────────────────────────────────────────────────
    fun host(romHash: String) {
        val ip = getLocalIp()
        val sess = LanSession(
            isHost     = true,
            localIp    = ip,
            port       = DATA_PORT,
            playerId   = 0,
            maxPlayers = MAX_PLAYERS
        )
        session = sess

        discovery.onPeerFound = { peer ->
            peerList.add(peer)
            _state.value = LanState.Lobby(sess, peerList.toList())
        }
        discovery.onPeerLeft = { ip2 ->
            peerList.removeAll { it.ip == ip2 }
            _state.value = LanState.Lobby(sess, peerList.toList())
        }

        discovery.startHosting(DATA_PORT, MAX_PLAYERS, playerId = 0)
        GBACore.nativeLanHost(DATA_PORT)

        _state.value = LanState.Lobby(sess, emptyList())
    }

    // ── Join ──────────────────────────────────────────────────────────
    fun join(hostPeer: LanDiscovery.Peer) {
        val nextId = (peerList.maxOfOrNull { it.playerId } ?: 0) + 1
        val sess = LanSession(
            isHost     = false,
            localIp    = getLocalIp(),
            port       = DATA_PORT + nextId,
            playerId   = nextId,
            maxPlayers = hostPeer.maxPlayers
        )
        session = sess

        GBACore.nativeLanConnect(hostPeer.ip, hostPeer.port, nextId)
        discovery.startScanning(sess.port, nextId)
        _state.value = LanState.Lobby(sess, listOf(hostPeer))
    }

    // ── Start game ────────────────────────────────────────────────────
    fun startGame() {
        val sess = session ?: return
        _state.value = LanState.InGame(sess, 0)

        // Poll ping every second
        scope.launch {
            while (isActive) {
                delay(1000)
                val ping = GBACore.nativeLanGetPing()
                _state.update {
                    if (it is LanState.InGame) it.copy(pingMs = ping) else it
                }
            }
        }
    }

    // ── Disconnect ────────────────────────────────────────────────────
    fun disconnect() {
        scope.cancel()
        discovery.stop()
        GBACore.nativeLanDisconnect()
        peerList.clear()
        session = null
        _state.value = LanState.Idle
    }

    // ── Utilities ─────────────────────────────────────────────────────
    fun getLocalIp(): String {
        return try {
            NetworkInterface.getNetworkInterfaces()?.toList()
                ?.flatMap { it.inetAddresses.toList() }
                ?.firstOrNull { !it.isLoopbackAddress && it.hostAddress?.contains('.') == true }
                ?.hostAddress ?: "0.0.0.0"
        } catch (e: Exception) {
            "0.0.0.0"
        }
    }

    fun scanForGames() {
        discovery.onPeerFound = { peer ->
            peerList.add(peer)
            _state.value = LanState.Discovering
        }
        discovery.startScanning(DATA_PORT, playerId = -1)
        _state.value = LanState.Discovering
    }

    fun getDiscoveredPeers(): List<LanDiscovery.Peer> = peerList.toList()
}
