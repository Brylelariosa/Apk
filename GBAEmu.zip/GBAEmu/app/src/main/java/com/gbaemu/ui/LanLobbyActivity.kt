package com.gbaemu.ui

import android.content.Intent
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.*
import com.gbaemu.R
import com.gbaemu.databinding.ActivityLanLobbyBinding
import com.gbaemu.lan.*
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class LanLobbyActivity : AppCompatActivity() {

    private lateinit var binding : ActivityLanLobbyBinding
    private lateinit var manager : LanSessionManager
    private val peerAdapter = PeerAdapter { peer -> joinGame(peer) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLanLobbyBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.title = "LAN Multiplayer"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        manager = LanSessionManager(this)

        binding.recyclerPeers.layoutManager = LinearLayoutManager(this)
        binding.recyclerPeers.adapter = peerAdapter

        // HOST button
        binding.btnHost.setOnClickListener {
            val romPath = intent.getStringExtra(EXTRA_ROM_PATH)
            manager.host(romPath ?: "")
            binding.btnHost.isEnabled = false
            binding.btnScan.isEnabled = false
            binding.hostPanel.visibility = View.VISIBLE
            binding.tvLocalIp.text = "Your IP: ${manager.getLocalIp()}"
            binding.tvPort.text    = "Port: ${LanSessionManager.DATA_PORT}"
        }

        // SCAN button
        binding.btnScan.setOnClickListener {
            manager.scanForGames()
            binding.btnHost.isEnabled = false
            binding.btnScan.isEnabled = false
            binding.scanPanel.visibility = View.VISIBLE
        }

        // Start game (host only)
        binding.btnStartGame.setOnClickListener {
            val state = manager.state.value
            if (state is LanState.Lobby && state.session.isHost) {
                manager.startGame()
                launchEmulator()
            }
        }

        // Observe state
        lifecycleScope.launch {
            manager.state.collectLatest { state ->
                updateUI(state)
            }
        }
    }

    private fun updateUI(state: LanState) {
        when (state) {
            is LanState.Idle -> {
                binding.tvStatus.text = "Choose Host or Scan to find games"
            }
            is LanState.Discovering -> {
                binding.tvStatus.text = "Scanning for games…"
                peerAdapter.submitList(manager.getDiscoveredPeers())
            }
            is LanState.Lobby -> {
                val cnt = state.peers.size
                binding.tvStatus.text = if (state.session.isHost)
                    "Hosting — $cnt / ${LanSessionManager.MAX_PLAYERS - 1} players joined"
                else
                    "Joined lobby — waiting for host to start"
                peerAdapter.submitList(state.peers)
                binding.btnStartGame.isEnabled = state.session.isHost && cnt > 0
            }
            is LanState.InGame -> {
                binding.tvStatus.text = "In game — ping ${state.pingMs}ms"
            }
            is LanState.Error -> {
                binding.tvStatus.text = "Error: ${state.msg}"
                Toast.makeText(this, state.msg, Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun joinGame(peer: LanDiscovery.Peer) {
        manager.join(peer)
        launchEmulator()
    }

    private fun launchEmulator() {
        val romPath  = intent.getStringExtra(EXTRA_ROM_PATH)  ?: return
        val savePath = intent.getStringExtra(EXTRA_SAVE_PATH) ?: return
        startActivity(Intent(this, EmulatorActivity::class.java).apply {
            putExtra(EmulatorActivity.EXTRA_ROM_PATH,  romPath)
            putExtra(EmulatorActivity.EXTRA_SAVE_PATH, savePath)
            putExtra(EmulatorActivity.EXTRA_LAN_MODE,  true)
        })
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }

    override fun onDestroy() {
        super.onDestroy()
        if (manager.state.value is LanState.Idle) manager.disconnect()
    }

    companion object {
        const val EXTRA_ROM_PATH  = "rom_path"
        const val EXTRA_SAVE_PATH = "save_path"
    }
}

// ── Peer list adapter ─────────────────────────────────────────────────────

class PeerAdapter(
    private val onJoin: (LanDiscovery.Peer) -> Unit
) : ListAdapter<LanDiscovery.Peer, PeerAdapter.VH>(
    object : DiffUtil.ItemCallback<LanDiscovery.Peer>() {
        override fun areItemsTheSame(a: LanDiscovery.Peer, b: LanDiscovery.Peer) = a.ip == b.ip
        override fun areContentsTheSame(a: LanDiscovery.Peer, b: LanDiscovery.Peer) = a == b
    }
) {
    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        val name  : TextView = view.findViewById(R.id.peer_name)
        val detail: TextView = view.findViewById(R.id.peer_detail)
        val btnJoin: Button  = view.findViewById(R.id.btn_join)
    }

    override fun onCreateViewHolder(parent: ViewGroup, type: Int): VH {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_peer, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, pos: Int) {
        val p = getItem(pos)
        holder.name.text   = "Player ${p.playerId}  (${p.ip})"
        holder.detail.text = "Port ${p.port}"
        holder.btnJoin.visibility = if (p.maxPlayers > 0) View.VISIBLE else View.GONE
        holder.btnJoin.setOnClickListener { onJoin(p) }
    }
}
