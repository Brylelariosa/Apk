package com.gbaemu.core

import android.view.Surface

/**
 * Thin Kotlin wrapper around the native GBA emulator core.
 * All heavy lifting is in libgbaemu.so via JNI.
 */
object GBACore {

    init {
        System.loadLibrary("gbaemu")
    }

    // ── Core lifecycle ────────────────────────────────────────────────
    external fun nativeInit(romPath: String, savePath: String, surface: Surface)
    external fun nativeStop()
    external fun nativePause()
    external fun nativeResume()
    external fun nativeSurfaceChanged(surface: Surface, w: Int, h: Int)

    // ── Input: 16-bit GBA key mask ────────────────────────────────────
    external fun nativeSetKeys(keys: Int)

    // ── LAN multiplayer ───────────────────────────────────────────────
    external fun nativeLanHost(port: Int)
    external fun nativeLanConnect(ip: String, port: Int, playerId: Int)
    external fun nativeLanDisconnect()
    external fun nativeLanGetPing(): Int

    // ── GBA key bit positions (matches GBA hardware) ──────────────────
    object Keys {
        const val A      = 1 shl 0
        const val B      = 1 shl 1
        const val SELECT = 1 shl 2
        const val START  = 1 shl 3
        const val RIGHT  = 1 shl 4
        const val LEFT   = 1 shl 5
        const val UP     = 1 shl 6
        const val DOWN   = 1 shl 7
        const val R      = 1 shl 8
        const val L      = 1 shl 9
    }
}
