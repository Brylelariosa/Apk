package com.gbaemu.input

import android.content.Context
import android.graphics.Canvas
import android.util.AttributeSet
import android.view.View

/**
 * A transparent View used as the controller overlay.
 * Actual drawing and touch handling is delegated to TouchController
 * once it is attached via [setController].
 */
class ControllerOverlayView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var controller: TouchController? = null

    fun setController(tc: TouchController) {
        controller = tc
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        controller?.updateLayout(w, h)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        controller?.draw(canvas)
    }
}
