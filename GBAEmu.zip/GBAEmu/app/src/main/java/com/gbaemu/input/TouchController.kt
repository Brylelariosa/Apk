package com.gbaemu.input

import android.graphics.*
import android.view.*
import com.gbaemu.core.GBACore

/**
 * Renders and handles the on-screen GBA controller overlay.
 * Uses a custom View drawn with Canvas for minimal latency.
 *
 * Layout (landscape):
 *   Left side  : D-pad
 *   Right side : A / B buttons + L / R shoulders
 *   Center-bottom: Start / Select
 */
class TouchController(
    private val view: View,
    private val onKeysChanged: (Int) -> Unit
) {

    private var pressedKeys   = 0
    private var hardwareKeys  = 0

    // Hit regions (computed in onLayout)
    private val dpadCenter    = PointF()
    private val btnACenter    = PointF()
    private val btnBCenter    = PointF()
    private val btnLRect      = RectF()
    private val btnRRect      = RectF()
    private val btnStartRect  = RectF()
    private val btnSelectRect = RectF()

    private val DPAD_RADIUS  get() = view.width * 0.10f
    private val BTN_RADIUS   get() = view.width * 0.050f
    private val SHOULDER_H   get() = view.height * 0.12f
    private val SHOULDER_W   get() = view.width  * 0.12f

    // Paint objects
    private val paintBase = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x55FFFFFF.toInt(); style = Paint.Style.FILL
    }
    private val paintPressed = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xAAFFFFFF.toInt(); style = Paint.Style.FILL
    }
    private val paintText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textAlign = Paint.Align.CENTER
        textSize = 28f; typeface = Typeface.DEFAULT_BOLD
    }

    private val activePointers = mutableMapOf<Int, Int>() // pointerId → keyMask

    init {
        // Make the overlay a transparent drawing surface
        view.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        view.setOnTouchListener { v, event -> onTouch(v, event); true }

        // Override onDraw via a custom overlay class set in XML (ControllerOverlayView)
        // For simplicity, we draw via a dedicated ControllerOverlayView (see below)
    }

    fun pressHardwareKey(key: Int)  { hardwareKeys = hardwareKeys  or  key; flush() }
    fun releaseHardwareKey(key: Int){ hardwareKeys = hardwareKeys and key.inv(); flush() }

    private fun onTouch(v: View, event: MotionEvent) {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN,
            MotionEvent.ACTION_POINTER_DOWN -> {
                val idx = event.actionIndex
                val pid = event.getPointerId(idx)
                val x   = event.getX(idx)
                val y   = event.getY(idx)
                val k   = hittest(x, y)
                activePointers[pid] = k
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until event.pointerCount) {
                    val pid = event.getPointerId(i)
                    val k   = hittest(event.getX(i), event.getY(i))
                    activePointers[pid] = k
                }
            }
            MotionEvent.ACTION_UP,
            MotionEvent.ACTION_POINTER_UP -> {
                val pid = event.getPointerId(event.actionIndex)
                activePointers.remove(pid)
            }
            MotionEvent.ACTION_CANCEL -> activePointers.clear()
        }
        pressedKeys = activePointers.values.fold(0) { acc, k -> acc or k }
        flush()
        v.invalidate()
    }

    private fun flush() {
        onKeysChanged(pressedKeys or hardwareKeys)
    }

    private fun hittest(x: Float, y: Float): Int {
        var keys = 0

        // D-pad — octant detection
        val dx = x - dpadCenter.x
        val dy = y - dpadCenter.y
        val dist = Math.hypot(dx.toDouble(), dy.toDouble()).toFloat()
        if (dist < DPAD_RADIUS * 1.5f && dist > DPAD_RADIUS * 0.1f) {
            val angle = Math.toDegrees(Math.atan2(dy.toDouble(), dx.toDouble())).toFloat()
            // 8-way
            keys = keys or when {
                angle in -22.5f..22.5f                    -> GBACore.Keys.RIGHT
                angle in  22.5f..67.5f                    -> GBACore.Keys.RIGHT or GBACore.Keys.DOWN
                angle in  67.5f..112.5f                   -> GBACore.Keys.DOWN
                angle in  112.5f..157.5f                  -> GBACore.Keys.LEFT or GBACore.Keys.DOWN
                angle >= 157.5f || angle <= -157.5f       -> GBACore.Keys.LEFT
                angle in -157.5f..-112.5f                 -> GBACore.Keys.LEFT or GBACore.Keys.UP
                angle in -112.5f..-67.5f                  -> GBACore.Keys.UP
                angle in -67.5f..-22.5f                   -> GBACore.Keys.RIGHT or GBACore.Keys.UP
                else -> 0
            }
        }

        // A button
        if (dist(x, y, btnACenter.x, btnACenter.y) < BTN_RADIUS * 1.3f)
            keys = keys or GBACore.Keys.A

        // B button
        if (dist(x, y, btnBCenter.x, btnBCenter.y) < BTN_RADIUS * 1.3f)
            keys = keys or GBACore.Keys.B

        // Shoulders
        if (btnLRect.contains(x, y)) keys = keys or GBACore.Keys.L
        if (btnRRect.contains(x, y)) keys = keys or GBACore.Keys.R

        // Start / Select
        if (btnStartRect.contains(x, y))  keys = keys or GBACore.Keys.START
        if (btnSelectRect.contains(x, y)) keys = keys or GBACore.Keys.SELECT

        return keys
    }

    private fun dist(x1: Float, y1: Float, x2: Float, y2: Float) =
        Math.hypot((x1 - x2).toDouble(), (y1 - y2).toDouble()).toFloat()

    /** Called by ControllerOverlayView.onSizeChanged */
    fun updateLayout(w: Int, h: Int) {
        val wf = w.toFloat(); val hf = h.toFloat()
        // D-pad — left quarter
        dpadCenter.set(wf * 0.15f, hf * 0.65f)
        // A / B — right side
        btnACenter.set(wf * 0.87f, hf * 0.55f)
        btnBCenter.set(wf * 0.80f, hf * 0.70f)
        // Shoulders
        btnLRect.set(0f, 0f, SHOULDER_W, SHOULDER_H)
        btnRRect.set(wf - SHOULDER_W, 0f, wf, SHOULDER_H)
        // Start / Select — bottom center
        val midX = wf * 0.5f; val midY = hf * 0.88f
        btnSelectRect.set(midX - 120f, midY - 24f, midX - 10f, midY + 24f)
        btnStartRect .set(midX + 10f,  midY - 24f, midX + 120f, midY + 24f)
    }

    /** Called by ControllerOverlayView.onDraw */
    fun draw(canvas: Canvas) {
        val p = pressedKeys or hardwareKeys

        // D-pad
        drawDpad(canvas, p)

        // A button
        canvas.drawCircle(btnACenter.x, btnACenter.y, BTN_RADIUS,
            if (p and GBACore.Keys.A != 0) paintPressed else paintBase)
        canvas.drawText("A", btnACenter.x, btnACenter.y + 10f, paintText)

        // B button
        canvas.drawCircle(btnBCenter.x, btnBCenter.y, BTN_RADIUS,
            if (p and GBACore.Keys.B != 0) paintPressed else paintBase)
        canvas.drawText("B", btnBCenter.x, btnBCenter.y + 10f, paintText)

        // Shoulders
        val lp = if (p and GBACore.Keys.L != 0) paintPressed else paintBase
        val rp = if (p and GBACore.Keys.R != 0) paintPressed else paintBase
        canvas.drawRoundRect(btnLRect, 16f, 16f, lp)
        canvas.drawRoundRect(btnRRect, 16f, 16f, rp)
        canvas.drawText("L", btnLRect.centerX(), btnLRect.centerY() + 10f, paintText)
        canvas.drawText("R", btnRRect.centerX(), btnRRect.centerY() + 10f, paintText)

        // Start / Select
        val selP = if (p and GBACore.Keys.SELECT != 0) paintPressed else paintBase
        val stP  = if (p and GBACore.Keys.START  != 0) paintPressed else paintBase
        canvas.drawRoundRect(btnSelectRect, 24f, 24f, selP)
        canvas.drawRoundRect(btnStartRect,  24f, 24f, stP)
        canvas.drawText("SELECT", btnSelectRect.centerX(), btnSelectRect.centerY()+10f, paintText.apply { textSize = 18f })
        canvas.drawText("START",  btnStartRect.centerX(),  btnStartRect.centerY()+10f,  paintText.apply { textSize = 18f })
        paintText.textSize = 28f
    }

    private fun drawDpad(canvas: Canvas, p: Int) {
        val cx = dpadCenter.x; val cy = dpadCenter.y
        val arm = DPAD_RADIUS * 0.5f; val thick = DPAD_RADIUS * 0.42f

        // Cross arms
        val arms = listOf(
            Triple(GBACore.Keys.UP,    RectF(cx - thick, cy - DPAD_RADIUS, cx + thick, cy - arm)),
            Triple(GBACore.Keys.DOWN,  RectF(cx - thick, cy + arm, cx + thick, cy + DPAD_RADIUS)),
            Triple(GBACore.Keys.LEFT,  RectF(cx - DPAD_RADIUS, cy - thick, cx - arm, cy + thick)),
            Triple(GBACore.Keys.RIGHT, RectF(cx + arm, cy - thick, cx + DPAD_RADIUS, cy + thick)),
        )
        for ((k, r) in arms) {
            canvas.drawRoundRect(r, 12f, 12f, if (p and k != 0) paintPressed else paintBase)
        }
        // Center square
        canvas.drawRoundRect(RectF(cx - thick, cy - thick, cx + thick, cy + thick),
            12f, 12f, paintBase)
    }
}
