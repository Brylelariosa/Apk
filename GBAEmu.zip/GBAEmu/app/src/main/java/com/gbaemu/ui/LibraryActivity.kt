package com.gbaemu.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.*
import com.gbaemu.R
import com.gbaemu.databinding.ActivityLibraryBinding
import java.io.File

data class RomEntry(
    val title   : String,
    val path    : String,
    val sizeKb  : Int,
    val lastPlay: Long   // epoch ms; 0 if never
)

class LibraryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLibraryBinding
    private val adapter = RomAdapter { entry -> launchGame(entry.path) }

    private val pickRom = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri ?: return@registerForActivityResult
        copyAndLaunch(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLibraryBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.title = "GBAEmu"

        binding.recycler.layoutManager = LinearLayoutManager(this)
        binding.recycler.adapter = adapter

        binding.fabAddRom.setOnClickListener {
            pickRom.launch(arrayOf("application/octet-stream", "*/*"))
        }

        binding.fabLan.setOnClickListener {
            startActivity(Intent(this, LanLobbyActivity::class.java))
        }

        loadLibrary()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.library_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem) = when (item.itemId) {
        R.id.action_settings -> {
            startActivity(Intent(this, SettingsActivity::class.java))
            true
        }
        else -> super.onOptionsItemSelected(item)
    }

    private fun loadLibrary() {
        val romsDir = File(filesDir, "roms")
        romsDir.mkdirs()
        val entries = romsDir.listFiles { f -> f.extension.lowercase() == "gba" }
            ?.map { f ->
                RomEntry(
                    title    = f.nameWithoutExtension,
                    path     = f.absolutePath,
                    sizeKb   = (f.length() / 1024).toInt(),
                    lastPlay = 0L
                )
            }
            ?.sortedByDescending { it.lastPlay }
            ?: emptyList()

        adapter.submitList(entries)
        binding.emptyHint.visibility = if (entries.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun copyAndLaunch(uri: Uri) {
        val romsDir = File(filesDir, "roms").also { it.mkdirs() }
        val name    = uri.lastPathSegment?.substringAfterLast('/')
            ?.takeIf { it.endsWith(".gba", ignoreCase = true) }
            ?: "game_${System.currentTimeMillis()}.gba"
        val dest = File(romsDir, name)

        contentResolver.openInputStream(uri)?.use { input ->
            dest.outputStream().use { output -> input.copyTo(output) }
        }
        loadLibrary()
        launchGame(dest.absolutePath)
    }

    private fun launchGame(romPath: String) {
        val savePath = File(filesDir, "saves")
            .also { it.mkdirs() }
            .resolve(File(romPath).nameWithoutExtension + ".sav")
            .absolutePath

        startActivity(Intent(this, EmulatorActivity::class.java).apply {
            putExtra(EmulatorActivity.EXTRA_ROM_PATH,  romPath)
            putExtra(EmulatorActivity.EXTRA_SAVE_PATH, savePath)
        })
    }
}

// ── RecyclerView adapter ──────────────────────────────────────────────────

class RomAdapter(
    private val onClick: (RomEntry) -> Unit
) : ListAdapter<RomEntry, RomAdapter.VH>(
    object : DiffUtil.ItemCallback<RomEntry>() {
        override fun areItemsTheSame(a: RomEntry, b: RomEntry) = a.path == b.path
        override fun areContentsTheSame(a: RomEntry, b: RomEntry) = a == b
    }
) {
    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(R.id.rom_title)
        val sub  : TextView = view.findViewById(R.id.rom_sub)
    }

    override fun onCreateViewHolder(parent: ViewGroup, type: Int): VH {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_rom, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, pos: Int) {
        val e = getItem(pos)
        holder.title.text = e.title
        holder.sub.text   = "${e.sizeKb} KB"
        holder.itemView.setOnClickListener { onClick(e) }
    }
}
