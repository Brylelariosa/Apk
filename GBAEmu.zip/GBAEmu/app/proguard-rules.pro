# GBAEmu ProGuard rules

# Keep JNI-called methods
-keep class com.gbaemu.core.GBACore { *; }
-keepclassmembers class com.gbaemu.core.GBACore {
    native <methods>;
}

# Keep all native (JNI) method signatures
-keepclasseswithmembernames class * {
    native <methods>;
}

# Kotlin metadata
-keep class kotlin.Metadata { *; }
-dontwarn kotlin.**

# AndroidX / Material
-keep class androidx.** { *; }
-keep class com.google.android.material.** { *; }

# Preferences
-keep class * extends androidx.preference.Preference { *; }
