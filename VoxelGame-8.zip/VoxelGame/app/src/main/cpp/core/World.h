#pragma once
#include "Chunk.h"
#include "Noise.h"
#include "MathUtils.h"
#include <unordered_map>
#include <memory>
#include <thread>
#include <mutex>
#include <atomic>
#include <vector>
#include <cstdint>

struct ChunkKey {
    int x, z;
    bool operator==(const ChunkKey& o) const { return x==o.x && z==o.z; }
};
struct ChunkHash {
    size_t operator()(const ChunkKey& k) const {
        return std::hash<int64_t>()(((int64_t)k.x<<32)|(uint32_t)k.z);
    }
};

class World {
public:
    explicit World(uint32_t seed = 42);
    ~World();

    uint8_t getBlock(int x, int y, int z) const;
    void    setBlock(int x, int y, int z, uint8_t type);
    Chunk*  getChunk(int cx, int cz) const;

    // Call every frame from GL thread
    void    update(float px, float pz, int renderDist);
    void    renderAll(GLint mvpLoc, const float* vp) const;

    bool    raycast(Vec3 origin, Vec3 dir, float maxDist,
                    Vec3& hitPos, Vec3& hitNormal) const;

private:
    // ── Main-thread chunk map (GL thread only) ────────────────────────────────
    std::unordered_map<ChunkKey, std::unique_ptr<Chunk>, ChunkHash> chunks;

    // ── Background worker ─────────────────────────────────────────────────────
    std::thread              worker;
    std::atomic<bool>        workerRunning{false};

    // Requests:  GL thread writes, worker reads
    std::mutex               reqMutex;
    std::vector<ChunkKey>    requested;   // keys that need generating
    std::vector<ChunkKey>    inFlight;    // currently being generated

    // Results:   worker writes, GL thread reads
    struct BuiltChunk {
        int cx, cz;
        std::unique_ptr<Chunk> chunk;   // fully generated + meshed, ready to upload
    };
    std::mutex               resMutex;
    std::vector<BuiltChunk>  results;

    Noise    noise;
    uint32_t seed;

    void workerMain();
    void generateAndMesh(int cx, int cz);
    void generateChunk(Chunk* c);
    void placeTree(Chunk* c, int lx, int y, int lz);

    // Local block query used by mesh builder (worker thread only)
    uint8_t workerGetBlock(int x, int y, int z,
        const std::unordered_map<ChunkKey,std::unique_ptr<Chunk>,ChunkHash>& local) const;
};
