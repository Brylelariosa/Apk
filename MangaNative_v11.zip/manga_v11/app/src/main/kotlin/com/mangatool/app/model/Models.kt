package com.mangatool.app.model

data class ImageItem(
    val originalIdx: Int,
    val data: ByteArray,
    val ext: String,
    val size: Int,
    var name: String = "",
    var userDeleted: Boolean = false,
    var forceKeep: Boolean = false,
    var filterReason: String? = null,
    val width: Int = 0,
    val height: Int = 0
) {
    // Use reference identity so images from different groups with the same
    // originalIdx are never treated as equal (avoids false matches in sets/maps).
    override fun equals(other: Any?) = this === other
    override fun hashCode() = System.identityHashCode(this)
}

data class ImageGroup(
    val groupName: String,
    val allImages: MutableList<ImageItem> = mutableListOf(),
    var displayImages: List<ImageItem> = emptyList(),
    var filteredImages: List<ImageItem> = emptyList(),
    /** Set of pair indices (0-based) where the two images are swapped (right shown on left) */
    val pairSwaps: MutableSet<Int> = mutableSetOf()
)
