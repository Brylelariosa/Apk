package com.batteryguard

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.batteryguard.databinding.ActivityMainBinding
import rikka.shizuku.Shizuku

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val PERM_NOTIF   = 100
    private val PERM_SHIZUKU = 101

    private val uiReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            refreshBatteryCard()
            refreshPrivilegeCard()
        }
    }

    private val shizukuPermListener = Shizuku.OnRequestPermissionResultListener { _, result ->
        val ok = result == PackageManager.PERMISSION_GRANTED
        Toast.makeText(this, if (ok) "Shizuku access granted ✓" else "Shizuku permission denied", Toast.LENGTH_SHORT).show()
        refreshPrivilegeCard()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        Shizuku.addRequestPermissionResultListener(shizukuPermListener)
        requestNotifPermission()
        setupThresholdSlider()
        setupButtons()
        refreshBatteryCard()
        refreshPrivilegeCard()
        refreshServiceState()
    }

    override fun onResume() {
        super.onResume()
        registerReceiver(uiReceiver, IntentFilter(BatteryService.ACTION_UPDATE_UI))
        refreshBatteryCard()
        refreshPrivilegeCard()
        refreshServiceState()
    }

    override fun onPause() {
        super.onPause()
        try { unregisterReceiver(uiReceiver) } catch (_: Exception) {}
    }

    override fun onDestroy() {
        super.onDestroy()
        Shizuku.removeRequestPermissionResultListener(shizukuPermListener)
    }

    // ── Buttons ───────────────────────────────────────────────────────────────

    private fun setupButtons() {
        binding.btnStart.setOnClickListener { startService() }
        binding.btnStop.setOnClickListener  { stopService()  }

        binding.btnShizuku.setOnClickListener {
            if (!ChargingController.isShizukuAvailable()) {
                Toast.makeText(this, "Shizuku not running — install & start Shizuku app first", Toast.LENGTH_LONG).show()
            } else {
                ChargingController.requestShizukuPermission(PERM_SHIZUKU)
            }
        }
    }

    private fun startService() {
        val intent = Intent(this, BatteryService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent)
        else startService(intent)
        prefs().edit().putBoolean("service_running", true).apply()
        refreshServiceState()
        Toast.makeText(this, "Battery Guard started", Toast.LENGTH_SHORT).show()
    }

    private fun stopService() {
        stopService(Intent(this, BatteryService::class.java))
        prefs().edit().putBoolean("service_running", false).apply()
        refreshServiceState()
        Toast.makeText(this, "Service stopped", Toast.LENGTH_SHORT).show()
    }

    // ── Threshold slider ──────────────────────────────────────────────────────

    private fun setupThresholdSlider() {
        val saved = prefs().getInt("threshold", 100)
        binding.seekbarThreshold.progress = saved - 80   // 0-20 maps to 80-100
        binding.tvThresholdValue.text = "$saved%"

        binding.seekbarThreshold.setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: android.widget.SeekBar?, p: Int, user: Boolean) {
                val t = 80 + p
                binding.tvThresholdValue.text = "$t%"
                prefs().edit().putInt("threshold", t).apply()
            }
            override fun onStartTrackingTouch(sb: android.widget.SeekBar?) {}
            override fun onStopTrackingTouch(sb: android.widget.SeekBar?) {}
        })
    }

    // ── Refresh helpers ───────────────────────────────────────────────────────

    private fun refreshBatteryCard() {
        val batt   = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return
        val level  = batt.getIntExtra(BatteryManager.EXTRA_LEVEL, 0)
        val scale  = batt.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val status = batt.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val percent = level * 100 / scale

        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                       status == BatteryManager.BATTERY_STATUS_FULL

        binding.tvBatteryPercent.text = "$percent%"
        binding.progressBattery.progress = percent

        val (colorRes, emoji) = when {
            percent >= 80 -> Pair(android.R.color.holo_green_light,  if (charging) "⚡" else "🔋")
            percent >= 40 -> Pair(android.R.color.holo_orange_light, if (charging) "⚡" else "🔋")
            else          -> Pair(android.R.color.holo_red_light,    if (charging) "⚡" else "🪫")
        }
        val color = ContextCompat.getColor(this, colorRes)
        binding.tvBatteryPercent.setTextColor(color)
        binding.progressBattery.progressTintList = android.content.res.ColorStateList.valueOf(color)
        binding.tvChargingStatus.text = if (charging) "$emoji Charging" else "$emoji On Battery"
    }

    private fun refreshPrivilegeCard() {
        val method = ChargingController.availableMethod()
        val shizukuAvail = ChargingController.isShizukuAvailable()

        when (method) {
            ChargingController.Method.ROOT -> {
                binding.tvPrivilegeStatus.text = "Root detected — full auto-control active"
                binding.tvPrivilegeStatus.setTextColor(ContextCompat.getColor(this, android.R.color.holo_green_light))
                binding.btnShizuku.visibility = View.GONE
            }
            ChargingController.Method.SHIZUKU -> {
                binding.tvPrivilegeStatus.text = "Shizuku active — auto-control enabled"
                binding.tvPrivilegeStatus.setTextColor(ContextCompat.getColor(this, android.R.color.holo_green_light))
                binding.btnShizuku.visibility = View.GONE
            }
            ChargingController.Method.NONE -> {
                if (shizukuAvail) {
                    binding.tvPrivilegeStatus.text = "Shizuku found — tap to grant permission"
                    binding.tvPrivilegeStatus.setTextColor(ContextCompat.getColor(this, android.R.color.holo_orange_light))
                    binding.btnShizuku.visibility = View.VISIBLE
                    binding.btnShizuku.text = "Grant Shizuku Permission"
                } else {
                    binding.tvPrivilegeStatus.text = "No root or Shizuku — alert-only mode"
                    binding.tvPrivilegeStatus.setTextColor(ContextCompat.getColor(this, android.R.color.holo_red_light))
                    binding.btnShizuku.visibility = View.VISIBLE
                    binding.btnShizuku.text = "How to set up Shizuku"
                }
            }
        }
    }

    private fun refreshServiceState() {
        val running = prefs().getBoolean("service_running", false)
        binding.tvServiceStatus.text = if (running) "Active" else "Stopped"
        val color = if (running)
            ContextCompat.getColor(this, android.R.color.holo_green_light)
        else
            ContextCompat.getColor(this, android.R.color.holo_red_light)
        binding.tvServiceStatus.setTextColor(color)
        binding.btnStart.isEnabled = !running
        binding.btnStop.isEnabled  = running
    }

    // ── Misc ──────────────────────────────────────────────────────────────────

    private fun prefs() = getSharedPreferences("settings", MODE_PRIVATE)

    private fun requestNotifPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), PERM_NOTIF)
        }
    }
}
