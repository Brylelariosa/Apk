package com.batteryguard

import android.content.Context
import android.util.Log
import rikka.shizuku.Shizuku
import java.io.File

/**
 * Handles disabling/enabling charging via:
 *   1. Root (su)
 *   2. Shizuku (privileged shell without full root)
 *   3. Fallback: notification alert only
 */
object ChargingController {

    private const val TAG = "ChargingController"

    // Known sysfs nodes — ordered by reliability
    private val CHARGING_NODES = listOf(
        "/sys/class/power_supply/battery/charging_enabled",   // Qualcomm / most common
        "/sys/class/power_supply/battery/charge_control_limit_max",
        "/sys/class/power_supply/battery/input_suspend",      // OnePlus / Oppo
        "/sys/class/power_supply/batt_drv/charge_disable",    // Google Pixel
        "/sys/class/power_supply/battery/stop_charging",      // Samsung
        "/sys/class/power_supply/battery/inhibit_charge",
    )

    enum class Method { ROOT, SHIZUKU, NONE }

    /** Returns which privileged method is available */
    fun availableMethod(): Method {
        return when {
            isRooted()          -> Method.ROOT
            isShizukuGranted()  -> Method.SHIZUKU
            else                -> Method.NONE
        }
    }

    /** Disable charging. Returns true on success. */
    fun disableCharging(): Boolean {
        val method = availableMethod()
        Log.d(TAG, "disableCharging() via $method")
        return when (method) {
            Method.ROOT    -> runCommands(buildDisableCommands(), useRoot = true)
            Method.SHIZUKU -> runCommands(buildDisableCommands(), useRoot = false)
            Method.NONE    -> false
        }
    }

    /** Re-enable charging. */
    fun enableCharging(): Boolean {
        val method = availableMethod()
        return when (method) {
            Method.ROOT    -> runCommands(buildEnableCommands(), useRoot = true)
            Method.SHIZUKU -> runCommands(buildEnableCommands(), useRoot = false)
            Method.NONE    -> false
        }
    }

    // ── Command builders ──────────────────────────────────────────────────────

    private fun buildDisableCommands(): List<String> {
        val cmds = mutableListOf<String>()
        for (path in CHARGING_NODES) {
            if (File(path).exists()) {
                cmds.add("echo 0 > $path")
            }
        }
        // Fallback via dumpsys (works on some stock ROMs)
        cmds.add("dumpsys battery set status 1 2>/dev/null || true")
        return cmds
    }

    private fun buildEnableCommands(): List<String> {
        val cmds = mutableListOf<String>()
        for (path in CHARGING_NODES) {
            if (File(path).exists()) {
                cmds.add("echo 1 > $path")
            }
        }
        cmds.add("dumpsys battery reset 2>/dev/null || true")
        return cmds
    }

    // ── Execution ─────────────────────────────────────────────────────────────

    private fun runCommands(commands: List<String>, useRoot: Boolean): Boolean {
        if (commands.isEmpty()) return false
        val joined = commands.joinToString(" && ")
        return if (useRoot) runAsRoot(joined) else runViaShizuku(joined)
    }

    private fun runAsRoot(command: String): Boolean {
        return try {
            val process = Runtime.getRuntime().exec(arrayOf("su", "-c", command))
            val exit = process.waitFor()
            Log.d(TAG, "root exit=$exit cmd=$command")
            exit == 0
        } catch (e: Exception) {
            Log.e(TAG, "root failed: ${e.message}")
            false
        }
    }

    private fun runViaShizuku(command: String): Boolean {
        return try {
            if (!isShizukuGranted()) return false
            val process = Shizuku.newProcess(arrayOf("sh", "-c", command), null, null)
            val exit = process.waitFor()
            Log.d(TAG, "shizuku exit=$exit cmd=$command")
            exit == 0
        } catch (e: Exception) {
            Log.e(TAG, "shizuku failed: ${e.message}")
            false
        }
    }

    // ── Detection helpers ─────────────────────────────────────────────────────

    private fun isRooted(): Boolean {
        val paths = listOf(
            "/system/bin/su", "/system/xbin/su",
            "/sbin/su", "/su/bin/su", "/magisk/.core/bin/su"
        )
        return paths.any { File(it).exists() }
    }

    fun isShizukuAvailable(): Boolean {
        return try { Shizuku.pingBinder() } catch (e: Exception) { false }
    }

    fun isShizukuGranted(): Boolean {
        return try {
            isShizukuAvailable() &&
            Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED
        } catch (e: Exception) { false }
    }

    fun requestShizukuPermission(requestCode: Int) {
        try {
            if (isShizukuAvailable()) Shizuku.requestPermission(requestCode)
        } catch (e: Exception) {
            Log.e(TAG, "requestShizukuPermission: ${e.message}")
        }
    }
}
