package com.steve.browser

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.*
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.*
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONArray
import org.json.JSONObject
import java.util.*

data class BrowserTab(
    val id: String = UUID.randomUUID().toString(),
    var title: String = "New Tab",
    var url: String = "https://www.google.com",
    var isIncognito: Boolean = false
)

@SuppressLint("SetJavaScriptEnabled")
class MainActivity : AppCompatActivity() {

    companion object {
        const val HOME_URL = "https://www.google.com"
        const val PREFS_NAME = "browser_prefs"
        const val KEY_BOOKMARKS = "bookmarks"
        const val KEY_HISTORY = "history"
        const val MAX_HISTORY = 200
        const val MAX_TABS = 15
    }

    private lateinit var webViewContainer: FrameLayout
    private lateinit var urlBar: EditText
    private lateinit var tabsRecycler: RecyclerView
    private lateinit var progressBar: ProgressBar
    private lateinit var backBtn: ImageButton
    private lateinit var forwardBtn: ImageButton
    private lateinit var refreshBtn: ImageButton
    private lateinit var menuBtn: ImageButton
    private lateinit var newTabBtn: ImageButton
    private lateinit var incognitoBar: LinearLayout
    private lateinit var tabCountBadge: TextView

    private lateinit var prefs: SharedPreferences
    private lateinit var tabAdapter: TabAdapter

    private val tabs = mutableListOf<BrowserTab>()
    private val webViews = mutableMapOf<String, WebView>()
    private var currentTabId: String = ""

    private val currentTab get() = tabs.find { it.id == currentTabId }
    private val currentWebView get() = webViews[currentTabId]

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        initViews()
        setupTabsRecycler()
        setupUrlBar()
        setupButtons()
        addNewTab(isIncognito = false)
    }

    private fun initViews() {
        webViewContainer = findViewById(R.id.webViewContainer)
        urlBar = findViewById(R.id.urlBar)
        tabsRecycler = findViewById(R.id.tabsRecycler)
        progressBar = findViewById(R.id.progressBar)
        backBtn = findViewById(R.id.backButton)
        forwardBtn = findViewById(R.id.forwardButton)
        refreshBtn = findViewById(R.id.refreshButton)
        menuBtn = findViewById(R.id.menuButton)
        newTabBtn = findViewById(R.id.newTabButton)
        incognitoBar = findViewById(R.id.incognitoBar)
        tabCountBadge = findViewById(R.id.tabCountBadge)
    }

    private fun setupTabsRecycler() {
        tabAdapter = TabAdapter(tabs,
            onTabClick = { tab -> switchToTab(tab.id) },
            onTabClose = { tab -> closeTab(tab.id) }
        )
        tabsRecycler.apply {
            layoutManager = LinearLayoutManager(this@MainActivity, LinearLayoutManager.HORIZONTAL, false)
            adapter = tabAdapter
        }
    }

    private fun setupUrlBar() {
        urlBar.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) {
                val query = urlBar.text.toString().trim()
                if (query.isNotEmpty()) {
                    navigateTo(query)
                    hideKeyboard()
                }
                true
            } else false
        }
        urlBar.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) urlBar.selectAll()
        }
    }

    private fun setupButtons() {
        backBtn.setOnClickListener {
            if (currentWebView?.canGoBack() == true) currentWebView?.goBack()
        }
        forwardBtn.setOnClickListener {
            if (currentWebView?.canGoForward() == true) currentWebView?.goForward()
        }
        refreshBtn.setOnClickListener {
            if (currentWebView?.progress == 100) currentWebView?.reload()
            else currentWebView?.stopLoading()
        }
        newTabBtn.setOnClickListener { showNewTabOptions() }
        menuBtn.setOnClickListener { showMenu() }
    }

    private fun navigateTo(input: String) {
        val url = when {
            input.startsWith("http://") || input.startsWith("https://") -> input
            input.matches(Regex("^[a-zA-Z0-9-]+(\\.[a-zA-Z]{2,})+(/.*)?$")) -> "https://$input"
            else -> "https://www.google.com/search?q=${Uri.encode(input)}"
        }
        currentWebView?.loadUrl(url)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createWebView(isIncognito: Boolean): WebView {
        val wv = WebView(this)
        wv.layoutParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        )
        wv.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = !isIncognito
            databaseEnabled = !isIncognito
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            useWideViewPort = true
            loadWithOverviewMode = true
            setSupportMultipleWindows(true)
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            mediaPlaybackRequiresUserGesture = false
            userAgentString = "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.6099.230 Mobile Safari/537.36"
            if (isIncognito) cacheMode = WebSettings.LOAD_NO_CACHE
        }

        if (isIncognito) {
            CookieManager.getInstance().setAcceptCookie(false)
        } else {
            CookieManager.getInstance().setAcceptCookie(true)
            CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true)
        }

        wv.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                if (view != currentWebView) return
                progressBar.visibility = View.VISIBLE
                refreshBtn.setImageResource(android.R.drawable.ic_menu_close_clear_cancel)
                urlBar.setText(url ?: "")
                currentTab?.url = url ?: ""
                updateNavButtons()
            }

            override fun onPageFinished(view: WebView, url: String?) {
                if (view != currentWebView) return
                progressBar.visibility = View.GONE
                refreshBtn.setImageResource(android.R.drawable.ic_menu_rotate)
                url?.let {
                    currentTab?.apply {
                        this.url = it
                        this.title = view.title ?: it
                    }
                    tabAdapter.notifyDataSetChanged()
                    if (!currentTab!!.isIncognito) addToHistory(it, view.title ?: it)
                }
                updateNavButtons()
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url.toString()
                if (!url.startsWith("http")) {
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                        return true
                    } catch (e: Exception) {}
                }
                return false
            }
        }

        wv.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                if (view != currentWebView) return
                progressBar.progress = newProgress
                if (newProgress == 100) progressBar.visibility = View.GONE
            }

            override fun onReceivedTitle(view: WebView, title: String?) {
                val tabId = webViews.entries.find { it.value == view }?.key ?: return
                tabs.find { it.id == tabId }?.title = title ?: "New Tab"
                tabAdapter.notifyDataSetChanged()
            }
        }

        wv.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            try {
                val fileName = URLUtil.guessFileName(url, contentDisposition, mimeType)
                val request = DownloadManager.Request(Uri.parse(url)).apply {
                    setMimeType(mimeType)
                    addRequestHeader("User-Agent", userAgent)
                    setTitle(fileName)
                    setDescription("Downloading $fileName")
                    setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
                }
                val dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                dm.enqueue(request)
                Toast.makeText(this, "⬇️ Downloading: $fileName", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Download failed: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }

        return wv
    }

    private fun addNewTab(isIncognito: Boolean = false, url: String = HOME_URL) {
        if (tabs.size >= MAX_TABS) {
            Toast.makeText(this, "Max $MAX_TABS tabs reached", Toast.LENGTH_SHORT).show()
            return
        }
        val tab = BrowserTab(isIncognito = isIncognito, url = url)
        val wv = createWebView(isIncognito)
        wv.visibility = View.GONE
        wv.loadUrl(url)

        tabs.add(tab)
        webViews[tab.id] = wv
        webViewContainer.addView(wv)

        tabAdapter.notifyItemInserted(tabs.size - 1)
        switchToTab(tab.id)
        updateTabBadge()
    }

    private fun switchToTab(tabId: String) {
        currentWebView?.visibility = View.GONE
        currentTabId = tabId
        currentWebView?.visibility = View.VISIBLE

        currentTab?.let { tab ->
            urlBar.setText(tab.url)
            incognitoBar.visibility = if (tab.isIncognito) View.VISIBLE else View.GONE
        }
        updateNavButtons()

        val idx = tabs.indexOfFirst { it.id == tabId }
        if (idx >= 0) {
            tabAdapter.setSelected(idx)
            tabsRecycler.scrollToPosition(idx)
        }
    }

    private fun closeTab(tabId: String) {
        val idx = tabs.indexOfFirst { it.id == tabId }
        if (idx < 0) return

        val wv = webViews.remove(tabId)
        webViewContainer.removeView(wv)
        wv?.destroy()
        tabs.removeAt(idx)
        tabAdapter.notifyItemRemoved(idx)
        updateTabBadge()

        if (tabs.isEmpty()) {
            addNewTab()
        } else {
            val newIdx = (idx - 1).coerceAtLeast(0)
            switchToTab(tabs[newIdx].id)
        }
    }

    private fun updateNavButtons() {
        val canBack = currentWebView?.canGoBack() == true
        val canFwd = currentWebView?.canGoForward() == true
        backBtn.alpha = if (canBack) 1f else 0.35f
        forwardBtn.alpha = if (canFwd) 1f else 0.35f
        backBtn.isEnabled = canBack
        forwardBtn.isEnabled = canFwd
    }

    private fun updateTabBadge() {
        tabCountBadge.text = tabs.size.toString()
    }

    private fun showNewTabOptions() {
        val options = arrayOf("🌐  New Tab", "🕵️  New Incognito Tab")
        AlertDialog.Builder(this)
            .setTitle("Open New Tab")
            .setItems(options) { _, which ->
                addNewTab(isIncognito = which == 1)
            }.show()
    }

    private fun showMenu() {
        val popup = PopupMenu(this, menuBtn)
        popup.menu.apply {
            add(0, 1, 0, "⭐  Add Bookmark")
            add(0, 2, 0, "📚  Bookmarks")
            add(0, 3, 0, "🕐  History")
            add(0, 4, 0, "📤  Share Page")
            add(0, 5, 0, "🏠  Go Home")
            add(0, 6, 0, "📋  Copy URL")
            add(0, 7, 0, "🖥️  Desktop Site")
        }
        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> addBookmark()
                2 -> showBookmarks()
                3 -> showHistory()
                4 -> shareCurrentPage()
                5 -> currentWebView?.loadUrl(HOME_URL)
                6 -> copyUrl()
                7 -> toggleDesktopSite()
            }
            true
        }
        popup.show()
    }

    // ─── Bookmarks ────────────────────────────────────────────────────────────

    private fun loadBookmarks(): MutableList<Pair<String, String>> {
        val list = mutableListOf<Pair<String, String>>()
        return try {
            val arr = JSONArray(prefs.getString(KEY_BOOKMARKS, "[]"))
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(obj.getString("title") to obj.getString("url"))
            }
            list
        } catch (e: Exception) { list }
    }

    private fun saveBookmarks(bookmarks: List<Pair<String, String>>) {
        val arr = JSONArray()
        bookmarks.forEach { (title, url) ->
            arr.put(JSONObject().apply { put("title", title); put("url", url) })
        }
        prefs.edit().putString(KEY_BOOKMARKS, arr.toString()).apply()
    }

    private fun addBookmark() {
        val tab = currentTab ?: return
        val bookmarks = loadBookmarks()
        if (bookmarks.none { it.second == tab.url }) {
            // let user edit the title
            val input = EditText(this).apply {
                setText(tab.title)
                selectAll()
            }
            AlertDialog.Builder(this)
                .setTitle("Add Bookmark")
                .setView(input)
                .setPositiveButton("Save") { _, _ ->
                    val title = input.text.toString().ifBlank { tab.title }
                    bookmarks.add(title to tab.url)
                    saveBookmarks(bookmarks)
                    Toast.makeText(this, "⭐ Bookmarked!", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Cancel", null)
                .show()
        } else {
            Toast.makeText(this, "Already bookmarked", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showBookmarks() {
        val bookmarks = loadBookmarks()
        if (bookmarks.isEmpty()) {
            Toast.makeText(this, "No bookmarks yet. Tap ⋮ → Add Bookmark", Toast.LENGTH_SHORT).show()
            return
        }
        val titles = bookmarks.map { "⭐ ${it.first}" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Bookmarks (${bookmarks.size})")
            .setItems(titles) { _, which -> navigateTo(bookmarks[which].second) }
            .setNeutralButton("🗑 Clear All") { _, _ ->
                AlertDialog.Builder(this)
                    .setMessage("Delete all bookmarks?")
                    .setPositiveButton("Delete") { _, _ ->
                        saveBookmarks(emptyList())
                        Toast.makeText(this, "Bookmarks cleared", Toast.LENGTH_SHORT).show()
                    }
                    .setNegativeButton("Cancel", null).show()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    // ─── History ──────────────────────────────────────────────────────────────

    private fun loadHistory(): MutableList<Pair<String, String>> {
        val list = mutableListOf<Pair<String, String>>()
        return try {
            val arr = JSONArray(prefs.getString(KEY_HISTORY, "[]"))
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(obj.getString("title") to obj.getString("url"))
            }
            list
        } catch (e: Exception) { list }
    }

    private fun addToHistory(url: String, title: String) {
        if (url == HOME_URL) return
        val history = loadHistory()
        history.removeAll { it.second == url }
        history.add(0, title to url)
        val trimmed = if (history.size > MAX_HISTORY) history.subList(0, MAX_HISTORY) else history
        val arr = JSONArray()
        trimmed.forEach { (t, u) -> arr.put(JSONObject().apply { put("title", t); put("url", u) }) }
        prefs.edit().putString(KEY_HISTORY, arr.toString()).apply()
    }

    private fun showHistory() {
        val history = loadHistory()
        if (history.isEmpty()) {
            Toast.makeText(this, "No history yet", Toast.LENGTH_SHORT).show()
            return
        }
        val titles = history.map { "🕐 ${it.first}" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("History (${history.size})")
            .setItems(titles) { _, which -> navigateTo(history[which].second) }
            .setNeutralButton("🗑 Clear All") { _, _ ->
                AlertDialog.Builder(this)
                    .setMessage("Clear all history?")
                    .setPositiveButton("Clear") { _, _ ->
                        prefs.edit().remove(KEY_HISTORY).apply()
                        Toast.makeText(this, "History cleared", Toast.LENGTH_SHORT).show()
                    }
                    .setNegativeButton("Cancel", null).show()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    // ─── Utilities ────────────────────────────────────────────────────────────

    private fun shareCurrentPage() {
        val tab = currentTab ?: return
        startActivity(Intent.createChooser(
            Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, tab.url)
                putExtra(Intent.EXTRA_SUBJECT, tab.title)
            }, "Share via"
        ))
    }

    private fun copyUrl() {
        val url = currentTab?.url ?: return
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        cm.setPrimaryClip(android.content.ClipData.newPlainText("URL", url))
        Toast.makeText(this, "URL copied!", Toast.LENGTH_SHORT).show()
    }

    private var isDesktopSite = false
    private fun toggleDesktopSite() {
        isDesktopSite = !isDesktopSite
        val ua = if (isDesktopSite)
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        else
            "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.6099.230 Mobile Safari/537.36"
        currentWebView?.settings?.userAgentString = ua
        currentWebView?.reload()
        Toast.makeText(this, if (isDesktopSite) "🖥️ Desktop site" else "📱 Mobile site", Toast.LENGTH_SHORT).show()
    }

    private fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(urlBar.windowToken, 0)
        urlBar.clearFocus()
    }

    override fun onBackPressed() {
        if (currentWebView?.canGoBack() == true) {
            currentWebView?.goBack()
        } else {
            super.onBackPressed()
        }
    }

    override fun onPause() {
        super.onPause()
        currentWebView?.onPause()
    }

    override fun onResume() {
        super.onResume()
        currentWebView?.onResume()
    }

    override fun onDestroy() {
        webViews.values.forEach { it.destroy() }
        super.onDestroy()
    }
}
