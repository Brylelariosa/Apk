#include "World.h"
#include "BlockDefs.h"
#include <cmath>
#include <algorithm>
#include <condition_variable>
#include <android/log.h>
#include <cstring>
#include <time.h>

#define LOG_TAG "VoxelWorld"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

World::World(uint32_t s) : noise(s), seed(s) {
    // Allocate flat terrain cache (2048 × ~32KB = ~64MB)
    terrainCache = std::make_unique<TerrainEntry[]>(TC_CAP);
    workerRunning = true;
    for (int i = 0; i < NUM_WORKERS; i++)
        workers.emplace_back(&World::workerMain, this);
}

World::~World() {
    {
        std::lock_guard<std::mutex> lk(reqMutex);
        workerRunning = false;
    }
    reqCV.notify_all();          // wake ALL workers so they can exit cleanly
    for (auto& t : workers) if (t.joinable()) t.join();
}

// ── Block access (GL thread) ──────────────────────────────────────────────────
uint8_t World::getBlock(int x, int y, int z) const {
    if (y < 0 || y >= CH) return 0;
    int cx = (x < 0) ? ((x+1)/CW)-1 : x/CW;
    int cz = (z < 0) ? ((z+1)/CD)-1 : z/CD;
    auto it = chunks.find({cx,cz});
    if (it == chunks.end()) return 0;
    return it->second->getBlock(x - cx*CW, y, z - cz*CD);
}

bool World::blockSolidForCollision(int x, int y, int z) const {
    if (y < 0)    return true;   // below world = solid floor
    if (y >= CH)  return false;  // above world = air
    int cx = (x < 0) ? ((x+1)/CW)-1 : x/CW;
    int cz = (z < 0) ? ((z+1)/CD)-1 : z/CD;
    auto it = chunks.find({cx,cz});
    if (it == chunks.end()) {
        // Unloaded chunk: treat entire column as solid so player never falls through.
        // This is safe — the player can't be above real terrain, so solid=true
        // just keeps them standing until the chunk finishes loading.
        return true;
    }
    return blockSolid(it->second->getBlock(x - cx*CW, y, z - cz*CD));
}

void World::setBlock(int x, int y, int z, uint8_t type) {
    if (y < 0 || y >= CH) return;
    int cx = (x<0)?((x+1)/CW)-1:x/CW;
    int cz = (z<0)?((z+1)/CD)-1:z/CD;
    auto it = chunks.find({cx,cz});
    if (it == chunks.end()) return;
    it->second->setBlock(x-cx*CW, y, z-cz*CD, type);
    // Mark chunk dirty and track it for remeshing
    int lx = x-cx*CW, lz = z-cz*CD;
    auto markAndTrack = [&](int ncx, int ncz) {
        ChunkKey dk{ncx, ncz};
        auto n = chunks.find(dk);
        if (n == chunks.end()) return;
        n->second->markDirty();
        // Add to list if not already present (avoid O(n²) with small list)
        bool found = false;
        for (auto& k : dirtyChunks) if (k.x==ncx&&k.z==ncz){found=true;break;}
        if (!found) dirtyChunks.push_back(dk);
    };
    markAndTrack(cx, cz);
    if (lx == 0)    markAndTrack(cx-1, cz);
    if (lx == CW-1) markAndTrack(cx+1, cz);
    if (lz == 0)    markAndTrack(cx,   cz-1);
    if (lz == CD-1) markAndTrack(cx,   cz+1);
}

Chunk* World::getChunk(int cx, int cz) const {
    auto it = chunks.find({cx,cz});
    return it != chunks.end() ? it->second.get() : nullptr;
}

// ── Worker thread — condition-variable driven, no busy-polling ────────────────
void World::workerMain() {
    while (true) {
        ChunkKey key{0, 0};
        {
            std::unique_lock<std::mutex> lk(reqMutex);
            // Sleep until there's work or shutdown
            reqCV.wait(lk, [this]{ return !requested.empty() || !workerRunning; });
            if (!workerRunning && requested.empty()) break;
            if (requested.empty()) continue;
            key = requested.back();
            requested.pop_back();
            inFlight.push_back(key);
        }
        try {
            generateAndMesh(key.x, key.z);
        } catch (const std::exception& e) {
            LOGE("Worker exception: %s", e.what());
        } catch (...) {
            LOGE("Worker unknown exception");
        }
        {
            std::lock_guard<std::mutex> lk(reqMutex);
            inFlight.erase(
                std::remove_if(inFlight.begin(), inFlight.end(),
                    [&](const ChunkKey& k){ return k.x==key.x && k.z==key.z; }),
                inFlight.end());
        }
        // No notify here — workers naturally loop back to wait() themselves.
        // notify_all() was firing 3000+ times during load, waking idle workers
        // for no reason.
    }  // while(true)
}


// ── Flat-array terrain cache helpers ─────────────────────────────────────────
// Open-addressing with linear probing. Power-of-2 capacity (TC_CAP=2048)
// so modulo is a bitwise AND. Each slot is 32KB+8 bytes.
// INT_MIN keyX = empty slot.
int World::tcFind(int cx, int cz) const {
    int slot = (int)(((uint32_t)cx * 2654435761u ^ (uint32_t)cz * 2246822519u) & TC_MASK);
    for (int i = 0; i < TC_CAP; i++) {
        int s = (slot + i) & TC_MASK;
        if (terrainCache[s].keyX == INT_MIN) return -1;  // empty = not found
        if (terrainCache[s].keyX == cx && terrainCache[s].keyZ == cz) return s;
    }
    return -1;
}

int World::tcInsert(int cx, int cz) {
    // Find existing or empty slot. If full, evict the slot right after ideal.
    int ideal = (int)(((uint32_t)cx * 2654435761u ^ (uint32_t)cz * 2246822519u) & TC_MASK);
    for (int i = 0; i < TC_CAP; i++) {
        int s = (ideal + i) & TC_MASK;
        if (terrainCache[s].keyX == INT_MIN ||
            (terrainCache[s].keyX == cx && terrainCache[s].keyZ == cz))
            return s;
    }
    // Table full: evict the slot 1 past ideal (simple but effective)
    return (ideal + 1) & TC_MASK;
}

bool World::getTerrainCopy(int cx, int cz, uint8_t* out) {
    // Fast path: already in cache
    {
        std::lock_guard<std::mutex> lk(terrainCacheMutex);
        int s = tcFind(cx, cz);
        if (s >= 0 && terrainCache[s].ready) {
            memcpy(out, terrainCache[s].blocks, CSIZE);
            return true;
        }
    }

    // Cache miss: generate WITHOUT holding any lock (workers run fully in parallel)
    uint8_t temp[CSIZE];
    generateTerrainInto(cx, cz, temp);

    // Re-lock to insert
    {
        std::lock_guard<std::mutex> lk(terrainCacheMutex);
        int s = tcInsert(cx, cz);
        if (!terrainCache[s].ready || terrainCache[s].keyX != cx || terrainCache[s].keyZ != cz) {
            terrainCache[s].keyX  = cx;
            terrainCache[s].keyZ  = cz;
            terrainCache[s].ready = false;
        }
        if (!terrainCache[s].ready) {
            memcpy(terrainCache[s].blocks, temp, CSIZE);
            terrainCache[s].ready = true;
        }
        memcpy(out, terrainCache[s].blocks, CSIZE);
    }
    return false;
}

void World::generateAndMesh(int cx, int cz) {
    // Stack-allocated local terrain copies — no heap allocation per chunk.
    // Each is CSIZE = 32KB; 5 total = 160KB on the worker stack.
    uint8_t local[5][CSIZE];
    const std::pair<int,int> offsets[5] = {{0,0},{-1,0},{1,0},{0,-1},{0,1}};
    for (int i = 0; i < 5; i++)
        getTerrainCopy(cx+offsets[i].first, cz+offsets[i].second, local[i]);

    auto c = std::make_unique<Chunk>(cx, cz);
    c->populate(local[0]);

    // buildMeshT uses the direct lambda type — no std::function overhead.
    // The worldGet lambda is inlined by the compiler, eliminating ~200K
    // indirect calls per chunk that std::function would impose.
    // Direct offset lookup: (dx+1)*3+(dz+1) maps to local[] index.
    // offsets: {0,0}→idx0, {-1,0}→idx1, {1,0}→idx2, {0,-1}→idx3, {0,1}→idx4
    // Hash: (dx+1)*3+(dz+1) → 4,1,7,3,5 for valid offsets, -1 for unused slots.
    static const int8_t OFF_LUT[9] = {-1, 1, -1, 3, 0, 4, -1, 2, -1};
    auto worldGet = [&](int x, int y, int z) -> uint8_t {
        if (y < 0 || y >= CH) return 0;
        int ncx = (x<0)?((x+1)/CW)-1:x/CW;
        int ncz = (z<0)?((z+1)/CD)-1:z/CD;
        int lx = x-ncx*CW, lz = z-ncz*CD;
        if ((unsigned)lx>=(unsigned)CW || (unsigned)lz>=(unsigned)CD) return 0;
        int hash = (ncx-cx+1)*3 + (ncz-cz+1);
        if ((unsigned)hash >= 9) return 0;
        int8_t idx = OFF_LUT[hash];
        if (idx < 0) return 0;
        return local[idx][bidx(lx,y,lz)];
    };
    c->buildMeshT(worldGet);

    std::lock_guard<std::mutex> lk(resMutex);
    results.push_back({cx, cz, std::move(c)});
}

// Fast integer hash for ore generation — replaces noise3D.
// ~17K noise3D calls per chunk (each calling noise2D twice) → ~17K hash calls.
// 10-20× faster while producing visually identical sparse ore distribution.
static inline uint32_t oreHash(int wx, int wy, int wz, uint32_t seed) {
    uint32_t h = (uint32_t)wx * 374761393u ^ (uint32_t)wy * 1145141u
               ^ (uint32_t)wz * 8918441u  ^ seed;
    h ^= h >> 16; h *= 0x45d9f3bu; h ^= h >> 16;
    return h;
}

void World::generateTerrainInto(int cx, int cz, uint8_t* blocks) {
    memset(blocks, 0, CSIZE);
    const int wx0 = cx * CW;
    const int wz0 = cz * CD;
    float tempBase = noise.noise2D(wx0/300.f+500.f, wz0/300.f)*0.5f+0.5f;

    for (int lx = 0; lx < CW; lx++) {
        for (int lz = 0; lz < CD; lz++) {
            float wx = (float)(wx0+lx), wz = (float)(wz0+lz);
            // 4 octaves instead of 5: 5th octave adds sub-block detail
            // invisible after block quantization. 20% fewer noise calls.
            float h  = noise.fbm(wx/120.f, wz/120.f, 4);
            float h2 = noise.fbm(wx/40.f+7.f, wz/40.f+3.f, 3)*0.3f;
            int   height = 60 + (int)((h+h2)*28.f);
            height = std::max(2, std::min(CH-2, height));

            float temp = tempBase + noise.noise2D(wx/80.f, wz/80.f)*0.15f;

            uint8_t surface = BLOCK_GRASS, sub = BLOCK_DIRT;
            if      (height <= 61)  { surface=BLOCK_SAND; sub=BLOCK_SAND; }
            else if (temp  > 0.65f) { surface=BLOCK_SAND; sub=BLOCK_SAND; }
            else if (temp  < 0.35f) { surface=BLOCK_SNOW; }
            else if (height > 90)   { surface=BLOCK_SNOW; }

            for (int y = 0; y <= height; y++) {
                uint8_t type;
                if      (y == height)   type = surface;
                else if (y >= height-3) type = sub;
                else                    type = BLOCK_STONE;
                if (type == BLOCK_STONE) {
                    // Fast integer hash replaces noise3D (~17K calls per chunk)
                    uint32_t h = oreHash(wx0+lx, y, wz0+lz, seed);
                    // Map top 8 bits to 0-255 range for threshold comparison
                    uint32_t v = h >> 24;
                    if      (v > 237 && y < 20) type = BLOCK_GLOWSTONE; // ~7.5%
                    else if (v > 235 && y < 50) type = BLOCK_IRON;      // ~7.8%
                    else if (v > 230 && y < 30) type = BLOCK_COAL;      // ~9.8%
                }
                blocks[bidx(lx,y,lz)] = type;
            }

            if (surface==BLOCK_GRASS && lx>=3 && lx<=CW-4 && lz>=3 && lz<=CD-4) {
                uint32_t rng = (uint32_t)(wx0+lx)*73856093u^(uint32_t)(wz0+lz)*19349663u^seed;
                rng = rng*1664525u+1013904223u;
                if ((rng % 60) == 0) placeTree(blocks, lx, height+1, lz, wx, wz);
            }
        }
    }
}

void World::placeTree(uint8_t* blocks, int lx, int y, int lz, float wx, float wz) {
    int trunkH = 4+(int)((noise.noise2D(wx*0.07f, wz*0.07f)+1.f)*1.5f);
    trunkH = std::max(3, std::min(7, trunkH));
    for (int i = 0; i < trunkH && y+i < CH; i++)
        blocks[bidx(lx,y+i,lz)] = BLOCK_LOG;
    for (int dy = trunkH-2; dy <= trunkH+1; dy++) {
        int r = (dy < trunkH) ? 2 : 1;
        for (int dx = -r; dx <= r; dx++)
            for (int dz = -r; dz <= r; dz++) {
                if (abs(dx)+abs(dz) > r+1) continue;
                int bx=lx+dx, bz=lz+dz, by=y+dy;
                if (bx>=0&&bx<CW&&bz>=0&&bz<CD&&by>=0&&by<CH)
                    if (blocks[bidx(bx,by,bz)]==BLOCK_AIR)
                        blocks[bidx(bx,by,bz)]=BLOCK_LEAVES;
            }
    }
}

// ── GL thread update ──────────────────────────────────────────────────────────
// movDirX/Z: normalised player movement direction.
// Chunks in the forward half-space are pushed to the back of the queue
// (workers pop_back → highest priority) so terrain in front of the player
// always loads before terrain behind them.
void World::update(float px, float pz, int renderDist, float movDirX, float movDirZ) {
    int pcx = (int)floorf(px/CW);
    int pcz = (int)floorf(pz/CD);

    // ── Pull finished chunks from worker and upload ────────────────────────────
    // Discard results that are now outside render distance (player moved away
    // while chunk was being generated — don't waste GPU memory on them).
    // Maintain flat renderList for cache-friendly iteration in renderAll().
    {
        std::lock_guard<std::mutex> lk(resMutex);
        struct timespec t0; clock_gettime(CLOCK_MONOTONIC, &t0);
        int uploaded = 0;
        while (!results.empty()) {
            auto& r = results.back();
            ChunkKey rk{r.cx, r.cz};
            int rdx = r.cx-pcx, rdz = r.cz-pcz;
            bool inRange = (rdx*rdx+rdz*rdz <= (renderDist+6)*(renderDist+6));
            pendingSet.erase(rk);
            if (inRange) {
                r.chunk->uploadMesh();
                // Maintain renderList: add if not already present
                auto existing = chunks.find(rk);
                if (existing == chunks.end())
                    renderList.push_back(r.chunk.get());
                else
                    // Replace: remove old pointer from renderList
                    for (auto& p : renderList) if (p == existing->second.get()) { p = r.chunk.get(); break; }
                chunks[rk] = std::move(r.chunk);
                uploaded++;
            }
            results.pop_back();
            struct timespec t1; clock_gettime(CLOCK_MONOTONIC, &t1);
            long elapsedUs = (t1.tv_sec-t0.tv_sec)*1000000L
                           + (t1.tv_nsec-t0.tv_nsec)/1000L;
            if (elapsedUs > 3000) break;
        }
        // If results still pending, force re-scan next frame to check for gaps
        if (uploaded > 0 || !results.empty()) needsRescan = true;
    }

    // ── Rebuild dirty chunks (placed/broken blocks) — max 1 per frame ─────────
    for (auto it = dirtyChunks.begin(); it != dirtyChunks.end(); ) {
        auto cit = chunks.find(*it);
        if (cit == chunks.end() || !cit->second->isDirty()) {
            it = dirtyChunks.erase(it);
            continue;
        }
        auto worldGet = [this](int x, int y, int z)->uint8_t{ return getBlock(x,y,z); };
        try {
            cit->second->buildMesh(worldGet);
            cit->second->uploadMesh();
        } catch (...) { LOGE("buildMesh exception on dirty chunk"); }
        it = dirtyChunks.erase(it);
        break;
    }

    // ── Unload far chunks ──────────────────────────────────────────────────────
    const int maxDist = renderDist + 6;
    for (auto it = chunks.begin(); it != chunks.end(); ) {
        int dx = it->first.x-pcx, dz = it->first.z-pcz;
        if (dx*dx+dz*dz > maxDist*maxDist) {
            ChunkKey k = it->first;
            // Remove from flat renderList
            Chunk* ptr = it->second.get();
            renderList.erase(
                std::remove(renderList.begin(), renderList.end(), ptr),
                renderList.end());
            dirtyChunks.erase(
                std::remove_if(dirtyChunks.begin(), dirtyChunks.end(),
                    [&k](const ChunkKey& dk){ return dk.x==k.x && dk.z==k.z; }),
                dirtyChunks.end());
            pendingSet.erase(k);
            it = chunks.erase(it);
        } else ++it;
    }

    // ── Queue missing chunks ───────────────────────────────────────────────────
    // Run scan when: player crosses chunk boundary, renderDist changes, OR
    // new results arrived (needsRescan=true) — ensures no holes after loading.
    bool posChanged = (pcx != lastQueuePcx || pcz != lastQueuePcz ||
                       renderDist != lastQueueRdist || needsRescan);
    needsRescan = false;
    if (pcx != lastQueuePcx || pcz != lastQueuePcz || renderDist != lastQueueRdist) {
        lastQueuePcx   = pcx;
        lastQueuePcz   = pcz;
        lastQueueRdist = renderDist;
    }

    bool didQueue = false;
    if (posChanged) {
        std::lock_guard<std::mutex> lk(reqMutex);

        // Purge stale requests (player moved away while they were queued)
        {
            std::vector<ChunkKey> kept;
            kept.reserve(requested.size());
            for (auto& k : requested) {
                int dx=k.x-pcx, dz=k.z-pcz;
                if (dx*dx+dz*dz <= (renderDist+2)*(renderDist+2))
                    kept.push_back(k);
                else
                    pendingSet.erase(k);
            }
            requested = std::move(kept);
        }

        // ── Queue missing chunks — 3-level priority ───────────────────────────
        // Workers do pop_back() → last pushed = first loaded.
        // Push order (lowest priority first, highest priority last):
        //   Pass 0: behind player          (dot < 0)
        //   Pass 1: side/weakly forward    (0 ≤ dot < halfR)
        //   Pass 2: strongly forward       (dot ≥ halfR, within ~60° of facing dir)
        //
        // This ensures the player sees terrain appear DIRECTLY IN FRONT first,
        // not to the sides, regardless of movement speed or direction.
        const int rd2 = renderDist * renderDist;
        for (int r = renderDist; r >= 0; r--) {
            const float halfR = (float)r * 0.5f + 0.5f;  // +0.5 avoids 0 threshold at r=0
            for (int pass = 0; pass < 3; pass++) {
                for (int dx = -r; dx <= r; dx++) {
                    for (int dz = -r; dz <= r; dz++) {
                        if (abs(dx) != r && abs(dz) != r) continue;
                        if (dx*dx+dz*dz > rd2) continue;
                        ChunkKey key{pcx+dx, pcz+dz};
                        if (chunks.find(key)    != chunks.end()) continue;
                        if (pendingSet.count(key))               continue;
                        float dot = (float)dx*movDirX + (float)dz*movDirZ;
                        // Classify into 3 priority buckets
                        int bucket = (dot < 0.f)       ? 0 :  // behind
                                     (dot < halfR)     ? 1 :  // side/weak
                                                         2;   // strongly forward
                        if (pass != bucket) continue;
                        pendingSet.insert(key);
                        requested.push_back(key);
                        didQueue = true;
                    }
                }
            }
        }
    }
    if (didQueue) reqCV.notify_all();
}

void World::renderAll(GLint mvpLoc, const float* vp) const {
    glUniformMatrix4fv(mvpLoc, 1, GL_FALSE, vp);

    // ── Frustum planes (Gribb-Hartmann, column-major VP matrix) ──────────────
    const float pl[5][4] = {
        {vp[3]+vp[0], vp[7]+vp[4], vp[11]+vp[8],  vp[15]+vp[12]},
        {vp[3]-vp[0], vp[7]-vp[4], vp[11]-vp[8],  vp[15]-vp[12]},
        {vp[3]+vp[1], vp[7]+vp[5], vp[11]+vp[9],  vp[15]+vp[13]},
        {vp[3]-vp[1], vp[7]-vp[5], vp[11]-vp[9],  vp[15]-vp[13]},
        {vp[3]+vp[2], vp[7]+vp[6], vp[11]+vp[10], vp[15]+vp[14]},
    };

    // Iterate flat renderList — contiguous pointers, no hash map indirection.
    // At rd=64 this is 9440 pointer reads vs 9440 unordered_map node lookups.
    for (Chunk* chunk : renderList) {
        if (!chunk || !chunk->hasGpu()) continue;

        const float ax = (float)(chunk->getChunkX() * CW);
        const float az = (float)(chunk->getChunkZ() * CD);
        const float bx = ax + CW, bz = az + CD;
        const float by = chunk->getWorldMaxY();

        bool cull = false;
        for (int p = 0; p < 5 && !cull; p++) {
            const float a=pl[p][0], b=pl[p][1], c=pl[p][2], d=pl[p][3];
            float px=(a>=0.f)?bx:ax, py=(b>=0.f)?by:0.f, pz=(c>=0.f)?bz:az;
            if (a*px + b*py + c*pz + d < 0.f) cull = true;
        }
        if (!cull) chunk->render();
    }
    // Caller does glBindVertexArray(0) — no internal unbind needed
}

// ── DDA Raycast ───────────────────────────────────────────────────────────────
bool World::raycast(Vec3 origin, Vec3 dir, float maxDist,
                    Vec3& hitPos, Vec3& hitNormal) const {
    dir = normalize(dir);
    int bx=(int)floorf(origin.x), by=(int)floorf(origin.y), bz=(int)floorf(origin.z);
    int sx=(dir.x>0)?1:-1, sy=(dir.y>0)?1:-1, sz=(dir.z>0)?1:-1;
    float ddx=(fabsf(dir.x)>1e-6f)?fabsf(1.f/dir.x):1e30f;
    float ddy=(fabsf(dir.y)>1e-6f)?fabsf(1.f/dir.y):1e30f;
    float ddz=(fabsf(dir.z)>1e-6f)?fabsf(1.f/dir.z):1e30f;
    auto frac=[](float v){return v-floorf(v);};
    float tx=(dir.x>0)?(1.f-frac(origin.x))*ddx:frac(origin.x)*ddx;
    float ty=(dir.y>0)?(1.f-frac(origin.y))*ddy:frac(origin.y)*ddy;
    float tz=(dir.z>0)?(1.f-frac(origin.z))*ddz:frac(origin.z)*ddz;
    Vec3 normal{};
    for (int i = 0; i < 200; i++) {
        uint8_t blk = getBlock(bx, by, bz);
        if (blk != BLOCK_AIR && blockSolid(blk)) { // only hit solid blocks
            hitPos    = {(float)bx, (float)by, (float)bz};
            hitNormal = normal;
            return true;
        }
        float tmin = std::min({tx,ty,tz});
        if (tmin > maxDist) break;
        if      (tx <= ty && tx <= tz) { tx+=ddx; bx+=sx; normal={-(float)sx,0,0}; }
        else if (ty <= tz)             { ty+=ddy; by+=sy; normal={0,-(float)sy,0}; }
        else                           { tz+=ddz; bz+=sz; normal={0,0,-(float)sz}; }
    }
    return false;
}
