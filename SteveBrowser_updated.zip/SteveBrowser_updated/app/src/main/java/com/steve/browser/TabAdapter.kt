package com.steve.browser

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class TabAdapter(
    private val tabs: List<BrowserTab>,
    private val onTabClick: (BrowserTab) -> Unit,
    private val onTabClose: (BrowserTab) -> Unit
) : RecyclerView.Adapter<TabAdapter.TabViewHolder>() {

    private var selectedIndex = 0

    fun setSelected(index: Int) {
        val old = selectedIndex
        selectedIndex = index
        if (old >= 0 && old < itemCount) notifyItemChanged(old)
        if (index >= 0 && index < itemCount) notifyItemChanged(index)
    }

    inner class TabViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(R.id.tabTitle)
        val closeBtn: ImageButton = view.findViewById(R.id.closeTabButton)
        val incognito: TextView = view.findViewById(R.id.tabIncognitoIcon)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TabViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.tab_item, parent, false)
        return TabViewHolder(v)
    }

    override fun onBindViewHolder(holder: TabViewHolder, position: Int) {
        val tab = tabs[position]
        val isSelected = position == selectedIndex

        holder.title.text = tab.title.take(22).let { if (tab.title.length > 22) "$it…" else it }
        holder.incognito.visibility = if (tab.isIncognito) View.VISIBLE else View.GONE

        holder.itemView.setBackgroundResource(
            if (isSelected) R.drawable.tab_selected_bg else android.R.color.transparent
        )
        holder.title.alpha = if (isSelected) 1f else 0.55f

        holder.itemView.setOnClickListener { onTabClick(tab) }
        holder.closeBtn.setOnClickListener { onTabClose(tab) }
    }

    override fun getItemCount() = tabs.size
}
