# SteveBrowser 🌐

A full-featured Android WebView browser.

## Features
- **Multi-tab browsing** — up to 15 tabs with a tab strip
- **Incognito mode** — no cookies, no history, no cache
- **Bookmarks** — save and manage bookmarks with custom titles
- **History** — last 200 visited pages, with clear option
- **Downloads** — files go to your Downloads folder via Android DownloadManager
- **Desktop mode** — toggle mobile/desktop user agent
- **Share & Copy URL** — from the ⋮ menu
- **Back/Forward navigation** — hardware back button supported
- **URL bar** — auto-detects search queries vs URLs

## Build via GitHub Actions

1. Create a new GitHub repo
2. Upload all these files (keep the folder structure)
3. Push to `main` or `master`
4. Go to **Actions** tab → watch it build
5. Download the APK from **Artifacts** when done

## Build locally

```bash
# Requires JDK 17 and Android SDK
gradle wrapper --gradle-version=8.6
chmod +x gradlew
./gradlew assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk
```

## Package
`com.steve.browser` — change in `app/build.gradle` and `AndroidManifest.xml` if needed.
