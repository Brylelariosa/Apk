#pragma once
#include "Chunk.h"
#include "Noise.h"
#include "MathUtils.h"
#include <unordered_map>
#include <unordered_set>
#include <memory>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <atomic>
#include <vector>
#include <cstdint>
#include <climits>
#include <memory>

struct ChunkKey {
    int x, z;
    bool operator==(const ChunkKey& o) const { return x==o.x && z==o.z; }
};
struct ChunkHash {
    size_t operator()(const ChunkKey& k) const {
        return std::hash<int64_t>()(((int64_t)k.x<<32)|(uint32_t)k.z);
    }
};

class World {
public:
    explicit World(uint32_t seed = 42);
    ~World();

    uint8_t getBlock(int x, int y, int z) const;
    // Like getBlock but treats unloaded chunks as solid below y=100
    // Used by collision so player never falls through ungenerated terrain
    bool    blockSolidForCollision(int x, int y, int z) const;
    void    setBlock(int x, int y, int z, uint8_t type);
    Chunk*  getChunk(int cx, int cz) const;

    // movDirX/Z: normalised player movement direction (0,0 = stationary).
    // Chunks in the forward half-space are prioritised in the load queue.
    void    update(float px, float pz, int renderDist,
                   float movDirX = 0.f, float movDirZ = 0.f);
    void    renderAll(GLint mvpLoc, const float* vp) const;

    size_t  chunkCount() const { return chunks.size(); }
    bool    raycast(Vec3 origin, Vec3 dir, float maxDist,
                    Vec3& hitPos, Vec3& hitNormal) const;

private:
    // ── GL-thread-only ────────────────────────────────────────────────────────
    std::unordered_map<ChunkKey, std::unique_ptr<Chunk>, ChunkHash> chunks;
    std::vector<ChunkKey> dirtyChunks;
    std::unordered_set<ChunkKey, ChunkHash> pendingSet;  // O(1) "already queued?" check

    // ── Worker threads ────────────────────────────────────────────────────────
    std::vector<std::thread> workers;
    static constexpr int     NUM_WORKERS = 4;
    bool                     workerRunning{false};  // protected by reqMutex
    std::condition_variable  reqCV;
    std::mutex               reqMutex;
    std::vector<ChunkKey>    requested;    // workers pop_back; push_back = high priority
    std::vector<ChunkKey>    inFlight;

    struct BuiltChunk { int cx, cz; std::unique_ptr<Chunk> chunk; };
    std::mutex               resMutex;
    std::vector<BuiltChunk>  results;

    // ── Terrain cache — flat open-addressing hash table ──────────────────────
    // Replaces unordered_map<ChunkKey, TerrainEntry> where TerrainEntry is 32KB.
    // unordered_map stores each 32KB value in a separately heap-allocated node —
    // terrible cache performance on every lookup.  Flat array with linear probing:
    // all entries are contiguous in memory, hot keys stay in L2 cache.
    // Capacity = 2048 (power-of-2 for fast modulo), ~64MB total.
    static constexpr int TC_CAP = 2048;
    static constexpr int TC_MASK = TC_CAP - 1;
    struct TerrainEntry {
        int32_t  keyX = INT_MIN;  // INT_MIN = empty slot
        int32_t  keyZ = INT_MIN;
        bool     ready = false;
        uint8_t  blocks[CSIZE];
    };
    mutable std::mutex terrainCacheMutex;
    // Heap-allocated flat array (64MB stack alloc would overflow)
    std::unique_ptr<TerrainEntry[]> terrainCache;

    // Flat-array open-addressing probe: linear probing with power-of-2 capacity
    int tcFind(int cx, int cz) const;   // returns slot index or -1 if not found
    int tcInsert(int cx, int cz);       // returns slot to write into (guaranteed)

    // ── Flat render list — cache-friendly alternative to iterating unordered_map
    // Kept in sync: added on chunk upload, removed on unload.
    // renderAll iterates this flat vector instead of the hash map (9440 entries
    // with pointer-chasing → 9440 contiguous pointers with no heap indirection).
    std::vector<Chunk*> renderList;

    // ── Queue-scan position tracking ─────────────────────────────────────────
    int  lastQueuePcx    = INT_MIN;
    int  lastQueuePcz    = INT_MIN;
    int  lastQueueRdist  = -1;
    bool needsRescan     = false;  // set when results arrive to force next-frame scan

    Noise    noise;
    uint32_t seed;

    void    workerMain();
    void    generateAndMesh(int cx, int cz);
    void    generateTerrainInto(int cx, int cz, uint8_t* blocks);   // flat CW*CH*CD array
    bool    getTerrainCopy(int cx, int cz, uint8_t* out);            // true = cache hit
    void    placeTree(uint8_t* blocks, int lx, int y, int lz, float wx, float wz);
};
