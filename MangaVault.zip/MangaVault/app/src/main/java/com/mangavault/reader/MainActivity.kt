package com.mangavault.reader

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowInsetsController
import android.webkit.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private val prefs by lazy { getSharedPreferences("manga_prefs", Context.MODE_PRIVATE) }

    private val folderPicker = registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {}
            val files = listMHtmlFiles(uri)
            val json = files.toString()
            webView.post {
                webView.evaluateJavascript("window.onFolderPicked($json)", null)
            }
        } else {
            webView.post {
                webView.evaluateJavascript("window.onFolderPicked(null)", null)
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Full screen / immersive
        makeFullscreen()

        webView = WebView(this)
        setContentView(webView)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            setSupportZoom(false)
            loadWithOverviewMode = true
            useWideViewPort = true
            cacheMode = WebSettings.LOAD_DEFAULT
        }

        WebView.setWebContentsDebuggingEnabled(false)

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest) = false
        }

        webView.addJavascriptInterface(AndroidBridge(), "Android")
        webView.loadUrl("file:///android_asset/index.html")
    }

    override fun onBackPressed() {
        webView.evaluateJavascript("window.handleBack && window.handleBack()") { result ->
            if (result == "null" || result == "false") {
                super.onBackPressed()
            }
        }
    }

    private fun makeFullscreen() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.let {
                it.hide(android.view.WindowInsets.Type.statusBars() or android.view.WindowInsets.Type.navigationBars())
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            )
        }
    }

    private fun listMHtmlFiles(treeUri: Uri): JSONArray {
        val result = JSONArray()
        val dir = DocumentFile.fromTreeUri(this, treeUri) ?: return result
        dir.listFiles()
            .filter { it.isFile && (it.name?.endsWith(".mhtml", true) == true || it.name?.endsWith(".mht", true) == true) }
            .sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.name ?: "" })
            .forEach { file ->
                val obj = JSONObject()
                obj.put("uri", file.uri.toString())
                obj.put("name", cleanName(file.name ?: "Unknown"))
                result.put(obj)
            }
        return result
    }

    private fun cleanName(filename: String): String {
        return filename
            .replace(Regex("\\.(mhtml|mht)$", RegexOption.IGNORE_CASE), "")
            .replace(Regex("[-_]+"), " ")
            .trim()
    }

    private fun parseMHTML(content: String): List<String> {
        val boundaryRegex = Regex(
            """boundary=(?:"([^"]+)"|([^\s;\r\n]+))""",
            RegexOption.IGNORE_CASE
        )
        val boundaryMatch = boundaryRegex.find(content) ?: return emptyList()
        val boundary = boundaryMatch.groupValues[1].ifEmpty { boundaryMatch.groupValues[2] }

        val parts = content.split("--$boundary")
        val images = mutableListOf<String>()

        for (part in parts) {
            if (!part.contains(Regex("""Content-Type:\s*image/""", RegexOption.IGNORE_CASE))) continue

            var sepIdx = part.indexOf("\r\n\r\n")
            val sepLen: Int
            if (sepIdx != -1) {
                sepLen = 4
            } else {
                sepIdx = part.indexOf("\n\n")
                sepLen = 2
            }
            if (sepIdx == -1) continue

            val headers = part.substring(0, sepIdx)
            val rawBody = part.substring(sepIdx + sepLen)
            val body = rawBody.replace(Regex("""[\r\n\t ]"""), "").trim()
            if (body.length < 10) continue

            val ct = Regex("""Content-Type:\s*(image/[^\r\n;]+)""", RegexOption.IGNORE_CASE)
                .find(headers)?.groupValues?.get(1)?.trim() ?: "image/jpeg"

            images.add("data:$ct;base64,$body")
        }
        return images
    }

    inner class AndroidBridge {

        @JavascriptInterface
        fun pickFolder() {
            folderPicker.launch(null)
        }

        @JavascriptInterface
        fun readManga(uriString: String): String {
            return try {
                val uri = Uri.parse(uriString)
                val sb = StringBuilder()
                contentResolver.openInputStream(uri)?.use { input ->
                    BufferedReader(InputStreamReader(input, "UTF-8"), 65536).use { reader ->
                        var line = reader.readLine()
                        while (line != null) {
                            sb.append(line).append('\n')
                            line = reader.readLine()
                        }
                    }
                }
                val images = parseMHTML(sb.toString())
                val arr = JSONArray()
                images.forEach { arr.put(it) }
                arr.toString()
            } catch (e: Exception) {
                "[]"
            }
        }

        @JavascriptInterface
        fun saveProgress(key: String, value: String) {
            prefs.edit().putString("prog_$key", value).apply()
        }

        @JavascriptInterface
        fun loadProgress(key: String): String {
            return prefs.getString("prog_$key", "") ?: ""
        }

        @JavascriptInterface
        fun loadAllProgress(): String {
            val obj = JSONObject()
            prefs.all.forEach { (k, v) ->
                if (k.startsWith("prog_") && v is String) {
                    obj.put(k.removePrefix("prog_"), v)
                }
            }
            return obj.toString()
        }

        @JavascriptInterface
        fun clearProgress(key: String) {
            prefs.edit().remove("prog_$key").apply()
        }

        @JavascriptInterface
        fun saveFolder(uri: String) {
            prefs.edit().putString("last_folder_uri", uri).apply()
        }

        @JavascriptInterface
        fun loadFolder(): String {
            return prefs.getString("last_folder_uri", "") ?: ""
        }
    }
}
