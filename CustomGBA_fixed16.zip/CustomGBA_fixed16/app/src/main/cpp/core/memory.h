#pragma once
#include "types.h"
#include <vector>
#include <cstring>
#include <functional>

struct Memory {
    u8 bios [BIOS_SIZE]  = {};
    u8 ewram[EWRAM_SIZE] = {};
    u8 iwram[IWRAM_SIZE] = {};
    u8 io   [IO_SIZE]    = {};
    u8 pal  [PAL_SIZE]   = {};
    u8 vram [VRAM_SIZE]  = {};
    u8 oam  [OAM_SIZE]   = {};
    std::vector<u8> rom;

    u16 keyState = 0x03FF;

    // ── Direct Sound FIFO hooks ──────────────────────────────────────────────
    // Set by GBA::init() to route 32-bit writes at 0x040000A0/A4 into APU FIFOs.
    std::function<void(u32)> onFifoAWrite;
    std::function<void(u32)> onFifoBWrite;
    // Set by GBA::init() to notify APU of SOUNDCNT_H writes
    std::function<void(u16)> onSoundCntHWrite;

    // Debug counters for FIFO path (readable from JNI overlay)
    int dbgFifoAWrites = 0;
    int dbgFifoBWrites = 0;

    void init() {
        memset(ewram,0,sizeof(ewram));
        memset(iwram,0,sizeof(iwram));
        memset(io,0,sizeof(io));
        memset(pal,0,sizeof(pal));
        memset(vram,0,sizeof(vram));
        memset(oam,0,sizeof(oam));
        write16(REG_KEYINPUT, 0x03FF);
        write16(REG_DISPCNT, 0x0080);

        // ── Minimal BIOS stub ─────────────────────────────────────────────────
        // Without a real BIOS ROM, the bios[] array is all-zeros.
        // 0x00000000 in ARM = "ANDEQ r0,r0,r0" which is skipped when Z=0, but
        // PC still advances by 4. The CPU slides from a null-pointer call at
        // 0x00000000 through all 16KB of BIOS, then hits open-bus (0xFF =
        // NV-skip) and keeps running through all of memory. This caused the
        // "PC in open-bus" escape seen at frames 60-300.
        //
        // Fix: plant "BX LR" (ARM: 0xE12FFF1E) at address 0x00000000.
        // Any null-pointer call (BLX/BL through an uninitialised fn-ptr) now
        // returns immediately to the caller. LR was set by the BL/BLX that
        // called through the pointer, so the return address is valid.
        //
        // Also plant the GBA BIOS IRQ trampoline pattern at 0x00000018 (the
        // hardware IRQ vector). Although our CPU handles IRQs via checkIRQ()
        // rather than the hardware vector, having garbage at 0x18 confuses
        // any game that reads the vector for inspection.
        //   0x00000000: E1 2F FF 1E  → BX LR   (null-ptr safety return)
        //   0x00000004: EA FF FF FE  → B  0x04  (spin — shouldn't be reached)
        //   0x00000018: EA FF FF FE  → B  0x18  (spin at IRQ vector)
        bios[0x00] = 0x1E; bios[0x01] = 0xFF; bios[0x02] = 0x2F; bios[0x03] = 0xE1; // BX LR
        bios[0x04] = 0xFE; bios[0x05] = 0xFF; bios[0x06] = 0xFF; bios[0x07] = 0xEA; // B 0x04
        bios[0x18] = 0xFE; bios[0x19] = 0xFF; bios[0x1A] = 0xFF; bios[0x1B] = 0xEA; // B 0x18
    }

    bool loadROM(const u8* data, size_t size) {
        if (!data || size == 0) return false;
        rom.assign(data, data+size);
        return true;
    }

    // ── Read helpers ─────────────────────────────────────────────────────────
    u8 read8(u32 addr) const {
        addr &= 0x0FFFFFFF;
        if (addr < BIOS_SIZE)                            return bios[addr];
        if (addr >= 0x02000000 && addr < 0x03000000)    return ewram[(addr-0x02000000) % EWRAM_SIZE];
        if (addr >= 0x03000000 && addr < 0x04000000)    return iwram[(addr-0x03000000) % IWRAM_SIZE];
        if (addr >= 0x04000000 && addr < 0x04000000+IO_SIZE) return readIO8(addr);
        if (addr >= 0x05000000 && addr < 0x05000000+PAL_SIZE*2)      return pal[(addr-0x05000000) % PAL_SIZE];
        if (addr >= 0x06000000 && addr < 0x06000000+VRAM_SIZE+0x8000) return vram[(addr-0x06000000) % VRAM_SIZE];
        if (addr >= 0x07000000 && addr < 0x07000000+OAM_SIZE*8)      return oam[(addr-0x07000000) % OAM_SIZE];
        if (addr >= 0x08000000) {
            u32 off = addr - 0x08000000;
            if (off < rom.size()) return rom[off];
        }
        return 0xFF;
    }

    u16 read16(u32 addr) const {
        addr &= ~1u;
        return (u16)read8(addr) | ((u16)read8(addr+1) << 8);
    }
    u32 read32(u32 addr) const {
        addr &= ~3u;
        return (u32)read16(addr) | ((u32)read16(addr+2) << 16);
    }

    // ── Write helpers ────────────────────────────────────────────────────────
    void write8(u32 addr, u8 val) {
        addr &= 0x0FFFFFFF;
        if (addr >= 0x02000000 && addr < 0x03000000) { ewram[(addr-0x02000000)%EWRAM_SIZE]=val; return; }
        if (addr >= 0x03000000 && addr < 0x04000000) { iwram[(addr-0x03000000)%IWRAM_SIZE]=val; return; }
        if (addr >= 0x04000000 && addr < 0x04000000+IO_SIZE) { writeIO8(addr,val); return; }
        if (addr >= 0x05000000 && addr < 0x05000000+PAL_SIZE*2)       { pal[(addr-0x05000000)%PAL_SIZE]=val; return; }
        if (addr >= 0x06000000 && addr < 0x06000000+VRAM_SIZE+0x8000) { vram[(addr-0x06000000)%VRAM_SIZE]=val; return; }
        if (addr >= 0x07000000 && addr < 0x07000000+OAM_SIZE*8)       { oam[(addr-0x07000000)%OAM_SIZE]=val; return; }
    }

    void write16(u32 addr, u16 val) {
        addr &= ~1u;
        write8(addr,   val & 0xFF);
        write8(addr+1, val >> 8);
    }

    // write32: intercepts Direct Sound FIFO addresses (0x040000A0 / 0x040000A4)
    void write32(u32 addr, u32 val) {
        addr &= ~3u;
        addr &= 0x0FFFFFFF;
        if (addr == 0x040000A0) {
            dbgFifoAWrites++;
            if (onFifoAWrite) onFifoAWrite(val);
            return;
        }
        if (addr == 0x040000A4) {
            dbgFifoBWrites++;
            if (onFifoBWrite) onFifoBWrite(val);
            return;
        }
        write16(addr,   val & 0xFFFF);
        write16(addr+2, val >> 16);
    }

    // ── IO register read ──────────────────────────────────────────────────────
    u8 readIO8(u32 addr) const {
        u32 off = addr - 0x04000000;
        if (off == (REG_KEYINPUT & 0xFFF))   return keyState & 0xFF;
        if (off == (REG_KEYINPUT & 0xFFF)+1) return keyState >> 8;
        if (off < IO_SIZE) return io[off];
        return 0;
    }

    // ── IO register write ─────────────────────────────────────────────────────
    void writeIO8(u32 addr, u8 val) {
        u32 off = addr - 0x04000000;
        if (off >= IO_SIZE) return;

        // IF: write-to-clear
        if (addr == REG_IF || addr == REG_IF + 1) { io[off] &= ~val; return; }

        io[off] = val;

        // SOUNDCNT_H (0x04000082-83): notify APU for FIFO reset / config
        if (addr == 0x04000082 || addr == 0x04000083) {
            u16 sndH = (u16)io[0x82] | ((u16)io[0x83] << 8);
            if (onSoundCntHWrite) onSoundCntHWrite(sndH);
        }
    }

    void raiseIRQ(u16 bits) {
        u32 off = REG_IF - 0x04000000;
        io[off]   |= (bits & 0x00FF);
        io[off+1] |= (bits >> 8);
    }

    u16 ioRead16(u32 addr) const {
        return (u16)readIO8(addr) | ((u16)readIO8(addr+1) << 8);
    }
    void ioWrite16(u32 addr, u16 val) {
        writeIO8(addr,   val & 0xFF);
        writeIO8(addr+1, val >> 8);
    }
};
