package com.screenshottile

import android.accessibilityservice.AccessibilityService
import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper

/**
 * Invisible zero-UI activity.
 * startActivityAndCollapse() collapses the QS panel before this runs,
 * then we wait for the animation to finish before taking the screenshot.
 */
class TriggerActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val service = ScreenshotAccessibilityService.instance
        if (service == null) { finish(); return }
        Handler(Looper.getMainLooper()).postDelayed({
            service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)
            finish()
        }, 250)
    }
}
