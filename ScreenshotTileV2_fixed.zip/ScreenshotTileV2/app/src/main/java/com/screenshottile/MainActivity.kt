package com.screenshottile

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var statusText: TextView
    private lateinit var enableButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        statusText  = findViewById(R.id.statusText)
        enableButton = findViewById(R.id.enableButton)
        enableButton.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
    }

    override fun onResume() {
        super.onResume()
        val running = ScreenshotAccessibilityService.instance != null
        statusText.text = if (running) "✅ Ready — tap the tile to screenshot!"
                          else "⚠\uFE0F Enable the accessibility service below, then add the tile to Quick Settings."
        enableButton.text = if (running) "Accessibility Settings" else "Enable Accessibility Service"
    }
}
