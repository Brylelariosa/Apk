# Keep all public classes
-keep public class * { public *; }
