package com.gary.engineermode

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast

/**
 * Receives android.provider.Telephony.SECRET_CODE broadcasts
 * for *#*#4636#*#* and *#*#83781#*#*.
 * On stock Android the dialer handles these; this receiver lets
 * the app intercept them too and optionally launch our own UI.
 */
class SecretCodeReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val host = intent.data?.host ?: return
        when (host) {
            "4636"  -> {
                Toast.makeText(context, "Phone Testing / Info", Toast.LENGTH_SHORT).show()
                val launch = Intent(context, MainActivity::class.java)
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launch)
            }
            "83781" -> {
                Toast.makeText(context, "Engineer Mode", Toast.LENGTH_SHORT).show()
                val launch = Intent(context, MainActivity::class.java)
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launch)
            }
        }
    }
}
