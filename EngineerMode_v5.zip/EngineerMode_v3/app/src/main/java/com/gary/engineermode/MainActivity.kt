package com.gary.engineermode

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.telephony.TelephonyManager
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.gary.engineermode.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val PHONE_PERM_CODE = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupButtons()
        checkPermissionsThenLoad()
    }

    private fun setupButtons() {
        // ── Secret code buttons ───────────────────────────────────────────
        binding.btnPhone4636.setOnClickListener {
            dialSecretCode("*#*#4636#*#*")
        }
        binding.btnEngineer83781.setOnClickListener {
            dialSecretCode("*#*#83781#*#*")
        }

        // ── Copy buttons ──────────────────────────────────────────────────
        binding.btnCopy4636.setOnClickListener {
            copyToClipboard("*#*#4636#*#*")
        }
        binding.btnCopy83781.setOnClickListener {
            copyToClipboard("*#*#83781#*#*")
        }

        // ── Refresh button ────────────────────────────────────────────────
        binding.btnRefresh.setOnClickListener {
            checkPermissionsThenLoad()
        }

        // ── Common codes section ──────────────────────────────────────────
        binding.btnCodeImei.setOnClickListener { dialSecretCode("*#06#") }
        binding.btnCodeField.setOnClickListener { dialSecretCode("*#*#7262626#*#*") }
        binding.btnCodeRtk.setOnClickListener { dialSecretCode("*#*#1472365#*#*") }
        binding.btnCodeServiceMenu.setOnClickListener { dialSecretCode("*#0*#") }
    }

    // ── Dial a secret code via the system dialer ──────────────────────────
    private fun dialSecretCode(code: String) {
        try {
            // First try direct broadcast (works on some ROMs for *#*# codes)
            val numericCode = code.replace("*#*#", "").replace("#*#*", "")
            val broadcastIntent = Intent(
                "android.provider.Telephony.SECRET_CODE",
                Uri.parse("android_secret_code://$numericCode")
            )
            broadcastIntent.addFlags(Intent.FLAG_RECEIVER_FOREGROUND)
            sendBroadcast(broadcastIntent)

            // Also open dialer as fallback — user just taps call
            val encoded = Uri.encode(code)
            val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$encoded"))
            startActivity(dialIntent)
        } catch (e: Exception) {
            Toast.makeText(this, "Could not launch: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun copyToClipboard(text: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        cm.setPrimaryClip(android.content.ClipData.newPlainText("code", text))
        Toast.makeText(this, "Copied: $text", Toast.LENGTH_SHORT).show()
    }

    // ── Permission handling ───────────────────────────────────────────────
    private fun checkPermissionsThenLoad() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.READ_PHONE_STATE),
                PHONE_PERM_CODE
            )
        } else {
            loadAllInfo()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PHONE_PERM_CODE) {
            loadAllInfo()
        }
    }

    // ── Gather all device info ────────────────────────────────────────────
    @SuppressLint("MissingPermission", "HardwareIds")
    private fun loadAllInfo() {
        val tm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val hasPhone = ContextCompat.checkSelfPermission(
            this, Manifest.permission.READ_PHONE_STATE
        ) == PackageManager.PERMISSION_GRANTED

        val sb = StringBuilder()

        // ── Device ────────────────────────────────────────────────────────
        sb.append("═══  DEVICE  ═══\n")
        sb.append("Manufacturer : ${Build.MANUFACTURER}\n")
        sb.append("Model        : ${Build.MODEL}\n")
        sb.append("Android      : ${Build.VERSION.RELEASE}  (API ${Build.VERSION.SDK_INT})\n")
        sb.append("Board        : ${Build.BOARD}\n")
        sb.append("Hardware     : ${Build.HARDWARE}\n")
        sb.append("Fingerprint  : ${Build.FINGERPRINT}\n\n")

        // ── Phone / SIM ───────────────────────────────────────────────────
        sb.append("═══  PHONE / SIM  ═══\n")
        if (hasPhone) {
            sb.append("IMEI         : ${getImei(tm)}\n")
            sb.append("Phone Type   : ${phoneType(tm.phoneType)}\n")
            sb.append("Network Op   : ${tm.networkOperatorName.ifEmpty { "—" }}\n")
            sb.append("Network Type : ${networkType(tm.networkType)}\n")
            sb.append("SIM State    : ${simState(tm.simState)}\n")
            sb.append("SIM Country  : ${tm.simCountryIso.uppercase().ifEmpty { "—" }}\n")
            sb.append("SIM Operator : ${tm.simOperatorName.ifEmpty { "—" }}\n")
            sb.append("Roaming      : ${if (tm.isNetworkRoaming) "Yes" else "No"}\n\n")
        } else {
            sb.append("⚠ READ_PHONE_STATE not granted — tap Refresh after allowing\n\n")
        }

        // ── Wi-Fi ─────────────────────────────────────────────────────────
        sb.append("═══  WI-FI  ═══\n")
        val wifiInfo = wm.connectionInfo
        sb.append("Enabled      : ${if (wm.isWifiEnabled) "Yes" else "No"}\n")
        if (wm.isWifiEnabled && wifiInfo != null) {
            val rssi = wifiInfo.rssi
            sb.append("SSID         : ${wifiInfo.ssid}\n")
            sb.append("BSSID        : ${wifiInfo.bssid ?: "—"}\n")
            sb.append("Link Speed   : ${wifiInfo.linkSpeed} Mbps\n")
            sb.append("Signal (dBm) : $rssi  ${signalBars(rssi)}\n")
            sb.append("IP Address   : ${intToIp(wifiInfo.ipAddress)}\n")
            sb.append("Frequency    : ${wifiInfo.frequency} MHz\n")
        }
        sb.append("\n")

        // ── Battery ───────────────────────────────────────────────────────
        sb.append("═══  BATTERY  ═══\n")
        val battFilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        val battIntent = registerReceiver(null, battFilter)
        if (battIntent != null) {
            val level = battIntent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = battIntent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
            val pct = if (scale > 0) (level * 100 / scale) else -1
            val status = battIntent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val health = battIntent.getIntExtra(BatteryManager.EXTRA_HEALTH, -1)
            val voltage = battIntent.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1)
            val temp = battIntent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1)
            val plugged = battIntent.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1)
            val technology = battIntent.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY) ?: "—"
            sb.append("Level        : $pct%\n")
            sb.append("Status       : ${battStatus(status)}\n")
            sb.append("Health       : ${battHealth(health)}\n")
            sb.append("Voltage      : ${voltage} mV\n")
            sb.append("Temperature  : ${temp / 10.0}°C\n")
            sb.append("Power Source : ${pluggedSource(plugged)}\n")
            sb.append("Technology   : $technology\n")
        }

        binding.tvInfo.text = sb.toString()
        binding.tvInfo.visibility = View.VISIBLE
    }

    // ── Helpers ───────────────────────────────────────────────────────────

    @SuppressLint("MissingPermission", "HardwareIds")
    private fun getImei(tm: TelephonyManager): String {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                tm.imei ?: "N/A (restricted on Android 10+)"
            } else {
                @Suppress("DEPRECATION")
                tm.deviceId ?: "—"
            }
        } catch (e: Exception) {
            "Requires carrier privilege"
        }
    }

    private fun phoneType(t: Int) = when (t) {
        TelephonyManager.PHONE_TYPE_GSM   -> "GSM"
        TelephonyManager.PHONE_TYPE_CDMA  -> "CDMA"
        TelephonyManager.PHONE_TYPE_SIP   -> "SIP"
        else                               -> "None / Unknown"
    }

    @Suppress("DEPRECATION")
    private fun networkType(t: Int) = when (t) {
        TelephonyManager.NETWORK_TYPE_LTE    -> "LTE (4G)"
        TelephonyManager.NETWORK_TYPE_NR     -> "NR (5G)"
        TelephonyManager.NETWORK_TYPE_HSDPA,
        TelephonyManager.NETWORK_TYPE_HSUPA,
        TelephonyManager.NETWORK_TYPE_HSPA   -> "HSPA (3G)"
        TelephonyManager.NETWORK_TYPE_UMTS   -> "UMTS (3G)"
        TelephonyManager.NETWORK_TYPE_EDGE   -> "EDGE (2G)"
        TelephonyManager.NETWORK_TYPE_GPRS   -> "GPRS (2G)"
        TelephonyManager.NETWORK_TYPE_UNKNOWN -> "Unknown"
        else -> "Type $t"
    }

    private fun simState(s: Int) = when (s) {
        TelephonyManager.SIM_STATE_READY          -> "Ready"
        TelephonyManager.SIM_STATE_ABSENT         -> "Absent"
        TelephonyManager.SIM_STATE_PIN_REQUIRED   -> "PIN Locked"
        TelephonyManager.SIM_STATE_PUK_REQUIRED   -> "PUK Locked"
        TelephonyManager.SIM_STATE_NETWORK_LOCKED -> "Network Locked"
        TelephonyManager.SIM_STATE_UNKNOWN -> "Unknown"
        else -> "State $s"
    }

    private fun battStatus(s: Int) = when (s) {
        BatteryManager.BATTERY_STATUS_CHARGING    -> "Charging"
        BatteryManager.BATTERY_STATUS_DISCHARGING -> "Discharging"
        BatteryManager.BATTERY_STATUS_FULL        -> "Full"
        BatteryManager.BATTERY_STATUS_NOT_CHARGING-> "Not Charging"
        else -> "Unknown"
    }

    private fun battHealth(h: Int) = when (h) {
        BatteryManager.BATTERY_HEALTH_GOOD        -> "Good"
        BatteryManager.BATTERY_HEALTH_OVERHEAT    -> "Overheat"
        BatteryManager.BATTERY_HEALTH_DEAD        -> "Dead"
        BatteryManager.BATTERY_HEALTH_COLD        -> "Cold"
        BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE-> "Over Voltage"
        else -> "Unknown"
    }

    private fun pluggedSource(p: Int) = when (p) {
        BatteryManager.BATTERY_PLUGGED_AC    -> "AC"
        BatteryManager.BATTERY_PLUGGED_USB   -> "USB"
        BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Wireless"
        0 -> "Battery (unplugged)"
        else -> "Unknown"
    }

    private fun signalBars(rssi: Int) = when {
        rssi >= -55 -> "▂▄▆█ Excellent"
        rssi >= -66 -> "▂▄▆░ Good"
        rssi >= -77 -> "▂▄░░ Fair"
        rssi >= -88 -> "▂░░░ Weak"
        else        -> "░░░░ Poor"
    }

    private fun intToIp(i: Int): String {
        return "${i and 0xFF}.${(i shr 8) and 0xFF}.${(i shr 16) and 0xFF}.${(i shr 24) and 0xFF}"
    }
}
