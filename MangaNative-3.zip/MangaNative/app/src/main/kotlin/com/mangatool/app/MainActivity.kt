package com.mangatool.app

import android.Manifest
import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.mangatool.app.adapter.ChapterAdapter
import com.mangatool.app.databinding.ActivityMainBinding
import com.mangatool.app.model.ImageGroup
import com.mangatool.app.model.ImageItem
import com.mangatool.app.util.CbzCreator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private var chapterAdapter: ChapterAdapter? = null
    private var isProcessing = false

    // ── File picker ───────────────────────────────────────────────────────────
    private val filePickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val data = result.data
            val uris: List<Uri> = when {
                data?.clipData != null -> (0 until data.clipData!!.itemCount)
                    .map { data.clipData!!.getItemAt(it).uri }
                data?.data != null -> listOf(data.data!!)
                else -> emptyList()
            }
            if (uris.isNotEmpty()) processFiles(uris)
        }
    }

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (!granted) Toast.makeText(this, "Storage permission needed", Toast.LENGTH_LONG).show()
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        setupControls()
        setupActionBar()
        refreshUI()
    }

    // ── UI setup ──────────────────────────────────────────────────────────────
    private fun setupControls() {
        // Mode tabs
        b.tabExtract.setOnClickListener { setMode("extract") }
        b.tabMerge.setOnClickListener   { setMode("merge") }

        // Settings panel toggle
        b.settingsToggle.setOnClickListener {
            val v = b.settingsPanel
            v.visibility = if (v.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }

        // Min-size slider
        b.sizeSlider.progress = AppState.minSizeKb
        updateSizeLabel()
        b.sizeSlider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, v: Int, user: Boolean) {
                AppState.minSizeKb = v
                updateSizeLabel()
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {
                AppState.applyFilters(); refreshChapterList()
            }
        })

        // Toggles
        b.toggleGifs.isChecked    = AppState.excludeGifs
        b.toggleReverse.isChecked = AppState.reverseOrder
        b.toggleRtl.isChecked     = AppState.rtlMode

        b.toggleGifs.setOnCheckedChangeListener { _, c ->
            AppState.excludeGifs = c; AppState.applyFilters(); refreshChapterList()
        }
        b.toggleReverse.setOnCheckedChangeListener { _, c ->
            AppState.reverseOrder = c; AppState.applyFilters(); refreshChapterList()
        }
        b.toggleRtl.setOnCheckedChangeListener { _, c ->
            AppState.rtlMode = c; AppState.applyFilters(); refreshChapterList()
        }

        // Drop zone / pick files
        b.dropZone.setOnClickListener { openFilePicker() }
        b.chapterList.layoutManager = LinearLayoutManager(this)
    }

    private fun setupActionBar() {
        b.btnAddMore.setOnClickListener { openFilePicker() }
        b.btnDownload.setOnClickListener { startDownload() }
        b.btnReset.setOnClickListener {
            AppState.reset()
            chapterAdapter = null
            b.chapterList.adapter = null
            refreshUI()
        }
    }

    private fun setMode(mode: String) {
        AppState.currentMode = mode
        b.tabExtract.isSelected = (mode == "extract")
        b.tabMerge.isSelected   = (mode == "merge")
        b.tabExtract.alpha = if (mode == "extract") 1f else 0.5f
        b.tabMerge.alpha   = if (mode == "merge")   1f else 0.5f

        // Show/hide RTL toggle (merge-only)
        b.rtlRow.visibility = if (mode == "merge") View.VISIBLE else View.GONE

        AppState.applyFilters()
        refreshChapterList()
    }

    private fun updateSizeLabel() {
        b.sizeLabel.text = "${AppState.minSizeKb} KB"
    }

    private fun refreshUI() {
        val hasGroups = AppState.groups.isNotEmpty()
        b.dropZone.visibility      = if (hasGroups) View.GONE else View.VISIBLE
        b.actionBar.visibility     = if (hasGroups) View.VISIBLE else View.GONE
        b.badgeText.visibility     = if (hasGroups) View.VISIBLE else View.GONE

        val totalImgs = AppState.groups.sumOf { it.displayImages.size }
        val totalKb   = AppState.groups.sumOf { g -> g.displayImages.sumOf { it.size.toLong() } } / 1024
        b.badgeText.text = "${AppState.groups.size} files / $totalImgs imgs"

        val sizeStr = when {
            totalKb > 1024 -> "%.1f MB".format(totalKb / 1024.0)
            else -> "$totalKb KB"
        }
        b.btnDownload.text = "Download All (~$sizeStr)"

        // Tab styling
        b.tabExtract.alpha = if (AppState.currentMode == "extract") 1f else 0.5f
        b.tabMerge.alpha   = if (AppState.currentMode == "merge")   1f else 0.5f
        b.rtlRow.visibility = if (AppState.currentMode == "merge") View.VISIBLE else View.GONE
    }

    private fun refreshChapterList() {
        chapterAdapter = ChapterAdapter(
            groups = AppState.groups,
            onImageClick = { groupIdx, imgIdx ->
                val intent = Intent(this, ImagePreviewActivity::class.java).apply {
                    putExtra(ImagePreviewActivity.EXTRA_GROUP_IDX, groupIdx)
                    putExtra(ImagePreviewActivity.EXTRA_IMAGE_IDX, imgIdx)
                    putExtra(ImagePreviewActivity.EXTRA_IS_MERGE, AppState.currentMode == "merge")
                }
                previewLauncher.launch(intent)
            },
            onGroupRemove = { idx ->
                AppState.groups.removeAt(idx)
                AppState.applyFilters()
                refreshChapterList()
                refreshUI()
            },
            onImageLongClick = { img ->
                img.userDeleted = true
                img.forceKeep   = false
                AppState.applyFilters()
                refreshChapterList()
            }
        )
        b.chapterList.adapter = chapterAdapter
        refreshUI()
    }

    // ── File picker ───────────────────────────────────────────────────────────
    private fun openFilePicker() {
        val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                "image/jpeg", "image/png", "image/webp", "image/gif",
                "multipart/related", "message/rfc822", "application/octet-stream"
            ))
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        filePickerLauncher.launch(Intent.createChooser(intent, "Select Files — MangaTool"))
    }

    // ── File processing ───────────────────────────────────────────────────────
    private fun processFiles(uris: List<Uri>) {
        if (isProcessing) return
        isProcessing = true
        b.progressArea.visibility = View.VISIBLE
        b.dropZone.visibility = View.GONE
        b.actionBar.visibility = View.GONE

        lifecycleScope.launch {
            val looseImages = mutableListOf<ImageItem>()

            uris.forEachIndexed { i, uri ->
                updateProgress("Reading ${i + 1}/${uris.size}…", (i * 100) / uris.size)

                val name = getFileName(uri).lowercase()
                val data: ByteArray? = withContext(Dispatchers.IO) {
                    runCatching { contentResolver.openInputStream(uri)?.readBytes() }.getOrNull()
                }
                if (data == null) return@forEachIndexed

                when {
                    name.endsWith(".mhtml") || name.endsWith(".mht") -> {
                        val group: ImageGroup? = withContext(Dispatchers.IO) {
                            MhtmlParser.parse(data, getFileName(uri))
                        }
                        if (group != null) AppState.groups.add(group)
                    }
                    name.matches(Regex(".*\\.(jpg|jpeg|png|webp|gif)")) -> {
                        val ext = name.substringAfterLast('.')
                        looseImages.add(ImageItem(looseImages.size, data, ext, data.size))
                    }
                }
            }

            if (looseImages.isNotEmpty()) {
                AppState.groups.add(
                    ImageGroup("Loose Images ${AppState.groups.size + 1}")
                        .also { it.allImages.addAll(looseImages) }
                )
            }

            AppState.applyFilters()
            isProcessing = false
            b.progressArea.visibility = View.GONE
            refreshChapterList()
        }
    }

    private fun updateProgress(msg: String, pct: Int) {
        b.progressStatus.text = msg
        b.progressBar.progress = pct
    }

    private fun getFileName(uri: Uri): String {
        val cursor = contentResolver.query(uri, null, null, null, null)
        return cursor?.use {
            val idx = it.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            it.moveToFirst()
            if (idx >= 0) it.getString(idx) else "file"
        } ?: uri.lastPathSegment ?: "file"
    }

    // ── Download ──────────────────────────────────────────────────────────────
    private fun startDownload() {
        if (AppState.groups.isEmpty()) return
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
                permLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                return
            }
        }

        b.btnDownload.isEnabled = false
        b.progressArea.visibility = View.VISIBLE
        val isMerge = AppState.currentMode == "merge"

        lifecycleScope.launch(Dispatchers.IO) {
            runCatching {
                CbzCreator.create(
                    context   = this@MainActivity,
                    groups    = AppState.groups,
                    isMerge   = isMerge,
                    isRtl     = AppState.rtlMode,
                    onProgress = { p ->
                        lifecycleScope.launch(Dispatchers.Main) {
                            updateProgress(p.message, p.percent)
                        }
                    }
                )
            }.onSuccess {
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility = View.GONE
                    b.btnDownload.text = "✅ Saved to Downloads!"
                    Toast.makeText(this@MainActivity, "Saved to Downloads!", Toast.LENGTH_LONG).show()
                }
            }.onFailure { e ->
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility = View.GONE
                    b.btnDownload.isEnabled = true
                    Toast.makeText(this@MainActivity, "Failed: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    // ── Preview result ────────────────────────────────────────────────────────
    private val previewLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            // Image was deleted in preview — refresh
            AppState.applyFilters()
            refreshChapterList()
        }
    }
}
