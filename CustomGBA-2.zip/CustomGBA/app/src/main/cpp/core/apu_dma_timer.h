#pragma once
#include "types.h"
#include "memory.h"
#include <cstring>
#include <functional>

// ─────────────────────────────────────────────────────────────────────────────
// APU - Audio Processing Unit
// ─────────────────────────────────────────────────────────────────────────────
struct APU {
    Memory* mem;
    static constexpr int SAMPLE_RATE  = 32768;
    static constexpr int BUFFER_SIZE  = 2048;

    float  sampleBuffer[BUFFER_SIZE*2] = {};
    int    samplePos = 0;
    int    cycles    = 0;
    int    cyclesPerSample;

    // Channel 1: Square wave with sweep
    struct Sq {
        bool  enabled = false;
        u8    duty    = 2;       // 0-3
        int   period  = 0;
        int   timer   = 0;
        int   lenTimer= 0;
        bool  lenEnable=false;
        int   volume  = 0;
        int   envTimer= 0;
        int   envPeriod=0;
        bool  envAdd  = false;
        int   pos     = 0;
        float sample  = 0;
    } sq1, sq2;

    // Channel 4: Noise
    struct Noise {
        bool  enabled  = false;
        u16   lfsr     = 0x7FFF;
        int   volume   = 0;
        int   timer    = 0;
        int   period   = 0;
        int   lenTimer = 0;
        bool  lenEnable= false;
        bool  shortMode= false;
        float sample   = 0;
    } noise;

    std::function<void(float*, int)> onSamplesReady;

    void init(Memory* m) {
        mem = m;
        cyclesPerSample = GBA_CPU_HZ / SAMPLE_RATE;
        memset(sampleBuffer, 0, sizeof(sampleBuffer));
    }

    void step(int cpuCycles) {
        cycles += cpuCycles;
        while (cycles >= cyclesPerSample) {
            cycles -= cyclesPerSample;
            generateSample();
        }
    }

    void generateSample() {
        float left  = 0.0f;
        float right = 0.0f;

        // Mix all channels
        u8 nr51 = mem->io[0x25]; // NR51 - channel panning
        u8 nr50 = mem->io[0x24]; // NR50 - master volume

        float masterL = ((nr50 >> 4) & 7) / 7.0f;
        float masterR = ((nr50 >> 0) & 7) / 7.0f;

        // Square 1
        tickSq(sq1);
        if ((nr51 >> 4) & 1) left  += sq1.sample * 0.25f;
        if ((nr51 >> 0) & 1) right += sq1.sample * 0.25f;

        // Square 2
        tickSq(sq2);
        if ((nr51 >> 5) & 1) left  += sq2.sample * 0.25f;
        if ((nr51 >> 1) & 1) right += sq2.sample * 0.25f;

        // Noise
        tickNoise();
        if ((nr51 >> 7) & 1) left  += noise.sample * 0.25f;
        if ((nr51 >> 3) & 1) right += noise.sample * 0.25f;

        sampleBuffer[samplePos*2  ] = left  * masterL * 0.5f;
        sampleBuffer[samplePos*2+1] = right * masterR * 0.5f;
        samplePos++;

        if (samplePos >= BUFFER_SIZE) {
            if (onSamplesReady) onSamplesReady(sampleBuffer, BUFFER_SIZE);
            samplePos = 0;
        }
    }

    static const int DUTY_TABLE[4][8];

    void tickSq(Sq& sq) {
        if (!sq.enabled) { sq.sample=0; return; }
        sq.timer--;
        if (sq.timer <= 0) {
            sq.pos = (sq.pos+1) & 7;
            sq.timer = sq.period;
        }
        sq.sample = DUTY_TABLE[sq.duty][sq.pos] ? sq.volume/15.0f : -sq.volume/15.0f;
    }

    void tickNoise() {
        if (!noise.enabled) { noise.sample=0; return; }
        noise.timer--;
        if (noise.timer <= 0) {
            noise.timer = noise.period;
            bool bit0 = noise.lfsr & 1;
            bool bit1 = (noise.lfsr >> 1) & 1;
            bool xorBit = bit0 ^ bit1;
            noise.lfsr >>= 1;
            if (xorBit) noise.lfsr |= 0x4000;
            if (noise.shortMode && xorBit) noise.lfsr |= 0x40;
        }
        noise.sample = (noise.lfsr & 1) ? noise.volume/15.0f : -noise.volume/15.0f;
    }
};

const int APU::DUTY_TABLE[4][8] = {
    {0,0,0,0,0,0,0,1}, // 12.5%
    {1,0,0,0,0,0,0,1}, // 25%
    {1,0,0,0,0,0,1,1}, // 50%
    {0,1,1,1,1,1,1,0}  // 75%
};

// ─────────────────────────────────────────────────────────────────────────────
// DMA Controller
// ─────────────────────────────────────────────────────────────────────────────
struct DMA {
    Memory* mem;

    struct Channel {
        u32  src, dst, count;
        u16  ctrl;
        bool active = false;
    } ch[4];

    void init(Memory* m) { mem=m; memset(ch,0,sizeof(ch)); }

    void trigger(int n) {
        u32 base = 0x040000B0 + n*12;
        ch[n].src   = mem->read32(base+0) & 0x0FFFFFFF;
        ch[n].dst   = mem->read32(base+4) & 0x0FFFFFFF;
        ch[n].count = mem->read16(base+8);
        ch[n].ctrl  = mem->read16(base+10);
        if (ch[n].count==0) ch[n].count = (n==3) ? 0x10000 : 0x4000;
        ch[n].active = true;
    }

    void step() {
        for (int n=0;n<4;n++) {
            u32 base = 0x040000B0 + n*12;
            u16 ctrl = mem->read16(base+10);
            if (!(ctrl & (1<<15))) continue; // DMA enable bit

            // Start timing
            u32 timing = (ctrl >> 12) & 3;
            if (!ch[n].active) { if (timing==0) trigger(n); else continue; }

            if (!ch[n].active) continue;

            bool word   = (ctrl >> 10) & 1;
            int  dstInc = (ctrl >>  5) & 3; // 0=+1, 1=-1, 2=fixed, 3=reload
            int  srcInc = (ctrl >>  7) & 3;

            u32 srcStep = word ? 4 : 2;
            u32 dstStep = word ? 4 : 2;

            // Transfer all at once (simplified, not cycle-accurate)
            for (u32 i=0;i<ch[n].count;i++) {
                if (word) mem->write32(ch[n].dst, mem->read32(ch[n].src));
                else      mem->write16(ch[n].dst, mem->read16(ch[n].src));

                if (srcInc==0) ch[n].src += srcStep;
                else if (srcInc==1) ch[n].src -= srcStep;

                if (dstInc==0) ch[n].dst += dstStep;
                else if (dstInc==1) ch[n].dst -= dstStep;
            }

            // IRQ on completion
            if (ctrl & (1<<14)) mem->raiseIRQ(IRQ_DMA0 << n);

            // Repeat flag
            if (!(ctrl & (1<<9))) {
                // Disable DMA
                u16 c = mem->read16(base+10);
                mem->write16(base+10, c & ~(1<<15));
            }
            ch[n].active = false;
        }
    }
};

// ─────────────────────────────────────────────────────────────────────────────
// Timer Controller
// ─────────────────────────────────────────────────────────────────────────────
struct Timers {
    Memory* mem;

    struct Timer {
        u16  counter  = 0;
        u16  reload   = 0;
        bool enable   = false;
        bool cascade  = false;
        bool irq      = false;
        int  prescaler= 1;
        int  cycles   = 0;
        bool overflow = false;
    } t[4];

    static constexpr int PRESCALERS[4] = {1, 64, 256, 1024};

    void init(Memory* m) { mem=m; memset(t,0,sizeof(t)); }

    void step(int cpuCycles) {
        for (int n=0;n<4;n++) {
            u32 base = 0x04000100 + n*4;
            u16 ctrl = mem->io[(base+2)-0x04000000];
            t[n].enable    = (ctrl >> 7) & 1;
            t[n].cascade   = (ctrl >> 2) & 1;
            t[n].irq       = (ctrl >> 6) & 1;
            t[n].prescaler = PRESCALERS[ctrl & 3];
            t[n].reload    = mem->io[(base)-0x04000000] | (mem->io[(base+1)-0x04000000]<<8);

            if (!t[n].enable) continue;
            if (t[n].cascade) continue; // Cascaded timers tick via overflow of prev

            t[n].cycles += cpuCycles;
            while (t[n].cycles >= t[n].prescaler) {
                t[n].cycles -= t[n].prescaler;
                t[n].counter++;
                if (t[n].counter == 0) { // Overflow
                    t[n].counter = t[n].reload;
                    t[n].overflow = true;
                    if (t[n].irq) mem->raiseIRQ(IRQ_TIMER0 << n);
                    // Cascade into next timer
                    if (n < 3 && t[n+1].cascade && t[n+1].enable) {
                        t[n+1].counter++;
                        if (t[n+1].counter == 0) {
                            t[n+1].counter = t[n+1].reload;
                            if (t[n+1].irq) mem->raiseIRQ(IRQ_TIMER0 << (n+1));
                        }
                    }
                }
            }

            // Write back counter to IO
            mem->io[(base)-0x04000000]   = t[n].counter & 0xFF;
            mem->io[(base+1)-0x04000000] = t[n].counter >> 8;
        }
    }
};
