package com.zipapkbuilder

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.util.Base64
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import java.util.zip.ZipInputStream
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    // ── UI ──────────────────────────────────────────────────────────────────
    private lateinit var etToken: EditText
    private lateinit var tvOwnerInfo: TextView      // shows "✓ @username" after verify
    private lateinit var etRepo: EditText
    private lateinit var etBranch: EditText
    private lateinit var btnPickZip: Button
    private lateinit var tvFileName: TextView
    private lateinit var btnUploadBuild: Button
    private lateinit var tvStatus: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var btnDownloadApk: Button
    private lateinit var tvLog: TextView
    private lateinit var scrollLog: ScrollView

    // ── State ────────────────────────────────────────────────────────────────
    private val mainHandler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("cfg", MODE_PRIVATE) }

    private var selectedZipUri: Uri? = null
    private var selectedZipName = ""
    private var artifactDownloadUrl: String? = null
    private var isBusy = false

    // ── Workflow YAML (auto-committed to new repos) ───────────────────────────
    private val WORKFLOW_YAML: String by lazy {
        val d = "\$"
        """
name: Build APK

on:
  push:
    branches: [ main, master ]
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    permissions:
      contents: write

    steps:
      - name: Checkout code
        uses: actions/checkout@v4
        with:
          token: ${d}{{ secrets.GITHUB_TOKEN }}

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          java-version: '17'
          distribution: 'temurin'

      - name: Setup Android SDK
        uses: android-actions/setup-android@v3

      - name: Cache NDK and CMake
        id: cache-ndk
        uses: actions/cache@v4
        with:
          path: |
            ${d}{{ env.ANDROID_HOME }}/ndk/25.2.9519653
            ${d}{{ env.ANDROID_HOME }}/cmake/3.22.1
          key: ndk-25.2.9519653-cmake-3.22.1

      - name: Install NDK and CMake
        run: |
          if [ ! -d "${d}ANDROID_SDK_ROOT/ndk/25.2.9519653" ]; then
            sdkmanager --install "ndk;25.2.9519653"
          fi
          if [ ! -d "${d}ANDROID_SDK_ROOT/cmake/3.22.1" ]; then
            sdkmanager --install "cmake;3.22.1"
          fi
          echo "ANDROID_NDK_HOME=${d}ANDROID_SDK_ROOT/ndk/25.2.9519653" >> ${d}GITHUB_ENV

      - name: Setup Gradle
        uses: gradle/actions/setup-gradle@v3
        with:
          gradle-version: '8.6'
          cache-read-only: false

      - name: Unzip project
        run: |
          ZIP=${d}(find . -maxdepth 2 -name "*.zip" -printf "%T@ %p\n" | sort -rn | head -1 | cut -d" " -f2-)
          ZIP_NAME=${d}(basename "${d}ZIP" .zip)
          echo "zip_name=${d}ZIP_NAME" >> ${d}GITHUB_ENV
          echo "zip_path=${d}ZIP" >> ${d}GITHUB_ENV
          unzip -q "${d}ZIP" -d extracted

      - name: Find project directory
        id: find_project
        run: |
          RESULT=${d}(find extracted -maxdepth 4 \( -name "settings.gradle" -o -name "settings.gradle.kts" \) | head -1)
          if [ -z "${d}RESULT" ]; then
            echo "##[error]No settings.gradle found inside the zip!"
            exit 1
          fi
          PROJECT_DIR=${d}(dirname "${d}RESULT")
          echo "project_dir=${d}PROJECT_DIR" >> ${d}GITHUB_OUTPUT

      - name: Fetch gradle-wrapper.jar
        working-directory: ${d}{{ steps.find_project.outputs.project_dir }}
        run: |
          mkdir -p gradle/wrapper
          curl --fail --silent --show-error --location \
            "https://raw.githubusercontent.com/gradle/gradle/v8.6.0/gradle/wrapper/gradle-wrapper.jar" \
            -o "gradle/wrapper/gradle-wrapper.jar"

      - name: Make gradlew executable
        working-directory: ${d}{{ steps.find_project.outputs.project_dir }}
        run: chmod +x gradlew && sed -i 's/\r//' gradlew

      - name: Build Debug APK
        id: build
        working-directory: ${d}{{ steps.find_project.outputs.project_dir }}
        run: ./gradlew assembleDebug --no-daemon --build-cache --parallel
        env:
          ANDROID_NDK_HOME: ${d}{{ env.ANDROID_NDK_HOME }}

      - name: Delete zip from repo on build failure
        if: failure()
        run: |
          ZIP="${d}{{ env.zip_path }}"
          if [ -n "${d}ZIP" ] && [ -f "${d}ZIP" ]; then
            git config user.name "github-actions[bot]"
            git config user.email "github-actions[bot]@users.noreply.github.com"
            git rm "${d}ZIP"
            git commit -m "ci: remove ${d}ZIP (build failed on run #${d}{{ github.run_number }})"
            git push
          fi

      - name: Upload APK artifact
        if: success()
        uses: actions/upload-artifact@v4
        with:
          name: ${d}{{ env.zip_name }}-debug-v${d}{{ github.run_number }}
          path: ${d}{{ steps.find_project.outputs.project_dir }}/app/build/outputs/apk/debug/*.apk
          retention-days: 30
        """.trimIndent()
    }

    // ── File picker launcher ─────────────────────────────────────────────────
    private val pickZip = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri ?: return@registerForActivityResult
        selectedZipUri = uri
        selectedZipName = resolveFileName(uri)
        tvFileName.text = selectedZipName
        appendLog("Selected: $selectedZipName")
    }

    // ── Lifecycle ────────────────────────────────────────────────────────────
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etToken        = findViewById(R.id.etToken)
        tvOwnerInfo    = findViewById(R.id.tvOwnerInfo)
        etRepo         = findViewById(R.id.etRepo)
        etBranch       = findViewById(R.id.etBranch)
        btnPickZip     = findViewById(R.id.btnPickZip)
        tvFileName     = findViewById(R.id.tvFileName)
        btnUploadBuild = findViewById(R.id.btnUploadBuild)
        tvStatus       = findViewById(R.id.tvStatus)
        progressBar    = findViewById(R.id.progressBar)
        btnDownloadApk = findViewById(R.id.btnDownloadApk)
        tvLog          = findViewById(R.id.tvLog)
        scrollLog      = findViewById(R.id.scrollLog)

        // Restore saved config
        etToken.setText(prefs.getString("token", ""))
        etRepo.setText(prefs.getString("repo", ""))
        etBranch.setText(prefs.getString("branch", "main"))

        btnPickZip.setOnClickListener     { if (!isBusy) pickZip.launch("application/zip") }
        btnUploadBuild.setOnClickListener  { if (!isBusy) startFlow() }
        btnDownloadApk.setOnClickListener  { artifactDownloadUrl?.let { downloadArtifact(it) } }

        setStatus("Idle")
    }

    // ── Entry point ──────────────────────────────────────────────────────────
    private fun startFlow() {
        val token  = etToken.text.toString().trim()
        val repo   = etRepo.text.toString().trim()
        val branch = etBranch.text.toString().trim().ifEmpty { "main" }
        val uri    = selectedZipUri

        if (token.isEmpty()) { appendLog("⚠ Enter your GitHub Personal Access Token."); return }
        if (repo.isEmpty())  { appendLog("⚠ Enter a repository name."); return }
        if (uri == null)     { appendLog("⚠ Pick a ZIP file first."); return }

        prefs.edit()
            .putString("token", token)
            .putString("repo", repo)
            .putString("branch", branch)
            .apply()

        setBusy(true)
        tvLog.text = ""
        artifactDownloadUrl = null
        btnDownloadApk.isEnabled = false
        mainHandler.post { tvOwnerInfo.text = "" }

        thread { runFlow(token, repo, branch, uri) }
    }

    // ── Main flow (background thread) ────────────────────────────────────────
    private fun runFlow(token: String, repo: String, branch: String, uri: Uri) {
        try {
            // ── 1. Verify token & get username ───────────────────────────────
            setStatus("Verifying token…")
            appendLog("Verifying GitHub token…")
            val owner = fetchOwner(token)
                ?: throw Exception("Token invalid or no network. Make sure your PAT has 'repo' scope.")
            appendLog("✓  Signed in as @$owner")
            mainHandler.post { tvOwnerInfo.text = "✓  @$owner" }

            // ── 2. Ensure repo exists (create if not) ────────────────────────
            setStatus("Checking repo…")
            appendLog("Checking github.com/$owner/$repo …")
            ensureRepo(token, owner, repo)

            // ── 3. Ensure workflow file is committed ─────────────────────────
            setStatus("Setting up workflow…")
            ensureWorkflow(token, owner, repo, branch)

            // ── 4. Read & base64-encode ZIP ──────────────────────────────────
            setStatus("Reading ZIP…")
            appendLog("Reading ZIP…")
            val bytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
            val b64   = Base64.encodeToString(bytes, Base64.NO_WRAP)
            appendLog("Size: ${bytes.size / 1024} KB  →  encoded: ${b64.length / 1024} KB")
            if (b64.length > 95 * 1024 * 1024) {
                throw Exception("ZIP too large for GitHub Contents API (> ~70 MB raw). Split or reduce the project.")
            }

            // ── 5. Upload ZIP to GitHub ──────────────────────────────────────
            setStatus("Uploading…")
            appendLog("Uploading to github.com/$owner/$repo …")
            val remotePath  = "uploads/$selectedZipName"
            val existingSha = fetchFileSha(token, owner, repo, remotePath)
            val uploadJson  = JSONObject().apply {
                put("message", "ci: upload $selectedZipName [run ${System.currentTimeMillis()}]")
                put("content", b64)
                put("branch", branch)
                if (existingSha != null) {
                    put("sha", existingSha)
                    appendLog("Replacing existing file (SHA: ${existingSha.take(8)}…)")
                }
            }.toString()

            val (upCode, upBody) = httpPut(token, apiContents(owner, repo, remotePath), uploadJson)
            if (upCode !in 200..201) throw Exception("Upload failed ($upCode): ${upBody.take(400)}")
            appendLog("Upload OK — GitHub Actions will start shortly…")

            // ── 6. Wait for workflow run ─────────────────────────────────────
            setStatus("Waiting for build…")
            appendLog("Waiting for GitHub Actions to pick up the commit…")
            val afterMs = System.currentTimeMillis()
            Thread.sleep(6_000)

            val runId = waitForRun(token, owner, repo, branch, afterMs)
                ?: throw Exception("No workflow run appeared within 3 minutes. " +
                    "Check that build.yml is on the $branch branch.")
            appendLog("Run #$runId started — building…")

            // ── 7. Poll until done ───────────────────────────────────────────
            setStatus("Building…")
            val success = pollRunUntilDone(token, owner, repo, runId)
            if (!success) throw Exception(
                "Build failed. Open github.com/$owner/$repo/actions to see the logs.")

            // ── 8. Retrieve artifact ─────────────────────────────────────────
            setStatus("Fetching APK…")
            appendLog("Build succeeded! Looking for APK artifact…")
            val (artName, artUrl) = fetchArtifact(token, owner, repo, runId)
                ?: throw Exception("Run succeeded but no artifact found. " +
                    "Check the 'Upload APK artifact' step in the workflow log.")

            artifactDownloadUrl = artUrl
            appendLog("Artifact ready: $artName")
            setStatus("Ready ✓")
            mainHandler.post { btnDownloadApk.isEnabled = true }

        } catch (e: Exception) {
            appendLog("✗ ${e.message}")
            setStatus("Failed")
        } finally {
            setBusy(false)
        }
    }

    // ── Auto-setup helpers ────────────────────────────────────────────────────

    /** GET /user → returns login (username) or null on failure */
    private fun fetchOwner(token: String): String? = try {
        val (code, body) = httpGet(token, "https://api.github.com/user")
        if (code == 200) JSONObject(body).optString("login").takeIf { it.isNotEmpty() }
        else null
    } catch (_: Exception) { null }

    /**
     * Check if repo exists; if not, create it automatically.
     * Uses POST /user/repos for private repo with Actions enabled.
     */
    private fun ensureRepo(token: String, owner: String, repo: String) {
        val (code, _) = httpGet(token, "https://api.github.com/repos/$owner/$repo")
        if (code == 200) {
            appendLog("Repo already exists ✓")
            return
        }
        appendLog("Repo not found — creating github.com/$owner/$repo …")
        val body = JSONObject().apply {
            put("name", repo)
            put("private", false)
            put("auto_init", true)          // creates initial commit so we can push files
            put("description", "APK build repo — managed by ZipApkBuilder")
        }.toString()
        val (createCode, createBody) = httpPost(token, "https://api.github.com/user/repos", body)
        if (createCode !in 200..201) throw Exception("Could not create repo ($createCode): ${createBody.take(300)}")
        appendLog("Repo created ✓ — waiting for GitHub to initialise it…")
        Thread.sleep(4_000)   // GitHub needs a moment before the default branch exists
    }

    /**
     * Check if .github/workflows/build.yml exists; if not, commit it.
     */
    private fun ensureWorkflow(token: String, owner: String, repo: String, branch: String) {
        val path = ".github/workflows/build.yml"
        val existingSha = fetchFileSha(token, owner, repo, path)
        if (existingSha != null) {
            appendLog("Workflow already present ✓")
            return
        }
        appendLog("Committing build workflow to repo…")
        val encoded = Base64.encodeToString(WORKFLOW_YAML.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
        val payload = JSONObject().apply {
            put("message", "ci: add GitHub Actions build workflow")
            put("content", encoded)
            put("branch", branch)
        }.toString()
        val (code, body) = httpPut(token, apiContents(owner, repo, path), payload)
        if (code !in 200..201) throw Exception("Could not commit workflow ($code): ${body.take(300)}")
        appendLog("Workflow committed ✓")
        Thread.sleep(2_000)   // brief pause before next push
    }

    // ── GitHub API helpers ────────────────────────────────────────────────────

    private fun fetchFileSha(token: String, owner: String, repo: String, path: String): String? =
        try {
            val (code, body) = httpGet(token, apiContents(owner, repo, path))
            if (code == 200) JSONObject(body).optString("sha").takeIf { it.isNotEmpty() }
            else null
        } catch (_: Exception) { null }

    private fun waitForRun(token: String, owner: String, repo: String, branch: String, afterMs: Long): Long? {
        val deadline = System.currentTimeMillis() + 3 * 60_000L
        while (System.currentTimeMillis() < deadline) {
            try {
                val url = "${apiRuns(owner, repo)}?branch=$branch&per_page=10&event=push"
                val (code, body) = httpGet(token, url)
                if (code == 200) {
                    val runs = JSONObject(body).getJSONArray("workflow_runs")
                    for (i in 0 until runs.length()) {
                        val run    = runs.getJSONObject(i)
                        val runMs  = parseIso8601(run.getString("created_at"))
                        if (runMs >= afterMs - 15_000) return run.getLong("id")
                    }
                }
            } catch (_: Exception) {}
            Thread.sleep(10_000)
        }
        return null
    }

    private fun pollRunUntilDone(token: String, owner: String, repo: String, runId: Long): Boolean {
        val deadline = System.currentTimeMillis() + 45 * 60_000L
        while (System.currentTimeMillis() < deadline) {
            try {
                val (code, body) = httpGet(token, "${apiRuns(owner, repo)}/$runId")
                if (code == 200) {
                    val obj        = JSONObject(body)
                    val status     = obj.getString("status")
                    val conclusion = obj.optString("conclusion", "-")
                    appendLog("  status=$status  conclusion=$conclusion")
                    if (status == "completed") return conclusion == "success"
                }
            } catch (_: Exception) {}
            Thread.sleep(15_000)
        }
        return false
    }

    private fun fetchArtifact(token: String, owner: String, repo: String, runId: Long): Pair<String, String>? {
        val (code, body) = httpGet(token, "${apiRuns(owner, repo)}/$runId/artifacts")
        if (code != 200) return null
        val artifacts = JSONObject(body).getJSONArray("artifacts")
        if (artifacts.length() == 0) return null
        val art = artifacts.getJSONObject(0)
        return art.getString("name") to art.getString("archive_download_url")
    }

    // ── Download & install ────────────────────────────────────────────────────

    private fun downloadArtifact(downloadUrl: String) {
        if (isBusy) return
        setBusy(true)
        btnDownloadApk.isEnabled = false
        setStatus("Downloading…")
        appendLog("Downloading artifact ZIP…")
        val token = etToken.text.toString().trim()

        thread {
            try {
                // Follow GitHub redirect to S3
                var conn = URL(downloadUrl).openConnection() as HttpURLConnection
                conn.setRequestProperty("Authorization", "token $token")
                conn.setRequestProperty("Accept", "application/vnd.github.v3+json")
                conn.instanceFollowRedirects = false
                conn.connectTimeout = 30_000
                conn.readTimeout    = 30_000
                conn.connect()

                val realUrl = if (conn.responseCode in 301..308) {
                    val loc = conn.getHeaderField("Location")
                    conn.disconnect(); loc
                } else { downloadUrl }

                val dlConn = URL(realUrl).openConnection() as HttpURLConnection
                dlConn.connectTimeout = 60_000
                dlConn.readTimeout   = 180_000
                val total = dlConn.contentLength
                appendLog("Downloading… (${if (total > 0) "${total / 1024} KB" else "size unknown"})")

                val artifactZip = File(cacheDir, "artifact_${System.currentTimeMillis()}.zip")
                dlConn.inputStream.use { inp -> FileOutputStream(artifactZip).use { inp.copyTo(it) } }
                dlConn.disconnect()
                appendLog("Downloaded: ${artifactZip.length() / 1024} KB")

                val apkFile = extractApk(artifactZip)
                    ?: throw Exception("No .apk found inside the artifact ZIP.")
                appendLog("Extracted: ${apkFile.name}  (${apkFile.length() / 1024} KB)")

                setStatus("Done ✓")
                mainHandler.post {
                    btnDownloadApk.isEnabled = true
                    offerInstall(apkFile)
                }

            } catch (e: Exception) {
                appendLog("✗ Download error: ${e.message}")
                setStatus("Download failed")
                mainHandler.post { btnDownloadApk.isEnabled = true }
            } finally {
                setBusy(false)
            }
        }
    }

    private fun extractApk(zipFile: File): File? {
        val outDir = File(cacheDir, "apks").also { it.mkdirs() }
        ZipInputStream(zipFile.inputStream().buffered()).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                if (!entry.isDirectory && entry.name.endsWith(".apk")) {
                    val out = File(outDir, File(entry.name).name)
                    FileOutputStream(out).use { zis.copyTo(it) }
                    return out
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
        return null
    }

    private fun offerInstall(apkFile: File) {
        val uri = FileProvider.getUriForFile(this, "${packageName}.provider", apkFile)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION
        }
        startActivity(Intent.createChooser(intent, "Install APK"))
    }

    // ── Low-level HTTP ────────────────────────────────────────────────────────

    private fun httpGet(token: String, urlStr: String): Pair<Int, String> {
        val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            setRequestProperty("Authorization", "token $token")
            setRequestProperty("Accept", "application/vnd.github.v3+json")
            connectTimeout = 30_000
            readTimeout    = 30_000
        }
        return readResponse(conn)
    }

    private fun httpPut(token: String, urlStr: String, body: String): Pair<Int, String> {
        val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = "PUT"
            setRequestProperty("Authorization", "token $token")
            setRequestProperty("Accept", "application/vnd.github.v3+json")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            doOutput      = true
            connectTimeout = 120_000
            readTimeout    = 120_000
        }
        conn.outputStream.bufferedWriter().use { it.write(body) }
        return readResponse(conn)
    }

    private fun httpPost(token: String, urlStr: String, body: String): Pair<Int, String> {
        val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            setRequestProperty("Authorization", "token $token")
            setRequestProperty("Accept", "application/vnd.github.v3+json")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            doOutput      = true
            connectTimeout = 30_000
            readTimeout    = 30_000
        }
        conn.outputStream.bufferedWriter().use { it.write(body) }
        return readResponse(conn)
    }

    private fun readResponse(conn: HttpURLConnection): Pair<Int, String> =
        try {
            val code   = conn.responseCode
            val stream = if (code < 400) conn.inputStream else conn.errorStream
            Pair(code, stream?.bufferedReader()?.readText() ?: "")
        } finally { conn.disconnect() }

    // ── URL builders ──────────────────────────────────────────────────────────

    private fun apiContents(owner: String, repo: String, path: String) =
        "https://api.github.com/repos/$owner/$repo/contents/$path"

    private fun apiRuns(owner: String, repo: String) =
        "https://api.github.com/repos/$owner/$repo/actions/runs"

    // ── UI helpers ────────────────────────────────────────────────────────────

    private fun setStatus(text: String) = mainHandler.post {
        tvStatus.text = text
        tvStatus.setTextColor(
            when {
                text.contains("✓") || text.startsWith("Ready") || text.startsWith("Done") ->
                    0xFF4CAF50.toInt()
                text.contains("✗") || text.startsWith("Fail") ->
                    0xFFFF5252.toInt()
                else -> 0xFFFFFFFF.toInt()
            }
        )
    }

    private fun appendLog(msg: String) = mainHandler.post {
        tvLog.append("$msg\n")
        scrollLog.post { scrollLog.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun setBusy(busy: Boolean) = mainHandler.post {
        isBusy                   = busy
        progressBar.visibility   = if (busy) View.VISIBLE else View.GONE
        btnUploadBuild.isEnabled = !busy
        btnPickZip.isEnabled     = !busy
    }

    // ── Utilities ─────────────────────────────────────────────────────────────

    private fun resolveFileName(uri: Uri): String {
        var name = "project.zip"
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val col = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (c.moveToFirst() && col >= 0) name = c.getString(col)
        }
        name = name.replace(Regex("[^a-zA-Z0-9._\\-]"), "_")
        if (!name.lowercase().endsWith(".zip")) name += ".zip"
        return name
    }

    private fun parseIso8601(s: String): Long = try {
        SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
            .apply { timeZone = TimeZone.getTimeZone("UTC") }
            .parse(s)?.time ?: 0L
    } catch (_: Exception) { 0L }
}
