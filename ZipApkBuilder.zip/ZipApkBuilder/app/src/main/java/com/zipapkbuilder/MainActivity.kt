package com.zipapkbuilder

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.util.Base64
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import java.util.zip.ZipInputStream
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    // ── UI ──────────────────────────────────────────────────────────────────
    private lateinit var etToken: EditText
    private lateinit var etOwner: EditText
    private lateinit var etRepo: EditText
    private lateinit var etBranch: EditText
    private lateinit var btnPickZip: Button
    private lateinit var tvFileName: TextView
    private lateinit var btnUploadBuild: Button
    private lateinit var tvStatus: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var btnDownloadApk: Button
    private lateinit var tvLog: TextView
    private lateinit var scrollLog: ScrollView

    // ── State ────────────────────────────────────────────────────────────────
    private val mainHandler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("cfg", MODE_PRIVATE) }

    private var selectedZipUri: Uri? = null
    private var selectedZipName = ""
    private var artifactDownloadUrl: String? = null
    private var isBusy = false

    // ── File picker launcher ─────────────────────────────────────────────────
    private val pickZip = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri ?: return@registerForActivityResult
        selectedZipUri = uri
        selectedZipName = resolveFileName(uri)
        tvFileName.text = selectedZipName
        appendLog("Selected: $selectedZipName")
    }

    // ── Lifecycle ────────────────────────────────────────────────────────────
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etToken       = findViewById(R.id.etToken)
        etOwner       = findViewById(R.id.etOwner)
        etRepo        = findViewById(R.id.etRepo)
        etBranch      = findViewById(R.id.etBranch)
        btnPickZip    = findViewById(R.id.btnPickZip)
        tvFileName    = findViewById(R.id.tvFileName)
        btnUploadBuild = findViewById(R.id.btnUploadBuild)
        tvStatus      = findViewById(R.id.tvStatus)
        progressBar   = findViewById(R.id.progressBar)
        btnDownloadApk = findViewById(R.id.btnDownloadApk)
        tvLog         = findViewById(R.id.tvLog)
        scrollLog     = findViewById(R.id.scrollLog)

        // Restore saved config
        etToken.setText(prefs.getString("token", ""))
        etOwner.setText(prefs.getString("owner", ""))
        etRepo.setText(prefs.getString("repo", ""))
        etBranch.setText(prefs.getString("branch", "main"))

        btnPickZip.setOnClickListener    { if (!isBusy) pickZip.launch("application/zip") }
        btnUploadBuild.setOnClickListener { if (!isBusy) startFlow() }
        btnDownloadApk.setOnClickListener { artifactDownloadUrl?.let { downloadArtifact(it) } }

        setStatus("Idle")
    }

    // ── Entry point ──────────────────────────────────────────────────────────
    private fun startFlow() {
        val token  = etToken.text.toString().trim()
        val owner  = etOwner.text.toString().trim()
        val repo   = etRepo.text.toString().trim()
        val branch = etBranch.text.toString().trim().ifEmpty { "main" }
        val uri    = selectedZipUri

        if (token.isEmpty() || owner.isEmpty() || repo.isEmpty()) {
            appendLog("⚠ Fill in Token, Owner, and Repository first.")
            return
        }
        if (uri == null) {
            appendLog("⚠ Pick a ZIP file first.")
            return
        }

        prefs.edit()
            .putString("token", token).putString("owner", owner)
            .putString("repo", repo).putString("branch", branch)
            .apply()

        setBusy(true)
        tvLog.text = ""
        artifactDownloadUrl = null
        btnDownloadApk.isEnabled = false

        thread { runFlow(token, owner, repo, branch, uri) }
    }

    // ── Main flow (background thread) ────────────────────────────────────────
    private fun runFlow(token: String, owner: String, repo: String, branch: String, uri: Uri) {
        try {
            // 1 ─ Read & base64-encode ZIP
            setStatus("Reading ZIP…")
            appendLog("Reading ZIP…")
            val bytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
            val b64   = Base64.encodeToString(bytes, Base64.NO_WRAP)
            appendLog("Size: ${bytes.size / 1024} KB  →  encoded: ${b64.length / 1024} KB")
            if (b64.length > 95 * 1024 * 1024) {   // ~95 MB encoded ≈ ~70 MB raw
                throw Exception("ZIP too large for GitHub Contents API (>70 MB raw). Split or reduce the project.")
            }

            // 2 ─ Upload ZIP to GitHub
            setStatus("Uploading…")
            appendLog("Uploading to github.com/$owner/$repo …")
            val remotePath = "uploads/$selectedZipName"
            val existingSha = fetchFileSha(token, owner, repo, remotePath)
            val uploadJson  = JSONObject().apply {
                put("message", "ci: upload $selectedZipName [run ${System.currentTimeMillis()}]")
                put("content", b64)
                put("branch", branch)
                if (existingSha != null) {
                    put("sha", existingSha)
                    appendLog("Replacing existing file (SHA: ${existingSha.take(8)}…)")
                }
            }.toString()

            val (upCode, upBody) = httpPut(token, apiContents(owner, repo, remotePath), uploadJson)
            if (upCode !in 200..201) throw Exception("Upload failed ($upCode): ${upBody.take(400)}")
            appendLog("Upload OK. Commit created — workflow will trigger on push.")

            // 3 ─ Wait for a new workflow run to appear
            setStatus("Waiting for build…")
            appendLog("Waiting for GitHub Actions to pick up the commit…")
            val afterMs = System.currentTimeMillis()
            Thread.sleep(6_000)

            val runId = waitForRun(token, owner, repo, branch, afterMs)
                ?: throw Exception("No workflow run appeared within 3 minutes. " +
                        "Check that .github/workflows/build.yml is committed to the $branch branch.")
            appendLog("Run ID: $runId  ─  build is in progress…")

            // 4 ─ Poll until the run finishes
            setStatus("Building…")
            val success = pollRunUntilDone(token, owner, repo, runId)
            if (!success) throw Exception(
                "Build failed. Open github.com/$owner/$repo/actions to see the logs.")

            // 5 ─ Retrieve artifact info
            setStatus("Fetching APK…")
            appendLog("Build succeeded! Looking for APK artifact…")
            val (artName, artUrl) = fetchArtifact(token, owner, repo, runId)
                ?: throw Exception("Run succeeded but no artifacts were found. " +
                        "Check the 'Upload APK artifact' step in the workflow log.")

            artifactDownloadUrl = artUrl
            appendLog("Artifact ready: $artName")
            setStatus("Ready ✓")
            mainHandler.post { btnDownloadApk.isEnabled = true }

        } catch (e: Exception) {
            appendLog("✗ ${e.message}")
            setStatus("Failed")
        } finally {
            setBusy(false)
        }
    }

    // ── GitHub API helpers ───────────────────────────────────────────────────

    /** GET the SHA of an existing file (returns null if absent) */
    private fun fetchFileSha(token: String, owner: String, repo: String, path: String): String? =
        try {
            val (code, body) = httpGet(token, apiContents(owner, repo, path))
            if (code == 200) JSONObject(body).optString("sha").takeIf { it.isNotEmpty() }
            else null
        } catch (_: Exception) { null }

    /**
     * Poll /actions/runs until a run created after [afterMs] appears for the workflow.
     * Retries for up to 3 minutes.
     */
    private fun waitForRun(token: String, owner: String, repo: String, branch: String, afterMs: Long): Long? {
        val deadline = System.currentTimeMillis() + 3 * 60_000L
        while (System.currentTimeMillis() < deadline) {
            try {
                val url = "${apiRuns(owner, repo)}?branch=$branch&per_page=10&event=push"
                val (code, body) = httpGet(token, url)
                if (code == 200) {
                    val runs = JSONObject(body).getJSONArray("workflow_runs")
                    for (i in 0 until runs.length()) {
                        val run       = runs.getJSONObject(i)
                        val createdAt = run.getString("created_at")   // e.g. "2024-06-01T10:00:00Z"
                        val runMs     = parseIso8601(createdAt)
                        if (runMs >= afterMs - 15_000) {              // 15 s tolerance
                            return run.getLong("id")
                        }
                    }
                }
            } catch (_: Exception) {}
            Thread.sleep(10_000)
        }
        return null
    }

    /**
     * Poll a specific run until status == "completed".
     * Waits up to 45 minutes (typical Android build).
     */
    private fun pollRunUntilDone(token: String, owner: String, repo: String, runId: Long): Boolean {
        val deadline = System.currentTimeMillis() + 45 * 60_000L
        while (System.currentTimeMillis() < deadline) {
            try {
                val (code, body) = httpGet(token, "${apiRuns(owner, repo)}/$runId")
                if (code == 200) {
                    val obj        = JSONObject(body)
                    val status     = obj.getString("status")
                    val conclusion = obj.optString("conclusion", "-")
                    val elapsed    = obj.optString("run_started_at", "")
                    appendLog("  status=$status  conclusion=$conclusion")
                    if (status == "completed") return conclusion == "success"
                }
            } catch (_: Exception) {}
            Thread.sleep(15_000)
        }
        return false
    }

    /** Retrieve the first artifact for a run → (name, archive_download_url) */
    private fun fetchArtifact(token: String, owner: String, repo: String, runId: Long): Pair<String, String>? {
        val (code, body) = httpGet(token, "${apiRuns(owner, repo)}/$runId/artifacts")
        if (code != 200) return null
        val artifacts = JSONObject(body).getJSONArray("artifacts")
        if (artifacts.length() == 0) return null
        val art = artifacts.getJSONObject(0)
        return art.getString("name") to art.getString("archive_download_url")
    }

    // ── Download & install ───────────────────────────────────────────────────

    /**
     * Downloads the artifact ZIP (GitHub redirects to S3), extracts the .apk,
     * and fires an install intent via FileProvider.
     */
    private fun downloadArtifact(downloadUrl: String) {
        if (isBusy) return
        setBusy(true)
        btnDownloadApk.isEnabled = false
        setStatus("Downloading…")
        appendLog("Downloading artifact ZIP…")
        val token = etToken.text.toString().trim()

        thread {
            try {
                // Step 1: follow GitHub's redirect to get the real download URL
                var conn = URL(downloadUrl).openConnection() as HttpURLConnection
                conn.setRequestProperty("Authorization", "token $token")
                conn.setRequestProperty("Accept", "application/vnd.github.v3+json")
                conn.instanceFollowRedirects = false
                conn.connectTimeout = 30_000
                conn.readTimeout    = 30_000
                conn.connect()

                val realUrl = if (conn.responseCode in 301..308) {
                    val loc = conn.getHeaderField("Location")
                    conn.disconnect()
                    loc
                } else {
                    // Not redirected; download directly (shouldn't happen but handled)
                    downloadUrl
                }

                // Step 2: download the actual ZIP (unauthenticated S3 URL)
                val dlConn = URL(realUrl).openConnection() as HttpURLConnection
                dlConn.connectTimeout = 60_000
                dlConn.readTimeout   = 180_000
                val total = dlConn.contentLength
                appendLog("Downloading… (${if (total > 0) "${total / 1024} KB" else "size unknown"})")

                val artifactZip = File(cacheDir, "artifact_${System.currentTimeMillis()}.zip")
                dlConn.inputStream.use { inp -> FileOutputStream(artifactZip).use { inp.copyTo(it) } }
                dlConn.disconnect()
                appendLog("Downloaded: ${artifactZip.length() / 1024} KB")

                // Step 3: extract the .apk from inside the artifact ZIP
                val apkFile = extractApk(artifactZip)
                    ?: throw Exception("No .apk found inside the artifact ZIP.")
                appendLog("Extracted: ${apkFile.name}  (${apkFile.length() / 1024} KB)")

                setStatus("Done ✓")
                mainHandler.post {
                    btnDownloadApk.isEnabled = true
                    offerInstall(apkFile)
                }

            } catch (e: Exception) {
                appendLog("✗ Download error: ${e.message}")
                setStatus("Download failed")
                mainHandler.post { btnDownloadApk.isEnabled = true }
            } finally {
                setBusy(false)
            }
        }
    }

    /** Unzip the artifact and return the first .apk file found */
    private fun extractApk(zipFile: File): File? {
        val outDir = File(cacheDir, "apks").also { it.mkdirs() }
        ZipInputStream(zipFile.inputStream().buffered()).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                if (!entry.isDirectory && entry.name.endsWith(".apk")) {
                    val out = File(outDir, File(entry.name).name)
                    FileOutputStream(out).use { zis.copyTo(it) }
                    return out
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
        return null
    }

    /** Open the Android package installer via FileProvider */
    private fun offerInstall(apkFile: File) {
        val uri = FileProvider.getUriForFile(this, "${packageName}.provider", apkFile)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION
        }
        startActivity(Intent.createChooser(intent, "Install APK"))
    }

    // ── Low-level HTTP ───────────────────────────────────────────────────────

    private fun httpGet(token: String, urlStr: String): Pair<Int, String> {
        val conn = URL(urlStr).openConnection() as HttpURLConnection
        conn.apply {
            requestMethod = "GET"
            setRequestProperty("Authorization", "token $token")
            setRequestProperty("Accept", "application/vnd.github.v3+json")
            connectTimeout = 30_000
            readTimeout    = 30_000
        }
        return readResponse(conn)
    }

    private fun httpPut(token: String, urlStr: String, body: String): Pair<Int, String> {
        val conn = URL(urlStr).openConnection() as HttpURLConnection
        conn.apply {
            requestMethod = "PUT"
            setRequestProperty("Authorization", "token $token")
            setRequestProperty("Accept", "application/vnd.github.v3+json")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            doOutput = true
            connectTimeout = 120_000   // large upload can take time
            readTimeout    = 120_000
        }
        conn.outputStream.bufferedWriter().use { it.write(body) }
        return readResponse(conn)
    }

    private fun readResponse(conn: HttpURLConnection): Pair<Int, String> =
        try {
            val code = conn.responseCode
            val stream = if (code < 400) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.readText() ?: ""
            Pair(code, text)
        } finally {
            conn.disconnect()
        }

    // ── URL builders ─────────────────────────────────────────────────────────

    private fun apiContents(owner: String, repo: String, path: String) =
        "https://api.github.com/repos/$owner/$repo/contents/$path"

    private fun apiRuns(owner: String, repo: String) =
        "https://api.github.com/repos/$owner/$repo/actions/runs"

    // ── UI helpers ───────────────────────────────────────────────────────────

    private fun setStatus(text: String) = mainHandler.post {
        tvStatus.text = text
        tvStatus.setTextColor(
            when {
                text.contains("✓") || text.startsWith("Ready") || text.startsWith("Done") ->
                    0xFF4CAF50.toInt()
                text.contains("✗") || text.startsWith("Fail") ->
                    0xFFFF5252.toInt()
                else -> 0xFFFFFFFF.toInt()
            }
        )
    }

    private fun appendLog(msg: String) = mainHandler.post {
        tvLog.append("$msg\n")
        scrollLog.post { scrollLog.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun setBusy(busy: Boolean) = mainHandler.post {
        isBusy              = busy
        progressBar.visibility = if (busy) View.VISIBLE else View.GONE
        btnUploadBuild.isEnabled = !busy
        btnPickZip.isEnabled     = !busy
    }

    // ── Utilities ─────────────────────────────────────────────────────────────

    private fun resolveFileName(uri: Uri): String {
        var name = "project.zip"
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val col = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (c.moveToFirst() && col >= 0) name = c.getString(col)
        }
        // Sanitise: keep only alphanumerics, dots, hyphens, underscores
        name = name.replace(Regex("[^a-zA-Z0-9._\\-]"), "_")
        if (!name.lowercase().endsWith(".zip")) name += ".zip"
        return name
    }

    private fun parseIso8601(s: String): Long = try {
        SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
            .apply { timeZone = TimeZone.getTimeZone("UTC") }
            .parse(s)?.time ?: 0L
    } catch (_: Exception) { 0L }
}
