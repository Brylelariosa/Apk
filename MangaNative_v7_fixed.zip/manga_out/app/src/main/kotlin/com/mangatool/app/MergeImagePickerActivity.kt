package com.mangatool.app

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mangatool.app.util.BitmapUtils

class MergeImagePickerActivity : AppCompatActivity() {

    companion object {
        const val RESULT_URIS = "selected_uris"
    }

    private lateinit var recycler: RecyclerView
    private lateinit var btnAdd: Button
    private lateinit var selectionBar: TextView
    private lateinit var tvCount: TextView

    private val allImages    = mutableListOf<DeviceImage>()
    private val selectedUris = linkedSetOf<String>()   // store as String for Parcelable ease

    data class DeviceImage(val uri: Uri, val id: Long)

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results.values.any { it }) loadImages()
        else { tvCount.text = "Storage permission denied" }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_merge_picker)

        recycler     = findViewById(R.id.picker_grid)
        btnAdd       = findViewById(R.id.btn_add_selected)
        selectionBar = findViewById(R.id.tv_selection_bar)
        tvCount      = findViewById(R.id.tv_picker_count)

        findViewById<ImageButton>(R.id.btn_picker_back).setOnClickListener { finish() }
        btnAdd.setOnClickListener { returnSelected() }
        btnAdd.isEnabled = false

        checkAndLoad()
    }

    private fun checkAndLoad() {
        val needed = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            arrayOf(Manifest.permission.READ_MEDIA_IMAGES)
        else
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)

        val ok = needed.all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }
        if (ok) loadImages() else permLauncher.launch(needed)
    }

    private fun loadImages() {
        Thread {
            val proj = arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.DATE_ADDED)
            contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                proj, null, null, "${MediaStore.Images.Media.DATE_ADDED} DESC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                while (cursor.moveToNext()) {
                    val id  = cursor.getLong(idCol)
                    val uri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id)
                    allImages.add(DeviceImage(uri, id))
                }
            }
            runOnUiThread {
                tvCount.text = "${allImages.size} photos"
                // Compute square cell size from screen width
                val screenW = resources.displayMetrics.widthPixels
                val cellSize = screenW / 3
                recycler.layoutManager = GridLayoutManager(this, 3)
                recycler.adapter = PickerAdapter(cellSize)
            }
        }.start()
    }

    private fun refreshUI() {
        val n = selectedUris.size
        btnAdd.isEnabled = n > 0
        btnAdd.text = if (n > 0) "Add $n image${if (n == 1) "" else "s"}" else "Add"
        selectionBar.text = if (n > 0) "$n selected  ·  tap to deselect" else "Tap images to select"
    }

    private fun returnSelected() {
        if (selectedUris.isEmpty()) { finish(); return }
        val data = Intent().apply {
            putStringArrayListExtra(RESULT_URIS, ArrayList(selectedUris))
        }
        setResult(Activity.RESULT_OK, data)
        finish()
    }

    // ── Adapter ────────────────────────────────────────────────────────────────
    inner class PickerAdapter(private val cellSize: Int) : RecyclerView.Adapter<PickerAdapter.VH>() {

        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val image:   ImageView = v.findViewById(R.id.picker_thumb)
            val check:   View      = v.findViewById(R.id.picker_check)
            val overlay: View      = v.findViewById(R.id.picker_overlay)
            val badge:   TextView  = v.findViewById(R.id.picker_badge)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_picker_thumb, parent, false)
            v.layoutParams = v.layoutParams.also { it.height = cellSize }
            return VH(v)
        }

        override fun getItemCount() = allImages.size

        override fun onBindViewHolder(holder: VH, position: Int) {
            val img      = allImages[position]
            val uriStr   = img.uri.toString()
            val selected = uriStr in selectedUris

            holder.overlay.visibility = if (selected) View.VISIBLE else View.GONE
            holder.check.visibility   = if (selected) View.VISIBLE else View.GONE

            val selIdx = selectedUris.indexOf(uriStr)
            holder.badge.visibility = if (selIdx >= 0) View.VISIBLE else View.GONE
            if (selIdx >= 0) holder.badge.text = "${selIdx + 1}"

            holder.image.setImageBitmap(null)
            val cacheKey = "pick_${img.id}"
            AppState.thumbCache.get(cacheKey)?.let { holder.image.setImageBitmap(it); return }

            holder.image.tag = cacheKey
            Thread {
                val bmp = runCatching {
                    contentResolver.openInputStream(img.uri)?.use { s ->
                        BitmapUtils.decodeThumbnail(s.readBytes(), 240)
                    }
                }.getOrNull()
                if (bmp != null) {
                    AppState.thumbCache.put(cacheKey, bmp)
                    if (holder.image.tag == cacheKey)
                        holder.image.post { holder.image.setImageBitmap(bmp) }
                }
            }.start()

            holder.itemView.setOnClickListener {
                if (uriStr in selectedUris) selectedUris.remove(uriStr)
                else selectedUris.add(uriStr)
                notifyItemChanged(position)
                refreshUI()
            }
        }
    }
}

private fun <T> LinkedHashSet<T>.indexOf(element: T): Int {
    var i = 0; for (e in this) { if (e == element) return i; i++ }; return -1
}
